000000000010e900 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 00000010E900: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 00000010E904: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 00000010E90C: F4080500 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 00000010E914: 3706009F
	v_lshrrev_b32_e32 v155, 5, v0                              // 00000010E918: 33360085
	s_mov_b32 s24, s3                                          // 00000010E91C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010E920: BF870112
	.long 0xd44c0003                                           // 00000010E924: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 00000010E928: 02030690
	v_lshlrev_b32_e32 v132, 6, v155                            // 00000010E92C: 31093686
	s_waitcnt lgkmcnt(0)                                       // 00000010E930: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 00000010E934: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 00000010E93C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010E940: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 00000010E944: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 00000010E94C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:231 offset1:243// 00000010E958: D83CF3E7 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 00000010E960: 8C7E047E
	v_mul_u32_u24_e32 v1, 0x2ab, v0                            // 00000010E964: 160200FF 000002AB
	s_lshl_b32 s25, s2, 5                                      // 00000010E96C: 84198502
	v_dual_mov_b32 v141, 0 :: v_dual_and_b32 v154, 15, v0      // 00000010E970: CA240080 8D9A008F
	s_cmp_eq_u64 s[14:15], 0                                   // 00000010E978: BF10800E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000010E97C: BF8704C2
	.long 0xd7381001                                           // 00000010E980: D7381001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000010E984: 02020282
	.long 0x7f023880                                           // 00000010E988: 7F023880
	v_mov_b32_e32 v142, 0                                      // 00000010E98C: 7F1C0280
	s_cselect_b32 s27, -1, 0                                   // 00000010E990: 981B80C1
	s_and_b32 vcc_lo, exec_lo, s27                             // 00000010E994: 8B6A1B7E
	.long 0xd7620001                                           // 00000010E998: D7620001
	v_cndmask_b32_e32 v0, v1, v176, vcc_lo                     // 00000010E99C: 02016101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E9A0: BF870091
	v_add_nc_u32_e32 v156, s25, v1                             // 00000010E9A4: 4B380219
	v_or_b32_e32 v129, v156, v154                              // 00000010E9A8: 3903359C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010E9AC: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 00000010E9B0: 3505029F
	s_cbranch_vccnz 10                                         // 00000010E9B4: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xe0>
	v_mad_i64_i32 v[1:2], null, s23, v129, 0                   // 00000010E9B8: D6FF7C01 02030217
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E9C0: BF870091
	.long 0xd73c0001                                           // 00000010E9C4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000010E9C8: 02020282
	.long 0xd7006a8d                                           // 00000010E9CC: D7006A8D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000010E9D0: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010E9D4: BF870001
	v_add_co_ci_u32_e64 v142, null, s15, v2, vcc_lo            // 00000010E9D8: D5207C8E 01AA040F
	s_clause 0x2                                               // 00000010E9E0: BF850002
	s_load_b64 s[14:15], s[0:1], 0x38                          // 00000010E9E4: F4040380 F8000038
	s_load_b128 s[16:19], s[0:1], 0x20                         // 00000010E9EC: F4080400 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 00000010E9F4: F40C0100 F8000000
	v_mov_b32_e32 v158, 0                                      // 00000010E9FC: 7F3C0280
	s_xor_b32 s0, s27, -1                                      // 00000010EA00: 8D00C11B
	s_waitcnt lgkmcnt(0)                                       // 00000010EA04: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v129                         // 00000010EA08: 7C89020E
	s_and_b32 s23, s0, vcc_lo                                  // 00000010EA0C: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010EA10: BF870009
	s_and_saveexec_b32 s0, s23                                 // 00000010EA14: BE802017
	s_cbranch_execz 9                                          // 00000010EA18: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x140>
	.long 0xd73c0001                                           // 00000010EA1C: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 00000010EA20: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010EA24: BF870091
	.long 0xd7006a01                                           // 00000010EA28: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 00000010EA2C: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 00000010EA30: D5207C02 01AA0415
	global_load_b32 v158, v[1:2], off                          // 00000010EA38: DC520000 9E7C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 00000010EA40: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 00000010EA44: BF10800C
	s_mov_b64 s[20:21], 0                                      // 00000010EA48: BE940180
	s_cbranch_scc1 10                                          // 00000010EA4C: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x178>
	s_ashr_i32 s0, s22, 31                                     // 00000010EA50: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 00000010EA54: 96810216
	s_mul_i32 s0, s0, s2                                       // 00000010EA58: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000010EA5C: BF8704A9
	s_add_i32 s1, s1, s0                                       // 00000010EA60: 81010001
	s_mul_i32 s0, s22, s2                                      // 00000010EA64: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000010EA68: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010EA6C: BF870009
	s_add_u32 s20, s12, s0                                     // 00000010EA70: 8014000C
	s_addc_u32 s21, s13, s1                                    // 00000010EA74: 8215010D
	.long 0xd7050001                                           // 00000010EA78: D7050001
	v_cndmask_b32_e32 v0, v155, v150, vcc_lo                   // 00000010EA7C: 02012D9B
	s_or_b32 s25, s25, 31                                      // 00000010EA80: 8C199F19
	s_add_i32 s0, s14, -1                                      // 00000010EA84: 8100C10E
	v_lshrrev_b32_e32 v157, 4, v131                            // 00000010EA88: 333B0684
	s_min_i32 s0, s25, s0                                      // 00000010EA8C: 89000019
	.long 0xd7390001                                           // 00000010EA90: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 00000010EA94: 02020288
	s_add_i32 s0, s26, s0                                      // 00000010EA98: 8100001A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010EA9C: BF870099
	s_cmp_lt_i32 s0, -15                                       // 00000010EAA0: BF04CF00
	.long 0xd7050001                                           // 00000010EAA4: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 00000010EAA8: 02011901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010EAAC: BF870091
	.long 0xd7040001                                           // 00000010EAB0: D7040001
	v_cndmask_b32_e32 v1, v155, v1, vcc_lo                     // 00000010EAB4: 0202039B
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 00000010EAB8: CA240080 480002FF 000000FF
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010EAC4: BF870001
	v_mov_b32_e32 v71, v72                                     // 00000010EAC8: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 00000010EACC: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 00000010EAD0: 7E880348
	v_mov_b32_e32 v67, v72                                     // 00000010EAD4: 7E860348
	v_mad_u64_u32 v[138:139], null, s24, 12, v[1:2]            // 00000010EAD8: D6FE7C8A 04051818
	v_mov_b32_e32 v70, v72                                     // 00000010EAE0: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 00000010EAE4: 7E840348
	v_mov_b32_e32 v65, v72                                     // 00000010EAE8: 7E820348
	v_mov_b32_e32 v80, v72                                     // 00000010EAEC: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 00000010EAF0: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 00000010EAF4: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 00000010EAF8: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 00000010EAFC: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 00000010EB04: 7E960348
	v_mov_b32_e32 v74, v72                                     // 00000010EB08: 7E940348
	v_mov_b32_e32 v73, v72                                     // 00000010EB0C: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 00000010EB10: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000010EB14: 3404029F
	v_mov_b32_e32 v88, v72                                     // 00000010EB18: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 00000010EB1C: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 00000010EB20: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 00000010EB24: 7EAA0348
	.long 0xd73c008b                                           // 00000010EB28: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000010EB2C: 02020281
	v_mov_b32_e32 v84, v72                                     // 00000010EB30: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 00000010EB34: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 00000010EB38: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 00000010EB3C: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 00000010EB40: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 00000010EB44: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 00000010EB48: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 00000010EB4C: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 00000010EB50: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 00000010EB54: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 00000010EB58: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 00000010EB5C: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 00000010EB60: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 00000010EB64: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 00000010EB68: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 00000010EB6C: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 00000010EB70: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 00000010EB74: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 00000010EB78: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 00000010EB7C: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 00000010EB80: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 00000010EB84: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 00000010EB88: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 00000010EB8C: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 00000010EB90: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 00000010EB94: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 00000010EB98: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 00000010EB9C: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 00000010EBA0: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 00000010EBA4: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 00000010EBA8: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 00000010EBAC: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 00000010EBB0: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 00000010EBB4: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 00000010EBB8: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 00000010EBBC: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 00000010EBC0: 7F000348
	v_mov_b32_e32 v127, v72                                    // 00000010EBC4: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 00000010EBC8: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 00000010EBCC: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 00000010EBD0: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 00000010EBD4: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 00000010EBD8: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 00000010EBDC: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 00000010EBE0: 7E800348
	v_mov_b32_e32 v63, v72                                     // 00000010EBE4: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 00000010EBE8: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 00000010EBEC: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 00000010EBF0: 7E780348
	v_mov_b32_e32 v59, v72                                     // 00000010EBF4: 7E760348
	v_mov_b32_e32 v58, v72                                     // 00000010EBF8: 7E740348
	v_mov_b32_e32 v57, v72                                     // 00000010EBFC: 7E720348
	v_mov_b32_e32 v56, v72                                     // 00000010EC00: 7E700348
	v_mov_b32_e32 v55, v72                                     // 00000010EC04: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 00000010EC08: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 00000010EC0C: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 00000010EC10: 7E680348
	v_mov_b32_e32 v51, v72                                     // 00000010EC14: 7E660348
	v_mov_b32_e32 v50, v72                                     // 00000010EC18: 7E640348
	v_mov_b32_e32 v49, v72                                     // 00000010EC1C: 7E620348
	v_mov_b32_e32 v48, v72                                     // 00000010EC20: 7E600348
	v_mov_b32_e32 v47, v72                                     // 00000010EC24: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 00000010EC28: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 00000010EC2C: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 00000010EC30: 7E580348
	v_mov_b32_e32 v43, v72                                     // 00000010EC34: 7E560348
	v_mov_b32_e32 v42, v72                                     // 00000010EC38: 7E540348
	v_mov_b32_e32 v41, v72                                     // 00000010EC3C: 7E520348
	v_mov_b32_e32 v40, v72                                     // 00000010EC40: 7E500348
	v_mov_b32_e32 v39, v72                                     // 00000010EC44: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 00000010EC48: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 00000010EC4C: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 00000010EC50: 7E480348
	v_mov_b32_e32 v35, v72                                     // 00000010EC54: 7E460348
	v_mov_b32_e32 v34, v72                                     // 00000010EC58: 7E440348
	v_mov_b32_e32 v33, v72                                     // 00000010EC5C: 7E420348
	v_mov_b32_e32 v32, v72                                     // 00000010EC60: 7E400348
	v_mov_b32_e32 v31, v72                                     // 00000010EC64: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 00000010EC68: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 00000010EC6C: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 00000010EC70: 7E380348
	v_mov_b32_e32 v27, v72                                     // 00000010EC74: 7E360348
	v_mov_b32_e32 v26, v72                                     // 00000010EC78: 7E340348
	v_mov_b32_e32 v25, v72                                     // 00000010EC7C: 7E320348
	v_mov_b32_e32 v24, v72                                     // 00000010EC80: 7E300348
	v_mov_b32_e32 v23, v72                                     // 00000010EC84: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 00000010EC88: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 00000010EC8C: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 00000010EC90: 7E280348
	v_mov_b32_e32 v19, v72                                     // 00000010EC94: 7E260348
	v_mov_b32_e32 v18, v72                                     // 00000010EC98: 7E240348
	v_mov_b32_e32 v17, v72                                     // 00000010EC9C: 7E220348
	v_mov_b32_e32 v16, v72                                     // 00000010ECA0: 7E200348
	v_mov_b32_e32 v15, v72                                     // 00000010ECA4: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 00000010ECA8: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 00000010ECAC: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 00000010ECB0: 7E180348
	v_mov_b32_e32 v11, v72                                     // 00000010ECB4: 7E160348
	v_mov_b32_e32 v10, v72                                     // 00000010ECB8: 7E140348
	v_mov_b32_e32 v9, v72                                      // 00000010ECBC: 7E120348
	v_mov_b32_e32 v8, v72                                      // 00000010ECC0: 7E100348
	v_mov_b32_e32 v7, v72                                      // 00000010ECC4: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 00000010ECC8: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 00000010ECCC: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 00000010ECD0: 7E080348
	v_mov_b32_e32 v3, v72                                      // 00000010ECD4: 7E060348
	v_mov_b32_e32 v2, v72                                      // 00000010ECD8: 7E040348
	v_mov_b32_e32 v1, v72                                      // 00000010ECDC: 7E020348
	s_cbranch_scc1 2250                                        // 00000010ECE0: BFA208CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x270c>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[4:5]           // 00000010ECE4: D6FF7C01 001302FF 00003000
	s_ashr_i32 s1, s0, 31                                      // 00000010ECF0: 86019F00
	v_lshlrev_b32_e32 v4, 2, v131                              // 00000010ECF4: 30090682
	s_lshr_b32 s1, s1, 28                                      // 00000010ECF8: 85019C01
	v_add3_u32 v161, v156, v131, s26                           // 00000010ECFC: D65500A1 006B079C
	s_add_i32 s0, s0, s1                                       // 00000010ED04: 81000100
	s_movk_i32 s1, 0x440                                       // 00000010ED08: B0010440
	s_ashr_i32 s5, s0, 4                                       // 00000010ED0C: 86058400
	.long 0xd7006a8f                                           // 00000010ED10: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 00000010ED14: 02031701
	v_add3_u32 v1, v129, s26, 1                                // 00000010ED18: D6550001 02043581
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 00000010ED20: D5207C90 01AB1902
	v_mad_u32_u24 v3, v155, s1, 0x3000                         // 00000010ED28: D60B0003 03FC039B 00003000
	v_mov_b32_e32 v129, 0                                      // 00000010ED34: 7F020280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000010ED38: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000010ED3C: 3404029F
	.long 0xd44c0000                                           // 00000010ED40: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 00000010ED44: 020200FF 00000200
	s_cmp_eq_u64 s[20:21], 0                                   // 00000010ED4C: BF108014
	v_mad_u32_u24 v5, 0x44, v157, v3                           // 00000010ED50: D60B0005 040F3AFF 00000044
	v_mad_u32_u24 v163, 0x44, v131, v3                         // 00000010ED5C: D60B00A3 040F06FF 00000044
	v_lshrrev_b32_e32 v2, 30, v2                               // 00000010ED68: 3204049E
	v_lshlrev_b32_e32 v3, 4, v0                                // 00000010ED6C: 30060084
	v_add_nc_u32_e32 v6, 0xed00, v132                          // 00000010ED70: 4A0D08FF 0000ED00
	v_lshl_add_u32 v159, v154, 2, v5                           // 00000010ED78: D646009F 0415059A
	v_lshlrev_b32_e32 v5, 9, v155                              // 00000010ED80: 300B3689
	v_add_nc_u32_e32 v1, v1, v2                                // 00000010ED84: 4A020501
	v_add_nc_u32_e32 v2, v132, v4                              // 00000010ED88: 4A040984
	s_cselect_b32 s12, -1, 0                                   // 00000010ED8C: 980C80C1
	s_cmp_lg_u64 s[20:21], 0                                   // 00000010ED90: BF118014
	v_mov_b32_e32 v7, v129                                     // 00000010ED94: 7E0E0381
	v_ashrrev_i32_e32 v160, 2, v1                              // 00000010ED98: 35400282
	v_lshrrev_b32_e32 v1, 1, v0                                // 00000010ED9C: 32020081
	v_add_nc_u32_e32 v162, 0xe700, v2                          // 00000010EDA0: 4B4404FF 0000E700
	v_add_nc_u32_e32 v0, 0xf300, v2                            // 00000010EDA8: 4A0004FF 0000F300
	s_cselect_b32 s13, -1, 0                                   // 00000010EDB0: 980D80C1
	s_ashr_i32 s25, s24, 31                                    // 00000010EDB4: 86199F18
	v_and_b32_e32 v1, 0xf8, v1                                 // 00000010EDB8: 360202FF 000000F8
	s_lshl_b64 s[24:25], s[24:25], 9                           // 00000010EDC0: 84988918
	s_add_i32 s15, s15, -1                                     // 00000010EDC4: 810FC10F
	s_add_u32 s2, s6, s24                                      // 00000010EDC8: 80021806
	s_addc_u32 s1, s7, s25                                     // 00000010EDCC: 82011907
	v_mul_u32_u24_e32 v2, 48, v1                               // 00000010EDD0: 160402B0
	s_add_u32 s4, s8, s24                                      // 00000010EDD4: 80041808
	s_addc_u32 s6, s9, s25                                     // 00000010EDD8: 82061909
	s_movk_i32 s7, 0x210                                       // 00000010EDDC: B0070210
	v_mov_b32_e32 v11, v129                                    // 00000010EDE0: 7E160381
	v_lshl_or_b32 v2, v154, 1, v2                              // 00000010EDE4: D6560002 0409039A
	v_mov_b32_e32 v13, v129                                    // 00000010EDEC: 7E1A0381
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, v129           // 00000010EDF0: CA100080 090A0181
	s_delay_alu instid0(VALU_DEP_3)                            // 00000010EDF8: BF870003
	v_dual_mov_b32 v8, v129 :: v_dual_add_nc_u32 v169, 0x9600, v2// 00000010EDFC: CA200181 08A804FF 00009600
	v_mov_b32_e32 v12, v129                                    // 00000010EE08: 7E180381
	v_mov_b32_e32 v2, v129                                     // 00000010EE0C: 7E040381
	v_lshl_add_u32 v164, v131, 5, v5                           // 00000010EE10: D64600A4 04150B83
	v_lshl_or_b32 v167, v154, 5, v5                            // 00000010EE18: D65600A7 04150B9A
	v_mov_b32_e32 v5, v129                                     // 00000010EE20: 7E0A0381
	v_add_nc_u32_e32 v165, v6, v4                              // 00000010EE24: 4B4A0906
	v_lshl_or_b32 v166, v157, 2, v6                            // 00000010EE28: D65600A6 0419059D
	v_mov_b32_e32 v6, v129                                     // 00000010EE30: 7E0C0381
	v_and_b32_e32 v130, 0x1f0, v3                              // 00000010EE34: 370406FF 000001F0
	v_dual_mov_b32 v4, v129 :: v_dual_lshlrev_b32 v131, 1, v1  // 00000010EE3C: CA220181 04820281
	v_mul_u32_u24_e32 v3, 0x210, v155                          // 00000010EE44: 160736FF 00000210
	v_mov_b32_e32 v1, 0                                        // 00000010EE4C: 7E020280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010EE50: BF870094
	.long 0xd70002ac                                           // 00000010EE54: D70002AC
	v_cndmask_b32_e32 v1, s2, v130, vcc_lo                     // 00000010EE58: 02030402
	v_add_co_ci_u32_e64 v173, null, s1, 0, s2                  // 00000010EE5C: D5207CAD 00090001
	.long 0xd70001ae                                           // 00000010EE64: D70001AE
	v_cndmask_b32_e32 v1, s4, v131, vcc_lo                     // 00000010EE68: 02030604
	v_add3_u32 v168, v3, v130, 0xc600                          // 00000010EE6C: D65500A8 03FF0503 0000C600
	v_mov_b32_e32 v3, v129                                     // 00000010EE78: 7E060381
	v_dual_mov_b32 v14, v129 :: v_dual_mov_b32 v17, 0          // 00000010EE7C: CA100181 0E100080
	v_mov_b32_e32 v15, v129                                    // 00000010EE84: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v25, 0          // 00000010EE88: CA100181 10180080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v33, 0          // 00000010EE90: CA100181 12200080
	v_mov_b32_e32 v19, v129                                    // 00000010EE98: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v41, 0          // 00000010EE9C: CA100181 14280080
	v_mov_b32_e32 v21, v129                                    // 00000010EEA4: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v49, 0          // 00000010EEA8: CA100181 16300080
	v_mov_b32_e32 v23, v129                                    // 00000010EEB0: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v57, 0          // 00000010EEB4: CA100181 18380080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v121, 0         // 00000010EEBC: CA100181 1A780080
	v_mov_b32_e32 v27, v129                                    // 00000010EEC4: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v113, 0         // 00000010EEC8: CA100181 1C700080
	v_mov_b32_e32 v29, v129                                    // 00000010EED0: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v105, 0         // 00000010EED4: CA100181 1E680080
	v_mov_b32_e32 v31, v129                                    // 00000010EEDC: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v97, 0          // 00000010EEE0: CA100181 20600080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v89, 0          // 00000010EEE8: CA100181 22580080
	v_mov_b32_e32 v35, v129                                    // 00000010EEF0: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v81, 0          // 00000010EEF4: CA100181 24500080
	v_mov_b32_e32 v37, v129                                    // 00000010EEFC: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v73, 0          // 00000010EF00: CA100181 26480080
	v_mov_b32_e32 v39, v129                                    // 00000010EF08: 7E4E0381
	v_dual_mov_b32 v40, v129 :: v_dual_mov_b32 v65, 0          // 00000010EF0C: CA100181 28400080
	v_dual_mov_b32 v42, v129 :: v_dual_mov_b32 v145, 0         // 00000010EF14: CA100181 2A900080
	v_mov_b32_e32 v43, v129                                    // 00000010EF1C: 7E560381
	v_mov_b32_e32 v44, v129                                    // 00000010EF20: 7E580381
	v_mov_b32_e32 v45, v129                                    // 00000010EF24: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 00000010EF28: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 00000010EF2C: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 00000010EF30: 7E600381
	v_mov_b32_e32 v50, v129                                    // 00000010EF34: 7E640381
	v_mov_b32_e32 v51, v129                                    // 00000010EF38: 7E660381
	v_mov_b32_e32 v52, v129                                    // 00000010EF3C: 7E680381
	v_mov_b32_e32 v53, v129                                    // 00000010EF40: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 00000010EF44: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 00000010EF48: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 00000010EF4C: 7E700381
	v_mov_b32_e32 v58, v129                                    // 00000010EF50: 7E740381
	v_mov_b32_e32 v59, v129                                    // 00000010EF54: 7E760381
	v_mov_b32_e32 v60, v129                                    // 00000010EF58: 7E780381
	v_mov_b32_e32 v61, v129                                    // 00000010EF5C: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 00000010EF60: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 00000010EF64: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 00000010EF68: 7E800381
	v_mov_b32_e32 v122, v129                                   // 00000010EF6C: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 00000010EF70: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 00000010EF74: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 00000010EF78: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 00000010EF7C: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 00000010EF80: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 00000010EF84: 7F000381
	v_mov_b32_e32 v114, v129                                   // 00000010EF88: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 00000010EF8C: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 00000010EF90: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 00000010EF94: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 00000010EF98: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 00000010EF9C: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 00000010EFA0: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 00000010EFA4: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 00000010EFA8: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 00000010EFAC: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 00000010EFB0: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 00000010EFB4: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 00000010EFB8: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 00000010EFBC: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 00000010EFC0: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 00000010EFC4: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 00000010EFC8: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 00000010EFCC: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 00000010EFD0: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 00000010EFD4: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 00000010EFD8: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 00000010EFDC: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 00000010EFE0: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 00000010EFE4: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 00000010EFE8: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 00000010EFEC: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 00000010EFF0: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 00000010EFF4: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 00000010EFF8: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 00000010EFFC: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 00000010F000: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 00000010F004: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 00000010F008: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 00000010F00C: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 00000010F010: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 00000010F014: 7E940381
	v_mov_b32_e32 v75, v129                                    // 00000010F018: 7E960381
	v_mov_b32_e32 v76, v129                                    // 00000010F01C: 7E980381
	v_mov_b32_e32 v77, v129                                    // 00000010F020: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 00000010F024: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 00000010F028: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 00000010F02C: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 00000010F030: 7E840381
	v_mov_b32_e32 v67, v129                                    // 00000010F034: 7E860381
	v_mov_b32_e32 v68, v129                                    // 00000010F038: 7E880381
	v_mov_b32_e32 v69, v129                                    // 00000010F03C: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 00000010F040: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 00000010F044: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 00000010F048: 7E900381
	v_mad_u32_u24 v170, v154, s7, 0xc600                       // 00000010F04C: D60B00AA 03FC0F9A 0000C600
	v_mad_u32_u24 v171, v154, 48, 0x9600                       // 00000010F058: D60B00AB 03FD619A 00009600
	v_add_co_ci_u32_e64 v175, null, s6, 0, s1                  // 00000010F064: D5207CAF 00050006
	s_mov_b32 s6, 0                                            // 00000010F06C: BE860080
	s_branch 116                                               // 00000010F070: BFA00074 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x944>
	ds_load_b128 v[146:149], v171                              // 00000010F074: DBFC0000 920000AB
	ds_load_b128 v[150:153], v171 offset:16                    // 00000010F07C: DBFC0010 960000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F084: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[146:153], v[121:128]// 00000010F088: CC414079 1DE72582
	ds_load_b128 v[150:153], v171 offset:784                   // 00000010F090: DBFC0310 960000AB
	ds_load_b128 v[146:149], v171 offset:768                   // 00000010F098: DBFC0300 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F0A0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[146:153], v[113:120]// 00000010F0A4: CC414071 1DC72582
	ds_load_b128 v[150:153], v171 offset:1552                  // 00000010F0AC: DBFC0610 960000AB
	ds_load_b128 v[146:149], v171 offset:1536                  // 00000010F0B4: DBFC0600 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F0BC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[146:153], v[105:112]// 00000010F0C0: CC414069 1DA72582
	ds_load_b128 v[150:153], v171 offset:2320                  // 00000010F0C8: DBFC0910 960000AB
	ds_load_b128 v[146:149], v171 offset:2304                  // 00000010F0D0: DBFC0900 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F0D8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[146:153], v[97:104]// 00000010F0DC: CC414061 1D872582
	ds_load_b128 v[150:153], v171 offset:3088                  // 00000010F0E4: DBFC0C10 960000AB
	ds_load_b128 v[146:149], v171 offset:3072                  // 00000010F0EC: DBFC0C00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F0F4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[146:153], v[89:96]// 00000010F0F8: CC414059 1D672582
	ds_load_b128 v[150:153], v171 offset:3856                  // 00000010F100: DBFC0F10 960000AB
	ds_load_b128 v[146:149], v171 offset:3840                  // 00000010F108: DBFC0F00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F110: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[146:153], v[81:88]// 00000010F114: CC414051 1D472582
	ds_load_b128 v[150:153], v171 offset:4624                  // 00000010F11C: DBFC1210 960000AB
	ds_load_b128 v[146:149], v171 offset:4608                  // 00000010F124: DBFC1200 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F12C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[146:153], v[73:80]// 00000010F130: CC414049 1D272582
	ds_load_b128 v[150:153], v171 offset:5392                  // 00000010F138: DBFC1510 960000AB
	ds_load_b128 v[146:149], v171 offset:5376                  // 00000010F140: DBFC1500 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F148: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[146:153], v[65:72]// 00000010F14C: CC414041 1D072582
	ds_load_b128 v[150:153], v171 offset:6160                  // 00000010F154: DBFC1810 960000AB
	ds_load_b128 v[146:149], v171 offset:6144                  // 00000010F15C: DBFC1800 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F164: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[146:153], v[57:64]// 00000010F168: CC414039 1CE72582
	ds_load_b128 v[150:153], v171 offset:6928                  // 00000010F170: DBFC1B10 960000AB
	ds_load_b128 v[146:149], v171 offset:6912                  // 00000010F178: DBFC1B00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F180: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[146:153], v[49:56]// 00000010F184: CC414031 1CC72582
	ds_load_b128 v[150:153], v171 offset:7696                  // 00000010F18C: DBFC1E10 960000AB
	ds_load_b128 v[146:149], v171 offset:7680                  // 00000010F194: DBFC1E00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F19C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[146:153], v[41:48]// 00000010F1A0: CC414029 1CA72582
	ds_load_b128 v[150:153], v171 offset:8464                  // 00000010F1A8: DBFC2110 960000AB
	ds_load_b128 v[146:149], v171 offset:8448                  // 00000010F1B0: DBFC2100 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F1B8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[146:153], v[33:40]// 00000010F1BC: CC414021 1C872582
	ds_load_b128 v[150:153], v171 offset:9232                  // 00000010F1C4: DBFC2410 960000AB
	ds_load_b128 v[146:149], v171 offset:9216                  // 00000010F1CC: DBFC2400 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F1D4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[146:153], v[25:32]// 00000010F1D8: CC414019 1C672582
	ds_load_b128 v[150:153], v171 offset:10000                 // 00000010F1E0: DBFC2710 960000AB
	ds_load_b128 v[146:149], v171 offset:9984                  // 00000010F1E8: DBFC2700 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F1F0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[146:153], v[17:24]// 00000010F1F4: CC414011 1C472582
	ds_load_b128 v[150:153], v171 offset:10768                 // 00000010F1FC: DBFC2A10 960000AB
	ds_load_b128 v[146:149], v171 offset:10752                 // 00000010F204: DBFC2A00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F20C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[146:153], v[9:16]// 00000010F210: CC414009 1C272582
	ds_load_b128 v[150:153], v171 offset:11536                 // 00000010F218: DBFC2D10 960000AB
	ds_load_b128 v[146:149], v171 offset:11520                 // 00000010F220: DBFC2D00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000010F228: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[146:153], v[1:8]// 00000010F22C: CC414001 1C072582
	s_add_i32 s1, s6, 1                                        // 00000010F234: 81018106
	s_cmp_eq_u32 s6, s5                                        // 00000010F238: BF060506
	s_mov_b32 s6, s1                                           // 00000010F23C: BE860001
	s_cbranch_scc1 1906                                        // 00000010F240: BFA20772 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x270c>
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 00000010F244: 916A0D7E
	s_mov_b32 s1, s12                                          // 00000010F248: BE81000C
	s_cbranch_vccz 3                                           // 00000010F24C: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x95c>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000010F250: 916A017E
	s_cbranch_vccnz 65527                                      // 00000010F254: BFA4FFF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x934>
	s_branch 15                                                // 00000010F258: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x998>
	s_lshr_b32 s1, s6, 3                                       // 00000010F25C: 85018306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000010F260: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 00000010F264: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 00000010F26C: 7F040201
	global_load_b32 v130, v130, s[20:21]                       // 00000010F270: DC520000 82140082
	s_waitcnt vmcnt(0)                                         // 00000010F278: BF8903F7
	v_lshrrev_b32_e32 v130, s6, v130                           // 00000010F27C: 33050406
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010F280: BF870091
	v_and_b32_e32 v130, 1, v130                                // 00000010F284: 37050481
	.long 0xd44a0001                                           // 00000010F288: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000010F28C: 02030481
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000010F290: 916A017E
	s_cbranch_vccnz 65511                                      // 00000010F294: BFA4FFE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x934>
	s_lshl_b32 s2, s6, 4                                       // 00000010F298: 84028406
	s_waitcnt vmcnt(0)                                         // 00000010F29C: BF8903F7
	s_barrier                                                  // 00000010F2A0: BFBD0000
	buffer_gl0_inv                                             // 00000010F2A4: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000010F2AC: BE812000
	s_cbranch_execz 64                                         // 00000010F2B0: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xab4>
	v_or_b32_e32 v130, s2, v155                                // 00000010F2B4: 39053602
	v_or_b32_e32 v131, s2, v154                                // 00000010F2B8: 39073402
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010F2BC: BF870112
	v_min_i32_e32 v130, s15, v130                              // 00000010F2C0: 2305040F
	v_min_i32_e32 v132, s15, v131                              // 00000010F2C4: 2309060F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010F2C8: BF870112
	v_ashrrev_i32_e32 v133, 31, v130                           // 00000010F2CC: 350B049F
	v_ashrrev_i32_e32 v135, 31, v132                           // 00000010F2D0: 350F089F
	.long 0xd72c0086                                           // 00000010F2D4: D72C0086
	v_cndmask_b32_e32 v1, s11, v130, vcc_lo                    // 00000010F2D8: 0203040B
	v_mad_u64_u32 v[130:131], null, s10, v130, 0               // 00000010F2DC: D6FE7C82 0203040A
	.long 0xd72c0089                                           // 00000010F2E4: D72C0089
	v_cndmask_b32_e32 v1, s11, v132, vcc_lo                    // 00000010F2E8: 0203080B
	.long 0xd72c0088                                           // 00000010F2EC: D72C0088
	v_cndmask_b32_e32 v1, s10, v133, vcc_lo                    // 00000010F2F0: 02030A0A
	v_mad_u64_u32 v[132:133], null, s10, v132, 0               // 00000010F2F4: D6FE7C84 0203080A
	.long 0xd72c0087                                           // 00000010F2FC: D72C0087
	v_cndmask_b32_e32 v1, s10, v135, vcc_lo                    // 00000010F300: 02030E0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010F304: BF870113
	v_add3_u32 v131, v131, v136, v134                          // 00000010F308: D6550083 061B1183
	v_add3_u32 v133, v133, v135, v137                          // 00000010F310: D6550085 06270F85
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010F318: BF870112
	.long 0xd73c0082                                           // 00000010F31C: D73C0082
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000010F320: 02030481
	.long 0xd73c0084                                           // 00000010F324: D73C0084
	v_cndmask_b32_e32 v1, 1, v132, vcc_lo                      // 00000010F328: 02030881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010F32C: BF870092
	.long 0xd7006a82                                           // 00000010F330: D7006A82
	v_cndmask_b32_e32 v1, v172, v130, vcc_lo                   // 00000010F334: 020305AC
	v_add_co_ci_u32_e64 v131, null, v173, v131, vcc_lo         // 00000010F338: D5207C83 01AB07AD
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010F340: BF870093
	.long 0xd7006a86                                           // 00000010F344: D7006A86
	v_cndmask_b32_e32 v1, v174, v132, vcc_lo                   // 00000010F348: 020309AE
	v_add_co_ci_u32_e64 v135, null, v175, v133, vcc_lo         // 00000010F34C: D5207C87 01AB0BAF
	global_load_b128 v[130:133], v[130:131], off               // 00000010F354: DC5E0000 827C0082
	global_load_b128 v[134:137], v[134:135], off               // 00000010F35C: DC5E0000 867C0086
	s_waitcnt vmcnt(1)                                         // 00000010F364: BF8907F7
	ds_store_b128 v168, v[130:133]                             // 00000010F368: DB7C0000 000082A8
	s_waitcnt vmcnt(0)                                         // 00000010F370: BF8903F7
	ds_store_b16 v169, v134                                    // 00000010F374: D87C0000 000086A9
	ds_store_b16_d16_hi v169, v134 offset:48                   // 00000010F37C: DA840030 000086A9
	ds_store_b16 v169, v135 offset:96                          // 00000010F384: D87C0060 000087A9
	ds_store_b16_d16_hi v169, v135 offset:144                  // 00000010F38C: DA840090 000087A9
	ds_store_b16 v169, v136 offset:192                         // 00000010F394: D87C00C0 000088A9
	ds_store_b16_d16_hi v169, v136 offset:240                  // 00000010F39C: DA8400F0 000088A9
	ds_store_b16 v169, v137 offset:288                         // 00000010F3A4: D87C0120 000089A9
	ds_store_b16_d16_hi v169, v137 offset:336                  // 00000010F3AC: DA840150 000089A9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010F3B4: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 00000010F3B8: BF89FC07
	s_barrier                                                  // 00000010F3BC: BFBD0000
	buffer_gl0_inv                                             // 00000010F3C0: E0AC0000 00000000
	s_clause 0x1                                               // 00000010F3C8: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:16     // 00000010F3CC: DC5E0010 967C008F
	global_load_b128 v[146:149], v[143:144], off               // 00000010F3D4: DC5E0000 927C008F
	ds_load_b128 v[176:179], v170                              // 00000010F3DC: DBFC0000 B00000AA
	ds_load_b128 v[180:183], v170 offset:16                    // 00000010F3E4: DBFC0010 B40000AA
	v_mov_b32_e32 v136, v129                                   // 00000010F3EC: 7F100381
	v_mov_b32_e32 v130, v129                                   // 00000010F3F0: 7F040381
	v_mov_b32_e32 v131, v129                                   // 00000010F3F4: 7F060381
	v_mov_b32_e32 v132, v129                                   // 00000010F3F8: 7F080381
	v_mov_b32_e32 v133, v129                                   // 00000010F3FC: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 00000010F400: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 00000010F404: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 00000010F408: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000010F40C: BF870212
	v_mov_b32_e32 v136, v135                                   // 00000010F410: 7F100387
	v_mov_b32_e32 v135, v134                                   // 00000010F414: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 00000010F418: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 00000010F41C: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 00000010F420: 7F080383
	v_mov_b32_e32 v131, v130                                   // 00000010F424: 7F060382
	v_mov_b32_e32 v130, v129                                   // 00000010F428: 7F040381
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F42C: BF890007
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010F430: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F434: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F43C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:48     // 00000010F440: DC5E0030 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:32     // 00000010F448: DC5E0020 927C008F
	ds_load_b128 v[176:179], v170 offset:32                    // 00000010F450: DBFC0020 B00000AA
	ds_load_b128 v[180:183], v170 offset:48                    // 00000010F458: DBFC0030 B40000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F460: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F464: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F46C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:80     // 00000010F470: DC5E0050 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:64     // 00000010F478: DC5E0040 927C008F
	ds_load_b128 v[180:183], v170 offset:80                    // 00000010F480: DBFC0050 B40000AA
	ds_load_b128 v[176:179], v170 offset:64                    // 00000010F488: DBFC0040 B00000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F490: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F494: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F49C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:112    // 00000010F4A0: DC5E0070 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:96     // 00000010F4A8: DC5E0060 927C008F
	ds_load_b128 v[180:183], v170 offset:112                   // 00000010F4B0: DBFC0070 B40000AA
	ds_load_b128 v[176:179], v170 offset:96                    // 00000010F4B8: DBFC0060 B00000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F4C0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F4C4: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F4CC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:144    // 00000010F4D0: DC5E0090 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:128    // 00000010F4D8: DC5E0080 927C008F
	ds_load_b128 v[180:183], v170 offset:144                   // 00000010F4E0: DBFC0090 B40000AA
	ds_load_b128 v[176:179], v170 offset:128                   // 00000010F4E8: DBFC0080 B00000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F4F0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F4F4: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F4FC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:176    // 00000010F500: DC5E00B0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:160    // 00000010F508: DC5E00A0 927C008F
	ds_load_b128 v[180:183], v170 offset:176                   // 00000010F510: DBFC00B0 B40000AA
	ds_load_b128 v[176:179], v170 offset:160                   // 00000010F518: DBFC00A0 B00000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F520: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F524: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F52C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:208    // 00000010F530: DC5E00D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:192    // 00000010F538: DC5E00C0 927C008F
	ds_load_b128 v[180:183], v170 offset:208                   // 00000010F540: DBFC00D0 B40000AA
	ds_load_b128 v[176:179], v170 offset:192                   // 00000010F548: DBFC00C0 B00000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F550: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F554: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F55C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:240    // 00000010F560: DC5E00F0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:224    // 00000010F568: DC5E00E0 927C008F
	ds_load_b128 v[180:183], v170 offset:240                   // 00000010F570: DBFC00F0 B40000AA
	ds_load_b128 v[176:179], v170 offset:224                   // 00000010F578: DBFC00E0 B00000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F580: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F584: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F58C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:272    // 00000010F590: DC5E0110 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:256    // 00000010F598: DC5E0100 927C008F
	ds_load_b128 v[180:183], v170 offset:272                   // 00000010F5A0: DBFC0110 B40000AA
	ds_load_b128 v[176:179], v170 offset:256                   // 00000010F5A8: DBFC0100 B00000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F5B0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F5B4: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F5BC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:304    // 00000010F5C0: DC5E0130 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:288    // 00000010F5C8: DC5E0120 927C008F
	ds_load_b128 v[180:183], v170 offset:304                   // 00000010F5D0: DBFC0130 B40000AA
	ds_load_b128 v[176:179], v170 offset:288                   // 00000010F5D8: DBFC0120 B00000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F5E0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F5E4: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F5EC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:336    // 00000010F5F0: DC5E0150 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:320    // 00000010F5F8: DC5E0140 927C008F
	ds_load_b128 v[180:183], v170 offset:336                   // 00000010F600: DBFC0150 B40000AA
	ds_load_b128 v[176:179], v170 offset:320                   // 00000010F608: DBFC0140 B00000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F610: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F614: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F61C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:368    // 00000010F620: DC5E0170 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:352    // 00000010F628: DC5E0160 927C008F
	ds_load_b128 v[180:183], v170 offset:368                   // 00000010F630: DBFC0170 B40000AA
	ds_load_b128 v[176:179], v170 offset:352                   // 00000010F638: DBFC0160 B00000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F640: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F644: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F64C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:400    // 00000010F650: DC5E0190 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:384    // 00000010F658: DC5E0180 927C008F
	ds_load_b128 v[180:183], v170 offset:400                   // 00000010F660: DBFC0190 B40000AA
	ds_load_b128 v[176:179], v170 offset:384                   // 00000010F668: DBFC0180 B00000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F670: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F674: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F67C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:432    // 00000010F680: DC5E01B0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:416    // 00000010F688: DC5E01A0 927C008F
	ds_load_b128 v[180:183], v170 offset:432                   // 00000010F690: DBFC01B0 B40000AA
	ds_load_b128 v[176:179], v170 offset:416                   // 00000010F698: DBFC01A0 B00000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F6A0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F6A4: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F6AC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:464    // 00000010F6B0: DC5E01D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:448    // 00000010F6B8: DC5E01C0 927C008F
	ds_load_b128 v[180:183], v170 offset:464                   // 00000010F6C0: DBFC01D0 B40000AA
	ds_load_b128 v[176:179], v170 offset:448                   // 00000010F6C8: DBFC01C0 B00000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F6D0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F6D4: CC414082 1E0B6192
	s_clause 0x1                                               // 00000010F6DC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:496    // 00000010F6E0: DC5E01F0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:480    // 00000010F6E8: DC5E01E0 927C008F
	ds_load_b128 v[180:183], v170 offset:496                   // 00000010F6F0: DBFC01F0 B40000AA
	ds_load_b128 v[176:179], v170 offset:480                   // 00000010F6F8: DBFC01E0 B00000AA
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000010F700: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[176:183], v[130:137]// 00000010F704: CC414082 1E0B6192
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010F70C: BF870111
	v_dual_mul_f32 v130, 0x3d800000, v130 :: v_dual_mul_f32 v131, 0x3d800000, v131// 00000010F710: C8C704FF 828306FF 3D800000
	v_mul_f32_e32 v146, 0x3d800000, v133                       // 00000010F71C: 11250AFF 3D800000
	v_mov_b32_e32 v133, 0xffff                                 // 00000010F724: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000010F72C: BF870004
	v_mul_f32_e32 v132, 0x3d800000, v132                       // 00000010F730: 110908FF 3D800000
	v_dual_mul_f32 v134, 0x3d800000, v134 :: v_dual_mul_f32 v135, 0x3d800000, v135// 00000010F738: C8C70CFF 86870EFF 3D800000
	v_dual_mul_f32 v136, 0x3d800000, v136 :: v_dual_mul_f32 v137, 0x3d800000, v137// 00000010F744: C8C710FF 888912FF 3D800000
	ds_store_2addr_b32 v159, v130, v131 offset1:34             // 00000010F750: D8382200 0083829F
	ds_store_2addr_b32 v159, v132, v146 offset0:68 offset1:102 // 00000010F758: D8386644 0092849F
	ds_store_2addr_b32 v159, v134, v135 offset0:136 offset1:170// 00000010F760: D838AA88 0087869F
	ds_store_2addr_b32 v159, v136, v137 offset0:204 offset1:238// 00000010F768: D838EECC 0089889F
	s_and_saveexec_b32 s4, s23                                 // 00000010F770: BE842017
	s_cbranch_execz 358                                        // 00000010F774: BFA50166 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1410>
	s_lshl_b32 s7, s6, 2                                       // 00000010F778: 84078206
	s_mov_b32 s8, exec_lo                                      // 00000010F77C: BE88007E
	.long 0xd4c1007e                                           // 00000010F780: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 00000010F784: 02033D91
	s_cbranch_execz 43                                         // 00000010F788: BFA5002B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf38>
	v_ashrrev_i32_e32 v146, 31, v145                           // 00000010F78C: 3525229F
	s_mov_b32 s9, 0                                            // 00000010F790: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010F794: BF870091
	.long 0xd73c0082                                           // 00000010F798: D73C0082
	v_cndmask_b32_e32 v1, 2, v145, vcc_lo                      // 00000010F79C: 02032282
	.long 0xd7006a82                                           // 00000010F7A0: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 00000010F7A4: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010F7A8: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 00000010F7AC: D5207C83 01AB078E
	s_branch 10                                                // 00000010F7B4: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xee0>
	s_nop 0                                                    // 00000010F7B8: BF800000
	s_nop 0                                                    // 00000010F7BC: BF800000
	s_or_b32 exec_lo, exec_lo, s24                             // 00000010F7C0: 8C7E187E
	v_mov_b32_e32 v133, v145                                   // 00000010F7C4: 7F0A0391
	v_mov_b32_e32 v145, v132                                   // 00000010F7C8: 7F220384
	s_and_b32 s1, exec_lo, s22                                 // 00000010F7CC: 8B01167E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000010F7D0: BF870499
	s_or_b32 s9, s1, s9                                        // 00000010F7D4: 8C090901
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 00000010F7D8: 917E097E
	s_cbranch_execz 20                                         // 00000010F7DC: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf30>
	global_load_b32 v132, v[130:131], off                      // 00000010F7E0: DC520000 847C0082
	s_or_b32 s22, s22, exec_lo                                 // 00000010F7E8: 8C167E16
	s_waitcnt vmcnt(0)                                         // 00000010F7EC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s7, v132                          // 00000010F7F0: 7C890807
	s_and_saveexec_b32 s24, vcc_lo                             // 00000010F7F4: BE98206A
	s_cbranch_execz 65521                                      // 00000010F7F8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xec0>
	v_dual_mov_b32 v145, v158 :: v_dual_add_nc_u32 v132, 1, v145// 00000010F7FC: CA20019E 91852281
	.long 0xd7000182                                           // 00000010F804: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 00000010F808: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000010F80C: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 00000010F810: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v158, v132                        // 00000010F818: 7C95099E
	s_and_not1_b32 s1, s22, exec_lo                            // 00000010F81C: 91017E16
	s_and_b32 s22, vcc_lo, exec_lo                             // 00000010F820: 8B167E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010F824: BF870009
	s_or_b32 s22, s1, s22                                      // 00000010F828: 8C161601
	s_branch 65508                                             // 00000010F82C: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xec0>
	s_or_b32 exec_lo, exec_lo, s9                              // 00000010F830: 8C7E097E
	v_mov_b32_e32 v145, v133                                   // 00000010F834: 7F220385
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010F838: 8C7E087E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010F83C: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v145       // 00000010F840: CA10008F 85820191
	s_mov_b32 s1, exec_lo                                      // 00000010F848: BE81007E
	.long 0xd4c1007e                                           // 00000010F84C: D4C1007E
	v_cndmask_b32_e32 v1, s7, v160, vcc_lo                     // 00000010F850: 02034007
	s_cbranch_execz 62                                         // 00000010F854: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1050>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v145        // 00000010F858: CA100080 85820191
	s_mov_b32 s8, exec_lo                                      // 00000010F860: BE88007E
	.long 0xd4c1007e                                           // 00000010F864: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 00000010F868: 02033D91
	s_cbranch_execz 54                                         // 00000010F86C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1048>
	v_mov_b32_e32 v130, v145                                   // 00000010F870: 7F040391
	s_mov_b32 s22, 0                                           // 00000010F874: BE960080
	s_set_inst_prefetch_distance 0x1                           // 00000010F878: BF840001
	s_branch 10                                                // 00000010F87C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfa8>
	s_or_b32 exec_lo, exec_lo, s26                             // 00000010F880: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000010F884: BF870499
	s_and_b32 s26, exec_lo, s25                                // 00000010F888: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 00000010F88C: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 00000010F890: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 00000010F894: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010F898: BF870009
	s_or_b32 s9, s9, s26                                       // 00000010F89C: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 00000010F8A0: 917E167E
	s_cbranch_execz 28                                         // 00000010F8A4: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1018>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000010F8A8: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 00000010F8AC: 7F060382
	s_or_b32 s24, s24, exec_lo                                 // 00000010F8B0: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 00000010F8B4: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 00000010F8B8: BE9A007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000010F8BC: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010F8C0: BF870091
	.long 0xd73c0084                                           // 00000010F8C4: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000010F8C8: 02030682
	.long 0xd7006a84                                           // 00000010F8CC: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 00000010F8D0: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010F8D4: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 00000010F8D8: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 00000010F8E0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 00000010F8E8: BF8903F7
	.long 0xd4c4007e                                           // 00000010F8EC: D4C4007E
	v_cndmask_b32_e32 v1, s7, v132, vcc_lo                     // 00000010F8F0: 02030807
	s_cbranch_execz 65506                                      // 00000010F8F4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000010F8F8: 4B050681
	s_and_not1_b32 s25, s25, exec_lo                           // 00000010F8FC: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 00000010F900: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000010F904: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000010F908: 7C95059E
	s_and_b32 s27, vcc_lo, exec_lo                             // 00000010F90C: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 00000010F910: 8C191B19
	s_branch 65498                                             // 00000010F914: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	s_set_inst_prefetch_distance 0x2                           // 00000010F918: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 00000010F91C: 8C7E167E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v158        // 00000010F920: CA100080 8582019E
	s_and_saveexec_b32 s22, s9                                 // 00000010F928: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010F92C: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 00000010F930: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v132                          // 00000010F934: 7C950807
	v_mov_b32_e32 v130, v131                                   // 00000010F938: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 00000010F93C: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s9                              // 00000010F944: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010F948: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010F94C: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010F950: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010F954: 8C7E017E
	s_or_b32 s8, s7, 1                                         // 00000010F958: 8C088107
	s_mov_b32 s1, exec_lo                                      // 00000010F95C: BE81007E
	.long 0xd4c6007e                                           // 00000010F960: D4C6007E
	v_cndmask_b32_e32 v1, s8, v160, vcc_lo                     // 00000010F964: 02034008
	s_xor_b32 s1, exec_lo, s1                                  // 00000010F968: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 00000010F96C: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 00000010F974: BE813001
	s_cbranch_execz 70                                         // 00000010F978: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1194>
	s_mov_b32 s9, exec_lo                                      // 00000010F97C: BE89007E
	.long 0xd4c1007e                                           // 00000010F980: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000010F984: 02033D82
	s_cbranch_execz 64                                         // 00000010F988: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x118c>
	s_mov_b32 s24, 0                                           // 00000010F98C: BE980080
	s_set_inst_prefetch_distance 0x1                           // 00000010F990: BF840001
	s_branch 20                                                // 00000010F994: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10e8>
	s_nop 0                                                    // 00000010F998: BF800000
	s_nop 0                                                    // 00000010F99C: BF800000
	s_nop 0                                                    // 00000010F9A0: BF800000
	s_nop 0                                                    // 00000010F9A4: BF800000
	s_nop 0                                                    // 00000010F9A8: BF800000
	s_nop 0                                                    // 00000010F9AC: BF800000
	s_nop 0                                                    // 00000010F9B0: BF800000
	s_nop 0                                                    // 00000010F9B4: BF800000
	s_nop 0                                                    // 00000010F9B8: BF800000
	s_nop 0                                                    // 00000010F9BC: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 00000010F9C0: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000010F9C4: BF870499
	s_and_b32 s27, exec_lo, s26                                // 00000010F9C8: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 00000010F9CC: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 00000010F9D0: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 00000010F9D4: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010F9D8: BF870009
	s_or_b32 s22, s22, s27                                     // 00000010F9DC: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 00000010F9E0: 917E187E
	s_cbranch_execz 27                                         // 00000010F9E4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1154>
	v_mov_b32_e32 v131, v130                                   // 00000010F9E8: 7F060382
	s_or_b32 s25, s25, exec_lo                                 // 00000010F9EC: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 00000010F9F0: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 00000010F9F4: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010F9F8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000010F9FC: 3509069F
	.long 0xd73c0086                                           // 00000010FA00: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000010FA04: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010FA08: BF870091
	.long 0xd7006a86                                           // 00000010FA0C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 00000010FA10: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 00000010FA14: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 00000010FA1C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 00000010FA24: BF8903F7
	.long 0xd4c6007e                                           // 00000010FA28: D4C6007E
	v_cndmask_b32_e32 v1, s7, v132, vcc_lo                     // 00000010FA2C: 02030807
	s_cbranch_execz 65507                                      // 00000010FA30: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000010FA34: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 00000010FA38: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 00000010FA3C: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000010FA40: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000010FA44: 7C95059E
	s_and_b32 s28, vcc_lo, exec_lo                             // 00000010FA48: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 00000010FA4C: 8C1A1C1A
	s_branch 65499                                             // 00000010FA50: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10c0>
	s_set_inst_prefetch_distance 0x2                           // 00000010FA54: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 00000010FA58: 8C7E187E
	v_mov_b32_e32 v130, v158                                   // 00000010FA5C: 7F04039E
	s_and_saveexec_b32 s24, s22                                // 00000010FA60: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FA64: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 00000010FA68: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v132                          // 00000010FA6C: 7C950808
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 00000010FA70: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010FA7C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000010FA80: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 00000010FA84: 7F040383
	s_or_b32 exec_lo, exec_lo, s22                             // 00000010FA88: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FA8C: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 00000010FA90: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FA94: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010FA98: 8C7E017E
	s_or_b32 s8, s7, 2                                         // 00000010FA9C: 8C088207
	s_mov_b32 s1, exec_lo                                      // 00000010FAA0: BE81007E
	.long 0xd4c6007e                                           // 00000010FAA4: D4C6007E
	v_cndmask_b32_e32 v1, s8, v160, vcc_lo                     // 00000010FAA8: 02034008
	s_xor_b32 s1, exec_lo, s1                                  // 00000010FAAC: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 00000010FAB0: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 00000010FAB8: BE813001
	s_cbranch_execz 69                                         // 00000010FABC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12d4>
	s_mov_b32 s9, exec_lo                                      // 00000010FAC0: BE89007E
	.long 0xd4c1007e                                           // 00000010FAC4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000010FAC8: 02033D82
	s_cbranch_execz 63                                         // 00000010FACC: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12cc>
	s_mov_b32 s24, 0                                           // 00000010FAD0: BE980080
	s_set_inst_prefetch_distance 0x1                           // 00000010FAD4: BF840001
	s_branch 19                                                // 00000010FAD8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1228>
	s_nop 0                                                    // 00000010FADC: BF800000
	s_nop 0                                                    // 00000010FAE0: BF800000
	s_nop 0                                                    // 00000010FAE4: BF800000
	s_nop 0                                                    // 00000010FAE8: BF800000
	s_nop 0                                                    // 00000010FAEC: BF800000
	s_nop 0                                                    // 00000010FAF0: BF800000
	s_nop 0                                                    // 00000010FAF4: BF800000
	s_nop 0                                                    // 00000010FAF8: BF800000
	s_nop 0                                                    // 00000010FAFC: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 00000010FB00: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000010FB04: BF870499
	s_and_b32 s27, exec_lo, s26                                // 00000010FB08: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 00000010FB0C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 00000010FB10: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 00000010FB14: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FB18: BF870009
	s_or_b32 s22, s22, s27                                     // 00000010FB1C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 00000010FB20: 917E187E
	s_cbranch_execz 27                                         // 00000010FB24: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1294>
	v_mov_b32_e32 v131, v130                                   // 00000010FB28: 7F060382
	s_or_b32 s25, s25, exec_lo                                 // 00000010FB2C: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 00000010FB30: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 00000010FB34: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010FB38: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000010FB3C: 3509069F
	.long 0xd73c0086                                           // 00000010FB40: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000010FB44: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010FB48: BF870091
	.long 0xd7006a86                                           // 00000010FB4C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 00000010FB50: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 00000010FB54: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 00000010FB5C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 00000010FB64: BF8903F7
	.long 0xd4c4007e                                           // 00000010FB68: D4C4007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 00000010FB6C: 02030808
	s_cbranch_execz 65507                                      // 00000010FB70: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1200>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000010FB74: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 00000010FB78: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 00000010FB7C: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000010FB80: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000010FB84: 7C95059E
	s_and_b32 s28, vcc_lo, exec_lo                             // 00000010FB88: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 00000010FB8C: 8C1A1C1A
	s_branch 65499                                             // 00000010FB90: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1200>
	s_set_inst_prefetch_distance 0x2                           // 00000010FB94: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 00000010FB98: 8C7E187E
	v_mov_b32_e32 v130, v158                                   // 00000010FB9C: 7F04039E
	s_and_saveexec_b32 s24, s22                                // 00000010FBA0: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FBA4: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 00000010FBA8: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v132                          // 00000010FBAC: 7C950808
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 00000010FBB0: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010FBBC: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000010FBC0: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 00000010FBC4: 7F040383
	s_or_b32 exec_lo, exec_lo, s22                             // 00000010FBC8: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FBCC: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 00000010FBD0: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FBD4: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010FBD8: 8C7E017E
	s_or_b32 s7, s7, 3                                         // 00000010FBDC: 8C078307
	s_mov_b32 s1, exec_lo                                      // 00000010FBE0: BE81007E
	.long 0xd4c6007e                                           // 00000010FBE4: D4C6007E
	v_cndmask_b32_e32 v1, s7, v160, vcc_lo                     // 00000010FBE8: 02034007
	s_xor_b32 s1, exec_lo, s1                                  // 00000010FBEC: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 00000010FBF0: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 00000010FBF8: BE813001
	s_cbranch_execz 66                                         // 00000010FBFC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1408>
	s_mov_b32 s8, exec_lo                                      // 00000010FC00: BE88007E
	.long 0xd4c1007e                                           // 00000010FC04: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000010FC08: 02033D82
	s_cbranch_execz 60                                         // 00000010FC0C: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	s_mov_b32 s22, 0                                           // 00000010FC10: BE960080
	s_set_inst_prefetch_distance 0x1                           // 00000010FC14: BF840001
	s_branch 19                                                // 00000010FC18: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1368>
	s_nop 0                                                    // 00000010FC1C: BF800000
	s_nop 0                                                    // 00000010FC20: BF800000
	s_nop 0                                                    // 00000010FC24: BF800000
	s_nop 0                                                    // 00000010FC28: BF800000
	s_nop 0                                                    // 00000010FC2C: BF800000
	s_nop 0                                                    // 00000010FC30: BF800000
	s_nop 0                                                    // 00000010FC34: BF800000
	s_nop 0                                                    // 00000010FC38: BF800000
	s_nop 0                                                    // 00000010FC3C: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 00000010FC40: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000010FC44: BF870499
	s_and_b32 s26, exec_lo, s25                                // 00000010FC48: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 00000010FC4C: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 00000010FC50: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 00000010FC54: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FC58: BF870009
	s_or_b32 s9, s9, s26                                       // 00000010FC5C: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 00000010FC60: 917E167E
	s_cbranch_execz 26                                         // 00000010FC64: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13d0>
	v_ashrrev_i32_e32 v131, 31, v130                           // 00000010FC68: 3507049F
	s_or_b32 s24, s24, exec_lo                                 // 00000010FC6C: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 00000010FC70: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 00000010FC74: BE9A007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010FC78: BF870091
	.long 0xd73c0083                                           // 00000010FC7C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 00000010FC80: 02030482
	.long 0xd7006a83                                           // 00000010FC84: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 00000010FC88: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010FC8C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 00000010FC90: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 00000010FC98: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 00000010FCA0: BF8903F7
	.long 0xd4c4007e                                           // 00000010FCA4: D4C4007E
	v_cndmask_b32_e32 v1, s7, v131, vcc_lo                     // 00000010FCA8: 02030607
	s_cbranch_execz 65508                                      // 00000010FCAC: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1340>
	v_add_nc_u32_e32 v130, 1, v130                             // 00000010FCB0: 4B050481
	s_and_not1_b32 s25, s25, exec_lo                           // 00000010FCB4: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 00000010FCB8: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000010FCBC: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000010FCC0: 7C95059E
	s_and_b32 s27, vcc_lo, exec_lo                             // 00000010FCC4: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 00000010FCC8: 8C191B19
	s_branch 65500                                             // 00000010FCCC: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1340>
	s_set_inst_prefetch_distance 0x2                           // 00000010FCD0: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 00000010FCD4: 8C7E167E
	s_and_saveexec_b32 s22, s9                                 // 00000010FCD8: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FCDC: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 00000010FCE0: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v131                          // 00000010FCE4: 7C950607
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 00000010FCE8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010FCF4: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000010FCF8: 390B0B82
	s_or_b32 exec_lo, exec_lo, s9                              // 00000010FCFC: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FD00: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010FD04: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FD08: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010FD0C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FD10: BF870009
	s_or_b32 exec_lo, exec_lo, s4                              // 00000010FD14: 8C7E047E
	s_and_saveexec_b32 s4, s3                                  // 00000010FD18: BE842003
	s_cbranch_execz 1029                                       // 00000010FD1C: BFA50405 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2434>
	ds_load_b32 v131, v162                                     // 00000010FD20: D8D80000 830000A2
	v_and_b32_e32 v130, 1, v133                                // 00000010FD28: 37050A81
	v_cmp_le_i32_e32 vcc_lo, s2, v161                          // 00000010FD2C: 7C874202
	s_delay_alu instid0(VALU_DEP_2)                            // 00000010FD30: BF870002
	.long 0xd44a0001                                           // 00000010FD34: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000010FD38: 02030481
	s_and_b32 s35, vcc_lo, s1                                  // 00000010FD3C: 8B23016A
	s_waitcnt lgkmcnt(0)                                       // 00000010FD40: BF89FC07
	v_mov_b32_e32 v130, v131                                   // 00000010FD44: 7F040383
	s_and_saveexec_b32 s1, s35                                 // 00000010FD48: BE812023
	s_cbranch_execz 7                                          // 00000010FD4C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x146c>
	ds_load_b32 v130, v163                                     // 00000010FD50: D8D80000 820000A3
	v_max_f32_e32 v132, v131, v131                             // 00000010FD58: 21090783
	s_waitcnt lgkmcnt(0)                                       // 00000010FD5C: BF89FC07
	v_max_f32_e32 v130, v130, v130                             // 00000010FD60: 21050582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010FD64: BF870001
	v_max_f32_e32 v130, v132, v130                             // 00000010FD68: 21050584
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010FD6C: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 00000010FD70: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s2, v161                          // 00000010FD74: 7C834202
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000010FD78: BF8704A2
	.long 0xd44d0001                                           // 00000010FD7C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000010FD80: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 00000010FD84: 8B22016A
	s_and_saveexec_b32 s1, s34                                 // 00000010FD88: BE812022
	s_cbranch_execz 7                                          // 00000010FD8C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14ac>
	ds_load_b32 v132, v163 offset:4                            // 00000010FD90: D8D80004 840000A3
	v_max_f32_e32 v130, v130, v130                             // 00000010FD98: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000010FD9C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000010FDA0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010FDA4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000010FDA8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010FDAC: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 00000010FDB0: 37090A84
	s_or_b32 s1, s2, 2                                         // 00000010FDB4: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010FDB8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v161                          // 00000010FDBC: 7C874201
	.long 0xd44d0001                                           // 00000010FDC0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000010FDC4: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 00000010FDC8: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FDCC: BF870009
	s_and_saveexec_b32 s1, s33                                 // 00000010FDD0: BE812021
	s_cbranch_execz 7                                          // 00000010FDD4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14f4>
	ds_load_b32 v132, v163 offset:8                            // 00000010FDD8: D8D80008 840000A3
	v_max_f32_e32 v130, v130, v130                             // 00000010FDE0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000010FDE4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000010FDE8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010FDEC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000010FDF0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010FDF4: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 00000010FDF8: 37090A88
	s_or_b32 s1, s2, 3                                         // 00000010FDFC: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010FE00: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v161                          // 00000010FE04: 7C874201
	.long 0xd44d0001                                           // 00000010FE08: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000010FE0C: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 00000010FE10: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FE14: BF870009
	s_and_saveexec_b32 s1, s31                                 // 00000010FE18: BE81201F
	s_cbranch_execz 7                                          // 00000010FE1C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x153c>
	ds_load_b32 v132, v163 offset:12                           // 00000010FE20: D8D8000C 840000A3
	v_max_f32_e32 v130, v130, v130                             // 00000010FE28: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000010FE2C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000010FE30: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010FE34: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000010FE38: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010FE3C: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 00000010FE40: 37090A90
	s_or_b32 s1, s2, 4                                         // 00000010FE44: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010FE48: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v161                          // 00000010FE4C: 7C874201
	.long 0xd44d0001                                           // 00000010FE50: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000010FE54: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 00000010FE58: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FE5C: BF870009
	s_and_saveexec_b32 s1, s30                                 // 00000010FE60: BE81201E
	s_cbranch_execz 7                                          // 00000010FE64: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1584>
	ds_load_b32 v132, v163 offset:16                           // 00000010FE68: D8D80010 840000A3
	v_max_f32_e32 v130, v130, v130                             // 00000010FE70: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000010FE74: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000010FE78: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010FE7C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000010FE80: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010FE84: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 00000010FE88: 37090AA0
	s_or_b32 s1, s2, 5                                         // 00000010FE8C: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010FE90: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v161                          // 00000010FE94: 7C874201
	.long 0xd44d0001                                           // 00000010FE98: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000010FE9C: 02030880
	s_and_b32 s29, vcc_lo, s1                                  // 00000010FEA0: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FEA4: BF870009
	s_and_saveexec_b32 s1, s29                                 // 00000010FEA8: BE81201D
	s_cbranch_execz 7                                          // 00000010FEAC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15cc>
	ds_load_b32 v132, v163 offset:20                           // 00000010FEB0: D8D80014 840000A3
	v_max_f32_e32 v130, v130, v130                             // 00000010FEB8: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000010FEBC: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000010FEC0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010FEC4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000010FEC8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010FECC: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 00000010FED0: 37090AC0
	s_or_b32 s1, s2, 6                                         // 00000010FED4: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010FED8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v161                          // 00000010FEDC: 7C874201
	.long 0xd44d0001                                           // 00000010FEE0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000010FEE4: 02030880
	s_and_b32 s28, vcc_lo, s1                                  // 00000010FEE8: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FEEC: BF870009
	s_and_saveexec_b32 s1, s28                                 // 00000010FEF0: BE81201C
	s_cbranch_execz 7                                          // 00000010FEF4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1614>
	ds_load_b32 v132, v163 offset:24                           // 00000010FEF8: D8D80018 840000A3
	v_max_f32_e32 v130, v130, v130                             // 00000010FF00: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000010FF04: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000010FF08: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010FF0C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000010FF10: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010FF14: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 00000010FF18: 37090AFF 00000080
	s_or_b32 s1, s2, 7                                         // 00000010FF20: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010FF24: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v161                          // 00000010FF28: 7C874201
	.long 0xd44d0001                                           // 00000010FF2C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000010FF30: 02030880
	s_and_b32 s27, vcc_lo, s1                                  // 00000010FF34: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FF38: BF870009
	s_and_saveexec_b32 s1, s27                                 // 00000010FF3C: BE81201B
	s_cbranch_execz 7                                          // 00000010FF40: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1660>
	ds_load_b32 v132, v163 offset:28                           // 00000010FF44: D8D8001C 840000A3
	v_max_f32_e32 v130, v130, v130                             // 00000010FF4C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000010FF50: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000010FF54: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010FF58: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000010FF5C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010FF60: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 00000010FF64: 37090AFF 00000100
	s_or_b32 s1, s2, 8                                         // 00000010FF6C: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010FF70: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v161                          // 00000010FF74: 7C874201
	.long 0xd44d0001                                           // 00000010FF78: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000010FF7C: 02030880
	s_and_b32 s26, vcc_lo, s1                                  // 00000010FF80: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FF84: BF870009
	s_and_saveexec_b32 s1, s26                                 // 00000010FF88: BE81201A
	s_cbranch_execz 7                                          // 00000010FF8C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16ac>
	ds_load_b32 v132, v163 offset:32                           // 00000010FF90: D8D80020 840000A3
	v_max_f32_e32 v130, v130, v130                             // 00000010FF98: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000010FF9C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000010FFA0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010FFA4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000010FFA8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010FFAC: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 00000010FFB0: 37090AFF 00000200
	s_or_b32 s1, s2, 9                                         // 00000010FFB8: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010FFBC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v161                          // 00000010FFC0: 7C874201
	.long 0xd44d0001                                           // 00000010FFC4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000010FFC8: 02030880
	s_and_b32 s25, vcc_lo, s1                                  // 00000010FFCC: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010FFD0: BF870009
	s_and_saveexec_b32 s1, s25                                 // 00000010FFD4: BE812019
	s_cbranch_execz 7                                          // 00000010FFD8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16f8>
	ds_load_b32 v132, v163 offset:36                           // 00000010FFDC: D8D80024 840000A3
	v_max_f32_e32 v130, v130, v130                             // 00000010FFE4: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000010FFE8: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000010FFEC: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010FFF0: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000010FFF4: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010FFF8: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 00000010FFFC: 37090AFF 00000400
	s_or_b32 s1, s2, 10                                        // 000000110004: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000110008: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v161                          // 00000011000C: 7C874201
	.long 0xd44d0001                                           // 000000110010: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000110014: 02030880
	s_and_b32 s24, vcc_lo, s1                                  // 000000110018: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011001C: BF870009
	s_and_saveexec_b32 s1, s24                                 // 000000110020: BE812018
	s_cbranch_execz 7                                          // 000000110024: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1744>
	ds_load_b32 v132, v163 offset:40                           // 000000110028: D8D80028 840000A3
	v_max_f32_e32 v130, v130, v130                             // 000000110030: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000110034: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000110038: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011003C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000110040: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000110044: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 000000110048: 37090AFF 00000800
	s_or_b32 s1, s2, 11                                        // 000000110050: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000110054: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v161                          // 000000110058: 7C874201
	.long 0xd44d0001                                           // 00000011005C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000110060: 02030880
	s_and_b32 s22, vcc_lo, s1                                  // 000000110064: 8B16016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000110068: BF870009
	s_and_saveexec_b32 s1, s22                                 // 00000011006C: BE812016
	s_cbranch_execz 7                                          // 000000110070: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1790>
	ds_load_b32 v132, v163 offset:44                           // 000000110074: D8D8002C 840000A3
	v_max_f32_e32 v130, v130, v130                             // 00000011007C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000110080: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000110084: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000110088: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000011008C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000110090: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 000000110094: 37090AFF 00001000
	s_or_b32 s1, s2, 12                                        // 00000011009C: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001100A0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v161                          // 0000001100A4: 7C874201
	.long 0xd44d0001                                           // 0000001100A8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000001100AC: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 0000001100B0: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001100B4: BF870009
	s_and_saveexec_b32 s1, s9                                  // 0000001100B8: BE812009
	s_cbranch_execz 7                                          // 0000001100BC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17dc>
	ds_load_b32 v132, v163 offset:48                           // 0000001100C0: D8D80030 840000A3
	v_max_f32_e32 v130, v130, v130                             // 0000001100C8: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000001100CC: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000001100D0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001100D4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000001100D8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001100DC: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 0000001100E0: 37090AFF 00002000
	s_or_b32 s1, s2, 13                                        // 0000001100E8: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001100EC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v161                          // 0000001100F0: 7C874201
	.long 0xd44d0001                                           // 0000001100F4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000001100F8: 02030880
	s_and_b32 s8, vcc_lo, s1                                   // 0000001100FC: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000110100: BF870009
	s_and_saveexec_b32 s1, s8                                  // 000000110104: BE812008
	s_cbranch_execz 7                                          // 000000110108: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1828>
	ds_load_b32 v132, v163 offset:52                           // 00000011010C: D8D80034 840000A3
	v_max_f32_e32 v130, v130, v130                             // 000000110114: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000110118: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000011011C: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000110120: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000110124: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000110128: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 00000011012C: 37090AFF 00004000
	s_or_b32 s1, s2, 14                                        // 000000110134: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000110138: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v161                          // 00000011013C: 7C874201
	.long 0xd44d0001                                           // 000000110140: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000110144: 02030880
	s_and_b32 s7, vcc_lo, s1                                   // 000000110148: 8B07016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011014C: BF870009
	s_and_saveexec_b32 s1, s7                                  // 000000110150: BE812007
	s_cbranch_execz 7                                          // 000000110154: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1874>
	ds_load_b32 v132, v163 offset:56                           // 000000110158: D8D80038 840000A3
	v_max_f32_e32 v130, v130, v130                             // 000000110160: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000110164: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000110168: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011016C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000110170: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000110174: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 000000110178: 37090AFF 00008000
	s_or_b32 s2, s2, 15                                        // 000000110180: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000110184: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v161                          // 000000110188: 7C874202
	.long 0xd44d0001                                           // 00000011018C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000110190: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 000000110194: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000110198: BF870009
	s_and_saveexec_b32 s2, s1                                  // 00000011019C: BE822001
	s_cbranch_execz 7                                          // 0000001101A0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18c0>
	ds_load_b32 v132, v163 offset:60                           // 0000001101A4: D8D8003C 840000A3
	v_max_f32_e32 v130, v130, v130                             // 0000001101AC: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000001101B0: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000001101B4: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001101B8: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000001101BC: 21050982
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001101C0: 8C7E027E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 0000001101C4: CA100080 84840080
	s_and_saveexec_b32 s2, s35                                 // 0000001101CC: BE822023
	s_cbranch_execz 30                                         // 0000001101D0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x194c>
	ds_load_b32 v133, v163                                     // 0000001101D4: D8D80000 850000A3
	s_waitcnt lgkmcnt(0)                                       // 0000001101DC: BF89FC07
	v_sub_f32_e32 v133, v133, v130                             // 0000001101E0: 090B0585
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001101E4: BF870091
	v_mul_f32_e32 v134, 0x3fb8aa3b, v133                       // 0000001101E8: 110D0AFF 3FB8AA3B
	v_fma_f32 v135, 0x3fb8aa3b, v133, -v134                    // 0000001101F0: D6130087 861B0AFF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 0000001101FC: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000110200: BF870221
	v_sub_f32_e32 v134, v134, v136                             // 000000110204: 090D1186
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 000000110208: 7C370AFF C2CE8ED0
	v_fmac_f32_e32 v135, 0x32a5705f, v133                      // 000000110210: 570F0AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110218: BF870121
	v_add_f32_e32 v134, v134, v135                             // 00000011021C: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 000000110220: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 000000110224: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110228: BF870095
	.long 0xd71c0086                                           // 00000011022C: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 000000110230: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 000000110234: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 000000110238: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000110240: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v134, vcc_lo           // 000000110244: 030B0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011024C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110250: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 000000110254: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 00000011025C: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v164, v134                             // 000000110268: DA840000 000086A4
	s_and_saveexec_b32 s2, s34                                 // 000000110270: BE822022
	s_cbranch_execz 30                                         // 000000110274: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19f0>
	ds_load_b32 v132, v163 offset:4                            // 000000110278: D8D80004 840000A3
	s_waitcnt lgkmcnt(0)                                       // 000000110280: BF89FC07
	v_sub_f32_e32 v132, v132, v130                             // 000000110284: 09090584
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110288: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v132                       // 00000011028C: 110D08FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v132                 // 000000110294: 7C3708FF C2CE8ED0
	v_fma_f32 v135, 0x3fb8aa3b, v132, -v134                    // 00000011029C: D6130087 861B08FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 0000001102A8: 7F104786
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001102AC: BF870112
	v_fmac_f32_e32 v135, 0x32a5705f, v132                      // 0000001102B0: 570F08FF 32A5705F
	v_sub_f32_e32 v134, v134, v136                             // 0000001102B8: 090D1186
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001102BC: BF870121
	v_add_f32_e32 v134, v134, v135                             // 0000001102C0: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 0000001102C4: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 0000001102C8: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001102CC: BF870095
	.long 0xd71c0086                                           // 0000001102D0: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 0000001102D4: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000001102D8: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v132                 // 0000001102DC: 7C3D08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001102E4: BF870002
	v_cndmask_b32_e32 v132, 0x7f800000, v134, vcc_lo           // 0000001102E8: 03090CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001102F0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001102F4: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 0000001102F8: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 000000110300: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 000000110304: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 000000110310: 7F0C0280
	ds_store_b16_d16_hi v164, v136 offset:2                    // 000000110314: DA840002 000088A4
	s_and_saveexec_b32 s2, s33                                 // 00000011031C: BE822021
	s_cbranch_execz 29                                         // 000000110320: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a98>
	ds_load_b32 v135, v163 offset:8                            // 000000110324: D8D80008 870000A3
	s_waitcnt lgkmcnt(0)                                       // 00000011032C: BF89FC07
	v_sub_f32_e32 v135, v135, v130                             // 000000110330: 090F0587
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110334: BF870091
	v_mul_f32_e32 v136, 0x3fb8aa3b, v135                       // 000000110338: 11110EFF 3FB8AA3B
	v_fma_f32 v137, 0x3fb8aa3b, v135, -v136                    // 000000110340: D6130089 86230EFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 00000011034C: 7F244788
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110350: BF870091
	v_dual_fmac_f32 v137, 0x32a5705f, v135 :: v_dual_sub_f32 v136, v136, v146// 000000110354: C80B0EFF 89892588 32A5705F
	v_add_f32_e32 v136, v136, v137                             // 000000110360: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 000000110364: 7F121192
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 000000110368: 7C370EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000110370: BF870293
	v_exp_f32_e32 v136, v136                                   // 000000110374: 7F104B88
	.long 0xd71c0088                                           // 000000110378: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 00000011037C: 02031388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110380: BF870121
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 000000110384: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 000000110388: 7C3D0EFF 42B17218
	v_cndmask_b32_e32 v135, 0x7f800000, v136, vcc_lo           // 000000110390: 030F10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000110398: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011039C: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 0000001103A0: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 0000001103A8: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v164, v136 offset:4                    // 0000001103B4: DA840004 000088A4
	s_and_saveexec_b32 s2, s31                                 // 0000001103BC: BE82201F
	s_cbranch_execz 30                                         // 0000001103C0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b3c>
	ds_load_b32 v134, v163 offset:12                           // 0000001103C4: D8D8000C 860000A3
	s_waitcnt lgkmcnt(0)                                       // 0000001103CC: BF89FC07
	v_sub_f32_e32 v134, v134, v130                             // 0000001103D0: 090D0586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001103D4: BF870121
	v_mul_f32_e32 v136, 0x3fb8aa3b, v134                       // 0000001103D8: 11110CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 0000001103E0: 7C370CFF C2CE8ED0
	v_fma_f32 v137, 0x3fb8aa3b, v134, -v136                    // 0000001103E8: D6130089 86230CFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 0000001103F4: 7F244788
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001103F8: BF870112
	v_fmac_f32_e32 v137, 0x32a5705f, v134                      // 0000001103FC: 57130CFF 32A5705F
	v_sub_f32_e32 v136, v136, v146                             // 000000110404: 09112588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110408: BF870121
	v_add_f32_e32 v136, v136, v137                             // 00000011040C: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 000000110410: 7F121192
	v_exp_f32_e32 v136, v136                                   // 000000110414: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110418: BF870095
	.long 0xd71c0088                                           // 00000011041C: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 000000110420: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 000000110424: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 000000110428: 7C3D0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000110430: BF870002
	v_cndmask_b32_e32 v134, 0x7f800000, v136, vcc_lo           // 000000110434: 030D10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011043C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110440: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 000000110444: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 00000011044C: 7F120280
	v_add3_u32 v146, v134, v136, 0x7fff                        // 000000110450: D6550092 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 00000011045C: 7F100280
	ds_store_b16_d16_hi v164, v146 offset:6                    // 000000110460: DA840006 000092A4
	s_and_saveexec_b32 s2, s30                                 // 000000110468: BE82201E
	s_cbranch_execz 30                                         // 00000011046C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1be8>
	ds_load_b32 v137, v163 offset:16                           // 000000110470: D8D80010 890000A3
	s_waitcnt lgkmcnt(0)                                       // 000000110478: BF89FC07
	v_sub_f32_e32 v137, v137, v130                             // 00000011047C: 09130589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110480: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 000000110484: 112512FF 3FB8AA3B
	v_fma_f32 v147, 0x3fb8aa3b, v137, -v146                    // 00000011048C: D6130093 864B12FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 000000110498: 7F284792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011049C: BF870221
	v_sub_f32_e32 v146, v146, v148                             // 0000001104A0: 09252992
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v137                 // 0000001104A4: 7C3712FF C2CE8ED0
	v_fmac_f32_e32 v147, 0x32a5705f, v137                      // 0000001104AC: 572712FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001104B4: BF870121
	v_add_f32_e32 v146, v146, v147                             // 0000001104B8: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 0000001104BC: 7F261194
	v_exp_f32_e32 v146, v146                                   // 0000001104C0: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001104C4: BF870095
	.long 0xd71c0092                                           // 0000001104C8: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 0000001104CC: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 0000001104D0: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v137                 // 0000001104D4: 7C3D12FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001104DC: BF870002
	v_cndmask_b32_e32 v137, 0x7f800000, v146, vcc_lo           // 0000001104E0: 031324FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001104E8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001104EC: BF870091
	v_bfe_u32 v146, v137, 16, 1                                // 0000001104F0: D6100092 02052189
	v_add3_u32 v146, v137, v146, 0x7fff                        // 0000001104F8: D6550092 03FF2589 00007FFF
	ds_store_b16_d16_hi v164, v146 offset:8                    // 000000110504: DA840008 000092A4
	s_and_saveexec_b32 s2, s29                                 // 00000011050C: BE82201D
	s_cbranch_execz 30                                         // 000000110510: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c8c>
	ds_load_b32 v136, v163 offset:20                           // 000000110514: D8D80014 880000A3
	s_waitcnt lgkmcnt(0)                                       // 00000011051C: BF89FC07
	v_sub_f32_e32 v136, v136, v130                             // 000000110520: 09110588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110524: BF870121
	v_mul_f32_e32 v146, 0x3fb8aa3b, v136                       // 000000110528: 112510FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 000000110530: 7C3710FF C2CE8ED0
	v_fma_f32 v147, 0x3fb8aa3b, v136, -v146                    // 000000110538: D6130093 864B10FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 000000110544: 7F284792
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000110548: BF870112
	v_fmac_f32_e32 v147, 0x32a5705f, v136                      // 00000011054C: 572710FF 32A5705F
	v_sub_f32_e32 v146, v146, v148                             // 000000110554: 09252992
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110558: BF870121
	v_add_f32_e32 v146, v146, v147                             // 00000011055C: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 000000110560: 7F261194
	v_exp_f32_e32 v146, v146                                   // 000000110564: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110568: BF870095
	.long 0xd71c0092                                           // 00000011056C: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 000000110570: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 000000110574: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 000000110578: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000110580: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v146, vcc_lo           // 000000110584: 031124FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011058C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110590: BF870121
	v_bfe_u32 v146, v136, 16, 1                                // 000000110594: D6100092 02052188
	v_mov_b32_e32 v147, 0                                      // 00000011059C: 7F260280
	v_add3_u32 v148, v136, v146, 0x7fff                        // 0000001105A0: D6550094 03FF2588 00007FFF
	v_mov_b32_e32 v146, 0                                      // 0000001105AC: 7F240280
	ds_store_b16_d16_hi v164, v148 offset:10                   // 0000001105B0: DA84000A 000094A4
	s_and_saveexec_b32 s2, s28                                 // 0000001105B8: BE82201C
	s_cbranch_execz 29                                         // 0000001105BC: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d34>
	ds_load_b32 v147, v163 offset:24                           // 0000001105C0: D8D80018 930000A3
	s_waitcnt lgkmcnt(0)                                       // 0000001105C8: BF89FC07
	v_sub_f32_e32 v147, v147, v130                             // 0000001105CC: 09270593
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001105D0: BF870091
	v_mul_f32_e32 v148, 0x3fb8aa3b, v147                       // 0000001105D4: 112926FF 3FB8AA3B
	v_fma_f32 v149, 0x3fb8aa3b, v147, -v148                    // 0000001105DC: D6130095 865326FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 0000001105E8: 7F2C4794
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001105EC: BF870091
	v_dual_fmac_f32 v149, 0x32a5705f, v147 :: v_dual_sub_f32 v148, v148, v150// 0000001105F0: C80B26FF 95952D94 32A5705F
	v_add_f32_e32 v148, v148, v149                             // 0000001105FC: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 000000110600: 7F2A1196
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 000000110604: 7C3726FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011060C: BF870293
	v_exp_f32_e32 v148, v148                                   // 000000110610: 7F284B94
	.long 0xd71c0094                                           // 000000110614: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 000000110618: 02032B94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011061C: BF870121
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 000000110620: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 000000110624: 7C3D26FF 42B17218
	v_cndmask_b32_e32 v147, 0x7f800000, v148, vcc_lo           // 00000011062C: 032728FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000110634: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110638: BF870091
	v_bfe_u32 v148, v147, 16, 1                                // 00000011063C: D6100094 02052193
	v_add3_u32 v148, v147, v148, 0x7fff                        // 000000110644: D6550094 03FF2993 00007FFF
	ds_store_b16_d16_hi v164, v148 offset:12                   // 000000110650: DA84000C 000094A4
	s_and_saveexec_b32 s2, s27                                 // 000000110658: BE82201B
	s_cbranch_execz 30                                         // 00000011065C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1dd8>
	ds_load_b32 v146, v163 offset:28                           // 000000110660: D8D8001C 920000A3
	s_waitcnt lgkmcnt(0)                                       // 000000110668: BF89FC07
	v_sub_f32_e32 v146, v146, v130                             // 00000011066C: 09250592
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110670: BF870121
	v_mul_f32_e32 v148, 0x3fb8aa3b, v146                       // 000000110674: 112924FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 00000011067C: 7C3724FF C2CE8ED0
	v_fma_f32 v149, 0x3fb8aa3b, v146, -v148                    // 000000110684: D6130095 865324FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 000000110690: 7F2C4794
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000110694: BF870112
	v_fmac_f32_e32 v149, 0x32a5705f, v146                      // 000000110698: 572B24FF 32A5705F
	v_sub_f32_e32 v148, v148, v150                             // 0000001106A0: 09292D94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001106A4: BF870121
	v_add_f32_e32 v148, v148, v149                             // 0000001106A8: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 0000001106AC: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 0000001106B0: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001106B4: BF870095
	.long 0xd71c0094                                           // 0000001106B8: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 0000001106BC: 02032B94
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 0000001106C0: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 0000001106C4: 7C3D24FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001106CC: BF870002
	v_cndmask_b32_e32 v146, 0x7f800000, v148, vcc_lo           // 0000001106D0: 032528FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001106D8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001106DC: BF870121
	v_bfe_u32 v148, v146, 16, 1                                // 0000001106E0: D6100094 02052192
	v_mov_b32_e32 v149, 0                                      // 0000001106E8: 7F2A0280
	v_add3_u32 v150, v146, v148, 0x7fff                        // 0000001106EC: D6550096 03FF2992 00007FFF
	v_mov_b32_e32 v148, 0                                      // 0000001106F8: 7F280280
	ds_store_b16_d16_hi v164, v150 offset:14                   // 0000001106FC: DA84000E 000096A4
	s_and_saveexec_b32 s2, s26                                 // 000000110704: BE82201A
	s_cbranch_execz 30                                         // 000000110708: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e84>
	ds_load_b32 v149, v163 offset:32                           // 00000011070C: D8D80020 950000A3
	s_waitcnt lgkmcnt(0)                                       // 000000110714: BF89FC07
	v_sub_f32_e32 v149, v149, v130                             // 000000110718: 092B0595
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011071C: BF870091
	v_mul_f32_e32 v150, 0x3fb8aa3b, v149                       // 000000110720: 112D2AFF 3FB8AA3B
	v_fma_f32 v151, 0x3fb8aa3b, v149, -v150                    // 000000110728: D6130097 865B2AFF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 000000110734: 7F304796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000110738: BF870221
	v_sub_f32_e32 v150, v150, v152                             // 00000011073C: 092D3196
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 000000110740: 7C372AFF C2CE8ED0
	v_fmac_f32_e32 v151, 0x32a5705f, v149                      // 000000110748: 572F2AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110750: BF870121
	v_add_f32_e32 v150, v150, v151                             // 000000110754: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 000000110758: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 00000011075C: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110760: BF870095
	.long 0xd71c0096                                           // 000000110764: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 000000110768: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 00000011076C: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 000000110770: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000110778: BF870002
	v_cndmask_b32_e32 v149, 0x7f800000, v150, vcc_lo           // 00000011077C: 032B2CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000110784: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110788: BF870091
	v_bfe_u32 v150, v149, 16, 1                                // 00000011078C: D6100096 02052195
	v_add3_u32 v150, v149, v150, 0x7fff                        // 000000110794: D6550096 03FF2D95 00007FFF
	ds_store_b16_d16_hi v164, v150 offset:16                   // 0000001107A0: DA840010 000096A4
	s_and_saveexec_b32 s2, s25                                 // 0000001107A8: BE822019
	s_cbranch_execz 30                                         // 0000001107AC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f28>
	ds_load_b32 v148, v163 offset:36                           // 0000001107B0: D8D80024 940000A3
	s_waitcnt lgkmcnt(0)                                       // 0000001107B8: BF89FC07
	v_sub_f32_e32 v148, v148, v130                             // 0000001107BC: 09290594
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001107C0: BF870121
	v_mul_f32_e32 v150, 0x3fb8aa3b, v148                       // 0000001107C4: 112D28FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 0000001107CC: 7C3728FF C2CE8ED0
	v_fma_f32 v151, 0x3fb8aa3b, v148, -v150                    // 0000001107D4: D6130097 865B28FF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 0000001107E0: 7F304796
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001107E4: BF870112
	v_fmac_f32_e32 v151, 0x32a5705f, v148                      // 0000001107E8: 572F28FF 32A5705F
	v_sub_f32_e32 v150, v150, v152                             // 0000001107F0: 092D3196
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001107F4: BF870121
	v_add_f32_e32 v150, v150, v151                             // 0000001107F8: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 0000001107FC: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 000000110800: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110804: BF870095
	.long 0xd71c0096                                           // 000000110808: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 00000011080C: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 000000110810: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 000000110814: 7C3D28FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011081C: BF870002
	v_cndmask_b32_e32 v148, 0x7f800000, v150, vcc_lo           // 000000110820: 03292CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000110828: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011082C: BF870121
	v_bfe_u32 v150, v148, 16, 1                                // 000000110830: D6100096 02052194
	v_mov_b32_e32 v151, 0                                      // 000000110838: 7F2E0280
	v_add3_u32 v152, v148, v150, 0x7fff                        // 00000011083C: D6550098 03FF2D94 00007FFF
	v_mov_b32_e32 v150, 0                                      // 000000110848: 7F2C0280
	ds_store_b16_d16_hi v164, v152 offset:18                   // 00000011084C: DA840012 000098A4
	s_and_saveexec_b32 s2, s24                                 // 000000110854: BE822018
	s_cbranch_execz 30                                         // 000000110858: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1fd4>
	ds_load_b32 v151, v163 offset:40                           // 00000011085C: D8D80028 970000A3
	s_waitcnt lgkmcnt(0)                                       // 000000110864: BF89FC07
	v_sub_f32_e32 v151, v151, v130                             // 000000110868: 092F0597
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011086C: BF870091
	v_mul_f32_e32 v152, 0x3fb8aa3b, v151                       // 000000110870: 11312EFF 3FB8AA3B
	v_fma_f32 v153, 0x3fb8aa3b, v151, -v152                    // 000000110878: D6130099 86632EFF 3FB8AA3B
	v_rndne_f32_e32 v176, v152                                 // 000000110884: 7F604798
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000110888: BF870221
	v_sub_f32_e32 v152, v152, v176                             // 00000011088C: 09316198
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 000000110890: 7C372EFF C2CE8ED0
	v_fmac_f32_e32 v153, 0x32a5705f, v151                      // 000000110898: 57332EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001108A0: BF870121
	v_add_f32_e32 v152, v152, v153                             // 0000001108A4: 07313398
	v_cvt_i32_f32_e32 v153, v176                               // 0000001108A8: 7F3211B0
	v_exp_f32_e32 v152, v152                                   // 0000001108AC: 7F304B98
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001108B0: BF870095
	.long 0xd71c0098                                           // 0000001108B4: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 0000001108B8: 02033398
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 0000001108BC: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 0000001108C0: 7C3D2EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001108C8: BF870002
	v_cndmask_b32_e32 v151, 0x7f800000, v152, vcc_lo           // 0000001108CC: 032F30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001108D4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001108D8: BF870091
	v_bfe_u32 v152, v151, 16, 1                                // 0000001108DC: D6100098 02052197
	v_add3_u32 v152, v151, v152, 0x7fff                        // 0000001108E4: D6550098 03FF3197 00007FFF
	ds_store_b16_d16_hi v164, v152 offset:20                   // 0000001108F0: DA840014 000098A4
	s_and_saveexec_b32 s2, s22                                 // 0000001108F8: BE822016
	s_cbranch_execz 29                                         // 0000001108FC: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2074>
	ds_load_b32 v150, v163 offset:44                           // 000000110900: D8D8002C 960000A3
	s_waitcnt lgkmcnt(0)                                       // 000000110908: BF89FC07
	v_sub_f32_e32 v150, v150, v130                             // 00000011090C: 092D0596
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110910: BF870121
	v_mul_f32_e32 v152, 0x3fb8aa3b, v150                       // 000000110914: 11312CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 00000011091C: 7C372CFF C2CE8ED0
	v_fma_f32 v153, 0x3fb8aa3b, v150, -v152                    // 000000110924: D6130099 86632CFF 3FB8AA3B
	v_rndne_f32_e32 v176, v152                                 // 000000110930: 7F604798
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110934: BF870091
	v_dual_fmac_f32 v153, 0x32a5705f, v150 :: v_dual_sub_f32 v152, v152, v176// 000000110938: C80B2CFF 99996198 32A5705F
	v_add_f32_e32 v152, v152, v153                             // 000000110944: 07313398
	v_cvt_i32_f32_e32 v153, v176                               // 000000110948: 7F3211B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011094C: BF870292
	v_exp_f32_e32 v152, v152                                   // 000000110950: 7F304B98
	.long 0xd71c0098                                           // 000000110954: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 000000110958: 02033398
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011095C: BF870121
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 000000110960: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 000000110964: 7C3D2CFF 42B17218
	v_cndmask_b32_e32 v150, 0x7f800000, v152, vcc_lo           // 00000011096C: 032D30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000110974: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110978: BF870121
	v_bfe_u32 v152, v150, 16, 1                                // 00000011097C: D6100098 02052196
	v_mov_b32_e32 v153, 0                                      // 000000110984: 7F320280
	v_add3_u32 v176, v150, v152, 0x7fff                        // 000000110988: D65500B0 03FF3196 00007FFF
	v_mov_b32_e32 v152, 0                                      // 000000110994: 7F300280
	ds_store_b16_d16_hi v164, v176 offset:22                   // 000000110998: DA840016 0000B0A4
	s_and_saveexec_b32 s2, s9                                  // 0000001109A0: BE822009
	s_cbranch_execz 29                                         // 0000001109A4: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x211c>
	ds_load_b32 v153, v163 offset:48                           // 0000001109A8: D8D80030 990000A3
	s_waitcnt lgkmcnt(0)                                       // 0000001109B0: BF89FC07
	v_sub_f32_e32 v153, v153, v130                             // 0000001109B4: 09330599
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001109B8: BF870091
	v_mul_f32_e32 v176, 0x3fb8aa3b, v153                       // 0000001109BC: 116132FF 3FB8AA3B
	v_fma_f32 v177, 0x3fb8aa3b, v153, -v176                    // 0000001109C4: D61300B1 86C332FF 3FB8AA3B
	v_rndne_f32_e32 v178, v176                                 // 0000001109D0: 7F6447B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001109D4: BF870091
	v_dual_fmac_f32 v177, 0x32a5705f, v153 :: v_dual_sub_f32 v176, v176, v178// 0000001109D8: C80B32FF B1B165B0 32A5705F
	v_add_f32_e32 v176, v176, v177                             // 0000001109E4: 076163B0
	v_cvt_i32_f32_e32 v177, v178                               // 0000001109E8: 7F6211B2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 0000001109EC: 7C3732FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001109F4: BF870293
	v_exp_f32_e32 v176, v176                                   // 0000001109F8: 7F604BB0
	.long 0xd71c00b0                                           // 0000001109FC: D71C00B0
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                   // 000000110A00: 020363B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110A04: BF870121
	v_cndmask_b32_e32 v176, 0, v176, vcc_lo                    // 000000110A08: 03616080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 000000110A0C: 7C3D32FF 42B17218
	v_cndmask_b32_e32 v153, 0x7f800000, v176, vcc_lo           // 000000110A14: 033360FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000110A1C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110A20: BF870091
	v_bfe_u32 v176, v153, 16, 1                                // 000000110A24: D61000B0 02052199
	v_add3_u32 v176, v153, v176, 0x7fff                        // 000000110A2C: D65500B0 03FF6199 00007FFF
	ds_store_b16_d16_hi v164, v176 offset:24                   // 000000110A38: DA840018 0000B0A4
	s_and_saveexec_b32 s2, s8                                  // 000000110A40: BE822008
	s_cbranch_execz 29                                         // 000000110A44: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21bc>
	ds_load_b32 v152, v163 offset:52                           // 000000110A48: D8D80034 980000A3
	s_waitcnt lgkmcnt(0)                                       // 000000110A50: BF89FC07
	v_sub_f32_e32 v152, v152, v130                             // 000000110A54: 09310598
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110A58: BF870121
	v_mul_f32_e32 v176, 0x3fb8aa3b, v152                       // 000000110A5C: 116130FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 000000110A64: 7C3730FF C2CE8ED0
	v_fma_f32 v177, 0x3fb8aa3b, v152, -v176                    // 000000110A6C: D61300B1 86C330FF 3FB8AA3B
	v_rndne_f32_e32 v178, v176                                 // 000000110A78: 7F6447B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110A7C: BF870091
	v_dual_fmac_f32 v177, 0x32a5705f, v152 :: v_dual_sub_f32 v176, v176, v178// 000000110A80: C80B30FF B1B165B0 32A5705F
	v_add_f32_e32 v176, v176, v177                             // 000000110A8C: 076163B0
	v_cvt_i32_f32_e32 v177, v178                               // 000000110A90: 7F6211B2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000110A94: BF870292
	v_exp_f32_e32 v176, v176                                   // 000000110A98: 7F604BB0
	.long 0xd71c00b0                                           // 000000110A9C: D71C00B0
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                   // 000000110AA0: 020363B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110AA4: BF870121
	v_cndmask_b32_e32 v176, 0, v176, vcc_lo                    // 000000110AA8: 03616080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 000000110AAC: 7C3D30FF 42B17218
	v_cndmask_b32_e32 v152, 0x7f800000, v176, vcc_lo           // 000000110AB4: 033160FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000110ABC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110AC0: BF870121
	v_bfe_u32 v176, v152, 16, 1                                // 000000110AC4: D61000B0 02052198
	v_mov_b32_e32 v177, 0                                      // 000000110ACC: 7F620280
	v_add3_u32 v178, v152, v176, 0x7fff                        // 000000110AD0: D65500B2 03FF6198 00007FFF
	v_mov_b32_e32 v176, 0                                      // 000000110ADC: 7F600280
	ds_store_b16_d16_hi v164, v178 offset:26                   // 000000110AE0: DA84001A 0000B2A4
	s_and_saveexec_b32 s2, s7                                  // 000000110AE8: BE822007
	s_cbranch_execz 30                                         // 000000110AEC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2268>
	ds_load_b32 v177, v163 offset:56                           // 000000110AF0: D8D80038 B10000A3
	s_waitcnt lgkmcnt(0)                                       // 000000110AF8: BF89FC07
	v_sub_f32_e32 v177, v177, v130                             // 000000110AFC: 096305B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110B00: BF870091
	v_mul_f32_e32 v178, 0x3fb8aa3b, v177                       // 000000110B04: 116562FF 3FB8AA3B
	v_fma_f32 v179, 0x3fb8aa3b, v177, -v178                    // 000000110B0C: D61300B3 86CB62FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 000000110B18: 7F6847B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000110B1C: BF870221
	v_sub_f32_e32 v178, v178, v180                             // 000000110B20: 096569B2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v177                 // 000000110B24: 7C3762FF C2CE8ED0
	v_fmac_f32_e32 v179, 0x32a5705f, v177                      // 000000110B2C: 576762FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110B34: BF870121
	v_add_f32_e32 v178, v178, v179                             // 000000110B38: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 000000110B3C: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 000000110B40: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110B44: BF870095
	.long 0xd71c00b2                                           // 000000110B48: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 000000110B4C: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 000000110B50: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v177                 // 000000110B54: 7C3D62FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000110B5C: BF870002
	v_cndmask_b32_e32 v177, 0x7f800000, v178, vcc_lo           // 000000110B60: 036364FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000110B68: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110B6C: BF870091
	v_bfe_u32 v178, v177, 16, 1                                // 000000110B70: D61000B2 020521B1
	v_add3_u32 v178, v177, v178, 0x7fff                        // 000000110B78: D65500B2 03FF65B1 00007FFF
	ds_store_b16_d16_hi v164, v178 offset:28                   // 000000110B84: DA84001C 0000B2A4
	s_and_saveexec_b32 s2, s1                                  // 000000110B8C: BE822001
	s_cbranch_execz 30                                         // 000000110B90: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x230c>
	ds_load_b32 v176, v163 offset:60                           // 000000110B94: D8D8003C B00000A3
	s_waitcnt lgkmcnt(0)                                       // 000000110B9C: BF89FC07
	v_sub_f32_e32 v176, v176, v130                             // 000000110BA0: 096105B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110BA4: BF870121
	v_mul_f32_e32 v178, 0x3fb8aa3b, v176                       // 000000110BA8: 116560FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v176                 // 000000110BB0: 7C3760FF C2CE8ED0
	v_fma_f32 v179, 0x3fb8aa3b, v176, -v178                    // 000000110BB8: D61300B3 86CB60FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 000000110BC4: 7F6847B2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000110BC8: BF870112
	v_fmac_f32_e32 v179, 0x32a5705f, v176                      // 000000110BCC: 576760FF 32A5705F
	v_sub_f32_e32 v178, v178, v180                             // 000000110BD4: 096569B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110BD8: BF870121
	v_add_f32_e32 v178, v178, v179                             // 000000110BDC: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 000000110BE0: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 000000110BE4: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110BE8: BF870095
	.long 0xd71c00b2                                           // 000000110BEC: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 000000110BF0: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 000000110BF4: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v176                 // 000000110BF8: 7C3D60FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000110C00: BF870002
	v_cndmask_b32_e32 v176, 0x7f800000, v178, vcc_lo           // 000000110C04: 036164FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000110C0C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000110C10: BF8700A1
	v_bfe_u32 v178, v176, 16, 1                                // 000000110C14: D61000B2 020521B0
	s_mov_b32 s1, exec_lo                                      // 000000110C1C: BE81007E
	v_add3_u32 v179, v176, v178, 0x7fff                        // 000000110C20: D65500B3 03FF65B0 00007FFF
	v_mov_b32_e32 v178, 0                                      // 000000110C2C: 7F640280
	ds_store_b16_d16_hi v164, v179 offset:30                   // 000000110C30: DA84001E 0000B3A4
	v_cmpx_lt_f32_e32 0xefa18f08, v131                         // 000000110C38: 7D2306FF EFA18F08
	s_cbranch_execz 27                                         // 000000110C40: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x23b0>
	v_sub_f32_e32 v131, v131, v130                             // 000000110C44: 09070583
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110C48: BF870091
	v_mul_f32_e32 v178, 0x3fb8aa3b, v131                       // 000000110C4C: 116506FF 3FB8AA3B
	v_fma_f32 v179, 0x3fb8aa3b, v131, -v178                    // 000000110C54: D61300B3 86CB06FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 000000110C60: 7F6847B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000110C64: BF870221
	v_sub_f32_e32 v178, v178, v180                             // 000000110C68: 096569B2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 000000110C6C: 7C3706FF C2CE8ED0
	v_fmac_f32_e32 v179, 0x32a5705f, v131                      // 000000110C74: 576706FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000110C7C: BF870121
	v_add_f32_e32 v178, v178, v179                             // 000000110C80: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 000000110C84: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 000000110C88: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110C8C: BF870095
	.long 0xd71c00b2                                           // 000000110C90: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 000000110C94: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 000000110C98: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 000000110C9C: 7C3D06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000110CA4: BF870002
	v_cndmask_b32_e32 v178, 0x7f800000, v178, vcc_lo           // 000000110CA8: 036564FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000110CB0: 8C7E017E
	v_add_f32_e32 v131, v133, v132                             // 000000110CB4: 07070985
	ds_load_b32 v132, v0                                       // 000000110CB8: D8D80000 84000000
	v_add_f32_e32 v131, v131, v135                             // 000000110CC0: 07070F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110CC4: BF870091
	v_add_f32_e32 v131, v131, v134                             // 000000110CC8: 07070D83
	v_add_f32_e32 v131, v131, v137                             // 000000110CCC: 07071383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110CD0: BF870091
	v_add_f32_e32 v131, v131, v136                             // 000000110CD4: 07071183
	v_add_f32_e32 v131, v131, v147                             // 000000110CD8: 07072783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110CDC: BF870091
	v_add_f32_e32 v131, v131, v146                             // 000000110CE0: 07072583
	v_add_f32_e32 v131, v131, v149                             // 000000110CE4: 07072B83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110CE8: BF870091
	v_add_f32_e32 v131, v131, v148                             // 000000110CEC: 07072983
	v_add_f32_e32 v131, v131, v151                             // 000000110CF0: 07072F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110CF4: BF870091
	v_add_f32_e32 v131, v131, v150                             // 000000110CF8: 07072D83
	v_add_f32_e32 v131, v131, v153                             // 000000110CFC: 07073383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110D00: BF870091
	v_add_f32_e32 v131, v131, v152                             // 000000110D04: 07073183
	v_add_f32_e32 v131, v131, v177                             // 000000110D08: 07076383
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000110D0C: BF8700A1
	v_add_f32_e32 v131, v131, v176                             // 000000110D10: 07076183
	s_waitcnt lgkmcnt(0)                                       // 000000110D14: BF89FC07
	v_fmac_f32_e32 v131, v178, v132                            // 000000110D18: 570709B2
	ds_store_b32 v162, v130                                    // 000000110D1C: D8340000 000082A2
	ds_store_b32 v0, v131                                      // 000000110D24: D8340000 00008300
	ds_store_b32 v165, v178                                    // 000000110D2C: D8340000 0000B2A5
	s_or_b32 exec_lo, exec_lo, s4                              // 000000110D34: 8C7E047E
	ds_load_2addr_b32 v[152:153], v166 offset1:2               // 000000110D38: D8DC0200 980000A6
	ds_load_2addr_b32 v[150:151], v166 offset0:4 offset1:6     // 000000110D40: D8DC0604 960000A6
	ds_load_2addr_b32 v[148:149], v166 offset0:8 offset1:10    // 000000110D48: D8DC0A08 940000A6
	ds_load_2addr_b32 v[146:147], v166 offset0:12 offset1:14   // 000000110D50: D8DC0E0C 920000A6
	s_waitcnt lgkmcnt(3)                                       // 000000110D58: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v152                         // 000000110D5C: 7C2530F2
	.long 0xd4120001                                           // 000000110D60: D4120001
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 000000110D64: 020332F2
	s_waitcnt lgkmcnt(2)                                       // 000000110D68: BF89FC27
	.long 0xd4120002                                           // 000000110D6C: D4120002
	v_cndmask_b32_e32 v1, 1.0, v150, vcc_lo                    // 000000110D70: 02032CF2
	.long 0xd4120004                                           // 000000110D74: D4120004
	v_cndmask_b32_e32 v1, 1.0, v151, vcc_lo                    // 000000110D78: 02032EF2
	s_and_b32 s1, vcc_lo, s1                                   // 000000110D7C: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 000000110D80: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v148                         // 000000110D84: 7C2528F2
	s_and_b32 s2, s1, s2                                       // 000000110D88: 8B020201
	.long 0xd4120001                                           // 000000110D8C: D4120001
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 000000110D90: 02032AF2
	s_and_b32 s4, s2, s4                                       // 000000110D94: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 000000110D98: BF89FC07
	.long 0xd4120002                                           // 000000110D9C: D4120002
	v_cndmask_b32_e32 v1, 1.0, v146, vcc_lo                    // 000000110DA0: 020324F2
	s_and_b32 s4, s4, vcc_lo                                   // 000000110DA4: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v147                         // 000000110DA8: 7C2526F2
	s_and_b32 s1, s4, s1                                       // 000000110DAC: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000110DB0: BF870499
	s_and_b32 s1, s1, s2                                       // 000000110DB4: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 000000110DB8: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110DBC: BF870099
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 000000110DC0: D5010082 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v130                           // 000000110DC8: 7C9B0480
	ds_load_b128 v[130:133], v167                              // 000000110DCC: DBFC0000 820000A7
	ds_load_b128 v[134:137], v167 offset:16                    // 000000110DD4: DBFC0010 860000A7
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 000000110DDC: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 000000110DE0: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000110DE4: BF870099
	v_cndmask_b32_e64 v176, 0, 1, s1                           // 000000110DE8: D50100B0 00050280
	v_readfirstlane_b32 s1, v176                               // 000000110DF0: 7E0205B0
	s_bitcmp1_b32 s1, 0                                        // 000000110DF4: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 000000110DF8: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000110DFC: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000110E00: 8B6A017E
	s_cbranch_vccnz 63643                                      // 000000110E04: BFA4F89B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x774>
	v_dual_mul_f32 v121, v152, v121 :: v_dual_mul_f32 v122, v153, v122// 000000110E08: C8C6F398 797AF599
	v_dual_mul_f32 v123, v150, v123 :: v_dual_mul_f32 v124, v151, v124// 000000110E10: C8C6F796 7B7CF997
	v_dual_mul_f32 v125, v148, v125 :: v_dual_mul_f32 v126, v149, v126// 000000110E18: C8C6FB94 7D7EFD95
	v_dual_mul_f32 v127, v146, v127 :: v_dual_mul_f32 v128, v147, v128// 000000110E20: C8C6FF92 7F810193
	v_dual_mul_f32 v113, v152, v113 :: v_dual_mul_f32 v114, v153, v114// 000000110E28: C8C6E398 7172E599
	v_dual_mul_f32 v115, v150, v115 :: v_dual_mul_f32 v116, v151, v116// 000000110E30: C8C6E796 7374E997
	v_dual_mul_f32 v117, v148, v117 :: v_dual_mul_f32 v118, v149, v118// 000000110E38: C8C6EB94 7576ED95
	v_dual_mul_f32 v119, v146, v119 :: v_dual_mul_f32 v120, v147, v120// 000000110E40: C8C6EF92 7778F193
	v_dual_mul_f32 v105, v152, v105 :: v_dual_mul_f32 v106, v153, v106// 000000110E48: C8C6D398 696AD599
	v_dual_mul_f32 v107, v150, v107 :: v_dual_mul_f32 v108, v151, v108// 000000110E50: C8C6D796 6B6CD997
	v_dual_mul_f32 v109, v148, v109 :: v_dual_mul_f32 v110, v149, v110// 000000110E58: C8C6DB94 6D6EDD95
	v_dual_mul_f32 v111, v146, v111 :: v_dual_mul_f32 v112, v147, v112// 000000110E60: C8C6DF92 6F70E193
	v_dual_mul_f32 v97, v152, v97 :: v_dual_mul_f32 v98, v153, v98// 000000110E68: C8C6C398 6162C599
	v_dual_mul_f32 v99, v150, v99 :: v_dual_mul_f32 v100, v151, v100// 000000110E70: C8C6C796 6364C997
	v_dual_mul_f32 v101, v148, v101 :: v_dual_mul_f32 v102, v149, v102// 000000110E78: C8C6CB94 6566CD95
	v_dual_mul_f32 v103, v146, v103 :: v_dual_mul_f32 v104, v147, v104// 000000110E80: C8C6CF92 6768D193
	v_dual_mul_f32 v89, v152, v89 :: v_dual_mul_f32 v90, v153, v90// 000000110E88: C8C6B398 595AB599
	v_dual_mul_f32 v91, v150, v91 :: v_dual_mul_f32 v92, v151, v92// 000000110E90: C8C6B796 5B5CB997
	v_dual_mul_f32 v93, v148, v93 :: v_dual_mul_f32 v94, v149, v94// 000000110E98: C8C6BB94 5D5EBD95
	v_dual_mul_f32 v95, v146, v95 :: v_dual_mul_f32 v96, v147, v96// 000000110EA0: C8C6BF92 5F60C193
	v_dual_mul_f32 v81, v152, v81 :: v_dual_mul_f32 v82, v153, v82// 000000110EA8: C8C6A398 5152A599
	v_dual_mul_f32 v83, v150, v83 :: v_dual_mul_f32 v84, v151, v84// 000000110EB0: C8C6A796 5354A997
	v_dual_mul_f32 v85, v148, v85 :: v_dual_mul_f32 v86, v149, v86// 000000110EB8: C8C6AB94 5556AD95
	v_dual_mul_f32 v87, v146, v87 :: v_dual_mul_f32 v88, v147, v88// 000000110EC0: C8C6AF92 5758B193
	v_dual_mul_f32 v73, v152, v73 :: v_dual_mul_f32 v74, v153, v74// 000000110EC8: C8C69398 494A9599
	v_dual_mul_f32 v75, v150, v75 :: v_dual_mul_f32 v76, v151, v76// 000000110ED0: C8C69796 4B4C9997
	v_dual_mul_f32 v77, v148, v77 :: v_dual_mul_f32 v78, v149, v78// 000000110ED8: C8C69B94 4D4E9D95
	v_dual_mul_f32 v79, v146, v79 :: v_dual_mul_f32 v80, v147, v80// 000000110EE0: C8C69F92 4F50A193
	v_dual_mul_f32 v65, v152, v65 :: v_dual_mul_f32 v66, v153, v66// 000000110EE8: C8C68398 41428599
	v_dual_mul_f32 v67, v150, v67 :: v_dual_mul_f32 v68, v151, v68// 000000110EF0: C8C68796 43448997
	v_dual_mul_f32 v69, v148, v69 :: v_dual_mul_f32 v70, v149, v70// 000000110EF8: C8C68B94 45468D95
	v_dual_mul_f32 v71, v146, v71 :: v_dual_mul_f32 v72, v147, v72// 000000110F00: C8C68F92 47489193
	v_dual_mul_f32 v57, v152, v57 :: v_dual_mul_f32 v58, v153, v58// 000000110F08: C8C67398 393A7599
	v_dual_mul_f32 v59, v150, v59 :: v_dual_mul_f32 v60, v151, v60// 000000110F10: C8C67796 3B3C7997
	v_dual_mul_f32 v61, v148, v61 :: v_dual_mul_f32 v62, v149, v62// 000000110F18: C8C67B94 3D3E7D95
	v_dual_mul_f32 v63, v146, v63 :: v_dual_mul_f32 v64, v147, v64// 000000110F20: C8C67F92 3F408193
	v_dual_mul_f32 v49, v152, v49 :: v_dual_mul_f32 v50, v153, v50// 000000110F28: C8C66398 31326599
	v_dual_mul_f32 v51, v150, v51 :: v_dual_mul_f32 v52, v151, v52// 000000110F30: C8C66796 33346997
	v_dual_mul_f32 v53, v148, v53 :: v_dual_mul_f32 v54, v149, v54// 000000110F38: C8C66B94 35366D95
	v_dual_mul_f32 v55, v146, v55 :: v_dual_mul_f32 v56, v147, v56// 000000110F40: C8C66F92 37387193
	v_dual_mul_f32 v41, v152, v41 :: v_dual_mul_f32 v42, v153, v42// 000000110F48: C8C65398 292A5599
	v_dual_mul_f32 v43, v150, v43 :: v_dual_mul_f32 v44, v151, v44// 000000110F50: C8C65796 2B2C5997
	v_dual_mul_f32 v45, v148, v45 :: v_dual_mul_f32 v46, v149, v46// 000000110F58: C8C65B94 2D2E5D95
	v_dual_mul_f32 v47, v146, v47 :: v_dual_mul_f32 v48, v147, v48// 000000110F60: C8C65F92 2F306193
	v_dual_mul_f32 v33, v152, v33 :: v_dual_mul_f32 v34, v153, v34// 000000110F68: C8C64398 21224599
	v_dual_mul_f32 v35, v150, v35 :: v_dual_mul_f32 v36, v151, v36// 000000110F70: C8C64796 23244997
	v_dual_mul_f32 v37, v148, v37 :: v_dual_mul_f32 v38, v149, v38// 000000110F78: C8C64B94 25264D95
	v_dual_mul_f32 v39, v146, v39 :: v_dual_mul_f32 v40, v147, v40// 000000110F80: C8C64F92 27285193
	v_dual_mul_f32 v25, v152, v25 :: v_dual_mul_f32 v26, v153, v26// 000000110F88: C8C63398 191A3599
	v_dual_mul_f32 v27, v150, v27 :: v_dual_mul_f32 v28, v151, v28// 000000110F90: C8C63796 1B1C3997
	v_dual_mul_f32 v29, v148, v29 :: v_dual_mul_f32 v30, v149, v30// 000000110F98: C8C63B94 1D1E3D95
	v_dual_mul_f32 v31, v146, v31 :: v_dual_mul_f32 v32, v147, v32// 000000110FA0: C8C63F92 1F204193
	v_dual_mul_f32 v17, v152, v17 :: v_dual_mul_f32 v18, v153, v18// 000000110FA8: C8C62398 11122599
	v_dual_mul_f32 v19, v150, v19 :: v_dual_mul_f32 v20, v151, v20// 000000110FB0: C8C62796 13142997
	v_dual_mul_f32 v21, v148, v21 :: v_dual_mul_f32 v22, v149, v22// 000000110FB8: C8C62B94 15162D95
	v_dual_mul_f32 v23, v146, v23 :: v_dual_mul_f32 v24, v147, v24// 000000110FC0: C8C62F92 17183193
	v_dual_mul_f32 v9, v152, v9 :: v_dual_mul_f32 v10, v153, v10// 000000110FC8: C8C61398 090A1599
	v_dual_mul_f32 v11, v150, v11 :: v_dual_mul_f32 v12, v151, v12// 000000110FD0: C8C61796 0B0C1997
	v_dual_mul_f32 v13, v148, v13 :: v_dual_mul_f32 v14, v149, v14// 000000110FD8: C8C61B94 0D0E1D95
	v_dual_mul_f32 v15, v146, v15 :: v_dual_mul_f32 v16, v147, v16// 000000110FE0: C8C61F92 0F102193
	v_dual_mul_f32 v1, v152, v1 :: v_dual_mul_f32 v2, v153, v2 // 000000110FE8: C8C60398 01020599
	v_dual_mul_f32 v3, v150, v3 :: v_dual_mul_f32 v4, v151, v4 // 000000110FF0: C8C60796 03040997
	v_dual_mul_f32 v5, v148, v5 :: v_dual_mul_f32 v6, v149, v6 // 000000110FF8: C8C60B94 05060D95
	v_dual_mul_f32 v7, v146, v7 :: v_dual_mul_f32 v8, v147, v8 // 000000111000: C8C60F92 07081193
	s_branch 63514                                             // 000000111008: BFA0F81A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x774>
	v_lshlrev_b32_e32 v0, 2, v157                              // 00000011100C: 30013A82
	.long 0xd700008b                                           // 000000111010: D700008B
	v_cndmask_b32_e32 v1, s18, v139, vcc_lo                    // 000000111014: 02031612
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000111018: BF870191
	v_add_co_ci_u32_e64 v140, null, s19, v140, s0              // 00000011101C: D5207C8C 00031813
	v_lshl_or_b32 v0, v155, 6, v0                              // 000000111024: D6560000 04010D9B
	v_lshlrev_b32_e32 v147, 1, v154                            // 00000011102C: 31273481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000111030: BF870152
	v_add_nc_u32_e32 v133, 0xf000, v0                          // 000000111034: 4B0A00FF 0000F000
	ds_load_2addr_b32 v[141:142], v133 offset0:192 offset1:194 // 00000011103C: D8DCC2C0 8D000085
	s_waitcnt lgkmcnt(0)                                       // 000000111044: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 000000111048: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 000000111050: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 000000111058: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000011105C: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 000000111060: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 000000111068: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:196 offset1:198 // 00000011106C: D8DCC6C4 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:200 offset1:202 // 000000111074: D8DCCAC8 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:204 offset1:206 // 00000011107C: D8DCCECC 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 000000111084: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 000000111088: 3505029F
	v_or_b32_e32 v0, v156, v157                                // 00000011108C: 38013B9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000111090: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 000000111094: 11252191
	.long 0xd73c0083                                           // 000000111098: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 00000011109C: 02030281
	.long 0xd7000081                                           // 0000001110A0: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 0000001110A4: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001110A8: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 0000001110AC: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 0000001110B4: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001110BC: BF870094
	.long 0xd7000083                                           // 0000001110C0: D7000083
	v_cndmask_b32_e32 v1, s16, v131, vcc_lo                    // 0000001110C4: 02030610
	v_add_co_ci_u32_e64 v132, null, s17, v132, s0              // 0000001110C8: D5207C84 00030811
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001110D0: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 0000001110D4: 57252194
	.long 0xd4440000                                           // 0000001110D8: D4440000
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 0000001110DC: 0202000E
	v_fma_f32 v139, -v143, v146, v145                          // 0000001110E0: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001110E8: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 0000001110EC: D637008B 064B218B
	.long 0xd7006a83                                           // 0000001110F4: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 0000001110F8: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 0000001110FC: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 000000111104: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 000000111108: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 000000111110: BE812000
	s_cbranch_execz 70                                         // 000000111114: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2930>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000111118: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 00000011111C: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 000000111128: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 00000011112C: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 000000111134: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 000000111138: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011113C: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 000000111140: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 000000111148: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 000000111154: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000111158: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 00000011115C: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 000000111164: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000111168: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 00000011116C: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 000000111170: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 000000111174: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 00000011117C: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111180: BF870095
	.long 0xd71c008d                                           // 000000111184: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 000000111188: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 00000011118C: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 000000111190: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111198: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 00000011119C: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 0000001111A4: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001111A8: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 0000001111AC: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 0000001111B4: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001111B8: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 0000001111BC: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 0000001111C4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 0000001111C8: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001111D0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000001111D4: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 0000001111D8: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001111E0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000001111E4: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 0000001111E8: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001111F0: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 0000001111F4: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 0000001111FC: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 000000111204: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111210: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 000000111214: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 00000011121C: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 000000111228: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000111230: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 000000111234: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 00000011123C: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000111244: BF870292
	v_rcp_f32_e32 v140, v121                                   // 000000111248: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 00000011124C: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111254: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 000000111258: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 00000011125C: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111260: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 000000111264: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 00000011126C: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111270: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 000000111274: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 00000011127C: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 000000111284: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000111288: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 00000011128C: D627008C 03CB1D8C
	.long 0xd4440001                                           // 000000111294: D4440001
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 000000111298: 0202F20E
	s_and_saveexec_b32 s2, s1                                  // 00000011129C: BE822001
	s_cbranch_execz 69                                         // 0000001112A0: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2ab8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000001112A4: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 0000001112B0: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 0000001112B4: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000001112BC: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000001112C0: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001112C4: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000001112C8: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000001112D0: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000001112DC: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001112E0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000001112E4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000001112E8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000001112F0: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001112F8: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000001112FC: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000111300: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000111304: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111308: BF870095
	.long 0xd71c008e                                           // 00000011130C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000111310: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000111314: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000111318: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111320: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000111324: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000011132C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111330: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 000000111334: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000011133C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111340: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000111344: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000011134C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 000000111350: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111358: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000011135C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000111360: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111368: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000011136C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000111370: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111378: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000011137C: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 000000111384: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 00000011138C: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111398: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 00000011139C: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 0000001113A4: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 0000001113B0: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001113B8: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 0000001113BC: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 0000001113C0: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 0000001113C8: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001113D0: BF870292
	v_rcp_f32_e32 v141, v122                                   // 0000001113D4: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 0000001113D8: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001113E0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000001113E4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000001113E8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001113EC: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 0000001113F0: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 0000001113F8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001113FC: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 000000111400: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 000000111408: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 000000111410: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000111414: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 000000111418: D6270089 03CB138D
	.long 0xd4440002                                           // 000000111420: D4440002
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 000000111424: 0202F40E
	s_and_saveexec_b32 s3, s2                                  // 000000111428: BE832002
	s_cbranch_execz 69                                         // 00000011142C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2c44>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 000000111430: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 00000011143C: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 000000111440: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000111448: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000011144C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111450: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000111454: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000011145C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000111468: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011146C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000111470: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000111474: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000011147C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000111484: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000111488: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000011148C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000111490: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111494: BF870095
	.long 0xd71c008e                                           // 000000111498: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000011149C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000001114A0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000001114A4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001114AC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000001114B0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000001114B8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001114BC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 0000001114C0: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000001114C8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001114CC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000001114D0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000001114D8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 0000001114DC: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001114E4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000001114E8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000001114EC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001114F4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000001114F8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000001114FC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111504: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000111508: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 000000111510: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 000000111518: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111524: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 000000111528: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 000000111530: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 00000011153C: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 000000111544: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 000000111548: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 000000111550: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000111558: BF870292
	v_rcp_f32_e32 v141, v123                                   // 00000011155C: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 000000111560: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111568: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000011156C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000111570: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111574: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 000000111578: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 000000111580: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111584: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 000000111588: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 000000111590: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 000000111598: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011159C: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 0000001115A0: D627008A 03CB158D
	.long 0xd4440003                                           // 0000001115A8: D4440003
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 0000001115AC: 0202F60E
	s_and_saveexec_b32 s4, s3                                  // 0000001115B0: BE842003
	s_cbranch_execz 69                                         // 0000001115B4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2dcc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 0000001115B8: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 0000001115C4: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 0000001115C8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000001115D0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000001115D4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001115D8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000001115DC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000001115E4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000001115F0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001115F4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000001115F8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000001115FC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000111604: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011160C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000111610: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000111614: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000111618: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011161C: BF870095
	.long 0xd71c008e                                           // 000000111620: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000111624: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000111628: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000011162C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111634: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000111638: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000111640: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111644: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 000000111648: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 000000111650: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111654: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000111658: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000111660: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 000000111664: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011166C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000111670: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000111674: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011167C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000111680: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000111684: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011168C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000111690: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 000000111698: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 0000001116A0: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001116AC: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 0000001116B0: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 0000001116B8: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 0000001116C4: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001116CC: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 0000001116D0: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 0000001116D4: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 0000001116DC: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001116E4: BF870292
	v_rcp_f32_e32 v141, v124                                   // 0000001116E8: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 0000001116EC: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001116F4: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000001116F8: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000001116FC: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111700: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 000000111704: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 00000011170C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111710: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 000000111714: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 00000011171C: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 000000111724: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000111728: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 00000011172C: D6270087 03CB0F8D
	.long 0xd4440004                                           // 000000111734: D4440004
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 000000111738: 0202F80E
	s_and_saveexec_b32 s5, s4                                  // 00000011173C: BE852004
	s_cbranch_execz 69                                         // 000000111740: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2f58>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 000000111744: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 000000111750: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 000000111754: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000011175C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000111760: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111764: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000111768: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000111770: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000011177C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000111780: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000111784: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000111788: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000111790: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000111798: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000011179C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000001117A0: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000001117A4: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001117A8: BF870095
	.long 0xd71c008e                                           // 0000001117AC: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000001117B0: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000001117B4: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000001117B8: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001117C0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000001117C4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000001117CC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001117D0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 0000001117D4: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 0000001117DC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001117E0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000001117E4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000001117EC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 0000001117F0: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001117F8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000001117FC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000111800: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111808: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000011180C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000111810: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111818: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000011181C: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 000000111824: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 00000011182C: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111838: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 00000011183C: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 000000111844: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 000000111850: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 000000111858: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 00000011185C: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 000000111864: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011186C: BF870292
	v_rcp_f32_e32 v141, v125                                   // 000000111870: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 000000111874: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011187C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000111880: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000111884: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111888: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 00000011188C: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 000000111894: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111898: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 00000011189C: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 0000001118A4: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 0000001118AC: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001118B0: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 0000001118B4: D6270088 03CB118D
	.long 0xd4440005                                           // 0000001118BC: D4440005
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 0000001118C0: 0202FA0E
	s_and_saveexec_b32 s6, s5                                  // 0000001118C4: BE862005
	s_cbranch_execz 69                                         // 0000001118C8: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x30e0>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 0000001118CC: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 0000001118D8: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 0000001118DC: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000001118E4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000001118E8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001118EC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000001118F0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000001118F8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000111904: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000111908: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000011190C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000111910: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000111918: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000111920: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000111924: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000111928: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000011192C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111930: BF870095
	.long 0xd71c008e                                           // 000000111934: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000111938: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000011193C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000111940: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111948: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000011194C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000111954: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111958: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 00000011195C: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000111964: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111968: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000011196C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000111974: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 000000111978: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111980: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000111984: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000111988: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111990: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000111994: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000111998: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001119A0: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000001119A4: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 0000001119AC: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 0000001119B4: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001119C0: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 0000001119C4: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 0000001119CC: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 0000001119D8: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001119E0: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000001119E4: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 0000001119E8: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 0000001119F0: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001119F8: BF870292
	v_rcp_f32_e32 v141, v126                                   // 0000001119FC: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 000000111A00: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111A08: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000111A0C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000111A10: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111A14: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 000000111A18: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 000000111A20: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111A24: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 000000111A28: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 000000111A30: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 000000111A38: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000111A3C: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 000000111A40: D6270085 03CB0B8D
	.long 0xd4440006                                           // 000000111A48: D4440006
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 000000111A4C: 0202FC0E
	s_and_saveexec_b32 s7, s6                                  // 000000111A50: BE872006
	s_cbranch_execz 69                                         // 000000111A54: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x326c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 000000111A58: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 000000111A64: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 000000111A68: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000111A70: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000111A74: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111A78: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000111A7C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000111A84: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000111A90: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000111A94: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000111A98: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000111A9C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000111AA4: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000111AAC: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000111AB0: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000111AB4: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000111AB8: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111ABC: BF870095
	.long 0xd71c008e                                           // 000000111AC0: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000111AC4: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000111AC8: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000111ACC: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111AD4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000111AD8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000111AE0: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111AE4: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 000000111AE8: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000111AF0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111AF4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000111AF8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000111B00: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 000000111B04: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111B0C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000111B10: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000111B14: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111B1C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000111B20: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000111B24: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111B2C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000111B30: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 000000111B38: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 000000111B40: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111B4C: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 000000111B50: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 000000111B58: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 000000111B64: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 000000111B6C: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 000000111B70: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 000000111B78: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000111B80: BF870292
	v_rcp_f32_e32 v141, v127                                   // 000000111B84: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 000000111B88: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111B90: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000111B94: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000111B98: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111B9C: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 000000111BA0: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 000000111BA8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000111BAC: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 000000111BB0: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 000000111BB8: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 000000111BC0: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000111BC4: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 000000111BC8: D6270086 03CB0D8D
	.long 0xd4440007                                           // 000000111BD0: D4440007
	v_cndmask_b32_e32 v1, s14, v127, vcc_lo                    // 000000111BD4: 0202FE0E
	s_and_saveexec_b32 s8, s7                                  // 000000111BD8: BE882007
	s_cbranch_execnz 363                                       // 000000111BDC: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x388c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111BE0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000111BE4: BE882000
	s_cbranch_execnz 432                                       // 000000111BE8: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111BEC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000111BF0: BE882001
	s_cbranch_execnz 501                                       // 000000111BF4: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3acc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111BF8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000111BFC: BE882002
	s_cbranch_execnz 570                                       // 000000111C00: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111C04: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000111C08: BE882003
	s_cbranch_execnz 639                                       // 000000111C0C: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111C10: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000111C14: BE882004
	s_cbranch_execnz 708                                       // 000000111C18: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111C1C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000111C20: BE882005
	s_cbranch_execnz 777                                       // 000000111C24: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111C28: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000111C2C: BE882006
	s_cbranch_execnz 846                                       // 000000111C30: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x406c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111C34: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000111C38: BE882007
	s_cbranch_execnz 915                                       // 000000111C3C: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x418c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111C40: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000111C44: BE882000
	s_cbranch_execnz 984                                       // 000000111C48: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111C4C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000111C50: BE882001
	s_cbranch_execnz 1053                                      // 000000111C54: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x43cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111C58: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000111C5C: BE882002
	s_cbranch_execnz 1122                                      // 000000111C60: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x44ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111C64: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000111C68: BE882003
	s_cbranch_execnz 1191                                      // 000000111C6C: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x460c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111C70: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000111C74: BE882004
	s_cbranch_execnz 1260                                      // 000000111C78: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x472c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111C7C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000111C80: BE882005
	s_cbranch_execnz 1329                                      // 000000111C84: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x484c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111C88: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000111C8C: BE882006
	s_cbranch_execnz 1398                                      // 000000111C90: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x496c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111C94: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000111C98: BE882007
	s_cbranch_execnz 1467                                      // 000000111C9C: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4a8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111CA0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000111CA4: BE882000
	s_cbranch_execnz 1536                                      // 000000111CA8: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4bac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111CAC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000111CB0: BE882001
	s_cbranch_execnz 1605                                      // 000000111CB4: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4ccc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111CB8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000111CBC: BE882002
	s_cbranch_execnz 1674                                      // 000000111CC0: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4dec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111CC4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000111CC8: BE882003
	s_cbranch_execnz 1743                                      // 000000111CCC: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4f0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111CD0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000111CD4: BE882004
	s_cbranch_execnz 1812                                      // 000000111CD8: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x502c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111CDC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000111CE0: BE882005
	s_cbranch_execnz 1881                                      // 000000111CE4: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x514c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111CE8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000111CEC: BE882006
	s_cbranch_execnz 1950                                      // 000000111CF0: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x526c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111CF4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000111CF8: BE882007
	s_cbranch_execnz 2019                                      // 000000111CFC: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x538c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111D00: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000111D04: BE882000
	s_cbranch_execnz 2088                                      // 000000111D08: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x54ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111D0C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000111D10: BE882001
	s_cbranch_execnz 2157                                      // 000000111D14: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x55cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111D18: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000111D1C: BE882002
	s_cbranch_execnz 2226                                      // 000000111D20: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x56ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111D24: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000111D28: BE882003
	s_cbranch_execnz 2295                                      // 000000111D2C: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x580c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111D30: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000111D34: BE882004
	s_cbranch_execnz 2364                                      // 000000111D38: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x592c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111D3C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000111D40: BE882005
	s_cbranch_execnz 2433                                      // 000000111D44: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5a4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111D48: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000111D4C: BE882006
	s_cbranch_execnz 2502                                      // 000000111D50: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5b6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111D54: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000111D58: BE882007
	s_cbranch_execnz 2571                                      // 000000111D5C: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5c8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111D60: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000111D64: BE882000
	s_cbranch_execnz 2640                                      // 000000111D68: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5dac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111D6C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000111D70: BE882001
	s_cbranch_execnz 2709                                      // 000000111D74: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5ecc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111D78: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000111D7C: BE882002
	s_cbranch_execnz 2778                                      // 000000111D80: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5fec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111D84: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000111D88: BE882003
	s_cbranch_execnz 2847                                      // 000000111D8C: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x610c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111D90: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000111D94: BE882004
	s_cbranch_execnz 2916                                      // 000000111D98: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x622c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111D9C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000111DA0: BE882005
	s_cbranch_execnz 2985                                      // 000000111DA4: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x634c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111DA8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000111DAC: BE882006
	s_cbranch_execnz 3054                                      // 000000111DB0: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x646c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111DB4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000111DB8: BE882007
	s_cbranch_execnz 3123                                      // 000000111DBC: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x658c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111DC0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000111DC4: BE882000
	s_cbranch_execnz 3192                                      // 000000111DC8: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x66ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111DCC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000111DD0: BE882001
	s_cbranch_execnz 3261                                      // 000000111DD4: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x67cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111DD8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000111DDC: BE882002
	s_cbranch_execnz 3330                                      // 000000111DE0: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x68ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111DE4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000111DE8: BE882003
	s_cbranch_execnz 3399                                      // 000000111DEC: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6a0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111DF0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000111DF4: BE882004
	s_cbranch_execnz 3468                                      // 000000111DF8: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6b2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111DFC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000111E00: BE882005
	s_cbranch_execnz 3537                                      // 000000111E04: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6c4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111E08: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000111E0C: BE882006
	s_cbranch_execnz 3606                                      // 000000111E10: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6d6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111E14: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000111E18: BE882007
	s_cbranch_execnz 3675                                      // 000000111E1C: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6e8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111E20: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000111E24: BE882000
	s_cbranch_execnz 3744                                      // 000000111E28: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6fac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111E2C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000111E30: BE882001
	s_cbranch_execnz 3813                                      // 000000111E34: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x70cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111E38: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000111E3C: BE882002
	s_cbranch_execnz 3882                                      // 000000111E40: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x71ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111E44: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000111E48: BE882003
	s_cbranch_execnz 3951                                      // 000000111E4C: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x730c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111E50: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000111E54: BE882004
	s_cbranch_execnz 4020                                      // 000000111E58: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x742c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111E5C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000111E60: BE882005
	s_cbranch_execnz 4089                                      // 000000111E64: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x754c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111E68: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000111E6C: BE882006
	s_cbranch_execnz 4158                                      // 000000111E70: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x766c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111E74: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000111E78: BE882007
	s_cbranch_execnz 4227                                      // 000000111E7C: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x778c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111E80: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000111E84: BE882000
	s_cbranch_execnz 4296                                      // 000000111E88: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x78ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111E8C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000111E90: BE882001
	s_cbranch_execnz 4365                                      // 000000111E94: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x79cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111E98: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000111E9C: BE882002
	s_cbranch_execnz 4434                                      // 000000111EA0: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7aec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111EA4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000111EA8: BE882003
	s_cbranch_execnz 4503                                      // 000000111EAC: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7c0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111EB0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000111EB4: BE882004
	s_cbranch_execnz 4572                                      // 000000111EB8: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7d2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111EBC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000111EC0: BE882005
	s_cbranch_execnz 4641                                      // 000000111EC4: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7e4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111EC8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000111ECC: BE882006
	s_cbranch_execnz 4710                                      // 000000111ED0: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7f6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111ED4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000111ED8: BE882007
	s_cbranch_execnz 4779                                      // 000000111EDC: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x808c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111EE0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000111EE4: BE882000
	s_cbranch_execnz 4848                                      // 000000111EE8: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x81ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111EEC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000111EF0: BE882001
	s_cbranch_execnz 4917                                      // 000000111EF4: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x82cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111EF8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000111EFC: BE882002
	s_cbranch_execnz 4986                                      // 000000111F00: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x83ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111F04: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000111F08: BE882003
	s_cbranch_execnz 5055                                      // 000000111F0C: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x850c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111F10: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000111F14: BE882004
	s_cbranch_execnz 5124                                      // 000000111F18: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x862c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111F1C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000111F20: BE882005
	s_cbranch_execnz 5193                                      // 000000111F24: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x874c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111F28: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000111F2C: BE882006
	s_cbranch_execnz 5262                                      // 000000111F30: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x886c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111F34: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000111F38: BE882007
	s_cbranch_execnz 5331                                      // 000000111F3C: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x898c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111F40: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000111F44: BE882000
	s_cbranch_execnz 5400                                      // 000000111F48: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8aac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111F4C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000111F50: BE882001
	s_cbranch_execnz 5469                                      // 000000111F54: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8bcc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111F58: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000111F5C: BE882002
	s_cbranch_execnz 5538                                      // 000000111F60: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8cec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111F64: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000111F68: BE882003
	s_cbranch_execnz 5607                                      // 000000111F6C: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8e0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111F70: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000111F74: BE882004
	s_cbranch_execnz 5676                                      // 000000111F78: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8f2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111F7C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000111F80: BE882005
	s_cbranch_execnz 5745                                      // 000000111F84: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x904c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111F88: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000111F8C: BE882006
	s_cbranch_execnz 5814                                      // 000000111F90: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x916c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111F94: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000111F98: BE882007
	s_cbranch_execnz 5883                                      // 000000111F9C: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x928c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111FA0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000111FA4: BE882000
	s_cbranch_execnz 5952                                      // 000000111FA8: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x93ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111FAC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000111FB0: BE882001
	s_cbranch_execnz 6021                                      // 000000111FB4: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x94cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111FB8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000111FBC: BE882002
	s_cbranch_execnz 6090                                      // 000000111FC0: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x95ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111FC4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000111FC8: BE882003
	s_cbranch_execnz 6159                                      // 000000111FCC: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x970c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111FD0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000111FD4: BE882004
	s_cbranch_execnz 6228                                      // 000000111FD8: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x982c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111FDC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000111FE0: BE882005
	s_cbranch_execnz 6297                                      // 000000111FE4: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x994c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111FE8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000111FEC: BE882006
	s_cbranch_execnz 6366                                      // 000000111FF0: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9a6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000111FF4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000111FF8: BE882007
	s_cbranch_execnz 6435                                      // 000000111FFC: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9b8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112000: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000112004: BE882000
	s_cbranch_execnz 6504                                      // 000000112008: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9cac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011200C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000112010: BE882001
	s_cbranch_execnz 6573                                      // 000000112014: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9dcc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112018: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011201C: BE882002
	s_cbranch_execnz 6642                                      // 000000112020: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9eec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112024: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000112028: BE882003
	s_cbranch_execnz 6711                                      // 00000011202C: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa00c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112030: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000112034: BE882004
	s_cbranch_execnz 6780                                      // 000000112038: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa12c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011203C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000112040: BE882005
	s_cbranch_execnz 6849                                      // 000000112044: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa24c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112048: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011204C: BE882006
	s_cbranch_execnz 6918                                      // 000000112050: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa36c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112054: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000112058: BE882007
	s_cbranch_execnz 6987                                      // 00000011205C: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa48c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112060: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000112064: BE882000
	s_cbranch_execnz 7056                                      // 000000112068: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa5ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011206C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000112070: BE882001
	s_cbranch_execnz 7125                                      // 000000112074: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa6cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112078: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011207C: BE882002
	s_cbranch_execnz 7194                                      // 000000112080: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa7ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112084: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000112088: BE882003
	s_cbranch_execnz 7263                                      // 00000011208C: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa90c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112090: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000112094: BE882004
	s_cbranch_execnz 7332                                      // 000000112098: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaa2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011209C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001120A0: BE882005
	s_cbranch_execnz 7401                                      // 0000001120A4: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xab4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001120A8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001120AC: BE882006
	s_cbranch_execnz 7470                                      // 0000001120B0: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001120B4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001120B8: BE882007
	s_cbranch_execnz 7539                                      // 0000001120BC: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xad8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001120C0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001120C4: BE882000
	s_cbranch_execnz 7608                                      // 0000001120C8: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaeac>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001120CC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001120D0: BE882001
	s_cbranch_execnz 7677                                      // 0000001120D4: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xafcc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001120D8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001120DC: BE882002
	s_cbranch_execnz 7746                                      // 0000001120E0: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb0ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001120E4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001120E8: BE882003
	s_cbranch_execnz 7815                                      // 0000001120EC: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb20c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001120F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001120F4: BE882004
	s_cbranch_execnz 7884                                      // 0000001120F8: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb32c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001120FC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000112100: BE882005
	s_cbranch_execnz 7953                                      // 000000112104: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb44c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112108: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011210C: BE882006
	s_cbranch_execnz 8022                                      // 000000112110: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb56c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112114: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000112118: BE882007
	s_cbranch_execnz 8091                                      // 00000011211C: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb68c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112120: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000112124: BE882000
	s_cbranch_execnz 8160                                      // 000000112128: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb7ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011212C: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000112130: BE802001
	s_cbranch_execnz 8229                                      // 000000112134: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb8cc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000112138: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000011213C: BE802002
	s_cbranch_execnz 8298                                      // 000000112140: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb9ec>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000112144: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 000000112148: BE802003
	s_cbranch_execnz 8367                                      // 00000011214C: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbb0c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000112150: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000112154: BE802004
	s_cbranch_execnz 8436                                      // 000000112158: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbc2c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000011215C: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000112160: BE802005
	s_cbranch_execnz 8505                                      // 000000112164: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbd4c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000112168: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000011216C: BE802006
	s_cbranch_execnz 8574                                      // 000000112170: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbe6c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000112174: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000112178: BE802007
	s_cbranch_execnz 8643                                      // 00000011217C: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbf8c>
	s_nop 0                                                    // 000000112180: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000112184: BFB60003
	s_endpgm                                                   // 000000112188: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 00000011218C: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 000000112198: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 00000011219C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000001121A4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000001121A8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001121AC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000001121B0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000001121B8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000001121C4: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001121C8: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000001121CC: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000001121D0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000001121D8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001121E0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000001121E4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000001121E8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000001121EC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001121F0: BF870095
	.long 0xd71c008e                                           // 0000001121F4: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000001121F8: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000001121FC: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000112200: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112208: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000011220C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000112214: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112218: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 00000011221C: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 000000112224: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112228: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000011222C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000112234: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 000000112238: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112240: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000112244: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000112248: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112250: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000112254: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000112258: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112260: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000112264: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 00000011226C: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 000000112274: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112280: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 000000112284: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 00000011228C: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 000000112298: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001122A0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001122A4: BE882000
	s_cbranch_execz 65104                                      // 0000001122A8: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32ec>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 0000001122AC: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 0000001122B8: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 0000001122BC: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 0000001122C4: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 0000001122C8: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001122CC: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 0000001122D0: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 0000001122D8: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 0000001122E4: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001122E8: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 0000001122EC: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 0000001122F0: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 0000001122F8: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000112300: BF870121
	v_add_f32_e32 v141, v141, v142                             // 000000112304: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 000000112308: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 00000011230C: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112310: BF870095
	.long 0xd71c008d                                           // 000000112314: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 000000112318: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 00000011231C: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 000000112320: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112328: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 00000011232C: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 000000112334: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112338: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 00000011233C: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 000000112344: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112348: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 00000011234C: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 000000112354: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 000000112358: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112360: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 000000112364: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 000000112368: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112370: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 000000112374: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 000000112378: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112380: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 000000112384: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 00000011238C: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 000000112394: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001123A0: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 0000001123A4: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 0000001123AC: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 0000001123B8: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001123C0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001123C4: BE882001
	s_cbranch_execz 65035                                      // 0000001123C8: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32f8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000001123CC: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 0000001123D8: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 0000001123DC: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 0000001123E4: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000001123E8: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001123EC: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 0000001123F0: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 0000001123F8: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 000000112404: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000112408: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 00000011240C: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000112410: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 000000112418: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000112420: BF870121
	v_add_f32_e32 v128, v128, v141                             // 000000112424: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 000000112428: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 00000011242C: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112430: BF870095
	.long 0xd71c0080                                           // 000000112434: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 000000112438: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 00000011243C: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000112440: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112448: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 00000011244C: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000112454: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112458: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 00000011245C: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 000000112464: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112468: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 00000011246C: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 000000112474: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 000000112478: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112480: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 000000112484: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 000000112488: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112490: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 000000112494: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 000000112498: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001124A0: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 0000001124A4: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 0000001124AC: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 0000001124B4: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001124C0: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 0000001124C4: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 0000001124CC: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 0000001124D8: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001124E0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001124E4: BE882002
	s_cbranch_execz 64966                                      // 0000001124E8: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3304>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 0000001124EC: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000001124F8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000112500: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000112504: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112508: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000011250C: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 000000112514: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 000000112520: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000112524: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 000000112528: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 000000112530: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000112534: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 000000112538: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 00000011253C: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000112540: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 000000112548: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011254C: BF870095
	.long 0xd71c0072                                           // 000000112550: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 000000112554: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000112558: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000011255C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112564: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 000000112568: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000112574: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112578: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000011257C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 000000112584: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112588: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 00000011258C: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 000000112594: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 000000112598: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001125A0: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 0000001125A4: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 0000001125A8: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001125B0: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 0000001125B4: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 0000001125B8: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001125C0: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 0000001125C4: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000001125CC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 0000001125D4: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001125E0: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 0000001125E4: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 0000001125EC: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000001125F8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112600: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000112604: BE882003
	s_cbranch_execz 64897                                      // 000000112608: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3310>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 00000011260C: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000112618: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000112620: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000112624: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112628: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000011262C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000112634: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 000000112640: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000112644: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 000000112648: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000011264C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000112654: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011265C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000112660: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 000000112664: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 000000112668: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011266C: BF870095
	.long 0xd71c0072                                           // 000000112670: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000112674: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000112678: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000011267C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112684: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 000000112688: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000112694: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112698: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000011269C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000001126A4: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001126A8: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 0000001126AC: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 0000001126B4: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 0000001126B8: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001126C0: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 0000001126C4: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 0000001126C8: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001126D0: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 0000001126D4: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 0000001126D8: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001126E0: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 0000001126E4: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000001126EC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 0000001126F4: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112700: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000112704: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000011270C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000112718: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112720: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000112724: BE882004
	s_cbranch_execz 64828                                      // 000000112728: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x331c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 00000011272C: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000112738: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000112740: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000112744: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112748: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000011274C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000112754: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000112760: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000112764: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000112768: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000011276C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000112774: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011277C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000112780: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000112784: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000112788: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011278C: BF870095
	.long 0xd71c0072                                           // 000000112790: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000112794: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000112798: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000011279C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001127A4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 0000001127A8: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000001127B4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001127B8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000001127BC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000001127C4: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001127C8: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000001127CC: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000001127D4: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000001127D8: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001127E0: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 0000001127E4: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 0000001127E8: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001127F0: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 0000001127F4: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 0000001127F8: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112800: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 000000112804: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000011280C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 000000112814: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112820: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000112824: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000011282C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000112838: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112840: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000112844: BE882005
	s_cbranch_execz 64759                                      // 000000112848: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3328>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 00000011284C: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000112858: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000112860: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000112864: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112868: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000011286C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000112874: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000112880: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000112884: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000112888: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000011288C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000112894: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011289C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000001128A0: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000001128A4: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000001128A8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001128AC: BF870095
	.long 0xd71c0072                                           // 0000001128B0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000001128B4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000001128B8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000001128BC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001128C4: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000001128C8: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 0000001128D0: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001128D8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000001128DC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000001128E4: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001128E8: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000001128EC: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000001128F4: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000001128F8: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112900: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 000000112904: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 000000112908: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112910: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 000000112914: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 000000112918: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112920: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 000000112924: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000011292C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 000000112934: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112940: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000112944: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000011294C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000112958: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112960: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000112964: BE882006
	s_cbranch_execz 64690                                      // 000000112968: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3334>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 00000011296C: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000112978: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000112980: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000112984: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112988: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000011298C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000112994: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000001129A0: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001129A4: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000001129A8: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000001129AC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000001129B4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001129BC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000001129C0: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000001129C4: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000001129C8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001129CC: BF870095
	.long 0xd71c0072                                           // 0000001129D0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000001129D4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000001129D8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000001129DC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001129E4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 0000001129E8: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000001129F4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001129F8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000001129FC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000112A04: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112A08: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 000000112A0C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 000000112A14: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 000000112A18: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112A20: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 000000112A24: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 000000112A28: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112A30: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 000000112A34: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 000000112A38: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112A40: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 000000112A44: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000112A4C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 000000112A54: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112A60: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000112A64: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000112A6C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000112A78: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112A80: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000112A84: BE882007
	s_cbranch_execz 64621                                      // 000000112A88: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3340>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 000000112A8C: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000112A98: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000112AA0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000112AA4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112AA8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000112AAC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000112AB4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000112AC0: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000112AC4: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000112AC8: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000112ACC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000112AD4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000112ADC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000112AE0: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000112AE4: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000112AE8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112AEC: BF870095
	.long 0xd71c0072                                           // 000000112AF0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000112AF4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000112AF8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000112AFC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112B04: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 000000112B08: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000112B14: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112B18: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000112B1C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000112B24: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112B28: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 000000112B2C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 000000112B34: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 000000112B38: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112B40: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 000000112B44: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 000000112B48: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112B50: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 000000112B54: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 000000112B58: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112B60: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 000000112B64: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000112B6C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 000000112B74: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112B80: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000112B84: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000112B8C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000112B98: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112BA0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000112BA4: BE882000
	s_cbranch_execz 64552                                      // 000000112BA8: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x334c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 000000112BAC: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 000000112BB8: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 000000112BBC: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 000000112BC4: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000112BC8: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112BCC: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000112BD0: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000112BD8: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000112BE4: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000112BE8: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000112BEC: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000112BF0: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000112BF8: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000112C00: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000112C04: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000112C08: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000112C0C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112C10: BF870095
	.long 0xd71c0072                                           // 000000112C14: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000112C18: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000112C1C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000112C20: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112C28: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 000000112C2C: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000112C34: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112C38: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 000000112C3C: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 000000112C44: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112C48: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 000000112C4C: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 000000112C54: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 000000112C58: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112C60: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 000000112C64: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 000000112C68: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112C70: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 000000112C74: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 000000112C78: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112C80: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 000000112C84: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 000000112C8C: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 000000112C94: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112CA0: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 000000112CA4: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 000000112CAC: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 000000112CB8: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112CC0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000112CC4: BE882001
	s_cbranch_execz 64483                                      // 000000112CC8: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3358>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 000000112CCC: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 000000112CD8: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 000000112CDC: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 000000112CE4: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000112CE8: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000112CEC: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 000000112CF0: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000112CF8: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 000000112D00: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 000000112D0C: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000112D10: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 000000112D14: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 000000112D1C: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000112D20: BF870121
	v_add_f32_e32 v113, v113, v114                             // 000000112D24: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 000000112D28: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 000000112D2C: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112D30: BF870095
	.long 0xd71c0071                                           // 000000112D34: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 000000112D38: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 000000112D3C: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000112D40: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112D48: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 000000112D4C: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000112D54: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112D58: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 000000112D5C: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 000000112D64: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112D68: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 000000112D6C: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 000000112D74: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 000000112D78: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112D80: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 000000112D84: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 000000112D88: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112D90: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 000000112D94: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 000000112D98: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112DA0: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 000000112DA4: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 000000112DAC: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 000000112DB4: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112DC0: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 000000112DC4: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 000000112DCC: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 000000112DD8: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112DE0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000112DE4: BE882002
	s_cbranch_execz 64414                                      // 000000112DE8: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3364>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 000000112DEC: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000112DF8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000112E00: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000112E04: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112E08: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000112E0C: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 000000112E14: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 000000112E20: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000112E24: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 000000112E28: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000112E2C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 000000112E34: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000112E3C: BF870121
	v_add_f32_e32 v106, v106, v113                             // 000000112E40: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 000000112E44: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 000000112E48: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112E4C: BF870095
	.long 0xd71c006a                                           // 000000112E50: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 000000112E54: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000112E58: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000112E5C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112E64: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 000000112E68: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000112E74: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112E78: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000112E7C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 000000112E84: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112E88: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 000000112E8C: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 000000112E94: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 000000112E98: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112EA0: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 000000112EA4: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 000000112EA8: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112EB0: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 000000112EB4: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 000000112EB8: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112EC0: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 000000112EC4: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000112ECC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 000000112ED4: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112EE0: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 000000112EE4: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 000000112EEC: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000112EF8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000112F00: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000112F04: BE882003
	s_cbranch_execz 64345                                      // 000000112F08: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3370>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 000000112F0C: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000112F18: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000112F20: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000112F24: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112F28: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000112F2C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000112F34: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 000000112F40: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112F44: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 000000112F48: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 000000112F54: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 000000112F58: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000112F5C: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000112F64: BF870293
	v_exp_f32_e32 v106, v106                                   // 000000112F68: 7ED44B6A
	.long 0xd71c006a                                           // 000000112F6C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000112F70: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000112F74: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000112F78: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000112F7C: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 000000112F84: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112F90: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 000000112F94: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000112F98: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000112FA0: BF870291
	v_rcp_f32_e32 v108, v107                                   // 000000112FA4: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 000000112FA8: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000112FB0: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 000000112FB4: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 000000112FB8: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 000000112FC0: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112FC4: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 000000112FC8: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 000000112FD0: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000112FD4: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 000000112FD8: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 000000112FE0: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000112FE8: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000112FEC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 000000112FF4: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 000000113000: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000113008: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000011300C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000113018: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000113020: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000113024: BE882004
	s_cbranch_execz 64276                                      // 000000113028: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x337c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 00000011302C: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000113038: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000113040: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000113044: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113048: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000011304C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000113054: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000113060: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000113064: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000113068: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000011306C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000113074: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011307C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000113080: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000113084: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000113088: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011308C: BF870095
	.long 0xd71c006a                                           // 000000113090: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000113094: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000113098: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000011309C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001130A4: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 0000001130A8: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000001130B4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001130B8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000001130BC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000001130C4: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001130C8: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000001130CC: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000001130D4: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000001130D8: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001130E0: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 0000001130E4: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 0000001130E8: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001130F0: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 0000001130F4: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 0000001130F8: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113100: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 000000113104: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000011310C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 000000113114: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113120: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000113124: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000011312C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000113138: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000113140: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000113144: BE882005
	s_cbranch_execz 64207                                      // 000000113148: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3388>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 00000011314C: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000113158: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000113160: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000113164: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113168: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000011316C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000113174: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000113180: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000113184: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000113188: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000011318C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000113194: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011319C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000001131A0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000001131A4: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000001131A8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001131AC: BF870095
	.long 0xd71c006a                                           // 0000001131B0: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000001131B4: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000001131B8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000001131BC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001131C4: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000001131C8: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 0000001131D0: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001131D8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000001131DC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000001131E4: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001131E8: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000001131EC: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000001131F4: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000001131F8: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113200: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000113204: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 000000113208: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113210: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 000000113214: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 000000113218: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113220: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000113224: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000011322C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 000000113234: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113240: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000113244: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000011324C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000113258: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000113260: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000113264: BE882006
	s_cbranch_execz 64138                                      // 000000113268: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3394>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 00000011326C: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000113278: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000113280: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000113284: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113288: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000011328C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000113294: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000001132A0: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001132A4: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000001132A8: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000001132AC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000001132B4: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001132BC: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000001132C0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000001132C4: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000001132C8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001132CC: BF870095
	.long 0xd71c006a                                           // 0000001132D0: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000001132D4: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000001132D8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000001132DC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001132E4: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 0000001132E8: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000001132F4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001132F8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000001132FC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000113304: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113308: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000011330C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000113314: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000113318: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113320: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000113324: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 000000113328: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113330: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 000000113334: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 000000113338: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113340: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000113344: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000011334C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 000000113354: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113360: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000113364: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000011336C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000113378: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000113380: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000113384: BE882007
	s_cbranch_execz 64069                                      // 000000113388: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33a0>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 00000011338C: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000113398: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000001133A0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000001133A4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001133A8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000001133AC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000001133B4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000001133C0: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001133C4: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000001133C8: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000001133CC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000001133D4: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001133DC: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000001133E0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000001133E4: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000001133E8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001133EC: BF870095
	.long 0xd71c006a                                           // 0000001133F0: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000001133F4: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000001133F8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000001133FC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113404: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 000000113408: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000113414: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113418: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000011341C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000113424: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113428: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000011342C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000113434: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000113438: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113440: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000113444: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 000000113448: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113450: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 000000113454: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 000000113458: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113460: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000113464: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000011346C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 000000113474: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113480: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000113484: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000011348C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000113498: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001134A0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001134A4: BE882000
	s_cbranch_execz 64000                                      // 0000001134A8: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33ac>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 0000001134AC: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 0000001134B8: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 0000001134BC: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 0000001134C4: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000001134C8: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001134CC: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000001134D0: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000001134D8: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000001134E4: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001134E8: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000001134EC: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000001134F0: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000001134F8: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000113500: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000113504: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000113508: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000011350C: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113510: BF870095
	.long 0xd71c006a                                           // 000000113514: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000113518: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000011351C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000113520: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113528: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 00000011352C: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000113534: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113538: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 00000011353C: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 000000113544: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113548: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 00000011354C: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 000000113554: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 000000113558: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113560: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 000000113564: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 000000113568: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113570: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 000000113574: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 000000113578: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113580: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 000000113584: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 00000011358C: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 000000113594: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001135A0: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 0000001135A4: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 0000001135AC: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 0000001135B8: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001135C0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001135C4: BE882001
	s_cbranch_execz 63931                                      // 0000001135C8: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33b8>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 0000001135CC: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 0000001135D8: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 0000001135DC: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 0000001135E4: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000001135E8: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001135EC: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 0000001135F0: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001135F8: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 000000113600: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 00000011360C: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000113610: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 000000113614: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 00000011361C: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000113620: BF870121
	v_add_f32_e32 v105, v105, v106                             // 000000113624: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 000000113628: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 00000011362C: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113630: BF870095
	.long 0xd71c0069                                           // 000000113634: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 000000113638: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 00000011363C: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000113640: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113648: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 00000011364C: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000113654: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113658: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 00000011365C: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 000000113664: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113668: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 00000011366C: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 000000113674: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 000000113678: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113680: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 000000113684: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 000000113688: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113690: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 000000113694: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 000000113698: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001136A0: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 0000001136A4: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 0000001136AC: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 0000001136B4: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001136C0: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 0000001136C4: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 0000001136CC: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 0000001136D8: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001136E0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001136E4: BE882002
	s_cbranch_execz 63862                                      // 0000001136E8: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33c4>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 0000001136EC: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000001136F8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000113700: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000113704: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113708: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000011370C: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 000000113714: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 000000113720: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000113724: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 000000113728: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000011372C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 000000113734: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011373C: BF870121
	v_add_f32_e32 v98, v98, v105                               // 000000113740: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 000000113744: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 000000113748: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011374C: BF870095
	.long 0xd71c0062                                           // 000000113750: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 000000113754: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000113758: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000011375C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113764: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 000000113768: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000113774: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113778: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000011377C: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 000000113784: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113788: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 00000011378C: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 000000113794: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 000000113798: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001137A0: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 0000001137A4: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 0000001137A8: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001137B0: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 0000001137B4: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 0000001137B8: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001137C0: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 0000001137C4: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000001137CC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 0000001137D4: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001137E0: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 0000001137E4: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 0000001137EC: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000001137F8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000113800: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000113804: BE882003
	s_cbranch_execz 63793                                      // 000000113808: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33d0>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 00000011380C: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000113818: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000113820: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000113824: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113828: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000011382C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000113834: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 000000113840: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113844: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 000000113848: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 000000113854: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 000000113858: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000011385C: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000113864: BF870293
	v_exp_f32_e32 v98, v98                                     // 000000113868: 7EC44B62
	.long 0xd71c0062                                           // 00000011386C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000113870: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000113874: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000113878: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000011387C: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 000000113884: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113890: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 000000113894: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000113898: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001138A0: BF870291
	v_rcp_f32_e32 v100, v99                                    // 0000001138A4: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 0000001138A8: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001138B0: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 0000001138B4: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 0000001138B8: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 0000001138C0: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001138C4: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 0000001138C8: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 0000001138D0: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001138D4: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 0000001138D8: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 0000001138E0: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001138E8: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000001138EC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 0000001138F4: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 000000113900: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 000000113908: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000011390C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000113918: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000113920: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000113924: BE882004
	s_cbranch_execz 63724                                      // 000000113928: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33dc>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 00000011392C: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000113938: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000113940: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000113944: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113948: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000011394C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000113954: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000113960: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000113964: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000113968: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000011396C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000113974: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011397C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000113980: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000113984: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000113988: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011398C: BF870095
	.long 0xd71c0062                                           // 000000113990: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000113994: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000113998: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000011399C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001139A4: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 0000001139A8: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000001139B4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001139B8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000001139BC: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000001139C4: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001139C8: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000001139CC: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000001139D4: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000001139D8: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001139E0: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 0000001139E4: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 0000001139E8: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001139F0: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 0000001139F4: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 0000001139F8: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113A00: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 000000113A04: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000113A0C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 000000113A14: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113A20: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000113A24: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000113A2C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000113A38: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000113A40: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000113A44: BE882005
	s_cbranch_execz 63655                                      // 000000113A48: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33e8>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 000000113A4C: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000113A58: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000113A60: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000113A64: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113A68: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000113A6C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000113A74: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000113A80: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000113A84: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000113A88: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000113A8C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000113A94: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000113A9C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000113AA0: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000113AA4: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000113AA8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113AAC: BF870095
	.long 0xd71c0062                                           // 000000113AB0: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000113AB4: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000113AB8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000113ABC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113AC4: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 000000113AC8: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 000000113AD0: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113AD8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000113ADC: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000113AE4: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113AE8: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000113AEC: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000113AF4: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000113AF8: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113B00: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 000000113B04: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 000000113B08: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113B10: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 000000113B14: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 000000113B18: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113B20: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 000000113B24: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000113B2C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 000000113B34: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113B40: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000113B44: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000113B4C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000113B58: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000113B60: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000113B64: BE882006
	s_cbranch_execz 63586                                      // 000000113B68: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33f4>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 000000113B6C: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000113B78: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000113B80: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000113B84: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113B88: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000113B8C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000113B94: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000113BA0: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000113BA4: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000113BA8: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000113BAC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000113BB4: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000113BBC: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000113BC0: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000113BC4: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000113BC8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113BCC: BF870095
	.long 0xd71c0062                                           // 000000113BD0: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000113BD4: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000113BD8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000113BDC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113BE4: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 000000113BE8: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000113BF4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113BF8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000113BFC: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000113C04: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113C08: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000113C0C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000113C14: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000113C18: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113C20: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 000000113C24: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 000000113C28: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113C30: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 000000113C34: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 000000113C38: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113C40: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 000000113C44: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000113C4C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 000000113C54: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113C60: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000113C64: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000113C6C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000113C78: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000113C80: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000113C84: BE882007
	s_cbranch_execz 63517                                      // 000000113C88: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3400>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 000000113C8C: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000113C98: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000113CA0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000113CA4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113CA8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000113CAC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000113CB4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000113CC0: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000113CC4: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000113CC8: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000113CCC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000113CD4: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000113CDC: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000113CE0: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000113CE4: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000113CE8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113CEC: BF870095
	.long 0xd71c0062                                           // 000000113CF0: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000113CF4: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000113CF8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000113CFC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113D04: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 000000113D08: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000113D14: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113D18: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000113D1C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000113D24: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113D28: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000113D2C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000113D34: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000113D38: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113D40: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 000000113D44: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 000000113D48: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113D50: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 000000113D54: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 000000113D58: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113D60: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 000000113D64: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000113D6C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 000000113D74: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113D80: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000113D84: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000113D8C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000113D98: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000113DA0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000113DA4: BE882000
	s_cbranch_execz 63448                                      // 000000113DA8: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x340c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 000000113DAC: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 000000113DB8: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 000000113DBC: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 000000113DC4: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000113DC8: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113DCC: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000113DD0: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000113DD8: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000113DE4: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000113DE8: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000113DEC: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000113DF0: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000113DF8: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000113E00: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000113E04: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000113E08: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000113E0C: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113E10: BF870095
	.long 0xd71c0062                                           // 000000113E14: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000113E18: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000113E1C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000113E20: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113E28: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 000000113E2C: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000113E34: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113E38: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 000000113E3C: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 000000113E44: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113E48: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 000000113E4C: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 000000113E54: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 000000113E58: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113E60: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 000000113E64: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 000000113E68: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113E70: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 000000113E74: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 000000113E78: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113E80: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 000000113E84: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 000000113E8C: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 000000113E94: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113EA0: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 000000113EA4: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 000000113EAC: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 000000113EB8: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 000000113EC0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000113EC4: BE882001
	s_cbranch_execz 63379                                      // 000000113EC8: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3418>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 000000113ECC: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 000000113ED8: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 000000113EDC: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 000000113EE4: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000113EE8: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000113EEC: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 000000113EF0: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000113EF8: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 000000113F00: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 000000113F0C: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000113F10: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 000000113F14: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 000000113F1C: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000113F20: BF870121
	v_add_f32_e32 v97, v97, v98                                // 000000113F24: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 000000113F28: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 000000113F2C: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113F30: BF870095
	.long 0xd71c0061                                           // 000000113F34: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 000000113F38: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 000000113F3C: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000113F40: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113F48: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 000000113F4C: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000113F54: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113F58: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 000000113F5C: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 000000113F64: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113F68: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 000000113F6C: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 000000113F74: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 000000113F78: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113F80: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 000000113F84: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 000000113F88: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113F90: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 000000113F94: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 000000113F98: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113FA0: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 000000113FA4: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 000000113FAC: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 000000113FB4: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000113FC0: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 000000113FC4: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 000000113FCC: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 000000113FD8: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 000000113FE0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000113FE4: BE882002
	s_cbranch_execz 63310                                      // 000000113FE8: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3424>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 000000113FEC: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000113FF8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000114000: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000114004: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114008: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000011400C: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 000000114014: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 000000114020: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000114024: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 000000114028: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000011402C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 000000114034: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011403C: BF870121
	v_add_f32_e32 v90, v90, v97                                // 000000114040: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 000000114044: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 000000114048: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011404C: BF870095
	.long 0xd71c005a                                           // 000000114050: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 000000114054: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000114058: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000011405C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114064: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 000000114068: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000114074: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114078: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000011407C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 000000114084: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114088: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 00000011408C: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 000000114094: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 000000114098: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001140A0: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 0000001140A4: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 0000001140A8: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001140B0: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 0000001140B4: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 0000001140B8: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001140C0: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 0000001140C4: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000001140CC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 0000001140D4: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001140E0: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 0000001140E4: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 0000001140EC: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000001140F8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000114100: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000114104: BE882003
	s_cbranch_execz 63241                                      // 000000114108: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3430>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 00000011410C: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000114118: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000114120: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000114124: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114128: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000011412C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000114134: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 000000114140: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114144: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 000000114148: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 000000114154: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 000000114158: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000011415C: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000114164: BF870293
	v_exp_f32_e32 v90, v90                                     // 000000114168: 7EB44B5A
	.long 0xd71c005a                                           // 00000011416C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000114170: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000114174: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000114178: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000011417C: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 000000114184: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114190: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 000000114194: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000114198: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001141A0: BF870291
	v_rcp_f32_e32 v92, v91                                     // 0000001141A4: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 0000001141A8: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001141B0: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 0000001141B4: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 0000001141B8: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 0000001141C0: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001141C4: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 0000001141C8: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 0000001141D0: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001141D4: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 0000001141D8: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 0000001141E0: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001141E8: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000001141EC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 0000001141F4: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 000000114200: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000114208: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000011420C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000114218: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000114220: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000114224: BE882004
	s_cbranch_execz 63172                                      // 000000114228: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x343c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 00000011422C: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000114238: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000114240: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000114244: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114248: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000011424C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000114254: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000114260: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000114264: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000114268: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000011426C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000114274: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011427C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000114280: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000114284: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000114288: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011428C: BF870095
	.long 0xd71c005a                                           // 000000114290: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000114294: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000114298: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000011429C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001142A4: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 0000001142A8: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000001142B4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001142B8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000001142BC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000001142C4: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001142C8: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000001142CC: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000001142D4: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000001142D8: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001142E0: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 0000001142E4: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 0000001142E8: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001142F0: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 0000001142F4: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 0000001142F8: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114300: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 000000114304: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000011430C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 000000114314: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114320: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000114324: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000011432C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000114338: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000114340: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000114344: BE882005
	s_cbranch_execz 63103                                      // 000000114348: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3448>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 00000011434C: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000114358: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000114360: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000114364: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114368: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000011436C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000114374: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000114380: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000114384: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000114388: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000011438C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000114394: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011439C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000001143A0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000001143A4: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000001143A8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001143AC: BF870095
	.long 0xd71c005a                                           // 0000001143B0: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000001143B4: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000001143B8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000001143BC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001143C4: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000001143C8: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 0000001143D0: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001143D8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000001143DC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000001143E4: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001143E8: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000001143EC: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000001143F4: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000001143F8: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114400: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000114404: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 000000114408: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114410: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 000000114414: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 000000114418: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114420: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000114424: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000011442C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 000000114434: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114440: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000114444: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000011444C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000114458: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000114460: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000114464: BE882006
	s_cbranch_execz 63034                                      // 000000114468: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3454>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 00000011446C: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000114478: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000114480: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000114484: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114488: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000011448C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000114494: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000001144A0: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001144A4: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000001144A8: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000001144AC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000001144B4: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001144BC: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000001144C0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000001144C4: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000001144C8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001144CC: BF870095
	.long 0xd71c005a                                           // 0000001144D0: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000001144D4: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000001144D8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000001144DC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001144E4: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 0000001144E8: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000001144F4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001144F8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000001144FC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000114504: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114508: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000011450C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000114514: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000114518: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114520: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000114524: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 000000114528: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114530: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 000000114534: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 000000114538: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114540: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000114544: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000011454C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 000000114554: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114560: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000114564: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000011456C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000114578: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000114580: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000114584: BE882007
	s_cbranch_execz 62965                                      // 000000114588: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3460>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 00000011458C: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000114598: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000001145A0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000001145A4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001145A8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000001145AC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000001145B4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000001145C0: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001145C4: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000001145C8: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000001145CC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000001145D4: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001145DC: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000001145E0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000001145E4: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000001145E8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001145EC: BF870095
	.long 0xd71c005a                                           // 0000001145F0: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000001145F4: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000001145F8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000001145FC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114604: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 000000114608: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000114614: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114618: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000011461C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000114624: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114628: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000011462C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000114634: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000114638: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114640: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000114644: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 000000114648: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114650: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 000000114654: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 000000114658: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114660: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000114664: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000011466C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 000000114674: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114680: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000114684: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000011468C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000114698: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001146A0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001146A4: BE882000
	s_cbranch_execz 62896                                      // 0000001146A8: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x346c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 0000001146AC: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 0000001146B8: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 0000001146BC: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 0000001146C4: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000001146C8: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001146CC: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000001146D0: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000001146D8: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000001146E4: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001146E8: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000001146EC: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000001146F0: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000001146F8: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000114700: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000114704: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000114708: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000011470C: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114710: BF870095
	.long 0xd71c005a                                           // 000000114714: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000114718: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000011471C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000114720: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114728: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 00000011472C: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000114734: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114738: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 00000011473C: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 000000114744: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114748: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 00000011474C: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 000000114754: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 000000114758: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114760: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 000000114764: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 000000114768: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114770: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 000000114774: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 000000114778: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114780: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 000000114784: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 00000011478C: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 000000114794: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001147A0: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 0000001147A4: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 0000001147AC: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 0000001147B8: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001147C0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001147C4: BE882001
	s_cbranch_execz 62827                                      // 0000001147C8: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3478>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 0000001147CC: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 0000001147D8: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 0000001147DC: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 0000001147E4: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000001147E8: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001147EC: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 0000001147F0: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000001147F8: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 000000114800: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 00000011480C: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000114810: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 000000114814: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 00000011481C: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000114820: BF870121
	v_add_f32_e32 v89, v89, v90                                // 000000114824: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 000000114828: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 00000011482C: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114830: BF870095
	.long 0xd71c0059                                           // 000000114834: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 000000114838: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000011483C: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000114840: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114848: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 00000011484C: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000114854: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114858: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 00000011485C: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 000000114864: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114868: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 00000011486C: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 000000114874: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 000000114878: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114880: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 000000114884: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 000000114888: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114890: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 000000114894: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 000000114898: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001148A0: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 0000001148A4: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 0000001148AC: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 0000001148B4: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001148C0: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 0000001148C4: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 0000001148CC: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 0000001148D8: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001148E0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001148E4: BE882002
	s_cbranch_execz 62758                                      // 0000001148E8: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3484>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 0000001148EC: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000001148F8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000114900: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000114904: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114908: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000011490C: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 000000114914: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 000000114920: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000114924: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 000000114928: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000011492C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 000000114934: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011493C: BF870121
	v_add_f32_e32 v82, v82, v89                                // 000000114940: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 000000114944: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 000000114948: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011494C: BF870095
	.long 0xd71c0052                                           // 000000114950: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 000000114954: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000114958: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000011495C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114964: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 000000114968: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000114974: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114978: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000011497C: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 000000114984: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114988: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 00000011498C: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 000000114994: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 000000114998: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001149A0: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 0000001149A4: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 0000001149A8: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001149B0: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 0000001149B4: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 0000001149B8: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001149C0: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 0000001149C4: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000001149CC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 0000001149D4: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001149E0: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 0000001149E4: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 0000001149EC: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000001149F8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000114A00: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000114A04: BE882003
	s_cbranch_execz 62689                                      // 000000114A08: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3490>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 000000114A0C: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000114A18: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000114A20: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000114A24: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114A28: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000114A2C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000114A34: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 000000114A40: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114A44: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 000000114A48: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 000000114A54: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 000000114A58: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000114A5C: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000114A64: BF870293
	v_exp_f32_e32 v82, v82                                     // 000000114A68: 7EA44B52
	.long 0xd71c0052                                           // 000000114A6C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000114A70: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000114A74: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000114A78: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000114A7C: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 000000114A84: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114A90: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 000000114A94: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000114A98: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000114AA0: BF870291
	v_rcp_f32_e32 v84, v83                                     // 000000114AA4: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 000000114AA8: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000114AB0: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 000000114AB4: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 000000114AB8: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 000000114AC0: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114AC4: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 000000114AC8: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 000000114AD0: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114AD4: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 000000114AD8: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 000000114AE0: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000114AE8: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000114AEC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 000000114AF4: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 000000114B00: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 000000114B08: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000114B0C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000114B18: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000114B20: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000114B24: BE882004
	s_cbranch_execz 62620                                      // 000000114B28: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x349c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 000000114B2C: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000114B38: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000114B40: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000114B44: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114B48: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000114B4C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000114B54: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000114B60: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000114B64: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000114B68: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000114B6C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000114B74: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000114B7C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000114B80: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000114B84: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000114B88: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114B8C: BF870095
	.long 0xd71c0052                                           // 000000114B90: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000114B94: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000114B98: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000114B9C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114BA4: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 000000114BA8: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000114BB4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114BB8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000114BBC: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000114BC4: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114BC8: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000114BCC: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000114BD4: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000114BD8: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114BE0: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 000000114BE4: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 000000114BE8: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114BF0: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 000000114BF4: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 000000114BF8: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114C00: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 000000114C04: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000114C0C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 000000114C14: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114C20: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000114C24: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000114C2C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000114C38: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000114C40: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000114C44: BE882005
	s_cbranch_execz 62551                                      // 000000114C48: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34a8>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 000000114C4C: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000114C58: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000114C60: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000114C64: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114C68: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000114C6C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000114C74: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000114C80: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000114C84: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000114C88: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000114C8C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000114C94: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000114C9C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000114CA0: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000114CA4: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000114CA8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114CAC: BF870095
	.long 0xd71c0052                                           // 000000114CB0: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000114CB4: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000114CB8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000114CBC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114CC4: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 000000114CC8: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 000000114CD0: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114CD8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000114CDC: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000114CE4: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114CE8: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000114CEC: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000114CF4: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000114CF8: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114D00: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 000000114D04: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 000000114D08: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114D10: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 000000114D14: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 000000114D18: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114D20: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 000000114D24: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000114D2C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 000000114D34: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114D40: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000114D44: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000114D4C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000114D58: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000114D60: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000114D64: BE882006
	s_cbranch_execz 62482                                      // 000000114D68: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34b4>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 000000114D6C: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000114D78: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000114D80: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000114D84: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114D88: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000114D8C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000114D94: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000114DA0: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000114DA4: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000114DA8: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000114DAC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000114DB4: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000114DBC: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000114DC0: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000114DC4: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000114DC8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114DCC: BF870095
	.long 0xd71c0052                                           // 000000114DD0: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000114DD4: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000114DD8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000114DDC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114DE4: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 000000114DE8: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000114DF4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114DF8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000114DFC: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000114E04: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114E08: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000114E0C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000114E14: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000114E18: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114E20: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 000000114E24: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 000000114E28: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114E30: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 000000114E34: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 000000114E38: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114E40: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 000000114E44: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000114E4C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 000000114E54: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114E60: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000114E64: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000114E6C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000114E78: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000114E80: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000114E84: BE882007
	s_cbranch_execz 62413                                      // 000000114E88: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34c0>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 000000114E8C: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000114E98: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000114EA0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000114EA4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114EA8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000114EAC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000114EB4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000114EC0: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000114EC4: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000114EC8: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000114ECC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000114ED4: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000114EDC: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000114EE0: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000114EE4: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000114EE8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114EEC: BF870095
	.long 0xd71c0052                                           // 000000114EF0: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000114EF4: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000114EF8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000114EFC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114F04: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 000000114F08: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000114F14: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114F18: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000114F1C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000114F24: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114F28: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000114F2C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000114F34: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000114F38: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114F40: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 000000114F44: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 000000114F48: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114F50: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 000000114F54: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 000000114F58: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114F60: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 000000114F64: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000114F6C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 000000114F74: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114F80: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000114F84: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000114F8C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000114F98: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000114FA0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000114FA4: BE882000
	s_cbranch_execz 62344                                      // 000000114FA8: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34cc>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 000000114FAC: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 000000114FB8: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 000000114FBC: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000114FC4: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000114FC8: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000114FCC: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000114FD0: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000114FD8: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000114FE4: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000114FE8: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000114FEC: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000114FF0: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000114FF8: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000115000: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000115004: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000115008: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000011500C: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115010: BF870095
	.long 0xd71c0052                                           // 000000115014: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000115018: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000011501C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000115020: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115028: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 00000011502C: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000115034: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115038: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 00000011503C: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 000000115044: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115048: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 00000011504C: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 000000115054: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 000000115058: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115060: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 000000115064: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 000000115068: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115070: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 000000115074: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 000000115078: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115080: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 000000115084: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 00000011508C: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 000000115094: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001150A0: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 0000001150A4: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 0000001150AC: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 0000001150B8: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001150C0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001150C4: BE882001
	s_cbranch_execz 62275                                      // 0000001150C8: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34d8>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 0000001150CC: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 0000001150D8: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 0000001150DC: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 0000001150E4: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000001150E8: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001150EC: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 0000001150F0: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000001150F8: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 000000115100: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000011510C: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000115110: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 000000115114: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 00000011511C: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000115120: BF870121
	v_add_f32_e32 v81, v81, v82                                // 000000115124: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 000000115128: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000011512C: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115130: BF870095
	.long 0xd71c0051                                           // 000000115134: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 000000115138: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000011513C: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000115140: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115148: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 00000011514C: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000115154: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115158: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 00000011515C: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 000000115164: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115168: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 00000011516C: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 000000115174: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 000000115178: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115180: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 000000115184: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 000000115188: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115190: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 000000115194: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 000000115198: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001151A0: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 0000001151A4: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 0000001151AC: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 0000001151B4: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001151C0: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 0000001151C4: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 0000001151CC: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 0000001151D8: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001151E0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001151E4: BE882002
	s_cbranch_execz 62206                                      // 0000001151E8: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34e4>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 0000001151EC: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000001151F8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000115200: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000115204: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115208: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000011520C: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 000000115214: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 000000115220: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000115224: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 000000115228: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000011522C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 000000115234: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011523C: BF870121
	v_add_f32_e32 v74, v74, v81                                // 000000115240: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 000000115244: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 000000115248: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011524C: BF870095
	.long 0xd71c004a                                           // 000000115250: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 000000115254: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000115258: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000011525C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115264: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 000000115268: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000115274: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115278: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000011527C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 000000115284: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115288: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 00000011528C: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 000000115294: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 000000115298: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001152A0: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 0000001152A4: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 0000001152A8: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001152B0: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 0000001152B4: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 0000001152B8: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001152C0: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 0000001152C4: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000001152CC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 0000001152D4: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001152E0: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 0000001152E4: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 0000001152EC: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000001152F8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000115300: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000115304: BE882003
	s_cbranch_execz 62137                                      // 000000115308: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34f0>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 00000011530C: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000115318: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000115320: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000115324: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115328: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000011532C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000115334: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 000000115340: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115344: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 000000115348: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 000000115354: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 000000115358: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000011535C: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000115364: BF870293
	v_exp_f32_e32 v74, v74                                     // 000000115368: 7E944B4A
	.long 0xd71c004a                                           // 00000011536C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000115370: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000115374: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000115378: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000011537C: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 000000115384: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115390: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 000000115394: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000115398: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001153A0: BF870291
	v_rcp_f32_e32 v76, v75                                     // 0000001153A4: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 0000001153A8: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001153B0: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 0000001153B4: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 0000001153B8: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 0000001153C0: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001153C4: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 0000001153C8: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 0000001153D0: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001153D4: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 0000001153D8: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 0000001153E0: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001153E8: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000001153EC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 0000001153F4: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 000000115400: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000115408: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000011540C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000115418: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000115420: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000115424: BE882004
	s_cbranch_execz 62068                                      // 000000115428: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34fc>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 00000011542C: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000115438: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000115440: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000115444: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115448: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000011544C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000115454: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000115460: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000115464: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000115468: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000011546C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000115474: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011547C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000115480: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000115484: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000115488: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011548C: BF870095
	.long 0xd71c004a                                           // 000000115490: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000115494: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000115498: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000011549C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001154A4: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 0000001154A8: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000001154B4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001154B8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000001154BC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000001154C4: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001154C8: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000001154CC: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000001154D4: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000001154D8: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001154E0: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 0000001154E4: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 0000001154E8: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001154F0: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 0000001154F4: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 0000001154F8: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115500: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 000000115504: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000011550C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 000000115514: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115520: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000115524: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000011552C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000115538: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000115540: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000115544: BE882005
	s_cbranch_execz 61999                                      // 000000115548: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3508>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 00000011554C: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000115558: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000115560: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000115564: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115568: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000011556C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000115574: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000115580: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000115584: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000115588: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000011558C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000115594: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011559C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000001155A0: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000001155A4: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000001155A8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001155AC: BF870095
	.long 0xd71c004a                                           // 0000001155B0: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000001155B4: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000001155B8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000001155BC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001155C4: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000001155C8: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 0000001155D0: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001155D8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000001155DC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000001155E4: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001155E8: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000001155EC: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000001155F4: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000001155F8: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115600: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 000000115604: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 000000115608: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115610: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 000000115614: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 000000115618: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115620: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 000000115624: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000011562C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 000000115634: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115640: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000115644: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000011564C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000115658: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000115660: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000115664: BE882006
	s_cbranch_execz 61930                                      // 000000115668: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3514>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 00000011566C: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000115678: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000115680: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000115684: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115688: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000011568C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000115694: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000001156A0: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001156A4: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000001156A8: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000001156AC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000001156B4: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001156BC: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000001156C0: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000001156C4: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000001156C8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001156CC: BF870095
	.long 0xd71c004a                                           // 0000001156D0: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000001156D4: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000001156D8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000001156DC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001156E4: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 0000001156E8: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000001156F4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001156F8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000001156FC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000115704: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115708: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000011570C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000115714: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000115718: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115720: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 000000115724: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 000000115728: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115730: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 000000115734: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 000000115738: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115740: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 000000115744: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000011574C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 000000115754: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115760: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000115764: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000011576C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000115778: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000115780: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000115784: BE882007
	s_cbranch_execz 61861                                      // 000000115788: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3520>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 00000011578C: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000115798: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000001157A0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000001157A4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001157A8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000001157AC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000001157B4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000001157C0: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001157C4: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000001157C8: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000001157CC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000001157D4: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001157DC: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000001157E0: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000001157E4: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000001157E8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001157EC: BF870095
	.long 0xd71c004a                                           // 0000001157F0: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000001157F4: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000001157F8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000001157FC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115804: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 000000115808: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000115814: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115818: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000011581C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000115824: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115828: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000011582C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000115834: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000115838: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115840: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 000000115844: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 000000115848: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115850: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 000000115854: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 000000115858: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115860: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 000000115864: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000011586C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 000000115874: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115880: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000115884: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000011588C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000115898: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001158A0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001158A4: BE882000
	s_cbranch_execz 61792                                      // 0000001158A8: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x352c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 0000001158AC: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 0000001158B8: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 0000001158BC: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000001158C4: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000001158C8: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001158CC: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000001158D0: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000001158D8: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000001158E4: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001158E8: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000001158EC: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000001158F0: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000001158F8: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000115900: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000115904: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000115908: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000011590C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115910: BF870095
	.long 0xd71c004a                                           // 000000115914: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000115918: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000011591C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000115920: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115928: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 00000011592C: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000115934: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115938: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 00000011593C: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 000000115944: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115948: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 00000011594C: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 000000115954: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 000000115958: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115960: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 000000115964: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 000000115968: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115970: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 000000115974: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 000000115978: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115980: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 000000115984: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 00000011598C: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 000000115994: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001159A0: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 0000001159A4: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 0000001159AC: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 0000001159B8: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001159C0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001159C4: BE882001
	s_cbranch_execz 61723                                      // 0000001159C8: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3538>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 0000001159CC: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 0000001159D8: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 0000001159DC: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 0000001159E4: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000001159E8: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001159EC: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 0000001159F0: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000001159F8: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 000000115A00: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 000000115A0C: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000115A10: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 000000115A14: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 000000115A1C: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000115A20: BF870121
	v_add_f32_e32 v73, v73, v74                                // 000000115A24: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 000000115A28: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 000000115A2C: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115A30: BF870095
	.long 0xd71c0049                                           // 000000115A34: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 000000115A38: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 000000115A3C: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000115A40: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115A48: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 000000115A4C: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000115A54: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115A58: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 000000115A5C: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 000000115A64: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115A68: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 000000115A6C: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 000000115A74: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 000000115A78: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115A80: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 000000115A84: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 000000115A88: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115A90: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 000000115A94: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 000000115A98: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115AA0: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 000000115AA4: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 000000115AAC: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 000000115AB4: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115AC0: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 000000115AC4: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 000000115ACC: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 000000115AD8: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000115AE0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000115AE4: BE882002
	s_cbranch_execz 61654                                      // 000000115AE8: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3544>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 000000115AEC: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000115AF8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000115B00: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000115B04: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115B08: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000115B0C: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 000000115B14: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 000000115B20: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000115B24: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 000000115B28: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000115B2C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 000000115B34: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000115B3C: BF870121
	v_add_f32_e32 v66, v66, v73                                // 000000115B40: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 000000115B44: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 000000115B48: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115B4C: BF870095
	.long 0xd71c0042                                           // 000000115B50: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 000000115B54: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000115B58: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000115B5C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115B64: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 000000115B68: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000115B74: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115B78: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000115B7C: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 000000115B84: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115B88: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 000000115B8C: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 000000115B94: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 000000115B98: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115BA0: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 000000115BA4: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 000000115BA8: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115BB0: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 000000115BB4: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 000000115BB8: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115BC0: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 000000115BC4: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000115BCC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 000000115BD4: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115BE0: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 000000115BE4: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 000000115BEC: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000115BF8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000115C00: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000115C04: BE882003
	s_cbranch_execz 61585                                      // 000000115C08: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3550>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 000000115C0C: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000115C18: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000115C20: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000115C24: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115C28: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000115C2C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000115C34: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 000000115C40: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115C44: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 000000115C48: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 000000115C54: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 000000115C58: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000115C5C: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000115C64: BF870293
	v_exp_f32_e32 v66, v66                                     // 000000115C68: 7E844B42
	.long 0xd71c0042                                           // 000000115C6C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000115C70: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000115C74: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000115C78: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000115C7C: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 000000115C84: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115C90: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 000000115C94: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000115C98: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000115CA0: BF870291
	v_rcp_f32_e32 v68, v67                                     // 000000115CA4: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 000000115CA8: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000115CB0: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 000000115CB4: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 000000115CB8: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 000000115CC0: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115CC4: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 000000115CC8: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 000000115CD0: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115CD4: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 000000115CD8: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 000000115CE0: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000115CE8: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000115CEC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 000000115CF4: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 000000115D00: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 000000115D08: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000115D0C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000115D18: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000115D20: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000115D24: BE882004
	s_cbranch_execz 61516                                      // 000000115D28: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x355c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 000000115D2C: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000115D38: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000115D40: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000115D44: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115D48: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000115D4C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000115D54: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000115D60: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000115D64: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000115D68: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000115D6C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000115D74: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000115D7C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000115D80: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000115D84: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000115D88: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115D8C: BF870095
	.long 0xd71c0042                                           // 000000115D90: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000115D94: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000115D98: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000115D9C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115DA4: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 000000115DA8: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000115DB4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115DB8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000115DBC: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000115DC4: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115DC8: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000115DCC: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000115DD4: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000115DD8: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115DE0: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 000000115DE4: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 000000115DE8: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115DF0: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 000000115DF4: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 000000115DF8: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115E00: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 000000115E04: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000115E0C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 000000115E14: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115E20: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000115E24: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000115E2C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000115E38: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000115E40: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000115E44: BE882005
	s_cbranch_execz 61447                                      // 000000115E48: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3568>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 000000115E4C: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000115E58: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000115E60: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000115E64: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115E68: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000115E6C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000115E74: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000115E80: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000115E84: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000115E88: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000115E8C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000115E94: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000115E9C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000115EA0: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000115EA4: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000115EA8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115EAC: BF870095
	.long 0xd71c0042                                           // 000000115EB0: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000115EB4: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000115EB8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000115EBC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115EC4: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000115EC8: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 000000115ED0: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115ED8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000115EDC: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000115EE4: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115EE8: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000115EEC: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000115EF4: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000115EF8: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115F00: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000115F04: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 000000115F08: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115F10: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 000000115F14: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 000000115F18: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115F20: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000115F24: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000115F2C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 000000115F34: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115F40: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000115F44: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000115F4C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000115F58: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000115F60: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000115F64: BE882006
	s_cbranch_execz 61378                                      // 000000115F68: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3574>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 000000115F6C: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000115F78: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000115F80: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000115F84: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115F88: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000115F8C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000115F94: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000115FA0: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000115FA4: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000115FA8: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000115FAC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000115FB4: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000115FBC: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000115FC0: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000115FC4: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000115FC8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115FCC: BF870095
	.long 0xd71c0042                                           // 000000115FD0: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000115FD4: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000115FD8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000115FDC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115FE4: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 000000115FE8: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000115FF4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000115FF8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000115FFC: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000116004: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116008: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000011600C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000116014: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000116018: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116020: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000116024: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000116028: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116030: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 000000116034: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000116038: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116040: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000116044: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000011604C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 000000116054: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116060: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000116064: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000011606C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000116078: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000116080: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000116084: BE882007
	s_cbranch_execz 61309                                      // 000000116088: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3580>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 00000011608C: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000116098: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000001160A0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000001160A4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001160A8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000001160AC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000001160B4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000001160C0: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001160C4: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000001160C8: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000001160CC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000001160D4: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001160DC: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000001160E0: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000001160E4: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000001160E8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001160EC: BF870095
	.long 0xd71c0042                                           // 0000001160F0: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000001160F4: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000001160F8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000001160FC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116104: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 000000116108: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000116114: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116118: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000011611C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000116124: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116128: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000011612C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000116134: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000116138: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116140: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000116144: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000116148: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116150: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 000000116154: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000116158: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116160: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000116164: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000011616C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 000000116174: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116180: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000116184: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000011618C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000116198: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001161A0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001161A4: BE882000
	s_cbranch_execz 61240                                      // 0000001161A8: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x358c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 0000001161AC: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 0000001161B8: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 0000001161BC: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 0000001161C4: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000001161C8: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001161CC: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000001161D0: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000001161D8: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000001161E4: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001161E8: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000001161EC: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000001161F0: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000001161F8: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000116200: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000116204: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000116208: 7E861144
	v_exp_f32_e32 v66, v66                                     // 00000011620C: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116210: BF870095
	.long 0xd71c0042                                           // 000000116214: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000116218: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000011621C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000116220: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116228: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 00000011622C: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000116234: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116238: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 00000011623C: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 000000116244: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116248: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 00000011624C: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 000000116254: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 000000116258: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116260: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 000000116264: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 000000116268: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116270: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 000000116274: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 000000116278: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116280: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 000000116284: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 00000011628C: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 000000116294: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001162A0: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 0000001162A4: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 0000001162AC: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 0000001162B8: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001162C0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001162C4: BE882001
	s_cbranch_execz 61171                                      // 0000001162C8: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3598>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 0000001162CC: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 0000001162D8: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 0000001162DC: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 0000001162E4: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000001162E8: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001162EC: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 0000001162F0: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000001162F8: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 000000116300: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000011630C: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000116310: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 000000116314: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 00000011631C: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000116320: BF870121
	v_add_f32_e32 v65, v65, v66                                // 000000116324: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000116328: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000011632C: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116330: BF870095
	.long 0xd71c0041                                           // 000000116334: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000116338: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000011633C: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000116340: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116348: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 00000011634C: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000116354: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116358: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 00000011635C: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 000000116364: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116368: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 00000011636C: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 000000116374: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 000000116378: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116380: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 000000116384: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 000000116388: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116390: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 000000116394: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 000000116398: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001163A0: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 0000001163A4: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 0000001163AC: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 0000001163B4: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001163C0: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 0000001163C4: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 0000001163CC: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 0000001163D8: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001163E0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001163E4: BE882002
	s_cbranch_execz 61102                                      // 0000001163E8: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35a4>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 0000001163EC: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000001163F8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000116400: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000116404: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116408: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000011640C: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 000000116414: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 000000116420: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000116424: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 000000116428: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000011642C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 000000116434: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011643C: BF870121
	v_add_f32_e32 v58, v58, v65                                // 000000116440: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 000000116444: 7E821142
	v_exp_f32_e32 v58, v58                                     // 000000116448: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011644C: BF870095
	.long 0xd71c003a                                           // 000000116450: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 000000116454: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000116458: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000011645C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116464: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 000000116468: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000116474: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116478: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000011647C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 000000116484: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116488: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 00000011648C: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 000000116494: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 000000116498: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001164A0: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 0000001164A4: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 0000001164A8: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001164B0: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 0000001164B4: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 0000001164B8: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001164C0: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 0000001164C4: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000001164CC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 0000001164D4: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001164E0: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 0000001164E4: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 0000001164EC: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000001164F8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000116500: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000116504: BE882003
	s_cbranch_execz 61033                                      // 000000116508: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35b0>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 00000011650C: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000116518: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000116520: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000116524: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116528: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000011652C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000116534: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 000000116540: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116544: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 000000116548: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 000000116554: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 000000116558: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000011655C: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000116564: BF870293
	v_exp_f32_e32 v58, v58                                     // 000000116568: 7E744B3A
	.long 0xd71c003a                                           // 00000011656C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000116570: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000116574: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000116578: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000011657C: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 000000116584: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116590: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 000000116594: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000116598: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001165A0: BF870291
	v_rcp_f32_e32 v60, v59                                     // 0000001165A4: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 0000001165A8: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001165B0: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 0000001165B4: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 0000001165B8: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 0000001165C0: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001165C4: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 0000001165C8: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 0000001165D0: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001165D4: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 0000001165D8: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 0000001165E0: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001165E8: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000001165EC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 0000001165F4: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 000000116600: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000116608: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000011660C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000116618: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000116620: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000116624: BE882004
	s_cbranch_execz 60964                                      // 000000116628: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35bc>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 00000011662C: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000116638: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000116640: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000116644: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116648: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000011664C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000116654: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000116660: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000116664: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000116668: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000011666C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000116674: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011667C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000116680: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000116684: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000116688: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011668C: BF870095
	.long 0xd71c003a                                           // 000000116690: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000116694: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000116698: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000011669C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001166A4: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 0000001166A8: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000001166B4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001166B8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000001166BC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000001166C4: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001166C8: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000001166CC: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000001166D4: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000001166D8: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001166E0: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 0000001166E4: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 0000001166E8: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001166F0: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 0000001166F4: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 0000001166F8: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116700: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 000000116704: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000011670C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 000000116714: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116720: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000116724: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000011672C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000116738: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000116740: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000116744: BE882005
	s_cbranch_execz 60895                                      // 000000116748: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35c8>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 00000011674C: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000116758: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000116760: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000116764: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116768: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000011676C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000116774: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000116780: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000116784: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000116788: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000011678C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000116794: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011679C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000001167A0: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000001167A4: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000001167A8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001167AC: BF870095
	.long 0xd71c003a                                           // 0000001167B0: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000001167B4: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000001167B8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000001167BC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001167C4: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000001167C8: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 0000001167D0: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001167D8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000001167DC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000001167E4: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001167E8: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000001167EC: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000001167F4: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000001167F8: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116800: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 000000116804: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 000000116808: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116810: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 000000116814: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 000000116818: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116820: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 000000116824: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000011682C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 000000116834: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116840: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000116844: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000011684C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000116858: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000116860: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000116864: BE882006
	s_cbranch_execz 60826                                      // 000000116868: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35d4>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 00000011686C: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000116878: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000116880: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000116884: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116888: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000011688C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000116894: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000001168A0: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001168A4: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000001168A8: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000001168AC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000001168B4: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001168BC: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000001168C0: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000001168C4: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000001168C8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001168CC: BF870095
	.long 0xd71c003a                                           // 0000001168D0: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000001168D4: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000001168D8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000001168DC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001168E4: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 0000001168E8: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000001168F4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001168F8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000001168FC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000116904: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116908: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000011690C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000116914: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000116918: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116920: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 000000116924: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 000000116928: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116930: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 000000116934: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 000000116938: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116940: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 000000116944: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000011694C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 000000116954: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116960: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000116964: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000011696C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000116978: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000116980: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000116984: BE882007
	s_cbranch_execz 60757                                      // 000000116988: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35e0>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 00000011698C: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000116998: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000001169A0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000001169A4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001169A8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000001169AC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000001169B4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000001169C0: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001169C4: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000001169C8: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000001169CC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000001169D4: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001169DC: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000001169E0: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000001169E4: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000001169E8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001169EC: BF870095
	.long 0xd71c003a                                           // 0000001169F0: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000001169F4: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000001169F8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000001169FC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116A04: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 000000116A08: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000116A14: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116A18: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000116A1C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000116A24: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116A28: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000116A2C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000116A34: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000116A38: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116A40: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 000000116A44: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 000000116A48: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116A50: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 000000116A54: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 000000116A58: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116A60: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 000000116A64: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000116A6C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 000000116A74: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116A80: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000116A84: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000116A8C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000116A98: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000116AA0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000116AA4: BE882000
	s_cbranch_execz 60688                                      // 000000116AA8: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35ec>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 000000116AAC: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 000000116AB8: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 000000116ABC: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 000000116AC4: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000116AC8: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116ACC: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000116AD0: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000116AD8: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000116AE4: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000116AE8: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000116AEC: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000116AF0: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000116AF8: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000116B00: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000116B04: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000116B08: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000116B0C: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116B10: BF870095
	.long 0xd71c003a                                           // 000000116B14: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000116B18: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000116B1C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000116B20: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116B28: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 000000116B2C: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000116B34: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116B38: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 000000116B3C: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 000000116B44: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116B48: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 000000116B4C: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 000000116B54: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 000000116B58: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116B60: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 000000116B64: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 000000116B68: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116B70: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 000000116B74: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 000000116B78: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116B80: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 000000116B84: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 000000116B8C: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 000000116B94: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116BA0: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 000000116BA4: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 000000116BAC: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 000000116BB8: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000116BC0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000116BC4: BE882001
	s_cbranch_execz 60619                                      // 000000116BC8: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35f8>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 000000116BCC: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 000000116BD8: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 000000116BDC: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 000000116BE4: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000116BE8: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000116BEC: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 000000116BF0: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000116BF8: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 000000116C00: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 000000116C0C: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000116C10: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 000000116C14: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 000000116C1C: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000116C20: BF870121
	v_add_f32_e32 v57, v57, v58                                // 000000116C24: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 000000116C28: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 000000116C2C: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116C30: BF870095
	.long 0xd71c0039                                           // 000000116C34: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 000000116C38: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 000000116C3C: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000116C40: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116C48: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 000000116C4C: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000116C54: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116C58: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 000000116C5C: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 000000116C64: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116C68: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 000000116C6C: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 000000116C74: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 000000116C78: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116C80: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 000000116C84: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 000000116C88: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116C90: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 000000116C94: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 000000116C98: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116CA0: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 000000116CA4: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 000000116CAC: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 000000116CB4: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116CC0: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 000000116CC4: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 000000116CCC: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 000000116CD8: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000116CE0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000116CE4: BE882002
	s_cbranch_execz 60550                                      // 000000116CE8: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3604>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 000000116CEC: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000116CF8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000116D00: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000116D04: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116D08: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000116D0C: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 000000116D14: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 000000116D20: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000116D24: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 000000116D28: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000116D2C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 000000116D34: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000116D3C: BF870121
	v_add_f32_e32 v50, v50, v57                                // 000000116D40: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 000000116D44: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 000000116D48: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116D4C: BF870095
	.long 0xd71c0032                                           // 000000116D50: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 000000116D54: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000116D58: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000116D5C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116D64: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 000000116D68: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000116D74: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116D78: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000116D7C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 000000116D84: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116D88: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 000000116D8C: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 000000116D94: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 000000116D98: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116DA0: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 000000116DA4: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 000000116DA8: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116DB0: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 000000116DB4: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 000000116DB8: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116DC0: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 000000116DC4: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000116DCC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 000000116DD4: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116DE0: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 000000116DE4: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 000000116DEC: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000116DF8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000116E00: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000116E04: BE882003
	s_cbranch_execz 60481                                      // 000000116E08: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3610>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 000000116E0C: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000116E18: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000116E20: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000116E24: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116E28: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000116E2C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000116E34: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 000000116E40: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116E44: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 000000116E48: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 000000116E54: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 000000116E58: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000116E5C: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000116E64: BF870293
	v_exp_f32_e32 v50, v50                                     // 000000116E68: 7E644B32
	.long 0xd71c0032                                           // 000000116E6C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000116E70: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000116E74: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000116E78: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000116E7C: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 000000116E84: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116E90: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 000000116E94: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000116E98: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000116EA0: BF870291
	v_rcp_f32_e32 v52, v51                                     // 000000116EA4: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 000000116EA8: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000116EB0: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 000000116EB4: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 000000116EB8: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 000000116EC0: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116EC4: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 000000116EC8: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 000000116ED0: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116ED4: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 000000116ED8: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 000000116EE0: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000116EE8: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000116EEC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 000000116EF4: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 000000116F00: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 000000116F08: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000116F0C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000116F18: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000116F20: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000116F24: BE882004
	s_cbranch_execz 60412                                      // 000000116F28: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x361c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 000000116F2C: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000116F38: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000116F40: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000116F44: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116F48: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000116F4C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000116F54: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000116F60: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000116F64: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000116F68: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000116F6C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000116F74: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000116F7C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000116F80: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000116F84: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000116F88: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116F8C: BF870095
	.long 0xd71c0032                                           // 000000116F90: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000116F94: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000116F98: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000116F9C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116FA4: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 000000116FA8: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000116FB4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116FB8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000116FBC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000116FC4: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116FC8: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000116FCC: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000116FD4: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000116FD8: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116FE0: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 000000116FE4: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 000000116FE8: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000116FF0: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 000000116FF4: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 000000116FF8: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117000: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 000000117004: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000011700C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 000000117014: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117020: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000117024: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000011702C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000117038: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000117040: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000117044: BE882005
	s_cbranch_execz 60343                                      // 000000117048: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3628>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 00000011704C: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000117058: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000117060: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000117064: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117068: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000011706C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000117074: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000117080: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000117084: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000117088: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000011708C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000117094: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011709C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000001170A0: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000001170A4: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000001170A8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001170AC: BF870095
	.long 0xd71c0032                                           // 0000001170B0: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000001170B4: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000001170B8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001170BC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001170C4: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 0000001170C8: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 0000001170D0: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001170D8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000001170DC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000001170E4: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001170E8: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000001170EC: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000001170F4: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000001170F8: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117100: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000117104: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 000000117108: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117110: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 000000117114: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 000000117118: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117120: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000117124: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000011712C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 000000117134: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117140: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000117144: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000011714C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000117158: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000117160: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000117164: BE882006
	s_cbranch_execz 60274                                      // 000000117168: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3634>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 00000011716C: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000117178: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000117180: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000117184: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117188: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000011718C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000117194: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000001171A0: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001171A4: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000001171A8: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001171AC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000001171B4: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001171BC: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000001171C0: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000001171C4: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000001171C8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001171CC: BF870095
	.long 0xd71c0032                                           // 0000001171D0: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000001171D4: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000001171D8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001171DC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001171E4: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 0000001171E8: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000001171F4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001171F8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000001171FC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000117204: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117208: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000011720C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000117214: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000117218: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117220: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000117224: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000117228: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117230: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 000000117234: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000117238: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117240: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000117244: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000011724C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 000000117254: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117260: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000117264: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000011726C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000117278: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000117280: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000117284: BE882007
	s_cbranch_execz 60205                                      // 000000117288: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3640>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 00000011728C: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000117298: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000001172A0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000001172A4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001172A8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000001172AC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000001172B4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000001172C0: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001172C4: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000001172C8: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001172CC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000001172D4: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001172DC: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000001172E0: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000001172E4: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000001172E8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001172EC: BF870095
	.long 0xd71c0032                                           // 0000001172F0: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000001172F4: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000001172F8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001172FC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117304: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 000000117308: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000117314: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117318: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000011731C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000117324: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117328: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000011732C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000117334: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000117338: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117340: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000117344: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000117348: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117350: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 000000117354: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000117358: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117360: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000117364: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000011736C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 000000117374: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117380: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000117384: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000011738C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000117398: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001173A0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001173A4: BE882000
	s_cbranch_execz 60136                                      // 0000001173A8: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x364c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 0000001173AC: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 0000001173B8: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 0000001173BC: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 0000001173C4: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000001173C8: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001173CC: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000001173D0: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000001173D8: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000001173E4: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001173E8: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000001173EC: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001173F0: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000001173F8: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000117400: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000117404: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000117408: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000011740C: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117410: BF870095
	.long 0xd71c0032                                           // 000000117414: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000117418: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000011741C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000117420: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117428: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 00000011742C: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000117434: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117438: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 00000011743C: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 000000117444: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117448: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000011744C: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 000000117454: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 000000117458: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117460: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 000000117464: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 000000117468: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117470: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 000000117474: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 000000117478: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117480: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 000000117484: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 00000011748C: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 000000117494: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001174A0: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 0000001174A4: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 0000001174AC: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 0000001174B8: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001174C0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001174C4: BE882001
	s_cbranch_execz 60067                                      // 0000001174C8: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3658>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 0000001174CC: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 0000001174D8: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 0000001174DC: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 0000001174E4: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000001174E8: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001174EC: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 0000001174F0: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000001174F8: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 000000117500: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000011750C: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000117510: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 000000117514: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 00000011751C: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000117520: BF870121
	v_add_f32_e32 v49, v49, v50                                // 000000117524: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 000000117528: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000011752C: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117530: BF870095
	.long 0xd71c0031                                           // 000000117534: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 000000117538: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000011753C: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000117540: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117548: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 00000011754C: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000117554: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117558: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 00000011755C: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 000000117564: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117568: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 00000011756C: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 000000117574: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 000000117578: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117580: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 000000117584: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 000000117588: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117590: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 000000117594: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 000000117598: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001175A0: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 0000001175A4: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 0000001175AC: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 0000001175B4: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001175C0: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 0000001175C4: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 0000001175CC: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 0000001175D8: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001175E0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001175E4: BE882002
	s_cbranch_execz 59998                                      // 0000001175E8: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3664>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 0000001175EC: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000001175F8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000117600: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000117604: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117608: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000011760C: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 000000117614: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 000000117620: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000117624: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 000000117628: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000011762C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 000000117634: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011763C: BF870121
	v_add_f32_e32 v42, v42, v49                                // 000000117640: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 000000117644: 7E621132
	v_exp_f32_e32 v42, v42                                     // 000000117648: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011764C: BF870095
	.long 0xd71c002a                                           // 000000117650: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 000000117654: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000117658: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000011765C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117664: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 000000117668: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000117674: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117678: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000011767C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 000000117684: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117688: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 00000011768C: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 000000117694: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 000000117698: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001176A0: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 0000001176A4: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 0000001176A8: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001176B0: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 0000001176B4: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 0000001176B8: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001176C0: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 0000001176C4: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000001176CC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 0000001176D4: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001176E0: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 0000001176E4: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 0000001176EC: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000001176F8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000117700: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000117704: BE882003
	s_cbranch_execz 59929                                      // 000000117708: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3670>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 00000011770C: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000117718: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000117720: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000117724: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117728: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000011772C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000117734: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 000000117740: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117744: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 000000117748: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 000000117754: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 000000117758: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000011775C: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000117764: BF870293
	v_exp_f32_e32 v42, v42                                     // 000000117768: 7E544B2A
	.long 0xd71c002a                                           // 00000011776C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000117770: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000117774: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000117778: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000011777C: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 000000117784: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117790: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 000000117794: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000117798: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001177A0: BF870291
	v_rcp_f32_e32 v44, v43                                     // 0000001177A4: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 0000001177A8: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001177B0: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 0000001177B4: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 0000001177B8: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 0000001177C0: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001177C4: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 0000001177C8: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 0000001177D0: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001177D4: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 0000001177D8: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 0000001177E0: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001177E8: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000001177EC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 0000001177F4: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 000000117800: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000117808: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000011780C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000117818: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000117820: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000117824: BE882004
	s_cbranch_execz 59860                                      // 000000117828: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x367c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 00000011782C: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000117838: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000117840: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000117844: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117848: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000011784C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000117854: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000117860: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000117864: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000117868: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000011786C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000117874: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011787C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000117880: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000117884: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000117888: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011788C: BF870095
	.long 0xd71c002a                                           // 000000117890: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000117894: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000117898: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000011789C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001178A4: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 0000001178A8: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000001178B4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001178B8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000001178BC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000001178C4: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001178C8: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000001178CC: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000001178D4: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000001178D8: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001178E0: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 0000001178E4: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 0000001178E8: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001178F0: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 0000001178F4: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 0000001178F8: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117900: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 000000117904: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000011790C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 000000117914: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117920: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000117924: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000011792C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000117938: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000117940: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000117944: BE882005
	s_cbranch_execz 59791                                      // 000000117948: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3688>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 00000011794C: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000117958: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000117960: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000117964: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117968: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000011796C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000117974: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000117980: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000117984: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000117988: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000011798C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000117994: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011799C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000001179A0: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000001179A4: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000001179A8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001179AC: BF870095
	.long 0xd71c002a                                           // 0000001179B0: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000001179B4: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000001179B8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000001179BC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001179C4: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000001179C8: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 0000001179D0: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001179D8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000001179DC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000001179E4: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001179E8: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000001179EC: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000001179F4: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000001179F8: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117A00: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 000000117A04: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 000000117A08: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117A10: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 000000117A14: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 000000117A18: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117A20: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 000000117A24: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000117A2C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 000000117A34: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117A40: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000117A44: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000117A4C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000117A58: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000117A60: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000117A64: BE882006
	s_cbranch_execz 59722                                      // 000000117A68: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3694>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 000000117A6C: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000117A78: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000117A80: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000117A84: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117A88: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000117A8C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000117A94: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000117AA0: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000117AA4: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000117AA8: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000117AAC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000117AB4: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000117ABC: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000117AC0: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000117AC4: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000117AC8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117ACC: BF870095
	.long 0xd71c002a                                           // 000000117AD0: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000117AD4: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000117AD8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000117ADC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117AE4: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 000000117AE8: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000117AF4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117AF8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000117AFC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000117B04: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117B08: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000117B0C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000117B14: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000117B18: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117B20: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 000000117B24: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 000000117B28: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117B30: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 000000117B34: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 000000117B38: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117B40: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 000000117B44: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000117B4C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 000000117B54: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117B60: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000117B64: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000117B6C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000117B78: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000117B80: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000117B84: BE882007
	s_cbranch_execz 59653                                      // 000000117B88: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36a0>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 000000117B8C: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000117B98: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000117BA0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000117BA4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117BA8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000117BAC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000117BB4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000117BC0: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000117BC4: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000117BC8: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000117BCC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000117BD4: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000117BDC: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000117BE0: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000117BE4: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000117BE8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117BEC: BF870095
	.long 0xd71c002a                                           // 000000117BF0: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000117BF4: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000117BF8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000117BFC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117C04: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 000000117C08: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000117C14: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117C18: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000117C1C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000117C24: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117C28: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000117C2C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000117C34: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000117C38: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117C40: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 000000117C44: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 000000117C48: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117C50: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 000000117C54: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 000000117C58: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117C60: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 000000117C64: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000117C6C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 000000117C74: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117C80: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000117C84: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000117C8C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000117C98: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000117CA0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000117CA4: BE882000
	s_cbranch_execz 59584                                      // 000000117CA8: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36ac>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 000000117CAC: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 000000117CB8: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 000000117CBC: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 000000117CC4: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000117CC8: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117CCC: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000117CD0: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000117CD8: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000117CE4: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000117CE8: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000117CEC: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000117CF0: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000117CF8: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000117D00: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000117D04: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000117D08: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000117D0C: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117D10: BF870095
	.long 0xd71c002a                                           // 000000117D14: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000117D18: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000117D1C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000117D20: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117D28: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 000000117D2C: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000117D34: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117D38: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 000000117D3C: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 000000117D44: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117D48: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 000000117D4C: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 000000117D54: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 000000117D58: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117D60: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 000000117D64: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 000000117D68: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117D70: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 000000117D74: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 000000117D78: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117D80: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 000000117D84: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 000000117D8C: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 000000117D94: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117DA0: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 000000117DA4: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 000000117DAC: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 000000117DB8: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 000000117DC0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000117DC4: BE882001
	s_cbranch_execz 59515                                      // 000000117DC8: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36b8>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 000000117DCC: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 000000117DD8: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 000000117DDC: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 000000117DE4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000117DE8: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000117DEC: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 000000117DF0: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000117DF8: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 000000117E00: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 000000117E0C: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000117E10: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 000000117E14: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 000000117E1C: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000117E20: BF870121
	v_add_f32_e32 v41, v41, v42                                // 000000117E24: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 000000117E28: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 000000117E2C: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117E30: BF870095
	.long 0xd71c0029                                           // 000000117E34: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 000000117E38: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 000000117E3C: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000117E40: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117E48: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 000000117E4C: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000117E54: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117E58: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 000000117E5C: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 000000117E64: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117E68: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 000000117E6C: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 000000117E74: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 000000117E78: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117E80: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 000000117E84: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 000000117E88: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117E90: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 000000117E94: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 000000117E98: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117EA0: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 000000117EA4: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 000000117EAC: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 000000117EB4: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117EC0: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 000000117EC4: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 000000117ECC: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 000000117ED8: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000117EE0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000117EE4: BE882002
	s_cbranch_execz 59446                                      // 000000117EE8: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36c4>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 000000117EEC: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000117EF8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000117F00: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000117F04: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117F08: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000117F0C: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 000000117F14: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 000000117F20: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000117F24: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 000000117F28: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000117F2C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 000000117F34: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000117F3C: BF870121
	v_add_f32_e32 v34, v34, v41                                // 000000117F40: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 000000117F44: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 000000117F48: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117F4C: BF870095
	.long 0xd71c0022                                           // 000000117F50: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 000000117F54: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000117F58: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000117F5C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117F64: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 000000117F68: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000117F74: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117F78: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000117F7C: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 000000117F84: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117F88: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 000000117F8C: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 000000117F94: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 000000117F98: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117FA0: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 000000117FA4: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 000000117FA8: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117FB0: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 000000117FB4: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 000000117FB8: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117FC0: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 000000117FC4: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000117FCC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 000000117FD4: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000117FE0: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 000000117FE4: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 000000117FEC: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000117FF8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000118000: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000118004: BE882003
	s_cbranch_execz 59377                                      // 000000118008: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36d0>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 00000011800C: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000118018: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000118020: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000118024: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118028: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000011802C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000118034: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 000000118040: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118044: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 000000118048: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 000000118054: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 000000118058: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000011805C: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000118064: BF870293
	v_exp_f32_e32 v34, v34                                     // 000000118068: 7E444B22
	.long 0xd71c0022                                           // 00000011806C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000118070: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000118074: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000118078: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000011807C: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 000000118084: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118090: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 000000118094: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000118098: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001180A0: BF870291
	v_rcp_f32_e32 v36, v35                                     // 0000001180A4: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 0000001180A8: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001180B0: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 0000001180B4: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 0000001180B8: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 0000001180C0: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001180C4: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 0000001180C8: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 0000001180D0: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001180D4: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 0000001180D8: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 0000001180E0: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001180E8: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000001180EC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 0000001180F4: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 000000118100: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 000000118108: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000011810C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000118118: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000118120: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000118124: BE882004
	s_cbranch_execz 59308                                      // 000000118128: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36dc>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 00000011812C: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000118138: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000118140: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000118144: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118148: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000011814C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000118154: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000118160: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000118164: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000118168: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000011816C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000118174: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011817C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000118180: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000118184: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000118188: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011818C: BF870095
	.long 0xd71c0022                                           // 000000118190: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000118194: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000118198: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000011819C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001181A4: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 0000001181A8: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000001181B4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001181B8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000001181BC: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000001181C4: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001181C8: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000001181CC: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000001181D4: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000001181D8: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001181E0: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 0000001181E4: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 0000001181E8: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001181F0: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 0000001181F4: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 0000001181F8: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118200: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 000000118204: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000011820C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 000000118214: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118220: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000118224: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000011822C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000118238: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000118240: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000118244: BE882005
	s_cbranch_execz 59239                                      // 000000118248: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36e8>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 00000011824C: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000118258: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000118260: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000118264: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118268: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000011826C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000118274: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000118280: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000118284: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000118288: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000011828C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000118294: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011829C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000001182A0: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000001182A4: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000001182A8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001182AC: BF870095
	.long 0xd71c0022                                           // 0000001182B0: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000001182B4: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000001182B8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000001182BC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001182C4: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000001182C8: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 0000001182D0: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001182D8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000001182DC: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000001182E4: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001182E8: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000001182EC: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000001182F4: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000001182F8: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118300: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000118304: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 000000118308: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118310: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 000000118314: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 000000118318: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118320: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000118324: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000011832C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 000000118334: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118340: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000118344: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000011834C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000118358: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000118360: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000118364: BE882006
	s_cbranch_execz 59170                                      // 000000118368: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36f4>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 00000011836C: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000118378: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000118380: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000118384: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118388: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000011838C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000118394: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000001183A0: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001183A4: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000001183A8: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000001183AC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000001183B4: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001183BC: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000001183C0: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000001183C4: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000001183C8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001183CC: BF870095
	.long 0xd71c0022                                           // 0000001183D0: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000001183D4: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000001183D8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000001183DC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001183E4: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 0000001183E8: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000001183F4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001183F8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000001183FC: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000118404: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118408: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000011840C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000118414: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000118418: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118420: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000118424: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000118428: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118430: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 000000118434: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000118438: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118440: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000118444: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000011844C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 000000118454: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118460: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000118464: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000011846C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000118478: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000118480: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000118484: BE882007
	s_cbranch_execz 59101                                      // 000000118488: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3700>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 00000011848C: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000118498: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000001184A0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000001184A4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001184A8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000001184AC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000001184B4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000001184C0: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001184C4: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000001184C8: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000001184CC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000001184D4: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001184DC: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000001184E0: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000001184E4: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000001184E8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001184EC: BF870095
	.long 0xd71c0022                                           // 0000001184F0: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000001184F4: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000001184F8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000001184FC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118504: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 000000118508: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000118514: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118518: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000011851C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000118524: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118528: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000011852C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000118534: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000118538: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118540: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000118544: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000118548: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118550: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 000000118554: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000118558: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118560: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000118564: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000011856C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 000000118574: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118580: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000118584: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000011858C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000118598: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001185A0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001185A4: BE882000
	s_cbranch_execz 59032                                      // 0000001185A8: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x370c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 0000001185AC: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 0000001185B8: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 0000001185BC: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 0000001185C4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000001185C8: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001185CC: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000001185D0: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000001185D8: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000001185E4: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001185E8: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000001185EC: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000001185F0: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000001185F8: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000118600: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000118604: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000118608: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000011860C: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118610: BF870095
	.long 0xd71c0022                                           // 000000118614: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000118618: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000011861C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000118620: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118628: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 00000011862C: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000118634: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118638: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 00000011863C: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 000000118644: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118648: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 00000011864C: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 000000118654: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 000000118658: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118660: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 000000118664: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 000000118668: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118670: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 000000118674: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 000000118678: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118680: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 000000118684: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 00000011868C: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 000000118694: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001186A0: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 0000001186A4: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 0000001186AC: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 0000001186B8: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001186C0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001186C4: BE882001
	s_cbranch_execz 58963                                      // 0000001186C8: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3718>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 0000001186CC: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 0000001186D8: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 0000001186DC: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 0000001186E4: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000001186E8: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001186EC: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 0000001186F0: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000001186F8: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 000000118700: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000011870C: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000118710: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 000000118714: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 00000011871C: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000118720: BF870121
	v_add_f32_e32 v33, v33, v34                                // 000000118724: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 000000118728: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000011872C: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118730: BF870095
	.long 0xd71c0021                                           // 000000118734: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 000000118738: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000011873C: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000118740: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118748: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 00000011874C: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000118754: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118758: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 00000011875C: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 000000118764: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118768: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 00000011876C: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 000000118774: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 000000118778: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118780: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 000000118784: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 000000118788: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118790: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 000000118794: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 000000118798: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001187A0: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 0000001187A4: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 0000001187AC: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 0000001187B4: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001187C0: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 0000001187C4: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 0000001187CC: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 0000001187D8: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001187E0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001187E4: BE882002
	s_cbranch_execz 58894                                      // 0000001187E8: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3724>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 0000001187EC: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000001187F8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000118800: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000118804: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118808: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000011880C: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 000000118814: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 000000118820: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000118824: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 000000118828: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000011882C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 000000118834: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011883C: BF870121
	v_add_f32_e32 v26, v26, v33                                // 000000118840: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 000000118844: 7E421122
	v_exp_f32_e32 v26, v26                                     // 000000118848: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011884C: BF870095
	.long 0xd71c001a                                           // 000000118850: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 000000118854: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000118858: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000011885C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118864: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 000000118868: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000118874: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118878: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000011887C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 000000118884: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118888: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 00000011888C: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 000000118894: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 000000118898: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001188A0: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 0000001188A4: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 0000001188A8: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001188B0: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 0000001188B4: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 0000001188B8: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001188C0: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 0000001188C4: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000001188CC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 0000001188D4: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001188E0: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 0000001188E4: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 0000001188EC: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000001188F8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000118900: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000118904: BE882003
	s_cbranch_execz 58825                                      // 000000118908: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3730>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 00000011890C: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000118918: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000118920: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000118924: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118928: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000011892C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000118934: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 000000118940: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118944: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 000000118948: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 000000118954: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 000000118958: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000011895C: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000118964: BF870293
	v_exp_f32_e32 v26, v26                                     // 000000118968: 7E344B1A
	.long 0xd71c001a                                           // 00000011896C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000118970: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000118974: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000118978: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000011897C: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 000000118984: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118990: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 000000118994: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000118998: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001189A0: BF870291
	v_rcp_f32_e32 v28, v27                                     // 0000001189A4: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 0000001189A8: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001189B0: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 0000001189B4: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 0000001189B8: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 0000001189C0: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001189C4: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 0000001189C8: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 0000001189D0: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001189D4: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 0000001189D8: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 0000001189E0: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001189E8: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000001189EC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 0000001189F4: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 000000118A00: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000118A08: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000118A0C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000118A18: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000118A20: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000118A24: BE882004
	s_cbranch_execz 58756                                      // 000000118A28: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x373c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 000000118A2C: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000118A38: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000118A40: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000118A44: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118A48: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000118A4C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000118A54: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000118A60: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000118A64: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000118A68: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000118A6C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000118A74: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000118A7C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000118A80: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000118A84: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000118A88: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118A8C: BF870095
	.long 0xd71c001a                                           // 000000118A90: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000118A94: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000118A98: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000118A9C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118AA4: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 000000118AA8: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000118AB4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118AB8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000118ABC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000118AC4: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118AC8: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000118ACC: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000118AD4: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000118AD8: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118AE0: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 000000118AE4: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 000000118AE8: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118AF0: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 000000118AF4: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 000000118AF8: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118B00: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 000000118B04: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000118B0C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 000000118B14: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118B20: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000118B24: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000118B2C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000118B38: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000118B40: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000118B44: BE882005
	s_cbranch_execz 58687                                      // 000000118B48: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3748>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 000000118B4C: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000118B58: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000118B60: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000118B64: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118B68: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000118B6C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000118B74: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000118B80: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000118B84: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000118B88: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000118B8C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000118B94: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000118B9C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000118BA0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000118BA4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000118BA8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118BAC: BF870095
	.long 0xd71c001a                                           // 000000118BB0: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000118BB4: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000118BB8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000118BBC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118BC4: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 000000118BC8: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 000000118BD0: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118BD8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000118BDC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000118BE4: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118BE8: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000118BEC: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000118BF4: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000118BF8: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118C00: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 000000118C04: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 000000118C08: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118C10: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 000000118C14: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 000000118C18: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118C20: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000118C24: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000118C2C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 000000118C34: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118C40: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000118C44: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000118C4C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000118C58: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000118C60: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000118C64: BE882006
	s_cbranch_execz 58618                                      // 000000118C68: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3754>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 000000118C6C: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000118C78: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000118C80: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000118C84: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118C88: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000118C8C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000118C94: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000118CA0: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000118CA4: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000118CA8: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000118CAC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000118CB4: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000118CBC: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000118CC0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000118CC4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000118CC8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118CCC: BF870095
	.long 0xd71c001a                                           // 000000118CD0: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000118CD4: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000118CD8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000118CDC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118CE4: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 000000118CE8: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000118CF4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118CF8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000118CFC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000118D04: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118D08: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000118D0C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000118D14: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000118D18: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118D20: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 000000118D24: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 000000118D28: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118D30: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 000000118D34: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 000000118D38: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118D40: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000118D44: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000118D4C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 000000118D54: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118D60: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000118D64: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000118D6C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000118D78: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000118D80: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000118D84: BE882007
	s_cbranch_execz 58549                                      // 000000118D88: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3760>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 000000118D8C: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000118D98: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000118DA0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000118DA4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118DA8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000118DAC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000118DB4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000118DC0: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000118DC4: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000118DC8: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000118DCC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000118DD4: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000118DDC: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000118DE0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000118DE4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000118DE8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118DEC: BF870095
	.long 0xd71c001a                                           // 000000118DF0: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000118DF4: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000118DF8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000118DFC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118E04: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 000000118E08: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000118E14: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118E18: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000118E1C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000118E24: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118E28: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000118E2C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000118E34: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000118E38: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118E40: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 000000118E44: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 000000118E48: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118E50: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 000000118E54: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 000000118E58: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118E60: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000118E64: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000118E6C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 000000118E74: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118E80: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000118E84: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000118E8C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000118E98: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000118EA0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000118EA4: BE882000
	s_cbranch_execz 58480                                      // 000000118EA8: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x376c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 000000118EAC: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 000000118EB8: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 000000118EBC: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 000000118EC4: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000118EC8: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118ECC: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000118ED0: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000118ED8: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000118EE4: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000118EE8: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000118EEC: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000118EF0: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000118EF8: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000118F00: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000118F04: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000118F08: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000118F0C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118F10: BF870095
	.long 0xd71c001a                                           // 000000118F14: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000118F18: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000118F1C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000118F20: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118F28: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 000000118F2C: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000118F34: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118F38: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 000000118F3C: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 000000118F44: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118F48: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 000000118F4C: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 000000118F54: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 000000118F58: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118F60: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 000000118F64: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 000000118F68: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118F70: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 000000118F74: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 000000118F78: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118F80: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 000000118F84: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 000000118F8C: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 000000118F94: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000118FA0: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 000000118FA4: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 000000118FAC: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 000000118FB8: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 000000118FC0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000118FC4: BE882001
	s_cbranch_execz 58411                                      // 000000118FC8: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3778>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 000000118FCC: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 000000118FD8: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 000000118FDC: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 000000118FE4: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000118FE8: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000118FEC: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 000000118FF0: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000118FF8: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 000000119000: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000011900C: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000119010: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 000000119014: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 00000011901C: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000119020: BF870121
	v_add_f32_e32 v25, v25, v26                                // 000000119024: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 000000119028: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000011902C: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119030: BF870095
	.long 0xd71c0019                                           // 000000119034: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000119038: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000011903C: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000119040: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119048: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 00000011904C: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000119054: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119058: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 00000011905C: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 000000119064: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119068: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 00000011906C: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 000000119074: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 000000119078: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119080: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 000000119084: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 000000119088: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119090: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 000000119094: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 000000119098: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001190A0: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 0000001190A4: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 0000001190AC: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 0000001190B4: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001190C0: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 0000001190C4: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000001190CC: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 0000001190D8: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001190E0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001190E4: BE882002
	s_cbranch_execz 58342                                      // 0000001190E8: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3784>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 0000001190EC: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000001190F8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000119100: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000119104: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119108: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000011910C: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 000000119114: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 000000119120: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000119124: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 000000119128: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000011912C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 000000119134: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011913C: BF870121
	v_add_f32_e32 v18, v18, v25                                // 000000119140: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 000000119144: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 000000119148: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011914C: BF870095
	.long 0xd71c0012                                           // 000000119150: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 000000119154: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000119158: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000011915C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119164: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 000000119168: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000119174: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119178: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000011917C: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 000000119184: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119188: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 00000011918C: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 000000119194: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 000000119198: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001191A0: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 0000001191A4: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 0000001191A8: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001191B0: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 0000001191B4: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 0000001191B8: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001191C0: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 0000001191C4: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000001191CC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 0000001191D4: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001191E0: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 0000001191E4: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 0000001191EC: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000001191F8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000119200: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000119204: BE882003
	s_cbranch_execz 58273                                      // 000000119208: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3790>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 00000011920C: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000119218: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000119220: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000119224: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119228: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000011922C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000119234: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 000000119240: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119244: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 000000119248: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 000000119254: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 000000119258: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000011925C: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000119264: BF870293
	v_exp_f32_e32 v18, v18                                     // 000000119268: 7E244B12
	.long 0xd71c0012                                           // 00000011926C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000119270: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000119274: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000119278: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000011927C: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 000000119284: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119290: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 000000119294: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000119298: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001192A0: BF870291
	v_rcp_f32_e32 v20, v19                                     // 0000001192A4: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 0000001192A8: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001192B0: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 0000001192B4: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 0000001192B8: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 0000001192C0: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001192C4: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 0000001192C8: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 0000001192D0: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001192D4: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 0000001192D8: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 0000001192E0: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001192E8: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000001192EC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 0000001192F4: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 000000119300: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000119308: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000011930C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000119318: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000119320: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000119324: BE882004
	s_cbranch_execz 58204                                      // 000000119328: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x379c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 00000011932C: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000119338: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000119340: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000119344: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119348: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000011934C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000119354: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000119360: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000119364: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000119368: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000011936C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000119374: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011937C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000119380: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000119384: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000119388: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011938C: BF870095
	.long 0xd71c0012                                           // 000000119390: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000119394: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000119398: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000011939C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001193A4: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 0000001193A8: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000001193B4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001193B8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000001193BC: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000001193C4: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001193C8: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000001193CC: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000001193D4: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000001193D8: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001193E0: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 0000001193E4: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 0000001193E8: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001193F0: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 0000001193F4: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 0000001193F8: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119400: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 000000119404: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000011940C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 000000119414: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119420: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000119424: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000011942C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000119438: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000119440: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000119444: BE882005
	s_cbranch_execz 58135                                      // 000000119448: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37a8>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 00000011944C: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000119458: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000119460: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000119464: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119468: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000011946C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000119474: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000119480: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000119484: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000119488: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000011948C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000119494: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011949C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000001194A0: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000001194A4: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000001194A8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001194AC: BF870095
	.long 0xd71c0012                                           // 0000001194B0: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000001194B4: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001194B8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000001194BC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001194C4: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000001194C8: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 0000001194D0: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001194D8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000001194DC: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000001194E4: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001194E8: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000001194EC: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000001194F4: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000001194F8: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119500: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 000000119504: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 000000119508: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119510: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 000000119514: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 000000119518: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119520: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000119524: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000011952C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 000000119534: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119540: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000119544: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000011954C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000119558: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000119560: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000119564: BE882006
	s_cbranch_execz 58066                                      // 000000119568: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37b4>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 00000011956C: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000119578: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000119580: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000119584: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119588: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000011958C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000119594: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000001195A0: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001195A4: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000001195A8: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000001195AC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000001195B4: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001195BC: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000001195C0: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000001195C4: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000001195C8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001195CC: BF870095
	.long 0xd71c0012                                           // 0000001195D0: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000001195D4: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001195D8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000001195DC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001195E4: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 0000001195E8: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000001195F4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001195F8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000001195FC: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000119604: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119608: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000011960C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000119614: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000119618: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119620: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 000000119624: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 000000119628: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119630: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 000000119634: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 000000119638: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119640: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000119644: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000011964C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 000000119654: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119660: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000119664: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000011966C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000119678: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000119680: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000119684: BE882007
	s_cbranch_execz 57997                                      // 000000119688: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37c0>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 00000011968C: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000119698: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000001196A0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000001196A4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001196A8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000001196AC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000001196B4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000001196C0: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001196C4: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000001196C8: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000001196CC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000001196D4: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001196DC: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000001196E0: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000001196E4: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000001196E8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001196EC: BF870095
	.long 0xd71c0012                                           // 0000001196F0: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000001196F4: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001196F8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000001196FC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119704: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 000000119708: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000119714: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119718: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000011971C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000119724: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119728: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000011972C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000119734: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000119738: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119740: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 000000119744: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 000000119748: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119750: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 000000119754: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 000000119758: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119760: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000119764: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000011976C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 000000119774: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119780: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000119784: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000011978C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000119798: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001197A0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001197A4: BE882000
	s_cbranch_execz 57928                                      // 0000001197A8: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37cc>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 0000001197AC: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 0000001197B8: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 0000001197BC: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000001197C4: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000001197C8: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001197CC: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000001197D0: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000001197D8: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000001197E4: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001197E8: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000001197EC: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000001197F0: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000001197F8: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000119800: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000119804: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000119808: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000011980C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119810: BF870095
	.long 0xd71c0012                                           // 000000119814: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000119818: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000011981C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000119820: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119828: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 00000011982C: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000119834: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119838: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 00000011983C: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 000000119844: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119848: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 00000011984C: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 000000119854: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 000000119858: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119860: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 000000119864: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 000000119868: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119870: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 000000119874: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 000000119878: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119880: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 000000119884: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 00000011988C: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 000000119894: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001198A0: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 0000001198A4: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 0000001198AC: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 0000001198B8: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001198C0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000001198C4: BE882001
	s_cbranch_execz 57859                                      // 0000001198C8: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37d8>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 0000001198CC: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 0000001198D8: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 0000001198DC: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 0000001198E4: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000001198E8: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001198EC: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 0000001198F0: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000001198F8: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 000000119900: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000011990C: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000119910: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 000000119914: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 00000011991C: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000119920: BF870121
	v_add_f32_e32 v17, v17, v18                                // 000000119924: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 000000119928: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000011992C: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119930: BF870095
	.long 0xd71c0011                                           // 000000119934: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000119938: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000011993C: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000119940: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119948: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 00000011994C: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000119954: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119958: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 00000011995C: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 000000119964: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119968: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 00000011996C: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 000000119974: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 000000119978: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119980: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 000000119984: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 000000119988: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119990: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 000000119994: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 000000119998: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001199A0: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 0000001199A4: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 0000001199AC: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 0000001199B4: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001199C0: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 0000001199C4: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000001199CC: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 0000001199D8: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001199E0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000001199E4: BE882002
	s_cbranch_execz 57790                                      // 0000001199E8: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37e4>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 0000001199EC: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000001199F8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000119A00: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000119A04: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119A08: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000119A0C: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 000000119A14: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 000000119A20: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000119A24: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 000000119A28: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000119A2C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 000000119A34: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000119A3C: BF870121
	v_add_f32_e32 v10, v10, v17                                // 000000119A40: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 000000119A44: 7E221112
	v_exp_f32_e32 v10, v10                                     // 000000119A48: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119A4C: BF870095
	.long 0xd71c000a                                           // 000000119A50: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 000000119A54: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000119A58: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000119A5C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119A64: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 000000119A68: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000119A74: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119A78: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000119A7C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 000000119A84: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119A88: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 000000119A8C: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 000000119A94: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 000000119A98: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119AA0: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 000000119AA4: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 000000119AA8: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119AB0: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 000000119AB4: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 000000119AB8: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119AC0: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 000000119AC4: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000119ACC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 000000119AD4: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119AE0: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 000000119AE4: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 000000119AEC: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000119AF8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000119B00: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000119B04: BE882003
	s_cbranch_execz 57721                                      // 000000119B08: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37f0>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 000000119B0C: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000119B18: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000119B20: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000119B24: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119B28: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000119B2C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000119B34: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 000000119B40: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119B44: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 000000119B48: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 000000119B54: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 000000119B58: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000119B5C: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000119B64: BF870293
	v_exp_f32_e32 v10, v10                                     // 000000119B68: 7E144B0A
	.long 0xd71c000a                                           // 000000119B6C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000119B70: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000119B74: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000119B78: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000119B7C: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 000000119B84: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119B90: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 000000119B94: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000119B98: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000119BA0: BF870291
	v_rcp_f32_e32 v12, v11                                     // 000000119BA4: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 000000119BA8: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000119BB0: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 000000119BB4: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 000000119BB8: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 000000119BC0: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119BC4: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 000000119BC8: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 000000119BD0: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119BD4: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 000000119BD8: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 000000119BE0: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000119BE8: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000119BEC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 000000119BF4: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 000000119C00: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000119C08: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000119C0C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000119C18: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000119C20: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000119C24: BE882004
	s_cbranch_execz 57652                                      // 000000119C28: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37fc>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 000000119C2C: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000119C38: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000119C40: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000119C44: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119C48: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000119C4C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000119C54: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000119C60: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000119C64: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000119C68: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000119C6C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000119C74: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000119C7C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000119C80: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000119C84: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000119C88: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119C8C: BF870095
	.long 0xd71c000a                                           // 000000119C90: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000119C94: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000119C98: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000119C9C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119CA4: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 000000119CA8: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000119CB4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119CB8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000119CBC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000119CC4: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119CC8: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000119CCC: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000119CD4: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000119CD8: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119CE0: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 000000119CE4: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 000000119CE8: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119CF0: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 000000119CF4: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 000000119CF8: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119D00: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 000000119D04: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000119D0C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 000000119D14: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119D20: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000119D24: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000119D2C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000119D38: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000119D40: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000119D44: BE882005
	s_cbranch_execz 57583                                      // 000000119D48: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3808>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 000000119D4C: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000119D58: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000119D60: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000119D64: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119D68: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000119D6C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000119D74: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000119D80: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000119D84: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000119D88: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000119D8C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000119D94: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000119D9C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000119DA0: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000119DA4: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000119DA8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119DAC: BF870095
	.long 0xd71c000a                                           // 000000119DB0: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000119DB4: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000119DB8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000119DBC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119DC4: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000119DC8: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 000000119DD0: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119DD8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000119DDC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000119DE4: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119DE8: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000119DEC: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000119DF4: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000119DF8: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119E00: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000119E04: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 000000119E08: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119E10: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 000000119E14: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 000000119E18: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119E20: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000119E24: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000119E2C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 000000119E34: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119E40: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000119E44: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000119E4C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000119E58: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000119E60: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000119E64: BE882006
	s_cbranch_execz 57514                                      // 000000119E68: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3814>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 000000119E6C: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000119E78: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000119E80: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000119E84: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119E88: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000119E8C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000119E94: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000119EA0: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000119EA4: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000119EA8: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000119EAC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000119EB4: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000119EBC: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000119EC0: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000119EC4: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000119EC8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119ECC: BF870095
	.long 0xd71c000a                                           // 000000119ED0: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000119ED4: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000119ED8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000119EDC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119EE4: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 000000119EE8: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000119EF4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119EF8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000119EFC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000119F04: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119F08: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000119F0C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000119F14: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000119F18: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119F20: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000119F24: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000119F28: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119F30: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000119F34: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000119F38: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119F40: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000119F44: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000119F4C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 000000119F54: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119F60: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000119F64: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000119F6C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000119F78: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000119F80: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000119F84: BE882007
	s_cbranch_execz 57445                                      // 000000119F88: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3820>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 000000119F8C: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000119F98: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000119FA0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000119FA4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119FA8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000119FAC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000119FB4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000119FC0: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000119FC4: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000119FC8: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000119FCC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000119FD4: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000119FDC: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000119FE0: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000119FE4: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000119FE8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000119FEC: BF870095
	.long 0xd71c000a                                           // 000000119FF0: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000119FF4: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000119FF8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000119FFC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A004: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 00000011A008: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000011A014: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A018: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000011A01C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 00000011A024: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A028: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000011A02C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 00000011A034: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000011A038: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A040: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 00000011A044: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 00000011A048: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A050: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 00000011A054: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 00000011A058: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A060: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 00000011A064: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000011A06C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 00000011A074: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A080: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 00000011A084: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000011A08C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000011A098: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011A0A0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011A0A4: BE882000
	s_cbranch_execz 57376                                      // 00000011A0A8: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x382c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 00000011A0AC: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 00000011A0B8: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 00000011A0BC: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000011A0C4: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000011A0C8: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A0CC: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000011A0D0: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 00000011A0D8: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000011A0E4: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011A0E8: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000011A0EC: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000011A0F0: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 00000011A0F8: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011A100: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000011A104: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 00000011A108: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000011A10C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A110: BF870095
	.long 0xd71c000a                                           // 00000011A114: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000011A118: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000011A11C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000011A120: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A128: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 00000011A12C: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000011A134: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A138: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 00000011A13C: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 00000011A144: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A148: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 00000011A14C: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000011A154: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 00000011A158: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A160: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 00000011A164: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 00000011A168: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A170: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 00000011A174: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 00000011A178: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A180: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 00000011A184: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 00000011A18C: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 00000011A194: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A1A0: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 00000011A1A4: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000011A1AC: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 00000011A1B8: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011A1C0: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000011A1C4: BE802001
	s_cbranch_execz 57307                                      // 00000011A1C8: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3838>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 00000011A1CC: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000011A1D8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000011A1E0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000011A1E4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A1E8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000011A1EC: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 00000011A1F4: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 00000011A200: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011A204: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 00000011A208: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 00000011A20C: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000011A214: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011A21C: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 00000011A220: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 00000011A224: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 00000011A228: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A22C: BF870095
	.long 0xd71c0001                                           // 00000011A230: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 00000011A234: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000011A238: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000011A23C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A244: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 00000011A248: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000011A254: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A258: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000011A25C: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 00000011A264: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A268: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 00000011A26C: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 00000011A274: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 00000011A278: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A280: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 00000011A284: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 00000011A288: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A290: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 00000011A294: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 00000011A298: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A2A0: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 00000011A2A4: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000011A2AC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 00000011A2B4: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A2C0: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 00000011A2C4: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 00000011A2CC: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000011A2D8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000011A2E0: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000011A2E4: BE802002
	s_cbranch_execz 57238                                      // 00000011A2E8: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3844>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 00000011A2EC: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000011A2F8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000011A300: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000011A304: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A308: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000011A30C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000011A314: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 00000011A320: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011A324: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 00000011A328: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000011A32C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000011A334: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011A33C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000011A340: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 00000011A344: 7E041109
	v_exp_f32_e32 v1, v1                                       // 00000011A348: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A34C: BF870095
	.long 0xd71c0001                                           // 00000011A350: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000011A354: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000011A358: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000011A35C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A364: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 00000011A368: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000011A374: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A378: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000011A37C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000011A384: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A388: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 00000011A38C: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 00000011A394: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 00000011A398: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A3A0: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 00000011A3A4: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 00000011A3A8: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A3B0: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 00000011A3B4: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 00000011A3B8: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A3C0: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 00000011A3C4: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000011A3CC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 00000011A3D4: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A3E0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000011A3E4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000011A3EC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000011A3F8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000011A400: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000011A404: BE802003
	s_cbranch_execz 57169                                      // 00000011A408: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3850>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 00000011A40C: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000011A418: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000011A420: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000011A424: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A428: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000011A42C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000011A434: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000011A440: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011A444: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000011A448: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000011A44C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000011A454: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011A45C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000011A460: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000011A464: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000011A468: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A46C: BF870095
	.long 0xd71c0001                                           // 00000011A470: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000011A474: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000011A478: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000011A47C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A484: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 00000011A488: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000011A494: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A498: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000011A49C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000011A4A4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A4A8: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000011A4AC: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000011A4B4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000011A4B8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A4C0: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 00000011A4C4: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 00000011A4C8: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A4D0: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 00000011A4D4: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 00000011A4D8: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A4E0: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 00000011A4E4: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000011A4EC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 00000011A4F4: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A500: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000011A504: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000011A50C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000011A518: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000011A520: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000011A524: BE802004
	s_cbranch_execz 57100                                      // 00000011A528: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x385c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 00000011A52C: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000011A538: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000011A540: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000011A544: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A548: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000011A54C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000011A554: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000011A560: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011A564: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000011A568: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000011A56C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000011A574: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011A57C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000011A580: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000011A584: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000011A588: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A58C: BF870095
	.long 0xd71c0001                                           // 00000011A590: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000011A594: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000011A598: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000011A59C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A5A4: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 00000011A5A8: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 00000011A5B0: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A5B8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000011A5BC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000011A5C4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A5C8: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000011A5CC: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000011A5D4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000011A5D8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A5E0: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000011A5E4: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 00000011A5E8: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A5F0: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 00000011A5F4: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 00000011A5F8: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A600: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000011A604: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000011A60C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 00000011A614: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A620: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000011A624: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000011A62C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000011A638: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000011A640: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000011A644: BE802005
	s_cbranch_execz 57031                                      // 00000011A648: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3868>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 00000011A64C: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000011A658: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000011A660: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000011A664: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A668: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000011A66C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000011A674: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000011A680: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011A684: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000011A688: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000011A68C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000011A694: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011A69C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000011A6A0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000011A6A4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000011A6A8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A6AC: BF870095
	.long 0xd71c0001                                           // 00000011A6B0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000011A6B4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000011A6B8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000011A6BC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A6C4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 00000011A6C8: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000011A6D4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A6D8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000011A6DC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000011A6E4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A6E8: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000011A6EC: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000011A6F4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000011A6F8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A700: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000011A704: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000011A708: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A710: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000011A714: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000011A718: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A720: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000011A724: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000011A72C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 00000011A734: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A740: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000011A744: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000011A74C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000011A758: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000011A760: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000011A764: BE802006
	s_cbranch_execz 56962                                      // 00000011A768: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3874>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 00000011A76C: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000011A778: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000011A780: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000011A784: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A788: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000011A78C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000011A794: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000011A7A0: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011A7A4: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000011A7A8: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000011A7AC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000011A7B4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011A7BC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000011A7C0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000011A7C4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000011A7C8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A7CC: BF870095
	.long 0xd71c0001                                           // 00000011A7D0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000011A7D4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000011A7D8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000011A7DC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A7E4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 00000011A7E8: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000011A7F4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A7F8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000011A7FC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000011A804: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A808: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000011A80C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000011A814: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000011A818: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A820: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000011A824: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000011A828: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A830: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000011A834: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000011A838: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A840: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000011A844: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000011A84C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 00000011A854: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A860: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000011A864: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000011A86C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000011A878: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000011A880: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000011A884: BE802007
	s_cbranch_execz 56893                                      // 00000011A888: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi4ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3880>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 00000011A88C: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000011A898: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000011A8A0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000011A8A4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A8A8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000011A8AC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000011A8B4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000011A8C0: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011A8C4: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000011A8C8: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000011A8CC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000011A8D4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011A8DC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000011A8E0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000011A8E4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000011A8E8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A8EC: BF870095
	.long 0xd71c0001                                           // 00000011A8F0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000011A8F4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000011A8F8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000011A8FC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A904: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 00000011A908: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000011A914: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A918: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000011A91C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000011A924: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A928: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000011A92C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000011A934: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000011A938: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A940: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000011A944: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000011A948: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A950: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000011A954: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000011A958: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A960: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000011A964: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000011A96C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 00000011A974: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011A980: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000011A984: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000011A98C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000011A998: DC9601E0 007C0200
	s_nop 0                                                    // 00000011A9A0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000011A9A4: BFB60003
	s_endpgm                                                   // 00000011A9A8: BFB00000
		...

