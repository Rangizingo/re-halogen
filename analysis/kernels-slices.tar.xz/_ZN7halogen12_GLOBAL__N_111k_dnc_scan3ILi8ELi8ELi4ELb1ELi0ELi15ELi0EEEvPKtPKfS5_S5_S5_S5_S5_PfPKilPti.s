0000000000129100 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000129100: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 000000129104: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000012910C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 000000129114: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 000000129118: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000012911C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 000000129120: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000129128: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000012912C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 000000129130: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 000000129134: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000012913C: 84928214
	s_add_u32 s25, s16, s18                                    // 000000129140: 80191210
	s_addc_u32 s28, s17, s19                                   // 000000129144: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 000000129148: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000012914C: BF870009
	s_add_u32 s25, s25, s20                                    // 000000129150: 80191419
	s_addc_u32 s30, s28, s21                                   // 000000129154: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 000000129158: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000012915C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 000000129164: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000012916C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 000000129170: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 000000129174: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000129178: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000012917C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 000000129180: 821E191E
	.long 0xd7001f02                                           // 000000129184: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 000000129188: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000012918C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 000000129194: BE9E0080
	s_nop 0                                                    // 000000129198: BF800000
	s_nop 0                                                    // 00000012919C: BF800000
	s_nop 0                                                    // 0000001291A0: BF800000
	s_nop 0                                                    // 0000001291A4: BF800000
	s_nop 0                                                    // 0000001291A8: BF800000
	s_nop 0                                                    // 0000001291AC: BF800000
	s_nop 0                                                    // 0000001291B0: BF800000
	s_nop 0                                                    // 0000001291B4: BF800000
	s_nop 0                                                    // 0000001291B8: BF800000
	s_nop 0                                                    // 0000001291BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000001291C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000001291C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001291CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000001291D0: 300C1089
	.long 0xd7006a06                                           // 0000001291D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000001291D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001291DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000001291E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000001291E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000001291F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000001291F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000001291FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 000000129208: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000012920C: BF8903F7
	ds_store_b32 v6, v9                                        // 000000129210: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 000000129218: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000012921C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 000000129220: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 000000129224: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 00000012922C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 000000129234: 32040084
	s_mov_b32 s0, 0                                            // 000000129238: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000012923C: BF89FC07
	s_barrier                                                  // 000000129240: BFBD0000
	buffer_gl0_inv                                             // 000000129244: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000012924C: BF02801E
	s_cbranch_scc1 12                                          // 000000129250: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 000000129254: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000012925C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000129264: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 000000129268: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 000000129270: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 000000129274: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000129278: 916A007E
	s_cbranch_vccz 2                                           // 00000012927C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2600                                              // 000000129280: BFA00A28 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a24>
	v_lshlrev_b32_e32 v39, 2, v5                               // 000000129284: 304E0A82
	s_add_i32 s0, s30, 63                                      // 000000129288: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000012928C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 000000129294: 85218600
	s_add_u32 s34, s10, s24                                    // 000000129298: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000012929C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000001292A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000001292A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000001292AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000001292B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000001292B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000001292B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000001292BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000001292C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000001292C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000001292C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000001292D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000001292D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000001292DC: B00A0204
	.long 0xd7000b2c                                           // 0000001292E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000001292E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001292E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000001292EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000001292F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 000000129300: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 000000129304: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 000000129310: 3816500A
	.long 0xd7000a05                                           // 000000129314: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 000000129318: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012931C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 000000129320: D5207C06 00290001
	.long 0xd7000107                                           // 000000129328: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 00000012932C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000129330: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 000000129334: D5207C08 0006180D
	.long 0xd7000109                                           // 00000012933C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 000000129340: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 000000129344: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 00000012934C: 84848E02
	.long 0xd700010b                                           // 000000129350: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 000000129354: 02021606
	s_add_u32 s4, s14, s4                                      // 000000129358: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 00000012935C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 000000129364: 8205050F
	.long 0xd700010d                                           // 000000129368: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 00000012936C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000129370: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 000000129374: D5207C0E 00050005
	.long 0xd700010f                                           // 00000012937C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 000000129380: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 000000129388: D5207C10 00061880
	.long 0xd7000111                                           // 000000129390: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 000000129394: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012939C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000001293A0: D5207C12 00061880
	.long 0xd7000113                                           // 0000001293A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000001293AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000001293B4: D5207C14 00061880
	.long 0xd7000115                                           // 0000001293BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000001293C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001293C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000001293CC: D5207C16 00061880
	.long 0xd7000117                                           // 0000001293D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000001293D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000001293E0: D5207C18 00061880
	.long 0xd7000119                                           // 0000001293E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000001293EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001293F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000001293F8: D5207C1A 00061880
	.long 0xd700011b                                           // 000000129400: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 000000129404: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 00000012940C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 000000129414: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000129418: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 000000129420: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 000000129424: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 00000012942C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 000000129434: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 00000012943C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 000000129444: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 00000012944C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 000000129454: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 00000012945C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 000000129464: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 00000012946C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 000000129474: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 00000012947C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 000000129484: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 00000012948C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 000000129494: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 00000012949C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000001294A0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000001294A4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001294AC: BF870499
	s_add_i32 s6, s31, s1                                      // 0000001294B0: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 0000001294B4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001294B8: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 0000001294BC: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 0000001294C0: 84078605
	s_add_u32 s10, s8, s10                                     // 0000001294C4: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 0000001294C8: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 0000001294CC: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000001294D4: BE84206A
	s_cbranch_execz 77                                         // 0000001294D8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s7, v0                                   // 0000001294DC: 383A0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001294E0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000001294E4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000001294EC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001294F0: BF870091
	.long 0xd73c001d                                           // 0000001294F4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000001294F8: 02023A82
	.long 0xd700011d                                           // 0000001294FC: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 000000129500: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000129504: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 000000129508: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 000000129510: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000129518: BF890007
	v_sub_f32_e32 v30, s6, v29                                 // 00000012951C: 083C3A06
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 000000129520: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000012952C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 000000129530: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 00000012953C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 000000129540: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 00000012954C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000129550: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 000000129554: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 000000129560: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129564: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 000000129568: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 000000129570: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 000000129574: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 00000012957C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 000000129584: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 000000129588: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012958C: BF870193
	v_exp_f32_e32 v32, v32                                     // 000000129590: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 000000129594: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000129598: BF870296
	.long 0xd71c0020                                           // 00000012959C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000001295A0: 02024520
	.long 0xd71c001f                                           // 0000001295A4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000001295A8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001295AC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000001295B0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000001295B8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000001295BC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000001295C4: D5010020 00064080
	.long 0xd41e0001                                           // 0000001295CC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000001295D0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001295D8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000001295DC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000001295E8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000001295EC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000001295F4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 000000129600: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 000000129608: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 000000129610: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 000000129614: CA100108 1E1C0107
	s_mov_b32 s10, 0                                           // 00000012961C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000129620: BF89FC07
	s_barrier                                                  // 000000129624: BFBD0000
	buffer_gl0_inv                                             // 000000129628: E0AC0000 00000000
	s_branch 15                                                // 000000129630: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000129634: 8C7E047E
	.long 0xd700011d                                           // 000000129638: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 00000012963C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129644: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000129648: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 000000129650: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 000000129654: BF08B70A
	s_mov_b32 s10, s1                                          // 000000129658: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 00000012965C: BF89FC07
	s_barrier                                                  // 000000129660: BFBD0000
	buffer_gl0_inv                                             // 000000129664: E0AC0000 00000000
	s_cbranch_scc1 706                                         // 00000012966C: BFA202C2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 000000129670: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 000000129678: CA100128 21220126
	s_mov_b32 s11, 0                                           // 000000129680: BE8B0080
	s_nop 0                                                    // 000000129684: BF800000
	s_nop 0                                                    // 000000129688: BF800000
	s_nop 0                                                    // 00000012968C: BF800000
	s_nop 0                                                    // 000000129690: BF800000
	s_nop 0                                                    // 000000129694: BF800000
	s_nop 0                                                    // 000000129698: BF800000
	s_nop 0                                                    // 00000012969C: BF800000
	s_nop 0                                                    // 0000001296A0: BF800000
	s_nop 0                                                    // 0000001296A4: BF800000
	s_nop 0                                                    // 0000001296A8: BF800000
	s_nop 0                                                    // 0000001296AC: BF800000
	s_nop 0                                                    // 0000001296B0: BF800000
	s_nop 0                                                    // 0000001296B4: BF800000
	s_nop 0                                                    // 0000001296B8: BF800000
	s_nop 0                                                    // 0000001296BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000001296C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000001296C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000001296D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000001296D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001296DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000001296E0: D5207C20 00064080
	.long 0xd4490004                                           // 0000001296E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000001296EC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 0000001296F4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 0000001296F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000001296FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 000000129704: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000012970C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000129710: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000129714: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000129718: BF89FC07
	s_barrier                                                  // 00000012971C: BFBD0000
	buffer_gl0_inv                                             // 000000129720: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000129728: BE842000
	s_cbranch_execz 65473                                      // 00000012972C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 000000129730: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 000000129738: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v1 offset1:17                  // 000000129740: D8DC1100 23000001
	ds_load_2addr_b32 v[60:61], v1 offset0:34 offset1:51       // 000000129748: D8DC3322 3C000001
	ds_load_2addr_b32 v[64:65], v46 offset0:4 offset1:5        // 000000129750: D8DC0504 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:6 offset1:7        // 000000129758: D8DC0706 4200002E
	ds_load_2addr_b32 v[68:69], v1 offset0:68 offset1:85       // 000000129760: D8DC5544 44000001
	ds_load_2addr_b32 v[70:71], v1 offset0:102 offset1:119     // 000000129768: D8DC7766 46000001
	v_or3_b32 v62, s10, s7, v2                                 // 000000129770: D658003E 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129778: BF870091
	v_mad_u64_u32 v[62:63], null, v62, 48, s[2:3]              // 00000012977C: D6FE7C3E 0009613E
	.long 0xd73c003e                                           // 000000129784: D73C003E
	v_cndmask_b32_e32 v1, 9, v62, vcc_lo                       // 000000129788: 02027C89
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012978C: BF870001
	.long 0xd700013e                                           // 000000129790: D700013E
	v_cndmask_b32_e32 v1, v44, v62, vcc_lo                     // 000000129794: 02027D2C
	ds_load_2addr_b32 v[72:73], v1 offset0:170 offset1:187     // 000000129798: D8DCBBAA 48000001
	v_add_co_ci_u32_e64 v63, null, v45, v63, s1                // 0000001297A0: D5207C3F 00067F2D
	global_load_b32 v62, v[62:63], off                         // 0000001297A8: DC520000 3E7C003E
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001297B0: BF890067
	v_fma_f32 v31, -v31, v35, v62                              // 0000001297B4: D613001F 24FA471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001297BC: BF8700A1
	v_fma_f32 v31, -v32, v36, v31                              // 0000001297C0: D613001F 247E4920
	s_waitcnt lgkmcnt(5)                                       // 0000001297C8: BF89FC57
	v_fma_f32 v33, -v33, v60, v31                              // 0000001297CC: D6130021 247E7921
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 0000001297D4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[35:36], v46 offset0:10 offset1:11      // 0000001297DC: D8DC0B0A 2300002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 0000001297E4: D8DC9988 3E000001
	v_fma_f32 v33, -v34, v61, v33                              // 0000001297EC: D6130021 24867B22
	s_waitcnt lgkmcnt(5)                                       // 0000001297F4: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001297F8: BF870091
	v_fma_f32 v33, -v64, v68, v33                              // 0000001297FC: D6130021 24868940
	v_fma_f32 v33, -v65, v69, v33                              // 000000129804: D6130021 24868B41
	s_waitcnt lgkmcnt(4)                                       // 00000012980C: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129810: BF870001
	v_fma_f32 v66, -v66, v70, v33                              // 000000129814: D6130042 24868D42
	ds_load_2addr_b32 v[33:34], v46 offset0:12 offset1:13      // 00000012981C: D8DC0D0C 2100002E
	ds_load_2addr_b32 v[60:61], v46 offset0:14 offset1:15      // 000000129824: D8DC0F0E 3C00002E
	ds_load_2addr_b32 v[64:65], v1 offset0:204 offset1:221     // 00000012982C: D8DCDDCC 40000001
	ds_load_2addr_b32 v[68:69], v1 offset0:238 offset1:255     // 000000129834: D8DCFFEE 44000001
	v_fma_f32 v66, -v67, v71, v66                              // 00000012983C: D6130042 250A8F43
	s_waitcnt lgkmcnt(4)                                       // 000000129844: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129848: BF870091
	v_fma_f32 v31, -v31, v62, v66                              // 00000012984C: D613001F 250A7D1F
	v_fma_f32 v31, -v32, v63, v31                              // 000000129854: D613001F 247E7F20
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012985C: BF870001
	v_fma_f32 v35, -v35, v72, v31                              // 000000129860: D6130023 247E9123
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 000000129868: D8DC1110 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:18 offset1:19      // 000000129870: D8DC1312 3E00002E
	ds_load_2addr_b32 v[66:67], v48 offset0:16 offset1:33      // 000000129878: D8DC2110 42000030
	ds_load_2addr_b32 v[70:71], v48 offset0:50 offset1:67      // 000000129880: D8DC4332 46000030
	v_fma_f32 v35, -v36, v73, v35                              // 000000129888: D6130023 248E9324
	s_waitcnt lgkmcnt(5)                                       // 000000129890: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129894: BF870091
	v_fma_f32 v33, -v33, v64, v35                              // 000000129898: D6130021 248E8121
	v_fma_f32 v33, -v34, v65, v33                              // 0000001298A0: D6130021 24868322
	s_waitcnt lgkmcnt(4)                                       // 0000001298A8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001298AC: BF870001
	v_fma_f32 v60, -v60, v68, v33                              // 0000001298B0: D613003C 2486893C
	ds_load_2addr_b32 v[33:34], v46 offset0:20 offset1:21      // 0000001298B8: D8DC1514 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:22 offset1:23      // 0000001298C0: D8DC1716 2300002E
	ds_load_2addr_b32 v[64:65], v48 offset0:84 offset1:101     // 0000001298C8: D8DC6554 40000030
	ds_load_2addr_b32 v[72:73], v48 offset0:118 offset1:135    // 0000001298D0: D8DC8776 48000030
	v_fma_f32 v60, -v61, v69, v60                              // 0000001298D8: D613003C 24F28B3D
	s_waitcnt lgkmcnt(5)                                       // 0000001298E0: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001298E4: BF870091
	v_fma_f32 v31, -v31, v66, v60                              // 0000001298E8: D613001F 24F2851F
	v_fma_f32 v31, -v32, v67, v31                              // 0000001298F0: D613001F 247E8720
	s_waitcnt lgkmcnt(4)                                       // 0000001298F8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001298FC: BF870001
	v_fma_f32 v62, -v62, v70, v31                              // 000000129900: D613003E 247E8D3E
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 000000129908: D8DC1918 1F00002E
	ds_load_2addr_b32 v[60:61], v46 offset0:26 offset1:27      // 000000129910: D8DC1B1A 3C00002E
	ds_load_2addr_b32 v[66:67], v48 offset0:152 offset1:169    // 000000129918: D8DCA998 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:186 offset1:203    // 000000129920: D8DCCBBA 44000030
	v_fma_f32 v62, -v63, v71, v62                              // 000000129928: D613003E 24FA8F3F
	s_waitcnt lgkmcnt(5)                                       // 000000129930: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129934: BF870091
	v_fma_f32 v33, -v33, v64, v62                              // 000000129938: D6130021 24FA8121
	v_fma_f32 v33, -v34, v65, v33                              // 000000129940: D6130021 24868322
	s_waitcnt lgkmcnt(4)                                       // 000000129948: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012994C: BF870001
	v_fma_f32 v35, -v35, v72, v33                              // 000000129950: D6130023 24869123
	ds_load_2addr_b32 v[33:34], v46 offset0:28 offset1:29      // 000000129958: D8DC1D1C 2100002E
	ds_load_2addr_b32 v[62:63], v46 offset0:30 offset1:31      // 000000129960: D8DC1F1E 3E00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:220 offset1:237    // 000000129968: D8DCEDDC 40000030
	ds_load_2addr_b32 v[70:71], v49 offset0:126 offset1:143    // 000000129970: D8DC8F7E 46000031
	v_fma_f32 v35, -v36, v73, v35                              // 000000129978: D6130023 248E9324
	s_waitcnt lgkmcnt(5)                                       // 000000129980: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129984: BF870091
	v_fma_f32 v31, -v31, v66, v35                              // 000000129988: D613001F 248E851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000129990: D613001F 247E8720
	s_waitcnt lgkmcnt(4)                                       // 000000129998: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012999C: BF870001
	v_fma_f32 v60, -v60, v68, v31                              // 0000001299A0: D613003C 247E893C
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 0000001299A8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[35:36], v46 offset0:34 offset1:35      // 0000001299B0: D8DC2322 2300002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 0000001299B8: D8DC3120 42000032
	ds_load_2addr_b32 v[72:73], v50 offset0:66 offset1:83      // 0000001299C0: D8DC5342 48000032
	v_fma_f32 v60, -v61, v69, v60                              // 0000001299C8: D613003C 24F28B3D
	s_waitcnt lgkmcnt(5)                                       // 0000001299D0: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001299D4: BF870091
	v_fma_f32 v33, -v33, v64, v60                              // 0000001299D8: D6130021 24F28121
	v_fma_f32 v33, -v34, v65, v33                              // 0000001299E0: D6130021 24868322
	s_waitcnt lgkmcnt(4)                                       // 0000001299E8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001299EC: BF870001
	v_fma_f32 v62, -v62, v70, v33                              // 0000001299F0: D613003E 24868D3E
	ds_load_2addr_b32 v[33:34], v46 offset0:36 offset1:37      // 0000001299F8: D8DC2524 2100002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 000000129A00: D8DC2726 3C00002E
	ds_load_2addr_b32 v[64:65], v50 offset0:100 offset1:117    // 000000129A08: D8DC7564 40000032
	ds_load_2addr_b32 v[68:69], v50 offset0:134 offset1:151    // 000000129A10: D8DC9786 44000032
	v_fma_f32 v62, -v63, v71, v62                              // 000000129A18: D613003E 24FA8F3F
	s_waitcnt lgkmcnt(5)                                       // 000000129A20: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129A24: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 000000129A28: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000129A30: D613001F 247E8720
	s_waitcnt lgkmcnt(4)                                       // 000000129A38: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129A3C: BF870001
	v_fma_f32 v35, -v35, v72, v31                              // 000000129A40: D6130023 247E9123
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 000000129A48: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 000000129A50: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:168 offset1:185    // 000000129A58: D8DCB9A8 42000032
	ds_load_2addr_b32 v[70:71], v50 offset0:202 offset1:219    // 000000129A60: D8DCDBCA 46000032
	v_fma_f32 v35, -v36, v73, v35                              // 000000129A68: D6130023 248E9324
	s_waitcnt lgkmcnt(5)                                       // 000000129A70: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129A74: BF870091
	v_fma_f32 v33, -v33, v64, v35                              // 000000129A78: D6130021 248E8121
	v_fma_f32 v33, -v34, v65, v33                              // 000000129A80: D6130021 24868322
	s_waitcnt lgkmcnt(4)                                       // 000000129A88: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129A8C: BF870001
	v_fma_f32 v60, -v60, v68, v33                              // 000000129A90: D613003C 2486893C
	ds_load_2addr_b32 v[33:34], v46 offset0:44 offset1:45      // 000000129A98: D8DC2D2C 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:46 offset1:47      // 000000129AA0: D8DC2F2E 2300002E
	ds_load_2addr_b32 v[64:65], v50 offset0:236 offset1:253    // 000000129AA8: D8DCFDEC 40000032
	ds_load_2addr_b32 v[72:73], v51 offset0:14 offset1:31      // 000000129AB0: D8DC1F0E 48000033
	v_fma_f32 v60, -v61, v69, v60                              // 000000129AB8: D613003C 24F28B3D
	s_waitcnt lgkmcnt(5)                                       // 000000129AC0: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129AC4: BF870091
	v_fma_f32 v31, -v31, v66, v60                              // 000000129AC8: D613001F 24F2851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000129AD0: D613001F 247E8720
	s_waitcnt lgkmcnt(4)                                       // 000000129AD8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129ADC: BF870001
	v_fma_f32 v62, -v62, v70, v31                              // 000000129AE0: D613003E 247E8D3E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 000000129AE8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[60:61], v46 offset0:50 offset1:51      // 000000129AF0: D8DC3332 3C00002E
	ds_load_2addr_b32 v[66:67], v51 offset0:48 offset1:65      // 000000129AF8: D8DC4130 42000033
	ds_load_2addr_b32 v[68:69], v51 offset0:82 offset1:99      // 000000129B00: D8DC6352 44000033
	v_fma_f32 v62, -v63, v71, v62                              // 000000129B08: D613003E 24FA8F3F
	s_waitcnt lgkmcnt(5)                                       // 000000129B10: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129B14: BF870091
	v_fma_f32 v33, -v33, v64, v62                              // 000000129B18: D6130021 24FA8121
	v_fma_f32 v33, -v34, v65, v33                              // 000000129B20: D6130021 24868322
	s_waitcnt lgkmcnt(4)                                       // 000000129B28: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129B2C: BF870001
	v_fma_f32 v35, -v35, v72, v33                              // 000000129B30: D6130023 24869123
	ds_load_2addr_b32 v[33:34], v46 offset0:52 offset1:53      // 000000129B38: D8DC3534 2100002E
	ds_load_2addr_b32 v[62:63], v46 offset0:54 offset1:55      // 000000129B40: D8DC3736 3E00002E
	ds_load_2addr_b32 v[64:65], v51 offset0:116 offset1:133    // 000000129B48: D8DC8574 40000033
	ds_load_2addr_b32 v[70:71], v51 offset0:150 offset1:167    // 000000129B50: D8DCA796 46000033
	v_fma_f32 v35, -v36, v73, v35                              // 000000129B58: D6130023 248E9324
	s_waitcnt lgkmcnt(5)                                       // 000000129B60: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129B64: BF870091
	v_fma_f32 v31, -v31, v66, v35                              // 000000129B68: D613001F 248E851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000129B70: D613001F 247E8720
	s_waitcnt lgkmcnt(4)                                       // 000000129B78: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129B7C: BF870001
	v_fma_f32 v60, -v60, v68, v31                              // 000000129B80: D613003C 247E893C
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 000000129B88: D8DC3938 1F00002E
	ds_load_2addr_b32 v[35:36], v46 offset0:58 offset1:59      // 000000129B90: D8DC3B3A 2300002E
	ds_load_2addr_b32 v[66:67], v51 offset0:184 offset1:201    // 000000129B98: D8DCC9B8 42000033
	ds_load_2addr_b32 v[72:73], v51 offset0:218 offset1:235    // 000000129BA0: D8DCEBDA 48000033
	v_fma_f32 v60, -v61, v69, v60                              // 000000129BA8: D613003C 24F28B3D
	s_waitcnt lgkmcnt(5)                                       // 000000129BB0: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129BB4: BF870091
	v_fma_f32 v33, -v33, v64, v60                              // 000000129BB8: D6130021 24F28121
	v_fma_f32 v33, -v34, v65, v33                              // 000000129BC0: D6130021 24868322
	s_waitcnt lgkmcnt(4)                                       // 000000129BC8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129BCC: BF870001
	v_fma_f32 v62, -v62, v70, v33                              // 000000129BD0: D613003E 24868D3E
	ds_load_2addr_b32 v[33:34], v46 offset0:60 offset1:61      // 000000129BD8: D8DC3D3C 2100002E
	ds_load_2addr_b32 v[60:61], v46 offset0:62 offset1:63      // 000000129BE0: D8DC3F3E 3C00002E
	ds_load_2addr_b32 v[64:65], v52 offset0:124 offset1:141    // 000000129BE8: D8DC8D7C 40000034
	ds_load_2addr_b32 v[68:69], v53 offset0:30 offset1:47      // 000000129BF0: D8DC2F1E 44000035
	v_fma_f32 v62, -v63, v71, v62                              // 000000129BF8: D613003E 24FA8F3F
	s_waitcnt lgkmcnt(5)                                       // 000000129C00: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129C04: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 000000129C08: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000129C10: D613001F 247E8720
	s_waitcnt lgkmcnt(4)                                       // 000000129C18: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129C1C: BF870001
	v_fma_f32 v35, -v35, v72, v31                              // 000000129C20: D6130023 247E9123
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 000000129C28: D8DC4140 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:66 offset1:67      // 000000129C30: D8DC4342 3E00002E
	ds_load_2addr_b32 v[66:67], v53 offset0:64 offset1:81      // 000000129C38: D8DC5140 42000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 000000129C40: D8DC7362 46000035
	v_fma_f32 v35, -v36, v73, v35                              // 000000129C48: D6130023 248E9324
	s_waitcnt lgkmcnt(5)                                       // 000000129C50: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129C54: BF870091
	v_fma_f32 v33, -v33, v64, v35                              // 000000129C58: D6130021 248E8121
	v_fma_f32 v33, -v34, v65, v33                              // 000000129C60: D6130021 24868322
	s_waitcnt lgkmcnt(4)                                       // 000000129C68: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129C6C: BF870001
	v_fma_f32 v60, -v60, v68, v33                              // 000000129C70: D613003C 2486893C
	ds_load_2addr_b32 v[33:34], v46 offset0:68 offset1:69      // 000000129C78: D8DC4544 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:70 offset1:71      // 000000129C80: D8DC4746 2300002E
	ds_load_2addr_b32 v[64:65], v53 offset0:132 offset1:149    // 000000129C88: D8DC9584 40000035
	ds_load_2addr_b32 v[72:73], v53 offset0:166 offset1:183    // 000000129C90: D8DCB7A6 48000035
	v_fma_f32 v60, -v61, v69, v60                              // 000000129C98: D613003C 24F28B3D
	s_waitcnt lgkmcnt(5)                                       // 000000129CA0: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129CA4: BF870091
	v_fma_f32 v31, -v31, v66, v60                              // 000000129CA8: D613001F 24F2851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000129CB0: D613001F 247E8720
	s_waitcnt lgkmcnt(4)                                       // 000000129CB8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129CBC: BF870001
	v_fma_f32 v62, -v62, v70, v31                              // 000000129CC0: D613003E 247E8D3E
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 000000129CC8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[60:61], v46 offset0:74 offset1:75      // 000000129CD0: D8DC4B4A 3C00002E
	ds_load_2addr_b32 v[66:67], v53 offset0:200 offset1:217    // 000000129CD8: D8DCD9C8 42000035
	ds_load_2addr_b32 v[68:69], v53 offset0:234 offset1:251    // 000000129CE0: D8DCFBEA 44000035
	v_fma_f32 v62, -v63, v71, v62                              // 000000129CE8: D613003E 24FA8F3F
	s_waitcnt lgkmcnt(5)                                       // 000000129CF0: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129CF4: BF870091
	v_fma_f32 v33, -v33, v64, v62                              // 000000129CF8: D6130021 24FA8121
	v_fma_f32 v33, -v34, v65, v33                              // 000000129D00: D6130021 24868322
	s_waitcnt lgkmcnt(4)                                       // 000000129D08: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129D0C: BF870001
	v_fma_f32 v35, -v35, v72, v33                              // 000000129D10: D6130023 24869123
	ds_load_2addr_b32 v[33:34], v46 offset0:76 offset1:77      // 000000129D18: D8DC4D4C 2100002E
	ds_load_2addr_b32 v[62:63], v46 offset0:78 offset1:79      // 000000129D20: D8DC4F4E 3E00002E
	ds_load_2addr_b32 v[64:65], v54 offset0:12 offset1:29      // 000000129D28: D8DC1D0C 40000036
	ds_load_2addr_b32 v[70:71], v54 offset0:46 offset1:63      // 000000129D30: D8DC3F2E 46000036
	v_fma_f32 v35, -v36, v73, v35                              // 000000129D38: D6130023 248E9324
	s_waitcnt lgkmcnt(5)                                       // 000000129D40: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129D44: BF870091
	v_fma_f32 v31, -v31, v66, v35                              // 000000129D48: D613001F 248E851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000129D50: D613001F 247E8720
	s_waitcnt lgkmcnt(4)                                       // 000000129D58: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129D5C: BF870001
	v_fma_f32 v60, -v60, v68, v31                              // 000000129D60: D613003C 247E893C
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 000000129D68: D8DC5150 1F00002E
	ds_load_2addr_b32 v[35:36], v46 offset0:82 offset1:83      // 000000129D70: D8DC5352 2300002E
	ds_load_2addr_b32 v[66:67], v54 offset0:80 offset1:97      // 000000129D78: D8DC6150 42000036
	ds_load_2addr_b32 v[72:73], v54 offset0:114 offset1:131    // 000000129D80: D8DC8372 48000036
	v_fma_f32 v60, -v61, v69, v60                              // 000000129D88: D613003C 24F28B3D
	s_waitcnt lgkmcnt(5)                                       // 000000129D90: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129D94: BF870091
	v_fma_f32 v33, -v33, v64, v60                              // 000000129D98: D6130021 24F28121
	v_fma_f32 v33, -v34, v65, v33                              // 000000129DA0: D6130021 24868322
	s_waitcnt lgkmcnt(4)                                       // 000000129DA8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129DAC: BF870001
	v_fma_f32 v62, -v62, v70, v33                              // 000000129DB0: D613003E 24868D3E
	ds_load_2addr_b32 v[33:34], v46 offset0:84 offset1:85      // 000000129DB8: D8DC5554 2100002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 000000129DC0: D8DC5756 3C00002E
	ds_load_2addr_b32 v[64:65], v54 offset0:148 offset1:165    // 000000129DC8: D8DCA594 40000036
	ds_load_2addr_b32 v[68:69], v54 offset0:182 offset1:199    // 000000129DD0: D8DCC7B6 44000036
	v_fma_f32 v62, -v63, v71, v62                              // 000000129DD8: D613003E 24FA8F3F
	s_waitcnt lgkmcnt(5)                                       // 000000129DE0: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129DE4: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 000000129DE8: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000129DF0: D613001F 247E8720
	s_waitcnt lgkmcnt(4)                                       // 000000129DF8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129DFC: BF870001
	v_fma_f32 v35, -v35, v72, v31                              // 000000129E00: D6130023 247E9123
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 000000129E08: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 000000129E10: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[66:67], v54 offset0:216 offset1:233    // 000000129E18: D8DCE9D8 42000036
	ds_load_2addr_b32 v[70:71], v55 offset0:122 offset1:139    // 000000129E20: D8DC8B7A 46000037
	v_fma_f32 v35, -v36, v73, v35                              // 000000129E28: D6130023 248E9324
	s_waitcnt lgkmcnt(5)                                       // 000000129E30: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129E34: BF870091
	v_fma_f32 v33, -v33, v64, v35                              // 000000129E38: D6130021 248E8121
	v_fma_f32 v33, -v34, v65, v33                              // 000000129E40: D6130021 24868322
	s_waitcnt lgkmcnt(4)                                       // 000000129E48: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129E4C: BF870001
	v_fma_f32 v60, -v60, v68, v33                              // 000000129E50: D613003C 2486893C
	ds_load_2addr_b32 v[33:34], v46 offset0:92 offset1:93      // 000000129E58: D8DC5D5C 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:94 offset1:95      // 000000129E60: D8DC5F5E 2300002E
	ds_load_2addr_b32 v[64:65], v56 offset0:28 offset1:45      // 000000129E68: D8DC2D1C 40000038
	ds_load_2addr_b32 v[72:73], v56 offset0:62 offset1:79      // 000000129E70: D8DC4F3E 48000038
	v_fma_f32 v60, -v61, v69, v60                              // 000000129E78: D613003C 24F28B3D
	s_waitcnt lgkmcnt(5)                                       // 000000129E80: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129E84: BF870091
	v_fma_f32 v31, -v31, v66, v60                              // 000000129E88: D613001F 24F2851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000129E90: D613001F 247E8720
	s_waitcnt lgkmcnt(4)                                       // 000000129E98: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129E9C: BF870001
	v_fma_f32 v62, -v62, v70, v31                              // 000000129EA0: D613003E 247E8D3E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 000000129EA8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[60:61], v46 offset0:98 offset1:99      // 000000129EB0: D8DC6362 3C00002E
	ds_load_2addr_b32 v[66:67], v56 offset0:96 offset1:113     // 000000129EB8: D8DC7160 42000038
	ds_load_2addr_b32 v[68:69], v56 offset0:130 offset1:147    // 000000129EC0: D8DC9382 44000038
	v_fma_f32 v62, -v63, v71, v62                              // 000000129EC8: D613003E 24FA8F3F
	s_waitcnt lgkmcnt(5)                                       // 000000129ED0: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129ED4: BF870091
	v_fma_f32 v33, -v33, v64, v62                              // 000000129ED8: D6130021 24FA8121
	v_fma_f32 v33, -v34, v65, v33                              // 000000129EE0: D6130021 24868322
	s_waitcnt lgkmcnt(4)                                       // 000000129EE8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129EEC: BF870001
	v_fma_f32 v35, -v35, v72, v33                              // 000000129EF0: D6130023 24869123
	ds_load_2addr_b32 v[33:34], v46 offset0:100 offset1:101    // 000000129EF8: D8DC6564 2100002E
	ds_load_2addr_b32 v[62:63], v46 offset0:102 offset1:103    // 000000129F00: D8DC6766 3E00002E
	ds_load_2addr_b32 v[64:65], v56 offset0:164 offset1:181    // 000000129F08: D8DCB5A4 40000038
	ds_load_2addr_b32 v[70:71], v56 offset0:198 offset1:215    // 000000129F10: D8DCD7C6 46000038
	v_fma_f32 v35, -v36, v73, v35                              // 000000129F18: D6130023 248E9324
	s_waitcnt lgkmcnt(5)                                       // 000000129F20: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129F24: BF870091
	v_fma_f32 v31, -v31, v66, v35                              // 000000129F28: D613001F 248E851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000129F30: D613001F 247E8720
	s_waitcnt lgkmcnt(4)                                       // 000000129F38: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129F3C: BF870001
	v_fma_f32 v60, -v60, v68, v31                              // 000000129F40: D613003C 247E893C
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 000000129F48: D8DC6968 1F00002E
	ds_load_2addr_b32 v[35:36], v46 offset0:106 offset1:107    // 000000129F50: D8DC6B6A 2300002E
	ds_load_2addr_b32 v[66:67], v56 offset0:232 offset1:249    // 000000129F58: D8DCF9E8 42000038
	ds_load_2addr_b32 v[72:73], v57 offset0:10 offset1:27      // 000000129F60: D8DC1B0A 48000039
	v_fma_f32 v60, -v61, v69, v60                              // 000000129F68: D613003C 24F28B3D
	s_waitcnt lgkmcnt(5)                                       // 000000129F70: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129F74: BF870091
	v_fma_f32 v33, -v33, v64, v60                              // 000000129F78: D6130021 24F28121
	v_fma_f32 v33, -v34, v65, v33                              // 000000129F80: D6130021 24868322
	s_waitcnt lgkmcnt(4)                                       // 000000129F88: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129F8C: BF870001
	v_fma_f32 v62, -v62, v70, v33                              // 000000129F90: D613003E 24868D3E
	ds_load_2addr_b32 v[33:34], v46 offset0:108 offset1:109    // 000000129F98: D8DC6D6C 2100002E
	ds_load_2addr_b32 v[60:61], v46 offset0:110 offset1:111    // 000000129FA0: D8DC6F6E 3C00002E
	ds_load_2addr_b32 v[64:65], v57 offset0:44 offset1:61      // 000000129FA8: D8DC3D2C 40000039
	ds_load_2addr_b32 v[68:69], v57 offset0:78 offset1:95      // 000000129FB0: D8DC5F4E 44000039
	v_fma_f32 v62, -v63, v71, v62                              // 000000129FB8: D613003E 24FA8F3F
	s_waitcnt lgkmcnt(5)                                       // 000000129FC0: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129FC4: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 000000129FC8: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000129FD0: D613001F 247E8720
	s_waitcnt lgkmcnt(4)                                       // 000000129FD8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000129FDC: BF870001
	v_fma_f32 v35, -v35, v72, v31                              // 000000129FE0: D6130023 247E9123
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 000000129FE8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:114 offset1:115    // 000000129FF0: D8DC7372 3E00002E
	ds_load_2addr_b32 v[66:67], v57 offset0:112 offset1:129    // 000000129FF8: D8DC8170 42000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 00000012A000: D8DCA392 46000039
	v_fma_f32 v35, -v36, v73, v35                              // 00000012A008: D6130023 248E9324
	s_waitcnt lgkmcnt(5)                                       // 00000012A010: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A014: BF870091
	v_fma_f32 v33, -v33, v64, v35                              // 00000012A018: D6130021 248E8121
	v_fma_f32 v33, -v34, v65, v33                              // 00000012A020: D6130021 24868322
	s_waitcnt lgkmcnt(4)                                       // 00000012A028: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A02C: BF870001
	v_fma_f32 v60, -v60, v68, v33                              // 00000012A030: D613003C 2486893C
	ds_load_2addr_b32 v[33:34], v46 offset0:116 offset1:117    // 00000012A038: D8DC7574 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:118 offset1:119    // 00000012A040: D8DC7776 2300002E
	ds_load_2addr_b32 v[64:65], v57 offset0:180 offset1:197    // 00000012A048: D8DCC5B4 40000039
	ds_load_2addr_b32 v[72:73], v57 offset0:214 offset1:231    // 00000012A050: D8DCE7D6 48000039
	v_fma_f32 v60, -v61, v69, v60                              // 00000012A058: D613003C 24F28B3D
	s_waitcnt lgkmcnt(5)                                       // 00000012A060: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A064: BF870091
	v_fma_f32 v31, -v31, v66, v60                              // 00000012A068: D613001F 24F2851F
	v_fma_f32 v31, -v32, v67, v31                              // 00000012A070: D613001F 247E8720
	s_waitcnt lgkmcnt(4)                                       // 00000012A078: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A07C: BF870001
	v_fma_f32 v62, -v62, v70, v31                              // 00000012A080: D613003E 247E8D3E
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 00000012A088: D8DC7978 1F00002E
	ds_load_2addr_b32 v[60:61], v46 offset0:122 offset1:123    // 00000012A090: D8DC7B7A 3C00002E
	ds_load_2addr_b32 v[66:67], v58 offset0:120 offset1:137    // 00000012A098: D8DC8978 4200003A
	ds_load_2addr_b32 v[68:69], v59 offset0:26 offset1:43      // 00000012A0A0: D8DC2B1A 4400003B
	v_fma_f32 v62, -v63, v71, v62                              // 00000012A0A8: D613003E 24FA8F3F
	s_waitcnt lgkmcnt(5)                                       // 00000012A0B0: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A0B4: BF870091
	v_fma_f32 v33, -v33, v64, v62                              // 00000012A0B8: D6130021 24FA8121
	v_fma_f32 v33, -v34, v65, v33                              // 00000012A0C0: D6130021 24868322
	s_waitcnt lgkmcnt(4)                                       // 00000012A0C8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A0CC: BF870001
	v_fma_f32 v35, -v35, v72, v33                              // 00000012A0D0: D6130023 24869123
	ds_load_2addr_b32 v[33:34], v46 offset0:124 offset1:125    // 00000012A0D8: D8DC7D7C 2100002E
	ds_load_2addr_b32 v[62:63], v46 offset0:126 offset1:127    // 00000012A0E0: D8DC7F7E 3E00002E
	ds_load_2addr_b32 v[64:65], v59 offset0:60 offset1:77      // 00000012A0E8: D8DC4D3C 4000003B
	ds_load_2addr_b32 v[70:71], v59 offset0:94 offset1:111     // 00000012A0F0: D8DC6F5E 4600003B
	v_fma_f32 v35, -v36, v73, v35                              // 00000012A0F8: D6130023 248E9324
	s_waitcnt lgkmcnt(5)                                       // 00000012A100: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A104: BF870091
	v_fma_f32 v31, -v31, v66, v35                              // 00000012A108: D613001F 248E851F
	v_fma_f32 v31, -v32, v67, v31                              // 00000012A110: D613001F 247E8720
	s_waitcnt lgkmcnt(4)                                       // 00000012A118: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A11C: BF870091
	v_fma_f32 v31, -v60, v68, v31                              // 00000012A120: D613001F 247E893C
	v_fma_f32 v31, -v61, v69, v31                              // 00000012A128: D613001F 247E8B3D
	s_waitcnt lgkmcnt(1)                                       // 00000012A130: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A134: BF870091
	v_fma_f32 v31, -v33, v64, v31                              // 00000012A138: D613001F 247E8121
	v_fma_f32 v31, -v34, v65, v31                              // 00000012A140: D613001F 247E8322
	s_waitcnt lgkmcnt(0)                                       // 00000012A148: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012A14C: BF870121
	v_fma_f32 v33, -v62, v70, v31                              // 00000012A150: D6130021 247E8D3E
	v_mad_u64_u32 v[31:32], null, 0x44, s10, v[4:5]            // 00000012A158: D6FE7C1F 041014FF 00000044
	v_fma_f32 v32, -v63, v71, v33                              // 00000012A164: D6130020 24868F3F
	ds_store_b32 v31, v32                                      // 00000012A16C: D8340000 0000201F
	s_branch 64815                                             // 00000012A174: BFA0FD2F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_mov_b32_e32 v30, v14                                     // 00000012A178: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 00000012A17C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 00000012A184: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 00000012A188: 7E46032B
	s_mov_b32 s10, 0                                           // 00000012A18C: BE8A0080
	s_branch 21                                                // 00000012A190: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000012A194: 8C7E0B7E
	.long 0xd700011f                                           // 00000012A198: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 00000012A19C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A1A4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000012A1A8: D5207C20 00064080
	.long 0xd700011d                                           // 00000012A1B0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 00000012A1B4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 00000012A1BC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012A1C0: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000012A1C8: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000012A1CC: BF08B70A
	s_mov_b32 s10, s1                                          // 00000012A1D0: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 00000012A1D4: BC7C0000
	s_barrier                                                  // 00000012A1D8: BFBD0000
	buffer_gl0_inv                                             // 00000012A1DC: E0AC0000 00000000
	s_cbranch_scc1 598                                         // 00000012A1E4: BFA20256 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_delay_alu instid0(VALU_DEP_2)                            // 00000012A1E8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 00000012A1EC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 00000012A1F4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 00000012A1F8: 7E780326
	s_mov_b32 s11, 0                                           // 00000012A1FC: BE8B0080
	global_load_b32 v61, v[33:34], off                         // 00000012A200: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 00000012A208: 4A7878FF 00000080
	.long 0xd7000121                                           // 00000012A210: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 00000012A214: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012A21C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 00000012A220: D5207C22 00064480
	.long 0xd4490004                                           // 00000012A228: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 00000012A22C: 020278FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000012A234: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000012A238: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 00000012A23C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 00000012A244: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000012A24C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000012A250: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000012A254: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000012A258: BF89FC07
	s_barrier                                                  // 00000012A25C: BFBD0000
	buffer_gl0_inv                                             // 00000012A260: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 00000012A268: BE8B2000
	s_cbranch_execz 65481                                      // 00000012A26C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s10, v2                                  // 00000012A270: 3842040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A274: BF870091
	v_or_b32_e32 v36, s7, v33                                  // 00000012A278: 38484207
	.long 0xd4440001                                           // 00000012A27C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 00000012A280: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 00000012A284: 8B7E017E
	s_cbranch_execz 65474                                      // 00000012A288: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 00000012A28C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 00000012A294: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 00000012A29C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 00000012A2A4: D8DC3322 42000001
	s_mov_b32 s12, 0                                           // 00000012A2AC: BE8C0080
	s_waitcnt lgkmcnt(2)                                       // 00000012A2B0: BF89FC27
	v_fma_f32 v68, v60, v62, 0                                 // 00000012A2B4: D6130044 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A2BC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A2C0: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A2C4: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A2C8: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A2CC: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A2D0: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:4 offset1:5        // 00000012A2D4: D8DC0504 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:68 offset1:85       // 00000012A2DC: D8DC5544 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:6 offset1:7        // 00000012A2E4: D8DC0706 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:102 offset1:119     // 00000012A2EC: D8DC7766 42000001
	s_waitcnt lgkmcnt(2)                                       // 00000012A2F4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A2F8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A2FC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A300: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A304: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A308: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A30C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A310: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:8 offset1:9        // 00000012A314: D8DC0908 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 00000012A31C: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 00000012A324: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 00000012A32C: D8DCBBAA 42000001
	s_waitcnt lgkmcnt(2)                                       // 00000012A334: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A338: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A33C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A340: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A344: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A348: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A34C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A350: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:12 offset1:13      // 00000012A354: D8DC0D0C 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:204 offset1:221     // 00000012A35C: D8DCDDCC 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:14 offset1:15      // 00000012A364: D8DC0F0E 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:238 offset1:255     // 00000012A36C: D8DCFFEE 42000001
	s_waitcnt lgkmcnt(2)                                       // 00000012A374: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A378: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A37C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A380: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A384: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A388: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A38C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A390: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 00000012A394: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 00000012A39C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 00000012A3A4: D8DC1312 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 00000012A3AC: D8DC4332 42000030
	s_waitcnt lgkmcnt(2)                                       // 00000012A3B4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A3B8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A3BC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A3C0: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A3C4: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A3C8: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A3CC: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A3D0: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:20 offset1:21      // 00000012A3D4: D8DC1514 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:84 offset1:101     // 00000012A3DC: D8DC6554 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:22 offset1:23      // 00000012A3E4: D8DC1716 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:118 offset1:135    // 00000012A3EC: D8DC8776 42000030
	s_waitcnt lgkmcnt(2)                                       // 00000012A3F4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A3F8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A3FC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A400: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A404: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A408: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A40C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A410: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 00000012A414: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 00000012A41C: D8DCA998 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 00000012A424: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 00000012A42C: D8DCCBBA 42000030
	s_waitcnt lgkmcnt(2)                                       // 00000012A434: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A438: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A43C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A440: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A444: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A448: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A44C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A450: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:28 offset1:29      // 00000012A454: D8DC1D1C 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:220 offset1:237    // 00000012A45C: D8DCEDDC 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:30 offset1:31      // 00000012A464: D8DC1F1E 4000002E
	ds_load_2addr_b32 v[66:67], v49 offset0:126 offset1:143    // 00000012A46C: D8DC8F7E 42000031
	s_waitcnt lgkmcnt(2)                                       // 00000012A474: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A478: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A47C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A480: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A484: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A488: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A48C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A490: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 00000012A494: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 00000012A49C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 00000012A4A4: D8DC2322 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:66 offset1:83      // 00000012A4AC: D8DC5342 42000032
	s_waitcnt lgkmcnt(2)                                       // 00000012A4B4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A4B8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A4BC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A4C0: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A4C4: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A4C8: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A4CC: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A4D0: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:36 offset1:37      // 00000012A4D4: D8DC2524 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:100 offset1:117    // 00000012A4DC: D8DC7564 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:38 offset1:39      // 00000012A4E4: D8DC2726 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:134 offset1:151    // 00000012A4EC: D8DC9786 42000032
	s_waitcnt lgkmcnt(2)                                       // 00000012A4F4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A4F8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A4FC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A500: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A504: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A508: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A50C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A510: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:40 offset1:41      // 00000012A514: D8DC2928 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:168 offset1:185    // 00000012A51C: D8DCB9A8 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 00000012A524: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:202 offset1:219    // 00000012A52C: D8DCDBCA 42000032
	s_waitcnt lgkmcnt(2)                                       // 00000012A534: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A538: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A53C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A540: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A544: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A548: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A54C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A550: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:44 offset1:45      // 00000012A554: D8DC2D2C 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:236 offset1:253    // 00000012A55C: D8DCFDEC 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:46 offset1:47      // 00000012A564: D8DC2F2E 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:14 offset1:31      // 00000012A56C: D8DC1F0E 42000033
	s_waitcnt lgkmcnt(2)                                       // 00000012A574: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A578: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A57C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A580: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A584: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A588: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A58C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A590: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 00000012A594: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 00000012A59C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 00000012A5A4: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 00000012A5AC: D8DC6352 42000033
	s_waitcnt lgkmcnt(2)                                       // 00000012A5B4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A5B8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A5BC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A5C0: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A5C4: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A5C8: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A5CC: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A5D0: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:52 offset1:53      // 00000012A5D4: D8DC3534 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:116 offset1:133    // 00000012A5DC: D8DC8574 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:54 offset1:55      // 00000012A5E4: D8DC3736 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:150 offset1:167    // 00000012A5EC: D8DCA796 42000033
	s_waitcnt lgkmcnt(2)                                       // 00000012A5F4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A5F8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A5FC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A600: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A604: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A608: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A60C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A610: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:56 offset1:57      // 00000012A614: D8DC3938 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:184 offset1:201    // 00000012A61C: D8DCC9B8 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 00000012A624: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:218 offset1:235    // 00000012A62C: D8DCEBDA 42000033
	s_waitcnt lgkmcnt(2)                                       // 00000012A634: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A638: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A63C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A640: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A644: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A648: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A64C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A650: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:60 offset1:61      // 00000012A654: D8DC3D3C 3C00002E
	ds_load_2addr_b32 v[62:63], v52 offset0:124 offset1:141    // 00000012A65C: D8DC8D7C 3E000034
	ds_load_2addr_b32 v[64:65], v46 offset0:62 offset1:63      // 00000012A664: D8DC3F3E 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:30 offset1:47      // 00000012A66C: D8DC2F1E 42000035
	s_waitcnt lgkmcnt(2)                                       // 00000012A674: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A678: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A67C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A680: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A684: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A688: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A68C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A690: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 00000012A694: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 00000012A69C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 00000012A6A4: D8DC4342 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:98 offset1:115     // 00000012A6AC: D8DC7362 42000035
	s_waitcnt lgkmcnt(2)                                       // 00000012A6B4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A6B8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A6BC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A6C0: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A6C4: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A6C8: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A6CC: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A6D0: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:68 offset1:69      // 00000012A6D4: D8DC4544 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:132 offset1:149    // 00000012A6DC: D8DC9584 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:70 offset1:71      // 00000012A6E4: D8DC4746 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:166 offset1:183    // 00000012A6EC: D8DCB7A6 42000035
	s_waitcnt lgkmcnt(2)                                       // 00000012A6F4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A6F8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A6FC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A700: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A704: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A708: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A70C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A710: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 00000012A714: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 00000012A71C: D8DCD9C8 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 00000012A724: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 00000012A72C: D8DCFBEA 42000035
	s_waitcnt lgkmcnt(2)                                       // 00000012A734: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A738: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A73C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A740: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A744: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A748: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A74C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A750: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:76 offset1:77      // 00000012A754: D8DC4D4C 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:12 offset1:29      // 00000012A75C: D8DC1D0C 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:78 offset1:79      // 00000012A764: D8DC4F4E 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:46 offset1:63      // 00000012A76C: D8DC3F2E 42000036
	s_waitcnt lgkmcnt(2)                                       // 00000012A774: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A778: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A77C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A780: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A784: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A788: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A78C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A790: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 00000012A794: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 00000012A79C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 00000012A7A4: D8DC5352 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:114 offset1:131    // 00000012A7AC: D8DC8372 42000036
	s_waitcnt lgkmcnt(2)                                       // 00000012A7B4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A7B8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A7BC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A7C0: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A7C4: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A7C8: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A7CC: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A7D0: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:84 offset1:85      // 00000012A7D4: D8DC5554 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:148 offset1:165    // 00000012A7DC: D8DCA594 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:86 offset1:87      // 00000012A7E4: D8DC5756 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:182 offset1:199    // 00000012A7EC: D8DCC7B6 42000036
	s_waitcnt lgkmcnt(2)                                       // 00000012A7F4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A7F8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A7FC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A800: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A804: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A808: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A80C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A810: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:88 offset1:89      // 00000012A814: D8DC5958 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:216 offset1:233    // 00000012A81C: D8DCE9D8 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:90 offset1:91      // 00000012A824: D8DC5B5A 4000002E
	ds_load_2addr_b32 v[66:67], v55 offset0:122 offset1:139    // 00000012A82C: D8DC8B7A 42000037
	s_waitcnt lgkmcnt(2)                                       // 00000012A834: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A838: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A83C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A840: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A844: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A848: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A84C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A850: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:92 offset1:93      // 00000012A854: D8DC5D5C 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:28 offset1:45      // 00000012A85C: D8DC2D1C 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:94 offset1:95      // 00000012A864: D8DC5F5E 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:62 offset1:79      // 00000012A86C: D8DC4F3E 42000038
	s_waitcnt lgkmcnt(2)                                       // 00000012A874: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A878: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A87C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A880: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A884: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A888: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A88C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A890: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 00000012A894: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 00000012A89C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 00000012A8A4: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 00000012A8AC: D8DC9382 42000038
	s_waitcnt lgkmcnt(2)                                       // 00000012A8B4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A8B8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A8BC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A8C0: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A8C4: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A8C8: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A8CC: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A8D0: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:100 offset1:101    // 00000012A8D4: D8DC6564 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:164 offset1:181    // 00000012A8DC: D8DCB5A4 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:102 offset1:103    // 00000012A8E4: D8DC6766 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:198 offset1:215    // 00000012A8EC: D8DCD7C6 42000038
	s_waitcnt lgkmcnt(2)                                       // 00000012A8F4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A8F8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A8FC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A900: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A904: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A908: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A90C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A910: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:104 offset1:105    // 00000012A914: D8DC6968 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:232 offset1:249    // 00000012A91C: D8DCF9E8 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 00000012A924: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:10 offset1:27      // 00000012A92C: D8DC1B0A 42000039
	s_waitcnt lgkmcnt(2)                                       // 00000012A934: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A938: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A93C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A940: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A944: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A948: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A94C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A950: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:108 offset1:109    // 00000012A954: D8DC6D6C 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:44 offset1:61      // 00000012A95C: D8DC3D2C 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:110 offset1:111    // 00000012A964: D8DC6F6E 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:78 offset1:95      // 00000012A96C: D8DC5F4E 42000039
	s_waitcnt lgkmcnt(2)                                       // 00000012A974: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A978: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A97C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A980: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A984: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A988: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A98C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A990: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 00000012A994: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 00000012A99C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 00000012A9A4: D8DC7372 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:146 offset1:163    // 00000012A9AC: D8DCA392 42000039
	s_waitcnt lgkmcnt(2)                                       // 00000012A9B4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A9B8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A9BC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012A9C0: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012A9C4: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012A9C8: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012A9CC: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012A9D0: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:116 offset1:117    // 00000012A9D4: D8DC7574 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:180 offset1:197    // 00000012A9DC: D8DCC5B4 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:118 offset1:119    // 00000012A9E4: D8DC7776 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:214 offset1:231    // 00000012A9EC: D8DCE7D6 42000039
	s_waitcnt lgkmcnt(2)                                       // 00000012A9F4: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012A9F8: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012A9FC: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012AA00: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012AA04: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012AA08: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012AA0C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012AA10: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 00000012AA14: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 00000012AA1C: D8DC8978 3E00003A
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 00000012AA24: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:26 offset1:43      // 00000012AA2C: D8DC2B1A 4200003B
	s_waitcnt lgkmcnt(2)                                       // 00000012AA34: BF89FC27
	v_fmac_f32_e32 v68, v60, v62                               // 00000012AA38: 56887D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012AA3C: BF8700A1
	v_fmac_f32_e32 v68, v61, v63                               // 00000012AA40: 56887F3D
	s_waitcnt lgkmcnt(0)                                       // 00000012AA44: BF89FC07
	v_fmac_f32_e32 v68, v64, v66                               // 00000012AA48: 56888540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012AA4C: BF870001
	v_fmac_f32_e32 v68, v65, v67                               // 00000012AA50: 56888741
	ds_load_2addr_b32 v[60:61], v46 offset0:124 offset1:125    // 00000012AA54: D8DC7D7C 3C00002E
	ds_load_2addr_b32 v[62:63], v59 offset0:60 offset1:77      // 00000012AA5C: D8DC4D3C 3E00003B
	ds_load_2addr_b32 v[64:65], v46 offset0:126 offset1:127    // 00000012AA64: D8DC7F7E 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:94 offset1:111     // 00000012AA6C: D8DC6F5E 4200003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 00000012AA74: 30424282
	ds_load_b32 v69, v33 offset:17440                          // 00000012AA78: D8D84420 45000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 00000012AA80: CA10011E 2220011D
	s_waitcnt lgkmcnt(3)                                       // 00000012AA88: BF89FC37
	v_fmac_f32_e32 v68, v60, v62                               // 00000012AA8C: 56887D3C
	v_mov_b32_e32 v62, v35                                     // 00000012AA90: 7E7C0323
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012AA94: BF8700A2
	v_fmac_f32_e32 v68, v61, v63                               // 00000012AA98: 56887F3D
	s_waitcnt lgkmcnt(1)                                       // 00000012AA9C: BF89FC17
	v_dual_mov_b32 v61, v1 :: v_dual_fmac_f32 v68, v64, v66    // 00000012AAA0: CA000101 3D448540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012AAA8: BF8700A1
	v_fmac_f32_e32 v68, v65, v67                               // 00000012AAAC: 56888741
	s_waitcnt lgkmcnt(0)                                       // 00000012AAB0: BF89FC07
	v_mul_f32_e32 v60, v68, v69                                // 00000012AAB4: 10788B44
	s_nop 0                                                    // 00000012AAB8: BF800000
	s_nop 0                                                    // 00000012AABC: BF800000
	global_load_b32 v63, v[33:34], off                         // 00000012AAC0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 00000012AAC8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 00000012AAD0: 4A7C7CC1
	.long 0xd7000121                                           // 00000012AAD4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 00000012AAD8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012AADC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 00000012AAE0: D5207C22 00064480
	.long 0xd44a0004                                           // 00000012AAE8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 00000012AAEC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 00000012AAF0: 4A7A7AFF 00000044
	s_or_b32 s12, s4, s12                                      // 00000012AAF8: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012AAFC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 00000012AB00: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 00000012AB04: 917E0C7E
	s_cbranch_execnz 65517                                     // 00000012AB08: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c0>
	s_or_b32 exec_lo, exec_lo, s12                             // 00000012AB0C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012AB10: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 00000012AB14: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 00000012AB1C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 00000012AB28: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 00000012AB34: DC960000 007C2421
	s_branch 64917                                             // 00000012AB3C: BFA0FD95 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 00000012AB40: A201FF06 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 00000012AB48: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000012AB4C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 00000012AB50: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 00000012AB58: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 00000012AB5C: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 00000012AB64: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 00000012AB6C: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000012AB70: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 00000012AB74: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 00000012AB7C: A0010401
	s_mov_b32 s4, 0                                            // 00000012AB80: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 00000012AB84: BF87000A
	v_exp_f32_e32 v29, s1                                      // 00000012AB88: 7E3A4A01
	s_cvt_i32_f32 s1, s7                                       // 00000012AB8C: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000012AB90: BF870585
	.long 0xd71c001d                                           // 00000012AB94: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 00000012AB98: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 00000012AB9C: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 00000012ABA0: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000012ABA8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 00000012ABAC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 00000012ABB4: 980180C1
	v_mov_b32_e32 v29, v37                                     // 00000012ABB8: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 00000012ABBC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 00000012ABC8: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 00000012ABD0: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012ABD8: BF870001
	.long 0xd4490001                                           // 00000012ABDC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 00000012ABE0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 00000012ABE8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 00000012ABEC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 00000012ABF0: 1040411E
	ds_store_b32 v29, v32                                      // 00000012ABF4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 00000012ABFC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012AC04: 917E047E
	s_cbranch_execnz 65519                                     // 00000012AC08: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ac8>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012AC0C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 00000012AC10: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 00000012AC18: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 00000012AC20: 7E420326
	s_mov_b32 s6, 0                                            // 00000012AC24: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012AC28: BF89FC07
	s_barrier                                                  // 00000012AC2C: BFBD0000
	buffer_gl0_inv                                             // 00000012AC30: E0AC0000 00000000
	s_nop 0                                                    // 00000012AC38: BF800000
	s_nop 0                                                    // 00000012AC3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012AC40: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 00000012AC48: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012AC50: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012AC58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012AC5C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 00000012AC64: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012AC68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012AC70: BF870004
	.long 0xd4490004                                           // 00000012AC74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012AC78: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012AC80: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012AC84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012AC88: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 00000012AC8C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 00000012AC94: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012AC9C: 917E067E
	s_cbranch_execnz 65511                                     // 00000012ACA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b40>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012ACA4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000012ACA8: BF89FC07
	s_barrier                                                  // 00000012ACAC: BFBD0000
	buffer_gl0_inv                                             // 00000012ACB0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 00000012ACB8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 00000012ACC0: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 00000012ACC8: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 00000012ACD0: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 00000012ACD8: 7E780300
	s_mov_b32 s4, 0                                            // 00000012ACDC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012ACE0: BF840001
	s_nop 0                                                    // 00000012ACE4: BF800000
	s_nop 0                                                    // 00000012ACE8: BF800000
	s_nop 0                                                    // 00000012ACEC: BF800000
	s_nop 0                                                    // 00000012ACF0: BF800000
	s_nop 0                                                    // 00000012ACF4: BF800000
	s_nop 0                                                    // 00000012ACF8: BF800000
	s_nop 0                                                    // 00000012ACFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012AD00: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000012AD04: 327A7884
	.long 0xd4490001                                           // 00000012AD08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012AD0C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000012AD14: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000012AD18: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012AD24: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000012AD28: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000012AD30: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000012AD38: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000012AD40: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000012AD48: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000012AD50: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000012AD58: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000012AD60: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000012AD64: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012AD70: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000012AD74: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000012AD78: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000012AD80: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000012AD84: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000012AD88: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000012AD8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012AD90: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000012AD94: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000012AD98: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000012AD9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012ADA0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012ADA4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000012ADB0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000012ADB8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012ADC0: 917E047E
	s_cbranch_execnz 65486                                     // 00000012ADC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_set_inst_prefetch_distance 0x2                           // 00000012ADC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012ADCC: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 00000012ADD0: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000012ADD8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012ADE0: 7E420326
	s_mov_b32 s6, 0                                            // 00000012ADE4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012ADE8: BF89FC07
	s_barrier                                                  // 00000012ADEC: BFBD0000
	buffer_gl0_inv                                             // 00000012ADF0: E0AC0000 00000000
	s_nop 0                                                    // 00000012ADF8: BF800000
	s_nop 0                                                    // 00000012ADFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012AE00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 00000012AE08: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012AE10: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012AE18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012AE1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000012AE24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012AE28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012AE30: BF870004
	.long 0xd4490004                                           // 00000012AE34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012AE38: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012AE40: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012AE44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012AE48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000012AE4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012AE54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012AE5C: 917E067E
	s_cbranch_execnz 65511                                     // 00000012AE60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d00>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012AE64: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000012AE68: BF89FC07
	s_barrier                                                  // 00000012AE6C: BFBD0000
	buffer_gl0_inv                                             // 00000012AE70: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 00000012AE78: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 00000012AE80: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 00000012AE88: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 00000012AE90: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 00000012AE98: 7E780300
	s_mov_b32 s4, 0                                            // 00000012AE9C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012AEA0: BF840001
	s_nop 0                                                    // 00000012AEA4: BF800000
	s_nop 0                                                    // 00000012AEA8: BF800000
	s_nop 0                                                    // 00000012AEAC: BF800000
	s_nop 0                                                    // 00000012AEB0: BF800000
	s_nop 0                                                    // 00000012AEB4: BF800000
	s_nop 0                                                    // 00000012AEB8: BF800000
	s_nop 0                                                    // 00000012AEBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012AEC0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000012AEC4: 327A7884
	.long 0xd4490001                                           // 00000012AEC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012AECC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000012AED4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000012AED8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012AEE4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000012AEE8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000012AEF0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000012AEF8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000012AF00: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000012AF08: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000012AF10: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000012AF18: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000012AF20: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000012AF24: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012AF30: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000012AF34: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000012AF38: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000012AF40: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000012AF44: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000012AF48: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000012AF4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012AF50: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000012AF54: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000012AF58: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000012AF5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012AF60: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012AF64: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000012AF70: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000012AF78: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012AF80: 917E047E
	s_cbranch_execnz 65486                                     // 00000012AF84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dc0>
	s_set_inst_prefetch_distance 0x2                           // 00000012AF88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012AF8C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 00000012AF90: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000012AF98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012AFA0: 7E420326
	s_mov_b32 s6, 0                                            // 00000012AFA4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012AFA8: BF89FC07
	s_barrier                                                  // 00000012AFAC: BFBD0000
	buffer_gl0_inv                                             // 00000012AFB0: E0AC0000 00000000
	s_nop 0                                                    // 00000012AFB8: BF800000
	s_nop 0                                                    // 00000012AFBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012AFC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 00000012AFC8: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012AFD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012AFD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012AFDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000012AFE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012AFE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012AFF0: BF870004
	.long 0xd4490004                                           // 00000012AFF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012AFF8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012B000: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012B004: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012B008: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000012B00C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012B014: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012B01C: 917E067E
	s_cbranch_execnz 65511                                     // 00000012B020: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ec0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012B024: 8C7E067E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 00000012B028: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 00000012B030: BF89FC07
	s_barrier                                                  // 00000012B034: BFBD0000
	buffer_gl0_inv                                             // 00000012B038: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 00000012B040: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 00000012B044: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 00000012B04C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 00000012B054: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 00000012B05C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 00000012B064: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012B068: BF840001
	s_nop 0                                                    // 00000012B06C: BF800000
	s_nop 0                                                    // 00000012B070: BF800000
	s_nop 0                                                    // 00000012B074: BF800000
	s_nop 0                                                    // 00000012B078: BF800000
	s_nop 0                                                    // 00000012B07C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000012B080: 327C7A84
	.long 0xd4490001                                           // 00000012B084: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000012B088: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000012B090: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000012B094: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000012B098: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012B0A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000012B0A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000012B0B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000012B0B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000012B0C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000012B0C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000012B0D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000012B0D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000012B0E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000012B0E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012B0E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000012B0EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000012B0F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000012B100: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000012B104: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000012B108: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000012B10C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B110: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000012B114: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000012B118: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000012B11C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B120: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000012B124: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000012B130: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000012B138: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012B140: 917E047E
	s_cbranch_execnz 65486                                     // 00000012B144: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f80>
	s_set_inst_prefetch_distance 0x2                           // 00000012B148: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012B14C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 00000012B150: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000012B158: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012B160: 7E420326
	s_mov_b32 s6, 0                                            // 00000012B164: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012B168: BF89FC07
	s_barrier                                                  // 00000012B16C: BFBD0000
	buffer_gl0_inv                                             // 00000012B170: E0AC0000 00000000
	s_nop 0                                                    // 00000012B178: BF800000
	s_nop 0                                                    // 00000012B17C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012B180: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 00000012B188: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012B190: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012B198: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012B19C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000012B1A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012B1A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012B1B0: BF870004
	.long 0xd4490004                                           // 00000012B1B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012B1B8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012B1C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012B1C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012B1C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000012B1CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012B1D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012B1DC: 917E067E
	s_cbranch_execnz 65511                                     // 00000012B1E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2080>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012B1E4: 8C7E067E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 00000012B1E8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 00000012B1F0: BF89FC07
	s_barrier                                                  // 00000012B1F4: BFBD0000
	buffer_gl0_inv                                             // 00000012B1F8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 00000012B200: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 00000012B208: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 00000012B210: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 00000012B218: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 00000012B220: 7E780300
	s_mov_b32 s4, 0                                            // 00000012B224: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012B228: BF840001
	s_nop 0                                                    // 00000012B22C: BF800000
	s_nop 0                                                    // 00000012B230: BF800000
	s_nop 0                                                    // 00000012B234: BF800000
	s_nop 0                                                    // 00000012B238: BF800000
	s_nop 0                                                    // 00000012B23C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B240: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000012B244: 327A7884
	.long 0xd4490001                                           // 00000012B248: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012B24C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000012B254: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000012B258: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012B264: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000012B268: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000012B270: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000012B278: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000012B280: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000012B288: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000012B290: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000012B298: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000012B2A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000012B2A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012B2B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000012B2B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000012B2B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000012B2C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000012B2C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000012B2C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000012B2CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B2D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000012B2D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000012B2D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000012B2DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B2E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012B2E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000012B2F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000012B2F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012B300: 917E047E
	s_cbranch_execnz 65486                                     // 00000012B304: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2140>
	s_set_inst_prefetch_distance 0x2                           // 00000012B308: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012B30C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 00000012B310: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000012B318: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012B320: 7E420326
	s_mov_b32 s6, 0                                            // 00000012B324: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012B328: BF89FC07
	s_barrier                                                  // 00000012B32C: BFBD0000
	buffer_gl0_inv                                             // 00000012B330: E0AC0000 00000000
	s_nop 0                                                    // 00000012B338: BF800000
	s_nop 0                                                    // 00000012B33C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012B340: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 00000012B348: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012B350: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012B358: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012B35C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000012B364: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012B368: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012B370: BF870004
	.long 0xd4490004                                           // 00000012B374: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012B378: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012B380: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012B384: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012B388: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000012B38C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012B394: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012B39C: 917E067E
	s_cbranch_execnz 65511                                     // 00000012B3A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2240>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012B3A4: 8C7E067E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 00000012B3A8: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 00000012B3B0: BF89FC07
	s_barrier                                                  // 00000012B3B4: BFBD0000
	buffer_gl0_inv                                             // 00000012B3B8: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 00000012B3C0: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 00000012B3C4: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 00000012B3CC: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 00000012B3D4: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 00000012B3DC: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 00000012B3E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012B3E8: BF840001
	s_nop 0                                                    // 00000012B3EC: BF800000
	s_nop 0                                                    // 00000012B3F0: BF800000
	s_nop 0                                                    // 00000012B3F4: BF800000
	s_nop 0                                                    // 00000012B3F8: BF800000
	s_nop 0                                                    // 00000012B3FC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 00000012B400: 327C7884
	.long 0xd4490001                                           // 00000012B404: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012B408: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000012B410: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000012B414: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000012B418: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012B424: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000012B428: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000012B430: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000012B438: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000012B440: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000012B448: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000012B450: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000012B458: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000012B460: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000012B464: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012B468: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000012B46C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000012B478: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000012B480: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000012B484: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000012B488: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000012B48C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B490: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000012B494: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000012B498: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000012B49C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B4A0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 00000012B4A4: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 00000012B4B0: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 00000012B4B4: BF870002
	v_mov_b32_e32 v60, v63                                     // 00000012B4B8: 7E78033F
	ds_store_b32 v62, v70                                      // 00000012B4BC: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012B4C4: 917E047E
	s_cbranch_execnz 65485                                     // 00000012B4C8: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2300>
	s_set_inst_prefetch_distance 0x2                           // 00000012B4CC: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012B4D0: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 00000012B4D4: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000012B4DC: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012B4E4: 7E420326
	s_mov_b32 s6, 0                                            // 00000012B4E8: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012B4EC: BF89FC07
	s_barrier                                                  // 00000012B4F0: BFBD0000
	buffer_gl0_inv                                             // 00000012B4F4: E0AC0000 00000000
	s_nop 0                                                    // 00000012B4FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012B500: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 00000012B508: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012B510: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012B518: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012B51C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000012B524: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012B528: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012B530: BF870004
	.long 0xd4490004                                           // 00000012B534: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012B538: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012B540: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012B544: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012B548: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000012B54C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012B554: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012B55C: 917E067E
	s_cbranch_execnz 65511                                     // 00000012B560: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2400>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012B564: 8C7E067E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 00000012B568: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 00000012B570: BF89FC07
	s_barrier                                                  // 00000012B574: BFBD0000
	buffer_gl0_inv                                             // 00000012B578: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 00000012B580: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 00000012B588: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 00000012B590: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 00000012B598: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 00000012B5A0: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000012B5A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012B5A8: BF840001
	s_nop 0                                                    // 00000012B5AC: BF800000
	s_nop 0                                                    // 00000012B5B0: BF800000
	s_nop 0                                                    // 00000012B5B4: BF800000
	s_nop 0                                                    // 00000012B5B8: BF800000
	s_nop 0                                                    // 00000012B5BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B5C0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000012B5C4: 327C7A84
	.long 0xd4490001                                           // 00000012B5C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000012B5CC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000012B5D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000012B5D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012B5E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000012B5E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000012B5F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000012B5F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000012B600: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000012B608: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000012B610: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000012B618: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000012B620: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000012B624: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012B628: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000012B62C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000012B638: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000012B640: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000012B644: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000012B648: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000012B64C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B650: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000012B654: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000012B658: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000012B65C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B660: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000012B664: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000012B670: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000012B678: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012B680: 917E047E
	s_cbranch_execnz 65486                                     // 00000012B684: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x24c0>
	s_set_inst_prefetch_distance 0x2                           // 00000012B688: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012B68C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 00000012B690: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000012B698: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012B6A0: 7E420326
	s_mov_b32 s6, 0                                            // 00000012B6A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012B6A8: BF89FC07
	s_barrier                                                  // 00000012B6AC: BFBD0000
	buffer_gl0_inv                                             // 00000012B6B0: E0AC0000 00000000
	s_nop 0                                                    // 00000012B6B8: BF800000
	s_nop 0                                                    // 00000012B6BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012B6C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 00000012B6C8: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012B6D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012B6D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012B6DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000012B6E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012B6E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012B6F0: BF870004
	.long 0xd4490004                                           // 00000012B6F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012B6F8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012B700: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012B704: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012B708: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000012B70C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012B714: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012B71C: 917E067E
	s_cbranch_execnz 65511                                     // 00000012B720: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012B724: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000012B728: BF89FC07
	s_barrier                                                  // 00000012B72C: BFBD0000
	buffer_gl0_inv                                             // 00000012B730: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 00000012B738: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 00000012B740: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 00000012B748: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 00000012B750: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 00000012B758: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000012B75C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012B760: BF840001
	s_nop 0                                                    // 00000012B764: BF800000
	s_nop 0                                                    // 00000012B768: BF800000
	s_nop 0                                                    // 00000012B76C: BF800000
	s_nop 0                                                    // 00000012B770: BF800000
	s_nop 0                                                    // 00000012B774: BF800000
	s_nop 0                                                    // 00000012B778: BF800000
	s_nop 0                                                    // 00000012B77C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B780: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000012B784: 327C7A84
	.long 0xd4490001                                           // 00000012B788: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000012B78C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000012B794: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000012B798: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012B7A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000012B7A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000012B7B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000012B7B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000012B7C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000012B7C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000012B7D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000012B7D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000012B7E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000012B7E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012B7E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000012B7EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000012B7F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000012B800: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000012B804: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000012B808: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000012B80C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B810: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000012B814: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000012B818: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000012B81C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B820: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000012B824: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000012B830: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000012B838: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012B840: 917E047E
	s_cbranch_execnz 65486                                     // 00000012B844: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2680>
	s_set_inst_prefetch_distance 0x2                           // 00000012B848: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012B84C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 00000012B850: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000012B858: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012B860: 7E420326
	s_mov_b32 s6, 0                                            // 00000012B864: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012B868: BF89FC07
	s_barrier                                                  // 00000012B86C: BFBD0000
	buffer_gl0_inv                                             // 00000012B870: E0AC0000 00000000
	s_nop 0                                                    // 00000012B878: BF800000
	s_nop 0                                                    // 00000012B87C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012B880: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 00000012B888: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012B890: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012B898: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012B89C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000012B8A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012B8A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012B8B0: BF870004
	.long 0xd4490004                                           // 00000012B8B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012B8B8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012B8C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012B8C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012B8C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000012B8CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012B8D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012B8DC: 917E067E
	s_cbranch_execnz 65511                                     // 00000012B8E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2780>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012B8E4: 8C7E067E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 00000012B8E8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 00000012B8F0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 00000012B8F8: BF89FC07
	s_barrier                                                  // 00000012B8FC: BFBD0000
	buffer_gl0_inv                                             // 00000012B900: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 00000012B908: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 00000012B910: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 00000012B918: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 00000012B920: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 00000012B928: 7E780300
	s_mov_b32 s4, 0                                            // 00000012B92C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012B930: BF840001
	s_nop 0                                                    // 00000012B934: BF800000
	s_nop 0                                                    // 00000012B938: BF800000
	s_nop 0                                                    // 00000012B93C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B940: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000012B944: 327A7884
	.long 0xd4490001                                           // 00000012B948: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012B94C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000012B954: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000012B958: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012B964: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000012B968: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000012B970: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000012B978: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000012B980: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000012B988: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000012B990: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000012B998: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000012B9A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000012B9A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012B9B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000012B9B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000012B9B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000012B9C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000012B9C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000012B9C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000012B9CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B9D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000012B9D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000012B9D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000012B9DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B9E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012B9E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000012B9F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000012B9F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012BA00: 917E047E
	s_cbranch_execnz 65486                                     // 00000012BA04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2840>
	s_set_inst_prefetch_distance 0x2                           // 00000012BA08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012BA0C: 8C7E047E
	.long 0xd7000107                                           // 00000012BA10: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 00000012BA14: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012BA1C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 00000012BA20: D5207C08 00061080
	.long 0xd7000109                                           // 00000012BA28: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 00000012BA2C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 00000012BA34: D5207C0A 00061480
	.long 0xd700010d                                           // 00000012BA3C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 00000012BA40: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012BA48: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 00000012BA4C: D5207C0E 00061C80
	.long 0xd700010b                                           // 00000012BA54: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 00000012BA58: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 00000012BA60: D5207C0C 00061880
	.long 0xd700010f                                           // 00000012BA68: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 00000012BA6C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012BA74: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 00000012BA78: D5207C10 00062080
	.long 0xd7000111                                           // 00000012BA80: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 00000012BA84: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 00000012BA8C: D5207C12 00062480
	.long 0xd7000113                                           // 00000012BA94: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 00000012BA98: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012BAA0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 00000012BAA4: D5207C14 00062880
	.long 0xd7000115                                           // 00000012BAAC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 00000012BAB0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 00000012BAB8: D5207C16 00062C80
	.long 0xd7000117                                           // 00000012BAC0: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 00000012BAC4: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012BACC: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 00000012BAD0: D5207C18 00063080
	.long 0xd7000119                                           // 00000012BAD8: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 00000012BADC: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 00000012BAE4: D5207C1A 00063480
	.long 0xd700011b                                           // 00000012BAEC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 00000012BAF0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012BAF8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 00000012BAFC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 00000012BB04: 81058105
	s_waitcnt lgkmcnt(0)                                       // 00000012BB08: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 00000012BB0C: BF062105
	s_barrier                                                  // 00000012BB10: BFBD0000
	buffer_gl0_inv                                             // 00000012BB14: E0AC0000 00000000
	s_cbranch_scc0 63073                                       // 00000012BB1C: BFA1F661 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 00000012BB20: 7E080326
	s_add_u32 s0, s28, s20                                     // 00000012BB24: 8000141C
	.long 0xd73c0000                                           // 00000012BB28: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000012BB2C: 02020489
	s_addc_u32 s1, s29, s21                                    // 00000012BB30: 8201151D
	s_add_u32 s2, s24, s18                                     // 00000012BB34: 80021218
	s_addc_u32 s3, s25, s19                                    // 00000012BB38: 82031319
	s_add_u32 s0, s2, s0                                       // 00000012BB3C: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000012BB40: 82010103
	.long 0xd7006a00                                           // 00000012BB44: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000012BB48: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000012BB4C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000012BB50: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000012BB58: BE810080
	.long 0xd7006a00                                           // 00000012BB5C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 00000012BB60: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000012BB64: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BB6C: BF870092
	.long 0xd7006a00                                           // 00000012BB70: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000012BB74: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000012BB78: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 00000012BB80: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 00000012BB88: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 00000012BB90: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000012BB98: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000012BB9C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 00000012BBA4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000012BBA8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 00000012BBAC: DC6A0000 007C0200
	.long 0xd7000000                                           // 00000012BBB4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000012BBB8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000012BBC0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000012BBC8: 917E017E
	s_cbranch_execnz 65516                                     // 00000012BBCC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a80>
	s_endpgm                                                   // 00000012BBD0: BFB00000
		...

