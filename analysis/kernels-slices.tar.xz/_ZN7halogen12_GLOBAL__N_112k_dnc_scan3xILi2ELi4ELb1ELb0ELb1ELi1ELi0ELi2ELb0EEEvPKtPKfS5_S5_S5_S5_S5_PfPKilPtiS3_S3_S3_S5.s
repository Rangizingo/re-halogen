0000000000197900 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE():
	s_load_b256 s[16:23], s[0:1], 0x38                         // 000000197900: F40C0400 F8000038
	s_lshl_b32 s6, s3, 6                                       // 000000197908: 84068603
	s_ashr_i32 s3, s2, 31                                      // 00000019790C: 86039F02
	s_ashr_i32 s7, s6, 31                                      // 000000197910: 86079F06
	v_and_b32_e32 v1, 63, v0                                   // 000000197914: 360200BF
	v_mov_b32_e32 v5, v0                                       // 000000197918: 7E0A0300
	s_waitcnt lgkmcnt(0)                                       // 00000019791C: BF89FC07
	s_load_b32 s4, s[18:19], null                              // 000000197920: F4000109 F8000000
	s_load_b64 s[8:9], s[0:1], 0xc0                            // 000000197928: F4040200 F80000C0
	s_lshl_b64 s[18:19], s[20:21], 2                           // 000000197930: 84928214
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000197934: 30060282
	s_add_u32 s5, s16, s18                                     // 000000197938: 80051210
	s_addc_u32 s10, s17, s19                                   // 00000019793C: 820A1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 000000197940: 84949002
	v_mul_u32_u24_e32 v2, 0x210, v1                            // 000000197944: 160402FF 00000210
	s_add_u32 s5, s5, s20                                      // 00000019794C: 80051405
	s_addc_u32 s10, s10, s21                                   // 000000197950: 820A150A
	s_waitcnt lgkmcnt(0)                                       // 000000197954: BF89FC07
	s_mul_i32 s58, s4, 0x9000000                               // 000000197958: 963AFF04 09000000
	s_mul_hi_i32 s33, s4, 0x9000000                            // 000000197960: 9721FF04 09000000
	s_add_u32 s4, s5, s58                                      // 000000197968: 80043A05
	s_addc_u32 s5, s10, s33                                    // 00000019796C: 8205210A
	s_lshl_b64 s[34:35], s[6:7], 2                             // 000000197970: 84A28206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000197974: BF8700B9
	s_add_u32 s4, s4, s34                                      // 000000197978: 80042204
	s_addc_u32 s5, s5, s35                                     // 00000019797C: 82052305
	.long 0xd7000403                                           // 000000197980: D7000403
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 000000197984: 02020604
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 000000197988: D5207C04 00110005
	s_mov_b32 s4, 0                                            // 000000197990: BE840080
	s_nop 0                                                    // 000000197994: BF800000
	s_nop 0                                                    // 000000197998: BF800000
	s_nop 0                                                    // 00000019799C: BF800000
	s_nop 0                                                    // 0000001979A0: BF800000
	s_nop 0                                                    // 0000001979A4: BF800000
	s_nop 0                                                    // 0000001979A8: BF800000
	s_nop 0                                                    // 0000001979AC: BF800000
	s_nop 0                                                    // 0000001979B0: BF800000
	s_nop 0                                                    // 0000001979B4: BF800000
	s_nop 0                                                    // 0000001979B8: BF800000
	s_nop 0                                                    // 0000001979BC: BF800000
	v_lshrrev_b32_e32 v8, 6, v5                                // 0000001979C0: 32100A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001979C4: BF870121
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000001979C8: 300C1089
	v_lshl_add_u32 v8, v8, 2, v2                               // 0000001979CC: D6460008 04090508
	.long 0xd7006a06                                           // 0000001979D4: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000001979D8: 02020D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001979DC: BF8700D1
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000001979E0: D5207C07 01AA0880
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v5                        // 0000001979E8: 7C920AFF 00001F7F
	global_load_b32 v6, v[6:7], off                            // 0000001979F0: DC520000 067C0006
	v_add_nc_u32_e32 v7, 0x80, v5                              // 0000001979F8: 4A0E0AFF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 000000197A00: 8C04046A
	v_mov_b32_e32 v5, v7                                       // 000000197A04: 7E0A0307
	s_waitcnt vmcnt(0)                                         // 000000197A08: BF8903F7
	ds_store_b32 v8, v6                                        // 000000197A0C: D8340000 00000608
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000197A14: 917E047E
	s_cbranch_execnz 65513                                     // 000000197A18: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000197A1C: 8C7E047E
	s_load_b32 s59, s[0:1], 0x58                               // 000000197A20: F4000EC0 F8000058
	v_or_b32_e32 v119, 0xffffff80, v0                          // 000000197A28: 38EE00FF FFFFFF80
	v_lshlrev_b32_e32 v5, 3, v0                                // 000000197A30: 300A0083
	v_lshlrev_b32_e32 v118, 2, v1                              // 000000197A34: 30EC0282
	v_mul_u32_u24_e32 v3, 0x210, v1                            // 000000197A38: 160602FF 00000210
	v_lshrrev_b32_e32 v4, 4, v0                                // 000000197A40: 32080084
	s_mov_b32 s4, 0                                            // 000000197A44: BE840080
	s_waitcnt lgkmcnt(0)                                       // 000000197A48: BF89FC07
	s_barrier                                                  // 000000197A4C: BFBD0000
	buffer_gl0_inv                                             // 000000197A50: E0AC0000 00000000
	s_cmp_gt_i32 s59, 0                                        // 000000197A58: BF02803B
	s_cbranch_scc1 14                                          // 000000197A5C: BFA2000E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	v_dual_mov_b32 v107, 0 :: v_dual_and_b32 v106, 0x200, v5   // 000000197A60: CA240080 6B6A0AFF 00000200
	v_mov_b32_e32 v1, s34                                      // 000000197A6C: 7E020222
	v_or_b32_e32 v6, 0xffffff80, v0                            // 000000197A70: 380C00FF FFFFFF80
	v_and_or_b32 v124, v4, 4, v3                               // 000000197A78: D657007C 040D0904
	s_delay_alu instid0(VALU_DEP_4)                            // 000000197A80: BF870004
	v_dual_mov_b32 v129, v107 :: v_dual_mov_b32 v2, s35        // 000000197A84: CA10016B 81020023
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 000000197A8C: 916A047E
	s_cbranch_vccz 1                                           // 000000197A90: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	s_branch 8093                                              // 000000197A94: BFA01F9D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x800c>
	s_clause 0x2                                               // 000000197A98: BF850002
	s_load_b256 s[24:31], s[0:1], 0x60                         // 000000197A9C: F40C0600 F8000060
	s_load_b64 s[56:57], s[0:1], null                          // 000000197AA4: F4040E00 F8000000
	s_load_b128 s[52:55], s[0:1], 0x18                         // 000000197AAC: F4080D00 F8000018
	s_lshl_b64 s[10:11], s[2:3], 2                             // 000000197AB4: 848A8202
	s_mul_hi_i32 s12, s2, 0x55555556                           // 000000197AB8: 970CFF02 55555556
	v_dual_mov_b32 v107, 0 :: v_dual_lshlrev_b32 v2, 2, v0     // 000000197AC0: CA220080 6B020082
	v_lshlrev_b32_e32 v6, 1, v0                                // 000000197AC8: 300C0081
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000197ACC: 32020085
	v_bfe_u32 v7, v0, 4, 1                                     // 000000197AD0: D6100007 02050900
	s_delay_alu instid0(VALU_DEP_4)                            // 000000197AD8: BF870004
	v_or_b32_e32 v120, 0xf000, v2                              // 000000197ADC: 38F004FF 0000F000
	v_dual_mov_b32 v172, 1 :: v_dual_add_nc_u32 v121, 0xf100, v2// 000000197AE4: CA200081 AC7804FF 0000F100
	v_mov_b32_e32 v129, v107                                   // 000000197AF0: 7F02036B
	s_mov_b32 s13, 0xcc00                                      // 000000197AF4: BE8D00FF 0000CC00
	s_clause 0x1                                               // 000000197AFC: BF850001
	s_load_b256 s[44:51], s[0:1], 0x80                         // 000000197B00: F40C0B00 F8000080
	s_load_b64 s[0:1], s[0:1], 0xa0                            // 000000197B08: F4040000 F80000A0
	v_and_b32_e32 v106, 0x200, v5                              // 000000197B10: 36D40AFF 00000200
	.long 0xd44c0004                                           // 000000197B18: D44C0004
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 000000197B1C: 020200C0
	.long 0xd4490005                                           // 000000197B20: D4490005
	v_cndmask_b32_e32 v1, 63, v0, vcc_lo                       // 000000197B24: 020200BF
	v_and_or_b32 v124, v4, 4, v3                               // 000000197B28: D657007C 040D0904
	s_waitcnt lgkmcnt(0)                                       // 000000197B30: BF89FC07
	s_add_u32 s60, s30, s10                                    // 000000197B34: 803C0A1E
	s_addc_u32 s61, s31, s11                                   // 000000197B38: 823D0B1F
	s_add_u32 s62, s8, s10                                     // 000000197B3C: 803E0A08
	s_addc_u32 s63, s9, s11                                    // 000000197B40: 823F0B09
	s_lshr_b32 s9, s12, 31                                     // 000000197B44: 85099F0C
	s_add_i32 s8, s59, 63                                      // 000000197B48: 8108BF3B
	s_add_i32 s12, s12, s9                                     // 000000197B4C: 810C090C
	s_add_i32 s65, s59, -1                                     // 000000197B50: 8141C13B
	s_lshr_b32 s66, s8, 6                                      // 000000197B54: 85428608
	s_lshl_b32 s8, s12, 7                                      // 000000197B58: 8408870C
	s_mul_i32 s11, s65, 0x5000                                 // 000000197B5C: 960BFF41 00005000
	s_add_i32 s64, s2, 0xbd0                                   // 000000197B64: 8140FF02 00000BD0
	s_mul_hi_u32 s10, s65, 0x5000                              // 000000197B6C: 968AFF41 00005000
	s_ashr_i32 s9, s8, 31                                      // 000000197B74: 86099F08
	s_add_u32 s11, s56, s11                                    // 000000197B78: 800B0B38
	s_addc_u32 s10, s57, s10                                   // 000000197B7C: 820A0A39
	s_lshl_b64 s[30:31], s[8:9], 1                             // 000000197B80: 849E8108
	s_mul_hi_u32 s8, s65, 0xc0                                 // 000000197B84: 9688FF41 000000C0
	s_add_u32 s9, s11, s30                                     // 000000197B8C: 80091E0B
	s_addc_u32 s10, s10, s31                                   // 000000197B90: 820A1F0A
	.long 0xd7000902                                           // 000000197B94: D7000902
	v_cndmask_b32_e32 v1, s9, v6, vcc_lo                       // 000000197B98: 02020C09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000197B9C: BF8700B1
	v_add_co_ci_u32_e64 v6, null, s10, 0, s9                   // 000000197BA0: D5207C06 0025000A
	s_mul_i32 s9, s65, 0xc0                                    // 000000197BA8: 9609FF41 000000C0
	.long 0xd7006a7a                                           // 000000197BB0: D7006A7A
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 000000197BB4: 020204FF 00001000
	v_add_co_ci_u32_e64 v123, null, 0, v6, vcc_lo              // 000000197BBC: D5207C7B 01AA0C80
	v_dual_mov_b32 v141, 0xf004 :: v_dual_lshlrev_b32 v2, 4, v1// 000000197BC4: CA2200FF 8D020284 0000F004
	v_dual_mov_b32 v143, 0xf014 :: v_dual_and_b32 v6, 15, v0   // 000000197BD0: CA2400FF 8F06008F 0000F014
	s_add_u32 s67, s60, s9                                     // 000000197BDC: 8043093C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000197BE0: BF870122
	v_or_b32_e32 v128, v2, v7                                  // 000000197BE4: 39000F02
	s_addc_u32 s68, s61, s8                                    // 000000197BE8: 8244083D
	v_or_b32_e32 v126, v2, v6                                  // 000000197BEC: 38FC0D02
	v_mul_u32_u24_e32 v2, 0x2100, v1                           // 000000197BF0: 160402FF 00002100
	s_add_u32 s11, s54, s34                                    // 000000197BF8: 800B2236
	s_addc_u32 s12, s55, s35                                   // 000000197BFC: 820C2337
	s_lshl_b32 s8, s2, 7                                       // 000000197C00: 84088702
	v_dual_mov_b32 v145, 0xf024 :: v_dual_lshlrev_b32 v8, 2, v6// 000000197C04: CA2200FF 91080C82 0000F024
	s_ashr_i32 s9, s8, 31                                      // 000000197C10: 86099F08
	v_mad_u32_u24 v2, 0x210, v6, v2                            // 000000197C14: D60B0002 040A0CFF 00000210
	s_lshl_b64 s[8:9], s[8:9], 1                               // 000000197C20: 84888108
	v_mad_u32_u24 v130, 0x90, v6, s13                          // 000000197C24: D60B0082 00360CFF 00000090
	s_add_u32 s8, s22, s8                                      // 000000197C30: 80080816
	s_addc_u32 s9, s23, s9                                     // 000000197C34: 82090917
	s_lshl_b64 s[6:7], s[6:7], 1                               // 000000197C38: 84868106
	v_lshl_or_b32 v133, v7, 2, v2                              // 000000197C3C: D6560085 04090507
	v_dual_mov_b32 v147, 0xf034 :: v_dual_lshlrev_b32 v2, 7, v126// 000000197C44: CA2200FF 9302FC87 0000F034
	s_add_u32 s13, s8, s6                                      // 000000197C50: 800D0608
	s_addc_u32 s9, s9, s7                                      // 000000197C54: 82090709
	.long 0xd7000786                                           // 000000197C58: D7000786
	v_cndmask_b32_e32 v1, s11, v8, vcc_lo                      // 000000197C5C: 0202100B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000197C60: BF870001
	v_add_co_ci_u32_e64 v135, null, s12, 0, s7                 // 000000197C64: D5207C87 001D000C
	.long 0xd7000789                                           // 000000197C6C: D7000789
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 000000197C70: 0202041C
	v_dual_mov_b32 v149, 0xf044 :: v_dual_lshlrev_b32 v2, 1, v6// 000000197C74: CA2200FF 95020C81 0000F044
	s_movk_i32 s10, 0x90                                       // 000000197C80: B00A0090
	v_mad_u32_u24 v131, 0x900, v1, v130                        // 000000197C84: D60B0083 060A02FF 00000900
	v_mad_u32_u24 v125, v0, s10, 0x8400                        // 000000197C90: D60B007D 03FC1500 00008400
	v_mad_u32_u24 v132, v6, s10, 0x8400                        // 000000197C9C: D60B0084 03FC1506 00008400
	.long 0xd7000a6c                                           // 000000197CA8: D7000A6C
	v_cndmask_b32_e32 v1, s13, v2, vcc_lo                      // 000000197CAC: 0202040D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000197CB0: BF870001
	v_add_co_ci_u32_e64 v109, null, s9, 0, s10                 // 000000197CB4: D5207C6D 00290009
	s_add_u32 s9, s34, s20                                     // 000000197CBC: 80091422
	v_add_co_ci_u32_e64 v138, null, s29, 0, s7                 // 000000197CC0: D5207C8A 001D001D
	.long 0xd44d0007                                           // 000000197CC8: D44D0007
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000197CCC: 02020280
	s_addc_u32 s10, s35, s21                                   // 000000197CD0: 820A1523
	.long 0xd7000901                                           // 000000197CD4: D7000901
	v_cndmask_b32_e32 v1, s9, v106, vcc_lo                     // 000000197CD8: 0202D409
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000197CDC: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s10, 0, s9                   // 000000197CE0: D5207C02 0025000A
	v_mul_u32_u24_e32 v127, 0x210, v6                          // 000000197CE8: 16FE0CFF 00000210
	.long 0xd7006a01                                           // 000000197CF0: D7006A01
	v_cndmask_b32_e32 v1, v1, v118, vcc_lo                     // 000000197CF4: 0202ED01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000197CF8: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000197CFC: D5207C02 01AA0480
	.long 0xd44a0006                                           // 000000197D04: D44A0006
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000197D08: 02020080
	.long 0xd7006a6e                                           // 000000197D0C: D7006A6E
	v_cndmask_b32_e32 v1, s48, v1, vcc_lo                      // 000000197D10: 02020230
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000197D14: BF8700A1
	v_add_co_ci_u32_e64 v111, null, s49, v2, vcc_lo            // 000000197D18: D5207C6F 01AA0431
	.long 0xd7006a70                                           // 000000197D20: D7006A70
	v_cndmask_b32_e32 v1, s50, v1, vcc_lo                      // 000000197D24: 02020232
	v_add_co_ci_u32_e64 v113, null, s51, v2, vcc_lo            // 000000197D28: D5207C71 01AA0433
	.long 0xd7006a72                                           // 000000197D30: D7006A72
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 000000197D34: 02020200
	v_lshl_add_u32 v136, v128, 1, v130                         // 000000197D38: D6460088 06090380
	.long 0xd4490008                                           // 000000197D40: D4490008
	v_cndmask_b32_e32 v1, 0x5f, v0, vcc_lo                     // 000000197D44: 020200FF 0000005F
	v_lshl_or_b32 v139, v128, 2, 0xf100                        // 000000197D4C: D656008B 03FD0580 0000F100
	v_add_co_ci_u32_e64 v115, null, s1, v2, vcc_lo             // 000000197D58: D5207C73 01AA0401
	v_dual_mov_b32 v151, 0xf054 :: v_dual_lshlrev_b32 v140, 1, v0// 000000197D60: CA2200FF 978C0081 0000F054
	v_mov_b32_e32 v142, 0xf00c                                 // 000000197D6C: 7F1C02FF 0000F00C
	v_mov_b32_e32 v144, 0xf01c                                 // 000000197D74: 7F2002FF 0000F01C
	v_mov_b32_e32 v146, 0xf02c                                 // 000000197D7C: 7F2402FF 0000F02C
	v_mov_b32_e32 v148, 0xf03c                                 // 000000197D84: 7F2802FF 0000F03C
	v_mov_b32_e32 v150, 0xf04c                                 // 000000197D8C: 7F2C02FF 0000F04C
	v_mov_b32_e32 v152, 0xf05c                                 // 000000197D94: 7F3002FF 0000F05C
	v_mov_b32_e32 v153, 0xf064                                 // 000000197D9C: 7F3202FF 0000F064
	v_mov_b32_e32 v154, 0xf06c                                 // 000000197DA4: 7F3402FF 0000F06C
	v_mov_b32_e32 v155, 0xf074                                 // 000000197DAC: 7F3602FF 0000F074
	v_mov_b32_e32 v156, 0xf07c                                 // 000000197DB4: 7F3802FF 0000F07C
	v_mov_b32_e32 v157, 0xf084                                 // 000000197DBC: 7F3A02FF 0000F084
	v_mov_b32_e32 v158, 0xf08c                                 // 000000197DC4: 7F3C02FF 0000F08C
	v_mov_b32_e32 v159, 0xf094                                 // 000000197DCC: 7F3E02FF 0000F094
	v_mov_b32_e32 v160, 0xf09c                                 // 000000197DD4: 7F4002FF 0000F09C
	v_mov_b32_e32 v161, 0xf0a4                                 // 000000197DDC: 7F4202FF 0000F0A4
	v_mov_b32_e32 v162, 0xf0ac                                 // 000000197DE4: 7F4402FF 0000F0AC
	v_mov_b32_e32 v163, 0xf0b4                                 // 000000197DEC: 7F4602FF 0000F0B4
	v_mov_b32_e32 v164, 0xf0bc                                 // 000000197DF4: 7F4802FF 0000F0BC
	v_mov_b32_e32 v165, 0xf0c4                                 // 000000197DFC: 7F4A02FF 0000F0C4
	v_mov_b32_e32 v166, 0xf0cc                                 // 000000197E04: 7F4C02FF 0000F0CC
	v_mov_b32_e32 v167, 0xf0d4                                 // 000000197E0C: 7F4E02FF 0000F0D4
	v_mov_b32_e32 v168, 0xf0dc                                 // 000000197E14: 7F5002FF 0000F0DC
	v_mov_b32_e32 v169, 0xf0e4                                 // 000000197E1C: 7F5202FF 0000F0E4
	v_mov_b32_e32 v170, 0xf0ec                                 // 000000197E24: 7F5402FF 0000F0EC
	v_mov_b32_e32 v171, 0xf0f4                                 // 000000197E2C: 7F5602FF 0000F0F4
	s_mov_b32 s36, 0                                           // 000000197E34: BEA40080
	s_mov_b32 s28, 0x41800000                                  // 000000197E38: BE9C00FF 41800000
	s_mov_b32 s37, s36                                         // 000000197E40: BEA50024
	s_mov_b32 s38, s36                                         // 000000197E44: BEA60024
	s_mov_b32 s39, s36                                         // 000000197E48: BEA70024
	s_mov_b32 s40, s36                                         // 000000197E4C: BEA80024
	s_mov_b32 s41, s36                                         // 000000197E50: BEA90024
	s_mov_b32 s42, s36                                         // 000000197E54: BEAA0024
	s_mov_b32 s43, s36                                         // 000000197E58: BEAB0024
	s_mov_b32 s29, s36                                         // 000000197E5C: BE9D0024
	s_branch 4                                                 // 000000197E60: BFA00004 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x574>
	s_add_i32 s29, s29, 1                                      // 000000197E64: 811D811D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000197E68: BF870009
	s_cmp_eq_u32 s29, s66                                      // 000000197E6C: BF06421D
	s_cbranch_scc1 7843                                        // 000000197E70: BFA21EA3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8000>
	s_mul_i32 s0, s29, 0xc00                                   // 000000197E74: 9600FF1D 00000C00
	s_lshl_b32 s48, s29, 6                                     // 000000197E7C: 8430861D
	s_add_i32 s0, s64, s0                                      // 000000197E80: 81000040
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000197E84: BF870499
	s_ashr_i32 s1, s0, 31                                      // 000000197E88: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 000000197E8C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000197E90: BF870009
	s_add_u32 s0, s52, s0                                      // 000000197E94: 80000034
	s_addc_u32 s1, s53, s1                                     // 000000197E98: 82010135
	global_load_b32 v1, v107, s[0:1]                           // 000000197E9C: DC520000 0100006B
	s_waitcnt vmcnt(0)                                         // 000000197EA4: BF8903F7
	v_readfirstlane_b32 s47, v1                                // 000000197EA8: 7E5E0501
	s_and_saveexec_b32 s0, s4                                  // 000000197EAC: BE802004
	s_cbranch_execz 69                                         // 000000197EB0: BFA50045 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6c8>
	v_or_b32_e32 v1, s48, v0                                   // 000000197EB4: 38020030
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000197EB8: BF870091
	v_mad_u64_u32 v[1:2], null, v1, 48, s[2:3]                 // 000000197EBC: D6FE7C01 00096101
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000197EC4: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000197EC8: BF870091
	.long 0xd73c0001                                           // 000000197ECC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000197ED0: 02020282
	.long 0xd7006a01                                           // 000000197ED4: D7006A01
	v_cndmask_b32_e32 v1, s52, v1, vcc_lo                      // 000000197ED8: 02020234
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000197EDC: BF8700C1
	v_add_co_ci_u32_e64 v2, null, s53, v2, vcc_lo              // 000000197EE0: D5207C02 01AA0435
	global_load_b32 v1, v[1:2], off                            // 000000197EE8: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000197EF0: BF8903F7
	v_sub_f32_e32 v2, s47, v1                                  // 000000197EF4: 0804022F
	v_dual_mul_f32 v4, 0x3fb8aa3b, v1 :: v_dual_mul_f32 v3, 0x3fb8aa3b, v2// 000000197EF8: C8C602FF 040204FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000197F04: BF8701A1
	v_rndne_f32_e32 v8, v4                                     // 000000197F08: 7E104704
	v_fma_f32 v7, 0x3fb8aa3b, v1, -v4                          // 000000197F0C: D6130007 841202FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v2, -v3                          // 000000197F18: D6130005 840E04FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 000000197F24: 7E0C4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000197F28: BF870191
	v_dual_sub_f32 v4, v4, v8 :: v_dual_sub_f32 v3, v3, v6     // 000000197F2C: C94A1104 04020D03
	v_fmac_f32_e32 v5, 0x32a5705f, v2                          // 000000197F34: 560A04FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2                   // 000000197F3C: 7C3604FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000197F44: BF8701B2
	v_add_f32_e32 v3, v3, v5                                   // 000000197F48: 06060B03
	v_cvt_i32_f32_e32 v5, v6                                   // 000000197F4C: 7E0A1106
	v_cvt_i32_f32_e32 v6, v8                                   // 000000197F50: 7E0C1108
	v_exp_f32_e32 v3, v3                                       // 000000197F54: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000197F58: BF870095
	.long 0xd71c0003                                           // 000000197F5C: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000197F60: 02020B03
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 000000197F64: 02060680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 000000197F68: 7C3602FF C2CE8ED0
	v_fmac_f32_e32 v7, 0x32a5705f, v1                          // 000000197F70: 560E02FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000197F78: BF870091
	v_add_f32_e32 v4, v4, v7                                   // 000000197F7C: 06080F04
	v_exp_f32_e32 v4, v4                                       // 000000197F80: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000197F84: BF870095
	.long 0xd71c0004                                           // 000000197F88: D71C0004
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000197F8C: 02020D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 000000197F90: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2                   // 000000197F94: 7C3C04FF 42B17218
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo               // 000000197F9C: 020406FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 000000197FA4: 7C3C02FF 42B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 000000197FAC: BF870004
	v_cndmask_b32_e32 v1, 0x7f800000, v4, vcc_lo               // 000000197FB0: 020208FF 7F800000
	ds_store_b32 v120, v2                                      // 000000197FB8: D8340000 00000278
	ds_store_b32 v121, v1                                      // 000000197FC0: D8340000 00000179
	s_or_b32 exec_lo, exec_lo, s0                              // 000000197FC8: 8C7E007E
	s_mul_i32 s0, s29, 0x140000                                // 000000197FCC: 9600FF1D 00140000
	s_sub_i32 s9, s59, s48                                     // 000000197FD4: 8189303B
	s_mul_hi_u32 s1, s29, 0x140000                             // 000000197FD8: 9681FF1D 00140000
	s_add_u32 s0, s56, s0                                      // 000000197FE0: 80000038
	s_addc_u32 s1, s57, s1                                     // 000000197FE4: 82010139
	s_add_u32 s0, s0, s30                                      // 000000197FE8: 80001E00
	s_addc_u32 s1, s1, s31                                     // 000000197FEC: 82011F01
	.long 0xd7000011                                           // 000000197FF0: D7000011
	v_cndmask_b32_e32 v1, s0, v140, vcc_lo                     // 000000197FF4: 02031800
	s_delay_alu instid0(VALU_DEP_1)                            // 000000197FF8: BF870001
	v_add_co_ci_u32_e64 v64, null, s1, 0, s0                   // 000000197FFC: D5207C40 00010001
	s_mul_i32 s0, s29, 0x3000                                  // 000000198004: 9600FF1D 00003000
	s_mul_hi_u32 s1, s29, 0x3000                               // 00000019800C: 9681FF1D 00003000
	s_add_u32 s23, s60, s0                                     // 000000198014: 8017003C
	s_addc_u32 s22, s61, s1                                    // 000000198018: 8216013D
	.long 0xd7006a01                                           // 00000019801C: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v17, vcc_lo                  // 000000198020: 020222FF 00001000
	s_cmp_gt_i32 s9, 0                                         // 000000198028: BF028009
	v_add_co_ci_u32_e64 v2, null, 0, v64, vcc_lo               // 00000019802C: D5207C02 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198034: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000198038: BF870009
	s_and_b32 s0, vcc_lo, exec_lo                              // 00000019803C: 8B007E6A
	s_cselect_b32 s11, s22, s68                                // 000000198040: 980B4416
	s_cselect_b32 s10, s23, s67                                // 000000198044: 980A4317
	s_add_u32 s0, s23, 0xc0                                    // 000000198048: 8000FF17 000000C0
	s_addc_u32 s1, s22, 0                                      // 000000198050: 82018016
	v_dual_cndmask_b32 v2, v123, v2 :: v_dual_cndmask_b32 v1, v122, v1// 000000198054: CA52057B 0200037A
	.long 0xd7006a04                                           // 00000019805C: D7006A04
	v_cndmask_b32_e32 v1, 0x6000, v17, vcc_lo                  // 000000198060: 020222FF 00006000
	s_cmp_gt_i32 s9, 1                                         // 000000198068: BF028109
	v_add_co_ci_u32_e64 v3, null, 0, v64, vcc_lo               // 00000019806C: D5207C03 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198074: 986A80C1
	global_load_d16_b16 v1, v[1:2], off                        // 000000198078: DC820000 017C0001
	s_and_b32 s12, vcc_lo, exec_lo                             // 000000198080: 8B0C7E6A
	s_cselect_b32 s13, s1, s68                                 // 000000198084: 980D4401
	s_cselect_b32 s12, s0, s67                                 // 000000198088: 980C4300
	s_add_u32 s0, s23, 0x180                                   // 00000019808C: 8000FF17 00000180
	s_addc_u32 s1, s22, 0                                      // 000000198094: 82018016
	v_dual_cndmask_b32 v3, v123, v3 :: v_dual_cndmask_b32 v2, v122, v4// 000000198098: CA52077B 0302097A
	.long 0xd7006a05                                           // 0000001980A0: D7006A05
	v_cndmask_b32_e32 v1, 0xb000, v17, vcc_lo                  // 0000001980A4: 020222FF 0000B000
	s_cmp_gt_i32 s9, 2                                         // 0000001980AC: BF028209
	v_add_co_ci_u32_e64 v4, null, 0, v64, vcc_lo               // 0000001980B0: D5207C04 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001980B8: 986A80C1
	global_load_d16_b16 v2, v[2:3], off                        // 0000001980BC: DC820000 027C0002
	s_and_b32 s14, vcc_lo, exec_lo                             // 0000001980C4: 8B0E7E6A
	s_cselect_b32 s15, s1, s68                                 // 0000001980C8: 980F4401
	s_cselect_b32 s14, s0, s67                                 // 0000001980CC: 980E4300
	s_add_u32 s0, s23, 0x240                                   // 0000001980D0: 8000FF17 00000240
	s_addc_u32 s1, s22, 0                                      // 0000001980D8: 82018016
	v_dual_cndmask_b32 v4, v123, v4 :: v_dual_cndmask_b32 v3, v122, v5// 0000001980DC: CA52097B 04020B7A
	.long 0xd7006a06                                           // 0000001980E4: D7006A06
	v_cndmask_b32_e32 v1, 0x10000, v17, vcc_lo                 // 0000001980E8: 020222FF 00010000
	s_cmp_gt_i32 s9, 3                                         // 0000001980F0: BF028309
	v_add_co_ci_u32_e64 v5, null, 0, v64, vcc_lo               // 0000001980F4: D5207C05 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001980FC: 986A80C1
	global_load_d16_b16 v3, v[3:4], off                        // 000000198100: DC820000 037C0003
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198108: 8B317E6A
	s_cselect_b32 s50, s0, s67                                 // 00000019810C: 98324300
	.long 0xd7000008                                           // 000000198110: D7000008
	v_cndmask_b32_e32 v1, 0x15000, v17, vcc_lo                 // 000000198114: 020222FF 00015000
	s_cselect_b32 s51, s1, s68                                 // 00000019811C: 98334401
	s_add_u32 s1, s23, 0x300                                   // 000000198120: 8001FF17 00000300
	v_add_co_ci_u32_e64 v7, null, 0, v64, s0                   // 000000198128: D5207C07 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198130: 82008016
	s_cmp_gt_i32 s9, 4                                         // 000000198134: BF028409
	v_dual_cndmask_b32 v5, v123, v5 :: v_dual_cndmask_b32 v4, v122, v6// 000000198138: CA520B7B 05040D7A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198140: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000198144: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198148: 8B317E6A
	s_cselect_b32 s55, s0, s68                                 // 00000019814C: 98374400
	.long 0xd7000009                                           // 000000198150: D7000009
	v_cndmask_b32_e32 v1, 0x1a000, v17, vcc_lo                 // 000000198154: 020222FF 0001A000
	s_cselect_b32 s54, s1, s67                                 // 00000019815C: 98364301
	s_add_u32 s1, s23, 0x3c0                                   // 000000198160: 8001FF17 000003C0
	v_add_co_ci_u32_e64 v10, null, 0, v64, s0                  // 000000198168: D5207C0A 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198170: 82008016
	s_cmp_gt_i32 s9, 5                                         // 000000198174: BF028509
	v_dual_cndmask_b32 v7, v123, v7 :: v_dual_cndmask_b32 v6, v122, v8// 000000198178: CA520F7B 0706117A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198180: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000198184: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198188: 8B317E6A
	s_cselect_b32 s71, s0, s68                                 // 00000019818C: 98474400
	.long 0xd7000008                                           // 000000198190: D7000008
	v_cndmask_b32_e32 v1, 0x1f000, v17, vcc_lo                 // 000000198194: 020222FF 0001F000
	s_cselect_b32 s70, s1, s67                                 // 00000019819C: 98464301
	s_add_u32 s1, s23, 0x480                                   // 0000001981A0: 8001FF17 00000480
	v_add_co_ci_u32_e64 v11, null, 0, v64, s0                  // 0000001981A8: D5207C0B 00028080
	s_addc_u32 s0, s22, 0                                      // 0000001981B0: 82008016
	s_cmp_gt_i32 s9, 6                                         // 0000001981B4: BF028609
	v_dual_cndmask_b32 v10, v123, v10 :: v_dual_cndmask_b32 v9, v122, v9// 0000001981B8: CA52157B 0A08137A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001981C0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001981C4: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001981C8: 8B317E6A
	s_cselect_b32 s73, s0, s68                                 // 0000001981CC: 98494400
	.long 0xd700000d                                           // 0000001981D0: D700000D
	v_cndmask_b32_e32 v1, 0x24000, v17, vcc_lo                 // 0000001981D4: 020222FF 00024000
	s_cselect_b32 s72, s1, s67                                 // 0000001981DC: 98484301
	s_add_u32 s49, s23, 0x540                                  // 0000001981E0: 8031FF17 00000540
	v_add_co_ci_u32_e64 v14, null, 0, v64, s0                  // 0000001981E8: D5207C0E 00028080
	s_addc_u32 s0, s22, 0                                      // 0000001981F0: 82008016
	s_cmp_gt_i32 s9, 7                                         // 0000001981F4: BF028709
	v_dual_cndmask_b32 v12, v123, v11 :: v_dual_cndmask_b32 v11, v122, v8// 0000001981F8: CA52177B 0C0A117A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198200: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000198204: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 000000198208: 8B017E6A
	s_cselect_b32 s1, s0, s68                                  // 00000019820C: 98014400
	s_cselect_b32 s0, s49, s67                                 // 000000198210: 98004331
	s_add_u32 s49, s23, 0x600                                  // 000000198214: 8031FF17 00000600
	v_dual_cndmask_b32 v14, v123, v14 :: v_dual_cndmask_b32 v13, v122, v13// 00000019821C: CA521D7B 0E0C1B7A
	s_addc_u32 s69, s22, 0                                     // 000000198224: 82458016
	global_load_d16_b16 v8, v[4:5], off                        // 000000198228: DC820000 087C0004
	global_load_d16_b16 v7, v[6:7], off                        // 000000198230: DC820000 077C0006
	global_load_d16_b16 v6, v[9:10], off                       // 000000198238: DC820000 067C0009
	global_load_d16_b16 v5, v[11:12], off                      // 000000198240: DC820000 057C000B
	global_load_d16_b16 v4, v[13:14], off                      // 000000198248: DC820000 047C000D
	s_cmp_gt_i32 s9, 8                                         // 000000198250: BF028809
	.long 0xd7006a09                                           // 000000198254: D7006A09
	v_cndmask_b32_e32 v1, 0x29000, v17, vcc_lo                 // 000000198258: 020222FF 00029000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000198260: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v64, vcc_lo              // 000000198264: D5207C0A 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 00000019826C: 986A80C1
	s_clause 0x7                                               // 000000198270: BF850007
	global_load_b32 v73, v107, s[10:11]                        // 000000198274: DC520000 490A006B
	global_load_b32 v71, v107, s[12:13]                        // 00000019827C: DC520000 470C006B
	global_load_b32 v72, v107, s[14:15]                        // 000000198284: DC520000 480E006B
	global_load_b32 v67, v107, s[50:51]                        // 00000019828C: DC520000 4332006B
	global_load_b32 v68, v107, s[54:55]                        // 000000198294: DC520000 4436006B
	global_load_b32 v69, v107, s[70:71]                        // 00000019829C: DC520000 4546006B
	global_load_b32 v70, v107, s[72:73]                        // 0000001982A4: DC520000 4648006B
	global_load_b32 v66, v107, s[0:1]                          // 0000001982AC: DC520000 4200006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001982B4: 8B007E6A
	s_cselect_b32 s11, s69, s68                                // 0000001982B8: 980B4445
	s_cselect_b32 s10, s49, s67                                // 0000001982BC: 980A4331
	s_add_u32 s0, s23, 0x6c0                                   // 0000001982C0: 8000FF17 000006C0
	s_addc_u32 s1, s22, 0                                      // 0000001982C8: 82018016
	v_dual_cndmask_b32 v10, v123, v10 :: v_dual_cndmask_b32 v9, v122, v9// 0000001982CC: CA52157B 0A08137A
	.long 0xd7006a0c                                           // 0000001982D4: D7006A0C
	v_cndmask_b32_e32 v1, 0x2e000, v17, vcc_lo                 // 0000001982D8: 020222FF 0002E000
	s_cmp_gt_i32 s9, 9                                         // 0000001982E0: BF028909
	v_add_co_ci_u32_e64 v11, null, 0, v64, vcc_lo              // 0000001982E4: D5207C0B 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001982EC: 986A80C1
	global_load_d16_b16 v9, v[9:10], off                       // 0000001982F0: DC820000 097C0009
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001982F8: 8B0C7E6A
	s_cselect_b32 s13, s1, s68                                 // 0000001982FC: 980D4401
	s_cselect_b32 s12, s0, s67                                 // 000000198300: 980C4300
	s_add_u32 s0, s23, 0x780                                   // 000000198304: 8000FF17 00000780
	s_addc_u32 s1, s22, 0                                      // 00000019830C: 82018016
	v_dual_cndmask_b32 v11, v123, v11 :: v_dual_cndmask_b32 v10, v122, v12// 000000198310: CA52177B 0B0A197A
	.long 0xd7006a0d                                           // 000000198318: D7006A0D
	v_cndmask_b32_e32 v1, 0x33000, v17, vcc_lo                 // 00000019831C: 020222FF 00033000
	s_cmp_gt_i32 s9, 10                                        // 000000198324: BF028A09
	v_add_co_ci_u32_e64 v12, null, 0, v64, vcc_lo              // 000000198328: D5207C0C 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198330: 986A80C1
	global_load_d16_b16 v10, v[10:11], off                     // 000000198334: DC820000 0A7C000A
	s_and_b32 s14, vcc_lo, exec_lo                             // 00000019833C: 8B0E7E6A
	s_cselect_b32 s15, s1, s68                                 // 000000198340: 980F4401
	s_cselect_b32 s14, s0, s67                                 // 000000198344: 980E4300
	s_add_u32 s0, s23, 0x840                                   // 000000198348: 8000FF17 00000840
	s_addc_u32 s1, s22, 0                                      // 000000198350: 82018016
	v_dual_cndmask_b32 v12, v123, v12 :: v_dual_cndmask_b32 v11, v122, v13// 000000198354: CA52197B 0C0A1B7A
	.long 0xd7006a0e                                           // 00000019835C: D7006A0E
	v_cndmask_b32_e32 v1, 0x38000, v17, vcc_lo                 // 000000198360: 020222FF 00038000
	s_cmp_gt_i32 s9, 11                                        // 000000198368: BF028B09
	v_add_co_ci_u32_e64 v13, null, 0, v64, vcc_lo              // 00000019836C: D5207C0D 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198374: 986A80C1
	global_load_d16_b16 v11, v[11:12], off                     // 000000198378: DC820000 0B7C000B
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198380: 8B317E6A
	s_cselect_b32 s50, s0, s67                                 // 000000198384: 98324300
	.long 0xd7000010                                           // 000000198388: D7000010
	v_cndmask_b32_e32 v1, 0x3d000, v17, vcc_lo                 // 00000019838C: 020222FF 0003D000
	s_cselect_b32 s51, s1, s68                                 // 000000198394: 98334401
	s_add_u32 s1, s23, 0x900                                   // 000000198398: 8001FF17 00000900
	v_add_co_ci_u32_e64 v15, null, 0, v64, s0                  // 0000001983A0: D5207C0F 00028080
	s_addc_u32 s0, s22, 0                                      // 0000001983A8: 82008016
	s_cmp_gt_i32 s9, 12                                        // 0000001983AC: BF028C09
	v_dual_cndmask_b32 v13, v123, v13 :: v_dual_cndmask_b32 v12, v122, v14// 0000001983B0: CA521B7B 0D0C1D7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001983B8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001983BC: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001983C0: 8B317E6A
	s_cselect_b32 s55, s0, s68                                 // 0000001983C4: 98374400
	.long 0xd7000012                                           // 0000001983C8: D7000012
	v_cndmask_b32_e32 v1, 0x42000, v17, vcc_lo                 // 0000001983CC: 020222FF 00042000
	s_cselect_b32 s54, s1, s67                                 // 0000001983D4: 98364301
	s_add_u32 s1, s23, 0x9c0                                   // 0000001983D8: 8001FF17 000009C0
	v_add_co_ci_u32_e64 v19, null, 0, v64, s0                  // 0000001983E0: D5207C13 00028080
	s_addc_u32 s0, s22, 0                                      // 0000001983E8: 82008016
	s_cmp_gt_i32 s9, 13                                        // 0000001983EC: BF028D09
	v_dual_cndmask_b32 v15, v123, v15 :: v_dual_cndmask_b32 v14, v122, v16// 0000001983F0: CA521F7B 0F0E217A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001983F8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001983FC: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198400: 8B317E6A
	s_cselect_b32 s71, s0, s68                                 // 000000198404: 98474400
	.long 0xd7000010                                           // 000000198408: D7000010
	v_cndmask_b32_e32 v1, 0x47000, v17, vcc_lo                 // 00000019840C: 020222FF 00047000
	s_cselect_b32 s70, s1, s67                                 // 000000198414: 98464301
	s_add_u32 s1, s23, 0xa80                                   // 000000198418: 8001FF17 00000A80
	v_add_co_ci_u32_e64 v20, null, 0, v64, s0                  // 000000198420: D5207C14 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198428: 82008016
	s_cmp_gt_i32 s9, 14                                        // 00000019842C: BF028E09
	v_dual_cndmask_b32 v19, v123, v19 :: v_dual_cndmask_b32 v18, v122, v18// 000000198430: CA52277B 1312257A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198438: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000019843C: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198440: 8B317E6A
	s_cselect_b32 s73, s0, s68                                 // 000000198444: 98494400
	.long 0xd7000016                                           // 000000198448: D7000016
	v_cndmask_b32_e32 v1, 0x4c000, v17, vcc_lo                 // 00000019844C: 020222FF 0004C000
	s_cselect_b32 s72, s1, s67                                 // 000000198454: 98484301
	s_add_u32 s49, s23, 0xb40                                  // 000000198458: 8031FF17 00000B40
	v_add_co_ci_u32_e64 v23, null, 0, v64, s0                  // 000000198460: D5207C17 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198468: 82008016
	s_cmp_gt_i32 s9, 15                                        // 00000019846C: BF028F09
	v_cndmask_b32_e32 v21, v123, v20, vcc_lo                   // 000000198470: 022A297B
	v_cndmask_b32_e32 v20, v122, v16, vcc_lo                   // 000000198474: 0228217A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198478: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000019847C: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 000000198480: 8B017E6A
	s_cselect_b32 s1, s0, s68                                  // 000000198484: 98014400
	s_cselect_b32 s0, s49, s67                                 // 000000198488: 98004331
	s_add_u32 s49, s23, 0xc00                                  // 00000019848C: 8031FF17 00000C00
	v_dual_cndmask_b32 v23, v123, v23 :: v_dual_cndmask_b32 v22, v122, v22// 000000198494: CA522F7B 17162D7A
	s_addc_u32 s69, s22, 0                                     // 00000019849C: 82458016
	global_load_d16_b16 v16, v[12:13], off                     // 0000001984A0: DC820000 107C000C
	global_load_d16_b16 v15, v[14:15], off                     // 0000001984A8: DC820000 0F7C000E
	global_load_d16_b16 v14, v[18:19], off                     // 0000001984B0: DC820000 0E7C0012
	global_load_d16_b16 v12, v[20:21], off                     // 0000001984B8: DC820000 0C7C0014
	global_load_d16_b16 v13, v[22:23], off                     // 0000001984C0: DC820000 0D7C0016
	s_cmp_gt_i32 s9, 16                                        // 0000001984C8: BF029009
	.long 0xd7006a12                                           // 0000001984CC: D7006A12
	v_cndmask_b32_e32 v1, 0x51000, v17, vcc_lo                 // 0000001984D0: 020222FF 00051000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001984D8: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v64, vcc_lo              // 0000001984DC: D5207C13 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001984E4: 986A80C1
	s_clause 0x7                                               // 0000001984E8: BF850007
	global_load_b32 v78, v107, s[10:11]                        // 0000001984EC: DC520000 4E0A006B
	global_load_b32 v79, v107, s[12:13]                        // 0000001984F4: DC520000 4F0C006B
	global_load_b32 v80, v107, s[14:15]                        // 0000001984FC: DC520000 500E006B
	global_load_b32 v81, v107, s[50:51]                        // 000000198504: DC520000 5132006B
	global_load_b32 v77, v107, s[54:55]                        // 00000019850C: DC520000 4D36006B
	global_load_b32 v74, v107, s[70:71]                        // 000000198514: DC520000 4A46006B
	global_load_b32 v75, v107, s[72:73]                        // 00000019851C: DC520000 4B48006B
	global_load_b32 v76, v107, s[0:1]                          // 000000198524: DC520000 4C00006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 00000019852C: 8B007E6A
	s_cselect_b32 s11, s69, s68                                // 000000198530: 980B4445
	s_cselect_b32 s10, s49, s67                                // 000000198534: 980A4331
	s_add_u32 s0, s23, 0xcc0                                   // 000000198538: 8000FF17 00000CC0
	s_addc_u32 s1, s22, 0                                      // 000000198540: 82018016
	v_dual_cndmask_b32 v19, v123, v19 :: v_dual_cndmask_b32 v18, v122, v18// 000000198544: CA52277B 1312257A
	.long 0xd7006a15                                           // 00000019854C: D7006A15
	v_cndmask_b32_e32 v1, 0x56000, v17, vcc_lo                 // 000000198550: 020222FF 00056000
	s_cmp_gt_i32 s9, 17                                        // 000000198558: BF029109
	v_add_co_ci_u32_e64 v20, null, 0, v64, vcc_lo              // 00000019855C: D5207C14 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198564: 986A80C1
	global_load_d16_b16 v18, v[18:19], off                     // 000000198568: DC820000 127C0012
	s_and_b32 s12, vcc_lo, exec_lo                             // 000000198570: 8B0C7E6A
	s_cselect_b32 s13, s1, s68                                 // 000000198574: 980D4401
	s_cselect_b32 s12, s0, s67                                 // 000000198578: 980C4300
	s_add_u32 s0, s23, 0xd80                                   // 00000019857C: 8000FF17 00000D80
	s_addc_u32 s1, s22, 0                                      // 000000198584: 82018016
	v_dual_cndmask_b32 v20, v123, v20 :: v_dual_cndmask_b32 v19, v122, v21// 000000198588: CA52297B 14122B7A
	.long 0xd7006a16                                           // 000000198590: D7006A16
	v_cndmask_b32_e32 v1, 0x5b000, v17, vcc_lo                 // 000000198594: 020222FF 0005B000
	s_cmp_gt_i32 s9, 18                                        // 00000019859C: BF029209
	v_add_co_ci_u32_e64 v21, null, 0, v64, vcc_lo              // 0000001985A0: D5207C15 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001985A8: 986A80C1
	global_load_d16_b16 v19, v[19:20], off                     // 0000001985AC: DC820000 137C0013
	s_and_b32 s14, vcc_lo, exec_lo                             // 0000001985B4: 8B0E7E6A
	s_cselect_b32 s15, s1, s68                                 // 0000001985B8: 980F4401
	s_cselect_b32 s14, s0, s67                                 // 0000001985BC: 980E4300
	s_add_u32 s0, s23, 0xe40                                   // 0000001985C0: 8000FF17 00000E40
	s_addc_u32 s1, s22, 0                                      // 0000001985C8: 82018016
	v_dual_cndmask_b32 v21, v123, v21 :: v_dual_cndmask_b32 v20, v122, v22// 0000001985CC: CA522B7B 15142D7A
	.long 0xd7006a17                                           // 0000001985D4: D7006A17
	v_cndmask_b32_e32 v1, 0x60000, v17, vcc_lo                 // 0000001985D8: 020222FF 00060000
	s_cmp_gt_i32 s9, 19                                        // 0000001985E0: BF029309
	v_add_co_ci_u32_e64 v22, null, 0, v64, vcc_lo              // 0000001985E4: D5207C16 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001985EC: 986A80C1
	global_load_d16_b16 v20, v[20:21], off                     // 0000001985F0: DC820000 147C0014
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001985F8: 8B317E6A
	s_cselect_b32 s50, s0, s67                                 // 0000001985FC: 98324300
	.long 0xd7000019                                           // 000000198600: D7000019
	v_cndmask_b32_e32 v1, 0x65000, v17, vcc_lo                 // 000000198604: 020222FF 00065000
	s_cselect_b32 s51, s1, s68                                 // 00000019860C: 98334401
	s_add_u32 s1, s23, 0xf00                                   // 000000198610: 8001FF17 00000F00
	v_add_co_ci_u32_e64 v24, null, 0, v64, s0                  // 000000198618: D5207C18 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198620: 82008016
	s_cmp_gt_i32 s9, 20                                        // 000000198624: BF029409
	v_dual_cndmask_b32 v22, v123, v22 :: v_dual_cndmask_b32 v21, v122, v23// 000000198628: CA522D7B 16142F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198630: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000198634: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198638: 8B317E6A
	s_cselect_b32 s55, s0, s68                                 // 00000019863C: 98374400
	.long 0xd700001a                                           // 000000198640: D700001A
	v_cndmask_b32_e32 v1, 0x6a000, v17, vcc_lo                 // 000000198644: 020222FF 0006A000
	s_cselect_b32 s54, s1, s67                                 // 00000019864C: 98364301
	s_add_u32 s1, s23, 0xfc0                                   // 000000198650: 8001FF17 00000FC0
	v_add_co_ci_u32_e64 v27, null, 0, v64, s0                  // 000000198658: D5207C1B 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198660: 82008016
	s_cmp_gt_i32 s9, 21                                        // 000000198664: BF029509
	v_dual_cndmask_b32 v24, v123, v24 :: v_dual_cndmask_b32 v23, v122, v25// 000000198668: CA52317B 1816337A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198670: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000198674: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198678: 8B317E6A
	s_cselect_b32 s71, s0, s68                                 // 00000019867C: 98474400
	.long 0xd7000019                                           // 000000198680: D7000019
	v_cndmask_b32_e32 v1, 0x6f000, v17, vcc_lo                 // 000000198684: 020222FF 0006F000
	s_cselect_b32 s70, s1, s67                                 // 00000019868C: 98464301
	s_add_u32 s1, s23, 0x1080                                  // 000000198690: 8001FF17 00001080
	v_add_co_ci_u32_e64 v28, null, 0, v64, s0                  // 000000198698: D5207C1C 00028080
	s_addc_u32 s0, s22, 0                                      // 0000001986A0: 82008016
	s_cmp_gt_i32 s9, 22                                        // 0000001986A4: BF029609
	v_dual_cndmask_b32 v27, v123, v27 :: v_dual_cndmask_b32 v26, v122, v26// 0000001986A8: CA52377B 1B1A357A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001986B0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001986B4: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001986B8: 8B317E6A
	s_cselect_b32 s73, s0, s68                                 // 0000001986BC: 98494400
	.long 0xd700001e                                           // 0000001986C0: D700001E
	v_cndmask_b32_e32 v1, 0x74000, v17, vcc_lo                 // 0000001986C4: 020222FF 00074000
	s_cselect_b32 s72, s1, s67                                 // 0000001986CC: 98484301
	s_add_u32 s49, s23, 0x1140                                 // 0000001986D0: 8031FF17 00001140
	v_add_co_ci_u32_e64 v31, null, 0, v64, s0                  // 0000001986D8: D5207C1F 00028080
	s_addc_u32 s0, s22, 0                                      // 0000001986E0: 82008016
	s_cmp_gt_i32 s9, 23                                        // 0000001986E4: BF029709
	v_dual_cndmask_b32 v29, v123, v28 :: v_dual_cndmask_b32 v28, v122, v25// 0000001986E8: CA52397B 1D1C337A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001986F0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001986F4: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001986F8: 8B017E6A
	s_cselect_b32 s1, s0, s68                                  // 0000001986FC: 98014400
	s_cselect_b32 s0, s49, s67                                 // 000000198700: 98004331
	s_add_u32 s49, s23, 0x1200                                 // 000000198704: 8031FF17 00001200
	v_dual_cndmask_b32 v31, v123, v31 :: v_dual_cndmask_b32 v30, v122, v30// 00000019870C: CA523F7B 1F1E3D7A
	s_addc_u32 s69, s22, 0                                     // 000000198714: 82458016
	global_load_d16_b16 v25, v[21:22], off                     // 000000198718: DC820000 197C0015
	global_load_d16_b16 v24, v[23:24], off                     // 000000198720: DC820000 187C0017
	global_load_d16_b16 v23, v[26:27], off                     // 000000198728: DC820000 177C001A
	global_load_d16_b16 v22, v[28:29], off                     // 000000198730: DC820000 167C001C
	global_load_d16_b16 v21, v[30:31], off                     // 000000198738: DC820000 157C001E
	s_cmp_gt_i32 s9, 24                                        // 000000198740: BF029809
	.long 0xd7006a1a                                           // 000000198744: D7006A1A
	v_cndmask_b32_e32 v1, 0x79000, v17, vcc_lo                 // 000000198748: 020222FF 00079000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000198750: BF870001
	v_add_co_ci_u32_e64 v27, null, 0, v64, vcc_lo              // 000000198754: D5207C1B 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 00000019875C: 986A80C1
	s_clause 0x7                                               // 000000198760: BF850007
	global_load_b32 v89, v107, s[10:11]                        // 000000198764: DC520000 590A006B
	global_load_b32 v88, v107, s[12:13]                        // 00000019876C: DC520000 580C006B
	global_load_b32 v84, v107, s[14:15]                        // 000000198774: DC520000 540E006B
	global_load_b32 v85, v107, s[50:51]                        // 00000019877C: DC520000 5532006B
	global_load_b32 v86, v107, s[54:55]                        // 000000198784: DC520000 5636006B
	global_load_b32 v87, v107, s[70:71]                        // 00000019878C: DC520000 5746006B
	global_load_b32 v83, v107, s[72:73]                        // 000000198794: DC520000 5348006B
	global_load_b32 v82, v107, s[0:1]                          // 00000019879C: DC520000 5200006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001987A4: 8B007E6A
	s_cselect_b32 s11, s69, s68                                // 0000001987A8: 980B4445
	s_cselect_b32 s10, s49, s67                                // 0000001987AC: 980A4331
	s_add_u32 s0, s23, 0x12c0                                  // 0000001987B0: 8000FF17 000012C0
	s_addc_u32 s1, s22, 0                                      // 0000001987B8: 82018016
	v_dual_cndmask_b32 v27, v123, v27 :: v_dual_cndmask_b32 v26, v122, v26// 0000001987BC: CA52377B 1B1A357A
	.long 0xd7006a1d                                           // 0000001987C4: D7006A1D
	v_cndmask_b32_e32 v1, 0x7e000, v17, vcc_lo                 // 0000001987C8: 020222FF 0007E000
	s_cmp_gt_i32 s9, 25                                        // 0000001987D0: BF029909
	v_add_co_ci_u32_e64 v28, null, 0, v64, vcc_lo              // 0000001987D4: D5207C1C 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001987DC: 986A80C1
	global_load_d16_b16 v26, v[26:27], off                     // 0000001987E0: DC820000 1A7C001A
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001987E8: 8B0C7E6A
	s_cselect_b32 s13, s1, s68                                 // 0000001987EC: 980D4401
	s_cselect_b32 s12, s0, s67                                 // 0000001987F0: 980C4300
	s_add_u32 s0, s23, 0x1380                                  // 0000001987F4: 8000FF17 00001380
	s_addc_u32 s1, s22, 0                                      // 0000001987FC: 82018016
	v_dual_cndmask_b32 v28, v123, v28 :: v_dual_cndmask_b32 v27, v122, v29// 000000198800: CA52397B 1C1A3B7A
	.long 0xd7006a1e                                           // 000000198808: D7006A1E
	v_cndmask_b32_e32 v1, 0x83000, v17, vcc_lo                 // 00000019880C: 020222FF 00083000
	s_cmp_gt_i32 s9, 26                                        // 000000198814: BF029A09
	v_add_co_ci_u32_e64 v29, null, 0, v64, vcc_lo              // 000000198818: D5207C1D 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198820: 986A80C1
	global_load_d16_b16 v27, v[27:28], off                     // 000000198824: DC820000 1B7C001B
	s_and_b32 s14, vcc_lo, exec_lo                             // 00000019882C: 8B0E7E6A
	s_cselect_b32 s15, s1, s68                                 // 000000198830: 980F4401
	s_cselect_b32 s14, s0, s67                                 // 000000198834: 980E4300
	s_add_u32 s0, s23, 0x1440                                  // 000000198838: 8000FF17 00001440
	s_addc_u32 s1, s22, 0                                      // 000000198840: 82018016
	v_dual_cndmask_b32 v29, v123, v29 :: v_dual_cndmask_b32 v28, v122, v30// 000000198844: CA523B7B 1D1C3D7A
	.long 0xd7006a1f                                           // 00000019884C: D7006A1F
	v_cndmask_b32_e32 v1, 0x88000, v17, vcc_lo                 // 000000198850: 020222FF 00088000
	s_cmp_gt_i32 s9, 27                                        // 000000198858: BF029B09
	v_add_co_ci_u32_e64 v30, null, 0, v64, vcc_lo              // 00000019885C: D5207C1E 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198864: 986A80C1
	global_load_d16_b16 v28, v[28:29], off                     // 000000198868: DC820000 1C7C001C
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198870: 8B317E6A
	s_cselect_b32 s50, s0, s67                                 // 000000198874: 98324300
	.long 0xd7000021                                           // 000000198878: D7000021
	v_cndmask_b32_e32 v1, 0x8d000, v17, vcc_lo                 // 00000019887C: 020222FF 0008D000
	s_cselect_b32 s51, s1, s68                                 // 000000198884: 98334401
	s_add_u32 s1, s23, 0x1500                                  // 000000198888: 8001FF17 00001500
	v_add_co_ci_u32_e64 v32, null, 0, v64, s0                  // 000000198890: D5207C20 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198898: 82008016
	s_cmp_gt_i32 s9, 28                                        // 00000019889C: BF029C09
	v_dual_cndmask_b32 v30, v123, v30 :: v_dual_cndmask_b32 v29, v122, v31// 0000001988A0: CA523D7B 1E1C3F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001988A8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001988AC: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001988B0: 8B317E6A
	s_cselect_b32 s55, s0, s68                                 // 0000001988B4: 98374400
	.long 0xd7000022                                           // 0000001988B8: D7000022
	v_cndmask_b32_e32 v1, 0x92000, v17, vcc_lo                 // 0000001988BC: 020222FF 00092000
	s_cselect_b32 s54, s1, s67                                 // 0000001988C4: 98364301
	s_add_u32 s1, s23, 0x15c0                                  // 0000001988C8: 8001FF17 000015C0
	v_add_co_ci_u32_e64 v35, null, 0, v64, s0                  // 0000001988D0: D5207C23 00028080
	s_addc_u32 s0, s22, 0                                      // 0000001988D8: 82008016
	s_cmp_gt_i32 s9, 29                                        // 0000001988DC: BF029D09
	v_dual_cndmask_b32 v32, v123, v32 :: v_dual_cndmask_b32 v31, v122, v33// 0000001988E0: CA52417B 201E437A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001988E8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001988EC: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001988F0: 8B317E6A
	s_cselect_b32 s71, s0, s68                                 // 0000001988F4: 98474400
	.long 0xd7000021                                           // 0000001988F8: D7000021
	v_cndmask_b32_e32 v1, 0x97000, v17, vcc_lo                 // 0000001988FC: 020222FF 00097000
	s_cselect_b32 s70, s1, s67                                 // 000000198904: 98464301
	s_add_u32 s1, s23, 0x1680                                  // 000000198908: 8001FF17 00001680
	v_add_co_ci_u32_e64 v36, null, 0, v64, s0                  // 000000198910: D5207C24 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198918: 82008016
	s_cmp_gt_i32 s9, 30                                        // 00000019891C: BF029E09
	v_dual_cndmask_b32 v35, v123, v35 :: v_dual_cndmask_b32 v34, v122, v34// 000000198920: CA52477B 2322457A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198928: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000019892C: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198930: 8B317E6A
	s_cselect_b32 s73, s0, s68                                 // 000000198934: 98494400
	.long 0xd7000026                                           // 000000198938: D7000026
	v_cndmask_b32_e32 v1, 0x9c000, v17, vcc_lo                 // 00000019893C: 020222FF 0009C000
	s_cselect_b32 s72, s1, s67                                 // 000000198944: 98484301
	s_add_u32 s49, s23, 0x1740                                 // 000000198948: 8031FF17 00001740
	v_add_co_ci_u32_e64 v39, null, 0, v64, s0                  // 000000198950: D5207C27 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198958: 82008016
	s_cmp_gt_i32 s9, 31                                        // 00000019895C: BF029F09
	v_dual_cndmask_b32 v37, v123, v36 :: v_dual_cndmask_b32 v36, v122, v33// 000000198960: CA52497B 2524437A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198968: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000019896C: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 000000198970: 8B017E6A
	s_cselect_b32 s1, s0, s68                                  // 000000198974: 98014400
	s_cselect_b32 s0, s49, s67                                 // 000000198978: 98004331
	s_add_u32 s49, s23, 0x1800                                 // 00000019897C: 8031FF17 00001800
	v_dual_cndmask_b32 v39, v123, v39 :: v_dual_cndmask_b32 v38, v122, v38// 000000198984: CA524F7B 27264D7A
	s_addc_u32 s69, s22, 0                                     // 00000019898C: 82458016
	global_load_d16_b16 v33, v[29:30], off                     // 000000198990: DC820000 217C001D
	global_load_d16_b16 v32, v[31:32], off                     // 000000198998: DC820000 207C001F
	global_load_d16_b16 v31, v[34:35], off                     // 0000001989A0: DC820000 1F7C0022
	global_load_d16_b16 v29, v[36:37], off                     // 0000001989A8: DC820000 1D7C0024
	global_load_d16_b16 v30, v[38:39], off                     // 0000001989B0: DC820000 1E7C0026
	s_cmp_gt_i32 s9, 32                                        // 0000001989B8: BF02A009
	.long 0xd7006a22                                           // 0000001989BC: D7006A22
	v_cndmask_b32_e32 v1, 0xa1000, v17, vcc_lo                 // 0000001989C0: 020222FF 000A1000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001989C8: BF870001
	v_add_co_ci_u32_e64 v35, null, 0, v64, vcc_lo              // 0000001989CC: D5207C23 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001989D4: 986A80C1
	s_clause 0x7                                               // 0000001989D8: BF850007
	global_load_b32 v95, v107, s[10:11]                        // 0000001989DC: DC520000 5F0A006B
	global_load_b32 v96, v107, s[12:13]                        // 0000001989E4: DC520000 600C006B
	global_load_b32 v97, v107, s[14:15]                        // 0000001989EC: DC520000 610E006B
	global_load_b32 v94, v107, s[50:51]                        // 0000001989F4: DC520000 5E32006B
	global_load_b32 v90, v107, s[54:55]                        // 0000001989FC: DC520000 5A36006B
	global_load_b32 v91, v107, s[70:71]                        // 000000198A04: DC520000 5B46006B
	global_load_b32 v92, v107, s[72:73]                        // 000000198A0C: DC520000 5C48006B
	global_load_b32 v93, v107, s[0:1]                          // 000000198A14: DC520000 5D00006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 000000198A1C: 8B007E6A
	s_cselect_b32 s11, s69, s68                                // 000000198A20: 980B4445
	s_cselect_b32 s10, s49, s67                                // 000000198A24: 980A4331
	s_add_u32 s0, s23, 0x18c0                                  // 000000198A28: 8000FF17 000018C0
	s_addc_u32 s1, s22, 0                                      // 000000198A30: 82018016
	v_dual_cndmask_b32 v35, v123, v35 :: v_dual_cndmask_b32 v34, v122, v34// 000000198A34: CA52477B 2322457A
	.long 0xd7006a25                                           // 000000198A3C: D7006A25
	v_cndmask_b32_e32 v1, 0xa6000, v17, vcc_lo                 // 000000198A40: 020222FF 000A6000
	s_cmp_gt_i32 s9, 33                                        // 000000198A48: BF02A109
	v_add_co_ci_u32_e64 v36, null, 0, v64, vcc_lo              // 000000198A4C: D5207C24 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198A54: 986A80C1
	global_load_d16_b16 v34, v[34:35], off                     // 000000198A58: DC820000 227C0022
	s_and_b32 s12, vcc_lo, exec_lo                             // 000000198A60: 8B0C7E6A
	s_cselect_b32 s13, s1, s68                                 // 000000198A64: 980D4401
	s_cselect_b32 s12, s0, s67                                 // 000000198A68: 980C4300
	s_add_u32 s0, s23, 0x1980                                  // 000000198A6C: 8000FF17 00001980
	s_addc_u32 s1, s22, 0                                      // 000000198A74: 82018016
	v_dual_cndmask_b32 v36, v123, v36 :: v_dual_cndmask_b32 v35, v122, v37// 000000198A78: CA52497B 24224B7A
	.long 0xd7006a26                                           // 000000198A80: D7006A26
	v_cndmask_b32_e32 v1, 0xab000, v17, vcc_lo                 // 000000198A84: 020222FF 000AB000
	s_cmp_gt_i32 s9, 34                                        // 000000198A8C: BF02A209
	v_add_co_ci_u32_e64 v37, null, 0, v64, vcc_lo              // 000000198A90: D5207C25 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198A98: 986A80C1
	global_load_d16_b16 v35, v[35:36], off                     // 000000198A9C: DC820000 237C0023
	s_and_b32 s14, vcc_lo, exec_lo                             // 000000198AA4: 8B0E7E6A
	s_cselect_b32 s15, s1, s68                                 // 000000198AA8: 980F4401
	s_cselect_b32 s14, s0, s67                                 // 000000198AAC: 980E4300
	s_add_u32 s0, s23, 0x1a40                                  // 000000198AB0: 8000FF17 00001A40
	s_addc_u32 s1, s22, 0                                      // 000000198AB8: 82018016
	v_dual_cndmask_b32 v37, v123, v37 :: v_dual_cndmask_b32 v36, v122, v38// 000000198ABC: CA524B7B 25244D7A
	.long 0xd7006a27                                           // 000000198AC4: D7006A27
	v_cndmask_b32_e32 v1, 0xb0000, v17, vcc_lo                 // 000000198AC8: 020222FF 000B0000
	s_cmp_gt_i32 s9, 35                                        // 000000198AD0: BF02A309
	v_add_co_ci_u32_e64 v38, null, 0, v64, vcc_lo              // 000000198AD4: D5207C26 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198ADC: 986A80C1
	global_load_d16_b16 v36, v[36:37], off                     // 000000198AE0: DC820000 247C0024
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198AE8: 8B317E6A
	s_cselect_b32 s50, s0, s67                                 // 000000198AEC: 98324300
	.long 0xd7000029                                           // 000000198AF0: D7000029
	v_cndmask_b32_e32 v1, 0xb5000, v17, vcc_lo                 // 000000198AF4: 020222FF 000B5000
	s_cselect_b32 s51, s1, s68                                 // 000000198AFC: 98334401
	s_add_u32 s1, s23, 0x1b00                                  // 000000198B00: 8001FF17 00001B00
	v_add_co_ci_u32_e64 v40, null, 0, v64, s0                  // 000000198B08: D5207C28 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198B10: 82008016
	s_cmp_gt_i32 s9, 36                                        // 000000198B14: BF02A409
	v_dual_cndmask_b32 v38, v123, v38 :: v_dual_cndmask_b32 v37, v122, v39// 000000198B18: CA524D7B 26244F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198B20: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000198B24: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198B28: 8B317E6A
	s_cselect_b32 s55, s0, s68                                 // 000000198B2C: 98374400
	.long 0xd700002a                                           // 000000198B30: D700002A
	v_cndmask_b32_e32 v1, 0xba000, v17, vcc_lo                 // 000000198B34: 020222FF 000BA000
	s_cselect_b32 s54, s1, s67                                 // 000000198B3C: 98364301
	s_add_u32 s1, s23, 0x1bc0                                  // 000000198B40: 8001FF17 00001BC0
	v_add_co_ci_u32_e64 v43, null, 0, v64, s0                  // 000000198B48: D5207C2B 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198B50: 82008016
	s_cmp_gt_i32 s9, 37                                        // 000000198B54: BF02A509
	v_dual_cndmask_b32 v40, v123, v40 :: v_dual_cndmask_b32 v39, v122, v41// 000000198B58: CA52517B 2826537A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198B60: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000198B64: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198B68: 8B317E6A
	s_cselect_b32 s71, s0, s68                                 // 000000198B6C: 98474400
	.long 0xd7000029                                           // 000000198B70: D7000029
	v_cndmask_b32_e32 v1, 0xbf000, v17, vcc_lo                 // 000000198B74: 020222FF 000BF000
	s_cselect_b32 s70, s1, s67                                 // 000000198B7C: 98464301
	s_add_u32 s1, s23, 0x1c80                                  // 000000198B80: 8001FF17 00001C80
	v_add_co_ci_u32_e64 v44, null, 0, v64, s0                  // 000000198B88: D5207C2C 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198B90: 82008016
	s_cmp_gt_i32 s9, 38                                        // 000000198B94: BF02A609
	v_dual_cndmask_b32 v43, v123, v43 :: v_dual_cndmask_b32 v42, v122, v42// 000000198B98: CA52577B 2B2A557A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198BA0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000198BA4: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198BA8: 8B317E6A
	s_cselect_b32 s73, s0, s68                                 // 000000198BAC: 98494400
	.long 0xd700002e                                           // 000000198BB0: D700002E
	v_cndmask_b32_e32 v1, 0xc4000, v17, vcc_lo                 // 000000198BB4: 020222FF 000C4000
	s_cselect_b32 s72, s1, s67                                 // 000000198BBC: 98484301
	s_add_u32 s49, s23, 0x1d40                                 // 000000198BC0: 8031FF17 00001D40
	v_add_co_ci_u32_e64 v47, null, 0, v64, s0                  // 000000198BC8: D5207C2F 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198BD0: 82008016
	s_cmp_gt_i32 s9, 39                                        // 000000198BD4: BF02A709
	v_dual_cndmask_b32 v45, v123, v44 :: v_dual_cndmask_b32 v44, v122, v41// 000000198BD8: CA52597B 2D2C537A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198BE0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000198BE4: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 000000198BE8: 8B017E6A
	s_cselect_b32 s1, s0, s68                                  // 000000198BEC: 98014400
	s_cselect_b32 s0, s49, s67                                 // 000000198BF0: 98004331
	s_add_u32 s49, s23, 0x1e00                                 // 000000198BF4: 8031FF17 00001E00
	v_dual_cndmask_b32 v47, v123, v47 :: v_dual_cndmask_b32 v46, v122, v46// 000000198BFC: CA525F7B 2F2E5D7A
	s_addc_u32 s69, s22, 0                                     // 000000198C04: 82458016
	global_load_d16_b16 v41, v[37:38], off                     // 000000198C08: DC820000 297C0025
	global_load_d16_b16 v40, v[39:40], off                     // 000000198C10: DC820000 287C0027
	global_load_d16_b16 v39, v[42:43], off                     // 000000198C18: DC820000 277C002A
	global_load_d16_b16 v37, v[44:45], off                     // 000000198C20: DC820000 257C002C
	global_load_d16_b16 v38, v[46:47], off                     // 000000198C28: DC820000 267C002E
	s_cmp_gt_i32 s9, 40                                        // 000000198C30: BF02A809
	.long 0xd7006a2a                                           // 000000198C34: D7006A2A
	v_cndmask_b32_e32 v1, 0xc9000, v17, vcc_lo                 // 000000198C38: 020222FF 000C9000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000198C40: BF870001
	v_add_co_ci_u32_e64 v43, null, 0, v64, vcc_lo              // 000000198C44: D5207C2B 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198C4C: 986A80C1
	s_clause 0x7                                               // 000000198C50: BF850007
	global_load_b32 v105, v107, s[10:11]                       // 000000198C54: DC520000 690A006B
	global_load_b32 v101, v107, s[12:13]                       // 000000198C5C: DC520000 650C006B
	global_load_b32 v102, v107, s[14:15]                       // 000000198C64: DC520000 660E006B
	global_load_b32 v103, v107, s[50:51]                       // 000000198C6C: DC520000 6732006B
	global_load_b32 v104, v107, s[54:55]                       // 000000198C74: DC520000 6836006B
	global_load_b32 v100, v107, s[70:71]                       // 000000198C7C: DC520000 6446006B
	global_load_b32 v98, v107, s[72:73]                        // 000000198C84: DC520000 6248006B
	global_load_b32 v99, v107, s[0:1]                          // 000000198C8C: DC520000 6300006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 000000198C94: 8B007E6A
	s_cselect_b32 s11, s69, s68                                // 000000198C98: 980B4445
	s_cselect_b32 s10, s49, s67                                // 000000198C9C: 980A4331
	s_add_u32 s0, s23, 0x1ec0                                  // 000000198CA0: 8000FF17 00001EC0
	s_addc_u32 s1, s22, 0                                      // 000000198CA8: 82018016
	v_dual_cndmask_b32 v43, v123, v43 :: v_dual_cndmask_b32 v42, v122, v42// 000000198CAC: CA52577B 2B2A557A
	.long 0xd7006a2d                                           // 000000198CB4: D7006A2D
	v_cndmask_b32_e32 v1, 0xce000, v17, vcc_lo                 // 000000198CB8: 020222FF 000CE000
	s_cmp_gt_i32 s9, 41                                        // 000000198CC0: BF02A909
	v_add_co_ci_u32_e64 v44, null, 0, v64, vcc_lo              // 000000198CC4: D5207C2C 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198CCC: 986A80C1
	global_load_d16_b16 v42, v[42:43], off                     // 000000198CD0: DC820000 2A7C002A
	s_and_b32 s12, vcc_lo, exec_lo                             // 000000198CD8: 8B0C7E6A
	s_cselect_b32 s13, s1, s68                                 // 000000198CDC: 980D4401
	s_cselect_b32 s12, s0, s67                                 // 000000198CE0: 980C4300
	s_add_u32 s0, s23, 0x1f80                                  // 000000198CE4: 8000FF17 00001F80
	s_addc_u32 s1, s22, 0                                      // 000000198CEC: 82018016
	v_dual_cndmask_b32 v44, v123, v44 :: v_dual_cndmask_b32 v43, v122, v45// 000000198CF0: CA52597B 2C2A5B7A
	.long 0xd7006a2e                                           // 000000198CF8: D7006A2E
	v_cndmask_b32_e32 v1, 0xd3000, v17, vcc_lo                 // 000000198CFC: 020222FF 000D3000
	s_cmp_gt_i32 s9, 42                                        // 000000198D04: BF02AA09
	v_add_co_ci_u32_e64 v45, null, 0, v64, vcc_lo              // 000000198D08: D5207C2D 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198D10: 986A80C1
	global_load_d16_b16 v43, v[43:44], off                     // 000000198D14: DC820000 2B7C002B
	s_and_b32 s14, vcc_lo, exec_lo                             // 000000198D1C: 8B0E7E6A
	s_cselect_b32 s15, s1, s68                                 // 000000198D20: 980F4401
	s_cselect_b32 s14, s0, s67                                 // 000000198D24: 980E4300
	s_add_u32 s0, s23, 0x2040                                  // 000000198D28: 8000FF17 00002040
	s_addc_u32 s1, s22, 0                                      // 000000198D30: 82018016
	v_dual_cndmask_b32 v45, v123, v45 :: v_dual_cndmask_b32 v44, v122, v46// 000000198D34: CA525B7B 2D2C5D7A
	.long 0xd7006a2f                                           // 000000198D3C: D7006A2F
	v_cndmask_b32_e32 v1, 0xd8000, v17, vcc_lo                 // 000000198D40: 020222FF 000D8000
	s_cmp_gt_i32 s9, 43                                        // 000000198D48: BF02AB09
	v_add_co_ci_u32_e64 v46, null, 0, v64, vcc_lo              // 000000198D4C: D5207C2E 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198D54: 986A80C1
	global_load_d16_b16 v44, v[44:45], off                     // 000000198D58: DC820000 2C7C002C
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198D60: 8B317E6A
	s_cselect_b32 s50, s0, s67                                 // 000000198D64: 98324300
	.long 0xd7000031                                           // 000000198D68: D7000031
	v_cndmask_b32_e32 v1, 0xdd000, v17, vcc_lo                 // 000000198D6C: 020222FF 000DD000
	s_cselect_b32 s51, s1, s68                                 // 000000198D74: 98334401
	s_add_u32 s1, s23, 0x2100                                  // 000000198D78: 8001FF17 00002100
	v_add_co_ci_u32_e64 v48, null, 0, v64, s0                  // 000000198D80: D5207C30 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198D88: 82008016
	s_cmp_gt_i32 s9, 44                                        // 000000198D8C: BF02AC09
	v_dual_cndmask_b32 v46, v123, v46 :: v_dual_cndmask_b32 v45, v122, v47// 000000198D90: CA525D7B 2E2C5F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198D98: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000198D9C: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198DA0: 8B317E6A
	s_cselect_b32 s55, s0, s68                                 // 000000198DA4: 98374400
	.long 0xd7000032                                           // 000000198DA8: D7000032
	v_cndmask_b32_e32 v1, 0xe2000, v17, vcc_lo                 // 000000198DAC: 020222FF 000E2000
	s_cselect_b32 s54, s1, s67                                 // 000000198DB4: 98364301
	s_add_u32 s1, s23, 0x21c0                                  // 000000198DB8: 8001FF17 000021C0
	v_add_co_ci_u32_e64 v51, null, 0, v64, s0                  // 000000198DC0: D5207C33 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198DC8: 82008016
	s_cmp_gt_i32 s9, 45                                        // 000000198DCC: BF02AD09
	v_dual_cndmask_b32 v48, v123, v48 :: v_dual_cndmask_b32 v47, v122, v49// 000000198DD0: CA52617B 302E637A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198DD8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000198DDC: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198DE0: 8B317E6A
	s_cselect_b32 s71, s0, s68                                 // 000000198DE4: 98474400
	.long 0xd7000031                                           // 000000198DE8: D7000031
	v_cndmask_b32_e32 v1, 0xe7000, v17, vcc_lo                 // 000000198DEC: 020222FF 000E7000
	s_cselect_b32 s70, s1, s67                                 // 000000198DF4: 98464301
	s_add_u32 s1, s23, 0x2280                                  // 000000198DF8: 8001FF17 00002280
	v_add_co_ci_u32_e64 v52, null, 0, v64, s0                  // 000000198E00: D5207C34 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198E08: 82008016
	s_cmp_gt_i32 s9, 46                                        // 000000198E0C: BF02AE09
	v_dual_cndmask_b32 v51, v123, v51 :: v_dual_cndmask_b32 v50, v122, v50// 000000198E10: CA52677B 3332657A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198E18: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000198E1C: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198E20: 8B317E6A
	s_cselect_b32 s73, s0, s68                                 // 000000198E24: 98494400
	.long 0xd7000036                                           // 000000198E28: D7000036
	v_cndmask_b32_e32 v1, 0xec000, v17, vcc_lo                 // 000000198E2C: 020222FF 000EC000
	s_cselect_b32 s72, s1, s67                                 // 000000198E34: 98484301
	s_add_u32 s49, s23, 0x2340                                 // 000000198E38: 8031FF17 00002340
	v_add_co_ci_u32_e64 v55, null, 0, v64, s0                  // 000000198E40: D5207C37 00028080
	s_addc_u32 s0, s22, 0                                      // 000000198E48: 82008016
	s_cmp_gt_i32 s9, 47                                        // 000000198E4C: BF02AF09
	v_dual_cndmask_b32 v53, v123, v52 :: v_dual_cndmask_b32 v52, v122, v49// 000000198E50: CA52697B 3534637A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198E58: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000198E5C: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 000000198E60: 8B017E6A
	s_cselect_b32 s1, s0, s68                                  // 000000198E64: 98014400
	s_cselect_b32 s0, s49, s67                                 // 000000198E68: 98004331
	s_add_u32 s49, s23, 0x2400                                 // 000000198E6C: 8031FF17 00002400
	v_dual_cndmask_b32 v55, v123, v55 :: v_dual_cndmask_b32 v54, v122, v54// 000000198E74: CA526F7B 37366D7A
	s_addc_u32 s69, s22, 0                                     // 000000198E7C: 82458016
	global_load_d16_b16 v49, v[45:46], off                     // 000000198E80: DC820000 317C002D
	global_load_d16_b16 v48, v[47:48], off                     // 000000198E88: DC820000 307C002F
	global_load_d16_b16 v47, v[50:51], off                     // 000000198E90: DC820000 2F7C0032
	global_load_d16_b16 v46, v[52:53], off                     // 000000198E98: DC820000 2E7C0034
	global_load_d16_b16 v45, v[54:55], off                     // 000000198EA0: DC820000 2D7C0036
	s_cmp_gt_i32 s9, 48                                        // 000000198EA8: BF02B009
	.long 0xd7006a32                                           // 000000198EAC: D7006A32
	v_cndmask_b32_e32 v1, 0xf1000, v17, vcc_lo                 // 000000198EB0: 020222FF 000F1000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000198EB8: BF870001
	v_add_co_ci_u32_e64 v51, null, 0, v64, vcc_lo              // 000000198EBC: D5207C33 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198EC4: 986A80C1
	s_clause 0x7                                               // 000000198EC8: BF850007
	global_load_b32 v198, v107, s[10:11]                       // 000000198ECC: DC520000 C60A006B
	global_load_b32 v199, v107, s[12:13]                       // 000000198ED4: DC520000 C70C006B
	global_load_b32 v197, v107, s[14:15]                       // 000000198EDC: DC520000 C50E006B
	global_load_b32 v193, v107, s[50:51]                       // 000000198EE4: DC520000 C132006B
	global_load_b32 v194, v107, s[54:55]                       // 000000198EEC: DC520000 C236006B
	global_load_b32 v195, v107, s[70:71]                       // 000000198EF4: DC520000 C346006B
	global_load_b32 v196, v107, s[72:73]                       // 000000198EFC: DC520000 C448006B
	global_load_b32 v192, v107, s[0:1]                         // 000000198F04: DC520000 C000006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 000000198F0C: 8B007E6A
	s_cselect_b32 s11, s69, s68                                // 000000198F10: 980B4445
	s_cselect_b32 s10, s49, s67                                // 000000198F14: 980A4331
	s_add_u32 s0, s23, 0x24c0                                  // 000000198F18: 8000FF17 000024C0
	s_addc_u32 s1, s22, 0                                      // 000000198F20: 82018016
	v_dual_cndmask_b32 v51, v123, v51 :: v_dual_cndmask_b32 v50, v122, v50// 000000198F24: CA52677B 3332657A
	.long 0xd7006a35                                           // 000000198F2C: D7006A35
	v_cndmask_b32_e32 v1, 0xf6000, v17, vcc_lo                 // 000000198F30: 020222FF 000F6000
	s_cmp_gt_i32 s9, 49                                        // 000000198F38: BF02B109
	v_add_co_ci_u32_e64 v52, null, 0, v64, vcc_lo              // 000000198F3C: D5207C34 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198F44: 986A80C1
	global_load_d16_b16 v50, v[50:51], off                     // 000000198F48: DC820000 327C0032
	s_and_b32 s12, vcc_lo, exec_lo                             // 000000198F50: 8B0C7E6A
	s_cselect_b32 s13, s1, s68                                 // 000000198F54: 980D4401
	s_cselect_b32 s12, s0, s67                                 // 000000198F58: 980C4300
	s_add_u32 s0, s23, 0x2580                                  // 000000198F5C: 8000FF17 00002580
	s_addc_u32 s1, s22, 0                                      // 000000198F64: 82018016
	v_dual_cndmask_b32 v52, v123, v52 :: v_dual_cndmask_b32 v51, v122, v53// 000000198F68: CA52697B 34326B7A
	.long 0xd7006a36                                           // 000000198F70: D7006A36
	v_cndmask_b32_e32 v1, 0xfb000, v17, vcc_lo                 // 000000198F74: 020222FF 000FB000
	s_cmp_gt_i32 s9, 50                                        // 000000198F7C: BF02B209
	v_add_co_ci_u32_e64 v53, null, 0, v64, vcc_lo              // 000000198F80: D5207C35 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198F88: 986A80C1
	global_load_d16_b16 v51, v[51:52], off                     // 000000198F8C: DC820000 337C0033
	s_and_b32 s14, vcc_lo, exec_lo                             // 000000198F94: 8B0E7E6A
	s_cselect_b32 s15, s1, s68                                 // 000000198F98: 980F4401
	s_cselect_b32 s14, s0, s67                                 // 000000198F9C: 980E4300
	s_add_u32 s0, s23, 0x2640                                  // 000000198FA0: 8000FF17 00002640
	s_addc_u32 s1, s22, 0                                      // 000000198FA8: 82018016
	v_dual_cndmask_b32 v53, v123, v53 :: v_dual_cndmask_b32 v52, v122, v54// 000000198FAC: CA526B7B 35346D7A
	.long 0xd7006a37                                           // 000000198FB4: D7006A37
	v_cndmask_b32_e32 v1, 0x100000, v17, vcc_lo                // 000000198FB8: 020222FF 00100000
	s_cmp_gt_i32 s9, 51                                        // 000000198FC0: BF02B309
	v_add_co_ci_u32_e64 v54, null, 0, v64, vcc_lo              // 000000198FC4: D5207C36 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000198FCC: 986A80C1
	global_load_d16_b16 v52, v[52:53], off                     // 000000198FD0: DC820000 347C0034
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000198FD8: 8B317E6A
	s_cselect_b32 s50, s0, s67                                 // 000000198FDC: 98324300
	.long 0xd7000039                                           // 000000198FE0: D7000039
	v_cndmask_b32_e32 v1, 0x105000, v17, vcc_lo                // 000000198FE4: 020222FF 00105000
	s_cselect_b32 s51, s1, s68                                 // 000000198FEC: 98334401
	s_add_u32 s1, s23, 0x2700                                  // 000000198FF0: 8001FF17 00002700
	v_add_co_ci_u32_e64 v56, null, 0, v64, s0                  // 000000198FF8: D5207C38 00028080
	s_addc_u32 s0, s22, 0                                      // 000000199000: 82008016
	s_cmp_gt_i32 s9, 52                                        // 000000199004: BF02B409
	v_dual_cndmask_b32 v54, v123, v54 :: v_dual_cndmask_b32 v53, v122, v55// 000000199008: CA526D7B 36346F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000199010: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000199014: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000199018: 8B317E6A
	s_cselect_b32 s55, s0, s68                                 // 00000019901C: 98374400
	.long 0xd700003a                                           // 000000199020: D700003A
	v_cndmask_b32_e32 v1, 0x10a000, v17, vcc_lo                // 000000199024: 020222FF 0010A000
	s_cselect_b32 s54, s1, s67                                 // 00000019902C: 98364301
	s_add_u32 s1, s23, 0x27c0                                  // 000000199030: 8001FF17 000027C0
	v_add_co_ci_u32_e64 v59, null, 0, v64, s0                  // 000000199038: D5207C3B 00028080
	s_addc_u32 s0, s22, 0                                      // 000000199040: 82008016
	s_cmp_gt_i32 s9, 53                                        // 000000199044: BF02B509
	v_dual_cndmask_b32 v56, v123, v56 :: v_dual_cndmask_b32 v55, v122, v57// 000000199048: CA52717B 3836737A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000199050: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000199054: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000199058: 8B317E6A
	s_cselect_b32 s71, s0, s68                                 // 00000019905C: 98474400
	.long 0xd7000039                                           // 000000199060: D7000039
	v_cndmask_b32_e32 v1, 0x10f000, v17, vcc_lo                // 000000199064: 020222FF 0010F000
	s_cselect_b32 s70, s1, s67                                 // 00000019906C: 98464301
	s_add_u32 s1, s23, 0x2880                                  // 000000199070: 8001FF17 00002880
	v_add_co_ci_u32_e64 v60, null, 0, v64, s0                  // 000000199078: D5207C3C 00028080
	s_addc_u32 s0, s22, 0                                      // 000000199080: 82008016
	s_cmp_gt_i32 s9, 54                                        // 000000199084: BF02B609
	v_dual_cndmask_b32 v59, v123, v59 :: v_dual_cndmask_b32 v58, v122, v58// 000000199088: CA52777B 3B3A757A
	s_cselect_b32 vcc_lo, -1, 0                                // 000000199090: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000199094: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000199098: 8B317E6A
	s_cselect_b32 s73, s0, s68                                 // 00000019909C: 98494400
	.long 0xd700003e                                           // 0000001990A0: D700003E
	v_cndmask_b32_e32 v1, 0x114000, v17, vcc_lo                // 0000001990A4: 020222FF 00114000
	s_cselect_b32 s72, s1, s67                                 // 0000001990AC: 98484301
	s_add_u32 s49, s23, 0x2940                                 // 0000001990B0: 8031FF17 00002940
	v_add_co_ci_u32_e64 v63, null, 0, v64, s0                  // 0000001990B8: D5207C3F 00028080
	s_addc_u32 s0, s22, 0                                      // 0000001990C0: 82008016
	s_cmp_gt_i32 s9, 55                                        // 0000001990C4: BF02B709
	v_dual_cndmask_b32 v61, v123, v60 :: v_dual_cndmask_b32 v60, v122, v57// 0000001990C8: CA52797B 3D3C737A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001990D0: 986A80C1
	v_dual_cndmask_b32 v63, v123, v63 :: v_dual_cndmask_b32 v62, v122, v62// 0000001990D4: CA527F7B 3F3E7D7A
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001990DC: 8B017E6A
	global_load_d16_b16 v57, v[53:54], off                     // 0000001990E0: DC820000 397C0035
	global_load_d16_b16 v56, v[55:56], off                     // 0000001990E8: DC820000 387C0037
	global_load_d16_b16 v55, v[58:59], off                     // 0000001990F0: DC820000 377C003A
	global_load_d16_b16 v53, v[60:61], off                     // 0000001990F8: DC820000 357C003C
	global_load_d16_b16 v54, v[62:63], off                     // 000000199100: DC820000 367C003E
	s_cselect_b32 s1, s0, s68                                  // 000000199108: 98014400
	s_cselect_b32 s0, s49, s67                                 // 00000019910C: 98004331
	s_add_u32 s49, s23, 0x2a00                                 // 000000199110: 8031FF17 00002A00
	.long 0xd7006a3a                                           // 000000199118: D7006A3A
	v_cndmask_b32_e32 v1, 0x119000, v17, vcc_lo                // 00000019911C: 020222FF 00119000
	s_addc_u32 s69, s22, 0                                     // 000000199124: 82458016
	s_cmp_gt_i32 s9, 56                                        // 000000199128: BF02B809
	v_add_co_ci_u32_e64 v59, null, 0, v64, vcc_lo              // 00000019912C: D5207C3B 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 000000199134: 986A80C1
	s_clause 0x7                                               // 000000199138: BF850007
	global_load_b32 v204, v107, s[10:11]                       // 00000019913C: DC520000 CC0A006B
	global_load_b32 v205, v107, s[12:13]                       // 000000199144: DC520000 CD0C006B
	global_load_b32 v206, v107, s[14:15]                       // 00000019914C: DC520000 CE0E006B
	global_load_b32 v207, v107, s[50:51]                       // 000000199154: DC520000 CF32006B
	global_load_b32 v203, v107, s[54:55]                       // 00000019915C: DC520000 CB36006B
	global_load_b32 v200, v107, s[70:71]                       // 000000199164: DC520000 C846006B
	global_load_b32 v201, v107, s[72:73]                       // 00000019916C: DC520000 C948006B
	global_load_b32 v202, v107, s[0:1]                         // 000000199174: DC520000 CA00006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 00000019917C: 8B007E6A
	v_dual_cndmask_b32 v59, v123, v59 :: v_dual_cndmask_b32 v58, v122, v58// 000000199180: CA52777B 3B3A757A
	s_cselect_b32 s1, s69, s68                                 // 000000199188: 98014445
	s_cselect_b32 s0, s49, s67                                 // 00000019918C: 98004331
	s_add_u32 s10, s23, 0x2ac0                                 // 000000199190: 800AFF17 00002AC0
	.long 0xd7006a3d                                           // 000000199198: D7006A3D
	v_cndmask_b32_e32 v1, 0x11e000, v17, vcc_lo                // 00000019919C: 020222FF 0011E000
	s_addc_u32 s11, s22, 0                                     // 0000001991A4: 820B8016
	v_add_co_ci_u32_e64 v60, null, 0, v64, vcc_lo              // 0000001991A8: D5207C3C 01AA8080
	s_cmp_gt_i32 s9, 57                                        // 0000001991B0: BF02B909
	global_load_d16_b16 v58, v[58:59], off                     // 0000001991B4: DC820000 3A7C003A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001991BC: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001991C0: BF870009
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001991C4: 8B0C7E6A
	v_dual_cndmask_b32 v60, v123, v60 :: v_dual_cndmask_b32 v59, v122, v61// 0000001991C8: CA52797B 3C3A7B7A
	s_cselect_b32 s11, s11, s68                                // 0000001991D0: 980B440B
	s_cselect_b32 s10, s10, s67                                // 0000001991D4: 980A430A
	s_add_u32 s12, s23, 0x2b80                                 // 0000001991D8: 800CFF17 00002B80
	.long 0xd7006a3e                                           // 0000001991E0: D7006A3E
	v_cndmask_b32_e32 v1, 0x123000, v17, vcc_lo                // 0000001991E4: 020222FF 00123000
	s_addc_u32 s13, s22, 0                                     // 0000001991EC: 820D8016
	v_add_co_ci_u32_e64 v61, null, 0, v64, vcc_lo              // 0000001991F0: D5207C3D 01AA8080
	s_cmp_gt_i32 s9, 58                                        // 0000001991F8: BF02BA09
	global_load_d16_b16 v59, v[59:60], off                     // 0000001991FC: DC820000 3B7C003B
	s_cselect_b32 vcc_lo, -1, 0                                // 000000199204: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000199208: BF870009
	s_and_b32 s14, vcc_lo, exec_lo                             // 00000019920C: 8B0E7E6A
	v_dual_cndmask_b32 v61, v123, v61 :: v_dual_cndmask_b32 v60, v122, v62// 000000199210: CA527B7B 3D3C7D7A
	s_cselect_b32 s13, s13, s68                                // 000000199218: 980D440D
	s_cselect_b32 s12, s12, s67                                // 00000019921C: 980C430C
	s_add_u32 s14, s23, 0x2c40                                 // 000000199220: 800EFF17 00002C40
	.long 0xd7006a3e                                           // 000000199228: D7006A3E
	v_cndmask_b32_e32 v1, 0x128000, v17, vcc_lo                // 00000019922C: 020222FF 00128000
	s_addc_u32 s15, s22, 0                                     // 000000199234: 820F8016
	v_add_co_ci_u32_e64 v63, null, 0, v64, vcc_lo              // 000000199238: D5207C3F 01AA8080
	s_cmp_gt_i32 s9, 59                                        // 000000199240: BF02BB09
	global_load_d16_b16 v61, v[60:61], off                     // 000000199244: DC820000 3D7C003C
	s_cselect_b32 vcc_lo, -1, 0                                // 00000019924C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000199250: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 000000199254: 8B317E6A
	v_dual_cndmask_b32 v63, v123, v63 :: v_dual_cndmask_b32 v62, v122, v62// 000000199258: CA527F7B 3F3E7D7A
	s_cselect_b32 s15, s15, s68                                // 000000199260: 980F440F
	s_cselect_b32 s14, s14, s67                                // 000000199264: 980E430E
	s_add_u32 s49, s23, 0x2d00                                 // 000000199268: 8031FF17 00002D00
	.long 0xd7006a41                                           // 000000199270: D7006A41
	v_cndmask_b32_e32 v1, 0x12d000, v17, vcc_lo                // 000000199274: 020222FF 0012D000
	s_addc_u32 s50, s22, 0                                     // 00000019927C: 82328016
	v_add_co_ci_u32_e64 v116, null, 0, v64, vcc_lo             // 000000199280: D5207C74 01AA8080
	s_cmp_gt_i32 s9, 60                                        // 000000199288: BF02BC09
	global_load_d16_b16 v60, v[62:63], off                     // 00000019928C: DC820000 3C7C003E
	s_cselect_b32 vcc_lo, -1, 0                                // 000000199294: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000199298: BF870009
	s_and_b32 s51, vcc_lo, exec_lo                             // 00000019929C: 8B337E6A
	v_dual_cndmask_b32 v63, v123, v116 :: v_dual_cndmask_b32 v62, v122, v65// 0000001992A0: CA52E97B 3F3E837A
	s_cselect_b32 s51, s50, s68                                // 0000001992A8: 98334432
	s_cselect_b32 s50, s49, s67                                // 0000001992AC: 98324331
	s_add_u32 s49, s23, 0x2dc0                                 // 0000001992B0: 8031FF17 00002DC0
	.long 0xd7006a41                                           // 0000001992B8: D7006A41
	v_cndmask_b32_e32 v1, 0x132000, v17, vcc_lo                // 0000001992BC: 020222FF 00132000
	s_addc_u32 s54, s22, 0                                     // 0000001992C4: 82368016
	v_add_co_ci_u32_e64 v116, null, 0, v64, vcc_lo             // 0000001992C8: D5207C74 01AA8080
	s_cmp_gt_i32 s9, 61                                        // 0000001992D0: BF02BD09
	global_load_d16_b16 v62, v[62:63], off                     // 0000001992D4: DC820000 3E7C003E
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001992DC: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001992E0: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001992E4: 8B377E6A
	v_dual_cndmask_b32 v117, v123, v116 :: v_dual_cndmask_b32 v116, v122, v65// 0000001992E8: CA52E97B 7574837A
	s_cselect_b32 s55, s54, s68                                // 0000001992F0: 98374436
	s_cselect_b32 s54, s49, s67                                // 0000001992F4: 98364331
	s_add_u32 s49, s23, 0x2e80                                 // 0000001992F8: 8031FF17 00002E80
	.long 0xd7006a41                                           // 000000199300: D7006A41
	v_cndmask_b32_e32 v1, 0x137000, v17, vcc_lo                // 000000199304: 020222FF 00137000
	s_addc_u32 s69, s22, 0                                     // 00000019930C: 82458016
	v_add_co_ci_u32_e64 v173, null, 0, v64, vcc_lo             // 000000199310: D5207CAD 01AA8080
	s_cmp_gt_i32 s9, 62                                        // 000000199318: BF02BE09
	global_load_d16_b16 v63, v[116:117], off                   // 00000019931C: DC820000 3F7C0074
	s_cselect_b32 vcc_lo, -1, 0                                // 000000199324: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000199328: BF870009
	s_and_b32 s70, vcc_lo, exec_lo                             // 00000019932C: 8B467E6A
	v_cndmask_b32_e32 v117, v123, v173, vcc_lo                 // 000000199330: 02EB5B7B
	v_cndmask_b32_e32 v116, v122, v65, vcc_lo                  // 000000199334: 02E8837A
	s_cselect_b32 s71, s69, s68                                // 000000199338: 98474445
	s_cselect_b32 s70, s49, s67                                // 00000019933C: 98464331
	s_add_u32 s49, s23, 0x2f40                                 // 000000199340: 8031FF17 00002F40
	.long 0xd7006a11                                           // 000000199348: D7006A11
	v_cndmask_b32_e32 v1, 0x13c000, v17, vcc_lo                // 00000019934C: 020222FF 0013C000
	s_addc_u32 s22, s22, 0                                     // 000000199354: 82168016
	v_add_co_ci_u32_e64 v65, null, 0, v64, vcc_lo              // 000000199358: D5207C41 01AA8080
	s_cmp_gt_i32 s9, 63                                        // 000000199360: BF02BF09
	global_load_d16_b16 v64, v[116:117], off                   // 000000199364: DC820000 407C0074
	s_cselect_b32 vcc_lo, -1, 0                                // 00000019936C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000199370: BF870009
	s_and_b32 s9, vcc_lo, exec_lo                              // 000000199374: 8B097E6A
	v_cndmask_b32_e32 v117, v123, v65, vcc_lo                  // 000000199378: 02EA837B
	v_cndmask_b32_e32 v116, v122, v17, vcc_lo                  // 00000019937C: 02E8237A
	s_cselect_b32 s23, s22, s68                                // 000000199380: 98174416
	s_cselect_b32 s22, s49, s67                                // 000000199384: 98164331
	s_clause 0x7                                               // 000000199388: BF850007
	global_load_b32 v215, v107, s[0:1]                         // 00000019938C: DC520000 D700006B
	global_load_b32 v214, v107, s[10:11]                       // 000000199394: DC520000 D60A006B
	global_load_b32 v213, v107, s[12:13]                       // 00000019939C: DC520000 D50C006B
	global_load_b32 v210, v107, s[14:15]                       // 0000001993A4: DC520000 D20E006B
	global_load_b32 v211, v107, s[50:51]                       // 0000001993AC: DC520000 D332006B
	global_load_b32 v212, v107, s[54:55]                       // 0000001993B4: DC520000 D436006B
	global_load_b32 v209, v107, s[70:71]                       // 0000001993BC: DC520000 D146006B
	global_load_b32 v208, v107, s[22:23]                       // 0000001993C4: DC520000 D016006B
	global_load_d16_b16 v65, v[116:117], off                   // 0000001993CC: DC820000 417C0074
	.long 0x7e223880                                           // 0000001993D4: 7E223880
	s_cmp_gt_i32 s59, s48                                      // 0000001993D8: BF02303B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001993DC: BF890007
	s_barrier                                                  // 0000001993E0: BFBD0000
	buffer_gl0_inv                                             // 0000001993E4: E0AC0000 00000000
	s_cbranch_scc0 10                                          // 0000001993EC: BFA1000A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x1b18>
	ds_load_b32 v17, v107 offset:61440                         // 0000001993F0: D8D8F000 1100006B
	v_lshlrev_b32_e32 v1, 16, v1                               // 0000001993F8: 30020290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001993FC: BF8700A1
	v_mul_f32_e32 v1, v73, v1                                  // 000000199400: 10020349
	s_waitcnt lgkmcnt(0)                                       // 000000199404: BF89FC07
	v_mul_f32_e32 v1, v1, v17                                  // 000000199408: 10022301
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019940C: BF870001
	v_fma_mixlo_f16 v17, v1, s28, 0                            // 000000199410: CC210011 02003901
	v_lshlrev_b32_e32 v5, 16, v5                               // 000000199418: 300A0A90
	v_lshlrev_b32_e32 v1, 16, v2                               // 00000019941C: 30020490
	s_or_b32 s0, s48, 1                                        // 000000199420: 8C008130
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000199424: BF870119
	s_cmp_lt_i32 s0, s59                                       // 000000199428: BF043B00
	v_mul_f32_e32 v70, v70, v5                                 // 00000019942C: 108C0B46
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000199430: BF8701B2
	v_dual_mul_f32 v71, v71, v1 :: v_dual_lshlrev_b32 v2, 16, v3// 000000199434: C8E20347 47020690
	v_lshlrev_b32_e32 v3, 16, v8                               // 00000019943C: 30061090
	v_lshlrev_b32_e32 v5, 16, v13                              // 000000199440: 300A1A90
	v_dual_mul_f32 v72, v72, v2 :: v_dual_lshlrev_b32 v1, 16, v7// 000000199444: C8E20548 48000E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019944C: BF8701A3
	v_dual_mul_f32 v67, v67, v3 :: v_dual_lshlrev_b32 v2, 16, v6// 000000199450: C8E20743 43020C90
	v_lshlrev_b32_e32 v6, 16, v18                              // 000000199458: 300C2490
	v_dual_mul_f32 v68, v68, v1 :: v_dual_lshlrev_b32 v1, 16, v4// 00000019945C: C8E20344 44000890
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000199464: BF8701A3
	v_dual_mul_f32 v69, v69, v2 :: v_dual_lshlrev_b32 v4, 16, v16// 000000199468: C8E20545 45042090
	v_lshlrev_b32_e32 v2, 16, v10                              // 000000199470: 30041490
	v_dual_mul_f32 v66, v66, v1 :: v_dual_lshlrev_b32 v7, 16, v24// 000000199474: C8E20342 42063090
	v_lshlrev_b32_e32 v3, 16, v11                              // 00000019947C: 30061690
	v_lshlrev_b32_e32 v1, 16, v9                               // 000000199480: 30021290
	s_delay_alu instid0(VALU_DEP_4)                            // 000000199484: BF870004
	v_mul_f32_e32 v73, v79, v2                                 // 000000199488: 1092054F
	v_mul_f32_e32 v79, v81, v4                                 // 00000019948C: 109E0951
	v_lshlrev_b32_e32 v2, 16, v12                              // 000000199490: 30041890
	v_lshlrev_b32_e32 v8, 16, v23                              // 000000199494: 30102E90
	v_dual_mul_f32 v16, v78, v1 :: v_dual_lshlrev_b32 v1, 16, v15// 000000199498: C8E2034E 10001E90
	v_mul_f32_e32 v186, v86, v7                                // 0000001994A0: 11740F56
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001994A4: BF870223
	v_dual_mul_f32 v78, v80, v3 :: v_dual_mul_f32 v183, v87, v8// 0000001994A8: C8C60750 4EB61157
	v_mul_f32_e32 v3, v75, v2                                  // 0000001994B0: 1006054B
	v_mul_f32_e32 v15, v77, v1                                 // 0000001994B4: 101E034D
	v_lshlrev_b32_e32 v1, 16, v14                              // 0000001994B8: 30021C90
	v_lshlrev_b32_e32 v8, 16, v28                              // 0000001994BC: 30103890
	v_lshlrev_b32_e32 v10, 16, v63                             // 0000001994C0: 30147E90
	.long 0x7e12392d                                           // 0000001994C4: 7E12392D
	s_cselect_b32 s0, -1, 0                                    // 0000001994C8: 980080C1
	v_dual_mul_f32 v4, v74, v1 :: v_dual_mul_f32 v1, v89, v6   // 0000001994CC: C8C6034A 04000D59
	v_lshlrev_b32_e32 v6, 16, v25                              // 0000001994D4: 300C3290
	v_mul_f32_e32 v178, v97, v8                                // 0000001994D8: 11641161
	v_lshlrev_b32_e32 v8, 16, v30                              // 0000001994DC: 30103C90
	s_or_b32 s1, s48, 2                                        // 0000001994E0: 8C018230
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001994E4: BF870113
	v_mul_f32_e32 v188, v85, v6                                // 0000001994E8: 11780D55
	v_dual_mul_f32 v177, v93, v8 :: v_dual_lshlrev_b32 v6, 16, v26// 0000001994EC: C8E2115D B1063490
	v_lshlrev_b32_e32 v8, 16, v40                              // 0000001994F4: 30105090
	s_cmp_lt_i32 s1, s59                                       // 0000001994F8: BF043B01
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001994FC: BF870252
	v_mul_f32_e32 v184, v95, v6                                // 000000199500: 11700D5F
	v_dual_mul_f32 v2, v76, v5 :: v_dual_lshlrev_b32 v5, 16, v19// 000000199504: C8E20B4C 02042690
	v_lshlrev_b32_e32 v6, 16, v31                              // 00000019950C: 300C3E90
	v_mul_f32_e32 v104, v104, v8                               // 000000199510: 10D01168
	v_lshlrev_b32_e32 v8, 16, v43                              // 000000199514: 30105690
	v_dual_mul_f32 v190, v88, v5 :: v_dual_lshlrev_b32 v13, 16, v64// 000000199518: C8E20B58 BE0C8090
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000199520: BF870124
	v_dual_mul_f32 v180, v91, v6 :: v_dual_lshlrev_b32 v5, 16, v20// 000000199524: C8E20D5B B4042890
	v_lshlrev_b32_e32 v6, 16, v36                              // 00000019952C: 300C4890
	v_mul_f32_e32 v191, v84, v5                                // 000000199530: 117E0B54
	v_lshlrev_b32_e32 v5, 16, v22                              // 000000199534: 300A2C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000199538: BF870113
	v_mul_f32_e32 v174, v102, v6                               // 00000019953C: 115C0D66
	v_mul_f32_e32 v187, v83, v5                                // 000000199540: 11760B53
	v_lshlrev_b32_e32 v5, 16, v21                              // 000000199544: 300A2A90
	v_lshlrev_b32_e32 v6, 16, v38                              // 000000199548: 300C4C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019954C: BF8701A2
	v_mul_f32_e32 v189, v82, v5                                // 000000199550: 117A0B52
	v_lshlrev_b32_e32 v5, 16, v33                              // 000000199554: 300A4290
	v_dual_mul_f32 v117, v99, v6 :: v_dual_lshlrev_b32 v6, 16, v48// 000000199558: C8E20D63 75066090
	v_dual_mul_f32 v99, v199, v8 :: v_dual_lshlrev_b32 v8, 16, v46// 000000199560: C8E211C7 63085C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000199568: BF870123
	v_dual_mul_f32 v182, v94, v5 :: v_dual_lshlrev_b32 v5, 16, v32// 00000019956C: C8E20B5E B6044090
	v_mul_f32_e32 v26, v212, v10                               // 000000199574: 103415D4
	v_mul_f32_e32 v185, v90, v5                                // 000000199578: 11720B5A
	v_lshlrev_b32_e32 v5, 16, v34                              // 00000019957C: 300A4490
	v_lshlrev_b32_e32 v7, 16, v27                              // 000000199580: 300E3690
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000199584: BF870131
	v_dual_mul_f32 v176, v105, v5 :: v_dual_mul_f32 v181, v96, v7// 000000199588: C8C60B69 B0B40F60
	v_lshlrev_b32_e32 v7, 16, v29                              // 000000199590: 300E3A90
	v_lshlrev_b32_e32 v5, 16, v35                              // 000000199594: 300A4690
	v_mul_f32_e32 v179, v92, v7                                // 000000199598: 11660F5C
	v_lshlrev_b32_e32 v7, 16, v41                              // 00000019959C: 300E5290
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001995A0: BF8701A3
	v_mul_f32_e32 v175, v101, v5                               // 0000001995A4: 115E0B65
	v_lshlrev_b32_e32 v5, 16, v39                              // 0000001995A8: 300A4E90
	v_mul_f32_e32 v105, v103, v7                               // 0000001995AC: 10D20F67
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001995B0: BF870242
	v_dual_mul_f32 v116, v100, v5 :: v_dual_lshlrev_b32 v7, 16, v42// 0000001995B4: C8E20B64 74065490
	v_mul_f32_e32 v100, v194, v6                               // 0000001995BC: 10C80DC2
	v_mul_f32_e32 v42, v196, v8                                // 0000001995C0: 105411C4
	v_lshlrev_b32_e32 v8, 16, v57                              // 0000001995C4: 30107290
	v_mul_f32_e32 v102, v198, v7                               // 0000001995C8: 10CC0FC6
	v_lshlrev_b32_e32 v7, 16, v47                              // 0000001995CC: 300E5E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001995D0: BF870113
	v_dual_mul_f32 v27, v207, v8 :: v_dual_lshlrev_b32 v6, 16, v51// 0000001995D4: C8E211CF 1B066690
	v_mul_f32_e32 v45, v195, v7                                // 0000001995DC: 105A0FC3
	v_lshlrev_b32_e32 v7, 16, v52                              // 0000001995E0: 300E6890
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001995E4: BF870113
	v_dual_mul_f32 v43, v205, v6 :: v_dual_lshlrev_b32 v6, 16, v53// 0000001995E8: C8E20DCD 2B066A90
	v_mul_f32_e32 v41, v206, v7                                // 0000001995F0: 10520FCE
	v_lshlrev_b32_e32 v7, 16, v54                              // 0000001995F4: 300E6C90
	v_lshlrev_b32_e32 v8, 16, v58                              // 0000001995F8: 30107490
	v_add_nc_u32_e32 v196, s48, v126                           // 0000001995FC: 4B88FC30
	v_mul_f32_e32 v29, v201, v6                                // 000000199600: 103A0DC9
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000199604: BF8701C4
	v_mul_f32_e32 v28, v202, v7                                // 000000199608: 10380FCA
	v_lshlrev_b32_e32 v7, 16, v59                              // 00000019960C: 300E7690
	v_lshlrev_b32_e32 v5, 16, v37                              // 000000199610: 300A4A90
	v_dual_mul_f32 v25, v215, v8 :: v_dual_lshlrev_b32 v8, 16, v61// 000000199614: C8E211D7 19087A90
	v_mul_f32_e32 v46, v214, v7                                // 00000019961C: 105C0FD6
	s_delay_alu instid0(VALU_DEP_3)                            // 000000199620: BF870003
	v_mul_f32_e32 v173, v98, v5                                // 000000199624: 115A0B62
	v_lshlrev_b32_e32 v5, 16, v44                              // 000000199628: 300A5890
	v_lshlrev_b32_e32 v7, 16, v60                              // 00000019962C: 300E7890
	v_mul_f32_e32 v47, v213, v8                                // 000000199630: 105E11D5
	ds_load_2addr_b32 v[53:54], v149 offset1:1                 // 000000199634: D8DC0100 35000095
	v_mul_f32_e32 v103, v197, v5                               // 00000019963C: 10CE0BC5
	v_lshlrev_b32_e32 v5, 16, v49                              // 000000199640: 300A6290
	v_mul_f32_e32 v31, v210, v7                                // 000000199644: 103E0FD2
	ds_load_2addr_b32 v[7:8], v142 offset1:1                   // 000000199648: D8DC0100 0700008E
	v_mul_f32_e32 v101, v193, v5                               // 000000199650: 10CA0BC1
	v_lshlrev_b32_e32 v5, 16, v9                               // 000000199654: 300A1290
	v_lshlrev_b32_e32 v9, 16, v62                              // 000000199658: 30127C90
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019965C: BF870001
	v_mul_f32_e32 v30, v211, v9                                // 000000199660: 103C13D3
	ds_load_2addr_b32 v[9:10], v143 offset1:1                  // 000000199664: D8DC0100 0900008F
	ds_load_2addr_b32 v[11:12], v144 offset1:1                 // 00000019966C: D8DC0100 0B000090
	v_mul_f32_e32 v49, v192, v5                                // 000000199674: 10620BC0
	v_dual_mul_f32 v50, v209, v13 :: v_dual_lshlrev_b32 v5, 16, v50// 000000199678: C8E21BD1 32046490
	v_lshlrev_b32_e32 v13, 16, v65                             // 000000199680: 301A8290
	ds_load_2addr_b32 v[192:193], v151 offset1:1               // 000000199684: D8DC0100 C0000097
	ds_load_2addr_b32 v[194:195], v152 offset1:1               // 00000019968C: D8DC0100 C2000098
	s_waitcnt lgkmcnt(5)                                       // 000000199694: BF89FC57
	v_mul_f32_e32 v53, v190, v53                               // 000000199698: 106A6BBE
	v_dual_mul_f32 v48, v204, v5 :: v_dual_lshlrev_b32 v5, 16, v56// 00000019969C: C8E20BCC 30047090
	v_dual_mul_f32 v51, v208, v13 :: v_dual_mul_f32 v54, v191, v54// 0000001996A4: C8C61BD0 33366DBF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001996AC: BF870092
	v_dual_mul_f32 v32, v203, v5 :: v_dual_lshlrev_b32 v5, 16, v55// 0000001996B0: C8E20BCB 20046E90
	v_mul_f32_e32 v44, v200, v5                                // 0000001996B8: 10580BC8
	ds_load_2addr_b32 v[5:6], v141 offset1:1                   // 0000001996BC: D8DC0100 0500008D
	ds_load_2addr_b32 v[55:56], v150 offset1:1                 // 0000001996C4: D8DC0100 37000096
	s_waitcnt lgkmcnt(1)                                       // 0000001996CC: BF89FC17
	v_dual_mul_f32 v5, v71, v5 :: v_dual_mul_f32 v6, v72, v6   // 0000001996D0: C8C60B47 05060D48
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001996D8: BF870091
	v_fma_mixlo_f16 v5, v5, s28, 0                             // 0000001996DC: CC210005 02003905
	v_cndmask_b16 v17, 0, v5, s0                               // 0000001996E4: D65D4011 00020A80
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001996EC: BF870003
	v_fma_mixlo_f16 v5, v6, s28, 0                             // 0000001996F0: CC210005 02003906
	v_mul_f32_e32 v6, v67, v7                                  // 0000001996F8: 100C0F43
	s_cselect_b32 s0, -1, 0                                    // 0000001996FC: 980080C1
	s_or_b32 s1, s48, 3                                        // 000000199700: 8C018330
	v_mul_f32_e32 v7, v68, v8                                  // 000000199704: 100E1144
	s_cmp_lt_i32 s1, s59                                       // 000000199708: BF043B01
	v_cndmask_b16 v18, 0, v5, s0                               // 00000019970C: D65D0012 00020A80
	v_fma_mixlo_f16 v5, v6, s28, 0                             // 000000199714: CC210005 02003906
	s_cselect_b32 s0, -1, 0                                    // 00000019971C: 980080C1
	s_or_b32 s1, s48, 4                                        // 000000199720: 8C018430
	v_mul_f32_e32 v6, v69, v9                                  // 000000199724: 100C1345
	s_cmp_lt_i32 s1, s59                                       // 000000199728: BF043B01
	v_fma_mixhi_f16 v5, v7, s28, 0                             // 00000019972C: CC220005 02003907
	s_cselect_b32 s1, -1, 0                                    // 000000199734: 980180C1
	v_cndmask_b16 v18, 0, v5, s0                               // 000000199738: D65D4012 00020A80
	s_or_b32 s0, s48, 5                                        // 000000199740: 8C008530
	v_fma_mixlo_f16 v5, v6, s28, 0                             // 000000199744: CC210005 02003906
	v_mul_f32_e32 v6, v70, v10                                 // 00000019974C: 100C1546
	s_cmp_lt_i32 s0, s59                                       // 000000199750: BF043B00
	v_cndmask_b16 v19, 0, v5, s1                               // 000000199754: D65D1013 00060A80
	s_cselect_b32 s0, -1, 0                                    // 00000019975C: 980080C1
	s_or_b32 s1, s48, 6                                        // 000000199760: 8C018630
	v_cndmask_b16 v19, 0, v5, s0                               // 000000199764: D65D4013 00020A80
	v_fma_mixlo_f16 v5, v6, s28, 0                             // 00000019976C: CC210005 02003906
	v_dual_mul_f32 v10, v66, v11 :: v_dual_mul_f32 v11, v16, v12// 000000199774: C8C61742 0A0A1910
	s_cmp_lt_i32 s1, s59                                       // 00000019977C: BF043B01
	ds_load_2addr_b32 v[6:7], v145 offset1:1                   // 000000199780: D8DC0100 06000091
	ds_load_2addr_b32 v[8:9], v146 offset1:1                   // 000000199788: D8DC0100 08000092
	s_cselect_b32 s0, -1, 0                                    // 000000199790: 980080C1
	v_fma_mixhi_f16 v5, v11, s28, 0                            // 000000199794: CC220005 0200390B
	v_cndmask_b16 v20, 0, v5, s0                               // 00000019979C: D65D0014 00020A80
	v_fma_mixlo_f16 v5, v10, s28, 0                            // 0000001997A4: CC210005 0200390A
	ds_load_2addr_b32 v[10:11], v147 offset1:1                 // 0000001997AC: D8DC0100 0A000093
	ds_load_2addr_b32 v[12:13], v148 offset1:1                 // 0000001997B4: D8DC0100 0C000094
	s_or_b32 s1, s48, 7                                        // 0000001997BC: 8C018730
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001997C0: BF870009
	s_cmp_lt_i32 s1, s59                                       // 0000001997C4: BF043B01
	s_cselect_b32 s0, -1, 0                                    // 0000001997C8: 980080C1
	s_or_b32 s1, s48, 8                                        // 0000001997CC: 8C018830
	v_cndmask_b16 v20, 0, v5, s0                               // 0000001997D0: D65D4014 00020A80
	s_cmp_lt_i32 s1, s59                                       // 0000001997D8: BF043B01
	s_cselect_b32 s0, -1, 0                                    // 0000001997DC: 980080C1
	s_or_b32 s1, s48, 9                                        // 0000001997E0: 8C018930
	v_cndmask_b16 v21, 0, v5, s0                               // 0000001997E4: D65D1015 00020A80
	s_cmp_lt_i32 s1, s59                                       // 0000001997EC: BF043B01
	s_cselect_b32 s0, -1, 0                                    // 0000001997F0: 980080C1
	s_or_b32 s1, s48, 10                                       // 0000001997F4: 8C018A30
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001997F8: BF870009
	s_cmp_lt_i32 s1, s59                                       // 0000001997FC: BF043B01
	s_waitcnt lgkmcnt(1)                                       // 000000199800: BF89FC17
	v_mul_f32_e32 v4, v4, v10                                  // 000000199804: 10081504
	s_waitcnt lgkmcnt(0)                                       // 000000199808: BF89FC07
	v_mul_f32_e32 v52, v1, v13                                 // 00000019980C: 10681B01
	s_cselect_b32 s1, -1, 0                                    // 000000199810: 980180C1
	s_or_b32 s9, s48, 11                                       // 000000199814: 8C098B30
	v_mul_f32_e32 v3, v3, v11                                  // 000000199818: 10061703
	s_cmp_lt_i32 s9, s59                                       // 00000019981C: BF043B09
	v_fma_mixlo_f16 v52, v52, s28, 0                           // 000000199820: CC210034 02003934
	v_fma_mixhi_f16 v52, v53, s28, 0                           // 000000199828: CC220034 02003935
	v_fma_mixlo_f16 v53, v54, s28, 0                           // 000000199830: CC210035 02003936
	v_dual_mul_f32 v54, v188, v55 :: v_dual_mul_f32 v55, v186, v56// 000000199838: C8C66FBC 363671BA
	v_mul_f32_e32 v56, v187, v193                              // 000000199840: 107183BB
	v_fma_mixlo_f16 v4, v4, s28, 0                             // 000000199844: CC210004 02003904
	v_fma_mixlo_f16 v3, v3, s28, 0                             // 00000019984C: CC210003 02003903
	s_delay_alu instid0(VALU_DEP_4)                            // 000000199854: BF870004
	v_fma_mixhi_f16 v53, v54, s28, 0                           // 000000199858: CC220035 02003936
	v_fma_mixlo_f16 v54, v55, s28, 0                           // 000000199860: CC210036 02003937
	v_mul_f32_e32 v55, v183, v192                              // 000000199868: 106F81B7
	v_dual_mul_f32 v183, v189, v194 :: v_dual_mul_f32 v2, v2, v12// 00000019986C: C8C785BD B7021902
	ds_load_2addr_b32 v[186:187], v153 offset1:1               // 000000199874: D8DC0100 BA000099
	ds_load_2addr_b32 v[188:189], v154 offset1:1               // 00000019987C: D8DC0100 BC00009A
	v_fma_mixhi_f16 v54, v55, s28, 0                           // 000000199884: CC220036 02003937
	v_fma_mixlo_f16 v55, v56, s28, 0                           // 00000019988C: CC210037 02003938
	v_fma_mixhi_f16 v55, v183, s28, 0                          // 000000199894: CC220037 020039B7
	v_mul_f32_e32 v56, v184, v195                              // 00000019989C: 107187B8
	ds_load_2addr_b32 v[183:184], v155 offset1:1               // 0000001998A0: D8DC0100 B700009B
	ds_load_2addr_b32 v[190:191], v156 offset1:1               // 0000001998A8: D8DC0100 BE00009C
	v_dual_mul_f32 v5, v73, v6 :: v_dual_mul_f32 v6, v78, v7   // 0000001998B0: C8C60D49 05060F4E
	v_mul_f32_e32 v7, v79, v8                                  // 0000001998B8: 100E114F
	v_fma_mixhi_f16 v24, v2, s28, 0                            // 0000001998BC: CC220018 02003902
	v_fma_mixlo_f16 v56, v56, s28, 0                           // 0000001998C4: CC210038 02003938
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001998CC: BF8701B4
	v_fma_mixlo_f16 v5, v5, s28, 0                             // 0000001998D0: CC210005 02003905
	v_fma_mixhi_f16 v5, v6, s28, 0                             // 0000001998D8: CC220005 02003906
	v_mul_f32_e32 v6, v15, v9                                  // 0000001998E0: 100C130F
	v_cndmask_b16 v21, 0, v5, s0                               // 0000001998E4: D65D4015 00020A80
	v_fma_mixlo_f16 v5, v7, s28, 0                             // 0000001998EC: CC210005 02003907
	s_cselect_b32 s0, -1, 0                                    // 0000001998F4: 980080C1
	v_cndmask_b16 v22, 0, v5, s1                               // 0000001998F8: D65D1016 00060A80
	s_or_b32 s1, s48, 12                                       // 000000199900: 8C018C30
	s_delay_alu instid0(VALU_DEP_2)                            // 000000199904: BF870002
	v_cndmask_b16 v22, 0, v5, s0                               // 000000199908: D65D4016 00020A80
	v_fma_mixlo_f16 v5, v6, s28, 0                             // 000000199910: CC210005 02003906
	v_min_i32_e32 v6, s65, v196                                // 000000199918: 220D8841
	s_cmp_lt_i32 s1, s59                                       // 00000019991C: BF043B01
	s_waitcnt lgkmcnt(1)                                       // 000000199920: BF89FC17
	v_mul_f32_e32 v179, v179, v184                             // 000000199924: 116771B3
	s_cselect_b32 s0, -1, 0                                    // 000000199928: 980080C1
	s_or_b32 s1, s48, 13                                       // 00000019992C: 8C018D30
	v_cndmask_b16 v23, 0, v5, s0                               // 000000199930: D65D0017 00020A80
	v_mad_i64_i32 v[5:6], null, v6, 48, s[2:3]                 // 000000199938: D6FF7C05 00096106
	s_cmp_lt_i32 s1, s59                                       // 000000199940: BF043B01
	s_waitcnt lgkmcnt(0)                                       // 000000199944: BF89FC07
	v_mul_f32_e32 v177, v177, v190                             // 000000199948: 11637DB1
	s_cselect_b32 s0, -1, 0                                    // 00000019994C: 980080C1
	s_or_b32 s1, s48, 14                                       // 000000199950: 8C018E30
	v_cndmask_b16 v23, 0, v4, s0                               // 000000199954: D65D4017 00020880
	s_cmp_lt_i32 s1, s59                                       // 00000019995C: BF043B01
	v_fma_mixlo_f16 v177, v177, s28, 0                         // 000000199960: CC2100B1 020039B1
	.long 0xd73c0061                                           // 000000199968: D73C0061
	v_cndmask_b32_e32 v1, 8, v5, vcc_lo                        // 00000019996C: 02020A88
	s_cselect_b32 s0, -1, 0                                    // 000000199970: 980080C1
	s_or_b32 s1, s48, 15                                       // 000000199974: 8C018F30
	v_cndmask_b16 v24, 0, v3, s0                               // 000000199978: D65D0018 00020680
	s_cmp_lt_i32 s1, s59                                       // 000000199980: BF043B01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000199984: BF870092
	.long 0xd7006a05                                           // 000000199988: D7006A05
	v_cndmask_b32_e32 v1, s26, v97, vcc_lo                     // 00000019998C: 0202C21A
	v_add_co_ci_u32_e64 v6, null, s27, v98, vcc_lo             // 000000199990: D5207C06 01AAC41B
	s_clause 0xf                                               // 000000199998: BF85000F
	global_load_b128 v[89:92], v[5:6], off                     // 00000019999C: DC5E0000 597C0005
	global_load_b128 v[93:96], v[5:6], off offset:16           // 0000001999A4: DC5E0010 5D7C0005
	global_load_b128 v[81:84], v[5:6], off offset:32           // 0000001999AC: DC5E0020 517C0005
	global_load_b128 v[85:88], v[5:6], off offset:48           // 0000001999B4: DC5E0030 557C0005
	global_load_b128 v[73:76], v[5:6], off offset:64           // 0000001999BC: DC5E0040 497C0005
	global_load_b128 v[77:80], v[5:6], off offset:80           // 0000001999C4: DC5E0050 4D7C0005
	global_load_b128 v[65:68], v[5:6], off offset:96           // 0000001999CC: DC5E0060 417C0005
	global_load_b128 v[69:72], v[5:6], off offset:112          // 0000001999D4: DC5E0070 457C0005
	global_load_b128 v[57:60], v[5:6], off offset:128          // 0000001999DC: DC5E0080 397C0005
	global_load_b128 v[61:64], v[5:6], off offset:144          // 0000001999E4: DC5E0090 3D7C0005
	global_load_b128 v[33:36], v[5:6], off offset:160          // 0000001999EC: DC5E00A0 217C0005
	global_load_b128 v[37:40], v[5:6], off offset:176          // 0000001999F4: DC5E00B0 257C0005
	global_load_b128 v[9:12], v[5:6], off offset:192           // 0000001999FC: DC5E00C0 097C0005
	global_load_b128 v[13:16], v[5:6], off offset:208          // 000000199A04: DC5E00D0 0D7C0005
	global_load_b128 v[1:4], v[5:6], off offset:224            // 000000199A0C: DC5E00E0 017C0005
	global_load_b128 v[5:8], v[5:6], off offset:240            // 000000199A14: DC5E00F0 057C0005
	s_cselect_b32 s0, -1, 0                                    // 000000199A1C: 980080C1
	s_or_b32 s1, s48, 16                                       // 000000199A20: 8C019030
	v_cndmask_b16 v24, 0, v24, s0                              // 000000199A24: D65D5018 00023080
	s_cmp_lt_i32 s1, s59                                       // 000000199A2C: BF043B01
	ds_store_b128 v125, v[17:20]                               // 000000199A30: DB7C0000 0000117D
	ds_store_b128 v125, v[21:24] offset:16                     // 000000199A38: DB7C0010 0000157D
	s_cselect_b32 s0, -1, 0                                    // 000000199A40: 980080C1
	ds_load_2addr_b32 v[19:20], v158 offset1:1                 // 000000199A44: D8DC0100 1300009E
	v_cndmask_b16 v52, 0, v52, s0                              // 000000199A4C: D65D0034 00026880
	s_or_b32 s0, s48, 17                                       // 000000199A54: 8C009130
	v_mul_f32_e32 v181, v181, v186                             // 000000199A58: 116B75B5
	s_cmp_lt_i32 s0, s59                                       // 000000199A5C: BF043B00
	v_mul_f32_e32 v178, v178, v187                             // 000000199A60: 116577B2
	s_cselect_b32 s0, -1, 0                                    // 000000199A64: 980080C1
	s_or_b32 s1, s48, 18                                       // 000000199A68: 8C019230
	v_cndmask_b16 v52, 0, v52, s0                              // 000000199A6C: D65D5034 00026880
	s_cmp_lt_i32 s1, s59                                       // 000000199A74: BF043B01
	v_fma_mixhi_f16 v56, v181, s28, 0                          // 000000199A78: CC220038 020039B5
	s_cselect_b32 s0, -1, 0                                    // 000000199A80: 980080C1
	s_or_b32 s1, s48, 19                                       // 000000199A84: 8C019330
	v_cndmask_b16 v53, 0, v53, s0                              // 000000199A88: D65D0035 00026A80
	s_cmp_lt_i32 s1, s59                                       // 000000199A90: BF043B01
	v_mul_f32_e32 v182, v182, v188                             // 000000199A94: 116D79B6
	s_cselect_b32 s0, -1, 0                                    // 000000199A98: 980080C1
	s_or_b32 s1, s48, 20                                       // 000000199A9C: 8C019430
	v_cndmask_b16 v53, 0, v53, s0                              // 000000199AA0: D65D5035 00026A80
	s_cmp_lt_i32 s1, s59                                       // 000000199AA8: BF043B01
	ds_load_2addr_b32 v[21:22], v159 offset1:1                 // 000000199AAC: D8DC0100 1500009F
	ds_load_2addr_b32 v[23:24], v160 offset1:1                 // 000000199AB4: D8DC0100 170000A0
	s_cselect_b32 s1, -1, 0                                    // 000000199ABC: 980180C1
	s_or_b32 s9, s48, 21                                       // 000000199AC0: 8C099530
	v_cndmask_b16 v54, 0, v54, s1                              // 000000199AC4: D65D0036 00066C80
	s_cmp_lt_i32 s9, s59                                       // 000000199ACC: BF043B09
	v_mul_f32_e32 v17, v176, v191                              // 000000199AD0: 10237FB0
	s_cselect_b32 s0, -1, 0                                    // 000000199AD4: 980080C1
	s_or_b32 s9, s48, 22                                       // 000000199AD8: 8C099630
	v_cndmask_b16 v54, 0, v54, s0                              // 000000199ADC: D65D5036 00026C80
	s_cmp_lt_i32 s9, s59                                       // 000000199AE4: BF043B09
	v_fma_mixlo_f16 v17, v17, s28, 0                           // 000000199AE8: CC210011 02003911
	s_cselect_b32 s1, -1, 0                                    // 000000199AF0: 980180C1
	s_or_b32 s9, s48, 23                                       // 000000199AF4: 8C099730
	v_cndmask_b16 v55, 0, v55, s1                              // 000000199AF8: D65D0037 00066E80
	s_cmp_lt_i32 s9, s59                                       // 000000199B00: BF043B09
	s_waitcnt lgkmcnt(2)                                       // 000000199B04: BF89FC27
	v_mul_f32_e32 v20, v104, v20                               // 000000199B08: 10282968
	s_cselect_b32 s0, -1, 0                                    // 000000199B0C: 980080C1
	s_or_b32 s9, s48, 24                                       // 000000199B10: 8C099830
	v_cndmask_b16 v55, 0, v55, s0                              // 000000199B14: D65D5037 00026E80
	s_cmp_lt_i32 s9, s59                                       // 000000199B1C: BF043B09
	v_cmp_le_i32_e32 vcc_lo, s59, v196                         // 000000199B20: 7C87883B
	s_cselect_b32 s0, -1, 0                                    // 000000199B24: 980080C1
	s_or_b32 s1, s48, 25                                       // 000000199B28: 8C019930
	v_cndmask_b16 v181, 0, v56, s0                             // 000000199B2C: D65D00B5 00027080
	s_cmp_lt_i32 s1, s59                                       // 000000199B34: BF043B01
	v_fma_mixlo_f16 v56, v178, s28, 0                          // 000000199B38: CC210038 020039B2
	s_cselect_b32 s1, -1, 0                                    // 000000199B40: 980180C1
	s_or_b32 s9, s48, 26                                       // 000000199B44: 8C099A30
	v_mul_f32_e32 v178, v185, v189                             // 000000199B48: 11657BB9
	s_cmp_lt_i32 s9, s59                                       // 000000199B4C: BF043B09
	v_cndmask_b16 v181, 0, v56, s1                             // 000000199B50: D65D50B5 00067080
	s_cselect_b32 s0, -1, 0                                    // 000000199B58: 980080C1
	s_or_b32 s9, s48, 27                                       // 000000199B5C: 8C099B30
	v_fma_mixhi_f16 v56, v182, s28, 0                          // 000000199B60: CC220038 020039B6
	s_cmp_lt_i32 s9, s59                                       // 000000199B68: BF043B09
	v_cndmask_b16 v182, 0, v56, s0                             // 000000199B6C: D65D00B6 00027080
	s_cselect_b32 s1, -1, 0                                    // 000000199B74: 980180C1
	s_or_b32 s9, s48, 28                                       // 000000199B78: 8C099C30
	v_fma_mixlo_f16 v56, v178, s28, 0                          // 000000199B7C: CC210038 020039B2
	v_mul_f32_e32 v178, v180, v183                             // 000000199B84: 11656FB4
	s_cmp_lt_i32 s9, s59                                       // 000000199B88: BF043B09
	v_cndmask_b16 v182, 0, v56, s1                             // 000000199B8C: D65D50B6 00067080
	s_cselect_b32 s0, -1, 0                                    // 000000199B94: 980080C1
	v_fma_mixhi_f16 v56, v179, s28, 0                          // 000000199B98: CC220038 020039B3
	v_cndmask_b16 v183, 0, v56, s0                             // 000000199BA0: D65D00B7 00027080
	v_fma_mixlo_f16 v56, v178, s28, 0                          // 000000199BA8: CC210038 020039B2
	ds_load_2addr_b32 v[178:179], v157 offset1:1               // 000000199BB0: D8DC0100 B200009D
	s_or_b32 s9, s48, 29                                       // 000000199BB8: 8C099D30
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000199BBC: BF870009
	s_cmp_lt_i32 s9, s59                                       // 000000199BC0: BF043B09
	s_cselect_b32 s0, -1, 0                                    // 000000199BC4: 980080C1
	s_or_b32 s1, s48, 30                                       // 000000199BC8: 8C019E30
	v_cndmask_b16 v183, 0, v56, s0                             // 000000199BCC: D65D40B7 00027080
	s_cmp_lt_i32 s1, s59                                       // 000000199BD4: BF043B01
	s_cselect_b32 s1, -1, 0                                    // 000000199BD8: 980180C1
	s_or_b32 s9, s48, 31                                       // 000000199BDC: 8C099F30
	v_cndmask_b16 v184, 0, v56, s1                             // 000000199BE0: D65D10B8 00067080
	s_cmp_lt_i32 s9, s59                                       // 000000199BE8: BF043B09
	s_cselect_b32 s0, -1, 0                                    // 000000199BEC: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000199BF0: BF870009
	v_cndmask_b16 v184, 0, v177, s0                            // 000000199BF4: D65D40B8 00036280
	s_or_b32 s0, s48, 32                                       // 000000199BFC: 8C00A030
	ds_store_b128 v125, v[52:55] offset:32                     // 000000199C00: DB7C0020 0000347D
	ds_store_b128 v125, v[181:184] offset:48                   // 000000199C08: DB7C0030 0000B57D
	s_cmp_lt_i32 s0, s59                                       // 000000199C10: BF043B00
	s_waitcnt lgkmcnt(2)                                       // 000000199C14: BF89FC27
	v_mul_f32_e32 v18, v175, v178                              // 000000199C18: 102565AF
	s_cselect_b32 s0, -1, 0                                    // 000000199C1C: 980080C1
	v_mul_f32_e32 v19, v105, v19                               // 000000199C20: 10262769
	v_cndmask_b16 v17, 0, v17, s0                              // 000000199C24: D65D0011 00022280
	s_or_b32 s0, s48, 33                                       // 000000199C2C: 8C00A130
	v_mul_f32_e32 v52, v174, v179                              // 000000199C30: 106967AE
	s_cmp_lt_i32 s0, s59                                       // 000000199C34: BF043B00
	v_fma_mixhi_f16 v17, v18, s28, 0                           // 000000199C38: CC220011 02003912
	s_cselect_b32 s0, -1, 0                                    // 000000199C40: 980080C1
	s_or_b32 s1, s48, 34                                       // 000000199C44: 8C01A230
	v_fma_mixhi_f16 v18, v19, s28, 0                           // 000000199C48: CC220012 02003913
	s_cmp_lt_i32 s1, s59                                       // 000000199C50: BF043B01
	v_fma_mixlo_f16 v19, v20, s28, 0                           // 000000199C54: CC210013 02003914
	v_dual_mul_f32 v20, v116, v21 :: v_dual_mul_f32 v21, v173, v22// 000000199C5C: C8C62B74 14142DAD
	v_fma_mixlo_f16 v18, v52, s28, 0                           // 000000199C64: CC210012 02003934
	v_cndmask_b16 v17, 0, v17, s0                              // 000000199C6C: D65D5011 00022280
	s_cselect_b32 s0, -1, 0                                    // 000000199C74: 980080C1
	s_or_b32 s1, s48, 35                                       // 000000199C78: 8C01A330
	ds_load_2addr_b32 v[52:53], v161 offset1:1                 // 000000199C7C: D8DC0100 340000A1
	s_cmp_lt_i32 s1, s59                                       // 000000199C84: BF043B01
	v_fma_mixhi_f16 v19, v20, s28, 0                           // 000000199C88: CC220013 02003914
	v_mul_f32_e32 v22, v117, v23                               // 000000199C90: 102C2F75
	v_fma_mixlo_f16 v20, v21, s28, 0                           // 000000199C94: CC210014 02003915
	v_mul_f32_e32 v21, v102, v24                               // 000000199C9C: 102A3166
	ds_load_2addr_b32 v[23:24], v162 offset1:1                 // 000000199CA0: D8DC0100 170000A2
	v_cndmask_b16 v18, 0, v18, s0                              // 000000199CA8: D65D0012 00022480
	s_cselect_b32 s0, -1, 0                                    // 000000199CB0: 980080C1
	s_or_b32 s1, s48, 36                                       // 000000199CB4: 8C01A430
	ds_load_2addr_b32 v[54:55], v163 offset1:1                 // 000000199CB8: D8DC0100 360000A3
	ds_load_2addr_b32 v[104:105], v164 offset1:1               // 000000199CC0: D8DC0100 680000A4
	s_cmp_lt_i32 s1, s59                                       // 000000199CC8: BF043B01
	v_cndmask_b16 v18, 0, v18, s0                              // 000000199CCC: D65D5012 00022480
	s_cselect_b32 s1, -1, 0                                    // 000000199CD4: 980180C1
	s_or_b32 s9, s48, 37                                       // 000000199CD8: 8C09A530
	v_cndmask_b16 v19, 0, v19, s1                              // 000000199CDC: D65D0013 00062680
	s_cmp_lt_i32 s9, s59                                       // 000000199CE4: BF043B09
	v_fma_mixhi_f16 v20, v22, s28, 0                           // 000000199CE8: CC220014 02003916
	s_cselect_b32 s0, -1, 0                                    // 000000199CF0: 980080C1
	s_or_b32 s9, s48, 38                                       // 000000199CF4: 8C09A630
	v_cndmask_b16 v19, 0, v19, s0                              // 000000199CF8: D65D5013 00022680
	s_cmp_lt_i32 s9, s59                                       // 000000199D00: BF043B09
	v_fma_mixlo_f16 v21, v21, s28, 0                           // 000000199D04: CC210015 02003915
	s_cselect_b32 s1, -1, 0                                    // 000000199D0C: 980180C1
	s_or_b32 s9, s48, 39                                       // 000000199D10: 8C09A730
	v_cndmask_b16 v20, 0, v20, s1                              // 000000199D14: D65D0014 00062880
	s_cmp_lt_i32 s9, s59                                       // 000000199D1C: BF043B09
	s_waitcnt lgkmcnt(3)                                       // 000000199D20: BF89FC37
	v_mul_f32_e32 v22, v99, v52                                // 000000199D24: 102C6963
	s_cselect_b32 s0, -1, 0                                    // 000000199D28: 980080C1
	s_or_b32 s1, s48, 40                                       // 000000199D2C: 8C01A830
	s_waitcnt lgkmcnt(2)                                       // 000000199D30: BF89FC27
	v_mul_f32_e32 v23, v101, v23                               // 000000199D34: 102E2F65
	s_cmp_lt_i32 s1, s59                                       // 000000199D38: BF043B01
	v_mul_f32_e32 v24, v100, v24                               // 000000199D3C: 10303164
	v_cndmask_b16 v20, 0, v20, s0                              // 000000199D40: D65D5014 00022880
	s_cselect_b32 s0, -1, 0                                    // 000000199D48: 980080C1
	v_mul_f32_e32 v52, v103, v53                               // 000000199D4C: 10686B67
	v_cndmask_b16 v21, 0, v21, s0                              // 000000199D50: D65D0015 00022A80
	s_or_b32 s0, s48, 41                                       // 000000199D58: 8C00A930
	v_fma_mixhi_f16 v21, v22, s28, 0                           // 000000199D5C: CC220015 02003916
	s_cmp_lt_i32 s0, s59                                       // 000000199D64: BF043B00
	v_fma_mixhi_f16 v22, v23, s28, 0                           // 000000199D68: CC220016 02003917
	v_fma_mixlo_f16 v23, v24, s28, 0                           // 000000199D70: CC210017 02003918
	s_waitcnt lgkmcnt(1)                                       // 000000199D78: BF89FC17
	v_mul_f32_e32 v24, v45, v54                                // 000000199D7C: 10306D2D
	v_mul_f32_e32 v42, v42, v55                                // 000000199D80: 10546F2A
	s_cselect_b32 s0, -1, 0                                    // 000000199D84: 980080C1
	s_or_b32 s1, s48, 42                                       // 000000199D88: 8C01AA30
	v_fma_mixlo_f16 v22, v52, s28, 0                           // 000000199D8C: CC210016 02003934
	s_cmp_lt_i32 s1, s59                                       // 000000199D94: BF043B01
	ds_load_2addr_b32 v[52:53], v165 offset1:1                 // 000000199D98: D8DC0100 340000A5
	v_fma_mixhi_f16 v23, v24, s28, 0                           // 000000199DA0: CC220017 02003918
	s_waitcnt lgkmcnt(1)                                       // 000000199DA8: BF89FC17
	v_mul_f32_e32 v45, v49, v104                               // 000000199DAC: 105AD131
	v_fma_mixlo_f16 v24, v42, s28, 0                           // 000000199DB0: CC210018 0200392A
	v_mul_f32_e32 v42, v48, v105                               // 000000199DB8: 1054D330
	ds_load_2addr_b32 v[48:49], v166 offset1:1                 // 000000199DBC: D8DC0100 300000A6
	v_cndmask_b16 v21, 0, v21, s0                              // 000000199DC4: D65D5015 00022A80
	s_cselect_b32 s0, -1, 0                                    // 000000199DCC: 980080C1
	s_or_b32 s1, s48, 43                                       // 000000199DD0: 8C01AB30
	v_cndmask_b16 v22, 0, v22, s0                              // 000000199DD4: D65D0016 00022C80
	s_cmp_lt_i32 s1, s59                                       // 000000199DDC: BF043B01
	v_fma_mixhi_f16 v24, v45, s28, 0                           // 000000199DE0: CC220018 0200392D
	s_cselect_b32 s0, -1, 0                                    // 000000199DE8: 980080C1
	s_or_b32 s1, s48, 44                                       // 000000199DEC: 8C01AC30
	v_cndmask_b16 v22, 0, v22, s0                              // 000000199DF0: D65D5016 00022C80
	s_cmp_lt_i32 s1, s59                                       // 000000199DF8: BF043B01
	ds_load_2addr_b32 v[54:55], v167 offset1:1                 // 000000199DFC: D8DC0100 360000A7
	ds_load_2addr_b32 v[99:100], v168 offset1:1                // 000000199E04: D8DC0100 630000A8
	s_cselect_b32 s1, -1, 0                                    // 000000199E0C: 980180C1
	s_or_b32 s9, s48, 45                                       // 000000199E10: 8C09AD30
	v_cndmask_b16 v23, 0, v23, s1                              // 000000199E14: D65D0017 00062E80
	s_cmp_lt_i32 s9, s59                                       // 000000199E1C: BF043B09
	v_fma_mixlo_f16 v42, v42, s28, 0                           // 000000199E20: CC21002A 0200392A
	s_cselect_b32 s0, -1, 0                                    // 000000199E28: 980080C1
	s_or_b32 s9, s48, 46                                       // 000000199E2C: 8C09AE30
	v_cndmask_b16 v23, 0, v23, s0                              // 000000199E30: D65D5017 00022E80
	s_cmp_lt_i32 s9, s59                                       // 000000199E38: BF043B09
	s_waitcnt lgkmcnt(2)                                       // 000000199E3C: BF89FC27
	v_mul_f32_e32 v27, v27, v48                                // 000000199E40: 1036611B
	s_cselect_b32 s1, -1, 0                                    // 000000199E44: 980180C1
	s_or_b32 s9, s48, 47                                       // 000000199E48: 8C09AF30
	v_mul_f32_e32 v32, v32, v49                                // 000000199E4C: 10406320
	s_cmp_lt_i32 s9, s59                                       // 000000199E50: BF043B09
	v_cndmask_b16 v24, 0, v24, s1                              // 000000199E54: D65D0018 00063080
	s_cselect_b32 s0, -1, 0                                    // 000000199E5C: 980080C1
	s_or_b32 s1, s48, 48                                       // 000000199E60: 8C01B030
	v_cndmask_b16 v24, 0, v24, s0                              // 000000199E64: D65D5018 00023080
	s_cmp_lt_i32 s1, s59                                       // 000000199E6C: BF043B01
	v_fma_mixlo_f16 v27, v27, s28, 0                           // 000000199E70: CC21001B 0200391B
	s_cselect_b32 s0, -1, 0                                    // 000000199E78: 980080C1
	v_fma_mixhi_f16 v27, v32, s28, 0                           // 000000199E7C: CC22001B 02003920
	ds_load_b32 v32, v107 offset:61692                         // 000000199E84: D8D8F0FC 2000006B
	v_mul_f32_e32 v43, v43, v52                                // 000000199E8C: 1056692B
	v_cndmask_b16 v42, 0, v42, s0                              // 000000199E90: D65D002A 00025480
	s_or_b32 s0, s48, 49                                       // 000000199E98: 8C00B130
	v_mul_f32_e32 v45, v41, v53                                // 000000199E9C: 105A6B29
	s_cmp_lt_i32 s0, s59                                       // 000000199EA0: BF043B00
	v_fma_mixlo_f16 v41, v43, s28, 0                           // 000000199EA4: CC210029 0200392B
	s_cselect_b32 s0, -1, 0                                    // 000000199EAC: 980080C1
	s_or_b32 s1, s48, 50                                       // 000000199EB0: 8C01B230
	v_fma_mixhi_f16 v41, v45, s28, 0                           // 000000199EB4: CC220029 0200392D
	s_cmp_lt_i32 s1, s59                                       // 000000199EBC: BF043B01
	v_cndmask_b16 v42, 0, v41, s0                              // 000000199EC0: D65D402A 00025280
	s_cselect_b32 s0, -1, 0                                    // 000000199EC8: 980080C1
	s_or_b32 s1, s48, 51                                       // 000000199ECC: 8C01B330
	v_cndmask_b16 v43, 0, v41, s0                              // 000000199ED0: D65D102B 00025280
	s_cmp_lt_i32 s1, s59                                       // 000000199ED8: BF043B01
	s_waitcnt lgkmcnt(2)                                       // 000000199EDC: BF89FC27
	v_mul_f32_e32 v41, v44, v54                                // 000000199EE0: 10526D2C
	s_cselect_b32 s0, -1, 0                                    // 000000199EE4: 980080C1
	s_or_b32 s1, s48, 52                                       // 000000199EE8: 8C01B430
	ds_load_2addr_b32 v[48:49], v169 offset1:1                 // 000000199EEC: D8DC0100 300000A9
	ds_load_2addr_b32 v[52:53], v170 offset1:1                 // 000000199EF4: D8DC0100 340000AA
	s_cmp_lt_i32 s1, s59                                       // 000000199EFC: BF043B01
	v_cndmask_b16 v43, 0, v27, s0                              // 000000199F00: D65D402B 00023680
	s_cselect_b32 s1, -1, 0                                    // 000000199F08: 980180C1
	s_or_b32 s9, s48, 53                                       // 000000199F0C: 8C09B530
	v_fma_mixlo_f16 v27, v41, s28, 0                           // 000000199F10: CC21001B 02003929
	s_cmp_lt_i32 s9, s59                                       // 000000199F18: BF043B09
	v_mul_f32_e32 v29, v29, v55                                // 000000199F1C: 103A6F1D
	s_cselect_b32 s0, -1, 0                                    // 000000199F20: 980080C1
	s_waitcnt lgkmcnt(3)                                       // 000000199F24: BF89FC37
	v_mul_f32_e32 v28, v28, v99                                // 000000199F28: 1038C71C
	v_cndmask_b16 v44, 0, v27, s0                              // 000000199F2C: D65D402C 00023680
	s_or_b32 s0, s48, 54                                       // 000000199F34: 8C00B630
	v_fma_mixlo_f16 v27, v29, s28, 0                           // 000000199F38: CC21001B 0200391D
	s_cmp_lt_i32 s0, s59                                       // 000000199F40: BF043B00
	v_cndmask_b16 v44, 0, v27, s1                              // 000000199F44: D65D102C 00063680
	s_cselect_b32 s0, -1, 0                                    // 000000199F4C: 980080C1
	s_or_b32 s1, s48, 55                                       // 000000199F50: 8C01B730
	v_fma_mixhi_f16 v27, v28, s28, 0                           // 000000199F54: CC22001B 0200391C
	s_cmp_lt_i32 s1, s59                                       // 000000199F5C: BF043B01
	v_cndmask_b16 v45, 0, v27, s0                              // 000000199F60: D65D002D 00023680
	s_cselect_b32 s0, -1, 0                                    // 000000199F68: 980080C1
	s_or_b32 s1, s48, 56                                       // 000000199F6C: 8C01B830
	v_mul_f32_e32 v25, v25, v100                               // 000000199F70: 1032C919
	s_cmp_lt_i32 s1, s59                                       // 000000199F74: BF043B01
	v_cndmask_b16 v45, 0, v27, s0                              // 000000199F78: D65D502D 00023680
	s_cselect_b32 s0, -1, 0                                    // 000000199F80: 980080C1
	s_or_b32 s1, s48, 57                                       // 000000199F84: 8C01B930
	ds_load_2addr_b32 v[54:55], v171 offset1:1                 // 000000199F88: D8DC0100 360000AB
	s_waitcnt lgkmcnt(2)                                       // 000000199F90: BF89FC27
	v_dual_mul_f32 v27, v46, v48 :: v_dual_mul_f32 v28, v47, v49// 000000199F94: C8C6612E 1B1C632F
	s_cmp_lt_i32 s1, s59                                       // 000000199F9C: BF043B01
	v_fma_mixlo_f16 v25, v25, s28, 0                           // 000000199FA0: CC210019 02003919
	s_cselect_b32 s1, -1, 0                                    // 000000199FA8: 980180C1
	s_or_b32 s9, s48, 58                                       // 000000199FAC: 8C09BA30
	v_fma_mixhi_f16 v25, v27, s28, 0                           // 000000199FB0: CC220019 0200391B
	v_fma_mixlo_f16 v28, v28, s28, 0                           // 000000199FB8: CC21001C 0200391C
	s_cmp_lt_i32 s9, s59                                       // 000000199FC0: BF043B09
	v_cndmask_b16 v27, 0, v25, s0                              // 000000199FC4: D65D001B 00023280
	s_cselect_b32 s0, -1, 0                                    // 000000199FCC: 980080C1
	v_cndmask_b16 v27, 0, v25, s1                              // 000000199FD0: D65D501B 00063280
	v_cndmask_b16 v28, 0, v28, s0                              // 000000199FD8: D65D001C 00023880
	s_or_b32 s0, s48, 59                                       // 000000199FE0: 8C00BB30
	s_waitcnt lgkmcnt(1)                                       // 000000199FE4: BF89FC17
	v_mul_f32_e32 v25, v31, v52                                // 000000199FE8: 1032691F
	v_mul_f32_e32 v29, v30, v53                                // 000000199FEC: 103A6B1E
	s_cmp_lt_i32 s0, s59                                       // 000000199FF0: BF043B00
	v_mul_f32_e32 v30, v51, v32                                // 000000199FF4: 103C4133
	s_cselect_b32 s0, -1, 0                                    // 000000199FF8: 980080C1
	s_or_b32 s1, s48, 60                                       // 000000199FFC: 8C01BC30
	v_fma_mixlo_f16 v25, v25, s28, 0                           // 00000019A000: CC210019 02003919
	v_fma_mixhi_f16 v25, v29, s28, 0                           // 00000019A008: CC220019 0200391D
	s_cmp_lt_i32 s1, s59                                       // 00000019A010: BF043B01
	s_cselect_b32 s1, -1, 0                                    // 00000019A014: 980180C1
	s_or_b32 s9, s48, 61                                       // 00000019A018: 8C09BD30
	v_cndmask_b16 v28, 0, v25, s0                              // 00000019A01C: D65D401C 00023280
	s_cmp_lt_i32 s9, s59                                       // 00000019A024: BF043B09
	v_cndmask_b16 v29, 0, v25, s1                              // 00000019A028: D65D101D 00063280
	s_waitcnt lgkmcnt(0)                                       // 00000019A030: BF89FC07
	v_mul_f32_e32 v25, v26, v54                                // 00000019A034: 10326D1A
	s_cselect_b32 s0, -1, 0                                    // 00000019A038: 980080C1
	s_or_b32 s1, s48, 62                                       // 00000019A03C: 8C01BE30
	v_mul_f32_e32 v26, v50, v55                                // 00000019A040: 10346F32
	s_cmp_lt_i32 s1, s59                                       // 00000019A044: BF043B01
	v_fma_mixlo_f16 v25, v25, s28, 0                           // 00000019A048: CC210019 02003919
	s_cselect_b32 s1, -1, 0                                    // 00000019A050: 980180C1
	s_or_b32 s9, s48, 63                                       // 00000019A054: 8C09BF30
	v_fma_mixhi_f16 v25, v26, s28, 0                           // 00000019A058: CC220019 0200391A
	v_fma_mixlo_f16 v26, v30, s28, 0                           // 00000019A060: CC21001A 0200391E
	s_cmp_lt_i32 s9, s59                                       // 00000019A068: BF043B09
	v_cndmask_b16 v29, 0, v25, s0                              // 00000019A06C: D65D401D 00023280
	s_cselect_b32 s0, -1, 0                                    // 00000019A074: 980080C1
	v_cndmask_b16 v30, 0, v25, s1                              // 00000019A078: D65D101E 00063280
	v_cndmask_b16 v30, 0, v26, s0                              // 00000019A080: D65D401E 00023480
	ds_store_b128 v125, v[17:20] offset:64                     // 00000019A088: DB7C0040 0000117D
	ds_store_b128 v125, v[21:24] offset:80                     // 00000019A090: DB7C0050 0000157D
	ds_store_b128 v125, v[42:45] offset:96                     // 00000019A098: DB7C0060 00002A7D
	ds_store_b128 v125, v[27:30] offset:112                    // 00000019A0A0: DB7C0070 00001B7D
	s_and_saveexec_b32 s0, vcc_lo                              // 00000019A0A8: BE80206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000019A0AC: BF870009
	s_xor_b32 s0, exec_lo, s0                                  // 00000019A0B0: 8D00007E
	s_cbranch_execz 67                                         // 00000019A0B4: BFA50043 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x28c4>
	s_waitcnt vmcnt(1)                                         // 00000019A0B8: BF8907F7
	v_mov_b32_e32 v1, 0                                        // 00000019A0BC: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019A0C0: BF870001
	v_mov_b32_e32 v2, v1                                       // 00000019A0C4: 7E040301
	v_mov_b32_e32 v3, v1                                       // 00000019A0C8: 7E060301
	v_mov_b32_e32 v4, v1                                       // 00000019A0CC: 7E080301
	s_waitcnt vmcnt(0)                                         // 00000019A0D0: BF8903F7
	v_mov_b32_e32 v5, v1                                       // 00000019A0D4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 00000019A0D8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000019A0DC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 00000019A0E0: 7E100301
	v_mov_b32_e32 v9, v1                                       // 00000019A0E4: 7E120301
	v_mov_b32_e32 v10, v1                                      // 00000019A0E8: 7E140301
	v_mov_b32_e32 v11, v1                                      // 00000019A0EC: 7E160301
	v_mov_b32_e32 v12, v1                                      // 00000019A0F0: 7E180301
	v_mov_b32_e32 v13, v1                                      // 00000019A0F4: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 00000019A0F8: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 00000019A0FC: 7E1E0301
	v_mov_b32_e32 v16, v1                                      // 00000019A100: 7E200301
	v_mov_b32_e32 v33, v1                                      // 00000019A104: 7E420301
	v_mov_b32_e32 v34, v1                                      // 00000019A108: 7E440301
	v_mov_b32_e32 v35, v1                                      // 00000019A10C: 7E460301
	v_mov_b32_e32 v36, v1                                      // 00000019A110: 7E480301
	v_mov_b32_e32 v37, v1                                      // 00000019A114: 7E4A0301
	v_mov_b32_e32 v38, v1                                      // 00000019A118: 7E4C0301
	v_mov_b32_e32 v39, v1                                      // 00000019A11C: 7E4E0301
	v_mov_b32_e32 v40, v1                                      // 00000019A120: 7E500301
	v_mov_b32_e32 v57, v1                                      // 00000019A124: 7E720301
	v_mov_b32_e32 v58, v1                                      // 00000019A128: 7E740301
	v_mov_b32_e32 v59, v1                                      // 00000019A12C: 7E760301
	v_mov_b32_e32 v60, v1                                      // 00000019A130: 7E780301
	v_mov_b32_e32 v61, v1                                      // 00000019A134: 7E7A0301
	v_mov_b32_e32 v62, v1                                      // 00000019A138: 7E7C0301
	v_mov_b32_e32 v63, v1                                      // 00000019A13C: 7E7E0301
	v_mov_b32_e32 v64, v1                                      // 00000019A140: 7E800301
	v_mov_b32_e32 v65, v1                                      // 00000019A144: 7E820301
	v_mov_b32_e32 v66, v1                                      // 00000019A148: 7E840301
	v_mov_b32_e32 v67, v1                                      // 00000019A14C: 7E860301
	v_mov_b32_e32 v68, v1                                      // 00000019A150: 7E880301
	v_mov_b32_e32 v69, v1                                      // 00000019A154: 7E8A0301
	v_mov_b32_e32 v70, v1                                      // 00000019A158: 7E8C0301
	v_mov_b32_e32 v71, v1                                      // 00000019A15C: 7E8E0301
	v_mov_b32_e32 v72, v1                                      // 00000019A160: 7E900301
	v_mov_b32_e32 v73, v1                                      // 00000019A164: 7E920301
	v_mov_b32_e32 v74, v1                                      // 00000019A168: 7E940301
	v_mov_b32_e32 v75, v1                                      // 00000019A16C: 7E960301
	v_mov_b32_e32 v76, v1                                      // 00000019A170: 7E980301
	v_mov_b32_e32 v77, v1                                      // 00000019A174: 7E9A0301
	v_mov_b32_e32 v78, v1                                      // 00000019A178: 7E9C0301
	v_mov_b32_e32 v79, v1                                      // 00000019A17C: 7E9E0301
	v_mov_b32_e32 v80, v1                                      // 00000019A180: 7EA00301
	v_mov_b32_e32 v81, v1                                      // 00000019A184: 7EA20301
	v_mov_b32_e32 v82, v1                                      // 00000019A188: 7EA40301
	v_mov_b32_e32 v83, v1                                      // 00000019A18C: 7EA60301
	v_mov_b32_e32 v84, v1                                      // 00000019A190: 7EA80301
	v_mov_b32_e32 v85, v1                                      // 00000019A194: 7EAA0301
	v_mov_b32_e32 v86, v1                                      // 00000019A198: 7EAC0301
	v_mov_b32_e32 v87, v1                                      // 00000019A19C: 7EAE0301
	v_mov_b32_e32 v88, v1                                      // 00000019A1A0: 7EB00301
	v_mov_b32_e32 v89, v1                                      // 00000019A1A4: 7EB20301
	v_mov_b32_e32 v90, v1                                      // 00000019A1A8: 7EB40301
	v_mov_b32_e32 v91, v1                                      // 00000019A1AC: 7EB60301
	v_mov_b32_e32 v92, v1                                      // 00000019A1B0: 7EB80301
	v_mov_b32_e32 v93, v1                                      // 00000019A1B4: 7EBA0301
	v_mov_b32_e32 v94, v1                                      // 00000019A1B8: 7EBC0301
	v_mov_b32_e32 v95, v1                                      // 00000019A1BC: 7EBE0301
	v_mov_b32_e32 v96, v1                                      // 00000019A1C0: 7EC00301
	s_or_b32 exec_lo, exec_lo, s0                              // 00000019A1C4: 8C7E007E
	ds_load_b128 v[17:20], v127                                // 00000019A1C8: DBFC0000 1100007F
	ds_load_b128 v[21:24], v127 offset:16                      // 00000019A1D0: DBFC0010 1500007F
	ds_load_b128 v[25:28], v127 offset:32                      // 00000019A1D8: DBFC0020 1900007F
	ds_load_b128 v[29:32], v127 offset:48                      // 00000019A1E0: DBFC0030 1D00007F
	ds_load_b128 v[41:44], v127 offset:8448                    // 00000019A1E8: DBFC2100 2900007F
	ds_load_b128 v[45:48], v127 offset:8464                    // 00000019A1F0: DBFC2110 2D00007F
	ds_load_b128 v[49:52], v127 offset:8480                    // 00000019A1F8: DBFC2120 3100007F
	ds_load_b128 v[53:56], v127 offset:8496                    // 00000019A200: DBFC2130 3500007F
	ds_load_b128 v[99:102], v127 offset:16896                  // 00000019A208: DBFC4200 6300007F
	ds_load_b128 v[181:184], v127 offset:16912                 // 00000019A210: DBFC4210 B500007F
	v_dual_mov_b32 v180, s43 :: v_dual_mov_b32 v179, s42       // 00000019A218: CA10002B B4B2002A
	v_dual_mov_b32 v178, s41 :: v_dual_mov_b32 v177, s40       // 00000019A220: CA100029 B2B00028
	v_dual_mov_b32 v176, s39 :: v_dual_mov_b32 v175, s38       // 00000019A228: CA100027 B0AE0026
	v_dual_mov_b32 v174, s37 :: v_dual_mov_b32 v173, s36       // 00000019A230: CA100025 AEAC0024
	ds_load_b128 v[185:188], v127 offset:25344                 // 00000019A238: DBFC6300 B900007F
	ds_load_b128 v[189:192], v127 offset:25360                 // 00000019A240: DBFC6310 BD00007F
	s_waitcnt lgkmcnt(11)                                      // 00000019A248: BF89FCB7
	v_fma_mixlo_f16 v17, v17, s28, 0                           // 00000019A24C: CC210011 02003911
	v_fma_mixhi_f16 v17, v18, s28, 0                           // 00000019A254: CC220011 02003912
	v_fma_mixlo_f16 v18, v19, s28, 0                           // 00000019A25C: CC210012 02003913
	v_fma_mixhi_f16 v18, v20, s28, 0                           // 00000019A264: CC220012 02003914
	s_waitcnt lgkmcnt(10)                                      // 00000019A26C: BF89FCA7
	v_fma_mixlo_f16 v19, v21, s28, 0                           // 00000019A270: CC210013 02003915
	v_fma_mixhi_f16 v19, v22, s28, 0                           // 00000019A278: CC220013 02003916
	v_fma_mixlo_f16 v20, v23, s28, 0                           // 00000019A280: CC210014 02003917
	v_fma_mixhi_f16 v20, v24, s28, 0                           // 00000019A288: CC220014 02003918
	s_waitcnt lgkmcnt(9)                                       // 00000019A290: BF89FC97
	v_fma_mixlo_f16 v21, v25, s28, 0                           // 00000019A294: CC210015 02003919
	v_fma_mixhi_f16 v21, v26, s28, 0                           // 00000019A29C: CC220015 0200391A
	v_fma_mixlo_f16 v22, v27, s28, 0                           // 00000019A2A4: CC210016 0200391B
	v_fma_mixhi_f16 v22, v28, s28, 0                           // 00000019A2AC: CC220016 0200391C
	s_waitcnt lgkmcnt(8)                                       // 00000019A2B4: BF89FC87
	v_fma_mixlo_f16 v23, v29, s28, 0                           // 00000019A2B8: CC210017 0200391D
	v_fma_mixhi_f16 v23, v30, s28, 0                           // 00000019A2C0: CC220017 0200391E
	v_fma_mixlo_f16 v24, v31, s28, 0                           // 00000019A2C8: CC210018 0200391F
	v_fma_mixhi_f16 v24, v32, s28, 0                           // 00000019A2D0: CC220018 02003920
	s_waitcnt lgkmcnt(7)                                       // 00000019A2D8: BF89FC77
	v_fma_mixlo_f16 v25, v41, s28, 0                           // 00000019A2DC: CC210019 02003929
	v_fma_mixhi_f16 v25, v42, s28, 0                           // 00000019A2E4: CC220019 0200392A
	v_fma_mixlo_f16 v26, v43, s28, 0                           // 00000019A2EC: CC21001A 0200392B
	v_fma_mixhi_f16 v26, v44, s28, 0                           // 00000019A2F4: CC22001A 0200392C
	s_waitcnt lgkmcnt(6)                                       // 00000019A2FC: BF89FC67
	v_fma_mixlo_f16 v27, v45, s28, 0                           // 00000019A300: CC21001B 0200392D
	v_fma_mixhi_f16 v27, v46, s28, 0                           // 00000019A308: CC22001B 0200392E
	v_fma_mixlo_f16 v28, v47, s28, 0                           // 00000019A310: CC21001C 0200392F
	v_fma_mixhi_f16 v28, v48, s28, 0                           // 00000019A318: CC22001C 02003930
	s_waitcnt lgkmcnt(5)                                       // 00000019A320: BF89FC57
	v_fma_mixlo_f16 v29, v49, s28, 0                           // 00000019A324: CC21001D 02003931
	v_fma_mixhi_f16 v29, v50, s28, 0                           // 00000019A32C: CC22001D 02003932
	v_fma_mixlo_f16 v30, v51, s28, 0                           // 00000019A334: CC21001E 02003933
	v_fma_mixhi_f16 v30, v52, s28, 0                           // 00000019A33C: CC22001E 02003934
	s_waitcnt lgkmcnt(4)                                       // 00000019A344: BF89FC47
	v_fma_mixlo_f16 v31, v53, s28, 0                           // 00000019A348: CC21001F 02003935
	v_fma_mixhi_f16 v31, v54, s28, 0                           // 00000019A350: CC22001F 02003936
	v_fma_mixlo_f16 v32, v55, s28, 0                           // 00000019A358: CC210020 02003937
	v_fma_mixhi_f16 v32, v56, s28, 0                           // 00000019A360: CC220020 02003938
	s_waitcnt vmcnt(14)                                        // 00000019A368: BF893BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[17:24], v[173:180]// 00000019A36C: CC404029 1EB62359
	ds_load_b128 v[49:52], v127 offset:16928                   // 00000019A374: DBFC4220 3100007F
	ds_load_b128 v[53:56], v127 offset:16944                   // 00000019A37C: DBFC4230 3500007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[25:32], v[173:180]// 00000019A384: CC404011 1EB63359
	s_waitcnt lgkmcnt(5)                                       // 00000019A38C: BF89FC57
	v_fma_mixlo_f16 v25, v99, s28, 0                           // 00000019A390: CC210019 02003963
	v_fma_mixhi_f16 v25, v100, s28, 0                          // 00000019A398: CC220019 02003964
	v_fma_mixlo_f16 v26, v101, s28, 0                          // 00000019A3A0: CC21001A 02003965
	v_fma_mixhi_f16 v26, v102, s28, 0                          // 00000019A3A8: CC22001A 02003966
	ds_load_b128 v[99:102], v127 offset:25376                  // 00000019A3B0: DBFC6320 6300007F
	ds_load_b128 v[193:196], v127 offset:25392                 // 00000019A3B8: DBFC6330 C100007F
	s_waitcnt lgkmcnt(6)                                       // 00000019A3C0: BF89FC67
	v_fma_mixlo_f16 v27, v181, s28, 0                          // 00000019A3C4: CC21001B 020039B5
	s_waitcnt lgkmcnt(5)                                       // 00000019A3CC: BF89FC57
	v_fma_mixlo_f16 v181, v185, s28, 0                         // 00000019A3D0: CC2100B5 020039B9
	v_fma_mixhi_f16 v181, v186, s28, 0                         // 00000019A3D8: CC2200B5 020039BA
	v_fma_mixhi_f16 v27, v182, s28, 0                          // 00000019A3E0: CC22001B 020039B6
	v_fma_mixlo_f16 v28, v183, s28, 0                          // 00000019A3E8: CC21001C 020039B7
	v_fma_mixhi_f16 v28, v184, s28, 0                          // 00000019A3F0: CC22001C 020039B8
	v_fma_mixlo_f16 v182, v187, s28, 0                         // 00000019A3F8: CC2100B6 020039BB
	v_fma_mixhi_f16 v182, v188, s28, 0                         // 00000019A400: CC2200B6 020039BC
	s_waitcnt lgkmcnt(4)                                       // 00000019A408: BF89FC47
	v_fma_mixlo_f16 v183, v189, s28, 0                         // 00000019A40C: CC2100B7 020039BD
	v_fma_mixhi_f16 v183, v190, s28, 0                         // 00000019A414: CC2200B7 020039BE
	s_waitcnt lgkmcnt(3)                                       // 00000019A41C: BF89FC37
	v_fma_mixlo_f16 v29, v49, s28, 0                           // 00000019A420: CC21001D 02003931
	v_fma_mixhi_f16 v29, v50, s28, 0                           // 00000019A428: CC22001D 02003932
	v_fma_mixlo_f16 v30, v51, s28, 0                           // 00000019A430: CC21001E 02003933
	v_fma_mixhi_f16 v30, v52, s28, 0                           // 00000019A438: CC22001E 02003934
	s_waitcnt lgkmcnt(2)                                       // 00000019A440: BF89FC27
	v_fma_mixlo_f16 v31, v53, s28, 0                           // 00000019A444: CC21001F 02003935
	v_fma_mixhi_f16 v31, v54, s28, 0                           // 00000019A44C: CC22001F 02003936
	v_fma_mixlo_f16 v32, v55, s28, 0                           // 00000019A454: CC210020 02003937
	v_fma_mixhi_f16 v32, v56, s28, 0                           // 00000019A45C: CC220020 02003938
	s_waitcnt lgkmcnt(1)                                       // 00000019A464: BF89FC17
	v_fma_mixlo_f16 v185, v99, s28, 0                          // 00000019A468: CC2100B9 02003963
	v_fma_mixhi_f16 v185, v100, s28, 0                         // 00000019A470: CC2200B9 02003964
	v_fma_mixlo_f16 v186, v101, s28, 0                         // 00000019A478: CC2100BA 02003965
	v_fma_mixhi_f16 v186, v102, s28, 0                         // 00000019A480: CC2200BA 02003966
	ds_load_b128 v[99:102], v127 offset:96                     // 00000019A488: DBFC0060 6300007F
	v_fma_mixlo_f16 v184, v191, s28, 0                         // 00000019A490: CC2100B8 020039BF
	v_fma_mixhi_f16 v184, v192, s28, 0                         // 00000019A498: CC2200B8 020039C0
	s_waitcnt lgkmcnt(1)                                       // 00000019A4A0: BF89FC17
	v_fma_mixlo_f16 v187, v193, s28, 0                         // 00000019A4A4: CC2100BB 020039C1
	v_fma_mixhi_f16 v187, v194, s28, 0                         // 00000019A4AC: CC2200BB 020039C2
	v_fma_mixlo_f16 v188, v195, s28, 0                         // 00000019A4B4: CC2100BC 020039C3
	v_fma_mixhi_f16 v188, v196, s28, 0                         // 00000019A4BC: CC2200BC 020039C4
	ds_load_b128 v[197:200], v127 offset:64                    // 00000019A4C4: DBFC0040 C500007F
	ds_load_b128 v[189:192], v127 offset:80                    // 00000019A4CC: DBFC0050 BD00007F
	ds_load_b128 v[193:196], v127 offset:112                   // 00000019A4D4: DBFC0070 C100007F
	v_wmma_f32_16x16x16_f16 v[49:56], v[89:96], v[25:32], v[173:180]// 00000019A4DC: CC404031 1EB63359
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[181:188], v[173:180]// 00000019A4E4: CC404019 1EB76B59
	ds_load_b128 v[173:176], v127 offset:8512                  // 00000019A4EC: DBFC2140 AD00007F
	ds_load_b128 v[177:180], v127 offset:8528                  // 00000019A4F4: DBFC2150 B100007F
	ds_load_b128 v[181:184], v127 offset:8544                  // 00000019A4FC: DBFC2160 B500007F
	ds_load_b128 v[185:188], v127 offset:16960                 // 00000019A504: DBFC4240 B900007F
	ds_load_b128 v[201:204], v127 offset:25424                 // 00000019A50C: DBFC6350 C900007F
	ds_load_b128 v[205:208], v127 offset:25440                 // 00000019A514: DBFC6360 CD00007F
	ds_load_b128 v[209:212], v127 offset:25456                 // 00000019A51C: DBFC6370 D100007F
	s_waitcnt lgkmcnt(10)                                      // 00000019A524: BF89FCA7
	v_fma_mixlo_f16 v93, v99, s28, 0                           // 00000019A528: CC21005D 02003963
	v_fma_mixhi_f16 v93, v100, s28, 0                          // 00000019A530: CC22005D 02003964
	v_fma_mixlo_f16 v94, v101, s28, 0                          // 00000019A538: CC21005E 02003965
	v_fma_mixhi_f16 v94, v102, s28, 0                          // 00000019A540: CC22005E 02003966
	ds_load_b128 v[99:102], v127 offset:8560                   // 00000019A548: DBFC2170 6300007F
	s_waitcnt lgkmcnt(10)                                      // 00000019A550: BF89FCA7
	v_fma_mixlo_f16 v89, v197, s28, 0                          // 00000019A554: CC210059 020039C5
	s_waitcnt lgkmcnt(9)                                       // 00000019A55C: BF89FC97
	v_fma_mixlo_f16 v91, v189, s28, 0                          // 00000019A560: CC21005B 020039BD
	v_fma_mixhi_f16 v91, v190, s28, 0                          // 00000019A568: CC22005B 020039BE
	v_fma_mixlo_f16 v92, v191, s28, 0                          // 00000019A570: CC21005C 020039BF
	v_fma_mixhi_f16 v92, v192, s28, 0                          // 00000019A578: CC22005C 020039C0
	ds_load_b128 v[189:192], v127 offset:16976                 // 00000019A580: DBFC4250 BD00007F
	v_fma_mixhi_f16 v89, v198, s28, 0                          // 00000019A588: CC220059 020039C6
	s_waitcnt lgkmcnt(8)                                       // 00000019A590: BF89FC87
	v_fma_mixlo_f16 v173, v173, s28, 0                         // 00000019A594: CC2100AD 020039AD
	v_fma_mixhi_f16 v173, v174, s28, 0                         // 00000019A59C: CC2200AD 020039AE
	v_fma_mixhi_f16 v174, v176, s28, 0                         // 00000019A5A4: CC2200AE 020039B0
	s_waitcnt lgkmcnt(7)                                       // 00000019A5AC: BF89FC77
	v_fma_mixlo_f16 v176, v179, s28, 0                         // 00000019A5B0: CC2100B0 020039B3
	v_fma_mixhi_f16 v176, v180, s28, 0                         // 00000019A5B8: CC2200B0 020039B4
	v_fma_mixlo_f16 v90, v199, s28, 0                          // 00000019A5C0: CC21005A 020039C7
	v_fma_mixhi_f16 v90, v200, s28, 0                          // 00000019A5C8: CC22005A 020039C8
	v_fma_mixlo_f16 v95, v193, s28, 0                          // 00000019A5D0: CC21005F 020039C1
	v_fma_mixhi_f16 v95, v194, s28, 0                          // 00000019A5D8: CC22005F 020039C2
	v_fma_mixlo_f16 v96, v195, s28, 0                          // 00000019A5E0: CC210060 020039C3
	v_fma_mixhi_f16 v96, v196, s28, 0                          // 00000019A5E8: CC220060 020039C4
	s_waitcnt lgkmcnt(1)                                       // 00000019A5F0: BF89FC17
	v_fma_mixlo_f16 v179, v99, s28, 0                          // 00000019A5F4: CC2100B3 02003963
	v_fma_mixhi_f16 v179, v100, s28, 0                         // 00000019A5FC: CC2200B3 02003964
	v_fma_mixlo_f16 v180, v101, s28, 0                         // 00000019A604: CC2100B4 02003965
	v_fma_mixhi_f16 v180, v102, s28, 0                         // 00000019A60C: CC2200B4 02003966
	ds_load_b128 v[99:102], v127 offset:25408                  // 00000019A614: DBFC6340 6300007F
	ds_load_b128 v[193:196], v127 offset:16992                 // 00000019A61C: DBFC4260 C100007F
	ds_load_b128 v[197:200], v127 offset:17008                 // 00000019A624: DBFC4270 C500007F
	v_fma_mixlo_f16 v174, v175, s28, 0                         // 00000019A62C: CC2100AE 020039AF
	v_fma_mixhi_f16 v175, v178, s28, 0                         // 00000019A634: CC2200AF 020039B2
	v_fma_mixlo_f16 v178, v183, s28, 0                         // 00000019A63C: CC2100B2 020039B7
	s_waitcnt lgkmcnt(3)                                       // 00000019A644: BF89FC37
	v_fma_mixlo_f16 v183, v189, s28, 0                         // 00000019A648: CC2100B7 020039BD
	v_fma_mixhi_f16 v183, v190, s28, 0                         // 00000019A650: CC2200B7 020039BE
	v_fma_mixlo_f16 v175, v177, s28, 0                         // 00000019A658: CC2100AF 020039B1
	v_fma_mixlo_f16 v177, v181, s28, 0                         // 00000019A660: CC2100B1 020039B5
	v_fma_mixhi_f16 v177, v182, s28, 0                         // 00000019A668: CC2200B1 020039B6
	v_fma_mixhi_f16 v178, v184, s28, 0                         // 00000019A670: CC2200B2 020039B8
	v_fma_mixlo_f16 v181, v185, s28, 0                         // 00000019A678: CC2100B5 020039B9
	v_fma_mixhi_f16 v181, v186, s28, 0                         // 00000019A680: CC2200B5 020039BA
	v_fma_mixlo_f16 v182, v187, s28, 0                         // 00000019A688: CC2100B6 020039BB
	v_fma_mixhi_f16 v182, v188, s28, 0                         // 00000019A690: CC2200B6 020039BC
	v_fma_mixlo_f16 v184, v191, s28, 0                         // 00000019A698: CC2100B8 020039BF
	v_fma_mixhi_f16 v184, v192, s28, 0                         // 00000019A6A0: CC2200B8 020039C0
	v_fma_mixlo_f16 v191, v201, s28, 0                         // 00000019A6A8: CC2100BF 020039C9
	v_fma_mixhi_f16 v191, v202, s28, 0                         // 00000019A6B0: CC2200BF 020039CA
	s_waitcnt lgkmcnt(2)                                       // 00000019A6B8: BF89FC27
	v_fma_mixlo_f16 v189, v99, s28, 0                          // 00000019A6BC: CC2100BD 02003963
	v_fma_mixhi_f16 v189, v100, s28, 0                         // 00000019A6C4: CC2200BD 02003964
	v_fma_mixlo_f16 v190, v101, s28, 0                         // 00000019A6CC: CC2100BE 02003965
	v_fma_mixhi_f16 v190, v102, s28, 0                         // 00000019A6D4: CC2200BE 02003966
	ds_load_b128 v[99:102], v127 offset:128                    // 00000019A6DC: DBFC0080 6300007F
	s_waitcnt lgkmcnt(2)                                       // 00000019A6E4: BF89FC27
	v_fma_mixlo_f16 v185, v193, s28, 0                         // 00000019A6E8: CC2100B9 020039C1
	v_fma_mixhi_f16 v185, v194, s28, 0                         // 00000019A6F0: CC2200B9 020039C2
	v_fma_mixlo_f16 v186, v195, s28, 0                         // 00000019A6F8: CC2100BA 020039C3
	v_fma_mixhi_f16 v186, v196, s28, 0                         // 00000019A700: CC2200BA 020039C4
	s_waitcnt lgkmcnt(1)                                       // 00000019A708: BF89FC17
	v_fma_mixlo_f16 v187, v197, s28, 0                         // 00000019A70C: CC2100BB 020039C5
	v_fma_mixhi_f16 v187, v198, s28, 0                         // 00000019A714: CC2200BB 020039C6
	v_fma_mixlo_f16 v188, v199, s28, 0                         // 00000019A71C: CC2100BC 020039C7
	v_fma_mixhi_f16 v188, v200, s28, 0                         // 00000019A724: CC2200BC 020039C8
	v_fma_mixlo_f16 v192, v203, s28, 0                         // 00000019A72C: CC2100C0 020039CB
	v_fma_mixhi_f16 v192, v204, s28, 0                         // 00000019A734: CC2200C0 020039CC
	v_fma_mixlo_f16 v193, v205, s28, 0                         // 00000019A73C: CC2100C1 020039CD
	v_fma_mixhi_f16 v193, v206, s28, 0                         // 00000019A744: CC2200C1 020039CE
	v_fma_mixlo_f16 v194, v207, s28, 0                         // 00000019A74C: CC2100C2 020039CF
	v_fma_mixhi_f16 v194, v208, s28, 0                         // 00000019A754: CC2200C2 020039D0
	v_fma_mixlo_f16 v195, v209, s28, 0                         // 00000019A75C: CC2100C3 020039D1
	v_fma_mixhi_f16 v195, v210, s28, 0                         // 00000019A764: CC2200C3 020039D2
	v_fma_mixlo_f16 v196, v211, s28, 0                         // 00000019A76C: CC2100C4 020039D3
	v_fma_mixhi_f16 v196, v212, s28, 0                         // 00000019A774: CC2200C4 020039D4
	ds_load_b128 v[197:200], v127 offset:144                   // 00000019A77C: DBFC0090 C500007F
	ds_load_b128 v[201:204], v127 offset:160                   // 00000019A784: DBFC00A0 C900007F
	s_waitcnt vmcnt(12)                                        // 00000019A78C: BF8933F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[89:96], v[41:48]// 00000019A790: CC404029 1CA6B351
	ds_load_b128 v[89:92], v127 offset:176                     // 00000019A798: DBFC00B0 5900007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[173:180], v[17:24]// 00000019A7A0: CC404011 1C475B51
	v_wmma_f32_16x16x16_f16 v[49:56], v[81:88], v[181:188], v[49:56]// 00000019A7A8: CC404031 1CC76B51
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[189:196], v[25:32]// 00000019A7B0: CC404019 1C677B51
	ds_load_b128 v[93:96], v127 offset:8576                    // 00000019A7B8: DBFC2180 5D00007F
	s_waitcnt lgkmcnt(4)                                       // 00000019A7C0: BF89FC47
	v_fma_mixlo_f16 v81, v99, s28, 0                           // 00000019A7C4: CC210051 02003963
	v_fma_mixhi_f16 v81, v100, s28, 0                          // 00000019A7CC: CC220051 02003964
	v_fma_mixlo_f16 v82, v101, s28, 0                          // 00000019A7D4: CC210052 02003965
	v_fma_mixhi_f16 v82, v102, s28, 0                          // 00000019A7DC: CC220052 02003966
	ds_load_b128 v[99:102], v127 offset:8592                   // 00000019A7E4: DBFC2190 6300007F
	ds_load_b128 v[173:176], v127 offset:8608                  // 00000019A7EC: DBFC21A0 AD00007F
	ds_load_b128 v[177:180], v127 offset:8624                  // 00000019A7F4: DBFC21B0 B100007F
	ds_load_b128 v[181:184], v127 offset:17024                 // 00000019A7FC: DBFC4280 B500007F
	ds_load_b128 v[185:188], v127 offset:17040                 // 00000019A804: DBFC4290 B900007F
	ds_load_b128 v[189:192], v127 offset:17072                 // 00000019A80C: DBFC42B0 BD00007F
	ds_load_b128 v[193:196], v127 offset:25472                 // 00000019A814: DBFC6380 C100007F
	ds_load_b128 v[205:208], v127 offset:25520                 // 00000019A81C: DBFC63B0 CD00007F
	s_waitcnt lgkmcnt(11)                                      // 00000019A824: BF89FCB7
	v_fma_mixlo_f16 v83, v197, s28, 0                          // 00000019A828: CC210053 020039C5
	v_fma_mixhi_f16 v83, v198, s28, 0                          // 00000019A830: CC220053 020039C6
	v_fma_mixlo_f16 v84, v199, s28, 0                          // 00000019A838: CC210054 020039C7
	s_waitcnt lgkmcnt(9)                                       // 00000019A840: BF89FC97
	v_fma_mixlo_f16 v88, v91, s28, 0                           // 00000019A844: CC210058 0200395B
	v_fma_mixhi_f16 v88, v92, s28, 0                           // 00000019A84C: CC220058 0200395C
	v_fma_mixhi_f16 v84, v200, s28, 0                          // 00000019A854: CC220054 020039C8
	v_fma_mixlo_f16 v85, v201, s28, 0                          // 00000019A85C: CC210055 020039C9
	v_fma_mixhi_f16 v85, v202, s28, 0                          // 00000019A864: CC220055 020039CA
	v_fma_mixlo_f16 v86, v203, s28, 0                          // 00000019A86C: CC210056 020039CB
	v_fma_mixhi_f16 v86, v204, s28, 0                          // 00000019A874: CC220056 020039CC
	ds_load_b128 v[197:200], v127 offset:25488                 // 00000019A87C: DBFC6390 C500007F
	ds_load_b128 v[201:204], v127 offset:25504                 // 00000019A884: DBFC63A0 C900007F
	s_waitcnt lgkmcnt(9)                                       // 00000019A88C: BF89FC97
	v_fma_mixlo_f16 v91, v99, s28, 0                           // 00000019A890: CC21005B 02003963
	v_fma_mixhi_f16 v91, v100, s28, 0                          // 00000019A898: CC22005B 02003964
	v_fma_mixlo_f16 v92, v101, s28, 0                          // 00000019A8A0: CC21005C 02003965
	v_fma_mixhi_f16 v92, v102, s28, 0                          // 00000019A8A8: CC22005C 02003966
	ds_load_b128 v[99:102], v127 offset:17056                  // 00000019A8B0: DBFC42A0 6300007F
	v_fma_mixhi_f16 v87, v90, s28, 0                           // 00000019A8B8: CC220057 0200395A
	v_fma_mixlo_f16 v90, v95, s28, 0                           // 00000019A8C0: CC21005A 0200395F
	s_waitcnt lgkmcnt(8)                                       // 00000019A8C8: BF89FC87
	v_fma_mixlo_f16 v95, v177, s28, 0                          // 00000019A8CC: CC21005F 020039B1
	v_fma_mixhi_f16 v95, v178, s28, 0                          // 00000019A8D4: CC22005F 020039B2
	v_fma_mixlo_f16 v87, v89, s28, 0                           // 00000019A8DC: CC210057 02003959
	v_fma_mixlo_f16 v89, v93, s28, 0                           // 00000019A8E4: CC210059 0200395D
	v_fma_mixhi_f16 v89, v94, s28, 0                           // 00000019A8EC: CC220059 0200395E
	v_fma_mixhi_f16 v90, v96, s28, 0                           // 00000019A8F4: CC22005A 02003960
	v_fma_mixlo_f16 v93, v173, s28, 0                          // 00000019A8FC: CC21005D 020039AD
	v_fma_mixhi_f16 v93, v174, s28, 0                          // 00000019A904: CC22005D 020039AE
	v_fma_mixlo_f16 v94, v175, s28, 0                          // 00000019A90C: CC21005E 020039AF
	v_fma_mixhi_f16 v94, v176, s28, 0                          // 00000019A914: CC22005E 020039B0
	v_fma_mixlo_f16 v96, v179, s28, 0                          // 00000019A91C: CC210060 020039B3
	v_fma_mixhi_f16 v96, v180, s28, 0                          // 00000019A924: CC220060 020039B4
	s_waitcnt lgkmcnt(7)                                       // 00000019A92C: BF89FC77
	v_fma_mixlo_f16 v173, v181, s28, 0                         // 00000019A930: CC2100AD 020039B5
	v_fma_mixhi_f16 v173, v182, s28, 0                         // 00000019A938: CC2200AD 020039B6
	v_fma_mixlo_f16 v174, v183, s28, 0                         // 00000019A940: CC2100AE 020039B7
	v_fma_mixhi_f16 v174, v184, s28, 0                         // 00000019A948: CC2200AE 020039B8
	s_waitcnt lgkmcnt(6)                                       // 00000019A950: BF89FC67
	v_fma_mixlo_f16 v175, v185, s28, 0                         // 00000019A954: CC2100AF 020039B9
	s_waitcnt lgkmcnt(0)                                       // 00000019A95C: BF89FC07
	v_fma_mixlo_f16 v177, v99, s28, 0                          // 00000019A960: CC2100B1 02003963
	v_fma_mixhi_f16 v177, v100, s28, 0                         // 00000019A968: CC2200B1 02003964
	v_fma_mixlo_f16 v178, v101, s28, 0                         // 00000019A970: CC2100B2 02003965
	v_fma_mixhi_f16 v178, v102, s28, 0                         // 00000019A978: CC2200B2 02003966
	ds_load_b128 v[99:102], v127 offset:192                    // 00000019A980: DBFC00C0 6300007F
	v_fma_mixhi_f16 v175, v186, s28, 0                         // 00000019A988: CC2200AF 020039BA
	v_fma_mixlo_f16 v176, v187, s28, 0                         // 00000019A990: CC2100B0 020039BB
	v_fma_mixhi_f16 v176, v188, s28, 0                         // 00000019A998: CC2200B0 020039BC
	v_fma_mixlo_f16 v179, v189, s28, 0                         // 00000019A9A0: CC2100B3 020039BD
	v_fma_mixhi_f16 v179, v190, s28, 0                         // 00000019A9A8: CC2200B3 020039BE
	v_fma_mixlo_f16 v180, v191, s28, 0                         // 00000019A9B0: CC2100B4 020039BF
	v_fma_mixhi_f16 v180, v192, s28, 0                         // 00000019A9B8: CC2200B4 020039C0
	v_fma_mixlo_f16 v181, v193, s28, 0                         // 00000019A9C0: CC2100B5 020039C1
	v_fma_mixhi_f16 v181, v194, s28, 0                         // 00000019A9C8: CC2200B5 020039C2
	v_fma_mixlo_f16 v182, v195, s28, 0                         // 00000019A9D0: CC2100B6 020039C3
	v_fma_mixhi_f16 v182, v196, s28, 0                         // 00000019A9D8: CC2200B6 020039C4
	v_fma_mixlo_f16 v183, v197, s28, 0                         // 00000019A9E0: CC2100B7 020039C5
	v_fma_mixhi_f16 v183, v198, s28, 0                         // 00000019A9E8: CC2200B7 020039C6
	v_fma_mixlo_f16 v184, v199, s28, 0                         // 00000019A9F0: CC2100B8 020039C7
	v_fma_mixhi_f16 v184, v200, s28, 0                         // 00000019A9F8: CC2200B8 020039C8
	v_fma_mixlo_f16 v185, v201, s28, 0                         // 00000019AA00: CC2100B9 020039C9
	v_fma_mixhi_f16 v185, v202, s28, 0                         // 00000019AA08: CC2200B9 020039CA
	v_fma_mixlo_f16 v186, v203, s28, 0                         // 00000019AA10: CC2100BA 020039CB
	v_fma_mixhi_f16 v186, v204, s28, 0                         // 00000019AA18: CC2200BA 020039CC
	v_fma_mixlo_f16 v187, v205, s28, 0                         // 00000019AA20: CC2100BB 020039CD
	v_fma_mixhi_f16 v187, v206, s28, 0                         // 00000019AA28: CC2200BB 020039CE
	v_fma_mixlo_f16 v188, v207, s28, 0                         // 00000019AA30: CC2100BC 020039CF
	v_fma_mixhi_f16 v188, v208, s28, 0                         // 00000019AA38: CC2200BC 020039D0
	ds_load_b128 v[189:192], v127 offset:208                   // 00000019AA40: DBFC00D0 BD00007F
	ds_load_b128 v[193:196], v127 offset:224                   // 00000019AA48: DBFC00E0 C100007F
	s_waitcnt vmcnt(10)                                        // 00000019AA50: BF892BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[73:80], v[81:88], v[41:48]// 00000019AA54: CC404029 1CA6A349
	ds_load_b128 v[81:84], v127 offset:240                     // 00000019AA5C: DBFC00F0 5100007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[89:96], v[17:24]// 00000019AA64: CC404011 1C46B349
	v_wmma_f32_16x16x16_f16 v[49:56], v[73:80], v[173:180], v[49:56]// 00000019AA6C: CC404031 1CC75B49
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[181:188], v[25:32]// 00000019AA74: CC404019 1C676B49
	ds_load_b128 v[85:88], v127 offset:8640                    // 00000019AA7C: DBFC21C0 5500007F
	ds_load_b128 v[89:92], v127 offset:8656                    // 00000019AA84: DBFC21D0 5900007F
	s_waitcnt lgkmcnt(5)                                       // 00000019AA8C: BF89FC57
	v_fma_mixlo_f16 v73, v99, s28, 0                           // 00000019AA90: CC210049 02003963
	v_fma_mixhi_f16 v73, v100, s28, 0                          // 00000019AA98: CC220049 02003964
	v_fma_mixlo_f16 v74, v101, s28, 0                          // 00000019AAA0: CC21004A 02003965
	v_fma_mixhi_f16 v74, v102, s28, 0                          // 00000019AAA8: CC22004A 02003966
	ds_load_b128 v[93:96], v127 offset:8672                    // 00000019AAB0: DBFC21E0 5D00007F
	ds_load_b128 v[99:102], v127 offset:8688                   // 00000019AAB8: DBFC21F0 6300007F
	ds_load_b128 v[173:176], v127 offset:17088                 // 00000019AAC0: DBFC42C0 AD00007F
	ds_load_b128 v[177:180], v127 offset:17104                 // 00000019AAC8: DBFC42D0 B100007F
	ds_load_b128 v[181:184], v127 offset:17120                 // 00000019AAD0: DBFC42E0 B500007F
	ds_load_b128 v[185:188], v127 offset:17136                 // 00000019AAD8: DBFC42F0 B900007F
	s_waitcnt lgkmcnt(10)                                      // 00000019AAE0: BF89FCA7
	v_fma_mixlo_f16 v75, v189, s28, 0                          // 00000019AAE4: CC21004B 020039BD
	v_fma_mixhi_f16 v75, v190, s28, 0                          // 00000019AAEC: CC22004B 020039BE
	v_fma_mixlo_f16 v76, v191, s28, 0                          // 00000019AAF4: CC21004C 020039BF
	s_waitcnt lgkmcnt(8)                                       // 00000019AAFC: BF89FC87
	v_fma_mixhi_f16 v79, v82, s28, 0                           // 00000019AB00: CC22004F 02003952
	v_fma_mixhi_f16 v76, v192, s28, 0                          // 00000019AB08: CC22004C 020039C0
	v_fma_mixlo_f16 v77, v193, s28, 0                          // 00000019AB10: CC21004D 020039C1
	v_fma_mixhi_f16 v77, v194, s28, 0                          // 00000019AB18: CC22004D 020039C2
	s_waitcnt lgkmcnt(7)                                       // 00000019AB20: BF89FC77
	v_fma_mixlo_f16 v82, v87, s28, 0                           // 00000019AB24: CC210052 02003957
	v_fma_mixhi_f16 v82, v88, s28, 0                           // 00000019AB2C: CC220052 02003958
	v_fma_mixlo_f16 v78, v195, s28, 0                          // 00000019AB34: CC21004E 020039C3
	v_fma_mixhi_f16 v78, v196, s28, 0                          // 00000019AB3C: CC22004E 020039C4
	v_fma_mixlo_f16 v79, v81, s28, 0                           // 00000019AB44: CC21004F 02003951
	v_fma_mixhi_f16 v80, v84, s28, 0                           // 00000019AB4C: CC220050 02003954
	v_fma_mixlo_f16 v81, v85, s28, 0                           // 00000019AB54: CC210051 02003955
	s_waitcnt lgkmcnt(4)                                       // 00000019AB5C: BF89FC47
	v_fma_mixlo_f16 v87, v99, s28, 0                           // 00000019AB60: CC210057 02003963
	v_fma_mixhi_f16 v87, v100, s28, 0                          // 00000019AB68: CC220057 02003964
	v_fma_mixlo_f16 v88, v101, s28, 0                          // 00000019AB70: CC210058 02003965
	v_fma_mixhi_f16 v88, v102, s28, 0                          // 00000019AB78: CC220058 02003966
	ds_load_b128 v[99:102], v127 offset:25536                  // 00000019AB80: DBFC63C0 6300007F
	ds_load_b128 v[189:192], v127 offset:25552                 // 00000019AB88: DBFC63D0 BD00007F
	v_fma_mixhi_f16 v84, v92, s28, 0                           // 00000019AB90: CC220054 0200395C
	v_fma_mixlo_f16 v85, v93, s28, 0                           // 00000019AB98: CC210055 0200395D
	s_waitcnt lgkmcnt(4)                                       // 00000019ABA0: BF89FC47
	v_fma_mixlo_f16 v92, v179, s28, 0                          // 00000019ABA4: CC21005C 020039B3
	ds_load_b128 v[193:196], v127 offset:25568                 // 00000019ABAC: DBFC63E0 C100007F
	v_fma_mixhi_f16 v92, v180, s28, 0                          // 00000019ABB4: CC22005C 020039B4
	s_waitcnt lgkmcnt(4)                                       // 00000019ABBC: BF89FC47
	v_fma_mixlo_f16 v93, v181, s28, 0                          // 00000019ABC0: CC21005D 020039B5
	v_fma_mixhi_f16 v93, v182, s28, 0                          // 00000019ABC8: CC22005D 020039B6
	ds_load_b128 v[179:182], v127 offset:25584                 // 00000019ABD0: DBFC63F0 B300007F
	v_fma_mixlo_f16 v80, v83, s28, 0                           // 00000019ABD8: CC210050 02003953
	v_fma_mixlo_f16 v83, v89, s28, 0                           // 00000019ABE0: CC210053 02003959
	v_fma_mixlo_f16 v89, v173, s28, 0                          // 00000019ABE8: CC210059 020039AD
	v_fma_mixhi_f16 v89, v174, s28, 0                          // 00000019ABF0: CC220059 020039AE
	v_fma_mixhi_f16 v81, v86, s28, 0                           // 00000019ABF8: CC220051 02003956
	v_fma_mixhi_f16 v83, v90, s28, 0                           // 00000019AC00: CC220053 0200395A
	v_fma_mixlo_f16 v84, v91, s28, 0                           // 00000019AC08: CC210054 0200395B
	v_fma_mixhi_f16 v85, v94, s28, 0                           // 00000019AC10: CC220055 0200395E
	v_fma_mixlo_f16 v86, v95, s28, 0                           // 00000019AC18: CC210056 0200395F
	v_fma_mixhi_f16 v86, v96, s28, 0                           // 00000019AC20: CC220056 02003960
	s_waitcnt lgkmcnt(3)                                       // 00000019AC28: BF89FC37
	v_fma_mixlo_f16 v173, v99, s28, 0                          // 00000019AC2C: CC2100AD 02003963
	v_fma_mixhi_f16 v173, v100, s28, 0                         // 00000019AC34: CC2200AD 02003964
	v_fma_mixlo_f16 v174, v101, s28, 0                         // 00000019AC3C: CC2100AE 02003965
	v_fma_mixhi_f16 v174, v102, s28, 0                         // 00000019AC44: CC2200AE 02003966
	ds_load_b128 v[99:102], v127 offset:256                    // 00000019AC4C: DBFC0100 6300007F
	v_fma_mixlo_f16 v90, v175, s28, 0                          // 00000019AC54: CC21005A 020039AF
	v_fma_mixhi_f16 v90, v176, s28, 0                          // 00000019AC5C: CC22005A 020039B0
	v_fma_mixlo_f16 v91, v177, s28, 0                          // 00000019AC64: CC21005B 020039B1
	v_fma_mixhi_f16 v91, v178, s28, 0                          // 00000019AC6C: CC22005B 020039B2
	v_fma_mixlo_f16 v94, v183, s28, 0                          // 00000019AC74: CC21005E 020039B7
	v_fma_mixhi_f16 v94, v184, s28, 0                          // 00000019AC7C: CC22005E 020039B8
	v_fma_mixlo_f16 v95, v185, s28, 0                          // 00000019AC84: CC21005F 020039B9
	v_fma_mixhi_f16 v95, v186, s28, 0                          // 00000019AC8C: CC22005F 020039BA
	v_fma_mixlo_f16 v96, v187, s28, 0                          // 00000019AC94: CC210060 020039BB
	v_fma_mixhi_f16 v96, v188, s28, 0                          // 00000019AC9C: CC220060 020039BC
	s_waitcnt lgkmcnt(3)                                       // 00000019ACA4: BF89FC37
	v_fma_mixlo_f16 v175, v189, s28, 0                         // 00000019ACA8: CC2100AF 020039BD
	v_fma_mixhi_f16 v175, v190, s28, 0                         // 00000019ACB0: CC2200AF 020039BE
	v_fma_mixlo_f16 v176, v191, s28, 0                         // 00000019ACB8: CC2100B0 020039BF
	v_fma_mixhi_f16 v176, v192, s28, 0                         // 00000019ACC0: CC2200B0 020039C0
	s_waitcnt lgkmcnt(2)                                       // 00000019ACC8: BF89FC27
	v_fma_mixlo_f16 v177, v193, s28, 0                         // 00000019ACCC: CC2100B1 020039C1
	v_fma_mixhi_f16 v177, v194, s28, 0                         // 00000019ACD4: CC2200B1 020039C2
	v_fma_mixlo_f16 v178, v195, s28, 0                         // 00000019ACDC: CC2100B2 020039C3
	v_fma_mixhi_f16 v178, v196, s28, 0                         // 00000019ACE4: CC2200B2 020039C4
	s_waitcnt lgkmcnt(1)                                       // 00000019ACEC: BF89FC17
	v_fma_mixlo_f16 v179, v179, s28, 0                         // 00000019ACF0: CC2100B3 020039B3
	v_fma_mixhi_f16 v179, v180, s28, 0                         // 00000019ACF8: CC2200B3 020039B4
	v_fma_mixlo_f16 v180, v181, s28, 0                         // 00000019AD00: CC2100B4 020039B5
	v_fma_mixhi_f16 v180, v182, s28, 0                         // 00000019AD08: CC2200B4 020039B6
	ds_load_b128 v[183:186], v127 offset:272                   // 00000019AD10: DBFC0110 B700007F
	ds_load_b128 v[187:190], v127 offset:288                   // 00000019AD18: DBFC0120 BB00007F
	s_waitcnt vmcnt(8)                                         // 00000019AD20: BF8923F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[73:80], v[41:48]// 00000019AD24: CC404029 1CA69341
	ds_load_b128 v[73:76], v127 offset:304                     // 00000019AD2C: DBFC0130 4900007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[65:72], v[81:88], v[17:24]// 00000019AD34: CC404011 1C46A341
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[89:96], v[49:56]// 00000019AD3C: CC404031 1CC6B341
	v_wmma_f32_16x16x16_f16 v[25:32], v[65:72], v[173:180], v[25:32]// 00000019AD44: CC404019 1C675B41
	ds_load_b128 v[77:80], v127 offset:8704                    // 00000019AD4C: DBFC2200 4D00007F
	ds_load_b128 v[81:84], v127 offset:8720                    // 00000019AD54: DBFC2210 5100007F
	s_waitcnt lgkmcnt(5)                                       // 00000019AD5C: BF89FC57
	v_fma_mixlo_f16 v65, v99, s28, 0                           // 00000019AD60: CC210041 02003963
	v_fma_mixhi_f16 v65, v100, s28, 0                          // 00000019AD68: CC220041 02003964
	v_fma_mixlo_f16 v66, v101, s28, 0                          // 00000019AD70: CC210042 02003965
	v_fma_mixhi_f16 v66, v102, s28, 0                          // 00000019AD78: CC220042 02003966
	ds_load_b128 v[85:88], v127 offset:8736                    // 00000019AD80: DBFC2220 5500007F
	ds_load_b128 v[89:92], v127 offset:8752                    // 00000019AD88: DBFC2230 5900007F
	ds_load_b128 v[93:96], v127 offset:17152                   // 00000019AD90: DBFC4300 5D00007F
	ds_load_b128 v[99:102], v127 offset:17168                  // 00000019AD98: DBFC4310 6300007F
	ds_load_b128 v[173:176], v127 offset:17184                 // 00000019ADA0: DBFC4320 AD00007F
	ds_load_b128 v[177:180], v127 offset:17200                 // 00000019ADA8: DBFC4330 B100007F
	s_waitcnt lgkmcnt(10)                                      // 00000019ADB0: BF89FCA7
	v_fma_mixlo_f16 v67, v183, s28, 0                          // 00000019ADB4: CC210043 020039B7
	v_fma_mixhi_f16 v67, v184, s28, 0                          // 00000019ADBC: CC220043 020039B8
	ds_load_b128 v[181:184], v127 offset:25616                 // 00000019ADC4: DBFC6410 B500007F
	s_waitcnt lgkmcnt(9)                                       // 00000019ADCC: BF89FC97
	v_fma_mixhi_f16 v71, v74, s28, 0                           // 00000019ADD0: CC220047 0200394A
	v_fma_mixlo_f16 v72, v75, s28, 0                           // 00000019ADD8: CC210048 0200394B
	v_fma_mixhi_f16 v72, v76, s28, 0                           // 00000019ADE0: CC220048 0200394C
	v_fma_mixlo_f16 v68, v185, s28, 0                          // 00000019ADE8: CC210044 020039B9
	s_waitcnt lgkmcnt(8)                                       // 00000019ADF0: BF89FC87
	v_fma_mixlo_f16 v74, v79, s28, 0                           // 00000019ADF4: CC21004A 0200394F
	v_fma_mixhi_f16 v74, v80, s28, 0                           // 00000019ADFC: CC22004A 02003950
	s_waitcnt lgkmcnt(7)                                       // 00000019AE04: BF89FC77
	v_fma_mixlo_f16 v75, v81, s28, 0                           // 00000019AE08: CC21004B 02003951
	v_fma_mixhi_f16 v75, v82, s28, 0                           // 00000019AE10: CC22004B 02003952
	v_fma_mixlo_f16 v76, v83, s28, 0                           // 00000019AE18: CC21004C 02003953
	v_fma_mixhi_f16 v76, v84, s28, 0                           // 00000019AE20: CC22004C 02003954
	v_fma_mixhi_f16 v68, v186, s28, 0                          // 00000019AE28: CC220044 020039BA
	s_waitcnt lgkmcnt(5)                                       // 00000019AE30: BF89FC57
	v_fma_mixlo_f16 v79, v89, s28, 0                           // 00000019AE34: CC21004F 02003959
	v_fma_mixhi_f16 v79, v90, s28, 0                           // 00000019AE3C: CC22004F 0200395A
	v_fma_mixlo_f16 v80, v91, s28, 0                           // 00000019AE44: CC210050 0200395B
	v_fma_mixhi_f16 v80, v92, s28, 0                           // 00000019AE4C: CC220050 0200395C
	ds_load_b128 v[89:92], v127 offset:25600                   // 00000019AE54: DBFC6400 5900007F
	s_waitcnt lgkmcnt(5)                                       // 00000019AE5C: BF89FC57
	v_fma_mixlo_f16 v81, v93, s28, 0                           // 00000019AE60: CC210051 0200395D
	v_fma_mixhi_f16 v81, v94, s28, 0                           // 00000019AE68: CC220051 0200395E
	v_fma_mixlo_f16 v82, v95, s28, 0                           // 00000019AE70: CC210052 0200395F
	v_fma_mixhi_f16 v82, v96, s28, 0                           // 00000019AE78: CC220052 02003960
	s_waitcnt lgkmcnt(4)                                       // 00000019AE80: BF89FC47
	v_fma_mixlo_f16 v83, v99, s28, 0                           // 00000019AE84: CC210053 02003963
	v_fma_mixhi_f16 v83, v100, s28, 0                          // 00000019AE8C: CC220053 02003964
	v_fma_mixlo_f16 v84, v101, s28, 0                          // 00000019AE94: CC210054 02003965
	ds_load_b128 v[93:96], v127 offset:25632                   // 00000019AE9C: DBFC6420 5D00007F
	v_fma_mixhi_f16 v84, v102, s28, 0                          // 00000019AEA4: CC220054 02003966
	ds_load_b128 v[99:102], v127 offset:25648                  // 00000019AEAC: DBFC6430 6300007F
	v_fma_mixlo_f16 v69, v187, s28, 0                          // 00000019AEB4: CC210045 020039BB
	v_fma_mixhi_f16 v69, v188, s28, 0                          // 00000019AEBC: CC220045 020039BC
	v_fma_mixlo_f16 v70, v189, s28, 0                          // 00000019AEC4: CC210046 020039BD
	v_fma_mixhi_f16 v70, v190, s28, 0                          // 00000019AECC: CC220046 020039BE
	v_fma_mixlo_f16 v71, v73, s28, 0                           // 00000019AED4: CC210047 02003949
	v_fma_mixlo_f16 v73, v77, s28, 0                           // 00000019AEDC: CC210049 0200394D
	v_fma_mixhi_f16 v73, v78, s28, 0                           // 00000019AEE4: CC220049 0200394E
	v_fma_mixlo_f16 v77, v85, s28, 0                           // 00000019AEEC: CC21004D 02003955
	v_fma_mixhi_f16 v77, v86, s28, 0                           // 00000019AEF4: CC22004D 02003956
	v_fma_mixlo_f16 v78, v87, s28, 0                           // 00000019AEFC: CC21004E 02003957
	v_fma_mixhi_f16 v78, v88, s28, 0                           // 00000019AF04: CC22004E 02003958
	s_waitcnt lgkmcnt(5)                                       // 00000019AF0C: BF89FC57
	v_fma_mixlo_f16 v85, v173, s28, 0                          // 00000019AF10: CC210055 020039AD
	v_fma_mixhi_f16 v85, v174, s28, 0                          // 00000019AF18: CC220055 020039AE
	v_fma_mixlo_f16 v86, v175, s28, 0                          // 00000019AF20: CC210056 020039AF
	v_fma_mixhi_f16 v86, v176, s28, 0                          // 00000019AF28: CC220056 020039B0
	s_waitcnt lgkmcnt(4)                                       // 00000019AF30: BF89FC47
	v_fma_mixlo_f16 v87, v177, s28, 0                          // 00000019AF34: CC210057 020039B1
	v_fma_mixhi_f16 v87, v178, s28, 0                          // 00000019AF3C: CC220057 020039B2
	v_fma_mixlo_f16 v88, v179, s28, 0                          // 00000019AF44: CC210058 020039B3
	v_fma_mixhi_f16 v88, v180, s28, 0                          // 00000019AF4C: CC220058 020039B4
	s_waitcnt lgkmcnt(2)                                       // 00000019AF54: BF89FC27
	v_fma_mixlo_f16 v89, v89, s28, 0                           // 00000019AF58: CC210059 02003959
	v_fma_mixhi_f16 v89, v90, s28, 0                           // 00000019AF60: CC220059 0200395A
	v_fma_mixlo_f16 v90, v91, s28, 0                           // 00000019AF68: CC21005A 0200395B
	v_fma_mixhi_f16 v90, v92, s28, 0                           // 00000019AF70: CC22005A 0200395C
	v_fma_mixlo_f16 v91, v181, s28, 0                          // 00000019AF78: CC21005B 020039B5
	v_fma_mixhi_f16 v91, v182, s28, 0                          // 00000019AF80: CC22005B 020039B6
	v_fma_mixlo_f16 v92, v183, s28, 0                          // 00000019AF88: CC21005C 020039B7
	v_fma_mixhi_f16 v92, v184, s28, 0                          // 00000019AF90: CC22005C 020039B8
	s_waitcnt lgkmcnt(1)                                       // 00000019AF98: BF89FC17
	v_fma_mixlo_f16 v93, v93, s28, 0                           // 00000019AF9C: CC21005D 0200395D
	v_fma_mixhi_f16 v93, v94, s28, 0                           // 00000019AFA4: CC22005D 0200395E
	v_fma_mixlo_f16 v94, v95, s28, 0                           // 00000019AFAC: CC21005E 0200395F
	v_fma_mixhi_f16 v94, v96, s28, 0                           // 00000019AFB4: CC22005E 02003960
	s_waitcnt lgkmcnt(0)                                       // 00000019AFBC: BF89FC07
	v_fma_mixlo_f16 v95, v99, s28, 0                           // 00000019AFC0: CC21005F 02003963
	v_fma_mixhi_f16 v95, v100, s28, 0                          // 00000019AFC8: CC22005F 02003964
	v_fma_mixlo_f16 v96, v101, s28, 0                          // 00000019AFD0: CC210060 02003965
	v_fma_mixhi_f16 v96, v102, s28, 0                          // 00000019AFD8: CC220060 02003966
	ds_load_b128 v[173:176], v127 offset:320                   // 00000019AFE0: DBFC0140 AD00007F
	ds_load_b128 v[177:180], v127 offset:336                   // 00000019AFE8: DBFC0150 B100007F
	ds_load_b128 v[181:184], v127 offset:352                   // 00000019AFF0: DBFC0160 B500007F
	s_waitcnt vmcnt(6)                                         // 00000019AFF8: BF891BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[57:64], v[65:72], v[41:48]// 00000019AFFC: CC404029 1CA68339
	ds_load_b128 v[65:68], v127 offset:368                     // 00000019B004: DBFC0170 4100007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[73:80], v[17:24]// 00000019B00C: CC404011 1C469339
	v_wmma_f32_16x16x16_f16 v[49:56], v[57:64], v[81:88], v[49:56]// 00000019B014: CC404031 1CC6A339
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[89:96], v[25:32]// 00000019B01C: CC404019 1C66B339
	ds_load_b128 v[69:72], v127 offset:8768                    // 00000019B024: DBFC2240 4500007F
	ds_load_b128 v[73:76], v127 offset:8784                    // 00000019B02C: DBFC2250 4900007F
	ds_load_b128 v[77:80], v127 offset:8800                    // 00000019B034: DBFC2260 4D00007F
	ds_load_b128 v[81:84], v127 offset:8816                    // 00000019B03C: DBFC2270 5100007F
	ds_load_b128 v[85:88], v127 offset:17216                   // 00000019B044: DBFC4340 5500007F
	ds_load_b128 v[89:92], v127 offset:17232                   // 00000019B04C: DBFC4350 5900007F
	ds_load_b128 v[93:96], v127 offset:17248                   // 00000019B054: DBFC4360 5D00007F
	ds_load_b128 v[99:102], v127 offset:17264                  // 00000019B05C: DBFC4370 6300007F
	s_waitcnt lgkmcnt(11)                                      // 00000019B064: BF89FCB7
	v_fma_mixlo_f16 v57, v173, s28, 0                          // 00000019B068: CC210039 020039AD
	v_fma_mixhi_f16 v57, v174, s28, 0                          // 00000019B070: CC220039 020039AE
	v_fma_mixlo_f16 v58, v175, s28, 0                          // 00000019B078: CC21003A 020039AF
	v_fma_mixhi_f16 v58, v176, s28, 0                          // 00000019B080: CC22003A 020039B0
	s_waitcnt lgkmcnt(8)                                       // 00000019B088: BF89FC87
	v_fma_mixhi_f16 v63, v66, s28, 0                           // 00000019B08C: CC22003F 02003942
	v_fma_mixlo_f16 v64, v67, s28, 0                           // 00000019B094: CC210040 02003943
	v_fma_mixhi_f16 v64, v68, s28, 0                           // 00000019B09C: CC220040 02003944
	ds_load_b128 v[173:176], v127 offset:25680                 // 00000019B0A4: DBFC6450 AD00007F
	s_waitcnt lgkmcnt(8)                                       // 00000019B0AC: BF89FC87
	v_fma_mixlo_f16 v66, v71, s28, 0                           // 00000019B0B0: CC210042 02003947
	v_fma_mixhi_f16 v66, v72, s28, 0                           // 00000019B0B8: CC220042 02003948
	s_waitcnt lgkmcnt(7)                                       // 00000019B0C0: BF89FC77
	v_fma_mixlo_f16 v67, v73, s28, 0                           // 00000019B0C4: CC210043 02003949
	v_fma_mixhi_f16 v67, v74, s28, 0                           // 00000019B0CC: CC220043 0200394A
	v_fma_mixlo_f16 v68, v75, s28, 0                           // 00000019B0D4: CC210044 0200394B
	v_fma_mixhi_f16 v68, v76, s28, 0                           // 00000019B0DC: CC220044 0200394C
	s_waitcnt lgkmcnt(5)                                       // 00000019B0E4: BF89FC57
	v_fma_mixlo_f16 v71, v81, s28, 0                           // 00000019B0E8: CC210047 02003951
	v_fma_mixhi_f16 v71, v82, s28, 0                           // 00000019B0F0: CC220047 02003952
	v_fma_mixlo_f16 v72, v83, s28, 0                           // 00000019B0F8: CC210048 02003953
	v_fma_mixhi_f16 v72, v84, s28, 0                           // 00000019B100: CC220048 02003954
	ds_load_b128 v[81:84], v127 offset:25664                   // 00000019B108: DBFC6440 5100007F
	s_waitcnt lgkmcnt(5)                                       // 00000019B110: BF89FC57
	v_fma_mixlo_f16 v73, v85, s28, 0                           // 00000019B114: CC210049 02003955
	v_fma_mixhi_f16 v73, v86, s28, 0                           // 00000019B11C: CC220049 02003956
	v_fma_mixlo_f16 v74, v87, s28, 0                           // 00000019B124: CC21004A 02003957
	v_fma_mixhi_f16 v74, v88, s28, 0                           // 00000019B12C: CC22004A 02003958
	s_waitcnt lgkmcnt(4)                                       // 00000019B134: BF89FC47
	v_fma_mixlo_f16 v75, v89, s28, 0                           // 00000019B138: CC21004B 02003959
	v_fma_mixhi_f16 v75, v90, s28, 0                           // 00000019B140: CC22004B 0200395A
	v_fma_mixlo_f16 v76, v91, s28, 0                           // 00000019B148: CC21004C 0200395B
	ds_load_b128 v[85:88], v127 offset:25696                   // 00000019B150: DBFC6460 5500007F
	v_fma_mixhi_f16 v76, v92, s28, 0                           // 00000019B158: CC22004C 0200395C
	ds_load_b128 v[89:92], v127 offset:25712                   // 00000019B160: DBFC6470 5900007F
	v_fma_mixlo_f16 v59, v177, s28, 0                          // 00000019B168: CC21003B 020039B1
	v_fma_mixhi_f16 v59, v178, s28, 0                          // 00000019B170: CC22003B 020039B2
	v_fma_mixlo_f16 v60, v179, s28, 0                          // 00000019B178: CC21003C 020039B3
	v_fma_mixhi_f16 v60, v180, s28, 0                          // 00000019B180: CC22003C 020039B4
	v_fma_mixlo_f16 v61, v181, s28, 0                          // 00000019B188: CC21003D 020039B5
	v_fma_mixhi_f16 v61, v182, s28, 0                          // 00000019B190: CC22003D 020039B6
	v_fma_mixlo_f16 v62, v183, s28, 0                          // 00000019B198: CC21003E 020039B7
	v_fma_mixhi_f16 v62, v184, s28, 0                          // 00000019B1A0: CC22003E 020039B8
	v_fma_mixlo_f16 v63, v65, s28, 0                           // 00000019B1A8: CC21003F 02003941
	v_fma_mixlo_f16 v65, v69, s28, 0                           // 00000019B1B0: CC210041 02003945
	v_fma_mixhi_f16 v65, v70, s28, 0                           // 00000019B1B8: CC220041 02003946
	v_fma_mixlo_f16 v69, v77, s28, 0                           // 00000019B1C0: CC210045 0200394D
	v_fma_mixhi_f16 v69, v78, s28, 0                           // 00000019B1C8: CC220045 0200394E
	v_fma_mixlo_f16 v70, v79, s28, 0                           // 00000019B1D0: CC210046 0200394F
	v_fma_mixhi_f16 v70, v80, s28, 0                           // 00000019B1D8: CC220046 02003950
	s_waitcnt lgkmcnt(5)                                       // 00000019B1E0: BF89FC57
	v_fma_mixlo_f16 v77, v93, s28, 0                           // 00000019B1E4: CC21004D 0200395D
	v_fma_mixhi_f16 v77, v94, s28, 0                           // 00000019B1EC: CC22004D 0200395E
	v_fma_mixlo_f16 v78, v95, s28, 0                           // 00000019B1F4: CC21004E 0200395F
	v_fma_mixhi_f16 v78, v96, s28, 0                           // 00000019B1FC: CC22004E 02003960
	s_waitcnt lgkmcnt(4)                                       // 00000019B204: BF89FC47
	v_fma_mixlo_f16 v79, v99, s28, 0                           // 00000019B208: CC21004F 02003963
	v_fma_mixhi_f16 v79, v100, s28, 0                          // 00000019B210: CC22004F 02003964
	v_fma_mixlo_f16 v80, v101, s28, 0                          // 00000019B218: CC210050 02003965
	v_fma_mixhi_f16 v80, v102, s28, 0                          // 00000019B220: CC220050 02003966
	s_waitcnt lgkmcnt(2)                                       // 00000019B228: BF89FC27
	v_fma_mixlo_f16 v81, v81, s28, 0                           // 00000019B22C: CC210051 02003951
	v_fma_mixhi_f16 v81, v82, s28, 0                           // 00000019B234: CC220051 02003952
	v_fma_mixlo_f16 v82, v83, s28, 0                           // 00000019B23C: CC210052 02003953
	v_fma_mixhi_f16 v82, v84, s28, 0                           // 00000019B244: CC220052 02003954
	v_fma_mixlo_f16 v83, v173, s28, 0                          // 00000019B24C: CC210053 020039AD
	v_fma_mixhi_f16 v83, v174, s28, 0                          // 00000019B254: CC220053 020039AE
	v_fma_mixlo_f16 v84, v175, s28, 0                          // 00000019B25C: CC210054 020039AF
	v_fma_mixhi_f16 v84, v176, s28, 0                          // 00000019B264: CC220054 020039B0
	s_waitcnt lgkmcnt(1)                                       // 00000019B26C: BF89FC17
	v_fma_mixlo_f16 v85, v85, s28, 0                           // 00000019B270: CC210055 02003955
	v_fma_mixhi_f16 v85, v86, s28, 0                           // 00000019B278: CC220055 02003956
	v_fma_mixlo_f16 v86, v87, s28, 0                           // 00000019B280: CC210056 02003957
	v_fma_mixhi_f16 v86, v88, s28, 0                           // 00000019B288: CC220056 02003958
	s_waitcnt lgkmcnt(0)                                       // 00000019B290: BF89FC07
	v_fma_mixlo_f16 v87, v89, s28, 0                           // 00000019B294: CC210057 02003959
	v_fma_mixhi_f16 v87, v90, s28, 0                           // 00000019B29C: CC220057 0200395A
	v_fma_mixlo_f16 v88, v91, s28, 0                           // 00000019B2A4: CC210058 0200395B
	v_fma_mixhi_f16 v88, v92, s28, 0                           // 00000019B2AC: CC220058 0200395C
	ds_load_b128 v[93:96], v127 offset:384                     // 00000019B2B4: DBFC0180 5D00007F
	ds_load_b128 v[99:102], v127 offset:400                    // 00000019B2BC: DBFC0190 6300007F
	ds_load_b128 v[173:176], v127 offset:416                   // 00000019B2C4: DBFC01A0 AD00007F
	s_waitcnt vmcnt(4)                                         // 00000019B2CC: BF8913F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[33:40], v[57:64], v[41:48]// 00000019B2D0: CC404029 1CA67321
	ds_load_b128 v[57:60], v127 offset:432                     // 00000019B2D8: DBFC01B0 3900007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[65:72], v[17:24]// 00000019B2E0: CC404011 1C468321
	v_wmma_f32_16x16x16_f16 v[49:56], v[33:40], v[73:80], v[49:56]// 00000019B2E8: CC404031 1CC69321
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[81:88], v[25:32]// 00000019B2F0: CC404019 1C66A321
	ds_load_b128 v[61:64], v127 offset:8832                    // 00000019B2F8: DBFC2280 3D00007F
	ds_load_b128 v[65:68], v127 offset:8848                    // 00000019B300: DBFC2290 4100007F
	ds_load_b128 v[69:72], v127 offset:8864                    // 00000019B308: DBFC22A0 4500007F
	ds_load_b128 v[73:76], v127 offset:8880                    // 00000019B310: DBFC22B0 4900007F
	ds_load_b128 v[77:80], v127 offset:17280                   // 00000019B318: DBFC4380 4D00007F
	ds_load_b128 v[81:84], v127 offset:17296                   // 00000019B320: DBFC4390 5100007F
	ds_load_b128 v[85:88], v127 offset:17312                   // 00000019B328: DBFC43A0 5500007F
	ds_load_b128 v[89:92], v127 offset:17328                   // 00000019B330: DBFC43B0 5900007F
	s_waitcnt lgkmcnt(11)                                      // 00000019B338: BF89FCB7
	v_fma_mixlo_f16 v33, v93, s28, 0                           // 00000019B33C: CC210021 0200395D
	v_fma_mixhi_f16 v33, v94, s28, 0                           // 00000019B344: CC220021 0200395E
	v_fma_mixlo_f16 v34, v95, s28, 0                           // 00000019B34C: CC210022 0200395F
	v_fma_mixhi_f16 v34, v96, s28, 0                           // 00000019B354: CC220022 02003960
	s_waitcnt lgkmcnt(8)                                       // 00000019B35C: BF89FC87
	v_fma_mixhi_f16 v39, v58, s28, 0                           // 00000019B360: CC220027 0200393A
	v_fma_mixlo_f16 v40, v59, s28, 0                           // 00000019B368: CC210028 0200393B
	v_fma_mixhi_f16 v40, v60, s28, 0                           // 00000019B370: CC220028 0200393C
	ds_load_b128 v[93:96], v127 offset:25744                   // 00000019B378: DBFC6490 5D00007F
	s_waitcnt lgkmcnt(8)                                       // 00000019B380: BF89FC87
	v_fma_mixlo_f16 v58, v63, s28, 0                           // 00000019B384: CC21003A 0200393F
	v_fma_mixhi_f16 v58, v64, s28, 0                           // 00000019B38C: CC22003A 02003940
	s_waitcnt lgkmcnt(7)                                       // 00000019B394: BF89FC77
	v_fma_mixlo_f16 v59, v65, s28, 0                           // 00000019B398: CC21003B 02003941
	v_fma_mixhi_f16 v59, v66, s28, 0                           // 00000019B3A0: CC22003B 02003942
	v_fma_mixlo_f16 v60, v67, s28, 0                           // 00000019B3A8: CC21003C 02003943
	v_fma_mixhi_f16 v60, v68, s28, 0                           // 00000019B3B0: CC22003C 02003944
	s_waitcnt lgkmcnt(5)                                       // 00000019B3B8: BF89FC57
	v_fma_mixlo_f16 v63, v73, s28, 0                           // 00000019B3BC: CC21003F 02003949
	v_fma_mixhi_f16 v63, v74, s28, 0                           // 00000019B3C4: CC22003F 0200394A
	v_fma_mixlo_f16 v64, v75, s28, 0                           // 00000019B3CC: CC210040 0200394B
	v_fma_mixhi_f16 v64, v76, s28, 0                           // 00000019B3D4: CC220040 0200394C
	ds_load_b128 v[73:76], v127 offset:25728                   // 00000019B3DC: DBFC6480 4900007F
	s_waitcnt lgkmcnt(5)                                       // 00000019B3E4: BF89FC57
	v_fma_mixlo_f16 v65, v77, s28, 0                           // 00000019B3E8: CC210041 0200394D
	v_fma_mixhi_f16 v65, v78, s28, 0                           // 00000019B3F0: CC220041 0200394E
	v_fma_mixlo_f16 v66, v79, s28, 0                           // 00000019B3F8: CC210042 0200394F
	v_fma_mixhi_f16 v66, v80, s28, 0                           // 00000019B400: CC220042 02003950
	s_waitcnt lgkmcnt(4)                                       // 00000019B408: BF89FC47
	v_fma_mixlo_f16 v67, v81, s28, 0                           // 00000019B40C: CC210043 02003951
	v_fma_mixhi_f16 v67, v82, s28, 0                           // 00000019B414: CC220043 02003952
	v_fma_mixlo_f16 v68, v83, s28, 0                           // 00000019B41C: CC210044 02003953
	ds_load_b128 v[77:80], v127 offset:25760                   // 00000019B424: DBFC64A0 4D00007F
	v_fma_mixhi_f16 v68, v84, s28, 0                           // 00000019B42C: CC220044 02003954
	ds_load_b128 v[81:84], v127 offset:25776                   // 00000019B434: DBFC64B0 5100007F
	v_fma_mixlo_f16 v35, v99, s28, 0                           // 00000019B43C: CC210023 02003963
	v_fma_mixhi_f16 v35, v100, s28, 0                          // 00000019B444: CC220023 02003964
	v_fma_mixlo_f16 v36, v101, s28, 0                          // 00000019B44C: CC210024 02003965
	v_fma_mixhi_f16 v36, v102, s28, 0                          // 00000019B454: CC220024 02003966
	v_fma_mixlo_f16 v37, v173, s28, 0                          // 00000019B45C: CC210025 020039AD
	v_fma_mixhi_f16 v37, v174, s28, 0                          // 00000019B464: CC220025 020039AE
	v_fma_mixlo_f16 v38, v175, s28, 0                          // 00000019B46C: CC210026 020039AF
	v_fma_mixhi_f16 v38, v176, s28, 0                          // 00000019B474: CC220026 020039B0
	v_fma_mixlo_f16 v39, v57, s28, 0                           // 00000019B47C: CC210027 02003939
	v_fma_mixlo_f16 v57, v61, s28, 0                           // 00000019B484: CC210039 0200393D
	v_fma_mixhi_f16 v57, v62, s28, 0                           // 00000019B48C: CC220039 0200393E
	v_fma_mixlo_f16 v61, v69, s28, 0                           // 00000019B494: CC21003D 02003945
	v_fma_mixhi_f16 v61, v70, s28, 0                           // 00000019B49C: CC22003D 02003946
	v_fma_mixlo_f16 v62, v71, s28, 0                           // 00000019B4A4: CC21003E 02003947
	v_fma_mixhi_f16 v62, v72, s28, 0                           // 00000019B4AC: CC22003E 02003948
	s_waitcnt lgkmcnt(5)                                       // 00000019B4B4: BF89FC57
	v_fma_mixlo_f16 v69, v85, s28, 0                           // 00000019B4B8: CC210045 02003955
	v_fma_mixhi_f16 v69, v86, s28, 0                           // 00000019B4C0: CC220045 02003956
	v_fma_mixlo_f16 v70, v87, s28, 0                           // 00000019B4C8: CC210046 02003957
	v_fma_mixhi_f16 v70, v88, s28, 0                           // 00000019B4D0: CC220046 02003958
	s_waitcnt lgkmcnt(4)                                       // 00000019B4D8: BF89FC47
	v_fma_mixlo_f16 v71, v89, s28, 0                           // 00000019B4DC: CC210047 02003959
	v_fma_mixhi_f16 v71, v90, s28, 0                           // 00000019B4E4: CC220047 0200395A
	v_fma_mixlo_f16 v72, v91, s28, 0                           // 00000019B4EC: CC210048 0200395B
	v_fma_mixhi_f16 v72, v92, s28, 0                           // 00000019B4F4: CC220048 0200395C
	s_waitcnt lgkmcnt(2)                                       // 00000019B4FC: BF89FC27
	v_fma_mixlo_f16 v73, v73, s28, 0                           // 00000019B500: CC210049 02003949
	v_fma_mixhi_f16 v73, v74, s28, 0                           // 00000019B508: CC220049 0200394A
	v_fma_mixlo_f16 v74, v75, s28, 0                           // 00000019B510: CC21004A 0200394B
	v_fma_mixhi_f16 v74, v76, s28, 0                           // 00000019B518: CC22004A 0200394C
	v_fma_mixlo_f16 v75, v93, s28, 0                           // 00000019B520: CC21004B 0200395D
	v_fma_mixhi_f16 v75, v94, s28, 0                           // 00000019B528: CC22004B 0200395E
	v_fma_mixlo_f16 v76, v95, s28, 0                           // 00000019B530: CC21004C 0200395F
	v_fma_mixhi_f16 v76, v96, s28, 0                           // 00000019B538: CC22004C 02003960
	s_waitcnt lgkmcnt(1)                                       // 00000019B540: BF89FC17
	v_fma_mixlo_f16 v77, v77, s28, 0                           // 00000019B544: CC21004D 0200394D
	v_fma_mixhi_f16 v77, v78, s28, 0                           // 00000019B54C: CC22004D 0200394E
	v_fma_mixlo_f16 v78, v79, s28, 0                           // 00000019B554: CC21004E 0200394F
	v_fma_mixhi_f16 v78, v80, s28, 0                           // 00000019B55C: CC22004E 02003950
	s_waitcnt lgkmcnt(0)                                       // 00000019B564: BF89FC07
	v_fma_mixlo_f16 v79, v81, s28, 0                           // 00000019B568: CC21004F 02003951
	v_fma_mixhi_f16 v79, v82, s28, 0                           // 00000019B570: CC22004F 02003952
	v_fma_mixlo_f16 v80, v83, s28, 0                           // 00000019B578: CC210050 02003953
	v_fma_mixhi_f16 v80, v84, s28, 0                           // 00000019B580: CC220050 02003954
	ds_load_b128 v[85:88], v127 offset:448                     // 00000019B588: DBFC01C0 5500007F
	ds_load_b128 v[89:92], v127 offset:464                     // 00000019B590: DBFC01D0 5900007F
	ds_load_b128 v[93:96], v127 offset:480                     // 00000019B598: DBFC01E0 5D00007F
	s_waitcnt vmcnt(2)                                         // 00000019B5A0: BF890BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[9:16], v[33:40], v[41:48]// 00000019B5A4: CC404029 1CA64309
	ds_load_b128 v[33:36], v127 offset:496                     // 00000019B5AC: DBFC01F0 2100007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[9:16], v[57:64], v[17:24]// 00000019B5B4: CC404011 1C467309
	v_wmma_f32_16x16x16_f16 v[49:56], v[9:16], v[65:72], v[49:56]// 00000019B5BC: CC404031 1CC68309
	v_wmma_f32_16x16x16_f16 v[25:32], v[9:16], v[73:80], v[25:32]// 00000019B5C4: CC404019 1C669309
	ds_load_b128 v[37:40], v127 offset:8896                    // 00000019B5CC: DBFC22C0 2500007F
	ds_load_b128 v[57:60], v127 offset:8912                    // 00000019B5D4: DBFC22D0 3900007F
	ds_load_b128 v[61:64], v127 offset:8928                    // 00000019B5DC: DBFC22E0 3D00007F
	ds_load_b128 v[65:68], v127 offset:8944                    // 00000019B5E4: DBFC22F0 4100007F
	ds_load_b128 v[69:72], v127 offset:17344                   // 00000019B5EC: DBFC43C0 4500007F
	ds_load_b128 v[73:76], v127 offset:17360                   // 00000019B5F4: DBFC43D0 4900007F
	ds_load_b128 v[77:80], v127 offset:17376                   // 00000019B5FC: DBFC43E0 4D00007F
	ds_load_b128 v[81:84], v127 offset:17392                   // 00000019B604: DBFC43F0 5100007F
	s_waitcnt lgkmcnt(11)                                      // 00000019B60C: BF89FCB7
	v_fma_mixlo_f16 v9, v85, s28, 0                            // 00000019B610: CC210009 02003955
	v_fma_mixhi_f16 v9, v86, s28, 0                            // 00000019B618: CC220009 02003956
	v_fma_mixlo_f16 v10, v87, s28, 0                           // 00000019B620: CC21000A 02003957
	v_fma_mixhi_f16 v10, v88, s28, 0                           // 00000019B628: CC22000A 02003958
	s_waitcnt lgkmcnt(8)                                       // 00000019B630: BF89FC87
	v_fma_mixhi_f16 v15, v34, s28, 0                           // 00000019B634: CC22000F 02003922
	v_fma_mixlo_f16 v16, v35, s28, 0                           // 00000019B63C: CC210010 02003923
	v_fma_mixhi_f16 v16, v36, s28, 0                           // 00000019B644: CC220010 02003924
	ds_load_b128 v[85:88], v127 offset:25808                   // 00000019B64C: DBFC64D0 5500007F
	s_waitcnt lgkmcnt(8)                                       // 00000019B654: BF89FC87
	v_fma_mixlo_f16 v34, v39, s28, 0                           // 00000019B658: CC210022 02003927
	v_fma_mixhi_f16 v34, v40, s28, 0                           // 00000019B660: CC220022 02003928
	s_waitcnt lgkmcnt(7)                                       // 00000019B668: BF89FC77
	v_fma_mixlo_f16 v35, v57, s28, 0                           // 00000019B66C: CC210023 02003939
	v_fma_mixhi_f16 v35, v58, s28, 0                           // 00000019B674: CC220023 0200393A
	v_fma_mixlo_f16 v36, v59, s28, 0                           // 00000019B67C: CC210024 0200393B
	v_fma_mixhi_f16 v36, v60, s28, 0                           // 00000019B684: CC220024 0200393C
	s_waitcnt lgkmcnt(5)                                       // 00000019B68C: BF89FC57
	v_fma_mixlo_f16 v39, v65, s28, 0                           // 00000019B690: CC210027 02003941
	v_fma_mixhi_f16 v39, v66, s28, 0                           // 00000019B698: CC220027 02003942
	v_fma_mixlo_f16 v40, v67, s28, 0                           // 00000019B6A0: CC210028 02003943
	v_fma_mixhi_f16 v40, v68, s28, 0                           // 00000019B6A8: CC220028 02003944
	ds_load_b128 v[65:68], v127 offset:25792                   // 00000019B6B0: DBFC64C0 4100007F
	s_waitcnt lgkmcnt(5)                                       // 00000019B6B8: BF89FC57
	v_fma_mixlo_f16 v57, v69, s28, 0                           // 00000019B6BC: CC210039 02003945
	v_fma_mixhi_f16 v57, v70, s28, 0                           // 00000019B6C4: CC220039 02003946
	v_fma_mixlo_f16 v58, v71, s28, 0                           // 00000019B6CC: CC21003A 02003947
	v_fma_mixhi_f16 v58, v72, s28, 0                           // 00000019B6D4: CC22003A 02003948
	s_waitcnt lgkmcnt(4)                                       // 00000019B6DC: BF89FC47
	v_fma_mixlo_f16 v59, v73, s28, 0                           // 00000019B6E0: CC21003B 02003949
	v_fma_mixhi_f16 v59, v74, s28, 0                           // 00000019B6E8: CC22003B 0200394A
	ds_load_b128 v[69:72], v127 offset:25824                   // 00000019B6F0: DBFC64E0 4500007F
	v_fma_mixlo_f16 v60, v75, s28, 0                           // 00000019B6F8: CC21003C 0200394B
	v_fma_mixhi_f16 v60, v76, s28, 0                           // 00000019B700: CC22003C 0200394C
	ds_load_b128 v[73:76], v127 offset:25840                   // 00000019B708: DBFC64F0 4900007F
	v_fma_mixlo_f16 v11, v89, s28, 0                           // 00000019B710: CC21000B 02003959
	v_fma_mixhi_f16 v11, v90, s28, 0                           // 00000019B718: CC22000B 0200395A
	v_fma_mixlo_f16 v12, v91, s28, 0                           // 00000019B720: CC21000C 0200395B
	v_fma_mixhi_f16 v12, v92, s28, 0                           // 00000019B728: CC22000C 0200395C
	v_fma_mixlo_f16 v13, v93, s28, 0                           // 00000019B730: CC21000D 0200395D
	v_fma_mixhi_f16 v13, v94, s28, 0                           // 00000019B738: CC22000D 0200395E
	v_fma_mixlo_f16 v14, v95, s28, 0                           // 00000019B740: CC21000E 0200395F
	v_fma_mixhi_f16 v14, v96, s28, 0                           // 00000019B748: CC22000E 02003960
	v_fma_mixlo_f16 v15, v33, s28, 0                           // 00000019B750: CC21000F 02003921
	v_fma_mixlo_f16 v33, v37, s28, 0                           // 00000019B758: CC210021 02003925
	v_fma_mixhi_f16 v33, v38, s28, 0                           // 00000019B760: CC220021 02003926
	v_fma_mixlo_f16 v37, v61, s28, 0                           // 00000019B768: CC210025 0200393D
	v_fma_mixhi_f16 v37, v62, s28, 0                           // 00000019B770: CC220025 0200393E
	v_fma_mixlo_f16 v38, v63, s28, 0                           // 00000019B778: CC210026 0200393F
	v_fma_mixhi_f16 v38, v64, s28, 0                           // 00000019B780: CC220026 02003940
	s_waitcnt lgkmcnt(5)                                       // 00000019B788: BF89FC57
	v_fma_mixlo_f16 v61, v77, s28, 0                           // 00000019B78C: CC21003D 0200394D
	v_fma_mixhi_f16 v61, v78, s28, 0                           // 00000019B794: CC22003D 0200394E
	v_fma_mixlo_f16 v62, v79, s28, 0                           // 00000019B79C: CC21003E 0200394F
	v_fma_mixhi_f16 v62, v80, s28, 0                           // 00000019B7A4: CC22003E 02003950
	s_waitcnt lgkmcnt(4)                                       // 00000019B7AC: BF89FC47
	v_fma_mixlo_f16 v63, v81, s28, 0                           // 00000019B7B0: CC21003F 02003951
	v_fma_mixhi_f16 v63, v82, s28, 0                           // 00000019B7B8: CC22003F 02003952
	v_fma_mixlo_f16 v64, v83, s28, 0                           // 00000019B7C0: CC210040 02003953
	v_fma_mixhi_f16 v64, v84, s28, 0                           // 00000019B7C8: CC220040 02003954
	s_waitcnt lgkmcnt(2)                                       // 00000019B7D0: BF89FC27
	v_fma_mixlo_f16 v65, v65, s28, 0                           // 00000019B7D4: CC210041 02003941
	v_fma_mixhi_f16 v65, v66, s28, 0                           // 00000019B7DC: CC220041 02003942
	v_fma_mixlo_f16 v66, v67, s28, 0                           // 00000019B7E4: CC210042 02003943
	v_fma_mixhi_f16 v66, v68, s28, 0                           // 00000019B7EC: CC220042 02003944
	v_fma_mixlo_f16 v67, v85, s28, 0                           // 00000019B7F4: CC210043 02003955
	v_fma_mixhi_f16 v67, v86, s28, 0                           // 00000019B7FC: CC220043 02003956
	v_fma_mixlo_f16 v68, v87, s28, 0                           // 00000019B804: CC210044 02003957
	v_fma_mixhi_f16 v68, v88, s28, 0                           // 00000019B80C: CC220044 02003958
	s_waitcnt lgkmcnt(1)                                       // 00000019B814: BF89FC17
	v_fma_mixlo_f16 v69, v69, s28, 0                           // 00000019B818: CC210045 02003945
	v_fma_mixhi_f16 v69, v70, s28, 0                           // 00000019B820: CC220045 02003946
	v_fma_mixlo_f16 v70, v71, s28, 0                           // 00000019B828: CC210046 02003947
	v_fma_mixhi_f16 v70, v72, s28, 0                           // 00000019B830: CC220046 02003948
	s_waitcnt lgkmcnt(0)                                       // 00000019B838: BF89FC07
	v_fma_mixlo_f16 v71, v73, s28, 0                           // 00000019B83C: CC210047 02003949
	v_fma_mixhi_f16 v71, v74, s28, 0                           // 00000019B844: CC220047 0200394A
	v_fma_mixlo_f16 v72, v75, s28, 0                           // 00000019B84C: CC210048 0200394B
	v_fma_mixhi_f16 v72, v76, s28, 0                           // 00000019B854: CC220048 0200394C
	s_waitcnt vmcnt(0)                                         // 00000019B85C: BF8903F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[1:8], v[9:16], v[41:48]// 00000019B860: CC404029 1CA61301
	v_wmma_f32_16x16x16_f16 v[17:24], v[1:8], v[33:40], v[17:24]// 00000019B868: CC404011 1C464301
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[57:64], v[49:56]// 00000019B870: CC404031 1CC67301
	v_wmma_f32_16x16x16_f16 v[25:32], v[1:8], v[65:72], v[25:32]// 00000019B878: CC404019 1C668301
	v_add_nc_u32_e32 v173, s48, v128                           // 00000019B880: 4B5B0030
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019B884: BF870001
	v_or_b32_e32 v1, 2, v173                                   // 00000019B888: 38035A82
	v_or_b32_e32 v2, 4, v173                                   // 00000019B88C: 38055A84
	v_or_b32_e32 v5, 6, v173                                   // 00000019B890: 380B5A86
	v_or_b32_e32 v7, 8, v173                                   // 00000019B894: 380F5A88
	v_or_b32_e32 v8, 10, v173                                  // 00000019B898: 38115A8A
	v_min_i32_e32 v1, s65, v1                                  // 00000019B89C: 22020241
	v_min_i32_e32 v6, s65, v2                                  // 00000019B8A0: 220C0441
	v_min_i32_e32 v10, s65, v5                                 // 00000019B8A4: 22140A41
	v_or_b32_e32 v9, 12, v173                                  // 00000019B8A8: 38135A8C
	v_min_i32_e32 v11, s65, v7                                 // 00000019B8AC: 22160E41
	v_mad_i64_i32 v[1:2], null, v1, 48, s[2:3]                 // 00000019B8B0: D6FF7C01 00096101
	v_mad_i64_i32 v[5:6], null, v6, 48, s[2:3]                 // 00000019B8B8: D6FF7C05 00096106
	v_min_i32_e32 v13, s65, v8                                 // 00000019B8C0: 221A1041
	v_mad_i64_i32 v[7:8], null, v10, 48, s[2:3]                // 00000019B8C4: D6FF7C07 0009610A
	v_min_i32_e32 v14, s65, v9                                 // 00000019B8CC: 221C1241
	v_mad_i64_i32 v[9:10], null, v11, 48, s[2:3]               // 00000019B8D0: D6FF7C09 0009610B
	v_or_b32_e32 v15, 14, v173                                 // 00000019B8D8: 381F5A8E
	v_min_i32_e32 v3, s65, v173                                // 00000019B8DC: 22075A41
	.long 0xd73c0001                                           // 00000019B8E0: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 00000019B8E4: 02020289
	.long 0xd73c0005                                           // 00000019B8E8: D73C0005
	v_cndmask_b32_e32 v1, 9, v5, vcc_lo                        // 00000019B8EC: 02020A89
	.long 0xd444000b                                           // 00000019B8F0: D444000B
	v_cndmask_b32_e32 v1, s59, v173, vcc_lo                    // 00000019B8F4: 02035A3B
	v_min_i32_e32 v15, s65, v15                                // 00000019B8F8: 221E1E41
	v_mad_i64_i32 v[3:4], null, v3, 48, s[2:3]                 // 00000019B8FC: D6FF7C03 00096103
	.long 0xd73c0009                                           // 00000019B904: D73C0009
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 00000019B908: 02021289
	.long 0xd700000b                                           // 00000019B90C: D700000B
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 00000019B910: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000019B914: BF8700D1
	v_add_co_ci_u32_e64 v12, null, v135, v2, s0                // 00000019B918: D5207C0C 00020587
	.long 0xd73c0001                                           // 00000019B920: D73C0001
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 00000019B924: 02020E89
	v_mad_i64_i32 v[7:8], null, v13, 48, s[2:3]                // 00000019B928: D6FF7C07 0009610D
	v_mad_i64_i32 v[13:14], null, v14, 48, s[2:3]              // 00000019B930: D6FF7C0D 0009610E
	.long 0xd7000005                                           // 00000019B938: D7000005
	v_cndmask_b32_e32 v1, v134, v5, vcc_lo                     // 00000019B93C: 02020B86
	v_add_co_ci_u32_e64 v6, null, v135, v6, s0                 // 00000019B940: D5207C06 00020D87
	.long 0xd7000024                                           // 00000019B948: D7000024
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 00000019B94C: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000019B950: BF8700B1
	v_add_co_ci_u32_e64 v37, null, v135, v2, s0                // 00000019B954: D5207C25 00020587
	.long 0xd73c0001                                           // 00000019B95C: D73C0001
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 00000019B960: 02020E89
	.long 0xd7000007                                           // 00000019B964: D7000007
	v_cndmask_b32_e32 v1, v134, v9, vcc_lo                     // 00000019B968: 02021386
	v_add_co_ci_u32_e64 v8, null, v135, v10, s0                // 00000019B96C: D5207C08 00021587
	.long 0xd73c0009                                           // 00000019B974: D73C0009
	v_cndmask_b32_e32 v1, 9, v13, vcc_lo                       // 00000019B978: 02021A89
	v_mad_i64_i32 v[13:14], null, v15, 48, s[2:3]              // 00000019B97C: D6FF7C0D 0009610F
	.long 0xd7000026                                           // 00000019B984: D7000026
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 00000019B988: 02020386
	.long 0xd73c0003                                           // 00000019B98C: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000019B990: 02020689
	v_add_co_ci_u32_e64 v39, null, v135, v2, s0                // 00000019B994: D5207C27 00020587
	.long 0xd7000043                                           // 00000019B99C: D7000043
	v_cndmask_b32_e32 v1, v134, v9, vcc_lo                     // 00000019B9A0: 02021386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000019B9A4: BF8700B1
	v_add_co_ci_u32_e64 v68, null, v135, v10, s0               // 00000019B9A8: D5207C44 00021587
	.long 0xd73c0009                                           // 00000019B9B0: D73C0009
	v_cndmask_b32_e32 v1, 9, v13, vcc_lo                       // 00000019B9B4: 02021A89
	.long 0xd7000002                                           // 00000019B9B8: D7000002
	v_cndmask_b32_e32 v1, v134, v3, vcc_lo                     // 00000019B9BC: 02020786
	v_add_co_ci_u32_e64 v3, null, v135, v4, s0                 // 00000019B9C0: D5207C03 00020987
	.long 0x7e023880                                           // 00000019B9C8: 7E023880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019B9CC: BF870094
	.long 0xd7000045                                           // 00000019B9D0: D7000045
	v_cndmask_b32_e32 v1, v134, v9, vcc_lo                     // 00000019B9D4: 02021386
	v_add_co_ci_u32_e64 v70, null, v135, v10, s0               // 00000019B9D8: D5207C46 00021587
	s_clause 0x1e                                              // 00000019B9E0: BF85001E
	global_load_b32 v63, v[11:12], off                         // 00000019B9E4: DC520000 3F7C000B
	global_load_b32 v60, v[5:6], off                           // 00000019B9EC: DC520000 3C7C0005
	global_load_b32 v40, v[2:3], off offset:64                 // 00000019B9F4: DC520040 287C0002
	global_load_b32 v57, v[11:12], off offset:64               // 00000019B9FC: DC520040 397C000B
	global_load_b32 v35, v[2:3], off offset:128                // 00000019BA04: DC520080 237C0002
	global_load_b32 v15, v[11:12], off offset:128              // 00000019BA0C: DC520080 0F7C000B
	global_load_b32 v9, v[11:12], off offset:192               // 00000019BA14: DC5200C0 097C000B
	global_load_b32 v10, v[2:3], off offset:192                // 00000019BA1C: DC5200C0 0A7C0002
	global_load_b32 v66, v[36:37], off                         // 00000019BA24: DC520000 427C0024
	global_load_b32 v65, v[7:8], off                           // 00000019BA2C: DC520000 417C0007
	global_load_b32 v59, v[5:6], off offset:64                 // 00000019BA34: DC520040 3B7C0005
	global_load_b32 v58, v[36:37], off offset:64               // 00000019BA3C: DC520040 3A7C0024
	global_load_b32 v34, v[5:6], off offset:128                // 00000019BA44: DC520080 227C0005
	global_load_b32 v12, v[36:37], off offset:128              // 00000019BA4C: DC520080 0C7C0024
	global_load_b32 v4, v[36:37], off offset:192               // 00000019BA54: DC5200C0 047C0024
	global_load_b32 v11, v[5:6], off offset:192                // 00000019BA5C: DC5200C0 0B7C0005
	global_load_b32 v64, v[38:39], off                         // 00000019BA64: DC520000 407C0026
	global_load_b32 v61, v[67:68], off                         // 00000019BA6C: DC520000 3D7C0043
	global_load_b32 v36, v[7:8], off offset:64                 // 00000019BA74: DC520040 247C0007
	global_load_b32 v37, v[38:39], off offset:64               // 00000019BA7C: DC520040 257C0026
	global_load_b32 v16, v[7:8], off offset:128                // 00000019BA84: DC520080 107C0007
	global_load_b32 v33, v[38:39], off offset:128              // 00000019BA8C: DC520080 217C0026
	global_load_b32 v5, v[38:39], off offset:192               // 00000019BA94: DC5200C0 057C0026
	global_load_b32 v6, v[7:8], off offset:192                 // 00000019BA9C: DC5200C0 067C0007
	global_load_b32 v62, v[69:70], off                         // 00000019BAA4: DC520000 3E7C0045
	global_load_b32 v38, v[67:68], off offset:64               // 00000019BAAC: DC520040 267C0043
	global_load_b32 v39, v[69:70], off offset:64               // 00000019BAB4: DC520040 277C0045
	global_load_b32 v13, v[67:68], off offset:128              // 00000019BABC: DC520080 0D7C0043
	global_load_b32 v14, v[69:70], off offset:128              // 00000019BAC4: DC520080 0E7C0045
	global_load_b32 v7, v[69:70], off offset:192               // 00000019BACC: DC5200C0 077C0045
	global_load_b32 v8, v[67:68], off offset:192               // 00000019BAD4: DC5200C0 087C0043
	s_and_saveexec_b32 s0, s11                                 // 00000019BADC: BE80200B
	s_cbranch_execz 8                                          // 00000019BAE0: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4204>
	global_load_b32 v1, v[2:3], off                            // 00000019BAE4: DC520000 017C0002
	s_waitcnt vmcnt(0)                                         // 00000019BAEC: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v41                         // 00000019BAF0: 560252FF BB800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019BAF8: BF870001
	v_fma_mixlo_f16 v1, v1, s28, 0                             // 00000019BAFC: CC210001 02003901
	s_or_b32 exec_lo, exec_lo, s0                              // 00000019BB04: 8C7E007E
	s_waitcnt vmcnt(30)                                        // 00000019BB08: BF897BF7
	v_dual_fmac_f32 v63, 0xbb800000, v42 :: v_dual_add_nc_u32 v180, 2, v173// 00000019BB0C: C82054FF 3FB55A82 BB800000
	s_waitcnt vmcnt(29)                                        // 00000019BB18: BF8977F7
	v_dual_fmac_f32 v60, 0xbb800000, v43 :: v_dual_add_nc_u32 v179, 4, v173// 00000019BB1C: C82056FF 3CB35A84 BB800000
	s_waitcnt vmcnt(13)                                        // 00000019BB28: BF8937F7
	v_dual_fmac_f32 v61, 0xbb800000, v47 :: v_dual_add_nc_u32 v178, 6, v173// 00000019BB2C: C8205EFF 3DB35A86 BB800000
	v_dual_fmac_f32 v66, 0xbb800000, v44 :: v_dual_add_nc_u32 v177, 8, v173// 00000019BB38: C82058FF 42B15A88 BB800000
	v_dual_fmac_f32 v65, 0xbb800000, v45 :: v_dual_fmac_f32 v64, 0xbb800000, v46// 00000019BB44: C8005AFF 41405CFF BB800000
	v_dual_fmac_f32 v57, 0xbb800000, v18 :: v_dual_add_nc_u32 v176, 10, v173// 00000019BB50: C82024FF 39B15A8A BB800000
	s_waitcnt vmcnt(6)                                         // 00000019BB5C: BF891BF7
	v_dual_fmac_f32 v62, 0xbb800000, v48 :: v_dual_add_nc_u32 v175, 12, v173// 00000019BB60: C82060FF 3EAF5A8C BB800000
	v_dual_fmac_f32 v59, 0xbb800000, v19 :: v_dual_add_nc_u32 v174, 14, v173// 00000019BB6C: C82026FF 3BAF5A8E BB800000
	.long 0xd444000e                                           // 00000019BB78: D444000E
	v_cndmask_b32_e32 v1, s59, v180, vcc_lo                    // 00000019BB7C: 0203683B
	v_fma_mixhi_f16 v1, v63, s28, 0                            // 00000019BB80: CC220001 0200393F
	.long 0xd444000d                                           // 00000019BB88: D444000D
	v_cndmask_b32_e32 v1, s59, v179, vcc_lo                    // 00000019BB8C: 0203663B
	v_fma_mixlo_f16 v2, v60, s28, 0                            // 00000019BB90: CC210002 0200393C
	v_dual_fmac_f32 v40, 0xbb800000, v17 :: v_dual_fmac_f32 v37, 0xbb800000, v22// 00000019BB98: C80022FF 28242CFF BB800000
	.long 0xd444000c                                           // 00000019BBA4: D444000C
	v_cndmask_b32_e32 v1, s59, v178, vcc_lo                    // 00000019BBA8: 0203643B
	v_fma_mixhi_f16 v2, v66, s28, 0                            // 00000019BBAC: CC220002 02003942
	.long 0xd444000a                                           // 00000019BBB4: D444000A
	v_cndmask_b32_e32 v1, s59, v177, vcc_lo                    // 00000019BBB8: 0203623B
	v_fma_mixlo_f16 v3, v65, s28, 0                            // 00000019BBBC: CC210003 02003941
	.long 0xd4440001                                           // 00000019BBC4: D4440001
	v_cndmask_b32_e32 v1, s59, v176, vcc_lo                    // 00000019BBC8: 0203603B
	v_fma_mixhi_f16 v3, v64, s28, 0                            // 00000019BBCC: CC220003 02003940
	.long 0xd4440009                                           // 00000019BBD4: D4440009
	v_cndmask_b32_e32 v1, s59, v175, vcc_lo                    // 00000019BBD8: 02035E3B
	v_fma_mixlo_f16 v41, v61, s28, 0                           // 00000019BBDC: CC210029 0200393D
	.long 0xd4440000                                           // 00000019BBE4: D4440000
	v_cndmask_b32_e32 v1, s59, v174, vcc_lo                    // 00000019BBE8: 02035C3B
	v_fma_mixhi_f16 v41, v62, s28, 0                           // 00000019BBEC: CC220029 0200393E
	v_dual_fmac_f32 v58, 0xbb800000, v20 :: v_dual_fmac_f32 v35, 0xbb800000, v49// 00000019BBF4: C80028FF 3A2262FF BB800000
	v_cndmask_b16 v1, 0, v1, s14                               // 00000019BC00: D65D5001 003A0280
	s_waitcnt vmcnt(4)                                         // 00000019BC08: BF8913F7
	v_dual_fmac_f32 v36, 0xbb800000, v21 :: v_dual_fmac_f32 v39, 0xbb800000, v24// 00000019BC0C: C8002AFF 242630FF BB800000
	v_cndmask_b16 v2, 0, v2, s13                               // 00000019BC18: D65D0002 00360480
	v_fma_mixlo_f16 v18, v40, s28, 0                           // 00000019BC20: CC210012 02003928
	v_dual_fmac_f32 v38, 0xbb800000, v23 :: v_dual_fmac_f32 v15, 0xbb800000, v50// 00000019BC28: C8002EFF 260E64FF BB800000
	v_cndmask_b16 v2, 0, v2, s12                               // 00000019BC34: D65D5002 00320480
	v_fma_mixhi_f16 v18, v57, s28, 0                           // 00000019BC3C: CC220012 02003939
	v_cndmask_b16 v3, 0, v3, s10                               // 00000019BC44: D65D0003 002A0680
	v_fma_mixlo_f16 v19, v59, s28, 0                           // 00000019BC4C: CC210013 0200393B
	v_cndmask_b16 v3, 0, v3, s1                                // 00000019BC54: D65D5003 00060680
	v_cndmask_b16 v17, 0, v41, s9                              // 00000019BC5C: D65D0011 00265280
	v_cndmask_b16 v17, 0, v41, s0                              // 00000019BC64: D65D5011 00025280
	ds_store_b16 v136, v1                                      // 00000019BC6C: D87C0000 00000188
	ds_store_b16_d16_hi v136, v1 offset:4                      // 00000019BC74: DA840004 00000188
	ds_store_b16 v136, v2 offset:8                             // 00000019BC7C: D87C0008 00000288
	ds_store_b16_d16_hi v136, v2 offset:12                     // 00000019BC84: DA84000C 00000288
	ds_store_b16 v136, v3 offset:16                            // 00000019BC8C: D87C0010 00000388
	ds_store_b16_d16_hi v136, v3 offset:20                     // 00000019BC94: DA840014 00000388
	ds_store_b16 v136, v17 offset:24                           // 00000019BC9C: D87C0018 00001188
	ds_store_b16_d16_hi v136, v17 offset:28                    // 00000019BCA4: DA84001C 00001188
	v_fma_mixhi_f16 v2, v58, s28, 0                            // 00000019BCAC: CC220002 0200393A
	v_fma_mixlo_f16 v3, v36, s28, 0                            // 00000019BCB4: CC210003 02003924
	v_cndmask_b16 v1, 0, v18, s11                              // 00000019BCBC: D65D0001 002E2480
	v_fma_mixhi_f16 v3, v37, s28, 0                            // 00000019BCC4: CC220003 02003925
	v_fma_mixlo_f16 v17, v38, s28, 0                           // 00000019BCCC: CC210011 02003926
	v_fma_mixhi_f16 v17, v39, s28, 0                           // 00000019BCD4: CC220011 02003927
	v_cndmask_b16 v1, 0, v18, s14                              // 00000019BCDC: D65D5001 003A2480
	v_dual_fmac_f32 v34, 0xbb800000, v51 :: v_dual_fmac_f32 v33, 0xbb800000, v54// 00000019BCE4: C80066FF 22206CFF BB800000
	v_cndmask_b16 v2, 0, v19, s13                              // 00000019BCF0: D65D0002 00362680
	s_waitcnt vmcnt(3)                                         // 00000019BCF8: BF890FF7
	v_dual_fmac_f32 v12, 0xbb800000, v52 :: v_dual_fmac_f32 v13, 0xbb800000, v55// 00000019BCFC: C80068FF 0C0C6EFF BB800000
	v_cndmask_b16 v2, 0, v2, s12                               // 00000019BD08: D65D5002 00320480
	v_dual_fmac_f32 v16, 0xbb800000, v53 :: v_dual_fmac_f32 v9, 0xbb800000, v26// 00000019BD10: C8006AFF 100834FF BB800000
	v_cndmask_b16 v3, 0, v3, s10                               // 00000019BD1C: D65D0003 002A0680
	v_fma_mixlo_f16 v18, v35, s28, 0                           // 00000019BD24: CC210012 02003923
	s_waitcnt vmcnt(2)                                         // 00000019BD2C: BF890BF7
	v_dual_fmac_f32 v14, 0xbb800000, v56 :: v_dual_fmac_f32 v11, 0xbb800000, v27// 00000019BD30: C80070FF 0E0A36FF BB800000
	v_cndmask_b16 v3, 0, v3, s1                                // 00000019BD3C: D65D5003 00060680
	v_cndmask_b16 v17, 0, v17, s9                              // 00000019BD44: D65D0011 00262280
	v_cndmask_b16 v17, 0, v17, s0                              // 00000019BD4C: D65D5011 00022280
	ds_store_b16 v136, v1 offset:2304                          // 00000019BD54: D87C0900 00000188
	ds_store_b16_d16_hi v136, v1 offset:2308                   // 00000019BD5C: DA840904 00000188
	ds_store_b16 v136, v2 offset:2312                          // 00000019BD64: D87C0908 00000288
	ds_store_b16_d16_hi v136, v2 offset:2316                   // 00000019BD6C: DA84090C 00000288
	ds_store_b16 v136, v3 offset:2320                          // 00000019BD74: D87C0910 00000388
	ds_store_b16_d16_hi v136, v3 offset:2324                   // 00000019BD7C: DA840914 00000388
	ds_store_b16 v136, v17 offset:2328                         // 00000019BD84: D87C0918 00001188
	ds_store_b16_d16_hi v136, v17 offset:2332                  // 00000019BD8C: DA84091C 00001188
	v_fma_mixhi_f16 v1, v15, s28, 0                            // 00000019BD94: CC220001 0200390F
	v_fma_mixlo_f16 v2, v34, s28, 0                            // 00000019BD9C: CC210002 02003922
	v_dual_fmac_f32 v10, 0xbb800000, v25 :: v_dual_fmac_f32 v5, 0xbb800000, v30// 00000019BDA4: C80032FF 0A043CFF BB800000
	v_fma_mixhi_f16 v2, v12, s28, 0                            // 00000019BDB0: CC220002 0200390C
	v_fma_mixlo_f16 v3, v16, s28, 0                            // 00000019BDB8: CC210003 02003910
	v_cndmask_b16 v1, 0, v18, s11                              // 00000019BDC0: D65D0001 002E2480
	v_fma_mixhi_f16 v3, v33, s28, 0                            // 00000019BDC8: CC220003 02003921
	v_fma_mixlo_f16 v12, v13, s28, 0                           // 00000019BDD0: CC21000C 0200390D
	v_fma_mixhi_f16 v12, v14, s28, 0                           // 00000019BDD8: CC22000C 0200390E
	v_fmac_f32_e32 v4, 0xbb800000, v28                         // 00000019BDE0: 560838FF BB800000
	v_cndmask_b16 v1, 0, v1, s14                               // 00000019BDE8: D65D5001 003A0280
	s_waitcnt vmcnt(1)                                         // 00000019BDF0: BF8907F7
	v_dual_fmac_f32 v6, 0xbb800000, v29 :: v_dual_fmac_f32 v7, 0xbb800000, v32// 00000019BDF4: C8003AFF 060640FF BB800000
	v_cndmask_b16 v2, 0, v2, s13                               // 00000019BE00: D65D0002 00360480
	v_fma_mixlo_f16 v10, v10, s28, 0                           // 00000019BE08: CC21000A 0200390A
	s_waitcnt vmcnt(0)                                         // 00000019BE10: BF8903F7
	v_fmac_f32_e32 v8, 0xbb800000, v31                         // 00000019BE14: 56103EFF BB800000
	v_cndmask_b16 v2, 0, v2, s12                               // 00000019BE1C: D65D5002 00320480
	v_fma_mixlo_f16 v9, v9, s28, 0                             // 00000019BE24: CC210009 02003909
	v_cndmask_b16 v3, 0, v3, s10                               // 00000019BE2C: D65D0003 002A0680
	v_fma_mixhi_f16 v9, v11, s28, 0                            // 00000019BE34: CC220009 0200390B
	v_cndmask_b16 v3, 0, v3, s1                                // 00000019BE3C: D65D5003 00060680
	v_cndmask_b16 v12, 0, v12, s9                              // 00000019BE44: D65D000C 00261880
	v_cndmask_b16 v12, 0, v12, s0                              // 00000019BE4C: D65D500C 00021880
	ds_store_b16 v136, v1 offset:4608                          // 00000019BE54: D87C1200 00000188
	ds_store_b16_d16_hi v136, v1 offset:4612                   // 00000019BE5C: DA841204 00000188
	ds_store_b16 v136, v2 offset:4616                          // 00000019BE64: D87C1208 00000288
	ds_store_b16_d16_hi v136, v2 offset:4620                   // 00000019BE6C: DA84120C 00000288
	ds_store_b16 v136, v3 offset:4624                          // 00000019BE74: D87C1210 00000388
	ds_store_b16_d16_hi v136, v3 offset:4628                   // 00000019BE7C: DA841214 00000388
	ds_store_b16 v136, v12 offset:4632                         // 00000019BE84: D87C1218 00000C88
	ds_store_b16_d16_hi v136, v12 offset:4636                  // 00000019BE8C: DA84121C 00000C88
	v_fma_mixhi_f16 v2, v4, s28, 0                             // 00000019BE94: CC220002 02003904
	v_fma_mixlo_f16 v3, v6, s28, 0                             // 00000019BE9C: CC210003 02003906
	v_cndmask_b16 v1, 0, v10, s11                              // 00000019BEA4: D65D0001 002E1480
	v_fma_mixhi_f16 v3, v5, s28, 0                             // 00000019BEAC: CC220003 02003905
	v_fma_mixlo_f16 v4, v8, s28, 0                             // 00000019BEB4: CC210004 02003908
	v_fma_mixhi_f16 v4, v7, s28, 0                             // 00000019BEBC: CC220004 02003907
	v_cndmask_b16 v1, 0, v9, s14                               // 00000019BEC4: D65D4001 003A1280
	v_cndmask_b16 v2, 0, v9, s13                               // 00000019BECC: D65D1002 00361280
	v_cndmask_b16 v2, 0, v2, s12                               // 00000019BED4: D65D5002 00320480
	v_cndmask_b16 v3, 0, v3, s10                               // 00000019BEDC: D65D0003 002A0680
	v_cndmask_b16 v3, 0, v3, s1                                // 00000019BEE4: D65D5003 00060680
	v_cndmask_b16 v4, 0, v4, s9                                // 00000019BEEC: D65D0004 00260880
	v_cndmask_b16 v4, 0, v4, s0                                // 00000019BEF4: D65D5004 00020880
	ds_store_b16 v136, v1 offset:6912                          // 00000019BEFC: D87C1B00 00000188
	ds_store_b16_d16_hi v136, v1 offset:6916                   // 00000019BF04: DA841B04 00000188
	ds_store_b16 v136, v2 offset:6920                          // 00000019BF0C: D87C1B08 00000288
	ds_store_b16_d16_hi v136, v2 offset:6924                   // 00000019BF14: DA841B0C 00000288
	ds_store_b16 v136, v3 offset:6928                          // 00000019BF1C: D87C1B10 00000388
	ds_store_b16_d16_hi v136, v3 offset:6932                   // 00000019BF24: DA841B14 00000388
	ds_store_b16 v136, v4 offset:6936                          // 00000019BF2C: D87C1B18 00000488
	ds_store_b16_d16_hi v136, v4 offset:6940                   // 00000019BF34: DA841B1C 00000488
	.long 0xd7000f01                                           // 00000019BF3C: D7000F01
	v_cndmask_b32_e32 v1, s24, v97, vcc_lo                     // 00000019BF40: 0202C218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019BF44: BF870001
	v_add_co_ci_u32_e64 v2, null, s25, v98, s15                // 00000019BF48: D5207C02 003EC419
	s_waitcnt lgkmcnt(0)                                       // 00000019BF50: BF89FC07
	s_barrier                                                  // 00000019BF54: BFBD0000
	buffer_gl0_inv                                             // 00000019BF58: E0AC0000 00000000
	s_clause 0xf                                               // 00000019BF60: BF85000F
	global_load_b128 v[97:100], v[1:2], off                    // 00000019BF64: DC5E0000 617C0001
	global_load_b128 v[101:104], v[1:2], off offset:16         // 00000019BF6C: DC5E0010 657C0001
	global_load_b128 v[89:92], v[1:2], off offset:32           // 00000019BF74: DC5E0020 597C0001
	global_load_b128 v[93:96], v[1:2], off offset:48           // 00000019BF7C: DC5E0030 5D7C0001
	global_load_b128 v[81:84], v[1:2], off offset:64           // 00000019BF84: DC5E0040 517C0001
	global_load_b128 v[85:88], v[1:2], off offset:80           // 00000019BF8C: DC5E0050 557C0001
	global_load_b128 v[73:76], v[1:2], off offset:96           // 00000019BF94: DC5E0060 497C0001
	global_load_b128 v[77:80], v[1:2], off offset:112          // 00000019BF9C: DC5E0070 4D7C0001
	global_load_b128 v[57:60], v[1:2], off offset:128          // 00000019BFA4: DC5E0080 397C0001
	global_load_b128 v[61:64], v[1:2], off offset:144          // 00000019BFAC: DC5E0090 3D7C0001
	global_load_b128 v[49:52], v[1:2], off offset:160          // 00000019BFB4: DC5E00A0 317C0001
	global_load_b128 v[53:56], v[1:2], off offset:176          // 00000019BFBC: DC5E00B0 357C0001
	global_load_b128 v[41:44], v[1:2], off offset:192          // 00000019BFC4: DC5E00C0 297C0001
	global_load_b128 v[45:48], v[1:2], off offset:208          // 00000019BFCC: DC5E00D0 2D7C0001
	global_load_b128 v[33:36], v[1:2], off offset:224          // 00000019BFD4: DC5E00E0 217C0001
	global_load_b128 v[37:40], v[1:2], off offset:240          // 00000019BFDC: DC5E00F0 257C0001
	s_and_saveexec_b32 s15, vcc_lo                             // 00000019BFE4: BE8F206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000019BFE8: BF870009
	s_xor_b32 s15, exec_lo, s15                                // 00000019BFEC: 8D0F0F7E
	s_cbranch_execz 81                                         // 00000019BFF0: BFA50051 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4838>
	s_waitcnt vmcnt(15)                                        // 00000019BFF4: BF893FF7
	v_mov_b32_e32 v97, 0                                       // 00000019BFF8: 7EC20280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019BFFC: BF870001
	v_mov_b32_e32 v98, v97                                     // 00000019C000: 7EC40361
	v_mov_b32_e32 v99, v97                                     // 00000019C004: 7EC60361
	v_mov_b32_e32 v100, v97                                    // 00000019C008: 7EC80361
	s_waitcnt vmcnt(14)                                        // 00000019C00C: BF893BF7
	v_mov_b32_e32 v101, v97                                    // 00000019C010: 7ECA0361
	v_mov_b32_e32 v102, v97                                    // 00000019C014: 7ECC0361
	v_mov_b32_e32 v103, v97                                    // 00000019C018: 7ECE0361
	v_mov_b32_e32 v104, v97                                    // 00000019C01C: 7ED00361
	s_waitcnt vmcnt(13)                                        // 00000019C020: BF8937F7
	v_mov_b32_e32 v89, v97                                     // 00000019C024: 7EB20361
	v_mov_b32_e32 v90, v97                                     // 00000019C028: 7EB40361
	v_mov_b32_e32 v91, v97                                     // 00000019C02C: 7EB60361
	v_mov_b32_e32 v92, v97                                     // 00000019C030: 7EB80361
	s_waitcnt vmcnt(12)                                        // 00000019C034: BF8933F7
	v_mov_b32_e32 v93, v97                                     // 00000019C038: 7EBA0361
	v_mov_b32_e32 v94, v97                                     // 00000019C03C: 7EBC0361
	v_mov_b32_e32 v95, v97                                     // 00000019C040: 7EBE0361
	v_mov_b32_e32 v96, v97                                     // 00000019C044: 7EC00361
	s_waitcnt vmcnt(11)                                        // 00000019C048: BF892FF7
	v_mov_b32_e32 v81, v97                                     // 00000019C04C: 7EA20361
	v_mov_b32_e32 v82, v97                                     // 00000019C050: 7EA40361
	v_mov_b32_e32 v83, v97                                     // 00000019C054: 7EA60361
	v_mov_b32_e32 v84, v97                                     // 00000019C058: 7EA80361
	s_waitcnt vmcnt(10)                                        // 00000019C05C: BF892BF7
	v_mov_b32_e32 v85, v97                                     // 00000019C060: 7EAA0361
	v_mov_b32_e32 v86, v97                                     // 00000019C064: 7EAC0361
	v_mov_b32_e32 v87, v97                                     // 00000019C068: 7EAE0361
	v_mov_b32_e32 v88, v97                                     // 00000019C06C: 7EB00361
	s_waitcnt vmcnt(9)                                         // 00000019C070: BF8927F7
	v_mov_b32_e32 v73, v97                                     // 00000019C074: 7E920361
	v_mov_b32_e32 v74, v97                                     // 00000019C078: 7E940361
	v_mov_b32_e32 v75, v97                                     // 00000019C07C: 7E960361
	v_mov_b32_e32 v76, v97                                     // 00000019C080: 7E980361
	s_waitcnt vmcnt(8)                                         // 00000019C084: BF8923F7
	v_mov_b32_e32 v77, v97                                     // 00000019C088: 7E9A0361
	v_mov_b32_e32 v78, v97                                     // 00000019C08C: 7E9C0361
	v_mov_b32_e32 v79, v97                                     // 00000019C090: 7E9E0361
	v_mov_b32_e32 v80, v97                                     // 00000019C094: 7EA00361
	s_waitcnt vmcnt(7)                                         // 00000019C098: BF891FF7
	v_mov_b32_e32 v57, v97                                     // 00000019C09C: 7E720361
	v_mov_b32_e32 v58, v97                                     // 00000019C0A0: 7E740361
	v_mov_b32_e32 v59, v97                                     // 00000019C0A4: 7E760361
	v_mov_b32_e32 v60, v97                                     // 00000019C0A8: 7E780361
	s_waitcnt vmcnt(6)                                         // 00000019C0AC: BF891BF7
	v_mov_b32_e32 v61, v97                                     // 00000019C0B0: 7E7A0361
	v_mov_b32_e32 v62, v97                                     // 00000019C0B4: 7E7C0361
	v_mov_b32_e32 v63, v97                                     // 00000019C0B8: 7E7E0361
	v_mov_b32_e32 v64, v97                                     // 00000019C0BC: 7E800361
	s_waitcnt vmcnt(5)                                         // 00000019C0C0: BF8917F7
	v_mov_b32_e32 v49, v97                                     // 00000019C0C4: 7E620361
	v_mov_b32_e32 v50, v97                                     // 00000019C0C8: 7E640361
	v_mov_b32_e32 v51, v97                                     // 00000019C0CC: 7E660361
	v_mov_b32_e32 v52, v97                                     // 00000019C0D0: 7E680361
	s_waitcnt vmcnt(4)                                         // 00000019C0D4: BF8913F7
	v_mov_b32_e32 v53, v97                                     // 00000019C0D8: 7E6A0361
	v_mov_b32_e32 v54, v97                                     // 00000019C0DC: 7E6C0361
	v_mov_b32_e32 v55, v97                                     // 00000019C0E0: 7E6E0361
	v_mov_b32_e32 v56, v97                                     // 00000019C0E4: 7E700361
	s_waitcnt vmcnt(3)                                         // 00000019C0E8: BF890FF7
	v_mov_b32_e32 v41, v97                                     // 00000019C0EC: 7E520361
	v_mov_b32_e32 v42, v97                                     // 00000019C0F0: 7E540361
	v_mov_b32_e32 v43, v97                                     // 00000019C0F4: 7E560361
	v_mov_b32_e32 v44, v97                                     // 00000019C0F8: 7E580361
	s_waitcnt vmcnt(2)                                         // 00000019C0FC: BF890BF7
	v_mov_b32_e32 v45, v97                                     // 00000019C100: 7E5A0361
	v_mov_b32_e32 v46, v97                                     // 00000019C104: 7E5C0361
	v_mov_b32_e32 v47, v97                                     // 00000019C108: 7E5E0361
	v_mov_b32_e32 v48, v97                                     // 00000019C10C: 7E600361
	s_waitcnt vmcnt(1)                                         // 00000019C110: BF8907F7
	v_mov_b32_e32 v33, v97                                     // 00000019C114: 7E420361
	v_mov_b32_e32 v34, v97                                     // 00000019C118: 7E440361
	v_mov_b32_e32 v35, v97                                     // 00000019C11C: 7E460361
	v_mov_b32_e32 v36, v97                                     // 00000019C120: 7E480361
	s_waitcnt vmcnt(0)                                         // 00000019C124: BF8903F7
	v_mov_b32_e32 v37, v97                                     // 00000019C128: 7E4A0361
	v_mov_b32_e32 v38, v97                                     // 00000019C12C: 7E4C0361
	v_mov_b32_e32 v39, v97                                     // 00000019C130: 7E4E0361
	v_mov_b32_e32 v40, v97                                     // 00000019C134: 7E500361
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019C138: 8C7E0F7E
	ds_load_b128 v[1:4], v127                                  // 00000019C13C: DBFC0000 0100007F
	ds_load_b128 v[5:8], v127 offset:16                        // 00000019C144: DBFC0010 0500007F
	ds_load_b128 v[9:12], v127 offset:32                       // 00000019C14C: DBFC0020 0900007F
	ds_load_b128 v[13:16], v127 offset:48                      // 00000019C154: DBFC0030 0D00007F
	ds_load_b128 v[17:20], v127 offset:8448                    // 00000019C15C: DBFC2100 1100007F
	ds_load_b128 v[21:24], v127 offset:8464                    // 00000019C164: DBFC2110 1500007F
	ds_load_b128 v[25:28], v127 offset:8480                    // 00000019C16C: DBFC2120 1900007F
	ds_load_b128 v[29:32], v127 offset:8496                    // 00000019C174: DBFC2130 1D00007F
	ds_load_b128 v[181:184], v127 offset:16896                 // 00000019C17C: DBFC4200 B500007F
	ds_load_b128 v[185:188], v127 offset:16912                 // 00000019C184: DBFC4210 B900007F
	ds_load_b128 v[189:192], v127 offset:16928                 // 00000019C18C: DBFC4220 BD00007F
	ds_load_b128 v[193:196], v127 offset:16944                 // 00000019C194: DBFC4230 C100007F
	ds_load_b128 v[197:200], v127 offset:25376                 // 00000019C19C: DBFC6320 C500007F
	v_dual_mov_b32 v72, s43 :: v_dual_mov_b32 v71, s42         // 00000019C1A4: CA10002B 4846002A
	v_dual_mov_b32 v70, s41 :: v_dual_mov_b32 v69, s40         // 00000019C1AC: CA100029 46440028
	v_dual_mov_b32 v68, s39 :: v_dual_mov_b32 v67, s38         // 00000019C1B4: CA100027 44420026
	v_dual_mov_b32 v66, s37 :: v_dual_mov_b32 v65, s36         // 00000019C1BC: CA100025 42400024
	s_waitcnt lgkmcnt(12)                                      // 00000019C1C4: BF89FCC7
	v_fma_mixlo_f16 v1, v1, s28, 0                             // 00000019C1C8: CC210001 02003901
	v_fma_mixhi_f16 v1, v2, s28, 0                             // 00000019C1D0: CC220001 02003902
	v_fma_mixlo_f16 v2, v3, s28, 0                             // 00000019C1D8: CC210002 02003903
	v_fma_mixhi_f16 v2, v4, s28, 0                             // 00000019C1E0: CC220002 02003904
	s_waitcnt lgkmcnt(11)                                      // 00000019C1E8: BF89FCB7
	v_fma_mixlo_f16 v3, v5, s28, 0                             // 00000019C1EC: CC210003 02003905
	v_fma_mixhi_f16 v3, v6, s28, 0                             // 00000019C1F4: CC220003 02003906
	v_fma_mixlo_f16 v4, v7, s28, 0                             // 00000019C1FC: CC210004 02003907
	v_fma_mixhi_f16 v4, v8, s28, 0                             // 00000019C204: CC220004 02003908
	s_waitcnt lgkmcnt(10)                                      // 00000019C20C: BF89FCA7
	v_fma_mixlo_f16 v5, v9, s28, 0                             // 00000019C210: CC210005 02003909
	v_fma_mixhi_f16 v5, v10, s28, 0                            // 00000019C218: CC220005 0200390A
	v_fma_mixlo_f16 v6, v11, s28, 0                            // 00000019C220: CC210006 0200390B
	v_fma_mixhi_f16 v6, v12, s28, 0                            // 00000019C228: CC220006 0200390C
	s_waitcnt lgkmcnt(9)                                       // 00000019C230: BF89FC97
	v_fma_mixlo_f16 v7, v13, s28, 0                            // 00000019C234: CC210007 0200390D
	v_fma_mixhi_f16 v7, v14, s28, 0                            // 00000019C23C: CC220007 0200390E
	v_fma_mixlo_f16 v8, v15, s28, 0                            // 00000019C244: CC210008 0200390F
	v_fma_mixhi_f16 v8, v16, s28, 0                            // 00000019C24C: CC220008 02003910
	s_waitcnt lgkmcnt(8)                                       // 00000019C254: BF89FC87
	v_fma_mixlo_f16 v17, v17, s28, 0                           // 00000019C258: CC210011 02003911
	v_fma_mixhi_f16 v17, v18, s28, 0                           // 00000019C260: CC220011 02003912
	v_fma_mixlo_f16 v18, v19, s28, 0                           // 00000019C268: CC210012 02003913
	v_fma_mixhi_f16 v18, v20, s28, 0                           // 00000019C270: CC220012 02003914
	s_waitcnt lgkmcnt(7)                                       // 00000019C278: BF89FC77
	v_fma_mixlo_f16 v19, v21, s28, 0                           // 00000019C27C: CC210013 02003915
	v_fma_mixhi_f16 v19, v22, s28, 0                           // 00000019C284: CC220013 02003916
	v_fma_mixlo_f16 v20, v23, s28, 0                           // 00000019C28C: CC210014 02003917
	v_fma_mixhi_f16 v20, v24, s28, 0                           // 00000019C294: CC220014 02003918
	s_waitcnt lgkmcnt(6)                                       // 00000019C29C: BF89FC67
	v_fma_mixlo_f16 v21, v25, s28, 0                           // 00000019C2A0: CC210015 02003919
	v_fma_mixhi_f16 v21, v26, s28, 0                           // 00000019C2A8: CC220015 0200391A
	v_fma_mixlo_f16 v22, v27, s28, 0                           // 00000019C2B0: CC210016 0200391B
	v_fma_mixhi_f16 v22, v28, s28, 0                           // 00000019C2B8: CC220016 0200391C
	s_waitcnt lgkmcnt(5)                                       // 00000019C2C0: BF89FC57
	v_fma_mixlo_f16 v23, v29, s28, 0                           // 00000019C2C4: CC210017 0200391D
	v_fma_mixhi_f16 v23, v30, s28, 0                           // 00000019C2CC: CC220017 0200391E
	v_fma_mixlo_f16 v24, v31, s28, 0                           // 00000019C2D4: CC210018 0200391F
	v_fma_mixhi_f16 v24, v32, s28, 0                           // 00000019C2DC: CC220018 02003920
	s_waitcnt vmcnt(14)                                        // 00000019C2E4: BF893BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[97:104], v[1:8], v[65:72]// 00000019C2E8: CC404019 1D060361
	s_waitcnt lgkmcnt(3)                                       // 00000019C2F0: BF89FC37
	v_fma_mixlo_f16 v4, v187, s28, 0                           // 00000019C2F4: CC210004 020039BB
	v_fma_mixhi_f16 v4, v188, s28, 0                           // 00000019C2FC: CC220004 020039BC
	v_wmma_f32_16x16x16_f16 v[9:16], v[97:104], v[17:24], v[65:72]// 00000019C304: CC404009 1D062361
	ds_load_b128 v[17:20], v127 offset:25344                   // 00000019C30C: DBFC6300 1100007F
	ds_load_b128 v[21:24], v127 offset:25360                   // 00000019C314: DBFC6310 1500007F
	s_waitcnt lgkmcnt(4)                                       // 00000019C31C: BF89FC47
	v_fma_mixlo_f16 v5, v189, s28, 0                           // 00000019C320: CC210005 020039BD
	v_fma_mixhi_f16 v5, v190, s28, 0                           // 00000019C328: CC220005 020039BE
	ds_load_b128 v[187:190], v127 offset:25392                 // 00000019C330: DBFC6330 BB00007F
	v_fma_mixlo_f16 v3, v185, s28, 0                           // 00000019C338: CC210003 020039B9
	v_fma_mixlo_f16 v6, v191, s28, 0                           // 00000019C340: CC210006 020039BF
	v_fma_mixhi_f16 v6, v192, s28, 0                           // 00000019C348: CC220006 020039C0
	s_waitcnt lgkmcnt(4)                                       // 00000019C350: BF89FC47
	v_fma_mixlo_f16 v7, v193, s28, 0                           // 00000019C354: CC210007 020039C1
	v_fma_mixhi_f16 v7, v194, s28, 0                           // 00000019C35C: CC220007 020039C2
	v_fma_mixlo_f16 v8, v195, s28, 0                           // 00000019C364: CC210008 020039C3
	v_fma_mixhi_f16 v8, v196, s28, 0                           // 00000019C36C: CC220008 020039C4
	ds_load_b128 v[191:194], v127 offset:64                    // 00000019C374: DBFC0040 BF00007F
	ds_load_b128 v[201:204], v127 offset:80                    // 00000019C37C: DBFC0050 C900007F
	s_waitcnt lgkmcnt(5)                                       // 00000019C384: BF89FC57
	v_fma_mixlo_f16 v185, v197, s28, 0                         // 00000019C388: CC2100B9 020039C5
	v_fma_mixhi_f16 v185, v198, s28, 0                         // 00000019C390: CC2200B9 020039C6
	ds_load_b128 v[195:198], v127 offset:96                    // 00000019C398: DBFC0060 C300007F
	ds_load_b128 v[205:208], v127 offset:112                   // 00000019C3A0: DBFC0070 CD00007F
	v_fma_mixlo_f16 v1, v181, s28, 0                           // 00000019C3A8: CC210001 020039B5
	v_fma_mixhi_f16 v1, v182, s28, 0                           // 00000019C3B0: CC220001 020039B6
	v_fma_mixlo_f16 v2, v183, s28, 0                           // 00000019C3B8: CC210002 020039B7
	v_fma_mixhi_f16 v2, v184, s28, 0                           // 00000019C3C0: CC220002 020039B8
	v_fma_mixhi_f16 v3, v186, s28, 0                           // 00000019C3C8: CC220003 020039BA
	s_waitcnt lgkmcnt(6)                                       // 00000019C3D0: BF89FC67
	v_fma_mixlo_f16 v181, v17, s28, 0                          // 00000019C3D4: CC2100B5 02003911
	v_fma_mixhi_f16 v181, v18, s28, 0                          // 00000019C3DC: CC2200B5 02003912
	v_fma_mixlo_f16 v182, v19, s28, 0                          // 00000019C3E4: CC2100B6 02003913
	v_fma_mixhi_f16 v182, v20, s28, 0                          // 00000019C3EC: CC2200B6 02003914
	s_waitcnt lgkmcnt(5)                                       // 00000019C3F4: BF89FC57
	v_fma_mixlo_f16 v183, v21, s28, 0                          // 00000019C3F8: CC2100B7 02003915
	v_fma_mixhi_f16 v183, v22, s28, 0                          // 00000019C400: CC2200B7 02003916
	v_fma_mixlo_f16 v184, v23, s28, 0                          // 00000019C408: CC2100B8 02003917
	v_fma_mixhi_f16 v184, v24, s28, 0                          // 00000019C410: CC2200B8 02003918
	v_fma_mixlo_f16 v186, v199, s28, 0                         // 00000019C418: CC2100BA 020039C7
	v_fma_mixhi_f16 v186, v200, s28, 0                         // 00000019C420: CC2200BA 020039C8
	s_waitcnt lgkmcnt(4)                                       // 00000019C428: BF89FC47
	v_fma_mixlo_f16 v187, v187, s28, 0                         // 00000019C42C: CC2100BB 020039BB
	v_fma_mixhi_f16 v187, v188, s28, 0                         // 00000019C434: CC2200BB 020039BC
	v_fma_mixlo_f16 v188, v189, s28, 0                         // 00000019C43C: CC2100BC 020039BD
	v_fma_mixhi_f16 v188, v190, s28, 0                         // 00000019C444: CC2200BC 020039BE
	v_wmma_f32_16x16x16_f16 v[17:24], v[97:104], v[1:8], v[65:72]// 00000019C44C: CC404011 1D060361
	ds_load_b128 v[209:212], v127 offset:17008                 // 00000019C454: DBFC4270 D100007F
	ds_load_b128 v[213:216], v127 offset:25408                 // 00000019C45C: DBFC6340 D500007F
	ds_load_b128 v[217:220], v127 offset:25424                 // 00000019C464: DBFC6350 D900007F
	v_wmma_f32_16x16x16_f16 v[1:8], v[97:104], v[181:188], v[65:72]// 00000019C46C: CC404001 1D076B61
	ds_load_b128 v[181:184], v127 offset:8512                  // 00000019C474: DBFC2140 B500007F
	ds_load_b128 v[185:188], v127 offset:8528                  // 00000019C47C: DBFC2150 B900007F
	s_waitcnt lgkmcnt(8)                                       // 00000019C484: BF89FC87
	v_fma_mixlo_f16 v97, v191, s28, 0                          // 00000019C488: CC210061 020039BF
	v_fma_mixhi_f16 v97, v192, s28, 0                          // 00000019C490: CC220061 020039C0
	v_fma_mixlo_f16 v98, v193, s28, 0                          // 00000019C498: CC210062 020039C1
	v_fma_mixhi_f16 v98, v194, s28, 0                          // 00000019C4A0: CC220062 020039C2
	s_waitcnt lgkmcnt(7)                                       // 00000019C4A8: BF89FC77
	v_fma_mixlo_f16 v99, v201, s28, 0                          // 00000019C4AC: CC210063 020039C9
	v_fma_mixhi_f16 v99, v202, s28, 0                          // 00000019C4B4: CC220063 020039CA
	v_fma_mixlo_f16 v100, v203, s28, 0                         // 00000019C4BC: CC210064 020039CB
	v_fma_mixhi_f16 v100, v204, s28, 0                         // 00000019C4C4: CC220064 020039CC
	ds_load_b128 v[189:192], v127 offset:8544                  // 00000019C4CC: DBFC2160 BD00007F
	s_waitcnt lgkmcnt(7)                                       // 00000019C4D4: BF89FC77
	v_fma_mixlo_f16 v101, v195, s28, 0                         // 00000019C4D8: CC210065 020039C3
	v_fma_mixhi_f16 v101, v196, s28, 0                         // 00000019C4E0: CC220065 020039C4
	v_fma_mixlo_f16 v102, v197, s28, 0                         // 00000019C4E8: CC210066 020039C5
	v_fma_mixhi_f16 v102, v198, s28, 0                         // 00000019C4F0: CC220066 020039C6
	ds_load_b128 v[193:196], v127 offset:8560                  // 00000019C4F8: DBFC2170 C100007F
	s_waitcnt lgkmcnt(7)                                       // 00000019C500: BF89FC77
	v_fma_mixlo_f16 v103, v205, s28, 0                         // 00000019C504: CC210067 020039CD
	v_fma_mixhi_f16 v103, v206, s28, 0                         // 00000019C50C: CC220067 020039CE
	v_fma_mixlo_f16 v104, v207, s28, 0                         // 00000019C514: CC210068 020039CF
	v_fma_mixhi_f16 v104, v208, s28, 0                         // 00000019C51C: CC220068 020039D0
	ds_load_b128 v[197:200], v127 offset:16960                 // 00000019C524: DBFC4240 C500007F
	ds_load_b128 v[201:204], v127 offset:16976                 // 00000019C52C: DBFC4250 C900007F
	ds_load_b128 v[205:208], v127 offset:16992                 // 00000019C534: DBFC4260 CD00007F
	s_waitcnt lgkmcnt(6)                                       // 00000019C53C: BF89FC67
	v_fma_mixlo_f16 v181, v181, s28, 0                         // 00000019C540: CC2100B5 020039B5
	v_fma_mixhi_f16 v181, v182, s28, 0                         // 00000019C548: CC2200B5 020039B6
	v_fma_mixlo_f16 v182, v183, s28, 0                         // 00000019C550: CC2100B6 020039B7
	v_fma_mixhi_f16 v182, v184, s28, 0                         // 00000019C558: CC2200B6 020039B8
	s_waitcnt lgkmcnt(5)                                       // 00000019C560: BF89FC57
	v_fma_mixhi_f16 v183, v186, s28, 0                         // 00000019C564: CC2200B7 020039BA
	v_fma_mixlo_f16 v184, v187, s28, 0                         // 00000019C56C: CC2100B8 020039BB
	ds_load_b128 v[221:224], v127 offset:25440                 // 00000019C574: DBFC6360 DD00007F
	s_waitcnt lgkmcnt(5)                                       // 00000019C57C: BF89FC57
	v_fma_mixhi_f16 v186, v192, s28, 0                         // 00000019C580: CC2200BA 020039C0
	v_fma_mixlo_f16 v183, v185, s28, 0                         // 00000019C588: CC2100B7 020039B9
	v_fma_mixhi_f16 v184, v188, s28, 0                         // 00000019C590: CC2200B8 020039BC
	v_fma_mixlo_f16 v185, v189, s28, 0                         // 00000019C598: CC2100B9 020039BD
	v_fma_mixhi_f16 v185, v190, s28, 0                         // 00000019C5A0: CC2200B9 020039BE
	s_waitcnt lgkmcnt(4)                                       // 00000019C5A8: BF89FC47
	v_fma_mixlo_f16 v187, v193, s28, 0                         // 00000019C5AC: CC2100BB 020039C1
	v_fma_mixlo_f16 v186, v191, s28, 0                         // 00000019C5B4: CC2100BA 020039BF
	v_fma_mixhi_f16 v187, v194, s28, 0                         // 00000019C5BC: CC2200BB 020039C2
	v_fma_mixlo_f16 v188, v195, s28, 0                         // 00000019C5C4: CC2100BC 020039C3
	v_fma_mixhi_f16 v188, v196, s28, 0                         // 00000019C5CC: CC2200BC 020039C4
	s_waitcnt lgkmcnt(3)                                       // 00000019C5D4: BF89FC37
	v_fma_mixlo_f16 v189, v197, s28, 0                         // 00000019C5D8: CC2100BD 020039C5
	s_waitcnt lgkmcnt(2)                                       // 00000019C5E0: BF89FC27
	v_fma_mixlo_f16 v192, v203, s28, 0                         // 00000019C5E4: CC2100C0 020039CB
	v_fma_mixhi_f16 v192, v204, s28, 0                         // 00000019C5EC: CC2200C0 020039CC
	s_waitcnt lgkmcnt(1)                                       // 00000019C5F4: BF89FC17
	v_fma_mixlo_f16 v193, v205, s28, 0                         // 00000019C5F8: CC2100C1 020039CD
	v_fma_mixhi_f16 v193, v206, s28, 0                         // 00000019C600: CC2200C1 020039CE
	ds_load_b128 v[203:206], v127 offset:25456                 // 00000019C608: DBFC6370 CB00007F
	v_fma_mixhi_f16 v189, v198, s28, 0                         // 00000019C610: CC2200BD 020039C6
	v_fma_mixlo_f16 v190, v199, s28, 0                         // 00000019C618: CC2100BE 020039C7
	v_fma_mixhi_f16 v190, v200, s28, 0                         // 00000019C620: CC2200BE 020039C8
	v_fma_mixlo_f16 v191, v201, s28, 0                         // 00000019C628: CC2100BF 020039C9
	v_fma_mixhi_f16 v191, v202, s28, 0                         // 00000019C630: CC2200BF 020039CA
	v_fma_mixlo_f16 v194, v207, s28, 0                         // 00000019C638: CC2100C2 020039CF
	v_fma_mixhi_f16 v194, v208, s28, 0                         // 00000019C640: CC2200C2 020039D0
	v_fma_mixlo_f16 v195, v209, s28, 0                         // 00000019C648: CC2100C3 020039D1
	v_fma_mixhi_f16 v195, v210, s28, 0                         // 00000019C650: CC2200C3 020039D2
	v_fma_mixlo_f16 v196, v211, s28, 0                         // 00000019C658: CC2100C4 020039D3
	v_fma_mixhi_f16 v196, v212, s28, 0                         // 00000019C660: CC2200C4 020039D4
	v_fma_mixlo_f16 v197, v213, s28, 0                         // 00000019C668: CC2100C5 020039D5
	v_fma_mixhi_f16 v197, v214, s28, 0                         // 00000019C670: CC2200C5 020039D6
	v_fma_mixlo_f16 v198, v215, s28, 0                         // 00000019C678: CC2100C6 020039D7
	v_fma_mixhi_f16 v198, v216, s28, 0                         // 00000019C680: CC2200C6 020039D8
	v_fma_mixlo_f16 v199, v217, s28, 0                         // 00000019C688: CC2100C7 020039D9
	v_fma_mixhi_f16 v199, v218, s28, 0                         // 00000019C690: CC2200C7 020039DA
	v_fma_mixlo_f16 v200, v219, s28, 0                         // 00000019C698: CC2100C8 020039DB
	v_fma_mixhi_f16 v200, v220, s28, 0                         // 00000019C6A0: CC2200C8 020039DC
	s_waitcnt lgkmcnt(1)                                       // 00000019C6A8: BF89FC17
	v_fma_mixlo_f16 v201, v221, s28, 0                         // 00000019C6AC: CC2100C9 020039DD
	v_fma_mixhi_f16 v201, v222, s28, 0                         // 00000019C6B4: CC2200C9 020039DE
	v_fma_mixlo_f16 v202, v223, s28, 0                         // 00000019C6BC: CC2100CA 020039DF
	v_fma_mixhi_f16 v202, v224, s28, 0                         // 00000019C6C4: CC2200CA 020039E0
	s_waitcnt lgkmcnt(0)                                       // 00000019C6CC: BF89FC07
	v_fma_mixlo_f16 v203, v203, s28, 0                         // 00000019C6D0: CC2100CB 020039CB
	v_fma_mixhi_f16 v203, v204, s28, 0                         // 00000019C6D8: CC2200CB 020039CC
	v_fma_mixlo_f16 v204, v205, s28, 0                         // 00000019C6E0: CC2100CC 020039CD
	v_fma_mixhi_f16 v204, v206, s28, 0                         // 00000019C6E8: CC2200CC 020039CE
	ds_load_b128 v[207:210], v127 offset:128                   // 00000019C6F0: DBFC0080 CF00007F
	ds_load_b128 v[211:214], v127 offset:144                   // 00000019C6F8: DBFC0090 D300007F
	ds_load_b128 v[215:218], v127 offset:160                   // 00000019C700: DBFC00A0 D700007F
	s_waitcnt vmcnt(12)                                        // 00000019C708: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[97:104], v[25:32]// 00000019C70C: CC404019 1C66C359
	ds_load_b128 v[97:100], v127 offset:176                    // 00000019C714: DBFC00B0 6100007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[89:96], v[181:188], v[9:16]// 00000019C71C: CC404009 1C276B59
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[189:196], v[17:24]// 00000019C724: CC404011 1C477B59
	v_wmma_f32_16x16x16_f16 v[1:8], v[89:96], v[197:204], v[1:8]// 00000019C72C: CC404001 1C078B59
	ds_load_b128 v[101:104], v127 offset:8576                  // 00000019C734: DBFC2180 6500007F
	ds_load_b128 v[181:184], v127 offset:8592                  // 00000019C73C: DBFC2190 B500007F
	ds_load_b128 v[185:188], v127 offset:8608                  // 00000019C744: DBFC21A0 B900007F
	ds_load_b128 v[189:192], v127 offset:8624                  // 00000019C74C: DBFC21B0 BD00007F
	ds_load_b128 v[193:196], v127 offset:17024                 // 00000019C754: DBFC4280 C100007F
	ds_load_b128 v[197:200], v127 offset:17040                 // 00000019C75C: DBFC4290 C500007F
	ds_load_b128 v[201:204], v127 offset:17056                 // 00000019C764: DBFC42A0 C900007F
	s_mul_i32 s22, s29, 48                                     // 00000019C76C: 9616B01D
	s_mul_hi_u32 s23, s29, 48                                  // 00000019C770: 9697B01D
	s_add_u32 s50, s22, s2                                     // 00000019C774: 80320216
	s_addc_u32 s51, s23, s3                                    // 00000019C778: 82330317
	ds_load_b128 v[221:224], v127 offset:25648                 // 00000019C77C: DBFC6430 DD00007F
	s_waitcnt lgkmcnt(11)                                      // 00000019C784: BF89FCB7
	v_fma_mixlo_f16 v89, v207, s28, 0                          // 00000019C788: CC210059 020039CF
	v_fma_mixhi_f16 v89, v208, s28, 0                          // 00000019C790: CC220059 020039D0
	v_fma_mixlo_f16 v90, v209, s28, 0                          // 00000019C798: CC21005A 020039D1
	v_fma_mixhi_f16 v90, v210, s28, 0                          // 00000019C7A0: CC22005A 020039D2
	s_waitcnt lgkmcnt(10)                                      // 00000019C7A8: BF89FCA7
	v_fma_mixlo_f16 v91, v211, s28, 0                          // 00000019C7AC: CC21005B 020039D3
	v_fma_mixhi_f16 v91, v212, s28, 0                          // 00000019C7B4: CC22005B 020039D4
	s_waitcnt lgkmcnt(8)                                       // 00000019C7BC: BF89FC87
	v_fma_mixhi_f16 v95, v98, s28, 0                           // 00000019C7C0: CC22005F 02003962
	v_fma_mixlo_f16 v96, v99, s28, 0                           // 00000019C7C8: CC210060 02003963
	v_fma_mixhi_f16 v96, v100, s28, 0                          // 00000019C7D0: CC220060 02003964
	s_waitcnt lgkmcnt(7)                                       // 00000019C7D8: BF89FC77
	v_fma_mixlo_f16 v98, v103, s28, 0                          // 00000019C7DC: CC210062 02003967
	v_fma_mixhi_f16 v98, v104, s28, 0                          // 00000019C7E4: CC220062 02003968
	s_waitcnt lgkmcnt(6)                                       // 00000019C7EC: BF89FC67
	v_fma_mixlo_f16 v99, v181, s28, 0                          // 00000019C7F0: CC210063 020039B5
	v_fma_mixhi_f16 v99, v182, s28, 0                          // 00000019C7F8: CC220063 020039B6
	v_fma_mixlo_f16 v100, v183, s28, 0                         // 00000019C800: CC210064 020039B7
	v_fma_mixhi_f16 v100, v184, s28, 0                         // 00000019C808: CC220064 020039B8
	s_waitcnt lgkmcnt(4)                                       // 00000019C810: BF89FC47
	v_fma_mixlo_f16 v103, v189, s28, 0                         // 00000019C814: CC210067 020039BD
	ds_load_b128 v[205:208], v127 offset:17072                 // 00000019C81C: DBFC42B0 CD00007F
	v_fma_mixhi_f16 v103, v190, s28, 0                         // 00000019C824: CC220067 020039BE
	v_fma_mixlo_f16 v104, v191, s28, 0                         // 00000019C82C: CC210068 020039BF
	v_fma_mixhi_f16 v104, v192, s28, 0                         // 00000019C834: CC220068 020039C0
	ds_load_b128 v[189:192], v127 offset:25472                 // 00000019C83C: DBFC6380 BD00007F
	ds_load_b128 v[209:212], v127 offset:25488                 // 00000019C844: DBFC6390 D100007F
	s_waitcnt lgkmcnt(6)                                       // 00000019C84C: BF89FC67
	v_fma_mixlo_f16 v181, v193, s28, 0                         // 00000019C850: CC2100B5 020039C1
	v_fma_mixhi_f16 v181, v194, s28, 0                         // 00000019C858: CC2200B5 020039C2
	v_fma_mixlo_f16 v182, v195, s28, 0                         // 00000019C860: CC2100B6 020039C3
	v_fma_mixhi_f16 v182, v196, s28, 0                         // 00000019C868: CC2200B6 020039C4
	s_waitcnt lgkmcnt(5)                                       // 00000019C870: BF89FC57
	v_fma_mixlo_f16 v183, v197, s28, 0                         // 00000019C874: CC2100B7 020039C5
	v_fma_mixhi_f16 v183, v198, s28, 0                         // 00000019C87C: CC2200B7 020039C6
	v_fma_mixlo_f16 v184, v199, s28, 0                         // 00000019C884: CC2100B8 020039C7
	ds_load_b128 v[193:196], v127 offset:25504                 // 00000019C88C: DBFC63A0 C100007F
	v_fma_mixhi_f16 v184, v200, s28, 0                         // 00000019C894: CC2200B8 020039C8
	ds_load_b128 v[197:200], v127 offset:25520                 // 00000019C89C: DBFC63B0 C500007F
	v_fma_mixlo_f16 v92, v213, s28, 0                          // 00000019C8A4: CC21005C 020039D5
	v_fma_mixhi_f16 v92, v214, s28, 0                          // 00000019C8AC: CC22005C 020039D6
	v_fma_mixlo_f16 v93, v215, s28, 0                          // 00000019C8B4: CC21005D 020039D7
	v_fma_mixhi_f16 v93, v216, s28, 0                          // 00000019C8BC: CC22005D 020039D8
	v_fma_mixlo_f16 v94, v217, s28, 0                          // 00000019C8C4: CC21005E 020039D9
	v_fma_mixhi_f16 v94, v218, s28, 0                          // 00000019C8CC: CC22005E 020039DA
	v_fma_mixlo_f16 v95, v97, s28, 0                           // 00000019C8D4: CC21005F 02003961
	v_fma_mixlo_f16 v97, v101, s28, 0                          // 00000019C8DC: CC210061 02003965
	v_fma_mixhi_f16 v97, v102, s28, 0                          // 00000019C8E4: CC220061 02003966
	v_fma_mixlo_f16 v101, v185, s28, 0                         // 00000019C8EC: CC210065 020039B9
	v_fma_mixhi_f16 v101, v186, s28, 0                         // 00000019C8F4: CC220065 020039BA
	v_fma_mixlo_f16 v102, v187, s28, 0                         // 00000019C8FC: CC210066 020039BB
	v_fma_mixhi_f16 v102, v188, s28, 0                         // 00000019C904: CC220066 020039BC
	s_waitcnt lgkmcnt(6)                                       // 00000019C90C: BF89FC67
	v_fma_mixlo_f16 v185, v201, s28, 0                         // 00000019C910: CC2100B9 020039C9
	v_fma_mixhi_f16 v185, v202, s28, 0                         // 00000019C918: CC2200B9 020039CA
	v_fma_mixlo_f16 v186, v203, s28, 0                         // 00000019C920: CC2100BA 020039CB
	v_fma_mixhi_f16 v186, v204, s28, 0                         // 00000019C928: CC2200BA 020039CC
	s_waitcnt lgkmcnt(4)                                       // 00000019C930: BF89FC47
	v_fma_mixlo_f16 v187, v205, s28, 0                         // 00000019C934: CC2100BB 020039CD
	v_fma_mixhi_f16 v187, v206, s28, 0                         // 00000019C93C: CC2200BB 020039CE
	v_fma_mixlo_f16 v188, v207, s28, 0                         // 00000019C944: CC2100BC 020039CF
	v_fma_mixhi_f16 v188, v208, s28, 0                         // 00000019C94C: CC2200BC 020039D0
	s_waitcnt lgkmcnt(3)                                       // 00000019C954: BF89FC37
	v_fma_mixlo_f16 v189, v189, s28, 0                         // 00000019C958: CC2100BD 020039BD
	v_fma_mixhi_f16 v189, v190, s28, 0                         // 00000019C960: CC2200BD 020039BE
	v_fma_mixlo_f16 v190, v191, s28, 0                         // 00000019C968: CC2100BE 020039BF
	v_fma_mixhi_f16 v190, v192, s28, 0                         // 00000019C970: CC2200BE 020039C0
	s_waitcnt lgkmcnt(2)                                       // 00000019C978: BF89FC27
	v_fma_mixlo_f16 v191, v209, s28, 0                         // 00000019C97C: CC2100BF 020039D1
	v_fma_mixhi_f16 v191, v210, s28, 0                         // 00000019C984: CC2200BF 020039D2
	v_fma_mixlo_f16 v192, v211, s28, 0                         // 00000019C98C: CC2100C0 020039D3
	v_fma_mixhi_f16 v192, v212, s28, 0                         // 00000019C994: CC2200C0 020039D4
	s_waitcnt lgkmcnt(1)                                       // 00000019C99C: BF89FC17
	v_fma_mixlo_f16 v193, v193, s28, 0                         // 00000019C9A0: CC2100C1 020039C1
	v_fma_mixhi_f16 v193, v194, s28, 0                         // 00000019C9A8: CC2200C1 020039C2
	v_fma_mixlo_f16 v194, v195, s28, 0                         // 00000019C9B0: CC2100C2 020039C3
	v_fma_mixhi_f16 v194, v196, s28, 0                         // 00000019C9B8: CC2200C2 020039C4
	s_waitcnt lgkmcnt(0)                                       // 00000019C9C0: BF89FC07
	v_fma_mixlo_f16 v195, v197, s28, 0                         // 00000019C9C4: CC2100C3 020039C5
	v_fma_mixhi_f16 v195, v198, s28, 0                         // 00000019C9CC: CC2200C3 020039C6
	v_fma_mixlo_f16 v196, v199, s28, 0                         // 00000019C9D4: CC2100C4 020039C7
	v_fma_mixhi_f16 v196, v200, s28, 0                         // 00000019C9DC: CC2200C4 020039C8
	ds_load_b128 v[201:204], v127 offset:192                   // 00000019C9E4: DBFC00C0 C900007F
	ds_load_b128 v[205:208], v127 offset:208                   // 00000019C9EC: DBFC00D0 CD00007F
	ds_load_b128 v[209:212], v127 offset:224                   // 00000019C9F4: DBFC00E0 D100007F
	s_waitcnt vmcnt(10)                                        // 00000019C9FC: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 00000019CA00: CC404019 1C66B351
	ds_load_b128 v[89:92], v127 offset:240                     // 00000019CA08: DBFC00F0 5900007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[97:104], v[9:16]// 00000019CA10: CC404009 1C26C351
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[181:188], v[17:24]// 00000019CA18: CC404011 1C476B51
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[189:196], v[1:8]// 00000019CA20: CC404001 1C077B51
	ds_load_b128 v[93:96], v127 offset:8640                    // 00000019CA28: DBFC21C0 5D00007F
	ds_load_b128 v[97:100], v127 offset:8656                   // 00000019CA30: DBFC21D0 6100007F
	ds_load_b128 v[101:104], v127 offset:8672                  // 00000019CA38: DBFC21E0 6500007F
	ds_load_b128 v[181:184], v127 offset:8688                  // 00000019CA40: DBFC21F0 B500007F
	ds_load_b128 v[185:188], v127 offset:17088                 // 00000019CA48: DBFC42C0 B900007F
	ds_load_b128 v[189:192], v127 offset:17104                 // 00000019CA50: DBFC42D0 BD00007F
	ds_load_b128 v[193:196], v127 offset:17120                 // 00000019CA58: DBFC42E0 C100007F
	ds_load_b128 v[197:200], v127 offset:17136                 // 00000019CA60: DBFC42F0 C500007F
	s_lshl_b64 s[50:51], s[50:51], 13                          // 00000019CA68: 84B28D32
	ds_load_b128 v[213:216], v127 offset:25616                 // 00000019CA6C: DBFC6410 D500007F
	.long 0xd7006a74                                           // 00000019CA74: D7006A74
	v_cndmask_b32_e32 v0, v137, v50, vcc_lo                    // 00000019CA78: 02006589
	s_waitcnt lgkmcnt(12)                                      // 00000019CA7C: BF89FCC7
	v_fma_mixlo_f16 v81, v201, s28, 0                          // 00000019CA80: CC210051 020039C9
	v_fma_mixhi_f16 v81, v202, s28, 0                          // 00000019CA88: CC220051 020039CA
	v_fma_mixlo_f16 v82, v203, s28, 0                          // 00000019CA90: CC210052 020039CB
	v_fma_mixhi_f16 v82, v204, s28, 0                          // 00000019CA98: CC220052 020039CC
	s_waitcnt lgkmcnt(9)                                       // 00000019CAA0: BF89FC97
	v_fma_mixhi_f16 v87, v90, s28, 0                           // 00000019CAA4: CC220057 0200395A
	v_fma_mixlo_f16 v88, v91, s28, 0                           // 00000019CAAC: CC210058 0200395B
	v_fma_mixhi_f16 v88, v92, s28, 0                           // 00000019CAB4: CC220058 0200395C
	ds_load_b128 v[201:204], v127 offset:25552                 // 00000019CABC: DBFC63D0 C900007F
	s_waitcnt lgkmcnt(9)                                       // 00000019CAC4: BF89FC97
	v_fma_mixlo_f16 v90, v95, s28, 0                           // 00000019CAC8: CC21005A 0200395F
	v_fma_mixhi_f16 v90, v96, s28, 0                           // 00000019CAD0: CC22005A 02003960
	s_waitcnt lgkmcnt(8)                                       // 00000019CAD8: BF89FC87
	v_fma_mixlo_f16 v91, v97, s28, 0                           // 00000019CADC: CC21005B 02003961
	v_fma_mixhi_f16 v91, v98, s28, 0                           // 00000019CAE4: CC22005B 02003962
	v_fma_mixlo_f16 v92, v99, s28, 0                           // 00000019CAEC: CC21005C 02003963
	v_fma_mixhi_f16 v92, v100, s28, 0                          // 00000019CAF4: CC22005C 02003964
	s_waitcnt lgkmcnt(6)                                       // 00000019CAFC: BF89FC67
	v_fma_mixlo_f16 v95, v181, s28, 0                          // 00000019CB00: CC21005F 020039B5
	v_fma_mixhi_f16 v95, v182, s28, 0                          // 00000019CB08: CC22005F 020039B6
	v_fma_mixlo_f16 v96, v183, s28, 0                          // 00000019CB10: CC210060 020039B7
	v_fma_mixhi_f16 v96, v184, s28, 0                          // 00000019CB18: CC220060 020039B8
	ds_load_b128 v[181:184], v127 offset:25536                 // 00000019CB20: DBFC63C0 B500007F
	s_waitcnt lgkmcnt(6)                                       // 00000019CB28: BF89FC67
	v_fma_mixlo_f16 v97, v185, s28, 0                          // 00000019CB2C: CC210061 020039B9
	v_fma_mixhi_f16 v97, v186, s28, 0                          // 00000019CB34: CC220061 020039BA
	v_fma_mixlo_f16 v98, v187, s28, 0                          // 00000019CB3C: CC210062 020039BB
	v_fma_mixhi_f16 v98, v188, s28, 0                          // 00000019CB44: CC220062 020039BC
	s_waitcnt lgkmcnt(5)                                       // 00000019CB4C: BF89FC57
	v_fma_mixlo_f16 v99, v189, s28, 0                          // 00000019CB50: CC210063 020039BD
	v_fma_mixhi_f16 v99, v190, s28, 0                          // 00000019CB58: CC220063 020039BE
	v_fma_mixlo_f16 v100, v191, s28, 0                         // 00000019CB60: CC210064 020039BF
	v_fma_mixhi_f16 v100, v192, s28, 0                         // 00000019CB68: CC220064 020039C0
	ds_load_b128 v[185:188], v127 offset:25568                 // 00000019CB70: DBFC63E0 B900007F
	ds_load_b128 v[189:192], v127 offset:25584                 // 00000019CB78: DBFC63F0 BD00007F
	v_fma_mixlo_f16 v83, v205, s28, 0                          // 00000019CB80: CC210053 020039CD
	v_fma_mixhi_f16 v83, v206, s28, 0                          // 00000019CB88: CC220053 020039CE
	v_fma_mixlo_f16 v84, v207, s28, 0                          // 00000019CB90: CC210054 020039CF
	v_fma_mixhi_f16 v84, v208, s28, 0                          // 00000019CB98: CC220054 020039D0
	v_fma_mixlo_f16 v85, v209, s28, 0                          // 00000019CBA0: CC210055 020039D1
	v_fma_mixhi_f16 v85, v210, s28, 0                          // 00000019CBA8: CC220055 020039D2
	v_fma_mixlo_f16 v86, v211, s28, 0                          // 00000019CBB0: CC210056 020039D3
	v_fma_mixhi_f16 v86, v212, s28, 0                          // 00000019CBB8: CC220056 020039D4
	v_fma_mixlo_f16 v87, v89, s28, 0                           // 00000019CBC0: CC210057 02003959
	v_fma_mixlo_f16 v89, v93, s28, 0                           // 00000019CBC8: CC210059 0200395D
	v_fma_mixhi_f16 v89, v94, s28, 0                           // 00000019CBD0: CC220059 0200395E
	v_fma_mixlo_f16 v93, v101, s28, 0                          // 00000019CBD8: CC21005D 02003965
	v_fma_mixhi_f16 v93, v102, s28, 0                          // 00000019CBE0: CC22005D 02003966
	v_fma_mixlo_f16 v94, v103, s28, 0                          // 00000019CBE8: CC21005E 02003967
	v_fma_mixhi_f16 v94, v104, s28, 0                          // 00000019CBF0: CC22005E 02003968
	s_waitcnt lgkmcnt(6)                                       // 00000019CBF8: BF89FC67
	v_fma_mixlo_f16 v101, v193, s28, 0                         // 00000019CBFC: CC210065 020039C1
	v_fma_mixhi_f16 v101, v194, s28, 0                         // 00000019CC04: CC220065 020039C2
	v_fma_mixlo_f16 v102, v195, s28, 0                         // 00000019CC0C: CC210066 020039C3
	v_fma_mixhi_f16 v102, v196, s28, 0                         // 00000019CC14: CC220066 020039C4
	s_waitcnt lgkmcnt(5)                                       // 00000019CC1C: BF89FC57
	v_fma_mixlo_f16 v103, v197, s28, 0                         // 00000019CC20: CC210067 020039C5
	v_fma_mixhi_f16 v103, v198, s28, 0                         // 00000019CC28: CC220067 020039C6
	v_fma_mixlo_f16 v104, v199, s28, 0                         // 00000019CC30: CC210068 020039C7
	v_fma_mixhi_f16 v104, v200, s28, 0                         // 00000019CC38: CC220068 020039C8
	s_waitcnt vmcnt(8)                                         // 00000019CC40: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[81:88], v[25:32]// 00000019CC44: CC404019 1C66A349
	ds_load_b128 v[81:84], v127 offset:8704                    // 00000019CC4C: DBFC2200 5100007F
	ds_load_b128 v[85:88], v127 offset:8720                    // 00000019CC54: DBFC2210 5500007F
	s_waitcnt lgkmcnt(4)                                       // 00000019CC5C: BF89FC47
	v_fma_mixlo_f16 v181, v181, s28, 0                         // 00000019CC60: CC2100B5 020039B5
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[97:104], v[17:24]// 00000019CC68: CC404011 1C46C349
	ds_load_b128 v[102:105], v127 offset:8736                  // 00000019CC70: DBFC2220 6600007F
	v_fma_mixhi_f16 v181, v182, s28, 0                         // 00000019CC78: CC2200B5 020039B6
	v_fma_mixlo_f16 v182, v183, s28, 0                         // 00000019CC80: CC2100B6 020039B7
	v_fma_mixhi_f16 v182, v184, s28, 0                         // 00000019CC88: CC2200B6 020039B8
	v_fma_mixlo_f16 v183, v201, s28, 0                         // 00000019CC90: CC2100B7 020039C9
	v_fma_mixhi_f16 v183, v202, s28, 0                         // 00000019CC98: CC2200B7 020039CA
	v_fma_mixlo_f16 v184, v203, s28, 0                         // 00000019CCA0: CC2100B8 020039CB
	v_fma_mixhi_f16 v184, v204, s28, 0                         // 00000019CCA8: CC2200B8 020039CC
	s_waitcnt lgkmcnt(4)                                       // 00000019CCB0: BF89FC47
	v_fma_mixlo_f16 v185, v185, s28, 0                         // 00000019CCB4: CC2100B9 020039B9
	v_fma_mixhi_f16 v185, v186, s28, 0                         // 00000019CCBC: CC2200B9 020039BA
	v_fma_mixlo_f16 v186, v187, s28, 0                         // 00000019CCC4: CC2100BA 020039BB
	v_fma_mixhi_f16 v186, v188, s28, 0                         // 00000019CCCC: CC2200BA 020039BC
	s_waitcnt lgkmcnt(3)                                       // 00000019CCD4: BF89FC37
	v_fma_mixlo_f16 v187, v189, s28, 0                         // 00000019CCD8: CC2100BB 020039BD
	v_fma_mixhi_f16 v187, v190, s28, 0                         // 00000019CCE0: CC2200BB 020039BE
	v_fma_mixlo_f16 v188, v191, s28, 0                         // 00000019CCE8: CC2100BC 020039BF
	v_fma_mixhi_f16 v188, v192, s28, 0                         // 00000019CCF0: CC2200BC 020039C0
	v_add_co_ci_u32_e64 v117, null, s51, v138, vcc_lo          // 00000019CCF8: D5207C75 01AB1433
	v_wmma_f32_16x16x16_f16 v[9:16], v[73:80], v[89:96], v[9:16]// 00000019CD00: CC404009 1C26B349
	s_waitcnt lgkmcnt(2)                                       // 00000019CD08: BF89FC27
	v_fma_mixlo_f16 v81, v81, s28, 0                           // 00000019CD0C: CC210051 02003951
	v_wmma_f32_16x16x16_f16 v[1:8], v[73:80], v[181:188], v[1:8]// 00000019CD14: CC404001 1C076B49
	s_clause 0x1                                               // 00000019CD1C: BF850001
	global_load_b128 v[185:188], v[116:117], off offset:16     // 00000019CD20: DC5E0010 B97C0074
	global_load_b128 v[181:184], v[116:117], off               // 00000019CD28: DC5E0000 B57C0074
	v_fma_mixhi_f16 v81, v82, s28, 0                           // 00000019CD30: CC220051 02003952
	v_fma_mixlo_f16 v82, v83, s28, 0                           // 00000019CD38: CC210052 02003953
	ds_load_b128 v[189:192], v127 offset:8752                  // 00000019CD40: DBFC2230 BD00007F
	s_waitcnt lgkmcnt(2)                                       // 00000019CD48: BF89FC27
	v_fma_mixlo_f16 v83, v85, s28, 0                           // 00000019CD4C: CC210053 02003955
	v_fma_mixhi_f16 v83, v86, s28, 0                           // 00000019CD54: CC220053 02003956
	s_waitcnt lgkmcnt(1)                                       // 00000019CD5C: BF89FC17
	v_fma_mixlo_f16 v85, v102, s28, 0                          // 00000019CD60: CC210055 02003966
	v_fma_mixhi_f16 v85, v103, s28, 0                          // 00000019CD68: CC220055 02003967
	v_fma_mixlo_f16 v86, v104, s28, 0                          // 00000019CD70: CC210056 02003968
	s_clause 0x3                                               // 00000019CD78: BF850003
	global_load_b128 v[101:104], v[116:117], off offset:80     // 00000019CD7C: DC5E0050 657C0074
	global_load_b128 v[97:100], v[116:117], off offset:64      // 00000019CD84: DC5E0040 617C0074
	global_load_b128 v[93:96], v[116:117], off offset:112      // 00000019CD8C: DC5E0070 5D7C0074
	global_load_b128 v[89:92], v[116:117], off offset:96       // 00000019CD94: DC5E0060 597C0074
	ds_load_b128 v[193:196], v127 offset:256                   // 00000019CD9C: DBFC0100 C100007F
	ds_load_b128 v[197:200], v127 offset:272                   // 00000019CDA4: DBFC0110 C500007F
	ds_load_b128 v[201:204], v127 offset:288                   // 00000019CDAC: DBFC0120 C900007F
	ds_load_b128 v[205:208], v127 offset:304                   // 00000019CDB4: DBFC0130 CD00007F
	ds_load_b128 v[209:212], v127 offset:25600                 // 00000019CDBC: DBFC6400 D100007F
	ds_load_b128 v[217:220], v127 offset:25632                 // 00000019CDC4: DBFC6420 D900007F
	v_fma_mixhi_f16 v82, v84, s28, 0                           // 00000019CDCC: CC220052 02003954
	v_fma_mixlo_f16 v84, v87, s28, 0                           // 00000019CDD4: CC210054 02003957
	v_fma_mixhi_f16 v84, v88, s28, 0                           // 00000019CDDC: CC220054 02003958
	v_fma_mixhi_f16 v86, v105, s28, 0                          // 00000019CDE4: CC220056 02003969
	s_waitcnt lgkmcnt(6)                                       // 00000019CDEC: BF89FC67
	v_fma_mixlo_f16 v87, v189, s28, 0                          // 00000019CDF0: CC210057 020039BD
	v_fma_mixhi_f16 v87, v190, s28, 0                          // 00000019CDF8: CC220057 020039BE
	v_fma_mixlo_f16 v88, v191, s28, 0                          // 00000019CE00: CC210058 020039BF
	v_fma_mixhi_f16 v88, v192, s28, 0                          // 00000019CE08: CC220058 020039C0
	s_waitcnt lgkmcnt(5)                                       // 00000019CE10: BF89FC57
	v_fma_mixlo_f16 v73, v193, s28, 0                          // 00000019CE14: CC210049 020039C1
	v_fma_mixhi_f16 v73, v194, s28, 0                          // 00000019CE1C: CC220049 020039C2
	v_fma_mixlo_f16 v74, v195, s28, 0                          // 00000019CE24: CC21004A 020039C3
	v_fma_mixhi_f16 v74, v196, s28, 0                          // 00000019CE2C: CC22004A 020039C4
	s_waitcnt lgkmcnt(4)                                       // 00000019CE34: BF89FC47
	v_fma_mixlo_f16 v75, v197, s28, 0                          // 00000019CE38: CC21004B 020039C5
	v_fma_mixhi_f16 v75, v198, s28, 0                          // 00000019CE40: CC22004B 020039C6
	v_fma_mixlo_f16 v76, v199, s28, 0                          // 00000019CE48: CC21004C 020039C7
	v_fma_mixhi_f16 v76, v200, s28, 0                          // 00000019CE50: CC22004C 020039C8
	s_waitcnt lgkmcnt(3)                                       // 00000019CE58: BF89FC37
	v_fma_mixlo_f16 v77, v201, s28, 0                          // 00000019CE5C: CC21004D 020039C9
	v_fma_mixhi_f16 v77, v202, s28, 0                          // 00000019CE64: CC22004D 020039CA
	v_fma_mixlo_f16 v78, v203, s28, 0                          // 00000019CE6C: CC21004E 020039CB
	v_fma_mixhi_f16 v78, v204, s28, 0                          // 00000019CE74: CC22004E 020039CC
	s_waitcnt lgkmcnt(2)                                       // 00000019CE7C: BF89FC27
	v_fma_mixlo_f16 v79, v205, s28, 0                          // 00000019CE80: CC21004F 020039CD
	v_fma_mixhi_f16 v79, v206, s28, 0                          // 00000019CE88: CC22004F 020039CE
	v_fma_mixlo_f16 v80, v207, s28, 0                          // 00000019CE90: CC210050 020039CF
	v_fma_mixhi_f16 v80, v208, s28, 0                          // 00000019CE98: CC220050 020039D0
	ds_load_b128 v[193:196], v127 offset:17152                 // 00000019CEA0: DBFC4300 C100007F
	ds_load_b128 v[197:200], v127 offset:17168                 // 00000019CEA8: DBFC4310 C500007F
	ds_load_b128 v[201:204], v127 offset:17184                 // 00000019CEB0: DBFC4320 C900007F
	ds_load_b128 v[205:208], v127 offset:17200                 // 00000019CEB8: DBFC4330 CD00007F
	s_waitcnt vmcnt(12)                                        // 00000019CEC0: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[73:80], v[25:32]// 00000019CEC4: CC404019 1C669339
	ds_load_b128 v[73:76], v127 offset:368                     // 00000019CECC: DBFC0170 4900007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[57:64], v[81:88], v[9:16]// 00000019CED4: CC404009 1C26A339
	ds_load_b128 v[77:80], v127 offset:8768                    // 00000019CEDC: DBFC2240 4D00007F
	ds_load_b128 v[81:84], v127 offset:8784                    // 00000019CEE4: DBFC2250 5100007F
	ds_load_b128 v[85:88], v127 offset:8800                    // 00000019CEEC: DBFC2260 5500007F
	s_waitcnt lgkmcnt(7)                                       // 00000019CEF4: BF89FC77
	v_fma_mixlo_f16 v189, v193, s28, 0                         // 00000019CEF8: CC2100BD 020039C1
	v_fma_mixhi_f16 v189, v194, s28, 0                         // 00000019CF00: CC2200BD 020039C2
	v_fma_mixlo_f16 v190, v195, s28, 0                         // 00000019CF08: CC2100BE 020039C3
	v_fma_mixhi_f16 v190, v196, s28, 0                         // 00000019CF10: CC2200BE 020039C4
	s_waitcnt lgkmcnt(6)                                       // 00000019CF18: BF89FC67
	v_fma_mixlo_f16 v191, v197, s28, 0                         // 00000019CF1C: CC2100BF 020039C5
	v_fma_mixhi_f16 v191, v198, s28, 0                         // 00000019CF24: CC2200BF 020039C6
	v_fma_mixlo_f16 v192, v199, s28, 0                         // 00000019CF2C: CC2100C0 020039C7
	v_fma_mixhi_f16 v192, v200, s28, 0                         // 00000019CF34: CC2200C0 020039C8
	s_waitcnt lgkmcnt(5)                                       // 00000019CF3C: BF89FC57
	v_fma_mixlo_f16 v193, v201, s28, 0                         // 00000019CF40: CC2100C1 020039C9
	v_fma_mixhi_f16 v193, v202, s28, 0                         // 00000019CF48: CC2200C1 020039CA
	v_fma_mixlo_f16 v194, v203, s28, 0                         // 00000019CF50: CC2100C2 020039CB
	v_fma_mixhi_f16 v194, v204, s28, 0                         // 00000019CF58: CC2200C2 020039CC
	s_waitcnt lgkmcnt(4)                                       // 00000019CF60: BF89FC47
	v_fma_mixlo_f16 v195, v205, s28, 0                         // 00000019CF64: CC2100C3 020039CD
	v_fma_mixhi_f16 v195, v206, s28, 0                         // 00000019CF6C: CC2200C3 020039CE
	v_fma_mixlo_f16 v196, v207, s28, 0                         // 00000019CF74: CC2100C4 020039CF
	v_fma_mixhi_f16 v196, v208, s28, 0                         // 00000019CF7C: CC2200C4 020039D0
	v_fma_mixlo_f16 v197, v209, s28, 0                         // 00000019CF84: CC2100C5 020039D1
	v_fma_mixhi_f16 v197, v210, s28, 0                         // 00000019CF8C: CC2200C5 020039D2
	v_fma_mixlo_f16 v198, v211, s28, 0                         // 00000019CF94: CC2100C6 020039D3
	v_fma_mixhi_f16 v198, v212, s28, 0                         // 00000019CF9C: CC2200C6 020039D4
	v_fma_mixlo_f16 v199, v213, s28, 0                         // 00000019CFA4: CC2100C7 020039D5
	v_fma_mixhi_f16 v199, v214, s28, 0                         // 00000019CFAC: CC2200C7 020039D6
	v_fma_mixlo_f16 v200, v215, s28, 0                         // 00000019CFB4: CC2100C8 020039D7
	v_fma_mixhi_f16 v200, v216, s28, 0                         // 00000019CFBC: CC2200C8 020039D8
	v_fma_mixlo_f16 v201, v217, s28, 0                         // 00000019CFC4: CC2100C9 020039D9
	v_fma_mixhi_f16 v201, v218, s28, 0                         // 00000019CFCC: CC2200C9 020039DA
	v_fma_mixlo_f16 v202, v219, s28, 0                         // 00000019CFD4: CC2100CA 020039DB
	v_fma_mixhi_f16 v202, v220, s28, 0                         // 00000019CFDC: CC2200CA 020039DC
	v_fma_mixlo_f16 v203, v221, s28, 0                         // 00000019CFE4: CC2100CB 020039DD
	v_fma_mixhi_f16 v203, v222, s28, 0                         // 00000019CFEC: CC2200CB 020039DE
	v_fma_mixlo_f16 v204, v223, s28, 0                         // 00000019CFF4: CC2100CC 020039DF
	v_fma_mixhi_f16 v204, v224, s28, 0                         // 00000019CFFC: CC2200CC 020039E0
	ds_load_b128 v[205:208], v127 offset:320                   // 00000019D004: DBFC0140 CD00007F
	ds_load_b128 v[209:212], v127 offset:336                   // 00000019D00C: DBFC0150 D100007F
	ds_load_b128 v[213:216], v127 offset:352                   // 00000019D014: DBFC0160 D500007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[189:196], v[17:24]// 00000019D01C: CC404011 1C477B39
	v_wmma_f32_16x16x16_f16 v[1:8], v[57:64], v[197:204], v[1:8]// 00000019D024: CC404001 1C078B39
	ds_load_b128 v[189:192], v127 offset:8816                  // 00000019D02C: DBFC2270 BD00007F
	ds_load_b128 v[193:196], v127 offset:17216                 // 00000019D034: DBFC4340 C100007F
	ds_load_b128 v[197:200], v127 offset:17232                 // 00000019D03C: DBFC4350 C500007F
	s_waitcnt lgkmcnt(9)                                       // 00000019D044: BF89FC97
	v_fma_mixhi_f16 v63, v74, s28, 0                           // 00000019D048: CC22003F 0200394A
	v_fma_mixlo_f16 v64, v75, s28, 0                           // 00000019D050: CC210040 0200394B
	v_fma_mixhi_f16 v64, v76, s28, 0                           // 00000019D058: CC220040 0200394C
	s_waitcnt lgkmcnt(8)                                       // 00000019D060: BF89FC87
	v_fma_mixlo_f16 v74, v79, s28, 0                           // 00000019D064: CC21004A 0200394F
	v_fma_mixhi_f16 v74, v80, s28, 0                           // 00000019D06C: CC22004A 02003950
	s_waitcnt lgkmcnt(7)                                       // 00000019D074: BF89FC77
	v_fma_mixlo_f16 v75, v81, s28, 0                           // 00000019D078: CC21004B 02003951
	v_fma_mixhi_f16 v75, v82, s28, 0                           // 00000019D080: CC22004B 02003952
	v_fma_mixlo_f16 v76, v83, s28, 0                           // 00000019D088: CC21004C 02003953
	v_fma_mixhi_f16 v76, v84, s28, 0                           // 00000019D090: CC22004C 02003954
	ds_load_b128 v[201:204], v127 offset:17248                 // 00000019D098: DBFC4360 C900007F
	v_fma_mixlo_f16 v63, v73, s28, 0                           // 00000019D0A0: CC21003F 02003949
	v_fma_mixlo_f16 v73, v77, s28, 0                           // 00000019D0A8: CC210049 0200394D
	s_waitcnt lgkmcnt(6)                                       // 00000019D0B0: BF89FC67
	v_fma_mixlo_f16 v57, v205, s28, 0                          // 00000019D0B4: CC210039 020039CD
	v_fma_mixhi_f16 v57, v206, s28, 0                          // 00000019D0BC: CC220039 020039CE
	v_fma_mixlo_f16 v58, v207, s28, 0                          // 00000019D0C4: CC21003A 020039CF
	v_fma_mixhi_f16 v58, v208, s28, 0                          // 00000019D0CC: CC22003A 020039D0
	s_waitcnt lgkmcnt(5)                                       // 00000019D0D4: BF89FC57
	v_fma_mixlo_f16 v59, v209, s28, 0                          // 00000019D0D8: CC21003B 020039D1
	v_fma_mixhi_f16 v59, v210, s28, 0                          // 00000019D0E0: CC22003B 020039D2
	v_fma_mixlo_f16 v60, v211, s28, 0                          // 00000019D0E8: CC21003C 020039D3
	v_fma_mixhi_f16 v60, v212, s28, 0                          // 00000019D0F0: CC22003C 020039D4
	s_waitcnt lgkmcnt(3)                                       // 00000019D0F8: BF89FC37
	v_fma_mixlo_f16 v79, v189, s28, 0                          // 00000019D0FC: CC21004F 020039BD
	ds_load_b128 v[205:208], v127 offset:17264                 // 00000019D104: DBFC4370 CD00007F
	v_fma_mixhi_f16 v79, v190, s28, 0                          // 00000019D10C: CC22004F 020039BE
	v_fma_mixlo_f16 v80, v191, s28, 0                          // 00000019D114: CC210050 020039BF
	v_fma_mixhi_f16 v80, v192, s28, 0                          // 00000019D11C: CC220050 020039C0
	ds_load_b128 v[189:192], v127 offset:25664                 // 00000019D124: DBFC6440 BD00007F
	ds_load_b128 v[209:212], v127 offset:25680                 // 00000019D12C: DBFC6450 D100007F
	s_waitcnt lgkmcnt(5)                                       // 00000019D134: BF89FC57
	v_fma_mixlo_f16 v81, v193, s28, 0                          // 00000019D138: CC210051 020039C1
	v_fma_mixhi_f16 v81, v194, s28, 0                          // 00000019D140: CC220051 020039C2
	v_fma_mixlo_f16 v82, v195, s28, 0                          // 00000019D148: CC210052 020039C3
	v_fma_mixhi_f16 v82, v196, s28, 0                          // 00000019D150: CC220052 020039C4
	s_waitcnt lgkmcnt(4)                                       // 00000019D158: BF89FC47
	v_fma_mixlo_f16 v83, v197, s28, 0                          // 00000019D15C: CC210053 020039C5
	v_fma_mixhi_f16 v83, v198, s28, 0                          // 00000019D164: CC220053 020039C6
	v_fma_mixlo_f16 v84, v199, s28, 0                          // 00000019D16C: CC210054 020039C7
	ds_load_b128 v[193:196], v127 offset:25696                 // 00000019D174: DBFC6460 C100007F
	v_fma_mixhi_f16 v84, v200, s28, 0                          // 00000019D17C: CC220054 020039C8
	ds_load_b128 v[197:200], v127 offset:25712                 // 00000019D184: DBFC6470 C500007F
	v_fma_mixlo_f16 v61, v213, s28, 0                          // 00000019D18C: CC21003D 020039D5
	v_fma_mixhi_f16 v61, v214, s28, 0                          // 00000019D194: CC22003D 020039D6
	v_fma_mixlo_f16 v62, v215, s28, 0                          // 00000019D19C: CC21003E 020039D7
	v_fma_mixhi_f16 v62, v216, s28, 0                          // 00000019D1A4: CC22003E 020039D8
	v_fma_mixhi_f16 v73, v78, s28, 0                           // 00000019D1AC: CC220049 0200394E
	v_fma_mixlo_f16 v77, v85, s28, 0                           // 00000019D1B4: CC21004D 02003955
	v_fma_mixhi_f16 v77, v86, s28, 0                           // 00000019D1BC: CC22004D 02003956
	v_fma_mixlo_f16 v78, v87, s28, 0                           // 00000019D1C4: CC21004E 02003957
	v_fma_mixhi_f16 v78, v88, s28, 0                           // 00000019D1CC: CC22004E 02003958
	s_waitcnt lgkmcnt(5)                                       // 00000019D1D4: BF89FC57
	v_fma_mixlo_f16 v85, v201, s28, 0                          // 00000019D1D8: CC210055 020039C9
	v_fma_mixhi_f16 v85, v202, s28, 0                          // 00000019D1E0: CC220055 020039CA
	v_fma_mixlo_f16 v86, v203, s28, 0                          // 00000019D1E8: CC210056 020039CB
	v_fma_mixhi_f16 v86, v204, s28, 0                          // 00000019D1F0: CC220056 020039CC
	s_waitcnt lgkmcnt(4)                                       // 00000019D1F8: BF89FC47
	v_fma_mixlo_f16 v87, v205, s28, 0                          // 00000019D1FC: CC210057 020039CD
	v_fma_mixhi_f16 v87, v206, s28, 0                          // 00000019D204: CC220057 020039CE
	v_fma_mixlo_f16 v88, v207, s28, 0                          // 00000019D20C: CC210058 020039CF
	v_fma_mixhi_f16 v88, v208, s28, 0                          // 00000019D214: CC220058 020039D0
	s_waitcnt lgkmcnt(3)                                       // 00000019D21C: BF89FC37
	v_fma_mixlo_f16 v189, v189, s28, 0                         // 00000019D220: CC2100BD 020039BD
	v_fma_mixhi_f16 v189, v190, s28, 0                         // 00000019D228: CC2200BD 020039BE
	v_fma_mixlo_f16 v190, v191, s28, 0                         // 00000019D230: CC2100BE 020039BF
	v_fma_mixhi_f16 v190, v192, s28, 0                         // 00000019D238: CC2200BE 020039C0
	s_waitcnt lgkmcnt(2)                                       // 00000019D240: BF89FC27
	v_fma_mixlo_f16 v191, v209, s28, 0                         // 00000019D244: CC2100BF 020039D1
	v_fma_mixhi_f16 v191, v210, s28, 0                         // 00000019D24C: CC2200BF 020039D2
	v_fma_mixlo_f16 v192, v211, s28, 0                         // 00000019D254: CC2100C0 020039D3
	v_fma_mixhi_f16 v192, v212, s28, 0                         // 00000019D25C: CC2200C0 020039D4
	s_waitcnt lgkmcnt(1)                                       // 00000019D264: BF89FC17
	v_fma_mixlo_f16 v193, v193, s28, 0                         // 00000019D268: CC2100C1 020039C1
	v_fma_mixhi_f16 v193, v194, s28, 0                         // 00000019D270: CC2200C1 020039C2
	v_fma_mixlo_f16 v194, v195, s28, 0                         // 00000019D278: CC2100C2 020039C3
	v_fma_mixhi_f16 v194, v196, s28, 0                         // 00000019D280: CC2200C2 020039C4
	s_waitcnt lgkmcnt(0)                                       // 00000019D288: BF89FC07
	v_fma_mixlo_f16 v195, v197, s28, 0                         // 00000019D28C: CC2100C3 020039C5
	v_fma_mixhi_f16 v195, v198, s28, 0                         // 00000019D294: CC2200C3 020039C6
	v_fma_mixlo_f16 v196, v199, s28, 0                         // 00000019D29C: CC2100C4 020039C7
	v_fma_mixhi_f16 v196, v200, s28, 0                         // 00000019D2A4: CC2200C4 020039C8
	ds_load_b128 v[201:204], v127 offset:384                   // 00000019D2AC: DBFC0180 C900007F
	ds_load_b128 v[205:208], v127 offset:400                   // 00000019D2B4: DBFC0190 CD00007F
	ds_load_b128 v[209:212], v127 offset:416                   // 00000019D2BC: DBFC01A0 D100007F
	s_waitcnt vmcnt(10)                                        // 00000019D2C4: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[57:64], v[25:32]// 00000019D2C8: CC404019 1C667331
	ds_load_b128 v[57:60], v127 offset:432                     // 00000019D2D0: DBFC01B0 3900007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[73:80], v[9:16]// 00000019D2D8: CC404009 1C269331
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[81:88], v[17:24]// 00000019D2E0: CC404011 1C46A331
	v_wmma_f32_16x16x16_f16 v[1:8], v[49:56], v[189:196], v[1:8]// 00000019D2E8: CC404001 1C077B31
	ds_load_b128 v[61:64], v127 offset:8832                    // 00000019D2F0: DBFC2280 3D00007F
	ds_load_b128 v[73:76], v127 offset:8848                    // 00000019D2F8: DBFC2290 4900007F
	ds_load_b128 v[77:80], v127 offset:8864                    // 00000019D300: DBFC22A0 4D00007F
	ds_load_b128 v[81:84], v127 offset:8880                    // 00000019D308: DBFC22B0 5100007F
	ds_load_b128 v[85:88], v127 offset:17280                   // 00000019D310: DBFC4380 5500007F
	ds_load_b128 v[189:192], v127 offset:17296                 // 00000019D318: DBFC4390 BD00007F
	ds_load_b128 v[193:196], v127 offset:17312                 // 00000019D320: DBFC43A0 C100007F
	ds_load_b128 v[197:200], v127 offset:17328                 // 00000019D328: DBFC43B0 C500007F
	ds_load_b128 v[216:219], v127 offset:25840                 // 00000019D330: DBFC64F0 D800007F
	s_waitcnt lgkmcnt(12)                                      // 00000019D338: BF89FCC7
	v_fma_mixlo_f16 v49, v201, s28, 0                          // 00000019D33C: CC210031 020039C9
	v_fma_mixhi_f16 v49, v202, s28, 0                          // 00000019D344: CC220031 020039CA
	v_fma_mixlo_f16 v50, v203, s28, 0                          // 00000019D34C: CC210032 020039CB
	v_fma_mixhi_f16 v50, v204, s28, 0                          // 00000019D354: CC220032 020039CC
	s_waitcnt lgkmcnt(9)                                       // 00000019D35C: BF89FC97
	v_fma_mixhi_f16 v55, v58, s28, 0                           // 00000019D360: CC220037 0200393A
	v_fma_mixlo_f16 v56, v59, s28, 0                           // 00000019D368: CC210038 0200393B
	v_fma_mixhi_f16 v56, v60, s28, 0                           // 00000019D370: CC220038 0200393C
	ds_load_b128 v[201:204], v127 offset:25744                 // 00000019D378: DBFC6490 C900007F
	s_waitcnt lgkmcnt(9)                                       // 00000019D380: BF89FC97
	v_fma_mixlo_f16 v58, v63, s28, 0                           // 00000019D384: CC21003A 0200393F
	v_fma_mixhi_f16 v58, v64, s28, 0                           // 00000019D38C: CC22003A 02003940
	s_waitcnt lgkmcnt(8)                                       // 00000019D394: BF89FC87
	v_fma_mixlo_f16 v59, v73, s28, 0                           // 00000019D398: CC21003B 02003949
	v_fma_mixhi_f16 v59, v74, s28, 0                           // 00000019D3A0: CC22003B 0200394A
	v_fma_mixlo_f16 v60, v75, s28, 0                           // 00000019D3A8: CC21003C 0200394B
	v_fma_mixhi_f16 v60, v76, s28, 0                           // 00000019D3B0: CC22003C 0200394C
	s_waitcnt lgkmcnt(6)                                       // 00000019D3B8: BF89FC67
	v_fma_mixlo_f16 v63, v81, s28, 0                           // 00000019D3BC: CC21003F 02003951
	v_fma_mixhi_f16 v63, v82, s28, 0                           // 00000019D3C4: CC22003F 02003952
	v_fma_mixlo_f16 v64, v83, s28, 0                           // 00000019D3CC: CC210040 02003953
	v_fma_mixhi_f16 v64, v84, s28, 0                           // 00000019D3D4: CC220040 02003954
	ds_load_b128 v[81:84], v127 offset:25728                   // 00000019D3DC: DBFC6480 5100007F
	s_waitcnt lgkmcnt(6)                                       // 00000019D3E4: BF89FC67
	v_fma_mixlo_f16 v73, v85, s28, 0                           // 00000019D3E8: CC210049 02003955
	v_fma_mixhi_f16 v73, v86, s28, 0                           // 00000019D3F0: CC220049 02003956
	v_fma_mixlo_f16 v74, v87, s28, 0                           // 00000019D3F8: CC21004A 02003957
	v_fma_mixhi_f16 v74, v88, s28, 0                           // 00000019D400: CC22004A 02003958
	s_waitcnt lgkmcnt(5)                                       // 00000019D408: BF89FC57
	v_fma_mixlo_f16 v75, v189, s28, 0                          // 00000019D40C: CC21004B 020039BD
	v_fma_mixhi_f16 v75, v190, s28, 0                          // 00000019D414: CC22004B 020039BE
	v_fma_mixlo_f16 v76, v191, s28, 0                          // 00000019D41C: CC21004C 020039BF
	ds_load_b128 v[85:88], v127 offset:25760                   // 00000019D424: DBFC64A0 5500007F
	v_fma_mixhi_f16 v76, v192, s28, 0                          // 00000019D42C: CC22004C 020039C0
	ds_load_b128 v[189:192], v127 offset:25776                 // 00000019D434: DBFC64B0 BD00007F
	v_fma_mixlo_f16 v55, v57, s28, 0                           // 00000019D43C: CC210037 02003939
	v_fma_mixlo_f16 v57, v61, s28, 0                           // 00000019D444: CC210039 0200393D
	v_fma_mixlo_f16 v61, v77, s28, 0                           // 00000019D44C: CC21003D 0200394D
	v_fma_mixhi_f16 v61, v78, s28, 0                           // 00000019D454: CC22003D 0200394E
	s_waitcnt lgkmcnt(6)                                       // 00000019D45C: BF89FC67
	v_fma_mixlo_f16 v77, v193, s28, 0                          // 00000019D460: CC21004D 020039C1
	v_fma_mixhi_f16 v77, v194, s28, 0                          // 00000019D468: CC22004D 020039C2
	v_fma_mixlo_f16 v78, v195, s28, 0                          // 00000019D470: CC21004E 020039C3
	v_fma_mixhi_f16 v78, v196, s28, 0                          // 00000019D478: CC22004E 020039C4
	ds_load_b128 v[193:196], v127 offset:448                   // 00000019D480: DBFC01C0 C100007F
	s_waitcnt lgkmcnt(3)                                       // 00000019D488: BF89FC37
	v_fma_mixlo_f16 v81, v81, s28, 0                           // 00000019D48C: CC210051 02003951
	v_fma_mixhi_f16 v81, v82, s28, 0                           // 00000019D494: CC220051 02003952
	v_fma_mixlo_f16 v82, v83, s28, 0                           // 00000019D49C: CC210052 02003953
	v_fma_mixhi_f16 v82, v84, s28, 0                           // 00000019D4A4: CC220052 02003954
	v_fma_mixlo_f16 v83, v201, s28, 0                          // 00000019D4AC: CC210053 020039C9
	v_fma_mixhi_f16 v83, v202, s28, 0                          // 00000019D4B4: CC220053 020039CA
	v_fma_mixlo_f16 v84, v203, s28, 0                          // 00000019D4BC: CC210054 020039CB
	v_fma_mixhi_f16 v84, v204, s28, 0                          // 00000019D4C4: CC220054 020039CC
	s_waitcnt lgkmcnt(2)                                       // 00000019D4CC: BF89FC27
	v_fma_mixlo_f16 v85, v85, s28, 0                           // 00000019D4D0: CC210055 02003955
	v_fma_mixhi_f16 v85, v86, s28, 0                           // 00000019D4D8: CC220055 02003956
	v_fma_mixlo_f16 v86, v87, s28, 0                           // 00000019D4E0: CC210056 02003957
	v_fma_mixhi_f16 v86, v88, s28, 0                           // 00000019D4E8: CC220056 02003958
	s_waitcnt lgkmcnt(1)                                       // 00000019D4F0: BF89FC17
	v_fma_mixlo_f16 v87, v189, s28, 0                          // 00000019D4F4: CC210057 020039BD
	ds_load_b128 v[201:204], v127 offset:480                   // 00000019D4FC: DBFC01E0 C900007F
	v_fma_mixhi_f16 v87, v190, s28, 0                          // 00000019D504: CC220057 020039BE
	v_fma_mixlo_f16 v88, v191, s28, 0                          // 00000019D50C: CC210058 020039BF
	v_fma_mixhi_f16 v88, v192, s28, 0                          // 00000019D514: CC220058 020039C0
	ds_load_b128 v[189:192], v127 offset:496                   // 00000019D51C: DBFC01F0 BD00007F
	v_fma_mixlo_f16 v51, v205, s28, 0                          // 00000019D524: CC210033 020039CD
	v_fma_mixhi_f16 v51, v206, s28, 0                          // 00000019D52C: CC220033 020039CE
	v_fma_mixlo_f16 v52, v207, s28, 0                          // 00000019D534: CC210034 020039CF
	v_fma_mixhi_f16 v52, v208, s28, 0                          // 00000019D53C: CC220034 020039D0
	v_fma_mixlo_f16 v53, v209, s28, 0                          // 00000019D544: CC210035 020039D1
	v_fma_mixhi_f16 v53, v210, s28, 0                          // 00000019D54C: CC220035 020039D2
	v_fma_mixlo_f16 v54, v211, s28, 0                          // 00000019D554: CC210036 020039D3
	v_fma_mixhi_f16 v54, v212, s28, 0                          // 00000019D55C: CC220036 020039D4
	v_fma_mixhi_f16 v57, v62, s28, 0                           // 00000019D564: CC220039 0200393E
	v_fma_mixlo_f16 v62, v79, s28, 0                           // 00000019D56C: CC21003E 0200394F
	v_fma_mixhi_f16 v62, v80, s28, 0                           // 00000019D574: CC22003E 02003950
	v_fma_mixlo_f16 v79, v197, s28, 0                          // 00000019D57C: CC21004F 020039C5
	v_fma_mixhi_f16 v79, v198, s28, 0                          // 00000019D584: CC22004F 020039C6
	v_fma_mixlo_f16 v80, v199, s28, 0                          // 00000019D58C: CC210050 020039C7
	v_fma_mixhi_f16 v80, v200, s28, 0                          // 00000019D594: CC220050 020039C8
	ds_load_b128 v[197:200], v127 offset:464                   // 00000019D59C: DBFC01D0 C500007F
	s_waitcnt vmcnt(8)                                         // 00000019D5A4: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[49:56], v[25:32]// 00000019D5A8: CC404019 1C666329
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[57:64], v[9:16]// 00000019D5B0: CC404009 1C267329
	v_wmma_f32_16x16x16_f16 v[1:8], v[41:48], v[81:88], v[1:8] // 00000019D5B8: CC404001 1C06A329
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[73:80], v[17:24]// 00000019D5C0: CC404011 1C469329
	ds_load_b128 v[49:52], v127 offset:8896                    // 00000019D5C8: DBFC22C0 3100007F
	ds_load_b128 v[53:56], v127 offset:8912                    // 00000019D5D0: DBFC22D0 3500007F
	s_waitcnt lgkmcnt(5)                                       // 00000019D5D8: BF89FC57
	v_fma_mixlo_f16 v41, v193, s28, 0                          // 00000019D5DC: CC210029 020039C1
	v_fma_mixhi_f16 v41, v194, s28, 0                          // 00000019D5E4: CC220029 020039C2
	v_fma_mixlo_f16 v42, v195, s28, 0                          // 00000019D5EC: CC21002A 020039C3
	v_fma_mixhi_f16 v42, v196, s28, 0                          // 00000019D5F4: CC22002A 020039C4
	ds_load_b128 v[57:60], v127 offset:8928                    // 00000019D5FC: DBFC22E0 3900007F
	ds_load_b128 v[61:64], v127 offset:8944                    // 00000019D604: DBFC22F0 3D00007F
	s_waitcnt lgkmcnt(5)                                       // 00000019D60C: BF89FC57
	v_fma_mixlo_f16 v47, v189, s28, 0                          // 00000019D610: CC21002F 020039BD
	v_fma_mixhi_f16 v47, v190, s28, 0                          // 00000019D618: CC22002F 020039BE
	v_fma_mixlo_f16 v48, v191, s28, 0                          // 00000019D620: CC210030 020039BF
	v_fma_mixhi_f16 v48, v192, s28, 0                          // 00000019D628: CC220030 020039C0
	ds_load_b128 v[73:76], v127 offset:17344                   // 00000019D630: DBFC43C0 4900007F
	ds_load_b128 v[77:80], v127 offset:17360                   // 00000019D638: DBFC43D0 4D00007F
	ds_load_b128 v[81:84], v127 offset:17376                   // 00000019D640: DBFC43E0 5100007F
	ds_load_b128 v[85:88], v127 offset:17392                   // 00000019D648: DBFC43F0 5500007F
	ds_load_b128 v[189:192], v127 offset:25792                 // 00000019D650: DBFC64C0 BD00007F
	ds_load_b128 v[193:196], v127 offset:25808                 // 00000019D658: DBFC64D0 C100007F
	ds_load_b128 v[212:215], v127 offset:25824                 // 00000019D660: DBFC64E0 D400007F
	s_waitcnt lgkmcnt(11)                                      // 00000019D668: BF89FCB7
	v_fma_mixlo_f16 v43, v197, s28, 0                          // 00000019D66C: CC21002B 020039C5
	v_fma_mixhi_f16 v43, v198, s28, 0                          // 00000019D674: CC22002B 020039C6
	v_fma_mixlo_f16 v44, v199, s28, 0                          // 00000019D67C: CC21002C 020039C7
	v_fma_mixhi_f16 v44, v200, s28, 0                          // 00000019D684: CC22002C 020039C8
	v_fma_mixlo_f16 v45, v201, s28, 0                          // 00000019D68C: CC21002D 020039C9
	v_fma_mixhi_f16 v45, v202, s28, 0                          // 00000019D694: CC22002D 020039CA
	v_fma_mixlo_f16 v46, v203, s28, 0                          // 00000019D69C: CC21002E 020039CB
	v_fma_mixhi_f16 v46, v204, s28, 0                          // 00000019D6A4: CC22002E 020039CC
	s_waitcnt lgkmcnt(10)                                      // 00000019D6AC: BF89FCA7
	v_fma_mixlo_f16 v49, v49, s28, 0                           // 00000019D6B0: CC210031 02003931
	v_fma_mixhi_f16 v49, v50, s28, 0                           // 00000019D6B8: CC220031 02003932
	v_fma_mixlo_f16 v50, v51, s28, 0                           // 00000019D6C0: CC210032 02003933
	v_fma_mixhi_f16 v50, v52, s28, 0                           // 00000019D6C8: CC220032 02003934
	s_waitcnt lgkmcnt(9)                                       // 00000019D6D0: BF89FC97
	v_fma_mixlo_f16 v51, v53, s28, 0                           // 00000019D6D4: CC210033 02003935
	v_fma_mixhi_f16 v51, v54, s28, 0                           // 00000019D6DC: CC220033 02003936
	v_fma_mixlo_f16 v52, v55, s28, 0                           // 00000019D6E4: CC210034 02003937
	v_fma_mixhi_f16 v52, v56, s28, 0                           // 00000019D6EC: CC220034 02003938
	s_waitcnt lgkmcnt(8)                                       // 00000019D6F4: BF89FC87
	v_fma_mixlo_f16 v53, v57, s28, 0                           // 00000019D6F8: CC210035 02003939
	v_fma_mixhi_f16 v53, v58, s28, 0                           // 00000019D700: CC220035 0200393A
	v_fma_mixlo_f16 v54, v59, s28, 0                           // 00000019D708: CC210036 0200393B
	s_waitcnt lgkmcnt(7)                                       // 00000019D710: BF89FC77
	v_fma_mixlo_f16 v55, v61, s28, 0                           // 00000019D714: CC210037 0200393D
	v_fma_mixhi_f16 v55, v62, s28, 0                           // 00000019D71C: CC220037 0200393E
	v_fma_mixlo_f16 v56, v63, s28, 0                           // 00000019D724: CC210038 0200393F
	v_fma_mixhi_f16 v56, v64, s28, 0                           // 00000019D72C: CC220038 02003940
	s_waitcnt lgkmcnt(6)                                       // 00000019D734: BF89FC67
	v_fma_mixlo_f16 v57, v73, s28, 0                           // 00000019D738: CC210039 02003949
	v_fma_mixhi_f16 v57, v74, s28, 0                           // 00000019D740: CC220039 0200394A
	v_fma_mixlo_f16 v58, v75, s28, 0                           // 00000019D748: CC21003A 0200394B
	v_fma_mixhi_f16 v58, v76, s28, 0                           // 00000019D750: CC22003A 0200394C
	s_waitcnt lgkmcnt(5)                                       // 00000019D758: BF89FC57
	v_fma_mixlo_f16 v59, v77, s28, 0                           // 00000019D75C: CC21003B 0200394D
	s_waitcnt lgkmcnt(4)                                       // 00000019D764: BF89FC47
	v_fma_mixlo_f16 v61, v81, s28, 0                           // 00000019D768: CC21003D 02003951
	v_fma_mixhi_f16 v61, v82, s28, 0                           // 00000019D770: CC22003D 02003952
	v_fma_mixlo_f16 v62, v83, s28, 0                           // 00000019D778: CC21003E 02003953
	v_fma_mixhi_f16 v62, v84, s28, 0                           // 00000019D780: CC22003E 02003954
	s_waitcnt lgkmcnt(3)                                       // 00000019D788: BF89FC37
	v_fma_mixlo_f16 v63, v85, s28, 0                           // 00000019D78C: CC21003F 02003955
	v_fma_mixhi_f16 v63, v86, s28, 0                           // 00000019D794: CC22003F 02003956
	v_fma_mixlo_f16 v64, v87, s28, 0                           // 00000019D79C: CC210040 02003957
	v_fma_mixhi_f16 v64, v88, s28, 0                           // 00000019D7A4: CC220040 02003958
	s_waitcnt lgkmcnt(2)                                       // 00000019D7AC: BF89FC27
	v_fma_mixlo_f16 v73, v189, s28, 0                          // 00000019D7B0: CC210049 020039BD
	v_fma_mixhi_f16 v73, v190, s28, 0                          // 00000019D7B8: CC220049 020039BE
	v_fma_mixlo_f16 v74, v191, s28, 0                          // 00000019D7C0: CC21004A 020039BF
	v_fma_mixhi_f16 v74, v192, s28, 0                          // 00000019D7C8: CC22004A 020039C0
	s_waitcnt lgkmcnt(1)                                       // 00000019D7D0: BF89FC17
	v_fma_mixlo_f16 v75, v193, s28, 0                          // 00000019D7D4: CC21004B 020039C1
	v_fma_mixhi_f16 v75, v194, s28, 0                          // 00000019D7DC: CC22004B 020039C2
	v_fma_mixlo_f16 v76, v195, s28, 0                          // 00000019D7E4: CC21004C 020039C3
	v_fma_mixhi_f16 v76, v196, s28, 0                          // 00000019D7EC: CC22004C 020039C4
	s_waitcnt lgkmcnt(0)                                       // 00000019D7F4: BF89FC07
	v_fma_mixlo_f16 v77, v212, s28, 0                          // 00000019D7F8: CC21004D 020039D4
	ds_load_b128 v[81:84], v130                                // 00000019D800: DBFC0000 51000082
	ds_load_b128 v[85:88], v130 offset:16                      // 00000019D808: DBFC0010 55000082
	ds_load_b128 v[193:196], v130 offset:2320                  // 00000019D810: DBFC0910 C1000082
	ds_load_b128 v[189:192], v130 offset:2304                  // 00000019D818: DBFC0900 BD000082
	ds_load_b128 v[201:204], v130 offset:4624                  // 00000019D820: DBFC1210 C9000082
	ds_load_b128 v[197:200], v130 offset:4608                  // 00000019D828: DBFC1200 C5000082
	ds_load_b128 v[209:212], v130 offset:6928                  // 00000019D830: DBFC1B10 D1000082
	ds_load_b128 v[205:208], v130 offset:6912                  // 00000019D838: DBFC1B00 CD000082
	v_fma_mixhi_f16 v54, v60, s28, 0                           // 00000019D840: CC220036 0200393C
	v_fma_mixhi_f16 v59, v78, s28, 0                           // 00000019D848: CC22003B 0200394E
	v_fma_mixlo_f16 v60, v79, s28, 0                           // 00000019D850: CC21003C 0200394F
	v_fma_mixhi_f16 v60, v80, s28, 0                           // 00000019D858: CC22003C 02003950
	v_fma_mixhi_f16 v77, v213, s28, 0                          // 00000019D860: CC22004D 020039D5
	v_fma_mixlo_f16 v78, v214, s28, 0                          // 00000019D868: CC21004E 020039D6
	v_fma_mixhi_f16 v78, v215, s28, 0                          // 00000019D870: CC22004E 020039D7
	v_fma_mixlo_f16 v79, v216, s28, 0                          // 00000019D878: CC21004F 020039D8
	v_fma_mixhi_f16 v79, v217, s28, 0                          // 00000019D880: CC22004F 020039D9
	v_fma_mixlo_f16 v80, v218, s28, 0                          // 00000019D888: CC210050 020039DA
	v_fma_mixhi_f16 v80, v219, s28, 0                          // 00000019D890: CC220050 020039DB
	s_waitcnt vmcnt(6)                                         // 00000019D898: BF891BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[41:48], v[25:32]// 00000019D89C: CC404019 1C665321
	v_wmma_f32_16x16x16_f16 v[9:16], v[33:40], v[49:56], v[9:16]// 00000019D8A4: CC404009 1C266321
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 00000019D8AC: CC404011 1C467321
	s_waitcnt vmcnt(4) lgkmcnt(6)                              // 00000019D8B4: BF891067
	v_wmma_f32_16x16x16_f16 v[57:64], v[181:188], v[81:88], v[65:72]// 00000019D8B8: CC404039 1D06A3B5
	v_wmma_f32_16x16x16_f16 v[1:8], v[33:40], v[73:80], v[1:8] // 00000019D8C0: CC404001 1C069321
	s_waitcnt lgkmcnt(4)                                       // 00000019D8C8: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[181:188], v[189:196], v[65:72]// 00000019D8CC: CC404031 1D077BB5
	s_waitcnt lgkmcnt(2)                                       // 00000019D8D4: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[181:188], v[197:204], v[65:72]// 00000019D8D8: CC404029 1D078BB5
	s_waitcnt lgkmcnt(0)                                       // 00000019D8E0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[181:188], v[205:212], v[65:72]// 00000019D8E4: CC404021 1D079BB5
	s_and_saveexec_b32 s15, s7                                 // 00000019D8EC: BE8F2007
	s_cbranch_execnz 1198                                      // 00000019D8F0: BFA604AE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x72ac>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019D8F4: 8C7E0F7E
	s_and_saveexec_b32 s15, s5                                 // 00000019D8F8: BE8F2005
	s_cbranch_execnz 1231                                      // 00000019D8FC: BFA604CF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x733c>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019D900: 8C7E0F7E
	s_and_saveexec_b32 s15, s8                                 // 00000019D904: BE8F2008
	s_cbranch_execz 30                                         // 00000019D908: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6084>
	ds_load_b128 v[65:68], v130 offset:96                      // 00000019D90C: DBFC0060 41000082
	ds_load_b128 v[69:72], v130 offset:112                     // 00000019D914: DBFC0070 45000082
	ds_load_b128 v[77:80], v130 offset:2416                    // 00000019D91C: DBFC0970 4D000082
	ds_load_b128 v[73:76], v130 offset:2400                    // 00000019D924: DBFC0960 49000082
	ds_load_b128 v[85:88], v130 offset:4720                    // 00000019D92C: DBFC1270 55000082
	ds_load_b128 v[81:84], v130 offset:4704                    // 00000019D934: DBFC1260 51000082
	s_waitcnt vmcnt(3)                                         // 00000019D93C: BF890FF7
	ds_load_b128 v[101:104], v130 offset:7024                  // 00000019D940: DBFC1B70 65000082
	s_waitcnt vmcnt(2)                                         // 00000019D948: BF890BF7
	ds_load_b128 v[97:100], v130 offset:7008                   // 00000019D94C: DBFC1B60 61000082
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 00000019D954: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[89:96], v[65:72], v[57:64]// 00000019D958: CC404039 1CE68359
	s_waitcnt lgkmcnt(4)                                       // 00000019D960: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[89:96], v[73:80], v[49:56]// 00000019D964: CC404031 1CC69359
	s_waitcnt lgkmcnt(2)                                       // 00000019D96C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[81:88], v[41:48]// 00000019D970: CC404029 1CA6A359
	s_waitcnt lgkmcnt(0)                                       // 00000019D978: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[89:96], v[97:104], v[33:40]// 00000019D97C: CC404021 1C86C359
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019D984: 8C7E0F7E
	s_add_i32 s48, s48, 64                                     // 00000019D988: 8130C030
	s_mov_b32 s15, -1                                          // 00000019D98C: BE8F00C1
	s_cmp_le_i32 s48, s59                                      // 00000019D990: BF053B30
	s_cbranch_scc0 392                                         // 00000019D994: BFA10188 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66b8>
	ds_load_2addr_b32 v[65:66], v139 offset1:2                 // 00000019D998: D8DC0200 4100008B
	ds_load_2addr_b32 v[67:68], v139 offset0:4 offset1:6       // 00000019D9A0: D8DC0604 4300008B
	ds_load_2addr_b32 v[69:70], v139 offset0:8 offset1:10      // 00000019D9A8: D8DC0A08 4500008B
	ds_load_2addr_b32 v[71:72], v139 offset0:12 offset1:14     // 00000019D9B0: D8DC0E0C 4700008B
	v_mad_u64_u32 v[73:74], null, 0x3000, v173, v[108:109]     // 00000019D9B8: D6FE7C49 05B35AFF 00003000
	v_mad_u64_u32 v[75:76], null, 0x3000, v180, v[108:109]     // 00000019D9C4: D6FE7C4B 05B368FF 00003000
	v_mad_u64_u32 v[77:78], null, 0x3000, v179, v[108:109]     // 00000019D9D0: D6FE7C4D 05B366FF 00003000
	v_mad_u64_u32 v[79:80], null, 0x3000, v178, v[108:109]     // 00000019D9DC: D6FE7C4F 05B364FF 00003000
	s_mov_b32 s15, 0                                           // 00000019D9E8: BE8F0080
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 00000019D9EC: BF890437
	v_fma_f32 v96, v9, v65, v49                                // 00000019D9F0: D6130060 04C68309
	v_fma_f32 v97, v10, v66, v50                               // 00000019D9F8: D6130061 04CA850A
	s_waitcnt lgkmcnt(2)                                       // 00000019DA00: BF89FC27
	v_fma_f32 v98, v11, v67, v51                               // 00000019DA04: D6130062 04CE870B
	v_fma_f32 v100, v12, v68, v52                              // 00000019DA0C: D6130064 04D2890C
	s_waitcnt lgkmcnt(1)                                       // 00000019DA14: BF89FC17
	v_fma_f32 v104, v13, v69, v53                              // 00000019DA18: D6130068 04D68B0D
	v_dual_mul_f32 v96, 0x3b800000, v96 :: v_dual_mul_f32 v97, 0x3b800000, v97// 00000019DA20: C8C6C0FF 6060C2FF 3B800000
	v_mul_f32_e32 v98, 0x3b800000, v98                         // 00000019DA2C: 10C4C4FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 00000019DA34: BF89FC07
	v_fma_f32 v105, v16, v72, v56                              // 00000019DA38: D6130069 04E29110
	v_mul_f32_e32 v100, 0x3b800000, v100                       // 00000019DA40: 10C8C8FF 3B800000
	v_bfe_u32 v101, v96, 16, 1                                 // 00000019DA48: D6100065 02052160
	v_bfe_u32 v102, v97, 16, 1                                 // 00000019DA50: D6100066 02052161
	v_bfe_u32 v103, v98, 16, 1                                 // 00000019DA58: D6100067 02052162
	v_mul_f32_e32 v105, 0x3b800000, v105                       // 00000019DA60: 10D2D2FF 3B800000
	v_fma_f32 v182, v18, v66, v42                              // 00000019DA68: D61300B6 04AA8512
	v_add3_u32 v96, v96, v101, 0x7fff                          // 00000019DA70: D6550060 03FECB60 00007FFF
	v_add3_u32 v97, v97, v102, 0x7fff                          // 00000019DA7C: D6550061 03FECD61 00007FFF
	v_add3_u32 v98, v98, v103, 0x7fff                          // 00000019DA88: D6550062 03FECF62 00007FFF
	v_bfe_u32 v101, v100, 16, 1                                // 00000019DA94: D6100065 02052164
	v_mul_f32_e32 v102, 0x3b800000, v104                       // 00000019DA9C: 10CCD0FF 3B800000
	v_fma_f32 v103, v14, v70, v54                              // 00000019DAA4: D6130067 04DA8D0E
	v_fma_f32 v104, v15, v71, v55                              // 00000019DAAC: D6130068 04DE8F0F
	v_fma_f32 v116, v17, v65, v41                              // 00000019DAB4: D6130074 04A68311
	v_add3_u32 v100, v100, v101, 0x7fff                        // 00000019DABC: D6550064 03FECB64 00007FFF
	v_bfe_u32 v101, v102, 16, 1                                // 00000019DAC8: D6100065 02052166
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000019DAD0: BF870234
	v_dual_mul_f32 v103, 0x3b800000, v103 :: v_dual_mul_f32 v104, 0x3b800000, v104// 00000019DAD4: C8C6CEFF 6768D0FF 3B800000
	v_bfe_u32 v181, v105, 16, 1                                // 00000019DAE0: D61000B5 02052169
	v_fma_f32 v183, v21, v69, v45                              // 00000019DAE8: D61300B7 04B68B15
	v_add3_u32 v101, v102, v101, 0x7fff                        // 00000019DAF0: D6550065 03FECB66 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019DAFC: BF870224
	v_bfe_u32 v102, v103, 16, 1                                // 00000019DB00: D6100066 02052167
	v_bfe_u32 v117, v104, 16, 1                                // 00000019DB08: D6100075 02052168
	v_dual_mul_f32 v116, 0x3b800000, v116 :: v_dual_mul_f32 v183, 0x3b800000, v183// 00000019DB10: C8C6E8FF 74B76EFF 3B800000
	v_fma_f32 v184, v22, v70, v46                              // 00000019DB1C: D61300B8 04BA8D16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019DB24: BF870214
	v_add3_u32 v102, v103, v102, 0x7fff                        // 00000019DB28: D6550066 03FECD67 00007FFF
	v_add3_u32 v103, v104, v117, 0x7fff                        // 00000019DB34: D6550067 03FEEB68 00007FFF
	v_add3_u32 v104, v105, v181, 0x7fff                        // 00000019DB40: D6550068 03FF6B69 00007FFF
	v_bfe_u32 v105, v116, 16, 1                                // 00000019DB4C: D6100069 02052174
	v_mul_f32_e32 v117, 0x3b800000, v182                       // 00000019DB54: 10EB6CFF 3B800000
	v_fma_f32 v181, v19, v67, v43                              // 00000019DB5C: D61300B5 04AE8713
	v_fma_f32 v182, v20, v68, v44                              // 00000019DB64: D61300B6 04B28914
	v_fma_f32 v187, v23, v71, v47                              // 00000019DB6C: D61300BB 04BE8F17
	v_add3_u32 v105, v116, v105, 0x7fff                        // 00000019DB74: D6550069 03FED374 00007FFF
	v_bfe_u32 v116, v117, 16, 1                                // 00000019DB80: D6100074 02052175
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000019DB88: BF870234
	v_dual_mul_f32 v181, 0x3b800000, v181 :: v_dual_mul_f32 v182, 0x3b800000, v182// 00000019DB8C: C8C76AFF B5B76CFF 3B800000
	v_fma_f32 v81, v25, v65, v57                               // 00000019DB98: D6130051 04E68319
	v_bfe_u32 v186, v183, 16, 1                                // 00000019DBA0: D61000BA 020521B7
	v_add3_u32 v116, v117, v116, 0x7fff                        // 00000019DBA8: D6550074 03FEE975 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019DBB4: BF870004
	v_bfe_u32 v117, v181, 16, 1                                // 00000019DBB8: D6100075 020521B5
	v_bfe_u32 v185, v182, 16, 1                                // 00000019DBC0: D61000B9 020521B6
	v_fma_f32 v65, v1, v65, v33                                // 00000019DBC8: D6130041 04868301
	v_mul_f32_e32 v184, 0x3b800000, v184                       // 00000019DBD0: 117170FF 3B800000
	v_fma_f32 v82, v26, v66, v58                               // 00000019DBD8: D6130052 04EA851A
	v_add3_u32 v117, v181, v117, 0x7fff                        // 00000019DBE0: D6550075 03FEEBB5 00007FFF
	v_add3_u32 v181, v182, v185, 0x7fff                        // 00000019DBEC: D65500B5 03FF73B6 00007FFF
	v_add3_u32 v182, v183, v186, 0x7fff                        // 00000019DBF8: D65500B6 03FF75B7 00007FFF
	v_mul_f32_e32 v185, 0x3b800000, v187                       // 00000019DC04: 117376FF 3B800000
	v_fma_f32 v186, v24, v72, v48                              // 00000019DC0C: D61300BA 04C29118
	v_mul_f32_e32 v65, 0x3b800000, v65                         // 00000019DC14: 108282FF 3B800000
	v_bfe_u32 v183, v184, 16, 1                                // 00000019DC1C: D61000B7 020521B8
	v_fma_f32 v66, v2, v66, v34                                // 00000019DC24: D6130042 048A8502
	v_fma_f32 v83, v27, v67, v59                               // 00000019DC2C: D6130053 04EE871B
	v_dual_mul_f32 v81, 0x3b800000, v81 :: v_dual_mul_f32 v82, 0x3b800000, v82// 00000019DC34: C8C6A2FF 5152A4FF 3B800000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019DC40: BF870004
	v_add3_u32 v183, v184, v183, 0x7fff                        // 00000019DC44: D65500B7 03FF6FB8 00007FFF
	v_bfe_u32 v184, v185, 16, 1                                // 00000019DC50: D61000B8 020521B9
	v_fma_f32 v67, v3, v67, v35                                // 00000019DC58: D6130043 048E8703
	v_mul_f32_e32 v186, 0x3b800000, v186                       // 00000019DC60: 117574FF 3B800000
	v_fma_f32 v85, v29, v69, v61                               // 00000019DC68: D6130055 04F68B1D
	v_fma_f32 v69, v5, v69, v37                                // 00000019DC70: D6130045 04968B05
	v_mul_f32_e32 v66, 0x3b800000, v66                         // 00000019DC78: 108484FF 3B800000
	v_fma_f32 v84, v28, v68, v60                               // 00000019DC80: D6130054 04F2891C
	v_fma_f32 v87, v31, v71, v63                               // 00000019DC88: D6130057 04FE8F1F
	s_waitcnt vmcnt(0)                                         // 00000019DC90: BF8903F7
	v_bfe_u32 v89, v81, 16, 1                                  // 00000019DC94: D6100059 02052151
	v_add3_u32 v184, v185, v184, 0x7fff                        // 00000019DC9C: D65500B8 03FF71B9 00007FFF
	v_mul_f32_e32 v67, 0x3b800000, v67                         // 00000019DCA8: 108686FF 3B800000
	v_bfe_u32 v185, v186, 16, 1                                // 00000019DCB0: D61000B9 020521BA
	v_fma_f32 v68, v4, v68, v36                                // 00000019DCB8: D6130044 04928904
	v_fma_f32 v86, v30, v70, v62                               // 00000019DCC0: D6130056 04FA8D1E
	v_bfe_u32 v90, v82, 16, 1                                  // 00000019DCC8: D610005A 02052152
	v_bfe_u32 v187, v65, 16, 1                                 // 00000019DCD0: D61000BB 02052141
	v_bfe_u32 v188, v66, 16, 1                                 // 00000019DCD8: D61000BC 02052142
	v_fma_f32 v88, v32, v72, v64                               // 00000019DCE0: D6130058 05029120
	v_dual_mul_f32 v83, 0x3b800000, v83 :: v_dual_mul_f32 v84, 0x3b800000, v84// 00000019DCE8: C8C6A6FF 5354A8FF 3B800000
	v_mul_f32_e32 v87, 0x3b800000, v87                         // 00000019DCF4: 10AEAEFF 3B800000
	v_add3_u32 v89, v81, v89, 0x7fff                           // 00000019DCFC: D6550059 03FEB351 00007FFF
	v_add3_u32 v185, v186, v185, 0x7fff                        // 00000019DD08: D65500B9 03FF73BA 00007FFF
	v_bfe_u32 v186, v67, 16, 1                                 // 00000019DD14: D61000BA 02052143
	v_fma_f32 v70, v6, v70, v38                                // 00000019DD1C: D6130046 049A8D06
	v_dual_mul_f32 v68, 0x3b800000, v68 :: v_dual_mul_f32 v85, 0x3b800000, v85// 00000019DD24: C8C688FF 4454AAFF 3B800000
	v_mul_f32_e32 v86, 0x3b800000, v86                         // 00000019DD30: 10ACACFF 3B800000
	v_add3_u32 v90, v82, v90, 0x7fff                           // 00000019DD38: D655005A 03FEB552 00007FFF
	v_add3_u32 v65, v65, v187, 0x7fff                          // 00000019DD44: D6550041 03FF7741 00007FFF
	v_add3_u32 v66, v66, v188, 0x7fff                          // 00000019DD50: D6550042 03FF7942 00007FFF
	v_mul_f32_e32 v88, 0x3b800000, v88                         // 00000019DD5C: 10B0B0FF 3B800000
	v_bfe_u32 v91, v83, 16, 1                                  // 00000019DD64: D610005B 02052153
	v_bfe_u32 v95, v87, 16, 1                                  // 00000019DD6C: D610005F 02052157
	s_clause 0x7                                               // 00000019DD74: BF850007
	global_store_d16_hi_b16 v[73:74], v89, off                 // 00000019DD78: DC960000 007C5949
	global_store_d16_hi_b16 v[73:74], v96, off offset:32       // 00000019DD80: DC960020 007C6049
	global_store_d16_hi_b16 v[73:74], v105, off offset:64      // 00000019DD88: DC960040 007C6949
	global_store_d16_hi_b16 v[75:76], v90, off                 // 00000019DD90: DC960000 007C5A4B
	global_store_d16_hi_b16 v[75:76], v97, off offset:32       // 00000019DD98: DC960020 007C614B
	global_store_d16_hi_b16 v[75:76], v116, off offset:64      // 00000019DDA0: DC960040 007C744B
	global_store_d16_hi_b16 v[73:74], v65, off offset:96       // 00000019DDA8: DC960060 007C4149
	global_store_d16_hi_b16 v[75:76], v66, off offset:96       // 00000019DDB0: DC960060 007C424B
	v_add3_u32 v65, v67, v186, 0x7fff                          // 00000019DDB8: D6550041 03FF7543 00007FFF
	v_mul_f32_e32 v67, 0x3b800000, v69                         // 00000019DDC4: 10868AFF 3B800000
	v_mul_f32_e32 v69, 0x3b800000, v70                         // 00000019DDCC: 108A8CFF 3B800000
	v_bfe_u32 v66, v68, 16, 1                                  // 00000019DDD4: D6100042 02052144
	v_fma_f32 v70, v7, v71, v39                                // 00000019DDDC: D6130046 049E8F07
	v_fma_f32 v71, v8, v72, v40                                // 00000019DDE4: D6130047 04A29108
	v_bfe_u32 v93, v85, 16, 1                                  // 00000019DDEC: D610005D 02052155
	v_bfe_u32 v94, v86, 16, 1                                  // 00000019DDF4: D610005E 02052156
	v_bfe_u32 v92, v84, 16, 1                                  // 00000019DDFC: D610005C 02052154
	v_add3_u32 v91, v83, v91, 0x7fff                           // 00000019DE04: D655005B 03FEB753 00007FFF
	v_add3_u32 v95, v87, v95, 0x7fff                           // 00000019DE10: D655005F 03FEBF57 00007FFF
	v_bfe_u32 v87, v88, 16, 1                                  // 00000019DE1C: D6100057 02052158
	v_add3_u32 v66, v68, v66, 0x7fff                           // 00000019DE24: D6550042 03FE8544 00007FFF
	v_bfe_u32 v68, v67, 16, 1                                  // 00000019DE30: D6100044 02052143
	v_dual_mul_f32 v70, 0x3b800000, v70 :: v_dual_mul_f32 v71, 0x3b800000, v71// 00000019DE38: C8C68CFF 46468EFF 3B800000
	v_add3_u32 v93, v85, v93, 0x7fff                           // 00000019DE44: D655005D 03FEBB55 00007FFF
	v_mad_u64_u32 v[81:82], null, 0x3000, v177, v[108:109]     // 00000019DE50: D6FE7C51 05B362FF 00003000
	v_add3_u32 v94, v86, v94, 0x7fff                           // 00000019DE5C: D655005E 03FEBD56 00007FFF
	v_mad_u64_u32 v[85:86], null, 0x3000, v175, v[108:109]     // 00000019DE68: D6FE7C55 05B35EFF 00003000
	v_add3_u32 v92, v84, v92, 0x7fff                           // 00000019DE74: D655005C 03FEB954 00007FFF
	v_bfe_u32 v72, v69, 16, 1                                  // 00000019DE80: D6100048 02052145
	v_mad_u64_u32 v[83:84], null, 0x3000, v176, v[108:109]     // 00000019DE88: D6FE7C53 05B360FF 00003000
	v_add3_u32 v99, v88, v87, 0x7fff                           // 00000019DE94: D6550063 03FEAF58 00007FFF
	v_mad_u64_u32 v[87:88], null, 0x3000, v174, v[108:109]     // 00000019DEA0: D6FE7C57 05B35CFF 00003000
	s_clause 0x7                                               // 00000019DEAC: BF850007
	global_store_d16_hi_b16 v[77:78], v91, off                 // 00000019DEB0: DC960000 007C5B4D
	global_store_d16_hi_b16 v[77:78], v98, off offset:32       // 00000019DEB8: DC960020 007C624D
	global_store_d16_hi_b16 v[77:78], v117, off offset:64      // 00000019DEC0: DC960040 007C754D
	global_store_d16_hi_b16 v[79:80], v92, off                 // 00000019DEC8: DC960000 007C5C4F
	global_store_d16_hi_b16 v[79:80], v100, off offset:32      // 00000019DED0: DC960020 007C644F
	global_store_d16_hi_b16 v[79:80], v181, off offset:64      // 00000019DED8: DC960040 007CB54F
	global_store_d16_hi_b16 v[77:78], v65, off offset:96       // 00000019DEE0: DC960060 007C414D
	global_store_d16_hi_b16 v[79:80], v66, off offset:96       // 00000019DEE8: DC960060 007C424F
	v_add3_u32 v65, v67, v68, 0x7fff                           // 00000019DEF0: D6550041 03FE8943 00007FFF
	v_bfe_u32 v67, v70, 16, 1                                  // 00000019DEFC: D6100043 02052146
	v_bfe_u32 v68, v71, 16, 1                                  // 00000019DF04: D6100044 02052147
	v_add3_u32 v66, v69, v72, 0x7fff                           // 00000019DF0C: D6550042 03FE9145 00007FFF
	s_clause 0x7                                               // 00000019DF18: BF850007
	global_store_d16_hi_b16 v[81:82], v93, off                 // 00000019DF1C: DC960000 007C5D51
	global_store_d16_hi_b16 v[81:82], v101, off offset:32      // 00000019DF24: DC960020 007C6551
	global_store_d16_hi_b16 v[81:82], v182, off offset:64      // 00000019DF2C: DC960040 007CB651
	global_store_d16_hi_b16 v[83:84], v94, off                 // 00000019DF34: DC960000 007C5E53
	global_store_d16_hi_b16 v[83:84], v102, off offset:32      // 00000019DF3C: DC960020 007C6653
	global_store_d16_hi_b16 v[83:84], v183, off offset:64      // 00000019DF44: DC960040 007CB753
	global_store_d16_hi_b16 v[81:82], v65, off offset:96       // 00000019DF4C: DC960060 007C4151
	global_store_d16_hi_b16 v[83:84], v66, off offset:96       // 00000019DF54: DC960060 007C4253
	v_add3_u32 v65, v70, v67, 0x7fff                           // 00000019DF5C: D6550041 03FE8746 00007FFF
	v_add3_u32 v66, v71, v68, 0x7fff                           // 00000019DF68: D6550042 03FE8947 00007FFF
	s_clause 0x7                                               // 00000019DF74: BF850007
	global_store_d16_hi_b16 v[85:86], v95, off                 // 00000019DF78: DC960000 007C5F55
	global_store_d16_hi_b16 v[85:86], v103, off offset:32      // 00000019DF80: DC960020 007C6755
	global_store_d16_hi_b16 v[85:86], v184, off offset:64      // 00000019DF88: DC960040 007CB855
	global_store_d16_hi_b16 v[87:88], v99, off                 // 00000019DF90: DC960000 007C6357
	global_store_d16_hi_b16 v[87:88], v104, off offset:32      // 00000019DF98: DC960020 007C6857
	global_store_d16_hi_b16 v[87:88], v185, off offset:64      // 00000019DFA0: DC960040 007CB957
	global_store_d16_hi_b16 v[85:86], v65, off offset:96       // 00000019DFA8: DC960060 007C4155
	global_store_d16_hi_b16 v[87:88], v66, off offset:96       // 00000019DFB0: DC960060 007C4257
	s_and_not1_b32 vcc_lo, exec_lo, s15                        // 00000019DFB8: 916A0F7E
	s_cbranch_vccnz 114                                        // 00000019DFBC: BFA40072 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6888>
	s_and_saveexec_b32 s15, s11                                // 00000019DFC0: BE8F200B
	s_cbranch_execnz 931                                       // 00000019DFC4: BFA603A3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7554>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019DFC8: 8C7E0F7E
	s_and_saveexec_b32 s15, s14                                // 00000019DFCC: BE8F200E
	s_cbranch_execnz 950                                       // 00000019DFD0: BFA603B6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x75ac>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019DFD4: 8C7E0F7E
	s_and_saveexec_b32 s15, s13                                // 00000019DFD8: BE8F200D
	s_cbranch_execnz 969                                       // 00000019DFDC: BFA603C9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7604>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019DFE0: 8C7E0F7E
	s_and_saveexec_b32 s15, s12                                // 00000019DFE4: BE8F200C
	s_cbranch_execnz 988                                       // 00000019DFE8: BFA603DC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x765c>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019DFEC: 8C7E0F7E
	s_and_saveexec_b32 s15, s10                                // 00000019DFF0: BE8F200A
	s_cbranch_execnz 1007                                      // 00000019DFF4: BFA603EF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x76b4>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019DFF8: 8C7E0F7E
	s_and_saveexec_b32 s15, s1                                 // 00000019DFFC: BE8F2001
	s_cbranch_execnz 1026                                      // 00000019E000: BFA60402 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x770c>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E004: 8C7E0F7E
	s_and_saveexec_b32 s15, s9                                 // 00000019E008: BE8F2009
	s_cbranch_execnz 1045                                      // 00000019E00C: BFA60415 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7764>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E010: 8C7E0F7E
	s_and_saveexec_b32 s15, s0                                 // 00000019E014: BE8F2000
	s_cbranch_execnz 1064                                      // 00000019E018: BFA60428 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x77bc>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E01C: 8C7E0F7E
	s_and_saveexec_b32 s15, s11                                // 00000019E020: BE8F200B
	s_cbranch_execnz 1083                                      // 00000019E024: BFA6043B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7814>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E028: 8C7E0F7E
	s_and_saveexec_b32 s15, s14                                // 00000019E02C: BE8F200E
	s_cbranch_execnz 1102                                      // 00000019E030: BFA6044E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x786c>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E034: 8C7E0F7E
	s_and_saveexec_b32 s15, s13                                // 00000019E038: BE8F200D
	s_cbranch_execnz 1121                                      // 00000019E03C: BFA60461 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x78c4>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E040: 8C7E0F7E
	s_and_saveexec_b32 s15, s12                                // 00000019E044: BE8F200C
	s_cbranch_execnz 1140                                      // 00000019E048: BFA60474 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x791c>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E04C: 8C7E0F7E
	s_and_saveexec_b32 s15, s10                                // 00000019E050: BE8F200A
	s_cbranch_execnz 1159                                      // 00000019E054: BFA60487 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7974>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E058: 8C7E0F7E
	s_and_saveexec_b32 s15, s1                                 // 00000019E05C: BE8F2001
	s_cbranch_execnz 1178                                      // 00000019E060: BFA6049A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x79cc>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E064: 8C7E0F7E
	s_and_saveexec_b32 s15, s9                                 // 00000019E068: BE8F2009
	s_cbranch_execnz 1197                                      // 00000019E06C: BFA604AD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7a24>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E070: 8C7E0F7E
	s_and_saveexec_b32 s15, s0                                 // 00000019E074: BE8F2000
	s_cbranch_execnz 1216                                      // 00000019E078: BFA604C0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7a7c>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E07C: 8C7E0F7E
	s_and_saveexec_b32 s15, s11                                // 00000019E080: BE8F200B
	s_cbranch_execnz 1235                                      // 00000019E084: BFA604D3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7ad4>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E088: 8C7E0F7E
	s_and_saveexec_b32 s15, s14                                // 00000019E08C: BE8F200E
	s_cbranch_execnz 1254                                      // 00000019E090: BFA604E6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7b2c>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E094: 8C7E0F7E
	s_and_saveexec_b32 s15, s13                                // 00000019E098: BE8F200D
	s_cbranch_execnz 1273                                      // 00000019E09C: BFA604F9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7b84>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E0A0: 8C7E0F7E
	s_and_saveexec_b32 s15, s12                                // 00000019E0A4: BE8F200C
	s_cbranch_execnz 1292                                      // 00000019E0A8: BFA6050C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7bdc>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E0AC: 8C7E0F7E
	s_and_saveexec_b32 s15, s10                                // 00000019E0B0: BE8F200A
	s_cbranch_execnz 1311                                      // 00000019E0B4: BFA6051F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7c34>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E0B8: 8C7E0F7E
	s_and_saveexec_b32 s15, s1                                 // 00000019E0BC: BE8F2001
	s_cbranch_execnz 1330                                      // 00000019E0C0: BFA60532 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7c8c>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E0C4: 8C7E0F7E
	s_and_saveexec_b32 s15, s9                                 // 00000019E0C8: BE8F2009
	s_cbranch_execnz 1349                                      // 00000019E0CC: BFA60545 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7ce4>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E0D0: 8C7E0F7E
	s_and_saveexec_b32 s15, s0                                 // 00000019E0D4: BE8F2000
	s_cbranch_execnz 1368                                      // 00000019E0D8: BFA60558 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7d3c>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E0DC: 8C7E0F7E
	s_and_saveexec_b32 s15, s11                                // 00000019E0E0: BE8F200B
	s_cbranch_execnz 1387                                      // 00000019E0E4: BFA6056B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7d94>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019E0E8: 8C7E0F7E
	s_and_saveexec_b32 s11, s14                                // 00000019E0EC: BE8B200E
	s_cbranch_execnz 1406                                      // 00000019E0F0: BFA6057E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7dec>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000019E0F4: 8C7E0B7E
	s_and_saveexec_b32 s11, s13                                // 00000019E0F8: BE8B200D
	s_cbranch_execnz 1425                                      // 00000019E0FC: BFA60591 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7e44>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000019E100: 8C7E0B7E
	s_and_saveexec_b32 s11, s12                                // 00000019E104: BE8B200C
	s_cbranch_execnz 1444                                      // 00000019E108: BFA605A4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7e9c>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000019E10C: 8C7E0B7E
	s_and_saveexec_b32 s11, s10                                // 00000019E110: BE8B200A
	s_cbranch_execnz 1463                                      // 00000019E114: BFA605B7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7ef4>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000019E118: 8C7E0B7E
	s_and_saveexec_b32 s10, s1                                 // 00000019E11C: BE8A2001
	s_cbranch_execnz 1482                                      // 00000019E120: BFA605CA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7f4c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000019E124: 8C7E0A7E
	s_and_saveexec_b32 s1, s9                                  // 00000019E128: BE812009
	s_cbranch_execnz 1501                                      // 00000019E12C: BFA605DD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7fa4>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000019E130: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000019E134: BE812000
	s_cbranch_execz 18                                         // 00000019E138: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6884>
	ds_load_b32 v1, v139 offset:56                             // 00000019E13C: D8D80038 0100008B
	s_waitcnt lgkmcnt(0)                                       // 00000019E144: BF89FC07
	v_fmac_f32_e32 v40, v8, v1                                 // 00000019E148: 56500308
	v_mad_u64_u32 v[1:2], null, 0x3000, v174, v[108:109]       // 00000019E14C: D6FE7C01 05B35CFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019E158: BF870092
	v_mul_f32_e32 v3, 0x3b800000, v40                          // 00000019E15C: 100650FF 3B800000
	v_bfe_u32 v4, v3, 16, 1                                    // 00000019E164: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019E16C: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000019E170: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 00000019E17C: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s1                              // 00000019E184: 8C7E017E
	v_mov_b32_e32 v41, 0                                       // 00000019E188: 7E520280
	s_waitcnt vmcnt(0)                                         // 00000019E18C: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 00000019E190: BC7C0000
	s_barrier                                                  // 00000019E194: BFBD0000
	buffer_gl0_inv                                             // 00000019E198: E0AC0000 00000000
	s_and_saveexec_b32 s0, s6                                  // 00000019E1A0: BE802006
	s_cbranch_execz 6                                          // 00000019E1A4: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68c0>
	s_lshl_b64 s[10:11], s[22:23], 2                           // 00000019E1A8: 848A8216
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000019E1AC: BF870009
	s_add_u32 s10, s62, s10                                    // 00000019E1B0: 800A0A3E
	s_addc_u32 s11, s63, s11                                   // 00000019E1B4: 820B0B3F
	global_atomic_inc_u32 v41, v107, v172, s[10:11] glc        // 00000019E1B8: DCFE4000 290AAC6B
	s_or_b32 exec_lo, exec_lo, s0                              // 00000019E1C0: 8C7E007E
	s_mul_f32 s0, s47, 0x3fb8aa3b                              // 00000019E1C4: A200FF2F 3FB8AA3B
	ds_load_b128 v[1:4], v131                                  // 00000019E1CC: DBFC0000 01000083
	ds_load_b128 v[5:8], v131 offset:16                        // 00000019E1D4: DBFC0010 05000083
	ds_load_b128 v[42:45], v132                                // 00000019E1DC: DBFC0000 2A000084
	ds_load_b128 v[46:49], v132 offset:16                      // 00000019E1E4: DBFC0010 2E000084
	ds_load_b128 v[17:20], v131 offset:32                      // 00000019E1EC: DBFC0020 11000083
	ds_load_b128 v[21:24], v131 offset:48                      // 00000019E1F4: DBFC0030 15000083
	ds_load_b128 v[50:53], v132 offset:32                      // 00000019E1FC: DBFC0020 32000084
	ds_load_b128 v[54:57], v132 offset:48                      // 00000019E204: DBFC0030 36000084
	s_xor_b32 s1, s0, 0x80000000                               // 00000019E20C: 8D01FF00 80000000
	s_rndne_f32 s9, s0                                         // 00000019E214: BE896300
	s_fmamk_f32 s1, s47, 0x3fb8aa3b, s1                        // 00000019E218: A301012F 3FB8AA3B
	ds_load_b128 v[13:16], v131 offset:80                      // 00000019E220: DBFC0050 0D000083
	ds_load_b128 v[9:12], v131 offset:64                       // 00000019E228: DBFC0040 09000083
	ds_load_b128 v[62:65], v132 offset:80                      // 00000019E230: DBFC0050 3E000084
	ds_load_b128 v[58:61], v132 offset:64                      // 00000019E238: DBFC0040 3A000084
	ds_load_b128 v[29:32], v131 offset:112                     // 00000019E240: DBFC0070 1D000083
	ds_load_b128 v[25:28], v131 offset:96                      // 00000019E248: DBFC0060 19000083
	s_sub_f32 s0, s0, s9                                       // 00000019E250: A0800900
	s_fmamk_f32 s1, s47, 0x32a5705f, s1                        // 00000019E254: A301012F 32A5705F
	v_dual_mov_b32 v33, s36 :: v_dual_mov_b32 v34, s37         // 00000019E25C: CA100024 21220025
	v_dual_mov_b32 v35, s38 :: v_dual_mov_b32 v36, s39         // 00000019E264: CA100026 23240027
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000019E26C: BF8704B9
	s_add_f32 s0, s0, s1                                       // 00000019E270: A0000100
	v_dual_mov_b32 v37, s40 :: v_dual_mov_b32 v38, s41         // 00000019E274: CA100028 25260029
	v_dual_mov_b32 v39, s42 :: v_dual_mov_b32 v40, s43         // 00000019E27C: CA10002A 2728002B
	v_exp_f32_e32 v84, s0                                      // 00000019E284: 7EA84A00
	ds_load_b128 v[70:73], v132 offset:112                     // 00000019E288: DBFC0070 46000084
	ds_load_b128 v[66:69], v132 offset:96                      // 00000019E290: DBFC0060 42000084
	ds_load_2addr_b32 v[82:83], v133 offset1:2                 // 00000019E298: D8DC0200 52000085
	s_cvt_i32_f32 s0, s9                                       // 00000019E2A0: BE806609
	s_cmp_nlt_f32 s47, 0xc2ce8ed0                              // 00000019E2A4: BF4EFF2F C2CE8ED0
	s_waitcnt lgkmcnt(13)                                      // 00000019E2AC: BF89FCD7
	v_wmma_f32_16x16x16_f16 v[74:81], v[42:49], v[1:8], v[33:40]// 00000019E2B0: CC40404A 1C86032A
	ds_load_2addr_b32 v[86:87], v133 offset0:8 offset1:10      // 00000019E2B8: D8DC0A08 56000085
	s_cselect_b32 vcc_lo, -1, 0                                // 00000019E2C0: 986A80C1
	s_cmp_ngt_f32 s47, 0x42b17218                              // 00000019E2C4: BF4BFF2F 42B17218
	s_waitcnt lgkmcnt(10)                                      // 00000019E2CC: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[74:81], v[50:57], v[17:24], v[74:81]// 00000019E2D0: CC40404A 1D2A2332
	.long 0xd71c002a                                           // 00000019E2D8: D71C002A
	v_cndmask_b32_e32 v0, v84, v0, vcc_lo                      // 00000019E2DC: 02000154
	ds_load_2addr_b32 v[84:85], v133 offset0:4 offset1:6       // 00000019E2E0: D8DC0604 54000085
	ds_load_2addr_b32 v[90:91], v133 offset0:12 offset1:14     // 00000019E2E8: D8DC0E0C 5A000085
	ds_load_b128 v[43:46], v132 offset:2304                    // 00000019E2F0: DBFC0900 2B000084
	ds_load_b128 v[47:50], v132 offset:2320                    // 00000019E2F8: DBFC0910 2F000084
	s_waitcnt lgkmcnt(10)                                      // 00000019E300: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[74:81], v[58:65], v[9:16], v[74:81]// 00000019E304: CC40404A 1D2A133A
	ds_load_b128 v[51:54], v132 offset:2336                    // 00000019E30C: DBFC0920 33000084
	ds_load_b128 v[55:58], v132 offset:2352                    // 00000019E314: DBFC0930 37000084
	s_waitcnt lgkmcnt(8)                                       // 00000019E31C: BF89FC87
	v_wmma_f32_16x16x16_f16 v[74:81], v[66:73], v[25:32], v[74:81]// 00000019E320: CC40404A 1D2A3342
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000019E328: 02545480
	s_cselect_b32 vcc_lo, -1, 0                                // 00000019E32C: 986A80C1
	ds_load_b128 v[63:66], v132 offset:2384                    // 00000019E330: DBFC0950 3F000084
	ds_load_b128 v[59:62], v132 offset:2368                    // 00000019E338: DBFC0940 3B000084
	v_cndmask_b32_e32 v42, 0x7f800000, v42, vcc_lo             // 00000019E340: 025454FF 7F800000
	s_waitcnt lgkmcnt(7)                                       // 00000019E348: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019E34C: BF870091
	v_mul_f32_e32 v95, v42, v85                                // 00000019E350: 10BEAB2A
	v_dual_mul_f32 v92, v42, v82 :: v_dual_fmac_f32 v95, 0x3b800000, v77// 00000019E354: C8C0A52A 5C5E9AFF 3B800000
	v_mul_f32_e32 v77, v42, v87                                // 00000019E360: 109AAF2A
	s_delay_alu instid0(VALU_DEP_2)                            // 00000019E364: BF870002
	v_dual_mul_f32 v93, v42, v83 :: v_dual_fmac_f32 v92, 0x3b800000, v74// 00000019E368: C8C0A72A 5D5C94FF 3B800000
	v_mul_f32_e32 v94, v42, v84                                // 00000019E374: 10BCA92A
	ds_load_b128 v[71:74], v132 offset:2416                    // 00000019E378: DBFC0970 47000084
	ds_load_b128 v[67:70], v132 offset:2400                    // 00000019E380: DBFC0960 43000084
	v_fmac_f32_e32 v77, 0x3b800000, v79                        // 00000019E388: 569A9EFF 3B800000
	s_waitcnt lgkmcnt(8)                                       // 00000019E390: BF89FC87
	v_mul_f32_e32 v79, v42, v90                                // 00000019E394: 109EB52A
	v_dual_mul_f32 v96, v42, v86 :: v_dual_fmac_f32 v93, 0x3b800000, v75// 00000019E398: C8C0AD2A 605C96FF 3B800000
	v_fmac_f32_e32 v94, 0x3b800000, v76                        // 00000019E3A4: 56BC98FF 3B800000
	ds_load_2addr_b32 v[75:76], v133 offset0:16 offset1:18     // 00000019E3AC: D8DC1210 4B000085
	v_dual_fmac_f32 v79, 0x3b800000, v80 :: v_dual_fmac_f32 v96, 0x3b800000, v78// 00000019E3B4: C800A0FF 4F609CFF 3B800000
	s_waitcnt lgkmcnt(7)                                       // 00000019E3C0: BF89FC77
	v_wmma_f32_16x16x16_f16 v[82:89], v[43:50], v[1:8], v[33:40]// 00000019E3C4: CC404052 1C86032B
	ds_store_2addr_b32 v133, v92, v93 offset1:2                // 00000019E3CC: D8380200 005D5C85
	ds_store_2addr_b32 v133, v94, v95 offset0:4 offset1:6      // 00000019E3D4: D8380604 005F5E85
	ds_load_2addr_b32 v[92:93], v133 offset0:28 offset1:30     // 00000019E3DC: D8DC1E1C 5C000085
	ds_store_2addr_b32 v133, v96, v77 offset0:8 offset1:10     // 00000019E3E4: D8380A08 004D6085
	ds_load_2addr_b32 v[77:78], v133 offset0:20 offset1:22     // 00000019E3EC: D8DC1614 4D000085
	s_waitcnt lgkmcnt(10)                                      // 00000019E3F4: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[82:89], v[51:58], v[17:24], v[82:89]// 00000019E3F8: CC404052 1D4A2333
	ds_load_b128 v[51:54], v132 offset:4640                    // 00000019E400: DBFC1220 33000084
	ds_load_b128 v[55:58], v132 offset:4656                    // 00000019E408: DBFC1230 37000084
	s_waitcnt lgkmcnt(10)                                      // 00000019E410: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[82:89], v[59:66], v[9:16], v[82:89]// 00000019E414: CC404052 1D4A133B
	ds_load_b128 v[63:66], v132 offset:4688                    // 00000019E41C: DBFC1250 3F000084
	ds_load_b128 v[59:62], v132 offset:4672                    // 00000019E424: DBFC1240 3B000084
	s_waitcnt lgkmcnt(10)                                      // 00000019E42C: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[82:89], v[67:74], v[25:32], v[82:89]// 00000019E430: CC404052 1D4A3343
	s_waitcnt lgkmcnt(9)                                       // 00000019E438: BF89FC97
	v_mul_f32_e32 v96, v42, v75                                // 00000019E43C: 10C0972A
	v_mul_f32_e32 v97, v42, v76                                // 00000019E440: 10C2992A
	ds_load_b128 v[71:74], v132 offset:4720                    // 00000019E444: DBFC1270 47000084
	ds_load_b128 v[67:70], v132 offset:4704                    // 00000019E44C: DBFC1260 43000084
	ds_load_2addr_b32 v[94:95], v133 offset0:32 offset1:34     // 00000019E454: D8DC2220 5E000085
	v_dual_fmac_f32 v96, 0x3b800000, v82 :: v_dual_fmac_f32 v97, 0x3b800000, v83// 00000019E45C: C800A4FF 6060A6FF 3B800000
	s_waitcnt lgkmcnt(7)                                       // 00000019E468: BF89FC77
	v_mul_f32_e32 v98, v42, v77                                // 00000019E46C: 10C49B2A
	v_mul_f32_e32 v99, v42, v78                                // 00000019E470: 10C69D2A
	ds_store_2addr_b32 v133, v96, v97 offset0:16 offset1:18    // 00000019E474: D8381210 00616085
	v_fmac_f32_e32 v98, 0x3b800000, v84                        // 00000019E47C: 56C4A8FF 3B800000
	v_dual_mul_f32 v80, v42, v91 :: v_dual_fmac_f32 v99, 0x3b800000, v85// 00000019E484: C8C0B72A 5062AAFF 3B800000
	ds_load_b128 v[43:46], v132 offset:4608                    // 00000019E490: DBFC1200 2B000084
	ds_load_b128 v[47:50], v132 offset:4624                    // 00000019E498: DBFC1210 2F000084
	ds_load_2addr_b32 v[90:91], v133 offset0:24 offset1:26     // 00000019E4A0: D8DC1A18 5A000085
	ds_load_2addr_b32 v[83:84], v133 offset0:36 offset1:38     // 00000019E4A8: D8DC2624 53000085
	v_dual_mul_f32 v85, v42, v92 :: v_dual_fmac_f32 v80, 0x3b800000, v81// 00000019E4B0: C8C0B92A 5550A2FF 3B800000
	ds_store_2addr_b32 v133, v98, v99 offset0:20 offset1:22    // 00000019E4BC: D8381614 00636285
	v_fmac_f32_e32 v85, 0x3b800000, v88                        // 00000019E4C4: 56AAB0FF 3B800000
	ds_store_2addr_b32 v133, v79, v80 offset0:12 offset1:14    // 00000019E4CC: D8380E0C 00504F85
	s_waitcnt lgkmcnt(4)                                       // 00000019E4D4: BF89FC47
	v_wmma_f32_16x16x16_f16 v[75:82], v[43:50], v[1:8], v[33:40]// 00000019E4D8: CC40404B 1C86032B
	s_waitcnt lgkmcnt(3)                                       // 00000019E4E0: BF89FC37
	v_mul_f32_e32 v44, v42, v91                                // 00000019E4E4: 1058B72A
	v_mul_f32_e32 v43, v42, v90                                // 00000019E4E8: 1056B52A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019E4EC: BF870003
	v_wmma_f32_16x16x16_f16 v[75:82], v[51:58], v[17:24], v[75:82]// 00000019E4F0: CC40404B 1D2E2333
	ds_load_2addr_b32 v[91:92], v133 offset0:40 offset1:42     // 00000019E4F8: D8DC2A28 5B000085
	ds_load_b128 v[51:54], v132 offset:6944                    // 00000019E500: DBFC1B20 33000084
	ds_load_b128 v[55:58], v132 offset:6960                    // 00000019E508: DBFC1B30 37000084
	v_dual_fmac_f32 v44, 0x3b800000, v87 :: v_dual_fmac_f32 v43, 0x3b800000, v86// 00000019E510: C800AEFF 2C2AACFF 3B800000
	v_wmma_f32_16x16x16_f16 v[75:82], v[59:66], v[9:16], v[75:82]// 00000019E51C: CC40404B 1D2E133B
	ds_load_b128 v[63:66], v132 offset:6992                    // 00000019E524: DBFC1B50 3F000084
	ds_load_b128 v[59:62], v132 offset:6976                    // 00000019E52C: DBFC1B40 3B000084
	ds_store_2addr_b32 v133, v43, v44 offset0:24 offset1:26    // 00000019E534: D8381A18 002C2B85
	ds_load_b128 v[43:46], v132 offset:6912                    // 00000019E53C: DBFC1B00 2B000084
	ds_load_b128 v[47:50], v132 offset:6928                    // 00000019E544: DBFC1B10 2F000084
	v_wmma_f32_16x16x16_f16 v[75:82], v[67:74], v[25:32], v[75:82]// 00000019E54C: CC40404B 1D2E3343
	s_waitcnt lgkmcnt(10)                                      // 00000019E554: BF89FCA7
	v_mul_f32_e32 v98, v42, v84                                // 00000019E558: 10C4A92A
	v_mul_f32_e32 v95, v42, v95                                // 00000019E55C: 10BEBF2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019E560: BF870112
	v_dual_mul_f32 v97, v42, v83 :: v_dual_fmac_f32 v98, 0x3b800000, v78// 00000019E564: C8C0A72A 61629CFF 3B800000
	v_dual_mul_f32 v86, v42, v93 :: v_dual_fmac_f32 v95, 0x3b800000, v76// 00000019E570: C8C0BB2A 565E98FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000019E57C: BF870151
	v_fmac_f32_e32 v86, 0x3b800000, v89                        // 00000019E580: 56ACB2FF 3B800000
	ds_store_2addr_b32 v133, v85, v86 offset0:28 offset1:30    // 00000019E588: D8381E1C 00565585
	s_waitcnt lgkmcnt(1)                                       // 00000019E590: BF89FC17
	v_wmma_f32_16x16x16_f16 v[83:90], v[43:50], v[1:8], v[33:40]// 00000019E594: CC404053 1C86032B
	v_mul_f32_e32 v44, v42, v92                                // 00000019E59C: 1058B92A
	v_wmma_f32_16x16x16_f16 v[83:90], v[51:58], v[17:24], v[83:90]// 00000019E5A0: CC404053 1D4E2333
	s_delay_alu instid0(VALU_DEP_2)                            // 00000019E5A8: BF870002
	v_fmac_f32_e32 v44, 0x3b800000, v80                        // 00000019E5AC: 5658A0FF 3B800000
	v_dual_mul_f32 v96, v42, v94 :: v_dual_fmac_f32 v97, 0x3b800000, v77// 00000019E5B4: C8C0BD2A 60609AFF 3B800000
	ds_load_2addr_b32 v[93:94], v133 offset0:44 offset1:46     // 00000019E5C0: D8DC2E2C 5D000085
	ds_load_2addr_b32 v[77:78], v133 offset0:52 offset1:54     // 00000019E5C8: D8DC3634 4D000085
	v_wmma_f32_16x16x16_f16 v[83:90], v[59:66], v[9:16], v[83:90]// 00000019E5D0: CC404053 1D4E133B
	v_fmac_f32_e32 v96, 0x3b800000, v75                        // 00000019E5D8: 56C096FF 3B800000
	ds_load_b128 v[71:74], v132 offset:7024                    // 00000019E5E0: DBFC1B70 47000084
	ds_load_b128 v[67:70], v132 offset:7008                    // 00000019E5E8: DBFC1B60 43000084
	ds_load_2addr_b32 v[75:76], v133 offset0:48 offset1:50     // 00000019E5F0: D8DC3230 4B000085
	ds_load_b128 v[63:66], v132 offset:9296                    // 00000019E5F8: DBFC2450 3F000084
	ds_load_b128 v[59:62], v132 offset:9280                    // 00000019E600: DBFC2440 3B000084
	s_waitcnt lgkmcnt(6)                                       // 00000019E608: BF89FC67
	v_mul_f32_e32 v45, v42, v93                                // 00000019E60C: 105ABB2A
	ds_store_2addr_b32 v133, v96, v95 offset0:32 offset1:34    // 00000019E610: D8382220 005F6085
	ds_store_2addr_b32 v133, v97, v98 offset0:36 offset1:38    // 00000019E618: D8382624 00626185
	s_waitcnt lgkmcnt(5)                                       // 00000019E620: BF89FC57
	v_wmma_f32_16x16x16_f16 v[83:90], v[67:74], v[25:32], v[83:90]// 00000019E624: CC404053 1D4E3343
	s_waitcnt lgkmcnt(4)                                       // 00000019E62C: BF89FC47
	v_mul_f32_e32 v68, v42, v76                                // 00000019E630: 1088992A
	v_mul_f32_e32 v67, v42, v75                                // 00000019E634: 1086972A
	v_mul_f32_e32 v76, v42, v78                                // 00000019E638: 10989D2A
	v_mul_f32_e32 v75, v42, v77                                // 00000019E63C: 10969B2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019E640: BF870112
	v_dual_fmac_f32 v45, 0x3b800000, v81 :: v_dual_fmac_f32 v76, 0x3b800000, v86// 00000019E644: C800A2FF 2D4CACFF 3B800000
	v_dual_fmac_f32 v75, 0x3b800000, v85 :: v_dual_fmac_f32 v68, 0x3b800000, v84// 00000019E650: C800AAFF 4B44A8FF 3B800000
	v_dual_mul_f32 v46, v42, v94 :: v_dual_fmac_f32 v67, 0x3b800000, v83// 00000019E65C: C8C0BD2A 2E42A6FF 3B800000
	v_mul_f32_e32 v43, v42, v91                                // 00000019E668: 1056B72A
	ds_load_2addr_b32 v[93:94], v133 offset0:60 offset1:62     // 00000019E66C: D8DC3E3C 5D000085
	ds_load_b128 v[51:54], v132 offset:9248                    // 00000019E674: DBFC2420 33000084
	ds_load_b128 v[55:58], v132 offset:9264                    // 00000019E67C: DBFC2430 37000084
	ds_load_2addr_b32 v[91:92], v133 offset0:56 offset1:58     // 00000019E684: D8DC3A38 5B000085
	v_fmac_f32_e32 v46, 0x3b800000, v82                        // 00000019E68C: 565CA4FF 3B800000
	ds_store_2addr_b32 v133, v67, v68 offset0:48 offset1:50    // 00000019E694: D8383230 00444385
	v_fmac_f32_e32 v43, 0x3b800000, v79                        // 00000019E69C: 56569EFF 3B800000
	ds_store_2addr_b32 v133, v43, v44 offset0:40 offset1:42    // 00000019E6A4: D8382A28 002C2B85
	ds_store_2addr_b32 v133, v45, v46 offset0:44 offset1:46    // 00000019E6AC: D8382E2C 002E2D85
	ds_load_b128 v[43:46], v132 offset:9216                    // 00000019E6B4: DBFC2400 2B000084
	ds_load_b128 v[47:50], v132 offset:9232                    // 00000019E6BC: DBFC2410 2F000084
	ds_load_b128 v[71:74], v132 offset:9328                    // 00000019E6C4: DBFC2470 47000084
	ds_load_b128 v[67:70], v132 offset:9312                    // 00000019E6CC: DBFC2460 43000084
	ds_load_2addr_b32 v[85:86], v133 offset0:68 offset1:70     // 00000019E6D4: D8DC4644 55000085
	ds_store_2addr_b32 v133, v75, v76 offset0:52 offset1:54    // 00000019E6DC: D8383634 004C4B85
	ds_load_2addr_b32 v[83:84], v133 offset0:64 offset1:66     // 00000019E6E4: D8DC4240 53000085
	s_waitcnt lgkmcnt(10)                                      // 00000019E6EC: BF89FCA7
	v_mul_f32_e32 v95, v42, v91                                // 00000019E6F0: 10BEB72A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000019E6F4: BF870151
	v_fmac_f32_e32 v95, 0x3b800000, v87                        // 00000019E6F8: 56BEAEFF 3B800000
	s_waitcnt lgkmcnt(5)                                       // 00000019E700: BF89FC57
	v_wmma_f32_16x16x16_f16 v[75:82], v[43:50], v[1:8], v[33:40]// 00000019E704: CC40404B 1C86032B
	s_waitcnt lgkmcnt(2)                                       // 00000019E70C: BF89FC27
	v_mul_f32_e32 v97, v42, v86                                // 00000019E710: 10C2AD2A
	v_wmma_f32_16x16x16_f16 v[75:82], v[51:58], v[17:24], v[75:82]// 00000019E714: CC40404B 1D2E2333
	ds_load_b128 v[51:54], v132 offset:11552                   // 00000019E71C: DBFC2D20 33000084
	ds_load_b128 v[55:58], v132 offset:11568                   // 00000019E724: DBFC2D30 37000084
	v_wmma_f32_16x16x16_f16 v[75:82], v[59:66], v[9:16], v[75:82]// 00000019E72C: CC40404B 1D2E133B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000019E734: BF8701B1
	v_wmma_f32_16x16x16_f16 v[75:82], v[67:74], v[25:32], v[75:82]// 00000019E738: CC40404B 1D2E3343
	v_mul_f32_e32 v87, v42, v92                                // 00000019E740: 10AEB92A
	v_mul_f32_e32 v92, v42, v93                                // 00000019E744: 10B8BB2A
	v_dual_mul_f32 v96, v42, v85 :: v_dual_fmac_f32 v97, 0x3b800000, v78// 00000019E748: C8C0AB2A 60609CFF 3B800000
	v_mul_f32_e32 v93, v42, v94                                // 00000019E754: 10BABD2A
	s_waitcnt lgkmcnt(2)                                       // 00000019E758: BF89FC27
	v_mul_f32_e32 v94, v42, v83                                // 00000019E75C: 10BCA72A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019E760: BF870003
	v_fmac_f32_e32 v96, 0x3b800000, v77                        // 00000019E764: 56C09AFF 3B800000
	ds_load_2addr_b32 v[77:78], v133 offset0:84 offset1:86     // 00000019E76C: D8DC5654 4D000085
	v_fmac_f32_e32 v93, 0x3b800000, v90                        // 00000019E774: 56BAB4FF 3B800000
	ds_load_2addr_b32 v[90:91], v133 offset0:72 offset1:74     // 00000019E77C: D8DC4A48 5A000085
	ds_load_b128 v[43:46], v132 offset:11520                   // 00000019E784: DBFC2D00 2B000084
	ds_load_b128 v[47:50], v132 offset:11536                   // 00000019E78C: DBFC2D10 2F000084
	v_dual_fmac_f32 v94, 0x3b800000, v75 :: v_dual_fmac_f32 v87, 0x3b800000, v88// 00000019E794: C80096FF 5E56B0FF 3B800000
	v_fmac_f32_e32 v92, 0x3b800000, v89                        // 00000019E7A0: 56B8B2FF 3B800000
	ds_store_2addr_b32 v133, v95, v87 offset0:56 offset1:58    // 00000019E7A8: D8383A38 00575F85
	ds_store_2addr_b32 v133, v92, v93 offset0:60 offset1:62    // 00000019E7B0: D8383E3C 005D5C85
	ds_load_2addr_b32 v[92:93], v133 offset0:76 offset1:78     // 00000019E7B8: D8DC4E4C 5C000085
	ds_load_b128 v[63:66], v132 offset:11600                   // 00000019E7C0: DBFC2D50 3F000084
	ds_load_b128 v[59:62], v132 offset:11584                   // 00000019E7C8: DBFC2D40 3B000084
	s_waitcnt lgkmcnt(7)                                       // 00000019E7D0: BF89FC77
	v_mul_f32_e32 v98, v42, v90                                // 00000019E7D4: 10C4B52A
	v_mul_f32_e32 v95, v42, v84                                // 00000019E7D8: 10BEA92A
	s_waitcnt lgkmcnt(5)                                       // 00000019E7DC: BF89FC57
	v_wmma_f32_16x16x16_f16 v[83:90], v[43:50], v[1:8], v[33:40]// 00000019E7E0: CC404053 1C86032B
	v_mul_f32_e32 v43, v42, v91                                // 00000019E7E8: 1056B72A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000019E7EC: BF8701B2
	v_wmma_f32_16x16x16_f16 v[83:90], v[51:58], v[17:24], v[83:90]// 00000019E7F0: CC404053 1D4E2333
	s_waitcnt lgkmcnt(2)                                       // 00000019E7F8: BF89FC27
	v_mul_f32_e32 v91, v42, v92                                // 00000019E7FC: 10B6B92A
	v_dual_fmac_f32 v43, 0x3b800000, v80 :: v_dual_fmac_f32 v98, 0x3b800000, v79// 00000019E800: C800A0FF 2B629EFF 3B800000
	v_fmac_f32_e32 v95, 0x3b800000, v76                        // 00000019E80C: 56BE98FF 3B800000
	ds_load_b128 v[71:74], v132 offset:11632                   // 00000019E814: DBFC2D70 47000084
	ds_load_b128 v[67:70], v132 offset:11616                   // 00000019E81C: DBFC2D60 43000084
	ds_load_2addr_b32 v[75:76], v133 offset0:80 offset1:82     // 00000019E824: D8DC5250 4B000085
	ds_load_2addr_b32 v[79:80], v133 offset0:88 offset1:90     // 00000019E82C: D8DC5A58 4F000085
	s_waitcnt lgkmcnt(4)                                       // 00000019E834: BF89FC47
	v_wmma_f32_16x16x16_f16 v[83:90], v[59:66], v[9:16], v[83:90]// 00000019E838: CC404053 1D4E133B
	ds_store_2addr_b32 v133, v96, v97 offset0:68 offset1:70    // 00000019E840: D8384644 00616085
	ds_store_2addr_b32 v133, v98, v43 offset0:72 offset1:74    // 00000019E848: D8384A48 002B6285
	ds_load_b128 v[43:46], v132 offset:13824                   // 00000019E850: DBFC3600 2B000084
	ds_load_b128 v[47:50], v132 offset:13840                   // 00000019E858: DBFC3610 2F000084
	v_dual_fmac_f32 v91, 0x3b800000, v81 :: v_dual_mul_f32 v96, v42, v78// 00000019E860: C806A2FF 5B609D2A 3B800000
	ds_store_2addr_b32 v133, v94, v95 offset0:64 offset1:66    // 00000019E86C: D8384240 005F5E85
	v_mul_f32_e32 v95, v42, v77                                // 00000019E874: 10BE9B2A
	s_waitcnt lgkmcnt(7)                                       // 00000019E878: BF89FC77
	v_wmma_f32_16x16x16_f16 v[83:90], v[67:74], v[25:32], v[83:90]// 00000019E87C: CC404053 1D4E3343
	s_waitcnt lgkmcnt(6)                                       // 00000019E884: BF89FC67
	v_mul_f32_e32 v67, v42, v75                                // 00000019E888: 1086972A
	s_waitcnt lgkmcnt(5)                                       // 00000019E88C: BF89FC57
	v_mul_f32_e32 v98, v42, v80                                // 00000019E890: 10C4A12A
	v_mul_f32_e32 v59, v42, v93                                // 00000019E894: 1076BB2A
	v_mul_f32_e32 v68, v42, v76                                // 00000019E898: 1088992A
	v_dual_fmac_f32 v96, 0x3b800000, v86 :: v_dual_fmac_f32 v67, 0x3b800000, v83// 00000019E89C: C800ACFF 6042A6FF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019E8A8: BF870193
	v_dual_fmac_f32 v98, 0x3b800000, v88 :: v_dual_fmac_f32 v59, 0x3b800000, v82// 00000019E8AC: C800B0FF 623AA4FF 3B800000
	v_fmac_f32_e32 v68, 0x3b800000, v84                        // 00000019E8B8: 5688A8FF 3B800000
	ds_load_b128 v[51:54], v132 offset:13856                   // 00000019E8C0: DBFC3620 33000084
	ds_load_b128 v[55:58], v132 offset:13872                   // 00000019E8C8: DBFC3630 37000084
	ds_load_2addr_b32 v[83:84], v133 offset0:92 offset1:94     // 00000019E8D0: D8DC5E5C 53000085
	v_mul_f32_e32 v97, v42, v79                                // 00000019E8D8: 10C29F2A
	s_waitcnt lgkmcnt(4)                                       // 00000019E8DC: BF89FC47
	v_wmma_f32_16x16x16_f16 v[75:82], v[43:50], v[1:8], v[33:40]// 00000019E8E0: CC40404B 1C86032B
	ds_store_2addr_b32 v133, v91, v59 offset0:76 offset1:78    // 00000019E8E8: D8384E4C 003B5B85
	ds_load_b128 v[63:66], v132 offset:13904                   // 00000019E8F0: DBFC3650 3F000084
	ds_load_b128 v[59:62], v132 offset:13888                   // 00000019E8F8: DBFC3640 3B000084
	ds_store_2addr_b32 v133, v67, v68 offset0:80 offset1:82    // 00000019E900: D8385250 00444385
	ds_load_b128 v[71:74], v132 offset:13936                   // 00000019E908: DBFC3670 47000084
	ds_load_b128 v[67:70], v132 offset:13920                   // 00000019E910: DBFC3660 43000084
	ds_load_2addr_b32 v[91:92], v133 offset0:96 offset1:98     // 00000019E918: D8DC6260 5B000085
	v_fmac_f32_e32 v95, 0x3b800000, v85                        // 00000019E920: 56BEAAFF 3B800000
	ds_load_2addr_b32 v[85:86], v133 offset0:100 offset1:102   // 00000019E928: D8DC6664 55000085
	ds_load_b128 v[43:46], v132 offset:16128                   // 00000019E930: DBFC3F00 2B000084
	ds_load_b128 v[47:50], v132 offset:16144                   // 00000019E938: DBFC3F10 2F000084
	v_fmac_f32_e32 v97, 0x3b800000, v87                        // 00000019E940: 56C2AEFF 3B800000
	ds_load_2addr_b32 v[93:94], v133 offset0:104 offset1:106   // 00000019E948: D8DC6A68 5D000085
	s_waitcnt lgkmcnt(12)                                      // 00000019E950: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[75:82], v[51:58], v[17:24], v[75:82]// 00000019E954: CC40404B 1D2E2333
	ds_load_b128 v[51:54], v132 offset:16160                   // 00000019E95C: DBFC3F20 33000084
	ds_load_b128 v[55:58], v132 offset:16176                   // 00000019E964: DBFC3F30 37000084
	s_waitcnt lgkmcnt(13)                                      // 00000019E96C: BF89FCD7
	v_mul_f32_e32 v99, v42, v83                                // 00000019E970: 10C6A72A
	s_waitcnt lgkmcnt(10)                                      // 00000019E974: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[75:82], v[59:66], v[9:16], v[75:82]// 00000019E978: CC40404B 1D2E133B
	ds_load_b128 v[63:66], v132 offset:16208                   // 00000019E980: DBFC3F50 3F000084
	ds_load_b128 v[59:62], v132 offset:16192                   // 00000019E988: DBFC3F40 3B000084
	s_waitcnt lgkmcnt(8)                                       // 00000019E990: BF89FC87
	v_mul_f32_e32 v100, v42, v92                               // 00000019E994: 10C8B92A
	s_waitcnt lgkmcnt(7)                                       // 00000019E998: BF89FC77
	v_mul_f32_e32 v102, v42, v86                               // 00000019E99C: 10CCAD2A
	ds_store_2addr_b32 v133, v95, v96 offset0:84 offset1:86    // 00000019E9A0: D8385654 00605F85
	ds_store_2addr_b32 v133, v97, v98 offset0:88 offset1:90    // 00000019E9A8: D8385A58 00626185
	v_wmma_f32_16x16x16_f16 v[75:82], v[67:74], v[25:32], v[75:82]// 00000019E9B0: CC40404B 1D2E3343
	v_mul_f32_e32 v98, v42, v91                                // 00000019E9B8: 10C4B72A
	v_mul_f32_e32 v97, v42, v84                                // 00000019E9BC: 10C2A92A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019E9C0: BF870193
	v_dual_mul_f32 v101, v42, v85 :: v_dual_fmac_f32 v100, 0x3b800000, v76// 00000019E9C4: C8C0AB2A 656498FF 3B800000
	v_fmac_f32_e32 v98, 0x3b800000, v75                        // 00000019E9D0: 56C496FF 3B800000
	ds_load_2addr_b32 v[75:76], v133 offset0:108 offset1:110   // 00000019E9D8: D8DC6E6C 4B000085
	ds_load_b128 v[71:74], v132 offset:16240                   // 00000019E9E0: DBFC3F70 47000084
	ds_load_b128 v[67:70], v132 offset:16224                   // 00000019E9E8: DBFC3F60 43000084
	ds_load_2addr_b32 v[91:92], v133 offset0:112 offset1:114   // 00000019E9F0: D8DC7270 5B000085
	ds_load_2addr_b32 v[95:96], v133 offset0:116 offset1:118   // 00000019E9F8: D8DC7674 5F000085
	v_fmac_f32_e32 v99, 0x3b800000, v89                        // 00000019EA00: 56C6B2FF 3B800000
	v_fmac_f32_e32 v97, 0x3b800000, v90                        // 00000019EA08: 56C2B4FF 3B800000
	s_waitcnt lgkmcnt(12)                                      // 00000019EA10: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[83:90], v[43:50], v[1:8], v[33:40]// 00000019EA14: CC404053 1C86032B
	ds_load_2addr_b32 v[3:4], v133 offset0:124 offset1:126     // 00000019EA1C: D8DC7E7C 03000085
	ds_load_2addr_b32 v[1:2], v133 offset0:120 offset1:122     // 00000019EA24: D8DC7A78 01000085
	s_waitcnt lgkmcnt(13)                                      // 00000019EA2C: BF89FCD7
	v_mul_f32_e32 v5, v42, v94                                 // 00000019EA30: 100ABD2A
	s_waitcnt lgkmcnt(11)                                      // 00000019EA34: BF89FCB7
	v_wmma_f32_16x16x16_f16 v[83:90], v[51:58], v[17:24], v[83:90]// 00000019EA38: CC404053 1D4E2333
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019EA40: BF870122
	v_dual_fmac_f32 v102, 0x3b800000, v78 :: v_dual_fmac_f32 v5, 0x3b800000, v80// 00000019EA44: C8009CFF 6604A0FF 3B800000
	s_waitcnt lgkmcnt(9)                                       // 00000019EA50: BF89FC97
	v_wmma_f32_16x16x16_f16 v[83:90], v[59:66], v[9:16], v[83:90]// 00000019EA54: CC404053 1D4E133B
	s_waitcnt lgkmcnt(6)                                       // 00000019EA5C: BF89FC67
	v_mul_f32_e32 v6, v42, v76                                 // 00000019EA60: 100C992A
	s_waitcnt lgkmcnt(4)                                       // 00000019EA64: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 00000019EA68: BF870002
	v_wmma_f32_16x16x16_f16 v[83:90], v[67:74], v[25:32], v[83:90]// 00000019EA6C: CC404053 1D4E3343
	s_waitcnt lgkmcnt(3)                                       // 00000019EA74: BF89FC37
	v_mul_f32_e32 v7, v42, v91                                 // 00000019EA78: 100EB72A
	s_waitcnt lgkmcnt(2)                                       // 00000019EA7C: BF89FC27
	v_mul_f32_e32 v10, v42, v96                                // 00000019EA80: 1014C12A
	v_mul_f32_e32 v8, v42, v92                                 // 00000019EA84: 1010B92A
	v_dual_mul_f32 v9, v42, v95 :: v_dual_fmac_f32 v6, 0x3b800000, v82// 00000019EA88: C8C0BF2A 0906A4FF 3B800000
	s_waitcnt lgkmcnt(1)                                       // 00000019EA94: BF89FC17
	v_dual_fmac_f32 v7, 0x3b800000, v83 :: v_dual_mul_f32 v4, v42, v4// 00000019EA98: C806A6FF 0704092A 3B800000
	v_mul_f32_e32 v93, v42, v93                                // 00000019EAA4: 10BABB2A
	s_waitcnt lgkmcnt(0)                                       // 00000019EAA8: BF89FC07
	v_mul_f32_e32 v2, v42, v2                                  // 00000019EAAC: 1004052A
	v_mul_f32_e32 v1, v42, v1                                  // 00000019EAB0: 1002032A
	v_dual_mul_f32 v3, v42, v3 :: v_dual_fmac_f32 v4, 0x3b800000, v90// 00000019EAB4: C8C0072A 0304B4FF 3B800000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019EAC0: BF870003
	v_dual_fmac_f32 v93, 0x3b800000, v79 :: v_dual_fmac_f32 v2, 0x3b800000, v88// 00000019EAC4: C8009EFF 5D02B0FF 3B800000
	v_fmac_f32_e32 v101, 0x3b800000, v77                       // 00000019EAD0: 56CA9AFF 3B800000
	ds_store_2addr_b32 v133, v101, v102 offset0:100 offset1:102// 00000019EAD8: D8386664 00666585
	ds_store_2addr_b32 v133, v93, v5 offset0:104 offset1:106   // 00000019EAE0: D8386A68 00055D85
	v_dual_mul_f32 v5, v42, v75 :: v_dual_fmac_f32 v8, 0x3b800000, v84// 00000019EAE8: C8C0972A 0508A8FF 3B800000
	v_dual_fmac_f32 v9, 0x3b800000, v85 :: v_dual_fmac_f32 v10, 0x3b800000, v86// 00000019EAF4: C800AAFF 090AACFF 3B800000
	v_fmac_f32_e32 v1, 0x3b800000, v87                         // 00000019EB00: 5602AEFF 3B800000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019EB08: BF870003
	v_fmac_f32_e32 v5, 0x3b800000, v81                         // 00000019EB0C: 560AA2FF 3B800000
	v_fmac_f32_e32 v3, 0x3b800000, v89                         // 00000019EB14: 5606B2FF 3B800000
	ds_store_2addr_b32 v133, v99, v97 offset0:92 offset1:94    // 00000019EB1C: D8385E5C 00616385
	ds_store_2addr_b32 v133, v98, v100 offset0:96 offset1:98   // 00000019EB24: D8386260 00646285
	ds_store_2addr_b32 v133, v5, v6 offset0:108 offset1:110    // 00000019EB2C: D8386E6C 00060585
	ds_store_2addr_b32 v133, v7, v8 offset0:112 offset1:114    // 00000019EB34: D8387270 00080785
	ds_store_2addr_b32 v133, v9, v10 offset0:116 offset1:118   // 00000019EB3C: D8387674 000A0985
	ds_store_2addr_b32 v133, v1, v2 offset0:120 offset1:122    // 00000019EB44: D8387A78 00020185
	ds_store_2addr_b32 v133, v3, v4 offset0:124 offset1:126    // 00000019EB4C: D8387E7C 00040385
	s_and_saveexec_b32 s0, s6                                  // 00000019EB54: BE802006
	s_cbranch_execz 3                                          // 00000019EB58: BFA50003 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7268>
	s_waitcnt vmcnt(0)                                         // 00000019EB5C: BF8903F7
	ds_store_b32 v107, v41 offset:61952                        // 00000019EB60: D834F200 0000296B
	s_or_b32 exec_lo, exec_lo, s0                              // 00000019EB68: 8C7E007E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000019EB6C: BF890007
	s_barrier                                                  // 00000019EB70: BFBD0000
	buffer_gl0_inv                                             // 00000019EB74: E0AC0000 00000000
	ds_load_b32 v1, v107 offset:61952                          // 00000019EB7C: D8D8F200 0100006B
	s_waitcnt lgkmcnt(0)                                       // 00000019EB84: BF89FC07
	v_cmp_ne_u32_e32 vcc_lo, 1, v1                             // 00000019EB88: 7C9A0281
	s_cbranch_vccz 75                                          // 00000019EB8C: BFA3004B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x73bc>
	s_cmp_lg_u32 s29, s44                                      // 00000019EB90: BF072C1D
	s_cbranch_scc0 79                                          // 00000019EB94: BFA1004F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x73d4>
	s_cmp_lg_u32 s29, s45                                      // 00000019EB98: BF072D1D
	s_cbranch_scc0 110                                         // 00000019EB9C: BFA1006E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7458>
	s_cmp_lg_u32 s29, s46                                      // 00000019EBA0: BF072E1D
	s_cbranch_scc1 58543                                       // 00000019EBA4: BFA2E4AF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x564>
	s_branch 139                                               // 00000019EBA8: BFA0008B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x74d8>
	s_clause 0x1                                               // 00000019EBAC: BF850001
	global_load_b128 v[69:72], v[116:117], off offset:48       // 00000019EBB0: DC5E0030 457C0074
	global_load_b128 v[65:68], v[116:117], off offset:32       // 00000019EBB8: DC5E0020 417C0074
	ds_load_b128 v[73:76], v130 offset:32                      // 00000019EBC0: DBFC0020 49000082
	ds_load_b128 v[77:80], v130 offset:48                      // 00000019EBC8: DBFC0030 4D000082
	ds_load_b128 v[85:88], v130 offset:2352                    // 00000019EBD0: DBFC0930 55000082
	ds_load_b128 v[81:84], v130 offset:2336                    // 00000019EBD8: DBFC0920 51000082
	ds_load_b128 v[185:188], v130 offset:4656                  // 00000019EBE0: DBFC1230 B9000082
	ds_load_b128 v[181:184], v130 offset:4640                  // 00000019EBE8: DBFC1220 B5000082
	ds_load_b128 v[193:196], v130 offset:6960                  // 00000019EBF0: DBFC1B30 C1000082
	ds_load_b128 v[189:192], v130 offset:6944                  // 00000019EBF8: DBFC1B20 BD000082
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 00000019EC00: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[73:80], v[57:64]// 00000019EC04: CC404039 1CE69341
	s_waitcnt lgkmcnt(4)                                       // 00000019EC0C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[81:88], v[49:56]// 00000019EC10: CC404031 1CC6A341
	s_waitcnt lgkmcnt(2)                                       // 00000019EC18: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[181:188], v[41:48]// 00000019EC1C: CC404029 1CA76B41
	s_waitcnt lgkmcnt(0)                                       // 00000019EC24: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[65:72], v[189:196], v[33:40]// 00000019EC28: CC404021 1C877B41
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019EC30: 8C7E0F7E
	s_and_saveexec_b32 s15, s5                                 // 00000019EC34: BE8F2005
	s_cbranch_execz 64305                                      // 00000019EC38: BFA5FB31 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6000>
	ds_load_b128 v[65:68], v130 offset:64                      // 00000019EC3C: DBFC0040 41000082
	ds_load_b128 v[69:72], v130 offset:80                      // 00000019EC44: DBFC0050 45000082
	ds_load_b128 v[77:80], v130 offset:2384                    // 00000019EC4C: DBFC0950 4D000082
	ds_load_b128 v[73:76], v130 offset:2368                    // 00000019EC54: DBFC0940 49000082
	ds_load_b128 v[85:88], v130 offset:4688                    // 00000019EC5C: DBFC1250 55000082
	ds_load_b128 v[81:84], v130 offset:4672                    // 00000019EC64: DBFC1240 51000082
	ds_load_b128 v[185:188], v130 offset:6992                  // 00000019EC6C: DBFC1B50 B9000082
	ds_load_b128 v[181:184], v130 offset:6976                  // 00000019EC74: DBFC1B40 B5000082
	s_waitcnt vmcnt(2) lgkmcnt(6)                              // 00000019EC7C: BF890867
	v_wmma_f32_16x16x16_f16 v[57:64], v[97:104], v[65:72], v[57:64]// 00000019EC80: CC404039 1CE68361
	s_waitcnt lgkmcnt(4)                                       // 00000019EC88: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[97:104], v[73:80], v[49:56]// 00000019EC8C: CC404031 1CC69361
	s_waitcnt lgkmcnt(2)                                       // 00000019EC94: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[97:104], v[81:88], v[41:48]// 00000019EC98: CC404029 1CA6A361
	s_waitcnt lgkmcnt(0)                                       // 00000019ECA0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[97:104], v[181:188], v[33:40]// 00000019ECA4: CC404021 1C876B61
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019ECAC: 8C7E0F7E
	s_and_saveexec_b32 s15, s8                                 // 00000019ECB0: BE8F2008
	s_cbranch_execnz 64277                                     // 00000019ECB4: BFA6FB15 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x600c>
	s_branch 64306                                             // 00000019ECB8: BFA0FB32 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6084>
	buffer_gl1_inv                                             // 00000019ECBC: E0B00000 00000000
	buffer_gl0_inv                                             // 00000019ECC4: E0AC0000 00000000
	s_cmp_lg_u32 s29, s44                                      // 00000019ECCC: BF072C1D
	s_cbranch_scc1 65457                                       // 00000019ECD0: BFA2FFB1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7298>
	v_dual_mov_b32 v1, v110 :: v_dual_mov_b32 v4, v119         // 00000019ECD4: CA10016E 01040177
	v_dual_mov_b32 v3, v124 :: v_dual_mov_b32 v2, v111         // 00000019ECDC: CA10017C 0302016F
	s_mov_b32 s1, 0                                            // 00000019ECE4: BE810080
	s_nop 0                                                    // 00000019ECE8: BF800000
	s_nop 0                                                    // 00000019ECEC: BF800000
	s_nop 0                                                    // 00000019ECF0: BF800000
	s_nop 0                                                    // 00000019ECF4: BF800000
	s_nop 0                                                    // 00000019ECF8: BF800000
	s_nop 0                                                    // 00000019ECFC: BF800000
	ds_load_b32 v5, v3                                         // 00000019ED00: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 00000019ED08: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 00000019ED10: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000019ED14: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 00000019ED18: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 00000019ED20: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000019ED24: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 00000019ED28: DC6A0000 007C0501
	.long 0xd7000001                                           // 00000019ED30: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 00000019ED34: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 00000019ED3C: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000019ED44: 917E017E
	s_cbranch_execnz 65517                                     // 00000019ED48: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7400>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000019ED4C: 8C7E017E
	s_cmp_lg_u32 s29, s45                                      // 00000019ED50: BF072D1D
	s_cbranch_scc1 65426                                       // 00000019ED54: BFA2FF92 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x72a0>
	v_dual_mov_b32 v1, v112 :: v_dual_mov_b32 v4, v119         // 00000019ED58: CA100170 01040177
	v_dual_mov_b32 v3, v124 :: v_dual_mov_b32 v2, v113         // 00000019ED60: CA10017C 03020171
	s_mov_b32 s1, 0                                            // 00000019ED68: BE810080
	s_nop 0                                                    // 00000019ED6C: BF800000
	s_nop 0                                                    // 00000019ED70: BF800000
	s_nop 0                                                    // 00000019ED74: BF800000
	s_nop 0                                                    // 00000019ED78: BF800000
	s_nop 0                                                    // 00000019ED7C: BF800000
	ds_load_b32 v5, v3                                         // 00000019ED80: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 00000019ED88: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 00000019ED90: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000019ED94: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 00000019ED98: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 00000019EDA0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000019EDA4: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 00000019EDA8: DC6A0000 007C0501
	.long 0xd7000001                                           // 00000019EDB0: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 00000019EDB4: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 00000019EDBC: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000019EDC4: 917E017E
	s_cbranch_execnz 65517                                     // 00000019EDC8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7480>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000019EDCC: 8C7E017E
	s_cmp_lg_u32 s29, s46                                      // 00000019EDD0: BF072E1D
	s_cbranch_scc1 58403                                       // 00000019EDD4: BFA2E423 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x564>
	v_dual_mov_b32 v1, v114 :: v_dual_mov_b32 v4, v119         // 00000019EDD8: CA100172 01040177
	v_dual_mov_b32 v3, v124 :: v_dual_mov_b32 v2, v115         // 00000019EDE0: CA10017C 03020173
	s_mov_b32 s1, 0                                            // 00000019EDE8: BE810080
	s_nop 0                                                    // 00000019EDEC: BF800000
	s_nop 0                                                    // 00000019EDF0: BF800000
	s_nop 0                                                    // 00000019EDF4: BF800000
	s_nop 0                                                    // 00000019EDF8: BF800000
	s_nop 0                                                    // 00000019EDFC: BF800000
	ds_load_b32 v5, v3                                         // 00000019EE00: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 00000019EE08: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 00000019EE10: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000019EE14: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 00000019EE18: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 00000019EE20: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000019EE24: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 00000019EE28: DC6A0000 007C0501
	.long 0xd7000001                                           // 00000019EE30: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 00000019EE34: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 00000019EE3C: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000019EE44: 917E017E
	s_cbranch_execnz 65517                                     // 00000019EE48: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7500>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000019EE4C: 8C7E017E
	s_branch 58372                                             // 00000019EE50: BFA0E404 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x564>
	ds_load_b32 v65, v139                                      // 00000019EE54: D8D80000 4100008B
	s_waitcnt lgkmcnt(0)                                       // 00000019EE5C: BF89FC07
	v_fma_f32 v25, v25, v65, v57                               // 00000019EE60: D6130019 04E68319
	v_mad_u64_u32 v[65:66], null, 0x3000, v173, v[108:109]     // 00000019EE68: D6FE7C41 05B35AFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019EE74: BF870092
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 00000019EE78: 103232FF 3B800000
	v_bfe_u32 v57, v25, 16, 1                                  // 00000019EE80: D6100039 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019EE88: BF870001
	v_add3_u32 v25, v25, v57, 0x7fff                           // 00000019EE8C: D6550019 03FE7319 00007FFF
	global_store_d16_hi_b16 v[65:66], v25, off                 // 00000019EE98: DC960000 007C1941
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019EEA0: 8C7E0F7E
	s_and_saveexec_b32 s15, s14                                // 00000019EEA4: BE8F200E
	s_cbranch_execz 64586                                      // 00000019EEA8: BFA5FC4A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66d4>
	ds_load_b32 v25, v139 offset:8                             // 00000019EEAC: D8D80008 1900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019EEB4: BF89FC07
	v_fma_f32 v25, v26, v25, v58                               // 00000019EEB8: D6130019 04EA331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019EEC0: BF870121
	v_mul_f32_e32 v57, 0x3b800000, v25                         // 00000019EEC4: 107232FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v180, v[108:109]     // 00000019EECC: D6FE7C19 05B368FF 00003000
	v_bfe_u32 v58, v57, 16, 1                                  // 00000019EED8: D610003A 02052139
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019EEE0: BF870001
	v_add3_u32 v57, v57, v58, 0x7fff                           // 00000019EEE4: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[25:26], v57, off                 // 00000019EEF0: DC960000 007C3919
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019EEF8: 8C7E0F7E
	s_and_saveexec_b32 s15, s13                                // 00000019EEFC: BE8F200D
	s_cbranch_execz 64567                                      // 00000019EF00: BFA5FC37 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66e0>
	ds_load_b32 v25, v139 offset:16                            // 00000019EF04: D8D80010 1900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019EF0C: BF89FC07
	v_fma_f32 v25, v27, v25, v59                               // 00000019EF10: D6130019 04EE331B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019EF18: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 00000019EF1C: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v179, v[108:109]     // 00000019EF24: D6FE7C19 05B366FF 00003000
	v_bfe_u32 v57, v27, 16, 1                                  // 00000019EF30: D6100039 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019EF38: BF870001
	v_add3_u32 v27, v27, v57, 0x7fff                           // 00000019EF3C: D655001B 03FE731B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 00000019EF48: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019EF50: 8C7E0F7E
	s_and_saveexec_b32 s15, s12                                // 00000019EF54: BE8F200C
	s_cbranch_execz 64548                                      // 00000019EF58: BFA5FC24 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66ec>
	ds_load_b32 v25, v139 offset:24                            // 00000019EF5C: D8D80018 1900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019EF64: BF89FC07
	v_fma_f32 v25, v28, v25, v60                               // 00000019EF68: D6130019 04F2331C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019EF70: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 00000019EF74: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v178, v[108:109]     // 00000019EF7C: D6FE7C19 05B364FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000019EF88: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019EF90: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000019EF94: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 00000019EFA0: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019EFA8: 8C7E0F7E
	s_and_saveexec_b32 s15, s10                                // 00000019EFAC: BE8F200A
	s_cbranch_execz 64529                                      // 00000019EFB0: BFA5FC11 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66f8>
	ds_load_b32 v25, v139 offset:32                            // 00000019EFB4: D8D80020 1900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019EFBC: BF89FC07
	v_fma_f32 v25, v29, v25, v61                               // 00000019EFC0: D6130019 04F6331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019EFC8: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 00000019EFCC: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v177, v[108:109]     // 00000019EFD4: D6FE7C19 05B362FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000019EFE0: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019EFE8: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000019EFEC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 00000019EFF8: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F000: 8C7E0F7E
	s_and_saveexec_b32 s15, s1                                 // 00000019F004: BE8F2001
	s_cbranch_execz 64510                                      // 00000019F008: BFA5FBFE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6704>
	ds_load_b32 v25, v139 offset:40                            // 00000019F00C: D8D80028 1900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F014: BF89FC07
	v_fma_f32 v25, v30, v25, v62                               // 00000019F018: D6130019 04FA331E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F020: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 00000019F024: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v176, v[108:109]     // 00000019F02C: D6FE7C19 05B360FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000019F038: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F040: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000019F044: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 00000019F050: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F058: 8C7E0F7E
	s_and_saveexec_b32 s15, s9                                 // 00000019F05C: BE8F2009
	s_cbranch_execz 64491                                      // 00000019F060: BFA5FBEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6710>
	ds_load_b32 v25, v139 offset:48                            // 00000019F064: D8D80030 1900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F06C: BF89FC07
	v_fma_f32 v25, v31, v25, v63                               // 00000019F070: D6130019 04FE331F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F078: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 00000019F07C: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v175, v[108:109]     // 00000019F084: D6FE7C19 05B35EFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000019F090: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F098: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000019F09C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 00000019F0A8: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F0B0: 8C7E0F7E
	s_and_saveexec_b32 s15, s0                                 // 00000019F0B4: BE8F2000
	s_cbranch_execz 64472                                      // 00000019F0B8: BFA5FBD8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x671c>
	ds_load_b32 v25, v139 offset:56                            // 00000019F0BC: D8D80038 1900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F0C4: BF89FC07
	v_fma_f32 v25, v32, v25, v64                               // 00000019F0C8: D6130019 05023320
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F0D0: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 00000019F0D4: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v174, v[108:109]     // 00000019F0DC: D6FE7C19 05B35CFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000019F0E8: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F0F0: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000019F0F4: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 00000019F100: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F108: 8C7E0F7E
	s_and_saveexec_b32 s15, s11                                // 00000019F10C: BE8F200B
	s_cbranch_execz 64453                                      // 00000019F110: BFA5FBC5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6728>
	ds_load_b32 v25, v139                                      // 00000019F114: D8D80000 1900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F11C: BF89FC07
	v_fma_f32 v9, v9, v25, v49                                 // 00000019F120: D6130009 04C63309
	v_mad_u64_u32 v[25:26], null, 0x3000, v173, v[108:109]     // 00000019F128: D6FE7C19 05B35AFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019F134: BF870092
	v_mul_f32_e32 v9, 0x3b800000, v9                           // 00000019F138: 101212FF 3B800000
	v_bfe_u32 v27, v9, 16, 1                                   // 00000019F140: D610001B 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F148: BF870001
	v_add3_u32 v9, v9, v27, 0x7fff                             // 00000019F14C: D6550009 03FE3709 00007FFF
	global_store_d16_hi_b16 v[25:26], v9, off offset:32        // 00000019F158: DC960020 007C0919
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F160: 8C7E0F7E
	s_and_saveexec_b32 s15, s14                                // 00000019F164: BE8F200E
	s_cbranch_execz 64434                                      // 00000019F168: BFA5FBB2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6734>
	ds_load_b32 v9, v139 offset:8                              // 00000019F16C: D8D80008 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F174: BF89FC07
	v_fma_f32 v9, v10, v9, v50                                 // 00000019F178: D6130009 04CA130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F180: BF870121
	v_mul_f32_e32 v25, 0x3b800000, v9                          // 00000019F184: 103212FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v180, v[108:109]      // 00000019F18C: D6FE7C09 05B368FF 00003000
	v_bfe_u32 v26, v25, 16, 1                                  // 00000019F198: D610001A 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F1A0: BF870001
	v_add3_u32 v25, v25, v26, 0x7fff                           // 00000019F1A4: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[9:10], v25, off offset:32        // 00000019F1B0: DC960020 007C1909
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F1B8: 8C7E0F7E
	s_and_saveexec_b32 s15, s13                                // 00000019F1BC: BE8F200D
	s_cbranch_execz 64415                                      // 00000019F1C0: BFA5FB9F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6740>
	ds_load_b32 v9, v139 offset:16                             // 00000019F1C4: D8D80010 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F1CC: BF89FC07
	v_fma_f32 v9, v11, v9, v51                                 // 00000019F1D0: D6130009 04CE130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F1D8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000019F1DC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v179, v[108:109]      // 00000019F1E4: D6FE7C09 05B366FF 00003000
	v_bfe_u32 v25, v11, 16, 1                                  // 00000019F1F0: D6100019 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F1F8: BF870001
	v_add3_u32 v11, v11, v25, 0x7fff                           // 00000019F1FC: D655000B 03FE330B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 00000019F208: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F210: 8C7E0F7E
	s_and_saveexec_b32 s15, s12                                // 00000019F214: BE8F200C
	s_cbranch_execz 64396                                      // 00000019F218: BFA5FB8C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x674c>
	ds_load_b32 v9, v139 offset:24                             // 00000019F21C: D8D80018 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F224: BF89FC07
	v_fma_f32 v9, v12, v9, v52                                 // 00000019F228: D6130009 04D2130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F230: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000019F234: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v178, v[108:109]      // 00000019F23C: D6FE7C09 05B364FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000019F248: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F250: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000019F254: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 00000019F260: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F268: 8C7E0F7E
	s_and_saveexec_b32 s15, s10                                // 00000019F26C: BE8F200A
	s_cbranch_execz 64377                                      // 00000019F270: BFA5FB79 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6758>
	ds_load_b32 v9, v139 offset:32                             // 00000019F274: D8D80020 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F27C: BF89FC07
	v_fma_f32 v9, v13, v9, v53                                 // 00000019F280: D6130009 04D6130D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F288: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000019F28C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v177, v[108:109]      // 00000019F294: D6FE7C09 05B362FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000019F2A0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F2A8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000019F2AC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 00000019F2B8: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F2C0: 8C7E0F7E
	s_and_saveexec_b32 s15, s1                                 // 00000019F2C4: BE8F2001
	s_cbranch_execz 64358                                      // 00000019F2C8: BFA5FB66 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6764>
	ds_load_b32 v9, v139 offset:40                             // 00000019F2CC: D8D80028 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F2D4: BF89FC07
	v_fma_f32 v9, v14, v9, v54                                 // 00000019F2D8: D6130009 04DA130E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F2E0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000019F2E4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v176, v[108:109]      // 00000019F2EC: D6FE7C09 05B360FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000019F2F8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F300: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000019F304: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 00000019F310: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F318: 8C7E0F7E
	s_and_saveexec_b32 s15, s9                                 // 00000019F31C: BE8F2009
	s_cbranch_execz 64339                                      // 00000019F320: BFA5FB53 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6770>
	ds_load_b32 v9, v139 offset:48                             // 00000019F324: D8D80030 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F32C: BF89FC07
	v_fma_f32 v9, v15, v9, v55                                 // 00000019F330: D6130009 04DE130F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F338: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000019F33C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v175, v[108:109]      // 00000019F344: D6FE7C09 05B35EFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000019F350: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F358: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000019F35C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 00000019F368: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F370: 8C7E0F7E
	s_and_saveexec_b32 s15, s0                                 // 00000019F374: BE8F2000
	s_cbranch_execz 64320                                      // 00000019F378: BFA5FB40 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x677c>
	ds_load_b32 v9, v139 offset:56                             // 00000019F37C: D8D80038 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F384: BF89FC07
	v_fma_f32 v9, v16, v9, v56                                 // 00000019F388: D6130009 04E21310
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F390: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000019F394: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v174, v[108:109]      // 00000019F39C: D6FE7C09 05B35CFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000019F3A8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F3B0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000019F3B4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 00000019F3C0: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F3C8: 8C7E0F7E
	s_and_saveexec_b32 s15, s11                                // 00000019F3CC: BE8F200B
	s_cbranch_execz 64301                                      // 00000019F3D0: BFA5FB2D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6788>
	ds_load_b32 v9, v139                                       // 00000019F3D4: D8D80000 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F3DC: BF89FC07
	v_fma_f32 v9, v17, v9, v41                                 // 00000019F3E0: D6130009 04A61311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F3E8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000019F3EC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v173, v[108:109]      // 00000019F3F4: D6FE7C09 05B35AFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000019F400: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F408: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000019F40C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 00000019F418: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F420: 8C7E0F7E
	s_and_saveexec_b32 s15, s14                                // 00000019F424: BE8F200E
	s_cbranch_execz 64282                                      // 00000019F428: BFA5FB1A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6794>
	ds_load_b32 v9, v139 offset:8                              // 00000019F42C: D8D80008 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F434: BF89FC07
	v_fma_f32 v9, v18, v9, v42                                 // 00000019F438: D6130009 04AA1312
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F440: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000019F444: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v180, v[108:109]      // 00000019F44C: D6FE7C09 05B368FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000019F458: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F460: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000019F464: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 00000019F470: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F478: 8C7E0F7E
	s_and_saveexec_b32 s15, s13                                // 00000019F47C: BE8F200D
	s_cbranch_execz 64263                                      // 00000019F480: BFA5FB07 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67a0>
	ds_load_b32 v9, v139 offset:16                             // 00000019F484: D8D80010 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F48C: BF89FC07
	v_fma_f32 v9, v19, v9, v43                                 // 00000019F490: D6130009 04AE1313
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F498: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000019F49C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v179, v[108:109]      // 00000019F4A4: D6FE7C09 05B366FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000019F4B0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F4B8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000019F4BC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 00000019F4C8: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F4D0: 8C7E0F7E
	s_and_saveexec_b32 s15, s12                                // 00000019F4D4: BE8F200C
	s_cbranch_execz 64244                                      // 00000019F4D8: BFA5FAF4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67ac>
	ds_load_b32 v9, v139 offset:24                             // 00000019F4DC: D8D80018 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F4E4: BF89FC07
	v_fma_f32 v9, v20, v9, v44                                 // 00000019F4E8: D6130009 04B21314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F4F0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000019F4F4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v178, v[108:109]      // 00000019F4FC: D6FE7C09 05B364FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000019F508: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F510: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000019F514: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 00000019F520: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F528: 8C7E0F7E
	s_and_saveexec_b32 s15, s10                                // 00000019F52C: BE8F200A
	s_cbranch_execz 64225                                      // 00000019F530: BFA5FAE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67b8>
	ds_load_b32 v9, v139 offset:32                             // 00000019F534: D8D80020 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F53C: BF89FC07
	v_fma_f32 v9, v21, v9, v45                                 // 00000019F540: D6130009 04B61315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F548: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000019F54C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v177, v[108:109]      // 00000019F554: D6FE7C09 05B362FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000019F560: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F568: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000019F56C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 00000019F578: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F580: 8C7E0F7E
	s_and_saveexec_b32 s15, s1                                 // 00000019F584: BE8F2001
	s_cbranch_execz 64206                                      // 00000019F588: BFA5FACE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67c4>
	ds_load_b32 v9, v139 offset:40                             // 00000019F58C: D8D80028 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F594: BF89FC07
	v_fma_f32 v9, v22, v9, v46                                 // 00000019F598: D6130009 04BA1316
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F5A0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000019F5A4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v176, v[108:109]      // 00000019F5AC: D6FE7C09 05B360FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000019F5B8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F5C0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000019F5C4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 00000019F5D0: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F5D8: 8C7E0F7E
	s_and_saveexec_b32 s15, s9                                 // 00000019F5DC: BE8F2009
	s_cbranch_execz 64187                                      // 00000019F5E0: BFA5FABB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67d0>
	ds_load_b32 v9, v139 offset:48                             // 00000019F5E4: D8D80030 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F5EC: BF89FC07
	v_fma_f32 v9, v23, v9, v47                                 // 00000019F5F0: D6130009 04BE1317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F5F8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000019F5FC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v175, v[108:109]      // 00000019F604: D6FE7C09 05B35EFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000019F610: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F618: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000019F61C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 00000019F628: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F630: 8C7E0F7E
	s_and_saveexec_b32 s15, s0                                 // 00000019F634: BE8F2000
	s_cbranch_execz 64168                                      // 00000019F638: BFA5FAA8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67dc>
	ds_load_b32 v9, v139 offset:56                             // 00000019F63C: D8D80038 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F644: BF89FC07
	v_fma_f32 v9, v24, v9, v48                                 // 00000019F648: D6130009 04C21318
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F650: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000019F654: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v174, v[108:109]      // 00000019F65C: D6FE7C09 05B35CFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000019F668: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F670: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000019F674: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 00000019F680: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F688: 8C7E0F7E
	s_and_saveexec_b32 s15, s11                                // 00000019F68C: BE8F200B
	s_cbranch_execz 64149                                      // 00000019F690: BFA5FA95 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67e8>
	ds_load_b32 v9, v139                                       // 00000019F694: D8D80000 0900008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F69C: BF89FC07
	v_fma_f32 v1, v1, v9, v33                                  // 00000019F6A0: D6130001 04861301
	v_mad_u64_u32 v[9:10], null, 0x3000, v173, v[108:109]      // 00000019F6A8: D6FE7C09 05B35AFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019F6B4: BF870092
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 00000019F6B8: 100202FF 3B800000
	v_bfe_u32 v11, v1, 16, 1                                   // 00000019F6C0: D610000B 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F6C8: BF870001
	v_add3_u32 v1, v1, v11, 0x7fff                             // 00000019F6CC: D6550001 03FE1701 00007FFF
	global_store_d16_hi_b16 v[9:10], v1, off offset:96         // 00000019F6D8: DC960060 007C0109
	s_or_b32 exec_lo, exec_lo, s15                             // 00000019F6E0: 8C7E0F7E
	s_and_saveexec_b32 s11, s14                                // 00000019F6E4: BE8B200E
	s_cbranch_execz 64130                                      // 00000019F6E8: BFA5FA82 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67f4>
	ds_load_b32 v1, v139 offset:8                              // 00000019F6EC: D8D80008 0100008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F6F4: BF89FC07
	v_fma_f32 v1, v2, v1, v34                                  // 00000019F6F8: D6130001 048A0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F700: BF870121
	v_mul_f32_e32 v9, 0x3b800000, v1                           // 00000019F704: 101202FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v180, v[108:109]       // 00000019F70C: D6FE7C01 05B368FF 00003000
	v_bfe_u32 v10, v9, 16, 1                                   // 00000019F718: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F720: BF870001
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000019F724: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[1:2], v9, off offset:96          // 00000019F730: DC960060 007C0901
	s_or_b32 exec_lo, exec_lo, s11                             // 00000019F738: 8C7E0B7E
	s_and_saveexec_b32 s11, s13                                // 00000019F73C: BE8B200D
	s_cbranch_execz 64111                                      // 00000019F740: BFA5FA6F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6800>
	ds_load_b32 v1, v139 offset:16                             // 00000019F744: D8D80010 0100008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F74C: BF89FC07
	v_fma_f32 v1, v3, v1, v35                                  // 00000019F750: D6130001 048E0303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F758: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 00000019F75C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v179, v[108:109]       // 00000019F764: D6FE7C01 05B366FF 00003000
	v_bfe_u32 v9, v3, 16, 1                                    // 00000019F770: D6100009 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F778: BF870001
	v_add3_u32 v3, v3, v9, 0x7fff                              // 00000019F77C: D6550003 03FE1303 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 00000019F788: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s11                             // 00000019F790: 8C7E0B7E
	s_and_saveexec_b32 s11, s12                                // 00000019F794: BE8B200C
	s_cbranch_execz 64092                                      // 00000019F798: BFA5FA5C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x680c>
	ds_load_b32 v1, v139 offset:24                             // 00000019F79C: D8D80018 0100008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F7A4: BF89FC07
	v_fma_f32 v1, v4, v1, v36                                  // 00000019F7A8: D6130001 04920304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F7B0: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 00000019F7B4: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v178, v[108:109]       // 00000019F7BC: D6FE7C01 05B364FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 00000019F7C8: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F7D0: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000019F7D4: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 00000019F7E0: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s11                             // 00000019F7E8: 8C7E0B7E
	s_and_saveexec_b32 s11, s10                                // 00000019F7EC: BE8B200A
	s_cbranch_execz 64073                                      // 00000019F7F0: BFA5FA49 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6818>
	ds_load_b32 v1, v139 offset:32                             // 00000019F7F4: D8D80020 0100008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F7FC: BF89FC07
	v_fma_f32 v1, v5, v1, v37                                  // 00000019F800: D6130001 04960305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F808: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 00000019F80C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v177, v[108:109]       // 00000019F814: D6FE7C01 05B362FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 00000019F820: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F828: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000019F82C: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 00000019F838: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s11                             // 00000019F840: 8C7E0B7E
	s_and_saveexec_b32 s10, s1                                 // 00000019F844: BE8A2001
	s_cbranch_execz 64054                                      // 00000019F848: BFA5FA36 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6824>
	ds_load_b32 v1, v139 offset:40                             // 00000019F84C: D8D80028 0100008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F854: BF89FC07
	v_fma_f32 v1, v6, v1, v38                                  // 00000019F858: D6130001 049A0306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F860: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 00000019F864: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v176, v[108:109]       // 00000019F86C: D6FE7C01 05B360FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 00000019F878: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F880: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000019F884: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 00000019F890: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s10                             // 00000019F898: 8C7E0A7E
	s_and_saveexec_b32 s1, s9                                  // 00000019F89C: BE812009
	s_cbranch_execz 64035                                      // 00000019F8A0: BFA5FA23 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6830>
	ds_load_b32 v1, v139 offset:48                             // 00000019F8A4: D8D80030 0100008B
	s_waitcnt lgkmcnt(0)                                       // 00000019F8AC: BF89FC07
	v_fma_f32 v1, v7, v1, v39                                  // 00000019F8B0: D6130001 049E0307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F8B8: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 00000019F8BC: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v175, v[108:109]       // 00000019F8C4: D6FE7C01 05B35EFF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 00000019F8D0: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019F8D8: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000019F8DC: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 00000019F8E8: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s1                              // 00000019F8F0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000019F8F4: BE812000
	s_cbranch_execnz 64016                                     // 00000019F8F8: BFA6FA10 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x683c>
	s_branch 64033                                             // 00000019F8FC: BFA0FA21 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6884>
	v_dual_mov_b32 v1, s34 :: v_dual_mov_b32 v2, s35           // 00000019F900: CA100022 01020023
	v_mov_b32_e32 v6, v119                                     // 00000019F908: 7E0C0377
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019F90C: BF870092
	.long 0xd7006a00                                           // 00000019F910: D7006A00
	v_cndmask_b32_e32 v0, v1, v18, vcc_lo                      // 00000019F914: 02002501
	v_add_co_ci_u32_e64 v1, null, s19, v2, vcc_lo              // 00000019F918: D5207C01 01AA0413
	s_add_u32 s0, s58, s20                                     // 00000019F920: 8000143A
	s_addc_u32 s1, s33, s21                                    // 00000019F924: 82011521
	.long 0xd7006a00                                           // 00000019F928: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000019F92C: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000019F930: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000019F934: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000019F93C: BE810080
	.long 0xd7006a00                                           // 00000019F940: D7006A00
	v_cndmask_b32_e32 v1, v0, v106, vcc_lo                     // 00000019F944: 0202D500
	v_add_co_ci_u32_e64 v1, null, v1, v107, vcc_lo             // 00000019F948: D5207C01 01AAD701
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019F950: BF870092
	.long 0xd7006a00                                           // 00000019F954: D7006A00
	v_cndmask_b32_e32 v1, v0, v118, vcc_lo                     // 00000019F958: 0202ED00
	v_add_co_ci_u32_e64 v1, null, v1, v129, vcc_lo             // 00000019F95C: D5207C01 01AB0301
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019F964: BF870092
	.long 0xd7006a00                                           // 00000019F968: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000019F96C: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000019F970: D5207C01 01AA0211
	s_nop 0                                                    // 00000019F978: BF800000
	s_nop 0                                                    // 00000019F97C: BF800000
	ds_load_b32 v2, v124                                       // 00000019F980: D8D80000 0200007C
	v_add_nc_u32_e32 v6, 0x80, v6                              // 00000019F988: 4A0C0CFF 00000080
	v_add_nc_u32_e32 v124, 8, v124                             // 00000019F990: 4AF8F888
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000019F994: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v6                        // 00000019F998: 7C920CFF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 00000019F9A0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000019F9A4: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 00000019F9A8: DC6A0000 007C0200
	.long 0xd7000000                                           // 00000019F9B0: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 00000019F9B4: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000019F9BC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000019F9C4: 917E017E
	s_cbranch_execnz 65517                                     // 00000019F9C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi2ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8080>
	s_nop 0                                                    // 00000019F9CC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000019F9D0: BFB60003
	s_endpgm                                                   // 00000019F9D4: BFB00000
		...

