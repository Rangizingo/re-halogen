00000000001aca00 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE():
	s_load_b256 s[16:23], s[0:1], 0x38                         // 0000001ACA00: F40C0400 F8000038
	s_lshl_b32 s6, s3, 6                                       // 0000001ACA08: 84068603
	s_ashr_i32 s3, s2, 31                                      // 0000001ACA0C: 86039F02
	s_ashr_i32 s7, s6, 31                                      // 0000001ACA10: 86079F06
	v_and_b32_e32 v1, 63, v0                                   // 0000001ACA14: 360200BF
	v_mov_b32_e32 v5, v0                                       // 0000001ACA18: 7E0A0300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001ACA1C: BF8704D2
	v_lshlrev_b32_e32 v3, 2, v1                                // 0000001ACA20: 30060282
	v_mul_u32_u24_e32 v2, 0x210, v1                            // 0000001ACA24: 160402FF 00000210
	s_waitcnt lgkmcnt(0)                                       // 0000001ACA2C: BF89FC07
	s_load_b32 s4, s[18:19], null                              // 0000001ACA30: F4000109 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000001ACA38: 84928214
	s_add_u32 s5, s16, s18                                     // 0000001ACA3C: 80051210
	s_addc_u32 s8, s17, s19                                    // 0000001ACA40: 82081311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000001ACA44: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ACA48: BF870009
	s_add_u32 s5, s5, s20                                      // 0000001ACA4C: 80051405
	s_addc_u32 s8, s8, s21                                     // 0000001ACA50: 82081508
	s_waitcnt lgkmcnt(0)                                       // 0000001ACA54: BF89FC07
	s_mul_i32 s33, s4, 0x9000000                               // 0000001ACA58: 9621FF04 09000000
	s_mul_hi_i32 s15, s4, 0x9000000                            // 0000001ACA60: 970FFF04 09000000
	s_add_u32 s4, s5, s33                                      // 0000001ACA68: 80042105
	s_addc_u32 s5, s8, s15                                     // 0000001ACA6C: 82050F08
	s_lshl_b64 s[34:35], s[6:7], 2                             // 0000001ACA70: 84A28206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001ACA74: BF8700B9
	s_add_u32 s4, s4, s34                                      // 0000001ACA78: 80042204
	s_addc_u32 s5, s5, s35                                     // 0000001ACA7C: 82052305
	.long 0xd7000403                                           // 0000001ACA80: D7000403
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000001ACA84: 02020604
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 0000001ACA88: D5207C04 00110005
	s_mov_b32 s4, 0                                            // 0000001ACA90: BE840080
	s_nop 0                                                    // 0000001ACA94: BF800000
	s_nop 0                                                    // 0000001ACA98: BF800000
	s_nop 0                                                    // 0000001ACA9C: BF800000
	s_nop 0                                                    // 0000001ACAA0: BF800000
	s_nop 0                                                    // 0000001ACAA4: BF800000
	s_nop 0                                                    // 0000001ACAA8: BF800000
	s_nop 0                                                    // 0000001ACAAC: BF800000
	s_nop 0                                                    // 0000001ACAB0: BF800000
	s_nop 0                                                    // 0000001ACAB4: BF800000
	s_nop 0                                                    // 0000001ACAB8: BF800000
	s_nop 0                                                    // 0000001ACABC: BF800000
	v_lshrrev_b32_e32 v8, 6, v5                                // 0000001ACAC0: 32100A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001ACAC4: BF870121
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000001ACAC8: 300C1089
	v_lshl_add_u32 v8, v8, 2, v2                               // 0000001ACACC: D6460008 04090508
	.long 0xd7006a06                                           // 0000001ACAD4: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000001ACAD8: 02020D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001ACADC: BF8700D1
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000001ACAE0: D5207C07 01AA0880
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v5                        // 0000001ACAE8: 7C920AFF 00001F7F
	global_load_b32 v6, v[6:7], off                            // 0000001ACAF0: DC520000 067C0006
	v_add_nc_u32_e32 v7, 0x80, v5                              // 0000001ACAF8: 4A0E0AFF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 0000001ACB00: 8C04046A
	v_mov_b32_e32 v5, v7                                       // 0000001ACB04: 7E0A0307
	s_waitcnt vmcnt(0)                                         // 0000001ACB08: BF8903F7
	ds_store_b32 v8, v6                                        // 0000001ACB0C: D8340000 00000608
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001ACB14: 917E047E
	s_cbranch_execnz 65513                                     // 0000001ACB18: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001ACB1C: 8C7E047E
	s_load_b32 s58, s[0:1], 0x58                               // 0000001ACB20: F4000E80 F8000058
	v_or_b32_e32 v119, 0xffffff80, v0                          // 0000001ACB28: 38EE00FF FFFFFF80
	v_lshlrev_b32_e32 v5, 3, v0                                // 0000001ACB30: 300A0083
	v_lshlrev_b32_e32 v118, 2, v1                              // 0000001ACB34: 30EC0282
	v_mul_u32_u24_e32 v3, 0x210, v1                            // 0000001ACB38: 160602FF 00000210
	v_lshrrev_b32_e32 v4, 4, v0                                // 0000001ACB40: 32080084
	s_waitcnt lgkmcnt(0)                                       // 0000001ACB44: BF89FC07
	s_barrier                                                  // 0000001ACB48: BFBD0000
	s_mov_b32 s4, 0                                            // 0000001ACB4C: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000001ACB50: BF89FC07
	s_cmp_gt_i32 s58, 0                                        // 0000001ACB54: BF02803A
	s_cbranch_scc1 14                                          // 0000001ACB58: BFA2000E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x194>
	v_dual_mov_b32 v107, 0 :: v_dual_and_b32 v106, 0x200, v5   // 0000001ACB5C: CA240080 6B6A0AFF 00000200
	v_mov_b32_e32 v1, s34                                      // 0000001ACB68: 7E020222
	v_or_b32_e32 v6, 0xffffff80, v0                            // 0000001ACB6C: 380C00FF FFFFFF80
	v_and_or_b32 v123, v4, 4, v3                               // 0000001ACB74: D657007B 040D0904
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001ACB7C: BF870004
	v_dual_mov_b32 v129, v107 :: v_dual_mov_b32 v2, s35        // 0000001ACB80: CA10016B 81020023
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 0000001ACB88: 916A047E
	s_cbranch_vccz 1                                           // 0000001ACB8C: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x194>
	s_branch 8046                                              // 0000001ACB90: BFA01F6E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7f4c>
	s_clause 0x2                                               // 0000001ACB94: BF850002
	s_load_b256 s[24:31], s[0:1], 0x60                         // 0000001ACB98: F40C0600 F8000060
	s_load_b64 s[56:57], s[0:1], null                          // 0000001ACBA0: F4040E00 F8000000
	s_load_b128 s[52:55], s[0:1], 0x18                         // 0000001ACBA8: F4080D00 F8000018
	s_lshl_b64 s[8:9], s[2:3], 2                               // 0000001ACBB0: 84888202
	s_mul_hi_i32 s10, s2, 0x55555556                           // 0000001ACBB4: 970AFF02 55555556
	v_dual_mov_b32 v107, 0 :: v_dual_lshlrev_b32 v2, 2, v0     // 0000001ACBBC: CA220080 6B020082
	v_lshlrev_b32_e32 v6, 1, v0                                // 0000001ACBC4: 300C0081
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000001ACBC8: 32020085
	v_bfe_u32 v7, v0, 4, 1                                     // 0000001ACBCC: D6100007 02050900
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001ACBD4: BF870004
	v_or_b32_e32 v120, 0xf000, v2                              // 0000001ACBD8: 38F004FF 0000F000
	v_add_nc_u32_e32 v121, 0xf100, v2                          // 0000001ACBE0: 4AF204FF 0000F100
	v_mov_b32_e32 v129, v107                                   // 0000001ACBE8: 7F02036B
	v_mul_u32_u24_e32 v8, 0x2100, v1                           // 0000001ACBEC: 161002FF 00002100
	s_load_b256 s[44:51], s[0:1], 0x80                         // 0000001ACBF4: F40C0B00 F8000080
	s_mov_b32 s13, 0xcc00                                      // 0000001ACBFC: BE8D00FF 0000CC00
	s_load_b64 s[0:1], s[0:1], 0xa0                            // 0000001ACC04: F4040000 F80000A0
	v_and_b32_e32 v106, 0x200, v5                              // 0000001ACC0C: 36D40AFF 00000200
	.long 0xd44c0004                                           // 0000001ACC14: D44C0004
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 0000001ACC18: 020200C0
	.long 0xd4490005                                           // 0000001ACC1C: D4490005
	v_cndmask_b32_e32 v1, 63, v0, vcc_lo                       // 0000001ACC20: 020200BF
	v_and_or_b32 v123, v4, 4, v3                               // 0000001ACC24: D657007B 040D0904
	s_waitcnt lgkmcnt(0)                                       // 0000001ACC2C: BF89FC07
	s_add_u32 s59, s30, s8                                     // 0000001ACC30: 803B081E
	s_addc_u32 s60, s31, s9                                    // 0000001ACC34: 823C091F
	s_lshr_b32 s9, s10, 31                                     // 0000001ACC38: 85099F0A
	s_add_i32 s8, s58, 63                                      // 0000001ACC3C: 8108BF3A
	s_add_i32 s10, s10, s9                                     // 0000001ACC40: 810A090A
	s_add_i32 s62, s58, -1                                     // 0000001ACC44: 813EC13A
	s_lshr_b32 s63, s8, 6                                      // 0000001ACC48: 853F8608
	s_lshl_b32 s8, s10, 7                                      // 0000001ACC4C: 8408870A
	s_mul_i32 s10, s62, 0x5000                                 // 0000001ACC50: 960AFF3E 00005000
	s_add_i32 s61, s2, 0xbd0                                   // 0000001ACC58: 813DFF02 00000BD0
	s_mul_hi_u32 s11, s62, 0x5000                              // 0000001ACC60: 968BFF3E 00005000
	s_ashr_i32 s9, s8, 31                                      // 0000001ACC68: 86099F08
	s_add_u32 s10, s56, s10                                    // 0000001ACC6C: 800A0A38
	s_addc_u32 s11, s57, s11                                   // 0000001ACC70: 820B0B39
	s_lshl_b64 s[30:31], s[8:9], 1                             // 0000001ACC74: 849E8108
	s_mul_hi_u32 s8, s62, 0xc0                                 // 0000001ACC78: 9688FF3E 000000C0
	s_add_u32 s9, s10, s30                                     // 0000001ACC80: 80091E0A
	s_addc_u32 s10, s11, s31                                   // 0000001ACC84: 820A1F0B
	.long 0xd7000902                                           // 0000001ACC88: D7000902
	v_cndmask_b32_e32 v1, s9, v6, vcc_lo                       // 0000001ACC8C: 02020C09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001ACC90: BF8700B1
	v_add_co_ci_u32_e64 v6, null, s10, 0, s9                   // 0000001ACC94: D5207C06 0025000A
	s_mul_i32 s9, s62, 0xc0                                    // 0000001ACC9C: 9609FF3E 000000C0
	.long 0xd7006a7a                                           // 0000001ACCA4: D7006A7A
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 0000001ACCA8: 020204FF 00001000
	v_add_co_ci_u32_e64 v124, null, 0, v6, vcc_lo              // 0000001ACCB0: D5207C7C 01AA0C80
	v_dual_mov_b32 v141, 0xf004 :: v_dual_lshlrev_b32 v2, 4, v1// 0000001ACCB8: CA2200FF 8D020284 0000F004
	v_dual_mov_b32 v143, 0xf014 :: v_dual_and_b32 v6, 15, v0   // 0000001ACCC4: CA2400FF 8F06008F 0000F014
	s_add_u32 s64, s59, s9                                     // 0000001ACCD0: 8040093B
	s_addc_u32 s65, s60, s8                                    // 0000001ACCD4: 8241083C
	s_add_u32 s11, s54, s34                                    // 0000001ACCD8: 800B2236
	s_addc_u32 s12, s55, s35                                   // 0000001ACCDC: 820C2337
	s_lshl_b32 s8, s2, 7                                       // 0000001ACCE0: 84088702
	v_or_b32_e32 v126, v2, v6                                  // 0000001ACCE4: 38FC0D02
	v_or_b32_e32 v130, v2, v7                                  // 0000001ACCE8: 39040F02
	v_mad_u32_u24 v2, 0x210, v6, v8                            // 0000001ACCEC: D60B0002 04220CFF 00000210
	s_ashr_i32 s9, s8, 31                                      // 0000001ACCF8: 86099F08
	v_dual_mov_b32 v145, 0xf024 :: v_dual_lshlrev_b32 v8, 2, v6// 0000001ACCFC: CA2200FF 91080C82 0000F024
	s_lshl_b64 s[8:9], s[8:9], 1                               // 0000001ACD08: 84888108
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001ACD0C: BF870002
	v_lshl_or_b32 v133, v7, 2, v2                              // 0000001ACD10: D6560085 04090507
	s_add_u32 s8, s22, s8                                      // 0000001ACD18: 80080816
	v_dual_mov_b32 v147, 0xf034 :: v_dual_lshlrev_b32 v2, 7, v126// 0000001ACD1C: CA2200FF 9302FC87 0000F034
	s_addc_u32 s9, s23, s9                                     // 0000001ACD28: 82090917
	s_lshl_b64 s[6:7], s[6:7], 1                               // 0000001ACD2C: 84868106
	v_mad_u32_u24 v128, 0x90, v6, s13                          // 0000001ACD30: D60B0080 00360CFF 00000090
	s_add_u32 s8, s8, s6                                       // 0000001ACD3C: 80080608
	.long 0xd7000686                                           // 0000001ACD40: D7000686
	v_cndmask_b32_e32 v1, s11, v8, vcc_lo                      // 0000001ACD44: 0202100B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001ACD48: BF870001
	v_add_co_ci_u32_e64 v135, null, s12, 0, s6                 // 0000001ACD4C: D5207C87 0019000C
	.long 0xd7000689                                           // 0000001ACD54: D7000689
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 0000001ACD58: 0202041C
	v_dual_mov_b32 v149, 0xf044 :: v_dual_lshlrev_b32 v2, 1, v6// 0000001ACD5C: CA2200FF 95020C81 0000F044
	s_addc_u32 s9, s9, s7                                      // 0000001ACD68: 82090709
	v_mad_u32_u24 v131, 0x900, v1, v128                        // 0000001ACD6C: D60B0083 060202FF 00000900
	v_add_co_ci_u32_e64 v138, null, s29, 0, s6                 // 0000001ACD78: D5207C8A 0019001D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ACD80: BF870093
	.long 0xd700086c                                           // 0000001ACD84: D700086C
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000001ACD88: 02020408
	v_add_co_ci_u32_e64 v109, null, s9, 0, s8                  // 0000001ACD8C: D5207C6D 00210009
	s_add_u32 s8, s34, s20                                     // 0000001ACD94: 80081422
	.long 0xd44d0006                                           // 0000001ACD98: D44D0006
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000001ACD9C: 02020280
	s_addc_u32 s9, s35, s21                                    // 0000001ACDA0: 82091523
	.long 0xd7000801                                           // 0000001ACDA4: D7000801
	v_cndmask_b32_e32 v1, s8, v106, vcc_lo                     // 0000001ACDA8: 0202D408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001ACDAC: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s9, 0, s8                    // 0000001ACDB0: D5207C02 00210009
	s_movk_i32 s10, 0x90                                       // 0000001ACDB8: B00A0090
	.long 0xd7006a01                                           // 0000001ACDBC: D7006A01
	v_cndmask_b32_e32 v1, v1, v118, vcc_lo                     // 0000001ACDC0: 0202ED01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000001ACDC4: D5207C02 01AA0480
	v_mad_u32_u24 v125, v0, s10, 0x8400                        // 0000001ACDCC: D60B007D 03FC1500 00008400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ACDD8: BF870093
	.long 0xd7006a6e                                           // 0000001ACDDC: D7006A6E
	v_cndmask_b32_e32 v1, s48, v1, vcc_lo                      // 0000001ACDE0: 02020230
	v_add_co_ci_u32_e64 v111, null, s49, v2, vcc_lo            // 0000001ACDE4: D5207C6F 01AA0431
	.long 0xd7006a70                                           // 0000001ACDEC: D7006A70
	v_cndmask_b32_e32 v1, s50, v1, vcc_lo                      // 0000001ACDF0: 02020232
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001ACDF4: BF870001
	v_add_co_ci_u32_e64 v113, null, s51, v2, vcc_lo            // 0000001ACDF8: D5207C71 01AA0433
	.long 0xd7006a72                                           // 0000001ACE00: D7006A72
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 0000001ACE04: 02020200
	v_mul_u32_u24_e32 v127, 0x210, v6                          // 0000001ACE08: 16FE0CFF 00000210
	v_mad_u32_u24 v132, v6, s10, 0x8400                        // 0000001ACE10: D60B0084 03FC1506 00008400
	v_lshl_add_u32 v136, v130, 1, v128                         // 0000001ACE1C: D6460088 06010382
	.long 0xd4490007                                           // 0000001ACE24: D4490007
	v_cndmask_b32_e32 v1, 0x5f, v0, vcc_lo                     // 0000001ACE28: 020200FF 0000005F
	v_lshl_or_b32 v139, v130, 2, 0xf100                        // 0000001ACE30: D656008B 03FD0582 0000F100
	v_add_co_ci_u32_e64 v115, null, s1, v2, vcc_lo             // 0000001ACE3C: D5207C73 01AA0401
	v_dual_mov_b32 v151, 0xf054 :: v_dual_lshlrev_b32 v140, 1, v0// 0000001ACE44: CA2200FF 978C0081 0000F054
	v_mov_b32_e32 v142, 0xf00c                                 // 0000001ACE50: 7F1C02FF 0000F00C
	v_mov_b32_e32 v144, 0xf01c                                 // 0000001ACE58: 7F2002FF 0000F01C
	v_mov_b32_e32 v146, 0xf02c                                 // 0000001ACE60: 7F2402FF 0000F02C
	v_mov_b32_e32 v148, 0xf03c                                 // 0000001ACE68: 7F2802FF 0000F03C
	v_mov_b32_e32 v150, 0xf04c                                 // 0000001ACE70: 7F2C02FF 0000F04C
	v_mov_b32_e32 v152, 0xf05c                                 // 0000001ACE78: 7F3002FF 0000F05C
	v_mov_b32_e32 v153, 0xf064                                 // 0000001ACE80: 7F3202FF 0000F064
	v_mov_b32_e32 v154, 0xf06c                                 // 0000001ACE88: 7F3402FF 0000F06C
	v_mov_b32_e32 v155, 0xf074                                 // 0000001ACE90: 7F3602FF 0000F074
	v_mov_b32_e32 v156, 0xf07c                                 // 0000001ACE98: 7F3802FF 0000F07C
	v_mov_b32_e32 v157, 0xf084                                 // 0000001ACEA0: 7F3A02FF 0000F084
	v_mov_b32_e32 v158, 0xf08c                                 // 0000001ACEA8: 7F3C02FF 0000F08C
	v_mov_b32_e32 v159, 0xf094                                 // 0000001ACEB0: 7F3E02FF 0000F094
	v_mov_b32_e32 v160, 0xf09c                                 // 0000001ACEB8: 7F4002FF 0000F09C
	v_mov_b32_e32 v161, 0xf0a4                                 // 0000001ACEC0: 7F4202FF 0000F0A4
	v_mov_b32_e32 v162, 0xf0ac                                 // 0000001ACEC8: 7F4402FF 0000F0AC
	v_mov_b32_e32 v163, 0xf0b4                                 // 0000001ACED0: 7F4602FF 0000F0B4
	v_mov_b32_e32 v164, 0xf0bc                                 // 0000001ACED8: 7F4802FF 0000F0BC
	v_mov_b32_e32 v165, 0xf0c4                                 // 0000001ACEE0: 7F4A02FF 0000F0C4
	v_mov_b32_e32 v166, 0xf0cc                                 // 0000001ACEE8: 7F4C02FF 0000F0CC
	v_mov_b32_e32 v167, 0xf0d4                                 // 0000001ACEF0: 7F4E02FF 0000F0D4
	v_mov_b32_e32 v168, 0xf0dc                                 // 0000001ACEF8: 7F5002FF 0000F0DC
	v_mov_b32_e32 v169, 0xf0e4                                 // 0000001ACF00: 7F5202FF 0000F0E4
	v_mov_b32_e32 v170, 0xf0ec                                 // 0000001ACF08: 7F5402FF 0000F0EC
	v_mov_b32_e32 v171, 0xf0f4                                 // 0000001ACF10: 7F5602FF 0000F0F4
	s_mov_b32 s36, 0                                           // 0000001ACF18: BEA40080
	s_mov_b32 s22, 0x41800000                                  // 0000001ACF1C: BE9600FF 41800000
	s_mov_b32 s37, s36                                         // 0000001ACF24: BEA50024
	s_mov_b32 s38, s36                                         // 0000001ACF28: BEA60024
	s_mov_b32 s39, s36                                         // 0000001ACF2C: BEA70024
	s_mov_b32 s40, s36                                         // 0000001ACF30: BEA80024
	s_mov_b32 s41, s36                                         // 0000001ACF34: BEA90024
	s_mov_b32 s42, s36                                         // 0000001ACF38: BEAA0024
	s_mov_b32 s43, s36                                         // 0000001ACF3C: BEAB0024
	s_mov_b32 s23, s36                                         // 0000001ACF40: BE970024
	s_branch 4                                                 // 0000001ACF44: BFA00004 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x558>
	s_add_i32 s23, s23, 1                                      // 0000001ACF48: 81178117
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ACF4C: BF870009
	s_cmp_eq_u32 s23, s63                                      // 0000001ACF50: BF063F17
	s_cbranch_scc1 7802                                        // 0000001ACF54: BFA21E7A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7f40>
	s_mul_i32 s0, s23, 0xc00                                   // 0000001ACF58: 9600FF17 00000C00
	s_lshl_b32 s29, s23, 6                                     // 0000001ACF60: 841D8617
	s_add_i32 s0, s61, s0                                      // 0000001ACF64: 8100003D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001ACF68: BF870499
	s_ashr_i32 s1, s0, 31                                      // 0000001ACF6C: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000001ACF70: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ACF74: BF870009
	s_add_u32 s0, s52, s0                                      // 0000001ACF78: 80000034
	s_addc_u32 s1, s53, s1                                     // 0000001ACF7C: 82010135
	global_load_b32 v1, v107, s[0:1]                           // 0000001ACF80: DC520000 0100006B
	s_waitcnt vmcnt(0)                                         // 0000001ACF88: BF8903F7
	v_readfirstlane_b32 s28, v1                                // 0000001ACF8C: 7E380501
	s_and_saveexec_b32 s0, s4                                  // 0000001ACF90: BE802004
	s_cbranch_execz 69                                         // 0000001ACF94: BFA50045 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6ac>
	v_or_b32_e32 v1, s29, v0                                   // 0000001ACF98: 3802001D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ACF9C: BF870091
	v_mad_u64_u32 v[1:2], null, v1, 48, s[2:3]                 // 0000001ACFA0: D6FE7C01 00096101
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000001ACFA8: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ACFAC: BF870091
	.long 0xd73c0001                                           // 0000001ACFB0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000001ACFB4: 02020282
	.long 0xd7006a01                                           // 0000001ACFB8: D7006A01
	v_cndmask_b32_e32 v1, s52, v1, vcc_lo                      // 0000001ACFBC: 02020234
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001ACFC0: BF8700C1
	v_add_co_ci_u32_e64 v2, null, s53, v2, vcc_lo              // 0000001ACFC4: D5207C02 01AA0435
	global_load_b32 v1, v[1:2], off                            // 0000001ACFCC: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001ACFD4: BF8903F7
	v_sub_f32_e32 v2, s28, v1                                  // 0000001ACFD8: 0804021C
	v_dual_mul_f32 v4, 0x3fb8aa3b, v1 :: v_dual_mul_f32 v3, 0x3fb8aa3b, v2// 0000001ACFDC: C8C602FF 040204FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001ACFE8: BF8701A1
	v_rndne_f32_e32 v8, v4                                     // 0000001ACFEC: 7E104704
	v_fma_f32 v7, 0x3fb8aa3b, v1, -v4                          // 0000001ACFF0: D6130007 841202FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v2, -v3                          // 0000001ACFFC: D6130005 840E04FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 0000001AD008: 7E0C4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AD00C: BF870191
	v_dual_sub_f32 v4, v4, v8 :: v_dual_sub_f32 v3, v3, v6     // 0000001AD010: C94A1104 04020D03
	v_fmac_f32_e32 v5, 0x32a5705f, v2                          // 0000001AD018: 560A04FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2                   // 0000001AD020: 7C3604FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AD028: BF8701B2
	v_add_f32_e32 v3, v3, v5                                   // 0000001AD02C: 06060B03
	v_cvt_i32_f32_e32 v5, v6                                   // 0000001AD030: 7E0A1106
	v_cvt_i32_f32_e32 v6, v8                                   // 0000001AD034: 7E0C1108
	v_exp_f32_e32 v3, v3                                       // 0000001AD038: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AD03C: BF870095
	.long 0xd71c0003                                           // 0000001AD040: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000001AD044: 02020B03
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 0000001AD048: 02060680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 0000001AD04C: 7C3602FF C2CE8ED0
	v_fmac_f32_e32 v7, 0x32a5705f, v1                          // 0000001AD054: 560E02FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AD05C: BF870091
	v_add_f32_e32 v4, v4, v7                                   // 0000001AD060: 06080F04
	v_exp_f32_e32 v4, v4                                       // 0000001AD064: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AD068: BF870095
	.long 0xd71c0004                                           // 0000001AD06C: D71C0004
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000001AD070: 02020D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 0000001AD074: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2                   // 0000001AD078: 7C3C04FF 42B17218
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo               // 0000001AD080: 020406FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 0000001AD088: 7C3C02FF 42B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AD090: BF870004
	v_cndmask_b32_e32 v1, 0x7f800000, v4, vcc_lo               // 0000001AD094: 020208FF 7F800000
	ds_store_b32 v120, v2                                      // 0000001AD09C: D8340000 00000278
	ds_store_b32 v121, v1                                      // 0000001AD0A4: D8340000 00000179
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001AD0AC: 8C7E007E
	s_mul_i32 s0, s23, 0x140000                                // 0000001AD0B0: 9600FF17 00140000
	s_sub_i32 s1, s58, s29                                     // 0000001AD0B8: 81811D3A
	s_mul_hi_u32 s8, s23, 0x140000                             // 0000001AD0BC: 9688FF17 00140000
	s_add_u32 s0, s56, s0                                      // 0000001AD0C4: 80000038
	s_addc_u32 s8, s57, s8                                     // 0000001AD0C8: 82080839
	s_add_u32 s0, s0, s30                                      // 0000001AD0CC: 80001E00
	s_addc_u32 s8, s8, s31                                     // 0000001AD0D0: 82081F08
	.long 0xd7000041                                           // 0000001AD0D4: D7000041
	v_cndmask_b32_e32 v1, s0, v140, vcc_lo                     // 0000001AD0D8: 02031800
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AD0DC: BF870001
	v_add_co_ci_u32_e64 v66, null, s8, 0, s0                   // 0000001AD0E0: D5207C42 00010008
	s_mul_i32 s0, s23, 0x3000                                  // 0000001AD0E8: 9600FF17 00003000
	s_mul_hi_u32 s8, s23, 0x3000                               // 0000001AD0F0: 9688FF17 00003000
	s_add_u32 s14, s59, s0                                     // 0000001AD0F8: 800E003B
	s_addc_u32 s47, s60, s8                                    // 0000001AD0FC: 822F083C
	s_add_u32 s0, s14, 0xc0                                    // 0000001AD100: 8000FF0E 000000C0
	s_addc_u32 s8, s47, 0                                      // 0000001AD108: 8208802F
	.long 0xd7006a01                                           // 0000001AD10C: D7006A01
	v_cndmask_b32_e32 v1, 0x6000, v65, vcc_lo                  // 0000001AD110: 020282FF 00006000
	s_cmp_gt_i32 s1, 1                                         // 0000001AD118: BF028101
	v_add_co_ci_u32_e64 v2, null, 0, v66, vcc_lo               // 0000001AD11C: D5207C02 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD124: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD128: BF870009
	s_and_b32 s9, vcc_lo, exec_lo                              // 0000001AD12C: 8B097E6A
	s_cselect_b32 s9, s8, s65                                  // 0000001AD130: 98094108
	s_cselect_b32 s8, s0, s64                                  // 0000001AD134: 98084000
	s_add_u32 s0, s14, 0x180                                   // 0000001AD138: 8000FF0E 00000180
	s_addc_u32 s10, s47, 0                                     // 0000001AD140: 820A802F
	v_dual_cndmask_b32 v2, v124, v2 :: v_dual_cndmask_b32 v1, v122, v1// 0000001AD144: CA52057C 0200037A
	.long 0xd7006a04                                           // 0000001AD14C: D7006A04
	v_cndmask_b32_e32 v1, 0xb000, v65, vcc_lo                  // 0000001AD150: 020282FF 0000B000
	s_cmp_gt_i32 s1, 2                                         // 0000001AD158: BF028201
	v_add_co_ci_u32_e64 v3, null, 0, v66, vcc_lo               // 0000001AD15C: D5207C03 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD164: 986A80C1
	global_load_d16_b16 v1, v[1:2], off                        // 0000001AD168: DC820000 017C0001
	s_and_b32 s11, vcc_lo, exec_lo                             // 0000001AD170: 8B0B7E6A
	s_cselect_b32 s11, s10, s65                                // 0000001AD174: 980B410A
	s_cselect_b32 s10, s0, s64                                 // 0000001AD178: 980A4000
	s_add_u32 s0, s14, 0x240                                   // 0000001AD17C: 8000FF0E 00000240
	s_addc_u32 s12, s47, 0                                     // 0000001AD184: 820C802F
	v_dual_cndmask_b32 v3, v124, v3 :: v_dual_cndmask_b32 v2, v122, v4// 0000001AD188: CA52077C 0302097A
	.long 0xd7006a05                                           // 0000001AD190: D7006A05
	v_cndmask_b32_e32 v1, 0x10000, v65, vcc_lo                 // 0000001AD194: 020282FF 00010000
	s_cmp_gt_i32 s1, 3                                         // 0000001AD19C: BF028301
	v_add_co_ci_u32_e64 v4, null, 0, v66, vcc_lo               // 0000001AD1A0: D5207C04 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD1A8: 986A80C1
	global_load_d16_b16 v2, v[2:3], off                        // 0000001AD1AC: DC820000 027C0002
	s_and_b32 s13, vcc_lo, exec_lo                             // 0000001AD1B4: 8B0D7E6A
	s_cselect_b32 s13, s12, s65                                // 0000001AD1B8: 980D410C
	s_cselect_b32 s12, s0, s64                                 // 0000001AD1BC: 980C4000
	s_add_u32 s0, s14, 0x300                                   // 0000001AD1C0: 8000FF0E 00000300
	s_addc_u32 s48, s47, 0                                     // 0000001AD1C8: 8230802F
	v_dual_cndmask_b32 v4, v124, v4 :: v_dual_cndmask_b32 v3, v122, v5// 0000001AD1CC: CA52097C 04020B7A
	.long 0xd7006a06                                           // 0000001AD1D4: D7006A06
	v_cndmask_b32_e32 v1, 0x15000, v65, vcc_lo                 // 0000001AD1D8: 020282FF 00015000
	s_cmp_gt_i32 s1, 4                                         // 0000001AD1E0: BF028401
	v_add_co_ci_u32_e64 v5, null, 0, v66, vcc_lo               // 0000001AD1E4: D5207C05 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD1EC: 986A80C1
	global_load_d16_b16 v3, v[3:4], off                        // 0000001AD1F0: DC820000 037C0003
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001AD1F8: 8B317E6A
	s_cselect_b32 s49, s48, s65                                // 0000001AD1FC: 98314130
	s_cselect_b32 s48, s0, s64                                 // 0000001AD200: 98304000
	.long 0xd7000008                                           // 0000001AD204: D7000008
	v_cndmask_b32_e32 v1, 0x1a000, v65, vcc_lo                 // 0000001AD208: 020282FF 0001A000
	s_add_u32 s50, s14, 0x3c0                                  // 0000001AD210: 8032FF0E 000003C0
	v_add_co_ci_u32_e64 v7, null, 0, v66, s0                   // 0000001AD218: D5207C07 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AD220: 8200802F
	s_cmp_gt_i32 s1, 5                                         // 0000001AD224: BF028501
	v_dual_cndmask_b32 v5, v124, v5 :: v_dual_cndmask_b32 v4, v122, v6// 0000001AD228: CA520B7C 05040D7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD230: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD234: BF870009
	s_and_b32 s51, vcc_lo, exec_lo                             // 0000001AD238: 8B337E6A
	s_cselect_b32 s51, s0, s65                                 // 0000001AD23C: 98334100
	.long 0xd7000009                                           // 0000001AD240: D7000009
	v_cndmask_b32_e32 v1, 0x1f000, v65, vcc_lo                 // 0000001AD244: 020282FF 0001F000
	s_cselect_b32 s50, s50, s64                                // 0000001AD24C: 98324032
	s_add_u32 s54, s14, 0x480                                  // 0000001AD250: 8036FF0E 00000480
	v_add_co_ci_u32_e64 v10, null, 0, v66, s0                  // 0000001AD258: D5207C0A 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AD260: 8200802F
	s_cmp_gt_i32 s1, 6                                         // 0000001AD264: BF028601
	v_dual_cndmask_b32 v7, v124, v7 :: v_dual_cndmask_b32 v6, v122, v8// 0000001AD268: CA520F7C 0706117A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD270: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD274: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001AD278: 8B377E6A
	s_cselect_b32 s55, s0, s65                                 // 0000001AD27C: 98374100
	.long 0xd7000008                                           // 0000001AD280: D7000008
	v_cndmask_b32_e32 v1, 0x24000, v65, vcc_lo                 // 0000001AD284: 020282FF 00024000
	s_cselect_b32 s54, s54, s64                                // 0000001AD28C: 98364036
	s_add_u32 s66, s14, 0x540                                  // 0000001AD290: 8042FF0E 00000540
	v_add_co_ci_u32_e64 v11, null, 0, v66, s0                  // 0000001AD298: D5207C0B 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AD2A0: 8200802F
	s_cmp_gt_i32 s1, 7                                         // 0000001AD2A4: BF028701
	v_dual_cndmask_b32 v10, v124, v10 :: v_dual_cndmask_b32 v9, v122, v9// 0000001AD2A8: CA52157C 0A08137A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD2B0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD2B4: BF870009
	s_and_b32 s67, vcc_lo, exec_lo                             // 0000001AD2B8: 8B437E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001AD2BC: 98434100
	.long 0xd700000d                                           // 0000001AD2C0: D700000D
	v_cndmask_b32_e32 v1, 0x29000, v65, vcc_lo                 // 0000001AD2C4: 020282FF 00029000
	s_cselect_b32 s66, s66, s64                                // 0000001AD2CC: 98424042
	s_add_u32 s68, s14, 0x600                                  // 0000001AD2D0: 8044FF0E 00000600
	v_add_co_ci_u32_e64 v14, null, 0, v66, s0                  // 0000001AD2D8: D5207C0E 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AD2E0: 8200802F
	s_cmp_gt_i32 s1, 8                                         // 0000001AD2E4: BF028801
	v_dual_cndmask_b32 v12, v124, v11 :: v_dual_cndmask_b32 v11, v122, v8// 0000001AD2E8: CA52177C 0C0A117A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD2F0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD2F4: BF870009
	s_and_b32 s69, vcc_lo, exec_lo                             // 0000001AD2F8: 8B457E6A
	s_cselect_b32 s69, s0, s65                                 // 0000001AD2FC: 98454100
	s_cselect_b32 s68, s68, s64                                // 0000001AD300: 98444044
	s_add_u32 s0, s14, 0x6c0                                   // 0000001AD304: 8000FF0E 000006C0
	v_dual_cndmask_b32 v14, v124, v14 :: v_dual_cndmask_b32 v13, v122, v13// 0000001AD30C: CA521D7C 0E0C1B7A
	s_addc_u32 s70, s47, 0                                     // 0000001AD314: 8246802F
	global_load_d16_b16 v8, v[4:5], off                        // 0000001AD318: DC820000 087C0004
	global_load_d16_b16 v7, v[6:7], off                        // 0000001AD320: DC820000 077C0006
	global_load_d16_b16 v6, v[9:10], off                       // 0000001AD328: DC820000 067C0009
	global_load_d16_b16 v5, v[11:12], off                      // 0000001AD330: DC820000 057C000B
	global_load_d16_b16 v4, v[13:14], off                      // 0000001AD338: DC820000 047C000D
	s_cmp_gt_i32 s1, 9                                         // 0000001AD340: BF028901
	.long 0xd7006a09                                           // 0000001AD344: D7006A09
	v_cndmask_b32_e32 v1, 0x2e000, v65, vcc_lo                 // 0000001AD348: 020282FF 0002E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AD350: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v66, vcc_lo              // 0000001AD354: D5207C0A 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD35C: 986A80C1
	s_clause 0x7                                               // 0000001AD360: BF850007
	global_load_b32 v73, v107, s[8:9]                          // 0000001AD364: DC520000 4908006B
	global_load_b32 v74, v107, s[10:11]                        // 0000001AD36C: DC520000 4A0A006B
	global_load_b32 v69, v107, s[12:13]                        // 0000001AD374: DC520000 450C006B
	global_load_b32 v70, v107, s[48:49]                        // 0000001AD37C: DC520000 4630006B
	global_load_b32 v71, v107, s[50:51]                        // 0000001AD384: DC520000 4732006B
	global_load_b32 v72, v107, s[54:55]                        // 0000001AD38C: DC520000 4836006B
	global_load_b32 v68, v107, s[66:67]                        // 0000001AD394: DC520000 4442006B
	global_load_b32 v67, v107, s[68:69]                        // 0000001AD39C: DC520000 4344006B
	s_and_b32 s8, vcc_lo, exec_lo                              // 0000001AD3A4: 8B087E6A
	s_cselect_b32 s9, s70, s65                                 // 0000001AD3A8: 98094146
	s_cselect_b32 s8, s0, s64                                  // 0000001AD3AC: 98084000
	s_add_u32 s0, s14, 0x780                                   // 0000001AD3B0: 8000FF0E 00000780
	s_addc_u32 s10, s47, 0                                     // 0000001AD3B8: 820A802F
	v_dual_cndmask_b32 v10, v124, v10 :: v_dual_cndmask_b32 v9, v122, v9// 0000001AD3BC: CA52157C 0A08137A
	.long 0xd7006a0c                                           // 0000001AD3C4: D7006A0C
	v_cndmask_b32_e32 v1, 0x33000, v65, vcc_lo                 // 0000001AD3C8: 020282FF 00033000
	s_cmp_gt_i32 s1, 10                                        // 0000001AD3D0: BF028A01
	v_add_co_ci_u32_e64 v11, null, 0, v66, vcc_lo              // 0000001AD3D4: D5207C0B 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD3DC: 986A80C1
	global_load_d16_b16 v9, v[9:10], off                       // 0000001AD3E0: DC820000 097C0009
	s_and_b32 s11, vcc_lo, exec_lo                             // 0000001AD3E8: 8B0B7E6A
	s_cselect_b32 s11, s10, s65                                // 0000001AD3EC: 980B410A
	s_cselect_b32 s10, s0, s64                                 // 0000001AD3F0: 980A4000
	s_add_u32 s0, s14, 0x840                                   // 0000001AD3F4: 8000FF0E 00000840
	s_addc_u32 s12, s47, 0                                     // 0000001AD3FC: 820C802F
	v_dual_cndmask_b32 v11, v124, v11 :: v_dual_cndmask_b32 v10, v122, v12// 0000001AD400: CA52177C 0B0A197A
	.long 0xd7006a0d                                           // 0000001AD408: D7006A0D
	v_cndmask_b32_e32 v1, 0x38000, v65, vcc_lo                 // 0000001AD40C: 020282FF 00038000
	s_cmp_gt_i32 s1, 11                                        // 0000001AD414: BF028B01
	v_add_co_ci_u32_e64 v12, null, 0, v66, vcc_lo              // 0000001AD418: D5207C0C 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD420: 986A80C1
	global_load_d16_b16 v10, v[10:11], off                     // 0000001AD424: DC820000 0A7C000A
	s_and_b32 s13, vcc_lo, exec_lo                             // 0000001AD42C: 8B0D7E6A
	s_cselect_b32 s13, s12, s65                                // 0000001AD430: 980D410C
	s_cselect_b32 s12, s0, s64                                 // 0000001AD434: 980C4000
	s_add_u32 s0, s14, 0x900                                   // 0000001AD438: 8000FF0E 00000900
	s_addc_u32 s48, s47, 0                                     // 0000001AD440: 8230802F
	v_dual_cndmask_b32 v12, v124, v12 :: v_dual_cndmask_b32 v11, v122, v13// 0000001AD444: CA52197C 0C0A1B7A
	.long 0xd7006a0e                                           // 0000001AD44C: D7006A0E
	v_cndmask_b32_e32 v1, 0x3d000, v65, vcc_lo                 // 0000001AD450: 020282FF 0003D000
	s_cmp_gt_i32 s1, 12                                        // 0000001AD458: BF028C01
	v_add_co_ci_u32_e64 v13, null, 0, v66, vcc_lo              // 0000001AD45C: D5207C0D 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD464: 986A80C1
	global_load_d16_b16 v11, v[11:12], off                     // 0000001AD468: DC820000 0B7C000B
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001AD470: 8B317E6A
	s_cselect_b32 s49, s48, s65                                // 0000001AD474: 98314130
	s_cselect_b32 s48, s0, s64                                 // 0000001AD478: 98304000
	.long 0xd7000010                                           // 0000001AD47C: D7000010
	v_cndmask_b32_e32 v1, 0x42000, v65, vcc_lo                 // 0000001AD480: 020282FF 00042000
	s_add_u32 s50, s14, 0x9c0                                  // 0000001AD488: 8032FF0E 000009C0
	v_add_co_ci_u32_e64 v15, null, 0, v66, s0                  // 0000001AD490: D5207C0F 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AD498: 8200802F
	s_cmp_gt_i32 s1, 13                                        // 0000001AD49C: BF028D01
	v_dual_cndmask_b32 v13, v124, v13 :: v_dual_cndmask_b32 v12, v122, v14// 0000001AD4A0: CA521B7C 0D0C1D7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD4A8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD4AC: BF870009
	s_and_b32 s51, vcc_lo, exec_lo                             // 0000001AD4B0: 8B337E6A
	s_cselect_b32 s51, s0, s65                                 // 0000001AD4B4: 98334100
	.long 0xd7000011                                           // 0000001AD4B8: D7000011
	v_cndmask_b32_e32 v1, 0x47000, v65, vcc_lo                 // 0000001AD4BC: 020282FF 00047000
	s_cselect_b32 s50, s50, s64                                // 0000001AD4C4: 98324032
	s_add_u32 s54, s14, 0xa80                                  // 0000001AD4C8: 8036FF0E 00000A80
	v_add_co_ci_u32_e64 v18, null, 0, v66, s0                  // 0000001AD4D0: D5207C12 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AD4D8: 8200802F
	s_cmp_gt_i32 s1, 14                                        // 0000001AD4DC: BF028E01
	v_dual_cndmask_b32 v15, v124, v15 :: v_dual_cndmask_b32 v14, v122, v16// 0000001AD4E0: CA521F7C 0F0E217A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD4E8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD4EC: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001AD4F0: 8B377E6A
	s_cselect_b32 s55, s0, s65                                 // 0000001AD4F4: 98374100
	.long 0xd7000010                                           // 0000001AD4F8: D7000010
	v_cndmask_b32_e32 v1, 0x4c000, v65, vcc_lo                 // 0000001AD4FC: 020282FF 0004C000
	s_cselect_b32 s54, s54, s64                                // 0000001AD504: 98364036
	s_add_u32 s66, s14, 0xb40                                  // 0000001AD508: 8042FF0E 00000B40
	v_add_co_ci_u32_e64 v19, null, 0, v66, s0                  // 0000001AD510: D5207C13 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AD518: 8200802F
	s_cmp_gt_i32 s1, 15                                        // 0000001AD51C: BF028F01
	v_dual_cndmask_b32 v18, v124, v18 :: v_dual_cndmask_b32 v17, v122, v17// 0000001AD520: CA52257C 1210237A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD528: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD52C: BF870009
	s_and_b32 s67, vcc_lo, exec_lo                             // 0000001AD530: 8B437E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001AD534: 98434100
	.long 0xd7000015                                           // 0000001AD538: D7000015
	v_cndmask_b32_e32 v1, 0x51000, v65, vcc_lo                 // 0000001AD53C: 020282FF 00051000
	s_cselect_b32 s66, s66, s64                                // 0000001AD544: 98424042
	s_add_u32 s68, s14, 0xc00                                  // 0000001AD548: 8044FF0E 00000C00
	v_add_co_ci_u32_e64 v22, null, 0, v66, s0                  // 0000001AD550: D5207C16 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AD558: 8200802F
	s_cmp_gt_i32 s1, 16                                        // 0000001AD55C: BF029001
	v_dual_cndmask_b32 v20, v124, v19 :: v_dual_cndmask_b32 v19, v122, v16// 0000001AD560: CA52277C 1412217A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD568: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD56C: BF870009
	s_and_b32 s69, vcc_lo, exec_lo                             // 0000001AD570: 8B457E6A
	s_cselect_b32 s69, s0, s65                                 // 0000001AD574: 98454100
	s_cselect_b32 s68, s68, s64                                // 0000001AD578: 98444044
	s_add_u32 s0, s14, 0xcc0                                   // 0000001AD57C: 8000FF0E 00000CC0
	v_dual_cndmask_b32 v22, v124, v22 :: v_dual_cndmask_b32 v21, v122, v21// 0000001AD584: CA522D7C 16142B7A
	s_addc_u32 s70, s47, 0                                     // 0000001AD58C: 8246802F
	global_load_d16_b16 v16, v[12:13], off                     // 0000001AD590: DC820000 107C000C
	global_load_d16_b16 v15, v[14:15], off                     // 0000001AD598: DC820000 0F7C000E
	global_load_d16_b16 v14, v[17:18], off                     // 0000001AD5A0: DC820000 0E7C0011
	global_load_d16_b16 v12, v[19:20], off                     // 0000001AD5A8: DC820000 0C7C0013
	global_load_d16_b16 v13, v[21:22], off                     // 0000001AD5B0: DC820000 0D7C0015
	s_cmp_gt_i32 s1, 17                                        // 0000001AD5B8: BF029101
	.long 0xd7006a11                                           // 0000001AD5BC: D7006A11
	v_cndmask_b32_e32 v1, 0x56000, v65, vcc_lo                 // 0000001AD5C0: 020282FF 00056000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AD5C8: BF870001
	v_add_co_ci_u32_e64 v18, null, 0, v66, vcc_lo              // 0000001AD5CC: D5207C12 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD5D4: 986A80C1
	s_clause 0x7                                               // 0000001AD5D8: BF850007
	global_load_b32 v80, v107, s[8:9]                          // 0000001AD5DC: DC520000 5008006B
	global_load_b32 v81, v107, s[10:11]                        // 0000001AD5E4: DC520000 510A006B
	global_load_b32 v82, v107, s[12:13]                        // 0000001AD5EC: DC520000 520C006B
	global_load_b32 v79, v107, s[48:49]                        // 0000001AD5F4: DC520000 4F30006B
	global_load_b32 v75, v107, s[50:51]                        // 0000001AD5FC: DC520000 4B32006B
	global_load_b32 v76, v107, s[54:55]                        // 0000001AD604: DC520000 4C36006B
	global_load_b32 v77, v107, s[66:67]                        // 0000001AD60C: DC520000 4D42006B
	global_load_b32 v78, v107, s[68:69]                        // 0000001AD614: DC520000 4E44006B
	s_and_b32 s8, vcc_lo, exec_lo                              // 0000001AD61C: 8B087E6A
	s_cselect_b32 s9, s70, s65                                 // 0000001AD620: 98094146
	s_cselect_b32 s8, s0, s64                                  // 0000001AD624: 98084000
	s_add_u32 s0, s14, 0xd80                                   // 0000001AD628: 8000FF0E 00000D80
	s_addc_u32 s10, s47, 0                                     // 0000001AD630: 820A802F
	v_dual_cndmask_b32 v18, v124, v18 :: v_dual_cndmask_b32 v17, v122, v17// 0000001AD634: CA52257C 1210237A
	.long 0xd7006a13                                           // 0000001AD63C: D7006A13
	v_cndmask_b32_e32 v1, 0x5b000, v65, vcc_lo                 // 0000001AD640: 020282FF 0005B000
	s_cmp_gt_i32 s1, 18                                        // 0000001AD648: BF029201
	v_add_co_ci_u32_e64 v20, null, 0, v66, vcc_lo              // 0000001AD64C: D5207C14 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD654: 986A80C1
	global_load_d16_b16 v18, v[17:18], off                     // 0000001AD658: DC820000 127C0011
	s_and_b32 s11, vcc_lo, exec_lo                             // 0000001AD660: 8B0B7E6A
	s_cselect_b32 s11, s10, s65                                // 0000001AD664: 980B410A
	s_cselect_b32 s10, s0, s64                                 // 0000001AD668: 980A4000
	s_add_u32 s0, s14, 0xe40                                   // 0000001AD66C: 8000FF0E 00000E40
	s_addc_u32 s12, s47, 0                                     // 0000001AD674: 820C802F
	v_dual_cndmask_b32 v20, v124, v20 :: v_dual_cndmask_b32 v19, v122, v19// 0000001AD678: CA52297C 1412277A
	.long 0xd7006a11                                           // 0000001AD680: D7006A11
	v_cndmask_b32_e32 v1, 0x60000, v65, vcc_lo                 // 0000001AD684: 020282FF 00060000
	s_cmp_gt_i32 s1, 19                                        // 0000001AD68C: BF029301
	v_add_co_ci_u32_e64 v21, null, 0, v66, vcc_lo              // 0000001AD690: D5207C15 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD698: 986A80C1
	global_load_d16_b16 v19, v[19:20], off                     // 0000001AD69C: DC820000 137C0013
	s_and_b32 s13, vcc_lo, exec_lo                             // 0000001AD6A4: 8B0D7E6A
	s_cselect_b32 s13, s12, s65                                // 0000001AD6A8: 980D410C
	s_cselect_b32 s12, s0, s64                                 // 0000001AD6AC: 980C4000
	s_add_u32 s0, s14, 0xf00                                   // 0000001AD6B0: 8000FF0E 00000F00
	s_addc_u32 s48, s47, 0                                     // 0000001AD6B8: 8230802F
	v_cndmask_b32_e32 v21, v124, v21, vcc_lo                   // 0000001AD6BC: 022A2B7C
	v_cndmask_b32_e32 v20, v122, v17, vcc_lo                   // 0000001AD6C0: 0228237A
	.long 0xd7006a11                                           // 0000001AD6C4: D7006A11
	v_cndmask_b32_e32 v1, 0x65000, v65, vcc_lo                 // 0000001AD6C8: 020282FF 00065000
	s_cmp_gt_i32 s1, 20                                        // 0000001AD6D0: BF029401
	v_add_co_ci_u32_e64 v22, null, 0, v66, vcc_lo              // 0000001AD6D4: D5207C16 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD6DC: 986A80C1
	global_load_d16_b16 v20, v[20:21], off                     // 0000001AD6E0: DC820000 147C0014
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001AD6E8: 8B317E6A
	s_cselect_b32 s49, s48, s65                                // 0000001AD6EC: 98314130
	s_cselect_b32 s48, s0, s64                                 // 0000001AD6F0: 98304000
	.long 0xd7000017                                           // 0000001AD6F4: D7000017
	v_cndmask_b32_e32 v1, 0x6a000, v65, vcc_lo                 // 0000001AD6F8: 020282FF 0006A000
	s_add_u32 s50, s14, 0xfc0                                  // 0000001AD700: 8032FF0E 00000FC0
	v_add_co_ci_u32_e64 v24, null, 0, v66, s0                  // 0000001AD708: D5207C18 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AD710: 8200802F
	s_cmp_gt_i32 s1, 21                                        // 0000001AD714: BF029501
	v_dual_cndmask_b32 v22, v124, v22 :: v_dual_cndmask_b32 v21, v122, v17// 0000001AD718: CA522D7C 1614237A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD720: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD724: BF870009
	s_and_b32 s51, vcc_lo, exec_lo                             // 0000001AD728: 8B337E6A
	s_cselect_b32 s51, s0, s65                                 // 0000001AD72C: 98334100
	.long 0xd7000011                                           // 0000001AD730: D7000011
	v_cndmask_b32_e32 v1, 0x6f000, v65, vcc_lo                 // 0000001AD734: 020282FF 0006F000
	s_cselect_b32 s50, s50, s64                                // 0000001AD73C: 98324032
	s_add_u32 s54, s14, 0x1080                                 // 0000001AD740: 8036FF0E 00001080
	v_add_co_ci_u32_e64 v25, null, 0, v66, s0                  // 0000001AD748: D5207C19 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AD750: 8200802F
	s_cmp_gt_i32 s1, 22                                        // 0000001AD754: BF029601
	v_dual_cndmask_b32 v24, v124, v24 :: v_dual_cndmask_b32 v23, v122, v23// 0000001AD758: CA52317C 18162F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD760: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD764: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001AD768: 8B377E6A
	v_cndmask_b32_e32 v27, v124, v25, vcc_lo                   // 0000001AD76C: 0236337C
	s_cselect_b32 s55, s0, s65                                 // 0000001AD770: 98374100
	.long 0xd7000019                                           // 0000001AD774: D7000019
	v_cndmask_b32_e32 v1, 0x74000, v65, vcc_lo                 // 0000001AD778: 020282FF 00074000
	s_cselect_b32 s54, s54, s64                                // 0000001AD780: 98364036
	s_add_u32 s66, s14, 0x1140                                 // 0000001AD784: 8042FF0E 00001140
	v_add_co_ci_u32_e64 v28, null, 0, v66, s0                  // 0000001AD78C: D5207C1C 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AD794: 8200802F
	s_cmp_gt_i32 s1, 23                                        // 0000001AD798: BF029701
	v_cndmask_b32_e32 v26, v122, v17, vcc_lo                   // 0000001AD79C: 0234237A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD7A0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD7A4: BF870009
	s_and_b32 s67, vcc_lo, exec_lo                             // 0000001AD7A8: 8B437E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001AD7AC: 98434100
	.long 0xd7000011                                           // 0000001AD7B0: D7000011
	v_cndmask_b32_e32 v1, 0x79000, v65, vcc_lo                 // 0000001AD7B4: 020282FF 00079000
	s_cselect_b32 s66, s66, s64                                // 0000001AD7BC: 98424042
	s_add_u32 s68, s14, 0x1200                                 // 0000001AD7C0: 8044FF0E 00001200
	v_add_co_ci_u32_e64 v30, null, 0, v66, s0                  // 0000001AD7C8: D5207C1E 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AD7D0: 8200802F
	s_cmp_gt_i32 s1, 24                                        // 0000001AD7D4: BF029801
	v_dual_cndmask_b32 v29, v124, v28 :: v_dual_cndmask_b32 v28, v122, v25// 0000001AD7D8: CA52397C 1D1C337A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD7E0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD7E4: BF870009
	s_and_b32 s69, vcc_lo, exec_lo                             // 0000001AD7E8: 8B457E6A
	s_cselect_b32 s69, s0, s65                                 // 0000001AD7EC: 98454100
	s_cselect_b32 s68, s68, s64                                // 0000001AD7F0: 98444044
	s_add_u32 s0, s14, 0x12c0                                  // 0000001AD7F4: 8000FF0E 000012C0
	s_addc_u32 s70, s47, 0                                     // 0000001AD7FC: 8246802F
	v_dual_cndmask_b32 v31, v124, v30 :: v_dual_cndmask_b32 v30, v122, v17// 0000001AD800: CA523D7C 1F1E237A
	s_cmp_gt_i32 s1, 25                                        // 0000001AD808: BF029901
	.long 0xd7006a11                                           // 0000001AD80C: D7006A11
	v_cndmask_b32_e32 v1, 0x7e000, v65, vcc_lo                 // 0000001AD810: 020282FF 0007E000
	global_load_d16_b16 v25, v[21:22], off                     // 0000001AD818: DC820000 197C0015
	global_load_d16_b16 v24, v[23:24], off                     // 0000001AD820: DC820000 187C0017
	global_load_d16_b16 v23, v[26:27], off                     // 0000001AD828: DC820000 177C001A
	global_load_d16_b16 v21, v[28:29], off                     // 0000001AD830: DC820000 157C001C
	global_load_d16_b16 v22, v[30:31], off                     // 0000001AD838: DC820000 167C001E
	v_add_co_ci_u32_e64 v26, null, 0, v66, vcc_lo              // 0000001AD840: D5207C1A 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD848: 986A80C1
	s_clause 0x7                                               // 0000001AD84C: BF850007
	global_load_b32 v90, v107, s[8:9]                          // 0000001AD850: DC520000 5A08006B
	global_load_b32 v86, v107, s[10:11]                        // 0000001AD858: DC520000 560A006B
	global_load_b32 v87, v107, s[12:13]                        // 0000001AD860: DC520000 570C006B
	global_load_b32 v88, v107, s[48:49]                        // 0000001AD868: DC520000 5830006B
	global_load_b32 v89, v107, s[50:51]                        // 0000001AD870: DC520000 5932006B
	global_load_b32 v85, v107, s[54:55]                        // 0000001AD878: DC520000 5536006B
	global_load_b32 v83, v107, s[66:67]                        // 0000001AD880: DC520000 5342006B
	global_load_b32 v84, v107, s[68:69]                        // 0000001AD888: DC520000 5444006B
	s_and_b32 s8, vcc_lo, exec_lo                              // 0000001AD890: 8B087E6A
	s_cselect_b32 s9, s70, s65                                 // 0000001AD894: 98094146
	s_cselect_b32 s8, s0, s64                                  // 0000001AD898: 98084000
	s_add_u32 s0, s14, 0x1380                                  // 0000001AD89C: 8000FF0E 00001380
	s_addc_u32 s10, s47, 0                                     // 0000001AD8A4: 820A802F
	v_dual_cndmask_b32 v27, v124, v26 :: v_dual_cndmask_b32 v26, v122, v17// 0000001AD8A8: CA52357C 1B1A237A
	.long 0xd7006a11                                           // 0000001AD8B0: D7006A11
	v_cndmask_b32_e32 v1, 0x83000, v65, vcc_lo                 // 0000001AD8B4: 020282FF 00083000
	s_cmp_gt_i32 s1, 26                                        // 0000001AD8BC: BF029A01
	v_add_co_ci_u32_e64 v28, null, 0, v66, vcc_lo              // 0000001AD8C0: D5207C1C 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD8C8: 986A80C1
	global_load_d16_b16 v26, v[26:27], off                     // 0000001AD8CC: DC820000 1A7C001A
	s_and_b32 s11, vcc_lo, exec_lo                             // 0000001AD8D4: 8B0B7E6A
	s_cselect_b32 s11, s10, s65                                // 0000001AD8D8: 980B410A
	s_cselect_b32 s10, s0, s64                                 // 0000001AD8DC: 980A4000
	s_add_u32 s0, s14, 0x1440                                  // 0000001AD8E0: 8000FF0E 00001440
	s_addc_u32 s12, s47, 0                                     // 0000001AD8E8: 820C802F
	v_dual_cndmask_b32 v28, v124, v28 :: v_dual_cndmask_b32 v27, v122, v17// 0000001AD8EC: CA52397C 1C1A237A
	.long 0xd7006a11                                           // 0000001AD8F4: D7006A11
	v_cndmask_b32_e32 v1, 0x88000, v65, vcc_lo                 // 0000001AD8F8: 020282FF 00088000
	s_cmp_gt_i32 s1, 27                                        // 0000001AD900: BF029B01
	v_add_co_ci_u32_e64 v29, null, 0, v66, vcc_lo              // 0000001AD904: D5207C1D 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD90C: 986A80C1
	global_load_d16_b16 v27, v[27:28], off                     // 0000001AD910: DC820000 1B7C001B
	s_and_b32 s13, vcc_lo, exec_lo                             // 0000001AD918: 8B0D7E6A
	s_cselect_b32 s13, s12, s65                                // 0000001AD91C: 980D410C
	s_cselect_b32 s12, s0, s64                                 // 0000001AD920: 980C4000
	s_add_u32 s0, s14, 0x1500                                  // 0000001AD924: 8000FF0E 00001500
	s_addc_u32 s48, s47, 0                                     // 0000001AD92C: 8230802F
	v_cndmask_b32_e32 v29, v124, v29, vcc_lo                   // 0000001AD930: 023A3B7C
	v_cndmask_b32_e32 v28, v122, v17, vcc_lo                   // 0000001AD934: 0238237A
	.long 0xd7006a11                                           // 0000001AD938: D7006A11
	v_cndmask_b32_e32 v1, 0x8d000, v65, vcc_lo                 // 0000001AD93C: 020282FF 0008D000
	s_cmp_gt_i32 s1, 28                                        // 0000001AD944: BF029C01
	v_add_co_ci_u32_e64 v30, null, 0, v66, vcc_lo              // 0000001AD948: D5207C1E 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD950: 986A80C1
	global_load_d16_b16 v28, v[28:29], off                     // 0000001AD954: DC820000 1C7C001C
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001AD95C: 8B317E6A
	s_cselect_b32 s49, s48, s65                                // 0000001AD960: 98314130
	s_cselect_b32 s48, s0, s64                                 // 0000001AD964: 98304000
	.long 0xd700001f                                           // 0000001AD968: D700001F
	v_cndmask_b32_e32 v1, 0x92000, v65, vcc_lo                 // 0000001AD96C: 020282FF 00092000
	s_add_u32 s50, s14, 0x15c0                                 // 0000001AD974: 8032FF0E 000015C0
	v_add_co_ci_u32_e64 v32, null, 0, v66, s0                  // 0000001AD97C: D5207C20 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AD984: 8200802F
	s_cmp_gt_i32 s1, 29                                        // 0000001AD988: BF029D01
	v_dual_cndmask_b32 v30, v124, v30 :: v_dual_cndmask_b32 v29, v122, v17// 0000001AD98C: CA523D7C 1E1C237A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD994: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD998: BF870009
	s_and_b32 s51, vcc_lo, exec_lo                             // 0000001AD99C: 8B337E6A
	s_cselect_b32 s51, s0, s65                                 // 0000001AD9A0: 98334100
	.long 0xd7000011                                           // 0000001AD9A4: D7000011
	v_cndmask_b32_e32 v1, 0x97000, v65, vcc_lo                 // 0000001AD9A8: 020282FF 00097000
	s_cselect_b32 s50, s50, s64                                // 0000001AD9B0: 98324032
	s_add_u32 s54, s14, 0x1680                                 // 0000001AD9B4: 8036FF0E 00001680
	v_add_co_ci_u32_e64 v33, null, 0, v66, s0                  // 0000001AD9BC: D5207C21 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AD9C4: 8200802F
	s_cmp_gt_i32 s1, 30                                        // 0000001AD9C8: BF029E01
	v_dual_cndmask_b32 v32, v124, v32 :: v_dual_cndmask_b32 v31, v122, v31// 0000001AD9CC: CA52417C 201E3F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AD9D4: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AD9D8: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001AD9DC: 8B377E6A
	v_cndmask_b32_e32 v35, v124, v33, vcc_lo                   // 0000001AD9E0: 0246437C
	s_cselect_b32 s55, s0, s65                                 // 0000001AD9E4: 98374100
	.long 0xd7000021                                           // 0000001AD9E8: D7000021
	v_cndmask_b32_e32 v1, 0x9c000, v65, vcc_lo                 // 0000001AD9EC: 020282FF 0009C000
	s_cselect_b32 s54, s54, s64                                // 0000001AD9F4: 98364036
	s_add_u32 s66, s14, 0x1740                                 // 0000001AD9F8: 8042FF0E 00001740
	v_add_co_ci_u32_e64 v36, null, 0, v66, s0                  // 0000001ADA00: D5207C24 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001ADA08: 8200802F
	s_cmp_gt_i32 s1, 31                                        // 0000001ADA0C: BF029F01
	v_cndmask_b32_e32 v34, v122, v17, vcc_lo                   // 0000001ADA10: 0244237A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADA14: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ADA18: BF870009
	s_and_b32 s67, vcc_lo, exec_lo                             // 0000001ADA1C: 8B437E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001ADA20: 98434100
	.long 0xd7000011                                           // 0000001ADA24: D7000011
	v_cndmask_b32_e32 v1, 0xa1000, v65, vcc_lo                 // 0000001ADA28: 020282FF 000A1000
	s_cselect_b32 s66, s66, s64                                // 0000001ADA30: 98424042
	s_add_u32 s68, s14, 0x1800                                 // 0000001ADA34: 8044FF0E 00001800
	v_add_co_ci_u32_e64 v38, null, 0, v66, s0                  // 0000001ADA3C: D5207C26 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001ADA44: 8200802F
	s_cmp_gt_i32 s1, 32                                        // 0000001ADA48: BF02A001
	v_dual_cndmask_b32 v37, v124, v36 :: v_dual_cndmask_b32 v36, v122, v33// 0000001ADA4C: CA52497C 2524437A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADA54: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ADA58: BF870009
	s_and_b32 s69, vcc_lo, exec_lo                             // 0000001ADA5C: 8B457E6A
	s_cselect_b32 s69, s0, s65                                 // 0000001ADA60: 98454100
	s_cselect_b32 s68, s68, s64                                // 0000001ADA64: 98444044
	s_add_u32 s0, s14, 0x18c0                                  // 0000001ADA68: 8000FF0E 000018C0
	s_addc_u32 s70, s47, 0                                     // 0000001ADA70: 8246802F
	v_dual_cndmask_b32 v39, v124, v38 :: v_dual_cndmask_b32 v38, v122, v17// 0000001ADA74: CA524D7C 2726237A
	s_cmp_gt_i32 s1, 33                                        // 0000001ADA7C: BF02A101
	.long 0xd7006a11                                           // 0000001ADA80: D7006A11
	v_cndmask_b32_e32 v1, 0xa6000, v65, vcc_lo                 // 0000001ADA84: 020282FF 000A6000
	global_load_d16_b16 v33, v[29:30], off                     // 0000001ADA8C: DC820000 217C001D
	global_load_d16_b16 v32, v[31:32], off                     // 0000001ADA94: DC820000 207C001F
	global_load_d16_b16 v31, v[34:35], off                     // 0000001ADA9C: DC820000 1F7C0022
	global_load_d16_b16 v30, v[36:37], off                     // 0000001ADAA4: DC820000 1E7C0024
	global_load_d16_b16 v29, v[38:39], off                     // 0000001ADAAC: DC820000 1D7C0026
	v_add_co_ci_u32_e64 v34, null, 0, v66, vcc_lo              // 0000001ADAB4: D5207C22 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADABC: 986A80C1
	s_clause 0x7                                               // 0000001ADAC0: BF850007
	global_load_b32 v97, v107, s[8:9]                          // 0000001ADAC4: DC520000 6108006B
	global_load_b32 v98, v107, s[10:11]                        // 0000001ADACC: DC520000 620A006B
	global_load_b32 v96, v107, s[12:13]                        // 0000001ADAD4: DC520000 600C006B
	global_load_b32 v92, v107, s[48:49]                        // 0000001ADADC: DC520000 5C30006B
	global_load_b32 v93, v107, s[50:51]                        // 0000001ADAE4: DC520000 5D32006B
	global_load_b32 v94, v107, s[54:55]                        // 0000001ADAEC: DC520000 5E36006B
	global_load_b32 v95, v107, s[66:67]                        // 0000001ADAF4: DC520000 5F42006B
	global_load_b32 v91, v107, s[68:69]                        // 0000001ADAFC: DC520000 5B44006B
	s_and_b32 s8, vcc_lo, exec_lo                              // 0000001ADB04: 8B087E6A
	s_cselect_b32 s9, s70, s65                                 // 0000001ADB08: 98094146
	s_cselect_b32 s8, s0, s64                                  // 0000001ADB0C: 98084000
	s_add_u32 s0, s14, 0x1980                                  // 0000001ADB10: 8000FF0E 00001980
	s_addc_u32 s10, s47, 0                                     // 0000001ADB18: 820A802F
	v_dual_cndmask_b32 v35, v124, v34 :: v_dual_cndmask_b32 v34, v122, v17// 0000001ADB1C: CA52457C 2322237A
	.long 0xd7006a11                                           // 0000001ADB24: D7006A11
	v_cndmask_b32_e32 v1, 0xab000, v65, vcc_lo                 // 0000001ADB28: 020282FF 000AB000
	s_cmp_gt_i32 s1, 34                                        // 0000001ADB30: BF02A201
	v_add_co_ci_u32_e64 v36, null, 0, v66, vcc_lo              // 0000001ADB34: D5207C24 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADB3C: 986A80C1
	global_load_d16_b16 v34, v[34:35], off                     // 0000001ADB40: DC820000 227C0022
	s_and_b32 s11, vcc_lo, exec_lo                             // 0000001ADB48: 8B0B7E6A
	s_cselect_b32 s11, s10, s65                                // 0000001ADB4C: 980B410A
	s_cselect_b32 s10, s0, s64                                 // 0000001ADB50: 980A4000
	s_add_u32 s0, s14, 0x1a40                                  // 0000001ADB54: 8000FF0E 00001A40
	s_addc_u32 s12, s47, 0                                     // 0000001ADB5C: 820C802F
	v_dual_cndmask_b32 v36, v124, v36 :: v_dual_cndmask_b32 v35, v122, v17// 0000001ADB60: CA52497C 2422237A
	.long 0xd7006a11                                           // 0000001ADB68: D7006A11
	v_cndmask_b32_e32 v1, 0xb0000, v65, vcc_lo                 // 0000001ADB6C: 020282FF 000B0000
	s_cmp_gt_i32 s1, 35                                        // 0000001ADB74: BF02A301
	v_add_co_ci_u32_e64 v37, null, 0, v66, vcc_lo              // 0000001ADB78: D5207C25 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADB80: 986A80C1
	global_load_d16_b16 v35, v[35:36], off                     // 0000001ADB84: DC820000 237C0023
	s_and_b32 s13, vcc_lo, exec_lo                             // 0000001ADB8C: 8B0D7E6A
	s_cselect_b32 s13, s12, s65                                // 0000001ADB90: 980D410C
	s_cselect_b32 s12, s0, s64                                 // 0000001ADB94: 980C4000
	s_add_u32 s0, s14, 0x1b00                                  // 0000001ADB98: 8000FF0E 00001B00
	s_addc_u32 s48, s47, 0                                     // 0000001ADBA0: 8230802F
	v_cndmask_b32_e32 v37, v124, v37, vcc_lo                   // 0000001ADBA4: 024A4B7C
	v_cndmask_b32_e32 v36, v122, v17, vcc_lo                   // 0000001ADBA8: 0248237A
	.long 0xd7006a11                                           // 0000001ADBAC: D7006A11
	v_cndmask_b32_e32 v1, 0xb5000, v65, vcc_lo                 // 0000001ADBB0: 020282FF 000B5000
	s_cmp_gt_i32 s1, 36                                        // 0000001ADBB8: BF02A401
	v_add_co_ci_u32_e64 v38, null, 0, v66, vcc_lo              // 0000001ADBBC: D5207C26 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADBC4: 986A80C1
	global_load_d16_b16 v36, v[36:37], off                     // 0000001ADBC8: DC820000 247C0024
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001ADBD0: 8B317E6A
	s_cselect_b32 s49, s48, s65                                // 0000001ADBD4: 98314130
	s_cselect_b32 s48, s0, s64                                 // 0000001ADBD8: 98304000
	.long 0xd7000027                                           // 0000001ADBDC: D7000027
	v_cndmask_b32_e32 v1, 0xba000, v65, vcc_lo                 // 0000001ADBE0: 020282FF 000BA000
	s_add_u32 s50, s14, 0x1bc0                                 // 0000001ADBE8: 8032FF0E 00001BC0
	v_add_co_ci_u32_e64 v40, null, 0, v66, s0                  // 0000001ADBF0: D5207C28 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001ADBF8: 8200802F
	s_cmp_gt_i32 s1, 37                                        // 0000001ADBFC: BF02A501
	v_dual_cndmask_b32 v38, v124, v38 :: v_dual_cndmask_b32 v37, v122, v17// 0000001ADC00: CA524D7C 2624237A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADC08: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ADC0C: BF870009
	s_and_b32 s51, vcc_lo, exec_lo                             // 0000001ADC10: 8B337E6A
	s_cselect_b32 s51, s0, s65                                 // 0000001ADC14: 98334100
	.long 0xd7000011                                           // 0000001ADC18: D7000011
	v_cndmask_b32_e32 v1, 0xbf000, v65, vcc_lo                 // 0000001ADC1C: 020282FF 000BF000
	s_cselect_b32 s50, s50, s64                                // 0000001ADC24: 98324032
	s_add_u32 s54, s14, 0x1c80                                 // 0000001ADC28: 8036FF0E 00001C80
	v_add_co_ci_u32_e64 v41, null, 0, v66, s0                  // 0000001ADC30: D5207C29 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001ADC38: 8200802F
	s_cmp_gt_i32 s1, 38                                        // 0000001ADC3C: BF02A601
	v_dual_cndmask_b32 v40, v124, v40 :: v_dual_cndmask_b32 v39, v122, v39// 0000001ADC40: CA52517C 28264F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADC48: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ADC4C: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001ADC50: 8B377E6A
	v_cndmask_b32_e32 v43, v124, v41, vcc_lo                   // 0000001ADC54: 0256537C
	s_cselect_b32 s55, s0, s65                                 // 0000001ADC58: 98374100
	.long 0xd7000029                                           // 0000001ADC5C: D7000029
	v_cndmask_b32_e32 v1, 0xc4000, v65, vcc_lo                 // 0000001ADC60: 020282FF 000C4000
	s_cselect_b32 s54, s54, s64                                // 0000001ADC68: 98364036
	s_add_u32 s66, s14, 0x1d40                                 // 0000001ADC6C: 8042FF0E 00001D40
	v_add_co_ci_u32_e64 v44, null, 0, v66, s0                  // 0000001ADC74: D5207C2C 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001ADC7C: 8200802F
	s_cmp_gt_i32 s1, 39                                        // 0000001ADC80: BF02A701
	v_cndmask_b32_e32 v42, v122, v17, vcc_lo                   // 0000001ADC84: 0254237A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADC88: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ADC8C: BF870009
	s_and_b32 s67, vcc_lo, exec_lo                             // 0000001ADC90: 8B437E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001ADC94: 98434100
	.long 0xd7000011                                           // 0000001ADC98: D7000011
	v_cndmask_b32_e32 v1, 0xc9000, v65, vcc_lo                 // 0000001ADC9C: 020282FF 000C9000
	s_cselect_b32 s66, s66, s64                                // 0000001ADCA4: 98424042
	s_add_u32 s68, s14, 0x1e00                                 // 0000001ADCA8: 8044FF0E 00001E00
	v_add_co_ci_u32_e64 v46, null, 0, v66, s0                  // 0000001ADCB0: D5207C2E 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001ADCB8: 8200802F
	s_cmp_gt_i32 s1, 40                                        // 0000001ADCBC: BF02A801
	v_dual_cndmask_b32 v45, v124, v44 :: v_dual_cndmask_b32 v44, v122, v41// 0000001ADCC0: CA52597C 2D2C537A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADCC8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ADCCC: BF870009
	s_and_b32 s69, vcc_lo, exec_lo                             // 0000001ADCD0: 8B457E6A
	s_cselect_b32 s69, s0, s65                                 // 0000001ADCD4: 98454100
	s_cselect_b32 s68, s68, s64                                // 0000001ADCD8: 98444044
	s_add_u32 s0, s14, 0x1ec0                                  // 0000001ADCDC: 8000FF0E 00001EC0
	s_addc_u32 s70, s47, 0                                     // 0000001ADCE4: 8246802F
	v_dual_cndmask_b32 v47, v124, v46 :: v_dual_cndmask_b32 v46, v122, v17// 0000001ADCE8: CA525D7C 2F2E237A
	s_cmp_gt_i32 s1, 41                                        // 0000001ADCF0: BF02A901
	.long 0xd7006a11                                           // 0000001ADCF4: D7006A11
	v_cndmask_b32_e32 v1, 0xce000, v65, vcc_lo                 // 0000001ADCF8: 020282FF 000CE000
	global_load_d16_b16 v41, v[37:38], off                     // 0000001ADD00: DC820000 297C0025
	global_load_d16_b16 v40, v[39:40], off                     // 0000001ADD08: DC820000 287C0027
	global_load_d16_b16 v39, v[42:43], off                     // 0000001ADD10: DC820000 277C002A
	global_load_d16_b16 v37, v[44:45], off                     // 0000001ADD18: DC820000 257C002C
	global_load_d16_b16 v38, v[46:47], off                     // 0000001ADD20: DC820000 267C002E
	v_add_co_ci_u32_e64 v42, null, 0, v66, vcc_lo              // 0000001ADD28: D5207C2A 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADD30: 986A80C1
	s_clause 0x7                                               // 0000001ADD34: BF850007
	global_load_b32 v103, v107, s[8:9]                         // 0000001ADD38: DC520000 6708006B
	global_load_b32 v104, v107, s[10:11]                       // 0000001ADD40: DC520000 680A006B
	global_load_b32 v105, v107, s[12:13]                       // 0000001ADD48: DC520000 690C006B
	global_load_b32 v116, v107, s[48:49]                       // 0000001ADD50: DC520000 7430006B
	global_load_b32 v102, v107, s[50:51]                       // 0000001ADD58: DC520000 6632006B
	global_load_b32 v99, v107, s[54:55]                        // 0000001ADD60: DC520000 6336006B
	global_load_b32 v100, v107, s[66:67]                       // 0000001ADD68: DC520000 6442006B
	global_load_b32 v101, v107, s[68:69]                       // 0000001ADD70: DC520000 6544006B
	s_and_b32 s8, vcc_lo, exec_lo                              // 0000001ADD78: 8B087E6A
	s_cselect_b32 s9, s70, s65                                 // 0000001ADD7C: 98094146
	s_cselect_b32 s8, s0, s64                                  // 0000001ADD80: 98084000
	s_add_u32 s0, s14, 0x1f80                                  // 0000001ADD84: 8000FF0E 00001F80
	s_addc_u32 s10, s47, 0                                     // 0000001ADD8C: 820A802F
	v_dual_cndmask_b32 v43, v124, v42 :: v_dual_cndmask_b32 v42, v122, v17// 0000001ADD90: CA52557C 2B2A237A
	.long 0xd7006a11                                           // 0000001ADD98: D7006A11
	v_cndmask_b32_e32 v1, 0xd3000, v65, vcc_lo                 // 0000001ADD9C: 020282FF 000D3000
	s_cmp_gt_i32 s1, 42                                        // 0000001ADDA4: BF02AA01
	v_add_co_ci_u32_e64 v44, null, 0, v66, vcc_lo              // 0000001ADDA8: D5207C2C 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADDB0: 986A80C1
	global_load_d16_b16 v42, v[42:43], off                     // 0000001ADDB4: DC820000 2A7C002A
	s_and_b32 s11, vcc_lo, exec_lo                             // 0000001ADDBC: 8B0B7E6A
	s_cselect_b32 s11, s10, s65                                // 0000001ADDC0: 980B410A
	s_cselect_b32 s10, s0, s64                                 // 0000001ADDC4: 980A4000
	s_add_u32 s0, s14, 0x2040                                  // 0000001ADDC8: 8000FF0E 00002040
	s_addc_u32 s12, s47, 0                                     // 0000001ADDD0: 820C802F
	v_dual_cndmask_b32 v44, v124, v44 :: v_dual_cndmask_b32 v43, v122, v17// 0000001ADDD4: CA52597C 2C2A237A
	.long 0xd7006a11                                           // 0000001ADDDC: D7006A11
	v_cndmask_b32_e32 v1, 0xd8000, v65, vcc_lo                 // 0000001ADDE0: 020282FF 000D8000
	s_cmp_gt_i32 s1, 43                                        // 0000001ADDE8: BF02AB01
	v_add_co_ci_u32_e64 v45, null, 0, v66, vcc_lo              // 0000001ADDEC: D5207C2D 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADDF4: 986A80C1
	global_load_d16_b16 v43, v[43:44], off                     // 0000001ADDF8: DC820000 2B7C002B
	s_and_b32 s13, vcc_lo, exec_lo                             // 0000001ADE00: 8B0D7E6A
	s_cselect_b32 s13, s12, s65                                // 0000001ADE04: 980D410C
	s_cselect_b32 s12, s0, s64                                 // 0000001ADE08: 980C4000
	s_add_u32 s0, s14, 0x2100                                  // 0000001ADE0C: 8000FF0E 00002100
	s_addc_u32 s48, s47, 0                                     // 0000001ADE14: 8230802F
	v_cndmask_b32_e32 v45, v124, v45, vcc_lo                   // 0000001ADE18: 025A5B7C
	v_cndmask_b32_e32 v44, v122, v17, vcc_lo                   // 0000001ADE1C: 0258237A
	.long 0xd7006a11                                           // 0000001ADE20: D7006A11
	v_cndmask_b32_e32 v1, 0xdd000, v65, vcc_lo                 // 0000001ADE24: 020282FF 000DD000
	s_cmp_gt_i32 s1, 44                                        // 0000001ADE2C: BF02AC01
	v_add_co_ci_u32_e64 v46, null, 0, v66, vcc_lo              // 0000001ADE30: D5207C2E 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADE38: 986A80C1
	global_load_d16_b16 v44, v[44:45], off                     // 0000001ADE3C: DC820000 2C7C002C
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001ADE44: 8B317E6A
	s_cselect_b32 s49, s48, s65                                // 0000001ADE48: 98314130
	s_cselect_b32 s48, s0, s64                                 // 0000001ADE4C: 98304000
	.long 0xd700002f                                           // 0000001ADE50: D700002F
	v_cndmask_b32_e32 v1, 0xe2000, v65, vcc_lo                 // 0000001ADE54: 020282FF 000E2000
	s_add_u32 s50, s14, 0x21c0                                 // 0000001ADE5C: 8032FF0E 000021C0
	v_add_co_ci_u32_e64 v48, null, 0, v66, s0                  // 0000001ADE64: D5207C30 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001ADE6C: 8200802F
	s_cmp_gt_i32 s1, 45                                        // 0000001ADE70: BF02AD01
	v_dual_cndmask_b32 v46, v124, v46 :: v_dual_cndmask_b32 v45, v122, v17// 0000001ADE74: CA525D7C 2E2C237A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADE7C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ADE80: BF870009
	s_and_b32 s51, vcc_lo, exec_lo                             // 0000001ADE84: 8B337E6A
	s_cselect_b32 s51, s0, s65                                 // 0000001ADE88: 98334100
	.long 0xd7000011                                           // 0000001ADE8C: D7000011
	v_cndmask_b32_e32 v1, 0xe7000, v65, vcc_lo                 // 0000001ADE90: 020282FF 000E7000
	s_cselect_b32 s50, s50, s64                                // 0000001ADE98: 98324032
	s_add_u32 s54, s14, 0x2280                                 // 0000001ADE9C: 8036FF0E 00002280
	v_add_co_ci_u32_e64 v49, null, 0, v66, s0                  // 0000001ADEA4: D5207C31 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001ADEAC: 8200802F
	s_cmp_gt_i32 s1, 46                                        // 0000001ADEB0: BF02AE01
	v_dual_cndmask_b32 v48, v124, v48 :: v_dual_cndmask_b32 v47, v122, v47// 0000001ADEB4: CA52617C 302E5F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADEBC: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ADEC0: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001ADEC4: 8B377E6A
	v_cndmask_b32_e32 v51, v124, v49, vcc_lo                   // 0000001ADEC8: 0266637C
	s_cselect_b32 s55, s0, s65                                 // 0000001ADECC: 98374100
	.long 0xd7000031                                           // 0000001ADED0: D7000031
	v_cndmask_b32_e32 v1, 0xec000, v65, vcc_lo                 // 0000001ADED4: 020282FF 000EC000
	s_cselect_b32 s54, s54, s64                                // 0000001ADEDC: 98364036
	s_add_u32 s66, s14, 0x2340                                 // 0000001ADEE0: 8042FF0E 00002340
	v_add_co_ci_u32_e64 v52, null, 0, v66, s0                  // 0000001ADEE8: D5207C34 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001ADEF0: 8200802F
	s_cmp_gt_i32 s1, 47                                        // 0000001ADEF4: BF02AF01
	v_cndmask_b32_e32 v50, v122, v17, vcc_lo                   // 0000001ADEF8: 0264237A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADEFC: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ADF00: BF870009
	s_and_b32 s67, vcc_lo, exec_lo                             // 0000001ADF04: 8B437E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001ADF08: 98434100
	.long 0xd7000011                                           // 0000001ADF0C: D7000011
	v_cndmask_b32_e32 v1, 0xf1000, v65, vcc_lo                 // 0000001ADF10: 020282FF 000F1000
	s_cselect_b32 s66, s66, s64                                // 0000001ADF18: 98424042
	s_add_u32 s68, s14, 0x2400                                 // 0000001ADF1C: 8044FF0E 00002400
	v_add_co_ci_u32_e64 v54, null, 0, v66, s0                  // 0000001ADF24: D5207C36 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001ADF2C: 8200802F
	s_cmp_gt_i32 s1, 48                                        // 0000001ADF30: BF02B001
	v_dual_cndmask_b32 v53, v124, v52 :: v_dual_cndmask_b32 v52, v122, v49// 0000001ADF34: CA52697C 3534637A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADF3C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ADF40: BF870009
	s_and_b32 s69, vcc_lo, exec_lo                             // 0000001ADF44: 8B457E6A
	s_cselect_b32 s69, s0, s65                                 // 0000001ADF48: 98454100
	s_cselect_b32 s68, s68, s64                                // 0000001ADF4C: 98444044
	s_add_u32 s0, s14, 0x24c0                                  // 0000001ADF50: 8000FF0E 000024C0
	s_addc_u32 s70, s47, 0                                     // 0000001ADF58: 8246802F
	v_dual_cndmask_b32 v55, v124, v54 :: v_dual_cndmask_b32 v54, v122, v17// 0000001ADF5C: CA526D7C 3736237A
	s_cmp_gt_i32 s1, 49                                        // 0000001ADF64: BF02B101
	.long 0xd7006a11                                           // 0000001ADF68: D7006A11
	v_cndmask_b32_e32 v1, 0xf6000, v65, vcc_lo                 // 0000001ADF6C: 020282FF 000F6000
	global_load_d16_b16 v49, v[45:46], off                     // 0000001ADF74: DC820000 317C002D
	global_load_d16_b16 v48, v[47:48], off                     // 0000001ADF7C: DC820000 307C002F
	global_load_d16_b16 v47, v[50:51], off                     // 0000001ADF84: DC820000 2F7C0032
	global_load_d16_b16 v46, v[52:53], off                     // 0000001ADF8C: DC820000 2E7C0034
	global_load_d16_b16 v45, v[54:55], off                     // 0000001ADF94: DC820000 2D7C0036
	v_add_co_ci_u32_e64 v50, null, 0, v66, vcc_lo              // 0000001ADF9C: D5207C32 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001ADFA4: 986A80C1
	s_clause 0x7                                               // 0000001ADFA8: BF850007
	global_load_b32 v198, v107, s[8:9]                         // 0000001ADFAC: DC520000 C608006B
	global_load_b32 v197, v107, s[10:11]                       // 0000001ADFB4: DC520000 C50A006B
	global_load_b32 v193, v107, s[12:13]                       // 0000001ADFBC: DC520000 C10C006B
	global_load_b32 v194, v107, s[48:49]                       // 0000001ADFC4: DC520000 C230006B
	global_load_b32 v195, v107, s[50:51]                       // 0000001ADFCC: DC520000 C332006B
	global_load_b32 v196, v107, s[54:55]                       // 0000001ADFD4: DC520000 C436006B
	global_load_b32 v192, v107, s[66:67]                       // 0000001ADFDC: DC520000 C042006B
	global_load_b32 v191, v107, s[68:69]                       // 0000001ADFE4: DC520000 BF44006B
	s_and_b32 s8, vcc_lo, exec_lo                              // 0000001ADFEC: 8B087E6A
	s_cselect_b32 s9, s70, s65                                 // 0000001ADFF0: 98094146
	s_cselect_b32 s8, s0, s64                                  // 0000001ADFF4: 98084000
	s_add_u32 s0, s14, 0x2580                                  // 0000001ADFF8: 8000FF0E 00002580
	s_addc_u32 s10, s47, 0                                     // 0000001AE000: 820A802F
	v_dual_cndmask_b32 v51, v124, v50 :: v_dual_cndmask_b32 v50, v122, v17// 0000001AE004: CA52657C 3332237A
	.long 0xd7006a11                                           // 0000001AE00C: D7006A11
	v_cndmask_b32_e32 v1, 0xfb000, v65, vcc_lo                 // 0000001AE010: 020282FF 000FB000
	s_cmp_gt_i32 s1, 50                                        // 0000001AE018: BF02B201
	v_add_co_ci_u32_e64 v52, null, 0, v66, vcc_lo              // 0000001AE01C: D5207C34 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE024: 986A80C1
	global_load_d16_b16 v50, v[50:51], off                     // 0000001AE028: DC820000 327C0032
	s_and_b32 s11, vcc_lo, exec_lo                             // 0000001AE030: 8B0B7E6A
	s_cselect_b32 s11, s10, s65                                // 0000001AE034: 980B410A
	s_cselect_b32 s10, s0, s64                                 // 0000001AE038: 980A4000
	s_add_u32 s0, s14, 0x2640                                  // 0000001AE03C: 8000FF0E 00002640
	s_addc_u32 s12, s47, 0                                     // 0000001AE044: 820C802F
	v_dual_cndmask_b32 v52, v124, v52 :: v_dual_cndmask_b32 v51, v122, v17// 0000001AE048: CA52697C 3432237A
	.long 0xd7006a11                                           // 0000001AE050: D7006A11
	v_cndmask_b32_e32 v1, 0x100000, v65, vcc_lo                // 0000001AE054: 020282FF 00100000
	s_cmp_gt_i32 s1, 51                                        // 0000001AE05C: BF02B301
	v_add_co_ci_u32_e64 v53, null, 0, v66, vcc_lo              // 0000001AE060: D5207C35 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE068: 986A80C1
	global_load_d16_b16 v51, v[51:52], off                     // 0000001AE06C: DC820000 337C0033
	s_and_b32 s13, vcc_lo, exec_lo                             // 0000001AE074: 8B0D7E6A
	s_cselect_b32 s13, s12, s65                                // 0000001AE078: 980D410C
	s_cselect_b32 s12, s0, s64                                 // 0000001AE07C: 980C4000
	s_add_u32 s0, s14, 0x2700                                  // 0000001AE080: 8000FF0E 00002700
	s_addc_u32 s48, s47, 0                                     // 0000001AE088: 8230802F
	v_cndmask_b32_e32 v53, v124, v53, vcc_lo                   // 0000001AE08C: 026A6B7C
	v_cndmask_b32_e32 v52, v122, v17, vcc_lo                   // 0000001AE090: 0268237A
	.long 0xd7006a11                                           // 0000001AE094: D7006A11
	v_cndmask_b32_e32 v1, 0x105000, v65, vcc_lo                // 0000001AE098: 020282FF 00105000
	s_cmp_gt_i32 s1, 52                                        // 0000001AE0A0: BF02B401
	v_add_co_ci_u32_e64 v54, null, 0, v66, vcc_lo              // 0000001AE0A4: D5207C36 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE0AC: 986A80C1
	global_load_d16_b16 v52, v[52:53], off                     // 0000001AE0B0: DC820000 347C0034
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001AE0B8: 8B317E6A
	s_cselect_b32 s49, s48, s65                                // 0000001AE0BC: 98314130
	s_cselect_b32 s48, s0, s64                                 // 0000001AE0C0: 98304000
	.long 0xd7000037                                           // 0000001AE0C4: D7000037
	v_cndmask_b32_e32 v1, 0x10a000, v65, vcc_lo                // 0000001AE0C8: 020282FF 0010A000
	s_add_u32 s50, s14, 0x27c0                                 // 0000001AE0D0: 8032FF0E 000027C0
	v_add_co_ci_u32_e64 v56, null, 0, v66, s0                  // 0000001AE0D8: D5207C38 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AE0E0: 8200802F
	s_cmp_gt_i32 s1, 53                                        // 0000001AE0E4: BF02B501
	v_dual_cndmask_b32 v54, v124, v54 :: v_dual_cndmask_b32 v53, v122, v17// 0000001AE0E8: CA526D7C 3634237A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE0F0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AE0F4: BF870009
	s_and_b32 s51, vcc_lo, exec_lo                             // 0000001AE0F8: 8B337E6A
	s_cselect_b32 s51, s0, s65                                 // 0000001AE0FC: 98334100
	.long 0xd7000011                                           // 0000001AE100: D7000011
	v_cndmask_b32_e32 v1, 0x10f000, v65, vcc_lo                // 0000001AE104: 020282FF 0010F000
	s_cselect_b32 s50, s50, s64                                // 0000001AE10C: 98324032
	s_add_u32 s54, s14, 0x2880                                 // 0000001AE110: 8036FF0E 00002880
	v_add_co_ci_u32_e64 v57, null, 0, v66, s0                  // 0000001AE118: D5207C39 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AE120: 8200802F
	s_cmp_gt_i32 s1, 54                                        // 0000001AE124: BF02B601
	v_dual_cndmask_b32 v56, v124, v56 :: v_dual_cndmask_b32 v55, v122, v55// 0000001AE128: CA52717C 38366F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE130: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AE134: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001AE138: 8B377E6A
	v_cndmask_b32_e32 v59, v124, v57, vcc_lo                   // 0000001AE13C: 0276737C
	s_cselect_b32 s55, s0, s65                                 // 0000001AE140: 98374100
	.long 0xd7000039                                           // 0000001AE144: D7000039
	v_cndmask_b32_e32 v1, 0x114000, v65, vcc_lo                // 0000001AE148: 020282FF 00114000
	s_cselect_b32 s54, s54, s64                                // 0000001AE150: 98364036
	s_add_u32 s66, s14, 0x2940                                 // 0000001AE154: 8042FF0E 00002940
	v_add_co_ci_u32_e64 v60, null, 0, v66, s0                  // 0000001AE15C: D5207C3C 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AE164: 8200802F
	s_cmp_gt_i32 s1, 55                                        // 0000001AE168: BF02B701
	v_cndmask_b32_e32 v58, v122, v17, vcc_lo                   // 0000001AE16C: 0274237A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE170: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AE174: BF870009
	s_and_b32 s67, vcc_lo, exec_lo                             // 0000001AE178: 8B437E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001AE17C: 98434100
	.long 0xd7000011                                           // 0000001AE180: D7000011
	v_cndmask_b32_e32 v1, 0x119000, v65, vcc_lo                // 0000001AE184: 020282FF 00119000
	s_cselect_b32 s66, s66, s64                                // 0000001AE18C: 98424042
	s_add_u32 s68, s14, 0x2a00                                 // 0000001AE190: 8044FF0E 00002A00
	v_add_co_ci_u32_e64 v62, null, 0, v66, s0                  // 0000001AE198: D5207C3E 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AE1A0: 8200802F
	s_cmp_gt_i32 s1, 56                                        // 0000001AE1A4: BF02B801
	v_dual_cndmask_b32 v61, v124, v60 :: v_dual_cndmask_b32 v60, v122, v57// 0000001AE1A8: CA52797C 3D3C737A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE1B0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AE1B4: BF870009
	s_and_b32 s69, vcc_lo, exec_lo                             // 0000001AE1B8: 8B457E6A
	s_cselect_b32 s69, s0, s65                                 // 0000001AE1BC: 98454100
	s_cselect_b32 s68, s68, s64                                // 0000001AE1C0: 98444044
	s_add_u32 s0, s14, 0x2ac0                                  // 0000001AE1C4: 8000FF0E 00002AC0
	s_addc_u32 s70, s47, 0                                     // 0000001AE1CC: 8246802F
	v_dual_cndmask_b32 v63, v124, v62 :: v_dual_cndmask_b32 v62, v122, v17// 0000001AE1D0: CA527D7C 3F3E237A
	s_cmp_gt_i32 s1, 57                                        // 0000001AE1D8: BF02B901
	.long 0xd7006a11                                           // 0000001AE1DC: D7006A11
	v_cndmask_b32_e32 v1, 0x11e000, v65, vcc_lo                // 0000001AE1E0: 020282FF 0011E000
	global_load_d16_b16 v57, v[53:54], off                     // 0000001AE1E8: DC820000 397C0035
	global_load_d16_b16 v56, v[55:56], off                     // 0000001AE1F0: DC820000 387C0037
	global_load_d16_b16 v55, v[58:59], off                     // 0000001AE1F8: DC820000 377C003A
	global_load_d16_b16 v53, v[60:61], off                     // 0000001AE200: DC820000 357C003C
	global_load_d16_b16 v54, v[62:63], off                     // 0000001AE208: DC820000 367C003E
	v_add_co_ci_u32_e64 v58, null, 0, v66, vcc_lo              // 0000001AE210: D5207C3A 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE218: 986A80C1
	s_clause 0x7                                               // 0000001AE21C: BF850007
	global_load_b32 v204, v107, s[8:9]                         // 0000001AE220: DC520000 CC08006B
	global_load_b32 v205, v107, s[10:11]                       // 0000001AE228: DC520000 CD0A006B
	global_load_b32 v206, v107, s[12:13]                       // 0000001AE230: DC520000 CE0C006B
	global_load_b32 v203, v107, s[48:49]                       // 0000001AE238: DC520000 CB30006B
	global_load_b32 v199, v107, s[50:51]                       // 0000001AE240: DC520000 C732006B
	global_load_b32 v200, v107, s[54:55]                       // 0000001AE248: DC520000 C836006B
	global_load_b32 v201, v107, s[66:67]                       // 0000001AE250: DC520000 C942006B
	global_load_b32 v202, v107, s[68:69]                       // 0000001AE258: DC520000 CA44006B
	s_and_b32 s8, vcc_lo, exec_lo                              // 0000001AE260: 8B087E6A
	s_cselect_b32 s9, s70, s65                                 // 0000001AE264: 98094146
	s_cselect_b32 s8, s0, s64                                  // 0000001AE268: 98084000
	s_add_u32 s0, s14, 0x2b80                                  // 0000001AE26C: 8000FF0E 00002B80
	s_addc_u32 s10, s47, 0                                     // 0000001AE274: 820A802F
	v_dual_cndmask_b32 v59, v124, v58 :: v_dual_cndmask_b32 v58, v122, v17// 0000001AE278: CA52757C 3B3A237A
	.long 0xd7006a11                                           // 0000001AE280: D7006A11
	v_cndmask_b32_e32 v1, 0x123000, v65, vcc_lo                // 0000001AE284: 020282FF 00123000
	s_cmp_gt_i32 s1, 58                                        // 0000001AE28C: BF02BA01
	v_add_co_ci_u32_e64 v60, null, 0, v66, vcc_lo              // 0000001AE290: D5207C3C 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE298: 986A80C1
	global_load_d16_b16 v58, v[58:59], off                     // 0000001AE29C: DC820000 3A7C003A
	s_and_b32 s11, vcc_lo, exec_lo                             // 0000001AE2A4: 8B0B7E6A
	s_cselect_b32 s11, s10, s65                                // 0000001AE2A8: 980B410A
	s_cselect_b32 s10, s0, s64                                 // 0000001AE2AC: 980A4000
	s_add_u32 s0, s14, 0x2c40                                  // 0000001AE2B0: 8000FF0E 00002C40
	s_addc_u32 s12, s47, 0                                     // 0000001AE2B8: 820C802F
	v_dual_cndmask_b32 v60, v124, v60 :: v_dual_cndmask_b32 v59, v122, v17// 0000001AE2BC: CA52797C 3C3A237A
	.long 0xd7006a11                                           // 0000001AE2C4: D7006A11
	v_cndmask_b32_e32 v1, 0x128000, v65, vcc_lo                // 0000001AE2C8: 020282FF 00128000
	s_cmp_gt_i32 s1, 59                                        // 0000001AE2D0: BF02BB01
	v_add_co_ci_u32_e64 v61, null, 0, v66, vcc_lo              // 0000001AE2D4: D5207C3D 01AA8480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE2DC: 986A80C1
	global_load_d16_b16 v59, v[59:60], off                     // 0000001AE2E0: DC820000 3B7C003B
	s_and_b32 s13, vcc_lo, exec_lo                             // 0000001AE2E8: 8B0D7E6A
	s_cselect_b32 s13, s12, s65                                // 0000001AE2EC: 980D410C
	s_cselect_b32 s12, s0, s64                                 // 0000001AE2F0: 980C4000
	.long 0xd700003e                                           // 0000001AE2F4: D700003E
	v_cndmask_b32_e32 v1, 0x12d000, v65, vcc_lo                // 0000001AE2F8: 020282FF 0012D000
	s_add_u32 s48, s14, 0x2d00                                 // 0000001AE300: 8030FF0E 00002D00
	v_add_co_ci_u32_e64 v63, null, 0, v66, s0                  // 0000001AE308: D5207C3F 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AE310: 8200802F
	s_cmp_gt_i32 s1, 60                                        // 0000001AE314: BF02BC01
	v_cndmask_b32_e32 v61, v124, v61, vcc_lo                   // 0000001AE318: 027A7B7C
	v_cndmask_b32_e32 v60, v122, v17, vcc_lo                   // 0000001AE31C: 0278237A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE320: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AE324: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001AE328: 8B317E6A
	s_cselect_b32 s49, s0, s65                                 // 0000001AE32C: 98314100
	.long 0xd7000011                                           // 0000001AE330: D7000011
	v_cndmask_b32_e32 v1, 0x132000, v65, vcc_lo                // 0000001AE334: 020282FF 00132000
	s_cselect_b32 s48, s48, s64                                // 0000001AE33C: 98304030
	s_add_u32 s50, s14, 0x2dc0                                 // 0000001AE340: 8032FF0E 00002DC0
	v_add_co_ci_u32_e64 v117, null, 0, v66, s0                 // 0000001AE348: D5207C75 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AE350: 8200802F
	s_cmp_gt_i32 s1, 61                                        // 0000001AE354: BF02BD01
	v_dual_cndmask_b32 v64, v124, v63 :: v_dual_cndmask_b32 v63, v122, v62// 0000001AE358: CA527F7C 403E7D7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE360: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AE364: BF870009
	s_and_b32 s51, vcc_lo, exec_lo                             // 0000001AE368: 8B337E6A
	s_cselect_b32 s51, s0, s65                                 // 0000001AE36C: 98334100
	.long 0xd700003e                                           // 0000001AE370: D700003E
	v_cndmask_b32_e32 v1, 0x137000, v65, vcc_lo                // 0000001AE374: 020282FF 00137000
	s_cselect_b32 s50, s50, s64                                // 0000001AE37C: 98324032
	s_add_u32 s54, s14, 0x2e80                                 // 0000001AE380: 8036FF0E 00002E80
	v_cndmask_b32_e32 v173, v124, v117, vcc_lo                 // 0000001AE388: 035AEB7C
	v_add_co_ci_u32_e64 v117, null, 0, v66, s0                 // 0000001AE38C: D5207C75 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AE394: 8200802F
	s_cmp_gt_i32 s1, 62                                        // 0000001AE398: BF02BE01
	v_cndmask_b32_e32 v172, v122, v17, vcc_lo                  // 0000001AE39C: 0358237A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE3A0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AE3A4: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001AE3A8: 8B377E6A
	s_cselect_b32 s55, s0, s65                                 // 0000001AE3AC: 98374100
	.long 0xd7000011                                           // 0000001AE3B0: D7000011
	v_cndmask_b32_e32 v1, 0x13c000, v65, vcc_lo                // 0000001AE3B4: 020282FF 0013C000
	s_cselect_b32 s54, s54, s64                                // 0000001AE3BC: 98364036
	s_add_u32 s66, s14, 0x2f40                                 // 0000001AE3C0: 8042FF0E 00002F40
	v_cndmask_b32_e32 v175, v124, v117, vcc_lo                 // 0000001AE3C8: 035EEB7C
	v_add_co_ci_u32_e64 v117, null, 0, v66, s0                 // 0000001AE3CC: D5207C75 00028480
	s_addc_u32 s0, s47, 0                                      // 0000001AE3D4: 8200802F
	s_cmp_gt_i32 s1, 63                                        // 0000001AE3D8: BF02BF01
	v_cndmask_b32_e32 v174, v122, v62, vcc_lo                  // 0000001AE3DC: 035C7D7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE3E0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AE3E4: BF870009
	s_and_b32 s67, vcc_lo, exec_lo                             // 0000001AE3E8: 8B437E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001AE3EC: 98434100
	s_cselect_b32 s66, s66, s64                                // 0000001AE3F0: 98424042
	s_clause 0x6                                               // 0000001AE3F4: BF850006
	global_load_b32 v213, v107, s[8:9]                         // 0000001AE3F8: DC520000 D508006B
	global_load_b32 v212, v107, s[10:11]                       // 0000001AE400: DC520000 D40A006B
	global_load_b32 v209, v107, s[12:13]                       // 0000001AE408: DC520000 D10C006B
	global_load_b32 v210, v107, s[48:49]                       // 0000001AE410: DC520000 D230006B
	global_load_b32 v211, v107, s[50:51]                       // 0000001AE418: DC520000 D332006B
	global_load_b32 v208, v107, s[54:55]                       // 0000001AE420: DC520000 D036006B
	global_load_b32 v207, v107, s[66:67]                       // 0000001AE428: DC520000 CF42006B
	v_cndmask_b32_e32 v177, v124, v117, vcc_lo                 // 0000001AE430: 0362EB7C
	v_cndmask_b32_e32 v176, v122, v17, vcc_lo                  // 0000001AE434: 0360237A
	global_load_d16_b16 v62, v[60:61], off                     // 0000001AE438: DC820000 3E7C003C
	global_load_d16_b16 v63, v[63:64], off                     // 0000001AE440: DC820000 3F7C003F
	global_load_d16_b16 v64, v[172:173], off                   // 0000001AE448: DC820000 407C00AC
	global_load_d16_b16 v61, v[174:175], off                   // 0000001AE450: DC820000 3D7C00AE
	global_load_d16_b16 v60, v[176:177], off                   // 0000001AE458: DC820000 3C7C00B0
	.long 0x7e223880                                           // 0000001AE460: 7E223880
	s_waitcnt lgkmcnt(0)                                       // 0000001AE464: BF89FC07
	s_barrier                                                  // 0000001AE468: BFBD0000
	s_cmp_gt_i32 s58, s29                                      // 0000001AE46C: BF021D3A
	s_cbranch_scc0 29                                          // 0000001AE470: BFA1001D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x1ae8>
	.long 0xd7006a11                                           // 0000001AE474: D7006A11
	v_cndmask_b32_e32 v1, 0x1000, v65, vcc_lo                  // 0000001AE478: 020282FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AE480: BF870001
	v_add_co_ci_u32_e64 v65, null, 0, v66, vcc_lo              // 0000001AE484: D5207C41 01AA8480
	s_cmp_gt_i32 s1, 0                                         // 0000001AE48C: BF028001
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001AE490: 986A80C1
	v_cndmask_b32_e32 v66, v124, v65, vcc_lo                   // 0000001AE494: 0284837C
	v_cndmask_b32_e32 v65, v122, v17, vcc_lo                   // 0000001AE498: 0282237A
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001AE49C: 8B007E6A
	s_cselect_b32 s1, s47, s65                                 // 0000001AE4A0: 9801412F
	s_cselect_b32 s0, s14, s64                                 // 0000001AE4A4: 9800400E
	global_load_u16 v17, v[65:66], off                         // 0000001AE4A8: DC4A0000 117C0041
	global_load_b32 v65, v107, s[0:1]                          // 0000001AE4B0: DC520000 4100006B
	ds_load_b32 v66, v107 offset:61440                         // 0000001AE4B8: D8D8F000 4200006B
	s_waitcnt vmcnt(1)                                         // 0000001AE4C0: BF8907F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000001AE4C4: 30222290
	s_waitcnt vmcnt(0)                                         // 0000001AE4C8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AE4CC: BF8700A1
	v_mul_f32_e32 v17, v65, v17                                // 0000001AE4D0: 10222341
	s_waitcnt lgkmcnt(0)                                       // 0000001AE4D4: BF89FC07
	v_mul_f32_e32 v17, v17, v66                                // 0000001AE4D8: 10228511
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AE4DC: BF870001
	v_fma_mixlo_f16 v17, v17, s22, 0                           // 0000001AE4E0: CC210011 02002D11
	s_waitcnt vmcnt(62)                                        // 0000001AE4E8: BF89FBF7
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000001AE4EC: 30040490
	v_lshlrev_b32_e32 v1, 16, v1                               // 0000001AE4F0: 30020290
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000001AE4F4: 300C0C90
	s_or_b32 s0, s29, 1                                        // 0000001AE4F8: 8C00811D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AE4FC: BF870112
	v_dual_mul_f32 v66, v74, v2 :: v_dual_mul_f32 v65, v73, v1 // 0000001AE500: C8C6054A 42400349
	v_dual_mul_f32 v72, v72, v6 :: v_dual_lshlrev_b32 v1, 16, v8// 0000001AE508: C8E20D48 48001090
	v_lshlrev_b32_e32 v3, 16, v3                               // 0000001AE510: 30060690
	s_cmp_lt_i32 s0, s58                                       // 0000001AE514: BF043A00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AE518: BF870122
	v_mul_f32_e32 v70, v70, v1                                 // 0000001AE51C: 108C0346
	s_cselect_b32 s0, -1, 0                                    // 0000001AE520: 980080C1
	v_mul_f32_e32 v69, v69, v3                                 // 0000001AE524: 108A0745
	v_lshlrev_b32_e32 v3, 16, v10                              // 0000001AE528: 30061490
	v_lshlrev_b32_e32 v1, 16, v5                               // 0000001AE52C: 30020A90
	v_lshlrev_b32_e32 v5, 16, v12                              // 0000001AE530: 300A1890
	s_waitcnt vmcnt(2)                                         // 0000001AE534: BF890BF7
	v_lshlrev_b32_e32 v10, 16, v64                             // 0000001AE538: 30148090
	s_or_b32 s1, s29, 2                                        // 0000001AE53C: 8C01821D
	v_mul_f32_e32 v74, v81, v3                                 // 0000001AE540: 10940751
	v_dual_mul_f32 v68, v68, v1 :: v_dual_lshlrev_b32 v1, 16, v4// 0000001AE544: C8E20344 44000890
	v_lshlrev_b32_e32 v2, 16, v7                               // 0000001AE54C: 30040E90
	s_cmp_lt_i32 s1, s58                                       // 0000001AE550: BF043A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AE554: BF870112
	v_mul_f32_e32 v67, v67, v1                                 // 0000001AE558: 10860343
	v_dual_mul_f32 v71, v71, v2 :: v_dual_lshlrev_b32 v2, 16, v9// 0000001AE55C: C8E20547 47021290
	v_lshlrev_b32_e32 v4, 16, v11                              // 0000001AE564: 30081690
	v_lshlrev_b32_e32 v1, 16, v16                              // 0000001AE568: 30022090
	.long 0x7e12392e                                           // 0000001AE56C: 7E12392E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001AE570: BF8701C4
	v_mul_f32_e32 v73, v80, v2                                 // 0000001AE574: 10920550
	v_lshlrev_b32_e32 v2, 16, v14                              // 0000001AE578: 30041C90
	v_lshlrev_b32_e32 v6, 16, v13                              // 0000001AE57C: 300C1A90
	v_mul_f32_e32 v80, v82, v4                                 // 0000001AE580: 10A00952
	v_dual_mul_f32 v3, v76, v2 :: v_dual_mul_f32 v2, v77, v5   // 0000001AE584: C8C6054C 03020B4D
	v_dual_mul_f32 v16, v79, v1 :: v_dual_lshlrev_b32 v1, 16, v15// 0000001AE58C: C8E2034F 10001E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001AE594: BF870131
	v_dual_mul_f32 v4, v75, v1 :: v_dual_mul_f32 v1, v78, v6   // 0000001AE598: C8C6034B 04000D4E
	v_lshlrev_b32_e32 v6, 16, v20                              // 0000001AE5A0: 300C2890
	v_lshlrev_b32_e32 v8, 16, v24                              // 0000001AE5A4: 30103090
	v_mul_f32_e32 v187, v87, v6                                // 0000001AE5A8: 11760D57
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AE5AC: BF8701B2
	v_dual_mul_f32 v182, v89, v8 :: v_dual_lshlrev_b32 v5, 16, v18// 0000001AE5B0: C8E21159 B6042490
	v_lshlrev_b32_e32 v8, 16, v27                              // 0000001AE5B8: 30103690
	v_lshlrev_b32_e32 v6, 16, v22                              // 0000001AE5BC: 300C2C90
	v_mul_f32_e32 v189, v90, v5                                // 0000001AE5C0: 117A0B5A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AE5C4: BF870193
	v_mul_f32_e32 v177, v98, v8                                // 0000001AE5C8: 11621162
	v_dual_mul_f32 v183, v84, v6 :: v_dual_lshlrev_b32 v6, 16, v32// 0000001AE5CC: C8E20D54 B7064090
	v_lshlrev_b32_e32 v8, 16, v30                              // 0000001AE5D4: 30103C90
	v_lshlrev_b32_e32 v5, 16, v19                              // 0000001AE5D8: 300A2690
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AE5DC: BF870193
	v_dual_mul_f32 v179, v93, v6 :: v_dual_lshlrev_b32 v6, 16, v35// 0000001AE5E0: C8E20D5D B3064690
	v_mul_f32_e32 v176, v95, v8                                // 0000001AE5E8: 1160115F
	v_lshlrev_b32_e32 v8, 16, v41                              // 0000001AE5EC: 30105290
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AE5F0: BF870113
	v_mul_f32_e32 v173, v104, v6                               // 0000001AE5F4: 115A0D68
	v_dual_mul_f32 v104, v116, v8 :: v_dual_lshlrev_b32 v7, 16, v25// 0000001AE5F8: C8E21174 68063290
	v_lshlrev_b32_e32 v8, 16, v42                              // 0000001AE600: 30105490
	v_lshlrev_b32_e32 v6, 16, v37                              // 0000001AE604: 300C4A90
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001AE608: BF870003
	v_dual_mul_f32 v190, v86, v5 :: v_dual_mul_f32 v185, v88, v7// 0000001AE60C: C8C60B56 BEB80F58
	v_lshlrev_b32_e32 v7, 16, v26                              // 0000001AE614: 300E3490
	s_waitcnt vmcnt(1)                                         // 0000001AE618: BF8907F7
	v_lshlrev_b32_e32 v13, 16, v61                             // 0000001AE61C: 301A7A90
	v_dual_mul_f32 v117, v100, v6 :: v_dual_lshlrev_b32 v6, 16, v49// 0000001AE620: C8E20D64 75066290
	v_lshlrev_b32_e32 v5, 16, v23                              // 0000001AE628: 300A2E90
	v_mul_f32_e32 v180, v97, v7                                // 0000001AE62C: 11680F61
	v_lshlrev_b32_e32 v7, 16, v31                              // 0000001AE630: 300E3E90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AE634: BF870214
	v_mul_f32_e32 v100, v194, v6                               // 0000001AE638: 10C80DC2
	v_mul_f32_e32 v186, v85, v5                                // 0000001AE63C: 11740B55
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AE640: BF870123
	v_dual_mul_f32 v178, v94, v7 :: v_dual_lshlrev_b32 v5, 16, v21// 0000001AE644: C8E20F5E B2042A90
	v_lshlrev_b32_e32 v7, 16, v36                              // 0000001AE64C: 300E4890
	v_dual_mul_f32 v188, v83, v5 :: v_dual_lshlrev_b32 v5, 16, v28// 0000001AE650: C8E20B53 BC043890
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AE658: BF8701A2
	v_mul_f32_e32 v105, v105, v7                               // 0000001AE65C: 10D20F69
	v_lshlrev_b32_e32 v7, 16, v38                              // 0000001AE660: 300E4C90
	v_mul_f32_e32 v181, v96, v5                                // 0000001AE664: 116A0B60
	v_lshlrev_b32_e32 v5, 16, v33                              // 0000001AE668: 300A4290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AE66C: BF8700A1
	v_mul_f32_e32 v184, v92, v5                                // 0000001AE670: 11700B5C
	v_dual_mul_f32 v26, v211, v10 :: v_dual_lshlrev_b32 v5, 16, v29// 0000001AE674: C8E215D3 1A043A90
	v_mul_f32_e32 v175, v91, v5                                // 0000001AE67C: 115E0B5B
	v_lshlrev_b32_e32 v5, 16, v34                              // 0000001AE680: 300A4490
	v_lshlrev_b32_e32 v6, 16, v50                              // 0000001AE684: 300C6490
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AE688: BF870092
	v_dual_mul_f32 v174, v103, v5 :: v_dual_lshlrev_b32 v5, 16, v40// 0000001AE68C: C8E20B67 AE045090
	v_dual_mul_f32 v116, v102, v5 :: v_dual_lshlrev_b32 v5, 16, v39// 0000001AE694: C8E20B66 74044E90
	v_mul_f32_e32 v50, v208, v13                               // 0000001AE69C: 10641BD0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AE6A0: BF8701B2
	v_dual_mul_f32 v172, v99, v5 :: v_dual_lshlrev_b32 v5, 16, v43// 0000001AE6A4: C8E20B63 AC045690
	v_dual_mul_f32 v102, v101, v7 :: v_dual_mul_f32 v43, v204, v6// 0000001AE6AC: C8C60F65 662A0DCC
	v_lshlrev_b32_e32 v6, 16, v55                              // 0000001AE6B4: 300C6E90
	v_mul_f32_e32 v103, v197, v5                               // 0000001AE6B8: 10CE0BC5
	v_lshlrev_b32_e32 v5, 16, v44                              // 0000001AE6BC: 300A5890
	v_dual_mul_f32 v99, v198, v8 :: v_dual_lshlrev_b32 v8, 16, v47// 0000001AE6C0: C8E211C6 63085E90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AE6C8: BF870194
	v_mul_f32_e32 v29, v200, v6                                // 0000001AE6CC: 103A0DC8
	v_mul_f32_e32 v101, v193, v5                               // 0000001AE6D0: 10CA0BC1
	v_lshlrev_b32_e32 v5, 16, v9                               // 0000001AE6D4: 300A1290
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AE6D8: BF8701A4
	v_dual_mul_f32 v42, v196, v8 :: v_dual_lshlrev_b32 v9, 16, v63// 0000001AE6DC: C8E211C4 2A087E90
	v_lshlrev_b32_e32 v8, 16, v52                              // 0000001AE6E4: 30106890
	v_mul_f32_e32 v49, v192, v5                                // 0000001AE6E8: 10620BC0
	v_lshlrev_b32_e32 v5, 16, v45                              // 0000001AE6EC: 300A5A90
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AE6F0: BF870004
	v_dual_mul_f32 v30, v210, v9 :: v_dual_lshlrev_b32 v7, 16, v48// 0000001AE6F4: C8E213D2 1E066090
	ds_load_2addr_b32 v[9:10], v143 offset1:1                  // 0000001AE6FC: D8DC0100 0900008F
	ds_load_2addr_b32 v[11:12], v144 offset1:1                 // 0000001AE704: D8DC0100 0B000090
	v_dual_mul_f32 v27, v206, v8 :: v_dual_mul_f32 v48, v191, v5// 0000001AE70C: C8C611CE 1B300BBF
	v_dual_mul_f32 v46, v195, v7 :: v_dual_lshlrev_b32 v5, 16, v57// 0000001AE714: C8E20FC3 2E047290
	v_lshlrev_b32_e32 v7, 16, v51                              // 0000001AE71C: 300E6690
	v_lshlrev_b32_e32 v8, 16, v54                              // 0000001AE720: 30106C90
	ds_load_2addr_b32 v[191:192], v151 offset1:1               // 0000001AE724: D8DC0100 BF000097
	ds_load_2addr_b32 v[193:194], v152 offset1:1               // 0000001AE72C: D8DC0100 C1000098
	s_waitcnt vmcnt(0)                                         // 0000001AE734: BF8903F7
	v_dual_mul_f32 v32, v203, v5 :: v_dual_lshlrev_b32 v13, 16, v60// 0000001AE738: C8E20BCB 200C7890
	v_mul_f32_e32 v41, v205, v7                                // 0000001AE740: 10520FCD
	v_lshlrev_b32_e32 v5, 16, v56                              // 0000001AE744: 300A7090
	v_lshlrev_b32_e32 v7, 16, v53                              // 0000001AE748: 300E6A90
	v_dual_mul_f32 v25, v202, v8 :: v_dual_lshlrev_b32 v8, 16, v59// 0000001AE74C: C8E211CA 19087690
	ds_load_2addr_b32 v[53:54], v149 offset1:1                 // 0000001AE754: D8DC0100 35000095
	v_mul_f32_e32 v44, v199, v5                                // 0000001AE75C: 10580BC7
	v_dual_mul_f32 v28, v201, v7 :: v_dual_lshlrev_b32 v7, 16, v58// 0000001AE760: C8E20FC9 1C067490
	ds_load_2addr_b32 v[5:6], v141 offset1:1                   // 0000001AE768: D8DC0100 0500008D
	v_mul_f32_e32 v47, v212, v8                                // 0000001AE770: 105E11D4
	v_mul_f32_e32 v51, v207, v13                               // 0000001AE774: 10661BCF
	v_mul_f32_e32 v45, v213, v7                                // 0000001AE778: 105A0FD5
	v_lshlrev_b32_e32 v7, 16, v62                              // 0000001AE77C: 300E7C90
	ds_load_2addr_b32 v[55:56], v150 offset1:1                 // 0000001AE780: D8DC0100 37000096
	v_mul_f32_e32 v31, v209, v7                                // 0000001AE788: 103E0FD1
	ds_load_2addr_b32 v[7:8], v142 offset1:1                   // 0000001AE78C: D8DC0100 0700008E
	s_waitcnt lgkmcnt(3)                                       // 0000001AE794: BF89FC37
	v_dual_mul_f32 v53, v189, v53 :: v_dual_mul_f32 v54, v190, v54// 0000001AE798: C8C66BBD 35366DBE
	s_waitcnt lgkmcnt(2)                                       // 0000001AE7A0: BF89FC27
	v_dual_mul_f32 v5, v65, v5 :: v_dual_mul_f32 v6, v66, v6   // 0000001AE7A4: C8C60B41 05060D42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AE7AC: BF870091
	v_fma_mixlo_f16 v5, v5, s22, 0                             // 0000001AE7B0: CC210005 02002D05
	v_cndmask_b16 v17, 0, v5, s0                               // 0000001AE7B8: D65D4011 00020A80
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001AE7C0: BF870003
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001AE7C4: CC210005 02002D06
	s_waitcnt lgkmcnt(0)                                       // 0000001AE7CC: BF89FC07
	v_mul_f32_e32 v6, v69, v7                                  // 0000001AE7D0: 100C0F45
	s_cselect_b32 s0, -1, 0                                    // 0000001AE7D4: 980080C1
	s_or_b32 s1, s29, 3                                        // 0000001AE7D8: 8C01831D
	v_mul_f32_e32 v7, v70, v8                                  // 0000001AE7DC: 100E1146
	s_cmp_lt_i32 s1, s58                                       // 0000001AE7E0: BF043A01
	v_cndmask_b16 v18, 0, v5, s0                               // 0000001AE7E4: D65D0012 00020A80
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001AE7EC: CC210005 02002D06
	s_cselect_b32 s0, -1, 0                                    // 0000001AE7F4: 980080C1
	s_or_b32 s1, s29, 4                                        // 0000001AE7F8: 8C01841D
	v_mul_f32_e32 v6, v71, v9                                  // 0000001AE7FC: 100C1347
	s_cmp_lt_i32 s1, s58                                       // 0000001AE800: BF043A01
	v_fma_mixhi_f16 v5, v7, s22, 0                             // 0000001AE804: CC220005 02002D07
	s_cselect_b32 s1, -1, 0                                    // 0000001AE80C: 980180C1
	v_cndmask_b16 v18, 0, v5, s0                               // 0000001AE810: D65D4012 00020A80
	s_or_b32 s0, s29, 5                                        // 0000001AE818: 8C00851D
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001AE81C: CC210005 02002D06
	v_mul_f32_e32 v6, v72, v10                                 // 0000001AE824: 100C1548
	s_cmp_lt_i32 s0, s58                                       // 0000001AE828: BF043A00
	v_cndmask_b16 v19, 0, v5, s1                               // 0000001AE82C: D65D1013 00060A80
	s_cselect_b32 s0, -1, 0                                    // 0000001AE834: 980080C1
	s_or_b32 s1, s29, 6                                        // 0000001AE838: 8C01861D
	v_cndmask_b16 v19, 0, v5, s0                               // 0000001AE83C: D65D4013 00020A80
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001AE844: CC210005 02002D06
	v_dual_mul_f32 v10, v68, v11 :: v_dual_mul_f32 v11, v67, v12// 0000001AE84C: C8C61744 0A0A1943
	s_cmp_lt_i32 s1, s58                                       // 0000001AE854: BF043A01
	ds_load_2addr_b32 v[6:7], v145 offset1:1                   // 0000001AE858: D8DC0100 06000091
	ds_load_2addr_b32 v[8:9], v146 offset1:1                   // 0000001AE860: D8DC0100 08000092
	s_cselect_b32 s0, -1, 0                                    // 0000001AE868: 980080C1
	v_fma_mixhi_f16 v5, v11, s22, 0                            // 0000001AE86C: CC220005 02002D0B
	v_cndmask_b16 v20, 0, v5, s0                               // 0000001AE874: D65D0014 00020A80
	v_fma_mixlo_f16 v5, v10, s22, 0                            // 0000001AE87C: CC210005 02002D0A
	ds_load_2addr_b32 v[10:11], v147 offset1:1                 // 0000001AE884: D8DC0100 0A000093
	ds_load_2addr_b32 v[12:13], v148 offset1:1                 // 0000001AE88C: D8DC0100 0C000094
	s_or_b32 s1, s29, 7                                        // 0000001AE894: 8C01871D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AE898: BF870009
	s_cmp_lt_i32 s1, s58                                       // 0000001AE89C: BF043A01
	s_cselect_b32 s0, -1, 0                                    // 0000001AE8A0: 980080C1
	s_or_b32 s1, s29, 8                                        // 0000001AE8A4: 8C01881D
	v_cndmask_b16 v20, 0, v5, s0                               // 0000001AE8A8: D65D4014 00020A80
	s_cmp_lt_i32 s1, s58                                       // 0000001AE8B0: BF043A01
	s_cselect_b32 s0, -1, 0                                    // 0000001AE8B4: 980080C1
	s_or_b32 s1, s29, 9                                        // 0000001AE8B8: 8C01891D
	v_cndmask_b16 v21, 0, v5, s0                               // 0000001AE8BC: D65D1015 00020A80
	s_cmp_lt_i32 s1, s58                                       // 0000001AE8C4: BF043A01
	s_cselect_b32 s0, -1, 0                                    // 0000001AE8C8: 980080C1
	s_or_b32 s1, s29, 10                                       // 0000001AE8CC: 8C018A1D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AE8D0: BF870009
	s_cmp_lt_i32 s1, s58                                       // 0000001AE8D4: BF043A01
	s_waitcnt lgkmcnt(1)                                       // 0000001AE8D8: BF89FC17
	v_mul_f32_e32 v4, v4, v10                                  // 0000001AE8DC: 10081504
	s_waitcnt lgkmcnt(0)                                       // 0000001AE8E0: BF89FC07
	v_mul_f32_e32 v52, v1, v13                                 // 0000001AE8E4: 10681B01
	s_cselect_b32 s1, -1, 0                                    // 0000001AE8E8: 980180C1
	s_or_b32 s8, s29, 11                                       // 0000001AE8EC: 8C088B1D
	v_mul_f32_e32 v3, v3, v11                                  // 0000001AE8F0: 10061703
	s_cmp_lt_i32 s8, s58                                       // 0000001AE8F4: BF043A08
	v_fma_mixlo_f16 v52, v52, s22, 0                           // 0000001AE8F8: CC210034 02002D34
	v_fma_mixhi_f16 v52, v53, s22, 0                           // 0000001AE900: CC220034 02002D35
	v_fma_mixlo_f16 v53, v54, s22, 0                           // 0000001AE908: CC210035 02002D36
	v_dual_mul_f32 v54, v187, v55 :: v_dual_mul_f32 v55, v185, v56// 0000001AE910: C8C66FBB 363671B9
	v_mul_f32_e32 v56, v186, v192                              // 0000001AE918: 107181BA
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 0000001AE91C: CC210004 02002D04
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 0000001AE924: CC210003 02002D03
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AE92C: BF870004
	v_fma_mixhi_f16 v53, v54, s22, 0                           // 0000001AE930: CC220035 02002D36
	v_fma_mixlo_f16 v54, v55, s22, 0                           // 0000001AE938: CC210036 02002D37
	v_dual_mul_f32 v55, v182, v191 :: v_dual_mul_f32 v182, v188, v193// 0000001AE940: C8C77FB6 37B783BC
	v_mul_f32_e32 v2, v2, v12                                  // 0000001AE948: 10041902
	ds_load_2addr_b32 v[185:186], v153 offset1:1               // 0000001AE94C: D8DC0100 B9000099
	ds_load_2addr_b32 v[187:188], v154 offset1:1               // 0000001AE954: D8DC0100 BB00009A
	v_fma_mixhi_f16 v54, v55, s22, 0                           // 0000001AE95C: CC220036 02002D37
	v_fma_mixlo_f16 v55, v56, s22, 0                           // 0000001AE964: CC210037 02002D38
	v_fma_mixhi_f16 v55, v182, s22, 0                          // 0000001AE96C: CC220037 02002DB6
	v_mul_f32_e32 v56, v183, v194                              // 0000001AE974: 107185B7
	ds_load_2addr_b32 v[182:183], v155 offset1:1               // 0000001AE978: D8DC0100 B600009B
	ds_load_2addr_b32 v[189:190], v156 offset1:1               // 0000001AE980: D8DC0100 BD00009C
	v_dual_mul_f32 v5, v73, v6 :: v_dual_mul_f32 v6, v74, v7   // 0000001AE988: C8C60D49 05060F4A
	v_mul_f32_e32 v7, v80, v8                                  // 0000001AE990: 100E1150
	v_add_nc_u32_e32 v195, s29, v126                           // 0000001AE994: 4B86FC1D
	v_fma_mixhi_f16 v24, v2, s22, 0                            // 0000001AE998: CC220018 02002D02
	v_fma_mixlo_f16 v56, v56, s22, 0                           // 0000001AE9A0: CC210038 02002D38
	s_waitcnt lgkmcnt(1)                                       // 0000001AE9A8: BF89FC17
	v_mul_f32_e32 v178, v178, v183                             // 0000001AE9AC: 11656FB2
	v_fma_mixlo_f16 v5, v5, s22, 0                             // 0000001AE9B0: CC210005 02002D05
	v_fma_mixhi_f16 v5, v6, s22, 0                             // 0000001AE9B8: CC220005 02002D06
	v_mul_f32_e32 v6, v16, v9                                  // 0000001AE9C0: 100C1310
	s_waitcnt lgkmcnt(0)                                       // 0000001AE9C4: BF89FC07
	v_mul_f32_e32 v176, v176, v189                             // 0000001AE9C8: 11617BB0
	v_cndmask_b16 v21, 0, v5, s0                               // 0000001AE9CC: D65D4015 00020A80
	v_fma_mixlo_f16 v5, v7, s22, 0                             // 0000001AE9D4: CC210005 02002D07
	s_cselect_b32 s0, -1, 0                                    // 0000001AE9DC: 980080C1
	v_cndmask_b16 v22, 0, v5, s1                               // 0000001AE9E0: D65D1016 00060A80
	s_or_b32 s1, s29, 12                                       // 0000001AE9E8: 8C018C1D
	v_fma_mixlo_f16 v176, v176, s22, 0                         // 0000001AE9EC: CC2100B0 02002DB0
	v_cndmask_b16 v22, 0, v5, s0                               // 0000001AE9F4: D65D4016 00020A80
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001AE9FC: CC210005 02002D06
	v_min_i32_e32 v6, s62, v195                                // 0000001AEA04: 220D863E
	s_cmp_lt_i32 s1, s58                                       // 0000001AEA08: BF043A01
	s_cselect_b32 s0, -1, 0                                    // 0000001AEA0C: 980080C1
	s_or_b32 s1, s29, 13                                       // 0000001AEA10: 8C018D1D
	v_cndmask_b16 v23, 0, v5, s0                               // 0000001AEA14: D65D0017 00020A80
	v_mad_i64_i32 v[5:6], null, v6, 48, s[2:3]                 // 0000001AEA1C: D6FF7C05 00096106
	s_cmp_lt_i32 s1, s58                                       // 0000001AEA24: BF043A01
	s_cselect_b32 s0, -1, 0                                    // 0000001AEA28: 980080C1
	s_or_b32 s1, s29, 14                                       // 0000001AEA2C: 8C018E1D
	v_cndmask_b16 v23, 0, v4, s0                               // 0000001AEA30: D65D4017 00020880
	s_cmp_lt_i32 s1, s58                                       // 0000001AEA38: BF043A01
	.long 0xd73c0061                                           // 0000001AEA3C: D73C0061
	v_cndmask_b32_e32 v1, 8, v5, vcc_lo                        // 0000001AEA40: 02020A88
	s_cselect_b32 s0, -1, 0                                    // 0000001AEA44: 980080C1
	s_or_b32 s1, s29, 15                                       // 0000001AEA48: 8C018F1D
	v_cndmask_b16 v24, 0, v3, s0                               // 0000001AEA4C: D65D0018 00020680
	s_cmp_lt_i32 s1, s58                                       // 0000001AEA54: BF043A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEA58: BF870092
	.long 0xd7006a05                                           // 0000001AEA5C: D7006A05
	v_cndmask_b32_e32 v1, s26, v97, vcc_lo                     // 0000001AEA60: 0202C21A
	v_add_co_ci_u32_e64 v6, null, s27, v98, vcc_lo             // 0000001AEA64: D5207C06 01AAC41B
	s_clause 0xf                                               // 0000001AEA6C: BF85000F
	global_load_b128 v[89:92], v[5:6], off                     // 0000001AEA70: DC5E0000 597C0005
	global_load_b128 v[93:96], v[5:6], off offset:16           // 0000001AEA78: DC5E0010 5D7C0005
	global_load_b128 v[81:84], v[5:6], off offset:32           // 0000001AEA80: DC5E0020 517C0005
	global_load_b128 v[85:88], v[5:6], off offset:48           // 0000001AEA88: DC5E0030 557C0005
	global_load_b128 v[73:76], v[5:6], off offset:64           // 0000001AEA90: DC5E0040 497C0005
	global_load_b128 v[77:80], v[5:6], off offset:80           // 0000001AEA98: DC5E0050 4D7C0005
	global_load_b128 v[65:68], v[5:6], off offset:96           // 0000001AEAA0: DC5E0060 417C0005
	global_load_b128 v[69:72], v[5:6], off offset:112          // 0000001AEAA8: DC5E0070 457C0005
	global_load_b128 v[57:60], v[5:6], off offset:128          // 0000001AEAB0: DC5E0080 397C0005
	global_load_b128 v[61:64], v[5:6], off offset:144          // 0000001AEAB8: DC5E0090 3D7C0005
	global_load_b128 v[33:36], v[5:6], off offset:160          // 0000001AEAC0: DC5E00A0 217C0005
	global_load_b128 v[37:40], v[5:6], off offset:176          // 0000001AEAC8: DC5E00B0 257C0005
	global_load_b128 v[9:12], v[5:6], off offset:192           // 0000001AEAD0: DC5E00C0 097C0005
	global_load_b128 v[13:16], v[5:6], off offset:208          // 0000001AEAD8: DC5E00D0 0D7C0005
	global_load_b128 v[1:4], v[5:6], off offset:224            // 0000001AEAE0: DC5E00E0 017C0005
	global_load_b128 v[5:8], v[5:6], off offset:240            // 0000001AEAE8: DC5E00F0 057C0005
	s_cselect_b32 s0, -1, 0                                    // 0000001AEAF0: 980080C1
	s_or_b32 s1, s29, 16                                       // 0000001AEAF4: 8C01901D
	v_cndmask_b16 v24, 0, v24, s0                              // 0000001AEAF8: D65D5018 00023080
	s_cmp_lt_i32 s1, s58                                       // 0000001AEB00: BF043A01
	ds_store_b128 v125, v[17:20]                               // 0000001AEB04: DB7C0000 0000117D
	ds_store_b128 v125, v[21:24] offset:16                     // 0000001AEB0C: DB7C0010 0000157D
	s_cselect_b32 s0, -1, 0                                    // 0000001AEB14: 980080C1
	ds_load_2addr_b32 v[19:20], v158 offset1:1                 // 0000001AEB18: D8DC0100 1300009E
	v_cndmask_b16 v52, 0, v52, s0                              // 0000001AEB20: D65D0034 00026880
	s_or_b32 s0, s29, 17                                       // 0000001AEB28: 8C00911D
	v_mul_f32_e32 v180, v180, v185                             // 0000001AEB2C: 116973B4
	s_cmp_lt_i32 s0, s58                                       // 0000001AEB30: BF043A00
	v_mul_f32_e32 v177, v177, v186                             // 0000001AEB34: 116375B1
	s_cselect_b32 s0, -1, 0                                    // 0000001AEB38: 980080C1
	s_or_b32 s1, s29, 18                                       // 0000001AEB3C: 8C01921D
	v_cndmask_b16 v52, 0, v52, s0                              // 0000001AEB40: D65D5034 00026880
	s_cmp_lt_i32 s1, s58                                       // 0000001AEB48: BF043A01
	v_fma_mixhi_f16 v56, v180, s22, 0                          // 0000001AEB4C: CC220038 02002DB4
	s_cselect_b32 s0, -1, 0                                    // 0000001AEB54: 980080C1
	s_or_b32 s1, s29, 19                                       // 0000001AEB58: 8C01931D
	v_cndmask_b16 v53, 0, v53, s0                              // 0000001AEB5C: D65D0035 00026A80
	s_cmp_lt_i32 s1, s58                                       // 0000001AEB64: BF043A01
	v_mul_f32_e32 v181, v181, v187                             // 0000001AEB68: 116B77B5
	s_cselect_b32 s0, -1, 0                                    // 0000001AEB6C: 980080C1
	s_or_b32 s1, s29, 20                                       // 0000001AEB70: 8C01941D
	v_cndmask_b16 v53, 0, v53, s0                              // 0000001AEB74: D65D5035 00026A80
	s_cmp_lt_i32 s1, s58                                       // 0000001AEB7C: BF043A01
	ds_load_2addr_b32 v[21:22], v159 offset1:1                 // 0000001AEB80: D8DC0100 1500009F
	ds_load_2addr_b32 v[23:24], v160 offset1:1                 // 0000001AEB88: D8DC0100 170000A0
	s_cselect_b32 s1, -1, 0                                    // 0000001AEB90: 980180C1
	s_or_b32 s8, s29, 21                                       // 0000001AEB94: 8C08951D
	v_cndmask_b16 v54, 0, v54, s1                              // 0000001AEB98: D65D0036 00066C80
	s_cmp_lt_i32 s8, s58                                       // 0000001AEBA0: BF043A08
	s_waitcnt lgkmcnt(2)                                       // 0000001AEBA4: BF89FC27
	v_mul_f32_e32 v19, v105, v19                               // 0000001AEBA8: 10262769
	s_cselect_b32 s0, -1, 0                                    // 0000001AEBAC: 980080C1
	s_or_b32 s8, s29, 22                                       // 0000001AEBB0: 8C08961D
	v_cndmask_b16 v54, 0, v54, s0                              // 0000001AEBB4: D65D5036 00026C80
	s_cmp_lt_i32 s8, s58                                       // 0000001AEBBC: BF043A08
	v_mul_f32_e32 v20, v104, v20                               // 0000001AEBC0: 10282968
	s_cselect_b32 s1, -1, 0                                    // 0000001AEBC4: 980180C1
	s_or_b32 s8, s29, 23                                       // 0000001AEBC8: 8C08971D
	v_cndmask_b16 v55, 0, v55, s1                              // 0000001AEBCC: D65D0037 00066E80
	s_cmp_lt_i32 s8, s58                                       // 0000001AEBD4: BF043A08
	v_cmp_le_i32_e32 vcc_lo, s58, v195                         // 0000001AEBD8: 7C87863A
	s_cselect_b32 s0, -1, 0                                    // 0000001AEBDC: 980080C1
	s_or_b32 s8, s29, 24                                       // 0000001AEBE0: 8C08981D
	v_cndmask_b16 v55, 0, v55, s0                              // 0000001AEBE4: D65D5037 00026E80
	s_cmp_lt_i32 s8, s58                                       // 0000001AEBEC: BF043A08
	s_cselect_b32 s0, -1, 0                                    // 0000001AEBF0: 980080C1
	s_or_b32 s1, s29, 25                                       // 0000001AEBF4: 8C01991D
	v_cndmask_b16 v180, 0, v56, s0                             // 0000001AEBF8: D65D00B4 00027080
	s_cmp_lt_i32 s1, s58                                       // 0000001AEC00: BF043A01
	v_fma_mixlo_f16 v56, v177, s22, 0                          // 0000001AEC04: CC210038 02002DB1
	s_cselect_b32 s1, -1, 0                                    // 0000001AEC0C: 980180C1
	s_or_b32 s8, s29, 26                                       // 0000001AEC10: 8C089A1D
	v_mul_f32_e32 v177, v184, v188                             // 0000001AEC14: 116379B8
	s_cmp_lt_i32 s8, s58                                       // 0000001AEC18: BF043A08
	v_cndmask_b16 v180, 0, v56, s1                             // 0000001AEC1C: D65D50B4 00067080
	s_cselect_b32 s0, -1, 0                                    // 0000001AEC24: 980080C1
	s_or_b32 s8, s29, 27                                       // 0000001AEC28: 8C089B1D
	v_fma_mixhi_f16 v56, v181, s22, 0                          // 0000001AEC2C: CC220038 02002DB5
	s_cmp_lt_i32 s8, s58                                       // 0000001AEC34: BF043A08
	v_cndmask_b16 v181, 0, v56, s0                             // 0000001AEC38: D65D00B5 00027080
	s_cselect_b32 s1, -1, 0                                    // 0000001AEC40: 980180C1
	s_or_b32 s8, s29, 28                                       // 0000001AEC44: 8C089C1D
	v_fma_mixlo_f16 v56, v177, s22, 0                          // 0000001AEC48: CC210038 02002DB1
	s_cmp_lt_i32 s8, s58                                       // 0000001AEC50: BF043A08
	v_mul_f32_e32 v177, v179, v182                             // 0000001AEC54: 11636DB3
	s_cselect_b32 s0, -1, 0                                    // 0000001AEC58: 980080C1
	s_or_b32 s8, s29, 29                                       // 0000001AEC5C: 8C089D1D
	v_cndmask_b16 v181, 0, v56, s1                             // 0000001AEC60: D65D50B5 00067080
	s_cmp_lt_i32 s8, s58                                       // 0000001AEC68: BF043A08
	v_cndmask_b16 v182, 0, v56, s0                             // 0000001AEC6C: D65D00B6 00027080
	s_cselect_b32 s0, -1, 0                                    // 0000001AEC74: 980080C1
	s_or_b32 s1, s29, 30                                       // 0000001AEC78: 8C019E1D
	v_fma_mixlo_f16 v56, v177, s22, 0                          // 0000001AEC7C: CC210038 02002DB1
	s_cmp_lt_i32 s1, s58                                       // 0000001AEC84: BF043A01
	v_fma_mixhi_f16 v56, v178, s22, 0                          // 0000001AEC88: CC220038 02002DB2
	s_cselect_b32 s1, -1, 0                                    // 0000001AEC90: 980180C1
	s_or_b32 s8, s29, 31                                       // 0000001AEC94: 8C089F1D
	v_cndmask_b16 v182, 0, v56, s0                             // 0000001AEC98: D65D40B6 00027080
	s_cmp_lt_i32 s8, s58                                       // 0000001AECA0: BF043A08
	v_cndmask_b16 v183, 0, v56, s1                             // 0000001AECA4: D65D10B7 00067080
	s_cselect_b32 s0, -1, 0                                    // 0000001AECAC: 980080C1
	ds_load_2addr_b32 v[177:178], v157 offset1:1               // 0000001AECB0: D8DC0100 B100009D
	v_cndmask_b16 v183, 0, v176, s0                            // 0000001AECB8: D65D40B7 00036080
	ds_store_b128 v125, v[52:55] offset:32                     // 0000001AECC0: DB7C0020 0000347D
	ds_store_b128 v125, v[180:183] offset:48                   // 0000001AECC8: DB7C0030 0000B47D
	ds_load_2addr_b32 v[54:55], v163 offset1:1                 // 0000001AECD0: D8DC0100 360000A3
	ds_load_2addr_b32 v[104:105], v164 offset1:1               // 0000001AECD8: D8DC0100 680000A4
	v_mul_f32_e32 v17, v175, v190                              // 0000001AECE0: 10237DAF
	s_or_b32 s0, s29, 32                                       // 0000001AECE4: 8C00A01D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AECE8: BF870009
	s_cmp_lt_i32 s0, s58                                       // 0000001AECEC: BF043A00
	s_cselect_b32 s0, -1, 0                                    // 0000001AECF0: 980080C1
	s_waitcnt lgkmcnt(4)                                       // 0000001AECF4: BF89FC47
	v_mul_f32_e32 v18, v174, v177                              // 0000001AECF8: 102563AE
	v_mul_f32_e32 v52, v173, v178                              // 0000001AECFC: 106965AD
	s_waitcnt lgkmcnt(1)                                       // 0000001AED00: BF89FC17
	v_mul_f32_e32 v42, v42, v55                                // 0000001AED04: 10546F2A
	v_fma_mixlo_f16 v17, v17, s22, 0                           // 0000001AED08: CC210011 02002D11
	v_fma_mixhi_f16 v17, v18, s22, 0                           // 0000001AED10: CC220011 02002D12
	v_fma_mixhi_f16 v18, v19, s22, 0                           // 0000001AED18: CC220012 02002D13
	v_fma_mixlo_f16 v19, v20, s22, 0                           // 0000001AED20: CC210013 02002D14
	v_mul_f32_e32 v20, v116, v21                               // 0000001AED28: 10282B74
	v_cndmask_b16 v17, 0, v17, s0                              // 0000001AED2C: D65D0011 00022280
	s_or_b32 s0, s29, 33                                       // 0000001AED34: 8C00A11D
	v_mul_f32_e32 v21, v172, v22                               // 0000001AED38: 102A2DAC
	s_cmp_lt_i32 s0, s58                                       // 0000001AED3C: BF043A00
	v_fma_mixlo_f16 v18, v52, s22, 0                           // 0000001AED40: CC210012 02002D34
	s_cselect_b32 s0, -1, 0                                    // 0000001AED48: 980080C1
	s_or_b32 s1, s29, 34                                       // 0000001AED4C: 8C01A21D
	v_cndmask_b16 v17, 0, v17, s0                              // 0000001AED50: D65D5011 00022280
	s_cmp_lt_i32 s1, s58                                       // 0000001AED58: BF043A01
	ds_load_2addr_b32 v[52:53], v161 offset1:1                 // 0000001AED5C: D8DC0100 340000A1
	s_cselect_b32 s0, -1, 0                                    // 0000001AED64: 980080C1
	s_or_b32 s1, s29, 35                                       // 0000001AED68: 8C01A31D
	v_fma_mixhi_f16 v19, v20, s22, 0                           // 0000001AED6C: CC220013 02002D14
	s_cmp_lt_i32 s1, s58                                       // 0000001AED74: BF043A01
	v_mul_f32_e32 v22, v117, v23                               // 0000001AED78: 102C2F75
	v_fma_mixlo_f16 v20, v21, s22, 0                           // 0000001AED7C: CC210014 02002D15
	v_mul_f32_e32 v21, v102, v24                               // 0000001AED84: 102A3166
	ds_load_2addr_b32 v[23:24], v162 offset1:1                 // 0000001AED88: D8DC0100 170000A2
	v_cndmask_b16 v18, 0, v18, s0                              // 0000001AED90: D65D0012 00022480
	s_cselect_b32 s0, -1, 0                                    // 0000001AED98: 980080C1
	s_or_b32 s1, s29, 36                                       // 0000001AED9C: 8C01A41D
	v_cndmask_b16 v18, 0, v18, s0                              // 0000001AEDA0: D65D5012 00022480
	s_cmp_lt_i32 s1, s58                                       // 0000001AEDA8: BF043A01
	v_fma_mixhi_f16 v20, v22, s22, 0                           // 0000001AEDAC: CC220014 02002D16
	s_cselect_b32 s1, -1, 0                                    // 0000001AEDB4: 980180C1
	s_or_b32 s8, s29, 37                                       // 0000001AEDB8: 8C08A51D
	v_cndmask_b16 v19, 0, v19, s1                              // 0000001AEDBC: D65D0013 00062680
	s_cmp_lt_i32 s8, s58                                       // 0000001AEDC4: BF043A08
	v_fma_mixlo_f16 v21, v21, s22, 0                           // 0000001AEDC8: CC210015 02002D15
	s_cselect_b32 s0, -1, 0                                    // 0000001AEDD0: 980080C1
	s_or_b32 s8, s29, 38                                       // 0000001AEDD4: 8C08A61D
	v_cndmask_b16 v19, 0, v19, s0                              // 0000001AEDD8: D65D5013 00022680
	s_cmp_lt_i32 s8, s58                                       // 0000001AEDE0: BF043A08
	s_waitcnt lgkmcnt(1)                                       // 0000001AEDE4: BF89FC17
	v_mul_f32_e32 v22, v99, v52                                // 0000001AEDE8: 102C6963
	s_cselect_b32 s1, -1, 0                                    // 0000001AEDEC: 980180C1
	s_or_b32 s8, s29, 39                                       // 0000001AEDF0: 8C08A71D
	v_cndmask_b16 v20, 0, v20, s1                              // 0000001AEDF4: D65D0014 00062880
	s_cmp_lt_i32 s8, s58                                       // 0000001AEDFC: BF043A08
	s_waitcnt lgkmcnt(0)                                       // 0000001AEE00: BF89FC07
	v_mul_f32_e32 v23, v101, v23                               // 0000001AEE04: 102E2F65
	s_cselect_b32 s0, -1, 0                                    // 0000001AEE08: 980080C1
	s_or_b32 s1, s29, 40                                       // 0000001AEE0C: 8C01A81D
	v_mul_f32_e32 v24, v100, v24                               // 0000001AEE10: 10303164
	s_cmp_lt_i32 s1, s58                                       // 0000001AEE14: BF043A01
	v_cndmask_b16 v20, 0, v20, s0                              // 0000001AEE18: D65D5014 00022880
	s_cselect_b32 s0, -1, 0                                    // 0000001AEE20: 980080C1
	v_mul_f32_e32 v52, v103, v53                               // 0000001AEE24: 10686B67
	v_cndmask_b16 v21, 0, v21, s0                              // 0000001AEE28: D65D0015 00022A80
	s_or_b32 s0, s29, 41                                       // 0000001AEE30: 8C00A91D
	v_fma_mixhi_f16 v21, v22, s22, 0                           // 0000001AEE34: CC220015 02002D16
	s_cmp_lt_i32 s0, s58                                       // 0000001AEE3C: BF043A00
	v_fma_mixhi_f16 v22, v23, s22, 0                           // 0000001AEE40: CC220016 02002D17
	v_fma_mixlo_f16 v23, v24, s22, 0                           // 0000001AEE48: CC210017 02002D18
	v_mul_f32_e32 v24, v46, v54                                // 0000001AEE50: 10306D2E
	s_cselect_b32 s0, -1, 0                                    // 0000001AEE54: 980080C1
	s_or_b32 s1, s29, 42                                       // 0000001AEE58: 8C01AA1D
	v_fma_mixlo_f16 v22, v52, s22, 0                           // 0000001AEE5C: CC210016 02002D34
	s_cmp_lt_i32 s1, s58                                       // 0000001AEE64: BF043A01
	ds_load_2addr_b32 v[52:53], v165 offset1:1                 // 0000001AEE68: D8DC0100 340000A5
	v_fma_mixhi_f16 v23, v24, s22, 0                           // 0000001AEE70: CC220017 02002D18
	v_mul_f32_e32 v46, v49, v104                               // 0000001AEE78: 105CD131
	v_fma_mixlo_f16 v24, v42, s22, 0                           // 0000001AEE7C: CC210018 02002D2A
	v_mul_f32_e32 v42, v48, v105                               // 0000001AEE84: 1054D330
	ds_load_2addr_b32 v[48:49], v166 offset1:1                 // 0000001AEE88: D8DC0100 300000A6
	v_cndmask_b16 v21, 0, v21, s0                              // 0000001AEE90: D65D5015 00022A80
	s_cselect_b32 s0, -1, 0                                    // 0000001AEE98: 980080C1
	s_or_b32 s1, s29, 43                                       // 0000001AEE9C: 8C01AB1D
	v_cndmask_b16 v22, 0, v22, s0                              // 0000001AEEA0: D65D0016 00022C80
	s_cmp_lt_i32 s1, s58                                       // 0000001AEEA8: BF043A01
	ds_load_2addr_b32 v[54:55], v167 offset1:1                 // 0000001AEEAC: D8DC0100 360000A7
	ds_load_2addr_b32 v[99:100], v168 offset1:1                // 0000001AEEB4: D8DC0100 630000A8
	s_cselect_b32 s0, -1, 0                                    // 0000001AEEBC: 980080C1
	s_or_b32 s1, s29, 44                                       // 0000001AEEC0: 8C01AC1D
	v_cndmask_b16 v22, 0, v22, s0                              // 0000001AEEC4: D65D5016 00022C80
	s_cmp_lt_i32 s1, s58                                       // 0000001AEECC: BF043A01
	v_fma_mixhi_f16 v24, v46, s22, 0                           // 0000001AEED0: CC220018 02002D2E
	s_cselect_b32 s1, -1, 0                                    // 0000001AEED8: 980180C1
	s_or_b32 s8, s29, 45                                       // 0000001AEEDC: 8C08AD1D
	v_cndmask_b16 v23, 0, v23, s1                              // 0000001AEEE0: D65D0017 00062E80
	s_cmp_lt_i32 s8, s58                                       // 0000001AEEE8: BF043A08
	v_fma_mixlo_f16 v42, v42, s22, 0                           // 0000001AEEEC: CC21002A 02002D2A
	s_cselect_b32 s0, -1, 0                                    // 0000001AEEF4: 980080C1
	s_or_b32 s8, s29, 46                                       // 0000001AEEF8: 8C08AE1D
	v_cndmask_b16 v23, 0, v23, s0                              // 0000001AEEFC: D65D5017 00022E80
	s_cmp_lt_i32 s8, s58                                       // 0000001AEF04: BF043A08
	s_waitcnt lgkmcnt(2)                                       // 0000001AEF08: BF89FC27
	v_mul_f32_e32 v27, v27, v48                                // 0000001AEF0C: 1036611B
	s_cselect_b32 s1, -1, 0                                    // 0000001AEF10: 980180C1
	s_or_b32 s8, s29, 47                                       // 0000001AEF14: 8C08AF1D
	v_mul_f32_e32 v32, v32, v49                                // 0000001AEF18: 10406320
	s_cmp_lt_i32 s8, s58                                       // 0000001AEF1C: BF043A08
	v_cndmask_b16 v24, 0, v24, s1                              // 0000001AEF20: D65D0018 00063080
	s_cselect_b32 s0, -1, 0                                    // 0000001AEF28: 980080C1
	s_or_b32 s1, s29, 48                                       // 0000001AEF2C: 8C01B01D
	v_cndmask_b16 v24, 0, v24, s0                              // 0000001AEF30: D65D5018 00023080
	s_cmp_lt_i32 s1, s58                                       // 0000001AEF38: BF043A01
	s_waitcnt lgkmcnt(0)                                       // 0000001AEF3C: BF89FC07
	v_mul_f32_e32 v28, v28, v99                                // 0000001AEF40: 1038C71C
	s_cselect_b32 s0, -1, 0                                    // 0000001AEF44: 980080C1
	v_fma_mixlo_f16 v27, v27, s22, 0                           // 0000001AEF48: CC21001B 02002D1B
	v_fma_mixhi_f16 v27, v32, s22, 0                           // 0000001AEF50: CC22001B 02002D20
	ds_load_b32 v32, v107 offset:61692                         // 0000001AEF58: D8D8F0FC 2000006B
	v_mul_f32_e32 v43, v43, v52                                // 0000001AEF60: 1056692B
	v_cndmask_b16 v52, 0, v42, s0                              // 0000001AEF64: D65D0034 00025480
	s_or_b32 s0, s29, 49                                       // 0000001AEF6C: 8C00B11D
	v_mul_f32_e32 v42, v41, v53                                // 0000001AEF70: 10546B29
	s_cmp_lt_i32 s0, s58                                       // 0000001AEF74: BF043A00
	v_fma_mixlo_f16 v41, v43, s22, 0                           // 0000001AEF78: CC210029 02002D2B
	s_cselect_b32 s0, -1, 0                                    // 0000001AEF80: 980080C1
	s_or_b32 s1, s29, 50                                       // 0000001AEF84: 8C01B21D
	v_fma_mixhi_f16 v41, v42, s22, 0                           // 0000001AEF88: CC220029 02002D2A
	s_cmp_lt_i32 s1, s58                                       // 0000001AEF90: BF043A01
	v_cndmask_b16 v52, 0, v41, s0                              // 0000001AEF94: D65D4034 00025280
	s_cselect_b32 s0, -1, 0                                    // 0000001AEF9C: 980080C1
	s_or_b32 s1, s29, 51                                       // 0000001AEFA0: 8C01B31D
	v_cndmask_b16 v53, 0, v41, s0                              // 0000001AEFA4: D65D1035 00025280
	v_mul_f32_e32 v41, v44, v54                                // 0000001AEFAC: 10526D2C
	s_cmp_lt_i32 s1, s58                                       // 0000001AEFB0: BF043A01
	ds_load_2addr_b32 v[43:44], v170 offset1:1                 // 0000001AEFB4: D8DC0100 2B0000AA
	ds_load_2addr_b32 v[48:49], v171 offset1:1                 // 0000001AEFBC: D8DC0100 300000AB
	s_cselect_b32 s0, -1, 0                                    // 0000001AEFC4: 980080C1
	s_or_b32 s1, s29, 52                                       // 0000001AEFC8: 8C01B41D
	v_cndmask_b16 v53, 0, v27, s0                              // 0000001AEFCC: D65D4035 00023680
	v_fma_mixlo_f16 v27, v41, s22, 0                           // 0000001AEFD4: CC21001B 02002D29
	ds_load_2addr_b32 v[41:42], v169 offset1:1                 // 0000001AEFDC: D8DC0100 290000A9
	s_cmp_lt_i32 s1, s58                                       // 0000001AEFE4: BF043A01
	v_mul_f32_e32 v29, v29, v55                                // 0000001AEFE8: 103A6F1D
	s_cselect_b32 s1, -1, 0                                    // 0000001AEFEC: 980180C1
	s_or_b32 s8, s29, 53                                       // 0000001AEFF0: 8C08B51D
	v_cndmask_b16 v54, 0, v27, s1                              // 0000001AEFF4: D65D1036 00063680
	s_cmp_lt_i32 s8, s58                                       // 0000001AEFFC: BF043A08
	v_fma_mixhi_f16 v27, v28, s22, 0                           // 0000001AF000: CC22001B 02002D1C
	s_cselect_b32 s0, -1, 0                                    // 0000001AF008: 980080C1
	v_mul_f32_e32 v25, v25, v100                               // 0000001AF00C: 1032C919
	v_cndmask_b16 v54, 0, v27, s0                              // 0000001AF010: D65D4036 00023680
	s_or_b32 s0, s29, 54                                       // 0000001AF018: 8C00B61D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AF01C: BF870119
	s_cmp_lt_i32 s0, s58                                       // 0000001AF020: BF043A00
	v_fma_mixlo_f16 v25, v25, s22, 0                           // 0000001AF024: CC210019 02002D19
	s_cselect_b32 s0, -1, 0                                    // 0000001AF02C: 980080C1
	s_or_b32 s1, s29, 55                                       // 0000001AF030: 8C01B71D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AF034: BF870009
	s_cmp_lt_i32 s1, s58                                       // 0000001AF038: BF043A01
	s_waitcnt lgkmcnt(0)                                       // 0000001AF03C: BF89FC07
	v_mul_f32_e32 v28, v47, v42                                // 0000001AF040: 1038552F
	v_fma_mixlo_f16 v27, v29, s22, 0                           // 0000001AF044: CC21001B 02002D1D
	v_mul_f32_e32 v29, v30, v44                                // 0000001AF04C: 103A591E
	v_mul_f32_e32 v30, v51, v32                                // 0000001AF050: 103C4133
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AF054: BF870214
	v_fma_mixlo_f16 v28, v28, s22, 0                           // 0000001AF058: CC21001C 02002D1C
	v_cndmask_b16 v55, 0, v27, s0                              // 0000001AF060: D65D0037 00023680
	s_cselect_b32 s0, -1, 0                                    // 0000001AF068: 980080C1
	s_or_b32 s1, s29, 56                                       // 0000001AF06C: 8C01B81D
	v_cndmask_b16 v55, 0, v27, s0                              // 0000001AF070: D65D5037 00023680
	s_cmp_lt_i32 s1, s58                                       // 0000001AF078: BF043A01
	v_mul_f32_e32 v27, v45, v41                                // 0000001AF07C: 1036532D
	s_cselect_b32 s0, -1, 0                                    // 0000001AF080: 980080C1
	s_or_b32 s1, s29, 57                                       // 0000001AF084: 8C01B91D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF088: BF870099
	s_cmp_lt_i32 s1, s58                                       // 0000001AF08C: BF043A01
	v_fma_mixhi_f16 v25, v27, s22, 0                           // 0000001AF090: CC220019 02002D1B
	s_cselect_b32 s1, -1, 0                                    // 0000001AF098: 980180C1
	s_or_b32 s8, s29, 58                                       // 0000001AF09C: 8C08BA1D
	v_cndmask_b16 v27, 0, v25, s0                              // 0000001AF0A0: D65D001B 00023280
	s_cmp_lt_i32 s8, s58                                       // 0000001AF0A8: BF043A08
	v_cndmask_b16 v27, 0, v25, s1                              // 0000001AF0AC: D65D501B 00063280
	s_cselect_b32 s0, -1, 0                                    // 0000001AF0B4: 980080C1
	v_mul_f32_e32 v25, v31, v43                                // 0000001AF0B8: 1032571F
	v_cndmask_b16 v28, 0, v28, s0                              // 0000001AF0BC: D65D001C 00023880
	s_or_b32 s0, s29, 59                                       // 0000001AF0C4: 8C00BB1D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AF0C8: BF870119
	s_cmp_lt_i32 s0, s58                                       // 0000001AF0CC: BF043A00
	v_fma_mixlo_f16 v25, v25, s22, 0                           // 0000001AF0D0: CC210019 02002D19
	s_cselect_b32 s0, -1, 0                                    // 0000001AF0D8: 980080C1
	s_or_b32 s1, s29, 60                                       // 0000001AF0DC: 8C01BC1D
	v_fma_mixhi_f16 v25, v29, s22, 0                           // 0000001AF0E0: CC220019 02002D1D
	s_cmp_lt_i32 s1, s58                                       // 0000001AF0E8: BF043A01
	v_cndmask_b16 v28, 0, v25, s0                              // 0000001AF0EC: D65D401C 00023280
	s_cselect_b32 s1, -1, 0                                    // 0000001AF0F4: 980180C1
	s_or_b32 s8, s29, 61                                       // 0000001AF0F8: 8C08BD1D
	v_cndmask_b16 v29, 0, v25, s1                              // 0000001AF0FC: D65D101D 00063280
	s_cmp_lt_i32 s8, s58                                       // 0000001AF104: BF043A08
	v_mul_f32_e32 v25, v26, v48                                // 0000001AF108: 1032611A
	s_cselect_b32 s0, -1, 0                                    // 0000001AF10C: 980080C1
	s_or_b32 s1, s29, 62                                       // 0000001AF110: 8C01BE1D
	v_mul_f32_e32 v26, v50, v49                                // 0000001AF114: 10346332
	s_cmp_lt_i32 s1, s58                                       // 0000001AF118: BF043A01
	v_fma_mixlo_f16 v25, v25, s22, 0                           // 0000001AF11C: CC210019 02002D19
	s_cselect_b32 s1, -1, 0                                    // 0000001AF124: 980180C1
	s_or_b32 s8, s29, 63                                       // 0000001AF128: 8C08BF1D
	v_fma_mixhi_f16 v25, v26, s22, 0                           // 0000001AF12C: CC220019 02002D1A
	v_fma_mixlo_f16 v26, v30, s22, 0                           // 0000001AF134: CC21001A 02002D1E
	s_cmp_lt_i32 s8, s58                                       // 0000001AF13C: BF043A08
	v_cndmask_b16 v29, 0, v25, s0                              // 0000001AF140: D65D401D 00023280
	s_cselect_b32 s0, -1, 0                                    // 0000001AF148: 980080C1
	v_cndmask_b16 v30, 0, v25, s1                              // 0000001AF14C: D65D101E 00063280
	v_cndmask_b16 v30, 0, v26, s0                              // 0000001AF154: D65D401E 00023480
	ds_store_b128 v125, v[17:20] offset:64                     // 0000001AF15C: DB7C0040 0000117D
	ds_store_b128 v125, v[21:24] offset:80                     // 0000001AF164: DB7C0050 0000157D
	ds_store_b128 v125, v[52:55] offset:96                     // 0000001AF16C: DB7C0060 0000347D
	ds_store_b128 v125, v[27:30] offset:112                    // 0000001AF174: DB7C0070 00001B7D
	s_and_saveexec_b32 s0, vcc_lo                              // 0000001AF17C: BE80206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AF180: BF870009
	s_xor_b32 s0, exec_lo, s0                                  // 0000001AF184: 8D00007E
	s_cbranch_execz 67                                         // 0000001AF188: BFA50043 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x2898>
	s_waitcnt vmcnt(1)                                         // 0000001AF18C: BF8907F7
	v_mov_b32_e32 v1, 0                                        // 0000001AF190: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AF194: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000001AF198: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000001AF19C: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000001AF1A0: 7E080301
	s_waitcnt vmcnt(0)                                         // 0000001AF1A4: BF8903F7
	v_mov_b32_e32 v5, v1                                       // 0000001AF1A8: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000001AF1AC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000001AF1B0: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000001AF1B4: 7E100301
	v_mov_b32_e32 v9, v1                                       // 0000001AF1B8: 7E120301
	v_mov_b32_e32 v10, v1                                      // 0000001AF1BC: 7E140301
	v_mov_b32_e32 v11, v1                                      // 0000001AF1C0: 7E160301
	v_mov_b32_e32 v12, v1                                      // 0000001AF1C4: 7E180301
	v_mov_b32_e32 v13, v1                                      // 0000001AF1C8: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 0000001AF1CC: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 0000001AF1D0: 7E1E0301
	v_mov_b32_e32 v16, v1                                      // 0000001AF1D4: 7E200301
	v_mov_b32_e32 v33, v1                                      // 0000001AF1D8: 7E420301
	v_mov_b32_e32 v34, v1                                      // 0000001AF1DC: 7E440301
	v_mov_b32_e32 v35, v1                                      // 0000001AF1E0: 7E460301
	v_mov_b32_e32 v36, v1                                      // 0000001AF1E4: 7E480301
	v_mov_b32_e32 v37, v1                                      // 0000001AF1E8: 7E4A0301
	v_mov_b32_e32 v38, v1                                      // 0000001AF1EC: 7E4C0301
	v_mov_b32_e32 v39, v1                                      // 0000001AF1F0: 7E4E0301
	v_mov_b32_e32 v40, v1                                      // 0000001AF1F4: 7E500301
	v_mov_b32_e32 v57, v1                                      // 0000001AF1F8: 7E720301
	v_mov_b32_e32 v58, v1                                      // 0000001AF1FC: 7E740301
	v_mov_b32_e32 v59, v1                                      // 0000001AF200: 7E760301
	v_mov_b32_e32 v60, v1                                      // 0000001AF204: 7E780301
	v_mov_b32_e32 v61, v1                                      // 0000001AF208: 7E7A0301
	v_mov_b32_e32 v62, v1                                      // 0000001AF20C: 7E7C0301
	v_mov_b32_e32 v63, v1                                      // 0000001AF210: 7E7E0301
	v_mov_b32_e32 v64, v1                                      // 0000001AF214: 7E800301
	v_mov_b32_e32 v65, v1                                      // 0000001AF218: 7E820301
	v_mov_b32_e32 v66, v1                                      // 0000001AF21C: 7E840301
	v_mov_b32_e32 v67, v1                                      // 0000001AF220: 7E860301
	v_mov_b32_e32 v68, v1                                      // 0000001AF224: 7E880301
	v_mov_b32_e32 v69, v1                                      // 0000001AF228: 7E8A0301
	v_mov_b32_e32 v70, v1                                      // 0000001AF22C: 7E8C0301
	v_mov_b32_e32 v71, v1                                      // 0000001AF230: 7E8E0301
	v_mov_b32_e32 v72, v1                                      // 0000001AF234: 7E900301
	v_mov_b32_e32 v73, v1                                      // 0000001AF238: 7E920301
	v_mov_b32_e32 v74, v1                                      // 0000001AF23C: 7E940301
	v_mov_b32_e32 v75, v1                                      // 0000001AF240: 7E960301
	v_mov_b32_e32 v76, v1                                      // 0000001AF244: 7E980301
	v_mov_b32_e32 v77, v1                                      // 0000001AF248: 7E9A0301
	v_mov_b32_e32 v78, v1                                      // 0000001AF24C: 7E9C0301
	v_mov_b32_e32 v79, v1                                      // 0000001AF250: 7E9E0301
	v_mov_b32_e32 v80, v1                                      // 0000001AF254: 7EA00301
	v_mov_b32_e32 v81, v1                                      // 0000001AF258: 7EA20301
	v_mov_b32_e32 v82, v1                                      // 0000001AF25C: 7EA40301
	v_mov_b32_e32 v83, v1                                      // 0000001AF260: 7EA60301
	v_mov_b32_e32 v84, v1                                      // 0000001AF264: 7EA80301
	v_mov_b32_e32 v85, v1                                      // 0000001AF268: 7EAA0301
	v_mov_b32_e32 v86, v1                                      // 0000001AF26C: 7EAC0301
	v_mov_b32_e32 v87, v1                                      // 0000001AF270: 7EAE0301
	v_mov_b32_e32 v88, v1                                      // 0000001AF274: 7EB00301
	v_mov_b32_e32 v89, v1                                      // 0000001AF278: 7EB20301
	v_mov_b32_e32 v90, v1                                      // 0000001AF27C: 7EB40301
	v_mov_b32_e32 v91, v1                                      // 0000001AF280: 7EB60301
	v_mov_b32_e32 v92, v1                                      // 0000001AF284: 7EB80301
	v_mov_b32_e32 v93, v1                                      // 0000001AF288: 7EBA0301
	v_mov_b32_e32 v94, v1                                      // 0000001AF28C: 7EBC0301
	v_mov_b32_e32 v95, v1                                      // 0000001AF290: 7EBE0301
	v_mov_b32_e32 v96, v1                                      // 0000001AF294: 7EC00301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001AF298: 8C7E007E
	ds_load_b128 v[17:20], v127                                // 0000001AF29C: DBFC0000 1100007F
	ds_load_b128 v[21:24], v127 offset:16                      // 0000001AF2A4: DBFC0010 1500007F
	ds_load_b128 v[25:28], v127 offset:32                      // 0000001AF2AC: DBFC0020 1900007F
	ds_load_b128 v[29:32], v127 offset:48                      // 0000001AF2B4: DBFC0030 1D00007F
	ds_load_b128 v[41:44], v127 offset:8448                    // 0000001AF2BC: DBFC2100 2900007F
	ds_load_b128 v[45:48], v127 offset:8464                    // 0000001AF2C4: DBFC2110 2D00007F
	ds_load_b128 v[49:52], v127 offset:8480                    // 0000001AF2CC: DBFC2120 3100007F
	ds_load_b128 v[53:56], v127 offset:8496                    // 0000001AF2D4: DBFC2130 3500007F
	ds_load_b128 v[99:102], v127 offset:16896                  // 0000001AF2DC: DBFC4200 6300007F
	ds_load_b128 v[180:183], v127 offset:16912                 // 0000001AF2E4: DBFC4210 B400007F
	v_dual_mov_b32 v179, s43 :: v_dual_mov_b32 v178, s42       // 0000001AF2EC: CA10002B B3B2002A
	v_dual_mov_b32 v177, s41 :: v_dual_mov_b32 v176, s40       // 0000001AF2F4: CA100029 B1B00028
	v_dual_mov_b32 v175, s39 :: v_dual_mov_b32 v174, s38       // 0000001AF2FC: CA100027 AFAE0026
	v_dual_mov_b32 v173, s37 :: v_dual_mov_b32 v172, s36       // 0000001AF304: CA100025 ADAC0024
	ds_load_b128 v[184:187], v127 offset:25344                 // 0000001AF30C: DBFC6300 B800007F
	ds_load_b128 v[188:191], v127 offset:25360                 // 0000001AF314: DBFC6310 BC00007F
	s_waitcnt lgkmcnt(11)                                      // 0000001AF31C: BF89FCB7
	v_fma_mixlo_f16 v17, v17, s22, 0                           // 0000001AF320: CC210011 02002D11
	v_fma_mixhi_f16 v17, v18, s22, 0                           // 0000001AF328: CC220011 02002D12
	v_fma_mixlo_f16 v18, v19, s22, 0                           // 0000001AF330: CC210012 02002D13
	v_fma_mixhi_f16 v18, v20, s22, 0                           // 0000001AF338: CC220012 02002D14
	s_waitcnt lgkmcnt(10)                                      // 0000001AF340: BF89FCA7
	v_fma_mixlo_f16 v19, v21, s22, 0                           // 0000001AF344: CC210013 02002D15
	v_fma_mixhi_f16 v19, v22, s22, 0                           // 0000001AF34C: CC220013 02002D16
	v_fma_mixlo_f16 v20, v23, s22, 0                           // 0000001AF354: CC210014 02002D17
	v_fma_mixhi_f16 v20, v24, s22, 0                           // 0000001AF35C: CC220014 02002D18
	s_waitcnt lgkmcnt(9)                                       // 0000001AF364: BF89FC97
	v_fma_mixlo_f16 v21, v25, s22, 0                           // 0000001AF368: CC210015 02002D19
	v_fma_mixhi_f16 v21, v26, s22, 0                           // 0000001AF370: CC220015 02002D1A
	v_fma_mixlo_f16 v22, v27, s22, 0                           // 0000001AF378: CC210016 02002D1B
	v_fma_mixhi_f16 v22, v28, s22, 0                           // 0000001AF380: CC220016 02002D1C
	s_waitcnt lgkmcnt(8)                                       // 0000001AF388: BF89FC87
	v_fma_mixlo_f16 v23, v29, s22, 0                           // 0000001AF38C: CC210017 02002D1D
	v_fma_mixhi_f16 v23, v30, s22, 0                           // 0000001AF394: CC220017 02002D1E
	v_fma_mixlo_f16 v24, v31, s22, 0                           // 0000001AF39C: CC210018 02002D1F
	v_fma_mixhi_f16 v24, v32, s22, 0                           // 0000001AF3A4: CC220018 02002D20
	s_waitcnt lgkmcnt(7)                                       // 0000001AF3AC: BF89FC77
	v_fma_mixlo_f16 v25, v41, s22, 0                           // 0000001AF3B0: CC210019 02002D29
	v_fma_mixhi_f16 v25, v42, s22, 0                           // 0000001AF3B8: CC220019 02002D2A
	v_fma_mixlo_f16 v26, v43, s22, 0                           // 0000001AF3C0: CC21001A 02002D2B
	v_fma_mixhi_f16 v26, v44, s22, 0                           // 0000001AF3C8: CC22001A 02002D2C
	s_waitcnt lgkmcnt(6)                                       // 0000001AF3D0: BF89FC67
	v_fma_mixlo_f16 v27, v45, s22, 0                           // 0000001AF3D4: CC21001B 02002D2D
	v_fma_mixhi_f16 v27, v46, s22, 0                           // 0000001AF3DC: CC22001B 02002D2E
	v_fma_mixlo_f16 v28, v47, s22, 0                           // 0000001AF3E4: CC21001C 02002D2F
	v_fma_mixhi_f16 v28, v48, s22, 0                           // 0000001AF3EC: CC22001C 02002D30
	s_waitcnt lgkmcnt(5)                                       // 0000001AF3F4: BF89FC57
	v_fma_mixlo_f16 v29, v49, s22, 0                           // 0000001AF3F8: CC21001D 02002D31
	v_fma_mixhi_f16 v29, v50, s22, 0                           // 0000001AF400: CC22001D 02002D32
	v_fma_mixlo_f16 v30, v51, s22, 0                           // 0000001AF408: CC21001E 02002D33
	v_fma_mixhi_f16 v30, v52, s22, 0                           // 0000001AF410: CC22001E 02002D34
	s_waitcnt lgkmcnt(4)                                       // 0000001AF418: BF89FC47
	v_fma_mixlo_f16 v31, v53, s22, 0                           // 0000001AF41C: CC21001F 02002D35
	v_fma_mixhi_f16 v31, v54, s22, 0                           // 0000001AF424: CC22001F 02002D36
	v_fma_mixlo_f16 v32, v55, s22, 0                           // 0000001AF42C: CC210020 02002D37
	v_fma_mixhi_f16 v32, v56, s22, 0                           // 0000001AF434: CC220020 02002D38
	s_waitcnt vmcnt(14)                                        // 0000001AF43C: BF893BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[17:24], v[172:179]// 0000001AF440: CC404029 1EB22359
	ds_load_b128 v[49:52], v127 offset:16928                   // 0000001AF448: DBFC4220 3100007F
	ds_load_b128 v[53:56], v127 offset:16944                   // 0000001AF450: DBFC4230 3500007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[25:32], v[172:179]// 0000001AF458: CC404011 1EB23359
	s_waitcnt lgkmcnt(5)                                       // 0000001AF460: BF89FC57
	v_fma_mixlo_f16 v25, v99, s22, 0                           // 0000001AF464: CC210019 02002D63
	v_fma_mixhi_f16 v25, v100, s22, 0                          // 0000001AF46C: CC220019 02002D64
	v_fma_mixlo_f16 v26, v101, s22, 0                          // 0000001AF474: CC21001A 02002D65
	v_fma_mixhi_f16 v26, v102, s22, 0                          // 0000001AF47C: CC22001A 02002D66
	ds_load_b128 v[99:102], v127 offset:25376                  // 0000001AF484: DBFC6320 6300007F
	ds_load_b128 v[192:195], v127 offset:25392                 // 0000001AF48C: DBFC6330 C000007F
	s_waitcnt lgkmcnt(6)                                       // 0000001AF494: BF89FC67
	v_fma_mixlo_f16 v27, v180, s22, 0                          // 0000001AF498: CC21001B 02002DB4
	s_waitcnt lgkmcnt(5)                                       // 0000001AF4A0: BF89FC57
	v_fma_mixlo_f16 v180, v184, s22, 0                         // 0000001AF4A4: CC2100B4 02002DB8
	v_fma_mixhi_f16 v180, v185, s22, 0                         // 0000001AF4AC: CC2200B4 02002DB9
	v_fma_mixhi_f16 v27, v181, s22, 0                          // 0000001AF4B4: CC22001B 02002DB5
	v_fma_mixlo_f16 v28, v182, s22, 0                          // 0000001AF4BC: CC21001C 02002DB6
	v_fma_mixhi_f16 v28, v183, s22, 0                          // 0000001AF4C4: CC22001C 02002DB7
	v_fma_mixlo_f16 v181, v186, s22, 0                         // 0000001AF4CC: CC2100B5 02002DBA
	v_fma_mixhi_f16 v181, v187, s22, 0                         // 0000001AF4D4: CC2200B5 02002DBB
	s_waitcnt lgkmcnt(4)                                       // 0000001AF4DC: BF89FC47
	v_fma_mixlo_f16 v182, v188, s22, 0                         // 0000001AF4E0: CC2100B6 02002DBC
	v_fma_mixhi_f16 v182, v189, s22, 0                         // 0000001AF4E8: CC2200B6 02002DBD
	s_waitcnt lgkmcnt(3)                                       // 0000001AF4F0: BF89FC37
	v_fma_mixlo_f16 v29, v49, s22, 0                           // 0000001AF4F4: CC21001D 02002D31
	v_fma_mixhi_f16 v29, v50, s22, 0                           // 0000001AF4FC: CC22001D 02002D32
	v_fma_mixlo_f16 v30, v51, s22, 0                           // 0000001AF504: CC21001E 02002D33
	v_fma_mixhi_f16 v30, v52, s22, 0                           // 0000001AF50C: CC22001E 02002D34
	s_waitcnt lgkmcnt(2)                                       // 0000001AF514: BF89FC27
	v_fma_mixlo_f16 v31, v53, s22, 0                           // 0000001AF518: CC21001F 02002D35
	v_fma_mixhi_f16 v31, v54, s22, 0                           // 0000001AF520: CC22001F 02002D36
	v_fma_mixlo_f16 v32, v55, s22, 0                           // 0000001AF528: CC210020 02002D37
	v_fma_mixhi_f16 v32, v56, s22, 0                           // 0000001AF530: CC220020 02002D38
	s_waitcnt lgkmcnt(1)                                       // 0000001AF538: BF89FC17
	v_fma_mixlo_f16 v184, v99, s22, 0                          // 0000001AF53C: CC2100B8 02002D63
	v_fma_mixhi_f16 v184, v100, s22, 0                         // 0000001AF544: CC2200B8 02002D64
	v_fma_mixlo_f16 v185, v101, s22, 0                         // 0000001AF54C: CC2100B9 02002D65
	v_fma_mixhi_f16 v185, v102, s22, 0                         // 0000001AF554: CC2200B9 02002D66
	ds_load_b128 v[99:102], v127 offset:96                     // 0000001AF55C: DBFC0060 6300007F
	v_fma_mixlo_f16 v183, v190, s22, 0                         // 0000001AF564: CC2100B7 02002DBE
	v_fma_mixhi_f16 v183, v191, s22, 0                         // 0000001AF56C: CC2200B7 02002DBF
	s_waitcnt lgkmcnt(1)                                       // 0000001AF574: BF89FC17
	v_fma_mixlo_f16 v186, v192, s22, 0                         // 0000001AF578: CC2100BA 02002DC0
	v_fma_mixhi_f16 v186, v193, s22, 0                         // 0000001AF580: CC2200BA 02002DC1
	v_fma_mixlo_f16 v187, v194, s22, 0                         // 0000001AF588: CC2100BB 02002DC2
	v_fma_mixhi_f16 v187, v195, s22, 0                         // 0000001AF590: CC2200BB 02002DC3
	ds_load_b128 v[196:199], v127 offset:64                    // 0000001AF598: DBFC0040 C400007F
	ds_load_b128 v[188:191], v127 offset:80                    // 0000001AF5A0: DBFC0050 BC00007F
	ds_load_b128 v[192:195], v127 offset:112                   // 0000001AF5A8: DBFC0070 C000007F
	v_wmma_f32_16x16x16_f16 v[49:56], v[89:96], v[25:32], v[172:179]// 0000001AF5B0: CC404031 1EB23359
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[180:187], v[172:179]// 0000001AF5B8: CC404019 1EB36959
	ds_load_b128 v[172:175], v127 offset:8512                  // 0000001AF5C0: DBFC2140 AC00007F
	ds_load_b128 v[176:179], v127 offset:8528                  // 0000001AF5C8: DBFC2150 B000007F
	ds_load_b128 v[180:183], v127 offset:8544                  // 0000001AF5D0: DBFC2160 B400007F
	ds_load_b128 v[184:187], v127 offset:16960                 // 0000001AF5D8: DBFC4240 B800007F
	ds_load_b128 v[200:203], v127 offset:25424                 // 0000001AF5E0: DBFC6350 C800007F
	ds_load_b128 v[204:207], v127 offset:25440                 // 0000001AF5E8: DBFC6360 CC00007F
	ds_load_b128 v[208:211], v127 offset:25456                 // 0000001AF5F0: DBFC6370 D000007F
	s_waitcnt lgkmcnt(10)                                      // 0000001AF5F8: BF89FCA7
	v_fma_mixlo_f16 v93, v99, s22, 0                           // 0000001AF5FC: CC21005D 02002D63
	v_fma_mixhi_f16 v93, v100, s22, 0                          // 0000001AF604: CC22005D 02002D64
	v_fma_mixlo_f16 v94, v101, s22, 0                          // 0000001AF60C: CC21005E 02002D65
	v_fma_mixhi_f16 v94, v102, s22, 0                          // 0000001AF614: CC22005E 02002D66
	ds_load_b128 v[99:102], v127 offset:8560                   // 0000001AF61C: DBFC2170 6300007F
	s_waitcnt lgkmcnt(10)                                      // 0000001AF624: BF89FCA7
	v_fma_mixlo_f16 v89, v196, s22, 0                          // 0000001AF628: CC210059 02002DC4
	s_waitcnt lgkmcnt(9)                                       // 0000001AF630: BF89FC97
	v_fma_mixlo_f16 v91, v188, s22, 0                          // 0000001AF634: CC21005B 02002DBC
	v_fma_mixhi_f16 v91, v189, s22, 0                          // 0000001AF63C: CC22005B 02002DBD
	v_fma_mixlo_f16 v92, v190, s22, 0                          // 0000001AF644: CC21005C 02002DBE
	v_fma_mixhi_f16 v92, v191, s22, 0                          // 0000001AF64C: CC22005C 02002DBF
	ds_load_b128 v[188:191], v127 offset:16976                 // 0000001AF654: DBFC4250 BC00007F
	v_fma_mixhi_f16 v89, v197, s22, 0                          // 0000001AF65C: CC220059 02002DC5
	s_waitcnt lgkmcnt(8)                                       // 0000001AF664: BF89FC87
	v_fma_mixlo_f16 v172, v172, s22, 0                         // 0000001AF668: CC2100AC 02002DAC
	v_fma_mixhi_f16 v172, v173, s22, 0                         // 0000001AF670: CC2200AC 02002DAD
	v_fma_mixhi_f16 v173, v175, s22, 0                         // 0000001AF678: CC2200AD 02002DAF
	s_waitcnt lgkmcnt(7)                                       // 0000001AF680: BF89FC77
	v_fma_mixlo_f16 v175, v178, s22, 0                         // 0000001AF684: CC2100AF 02002DB2
	v_fma_mixhi_f16 v175, v179, s22, 0                         // 0000001AF68C: CC2200AF 02002DB3
	v_fma_mixlo_f16 v90, v198, s22, 0                          // 0000001AF694: CC21005A 02002DC6
	v_fma_mixhi_f16 v90, v199, s22, 0                          // 0000001AF69C: CC22005A 02002DC7
	v_fma_mixlo_f16 v95, v192, s22, 0                          // 0000001AF6A4: CC21005F 02002DC0
	v_fma_mixhi_f16 v95, v193, s22, 0                          // 0000001AF6AC: CC22005F 02002DC1
	v_fma_mixlo_f16 v96, v194, s22, 0                          // 0000001AF6B4: CC210060 02002DC2
	v_fma_mixhi_f16 v96, v195, s22, 0                          // 0000001AF6BC: CC220060 02002DC3
	s_waitcnt lgkmcnt(1)                                       // 0000001AF6C4: BF89FC17
	v_fma_mixlo_f16 v178, v99, s22, 0                          // 0000001AF6C8: CC2100B2 02002D63
	v_fma_mixhi_f16 v178, v100, s22, 0                         // 0000001AF6D0: CC2200B2 02002D64
	v_fma_mixlo_f16 v179, v101, s22, 0                         // 0000001AF6D8: CC2100B3 02002D65
	v_fma_mixhi_f16 v179, v102, s22, 0                         // 0000001AF6E0: CC2200B3 02002D66
	ds_load_b128 v[99:102], v127 offset:25408                  // 0000001AF6E8: DBFC6340 6300007F
	ds_load_b128 v[192:195], v127 offset:16992                 // 0000001AF6F0: DBFC4260 C000007F
	ds_load_b128 v[196:199], v127 offset:17008                 // 0000001AF6F8: DBFC4270 C400007F
	v_fma_mixlo_f16 v173, v174, s22, 0                         // 0000001AF700: CC2100AD 02002DAE
	v_fma_mixhi_f16 v174, v177, s22, 0                         // 0000001AF708: CC2200AE 02002DB1
	v_fma_mixlo_f16 v177, v182, s22, 0                         // 0000001AF710: CC2100B1 02002DB6
	s_waitcnt lgkmcnt(3)                                       // 0000001AF718: BF89FC37
	v_fma_mixlo_f16 v182, v188, s22, 0                         // 0000001AF71C: CC2100B6 02002DBC
	v_fma_mixhi_f16 v182, v189, s22, 0                         // 0000001AF724: CC2200B6 02002DBD
	v_fma_mixlo_f16 v174, v176, s22, 0                         // 0000001AF72C: CC2100AE 02002DB0
	v_fma_mixlo_f16 v176, v180, s22, 0                         // 0000001AF734: CC2100B0 02002DB4
	v_fma_mixhi_f16 v176, v181, s22, 0                         // 0000001AF73C: CC2200B0 02002DB5
	v_fma_mixhi_f16 v177, v183, s22, 0                         // 0000001AF744: CC2200B1 02002DB7
	v_fma_mixlo_f16 v180, v184, s22, 0                         // 0000001AF74C: CC2100B4 02002DB8
	v_fma_mixhi_f16 v180, v185, s22, 0                         // 0000001AF754: CC2200B4 02002DB9
	v_fma_mixlo_f16 v181, v186, s22, 0                         // 0000001AF75C: CC2100B5 02002DBA
	v_fma_mixhi_f16 v181, v187, s22, 0                         // 0000001AF764: CC2200B5 02002DBB
	v_fma_mixlo_f16 v183, v190, s22, 0                         // 0000001AF76C: CC2100B7 02002DBE
	v_fma_mixhi_f16 v183, v191, s22, 0                         // 0000001AF774: CC2200B7 02002DBF
	v_fma_mixlo_f16 v190, v200, s22, 0                         // 0000001AF77C: CC2100BE 02002DC8
	v_fma_mixhi_f16 v190, v201, s22, 0                         // 0000001AF784: CC2200BE 02002DC9
	s_waitcnt lgkmcnt(2)                                       // 0000001AF78C: BF89FC27
	v_fma_mixlo_f16 v188, v99, s22, 0                          // 0000001AF790: CC2100BC 02002D63
	v_fma_mixhi_f16 v188, v100, s22, 0                         // 0000001AF798: CC2200BC 02002D64
	v_fma_mixlo_f16 v189, v101, s22, 0                         // 0000001AF7A0: CC2100BD 02002D65
	v_fma_mixhi_f16 v189, v102, s22, 0                         // 0000001AF7A8: CC2200BD 02002D66
	ds_load_b128 v[99:102], v127 offset:128                    // 0000001AF7B0: DBFC0080 6300007F
	s_waitcnt lgkmcnt(2)                                       // 0000001AF7B8: BF89FC27
	v_fma_mixlo_f16 v184, v192, s22, 0                         // 0000001AF7BC: CC2100B8 02002DC0
	v_fma_mixhi_f16 v184, v193, s22, 0                         // 0000001AF7C4: CC2200B8 02002DC1
	v_fma_mixlo_f16 v185, v194, s22, 0                         // 0000001AF7CC: CC2100B9 02002DC2
	v_fma_mixhi_f16 v185, v195, s22, 0                         // 0000001AF7D4: CC2200B9 02002DC3
	s_waitcnt lgkmcnt(1)                                       // 0000001AF7DC: BF89FC17
	v_fma_mixlo_f16 v186, v196, s22, 0                         // 0000001AF7E0: CC2100BA 02002DC4
	v_fma_mixhi_f16 v186, v197, s22, 0                         // 0000001AF7E8: CC2200BA 02002DC5
	v_fma_mixlo_f16 v187, v198, s22, 0                         // 0000001AF7F0: CC2100BB 02002DC6
	v_fma_mixhi_f16 v187, v199, s22, 0                         // 0000001AF7F8: CC2200BB 02002DC7
	v_fma_mixlo_f16 v191, v202, s22, 0                         // 0000001AF800: CC2100BF 02002DCA
	v_fma_mixhi_f16 v191, v203, s22, 0                         // 0000001AF808: CC2200BF 02002DCB
	v_fma_mixlo_f16 v192, v204, s22, 0                         // 0000001AF810: CC2100C0 02002DCC
	v_fma_mixhi_f16 v192, v205, s22, 0                         // 0000001AF818: CC2200C0 02002DCD
	v_fma_mixlo_f16 v193, v206, s22, 0                         // 0000001AF820: CC2100C1 02002DCE
	v_fma_mixhi_f16 v193, v207, s22, 0                         // 0000001AF828: CC2200C1 02002DCF
	v_fma_mixlo_f16 v194, v208, s22, 0                         // 0000001AF830: CC2100C2 02002DD0
	v_fma_mixhi_f16 v194, v209, s22, 0                         // 0000001AF838: CC2200C2 02002DD1
	v_fma_mixlo_f16 v195, v210, s22, 0                         // 0000001AF840: CC2100C3 02002DD2
	v_fma_mixhi_f16 v195, v211, s22, 0                         // 0000001AF848: CC2200C3 02002DD3
	ds_load_b128 v[196:199], v127 offset:144                   // 0000001AF850: DBFC0090 C400007F
	ds_load_b128 v[200:203], v127 offset:160                   // 0000001AF858: DBFC00A0 C800007F
	s_waitcnt vmcnt(12)                                        // 0000001AF860: BF8933F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[89:96], v[41:48]// 0000001AF864: CC404029 1CA6B351
	ds_load_b128 v[89:92], v127 offset:176                     // 0000001AF86C: DBFC00B0 5900007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[172:179], v[17:24]// 0000001AF874: CC404011 1C475951
	v_wmma_f32_16x16x16_f16 v[49:56], v[81:88], v[180:187], v[49:56]// 0000001AF87C: CC404031 1CC76951
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[188:195], v[25:32]// 0000001AF884: CC404019 1C677951
	ds_load_b128 v[93:96], v127 offset:8576                    // 0000001AF88C: DBFC2180 5D00007F
	s_waitcnt lgkmcnt(4)                                       // 0000001AF894: BF89FC47
	v_fma_mixlo_f16 v81, v99, s22, 0                           // 0000001AF898: CC210051 02002D63
	v_fma_mixhi_f16 v81, v100, s22, 0                          // 0000001AF8A0: CC220051 02002D64
	v_fma_mixlo_f16 v82, v101, s22, 0                          // 0000001AF8A8: CC210052 02002D65
	v_fma_mixhi_f16 v82, v102, s22, 0                          // 0000001AF8B0: CC220052 02002D66
	ds_load_b128 v[99:102], v127 offset:8592                   // 0000001AF8B8: DBFC2190 6300007F
	ds_load_b128 v[172:175], v127 offset:8608                  // 0000001AF8C0: DBFC21A0 AC00007F
	ds_load_b128 v[176:179], v127 offset:8624                  // 0000001AF8C8: DBFC21B0 B000007F
	ds_load_b128 v[180:183], v127 offset:17024                 // 0000001AF8D0: DBFC4280 B400007F
	ds_load_b128 v[184:187], v127 offset:17040                 // 0000001AF8D8: DBFC4290 B800007F
	ds_load_b128 v[188:191], v127 offset:17072                 // 0000001AF8E0: DBFC42B0 BC00007F
	ds_load_b128 v[192:195], v127 offset:25472                 // 0000001AF8E8: DBFC6380 C000007F
	ds_load_b128 v[204:207], v127 offset:25520                 // 0000001AF8F0: DBFC63B0 CC00007F
	s_waitcnt lgkmcnt(11)                                      // 0000001AF8F8: BF89FCB7
	v_fma_mixlo_f16 v83, v196, s22, 0                          // 0000001AF8FC: CC210053 02002DC4
	v_fma_mixhi_f16 v83, v197, s22, 0                          // 0000001AF904: CC220053 02002DC5
	v_fma_mixlo_f16 v84, v198, s22, 0                          // 0000001AF90C: CC210054 02002DC6
	s_waitcnt lgkmcnt(9)                                       // 0000001AF914: BF89FC97
	v_fma_mixlo_f16 v88, v91, s22, 0                           // 0000001AF918: CC210058 02002D5B
	v_fma_mixhi_f16 v88, v92, s22, 0                           // 0000001AF920: CC220058 02002D5C
	v_fma_mixhi_f16 v84, v199, s22, 0                          // 0000001AF928: CC220054 02002DC7
	v_fma_mixlo_f16 v85, v200, s22, 0                          // 0000001AF930: CC210055 02002DC8
	v_fma_mixhi_f16 v85, v201, s22, 0                          // 0000001AF938: CC220055 02002DC9
	v_fma_mixlo_f16 v86, v202, s22, 0                          // 0000001AF940: CC210056 02002DCA
	v_fma_mixhi_f16 v86, v203, s22, 0                          // 0000001AF948: CC220056 02002DCB
	ds_load_b128 v[196:199], v127 offset:25488                 // 0000001AF950: DBFC6390 C400007F
	ds_load_b128 v[200:203], v127 offset:25504                 // 0000001AF958: DBFC63A0 C800007F
	s_waitcnt lgkmcnt(9)                                       // 0000001AF960: BF89FC97
	v_fma_mixlo_f16 v91, v99, s22, 0                           // 0000001AF964: CC21005B 02002D63
	v_fma_mixhi_f16 v91, v100, s22, 0                          // 0000001AF96C: CC22005B 02002D64
	v_fma_mixlo_f16 v92, v101, s22, 0                          // 0000001AF974: CC21005C 02002D65
	v_fma_mixhi_f16 v92, v102, s22, 0                          // 0000001AF97C: CC22005C 02002D66
	ds_load_b128 v[99:102], v127 offset:17056                  // 0000001AF984: DBFC42A0 6300007F
	v_fma_mixhi_f16 v87, v90, s22, 0                           // 0000001AF98C: CC220057 02002D5A
	v_fma_mixlo_f16 v90, v95, s22, 0                           // 0000001AF994: CC21005A 02002D5F
	s_waitcnt lgkmcnt(8)                                       // 0000001AF99C: BF89FC87
	v_fma_mixlo_f16 v95, v176, s22, 0                          // 0000001AF9A0: CC21005F 02002DB0
	v_fma_mixhi_f16 v95, v177, s22, 0                          // 0000001AF9A8: CC22005F 02002DB1
	v_fma_mixlo_f16 v87, v89, s22, 0                           // 0000001AF9B0: CC210057 02002D59
	v_fma_mixlo_f16 v89, v93, s22, 0                           // 0000001AF9B8: CC210059 02002D5D
	v_fma_mixhi_f16 v89, v94, s22, 0                           // 0000001AF9C0: CC220059 02002D5E
	v_fma_mixhi_f16 v90, v96, s22, 0                           // 0000001AF9C8: CC22005A 02002D60
	v_fma_mixlo_f16 v93, v172, s22, 0                          // 0000001AF9D0: CC21005D 02002DAC
	v_fma_mixhi_f16 v93, v173, s22, 0                          // 0000001AF9D8: CC22005D 02002DAD
	v_fma_mixlo_f16 v94, v174, s22, 0                          // 0000001AF9E0: CC21005E 02002DAE
	v_fma_mixhi_f16 v94, v175, s22, 0                          // 0000001AF9E8: CC22005E 02002DAF
	v_fma_mixlo_f16 v96, v178, s22, 0                          // 0000001AF9F0: CC210060 02002DB2
	v_fma_mixhi_f16 v96, v179, s22, 0                          // 0000001AF9F8: CC220060 02002DB3
	s_waitcnt lgkmcnt(7)                                       // 0000001AFA00: BF89FC77
	v_fma_mixlo_f16 v172, v180, s22, 0                         // 0000001AFA04: CC2100AC 02002DB4
	v_fma_mixhi_f16 v172, v181, s22, 0                         // 0000001AFA0C: CC2200AC 02002DB5
	v_fma_mixlo_f16 v173, v182, s22, 0                         // 0000001AFA14: CC2100AD 02002DB6
	v_fma_mixhi_f16 v173, v183, s22, 0                         // 0000001AFA1C: CC2200AD 02002DB7
	s_waitcnt lgkmcnt(6)                                       // 0000001AFA24: BF89FC67
	v_fma_mixlo_f16 v174, v184, s22, 0                         // 0000001AFA28: CC2100AE 02002DB8
	s_waitcnt lgkmcnt(0)                                       // 0000001AFA30: BF89FC07
	v_fma_mixlo_f16 v176, v99, s22, 0                          // 0000001AFA34: CC2100B0 02002D63
	v_fma_mixhi_f16 v176, v100, s22, 0                         // 0000001AFA3C: CC2200B0 02002D64
	v_fma_mixlo_f16 v177, v101, s22, 0                         // 0000001AFA44: CC2100B1 02002D65
	v_fma_mixhi_f16 v177, v102, s22, 0                         // 0000001AFA4C: CC2200B1 02002D66
	ds_load_b128 v[99:102], v127 offset:192                    // 0000001AFA54: DBFC00C0 6300007F
	v_fma_mixhi_f16 v174, v185, s22, 0                         // 0000001AFA5C: CC2200AE 02002DB9
	v_fma_mixlo_f16 v175, v186, s22, 0                         // 0000001AFA64: CC2100AF 02002DBA
	v_fma_mixhi_f16 v175, v187, s22, 0                         // 0000001AFA6C: CC2200AF 02002DBB
	v_fma_mixlo_f16 v178, v188, s22, 0                         // 0000001AFA74: CC2100B2 02002DBC
	v_fma_mixhi_f16 v178, v189, s22, 0                         // 0000001AFA7C: CC2200B2 02002DBD
	v_fma_mixlo_f16 v179, v190, s22, 0                         // 0000001AFA84: CC2100B3 02002DBE
	v_fma_mixhi_f16 v179, v191, s22, 0                         // 0000001AFA8C: CC2200B3 02002DBF
	v_fma_mixlo_f16 v180, v192, s22, 0                         // 0000001AFA94: CC2100B4 02002DC0
	v_fma_mixhi_f16 v180, v193, s22, 0                         // 0000001AFA9C: CC2200B4 02002DC1
	v_fma_mixlo_f16 v181, v194, s22, 0                         // 0000001AFAA4: CC2100B5 02002DC2
	v_fma_mixhi_f16 v181, v195, s22, 0                         // 0000001AFAAC: CC2200B5 02002DC3
	v_fma_mixlo_f16 v182, v196, s22, 0                         // 0000001AFAB4: CC2100B6 02002DC4
	v_fma_mixhi_f16 v182, v197, s22, 0                         // 0000001AFABC: CC2200B6 02002DC5
	v_fma_mixlo_f16 v183, v198, s22, 0                         // 0000001AFAC4: CC2100B7 02002DC6
	v_fma_mixhi_f16 v183, v199, s22, 0                         // 0000001AFACC: CC2200B7 02002DC7
	v_fma_mixlo_f16 v184, v200, s22, 0                         // 0000001AFAD4: CC2100B8 02002DC8
	v_fma_mixhi_f16 v184, v201, s22, 0                         // 0000001AFADC: CC2200B8 02002DC9
	v_fma_mixlo_f16 v185, v202, s22, 0                         // 0000001AFAE4: CC2100B9 02002DCA
	v_fma_mixhi_f16 v185, v203, s22, 0                         // 0000001AFAEC: CC2200B9 02002DCB
	v_fma_mixlo_f16 v186, v204, s22, 0                         // 0000001AFAF4: CC2100BA 02002DCC
	v_fma_mixhi_f16 v186, v205, s22, 0                         // 0000001AFAFC: CC2200BA 02002DCD
	v_fma_mixlo_f16 v187, v206, s22, 0                         // 0000001AFB04: CC2100BB 02002DCE
	v_fma_mixhi_f16 v187, v207, s22, 0                         // 0000001AFB0C: CC2200BB 02002DCF
	ds_load_b128 v[188:191], v127 offset:208                   // 0000001AFB14: DBFC00D0 BC00007F
	ds_load_b128 v[192:195], v127 offset:224                   // 0000001AFB1C: DBFC00E0 C000007F
	s_waitcnt vmcnt(10)                                        // 0000001AFB24: BF892BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[73:80], v[81:88], v[41:48]// 0000001AFB28: CC404029 1CA6A349
	ds_load_b128 v[81:84], v127 offset:240                     // 0000001AFB30: DBFC00F0 5100007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[89:96], v[17:24]// 0000001AFB38: CC404011 1C46B349
	v_wmma_f32_16x16x16_f16 v[49:56], v[73:80], v[172:179], v[49:56]// 0000001AFB40: CC404031 1CC75949
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[180:187], v[25:32]// 0000001AFB48: CC404019 1C676949
	ds_load_b128 v[85:88], v127 offset:8640                    // 0000001AFB50: DBFC21C0 5500007F
	ds_load_b128 v[89:92], v127 offset:8656                    // 0000001AFB58: DBFC21D0 5900007F
	s_waitcnt lgkmcnt(5)                                       // 0000001AFB60: BF89FC57
	v_fma_mixlo_f16 v73, v99, s22, 0                           // 0000001AFB64: CC210049 02002D63
	v_fma_mixhi_f16 v73, v100, s22, 0                          // 0000001AFB6C: CC220049 02002D64
	v_fma_mixlo_f16 v74, v101, s22, 0                          // 0000001AFB74: CC21004A 02002D65
	v_fma_mixhi_f16 v74, v102, s22, 0                          // 0000001AFB7C: CC22004A 02002D66
	ds_load_b128 v[93:96], v127 offset:8672                    // 0000001AFB84: DBFC21E0 5D00007F
	ds_load_b128 v[99:102], v127 offset:8688                   // 0000001AFB8C: DBFC21F0 6300007F
	ds_load_b128 v[172:175], v127 offset:17088                 // 0000001AFB94: DBFC42C0 AC00007F
	ds_load_b128 v[176:179], v127 offset:17104                 // 0000001AFB9C: DBFC42D0 B000007F
	ds_load_b128 v[180:183], v127 offset:17120                 // 0000001AFBA4: DBFC42E0 B400007F
	ds_load_b128 v[184:187], v127 offset:17136                 // 0000001AFBAC: DBFC42F0 B800007F
	s_waitcnt lgkmcnt(10)                                      // 0000001AFBB4: BF89FCA7
	v_fma_mixlo_f16 v75, v188, s22, 0                          // 0000001AFBB8: CC21004B 02002DBC
	v_fma_mixhi_f16 v75, v189, s22, 0                          // 0000001AFBC0: CC22004B 02002DBD
	v_fma_mixlo_f16 v76, v190, s22, 0                          // 0000001AFBC8: CC21004C 02002DBE
	s_waitcnt lgkmcnt(8)                                       // 0000001AFBD0: BF89FC87
	v_fma_mixhi_f16 v79, v82, s22, 0                           // 0000001AFBD4: CC22004F 02002D52
	v_fma_mixhi_f16 v76, v191, s22, 0                          // 0000001AFBDC: CC22004C 02002DBF
	v_fma_mixlo_f16 v77, v192, s22, 0                          // 0000001AFBE4: CC21004D 02002DC0
	v_fma_mixhi_f16 v77, v193, s22, 0                          // 0000001AFBEC: CC22004D 02002DC1
	s_waitcnt lgkmcnt(7)                                       // 0000001AFBF4: BF89FC77
	v_fma_mixlo_f16 v82, v87, s22, 0                           // 0000001AFBF8: CC210052 02002D57
	v_fma_mixhi_f16 v82, v88, s22, 0                           // 0000001AFC00: CC220052 02002D58
	v_fma_mixlo_f16 v78, v194, s22, 0                          // 0000001AFC08: CC21004E 02002DC2
	v_fma_mixhi_f16 v78, v195, s22, 0                          // 0000001AFC10: CC22004E 02002DC3
	v_fma_mixlo_f16 v79, v81, s22, 0                           // 0000001AFC18: CC21004F 02002D51
	v_fma_mixhi_f16 v80, v84, s22, 0                           // 0000001AFC20: CC220050 02002D54
	v_fma_mixlo_f16 v81, v85, s22, 0                           // 0000001AFC28: CC210051 02002D55
	s_waitcnt lgkmcnt(4)                                       // 0000001AFC30: BF89FC47
	v_fma_mixlo_f16 v87, v99, s22, 0                           // 0000001AFC34: CC210057 02002D63
	v_fma_mixhi_f16 v87, v100, s22, 0                          // 0000001AFC3C: CC220057 02002D64
	v_fma_mixlo_f16 v88, v101, s22, 0                          // 0000001AFC44: CC210058 02002D65
	v_fma_mixhi_f16 v88, v102, s22, 0                          // 0000001AFC4C: CC220058 02002D66
	ds_load_b128 v[99:102], v127 offset:25536                  // 0000001AFC54: DBFC63C0 6300007F
	ds_load_b128 v[188:191], v127 offset:25552                 // 0000001AFC5C: DBFC63D0 BC00007F
	v_fma_mixhi_f16 v84, v92, s22, 0                           // 0000001AFC64: CC220054 02002D5C
	v_fma_mixlo_f16 v85, v93, s22, 0                           // 0000001AFC6C: CC210055 02002D5D
	s_waitcnt lgkmcnt(4)                                       // 0000001AFC74: BF89FC47
	v_fma_mixlo_f16 v92, v178, s22, 0                          // 0000001AFC78: CC21005C 02002DB2
	ds_load_b128 v[192:195], v127 offset:25568                 // 0000001AFC80: DBFC63E0 C000007F
	v_fma_mixhi_f16 v92, v179, s22, 0                          // 0000001AFC88: CC22005C 02002DB3
	s_waitcnt lgkmcnt(4)                                       // 0000001AFC90: BF89FC47
	v_fma_mixlo_f16 v93, v180, s22, 0                          // 0000001AFC94: CC21005D 02002DB4
	v_fma_mixhi_f16 v93, v181, s22, 0                          // 0000001AFC9C: CC22005D 02002DB5
	ds_load_b128 v[178:181], v127 offset:25584                 // 0000001AFCA4: DBFC63F0 B200007F
	v_fma_mixlo_f16 v80, v83, s22, 0                           // 0000001AFCAC: CC210050 02002D53
	v_fma_mixlo_f16 v83, v89, s22, 0                           // 0000001AFCB4: CC210053 02002D59
	v_fma_mixlo_f16 v89, v172, s22, 0                          // 0000001AFCBC: CC210059 02002DAC
	v_fma_mixhi_f16 v89, v173, s22, 0                          // 0000001AFCC4: CC220059 02002DAD
	v_fma_mixhi_f16 v81, v86, s22, 0                           // 0000001AFCCC: CC220051 02002D56
	v_fma_mixhi_f16 v83, v90, s22, 0                           // 0000001AFCD4: CC220053 02002D5A
	v_fma_mixlo_f16 v84, v91, s22, 0                           // 0000001AFCDC: CC210054 02002D5B
	v_fma_mixhi_f16 v85, v94, s22, 0                           // 0000001AFCE4: CC220055 02002D5E
	v_fma_mixlo_f16 v86, v95, s22, 0                           // 0000001AFCEC: CC210056 02002D5F
	v_fma_mixhi_f16 v86, v96, s22, 0                           // 0000001AFCF4: CC220056 02002D60
	s_waitcnt lgkmcnt(3)                                       // 0000001AFCFC: BF89FC37
	v_fma_mixlo_f16 v172, v99, s22, 0                          // 0000001AFD00: CC2100AC 02002D63
	v_fma_mixhi_f16 v172, v100, s22, 0                         // 0000001AFD08: CC2200AC 02002D64
	v_fma_mixlo_f16 v173, v101, s22, 0                         // 0000001AFD10: CC2100AD 02002D65
	v_fma_mixhi_f16 v173, v102, s22, 0                         // 0000001AFD18: CC2200AD 02002D66
	ds_load_b128 v[99:102], v127 offset:256                    // 0000001AFD20: DBFC0100 6300007F
	v_fma_mixlo_f16 v90, v174, s22, 0                          // 0000001AFD28: CC21005A 02002DAE
	v_fma_mixhi_f16 v90, v175, s22, 0                          // 0000001AFD30: CC22005A 02002DAF
	v_fma_mixlo_f16 v91, v176, s22, 0                          // 0000001AFD38: CC21005B 02002DB0
	v_fma_mixhi_f16 v91, v177, s22, 0                          // 0000001AFD40: CC22005B 02002DB1
	v_fma_mixlo_f16 v94, v182, s22, 0                          // 0000001AFD48: CC21005E 02002DB6
	v_fma_mixhi_f16 v94, v183, s22, 0                          // 0000001AFD50: CC22005E 02002DB7
	v_fma_mixlo_f16 v95, v184, s22, 0                          // 0000001AFD58: CC21005F 02002DB8
	v_fma_mixhi_f16 v95, v185, s22, 0                          // 0000001AFD60: CC22005F 02002DB9
	v_fma_mixlo_f16 v96, v186, s22, 0                          // 0000001AFD68: CC210060 02002DBA
	v_fma_mixhi_f16 v96, v187, s22, 0                          // 0000001AFD70: CC220060 02002DBB
	s_waitcnt lgkmcnt(3)                                       // 0000001AFD78: BF89FC37
	v_fma_mixlo_f16 v174, v188, s22, 0                         // 0000001AFD7C: CC2100AE 02002DBC
	v_fma_mixhi_f16 v174, v189, s22, 0                         // 0000001AFD84: CC2200AE 02002DBD
	v_fma_mixlo_f16 v175, v190, s22, 0                         // 0000001AFD8C: CC2100AF 02002DBE
	v_fma_mixhi_f16 v175, v191, s22, 0                         // 0000001AFD94: CC2200AF 02002DBF
	s_waitcnt lgkmcnt(2)                                       // 0000001AFD9C: BF89FC27
	v_fma_mixlo_f16 v176, v192, s22, 0                         // 0000001AFDA0: CC2100B0 02002DC0
	v_fma_mixhi_f16 v176, v193, s22, 0                         // 0000001AFDA8: CC2200B0 02002DC1
	v_fma_mixlo_f16 v177, v194, s22, 0                         // 0000001AFDB0: CC2100B1 02002DC2
	v_fma_mixhi_f16 v177, v195, s22, 0                         // 0000001AFDB8: CC2200B1 02002DC3
	s_waitcnt lgkmcnt(1)                                       // 0000001AFDC0: BF89FC17
	v_fma_mixlo_f16 v178, v178, s22, 0                         // 0000001AFDC4: CC2100B2 02002DB2
	v_fma_mixhi_f16 v178, v179, s22, 0                         // 0000001AFDCC: CC2200B2 02002DB3
	v_fma_mixlo_f16 v179, v180, s22, 0                         // 0000001AFDD4: CC2100B3 02002DB4
	v_fma_mixhi_f16 v179, v181, s22, 0                         // 0000001AFDDC: CC2200B3 02002DB5
	ds_load_b128 v[182:185], v127 offset:272                   // 0000001AFDE4: DBFC0110 B600007F
	ds_load_b128 v[186:189], v127 offset:288                   // 0000001AFDEC: DBFC0120 BA00007F
	s_waitcnt vmcnt(8)                                         // 0000001AFDF4: BF8923F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[73:80], v[41:48]// 0000001AFDF8: CC404029 1CA69341
	ds_load_b128 v[73:76], v127 offset:304                     // 0000001AFE00: DBFC0130 4900007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[65:72], v[81:88], v[17:24]// 0000001AFE08: CC404011 1C46A341
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[89:96], v[49:56]// 0000001AFE10: CC404031 1CC6B341
	v_wmma_f32_16x16x16_f16 v[25:32], v[65:72], v[172:179], v[25:32]// 0000001AFE18: CC404019 1C675941
	ds_load_b128 v[77:80], v127 offset:8704                    // 0000001AFE20: DBFC2200 4D00007F
	ds_load_b128 v[81:84], v127 offset:8720                    // 0000001AFE28: DBFC2210 5100007F
	s_waitcnt lgkmcnt(5)                                       // 0000001AFE30: BF89FC57
	v_fma_mixlo_f16 v65, v99, s22, 0                           // 0000001AFE34: CC210041 02002D63
	v_fma_mixhi_f16 v65, v100, s22, 0                          // 0000001AFE3C: CC220041 02002D64
	v_fma_mixlo_f16 v66, v101, s22, 0                          // 0000001AFE44: CC210042 02002D65
	v_fma_mixhi_f16 v66, v102, s22, 0                          // 0000001AFE4C: CC220042 02002D66
	ds_load_b128 v[85:88], v127 offset:8736                    // 0000001AFE54: DBFC2220 5500007F
	ds_load_b128 v[89:92], v127 offset:8752                    // 0000001AFE5C: DBFC2230 5900007F
	ds_load_b128 v[93:96], v127 offset:17152                   // 0000001AFE64: DBFC4300 5D00007F
	ds_load_b128 v[99:102], v127 offset:17168                  // 0000001AFE6C: DBFC4310 6300007F
	ds_load_b128 v[172:175], v127 offset:17184                 // 0000001AFE74: DBFC4320 AC00007F
	ds_load_b128 v[176:179], v127 offset:17200                 // 0000001AFE7C: DBFC4330 B000007F
	s_waitcnt lgkmcnt(10)                                      // 0000001AFE84: BF89FCA7
	v_fma_mixlo_f16 v67, v182, s22, 0                          // 0000001AFE88: CC210043 02002DB6
	v_fma_mixhi_f16 v67, v183, s22, 0                          // 0000001AFE90: CC220043 02002DB7
	ds_load_b128 v[180:183], v127 offset:25616                 // 0000001AFE98: DBFC6410 B400007F
	s_waitcnt lgkmcnt(9)                                       // 0000001AFEA0: BF89FC97
	v_fma_mixhi_f16 v71, v74, s22, 0                           // 0000001AFEA4: CC220047 02002D4A
	v_fma_mixlo_f16 v72, v75, s22, 0                           // 0000001AFEAC: CC210048 02002D4B
	v_fma_mixhi_f16 v72, v76, s22, 0                           // 0000001AFEB4: CC220048 02002D4C
	v_fma_mixlo_f16 v68, v184, s22, 0                          // 0000001AFEBC: CC210044 02002DB8
	s_waitcnt lgkmcnt(8)                                       // 0000001AFEC4: BF89FC87
	v_fma_mixlo_f16 v74, v79, s22, 0                           // 0000001AFEC8: CC21004A 02002D4F
	v_fma_mixhi_f16 v74, v80, s22, 0                           // 0000001AFED0: CC22004A 02002D50
	s_waitcnt lgkmcnt(7)                                       // 0000001AFED8: BF89FC77
	v_fma_mixlo_f16 v75, v81, s22, 0                           // 0000001AFEDC: CC21004B 02002D51
	v_fma_mixhi_f16 v75, v82, s22, 0                           // 0000001AFEE4: CC22004B 02002D52
	v_fma_mixlo_f16 v76, v83, s22, 0                           // 0000001AFEEC: CC21004C 02002D53
	v_fma_mixhi_f16 v76, v84, s22, 0                           // 0000001AFEF4: CC22004C 02002D54
	v_fma_mixhi_f16 v68, v185, s22, 0                          // 0000001AFEFC: CC220044 02002DB9
	s_waitcnt lgkmcnt(5)                                       // 0000001AFF04: BF89FC57
	v_fma_mixlo_f16 v79, v89, s22, 0                           // 0000001AFF08: CC21004F 02002D59
	v_fma_mixhi_f16 v79, v90, s22, 0                           // 0000001AFF10: CC22004F 02002D5A
	v_fma_mixlo_f16 v80, v91, s22, 0                           // 0000001AFF18: CC210050 02002D5B
	v_fma_mixhi_f16 v80, v92, s22, 0                           // 0000001AFF20: CC220050 02002D5C
	ds_load_b128 v[89:92], v127 offset:25600                   // 0000001AFF28: DBFC6400 5900007F
	s_waitcnt lgkmcnt(5)                                       // 0000001AFF30: BF89FC57
	v_fma_mixlo_f16 v81, v93, s22, 0                           // 0000001AFF34: CC210051 02002D5D
	v_fma_mixhi_f16 v81, v94, s22, 0                           // 0000001AFF3C: CC220051 02002D5E
	v_fma_mixlo_f16 v82, v95, s22, 0                           // 0000001AFF44: CC210052 02002D5F
	v_fma_mixhi_f16 v82, v96, s22, 0                           // 0000001AFF4C: CC220052 02002D60
	s_waitcnt lgkmcnt(4)                                       // 0000001AFF54: BF89FC47
	v_fma_mixlo_f16 v83, v99, s22, 0                           // 0000001AFF58: CC210053 02002D63
	v_fma_mixhi_f16 v83, v100, s22, 0                          // 0000001AFF60: CC220053 02002D64
	v_fma_mixlo_f16 v84, v101, s22, 0                          // 0000001AFF68: CC210054 02002D65
	ds_load_b128 v[93:96], v127 offset:25632                   // 0000001AFF70: DBFC6420 5D00007F
	v_fma_mixhi_f16 v84, v102, s22, 0                          // 0000001AFF78: CC220054 02002D66
	ds_load_b128 v[99:102], v127 offset:25648                  // 0000001AFF80: DBFC6430 6300007F
	v_fma_mixlo_f16 v69, v186, s22, 0                          // 0000001AFF88: CC210045 02002DBA
	v_fma_mixhi_f16 v69, v187, s22, 0                          // 0000001AFF90: CC220045 02002DBB
	v_fma_mixlo_f16 v70, v188, s22, 0                          // 0000001AFF98: CC210046 02002DBC
	v_fma_mixhi_f16 v70, v189, s22, 0                          // 0000001AFFA0: CC220046 02002DBD
	v_fma_mixlo_f16 v71, v73, s22, 0                           // 0000001AFFA8: CC210047 02002D49
	v_fma_mixlo_f16 v73, v77, s22, 0                           // 0000001AFFB0: CC210049 02002D4D
	v_fma_mixhi_f16 v73, v78, s22, 0                           // 0000001AFFB8: CC220049 02002D4E
	v_fma_mixlo_f16 v77, v85, s22, 0                           // 0000001AFFC0: CC21004D 02002D55
	v_fma_mixhi_f16 v77, v86, s22, 0                           // 0000001AFFC8: CC22004D 02002D56
	v_fma_mixlo_f16 v78, v87, s22, 0                           // 0000001AFFD0: CC21004E 02002D57
	v_fma_mixhi_f16 v78, v88, s22, 0                           // 0000001AFFD8: CC22004E 02002D58
	s_waitcnt lgkmcnt(5)                                       // 0000001AFFE0: BF89FC57
	v_fma_mixlo_f16 v85, v172, s22, 0                          // 0000001AFFE4: CC210055 02002DAC
	v_fma_mixhi_f16 v85, v173, s22, 0                          // 0000001AFFEC: CC220055 02002DAD
	v_fma_mixlo_f16 v86, v174, s22, 0                          // 0000001AFFF4: CC210056 02002DAE
	v_fma_mixhi_f16 v86, v175, s22, 0                          // 0000001AFFFC: CC220056 02002DAF
	s_waitcnt lgkmcnt(4)                                       // 0000001B0004: BF89FC47
	v_fma_mixlo_f16 v87, v176, s22, 0                          // 0000001B0008: CC210057 02002DB0
	v_fma_mixhi_f16 v87, v177, s22, 0                          // 0000001B0010: CC220057 02002DB1
	v_fma_mixlo_f16 v88, v178, s22, 0                          // 0000001B0018: CC210058 02002DB2
	v_fma_mixhi_f16 v88, v179, s22, 0                          // 0000001B0020: CC220058 02002DB3
	s_waitcnt lgkmcnt(2)                                       // 0000001B0028: BF89FC27
	v_fma_mixlo_f16 v89, v89, s22, 0                           // 0000001B002C: CC210059 02002D59
	v_fma_mixhi_f16 v89, v90, s22, 0                           // 0000001B0034: CC220059 02002D5A
	v_fma_mixlo_f16 v90, v91, s22, 0                           // 0000001B003C: CC21005A 02002D5B
	v_fma_mixhi_f16 v90, v92, s22, 0                           // 0000001B0044: CC22005A 02002D5C
	v_fma_mixlo_f16 v91, v180, s22, 0                          // 0000001B004C: CC21005B 02002DB4
	v_fma_mixhi_f16 v91, v181, s22, 0                          // 0000001B0054: CC22005B 02002DB5
	v_fma_mixlo_f16 v92, v182, s22, 0                          // 0000001B005C: CC21005C 02002DB6
	v_fma_mixhi_f16 v92, v183, s22, 0                          // 0000001B0064: CC22005C 02002DB7
	s_waitcnt lgkmcnt(1)                                       // 0000001B006C: BF89FC17
	v_fma_mixlo_f16 v93, v93, s22, 0                           // 0000001B0070: CC21005D 02002D5D
	v_fma_mixhi_f16 v93, v94, s22, 0                           // 0000001B0078: CC22005D 02002D5E
	v_fma_mixlo_f16 v94, v95, s22, 0                           // 0000001B0080: CC21005E 02002D5F
	v_fma_mixhi_f16 v94, v96, s22, 0                           // 0000001B0088: CC22005E 02002D60
	s_waitcnt lgkmcnt(0)                                       // 0000001B0090: BF89FC07
	v_fma_mixlo_f16 v95, v99, s22, 0                           // 0000001B0094: CC21005F 02002D63
	v_fma_mixhi_f16 v95, v100, s22, 0                          // 0000001B009C: CC22005F 02002D64
	v_fma_mixlo_f16 v96, v101, s22, 0                          // 0000001B00A4: CC210060 02002D65
	v_fma_mixhi_f16 v96, v102, s22, 0                          // 0000001B00AC: CC220060 02002D66
	ds_load_b128 v[172:175], v127 offset:320                   // 0000001B00B4: DBFC0140 AC00007F
	ds_load_b128 v[176:179], v127 offset:336                   // 0000001B00BC: DBFC0150 B000007F
	ds_load_b128 v[180:183], v127 offset:352                   // 0000001B00C4: DBFC0160 B400007F
	s_waitcnt vmcnt(6)                                         // 0000001B00CC: BF891BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[57:64], v[65:72], v[41:48]// 0000001B00D0: CC404029 1CA68339
	ds_load_b128 v[65:68], v127 offset:368                     // 0000001B00D8: DBFC0170 4100007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[73:80], v[17:24]// 0000001B00E0: CC404011 1C469339
	v_wmma_f32_16x16x16_f16 v[49:56], v[57:64], v[81:88], v[49:56]// 0000001B00E8: CC404031 1CC6A339
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[89:96], v[25:32]// 0000001B00F0: CC404019 1C66B339
	ds_load_b128 v[69:72], v127 offset:8768                    // 0000001B00F8: DBFC2240 4500007F
	ds_load_b128 v[73:76], v127 offset:8784                    // 0000001B0100: DBFC2250 4900007F
	ds_load_b128 v[77:80], v127 offset:8800                    // 0000001B0108: DBFC2260 4D00007F
	ds_load_b128 v[81:84], v127 offset:8816                    // 0000001B0110: DBFC2270 5100007F
	ds_load_b128 v[85:88], v127 offset:17216                   // 0000001B0118: DBFC4340 5500007F
	ds_load_b128 v[89:92], v127 offset:17232                   // 0000001B0120: DBFC4350 5900007F
	ds_load_b128 v[93:96], v127 offset:17248                   // 0000001B0128: DBFC4360 5D00007F
	ds_load_b128 v[99:102], v127 offset:17264                  // 0000001B0130: DBFC4370 6300007F
	s_waitcnt lgkmcnt(11)                                      // 0000001B0138: BF89FCB7
	v_fma_mixlo_f16 v57, v172, s22, 0                          // 0000001B013C: CC210039 02002DAC
	v_fma_mixhi_f16 v57, v173, s22, 0                          // 0000001B0144: CC220039 02002DAD
	v_fma_mixlo_f16 v58, v174, s22, 0                          // 0000001B014C: CC21003A 02002DAE
	v_fma_mixhi_f16 v58, v175, s22, 0                          // 0000001B0154: CC22003A 02002DAF
	s_waitcnt lgkmcnt(8)                                       // 0000001B015C: BF89FC87
	v_fma_mixhi_f16 v63, v66, s22, 0                           // 0000001B0160: CC22003F 02002D42
	v_fma_mixlo_f16 v64, v67, s22, 0                           // 0000001B0168: CC210040 02002D43
	v_fma_mixhi_f16 v64, v68, s22, 0                           // 0000001B0170: CC220040 02002D44
	ds_load_b128 v[172:175], v127 offset:25680                 // 0000001B0178: DBFC6450 AC00007F
	s_waitcnt lgkmcnt(8)                                       // 0000001B0180: BF89FC87
	v_fma_mixlo_f16 v66, v71, s22, 0                           // 0000001B0184: CC210042 02002D47
	v_fma_mixhi_f16 v66, v72, s22, 0                           // 0000001B018C: CC220042 02002D48
	s_waitcnt lgkmcnt(7)                                       // 0000001B0194: BF89FC77
	v_fma_mixlo_f16 v67, v73, s22, 0                           // 0000001B0198: CC210043 02002D49
	v_fma_mixhi_f16 v67, v74, s22, 0                           // 0000001B01A0: CC220043 02002D4A
	v_fma_mixlo_f16 v68, v75, s22, 0                           // 0000001B01A8: CC210044 02002D4B
	v_fma_mixhi_f16 v68, v76, s22, 0                           // 0000001B01B0: CC220044 02002D4C
	s_waitcnt lgkmcnt(5)                                       // 0000001B01B8: BF89FC57
	v_fma_mixlo_f16 v71, v81, s22, 0                           // 0000001B01BC: CC210047 02002D51
	v_fma_mixhi_f16 v71, v82, s22, 0                           // 0000001B01C4: CC220047 02002D52
	v_fma_mixlo_f16 v72, v83, s22, 0                           // 0000001B01CC: CC210048 02002D53
	v_fma_mixhi_f16 v72, v84, s22, 0                           // 0000001B01D4: CC220048 02002D54
	ds_load_b128 v[81:84], v127 offset:25664                   // 0000001B01DC: DBFC6440 5100007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B01E4: BF89FC57
	v_fma_mixlo_f16 v73, v85, s22, 0                           // 0000001B01E8: CC210049 02002D55
	v_fma_mixhi_f16 v73, v86, s22, 0                           // 0000001B01F0: CC220049 02002D56
	v_fma_mixlo_f16 v74, v87, s22, 0                           // 0000001B01F8: CC21004A 02002D57
	v_fma_mixhi_f16 v74, v88, s22, 0                           // 0000001B0200: CC22004A 02002D58
	s_waitcnt lgkmcnt(4)                                       // 0000001B0208: BF89FC47
	v_fma_mixlo_f16 v75, v89, s22, 0                           // 0000001B020C: CC21004B 02002D59
	v_fma_mixhi_f16 v75, v90, s22, 0                           // 0000001B0214: CC22004B 02002D5A
	v_fma_mixlo_f16 v76, v91, s22, 0                           // 0000001B021C: CC21004C 02002D5B
	ds_load_b128 v[85:88], v127 offset:25696                   // 0000001B0224: DBFC6460 5500007F
	v_fma_mixhi_f16 v76, v92, s22, 0                           // 0000001B022C: CC22004C 02002D5C
	ds_load_b128 v[89:92], v127 offset:25712                   // 0000001B0234: DBFC6470 5900007F
	v_fma_mixlo_f16 v59, v176, s22, 0                          // 0000001B023C: CC21003B 02002DB0
	v_fma_mixhi_f16 v59, v177, s22, 0                          // 0000001B0244: CC22003B 02002DB1
	v_fma_mixlo_f16 v60, v178, s22, 0                          // 0000001B024C: CC21003C 02002DB2
	v_fma_mixhi_f16 v60, v179, s22, 0                          // 0000001B0254: CC22003C 02002DB3
	v_fma_mixlo_f16 v61, v180, s22, 0                          // 0000001B025C: CC21003D 02002DB4
	v_fma_mixhi_f16 v61, v181, s22, 0                          // 0000001B0264: CC22003D 02002DB5
	v_fma_mixlo_f16 v62, v182, s22, 0                          // 0000001B026C: CC21003E 02002DB6
	v_fma_mixhi_f16 v62, v183, s22, 0                          // 0000001B0274: CC22003E 02002DB7
	v_fma_mixlo_f16 v63, v65, s22, 0                           // 0000001B027C: CC21003F 02002D41
	v_fma_mixlo_f16 v65, v69, s22, 0                           // 0000001B0284: CC210041 02002D45
	v_fma_mixhi_f16 v65, v70, s22, 0                           // 0000001B028C: CC220041 02002D46
	v_fma_mixlo_f16 v69, v77, s22, 0                           // 0000001B0294: CC210045 02002D4D
	v_fma_mixhi_f16 v69, v78, s22, 0                           // 0000001B029C: CC220045 02002D4E
	v_fma_mixlo_f16 v70, v79, s22, 0                           // 0000001B02A4: CC210046 02002D4F
	v_fma_mixhi_f16 v70, v80, s22, 0                           // 0000001B02AC: CC220046 02002D50
	s_waitcnt lgkmcnt(5)                                       // 0000001B02B4: BF89FC57
	v_fma_mixlo_f16 v77, v93, s22, 0                           // 0000001B02B8: CC21004D 02002D5D
	v_fma_mixhi_f16 v77, v94, s22, 0                           // 0000001B02C0: CC22004D 02002D5E
	v_fma_mixlo_f16 v78, v95, s22, 0                           // 0000001B02C8: CC21004E 02002D5F
	v_fma_mixhi_f16 v78, v96, s22, 0                           // 0000001B02D0: CC22004E 02002D60
	s_waitcnt lgkmcnt(4)                                       // 0000001B02D8: BF89FC47
	v_fma_mixlo_f16 v79, v99, s22, 0                           // 0000001B02DC: CC21004F 02002D63
	v_fma_mixhi_f16 v79, v100, s22, 0                          // 0000001B02E4: CC22004F 02002D64
	v_fma_mixlo_f16 v80, v101, s22, 0                          // 0000001B02EC: CC210050 02002D65
	v_fma_mixhi_f16 v80, v102, s22, 0                          // 0000001B02F4: CC220050 02002D66
	s_waitcnt lgkmcnt(2)                                       // 0000001B02FC: BF89FC27
	v_fma_mixlo_f16 v81, v81, s22, 0                           // 0000001B0300: CC210051 02002D51
	v_fma_mixhi_f16 v81, v82, s22, 0                           // 0000001B0308: CC220051 02002D52
	v_fma_mixlo_f16 v82, v83, s22, 0                           // 0000001B0310: CC210052 02002D53
	v_fma_mixhi_f16 v82, v84, s22, 0                           // 0000001B0318: CC220052 02002D54
	v_fma_mixlo_f16 v83, v172, s22, 0                          // 0000001B0320: CC210053 02002DAC
	v_fma_mixhi_f16 v83, v173, s22, 0                          // 0000001B0328: CC220053 02002DAD
	v_fma_mixlo_f16 v84, v174, s22, 0                          // 0000001B0330: CC210054 02002DAE
	v_fma_mixhi_f16 v84, v175, s22, 0                          // 0000001B0338: CC220054 02002DAF
	s_waitcnt lgkmcnt(1)                                       // 0000001B0340: BF89FC17
	v_fma_mixlo_f16 v85, v85, s22, 0                           // 0000001B0344: CC210055 02002D55
	v_fma_mixhi_f16 v85, v86, s22, 0                           // 0000001B034C: CC220055 02002D56
	v_fma_mixlo_f16 v86, v87, s22, 0                           // 0000001B0354: CC210056 02002D57
	v_fma_mixhi_f16 v86, v88, s22, 0                           // 0000001B035C: CC220056 02002D58
	s_waitcnt lgkmcnt(0)                                       // 0000001B0364: BF89FC07
	v_fma_mixlo_f16 v87, v89, s22, 0                           // 0000001B0368: CC210057 02002D59
	v_fma_mixhi_f16 v87, v90, s22, 0                           // 0000001B0370: CC220057 02002D5A
	v_fma_mixlo_f16 v88, v91, s22, 0                           // 0000001B0378: CC210058 02002D5B
	v_fma_mixhi_f16 v88, v92, s22, 0                           // 0000001B0380: CC220058 02002D5C
	ds_load_b128 v[93:96], v127 offset:384                     // 0000001B0388: DBFC0180 5D00007F
	ds_load_b128 v[99:102], v127 offset:400                    // 0000001B0390: DBFC0190 6300007F
	ds_load_b128 v[172:175], v127 offset:416                   // 0000001B0398: DBFC01A0 AC00007F
	s_waitcnt vmcnt(4)                                         // 0000001B03A0: BF8913F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[33:40], v[57:64], v[41:48]// 0000001B03A4: CC404029 1CA67321
	ds_load_b128 v[57:60], v127 offset:432                     // 0000001B03AC: DBFC01B0 3900007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[65:72], v[17:24]// 0000001B03B4: CC404011 1C468321
	v_wmma_f32_16x16x16_f16 v[49:56], v[33:40], v[73:80], v[49:56]// 0000001B03BC: CC404031 1CC69321
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[81:88], v[25:32]// 0000001B03C4: CC404019 1C66A321
	ds_load_b128 v[61:64], v127 offset:8832                    // 0000001B03CC: DBFC2280 3D00007F
	ds_load_b128 v[65:68], v127 offset:8848                    // 0000001B03D4: DBFC2290 4100007F
	ds_load_b128 v[69:72], v127 offset:8864                    // 0000001B03DC: DBFC22A0 4500007F
	ds_load_b128 v[73:76], v127 offset:8880                    // 0000001B03E4: DBFC22B0 4900007F
	ds_load_b128 v[77:80], v127 offset:17280                   // 0000001B03EC: DBFC4380 4D00007F
	ds_load_b128 v[81:84], v127 offset:17296                   // 0000001B03F4: DBFC4390 5100007F
	ds_load_b128 v[85:88], v127 offset:17312                   // 0000001B03FC: DBFC43A0 5500007F
	ds_load_b128 v[89:92], v127 offset:17328                   // 0000001B0404: DBFC43B0 5900007F
	s_waitcnt lgkmcnt(11)                                      // 0000001B040C: BF89FCB7
	v_fma_mixlo_f16 v33, v93, s22, 0                           // 0000001B0410: CC210021 02002D5D
	v_fma_mixhi_f16 v33, v94, s22, 0                           // 0000001B0418: CC220021 02002D5E
	v_fma_mixlo_f16 v34, v95, s22, 0                           // 0000001B0420: CC210022 02002D5F
	v_fma_mixhi_f16 v34, v96, s22, 0                           // 0000001B0428: CC220022 02002D60
	s_waitcnt lgkmcnt(8)                                       // 0000001B0430: BF89FC87
	v_fma_mixhi_f16 v39, v58, s22, 0                           // 0000001B0434: CC220027 02002D3A
	v_fma_mixlo_f16 v40, v59, s22, 0                           // 0000001B043C: CC210028 02002D3B
	v_fma_mixhi_f16 v40, v60, s22, 0                           // 0000001B0444: CC220028 02002D3C
	ds_load_b128 v[93:96], v127 offset:25744                   // 0000001B044C: DBFC6490 5D00007F
	s_waitcnt lgkmcnt(8)                                       // 0000001B0454: BF89FC87
	v_fma_mixlo_f16 v58, v63, s22, 0                           // 0000001B0458: CC21003A 02002D3F
	v_fma_mixhi_f16 v58, v64, s22, 0                           // 0000001B0460: CC22003A 02002D40
	s_waitcnt lgkmcnt(7)                                       // 0000001B0468: BF89FC77
	v_fma_mixlo_f16 v59, v65, s22, 0                           // 0000001B046C: CC21003B 02002D41
	v_fma_mixhi_f16 v59, v66, s22, 0                           // 0000001B0474: CC22003B 02002D42
	v_fma_mixlo_f16 v60, v67, s22, 0                           // 0000001B047C: CC21003C 02002D43
	v_fma_mixhi_f16 v60, v68, s22, 0                           // 0000001B0484: CC22003C 02002D44
	s_waitcnt lgkmcnt(5)                                       // 0000001B048C: BF89FC57
	v_fma_mixlo_f16 v63, v73, s22, 0                           // 0000001B0490: CC21003F 02002D49
	v_fma_mixhi_f16 v63, v74, s22, 0                           // 0000001B0498: CC22003F 02002D4A
	v_fma_mixlo_f16 v64, v75, s22, 0                           // 0000001B04A0: CC210040 02002D4B
	v_fma_mixhi_f16 v64, v76, s22, 0                           // 0000001B04A8: CC220040 02002D4C
	ds_load_b128 v[73:76], v127 offset:25728                   // 0000001B04B0: DBFC6480 4900007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B04B8: BF89FC57
	v_fma_mixlo_f16 v65, v77, s22, 0                           // 0000001B04BC: CC210041 02002D4D
	v_fma_mixhi_f16 v65, v78, s22, 0                           // 0000001B04C4: CC220041 02002D4E
	v_fma_mixlo_f16 v66, v79, s22, 0                           // 0000001B04CC: CC210042 02002D4F
	v_fma_mixhi_f16 v66, v80, s22, 0                           // 0000001B04D4: CC220042 02002D50
	s_waitcnt lgkmcnt(4)                                       // 0000001B04DC: BF89FC47
	v_fma_mixlo_f16 v67, v81, s22, 0                           // 0000001B04E0: CC210043 02002D51
	v_fma_mixhi_f16 v67, v82, s22, 0                           // 0000001B04E8: CC220043 02002D52
	v_fma_mixlo_f16 v68, v83, s22, 0                           // 0000001B04F0: CC210044 02002D53
	ds_load_b128 v[77:80], v127 offset:25760                   // 0000001B04F8: DBFC64A0 4D00007F
	v_fma_mixhi_f16 v68, v84, s22, 0                           // 0000001B0500: CC220044 02002D54
	ds_load_b128 v[81:84], v127 offset:25776                   // 0000001B0508: DBFC64B0 5100007F
	v_fma_mixlo_f16 v35, v99, s22, 0                           // 0000001B0510: CC210023 02002D63
	v_fma_mixhi_f16 v35, v100, s22, 0                          // 0000001B0518: CC220023 02002D64
	v_fma_mixlo_f16 v36, v101, s22, 0                          // 0000001B0520: CC210024 02002D65
	v_fma_mixhi_f16 v36, v102, s22, 0                          // 0000001B0528: CC220024 02002D66
	v_fma_mixlo_f16 v37, v172, s22, 0                          // 0000001B0530: CC210025 02002DAC
	v_fma_mixhi_f16 v37, v173, s22, 0                          // 0000001B0538: CC220025 02002DAD
	v_fma_mixlo_f16 v38, v174, s22, 0                          // 0000001B0540: CC210026 02002DAE
	v_fma_mixhi_f16 v38, v175, s22, 0                          // 0000001B0548: CC220026 02002DAF
	v_fma_mixlo_f16 v39, v57, s22, 0                           // 0000001B0550: CC210027 02002D39
	v_fma_mixlo_f16 v57, v61, s22, 0                           // 0000001B0558: CC210039 02002D3D
	v_fma_mixhi_f16 v57, v62, s22, 0                           // 0000001B0560: CC220039 02002D3E
	v_fma_mixlo_f16 v61, v69, s22, 0                           // 0000001B0568: CC21003D 02002D45
	v_fma_mixhi_f16 v61, v70, s22, 0                           // 0000001B0570: CC22003D 02002D46
	v_fma_mixlo_f16 v62, v71, s22, 0                           // 0000001B0578: CC21003E 02002D47
	v_fma_mixhi_f16 v62, v72, s22, 0                           // 0000001B0580: CC22003E 02002D48
	s_waitcnt lgkmcnt(5)                                       // 0000001B0588: BF89FC57
	v_fma_mixlo_f16 v69, v85, s22, 0                           // 0000001B058C: CC210045 02002D55
	v_fma_mixhi_f16 v69, v86, s22, 0                           // 0000001B0594: CC220045 02002D56
	v_fma_mixlo_f16 v70, v87, s22, 0                           // 0000001B059C: CC210046 02002D57
	v_fma_mixhi_f16 v70, v88, s22, 0                           // 0000001B05A4: CC220046 02002D58
	s_waitcnt lgkmcnt(4)                                       // 0000001B05AC: BF89FC47
	v_fma_mixlo_f16 v71, v89, s22, 0                           // 0000001B05B0: CC210047 02002D59
	v_fma_mixhi_f16 v71, v90, s22, 0                           // 0000001B05B8: CC220047 02002D5A
	v_fma_mixlo_f16 v72, v91, s22, 0                           // 0000001B05C0: CC210048 02002D5B
	v_fma_mixhi_f16 v72, v92, s22, 0                           // 0000001B05C8: CC220048 02002D5C
	s_waitcnt lgkmcnt(2)                                       // 0000001B05D0: BF89FC27
	v_fma_mixlo_f16 v73, v73, s22, 0                           // 0000001B05D4: CC210049 02002D49
	v_fma_mixhi_f16 v73, v74, s22, 0                           // 0000001B05DC: CC220049 02002D4A
	v_fma_mixlo_f16 v74, v75, s22, 0                           // 0000001B05E4: CC21004A 02002D4B
	v_fma_mixhi_f16 v74, v76, s22, 0                           // 0000001B05EC: CC22004A 02002D4C
	v_fma_mixlo_f16 v75, v93, s22, 0                           // 0000001B05F4: CC21004B 02002D5D
	v_fma_mixhi_f16 v75, v94, s22, 0                           // 0000001B05FC: CC22004B 02002D5E
	v_fma_mixlo_f16 v76, v95, s22, 0                           // 0000001B0604: CC21004C 02002D5F
	v_fma_mixhi_f16 v76, v96, s22, 0                           // 0000001B060C: CC22004C 02002D60
	s_waitcnt lgkmcnt(1)                                       // 0000001B0614: BF89FC17
	v_fma_mixlo_f16 v77, v77, s22, 0                           // 0000001B0618: CC21004D 02002D4D
	v_fma_mixhi_f16 v77, v78, s22, 0                           // 0000001B0620: CC22004D 02002D4E
	v_fma_mixlo_f16 v78, v79, s22, 0                           // 0000001B0628: CC21004E 02002D4F
	v_fma_mixhi_f16 v78, v80, s22, 0                           // 0000001B0630: CC22004E 02002D50
	s_waitcnt lgkmcnt(0)                                       // 0000001B0638: BF89FC07
	v_fma_mixlo_f16 v79, v81, s22, 0                           // 0000001B063C: CC21004F 02002D51
	v_fma_mixhi_f16 v79, v82, s22, 0                           // 0000001B0644: CC22004F 02002D52
	v_fma_mixlo_f16 v80, v83, s22, 0                           // 0000001B064C: CC210050 02002D53
	v_fma_mixhi_f16 v80, v84, s22, 0                           // 0000001B0654: CC220050 02002D54
	ds_load_b128 v[85:88], v127 offset:448                     // 0000001B065C: DBFC01C0 5500007F
	ds_load_b128 v[89:92], v127 offset:464                     // 0000001B0664: DBFC01D0 5900007F
	ds_load_b128 v[93:96], v127 offset:480                     // 0000001B066C: DBFC01E0 5D00007F
	s_waitcnt vmcnt(2)                                         // 0000001B0674: BF890BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[9:16], v[33:40], v[41:48]// 0000001B0678: CC404029 1CA64309
	ds_load_b128 v[33:36], v127 offset:496                     // 0000001B0680: DBFC01F0 2100007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[9:16], v[57:64], v[17:24]// 0000001B0688: CC404011 1C467309
	v_wmma_f32_16x16x16_f16 v[49:56], v[9:16], v[65:72], v[49:56]// 0000001B0690: CC404031 1CC68309
	v_wmma_f32_16x16x16_f16 v[25:32], v[9:16], v[73:80], v[25:32]// 0000001B0698: CC404019 1C669309
	ds_load_b128 v[37:40], v127 offset:8896                    // 0000001B06A0: DBFC22C0 2500007F
	ds_load_b128 v[57:60], v127 offset:8912                    // 0000001B06A8: DBFC22D0 3900007F
	ds_load_b128 v[61:64], v127 offset:8928                    // 0000001B06B0: DBFC22E0 3D00007F
	ds_load_b128 v[65:68], v127 offset:8944                    // 0000001B06B8: DBFC22F0 4100007F
	ds_load_b128 v[69:72], v127 offset:17344                   // 0000001B06C0: DBFC43C0 4500007F
	ds_load_b128 v[73:76], v127 offset:17360                   // 0000001B06C8: DBFC43D0 4900007F
	ds_load_b128 v[77:80], v127 offset:17376                   // 0000001B06D0: DBFC43E0 4D00007F
	ds_load_b128 v[81:84], v127 offset:17392                   // 0000001B06D8: DBFC43F0 5100007F
	s_waitcnt lgkmcnt(11)                                      // 0000001B06E0: BF89FCB7
	v_fma_mixlo_f16 v9, v85, s22, 0                            // 0000001B06E4: CC210009 02002D55
	v_fma_mixhi_f16 v9, v86, s22, 0                            // 0000001B06EC: CC220009 02002D56
	v_fma_mixlo_f16 v10, v87, s22, 0                           // 0000001B06F4: CC21000A 02002D57
	v_fma_mixhi_f16 v10, v88, s22, 0                           // 0000001B06FC: CC22000A 02002D58
	s_waitcnt lgkmcnt(8)                                       // 0000001B0704: BF89FC87
	v_fma_mixhi_f16 v15, v34, s22, 0                           // 0000001B0708: CC22000F 02002D22
	v_fma_mixlo_f16 v16, v35, s22, 0                           // 0000001B0710: CC210010 02002D23
	v_fma_mixhi_f16 v16, v36, s22, 0                           // 0000001B0718: CC220010 02002D24
	ds_load_b128 v[85:88], v127 offset:25808                   // 0000001B0720: DBFC64D0 5500007F
	s_waitcnt lgkmcnt(8)                                       // 0000001B0728: BF89FC87
	v_fma_mixlo_f16 v34, v39, s22, 0                           // 0000001B072C: CC210022 02002D27
	v_fma_mixhi_f16 v34, v40, s22, 0                           // 0000001B0734: CC220022 02002D28
	s_waitcnt lgkmcnt(7)                                       // 0000001B073C: BF89FC77
	v_fma_mixlo_f16 v35, v57, s22, 0                           // 0000001B0740: CC210023 02002D39
	v_fma_mixhi_f16 v35, v58, s22, 0                           // 0000001B0748: CC220023 02002D3A
	v_fma_mixlo_f16 v36, v59, s22, 0                           // 0000001B0750: CC210024 02002D3B
	v_fma_mixhi_f16 v36, v60, s22, 0                           // 0000001B0758: CC220024 02002D3C
	s_waitcnt lgkmcnt(5)                                       // 0000001B0760: BF89FC57
	v_fma_mixlo_f16 v39, v65, s22, 0                           // 0000001B0764: CC210027 02002D41
	v_fma_mixhi_f16 v39, v66, s22, 0                           // 0000001B076C: CC220027 02002D42
	v_fma_mixlo_f16 v40, v67, s22, 0                           // 0000001B0774: CC210028 02002D43
	v_fma_mixhi_f16 v40, v68, s22, 0                           // 0000001B077C: CC220028 02002D44
	ds_load_b128 v[65:68], v127 offset:25792                   // 0000001B0784: DBFC64C0 4100007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B078C: BF89FC57
	v_fma_mixlo_f16 v57, v69, s22, 0                           // 0000001B0790: CC210039 02002D45
	v_fma_mixhi_f16 v57, v70, s22, 0                           // 0000001B0798: CC220039 02002D46
	v_fma_mixlo_f16 v58, v71, s22, 0                           // 0000001B07A0: CC21003A 02002D47
	v_fma_mixhi_f16 v58, v72, s22, 0                           // 0000001B07A8: CC22003A 02002D48
	s_waitcnt lgkmcnt(4)                                       // 0000001B07B0: BF89FC47
	v_fma_mixlo_f16 v59, v73, s22, 0                           // 0000001B07B4: CC21003B 02002D49
	v_fma_mixhi_f16 v59, v74, s22, 0                           // 0000001B07BC: CC22003B 02002D4A
	ds_load_b128 v[69:72], v127 offset:25824                   // 0000001B07C4: DBFC64E0 4500007F
	v_fma_mixlo_f16 v60, v75, s22, 0                           // 0000001B07CC: CC21003C 02002D4B
	v_fma_mixhi_f16 v60, v76, s22, 0                           // 0000001B07D4: CC22003C 02002D4C
	ds_load_b128 v[73:76], v127 offset:25840                   // 0000001B07DC: DBFC64F0 4900007F
	v_fma_mixlo_f16 v11, v89, s22, 0                           // 0000001B07E4: CC21000B 02002D59
	v_fma_mixhi_f16 v11, v90, s22, 0                           // 0000001B07EC: CC22000B 02002D5A
	v_fma_mixlo_f16 v12, v91, s22, 0                           // 0000001B07F4: CC21000C 02002D5B
	v_fma_mixhi_f16 v12, v92, s22, 0                           // 0000001B07FC: CC22000C 02002D5C
	v_fma_mixlo_f16 v13, v93, s22, 0                           // 0000001B0804: CC21000D 02002D5D
	v_fma_mixhi_f16 v13, v94, s22, 0                           // 0000001B080C: CC22000D 02002D5E
	v_fma_mixlo_f16 v14, v95, s22, 0                           // 0000001B0814: CC21000E 02002D5F
	v_fma_mixhi_f16 v14, v96, s22, 0                           // 0000001B081C: CC22000E 02002D60
	v_fma_mixlo_f16 v15, v33, s22, 0                           // 0000001B0824: CC21000F 02002D21
	v_fma_mixlo_f16 v33, v37, s22, 0                           // 0000001B082C: CC210021 02002D25
	v_fma_mixhi_f16 v33, v38, s22, 0                           // 0000001B0834: CC220021 02002D26
	v_fma_mixlo_f16 v37, v61, s22, 0                           // 0000001B083C: CC210025 02002D3D
	v_fma_mixhi_f16 v37, v62, s22, 0                           // 0000001B0844: CC220025 02002D3E
	v_fma_mixlo_f16 v38, v63, s22, 0                           // 0000001B084C: CC210026 02002D3F
	v_fma_mixhi_f16 v38, v64, s22, 0                           // 0000001B0854: CC220026 02002D40
	s_waitcnt lgkmcnt(5)                                       // 0000001B085C: BF89FC57
	v_fma_mixlo_f16 v61, v77, s22, 0                           // 0000001B0860: CC21003D 02002D4D
	v_fma_mixhi_f16 v61, v78, s22, 0                           // 0000001B0868: CC22003D 02002D4E
	v_fma_mixlo_f16 v62, v79, s22, 0                           // 0000001B0870: CC21003E 02002D4F
	v_fma_mixhi_f16 v62, v80, s22, 0                           // 0000001B0878: CC22003E 02002D50
	s_waitcnt lgkmcnt(4)                                       // 0000001B0880: BF89FC47
	v_fma_mixlo_f16 v63, v81, s22, 0                           // 0000001B0884: CC21003F 02002D51
	v_fma_mixhi_f16 v63, v82, s22, 0                           // 0000001B088C: CC22003F 02002D52
	v_fma_mixlo_f16 v64, v83, s22, 0                           // 0000001B0894: CC210040 02002D53
	v_fma_mixhi_f16 v64, v84, s22, 0                           // 0000001B089C: CC220040 02002D54
	s_waitcnt lgkmcnt(2)                                       // 0000001B08A4: BF89FC27
	v_fma_mixlo_f16 v65, v65, s22, 0                           // 0000001B08A8: CC210041 02002D41
	v_fma_mixhi_f16 v65, v66, s22, 0                           // 0000001B08B0: CC220041 02002D42
	v_fma_mixlo_f16 v66, v67, s22, 0                           // 0000001B08B8: CC210042 02002D43
	v_fma_mixhi_f16 v66, v68, s22, 0                           // 0000001B08C0: CC220042 02002D44
	v_fma_mixlo_f16 v67, v85, s22, 0                           // 0000001B08C8: CC210043 02002D55
	v_fma_mixhi_f16 v67, v86, s22, 0                           // 0000001B08D0: CC220043 02002D56
	v_fma_mixlo_f16 v68, v87, s22, 0                           // 0000001B08D8: CC210044 02002D57
	v_fma_mixhi_f16 v68, v88, s22, 0                           // 0000001B08E0: CC220044 02002D58
	s_waitcnt lgkmcnt(1)                                       // 0000001B08E8: BF89FC17
	v_fma_mixlo_f16 v69, v69, s22, 0                           // 0000001B08EC: CC210045 02002D45
	v_fma_mixhi_f16 v69, v70, s22, 0                           // 0000001B08F4: CC220045 02002D46
	v_fma_mixlo_f16 v70, v71, s22, 0                           // 0000001B08FC: CC210046 02002D47
	v_fma_mixhi_f16 v70, v72, s22, 0                           // 0000001B0904: CC220046 02002D48
	s_waitcnt lgkmcnt(0)                                       // 0000001B090C: BF89FC07
	v_fma_mixlo_f16 v71, v73, s22, 0                           // 0000001B0910: CC210047 02002D49
	v_fma_mixhi_f16 v71, v74, s22, 0                           // 0000001B0918: CC220047 02002D4A
	v_fma_mixlo_f16 v72, v75, s22, 0                           // 0000001B0920: CC210048 02002D4B
	v_fma_mixhi_f16 v72, v76, s22, 0                           // 0000001B0928: CC220048 02002D4C
	s_waitcnt vmcnt(0)                                         // 0000001B0930: BF8903F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[1:8], v[9:16], v[41:48]// 0000001B0934: CC404029 1CA61301
	v_wmma_f32_16x16x16_f16 v[17:24], v[1:8], v[33:40], v[17:24]// 0000001B093C: CC404011 1C464301
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[57:64], v[49:56]// 0000001B0944: CC404031 1CC67301
	v_wmma_f32_16x16x16_f16 v[25:32], v[1:8], v[65:72], v[25:32]// 0000001B094C: CC404019 1C668301
	v_add_nc_u32_e32 v172, s29, v130                           // 0000001B0954: 4B59041D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B0958: BF870001
	v_or_b32_e32 v1, 2, v172                                   // 0000001B095C: 38035882
	v_or_b32_e32 v2, 4, v172                                   // 0000001B0960: 38055884
	v_or_b32_e32 v5, 6, v172                                   // 0000001B0964: 380B5886
	v_or_b32_e32 v7, 8, v172                                   // 0000001B0968: 380F5888
	v_or_b32_e32 v8, 10, v172                                  // 0000001B096C: 3811588A
	v_min_i32_e32 v1, s62, v1                                  // 0000001B0970: 2202023E
	v_min_i32_e32 v6, s62, v2                                  // 0000001B0974: 220C043E
	v_min_i32_e32 v10, s62, v5                                 // 0000001B0978: 22140A3E
	v_or_b32_e32 v9, 12, v172                                  // 0000001B097C: 3813588C
	v_min_i32_e32 v11, s62, v7                                 // 0000001B0980: 22160E3E
	v_mad_i64_i32 v[1:2], null, v1, 48, s[2:3]                 // 0000001B0984: D6FF7C01 00096101
	v_mad_i64_i32 v[5:6], null, v6, 48, s[2:3]                 // 0000001B098C: D6FF7C05 00096106
	v_min_i32_e32 v13, s62, v8                                 // 0000001B0994: 221A103E
	v_mad_i64_i32 v[7:8], null, v10, 48, s[2:3]                // 0000001B0998: D6FF7C07 0009610A
	v_min_i32_e32 v14, s62, v9                                 // 0000001B09A0: 221C123E
	v_mad_i64_i32 v[9:10], null, v11, 48, s[2:3]               // 0000001B09A4: D6FF7C09 0009610B
	v_or_b32_e32 v15, 14, v172                                 // 0000001B09AC: 381F588E
	v_min_i32_e32 v3, s62, v172                                // 0000001B09B0: 2207583E
	.long 0xd73c0001                                           // 0000001B09B4: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001B09B8: 02020289
	.long 0xd73c0005                                           // 0000001B09BC: D73C0005
	v_cndmask_b32_e32 v1, 9, v5, vcc_lo                        // 0000001B09C0: 02020A89
	.long 0xd444000a                                           // 0000001B09C4: D444000A
	v_cndmask_b32_e32 v1, s58, v172, vcc_lo                    // 0000001B09C8: 0203583A
	v_min_i32_e32 v15, s62, v15                                // 0000001B09CC: 221E1E3E
	v_mad_i64_i32 v[3:4], null, v3, 48, s[2:3]                 // 0000001B09D0: D6FF7C03 00096103
	.long 0xd73c0009                                           // 0000001B09D8: D73C0009
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 0000001B09DC: 02021289
	.long 0xd700000b                                           // 0000001B09E0: D700000B
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001B09E4: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001B09E8: BF8700D1
	v_add_co_ci_u32_e64 v12, null, v135, v2, s0                // 0000001B09EC: D5207C0C 00020587
	.long 0xd73c0001                                           // 0000001B09F4: D73C0001
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 0000001B09F8: 02020E89
	v_mad_i64_i32 v[7:8], null, v13, 48, s[2:3]                // 0000001B09FC: D6FF7C07 0009610D
	v_mad_i64_i32 v[13:14], null, v14, 48, s[2:3]              // 0000001B0A04: D6FF7C0D 0009610E
	.long 0xd7000005                                           // 0000001B0A0C: D7000005
	v_cndmask_b32_e32 v1, v134, v5, vcc_lo                     // 0000001B0A10: 02020B86
	v_add_co_ci_u32_e64 v6, null, v135, v6, s0                 // 0000001B0A14: D5207C06 00020D87
	.long 0xd7000024                                           // 0000001B0A1C: D7000024
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001B0A20: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001B0A24: BF8700B1
	v_add_co_ci_u32_e64 v37, null, v135, v2, s0                // 0000001B0A28: D5207C25 00020587
	.long 0xd73c0001                                           // 0000001B0A30: D73C0001
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 0000001B0A34: 02020E89
	.long 0xd7000007                                           // 0000001B0A38: D7000007
	v_cndmask_b32_e32 v1, v134, v9, vcc_lo                     // 0000001B0A3C: 02021386
	v_add_co_ci_u32_e64 v8, null, v135, v10, s0                // 0000001B0A40: D5207C08 00021587
	.long 0xd73c0009                                           // 0000001B0A48: D73C0009
	v_cndmask_b32_e32 v1, 9, v13, vcc_lo                       // 0000001B0A4C: 02021A89
	v_mad_i64_i32 v[13:14], null, v15, 48, s[2:3]              // 0000001B0A50: D6FF7C0D 0009610F
	.long 0xd7000026                                           // 0000001B0A58: D7000026
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001B0A5C: 02020386
	.long 0xd73c0003                                           // 0000001B0A60: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001B0A64: 02020689
	v_add_co_ci_u32_e64 v39, null, v135, v2, s0                // 0000001B0A68: D5207C27 00020587
	.long 0xd7000043                                           // 0000001B0A70: D7000043
	v_cndmask_b32_e32 v1, v134, v9, vcc_lo                     // 0000001B0A74: 02021386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001B0A78: BF8700B1
	v_add_co_ci_u32_e64 v68, null, v135, v10, s0               // 0000001B0A7C: D5207C44 00021587
	.long 0xd73c0009                                           // 0000001B0A84: D73C0009
	v_cndmask_b32_e32 v1, 9, v13, vcc_lo                       // 0000001B0A88: 02021A89
	.long 0xd7000002                                           // 0000001B0A8C: D7000002
	v_cndmask_b32_e32 v1, v134, v3, vcc_lo                     // 0000001B0A90: 02020786
	v_add_co_ci_u32_e64 v3, null, v135, v4, s0                 // 0000001B0A94: D5207C03 00020987
	.long 0x7e023880                                           // 0000001B0A9C: 7E023880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B0AA0: BF870094
	.long 0xd7000045                                           // 0000001B0AA4: D7000045
	v_cndmask_b32_e32 v1, v134, v9, vcc_lo                     // 0000001B0AA8: 02021386
	v_add_co_ci_u32_e64 v70, null, v135, v10, s0               // 0000001B0AAC: D5207C46 00021587
	s_clause 0x1e                                              // 0000001B0AB4: BF85001E
	global_load_b32 v63, v[11:12], off                         // 0000001B0AB8: DC520000 3F7C000B
	global_load_b32 v60, v[5:6], off                           // 0000001B0AC0: DC520000 3C7C0005
	global_load_b32 v40, v[2:3], off offset:64                 // 0000001B0AC8: DC520040 287C0002
	global_load_b32 v57, v[11:12], off offset:64               // 0000001B0AD0: DC520040 397C000B
	global_load_b32 v35, v[2:3], off offset:128                // 0000001B0AD8: DC520080 237C0002
	global_load_b32 v15, v[11:12], off offset:128              // 0000001B0AE0: DC520080 0F7C000B
	global_load_b32 v9, v[11:12], off offset:192               // 0000001B0AE8: DC5200C0 097C000B
	global_load_b32 v10, v[2:3], off offset:192                // 0000001B0AF0: DC5200C0 0A7C0002
	global_load_b32 v66, v[36:37], off                         // 0000001B0AF8: DC520000 427C0024
	global_load_b32 v65, v[7:8], off                           // 0000001B0B00: DC520000 417C0007
	global_load_b32 v59, v[5:6], off offset:64                 // 0000001B0B08: DC520040 3B7C0005
	global_load_b32 v58, v[36:37], off offset:64               // 0000001B0B10: DC520040 3A7C0024
	global_load_b32 v34, v[5:6], off offset:128                // 0000001B0B18: DC520080 227C0005
	global_load_b32 v12, v[36:37], off offset:128              // 0000001B0B20: DC520080 0C7C0024
	global_load_b32 v4, v[36:37], off offset:192               // 0000001B0B28: DC5200C0 047C0024
	global_load_b32 v11, v[5:6], off offset:192                // 0000001B0B30: DC5200C0 0B7C0005
	global_load_b32 v64, v[38:39], off                         // 0000001B0B38: DC520000 407C0026
	global_load_b32 v61, v[67:68], off                         // 0000001B0B40: DC520000 3D7C0043
	global_load_b32 v36, v[7:8], off offset:64                 // 0000001B0B48: DC520040 247C0007
	global_load_b32 v37, v[38:39], off offset:64               // 0000001B0B50: DC520040 257C0026
	global_load_b32 v16, v[7:8], off offset:128                // 0000001B0B58: DC520080 107C0007
	global_load_b32 v33, v[38:39], off offset:128              // 0000001B0B60: DC520080 217C0026
	global_load_b32 v5, v[38:39], off offset:192               // 0000001B0B68: DC5200C0 057C0026
	global_load_b32 v6, v[7:8], off offset:192                 // 0000001B0B70: DC5200C0 067C0007
	global_load_b32 v62, v[69:70], off                         // 0000001B0B78: DC520000 3E7C0045
	global_load_b32 v38, v[67:68], off offset:64               // 0000001B0B80: DC520040 267C0043
	global_load_b32 v39, v[69:70], off offset:64               // 0000001B0B88: DC520040 277C0045
	global_load_b32 v13, v[67:68], off offset:128              // 0000001B0B90: DC520080 0D7C0043
	global_load_b32 v14, v[69:70], off offset:128              // 0000001B0B98: DC520080 0E7C0045
	global_load_b32 v7, v[69:70], off offset:192               // 0000001B0BA0: DC5200C0 077C0045
	global_load_b32 v8, v[67:68], off offset:192               // 0000001B0BA8: DC5200C0 087C0043
	s_and_saveexec_b32 s0, s10                                 // 0000001B0BB0: BE80200A
	s_cbranch_execz 8                                          // 0000001B0BB4: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x41d8>
	global_load_b32 v1, v[2:3], off                            // 0000001B0BB8: DC520000 017C0002
	s_waitcnt vmcnt(0)                                         // 0000001B0BC0: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v41                         // 0000001B0BC4: 560252FF BB800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B0BCC: BF870001
	v_fma_mixlo_f16 v1, v1, s22, 0                             // 0000001B0BD0: CC210001 02002D01
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001B0BD8: 8C7E007E
	s_waitcnt vmcnt(29)                                        // 0000001B0BDC: BF8977F7
	v_dual_fmac_f32 v60, 0xbb800000, v43 :: v_dual_add_nc_u32 v179, 2, v172// 0000001B0BE0: C82056FF 3CB35882 BB800000
	v_dual_fmac_f32 v63, 0xbb800000, v42 :: v_dual_add_nc_u32 v178, 4, v172// 0000001B0BEC: C82054FF 3FB35884 BB800000
	s_waitcnt vmcnt(14)                                        // 0000001B0BF8: BF893BF7
	v_dual_fmac_f32 v64, 0xbb800000, v46 :: v_dual_add_nc_u32 v177, 6, v172// 0000001B0BFC: C8205CFF 40B15886 BB800000
	v_dual_fmac_f32 v66, 0xbb800000, v44 :: v_dual_fmac_f32 v65, 0xbb800000, v45// 0000001B0C08: C80058FF 42405AFF BB800000
	s_waitcnt vmcnt(13)                                        // 0000001B0C14: BF8937F7
	v_dual_fmac_f32 v61, 0xbb800000, v47 :: v_dual_add_nc_u32 v176, 8, v172// 0000001B0C18: C8205EFF 3DB15888 BB800000
	v_dual_fmac_f32 v40, 0xbb800000, v17 :: v_dual_add_nc_u32 v175, 10, v172// 0000001B0C24: C82022FF 28AF588A BB800000
	v_dual_fmac_f32 v57, 0xbb800000, v18 :: v_dual_add_nc_u32 v174, 12, v172// 0000001B0C30: C82024FF 39AF588C BB800000
	s_waitcnt vmcnt(12)                                        // 0000001B0C3C: BF8933F7
	v_dual_fmac_f32 v36, 0xbb800000, v21 :: v_dual_add_nc_u32 v173, 14, v172// 0000001B0C40: C8202AFF 24AD588E BB800000
	s_waitcnt vmcnt(6)                                         // 0000001B0C4C: BF891BF7
	v_dual_fmac_f32 v62, 0xbb800000, v48 :: v_dual_fmac_f32 v59, 0xbb800000, v19// 0000001B0C50: C80060FF 3E3A26FF BB800000
	.long 0xd444000d                                           // 0000001B0C5C: D444000D
	v_cndmask_b32_e32 v1, s58, v179, vcc_lo                    // 0000001B0C60: 0203663A
	v_fma_mixhi_f16 v1, v63, s22, 0                            // 0000001B0C64: CC220001 02002D3F
	.long 0xd444000c                                           // 0000001B0C6C: D444000C
	v_cndmask_b32_e32 v1, s58, v178, vcc_lo                    // 0000001B0C70: 0203643A
	v_fma_mixlo_f16 v2, v60, s22, 0                            // 0000001B0C74: CC210002 02002D3C
	.long 0xd444000b                                           // 0000001B0C7C: D444000B
	v_cndmask_b32_e32 v1, s58, v177, vcc_lo                    // 0000001B0C80: 0203623A
	v_fma_mixhi_f16 v2, v66, s22, 0                            // 0000001B0C84: CC220002 02002D42
	.long 0xd4440009                                           // 0000001B0C8C: D4440009
	v_cndmask_b32_e32 v1, s58, v176, vcc_lo                    // 0000001B0C90: 0203603A
	v_fma_mixlo_f16 v3, v65, s22, 0                            // 0000001B0C94: CC210003 02002D41
	.long 0xd4440001                                           // 0000001B0C9C: D4440001
	v_cndmask_b32_e32 v1, s58, v175, vcc_lo                    // 0000001B0CA0: 02035E3A
	v_fma_mixhi_f16 v3, v64, s22, 0                            // 0000001B0CA4: CC220003 02002D40
	.long 0xd4440008                                           // 0000001B0CAC: D4440008
	v_cndmask_b32_e32 v1, s58, v174, vcc_lo                    // 0000001B0CB0: 02035C3A
	v_fma_mixlo_f16 v41, v61, s22, 0                           // 0000001B0CB4: CC210029 02002D3D
	.long 0xd4440000                                           // 0000001B0CBC: D4440000
	v_cndmask_b32_e32 v1, s58, v173, vcc_lo                    // 0000001B0CC0: 02035A3A
	v_fma_mixhi_f16 v41, v62, s22, 0                           // 0000001B0CC4: CC220029 02002D3E
	v_dual_fmac_f32 v58, 0xbb800000, v20 :: v_dual_fmac_f32 v37, 0xbb800000, v22// 0000001B0CCC: C80028FF 3A242CFF BB800000
	v_cndmask_b16 v1, 0, v1, s13                               // 0000001B0CD8: D65D5001 00360280
	v_cndmask_b16 v2, 0, v2, s12                               // 0000001B0CE0: D65D0002 00320480
	v_fma_mixlo_f16 v18, v40, s22, 0                           // 0000001B0CE8: CC210012 02002D28
	s_waitcnt vmcnt(4)                                         // 0000001B0CF0: BF8913F7
	v_dual_fmac_f32 v38, 0xbb800000, v23 :: v_dual_fmac_f32 v39, 0xbb800000, v24// 0000001B0CF4: C8002EFF 262630FF BB800000
	v_cndmask_b16 v2, 0, v2, s11                               // 0000001B0D00: D65D5002 002E0480
	v_fma_mixhi_f16 v18, v57, s22, 0                           // 0000001B0D08: CC220012 02002D39
	v_cndmask_b16 v3, 0, v3, s9                                // 0000001B0D10: D65D0003 00260680
	v_fma_mixlo_f16 v19, v59, s22, 0                           // 0000001B0D18: CC210013 02002D3B
	v_cndmask_b16 v3, 0, v3, s1                                // 0000001B0D20: D65D5003 00060680
	v_cndmask_b16 v17, 0, v41, s8                              // 0000001B0D28: D65D0011 00225280
	v_cndmask_b16 v17, 0, v41, s0                              // 0000001B0D30: D65D5011 00025280
	ds_store_b16 v136, v1                                      // 0000001B0D38: D87C0000 00000188
	ds_store_b16_d16_hi v136, v1 offset:4                      // 0000001B0D40: DA840004 00000188
	ds_store_b16 v136, v2 offset:8                             // 0000001B0D48: D87C0008 00000288
	ds_store_b16_d16_hi v136, v2 offset:12                     // 0000001B0D50: DA84000C 00000288
	ds_store_b16 v136, v3 offset:16                            // 0000001B0D58: D87C0010 00000388
	ds_store_b16_d16_hi v136, v3 offset:20                     // 0000001B0D60: DA840014 00000388
	ds_store_b16 v136, v17 offset:24                           // 0000001B0D68: D87C0018 00001188
	ds_store_b16_d16_hi v136, v17 offset:28                    // 0000001B0D70: DA84001C 00001188
	v_fma_mixhi_f16 v2, v58, s22, 0                            // 0000001B0D78: CC220002 02002D3A
	v_fma_mixlo_f16 v3, v36, s22, 0                            // 0000001B0D80: CC210003 02002D24
	v_dual_fmac_f32 v35, 0xbb800000, v49 :: v_dual_fmac_f32 v34, 0xbb800000, v51// 0000001B0D88: C80062FF 232266FF BB800000
	v_cndmask_b16 v1, 0, v18, s10                              // 0000001B0D94: D65D0001 002A2480
	v_fma_mixhi_f16 v3, v37, s22, 0                            // 0000001B0D9C: CC220003 02002D25
	v_fma_mixlo_f16 v17, v38, s22, 0                           // 0000001B0DA4: CC210011 02002D26
	v_fma_mixhi_f16 v17, v39, s22, 0                           // 0000001B0DAC: CC220011 02002D27
	v_dual_fmac_f32 v15, 0xbb800000, v50 :: v_dual_fmac_f32 v12, 0xbb800000, v52// 0000001B0DB4: C80064FF 0F0C68FF BB800000
	v_cndmask_b16 v1, 0, v18, s13                              // 0000001B0DC0: D65D5001 00362480
	v_cndmask_b16 v2, 0, v19, s12                              // 0000001B0DC8: D65D0002 00322680
	v_cndmask_b16 v2, 0, v2, s11                               // 0000001B0DD0: D65D5002 002E0480
	v_dual_fmac_f32 v16, 0xbb800000, v53 :: v_dual_fmac_f32 v33, 0xbb800000, v54// 0000001B0DD8: C8006AFF 10206CFF BB800000
	v_cndmask_b16 v3, 0, v3, s9                                // 0000001B0DE4: D65D0003 00260680
	v_fma_mixlo_f16 v18, v35, s22, 0                           // 0000001B0DEC: CC210012 02002D23
	s_waitcnt vmcnt(2)                                         // 0000001B0DF4: BF890BF7
	v_dual_fmac_f32 v13, 0xbb800000, v55 :: v_dual_fmac_f32 v14, 0xbb800000, v56// 0000001B0DF8: C8006EFF 0D0E70FF BB800000
	v_cndmask_b16 v3, 0, v3, s1                                // 0000001B0E04: D65D5003 00060680
	v_cndmask_b16 v17, 0, v17, s8                              // 0000001B0E0C: D65D0011 00222280
	v_cndmask_b16 v17, 0, v17, s0                              // 0000001B0E14: D65D5011 00022280
	ds_store_b16 v136, v1 offset:2304                          // 0000001B0E1C: D87C0900 00000188
	ds_store_b16_d16_hi v136, v1 offset:2308                   // 0000001B0E24: DA840904 00000188
	ds_store_b16 v136, v2 offset:2312                          // 0000001B0E2C: D87C0908 00000288
	ds_store_b16_d16_hi v136, v2 offset:2316                   // 0000001B0E34: DA84090C 00000288
	ds_store_b16 v136, v3 offset:2320                          // 0000001B0E3C: D87C0910 00000388
	ds_store_b16_d16_hi v136, v3 offset:2324                   // 0000001B0E44: DA840914 00000388
	ds_store_b16 v136, v17 offset:2328                         // 0000001B0E4C: D87C0918 00001188
	ds_store_b16_d16_hi v136, v17 offset:2332                  // 0000001B0E54: DA84091C 00001188
	v_fma_mixhi_f16 v1, v15, s22, 0                            // 0000001B0E5C: CC220001 02002D0F
	v_fma_mixlo_f16 v2, v34, s22, 0                            // 0000001B0E64: CC210002 02002D22
	v_dual_fmac_f32 v10, 0xbb800000, v25 :: v_dual_fmac_f32 v9, 0xbb800000, v26// 0000001B0E6C: C80032FF 0A0834FF BB800000
	v_fma_mixhi_f16 v2, v12, s22, 0                            // 0000001B0E78: CC220002 02002D0C
	v_fma_mixlo_f16 v3, v16, s22, 0                            // 0000001B0E80: CC210003 02002D10
	v_dual_fmac_f32 v11, 0xbb800000, v27 :: v_dual_fmac_f32 v4, 0xbb800000, v28// 0000001B0E88: C80036FF 0B0438FF BB800000
	v_cndmask_b16 v1, 0, v18, s10                              // 0000001B0E94: D65D0001 002A2480
	v_fma_mixhi_f16 v3, v33, s22, 0                            // 0000001B0E9C: CC220003 02002D21
	v_fma_mixlo_f16 v12, v13, s22, 0                           // 0000001B0EA4: CC21000C 02002D0D
	v_fma_mixhi_f16 v12, v14, s22, 0                           // 0000001B0EAC: CC22000C 02002D0E
	v_cndmask_b16 v1, 0, v1, s13                               // 0000001B0EB4: D65D5001 00360280
	v_dual_fmac_f32 v6, 0xbb800000, v29 :: v_dual_fmac_f32 v5, 0xbb800000, v30// 0000001B0EBC: C8003AFF 06043CFF BB800000
	v_cndmask_b16 v2, 0, v2, s12                               // 0000001B0EC8: D65D0002 00320480
	v_fma_mixlo_f16 v10, v10, s22, 0                           // 0000001B0ED0: CC21000A 02002D0A
	s_waitcnt vmcnt(0)                                         // 0000001B0ED8: BF8903F7
	v_dual_fmac_f32 v8, 0xbb800000, v31 :: v_dual_fmac_f32 v7, 0xbb800000, v32// 0000001B0EDC: C8003EFF 080640FF BB800000
	v_cndmask_b16 v2, 0, v2, s11                               // 0000001B0EE8: D65D5002 002E0480
	v_fma_mixlo_f16 v9, v9, s22, 0                             // 0000001B0EF0: CC210009 02002D09
	v_cndmask_b16 v3, 0, v3, s9                                // 0000001B0EF8: D65D0003 00260680
	v_fma_mixhi_f16 v9, v11, s22, 0                            // 0000001B0F00: CC220009 02002D0B
	v_cndmask_b16 v3, 0, v3, s1                                // 0000001B0F08: D65D5003 00060680
	v_cndmask_b16 v12, 0, v12, s8                              // 0000001B0F10: D65D000C 00221880
	v_cndmask_b16 v12, 0, v12, s0                              // 0000001B0F18: D65D500C 00021880
	ds_store_b16 v136, v1 offset:4608                          // 0000001B0F20: D87C1200 00000188
	ds_store_b16_d16_hi v136, v1 offset:4612                   // 0000001B0F28: DA841204 00000188
	ds_store_b16 v136, v2 offset:4616                          // 0000001B0F30: D87C1208 00000288
	ds_store_b16_d16_hi v136, v2 offset:4620                   // 0000001B0F38: DA84120C 00000288
	ds_store_b16 v136, v3 offset:4624                          // 0000001B0F40: D87C1210 00000388
	ds_store_b16_d16_hi v136, v3 offset:4628                   // 0000001B0F48: DA841214 00000388
	ds_store_b16 v136, v12 offset:4632                         // 0000001B0F50: D87C1218 00000C88
	ds_store_b16_d16_hi v136, v12 offset:4636                  // 0000001B0F58: DA84121C 00000C88
	v_fma_mixhi_f16 v2, v4, s22, 0                             // 0000001B0F60: CC220002 02002D04
	v_fma_mixlo_f16 v3, v6, s22, 0                             // 0000001B0F68: CC210003 02002D06
	v_cndmask_b16 v1, 0, v10, s10                              // 0000001B0F70: D65D0001 002A1480
	v_fma_mixhi_f16 v3, v5, s22, 0                             // 0000001B0F78: CC220003 02002D05
	v_fma_mixlo_f16 v4, v8, s22, 0                             // 0000001B0F80: CC210004 02002D08
	v_fma_mixhi_f16 v4, v7, s22, 0                             // 0000001B0F88: CC220004 02002D07
	v_cndmask_b16 v1, 0, v9, s13                               // 0000001B0F90: D65D4001 00361280
	v_cndmask_b16 v2, 0, v9, s12                               // 0000001B0F98: D65D1002 00321280
	v_cndmask_b16 v2, 0, v2, s11                               // 0000001B0FA0: D65D5002 002E0480
	v_cndmask_b16 v3, 0, v3, s9                                // 0000001B0FA8: D65D0003 00260680
	v_cndmask_b16 v3, 0, v3, s1                                // 0000001B0FB0: D65D5003 00060680
	v_cndmask_b16 v4, 0, v4, s8                                // 0000001B0FB8: D65D0004 00220880
	v_cndmask_b16 v4, 0, v4, s0                                // 0000001B0FC0: D65D5004 00020880
	ds_store_b16 v136, v1 offset:6912                          // 0000001B0FC8: D87C1B00 00000188
	ds_store_b16_d16_hi v136, v1 offset:6916                   // 0000001B0FD0: DA841B04 00000188
	ds_store_b16 v136, v2 offset:6920                          // 0000001B0FD8: D87C1B08 00000288
	ds_store_b16_d16_hi v136, v2 offset:6924                   // 0000001B0FE0: DA841B0C 00000288
	ds_store_b16 v136, v3 offset:6928                          // 0000001B0FE8: D87C1B10 00000388
	ds_store_b16_d16_hi v136, v3 offset:6932                   // 0000001B0FF0: DA841B14 00000388
	ds_store_b16 v136, v4 offset:6936                          // 0000001B0FF8: D87C1B18 00000488
	ds_store_b16_d16_hi v136, v4 offset:6940                   // 0000001B1000: DA841B1C 00000488
	.long 0xd7000e01                                           // 0000001B1008: D7000E01
	v_cndmask_b32_e32 v1, s24, v97, vcc_lo                     // 0000001B100C: 0202C218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B1010: BF870001
	v_add_co_ci_u32_e64 v2, null, s25, v98, s14                // 0000001B1014: D5207C02 003AC419
	s_waitcnt lgkmcnt(0)                                       // 0000001B101C: BF89FC07
	s_barrier                                                  // 0000001B1020: BFBD0000
	s_clause 0xf                                               // 0000001B1024: BF85000F
	global_load_b128 v[97:100], v[1:2], off                    // 0000001B1028: DC5E0000 617C0001
	global_load_b128 v[101:104], v[1:2], off offset:16         // 0000001B1030: DC5E0010 657C0001
	global_load_b128 v[89:92], v[1:2], off offset:32           // 0000001B1038: DC5E0020 597C0001
	global_load_b128 v[93:96], v[1:2], off offset:48           // 0000001B1040: DC5E0030 5D7C0001
	global_load_b128 v[81:84], v[1:2], off offset:64           // 0000001B1048: DC5E0040 517C0001
	global_load_b128 v[85:88], v[1:2], off offset:80           // 0000001B1050: DC5E0050 557C0001
	global_load_b128 v[73:76], v[1:2], off offset:96           // 0000001B1058: DC5E0060 497C0001
	global_load_b128 v[77:80], v[1:2], off offset:112          // 0000001B1060: DC5E0070 4D7C0001
	global_load_b128 v[57:60], v[1:2], off offset:128          // 0000001B1068: DC5E0080 397C0001
	global_load_b128 v[61:64], v[1:2], off offset:144          // 0000001B1070: DC5E0090 3D7C0001
	global_load_b128 v[49:52], v[1:2], off offset:160          // 0000001B1078: DC5E00A0 317C0001
	global_load_b128 v[53:56], v[1:2], off offset:176          // 0000001B1080: DC5E00B0 357C0001
	global_load_b128 v[41:44], v[1:2], off offset:192          // 0000001B1088: DC5E00C0 297C0001
	global_load_b128 v[45:48], v[1:2], off offset:208          // 0000001B1090: DC5E00D0 2D7C0001
	global_load_b128 v[33:36], v[1:2], off offset:224          // 0000001B1098: DC5E00E0 217C0001
	global_load_b128 v[37:40], v[1:2], off offset:240          // 0000001B10A0: DC5E00F0 257C0001
	s_and_saveexec_b32 s14, vcc_lo                             // 0000001B10A8: BE8E206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B10AC: BF870009
	s_xor_b32 s14, exec_lo, s14                                // 0000001B10B0: 8D0E0E7E
	s_cbranch_execz 81                                         // 0000001B10B4: BFA50051 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x47fc>
	s_waitcnt vmcnt(15)                                        // 0000001B10B8: BF893FF7
	v_mov_b32_e32 v97, 0                                       // 0000001B10BC: 7EC20280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B10C0: BF870001
	v_mov_b32_e32 v98, v97                                     // 0000001B10C4: 7EC40361
	v_mov_b32_e32 v99, v97                                     // 0000001B10C8: 7EC60361
	v_mov_b32_e32 v100, v97                                    // 0000001B10CC: 7EC80361
	s_waitcnt vmcnt(14)                                        // 0000001B10D0: BF893BF7
	v_mov_b32_e32 v101, v97                                    // 0000001B10D4: 7ECA0361
	v_mov_b32_e32 v102, v97                                    // 0000001B10D8: 7ECC0361
	v_mov_b32_e32 v103, v97                                    // 0000001B10DC: 7ECE0361
	v_mov_b32_e32 v104, v97                                    // 0000001B10E0: 7ED00361
	s_waitcnt vmcnt(13)                                        // 0000001B10E4: BF8937F7
	v_mov_b32_e32 v89, v97                                     // 0000001B10E8: 7EB20361
	v_mov_b32_e32 v90, v97                                     // 0000001B10EC: 7EB40361
	v_mov_b32_e32 v91, v97                                     // 0000001B10F0: 7EB60361
	v_mov_b32_e32 v92, v97                                     // 0000001B10F4: 7EB80361
	s_waitcnt vmcnt(12)                                        // 0000001B10F8: BF8933F7
	v_mov_b32_e32 v93, v97                                     // 0000001B10FC: 7EBA0361
	v_mov_b32_e32 v94, v97                                     // 0000001B1100: 7EBC0361
	v_mov_b32_e32 v95, v97                                     // 0000001B1104: 7EBE0361
	v_mov_b32_e32 v96, v97                                     // 0000001B1108: 7EC00361
	s_waitcnt vmcnt(11)                                        // 0000001B110C: BF892FF7
	v_mov_b32_e32 v81, v97                                     // 0000001B1110: 7EA20361
	v_mov_b32_e32 v82, v97                                     // 0000001B1114: 7EA40361
	v_mov_b32_e32 v83, v97                                     // 0000001B1118: 7EA60361
	v_mov_b32_e32 v84, v97                                     // 0000001B111C: 7EA80361
	s_waitcnt vmcnt(10)                                        // 0000001B1120: BF892BF7
	v_mov_b32_e32 v85, v97                                     // 0000001B1124: 7EAA0361
	v_mov_b32_e32 v86, v97                                     // 0000001B1128: 7EAC0361
	v_mov_b32_e32 v87, v97                                     // 0000001B112C: 7EAE0361
	v_mov_b32_e32 v88, v97                                     // 0000001B1130: 7EB00361
	s_waitcnt vmcnt(9)                                         // 0000001B1134: BF8927F7
	v_mov_b32_e32 v73, v97                                     // 0000001B1138: 7E920361
	v_mov_b32_e32 v74, v97                                     // 0000001B113C: 7E940361
	v_mov_b32_e32 v75, v97                                     // 0000001B1140: 7E960361
	v_mov_b32_e32 v76, v97                                     // 0000001B1144: 7E980361
	s_waitcnt vmcnt(8)                                         // 0000001B1148: BF8923F7
	v_mov_b32_e32 v77, v97                                     // 0000001B114C: 7E9A0361
	v_mov_b32_e32 v78, v97                                     // 0000001B1150: 7E9C0361
	v_mov_b32_e32 v79, v97                                     // 0000001B1154: 7E9E0361
	v_mov_b32_e32 v80, v97                                     // 0000001B1158: 7EA00361
	s_waitcnt vmcnt(7)                                         // 0000001B115C: BF891FF7
	v_mov_b32_e32 v57, v97                                     // 0000001B1160: 7E720361
	v_mov_b32_e32 v58, v97                                     // 0000001B1164: 7E740361
	v_mov_b32_e32 v59, v97                                     // 0000001B1168: 7E760361
	v_mov_b32_e32 v60, v97                                     // 0000001B116C: 7E780361
	s_waitcnt vmcnt(6)                                         // 0000001B1170: BF891BF7
	v_mov_b32_e32 v61, v97                                     // 0000001B1174: 7E7A0361
	v_mov_b32_e32 v62, v97                                     // 0000001B1178: 7E7C0361
	v_mov_b32_e32 v63, v97                                     // 0000001B117C: 7E7E0361
	v_mov_b32_e32 v64, v97                                     // 0000001B1180: 7E800361
	s_waitcnt vmcnt(5)                                         // 0000001B1184: BF8917F7
	v_mov_b32_e32 v49, v97                                     // 0000001B1188: 7E620361
	v_mov_b32_e32 v50, v97                                     // 0000001B118C: 7E640361
	v_mov_b32_e32 v51, v97                                     // 0000001B1190: 7E660361
	v_mov_b32_e32 v52, v97                                     // 0000001B1194: 7E680361
	s_waitcnt vmcnt(4)                                         // 0000001B1198: BF8913F7
	v_mov_b32_e32 v53, v97                                     // 0000001B119C: 7E6A0361
	v_mov_b32_e32 v54, v97                                     // 0000001B11A0: 7E6C0361
	v_mov_b32_e32 v55, v97                                     // 0000001B11A4: 7E6E0361
	v_mov_b32_e32 v56, v97                                     // 0000001B11A8: 7E700361
	s_waitcnt vmcnt(3)                                         // 0000001B11AC: BF890FF7
	v_mov_b32_e32 v41, v97                                     // 0000001B11B0: 7E520361
	v_mov_b32_e32 v42, v97                                     // 0000001B11B4: 7E540361
	v_mov_b32_e32 v43, v97                                     // 0000001B11B8: 7E560361
	v_mov_b32_e32 v44, v97                                     // 0000001B11BC: 7E580361
	s_waitcnt vmcnt(2)                                         // 0000001B11C0: BF890BF7
	v_mov_b32_e32 v45, v97                                     // 0000001B11C4: 7E5A0361
	v_mov_b32_e32 v46, v97                                     // 0000001B11C8: 7E5C0361
	v_mov_b32_e32 v47, v97                                     // 0000001B11CC: 7E5E0361
	v_mov_b32_e32 v48, v97                                     // 0000001B11D0: 7E600361
	s_waitcnt vmcnt(1)                                         // 0000001B11D4: BF8907F7
	v_mov_b32_e32 v33, v97                                     // 0000001B11D8: 7E420361
	v_mov_b32_e32 v34, v97                                     // 0000001B11DC: 7E440361
	v_mov_b32_e32 v35, v97                                     // 0000001B11E0: 7E460361
	v_mov_b32_e32 v36, v97                                     // 0000001B11E4: 7E480361
	s_waitcnt vmcnt(0)                                         // 0000001B11E8: BF8903F7
	v_mov_b32_e32 v37, v97                                     // 0000001B11EC: 7E4A0361
	v_mov_b32_e32 v38, v97                                     // 0000001B11F0: 7E4C0361
	v_mov_b32_e32 v39, v97                                     // 0000001B11F4: 7E4E0361
	v_mov_b32_e32 v40, v97                                     // 0000001B11F8: 7E500361
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B11FC: 8C7E0E7E
	ds_load_b128 v[1:4], v127                                  // 0000001B1200: DBFC0000 0100007F
	ds_load_b128 v[5:8], v127 offset:16                        // 0000001B1208: DBFC0010 0500007F
	ds_load_b128 v[9:12], v127 offset:32                       // 0000001B1210: DBFC0020 0900007F
	ds_load_b128 v[13:16], v127 offset:48                      // 0000001B1218: DBFC0030 0D00007F
	ds_load_b128 v[17:20], v127 offset:8448                    // 0000001B1220: DBFC2100 1100007F
	ds_load_b128 v[21:24], v127 offset:8464                    // 0000001B1228: DBFC2110 1500007F
	ds_load_b128 v[25:28], v127 offset:8480                    // 0000001B1230: DBFC2120 1900007F
	ds_load_b128 v[29:32], v127 offset:8496                    // 0000001B1238: DBFC2130 1D00007F
	ds_load_b128 v[180:183], v127 offset:16896                 // 0000001B1240: DBFC4200 B400007F
	ds_load_b128 v[184:187], v127 offset:16912                 // 0000001B1248: DBFC4210 B800007F
	ds_load_b128 v[188:191], v127 offset:16928                 // 0000001B1250: DBFC4220 BC00007F
	ds_load_b128 v[192:195], v127 offset:16944                 // 0000001B1258: DBFC4230 C000007F
	ds_load_b128 v[196:199], v127 offset:25376                 // 0000001B1260: DBFC6320 C400007F
	v_dual_mov_b32 v72, s43 :: v_dual_mov_b32 v71, s42         // 0000001B1268: CA10002B 4846002A
	v_dual_mov_b32 v70, s41 :: v_dual_mov_b32 v69, s40         // 0000001B1270: CA100029 46440028
	v_dual_mov_b32 v68, s39 :: v_dual_mov_b32 v67, s38         // 0000001B1278: CA100027 44420026
	v_dual_mov_b32 v66, s37 :: v_dual_mov_b32 v65, s36         // 0000001B1280: CA100025 42400024
	s_waitcnt lgkmcnt(12)                                      // 0000001B1288: BF89FCC7
	v_fma_mixlo_f16 v1, v1, s22, 0                             // 0000001B128C: CC210001 02002D01
	v_fma_mixhi_f16 v1, v2, s22, 0                             // 0000001B1294: CC220001 02002D02
	v_fma_mixlo_f16 v2, v3, s22, 0                             // 0000001B129C: CC210002 02002D03
	v_fma_mixhi_f16 v2, v4, s22, 0                             // 0000001B12A4: CC220002 02002D04
	s_waitcnt lgkmcnt(11)                                      // 0000001B12AC: BF89FCB7
	v_fma_mixlo_f16 v3, v5, s22, 0                             // 0000001B12B0: CC210003 02002D05
	v_fma_mixhi_f16 v3, v6, s22, 0                             // 0000001B12B8: CC220003 02002D06
	v_fma_mixlo_f16 v4, v7, s22, 0                             // 0000001B12C0: CC210004 02002D07
	v_fma_mixhi_f16 v4, v8, s22, 0                             // 0000001B12C8: CC220004 02002D08
	s_waitcnt lgkmcnt(10)                                      // 0000001B12D0: BF89FCA7
	v_fma_mixlo_f16 v5, v9, s22, 0                             // 0000001B12D4: CC210005 02002D09
	v_fma_mixhi_f16 v5, v10, s22, 0                            // 0000001B12DC: CC220005 02002D0A
	v_fma_mixlo_f16 v6, v11, s22, 0                            // 0000001B12E4: CC210006 02002D0B
	v_fma_mixhi_f16 v6, v12, s22, 0                            // 0000001B12EC: CC220006 02002D0C
	s_waitcnt lgkmcnt(9)                                       // 0000001B12F4: BF89FC97
	v_fma_mixlo_f16 v7, v13, s22, 0                            // 0000001B12F8: CC210007 02002D0D
	v_fma_mixhi_f16 v7, v14, s22, 0                            // 0000001B1300: CC220007 02002D0E
	v_fma_mixlo_f16 v8, v15, s22, 0                            // 0000001B1308: CC210008 02002D0F
	v_fma_mixhi_f16 v8, v16, s22, 0                            // 0000001B1310: CC220008 02002D10
	s_waitcnt lgkmcnt(8)                                       // 0000001B1318: BF89FC87
	v_fma_mixlo_f16 v17, v17, s22, 0                           // 0000001B131C: CC210011 02002D11
	v_fma_mixhi_f16 v17, v18, s22, 0                           // 0000001B1324: CC220011 02002D12
	v_fma_mixlo_f16 v18, v19, s22, 0                           // 0000001B132C: CC210012 02002D13
	v_fma_mixhi_f16 v18, v20, s22, 0                           // 0000001B1334: CC220012 02002D14
	s_waitcnt lgkmcnt(7)                                       // 0000001B133C: BF89FC77
	v_fma_mixlo_f16 v19, v21, s22, 0                           // 0000001B1340: CC210013 02002D15
	v_fma_mixhi_f16 v19, v22, s22, 0                           // 0000001B1348: CC220013 02002D16
	v_fma_mixlo_f16 v20, v23, s22, 0                           // 0000001B1350: CC210014 02002D17
	v_fma_mixhi_f16 v20, v24, s22, 0                           // 0000001B1358: CC220014 02002D18
	s_waitcnt lgkmcnt(6)                                       // 0000001B1360: BF89FC67
	v_fma_mixlo_f16 v21, v25, s22, 0                           // 0000001B1364: CC210015 02002D19
	v_fma_mixhi_f16 v21, v26, s22, 0                           // 0000001B136C: CC220015 02002D1A
	v_fma_mixlo_f16 v22, v27, s22, 0                           // 0000001B1374: CC210016 02002D1B
	v_fma_mixhi_f16 v22, v28, s22, 0                           // 0000001B137C: CC220016 02002D1C
	s_waitcnt lgkmcnt(5)                                       // 0000001B1384: BF89FC57
	v_fma_mixlo_f16 v23, v29, s22, 0                           // 0000001B1388: CC210017 02002D1D
	v_fma_mixhi_f16 v23, v30, s22, 0                           // 0000001B1390: CC220017 02002D1E
	v_fma_mixlo_f16 v24, v31, s22, 0                           // 0000001B1398: CC210018 02002D1F
	v_fma_mixhi_f16 v24, v32, s22, 0                           // 0000001B13A0: CC220018 02002D20
	s_waitcnt vmcnt(14)                                        // 0000001B13A8: BF893BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[97:104], v[1:8], v[65:72]// 0000001B13AC: CC404019 1D060361
	s_waitcnt lgkmcnt(3)                                       // 0000001B13B4: BF89FC37
	v_fma_mixlo_f16 v4, v186, s22, 0                           // 0000001B13B8: CC210004 02002DBA
	v_fma_mixhi_f16 v4, v187, s22, 0                           // 0000001B13C0: CC220004 02002DBB
	v_wmma_f32_16x16x16_f16 v[9:16], v[97:104], v[17:24], v[65:72]// 0000001B13C8: CC404009 1D062361
	ds_load_b128 v[17:20], v127 offset:25344                   // 0000001B13D0: DBFC6300 1100007F
	ds_load_b128 v[21:24], v127 offset:25360                   // 0000001B13D8: DBFC6310 1500007F
	s_waitcnt lgkmcnt(4)                                       // 0000001B13E0: BF89FC47
	v_fma_mixlo_f16 v5, v188, s22, 0                           // 0000001B13E4: CC210005 02002DBC
	v_fma_mixhi_f16 v5, v189, s22, 0                           // 0000001B13EC: CC220005 02002DBD
	ds_load_b128 v[186:189], v127 offset:25392                 // 0000001B13F4: DBFC6330 BA00007F
	v_fma_mixlo_f16 v3, v184, s22, 0                           // 0000001B13FC: CC210003 02002DB8
	v_fma_mixlo_f16 v6, v190, s22, 0                           // 0000001B1404: CC210006 02002DBE
	v_fma_mixhi_f16 v6, v191, s22, 0                           // 0000001B140C: CC220006 02002DBF
	s_waitcnt lgkmcnt(4)                                       // 0000001B1414: BF89FC47
	v_fma_mixlo_f16 v7, v192, s22, 0                           // 0000001B1418: CC210007 02002DC0
	v_fma_mixhi_f16 v7, v193, s22, 0                           // 0000001B1420: CC220007 02002DC1
	v_fma_mixlo_f16 v8, v194, s22, 0                           // 0000001B1428: CC210008 02002DC2
	v_fma_mixhi_f16 v8, v195, s22, 0                           // 0000001B1430: CC220008 02002DC3
	ds_load_b128 v[190:193], v127 offset:64                    // 0000001B1438: DBFC0040 BE00007F
	ds_load_b128 v[200:203], v127 offset:80                    // 0000001B1440: DBFC0050 C800007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B1448: BF89FC57
	v_fma_mixlo_f16 v184, v196, s22, 0                         // 0000001B144C: CC2100B8 02002DC4
	v_fma_mixhi_f16 v184, v197, s22, 0                         // 0000001B1454: CC2200B8 02002DC5
	ds_load_b128 v[194:197], v127 offset:96                    // 0000001B145C: DBFC0060 C200007F
	ds_load_b128 v[204:207], v127 offset:112                   // 0000001B1464: DBFC0070 CC00007F
	v_fma_mixlo_f16 v1, v180, s22, 0                           // 0000001B146C: CC210001 02002DB4
	v_fma_mixhi_f16 v1, v181, s22, 0                           // 0000001B1474: CC220001 02002DB5
	v_fma_mixlo_f16 v2, v182, s22, 0                           // 0000001B147C: CC210002 02002DB6
	v_fma_mixhi_f16 v2, v183, s22, 0                           // 0000001B1484: CC220002 02002DB7
	v_fma_mixhi_f16 v3, v185, s22, 0                           // 0000001B148C: CC220003 02002DB9
	s_waitcnt lgkmcnt(6)                                       // 0000001B1494: BF89FC67
	v_fma_mixlo_f16 v180, v17, s22, 0                          // 0000001B1498: CC2100B4 02002D11
	v_fma_mixhi_f16 v180, v18, s22, 0                          // 0000001B14A0: CC2200B4 02002D12
	v_fma_mixlo_f16 v181, v19, s22, 0                          // 0000001B14A8: CC2100B5 02002D13
	v_fma_mixhi_f16 v181, v20, s22, 0                          // 0000001B14B0: CC2200B5 02002D14
	s_waitcnt lgkmcnt(5)                                       // 0000001B14B8: BF89FC57
	v_fma_mixlo_f16 v182, v21, s22, 0                          // 0000001B14BC: CC2100B6 02002D15
	v_fma_mixhi_f16 v182, v22, s22, 0                          // 0000001B14C4: CC2200B6 02002D16
	v_fma_mixlo_f16 v183, v23, s22, 0                          // 0000001B14CC: CC2100B7 02002D17
	v_fma_mixhi_f16 v183, v24, s22, 0                          // 0000001B14D4: CC2200B7 02002D18
	v_fma_mixlo_f16 v185, v198, s22, 0                         // 0000001B14DC: CC2100B9 02002DC6
	v_fma_mixhi_f16 v185, v199, s22, 0                         // 0000001B14E4: CC2200B9 02002DC7
	s_waitcnt lgkmcnt(4)                                       // 0000001B14EC: BF89FC47
	v_fma_mixlo_f16 v186, v186, s22, 0                         // 0000001B14F0: CC2100BA 02002DBA
	v_fma_mixhi_f16 v186, v187, s22, 0                         // 0000001B14F8: CC2200BA 02002DBB
	v_fma_mixlo_f16 v187, v188, s22, 0                         // 0000001B1500: CC2100BB 02002DBC
	v_fma_mixhi_f16 v187, v189, s22, 0                         // 0000001B1508: CC2200BB 02002DBD
	v_wmma_f32_16x16x16_f16 v[17:24], v[97:104], v[1:8], v[65:72]// 0000001B1510: CC404011 1D060361
	ds_load_b128 v[208:211], v127 offset:17008                 // 0000001B1518: DBFC4270 D000007F
	ds_load_b128 v[212:215], v127 offset:25408                 // 0000001B1520: DBFC6340 D400007F
	ds_load_b128 v[216:219], v127 offset:25424                 // 0000001B1528: DBFC6350 D800007F
	v_wmma_f32_16x16x16_f16 v[1:8], v[97:104], v[180:187], v[65:72]// 0000001B1530: CC404001 1D076961
	ds_load_b128 v[180:183], v127 offset:8512                  // 0000001B1538: DBFC2140 B400007F
	ds_load_b128 v[184:187], v127 offset:8528                  // 0000001B1540: DBFC2150 B800007F
	s_waitcnt lgkmcnt(8)                                       // 0000001B1548: BF89FC87
	v_fma_mixlo_f16 v97, v190, s22, 0                          // 0000001B154C: CC210061 02002DBE
	v_fma_mixhi_f16 v97, v191, s22, 0                          // 0000001B1554: CC220061 02002DBF
	v_fma_mixlo_f16 v98, v192, s22, 0                          // 0000001B155C: CC210062 02002DC0
	v_fma_mixhi_f16 v98, v193, s22, 0                          // 0000001B1564: CC220062 02002DC1
	s_waitcnt lgkmcnt(7)                                       // 0000001B156C: BF89FC77
	v_fma_mixlo_f16 v99, v200, s22, 0                          // 0000001B1570: CC210063 02002DC8
	v_fma_mixhi_f16 v99, v201, s22, 0                          // 0000001B1578: CC220063 02002DC9
	v_fma_mixlo_f16 v100, v202, s22, 0                         // 0000001B1580: CC210064 02002DCA
	v_fma_mixhi_f16 v100, v203, s22, 0                         // 0000001B1588: CC220064 02002DCB
	ds_load_b128 v[188:191], v127 offset:8544                  // 0000001B1590: DBFC2160 BC00007F
	s_waitcnt lgkmcnt(7)                                       // 0000001B1598: BF89FC77
	v_fma_mixlo_f16 v101, v194, s22, 0                         // 0000001B159C: CC210065 02002DC2
	v_fma_mixhi_f16 v101, v195, s22, 0                         // 0000001B15A4: CC220065 02002DC3
	v_fma_mixlo_f16 v102, v196, s22, 0                         // 0000001B15AC: CC210066 02002DC4
	v_fma_mixhi_f16 v102, v197, s22, 0                         // 0000001B15B4: CC220066 02002DC5
	ds_load_b128 v[192:195], v127 offset:8560                  // 0000001B15BC: DBFC2170 C000007F
	s_waitcnt lgkmcnt(7)                                       // 0000001B15C4: BF89FC77
	v_fma_mixlo_f16 v103, v204, s22, 0                         // 0000001B15C8: CC210067 02002DCC
	v_fma_mixhi_f16 v103, v205, s22, 0                         // 0000001B15D0: CC220067 02002DCD
	v_fma_mixlo_f16 v104, v206, s22, 0                         // 0000001B15D8: CC210068 02002DCE
	v_fma_mixhi_f16 v104, v207, s22, 0                         // 0000001B15E0: CC220068 02002DCF
	ds_load_b128 v[196:199], v127 offset:16960                 // 0000001B15E8: DBFC4240 C400007F
	ds_load_b128 v[200:203], v127 offset:16976                 // 0000001B15F0: DBFC4250 C800007F
	ds_load_b128 v[204:207], v127 offset:16992                 // 0000001B15F8: DBFC4260 CC00007F
	s_waitcnt lgkmcnt(6)                                       // 0000001B1600: BF89FC67
	v_fma_mixlo_f16 v180, v180, s22, 0                         // 0000001B1604: CC2100B4 02002DB4
	v_fma_mixhi_f16 v180, v181, s22, 0                         // 0000001B160C: CC2200B4 02002DB5
	v_fma_mixlo_f16 v181, v182, s22, 0                         // 0000001B1614: CC2100B5 02002DB6
	v_fma_mixhi_f16 v181, v183, s22, 0                         // 0000001B161C: CC2200B5 02002DB7
	s_waitcnt lgkmcnt(5)                                       // 0000001B1624: BF89FC57
	v_fma_mixhi_f16 v182, v185, s22, 0                         // 0000001B1628: CC2200B6 02002DB9
	v_fma_mixlo_f16 v183, v186, s22, 0                         // 0000001B1630: CC2100B7 02002DBA
	ds_load_b128 v[220:223], v127 offset:25440                 // 0000001B1638: DBFC6360 DC00007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B1640: BF89FC57
	v_fma_mixhi_f16 v185, v191, s22, 0                         // 0000001B1644: CC2200B9 02002DBF
	v_fma_mixlo_f16 v182, v184, s22, 0                         // 0000001B164C: CC2100B6 02002DB8
	v_fma_mixhi_f16 v183, v187, s22, 0                         // 0000001B1654: CC2200B7 02002DBB
	v_fma_mixlo_f16 v184, v188, s22, 0                         // 0000001B165C: CC2100B8 02002DBC
	v_fma_mixhi_f16 v184, v189, s22, 0                         // 0000001B1664: CC2200B8 02002DBD
	s_waitcnt lgkmcnt(4)                                       // 0000001B166C: BF89FC47
	v_fma_mixlo_f16 v186, v192, s22, 0                         // 0000001B1670: CC2100BA 02002DC0
	v_fma_mixlo_f16 v185, v190, s22, 0                         // 0000001B1678: CC2100B9 02002DBE
	v_fma_mixhi_f16 v186, v193, s22, 0                         // 0000001B1680: CC2200BA 02002DC1
	v_fma_mixlo_f16 v187, v194, s22, 0                         // 0000001B1688: CC2100BB 02002DC2
	v_fma_mixhi_f16 v187, v195, s22, 0                         // 0000001B1690: CC2200BB 02002DC3
	s_waitcnt lgkmcnt(3)                                       // 0000001B1698: BF89FC37
	v_fma_mixlo_f16 v188, v196, s22, 0                         // 0000001B169C: CC2100BC 02002DC4
	s_waitcnt lgkmcnt(2)                                       // 0000001B16A4: BF89FC27
	v_fma_mixlo_f16 v191, v202, s22, 0                         // 0000001B16A8: CC2100BF 02002DCA
	v_fma_mixhi_f16 v191, v203, s22, 0                         // 0000001B16B0: CC2200BF 02002DCB
	s_waitcnt lgkmcnt(1)                                       // 0000001B16B8: BF89FC17
	v_fma_mixlo_f16 v192, v204, s22, 0                         // 0000001B16BC: CC2100C0 02002DCC
	v_fma_mixhi_f16 v192, v205, s22, 0                         // 0000001B16C4: CC2200C0 02002DCD
	ds_load_b128 v[202:205], v127 offset:25456                 // 0000001B16CC: DBFC6370 CA00007F
	v_fma_mixhi_f16 v188, v197, s22, 0                         // 0000001B16D4: CC2200BC 02002DC5
	v_fma_mixlo_f16 v189, v198, s22, 0                         // 0000001B16DC: CC2100BD 02002DC6
	v_fma_mixhi_f16 v189, v199, s22, 0                         // 0000001B16E4: CC2200BD 02002DC7
	v_fma_mixlo_f16 v190, v200, s22, 0                         // 0000001B16EC: CC2100BE 02002DC8
	v_fma_mixhi_f16 v190, v201, s22, 0                         // 0000001B16F4: CC2200BE 02002DC9
	v_fma_mixlo_f16 v193, v206, s22, 0                         // 0000001B16FC: CC2100C1 02002DCE
	v_fma_mixhi_f16 v193, v207, s22, 0                         // 0000001B1704: CC2200C1 02002DCF
	v_fma_mixlo_f16 v194, v208, s22, 0                         // 0000001B170C: CC2100C2 02002DD0
	v_fma_mixhi_f16 v194, v209, s22, 0                         // 0000001B1714: CC2200C2 02002DD1
	v_fma_mixlo_f16 v195, v210, s22, 0                         // 0000001B171C: CC2100C3 02002DD2
	v_fma_mixhi_f16 v195, v211, s22, 0                         // 0000001B1724: CC2200C3 02002DD3
	v_fma_mixlo_f16 v196, v212, s22, 0                         // 0000001B172C: CC2100C4 02002DD4
	v_fma_mixhi_f16 v196, v213, s22, 0                         // 0000001B1734: CC2200C4 02002DD5
	v_fma_mixlo_f16 v197, v214, s22, 0                         // 0000001B173C: CC2100C5 02002DD6
	v_fma_mixhi_f16 v197, v215, s22, 0                         // 0000001B1744: CC2200C5 02002DD7
	v_fma_mixlo_f16 v198, v216, s22, 0                         // 0000001B174C: CC2100C6 02002DD8
	v_fma_mixhi_f16 v198, v217, s22, 0                         // 0000001B1754: CC2200C6 02002DD9
	v_fma_mixlo_f16 v199, v218, s22, 0                         // 0000001B175C: CC2100C7 02002DDA
	v_fma_mixhi_f16 v199, v219, s22, 0                         // 0000001B1764: CC2200C7 02002DDB
	s_waitcnt lgkmcnt(1)                                       // 0000001B176C: BF89FC17
	v_fma_mixlo_f16 v200, v220, s22, 0                         // 0000001B1770: CC2100C8 02002DDC
	v_fma_mixhi_f16 v200, v221, s22, 0                         // 0000001B1778: CC2200C8 02002DDD
	v_fma_mixlo_f16 v201, v222, s22, 0                         // 0000001B1780: CC2100C9 02002DDE
	v_fma_mixhi_f16 v201, v223, s22, 0                         // 0000001B1788: CC2200C9 02002DDF
	s_waitcnt lgkmcnt(0)                                       // 0000001B1790: BF89FC07
	v_fma_mixlo_f16 v202, v202, s22, 0                         // 0000001B1794: CC2100CA 02002DCA
	v_fma_mixhi_f16 v202, v203, s22, 0                         // 0000001B179C: CC2200CA 02002DCB
	v_fma_mixlo_f16 v203, v204, s22, 0                         // 0000001B17A4: CC2100CB 02002DCC
	v_fma_mixhi_f16 v203, v205, s22, 0                         // 0000001B17AC: CC2200CB 02002DCD
	ds_load_b128 v[206:209], v127 offset:128                   // 0000001B17B4: DBFC0080 CE00007F
	ds_load_b128 v[210:213], v127 offset:144                   // 0000001B17BC: DBFC0090 D200007F
	ds_load_b128 v[214:217], v127 offset:160                   // 0000001B17C4: DBFC00A0 D600007F
	s_waitcnt vmcnt(12)                                        // 0000001B17CC: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[97:104], v[25:32]// 0000001B17D0: CC404019 1C66C359
	ds_load_b128 v[97:100], v127 offset:176                    // 0000001B17D8: DBFC00B0 6100007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[89:96], v[180:187], v[9:16]// 0000001B17E0: CC404009 1C276959
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[188:195], v[17:24]// 0000001B17E8: CC404011 1C477959
	v_wmma_f32_16x16x16_f16 v[1:8], v[89:96], v[196:203], v[1:8]// 0000001B17F0: CC404001 1C078959
	ds_load_b128 v[101:104], v127 offset:8576                  // 0000001B17F8: DBFC2180 6500007F
	ds_load_b128 v[180:183], v127 offset:8592                  // 0000001B1800: DBFC2190 B400007F
	ds_load_b128 v[184:187], v127 offset:8608                  // 0000001B1808: DBFC21A0 B800007F
	ds_load_b128 v[188:191], v127 offset:8624                  // 0000001B1810: DBFC21B0 BC00007F
	ds_load_b128 v[192:195], v127 offset:17024                 // 0000001B1818: DBFC4280 C000007F
	ds_load_b128 v[196:199], v127 offset:17040                 // 0000001B1820: DBFC4290 C400007F
	ds_load_b128 v[200:203], v127 offset:17056                 // 0000001B1828: DBFC42A0 C800007F
	s_mul_i32 s14, s23, 48                                     // 0000001B1830: 960EB017
	s_mul_hi_u32 s47, s23, 48                                  // 0000001B1834: 96AFB017
	s_add_u32 s48, s14, s2                                     // 0000001B1838: 8030020E
	s_addc_u32 s49, s47, s3                                    // 0000001B183C: 8231032F
	ds_load_b128 v[220:223], v127 offset:25648                 // 0000001B1840: DBFC6430 DC00007F
	s_waitcnt lgkmcnt(11)                                      // 0000001B1848: BF89FCB7
	v_fma_mixlo_f16 v89, v206, s22, 0                          // 0000001B184C: CC210059 02002DCE
	v_fma_mixhi_f16 v89, v207, s22, 0                          // 0000001B1854: CC220059 02002DCF
	v_fma_mixlo_f16 v90, v208, s22, 0                          // 0000001B185C: CC21005A 02002DD0
	v_fma_mixhi_f16 v90, v209, s22, 0                          // 0000001B1864: CC22005A 02002DD1
	s_waitcnt lgkmcnt(10)                                      // 0000001B186C: BF89FCA7
	v_fma_mixlo_f16 v91, v210, s22, 0                          // 0000001B1870: CC21005B 02002DD2
	v_fma_mixhi_f16 v91, v211, s22, 0                          // 0000001B1878: CC22005B 02002DD3
	s_waitcnt lgkmcnt(8)                                       // 0000001B1880: BF89FC87
	v_fma_mixhi_f16 v95, v98, s22, 0                           // 0000001B1884: CC22005F 02002D62
	v_fma_mixlo_f16 v96, v99, s22, 0                           // 0000001B188C: CC210060 02002D63
	v_fma_mixhi_f16 v96, v100, s22, 0                          // 0000001B1894: CC220060 02002D64
	s_waitcnt lgkmcnt(7)                                       // 0000001B189C: BF89FC77
	v_fma_mixlo_f16 v98, v103, s22, 0                          // 0000001B18A0: CC210062 02002D67
	v_fma_mixhi_f16 v98, v104, s22, 0                          // 0000001B18A8: CC220062 02002D68
	s_waitcnt lgkmcnt(6)                                       // 0000001B18B0: BF89FC67
	v_fma_mixlo_f16 v99, v180, s22, 0                          // 0000001B18B4: CC210063 02002DB4
	v_fma_mixhi_f16 v99, v181, s22, 0                          // 0000001B18BC: CC220063 02002DB5
	v_fma_mixlo_f16 v100, v182, s22, 0                         // 0000001B18C4: CC210064 02002DB6
	v_fma_mixhi_f16 v100, v183, s22, 0                         // 0000001B18CC: CC220064 02002DB7
	s_waitcnt lgkmcnt(4)                                       // 0000001B18D4: BF89FC47
	v_fma_mixlo_f16 v103, v188, s22, 0                         // 0000001B18D8: CC210067 02002DBC
	ds_load_b128 v[204:207], v127 offset:17072                 // 0000001B18E0: DBFC42B0 CC00007F
	v_fma_mixhi_f16 v103, v189, s22, 0                         // 0000001B18E8: CC220067 02002DBD
	v_fma_mixlo_f16 v104, v190, s22, 0                         // 0000001B18F0: CC210068 02002DBE
	v_fma_mixhi_f16 v104, v191, s22, 0                         // 0000001B18F8: CC220068 02002DBF
	ds_load_b128 v[188:191], v127 offset:25472                 // 0000001B1900: DBFC6380 BC00007F
	ds_load_b128 v[208:211], v127 offset:25488                 // 0000001B1908: DBFC6390 D000007F
	s_waitcnt lgkmcnt(6)                                       // 0000001B1910: BF89FC67
	v_fma_mixlo_f16 v180, v192, s22, 0                         // 0000001B1914: CC2100B4 02002DC0
	v_fma_mixhi_f16 v180, v193, s22, 0                         // 0000001B191C: CC2200B4 02002DC1
	v_fma_mixlo_f16 v181, v194, s22, 0                         // 0000001B1924: CC2100B5 02002DC2
	v_fma_mixhi_f16 v181, v195, s22, 0                         // 0000001B192C: CC2200B5 02002DC3
	s_waitcnt lgkmcnt(5)                                       // 0000001B1934: BF89FC57
	v_fma_mixlo_f16 v182, v196, s22, 0                         // 0000001B1938: CC2100B6 02002DC4
	v_fma_mixhi_f16 v182, v197, s22, 0                         // 0000001B1940: CC2200B6 02002DC5
	v_fma_mixlo_f16 v183, v198, s22, 0                         // 0000001B1948: CC2100B7 02002DC6
	ds_load_b128 v[192:195], v127 offset:25504                 // 0000001B1950: DBFC63A0 C000007F
	v_fma_mixhi_f16 v183, v199, s22, 0                         // 0000001B1958: CC2200B7 02002DC7
	ds_load_b128 v[196:199], v127 offset:25520                 // 0000001B1960: DBFC63B0 C400007F
	v_fma_mixlo_f16 v92, v212, s22, 0                          // 0000001B1968: CC21005C 02002DD4
	v_fma_mixhi_f16 v92, v213, s22, 0                          // 0000001B1970: CC22005C 02002DD5
	v_fma_mixlo_f16 v93, v214, s22, 0                          // 0000001B1978: CC21005D 02002DD6
	v_fma_mixhi_f16 v93, v215, s22, 0                          // 0000001B1980: CC22005D 02002DD7
	v_fma_mixlo_f16 v94, v216, s22, 0                          // 0000001B1988: CC21005E 02002DD8
	v_fma_mixhi_f16 v94, v217, s22, 0                          // 0000001B1990: CC22005E 02002DD9
	v_fma_mixlo_f16 v95, v97, s22, 0                           // 0000001B1998: CC21005F 02002D61
	v_fma_mixlo_f16 v97, v101, s22, 0                          // 0000001B19A0: CC210061 02002D65
	v_fma_mixhi_f16 v97, v102, s22, 0                          // 0000001B19A8: CC220061 02002D66
	v_fma_mixlo_f16 v101, v184, s22, 0                         // 0000001B19B0: CC210065 02002DB8
	v_fma_mixhi_f16 v101, v185, s22, 0                         // 0000001B19B8: CC220065 02002DB9
	v_fma_mixlo_f16 v102, v186, s22, 0                         // 0000001B19C0: CC210066 02002DBA
	v_fma_mixhi_f16 v102, v187, s22, 0                         // 0000001B19C8: CC220066 02002DBB
	s_waitcnt lgkmcnt(6)                                       // 0000001B19D0: BF89FC67
	v_fma_mixlo_f16 v184, v200, s22, 0                         // 0000001B19D4: CC2100B8 02002DC8
	v_fma_mixhi_f16 v184, v201, s22, 0                         // 0000001B19DC: CC2200B8 02002DC9
	v_fma_mixlo_f16 v185, v202, s22, 0                         // 0000001B19E4: CC2100B9 02002DCA
	v_fma_mixhi_f16 v185, v203, s22, 0                         // 0000001B19EC: CC2200B9 02002DCB
	s_waitcnt lgkmcnt(4)                                       // 0000001B19F4: BF89FC47
	v_fma_mixlo_f16 v186, v204, s22, 0                         // 0000001B19F8: CC2100BA 02002DCC
	v_fma_mixhi_f16 v186, v205, s22, 0                         // 0000001B1A00: CC2200BA 02002DCD
	v_fma_mixlo_f16 v187, v206, s22, 0                         // 0000001B1A08: CC2100BB 02002DCE
	v_fma_mixhi_f16 v187, v207, s22, 0                         // 0000001B1A10: CC2200BB 02002DCF
	s_waitcnt lgkmcnt(3)                                       // 0000001B1A18: BF89FC37
	v_fma_mixlo_f16 v188, v188, s22, 0                         // 0000001B1A1C: CC2100BC 02002DBC
	v_fma_mixhi_f16 v188, v189, s22, 0                         // 0000001B1A24: CC2200BC 02002DBD
	v_fma_mixlo_f16 v189, v190, s22, 0                         // 0000001B1A2C: CC2100BD 02002DBE
	v_fma_mixhi_f16 v189, v191, s22, 0                         // 0000001B1A34: CC2200BD 02002DBF
	s_waitcnt lgkmcnt(2)                                       // 0000001B1A3C: BF89FC27
	v_fma_mixlo_f16 v190, v208, s22, 0                         // 0000001B1A40: CC2100BE 02002DD0
	v_fma_mixhi_f16 v190, v209, s22, 0                         // 0000001B1A48: CC2200BE 02002DD1
	v_fma_mixlo_f16 v191, v210, s22, 0                         // 0000001B1A50: CC2100BF 02002DD2
	v_fma_mixhi_f16 v191, v211, s22, 0                         // 0000001B1A58: CC2200BF 02002DD3
	s_waitcnt lgkmcnt(1)                                       // 0000001B1A60: BF89FC17
	v_fma_mixlo_f16 v192, v192, s22, 0                         // 0000001B1A64: CC2100C0 02002DC0
	v_fma_mixhi_f16 v192, v193, s22, 0                         // 0000001B1A6C: CC2200C0 02002DC1
	v_fma_mixlo_f16 v193, v194, s22, 0                         // 0000001B1A74: CC2100C1 02002DC2
	v_fma_mixhi_f16 v193, v195, s22, 0                         // 0000001B1A7C: CC2200C1 02002DC3
	s_waitcnt lgkmcnt(0)                                       // 0000001B1A84: BF89FC07
	v_fma_mixlo_f16 v194, v196, s22, 0                         // 0000001B1A88: CC2100C2 02002DC4
	v_fma_mixhi_f16 v194, v197, s22, 0                         // 0000001B1A90: CC2200C2 02002DC5
	v_fma_mixlo_f16 v195, v198, s22, 0                         // 0000001B1A98: CC2100C3 02002DC6
	v_fma_mixhi_f16 v195, v199, s22, 0                         // 0000001B1AA0: CC2200C3 02002DC7
	ds_load_b128 v[200:203], v127 offset:192                   // 0000001B1AA8: DBFC00C0 C800007F
	ds_load_b128 v[204:207], v127 offset:208                   // 0000001B1AB0: DBFC00D0 CC00007F
	ds_load_b128 v[208:211], v127 offset:224                   // 0000001B1AB8: DBFC00E0 D000007F
	s_waitcnt vmcnt(10)                                        // 0000001B1AC0: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 0000001B1AC4: CC404019 1C66B351
	ds_load_b128 v[89:92], v127 offset:240                     // 0000001B1ACC: DBFC00F0 5900007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[97:104], v[9:16]// 0000001B1AD4: CC404009 1C26C351
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[180:187], v[17:24]// 0000001B1ADC: CC404011 1C476951
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[188:195], v[1:8]// 0000001B1AE4: CC404001 1C077951
	ds_load_b128 v[93:96], v127 offset:8640                    // 0000001B1AEC: DBFC21C0 5D00007F
	ds_load_b128 v[97:100], v127 offset:8656                   // 0000001B1AF4: DBFC21D0 6100007F
	ds_load_b128 v[101:104], v127 offset:8672                  // 0000001B1AFC: DBFC21E0 6500007F
	ds_load_b128 v[180:183], v127 offset:8688                  // 0000001B1B04: DBFC21F0 B400007F
	ds_load_b128 v[184:187], v127 offset:17088                 // 0000001B1B0C: DBFC42C0 B800007F
	ds_load_b128 v[188:191], v127 offset:17104                 // 0000001B1B14: DBFC42D0 BC00007F
	ds_load_b128 v[192:195], v127 offset:17120                 // 0000001B1B1C: DBFC42E0 C000007F
	ds_load_b128 v[196:199], v127 offset:17136                 // 0000001B1B24: DBFC42F0 C400007F
	s_lshl_b64 s[48:49], s[48:49], 13                          // 0000001B1B2C: 84B08D30
	ds_load_b128 v[212:215], v127 offset:25616                 // 0000001B1B30: DBFC6410 D400007F
	.long 0xd7006a74                                           // 0000001B1B38: D7006A74
	v_cndmask_b32_e32 v0, v137, v48, vcc_lo                    // 0000001B1B3C: 02006189
	s_waitcnt lgkmcnt(12)                                      // 0000001B1B40: BF89FCC7
	v_fma_mixlo_f16 v81, v200, s22, 0                          // 0000001B1B44: CC210051 02002DC8
	v_fma_mixhi_f16 v81, v201, s22, 0                          // 0000001B1B4C: CC220051 02002DC9
	v_fma_mixlo_f16 v82, v202, s22, 0                          // 0000001B1B54: CC210052 02002DCA
	v_fma_mixhi_f16 v82, v203, s22, 0                          // 0000001B1B5C: CC220052 02002DCB
	s_waitcnt lgkmcnt(9)                                       // 0000001B1B64: BF89FC97
	v_fma_mixhi_f16 v87, v90, s22, 0                           // 0000001B1B68: CC220057 02002D5A
	v_fma_mixlo_f16 v88, v91, s22, 0                           // 0000001B1B70: CC210058 02002D5B
	v_fma_mixhi_f16 v88, v92, s22, 0                           // 0000001B1B78: CC220058 02002D5C
	ds_load_b128 v[200:203], v127 offset:25552                 // 0000001B1B80: DBFC63D0 C800007F
	s_waitcnt lgkmcnt(9)                                       // 0000001B1B88: BF89FC97
	v_fma_mixlo_f16 v90, v95, s22, 0                           // 0000001B1B8C: CC21005A 02002D5F
	v_fma_mixhi_f16 v90, v96, s22, 0                           // 0000001B1B94: CC22005A 02002D60
	s_waitcnt lgkmcnt(8)                                       // 0000001B1B9C: BF89FC87
	v_fma_mixlo_f16 v91, v97, s22, 0                           // 0000001B1BA0: CC21005B 02002D61
	v_fma_mixhi_f16 v91, v98, s22, 0                           // 0000001B1BA8: CC22005B 02002D62
	v_fma_mixlo_f16 v92, v99, s22, 0                           // 0000001B1BB0: CC21005C 02002D63
	v_fma_mixhi_f16 v92, v100, s22, 0                          // 0000001B1BB8: CC22005C 02002D64
	s_waitcnt lgkmcnt(6)                                       // 0000001B1BC0: BF89FC67
	v_fma_mixlo_f16 v95, v180, s22, 0                          // 0000001B1BC4: CC21005F 02002DB4
	v_fma_mixhi_f16 v95, v181, s22, 0                          // 0000001B1BCC: CC22005F 02002DB5
	v_fma_mixlo_f16 v96, v182, s22, 0                          // 0000001B1BD4: CC210060 02002DB6
	v_fma_mixhi_f16 v96, v183, s22, 0                          // 0000001B1BDC: CC220060 02002DB7
	ds_load_b128 v[180:183], v127 offset:25536                 // 0000001B1BE4: DBFC63C0 B400007F
	s_waitcnt lgkmcnt(6)                                       // 0000001B1BEC: BF89FC67
	v_fma_mixlo_f16 v97, v184, s22, 0                          // 0000001B1BF0: CC210061 02002DB8
	v_fma_mixhi_f16 v97, v185, s22, 0                          // 0000001B1BF8: CC220061 02002DB9
	v_fma_mixlo_f16 v98, v186, s22, 0                          // 0000001B1C00: CC210062 02002DBA
	v_fma_mixhi_f16 v98, v187, s22, 0                          // 0000001B1C08: CC220062 02002DBB
	s_waitcnt lgkmcnt(5)                                       // 0000001B1C10: BF89FC57
	v_fma_mixlo_f16 v99, v188, s22, 0                          // 0000001B1C14: CC210063 02002DBC
	v_fma_mixhi_f16 v99, v189, s22, 0                          // 0000001B1C1C: CC220063 02002DBD
	v_fma_mixlo_f16 v100, v190, s22, 0                         // 0000001B1C24: CC210064 02002DBE
	v_fma_mixhi_f16 v100, v191, s22, 0                         // 0000001B1C2C: CC220064 02002DBF
	ds_load_b128 v[184:187], v127 offset:25568                 // 0000001B1C34: DBFC63E0 B800007F
	ds_load_b128 v[188:191], v127 offset:25584                 // 0000001B1C3C: DBFC63F0 BC00007F
	v_fma_mixlo_f16 v83, v204, s22, 0                          // 0000001B1C44: CC210053 02002DCC
	v_fma_mixhi_f16 v83, v205, s22, 0                          // 0000001B1C4C: CC220053 02002DCD
	v_fma_mixlo_f16 v84, v206, s22, 0                          // 0000001B1C54: CC210054 02002DCE
	v_fma_mixhi_f16 v84, v207, s22, 0                          // 0000001B1C5C: CC220054 02002DCF
	v_fma_mixlo_f16 v85, v208, s22, 0                          // 0000001B1C64: CC210055 02002DD0
	v_fma_mixhi_f16 v85, v209, s22, 0                          // 0000001B1C6C: CC220055 02002DD1
	v_fma_mixlo_f16 v86, v210, s22, 0                          // 0000001B1C74: CC210056 02002DD2
	v_fma_mixhi_f16 v86, v211, s22, 0                          // 0000001B1C7C: CC220056 02002DD3
	v_fma_mixlo_f16 v87, v89, s22, 0                           // 0000001B1C84: CC210057 02002D59
	v_fma_mixlo_f16 v89, v93, s22, 0                           // 0000001B1C8C: CC210059 02002D5D
	v_fma_mixhi_f16 v89, v94, s22, 0                           // 0000001B1C94: CC220059 02002D5E
	v_fma_mixlo_f16 v93, v101, s22, 0                          // 0000001B1C9C: CC21005D 02002D65
	v_fma_mixhi_f16 v93, v102, s22, 0                          // 0000001B1CA4: CC22005D 02002D66
	v_fma_mixlo_f16 v94, v103, s22, 0                          // 0000001B1CAC: CC21005E 02002D67
	v_fma_mixhi_f16 v94, v104, s22, 0                          // 0000001B1CB4: CC22005E 02002D68
	s_waitcnt lgkmcnt(6)                                       // 0000001B1CBC: BF89FC67
	v_fma_mixlo_f16 v101, v192, s22, 0                         // 0000001B1CC0: CC210065 02002DC0
	v_fma_mixhi_f16 v101, v193, s22, 0                         // 0000001B1CC8: CC220065 02002DC1
	v_fma_mixlo_f16 v102, v194, s22, 0                         // 0000001B1CD0: CC210066 02002DC2
	v_fma_mixhi_f16 v102, v195, s22, 0                         // 0000001B1CD8: CC220066 02002DC3
	s_waitcnt lgkmcnt(5)                                       // 0000001B1CE0: BF89FC57
	v_fma_mixlo_f16 v103, v196, s22, 0                         // 0000001B1CE4: CC210067 02002DC4
	v_fma_mixhi_f16 v103, v197, s22, 0                         // 0000001B1CEC: CC220067 02002DC5
	v_fma_mixlo_f16 v104, v198, s22, 0                         // 0000001B1CF4: CC210068 02002DC6
	v_fma_mixhi_f16 v104, v199, s22, 0                         // 0000001B1CFC: CC220068 02002DC7
	s_waitcnt vmcnt(8)                                         // 0000001B1D04: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[81:88], v[25:32]// 0000001B1D08: CC404019 1C66A349
	ds_load_b128 v[81:84], v127 offset:8704                    // 0000001B1D10: DBFC2200 5100007F
	ds_load_b128 v[85:88], v127 offset:8720                    // 0000001B1D18: DBFC2210 5500007F
	s_waitcnt lgkmcnt(4)                                       // 0000001B1D20: BF89FC47
	v_fma_mixlo_f16 v180, v180, s22, 0                         // 0000001B1D24: CC2100B4 02002DB4
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[97:104], v[17:24]// 0000001B1D2C: CC404011 1C46C349
	ds_load_b128 v[102:105], v127 offset:8736                  // 0000001B1D34: DBFC2220 6600007F
	v_fma_mixhi_f16 v180, v181, s22, 0                         // 0000001B1D3C: CC2200B4 02002DB5
	v_fma_mixlo_f16 v181, v182, s22, 0                         // 0000001B1D44: CC2100B5 02002DB6
	v_fma_mixhi_f16 v181, v183, s22, 0                         // 0000001B1D4C: CC2200B5 02002DB7
	v_fma_mixlo_f16 v182, v200, s22, 0                         // 0000001B1D54: CC2100B6 02002DC8
	v_fma_mixhi_f16 v182, v201, s22, 0                         // 0000001B1D5C: CC2200B6 02002DC9
	v_fma_mixlo_f16 v183, v202, s22, 0                         // 0000001B1D64: CC2100B7 02002DCA
	v_fma_mixhi_f16 v183, v203, s22, 0                         // 0000001B1D6C: CC2200B7 02002DCB
	s_waitcnt lgkmcnt(4)                                       // 0000001B1D74: BF89FC47
	v_fma_mixlo_f16 v184, v184, s22, 0                         // 0000001B1D78: CC2100B8 02002DB8
	v_fma_mixhi_f16 v184, v185, s22, 0                         // 0000001B1D80: CC2200B8 02002DB9
	v_fma_mixlo_f16 v185, v186, s22, 0                         // 0000001B1D88: CC2100B9 02002DBA
	v_fma_mixhi_f16 v185, v187, s22, 0                         // 0000001B1D90: CC2200B9 02002DBB
	s_waitcnt lgkmcnt(3)                                       // 0000001B1D98: BF89FC37
	v_fma_mixlo_f16 v186, v188, s22, 0                         // 0000001B1D9C: CC2100BA 02002DBC
	v_fma_mixhi_f16 v186, v189, s22, 0                         // 0000001B1DA4: CC2200BA 02002DBD
	v_fma_mixlo_f16 v187, v190, s22, 0                         // 0000001B1DAC: CC2100BB 02002DBE
	v_fma_mixhi_f16 v187, v191, s22, 0                         // 0000001B1DB4: CC2200BB 02002DBF
	v_add_co_ci_u32_e64 v117, null, s49, v138, vcc_lo          // 0000001B1DBC: D5207C75 01AB1431
	v_wmma_f32_16x16x16_f16 v[9:16], v[73:80], v[89:96], v[9:16]// 0000001B1DC4: CC404009 1C26B349
	s_waitcnt lgkmcnt(2)                                       // 0000001B1DCC: BF89FC27
	v_fma_mixlo_f16 v81, v81, s22, 0                           // 0000001B1DD0: CC210051 02002D51
	v_wmma_f32_16x16x16_f16 v[1:8], v[73:80], v[180:187], v[1:8]// 0000001B1DD8: CC404001 1C076949
	s_clause 0x1                                               // 0000001B1DE0: BF850001
	global_load_b128 v[184:187], v[116:117], off offset:16     // 0000001B1DE4: DC5E0010 B87C0074
	global_load_b128 v[180:183], v[116:117], off               // 0000001B1DEC: DC5E0000 B47C0074
	v_fma_mixhi_f16 v81, v82, s22, 0                           // 0000001B1DF4: CC220051 02002D52
	v_fma_mixlo_f16 v82, v83, s22, 0                           // 0000001B1DFC: CC210052 02002D53
	ds_load_b128 v[188:191], v127 offset:8752                  // 0000001B1E04: DBFC2230 BC00007F
	s_waitcnt lgkmcnt(2)                                       // 0000001B1E0C: BF89FC27
	v_fma_mixlo_f16 v83, v85, s22, 0                           // 0000001B1E10: CC210053 02002D55
	v_fma_mixhi_f16 v83, v86, s22, 0                           // 0000001B1E18: CC220053 02002D56
	s_waitcnt lgkmcnt(1)                                       // 0000001B1E20: BF89FC17
	v_fma_mixlo_f16 v85, v102, s22, 0                          // 0000001B1E24: CC210055 02002D66
	v_fma_mixhi_f16 v85, v103, s22, 0                          // 0000001B1E2C: CC220055 02002D67
	v_fma_mixlo_f16 v86, v104, s22, 0                          // 0000001B1E34: CC210056 02002D68
	s_clause 0x3                                               // 0000001B1E3C: BF850003
	global_load_b128 v[101:104], v[116:117], off offset:80     // 0000001B1E40: DC5E0050 657C0074
	global_load_b128 v[97:100], v[116:117], off offset:64      // 0000001B1E48: DC5E0040 617C0074
	global_load_b128 v[93:96], v[116:117], off offset:112      // 0000001B1E50: DC5E0070 5D7C0074
	global_load_b128 v[89:92], v[116:117], off offset:96       // 0000001B1E58: DC5E0060 597C0074
	ds_load_b128 v[192:195], v127 offset:256                   // 0000001B1E60: DBFC0100 C000007F
	ds_load_b128 v[196:199], v127 offset:272                   // 0000001B1E68: DBFC0110 C400007F
	ds_load_b128 v[200:203], v127 offset:288                   // 0000001B1E70: DBFC0120 C800007F
	ds_load_b128 v[204:207], v127 offset:304                   // 0000001B1E78: DBFC0130 CC00007F
	ds_load_b128 v[208:211], v127 offset:25600                 // 0000001B1E80: DBFC6400 D000007F
	ds_load_b128 v[216:219], v127 offset:25632                 // 0000001B1E88: DBFC6420 D800007F
	v_fma_mixhi_f16 v82, v84, s22, 0                           // 0000001B1E90: CC220052 02002D54
	v_fma_mixlo_f16 v84, v87, s22, 0                           // 0000001B1E98: CC210054 02002D57
	v_fma_mixhi_f16 v84, v88, s22, 0                           // 0000001B1EA0: CC220054 02002D58
	v_fma_mixhi_f16 v86, v105, s22, 0                          // 0000001B1EA8: CC220056 02002D69
	s_waitcnt lgkmcnt(6)                                       // 0000001B1EB0: BF89FC67
	v_fma_mixlo_f16 v87, v188, s22, 0                          // 0000001B1EB4: CC210057 02002DBC
	v_fma_mixhi_f16 v87, v189, s22, 0                          // 0000001B1EBC: CC220057 02002DBD
	v_fma_mixlo_f16 v88, v190, s22, 0                          // 0000001B1EC4: CC210058 02002DBE
	v_fma_mixhi_f16 v88, v191, s22, 0                          // 0000001B1ECC: CC220058 02002DBF
	s_waitcnt lgkmcnt(5)                                       // 0000001B1ED4: BF89FC57
	v_fma_mixlo_f16 v73, v192, s22, 0                          // 0000001B1ED8: CC210049 02002DC0
	v_fma_mixhi_f16 v73, v193, s22, 0                          // 0000001B1EE0: CC220049 02002DC1
	v_fma_mixlo_f16 v74, v194, s22, 0                          // 0000001B1EE8: CC21004A 02002DC2
	v_fma_mixhi_f16 v74, v195, s22, 0                          // 0000001B1EF0: CC22004A 02002DC3
	s_waitcnt lgkmcnt(4)                                       // 0000001B1EF8: BF89FC47
	v_fma_mixlo_f16 v75, v196, s22, 0                          // 0000001B1EFC: CC21004B 02002DC4
	v_fma_mixhi_f16 v75, v197, s22, 0                          // 0000001B1F04: CC22004B 02002DC5
	v_fma_mixlo_f16 v76, v198, s22, 0                          // 0000001B1F0C: CC21004C 02002DC6
	v_fma_mixhi_f16 v76, v199, s22, 0                          // 0000001B1F14: CC22004C 02002DC7
	s_waitcnt lgkmcnt(3)                                       // 0000001B1F1C: BF89FC37
	v_fma_mixlo_f16 v77, v200, s22, 0                          // 0000001B1F20: CC21004D 02002DC8
	v_fma_mixhi_f16 v77, v201, s22, 0                          // 0000001B1F28: CC22004D 02002DC9
	v_fma_mixlo_f16 v78, v202, s22, 0                          // 0000001B1F30: CC21004E 02002DCA
	v_fma_mixhi_f16 v78, v203, s22, 0                          // 0000001B1F38: CC22004E 02002DCB
	s_waitcnt lgkmcnt(2)                                       // 0000001B1F40: BF89FC27
	v_fma_mixlo_f16 v79, v204, s22, 0                          // 0000001B1F44: CC21004F 02002DCC
	v_fma_mixhi_f16 v79, v205, s22, 0                          // 0000001B1F4C: CC22004F 02002DCD
	v_fma_mixlo_f16 v80, v206, s22, 0                          // 0000001B1F54: CC210050 02002DCE
	v_fma_mixhi_f16 v80, v207, s22, 0                          // 0000001B1F5C: CC220050 02002DCF
	ds_load_b128 v[192:195], v127 offset:17152                 // 0000001B1F64: DBFC4300 C000007F
	ds_load_b128 v[196:199], v127 offset:17168                 // 0000001B1F6C: DBFC4310 C400007F
	ds_load_b128 v[200:203], v127 offset:17184                 // 0000001B1F74: DBFC4320 C800007F
	ds_load_b128 v[204:207], v127 offset:17200                 // 0000001B1F7C: DBFC4330 CC00007F
	s_waitcnt vmcnt(12)                                        // 0000001B1F84: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[73:80], v[25:32]// 0000001B1F88: CC404019 1C669339
	ds_load_b128 v[73:76], v127 offset:368                     // 0000001B1F90: DBFC0170 4900007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[57:64], v[81:88], v[9:16]// 0000001B1F98: CC404009 1C26A339
	ds_load_b128 v[77:80], v127 offset:8768                    // 0000001B1FA0: DBFC2240 4D00007F
	ds_load_b128 v[81:84], v127 offset:8784                    // 0000001B1FA8: DBFC2250 5100007F
	ds_load_b128 v[85:88], v127 offset:8800                    // 0000001B1FB0: DBFC2260 5500007F
	s_waitcnt lgkmcnt(7)                                       // 0000001B1FB8: BF89FC77
	v_fma_mixlo_f16 v188, v192, s22, 0                         // 0000001B1FBC: CC2100BC 02002DC0
	v_fma_mixhi_f16 v188, v193, s22, 0                         // 0000001B1FC4: CC2200BC 02002DC1
	v_fma_mixlo_f16 v189, v194, s22, 0                         // 0000001B1FCC: CC2100BD 02002DC2
	v_fma_mixhi_f16 v189, v195, s22, 0                         // 0000001B1FD4: CC2200BD 02002DC3
	s_waitcnt lgkmcnt(6)                                       // 0000001B1FDC: BF89FC67
	v_fma_mixlo_f16 v190, v196, s22, 0                         // 0000001B1FE0: CC2100BE 02002DC4
	v_fma_mixhi_f16 v190, v197, s22, 0                         // 0000001B1FE8: CC2200BE 02002DC5
	v_fma_mixlo_f16 v191, v198, s22, 0                         // 0000001B1FF0: CC2100BF 02002DC6
	v_fma_mixhi_f16 v191, v199, s22, 0                         // 0000001B1FF8: CC2200BF 02002DC7
	s_waitcnt lgkmcnt(5)                                       // 0000001B2000: BF89FC57
	v_fma_mixlo_f16 v192, v200, s22, 0                         // 0000001B2004: CC2100C0 02002DC8
	v_fma_mixhi_f16 v192, v201, s22, 0                         // 0000001B200C: CC2200C0 02002DC9
	v_fma_mixlo_f16 v193, v202, s22, 0                         // 0000001B2014: CC2100C1 02002DCA
	v_fma_mixhi_f16 v193, v203, s22, 0                         // 0000001B201C: CC2200C1 02002DCB
	s_waitcnt lgkmcnt(4)                                       // 0000001B2024: BF89FC47
	v_fma_mixlo_f16 v194, v204, s22, 0                         // 0000001B2028: CC2100C2 02002DCC
	v_fma_mixhi_f16 v194, v205, s22, 0                         // 0000001B2030: CC2200C2 02002DCD
	v_fma_mixlo_f16 v195, v206, s22, 0                         // 0000001B2038: CC2100C3 02002DCE
	v_fma_mixhi_f16 v195, v207, s22, 0                         // 0000001B2040: CC2200C3 02002DCF
	v_fma_mixlo_f16 v196, v208, s22, 0                         // 0000001B2048: CC2100C4 02002DD0
	v_fma_mixhi_f16 v196, v209, s22, 0                         // 0000001B2050: CC2200C4 02002DD1
	v_fma_mixlo_f16 v197, v210, s22, 0                         // 0000001B2058: CC2100C5 02002DD2
	v_fma_mixhi_f16 v197, v211, s22, 0                         // 0000001B2060: CC2200C5 02002DD3
	v_fma_mixlo_f16 v198, v212, s22, 0                         // 0000001B2068: CC2100C6 02002DD4
	v_fma_mixhi_f16 v198, v213, s22, 0                         // 0000001B2070: CC2200C6 02002DD5
	v_fma_mixlo_f16 v199, v214, s22, 0                         // 0000001B2078: CC2100C7 02002DD6
	v_fma_mixhi_f16 v199, v215, s22, 0                         // 0000001B2080: CC2200C7 02002DD7
	v_fma_mixlo_f16 v200, v216, s22, 0                         // 0000001B2088: CC2100C8 02002DD8
	v_fma_mixhi_f16 v200, v217, s22, 0                         // 0000001B2090: CC2200C8 02002DD9
	v_fma_mixlo_f16 v201, v218, s22, 0                         // 0000001B2098: CC2100C9 02002DDA
	v_fma_mixhi_f16 v201, v219, s22, 0                         // 0000001B20A0: CC2200C9 02002DDB
	v_fma_mixlo_f16 v202, v220, s22, 0                         // 0000001B20A8: CC2100CA 02002DDC
	v_fma_mixhi_f16 v202, v221, s22, 0                         // 0000001B20B0: CC2200CA 02002DDD
	v_fma_mixlo_f16 v203, v222, s22, 0                         // 0000001B20B8: CC2100CB 02002DDE
	v_fma_mixhi_f16 v203, v223, s22, 0                         // 0000001B20C0: CC2200CB 02002DDF
	ds_load_b128 v[204:207], v127 offset:320                   // 0000001B20C8: DBFC0140 CC00007F
	ds_load_b128 v[208:211], v127 offset:336                   // 0000001B20D0: DBFC0150 D000007F
	ds_load_b128 v[212:215], v127 offset:352                   // 0000001B20D8: DBFC0160 D400007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[188:195], v[17:24]// 0000001B20E0: CC404011 1C477939
	v_wmma_f32_16x16x16_f16 v[1:8], v[57:64], v[196:203], v[1:8]// 0000001B20E8: CC404001 1C078939
	ds_load_b128 v[188:191], v127 offset:8816                  // 0000001B20F0: DBFC2270 BC00007F
	ds_load_b128 v[192:195], v127 offset:17216                 // 0000001B20F8: DBFC4340 C000007F
	ds_load_b128 v[196:199], v127 offset:17232                 // 0000001B2100: DBFC4350 C400007F
	s_waitcnt lgkmcnt(9)                                       // 0000001B2108: BF89FC97
	v_fma_mixhi_f16 v63, v74, s22, 0                           // 0000001B210C: CC22003F 02002D4A
	v_fma_mixlo_f16 v64, v75, s22, 0                           // 0000001B2114: CC210040 02002D4B
	v_fma_mixhi_f16 v64, v76, s22, 0                           // 0000001B211C: CC220040 02002D4C
	s_waitcnt lgkmcnt(8)                                       // 0000001B2124: BF89FC87
	v_fma_mixlo_f16 v74, v79, s22, 0                           // 0000001B2128: CC21004A 02002D4F
	v_fma_mixhi_f16 v74, v80, s22, 0                           // 0000001B2130: CC22004A 02002D50
	s_waitcnt lgkmcnt(7)                                       // 0000001B2138: BF89FC77
	v_fma_mixlo_f16 v75, v81, s22, 0                           // 0000001B213C: CC21004B 02002D51
	v_fma_mixhi_f16 v75, v82, s22, 0                           // 0000001B2144: CC22004B 02002D52
	v_fma_mixlo_f16 v76, v83, s22, 0                           // 0000001B214C: CC21004C 02002D53
	v_fma_mixhi_f16 v76, v84, s22, 0                           // 0000001B2154: CC22004C 02002D54
	ds_load_b128 v[200:203], v127 offset:17248                 // 0000001B215C: DBFC4360 C800007F
	v_fma_mixlo_f16 v63, v73, s22, 0                           // 0000001B2164: CC21003F 02002D49
	v_fma_mixlo_f16 v73, v77, s22, 0                           // 0000001B216C: CC210049 02002D4D
	s_waitcnt lgkmcnt(6)                                       // 0000001B2174: BF89FC67
	v_fma_mixlo_f16 v57, v204, s22, 0                          // 0000001B2178: CC210039 02002DCC
	v_fma_mixhi_f16 v57, v205, s22, 0                          // 0000001B2180: CC220039 02002DCD
	v_fma_mixlo_f16 v58, v206, s22, 0                          // 0000001B2188: CC21003A 02002DCE
	v_fma_mixhi_f16 v58, v207, s22, 0                          // 0000001B2190: CC22003A 02002DCF
	s_waitcnt lgkmcnt(5)                                       // 0000001B2198: BF89FC57
	v_fma_mixlo_f16 v59, v208, s22, 0                          // 0000001B219C: CC21003B 02002DD0
	v_fma_mixhi_f16 v59, v209, s22, 0                          // 0000001B21A4: CC22003B 02002DD1
	v_fma_mixlo_f16 v60, v210, s22, 0                          // 0000001B21AC: CC21003C 02002DD2
	v_fma_mixhi_f16 v60, v211, s22, 0                          // 0000001B21B4: CC22003C 02002DD3
	s_waitcnt lgkmcnt(3)                                       // 0000001B21BC: BF89FC37
	v_fma_mixlo_f16 v79, v188, s22, 0                          // 0000001B21C0: CC21004F 02002DBC
	ds_load_b128 v[204:207], v127 offset:17264                 // 0000001B21C8: DBFC4370 CC00007F
	v_fma_mixhi_f16 v79, v189, s22, 0                          // 0000001B21D0: CC22004F 02002DBD
	v_fma_mixlo_f16 v80, v190, s22, 0                          // 0000001B21D8: CC210050 02002DBE
	v_fma_mixhi_f16 v80, v191, s22, 0                          // 0000001B21E0: CC220050 02002DBF
	ds_load_b128 v[188:191], v127 offset:25664                 // 0000001B21E8: DBFC6440 BC00007F
	ds_load_b128 v[208:211], v127 offset:25680                 // 0000001B21F0: DBFC6450 D000007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B21F8: BF89FC57
	v_fma_mixlo_f16 v81, v192, s22, 0                          // 0000001B21FC: CC210051 02002DC0
	v_fma_mixhi_f16 v81, v193, s22, 0                          // 0000001B2204: CC220051 02002DC1
	v_fma_mixlo_f16 v82, v194, s22, 0                          // 0000001B220C: CC210052 02002DC2
	v_fma_mixhi_f16 v82, v195, s22, 0                          // 0000001B2214: CC220052 02002DC3
	s_waitcnt lgkmcnt(4)                                       // 0000001B221C: BF89FC47
	v_fma_mixlo_f16 v83, v196, s22, 0                          // 0000001B2220: CC210053 02002DC4
	v_fma_mixhi_f16 v83, v197, s22, 0                          // 0000001B2228: CC220053 02002DC5
	v_fma_mixlo_f16 v84, v198, s22, 0                          // 0000001B2230: CC210054 02002DC6
	ds_load_b128 v[192:195], v127 offset:25696                 // 0000001B2238: DBFC6460 C000007F
	v_fma_mixhi_f16 v84, v199, s22, 0                          // 0000001B2240: CC220054 02002DC7
	ds_load_b128 v[196:199], v127 offset:25712                 // 0000001B2248: DBFC6470 C400007F
	v_fma_mixlo_f16 v61, v212, s22, 0                          // 0000001B2250: CC21003D 02002DD4
	v_fma_mixhi_f16 v61, v213, s22, 0                          // 0000001B2258: CC22003D 02002DD5
	v_fma_mixlo_f16 v62, v214, s22, 0                          // 0000001B2260: CC21003E 02002DD6
	v_fma_mixhi_f16 v62, v215, s22, 0                          // 0000001B2268: CC22003E 02002DD7
	v_fma_mixhi_f16 v73, v78, s22, 0                           // 0000001B2270: CC220049 02002D4E
	v_fma_mixlo_f16 v77, v85, s22, 0                           // 0000001B2278: CC21004D 02002D55
	v_fma_mixhi_f16 v77, v86, s22, 0                           // 0000001B2280: CC22004D 02002D56
	v_fma_mixlo_f16 v78, v87, s22, 0                           // 0000001B2288: CC21004E 02002D57
	v_fma_mixhi_f16 v78, v88, s22, 0                           // 0000001B2290: CC22004E 02002D58
	s_waitcnt lgkmcnt(5)                                       // 0000001B2298: BF89FC57
	v_fma_mixlo_f16 v85, v200, s22, 0                          // 0000001B229C: CC210055 02002DC8
	v_fma_mixhi_f16 v85, v201, s22, 0                          // 0000001B22A4: CC220055 02002DC9
	v_fma_mixlo_f16 v86, v202, s22, 0                          // 0000001B22AC: CC210056 02002DCA
	v_fma_mixhi_f16 v86, v203, s22, 0                          // 0000001B22B4: CC220056 02002DCB
	s_waitcnt lgkmcnt(4)                                       // 0000001B22BC: BF89FC47
	v_fma_mixlo_f16 v87, v204, s22, 0                          // 0000001B22C0: CC210057 02002DCC
	v_fma_mixhi_f16 v87, v205, s22, 0                          // 0000001B22C8: CC220057 02002DCD
	v_fma_mixlo_f16 v88, v206, s22, 0                          // 0000001B22D0: CC210058 02002DCE
	v_fma_mixhi_f16 v88, v207, s22, 0                          // 0000001B22D8: CC220058 02002DCF
	s_waitcnt lgkmcnt(3)                                       // 0000001B22E0: BF89FC37
	v_fma_mixlo_f16 v188, v188, s22, 0                         // 0000001B22E4: CC2100BC 02002DBC
	v_fma_mixhi_f16 v188, v189, s22, 0                         // 0000001B22EC: CC2200BC 02002DBD
	v_fma_mixlo_f16 v189, v190, s22, 0                         // 0000001B22F4: CC2100BD 02002DBE
	v_fma_mixhi_f16 v189, v191, s22, 0                         // 0000001B22FC: CC2200BD 02002DBF
	s_waitcnt lgkmcnt(2)                                       // 0000001B2304: BF89FC27
	v_fma_mixlo_f16 v190, v208, s22, 0                         // 0000001B2308: CC2100BE 02002DD0
	v_fma_mixhi_f16 v190, v209, s22, 0                         // 0000001B2310: CC2200BE 02002DD1
	v_fma_mixlo_f16 v191, v210, s22, 0                         // 0000001B2318: CC2100BF 02002DD2
	v_fma_mixhi_f16 v191, v211, s22, 0                         // 0000001B2320: CC2200BF 02002DD3
	s_waitcnt lgkmcnt(1)                                       // 0000001B2328: BF89FC17
	v_fma_mixlo_f16 v192, v192, s22, 0                         // 0000001B232C: CC2100C0 02002DC0
	v_fma_mixhi_f16 v192, v193, s22, 0                         // 0000001B2334: CC2200C0 02002DC1
	v_fma_mixlo_f16 v193, v194, s22, 0                         // 0000001B233C: CC2100C1 02002DC2
	v_fma_mixhi_f16 v193, v195, s22, 0                         // 0000001B2344: CC2200C1 02002DC3
	s_waitcnt lgkmcnt(0)                                       // 0000001B234C: BF89FC07
	v_fma_mixlo_f16 v194, v196, s22, 0                         // 0000001B2350: CC2100C2 02002DC4
	v_fma_mixhi_f16 v194, v197, s22, 0                         // 0000001B2358: CC2200C2 02002DC5
	v_fma_mixlo_f16 v195, v198, s22, 0                         // 0000001B2360: CC2100C3 02002DC6
	v_fma_mixhi_f16 v195, v199, s22, 0                         // 0000001B2368: CC2200C3 02002DC7
	ds_load_b128 v[200:203], v127 offset:384                   // 0000001B2370: DBFC0180 C800007F
	ds_load_b128 v[204:207], v127 offset:400                   // 0000001B2378: DBFC0190 CC00007F
	ds_load_b128 v[208:211], v127 offset:416                   // 0000001B2380: DBFC01A0 D000007F
	s_waitcnt vmcnt(10)                                        // 0000001B2388: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[57:64], v[25:32]// 0000001B238C: CC404019 1C667331
	ds_load_b128 v[57:60], v127 offset:432                     // 0000001B2394: DBFC01B0 3900007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[73:80], v[9:16]// 0000001B239C: CC404009 1C269331
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[81:88], v[17:24]// 0000001B23A4: CC404011 1C46A331
	v_wmma_f32_16x16x16_f16 v[1:8], v[49:56], v[188:195], v[1:8]// 0000001B23AC: CC404001 1C077931
	ds_load_b128 v[61:64], v127 offset:8832                    // 0000001B23B4: DBFC2280 3D00007F
	ds_load_b128 v[73:76], v127 offset:8848                    // 0000001B23BC: DBFC2290 4900007F
	ds_load_b128 v[77:80], v127 offset:8864                    // 0000001B23C4: DBFC22A0 4D00007F
	ds_load_b128 v[81:84], v127 offset:8880                    // 0000001B23CC: DBFC22B0 5100007F
	ds_load_b128 v[85:88], v127 offset:17280                   // 0000001B23D4: DBFC4380 5500007F
	ds_load_b128 v[188:191], v127 offset:17296                 // 0000001B23DC: DBFC4390 BC00007F
	ds_load_b128 v[192:195], v127 offset:17312                 // 0000001B23E4: DBFC43A0 C000007F
	ds_load_b128 v[196:199], v127 offset:17328                 // 0000001B23EC: DBFC43B0 C400007F
	ds_load_b128 v[215:218], v127 offset:25840                 // 0000001B23F4: DBFC64F0 D700007F
	s_waitcnt lgkmcnt(12)                                      // 0000001B23FC: BF89FCC7
	v_fma_mixlo_f16 v49, v200, s22, 0                          // 0000001B2400: CC210031 02002DC8
	v_fma_mixhi_f16 v49, v201, s22, 0                          // 0000001B2408: CC220031 02002DC9
	v_fma_mixlo_f16 v50, v202, s22, 0                          // 0000001B2410: CC210032 02002DCA
	v_fma_mixhi_f16 v50, v203, s22, 0                          // 0000001B2418: CC220032 02002DCB
	s_waitcnt lgkmcnt(9)                                       // 0000001B2420: BF89FC97
	v_fma_mixhi_f16 v55, v58, s22, 0                           // 0000001B2424: CC220037 02002D3A
	v_fma_mixlo_f16 v56, v59, s22, 0                           // 0000001B242C: CC210038 02002D3B
	v_fma_mixhi_f16 v56, v60, s22, 0                           // 0000001B2434: CC220038 02002D3C
	ds_load_b128 v[200:203], v127 offset:25744                 // 0000001B243C: DBFC6490 C800007F
	s_waitcnt lgkmcnt(9)                                       // 0000001B2444: BF89FC97
	v_fma_mixlo_f16 v58, v63, s22, 0                           // 0000001B2448: CC21003A 02002D3F
	v_fma_mixhi_f16 v58, v64, s22, 0                           // 0000001B2450: CC22003A 02002D40
	s_waitcnt lgkmcnt(8)                                       // 0000001B2458: BF89FC87
	v_fma_mixlo_f16 v59, v73, s22, 0                           // 0000001B245C: CC21003B 02002D49
	v_fma_mixhi_f16 v59, v74, s22, 0                           // 0000001B2464: CC22003B 02002D4A
	v_fma_mixlo_f16 v60, v75, s22, 0                           // 0000001B246C: CC21003C 02002D4B
	v_fma_mixhi_f16 v60, v76, s22, 0                           // 0000001B2474: CC22003C 02002D4C
	s_waitcnt lgkmcnt(6)                                       // 0000001B247C: BF89FC67
	v_fma_mixlo_f16 v63, v81, s22, 0                           // 0000001B2480: CC21003F 02002D51
	v_fma_mixhi_f16 v63, v82, s22, 0                           // 0000001B2488: CC22003F 02002D52
	v_fma_mixlo_f16 v64, v83, s22, 0                           // 0000001B2490: CC210040 02002D53
	v_fma_mixhi_f16 v64, v84, s22, 0                           // 0000001B2498: CC220040 02002D54
	ds_load_b128 v[81:84], v127 offset:25728                   // 0000001B24A0: DBFC6480 5100007F
	s_waitcnt lgkmcnt(6)                                       // 0000001B24A8: BF89FC67
	v_fma_mixlo_f16 v73, v85, s22, 0                           // 0000001B24AC: CC210049 02002D55
	v_fma_mixhi_f16 v73, v86, s22, 0                           // 0000001B24B4: CC220049 02002D56
	v_fma_mixlo_f16 v74, v87, s22, 0                           // 0000001B24BC: CC21004A 02002D57
	v_fma_mixhi_f16 v74, v88, s22, 0                           // 0000001B24C4: CC22004A 02002D58
	s_waitcnt lgkmcnt(5)                                       // 0000001B24CC: BF89FC57
	v_fma_mixlo_f16 v75, v188, s22, 0                          // 0000001B24D0: CC21004B 02002DBC
	v_fma_mixhi_f16 v75, v189, s22, 0                          // 0000001B24D8: CC22004B 02002DBD
	v_fma_mixlo_f16 v76, v190, s22, 0                          // 0000001B24E0: CC21004C 02002DBE
	ds_load_b128 v[85:88], v127 offset:25760                   // 0000001B24E8: DBFC64A0 5500007F
	v_fma_mixhi_f16 v76, v191, s22, 0                          // 0000001B24F0: CC22004C 02002DBF
	ds_load_b128 v[188:191], v127 offset:25776                 // 0000001B24F8: DBFC64B0 BC00007F
	v_fma_mixlo_f16 v55, v57, s22, 0                           // 0000001B2500: CC210037 02002D39
	v_fma_mixlo_f16 v57, v61, s22, 0                           // 0000001B2508: CC210039 02002D3D
	v_fma_mixlo_f16 v61, v77, s22, 0                           // 0000001B2510: CC21003D 02002D4D
	v_fma_mixhi_f16 v61, v78, s22, 0                           // 0000001B2518: CC22003D 02002D4E
	s_waitcnt lgkmcnt(6)                                       // 0000001B2520: BF89FC67
	v_fma_mixlo_f16 v77, v192, s22, 0                          // 0000001B2524: CC21004D 02002DC0
	v_fma_mixhi_f16 v77, v193, s22, 0                          // 0000001B252C: CC22004D 02002DC1
	v_fma_mixlo_f16 v78, v194, s22, 0                          // 0000001B2534: CC21004E 02002DC2
	v_fma_mixhi_f16 v78, v195, s22, 0                          // 0000001B253C: CC22004E 02002DC3
	ds_load_b128 v[192:195], v127 offset:448                   // 0000001B2544: DBFC01C0 C000007F
	s_waitcnt lgkmcnt(3)                                       // 0000001B254C: BF89FC37
	v_fma_mixlo_f16 v81, v81, s22, 0                           // 0000001B2550: CC210051 02002D51
	v_fma_mixhi_f16 v81, v82, s22, 0                           // 0000001B2558: CC220051 02002D52
	v_fma_mixlo_f16 v82, v83, s22, 0                           // 0000001B2560: CC210052 02002D53
	v_fma_mixhi_f16 v82, v84, s22, 0                           // 0000001B2568: CC220052 02002D54
	v_fma_mixlo_f16 v83, v200, s22, 0                          // 0000001B2570: CC210053 02002DC8
	v_fma_mixhi_f16 v83, v201, s22, 0                          // 0000001B2578: CC220053 02002DC9
	v_fma_mixlo_f16 v84, v202, s22, 0                          // 0000001B2580: CC210054 02002DCA
	v_fma_mixhi_f16 v84, v203, s22, 0                          // 0000001B2588: CC220054 02002DCB
	s_waitcnt lgkmcnt(2)                                       // 0000001B2590: BF89FC27
	v_fma_mixlo_f16 v85, v85, s22, 0                           // 0000001B2594: CC210055 02002D55
	v_fma_mixhi_f16 v85, v86, s22, 0                           // 0000001B259C: CC220055 02002D56
	v_fma_mixlo_f16 v86, v87, s22, 0                           // 0000001B25A4: CC210056 02002D57
	v_fma_mixhi_f16 v86, v88, s22, 0                           // 0000001B25AC: CC220056 02002D58
	s_waitcnt lgkmcnt(1)                                       // 0000001B25B4: BF89FC17
	v_fma_mixlo_f16 v87, v188, s22, 0                          // 0000001B25B8: CC210057 02002DBC
	ds_load_b128 v[200:203], v127 offset:480                   // 0000001B25C0: DBFC01E0 C800007F
	v_fma_mixhi_f16 v87, v189, s22, 0                          // 0000001B25C8: CC220057 02002DBD
	v_fma_mixlo_f16 v88, v190, s22, 0                          // 0000001B25D0: CC210058 02002DBE
	v_fma_mixhi_f16 v88, v191, s22, 0                          // 0000001B25D8: CC220058 02002DBF
	ds_load_b128 v[188:191], v127 offset:496                   // 0000001B25E0: DBFC01F0 BC00007F
	v_fma_mixlo_f16 v51, v204, s22, 0                          // 0000001B25E8: CC210033 02002DCC
	v_fma_mixhi_f16 v51, v205, s22, 0                          // 0000001B25F0: CC220033 02002DCD
	v_fma_mixlo_f16 v52, v206, s22, 0                          // 0000001B25F8: CC210034 02002DCE
	v_fma_mixhi_f16 v52, v207, s22, 0                          // 0000001B2600: CC220034 02002DCF
	v_fma_mixlo_f16 v53, v208, s22, 0                          // 0000001B2608: CC210035 02002DD0
	v_fma_mixhi_f16 v53, v209, s22, 0                          // 0000001B2610: CC220035 02002DD1
	v_fma_mixlo_f16 v54, v210, s22, 0                          // 0000001B2618: CC210036 02002DD2
	v_fma_mixhi_f16 v54, v211, s22, 0                          // 0000001B2620: CC220036 02002DD3
	v_fma_mixhi_f16 v57, v62, s22, 0                           // 0000001B2628: CC220039 02002D3E
	v_fma_mixlo_f16 v62, v79, s22, 0                           // 0000001B2630: CC21003E 02002D4F
	v_fma_mixhi_f16 v62, v80, s22, 0                           // 0000001B2638: CC22003E 02002D50
	v_fma_mixlo_f16 v79, v196, s22, 0                          // 0000001B2640: CC21004F 02002DC4
	v_fma_mixhi_f16 v79, v197, s22, 0                          // 0000001B2648: CC22004F 02002DC5
	v_fma_mixlo_f16 v80, v198, s22, 0                          // 0000001B2650: CC210050 02002DC6
	v_fma_mixhi_f16 v80, v199, s22, 0                          // 0000001B2658: CC220050 02002DC7
	ds_load_b128 v[196:199], v127 offset:464                   // 0000001B2660: DBFC01D0 C400007F
	s_waitcnt vmcnt(8)                                         // 0000001B2668: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[49:56], v[25:32]// 0000001B266C: CC404019 1C666329
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[57:64], v[9:16]// 0000001B2674: CC404009 1C267329
	v_wmma_f32_16x16x16_f16 v[1:8], v[41:48], v[81:88], v[1:8] // 0000001B267C: CC404001 1C06A329
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[73:80], v[17:24]// 0000001B2684: CC404011 1C469329
	ds_load_b128 v[49:52], v127 offset:8896                    // 0000001B268C: DBFC22C0 3100007F
	ds_load_b128 v[53:56], v127 offset:8912                    // 0000001B2694: DBFC22D0 3500007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B269C: BF89FC57
	v_fma_mixlo_f16 v41, v192, s22, 0                          // 0000001B26A0: CC210029 02002DC0
	v_fma_mixhi_f16 v41, v193, s22, 0                          // 0000001B26A8: CC220029 02002DC1
	v_fma_mixlo_f16 v42, v194, s22, 0                          // 0000001B26B0: CC21002A 02002DC2
	v_fma_mixhi_f16 v42, v195, s22, 0                          // 0000001B26B8: CC22002A 02002DC3
	ds_load_b128 v[57:60], v127 offset:8928                    // 0000001B26C0: DBFC22E0 3900007F
	ds_load_b128 v[61:64], v127 offset:8944                    // 0000001B26C8: DBFC22F0 3D00007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B26D0: BF89FC57
	v_fma_mixlo_f16 v47, v188, s22, 0                          // 0000001B26D4: CC21002F 02002DBC
	v_fma_mixhi_f16 v47, v189, s22, 0                          // 0000001B26DC: CC22002F 02002DBD
	v_fma_mixlo_f16 v48, v190, s22, 0                          // 0000001B26E4: CC210030 02002DBE
	v_fma_mixhi_f16 v48, v191, s22, 0                          // 0000001B26EC: CC220030 02002DBF
	ds_load_b128 v[73:76], v127 offset:17344                   // 0000001B26F4: DBFC43C0 4900007F
	ds_load_b128 v[77:80], v127 offset:17360                   // 0000001B26FC: DBFC43D0 4D00007F
	ds_load_b128 v[81:84], v127 offset:17376                   // 0000001B2704: DBFC43E0 5100007F
	ds_load_b128 v[85:88], v127 offset:17392                   // 0000001B270C: DBFC43F0 5500007F
	ds_load_b128 v[188:191], v127 offset:25792                 // 0000001B2714: DBFC64C0 BC00007F
	ds_load_b128 v[192:195], v127 offset:25808                 // 0000001B271C: DBFC64D0 C000007F
	ds_load_b128 v[211:214], v127 offset:25824                 // 0000001B2724: DBFC64E0 D300007F
	s_waitcnt lgkmcnt(11)                                      // 0000001B272C: BF89FCB7
	v_fma_mixlo_f16 v43, v196, s22, 0                          // 0000001B2730: CC21002B 02002DC4
	v_fma_mixhi_f16 v43, v197, s22, 0                          // 0000001B2738: CC22002B 02002DC5
	v_fma_mixlo_f16 v44, v198, s22, 0                          // 0000001B2740: CC21002C 02002DC6
	v_fma_mixhi_f16 v44, v199, s22, 0                          // 0000001B2748: CC22002C 02002DC7
	v_fma_mixlo_f16 v45, v200, s22, 0                          // 0000001B2750: CC21002D 02002DC8
	v_fma_mixhi_f16 v45, v201, s22, 0                          // 0000001B2758: CC22002D 02002DC9
	v_fma_mixlo_f16 v46, v202, s22, 0                          // 0000001B2760: CC21002E 02002DCA
	v_fma_mixhi_f16 v46, v203, s22, 0                          // 0000001B2768: CC22002E 02002DCB
	s_waitcnt lgkmcnt(10)                                      // 0000001B2770: BF89FCA7
	v_fma_mixlo_f16 v49, v49, s22, 0                           // 0000001B2774: CC210031 02002D31
	v_fma_mixhi_f16 v49, v50, s22, 0                           // 0000001B277C: CC220031 02002D32
	v_fma_mixlo_f16 v50, v51, s22, 0                           // 0000001B2784: CC210032 02002D33
	v_fma_mixhi_f16 v50, v52, s22, 0                           // 0000001B278C: CC220032 02002D34
	s_waitcnt lgkmcnt(9)                                       // 0000001B2794: BF89FC97
	v_fma_mixlo_f16 v51, v53, s22, 0                           // 0000001B2798: CC210033 02002D35
	v_fma_mixhi_f16 v51, v54, s22, 0                           // 0000001B27A0: CC220033 02002D36
	v_fma_mixlo_f16 v52, v55, s22, 0                           // 0000001B27A8: CC210034 02002D37
	v_fma_mixhi_f16 v52, v56, s22, 0                           // 0000001B27B0: CC220034 02002D38
	s_waitcnt lgkmcnt(8)                                       // 0000001B27B8: BF89FC87
	v_fma_mixlo_f16 v53, v57, s22, 0                           // 0000001B27BC: CC210035 02002D39
	v_fma_mixhi_f16 v53, v58, s22, 0                           // 0000001B27C4: CC220035 02002D3A
	v_fma_mixlo_f16 v54, v59, s22, 0                           // 0000001B27CC: CC210036 02002D3B
	s_waitcnt lgkmcnt(7)                                       // 0000001B27D4: BF89FC77
	v_fma_mixlo_f16 v55, v61, s22, 0                           // 0000001B27D8: CC210037 02002D3D
	v_fma_mixhi_f16 v55, v62, s22, 0                           // 0000001B27E0: CC220037 02002D3E
	v_fma_mixlo_f16 v56, v63, s22, 0                           // 0000001B27E8: CC210038 02002D3F
	v_fma_mixhi_f16 v56, v64, s22, 0                           // 0000001B27F0: CC220038 02002D40
	s_waitcnt lgkmcnt(6)                                       // 0000001B27F8: BF89FC67
	v_fma_mixlo_f16 v57, v73, s22, 0                           // 0000001B27FC: CC210039 02002D49
	v_fma_mixhi_f16 v57, v74, s22, 0                           // 0000001B2804: CC220039 02002D4A
	v_fma_mixlo_f16 v58, v75, s22, 0                           // 0000001B280C: CC21003A 02002D4B
	v_fma_mixhi_f16 v58, v76, s22, 0                           // 0000001B2814: CC22003A 02002D4C
	s_waitcnt lgkmcnt(5)                                       // 0000001B281C: BF89FC57
	v_fma_mixlo_f16 v59, v77, s22, 0                           // 0000001B2820: CC21003B 02002D4D
	s_waitcnt lgkmcnt(4)                                       // 0000001B2828: BF89FC47
	v_fma_mixlo_f16 v61, v81, s22, 0                           // 0000001B282C: CC21003D 02002D51
	v_fma_mixhi_f16 v61, v82, s22, 0                           // 0000001B2834: CC22003D 02002D52
	v_fma_mixlo_f16 v62, v83, s22, 0                           // 0000001B283C: CC21003E 02002D53
	v_fma_mixhi_f16 v62, v84, s22, 0                           // 0000001B2844: CC22003E 02002D54
	s_waitcnt lgkmcnt(3)                                       // 0000001B284C: BF89FC37
	v_fma_mixlo_f16 v63, v85, s22, 0                           // 0000001B2850: CC21003F 02002D55
	v_fma_mixhi_f16 v63, v86, s22, 0                           // 0000001B2858: CC22003F 02002D56
	v_fma_mixlo_f16 v64, v87, s22, 0                           // 0000001B2860: CC210040 02002D57
	v_fma_mixhi_f16 v64, v88, s22, 0                           // 0000001B2868: CC220040 02002D58
	s_waitcnt lgkmcnt(2)                                       // 0000001B2870: BF89FC27
	v_fma_mixlo_f16 v73, v188, s22, 0                          // 0000001B2874: CC210049 02002DBC
	v_fma_mixhi_f16 v73, v189, s22, 0                          // 0000001B287C: CC220049 02002DBD
	v_fma_mixlo_f16 v74, v190, s22, 0                          // 0000001B2884: CC21004A 02002DBE
	v_fma_mixhi_f16 v74, v191, s22, 0                          // 0000001B288C: CC22004A 02002DBF
	s_waitcnt lgkmcnt(1)                                       // 0000001B2894: BF89FC17
	v_fma_mixlo_f16 v75, v192, s22, 0                          // 0000001B2898: CC21004B 02002DC0
	v_fma_mixhi_f16 v75, v193, s22, 0                          // 0000001B28A0: CC22004B 02002DC1
	v_fma_mixlo_f16 v76, v194, s22, 0                          // 0000001B28A8: CC21004C 02002DC2
	v_fma_mixhi_f16 v76, v195, s22, 0                          // 0000001B28B0: CC22004C 02002DC3
	s_waitcnt lgkmcnt(0)                                       // 0000001B28B8: BF89FC07
	v_fma_mixlo_f16 v77, v211, s22, 0                          // 0000001B28BC: CC21004D 02002DD3
	ds_load_b128 v[81:84], v128                                // 0000001B28C4: DBFC0000 51000080
	ds_load_b128 v[85:88], v128 offset:16                      // 0000001B28CC: DBFC0010 55000080
	ds_load_b128 v[192:195], v128 offset:2320                  // 0000001B28D4: DBFC0910 C0000080
	ds_load_b128 v[188:191], v128 offset:2304                  // 0000001B28DC: DBFC0900 BC000080
	ds_load_b128 v[200:203], v128 offset:4624                  // 0000001B28E4: DBFC1210 C8000080
	ds_load_b128 v[196:199], v128 offset:4608                  // 0000001B28EC: DBFC1200 C4000080
	ds_load_b128 v[208:211], v128 offset:6928                  // 0000001B28F4: DBFC1B10 D0000080
	ds_load_b128 v[204:207], v128 offset:6912                  // 0000001B28FC: DBFC1B00 CC000080
	v_fma_mixhi_f16 v54, v60, s22, 0                           // 0000001B2904: CC220036 02002D3C
	v_fma_mixhi_f16 v59, v78, s22, 0                           // 0000001B290C: CC22003B 02002D4E
	v_fma_mixlo_f16 v60, v79, s22, 0                           // 0000001B2914: CC21003C 02002D4F
	v_fma_mixhi_f16 v60, v80, s22, 0                           // 0000001B291C: CC22003C 02002D50
	v_fma_mixhi_f16 v77, v212, s22, 0                          // 0000001B2924: CC22004D 02002DD4
	v_fma_mixlo_f16 v78, v213, s22, 0                          // 0000001B292C: CC21004E 02002DD5
	v_fma_mixhi_f16 v78, v214, s22, 0                          // 0000001B2934: CC22004E 02002DD6
	v_fma_mixlo_f16 v79, v215, s22, 0                          // 0000001B293C: CC21004F 02002DD7
	v_fma_mixhi_f16 v79, v216, s22, 0                          // 0000001B2944: CC22004F 02002DD8
	v_fma_mixlo_f16 v80, v217, s22, 0                          // 0000001B294C: CC210050 02002DD9
	v_fma_mixhi_f16 v80, v218, s22, 0                          // 0000001B2954: CC220050 02002DDA
	s_waitcnt vmcnt(6)                                         // 0000001B295C: BF891BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[41:48], v[25:32]// 0000001B2960: CC404019 1C665321
	v_wmma_f32_16x16x16_f16 v[9:16], v[33:40], v[49:56], v[9:16]// 0000001B2968: CC404009 1C266321
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 0000001B2970: CC404011 1C467321
	s_waitcnt vmcnt(4) lgkmcnt(6)                              // 0000001B2978: BF891067
	v_wmma_f32_16x16x16_f16 v[57:64], v[180:187], v[81:88], v[65:72]// 0000001B297C: CC404039 1D06A3B4
	v_wmma_f32_16x16x16_f16 v[1:8], v[33:40], v[73:80], v[1:8] // 0000001B2984: CC404001 1C069321
	s_waitcnt lgkmcnt(4)                                       // 0000001B298C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[180:187], v[188:195], v[65:72]// 0000001B2990: CC404031 1D0779B4
	s_waitcnt lgkmcnt(2)                                       // 0000001B2998: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[180:187], v[196:203], v[65:72]// 0000001B299C: CC404029 1D0789B4
	s_waitcnt lgkmcnt(0)                                       // 0000001B29A4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[180:187], v[204:211], v[65:72]// 0000001B29A8: CC404021 1D0799B4
	s_and_saveexec_b32 s14, s6                                 // 0000001B29B0: BE8E2006
	s_cbranch_execnz 1172                                      // 0000001B29B4: BFA60494 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7208>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B29B8: 8C7E0E7E
	s_and_saveexec_b32 s14, s5                                 // 0000001B29BC: BE8E2005
	s_cbranch_execnz 1205                                      // 0000001B29C0: BFA604B5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7298>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B29C4: 8C7E0E7E
	s_and_saveexec_b32 s14, s7                                 // 0000001B29C8: BE8E2007
	s_cbranch_execz 30                                         // 0000001B29CC: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6048>
	ds_load_b128 v[65:68], v128 offset:96                      // 0000001B29D0: DBFC0060 41000080
	ds_load_b128 v[69:72], v128 offset:112                     // 0000001B29D8: DBFC0070 45000080
	ds_load_b128 v[77:80], v128 offset:2416                    // 0000001B29E0: DBFC0970 4D000080
	ds_load_b128 v[73:76], v128 offset:2400                    // 0000001B29E8: DBFC0960 49000080
	ds_load_b128 v[85:88], v128 offset:4720                    // 0000001B29F0: DBFC1270 55000080
	ds_load_b128 v[81:84], v128 offset:4704                    // 0000001B29F8: DBFC1260 51000080
	s_waitcnt vmcnt(3)                                         // 0000001B2A00: BF890FF7
	ds_load_b128 v[101:104], v128 offset:7024                  // 0000001B2A04: DBFC1B70 65000080
	s_waitcnt vmcnt(2)                                         // 0000001B2A0C: BF890BF7
	ds_load_b128 v[97:100], v128 offset:7008                   // 0000001B2A10: DBFC1B60 61000080
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001B2A18: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[89:96], v[65:72], v[57:64]// 0000001B2A1C: CC404039 1CE68359
	s_waitcnt lgkmcnt(4)                                       // 0000001B2A24: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[89:96], v[73:80], v[49:56]// 0000001B2A28: CC404031 1CC69359
	s_waitcnt lgkmcnt(2)                                       // 0000001B2A30: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[81:88], v[41:48]// 0000001B2A34: CC404029 1CA6A359
	s_waitcnt lgkmcnt(0)                                       // 0000001B2A3C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[89:96], v[97:104], v[33:40]// 0000001B2A40: CC404021 1C86C359
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B2A48: 8C7E0E7E
	s_add_i32 s29, s29, 64                                     // 0000001B2A4C: 811DC01D
	s_mov_b32 s14, -1                                          // 0000001B2A50: BE8E00C1
	s_cmp_le_i32 s29, s58                                      // 0000001B2A54: BF053A1D
	s_cbranch_scc0 392                                         // 0000001B2A58: BFA10188 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x667c>
	ds_load_2addr_b32 v[65:66], v139 offset1:2                 // 0000001B2A5C: D8DC0200 4100008B
	ds_load_2addr_b32 v[67:68], v139 offset0:4 offset1:6       // 0000001B2A64: D8DC0604 4300008B
	ds_load_2addr_b32 v[69:70], v139 offset0:8 offset1:10      // 0000001B2A6C: D8DC0A08 4500008B
	ds_load_2addr_b32 v[71:72], v139 offset0:12 offset1:14     // 0000001B2A74: D8DC0E0C 4700008B
	v_mad_u64_u32 v[73:74], null, 0x3000, v172, v[108:109]     // 0000001B2A7C: D6FE7C49 05B358FF 00003000
	v_mad_u64_u32 v[75:76], null, 0x3000, v179, v[108:109]     // 0000001B2A88: D6FE7C4B 05B366FF 00003000
	v_mad_u64_u32 v[77:78], null, 0x3000, v178, v[108:109]     // 0000001B2A94: D6FE7C4D 05B364FF 00003000
	v_mad_u64_u32 v[79:80], null, 0x3000, v177, v[108:109]     // 0000001B2AA0: D6FE7C4F 05B362FF 00003000
	s_mov_b32 s14, 0                                           // 0000001B2AAC: BE8E0080
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000001B2AB0: BF890437
	v_fma_f32 v96, v9, v65, v49                                // 0000001B2AB4: D6130060 04C68309
	v_fma_f32 v97, v10, v66, v50                               // 0000001B2ABC: D6130061 04CA850A
	s_waitcnt lgkmcnt(2)                                       // 0000001B2AC4: BF89FC27
	v_fma_f32 v98, v11, v67, v51                               // 0000001B2AC8: D6130062 04CE870B
	v_fma_f32 v100, v12, v68, v52                              // 0000001B2AD0: D6130064 04D2890C
	s_waitcnt lgkmcnt(1)                                       // 0000001B2AD8: BF89FC17
	v_fma_f32 v104, v13, v69, v53                              // 0000001B2ADC: D6130068 04D68B0D
	v_dual_mul_f32 v96, 0x3b800000, v96 :: v_dual_mul_f32 v97, 0x3b800000, v97// 0000001B2AE4: C8C6C0FF 6060C2FF 3B800000
	v_mul_f32_e32 v98, 0x3b800000, v98                         // 0000001B2AF0: 10C4C4FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 0000001B2AF8: BF89FC07
	v_fma_f32 v105, v16, v72, v56                              // 0000001B2AFC: D6130069 04E29110
	v_mul_f32_e32 v100, 0x3b800000, v100                       // 0000001B2B04: 10C8C8FF 3B800000
	v_bfe_u32 v101, v96, 16, 1                                 // 0000001B2B0C: D6100065 02052160
	v_bfe_u32 v102, v97, 16, 1                                 // 0000001B2B14: D6100066 02052161
	v_bfe_u32 v103, v98, 16, 1                                 // 0000001B2B1C: D6100067 02052162
	v_mul_f32_e32 v105, 0x3b800000, v105                       // 0000001B2B24: 10D2D2FF 3B800000
	v_fma_f32 v181, v18, v66, v42                              // 0000001B2B2C: D61300B5 04AA8512
	v_add3_u32 v96, v96, v101, 0x7fff                          // 0000001B2B34: D6550060 03FECB60 00007FFF
	v_add3_u32 v97, v97, v102, 0x7fff                          // 0000001B2B40: D6550061 03FECD61 00007FFF
	v_add3_u32 v98, v98, v103, 0x7fff                          // 0000001B2B4C: D6550062 03FECF62 00007FFF
	v_bfe_u32 v101, v100, 16, 1                                // 0000001B2B58: D6100065 02052164
	v_mul_f32_e32 v102, 0x3b800000, v104                       // 0000001B2B60: 10CCD0FF 3B800000
	v_fma_f32 v103, v14, v70, v54                              // 0000001B2B68: D6130067 04DA8D0E
	v_fma_f32 v104, v15, v71, v55                              // 0000001B2B70: D6130068 04DE8F0F
	v_fma_f32 v116, v17, v65, v41                              // 0000001B2B78: D6130074 04A68311
	v_add3_u32 v100, v100, v101, 0x7fff                        // 0000001B2B80: D6550064 03FECB64 00007FFF
	v_bfe_u32 v101, v102, 16, 1                                // 0000001B2B8C: D6100065 02052166
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001B2B94: BF870234
	v_dual_mul_f32 v103, 0x3b800000, v103 :: v_dual_mul_f32 v104, 0x3b800000, v104// 0000001B2B98: C8C6CEFF 6768D0FF 3B800000
	v_bfe_u32 v180, v105, 16, 1                                // 0000001B2BA4: D61000B4 02052169
	v_fma_f32 v183, v22, v70, v46                              // 0000001B2BAC: D61300B7 04BA8D16
	v_add3_u32 v101, v102, v101, 0x7fff                        // 0000001B2BB4: D6550065 03FECB66 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B2BC0: BF870224
	v_bfe_u32 v102, v103, 16, 1                                // 0000001B2BC4: D6100066 02052167
	v_bfe_u32 v117, v104, 16, 1                                // 0000001B2BCC: D6100075 02052168
	v_dual_mul_f32 v116, 0x3b800000, v116 :: v_dual_mul_f32 v183, 0x3b800000, v183// 0000001B2BD4: C8C6E8FF 74B76EFF 3B800000
	v_fma_f32 v182, v21, v69, v45                              // 0000001B2BE0: D61300B6 04B68B15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B2BE8: BF870214
	v_add3_u32 v102, v103, v102, 0x7fff                        // 0000001B2BEC: D6550066 03FECD67 00007FFF
	v_add3_u32 v103, v104, v117, 0x7fff                        // 0000001B2BF8: D6550067 03FEEB68 00007FFF
	v_add3_u32 v104, v105, v180, 0x7fff                        // 0000001B2C04: D6550068 03FF6969 00007FFF
	v_bfe_u32 v105, v116, 16, 1                                // 0000001B2C10: D6100069 02052174
	v_mul_f32_e32 v117, 0x3b800000, v181                       // 0000001B2C18: 10EB6AFF 3B800000
	v_fma_f32 v180, v19, v67, v43                              // 0000001B2C20: D61300B4 04AE8713
	v_fma_f32 v181, v20, v68, v44                              // 0000001B2C28: D61300B5 04B28914
	v_fma_f32 v81, v25, v65, v57                               // 0000001B2C30: D6130051 04E68319
	v_add3_u32 v105, v116, v105, 0x7fff                        // 0000001B2C38: D6550069 03FED374 00007FFF
	v_bfe_u32 v116, v117, 16, 1                                // 0000001B2C44: D6100074 02052175
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001B2C4C: BF870234
	v_dual_mul_f32 v180, 0x3b800000, v180 :: v_dual_mul_f32 v181, 0x3b800000, v181// 0000001B2C50: C8C768FF B4B56AFF 3B800000
	v_fma_f32 v65, v1, v65, v33                                // 0000001B2C5C: D6130041 04868301
	v_mul_f32_e32 v182, 0x3b800000, v182                       // 0000001B2C64: 116D6CFF 3B800000
	v_add3_u32 v116, v117, v116, 0x7fff                        // 0000001B2C6C: D6550074 03FEE975 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B2C78: BF870004
	v_bfe_u32 v117, v180, 16, 1                                // 0000001B2C7C: D6100075 020521B4
	v_bfe_u32 v184, v181, 16, 1                                // 0000001B2C84: D61000B8 020521B5
	v_fma_f32 v186, v23, v71, v47                              // 0000001B2C8C: D61300BA 04BE8F17
	v_mul_f32_e32 v65, 0x3b800000, v65                         // 0000001B2C94: 108282FF 3B800000
	v_bfe_u32 v185, v182, 16, 1                                // 0000001B2C9C: D61000B9 020521B6
	v_fma_f32 v83, v27, v67, v59                               // 0000001B2CA4: D6130053 04EE871B
	v_add3_u32 v117, v180, v117, 0x7fff                        // 0000001B2CAC: D6550075 03FEEBB4 00007FFF
	v_add3_u32 v180, v181, v184, 0x7fff                        // 0000001B2CB8: D65500B4 03FF71B5 00007FFF
	v_fma_f32 v67, v3, v67, v35                                // 0000001B2CC4: D6130043 048E8703
	v_add3_u32 v181, v182, v185, 0x7fff                        // 0000001B2CCC: D65500B5 03FF73B6 00007FFF
	v_bfe_u32 v182, v183, 16, 1                                // 0000001B2CD8: D61000B6 020521B7
	v_mul_f32_e32 v184, 0x3b800000, v186                       // 0000001B2CE0: 117174FF 3B800000
	v_fma_f32 v185, v24, v72, v48                              // 0000001B2CE8: D61300B9 04C29118
	v_fma_f32 v82, v26, v66, v58                               // 0000001B2CF0: D6130052 04EA851A
	v_fma_f32 v66, v2, v66, v34                                // 0000001B2CF8: D6130042 048A8502
	v_mul_f32_e32 v81, 0x3b800000, v81                         // 0000001B2D00: 10A2A2FF 3B800000
	v_add3_u32 v182, v183, v182, 0x7fff                        // 0000001B2D08: D65500B6 03FF6DB7 00007FFF
	v_mul_f32_e32 v185, 0x3b800000, v185                       // 0000001B2D14: 117372FF 3B800000
	v_mul_f32_e32 v67, 0x3b800000, v67                         // 0000001B2D1C: 108686FF 3B800000
	v_bfe_u32 v183, v184, 16, 1                                // 0000001B2D24: D61000B7 020521B8
	v_mul_f32_e32 v82, 0x3b800000, v82                         // 0000001B2D2C: 10A4A4FF 3B800000
	v_fma_f32 v85, v29, v69, v61                               // 0000001B2D34: D6130055 04F68B1D
	v_fma_f32 v69, v5, v69, v37                                // 0000001B2D3C: D6130045 04968B05
	v_mul_f32_e32 v66, 0x3b800000, v66                         // 0000001B2D44: 108484FF 3B800000
	v_fma_f32 v84, v28, v68, v60                               // 0000001B2D4C: D6130054 04F2891C
	v_fma_f32 v87, v31, v71, v63                               // 0000001B2D54: D6130057 04FE8F1F
	s_waitcnt vmcnt(0)                                         // 0000001B2D5C: BF8903F7
	v_bfe_u32 v89, v81, 16, 1                                  // 0000001B2D60: D6100059 02052151
	v_add3_u32 v183, v184, v183, 0x7fff                        // 0000001B2D68: D65500B7 03FF6FB8 00007FFF
	v_bfe_u32 v184, v185, 16, 1                                // 0000001B2D74: D61000B8 020521B9
	v_fma_f32 v68, v4, v68, v36                                // 0000001B2D7C: D6130044 04928904
	v_fma_f32 v86, v30, v70, v62                               // 0000001B2D84: D6130056 04FA8D1E
	v_bfe_u32 v90, v82, 16, 1                                  // 0000001B2D8C: D610005A 02052152
	v_bfe_u32 v186, v65, 16, 1                                 // 0000001B2D94: D61000BA 02052141
	v_bfe_u32 v187, v66, 16, 1                                 // 0000001B2D9C: D61000BB 02052142
	v_fma_f32 v88, v32, v72, v64                               // 0000001B2DA4: D6130058 05029120
	v_dual_mul_f32 v83, 0x3b800000, v83 :: v_dual_mul_f32 v84, 0x3b800000, v84// 0000001B2DAC: C8C6A6FF 5354A8FF 3B800000
	v_mul_f32_e32 v87, 0x3b800000, v87                         // 0000001B2DB8: 10AEAEFF 3B800000
	v_add3_u32 v89, v81, v89, 0x7fff                           // 0000001B2DC0: D6550059 03FEB351 00007FFF
	v_add3_u32 v184, v185, v184, 0x7fff                        // 0000001B2DCC: D65500B8 03FF71B9 00007FFF
	v_bfe_u32 v185, v67, 16, 1                                 // 0000001B2DD8: D61000B9 02052143
	v_fma_f32 v70, v6, v70, v38                                // 0000001B2DE0: D6130046 049A8D06
	v_dual_mul_f32 v68, 0x3b800000, v68 :: v_dual_mul_f32 v85, 0x3b800000, v85// 0000001B2DE8: C8C688FF 4454AAFF 3B800000
	v_mul_f32_e32 v86, 0x3b800000, v86                         // 0000001B2DF4: 10ACACFF 3B800000
	v_add3_u32 v90, v82, v90, 0x7fff                           // 0000001B2DFC: D655005A 03FEB552 00007FFF
	v_add3_u32 v65, v65, v186, 0x7fff                          // 0000001B2E08: D6550041 03FF7541 00007FFF
	v_add3_u32 v66, v66, v187, 0x7fff                          // 0000001B2E14: D6550042 03FF7742 00007FFF
	v_mul_f32_e32 v88, 0x3b800000, v88                         // 0000001B2E20: 10B0B0FF 3B800000
	v_bfe_u32 v91, v83, 16, 1                                  // 0000001B2E28: D610005B 02052153
	v_bfe_u32 v95, v87, 16, 1                                  // 0000001B2E30: D610005F 02052157
	s_clause 0x7                                               // 0000001B2E38: BF850007
	global_store_d16_hi_b16 v[73:74], v89, off                 // 0000001B2E3C: DC960000 007C5949
	global_store_d16_hi_b16 v[73:74], v96, off offset:32       // 0000001B2E44: DC960020 007C6049
	global_store_d16_hi_b16 v[73:74], v105, off offset:64      // 0000001B2E4C: DC960040 007C6949
	global_store_d16_hi_b16 v[75:76], v90, off                 // 0000001B2E54: DC960000 007C5A4B
	global_store_d16_hi_b16 v[75:76], v97, off offset:32       // 0000001B2E5C: DC960020 007C614B
	global_store_d16_hi_b16 v[75:76], v116, off offset:64      // 0000001B2E64: DC960040 007C744B
	global_store_d16_hi_b16 v[73:74], v65, off offset:96       // 0000001B2E6C: DC960060 007C4149
	global_store_d16_hi_b16 v[75:76], v66, off offset:96       // 0000001B2E74: DC960060 007C424B
	v_add3_u32 v65, v67, v185, 0x7fff                          // 0000001B2E7C: D6550041 03FF7343 00007FFF
	v_mul_f32_e32 v67, 0x3b800000, v69                         // 0000001B2E88: 10868AFF 3B800000
	v_mul_f32_e32 v69, 0x3b800000, v70                         // 0000001B2E90: 108A8CFF 3B800000
	v_bfe_u32 v66, v68, 16, 1                                  // 0000001B2E98: D6100042 02052144
	v_fma_f32 v70, v7, v71, v39                                // 0000001B2EA0: D6130046 049E8F07
	v_fma_f32 v71, v8, v72, v40                                // 0000001B2EA8: D6130047 04A29108
	v_bfe_u32 v93, v85, 16, 1                                  // 0000001B2EB0: D610005D 02052155
	v_bfe_u32 v94, v86, 16, 1                                  // 0000001B2EB8: D610005E 02052156
	v_bfe_u32 v92, v84, 16, 1                                  // 0000001B2EC0: D610005C 02052154
	v_add3_u32 v91, v83, v91, 0x7fff                           // 0000001B2EC8: D655005B 03FEB753 00007FFF
	v_add3_u32 v95, v87, v95, 0x7fff                           // 0000001B2ED4: D655005F 03FEBF57 00007FFF
	v_bfe_u32 v87, v88, 16, 1                                  // 0000001B2EE0: D6100057 02052158
	v_add3_u32 v66, v68, v66, 0x7fff                           // 0000001B2EE8: D6550042 03FE8544 00007FFF
	v_bfe_u32 v68, v67, 16, 1                                  // 0000001B2EF4: D6100044 02052143
	v_dual_mul_f32 v70, 0x3b800000, v70 :: v_dual_mul_f32 v71, 0x3b800000, v71// 0000001B2EFC: C8C68CFF 46468EFF 3B800000
	v_add3_u32 v93, v85, v93, 0x7fff                           // 0000001B2F08: D655005D 03FEBB55 00007FFF
	v_mad_u64_u32 v[81:82], null, 0x3000, v176, v[108:109]     // 0000001B2F14: D6FE7C51 05B360FF 00003000
	v_add3_u32 v94, v86, v94, 0x7fff                           // 0000001B2F20: D655005E 03FEBD56 00007FFF
	v_mad_u64_u32 v[85:86], null, 0x3000, v174, v[108:109]     // 0000001B2F2C: D6FE7C55 05B35CFF 00003000
	v_add3_u32 v92, v84, v92, 0x7fff                           // 0000001B2F38: D655005C 03FEB954 00007FFF
	v_bfe_u32 v72, v69, 16, 1                                  // 0000001B2F44: D6100048 02052145
	v_mad_u64_u32 v[83:84], null, 0x3000, v175, v[108:109]     // 0000001B2F4C: D6FE7C53 05B35EFF 00003000
	v_add3_u32 v99, v88, v87, 0x7fff                           // 0000001B2F58: D6550063 03FEAF58 00007FFF
	v_mad_u64_u32 v[87:88], null, 0x3000, v173, v[108:109]     // 0000001B2F64: D6FE7C57 05B35AFF 00003000
	s_clause 0x7                                               // 0000001B2F70: BF850007
	global_store_d16_hi_b16 v[77:78], v91, off                 // 0000001B2F74: DC960000 007C5B4D
	global_store_d16_hi_b16 v[77:78], v98, off offset:32       // 0000001B2F7C: DC960020 007C624D
	global_store_d16_hi_b16 v[77:78], v117, off offset:64      // 0000001B2F84: DC960040 007C754D
	global_store_d16_hi_b16 v[79:80], v92, off                 // 0000001B2F8C: DC960000 007C5C4F
	global_store_d16_hi_b16 v[79:80], v100, off offset:32      // 0000001B2F94: DC960020 007C644F
	global_store_d16_hi_b16 v[79:80], v180, off offset:64      // 0000001B2F9C: DC960040 007CB44F
	global_store_d16_hi_b16 v[77:78], v65, off offset:96       // 0000001B2FA4: DC960060 007C414D
	global_store_d16_hi_b16 v[79:80], v66, off offset:96       // 0000001B2FAC: DC960060 007C424F
	v_add3_u32 v65, v67, v68, 0x7fff                           // 0000001B2FB4: D6550041 03FE8943 00007FFF
	v_bfe_u32 v67, v70, 16, 1                                  // 0000001B2FC0: D6100043 02052146
	v_bfe_u32 v68, v71, 16, 1                                  // 0000001B2FC8: D6100044 02052147
	v_add3_u32 v66, v69, v72, 0x7fff                           // 0000001B2FD0: D6550042 03FE9145 00007FFF
	s_clause 0x7                                               // 0000001B2FDC: BF850007
	global_store_d16_hi_b16 v[81:82], v93, off                 // 0000001B2FE0: DC960000 007C5D51
	global_store_d16_hi_b16 v[81:82], v101, off offset:32      // 0000001B2FE8: DC960020 007C6551
	global_store_d16_hi_b16 v[81:82], v181, off offset:64      // 0000001B2FF0: DC960040 007CB551
	global_store_d16_hi_b16 v[83:84], v94, off                 // 0000001B2FF8: DC960000 007C5E53
	global_store_d16_hi_b16 v[83:84], v102, off offset:32      // 0000001B3000: DC960020 007C6653
	global_store_d16_hi_b16 v[83:84], v182, off offset:64      // 0000001B3008: DC960040 007CB653
	global_store_d16_hi_b16 v[81:82], v65, off offset:96       // 0000001B3010: DC960060 007C4151
	global_store_d16_hi_b16 v[83:84], v66, off offset:96       // 0000001B3018: DC960060 007C4253
	v_add3_u32 v65, v70, v67, 0x7fff                           // 0000001B3020: D6550041 03FE8746 00007FFF
	v_add3_u32 v66, v71, v68, 0x7fff                           // 0000001B302C: D6550042 03FE8947 00007FFF
	s_clause 0x7                                               // 0000001B3038: BF850007
	global_store_d16_hi_b16 v[85:86], v95, off                 // 0000001B303C: DC960000 007C5F55
	global_store_d16_hi_b16 v[85:86], v103, off offset:32      // 0000001B3044: DC960020 007C6755
	global_store_d16_hi_b16 v[85:86], v183, off offset:64      // 0000001B304C: DC960040 007CB755
	global_store_d16_hi_b16 v[87:88], v99, off                 // 0000001B3054: DC960000 007C6357
	global_store_d16_hi_b16 v[87:88], v104, off offset:32      // 0000001B305C: DC960020 007C6857
	global_store_d16_hi_b16 v[87:88], v184, off offset:64      // 0000001B3064: DC960040 007CB857
	global_store_d16_hi_b16 v[85:86], v65, off offset:96       // 0000001B306C: DC960060 007C4155
	global_store_d16_hi_b16 v[87:88], v66, off offset:96       // 0000001B3074: DC960060 007C4257
	s_and_not1_b32 vcc_lo, exec_lo, s14                        // 0000001B307C: 916A0E7E
	s_cbranch_vccnz 114                                        // 0000001B3080: BFA40072 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x684c>
	s_and_saveexec_b32 s14, s10                                // 0000001B3084: BE8E200A
	s_cbranch_execnz 898                                       // 0000001B3088: BFA60382 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7494>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B308C: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001B3090: BE8E200D
	s_cbranch_execnz 917                                       // 0000001B3094: BFA60395 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x74ec>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3098: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001B309C: BE8E200C
	s_cbranch_execnz 936                                       // 0000001B30A0: BFA603A8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7544>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B30A4: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001B30A8: BE8E200B
	s_cbranch_execnz 955                                       // 0000001B30AC: BFA603BB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x759c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B30B0: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001B30B4: BE8E2009
	s_cbranch_execnz 974                                       // 0000001B30B8: BFA603CE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x75f4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B30BC: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001B30C0: BE8E2001
	s_cbranch_execnz 993                                       // 0000001B30C4: BFA603E1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x764c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B30C8: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001B30CC: BE8E2008
	s_cbranch_execnz 1012                                      // 0000001B30D0: BFA603F4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x76a4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B30D4: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001B30D8: BE8E2000
	s_cbranch_execnz 1031                                      // 0000001B30DC: BFA60407 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x76fc>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B30E0: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001B30E4: BE8E200A
	s_cbranch_execnz 1050                                      // 0000001B30E8: BFA6041A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7754>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B30EC: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001B30F0: BE8E200D
	s_cbranch_execnz 1069                                      // 0000001B30F4: BFA6042D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x77ac>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B30F8: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001B30FC: BE8E200C
	s_cbranch_execnz 1088                                      // 0000001B3100: BFA60440 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7804>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3104: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001B3108: BE8E200B
	s_cbranch_execnz 1107                                      // 0000001B310C: BFA60453 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x785c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3110: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001B3114: BE8E2009
	s_cbranch_execnz 1126                                      // 0000001B3118: BFA60466 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x78b4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B311C: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001B3120: BE8E2001
	s_cbranch_execnz 1145                                      // 0000001B3124: BFA60479 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x790c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3128: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001B312C: BE8E2008
	s_cbranch_execnz 1164                                      // 0000001B3130: BFA6048C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7964>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3134: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001B3138: BE8E2000
	s_cbranch_execnz 1183                                      // 0000001B313C: BFA6049F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x79bc>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3140: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001B3144: BE8E200A
	s_cbranch_execnz 1202                                      // 0000001B3148: BFA604B2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7a14>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B314C: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001B3150: BE8E200D
	s_cbranch_execnz 1221                                      // 0000001B3154: BFA604C5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7a6c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3158: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001B315C: BE8E200C
	s_cbranch_execnz 1240                                      // 0000001B3160: BFA604D8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7ac4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3164: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001B3168: BE8E200B
	s_cbranch_execnz 1259                                      // 0000001B316C: BFA604EB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7b1c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3170: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001B3174: BE8E2009
	s_cbranch_execnz 1278                                      // 0000001B3178: BFA604FE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7b74>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B317C: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001B3180: BE8E2001
	s_cbranch_execnz 1297                                      // 0000001B3184: BFA60511 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7bcc>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3188: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001B318C: BE8E2008
	s_cbranch_execnz 1316                                      // 0000001B3190: BFA60524 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7c24>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3194: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001B3198: BE8E2000
	s_cbranch_execnz 1335                                      // 0000001B319C: BFA60537 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7c7c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B31A0: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001B31A4: BE8E200A
	s_cbranch_execnz 1354                                      // 0000001B31A8: BFA6054A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7cd4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B31AC: 8C7E0E7E
	s_and_saveexec_b32 s10, s13                                // 0000001B31B0: BE8A200D
	s_cbranch_execnz 1373                                      // 0000001B31B4: BFA6055D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7d2c>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001B31B8: 8C7E0A7E
	s_and_saveexec_b32 s10, s12                                // 0000001B31BC: BE8A200C
	s_cbranch_execnz 1392                                      // 0000001B31C0: BFA60570 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7d84>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001B31C4: 8C7E0A7E
	s_and_saveexec_b32 s10, s11                                // 0000001B31C8: BE8A200B
	s_cbranch_execnz 1411                                      // 0000001B31CC: BFA60583 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7ddc>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001B31D0: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 0000001B31D4: BE8A2009
	s_cbranch_execnz 1430                                      // 0000001B31D8: BFA60596 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7e34>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001B31DC: 8C7E0A7E
	s_and_saveexec_b32 s9, s1                                  // 0000001B31E0: BE892001
	s_cbranch_execnz 1449                                      // 0000001B31E4: BFA605A9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7e8c>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000001B31E8: 8C7E097E
	s_and_saveexec_b32 s1, s8                                  // 0000001B31EC: BE812008
	s_cbranch_execnz 1468                                      // 0000001B31F0: BFA605BC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7ee4>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001B31F4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000001B31F8: BE812000
	s_cbranch_execz 18                                         // 0000001B31FC: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6848>
	ds_load_b32 v1, v139 offset:56                             // 0000001B3200: D8D80038 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B3208: BF89FC07
	v_fmac_f32_e32 v40, v8, v1                                 // 0000001B320C: 56500308
	v_mad_u64_u32 v[1:2], null, 0x3000, v173, v[108:109]       // 0000001B3210: D6FE7C01 05B35AFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B321C: BF870092
	v_mul_f32_e32 v3, 0x3b800000, v40                          // 0000001B3220: 100650FF 3B800000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001B3228: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B3230: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001B3234: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001B3240: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001B3248: 8C7E017E
	s_mul_f32 s0, s28, 0x3fb8aa3b                              // 0000001B324C: A200FF1C 3FB8AA3B
	s_waitcnt lgkmcnt(0)                                       // 0000001B3254: BF89FC07
	s_barrier                                                  // 0000001B3258: BFBD0000
	ds_load_b128 v[1:4], v131                                  // 0000001B325C: DBFC0000 01000083
	ds_load_b128 v[5:8], v131 offset:16                        // 0000001B3264: DBFC0010 05000083
	ds_load_b128 v[41:44], v132                                // 0000001B326C: DBFC0000 29000084
	ds_load_b128 v[45:48], v132 offset:16                      // 0000001B3274: DBFC0010 2D000084
	s_xor_b32 s1, s0, 0x80000000                               // 0000001B327C: 8D01FF00 80000000
	s_rndne_f32 s8, s0                                         // 0000001B3284: BE886300
	s_fmamk_f32 s1, s28, 0x3fb8aa3b, s1                        // 0000001B3288: A301011C 3FB8AA3B
	ds_load_b128 v[17:20], v131 offset:32                      // 0000001B3290: DBFC0020 11000083
	ds_load_b128 v[21:24], v131 offset:48                      // 0000001B3298: DBFC0030 15000083
	ds_load_b128 v[49:52], v132 offset:32                      // 0000001B32A0: DBFC0020 31000084
	ds_load_b128 v[53:56], v132 offset:48                      // 0000001B32A8: DBFC0030 35000084
	ds_load_b128 v[13:16], v131 offset:80                      // 0000001B32B0: DBFC0050 0D000083
	ds_load_b128 v[9:12], v131 offset:64                       // 0000001B32B8: DBFC0040 09000083
	s_sub_f32 s0, s0, s8                                       // 0000001B32C0: A0800800
	s_fmamk_f32 s1, s28, 0x32a5705f, s1                        // 0000001B32C4: A301011C 32A5705F
	ds_load_b128 v[61:64], v132 offset:80                      // 0000001B32CC: DBFC0050 3D000084
	ds_load_b128 v[57:60], v132 offset:64                      // 0000001B32D4: DBFC0040 39000084
	ds_load_b128 v[29:32], v131 offset:112                     // 0000001B32DC: DBFC0070 1D000083
	ds_load_b128 v[25:28], v131 offset:96                      // 0000001B32E4: DBFC0060 19000083
	v_dual_mov_b32 v33, s36 :: v_dual_mov_b32 v34, s37         // 0000001B32EC: CA100024 21220025
	s_add_f32 s0, s0, s1                                       // 0000001B32F4: A0000100
	v_dual_mov_b32 v35, s38 :: v_dual_mov_b32 v36, s39         // 0000001B32F8: CA100026 23240027
	v_dual_mov_b32 v37, s40 :: v_dual_mov_b32 v38, s41         // 0000001B3300: CA100028 25260029
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B3308: BF870009
	v_exp_f32_e32 v83, s0                                      // 0000001B330C: 7EA64A00
	v_dual_mov_b32 v39, s42 :: v_dual_mov_b32 v40, s43         // 0000001B3310: CA10002A 2728002B
	ds_load_b128 v[69:72], v132 offset:112                     // 0000001B3318: DBFC0070 45000084
	ds_load_b128 v[65:68], v132 offset:96                      // 0000001B3320: DBFC0060 41000084
	ds_load_2addr_b32 v[81:82], v133 offset1:2                 // 0000001B3328: D8DC0200 51000085
	s_cvt_i32_f32 s0, s8                                       // 0000001B3330: BE806608
	s_cmp_nlt_f32 s28, 0xc2ce8ed0                              // 0000001B3334: BF4EFF1C C2CE8ED0
	ds_load_2addr_b32 v[85:86], v133 offset0:8 offset1:10      // 0000001B333C: D8DC0A08 55000085
	s_waitcnt lgkmcnt(14)                                      // 0000001B3344: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[73:80], v[41:48], v[1:8], v[33:40]// 0000001B3348: CC404049 1C860329
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B3350: 986A80C1
	.long 0xd71c0029                                           // 0000001B3354: D71C0029
	v_cndmask_b32_e32 v0, v83, v0, vcc_lo                      // 0000001B3358: 02000153
	ds_load_2addr_b32 v[83:84], v133 offset0:4 offset1:6       // 0000001B335C: D8DC0604 53000085
	s_waitcnt lgkmcnt(11)                                      // 0000001B3364: BF89FCB7
	v_wmma_f32_16x16x16_f16 v[73:80], v[49:56], v[17:24], v[73:80]// 0000001B3368: CC404049 1D262331
	s_cmp_ngt_f32 s28, 0x42b17218                              // 0000001B3370: BF4BFF1C 42B17218
	ds_load_b128 v[42:45], v132 offset:2304                    // 0000001B3378: DBFC0900 2A000084
	ds_load_b128 v[46:49], v132 offset:2320                    // 0000001B3380: DBFC0910 2E000084
	s_waitcnt vmcnt(0)                                         // 0000001B3388: BF8903F7
	ds_load_2addr_b32 v[89:90], v133 offset0:12 offset1:14     // 0000001B338C: D8DC0E0C 59000085
	s_waitcnt lgkmcnt(10)                                      // 0000001B3394: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[73:80], v[57:64], v[9:16], v[73:80]// 0000001B3398: CC404049 1D261339
	ds_load_b128 v[50:53], v132 offset:2336                    // 0000001B33A0: DBFC0920 32000084
	ds_load_b128 v[54:57], v132 offset:2352                    // 0000001B33A8: DBFC0930 36000084
	s_waitcnt lgkmcnt(8)                                       // 0000001B33B0: BF89FC87
	v_wmma_f32_16x16x16_f16 v[73:80], v[65:72], v[25:32], v[73:80]// 0000001B33B4: CC404049 1D263341
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000001B33BC: 02525280
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B33C0: 986A80C1
	ds_load_b128 v[62:65], v132 offset:2384                    // 0000001B33C4: DBFC0950 3E000084
	ds_load_b128 v[58:61], v132 offset:2368                    // 0000001B33CC: DBFC0940 3A000084
	s_cmp_lg_u32 s23, s44                                      // 0000001B33D4: BF072C17
	v_cndmask_b32_e32 v41, 0x7f800000, v41, vcc_lo             // 0000001B33D8: 025252FF 7F800000
	s_waitcnt lgkmcnt(7)                                       // 0000001B33E0: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B33E4: BF870091
	v_mul_f32_e32 v94, v41, v84                                // 0000001B33E8: 10BCA929
	v_dual_mul_f32 v91, v41, v81 :: v_dual_fmac_f32 v94, 0x3b800000, v76// 0000001B33EC: C8C0A329 5B5E98FF 3B800000
	v_mul_f32_e32 v76, v41, v86                                // 0000001B33F8: 1098AD29
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001B33FC: BF870002
	v_dual_mul_f32 v92, v41, v82 :: v_dual_fmac_f32 v91, 0x3b800000, v73// 0000001B3400: C8C0A529 5C5A92FF 3B800000
	v_mul_f32_e32 v93, v41, v83                                // 0000001B340C: 10BAA729
	ds_load_b128 v[70:73], v132 offset:2416                    // 0000001B3410: DBFC0970 46000084
	ds_load_b128 v[66:69], v132 offset:2400                    // 0000001B3418: DBFC0960 42000084
	v_fmac_f32_e32 v76, 0x3b800000, v78                        // 0000001B3420: 56989CFF 3B800000
	s_waitcnt lgkmcnt(6)                                       // 0000001B3428: BF89FC67
	v_mul_f32_e32 v78, v41, v89                                // 0000001B342C: 109CB329
	v_dual_mul_f32 v95, v41, v85 :: v_dual_fmac_f32 v92, 0x3b800000, v74// 0000001B3430: C8C0AB29 5F5C94FF 3B800000
	v_fmac_f32_e32 v93, 0x3b800000, v75                        // 0000001B343C: 56BA96FF 3B800000
	ds_load_2addr_b32 v[74:75], v133 offset0:16 offset1:18     // 0000001B3444: D8DC1210 4A000085
	v_dual_fmac_f32 v78, 0x3b800000, v79 :: v_dual_fmac_f32 v95, 0x3b800000, v77// 0000001B344C: C8009EFF 4E5E9AFF 3B800000
	v_wmma_f32_16x16x16_f16 v[81:88], v[42:49], v[1:8], v[33:40]// 0000001B3458: CC404051 1C86032A
	ds_store_2addr_b32 v133, v91, v92 offset1:2                // 0000001B3460: D8380200 005C5B85
	ds_store_2addr_b32 v133, v93, v94 offset0:4 offset1:6      // 0000001B3468: D8380604 005E5D85
	ds_load_2addr_b32 v[91:92], v133 offset0:28 offset1:30     // 0000001B3470: D8DC1E1C 5B000085
	ds_store_2addr_b32 v133, v95, v76 offset0:8 offset1:10     // 0000001B3478: D8380A08 004C5F85
	ds_load_2addr_b32 v[76:77], v133 offset0:20 offset1:22     // 0000001B3480: D8DC1614 4C000085
	s_waitcnt lgkmcnt(10)                                      // 0000001B3488: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[81:88], v[50:57], v[17:24], v[81:88]// 0000001B348C: CC404051 1D462332
	ds_load_b128 v[50:53], v132 offset:4640                    // 0000001B3494: DBFC1220 32000084
	ds_load_b128 v[54:57], v132 offset:4656                    // 0000001B349C: DBFC1230 36000084
	s_waitcnt lgkmcnt(10)                                      // 0000001B34A4: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[81:88], v[58:65], v[9:16], v[81:88]// 0000001B34A8: CC404051 1D46133A
	ds_load_b128 v[62:65], v132 offset:4688                    // 0000001B34B0: DBFC1250 3E000084
	ds_load_b128 v[58:61], v132 offset:4672                    // 0000001B34B8: DBFC1240 3A000084
	s_waitcnt lgkmcnt(10)                                      // 0000001B34C0: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[81:88], v[66:73], v[25:32], v[81:88]// 0000001B34C4: CC404051 1D463342
	s_waitcnt lgkmcnt(9)                                       // 0000001B34CC: BF89FC97
	v_mul_f32_e32 v95, v41, v74                                // 0000001B34D0: 10BE9529
	v_mul_f32_e32 v96, v41, v75                                // 0000001B34D4: 10C09729
	ds_load_b128 v[70:73], v132 offset:4720                    // 0000001B34D8: DBFC1270 46000084
	ds_load_b128 v[66:69], v132 offset:4704                    // 0000001B34E0: DBFC1260 42000084
	ds_load_2addr_b32 v[93:94], v133 offset0:32 offset1:34     // 0000001B34E8: D8DC2220 5D000085
	v_dual_fmac_f32 v95, 0x3b800000, v81 :: v_dual_fmac_f32 v96, 0x3b800000, v82// 0000001B34F0: C800A2FF 5F60A4FF 3B800000
	s_waitcnt lgkmcnt(7)                                       // 0000001B34FC: BF89FC77
	v_mul_f32_e32 v97, v41, v76                                // 0000001B3500: 10C29929
	v_mul_f32_e32 v98, v41, v77                                // 0000001B3504: 10C49B29
	ds_store_2addr_b32 v133, v95, v96 offset0:16 offset1:18    // 0000001B3508: D8381210 00605F85
	v_fmac_f32_e32 v97, 0x3b800000, v83                        // 0000001B3510: 56C2A6FF 3B800000
	v_dual_mul_f32 v79, v41, v90 :: v_dual_fmac_f32 v98, 0x3b800000, v84// 0000001B3518: C8C0B529 4F62A8FF 3B800000
	ds_load_b128 v[42:45], v132 offset:4608                    // 0000001B3524: DBFC1200 2A000084
	ds_load_b128 v[46:49], v132 offset:4624                    // 0000001B352C: DBFC1210 2E000084
	ds_load_2addr_b32 v[89:90], v133 offset0:24 offset1:26     // 0000001B3534: D8DC1A18 59000085
	ds_load_2addr_b32 v[82:83], v133 offset0:36 offset1:38     // 0000001B353C: D8DC2624 52000085
	v_dual_mul_f32 v84, v41, v91 :: v_dual_fmac_f32 v79, 0x3b800000, v80// 0000001B3544: C8C0B729 544EA0FF 3B800000
	ds_store_2addr_b32 v133, v97, v98 offset0:20 offset1:22    // 0000001B3550: D8381614 00626185
	v_fmac_f32_e32 v84, 0x3b800000, v87                        // 0000001B3558: 56A8AEFF 3B800000
	ds_store_2addr_b32 v133, v78, v79 offset0:12 offset1:14    // 0000001B3560: D8380E0C 004F4E85
	s_waitcnt lgkmcnt(4)                                       // 0000001B3568: BF89FC47
	v_wmma_f32_16x16x16_f16 v[74:81], v[42:49], v[1:8], v[33:40]// 0000001B356C: CC40404A 1C86032A
	s_waitcnt lgkmcnt(3)                                       // 0000001B3574: BF89FC37
	v_mul_f32_e32 v43, v41, v90                                // 0000001B3578: 1056B529
	v_mul_f32_e32 v42, v41, v89                                // 0000001B357C: 1054B329
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B3580: BF870003
	v_wmma_f32_16x16x16_f16 v[74:81], v[50:57], v[17:24], v[74:81]// 0000001B3584: CC40404A 1D2A2332
	ds_load_2addr_b32 v[90:91], v133 offset0:40 offset1:42     // 0000001B358C: D8DC2A28 5A000085
	ds_load_b128 v[50:53], v132 offset:6944                    // 0000001B3594: DBFC1B20 32000084
	ds_load_b128 v[54:57], v132 offset:6960                    // 0000001B359C: DBFC1B30 36000084
	v_dual_fmac_f32 v43, 0x3b800000, v86 :: v_dual_fmac_f32 v42, 0x3b800000, v85// 0000001B35A4: C800ACFF 2B2AAAFF 3B800000
	v_wmma_f32_16x16x16_f16 v[74:81], v[58:65], v[9:16], v[74:81]// 0000001B35B0: CC40404A 1D2A133A
	ds_load_b128 v[62:65], v132 offset:6992                    // 0000001B35B8: DBFC1B50 3E000084
	ds_load_b128 v[58:61], v132 offset:6976                    // 0000001B35C0: DBFC1B40 3A000084
	ds_store_2addr_b32 v133, v42, v43 offset0:24 offset1:26    // 0000001B35C8: D8381A18 002B2A85
	ds_load_b128 v[42:45], v132 offset:6912                    // 0000001B35D0: DBFC1B00 2A000084
	ds_load_b128 v[46:49], v132 offset:6928                    // 0000001B35D8: DBFC1B10 2E000084
	v_wmma_f32_16x16x16_f16 v[74:81], v[66:73], v[25:32], v[74:81]// 0000001B35E0: CC40404A 1D2A3342
	s_waitcnt lgkmcnt(10)                                      // 0000001B35E8: BF89FCA7
	v_mul_f32_e32 v97, v41, v83                                // 0000001B35EC: 10C2A729
	v_mul_f32_e32 v94, v41, v94                                // 0000001B35F0: 10BCBD29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B35F4: BF870112
	v_dual_mul_f32 v96, v41, v82 :: v_dual_fmac_f32 v97, 0x3b800000, v77// 0000001B35F8: C8C0A529 60609AFF 3B800000
	v_dual_mul_f32 v85, v41, v92 :: v_dual_fmac_f32 v94, 0x3b800000, v75// 0000001B3604: C8C0B929 555E96FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000001B3610: BF870151
	v_fmac_f32_e32 v85, 0x3b800000, v88                        // 0000001B3614: 56AAB0FF 3B800000
	ds_store_2addr_b32 v133, v84, v85 offset0:28 offset1:30    // 0000001B361C: D8381E1C 00555485
	s_waitcnt lgkmcnt(1)                                       // 0000001B3624: BF89FC17
	v_wmma_f32_16x16x16_f16 v[82:89], v[42:49], v[1:8], v[33:40]// 0000001B3628: CC404052 1C86032A
	v_mul_f32_e32 v43, v41, v91                                // 0000001B3630: 1056B729
	v_wmma_f32_16x16x16_f16 v[82:89], v[50:57], v[17:24], v[82:89]// 0000001B3634: CC404052 1D4A2332
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001B363C: BF870002
	v_fmac_f32_e32 v43, 0x3b800000, v79                        // 0000001B3640: 56569EFF 3B800000
	v_dual_mul_f32 v95, v41, v93 :: v_dual_fmac_f32 v96, 0x3b800000, v76// 0000001B3648: C8C0BB29 5F6098FF 3B800000
	ds_load_2addr_b32 v[92:93], v133 offset0:44 offset1:46     // 0000001B3654: D8DC2E2C 5C000085
	ds_load_2addr_b32 v[76:77], v133 offset0:52 offset1:54     // 0000001B365C: D8DC3634 4C000085
	v_wmma_f32_16x16x16_f16 v[82:89], v[58:65], v[9:16], v[82:89]// 0000001B3664: CC404052 1D4A133A
	v_fmac_f32_e32 v95, 0x3b800000, v74                        // 0000001B366C: 56BE94FF 3B800000
	ds_load_b128 v[70:73], v132 offset:7024                    // 0000001B3674: DBFC1B70 46000084
	ds_load_b128 v[66:69], v132 offset:7008                    // 0000001B367C: DBFC1B60 42000084
	ds_load_2addr_b32 v[74:75], v133 offset0:48 offset1:50     // 0000001B3684: D8DC3230 4A000085
	ds_load_b128 v[62:65], v132 offset:9296                    // 0000001B368C: DBFC2450 3E000084
	ds_load_b128 v[58:61], v132 offset:9280                    // 0000001B3694: DBFC2440 3A000084
	s_waitcnt lgkmcnt(6)                                       // 0000001B369C: BF89FC67
	v_mul_f32_e32 v44, v41, v92                                // 0000001B36A0: 1058B929
	ds_store_2addr_b32 v133, v95, v94 offset0:32 offset1:34    // 0000001B36A4: D8382220 005E5F85
	ds_store_2addr_b32 v133, v96, v97 offset0:36 offset1:38    // 0000001B36AC: D8382624 00616085
	s_waitcnt lgkmcnt(5)                                       // 0000001B36B4: BF89FC57
	v_wmma_f32_16x16x16_f16 v[82:89], v[66:73], v[25:32], v[82:89]// 0000001B36B8: CC404052 1D4A3342
	s_waitcnt lgkmcnt(4)                                       // 0000001B36C0: BF89FC47
	v_mul_f32_e32 v67, v41, v75                                // 0000001B36C4: 10869729
	v_mul_f32_e32 v66, v41, v74                                // 0000001B36C8: 10849529
	v_mul_f32_e32 v75, v41, v77                                // 0000001B36CC: 10969B29
	v_mul_f32_e32 v74, v41, v76                                // 0000001B36D0: 10949929
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B36D4: BF870112
	v_dual_fmac_f32 v44, 0x3b800000, v80 :: v_dual_fmac_f32 v75, 0x3b800000, v85// 0000001B36D8: C800A0FF 2C4AAAFF 3B800000
	v_dual_fmac_f32 v74, 0x3b800000, v84 :: v_dual_fmac_f32 v67, 0x3b800000, v83// 0000001B36E4: C800A8FF 4A42A6FF 3B800000
	v_dual_mul_f32 v45, v41, v93 :: v_dual_fmac_f32 v66, 0x3b800000, v82// 0000001B36F0: C8C0BB29 2D42A4FF 3B800000
	v_mul_f32_e32 v42, v41, v90                                // 0000001B36FC: 1054B529
	ds_load_2addr_b32 v[92:93], v133 offset0:60 offset1:62     // 0000001B3700: D8DC3E3C 5C000085
	ds_load_b128 v[50:53], v132 offset:9248                    // 0000001B3708: DBFC2420 32000084
	ds_load_b128 v[54:57], v132 offset:9264                    // 0000001B3710: DBFC2430 36000084
	ds_load_2addr_b32 v[90:91], v133 offset0:56 offset1:58     // 0000001B3718: D8DC3A38 5A000085
	v_fmac_f32_e32 v45, 0x3b800000, v81                        // 0000001B3720: 565AA2FF 3B800000
	ds_store_2addr_b32 v133, v66, v67 offset0:48 offset1:50    // 0000001B3728: D8383230 00434285
	v_fmac_f32_e32 v42, 0x3b800000, v78                        // 0000001B3730: 56549CFF 3B800000
	ds_store_2addr_b32 v133, v42, v43 offset0:40 offset1:42    // 0000001B3738: D8382A28 002B2A85
	ds_store_2addr_b32 v133, v44, v45 offset0:44 offset1:46    // 0000001B3740: D8382E2C 002D2C85
	ds_load_b128 v[42:45], v132 offset:9216                    // 0000001B3748: DBFC2400 2A000084
	ds_load_b128 v[46:49], v132 offset:9232                    // 0000001B3750: DBFC2410 2E000084
	ds_load_b128 v[70:73], v132 offset:9328                    // 0000001B3758: DBFC2470 46000084
	ds_load_b128 v[66:69], v132 offset:9312                    // 0000001B3760: DBFC2460 42000084
	ds_load_2addr_b32 v[84:85], v133 offset0:68 offset1:70     // 0000001B3768: D8DC4644 54000085
	ds_store_2addr_b32 v133, v74, v75 offset0:52 offset1:54    // 0000001B3770: D8383634 004B4A85
	ds_load_2addr_b32 v[82:83], v133 offset0:64 offset1:66     // 0000001B3778: D8DC4240 52000085
	s_waitcnt lgkmcnt(10)                                      // 0000001B3780: BF89FCA7
	v_mul_f32_e32 v94, v41, v90                                // 0000001B3784: 10BCB529
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000001B3788: BF870151
	v_fmac_f32_e32 v94, 0x3b800000, v86                        // 0000001B378C: 56BCACFF 3B800000
	s_waitcnt lgkmcnt(5)                                       // 0000001B3794: BF89FC57
	v_wmma_f32_16x16x16_f16 v[74:81], v[42:49], v[1:8], v[33:40]// 0000001B3798: CC40404A 1C86032A
	s_waitcnt lgkmcnt(2)                                       // 0000001B37A0: BF89FC27
	v_mul_f32_e32 v96, v41, v85                                // 0000001B37A4: 10C0AB29
	v_wmma_f32_16x16x16_f16 v[74:81], v[50:57], v[17:24], v[74:81]// 0000001B37A8: CC40404A 1D2A2332
	ds_load_b128 v[50:53], v132 offset:11552                   // 0000001B37B0: DBFC2D20 32000084
	ds_load_b128 v[54:57], v132 offset:11568                   // 0000001B37B8: DBFC2D30 36000084
	v_wmma_f32_16x16x16_f16 v[74:81], v[58:65], v[9:16], v[74:81]// 0000001B37C0: CC40404A 1D2A133A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B37C8: BF8701B1
	v_wmma_f32_16x16x16_f16 v[74:81], v[66:73], v[25:32], v[74:81]// 0000001B37CC: CC40404A 1D2A3342
	v_mul_f32_e32 v86, v41, v91                                // 0000001B37D4: 10ACB729
	v_mul_f32_e32 v91, v41, v92                                // 0000001B37D8: 10B6B929
	v_dual_mul_f32 v95, v41, v84 :: v_dual_fmac_f32 v96, 0x3b800000, v77// 0000001B37DC: C8C0A929 5F609AFF 3B800000
	v_mul_f32_e32 v92, v41, v93                                // 0000001B37E8: 10B8BB29
	s_waitcnt lgkmcnt(2)                                       // 0000001B37EC: BF89FC27
	v_mul_f32_e32 v93, v41, v82                                // 0000001B37F0: 10BAA529
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B37F4: BF870003
	v_fmac_f32_e32 v95, 0x3b800000, v76                        // 0000001B37F8: 56BE98FF 3B800000
	ds_load_2addr_b32 v[76:77], v133 offset0:84 offset1:86     // 0000001B3800: D8DC5654 4C000085
	v_fmac_f32_e32 v92, 0x3b800000, v89                        // 0000001B3808: 56B8B2FF 3B800000
	ds_load_2addr_b32 v[89:90], v133 offset0:72 offset1:74     // 0000001B3810: D8DC4A48 59000085
	ds_load_b128 v[42:45], v132 offset:11520                   // 0000001B3818: DBFC2D00 2A000084
	ds_load_b128 v[46:49], v132 offset:11536                   // 0000001B3820: DBFC2D10 2E000084
	v_dual_fmac_f32 v93, 0x3b800000, v74 :: v_dual_fmac_f32 v86, 0x3b800000, v87// 0000001B3828: C80094FF 5D56AEFF 3B800000
	v_fmac_f32_e32 v91, 0x3b800000, v88                        // 0000001B3834: 56B6B0FF 3B800000
	ds_store_2addr_b32 v133, v94, v86 offset0:56 offset1:58    // 0000001B383C: D8383A38 00565E85
	ds_store_2addr_b32 v133, v91, v92 offset0:60 offset1:62    // 0000001B3844: D8383E3C 005C5B85
	ds_load_2addr_b32 v[91:92], v133 offset0:76 offset1:78     // 0000001B384C: D8DC4E4C 5B000085
	ds_load_b128 v[62:65], v132 offset:11600                   // 0000001B3854: DBFC2D50 3E000084
	ds_load_b128 v[58:61], v132 offset:11584                   // 0000001B385C: DBFC2D40 3A000084
	s_waitcnt lgkmcnt(7)                                       // 0000001B3864: BF89FC77
	v_mul_f32_e32 v97, v41, v89                                // 0000001B3868: 10C2B329
	v_mul_f32_e32 v94, v41, v83                                // 0000001B386C: 10BCA729
	s_waitcnt lgkmcnt(5)                                       // 0000001B3870: BF89FC57
	v_wmma_f32_16x16x16_f16 v[82:89], v[42:49], v[1:8], v[33:40]// 0000001B3874: CC404052 1C86032A
	v_mul_f32_e32 v42, v41, v90                                // 0000001B387C: 1054B529
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B3880: BF8701B2
	v_wmma_f32_16x16x16_f16 v[82:89], v[50:57], v[17:24], v[82:89]// 0000001B3884: CC404052 1D4A2332
	s_waitcnt lgkmcnt(2)                                       // 0000001B388C: BF89FC27
	v_mul_f32_e32 v90, v41, v91                                // 0000001B3890: 10B4B729
	v_dual_fmac_f32 v42, 0x3b800000, v79 :: v_dual_fmac_f32 v97, 0x3b800000, v78// 0000001B3894: C8009EFF 2A609CFF 3B800000
	v_fmac_f32_e32 v94, 0x3b800000, v75                        // 0000001B38A0: 56BC96FF 3B800000
	ds_load_b128 v[70:73], v132 offset:11632                   // 0000001B38A8: DBFC2D70 46000084
	ds_load_b128 v[66:69], v132 offset:11616                   // 0000001B38B0: DBFC2D60 42000084
	ds_load_2addr_b32 v[74:75], v133 offset0:80 offset1:82     // 0000001B38B8: D8DC5250 4A000085
	ds_load_2addr_b32 v[78:79], v133 offset0:88 offset1:90     // 0000001B38C0: D8DC5A58 4E000085
	s_waitcnt lgkmcnt(4)                                       // 0000001B38C8: BF89FC47
	v_wmma_f32_16x16x16_f16 v[82:89], v[58:65], v[9:16], v[82:89]// 0000001B38CC: CC404052 1D4A133A
	ds_store_2addr_b32 v133, v95, v96 offset0:68 offset1:70    // 0000001B38D4: D8384644 00605F85
	ds_store_2addr_b32 v133, v97, v42 offset0:72 offset1:74    // 0000001B38DC: D8384A48 002A6185
	ds_load_b128 v[42:45], v132 offset:13824                   // 0000001B38E4: DBFC3600 2A000084
	ds_load_b128 v[46:49], v132 offset:13840                   // 0000001B38EC: DBFC3610 2E000084
	v_dual_fmac_f32 v90, 0x3b800000, v80 :: v_dual_mul_f32 v95, v41, v77// 0000001B38F4: C806A0FF 5A5E9B29 3B800000
	ds_store_2addr_b32 v133, v93, v94 offset0:64 offset1:66    // 0000001B3900: D8384240 005E5D85
	v_mul_f32_e32 v94, v41, v76                                // 0000001B3908: 10BC9929
	s_waitcnt lgkmcnt(7)                                       // 0000001B390C: BF89FC77
	v_wmma_f32_16x16x16_f16 v[82:89], v[66:73], v[25:32], v[82:89]// 0000001B3910: CC404052 1D4A3342
	s_waitcnt lgkmcnt(6)                                       // 0000001B3918: BF89FC67
	v_mul_f32_e32 v66, v41, v74                                // 0000001B391C: 10849529
	s_waitcnt lgkmcnt(5)                                       // 0000001B3920: BF89FC57
	v_mul_f32_e32 v97, v41, v79                                // 0000001B3924: 10C29F29
	v_mul_f32_e32 v58, v41, v92                                // 0000001B3928: 1074B929
	v_mul_f32_e32 v67, v41, v75                                // 0000001B392C: 10869729
	v_dual_fmac_f32 v95, 0x3b800000, v85 :: v_dual_fmac_f32 v66, 0x3b800000, v82// 0000001B3930: C800AAFF 5F42A4FF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B393C: BF870193
	v_dual_fmac_f32 v97, 0x3b800000, v87 :: v_dual_fmac_f32 v58, 0x3b800000, v81// 0000001B3940: C800AEFF 613AA2FF 3B800000
	v_fmac_f32_e32 v67, 0x3b800000, v83                        // 0000001B394C: 5686A6FF 3B800000
	ds_load_b128 v[50:53], v132 offset:13856                   // 0000001B3954: DBFC3620 32000084
	ds_load_b128 v[54:57], v132 offset:13872                   // 0000001B395C: DBFC3630 36000084
	ds_load_2addr_b32 v[82:83], v133 offset0:92 offset1:94     // 0000001B3964: D8DC5E5C 52000085
	v_mul_f32_e32 v96, v41, v78                                // 0000001B396C: 10C09D29
	s_waitcnt lgkmcnt(4)                                       // 0000001B3970: BF89FC47
	v_wmma_f32_16x16x16_f16 v[74:81], v[42:49], v[1:8], v[33:40]// 0000001B3974: CC40404A 1C86032A
	ds_store_2addr_b32 v133, v90, v58 offset0:76 offset1:78    // 0000001B397C: D8384E4C 003A5A85
	ds_load_b128 v[62:65], v132 offset:13904                   // 0000001B3984: DBFC3650 3E000084
	ds_load_b128 v[58:61], v132 offset:13888                   // 0000001B398C: DBFC3640 3A000084
	ds_store_2addr_b32 v133, v66, v67 offset0:80 offset1:82    // 0000001B3994: D8385250 00434285
	ds_load_b128 v[70:73], v132 offset:13936                   // 0000001B399C: DBFC3670 46000084
	ds_load_b128 v[66:69], v132 offset:13920                   // 0000001B39A4: DBFC3660 42000084
	ds_load_2addr_b32 v[90:91], v133 offset0:96 offset1:98     // 0000001B39AC: D8DC6260 5A000085
	v_fmac_f32_e32 v94, 0x3b800000, v84                        // 0000001B39B4: 56BCA8FF 3B800000
	ds_load_2addr_b32 v[84:85], v133 offset0:100 offset1:102   // 0000001B39BC: D8DC6664 54000085
	ds_load_b128 v[42:45], v132 offset:16128                   // 0000001B39C4: DBFC3F00 2A000084
	ds_load_b128 v[46:49], v132 offset:16144                   // 0000001B39CC: DBFC3F10 2E000084
	v_fmac_f32_e32 v96, 0x3b800000, v86                        // 0000001B39D4: 56C0ACFF 3B800000
	ds_load_2addr_b32 v[92:93], v133 offset0:104 offset1:106   // 0000001B39DC: D8DC6A68 5C000085
	s_waitcnt lgkmcnt(12)                                      // 0000001B39E4: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[74:81], v[50:57], v[17:24], v[74:81]// 0000001B39E8: CC40404A 1D2A2332
	ds_load_b128 v[50:53], v132 offset:16160                   // 0000001B39F0: DBFC3F20 32000084
	ds_load_b128 v[54:57], v132 offset:16176                   // 0000001B39F8: DBFC3F30 36000084
	s_waitcnt lgkmcnt(10)                                      // 0000001B3A00: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[74:81], v[58:65], v[9:16], v[74:81]// 0000001B3A04: CC40404A 1D2A133A
	ds_load_b128 v[62:65], v132 offset:16208                   // 0000001B3A0C: DBFC3F50 3E000084
	ds_load_b128 v[58:61], v132 offset:16192                   // 0000001B3A14: DBFC3F40 3A000084
	s_waitcnt lgkmcnt(8)                                       // 0000001B3A1C: BF89FC87
	v_mul_f32_e32 v99, v41, v91                                // 0000001B3A20: 10C6B729
	s_waitcnt lgkmcnt(7)                                       // 0000001B3A24: BF89FC77
	v_mul_f32_e32 v101, v41, v85                               // 0000001B3A28: 10CAAB29
	ds_store_2addr_b32 v133, v94, v95 offset0:84 offset1:86    // 0000001B3A2C: D8385654 005F5E85
	ds_store_2addr_b32 v133, v96, v97 offset0:88 offset1:90    // 0000001B3A34: D8385A58 00616085
	v_wmma_f32_16x16x16_f16 v[74:81], v[66:73], v[25:32], v[74:81]// 0000001B3A3C: CC40404A 1D2A3342
	v_mul_f32_e32 v97, v41, v90                                // 0000001B3A44: 10C2B529
	v_mul_f32_e32 v98, v41, v82                                // 0000001B3A48: 10C4A529
	v_mul_f32_e32 v96, v41, v83                                // 0000001B3A4C: 10C0A729
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B3A50: BF870214
	v_dual_mul_f32 v100, v41, v84 :: v_dual_fmac_f32 v99, 0x3b800000, v75// 0000001B3A54: C8C0A929 646296FF 3B800000
	v_fmac_f32_e32 v97, 0x3b800000, v74                        // 0000001B3A60: 56C294FF 3B800000
	ds_load_2addr_b32 v[74:75], v133 offset0:108 offset1:110   // 0000001B3A68: D8DC6E6C 4A000085
	ds_load_b128 v[70:73], v132 offset:16240                   // 0000001B3A70: DBFC3F70 46000084
	ds_load_b128 v[66:69], v132 offset:16224                   // 0000001B3A78: DBFC3F60 42000084
	ds_load_2addr_b32 v[90:91], v133 offset0:112 offset1:114   // 0000001B3A80: D8DC7270 5A000085
	ds_load_2addr_b32 v[94:95], v133 offset0:116 offset1:118   // 0000001B3A88: D8DC7674 5E000085
	v_fmac_f32_e32 v98, 0x3b800000, v88                        // 0000001B3A90: 56C4B0FF 3B800000
	v_fmac_f32_e32 v96, 0x3b800000, v89                        // 0000001B3A98: 56C0B2FF 3B800000
	s_waitcnt lgkmcnt(12)                                      // 0000001B3AA0: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[82:89], v[42:49], v[1:8], v[33:40]// 0000001B3AA4: CC404052 1C86032A
	ds_load_2addr_b32 v[1:2], v133 offset0:120 offset1:122     // 0000001B3AAC: D8DC7A78 01000085
	ds_load_2addr_b32 v[3:4], v133 offset0:124 offset1:126     // 0000001B3AB4: D8DC7E7C 03000085
	s_waitcnt lgkmcnt(13)                                      // 0000001B3ABC: BF89FCD7
	v_mul_f32_e32 v92, v41, v92                                // 0000001B3AC0: 10B8B929
	s_waitcnt lgkmcnt(11)                                      // 0000001B3AC4: BF89FCB7
	v_wmma_f32_16x16x16_f16 v[82:89], v[50:57], v[17:24], v[82:89]// 0000001B3AC8: CC404052 1D4A2332
	v_mul_f32_e32 v5, v41, v93                                 // 0000001B3AD0: 100ABB29
	v_fmac_f32_e32 v101, 0x3b800000, v77                       // 0000001B3AD4: 56CA9AFF 3B800000
	s_waitcnt lgkmcnt(9)                                       // 0000001B3ADC: BF89FC97
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B3AE0: BF870193
	v_wmma_f32_16x16x16_f16 v[82:89], v[58:65], v[9:16], v[82:89]// 0000001B3AE4: CC404052 1D4A133A
	v_fmac_f32_e32 v5, 0x3b800000, v79                         // 0000001B3AEC: 560A9EFF 3B800000
	s_waitcnt lgkmcnt(4)                                       // 0000001B3AF4: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000001B3AF8: BF870152
	v_wmma_f32_16x16x16_f16 v[82:89], v[66:73], v[25:32], v[82:89]// 0000001B3AFC: CC404052 1D4A3342
	s_waitcnt lgkmcnt(3)                                       // 0000001B3B04: BF89FC37
	v_mul_f32_e32 v8, v41, v91                                 // 0000001B3B08: 1010B729
	s_waitcnt lgkmcnt(2)                                       // 0000001B3B0C: BF89FC27
	v_mul_f32_e32 v10, v41, v95                                // 0000001B3B10: 1014BF29
	v_dual_mul_f32 v7, v41, v90 :: v_dual_fmac_f32 v8, 0x3b800000, v83// 0000001B3B14: C8C0B529 0708A6FF 3B800000
	s_waitcnt lgkmcnt(1)                                       // 0000001B3B20: BF89FC17
	v_mul_f32_e32 v1, v41, v1                                  // 0000001B3B24: 10020329
	s_waitcnt lgkmcnt(0)                                       // 0000001B3B28: BF89FC07
	v_dual_mul_f32 v3, v41, v3 :: v_dual_fmac_f32 v10, 0x3b800000, v85// 0000001B3B2C: C8C00729 030AAAFF 3B800000
	v_mul_f32_e32 v6, v41, v75                                 // 0000001B3B38: 100C9729
	v_mul_f32_e32 v2, v41, v2                                  // 0000001B3B3C: 10040529
	v_dual_fmac_f32 v1, 0x3b800000, v86 :: v_dual_fmac_f32 v100, 0x3b800000, v76// 0000001B3B40: C800ACFF 016498FF 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B3B4C: BF870214
	v_fmac_f32_e32 v3, 0x3b800000, v88                         // 0000001B3B50: 5606B0FF 3B800000
	v_dual_mul_f32 v9, v41, v94 :: v_dual_fmac_f32 v6, 0x3b800000, v81// 0000001B3B58: C8C0BD29 0906A2FF 3B800000
	v_fmac_f32_e32 v92, 0x3b800000, v78                        // 0000001B3B64: 56B89CFF 3B800000
	v_dual_mul_f32 v4, v41, v4 :: v_dual_fmac_f32 v7, 0x3b800000, v82// 0000001B3B6C: C8C00929 0406A4FF 3B800000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B3B78: BF870003
	v_fmac_f32_e32 v9, 0x3b800000, v84                         // 0000001B3B7C: 5612A8FF 3B800000
	ds_store_2addr_b32 v133, v100, v101 offset0:100 offset1:102// 0000001B3B84: D8386664 00656485
	ds_store_2addr_b32 v133, v92, v5 offset0:104 offset1:106   // 0000001B3B8C: D8386A68 00055C85
	v_dual_mul_f32 v5, v41, v74 :: v_dual_fmac_f32 v2, 0x3b800000, v87// 0000001B3B94: C8C09529 0502AEFF 3B800000
	v_fmac_f32_e32 v4, 0x3b800000, v89                         // 0000001B3BA0: 5608B2FF 3B800000
	ds_store_2addr_b32 v133, v98, v96 offset0:92 offset1:94    // 0000001B3BA8: D8385E5C 00606285
	ds_store_2addr_b32 v133, v97, v99 offset0:96 offset1:98    // 0000001B3BB0: D8386260 00636185
	v_fmac_f32_e32 v5, 0x3b800000, v80                         // 0000001B3BB8: 560AA0FF 3B800000
	ds_store_2addr_b32 v133, v5, v6 offset0:108 offset1:110    // 0000001B3BC0: D8386E6C 00060585
	ds_store_2addr_b32 v133, v7, v8 offset0:112 offset1:114    // 0000001B3BC8: D8387270 00080785
	ds_store_2addr_b32 v133, v9, v10 offset0:116 offset1:118   // 0000001B3BD0: D8387674 000A0985
	ds_store_2addr_b32 v133, v1, v2 offset0:120 offset1:122    // 0000001B3BD8: D8387A78 00020185
	ds_store_2addr_b32 v133, v3, v4 offset0:124 offset1:126    // 0000001B3BE0: D8387E7C 00040385
	s_waitcnt lgkmcnt(0)                                       // 0000001B3BE8: BF89FC07
	s_barrier                                                  // 0000001B3BEC: BFBD0000
	s_cbranch_scc0 73                                          // 0000001B3BF0: BFA10049 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7318>
	s_cmp_lg_u32 s23, s45                                      // 0000001B3BF4: BF072D17
	s_cbranch_scc0 103                                         // 0000001B3BF8: BFA10067 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7398>
	s_cmp_lg_u32 s23, s46                                      // 0000001B3BFC: BF072E17
	s_cbranch_scc1 58577                                       // 0000001B3C00: BFA2E4D1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x548>
	s_branch 132                                               // 0000001B3C04: BFA00084 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7418>
	s_clause 0x1                                               // 0000001B3C08: BF850001
	global_load_b128 v[69:72], v[116:117], off offset:48       // 0000001B3C0C: DC5E0030 457C0074
	global_load_b128 v[65:68], v[116:117], off offset:32       // 0000001B3C14: DC5E0020 417C0074
	ds_load_b128 v[73:76], v128 offset:32                      // 0000001B3C1C: DBFC0020 49000080
	ds_load_b128 v[77:80], v128 offset:48                      // 0000001B3C24: DBFC0030 4D000080
	ds_load_b128 v[85:88], v128 offset:2352                    // 0000001B3C2C: DBFC0930 55000080
	ds_load_b128 v[81:84], v128 offset:2336                    // 0000001B3C34: DBFC0920 51000080
	ds_load_b128 v[184:187], v128 offset:4656                  // 0000001B3C3C: DBFC1230 B8000080
	ds_load_b128 v[180:183], v128 offset:4640                  // 0000001B3C44: DBFC1220 B4000080
	ds_load_b128 v[192:195], v128 offset:6960                  // 0000001B3C4C: DBFC1B30 C0000080
	ds_load_b128 v[188:191], v128 offset:6944                  // 0000001B3C54: DBFC1B20 BC000080
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001B3C5C: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[73:80], v[57:64]// 0000001B3C60: CC404039 1CE69341
	s_waitcnt lgkmcnt(4)                                       // 0000001B3C68: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[81:88], v[49:56]// 0000001B3C6C: CC404031 1CC6A341
	s_waitcnt lgkmcnt(2)                                       // 0000001B3C74: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[180:187], v[41:48]// 0000001B3C78: CC404029 1CA76941
	s_waitcnt lgkmcnt(0)                                       // 0000001B3C80: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[65:72], v[188:195], v[33:40]// 0000001B3C84: CC404021 1C877941
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3C8C: 8C7E0E7E
	s_and_saveexec_b32 s14, s5                                 // 0000001B3C90: BE8E2005
	s_cbranch_execz 64331                                      // 0000001B3C94: BFA5FB4B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5fc4>
	ds_load_b128 v[65:68], v128 offset:64                      // 0000001B3C98: DBFC0040 41000080
	ds_load_b128 v[69:72], v128 offset:80                      // 0000001B3CA0: DBFC0050 45000080
	ds_load_b128 v[77:80], v128 offset:2384                    // 0000001B3CA8: DBFC0950 4D000080
	ds_load_b128 v[73:76], v128 offset:2368                    // 0000001B3CB0: DBFC0940 49000080
	ds_load_b128 v[85:88], v128 offset:4688                    // 0000001B3CB8: DBFC1250 55000080
	ds_load_b128 v[81:84], v128 offset:4672                    // 0000001B3CC0: DBFC1240 51000080
	ds_load_b128 v[184:187], v128 offset:6992                  // 0000001B3CC8: DBFC1B50 B8000080
	ds_load_b128 v[180:183], v128 offset:6976                  // 0000001B3CD0: DBFC1B40 B4000080
	s_waitcnt vmcnt(2) lgkmcnt(6)                              // 0000001B3CD8: BF890867
	v_wmma_f32_16x16x16_f16 v[57:64], v[97:104], v[65:72], v[57:64]// 0000001B3CDC: CC404039 1CE68361
	s_waitcnt lgkmcnt(4)                                       // 0000001B3CE4: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[97:104], v[73:80], v[49:56]// 0000001B3CE8: CC404031 1CC69361
	s_waitcnt lgkmcnt(2)                                       // 0000001B3CF0: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[97:104], v[81:88], v[41:48]// 0000001B3CF4: CC404029 1CA6A361
	s_waitcnt lgkmcnt(0)                                       // 0000001B3CFC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[97:104], v[180:187], v[33:40]// 0000001B3D00: CC404021 1C876961
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3D08: 8C7E0E7E
	s_and_saveexec_b32 s14, s7                                 // 0000001B3D0C: BE8E2007
	s_cbranch_execnz 64303                                     // 0000001B3D10: BFA6FB2F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5fd0>
	s_branch 64332                                             // 0000001B3D14: BFA0FB4C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6048>
	v_mov_b32_e32 v3, v123                                     // 0000001B3D18: 7E06037B
	v_dual_mov_b32 v1, v110 :: v_dual_mov_b32 v2, v111         // 0000001B3D1C: CA10016E 0102016F
	v_mov_b32_e32 v4, v119                                     // 0000001B3D24: 7E080377
	s_mov_b32 s1, 0                                            // 0000001B3D28: BE810080
	s_nop 0                                                    // 0000001B3D2C: BF800000
	s_nop 0                                                    // 0000001B3D30: BF800000
	s_nop 0                                                    // 0000001B3D34: BF800000
	s_nop 0                                                    // 0000001B3D38: BF800000
	s_nop 0                                                    // 0000001B3D3C: BF800000
	ds_load_b32 v5, v3                                         // 0000001B3D40: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001B3D48: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001B3D50: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001B3D54: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001B3D58: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001B3D60: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001B3D64: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001B3D68: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001B3D70: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001B3D74: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001B3D7C: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001B3D84: 917E017E
	s_cbranch_execnz 65517                                     // 0000001B3D88: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7340>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001B3D8C: 8C7E017E
	s_cmp_lg_u32 s23, s45                                      // 0000001B3D90: BF072D17
	s_cbranch_scc1 65433                                       // 0000001B3D94: BFA2FF99 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x71fc>
	v_dual_mov_b32 v1, v112 :: v_dual_mov_b32 v4, v119         // 0000001B3D98: CA100170 01040177
	v_dual_mov_b32 v3, v123 :: v_dual_mov_b32 v2, v113         // 0000001B3DA0: CA10017B 03020171
	s_mov_b32 s1, 0                                            // 0000001B3DA8: BE810080
	s_nop 0                                                    // 0000001B3DAC: BF800000
	s_nop 0                                                    // 0000001B3DB0: BF800000
	s_nop 0                                                    // 0000001B3DB4: BF800000
	s_nop 0                                                    // 0000001B3DB8: BF800000
	s_nop 0                                                    // 0000001B3DBC: BF800000
	ds_load_b32 v5, v3                                         // 0000001B3DC0: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001B3DC8: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001B3DD0: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001B3DD4: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001B3DD8: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001B3DE0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001B3DE4: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001B3DE8: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001B3DF0: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001B3DF4: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001B3DFC: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001B3E04: 917E017E
	s_cbranch_execnz 65517                                     // 0000001B3E08: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x73c0>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001B3E0C: 8C7E017E
	s_cmp_lg_u32 s23, s46                                      // 0000001B3E10: BF072E17
	s_cbranch_scc1 58444                                       // 0000001B3E14: BFA2E44C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x548>
	v_mov_b32_e32 v3, v123                                     // 0000001B3E18: 7E06037B
	v_dual_mov_b32 v1, v114 :: v_dual_mov_b32 v2, v115         // 0000001B3E1C: CA100172 01020173
	v_mov_b32_e32 v4, v119                                     // 0000001B3E24: 7E080377
	s_mov_b32 s1, 0                                            // 0000001B3E28: BE810080
	s_nop 0                                                    // 0000001B3E2C: BF800000
	s_nop 0                                                    // 0000001B3E30: BF800000
	s_nop 0                                                    // 0000001B3E34: BF800000
	s_nop 0                                                    // 0000001B3E38: BF800000
	s_nop 0                                                    // 0000001B3E3C: BF800000
	ds_load_b32 v5, v3                                         // 0000001B3E40: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001B3E48: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001B3E50: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001B3E54: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001B3E58: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001B3E60: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001B3E64: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001B3E68: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001B3E70: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001B3E74: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001B3E7C: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001B3E84: 917E017E
	s_cbranch_execnz 65517                                     // 0000001B3E88: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7440>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001B3E8C: 8C7E017E
	s_branch 58413                                             // 0000001B3E90: BFA0E42D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x548>
	ds_load_b32 v65, v139                                      // 0000001B3E94: D8D80000 4100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B3E9C: BF89FC07
	v_fma_f32 v25, v25, v65, v57                               // 0000001B3EA0: D6130019 04E68319
	v_mad_u64_u32 v[65:66], null, 0x3000, v172, v[108:109]     // 0000001B3EA8: D6FE7C41 05B358FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B3EB4: BF870092
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 0000001B3EB8: 103232FF 3B800000
	v_bfe_u32 v57, v25, 16, 1                                  // 0000001B3EC0: D6100039 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B3EC8: BF870001
	v_add3_u32 v25, v25, v57, 0x7fff                           // 0000001B3ECC: D6550019 03FE7319 00007FFF
	global_store_d16_hi_b16 v[65:66], v25, off                 // 0000001B3ED8: DC960000 007C1941
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3EE0: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001B3EE4: BE8E200D
	s_cbranch_execz 64619                                      // 0000001B3EE8: BFA5FC6B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6698>
	ds_load_b32 v25, v139 offset:8                             // 0000001B3EEC: D8D80008 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B3EF4: BF89FC07
	v_fma_f32 v25, v26, v25, v58                               // 0000001B3EF8: D6130019 04EA331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B3F00: BF870121
	v_mul_f32_e32 v57, 0x3b800000, v25                         // 0000001B3F04: 107232FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v179, v[108:109]     // 0000001B3F0C: D6FE7C19 05B366FF 00003000
	v_bfe_u32 v58, v57, 16, 1                                  // 0000001B3F18: D610003A 02052139
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B3F20: BF870001
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000001B3F24: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[25:26], v57, off                 // 0000001B3F30: DC960000 007C3919
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3F38: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001B3F3C: BE8E200C
	s_cbranch_execz 64600                                      // 0000001B3F40: BFA5FC58 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66a4>
	ds_load_b32 v25, v139 offset:16                            // 0000001B3F44: D8D80010 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B3F4C: BF89FC07
	v_fma_f32 v25, v27, v25, v59                               // 0000001B3F50: D6130019 04EE331B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B3F58: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001B3F5C: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v178, v[108:109]     // 0000001B3F64: D6FE7C19 05B364FF 00003000
	v_bfe_u32 v57, v27, 16, 1                                  // 0000001B3F70: D6100039 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B3F78: BF870001
	v_add3_u32 v27, v27, v57, 0x7fff                           // 0000001B3F7C: D655001B 03FE731B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001B3F88: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3F90: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001B3F94: BE8E200B
	s_cbranch_execz 64581                                      // 0000001B3F98: BFA5FC45 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66b0>
	ds_load_b32 v25, v139 offset:24                            // 0000001B3F9C: D8D80018 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B3FA4: BF89FC07
	v_fma_f32 v25, v28, v25, v60                               // 0000001B3FA8: D6130019 04F2331C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B3FB0: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001B3FB4: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v177, v[108:109]     // 0000001B3FBC: D6FE7C19 05B362FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001B3FC8: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B3FD0: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001B3FD4: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001B3FE0: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B3FE8: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001B3FEC: BE8E2009
	s_cbranch_execz 64562                                      // 0000001B3FF0: BFA5FC32 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66bc>
	ds_load_b32 v25, v139 offset:32                            // 0000001B3FF4: D8D80020 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B3FFC: BF89FC07
	v_fma_f32 v25, v29, v25, v61                               // 0000001B4000: D6130019 04F6331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4008: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001B400C: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v176, v[108:109]     // 0000001B4014: D6FE7C19 05B360FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001B4020: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4028: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001B402C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001B4038: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B4040: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001B4044: BE8E2001
	s_cbranch_execz 64543                                      // 0000001B4048: BFA5FC1F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66c8>
	ds_load_b32 v25, v139 offset:40                            // 0000001B404C: D8D80028 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B4054: BF89FC07
	v_fma_f32 v25, v30, v25, v62                               // 0000001B4058: D6130019 04FA331E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4060: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001B4064: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v175, v[108:109]     // 0000001B406C: D6FE7C19 05B35EFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001B4078: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4080: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001B4084: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001B4090: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B4098: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001B409C: BE8E2008
	s_cbranch_execz 64524                                      // 0000001B40A0: BFA5FC0C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66d4>
	ds_load_b32 v25, v139 offset:48                            // 0000001B40A4: D8D80030 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B40AC: BF89FC07
	v_fma_f32 v25, v31, v25, v63                               // 0000001B40B0: D6130019 04FE331F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B40B8: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001B40BC: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v174, v[108:109]     // 0000001B40C4: D6FE7C19 05B35CFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001B40D0: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B40D8: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001B40DC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001B40E8: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B40F0: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001B40F4: BE8E2000
	s_cbranch_execz 64505                                      // 0000001B40F8: BFA5FBF9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66e0>
	ds_load_b32 v25, v139 offset:56                            // 0000001B40FC: D8D80038 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B4104: BF89FC07
	v_fma_f32 v25, v32, v25, v64                               // 0000001B4108: D6130019 05023320
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4110: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001B4114: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v173, v[108:109]     // 0000001B411C: D6FE7C19 05B35AFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001B4128: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4130: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001B4134: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001B4140: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B4148: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001B414C: BE8E200A
	s_cbranch_execz 64486                                      // 0000001B4150: BFA5FBE6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66ec>
	ds_load_b32 v25, v139                                      // 0000001B4154: D8D80000 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B415C: BF89FC07
	v_fma_f32 v9, v9, v25, v49                                 // 0000001B4160: D6130009 04C63309
	v_mad_u64_u32 v[25:26], null, 0x3000, v172, v[108:109]     // 0000001B4168: D6FE7C19 05B358FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B4174: BF870092
	v_mul_f32_e32 v9, 0x3b800000, v9                           // 0000001B4178: 101212FF 3B800000
	v_bfe_u32 v27, v9, 16, 1                                   // 0000001B4180: D610001B 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4188: BF870001
	v_add3_u32 v9, v9, v27, 0x7fff                             // 0000001B418C: D6550009 03FE3709 00007FFF
	global_store_d16_hi_b16 v[25:26], v9, off offset:32        // 0000001B4198: DC960020 007C0919
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B41A0: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001B41A4: BE8E200D
	s_cbranch_execz 64467                                      // 0000001B41A8: BFA5FBD3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66f8>
	ds_load_b32 v9, v139 offset:8                              // 0000001B41AC: D8D80008 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B41B4: BF89FC07
	v_fma_f32 v9, v10, v9, v50                                 // 0000001B41B8: D6130009 04CA130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B41C0: BF870121
	v_mul_f32_e32 v25, 0x3b800000, v9                          // 0000001B41C4: 103212FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v179, v[108:109]      // 0000001B41CC: D6FE7C09 05B366FF 00003000
	v_bfe_u32 v26, v25, 16, 1                                  // 0000001B41D8: D610001A 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B41E0: BF870001
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000001B41E4: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[9:10], v25, off offset:32        // 0000001B41F0: DC960020 007C1909
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B41F8: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001B41FC: BE8E200C
	s_cbranch_execz 64448                                      // 0000001B4200: BFA5FBC0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6704>
	ds_load_b32 v9, v139 offset:16                             // 0000001B4204: D8D80010 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B420C: BF89FC07
	v_fma_f32 v9, v11, v9, v51                                 // 0000001B4210: D6130009 04CE130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4218: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001B421C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v178, v[108:109]      // 0000001B4224: D6FE7C09 05B364FF 00003000
	v_bfe_u32 v25, v11, 16, 1                                  // 0000001B4230: D6100019 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4238: BF870001
	v_add3_u32 v11, v11, v25, 0x7fff                           // 0000001B423C: D655000B 03FE330B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001B4248: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B4250: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001B4254: BE8E200B
	s_cbranch_execz 64429                                      // 0000001B4258: BFA5FBAD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6710>
	ds_load_b32 v9, v139 offset:24                             // 0000001B425C: D8D80018 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B4264: BF89FC07
	v_fma_f32 v9, v12, v9, v52                                 // 0000001B4268: D6130009 04D2130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4270: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001B4274: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v177, v[108:109]      // 0000001B427C: D6FE7C09 05B362FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001B4288: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4290: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001B4294: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001B42A0: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B42A8: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001B42AC: BE8E2009
	s_cbranch_execz 64410                                      // 0000001B42B0: BFA5FB9A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x671c>
	ds_load_b32 v9, v139 offset:32                             // 0000001B42B4: D8D80020 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B42BC: BF89FC07
	v_fma_f32 v9, v13, v9, v53                                 // 0000001B42C0: D6130009 04D6130D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B42C8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001B42CC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v176, v[108:109]      // 0000001B42D4: D6FE7C09 05B360FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001B42E0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B42E8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001B42EC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001B42F8: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B4300: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001B4304: BE8E2001
	s_cbranch_execz 64391                                      // 0000001B4308: BFA5FB87 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6728>
	ds_load_b32 v9, v139 offset:40                             // 0000001B430C: D8D80028 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B4314: BF89FC07
	v_fma_f32 v9, v14, v9, v54                                 // 0000001B4318: D6130009 04DA130E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4320: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001B4324: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v175, v[108:109]      // 0000001B432C: D6FE7C09 05B35EFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001B4338: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4340: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001B4344: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001B4350: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B4358: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001B435C: BE8E2008
	s_cbranch_execz 64372                                      // 0000001B4360: BFA5FB74 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6734>
	ds_load_b32 v9, v139 offset:48                             // 0000001B4364: D8D80030 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B436C: BF89FC07
	v_fma_f32 v9, v15, v9, v55                                 // 0000001B4370: D6130009 04DE130F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4378: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001B437C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v174, v[108:109]      // 0000001B4384: D6FE7C09 05B35CFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001B4390: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4398: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001B439C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001B43A8: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B43B0: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001B43B4: BE8E2000
	s_cbranch_execz 64353                                      // 0000001B43B8: BFA5FB61 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6740>
	ds_load_b32 v9, v139 offset:56                             // 0000001B43BC: D8D80038 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B43C4: BF89FC07
	v_fma_f32 v9, v16, v9, v56                                 // 0000001B43C8: D6130009 04E21310
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B43D0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001B43D4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v173, v[108:109]      // 0000001B43DC: D6FE7C09 05B35AFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001B43E8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B43F0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001B43F4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001B4400: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B4408: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001B440C: BE8E200A
	s_cbranch_execz 64334                                      // 0000001B4410: BFA5FB4E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x674c>
	ds_load_b32 v9, v139                                       // 0000001B4414: D8D80000 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B441C: BF89FC07
	v_fma_f32 v9, v17, v9, v41                                 // 0000001B4420: D6130009 04A61311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4428: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001B442C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v172, v[108:109]      // 0000001B4434: D6FE7C09 05B358FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001B4440: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4448: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001B444C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001B4458: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B4460: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001B4464: BE8E200D
	s_cbranch_execz 64315                                      // 0000001B4468: BFA5FB3B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6758>
	ds_load_b32 v9, v139 offset:8                              // 0000001B446C: D8D80008 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B4474: BF89FC07
	v_fma_f32 v9, v18, v9, v42                                 // 0000001B4478: D6130009 04AA1312
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4480: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001B4484: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v179, v[108:109]      // 0000001B448C: D6FE7C09 05B366FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001B4498: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B44A0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001B44A4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001B44B0: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B44B8: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001B44BC: BE8E200C
	s_cbranch_execz 64296                                      // 0000001B44C0: BFA5FB28 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6764>
	ds_load_b32 v9, v139 offset:16                             // 0000001B44C4: D8D80010 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B44CC: BF89FC07
	v_fma_f32 v9, v19, v9, v43                                 // 0000001B44D0: D6130009 04AE1313
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B44D8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001B44DC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v178, v[108:109]      // 0000001B44E4: D6FE7C09 05B364FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001B44F0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B44F8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001B44FC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001B4508: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B4510: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001B4514: BE8E200B
	s_cbranch_execz 64277                                      // 0000001B4518: BFA5FB15 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6770>
	ds_load_b32 v9, v139 offset:24                             // 0000001B451C: D8D80018 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B4524: BF89FC07
	v_fma_f32 v9, v20, v9, v44                                 // 0000001B4528: D6130009 04B21314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4530: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001B4534: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v177, v[108:109]      // 0000001B453C: D6FE7C09 05B362FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001B4548: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4550: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001B4554: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001B4560: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B4568: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001B456C: BE8E2009
	s_cbranch_execz 64258                                      // 0000001B4570: BFA5FB02 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x677c>
	ds_load_b32 v9, v139 offset:32                             // 0000001B4574: D8D80020 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B457C: BF89FC07
	v_fma_f32 v9, v21, v9, v45                                 // 0000001B4580: D6130009 04B61315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4588: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001B458C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v176, v[108:109]      // 0000001B4594: D6FE7C09 05B360FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001B45A0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B45A8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001B45AC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001B45B8: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B45C0: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001B45C4: BE8E2001
	s_cbranch_execz 64239                                      // 0000001B45C8: BFA5FAEF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6788>
	ds_load_b32 v9, v139 offset:40                             // 0000001B45CC: D8D80028 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B45D4: BF89FC07
	v_fma_f32 v9, v22, v9, v46                                 // 0000001B45D8: D6130009 04BA1316
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B45E0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001B45E4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v175, v[108:109]      // 0000001B45EC: D6FE7C09 05B35EFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001B45F8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4600: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001B4604: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001B4610: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B4618: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001B461C: BE8E2008
	s_cbranch_execz 64220                                      // 0000001B4620: BFA5FADC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6794>
	ds_load_b32 v9, v139 offset:48                             // 0000001B4624: D8D80030 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B462C: BF89FC07
	v_fma_f32 v9, v23, v9, v47                                 // 0000001B4630: D6130009 04BE1317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4638: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001B463C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v174, v[108:109]      // 0000001B4644: D6FE7C09 05B35CFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001B4650: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4658: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001B465C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001B4668: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B4670: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001B4674: BE8E2000
	s_cbranch_execz 64201                                      // 0000001B4678: BFA5FAC9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67a0>
	ds_load_b32 v9, v139 offset:56                             // 0000001B467C: D8D80038 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B4684: BF89FC07
	v_fma_f32 v9, v24, v9, v48                                 // 0000001B4688: D6130009 04C21318
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4690: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001B4694: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v173, v[108:109]      // 0000001B469C: D6FE7C09 05B35AFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001B46A8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B46B0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001B46B4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001B46C0: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B46C8: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001B46CC: BE8E200A
	s_cbranch_execz 64182                                      // 0000001B46D0: BFA5FAB6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67ac>
	ds_load_b32 v9, v139                                       // 0000001B46D4: D8D80000 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B46DC: BF89FC07
	v_fma_f32 v1, v1, v9, v33                                  // 0000001B46E0: D6130001 04861301
	v_mad_u64_u32 v[9:10], null, 0x3000, v172, v[108:109]      // 0000001B46E8: D6FE7C09 05B358FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B46F4: BF870092
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 0000001B46F8: 100202FF 3B800000
	v_bfe_u32 v11, v1, 16, 1                                   // 0000001B4700: D610000B 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4708: BF870001
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001B470C: D6550001 03FE1701 00007FFF
	global_store_d16_hi_b16 v[9:10], v1, off offset:96         // 0000001B4718: DC960060 007C0109
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B4720: 8C7E0E7E
	s_and_saveexec_b32 s10, s13                                // 0000001B4724: BE8A200D
	s_cbranch_execz 64163                                      // 0000001B4728: BFA5FAA3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67b8>
	ds_load_b32 v1, v139 offset:8                              // 0000001B472C: D8D80008 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B4734: BF89FC07
	v_fma_f32 v1, v2, v1, v34                                  // 0000001B4738: D6130001 048A0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4740: BF870121
	v_mul_f32_e32 v9, 0x3b800000, v1                           // 0000001B4744: 101202FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v179, v[108:109]       // 0000001B474C: D6FE7C01 05B366FF 00003000
	v_bfe_u32 v10, v9, 16, 1                                   // 0000001B4758: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4760: BF870001
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000001B4764: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[1:2], v9, off offset:96          // 0000001B4770: DC960060 007C0901
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001B4778: 8C7E0A7E
	s_and_saveexec_b32 s10, s12                                // 0000001B477C: BE8A200C
	s_cbranch_execz 64144                                      // 0000001B4780: BFA5FA90 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67c4>
	ds_load_b32 v1, v139 offset:16                             // 0000001B4784: D8D80010 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B478C: BF89FC07
	v_fma_f32 v1, v3, v1, v35                                  // 0000001B4790: D6130001 048E0303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4798: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001B479C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v178, v[108:109]       // 0000001B47A4: D6FE7C01 05B364FF 00003000
	v_bfe_u32 v9, v3, 16, 1                                    // 0000001B47B0: D6100009 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B47B8: BF870001
	v_add3_u32 v3, v3, v9, 0x7fff                              // 0000001B47BC: D6550003 03FE1303 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001B47C8: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001B47D0: 8C7E0A7E
	s_and_saveexec_b32 s10, s11                                // 0000001B47D4: BE8A200B
	s_cbranch_execz 64125                                      // 0000001B47D8: BFA5FA7D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67d0>
	ds_load_b32 v1, v139 offset:24                             // 0000001B47DC: D8D80018 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B47E4: BF89FC07
	v_fma_f32 v1, v4, v1, v36                                  // 0000001B47E8: D6130001 04920304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B47F0: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001B47F4: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v177, v[108:109]       // 0000001B47FC: D6FE7C01 05B362FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001B4808: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4810: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001B4814: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001B4820: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001B4828: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 0000001B482C: BE8A2009
	s_cbranch_execz 64106                                      // 0000001B4830: BFA5FA6A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67dc>
	ds_load_b32 v1, v139 offset:32                             // 0000001B4834: D8D80020 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B483C: BF89FC07
	v_fma_f32 v1, v5, v1, v37                                  // 0000001B4840: D6130001 04960305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4848: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001B484C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v176, v[108:109]       // 0000001B4854: D6FE7C01 05B360FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001B4860: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4868: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001B486C: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001B4878: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001B4880: 8C7E0A7E
	s_and_saveexec_b32 s9, s1                                  // 0000001B4884: BE892001
	s_cbranch_execz 64087                                      // 0000001B4888: BFA5FA57 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67e8>
	ds_load_b32 v1, v139 offset:40                             // 0000001B488C: D8D80028 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B4894: BF89FC07
	v_fma_f32 v1, v6, v1, v38                                  // 0000001B4898: D6130001 049A0306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B48A0: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001B48A4: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v175, v[108:109]       // 0000001B48AC: D6FE7C01 05B35EFF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001B48B8: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B48C0: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001B48C4: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001B48D0: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s9                              // 0000001B48D8: 8C7E097E
	s_and_saveexec_b32 s1, s8                                  // 0000001B48DC: BE812008
	s_cbranch_execz 64068                                      // 0000001B48E0: BFA5FA44 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67f4>
	ds_load_b32 v1, v139 offset:48                             // 0000001B48E4: D8D80030 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001B48EC: BF89FC07
	v_fma_f32 v1, v7, v1, v39                                  // 0000001B48F0: D6130001 049E0307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B48F8: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001B48FC: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v174, v[108:109]       // 0000001B4904: D6FE7C01 05B35CFF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001B4910: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4918: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001B491C: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001B4928: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001B4930: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000001B4934: BE812000
	s_cbranch_execnz 64049                                     // 0000001B4938: BFA6FA31 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6800>
	s_branch 64066                                             // 0000001B493C: BFA0FA42 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6848>
	v_dual_mov_b32 v1, s34 :: v_dual_mov_b32 v2, s35           // 0000001B4940: CA100022 01020023
	v_mov_b32_e32 v6, v119                                     // 0000001B4948: 7E0C0377
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B494C: BF870092
	.long 0xd7006a00                                           // 0000001B4950: D7006A00
	v_cndmask_b32_e32 v0, v1, v18, vcc_lo                      // 0000001B4954: 02002501
	v_add_co_ci_u32_e64 v1, null, s19, v2, vcc_lo              // 0000001B4958: D5207C01 01AA0413
	s_add_u32 s0, s33, s20                                     // 0000001B4960: 80001421
	s_addc_u32 s1, s15, s21                                    // 0000001B4964: 8201150F
	.long 0xd7006a00                                           // 0000001B4968: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000001B496C: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001B4970: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000001B4974: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000001B497C: BE810080
	.long 0xd7006a00                                           // 0000001B4980: D7006A00
	v_cndmask_b32_e32 v1, v0, v106, vcc_lo                     // 0000001B4984: 0202D500
	v_add_co_ci_u32_e64 v1, null, v1, v107, vcc_lo             // 0000001B4988: D5207C01 01AAD701
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B4990: BF870092
	.long 0xd7006a00                                           // 0000001B4994: D7006A00
	v_cndmask_b32_e32 v1, v0, v118, vcc_lo                     // 0000001B4998: 0202ED00
	v_add_co_ci_u32_e64 v1, null, v1, v129, vcc_lo             // 0000001B499C: D5207C01 01AB0301
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B49A4: BF870092
	.long 0xd7006a00                                           // 0000001B49A8: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000001B49AC: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000001B49B0: D5207C01 01AA0211
	s_nop 0                                                    // 0000001B49B8: BF800000
	s_nop 0                                                    // 0000001B49BC: BF800000
	ds_load_b32 v2, v123                                       // 0000001B49C0: D8D80000 0200007B
	v_add_nc_u32_e32 v6, 0x80, v6                              // 0000001B49C8: 4A0C0CFF 00000080
	v_add_nc_u32_e32 v123, 8, v123                             // 0000001B49D0: 4AF6F688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001B49D4: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v6                        // 0000001B49D8: 7C920CFF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001B49E0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001B49E4: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000001B49E8: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000001B49F0: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 0000001B49F4: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000001B49FC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001B4A04: 917E017E
	s_cbranch_execnz 65517                                     // 0000001B4A08: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7fc0>
	s_nop 0                                                    // 0000001B4A0C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001B4A10: BFB60003
	s_endpgm                                                   // 0000001B4A14: BFB00000
		...

