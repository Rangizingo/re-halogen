0000000000057500 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi():
	s_clause 0x1                                               // 000000057500: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000057504: F40C0100 F8000000
	s_load_b32 s1, s[0:1], 0x20                                // 00000005750C: F4000040 F8000020
	v_dual_mov_b32 v8, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 000000057514: CA240100 080000FF 0000007F
	s_mov_b32 s12, s3                                          // 000000057520: BE8C0003
	s_lshl_b32 s0, s2, 6                                       // 000000057524: 84008602
	s_ashr_i32 s13, s12, 31                                    // 000000057528: 860D9F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005752C: BF870121
	v_lshlrev_b32_e32 v2, 1, v1                                // 000000057530: 30040281
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000057534: 30020282
	v_or_b32_e32 v3, 0x4800, v2                                // 000000057538: 380604FF 00004800
	s_waitcnt lgkmcnt(0)                                       // 000000057540: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057544: BF870092
	.long 0xd7000304                                           // 000000057548: D7000304
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000005754C: 02020204
	v_add_co_ci_u32_e64 v5, null, s5, 0, s3                    // 000000057550: D5207C05 000D0005
	.long 0xd7000306                                           // 000000057558: D7000306
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 00000005755C: 02020206
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057560: BF870001
	v_add_co_ci_u32_e64 v7, null, s7, 0, s3                    // 000000057564: D5207C07 000D0007
	s_mov_b32 s3, 0                                            // 00000005756C: BE830080
	s_mov_b32 s4, 0x41800000                                   // 000000057570: BE8400FF 41800000
	s_branch 15                                                // 000000057578: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0xb8>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000005757C: 8C7E057E
	v_add_nc_u32_e32 v11, 0x100, v8                            // 000000057580: 4A1610FF 00000100
	v_mad_u64_u32 v[9:10], null, 0x120, v9, v[2:3]             // 000000057588: D6FE7C09 040A12FF 00000120
	v_cmp_lt_u32_e32 vcc_lo, 0x1eff, v8                        // 000000057594: 7C9210FF 00001EFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000005759C: BF870003
	v_mov_b32_e32 v8, v11                                      // 0000000575A0: 7E10030B
	s_or_b32 s3, vcc_lo, s3                                    // 0000000575A4: 8C03036A
	ds_store_b16 v9, v1                                        // 0000000575A8: D87C0000 00000109
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000000575B0: 917E037E
	s_cbranch_execz 47                                         // 0000000575B4: BFA5002F <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0x174>
	v_lshrrev_b32_e32 v9, 7, v8                                // 0000000575B8: 32121087
	s_mov_b32 s5, exec_lo                                      // 0000000575BC: BE85007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000575C0: BF870091
	v_or_b32_e32 v10, s0, v9                                   // 0000000575C4: 38141200
	.long 0xd4c3007e                                           // 0000000575C8: D4C3007E
	v_cndmask_b32_e32 v1, s1, v10, vcc_lo                      // 0000000575CC: 02021401
	s_xor_b32 s5, exec_lo, s5                                  // 0000000575D0: 8D05057E
	v_mad_u64_u32 v[10:11], null, 0x120, v9, v[3:4]            // 0000000575D4: D6FE7C0A 040E12FF 00000120
	.long 0x7e023880                                           // 0000000575E0: 7E023880
	ds_store_b16 v10, v1                                       // 0000000575E4: D87C0000 0000010A
	s_or_saveexec_b32 s5, s5                                   // 0000000575EC: BE852205
	.long 0x7e023880                                           // 0000000575F0: 7E023880
	s_xor_b32 exec_lo, exec_lo, s5                             // 0000000575F4: 8D7E057E
	s_cbranch_execz 65504                                      // 0000000575F8: BFA5FFE0 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0x7c>
	v_mad_i64_i32 v[10:11], null, v10, 48, s[12:13]            // 0000000575FC: D6FF7C0A 0031610A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057604: BF870091
	.long 0xd73c000a                                           // 000000057608: D73C000A
	v_cndmask_b32_e32 v1, 9, v10, vcc_lo                       // 00000005760C: 02021489
	.long 0xd7006a0c                                           // 000000057610: D7006A0C
	v_cndmask_b32_e32 v1, v4, v10, vcc_lo                      // 000000057614: 02021504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000057618: BF8700A1
	v_add_co_ci_u32_e64 v13, null, v5, v11, vcc_lo             // 00000005761C: D5207C0D 01AA1705
	.long 0xd7006a0a                                           // 000000057624: D7006A0A
	v_cndmask_b32_e32 v1, v6, v10, vcc_lo                      // 000000057628: 02021506
	v_add_co_ci_u32_e64 v11, null, v7, v11, vcc_lo             // 00000005762C: D5207C0B 01AA1707
	global_load_b32 v1, v[12:13], off                          // 000000057634: DC520000 017C000C
	global_load_b32 v12, v[10:11], off                         // 00000005763C: DC520000 0C7C000A
	v_mad_u64_u32 v[10:11], null, 0x120, v9, v[3:4]            // 000000057644: D6FE7C0A 040E12FF 00000120
	s_waitcnt vmcnt(1)                                         // 000000057650: BF8907F7
	v_fma_mixhi_f16 v1, v1, s4, 0                              // 000000057654: CC220001 02000901
	s_waitcnt vmcnt(0)                                         // 00000005765C: BF8903F7
	v_fma_mixlo_f16 v1, v12, s4, 0                             // 000000057660: CC210001 0200090C
	ds_store_b16_d16_hi v10, v1                                // 000000057668: DA840000 0000010A
	s_branch 65474                                             // 000000057670: BFA0FFC2 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0x7c>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000057674: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000057678: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000005767C: BE81007E
	v_cmpx_gt_u32_e32 64, v0                                   // 000000057680: 7D9800C0
	s_cbranch_execz 17                                         // 000000057684: BFA50011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0x1cc>
	v_or_b32_e32 v1, s0, v0                                    // 000000057688: 38020000
	s_lshl_b64 s[4:5], s[12:13], 2                             // 00000005768C: 8484820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057690: BF870091
	v_mad_i64_i32 v[1:2], null, 0xc0, v1, s[8:9]               // 000000057694: D6FF7C01 002202FF 000000C0
	.long 0xd7006a01                                           // 0000000576A0: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 0000000576A4: 02000901
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000576A8: BF870001
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000000576AC: D5207C02 01AA0405
	global_load_b32 v1, v[1:2], off                            // 0000000576B4: DC520000 017C0001
	v_lshlrev_b32_e32 v2, 2, v0                                // 0000000576BC: 30040082
	s_waitcnt vmcnt(0)                                         // 0000000576C0: BF8903F7
	ds_store_b32 v2, v1 offset:36864                           // 0000000576C4: D8349000 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000576CC: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 0000000576D0: BF89FC07
	s_barrier                                                  // 0000000576D4: BFBD0000
	buffer_gl0_inv                                             // 0000000576D8: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 0000000576E0: BE80007E
	v_cmpx_gt_u32_e32 0x200, v0                                // 0000000576E4: 7D9800FF 00000200
	s_cbranch_execz 599                                        // 0000000576EC: BFA50257 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0xb4c>
	v_lshrrev_b32_e32 v10, 7, v0                               // 0000000576F0: 32140087
	v_and_b32_e32 v1, 15, v0                                   // 0000000576F4: 3602008F
	v_bfe_u32 v9, v0, 5, 2                                     // 0000000576F8: D6100009 02090B00
	v_bfe_u32 v2, v0, 4, 1                                     // 000000057700: D6100002 02050900
	v_lshrrev_b32_e32 v5, 5, v0                                // 000000057708: 320A0085
	v_lshrrev_b32_e32 v0, 4, v0                                // 00000005770C: 32000084
	v_lshlrev_b32_e32 v6, 4, v10                               // 000000057710: 300C1484
	v_lshlrev_b32_e32 v3, 10, v10                              // 000000057714: 3006148A
	v_lshlrev_b32_e32 v4, 6, v2                                // 000000057718: 30080486
	s_mul_hi_u32 s1, s2, 48                                    // 00000005771C: 9681B002
	s_mul_i32 s2, s2, 48                                       // 000000057720: 9602B002
	v_or3_b32 v17, v6, v0, 14                                  // 000000057724: D6580011 023A0106
	v_mov_b32_e32 v0, 0                                        // 00000005772C: 7E000280
	v_lshl_or_b32 v11, v9, 4, v1                               // 000000057730: D656000B 04050909
	v_mul_u32_u24_e32 v1, 0x120, v1                            // 000000057738: 160202FF 00000120
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000057740: 30040482
	s_add_u32 s0, s2, s12                                      // 000000057744: 80000C02
	s_addc_u32 s1, s1, s13                                     // 000000057748: 82010D01
	v_or3_b32 v3, v3, v4, v11                                  // 00000005774C: D6580003 042E0903
	v_mul_u32_u24_e32 v4, 0x1200, v9                           // 000000057754: 160812FF 00001200
	s_lshl_b64 s[2:3], s[0:1], 14                              // 00000005775C: 84828E00
	v_lshl_or_b32 v12, v11, 2, 0x9000                          // 000000057760: D656000C 03FD050B 00009000
	v_or_b32_e32 v14, -8, v5                                   // 00000005776C: 381C0AC8
	v_lshlrev_b32_e32 v13, 2, v3                               // 000000057770: 301A0682
	v_mad_u32_u24 v15, 0x1200, v10, v1                         // 000000057774: D60B000F 040614FF 00001200
	v_lshl_or_b32 v16, v10, 6, v2                              // 000000057780: D6560010 04090D0A
	v_add_nc_u32_e32 v25, v1, v4                               // 000000057788: 4A320901
	s_add_u32 s1, s10, s2                                      // 00000005778C: 8001020A
	v_or_b32_e32 v18, 0xe00, v13                               // 000000057790: 38241AFF 00000E00
	v_or_b32_e32 v19, 0xc00, v13                               // 000000057798: 38261AFF 00000C00
	v_or_b32_e32 v20, 0xa00, v13                               // 0000000577A0: 38281AFF 00000A00
	v_or_b32_e32 v21, 0x800, v13                               // 0000000577A8: 382A1AFF 00000800
	v_or_b32_e32 v22, 0x600, v13                               // 0000000577B0: 382C1AFF 00000600
	v_or_b32_e32 v23, 0x400, v13                               // 0000000577B8: 382E1AFF 00000400
	v_or_b32_e32 v24, 0x200, v13                               // 0000000577C0: 38301AFF 00000200
	s_addc_u32 s2, s11, s3                                     // 0000000577C8: 8202030B
	s_mov_b32 s3, 0                                            // 0000000577CC: BE830080
	s_branch 24                                                // 0000000577D0: BFA00018 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0x334>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000577D4: 8C7E007E
	.long 0xd700000e                                           // 0000000577D8: D700000E
	v_cndmask_b32_e32 v0, v14, v136, vcc_lo                    // 0000000577DC: 0201110E
	.long 0xd7000402                                           // 0000000577E0: D7000402
	v_cndmask_b32_e32 v1, s1, v18, vcc_lo                      // 0000000577E4: 02022401
	s_xor_b32 s0, s0, -1                                       // 0000000577E8: 8D00C100
	s_add_u32 s1, s1, 0x2000                                   // 0000000577EC: 8001FF01 00002000
	v_add_co_ci_u32_e64 v3, null, s2, 0, s4                    // 0000000577F4: D5207C03 00110002
	v_add_nc_u32_e32 v15, 0x2400, v15                          // 0000000577FC: 4A1E1EFF 00002400
	v_add_nc_u32_e32 v16, 0x80, v16                            // 000000057804: 4A2020FF 00000080
	v_add_nc_u32_e32 v17, 32, v17                              // 00000005780C: 4A2222A0
	s_addc_u32 s2, s2, 0                                       // 000000057810: 82028002
	v_add_nc_u32_e32 v10, 2, v10                               // 000000057814: 4A141482
	s_and_b32 s0, exec_lo, s0                                  // 000000057818: 8B00007E
	global_store_b32 v[2:3], v1, off                           // 00000005781C: DC6A0000 007C0102
	s_or_b32 s3, s0, s3                                        // 000000057824: 8C030300
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000057828: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 00000005782C: 917E037E
	s_cbranch_execz 518                                        // 000000057830: BFA50206 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0xb4c>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 000000057834: CA100080 01020080
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, 0               // 00000005783C: CA100080 03040080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0               // 000000057844: CA100080 05060080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v8, 0               // 00000005784C: CA100080 07080080
	s_mov_b32 s4, exec_lo                                      // 000000057854: BE84007E
	v_cmp_lt_u32_e32 vcc_lo, v10, v9                           // 000000057858: 7C92130A
	.long 0xd4ce007e                                           // 00000005785C: D4CE007E
	v_cndmask_b32_e32 v1, v10, v9, vcc_lo                      // 000000057860: 0202130A
	s_cbranch_execz 106                                        // 000000057864: BFA5006A <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0x510>
	ds_load_b128 v[26:29], v15 offset:18432                    // 000000057868: DBFC4800 1A00000F
	ds_load_b128 v[30:33], v15 offset:18448                    // 000000057870: DBFC4810 1E00000F
	ds_load_b128 v[34:37], v15 offset:18464                    // 000000057878: DBFC4820 2200000F
	ds_load_b128 v[38:41], v15 offset:18480                    // 000000057880: DBFC4830 2600000F
	ds_load_b128 v[42:45], v25                                 // 000000057888: DBFC0000 2A000019
	ds_load_b128 v[46:49], v25 offset:16                       // 000000057890: DBFC0010 2E000019
	ds_load_b128 v[50:53], v25 offset:32                       // 000000057898: DBFC0020 32000019
	ds_load_b128 v[54:57], v25 offset:48                       // 0000000578A0: DBFC0030 36000019
	v_mov_b32_e32 v7, v0                                       // 0000000578A8: 7E0E0300
	ds_load_b128 v[62:65], v15 offset:18512                    // 0000000578AC: DBFC4850 3E00000F
	ds_load_b128 v[58:61], v15 offset:18496                    // 0000000578B4: DBFC4840 3A00000F
	ds_load_b128 v[70:73], v25 offset:80                       // 0000000578BC: DBFC0050 46000019
	ds_load_b128 v[66:69], v25 offset:64                       // 0000000578C4: DBFC0040 42000019
	v_mov_b32_e32 v1, v0                                       // 0000000578CC: 7E020300
	v_mov_b32_e32 v2, v0                                       // 0000000578D0: 7E040300
	v_mov_b32_e32 v3, v0                                       // 0000000578D4: 7E060300
	v_mov_b32_e32 v4, v0                                       // 0000000578D8: 7E080300
	v_mov_b32_e32 v5, v0                                       // 0000000578DC: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 0000000578E0: 7E0C0300
	v_mov_b32_e32 v8, v7                                       // 0000000578E4: 7E100307
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000578E8: BF870212
	v_mov_b32_e32 v7, v6                                       // 0000000578EC: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 0000000578F0: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 0000000578F4: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 0000000578F8: 7E080303
	v_mov_b32_e32 v3, v2                                       // 0000000578FC: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000057900: 7E040301
	v_mov_b32_e32 v1, v0                                       // 000000057904: 7E020300
	ds_load_b128 v[78:81], v15 offset:18544                    // 000000057908: DBFC4870 4E00000F
	ds_load_b128 v[74:77], v15 offset:18528                    // 000000057910: DBFC4860 4A00000F
	ds_load_b128 v[86:89], v25 offset:112                      // 000000057918: DBFC0070 56000019
	ds_load_b128 v[82:85], v25 offset:96                       // 000000057920: DBFC0060 52000019
	s_waitcnt lgkmcnt(10)                                      // 000000057928: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[1:8], v[26:33], v[42:49], v[1:8] // 00000005792C: CC404001 1C06551A
	ds_load_b128 v[30:33], v15 offset:18576                    // 000000057934: DBFC4890 1E00000F
	ds_load_b128 v[26:29], v15 offset:18560                    // 00000005793C: DBFC4880 1A00000F
	ds_load_b128 v[46:49], v25 offset:144                      // 000000057944: DBFC0090 2E000019
	ds_load_b128 v[42:45], v25 offset:128                      // 00000005794C: DBFC0080 2A000019
	s_waitcnt lgkmcnt(12)                                      // 000000057954: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[1:8], v[34:41], v[50:57], v[1:8] // 000000057958: CC404001 1C066522
	ds_load_b128 v[38:41], v15 offset:18608                    // 000000057960: DBFC48B0 2600000F
	ds_load_b128 v[34:37], v15 offset:18592                    // 000000057968: DBFC48A0 2200000F
	ds_load_b128 v[54:57], v25 offset:176                      // 000000057970: DBFC00B0 36000019
	ds_load_b128 v[50:53], v25 offset:160                      // 000000057978: DBFC00A0 32000019
	s_waitcnt lgkmcnt(12)                                      // 000000057980: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[1:8], v[58:65], v[66:73], v[1:8] // 000000057984: CC404001 1C06853A
	ds_load_b128 v[62:65], v15 offset:18640                    // 00000005798C: DBFC48D0 3E00000F
	ds_load_b128 v[58:61], v15 offset:18624                    // 000000057994: DBFC48C0 3A00000F
	ds_load_b128 v[70:73], v25 offset:208                      // 00000005799C: DBFC00D0 46000019
	ds_load_b128 v[66:69], v25 offset:192                      // 0000000579A4: DBFC00C0 42000019
	s_waitcnt lgkmcnt(12)                                      // 0000000579AC: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[1:8], v[74:81], v[82:89], v[1:8] // 0000000579B0: CC404001 1C06A54A
	ds_load_b128 v[78:81], v15 offset:18672                    // 0000000579B8: DBFC48F0 4E00000F
	ds_load_b128 v[74:77], v15 offset:18656                    // 0000000579C0: DBFC48E0 4A00000F
	ds_load_b128 v[86:89], v25 offset:240                      // 0000000579C8: DBFC00F0 56000019
	ds_load_b128 v[82:85], v25 offset:224                      // 0000000579D0: DBFC00E0 52000019
	s_waitcnt lgkmcnt(12)                                      // 0000000579D8: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[1:8], v[26:33], v[42:49], v[1:8] // 0000000579DC: CC404001 1C06551A
	s_waitcnt lgkmcnt(8)                                       // 0000000579E4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000579E8: BF8700A1
	v_wmma_f32_16x16x16_f16 v[1:8], v[34:41], v[50:57], v[1:8] // 0000000579EC: CC404001 1C066522
	s_waitcnt lgkmcnt(4)                                       // 0000000579F4: BF89FC47
	v_wmma_f32_16x16x16_f16 v[1:8], v[58:65], v[66:73], v[1:8] // 0000000579F8: CC404001 1C06853A
	s_waitcnt lgkmcnt(0)                                       // 000000057A00: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057A04: BF870001
	v_wmma_f32_16x16x16_f16 v[1:8], v[74:81], v[82:89], v[1:8] // 000000057A08: CC404001 1C06A54A
	s_or_b32 exec_lo, exec_lo, s4                              // 000000057A10: 8C7E047E
	v_dual_mov_b32 v27, 0 :: v_dual_add_nc_u32 v26, -14, v17   // 000000057A14: CA200080 1B1A22CE
	s_xor_b32 s4, vcc_lo, -1                                   // 000000057A1C: 8D04C16A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000057A20: BF8704B1
	.long 0xd44b0000                                           // 000000057A24: D44B0000
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 000000057A28: 0202350B
	v_mov_b32_e32 v26, 0                                       // 000000057A2C: 7E340280
	s_and_b32 s5, s4, s0                                       // 000000057A30: 8B050004
	s_and_saveexec_b32 s0, s5                                  // 000000057A34: BE802005
	s_cbranch_execz 36                                         // 000000057A38: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0x5cc>
	ds_load_b32 v27, v16 offset:36864                          // 000000057A3C: D8D89000 1B000010
	ds_load_b32 v28, v12                                       // 000000057A44: D8D80000 1C00000C
	s_waitcnt lgkmcnt(0)                                       // 000000057A4C: BF89FC07
	v_sub_f32_e32 v27, v27, v28                                // 000000057A50: 0836391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057A54: BF870091
	v_mul_f32_e32 v28, 0x3fb8aa3b, v27                         // 000000057A58: 103836FF 3FB8AA3B
	v_fma_f32 v29, 0x3fb8aa3b, v27, -v28                       // 000000057A60: D613001D 847236FF 3FB8AA3B
	v_rndne_f32_e32 v30, v28                                   // 000000057A6C: 7E3C471C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000057A70: BF870221
	v_sub_f32_e32 v28, v28, v30                                // 000000057A74: 08383D1C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v27                  // 000000057A78: 7C3636FF C2CE8ED0
	v_fmac_f32_e32 v29, 0x32a5705f, v27                        // 000000057A80: 563A36FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057A88: BF870121
	v_add_f32_e32 v28, v28, v29                                // 000000057A8C: 06383B1C
	v_cvt_i32_f32_e32 v29, v30                                 // 000000057A90: 7E3A111E
	v_exp_f32_e32 v28, v28                                     // 000000057A94: 7E384B1C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057A98: BF870095
	.long 0xd71c001c                                           // 000000057A9C: D71C001C
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                     // 000000057AA0: 02023B1C
	v_cndmask_b32_e32 v28, 0, v28, vcc_lo                      // 000000057AA4: 02383880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v27                  // 000000057AA8: 7C3C36FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057AB0: BF870092
	v_cndmask_b32_e32 v27, 0x7f800000, v28, vcc_lo             // 000000057AB4: 023638FF 7F800000
	v_mul_f32_e32 v27, 0x3b800000, v27                         // 000000057ABC: 103636FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057AC4: BF870001
	v_mul_f32_e32 v27, v1, v27                                 // 000000057AC8: 10363701
	s_or_b32 exec_lo, exec_lo, s0                              // 000000057ACC: 8C7E007E
	v_add_nc_u32_e32 v1, -12, v17                              // 000000057AD0: 4A0222CC
	.long 0xd700001c                                           // 000000057AD4: D700001C
	v_cndmask_b32_e32 v1, s1, v13, vcc_lo                      // 000000057AD8: 02021A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000057ADC: BF870191
	v_add_co_ci_u32_e64 v29, null, s2, 0, s0                   // 000000057AE0: D5207C1D 00010002
	v_cmp_le_u32_e32 vcc_lo, v11, v1                           // 000000057AE8: 7C96030B
	global_store_b32 v[28:29], v27, off                        // 000000057AEC: DC6A0000 007C1B1C
	s_and_b32 s5, s4, vcc_lo                                   // 000000057AF4: 8B056A04
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000057AF8: BF870009
	s_and_saveexec_b32 s0, s5                                  // 000000057AFC: BE802005
	s_cbranch_execz 36                                         // 000000057B00: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0x694>
	ds_load_b32 v1, v16 offset:36872                           // 000000057B04: D8D89008 01000010
	ds_load_b32 v26, v12                                       // 000000057B0C: D8D80000 1A00000C
	s_waitcnt lgkmcnt(0)                                       // 000000057B14: BF89FC07
	v_sub_f32_e32 v1, v1, v26                                  // 000000057B18: 08023501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057B1C: BF870091
	v_mul_f32_e32 v26, 0x3fb8aa3b, v1                          // 000000057B20: 103402FF 3FB8AA3B
	v_fma_f32 v27, 0x3fb8aa3b, v1, -v26                        // 000000057B28: D613001B 846A02FF 3FB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000057B34: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000057B38: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000057B3C: 0834391A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 000000057B40: 7C3602FF C2CE8ED0
	v_fmac_f32_e32 v27, 0x32a5705f, v1                         // 000000057B48: 563602FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057B50: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000057B54: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000057B58: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000057B5C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057B60: BF870095
	.long 0xd71c001a                                           // 000000057B64: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000057B68: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000057B6C: 02343480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 000000057B70: 7C3C02FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057B78: BF870092
	v_cndmask_b32_e32 v1, 0x7f800000, v26, vcc_lo              // 000000057B7C: 020234FF 7F800000
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 000000057B84: 100202FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057B8C: BF870001
	v_mul_f32_e32 v26, v2, v1                                  // 000000057B90: 10340302
	s_or_b32 exec_lo, exec_lo, s0                              // 000000057B94: 8C7E007E
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, -10, v17     // 000000057B98: CA200080 020022CA
	.long 0xd700001b                                           // 000000057BA0: D700001B
	v_cndmask_b32_e32 v1, s1, v24, vcc_lo                      // 000000057BA4: 02023001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000057BA8: BF870191
	v_add_co_ci_u32_e64 v28, null, s2, 0, s0                   // 000000057BAC: D5207C1C 00010002
	v_cmp_le_u32_e32 vcc_lo, v11, v1                           // 000000057BB4: 7C96030B
	v_mov_b32_e32 v1, 0                                        // 000000057BB8: 7E020280
	global_store_b32 v[27:28], v26, off                        // 000000057BBC: DC6A0000 007C1A1B
	s_and_b32 s5, s4, vcc_lo                                   // 000000057BC4: 8B056A04
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000057BC8: BF870009
	s_and_saveexec_b32 s0, s5                                  // 000000057BCC: BE802005
	s_cbranch_execz 35                                         // 000000057BD0: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0x760>
	ds_load_b32 v2, v16 offset:36880                           // 000000057BD4: D8D89010 02000010
	ds_load_b32 v26, v12                                       // 000000057BDC: D8D80000 1A00000C
	s_waitcnt lgkmcnt(0)                                       // 000000057BE4: BF89FC07
	v_sub_f32_e32 v2, v2, v26                                  // 000000057BE8: 08043502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057BEC: BF870121
	v_mul_f32_e32 v26, 0x3fb8aa3b, v2                          // 000000057BF0: 103404FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2                   // 000000057BF8: 7C3604FF C2CE8ED0
	v_fma_f32 v27, 0x3fb8aa3b, v2, -v26                        // 000000057C00: D613001B 846A04FF 3FB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000057C0C: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057C10: BF870091
	v_dual_fmac_f32 v27, 0x32a5705f, v2 :: v_dual_sub_f32 v26, v26, v28// 000000057C14: C80A04FF 1B1A391A 32A5705F
	v_add_f32_e32 v26, v26, v27                                // 000000057C20: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000057C24: 7E36111C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000057C28: BF870292
	v_exp_f32_e32 v26, v26                                     // 000000057C2C: 7E344B1A
	.long 0xd71c001a                                           // 000000057C30: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000057C34: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057C38: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000057C3C: 02343480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2                   // 000000057C40: 7C3C04FF 42B17218
	v_cndmask_b32_e32 v2, 0x7f800000, v26, vcc_lo              // 000000057C48: 020434FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057C50: BF870091
	v_mul_f32_e32 v2, 0x3b800000, v2                           // 000000057C54: 100404FF 3B800000
	v_mul_f32_e32 v2, v3, v2                                   // 000000057C5C: 10040503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000057C60: 8C7E007E
	v_add_nc_u32_e32 v3, -8, v17                               // 000000057C64: 4A0622C8
	.long 0xd700001a                                           // 000000057C68: D700001A
	v_cndmask_b32_e32 v1, s1, v23, vcc_lo                      // 000000057C6C: 02022E01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000057C70: BF870191
	v_add_co_ci_u32_e64 v27, null, s2, 0, s0                   // 000000057C74: D5207C1B 00010002
	v_cmp_le_u32_e32 vcc_lo, v11, v3                           // 000000057C7C: 7C96070B
	global_store_b32 v[26:27], v2, off                         // 000000057C80: DC6A0000 007C021A
	s_and_b32 s5, s4, vcc_lo                                   // 000000057C88: 8B056A04
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000057C8C: BF870009
	s_and_saveexec_b32 s0, s5                                  // 000000057C90: BE802005
	s_cbranch_execz 35                                         // 000000057C94: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0x824>
	ds_load_b32 v1, v16 offset:36888                           // 000000057C98: D8D89018 01000010
	ds_load_b32 v2, v12                                        // 000000057CA0: D8D80000 0200000C
	s_waitcnt lgkmcnt(0)                                       // 000000057CA8: BF89FC07
	v_sub_f32_e32 v1, v1, v2                                   // 000000057CAC: 08020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057CB0: BF870091
	v_mul_f32_e32 v2, 0x3fb8aa3b, v1                           // 000000057CB4: 100402FF 3FB8AA3B
	v_fma_f32 v3, 0x3fb8aa3b, v1, -v2                          // 000000057CBC: D6130003 840A02FF 3FB8AA3B
	v_rndne_f32_e32 v26, v2                                    // 000000057CC8: 7E344702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057CCC: BF870091
	v_dual_fmac_f32 v3, 0x32a5705f, v1 :: v_dual_sub_f32 v2, v2, v26// 000000057CD0: C80A02FF 03023502 32A5705F
	v_add_f32_e32 v2, v2, v3                                   // 000000057CDC: 06040702
	v_cvt_i32_f32_e32 v3, v26                                  // 000000057CE0: 7E06111A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 000000057CE4: 7C3602FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000057CEC: BF870293
	v_exp_f32_e32 v2, v2                                       // 000000057CF0: 7E044B02
	.long 0xd71c0002                                           // 000000057CF4: D71C0002
	v_cndmask_b32_e32 v1, v2, v3, vcc_lo                       // 000000057CF8: 02020702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057CFC: BF870121
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 000000057D00: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 000000057D04: 7C3C02FF 42B17218
	v_cndmask_b32_e32 v1, 0x7f800000, v2, vcc_lo               // 000000057D0C: 020204FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057D14: BF870091
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 000000057D18: 100202FF 3B800000
	v_mul_f32_e32 v1, v4, v1                                   // 000000057D20: 10020304
	s_or_b32 exec_lo, exec_lo, s0                              // 000000057D24: 8C7E007E
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, -6, v17      // 000000057D28: CA200080 030222C6
	.long 0xd700001a                                           // 000000057D30: D700001A
	v_cndmask_b32_e32 v1, s1, v22, vcc_lo                      // 000000057D34: 02022C01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000057D38: BF870191
	v_add_co_ci_u32_e64 v27, null, s2, 0, s0                   // 000000057D3C: D5207C1B 00010002
	v_cmp_le_u32_e32 vcc_lo, v11, v2                           // 000000057D44: 7C96050B
	v_mov_b32_e32 v2, 0                                        // 000000057D48: 7E040280
	global_store_b32 v[26:27], v1, off                         // 000000057D4C: DC6A0000 007C011A
	s_and_b32 s5, s4, vcc_lo                                   // 000000057D54: 8B056A04
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000057D58: BF870009
	s_and_saveexec_b32 s0, s5                                  // 000000057D5C: BE802005
	s_cbranch_execz 35                                         // 000000057D60: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0x8f0>
	ds_load_b32 v1, v16 offset:36896                           // 000000057D64: D8D89020 01000010
	ds_load_b32 v3, v12                                        // 000000057D6C: D8D80000 0300000C
	s_waitcnt lgkmcnt(0)                                       // 000000057D74: BF89FC07
	v_sub_f32_e32 v1, v1, v3                                   // 000000057D78: 08020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057D7C: BF870121
	v_mul_f32_e32 v3, 0x3fb8aa3b, v1                           // 000000057D80: 100602FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 000000057D88: 7C3602FF C2CE8ED0
	v_fma_f32 v4, 0x3fb8aa3b, v1, -v3                          // 000000057D90: D6130004 840E02FF 3FB8AA3B
	v_rndne_f32_e32 v26, v3                                    // 000000057D9C: 7E344703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057DA0: BF870091
	v_dual_fmac_f32 v4, 0x32a5705f, v1 :: v_dual_sub_f32 v3, v3, v26// 000000057DA4: C80A02FF 04023503 32A5705F
	v_add_f32_e32 v3, v3, v4                                   // 000000057DB0: 06060903
	v_cvt_i32_f32_e32 v4, v26                                  // 000000057DB4: 7E08111A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000057DB8: BF870292
	v_exp_f32_e32 v3, v3                                       // 000000057DBC: 7E064B03
	.long 0xd71c0003                                           // 000000057DC0: D71C0003
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 000000057DC4: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057DC8: BF870121
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 000000057DCC: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 000000057DD0: 7C3C02FF 42B17218
	v_cndmask_b32_e32 v1, 0x7f800000, v3, vcc_lo               // 000000057DD8: 020206FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057DE0: BF870091
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 000000057DE4: 100202FF 3B800000
	v_mul_f32_e32 v3, v5, v1                                   // 000000057DEC: 10060305
	s_or_b32 exec_lo, exec_lo, s0                              // 000000057DF0: 8C7E007E
	v_add_nc_u32_e32 v1, -4, v17                               // 000000057DF4: 4A0222C4
	.long 0xd7000004                                           // 000000057DF8: D7000004
	v_cndmask_b32_e32 v1, s1, v21, vcc_lo                      // 000000057DFC: 02022A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000057E00: BF870191
	v_add_co_ci_u32_e64 v5, null, s2, 0, s0                    // 000000057E04: D5207C05 00010002
	v_cmp_le_u32_e32 vcc_lo, v11, v1                           // 000000057E0C: 7C96030B
	global_store_b32 v[4:5], v3, off                           // 000000057E10: DC6A0000 007C0304
	s_and_b32 s5, s4, vcc_lo                                   // 000000057E18: 8B056A04
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000057E1C: BF870009
	s_and_saveexec_b32 s0, s5                                  // 000000057E20: BE802005
	s_cbranch_execz 36                                         // 000000057E24: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0x9b8>
	ds_load_b32 v1, v16 offset:36904                           // 000000057E28: D8D89028 01000010
	ds_load_b32 v2, v12                                        // 000000057E30: D8D80000 0200000C
	s_waitcnt lgkmcnt(0)                                       // 000000057E38: BF89FC07
	v_sub_f32_e32 v1, v1, v2                                   // 000000057E3C: 08020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057E40: BF870091
	v_mul_f32_e32 v2, 0x3fb8aa3b, v1                           // 000000057E44: 100402FF 3FB8AA3B
	v_fma_f32 v3, 0x3fb8aa3b, v1, -v2                          // 000000057E4C: D6130003 840A02FF 3FB8AA3B
	v_rndne_f32_e32 v4, v2                                     // 000000057E58: 7E084702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000057E5C: BF870221
	v_sub_f32_e32 v2, v2, v4                                   // 000000057E60: 08040902
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 000000057E64: 7C3602FF C2CE8ED0
	v_fmac_f32_e32 v3, 0x32a5705f, v1                          // 000000057E6C: 560602FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057E74: BF870121
	v_add_f32_e32 v2, v2, v3                                   // 000000057E78: 06040702
	v_cvt_i32_f32_e32 v3, v4                                   // 000000057E7C: 7E061104
	v_exp_f32_e32 v2, v2                                       // 000000057E80: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057E84: BF870095
	.long 0xd71c0002                                           // 000000057E88: D71C0002
	v_cndmask_b32_e32 v1, v2, v3, vcc_lo                       // 000000057E8C: 02020702
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 000000057E90: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 000000057E94: 7C3C02FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057E9C: BF870092
	v_cndmask_b32_e32 v1, 0x7f800000, v2, vcc_lo               // 000000057EA0: 020204FF 7F800000
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 000000057EA8: 100202FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057EB0: BF870001
	v_mul_f32_e32 v2, v6, v1                                   // 000000057EB4: 10040306
	s_or_b32 exec_lo, exec_lo, s0                              // 000000057EB8: 8C7E007E
	v_add_nc_u32_e32 v1, -2, v17                               // 000000057EBC: 4A0222C2
	.long 0xd7000004                                           // 000000057EC0: D7000004
	v_cndmask_b32_e32 v1, s1, v20, vcc_lo                      // 000000057EC4: 02022801
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000057EC8: BF870191
	v_add_co_ci_u32_e64 v5, null, s2, 0, s0                    // 000000057ECC: D5207C05 00010002
	v_cmp_le_u32_e32 vcc_lo, v11, v1                           // 000000057ED4: 7C96030B
	v_mov_b32_e32 v1, 0                                        // 000000057ED8: 7E020280
	v_mov_b32_e32 v3, 0                                        // 000000057EDC: 7E060280
	global_store_b32 v[4:5], v2, off                           // 000000057EE0: DC6A0000 007C0204
	s_and_b32 s5, s4, vcc_lo                                   // 000000057EE8: 8B056A04
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000057EEC: BF870009
	s_and_saveexec_b32 s0, s5                                  // 000000057EF0: BE802005
	s_cbranch_execz 36                                         // 000000057EF4: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0xa88>
	ds_load_b32 v2, v16 offset:36912                           // 000000057EF8: D8D89030 02000010
	ds_load_b32 v3, v12                                        // 000000057F00: D8D80000 0300000C
	s_waitcnt lgkmcnt(0)                                       // 000000057F08: BF89FC07
	v_sub_f32_e32 v2, v2, v3                                   // 000000057F0C: 08040702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057F10: BF870091
	v_mul_f32_e32 v3, 0x3fb8aa3b, v2                           // 000000057F14: 100604FF 3FB8AA3B
	v_fma_f32 v4, 0x3fb8aa3b, v2, -v3                          // 000000057F1C: D6130004 840E04FF 3FB8AA3B
	v_rndne_f32_e32 v5, v3                                     // 000000057F28: 7E0A4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000057F2C: BF870221
	v_sub_f32_e32 v3, v3, v5                                   // 000000057F30: 08060B03
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2                   // 000000057F34: 7C3604FF C2CE8ED0
	v_fmac_f32_e32 v4, 0x32a5705f, v2                          // 000000057F3C: 560804FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057F44: BF870121
	v_add_f32_e32 v3, v3, v4                                   // 000000057F48: 06060903
	v_cvt_i32_f32_e32 v4, v5                                   // 000000057F4C: 7E081105
	v_exp_f32_e32 v3, v3                                       // 000000057F50: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057F54: BF870095
	.long 0xd71c0003                                           // 000000057F58: D71C0003
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 000000057F5C: 02020903
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 000000057F60: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2                   // 000000057F64: 7C3C04FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057F6C: BF870092
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo               // 000000057F70: 020406FF 7F800000
	v_mul_f32_e32 v2, 0x3b800000, v2                           // 000000057F78: 100404FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057F80: BF870001
	v_mul_f32_e32 v3, v7, v2                                   // 000000057F84: 10060507
	s_or_b32 exec_lo, exec_lo, s0                              // 000000057F88: 8C7E007E
	v_cmp_le_u32_e32 vcc_lo, v11, v17                          // 000000057F8C: 7C96230B
	.long 0xd7000004                                           // 000000057F90: D7000004
	v_cndmask_b32_e32 v1, s1, v19, vcc_lo                      // 000000057F94: 02022601
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057F98: BF870001
	v_add_co_ci_u32_e64 v5, null, s2, 0, s0                    // 000000057F9C: D5207C05 00010002
	s_and_b32 s4, s4, vcc_lo                                   // 000000057FA4: 8B046A04
	global_store_b32 v[4:5], v3, off                           // 000000057FA8: DC6A0000 007C0304
	s_and_saveexec_b32 s0, s4                                  // 000000057FB0: BE802004
	s_cbranch_execz 65031                                      // 000000057FB4: BFA5FE07 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0x2d4>
	ds_load_b32 v1, v16 offset:36920                           // 000000057FB8: D8D89038 01000010
	ds_load_b32 v2, v12                                        // 000000057FC0: D8D80000 0200000C
	s_waitcnt lgkmcnt(0)                                       // 000000057FC8: BF89FC07
	v_sub_f32_e32 v1, v1, v2                                   // 000000057FCC: 08020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057FD0: BF870091
	v_mul_f32_e32 v2, 0x3fb8aa3b, v1                           // 000000057FD4: 100402FF 3FB8AA3B
	v_fma_f32 v3, 0x3fb8aa3b, v1, -v2                          // 000000057FDC: D6130003 840A02FF 3FB8AA3B
	v_rndne_f32_e32 v4, v2                                     // 000000057FE8: 7E084702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000057FEC: BF870221
	v_sub_f32_e32 v2, v2, v4                                   // 000000057FF0: 08040902
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 000000057FF4: 7C3602FF C2CE8ED0
	v_fmac_f32_e32 v3, 0x32a5705f, v1                          // 000000057FFC: 560602FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000058004: BF870121
	v_add_f32_e32 v2, v2, v3                                   // 000000058008: 06040702
	v_cvt_i32_f32_e32 v3, v4                                   // 00000005800C: 7E061104
	v_exp_f32_e32 v2, v2                                       // 000000058010: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058014: BF870095
	.long 0xd71c0002                                           // 000000058018: D71C0002
	v_cndmask_b32_e32 v1, v2, v3, vcc_lo                       // 00000005801C: 02020702
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 000000058020: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 000000058024: 7C3C02FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005802C: BF870092
	v_cndmask_b32_e32 v1, 0x7f800000, v2, vcc_lo               // 000000058030: 020204FF 7F800000
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 000000058038: 100202FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000058040: BF870001
	v_mul_f32_e32 v1, v8, v1                                   // 000000058044: 10020308
	s_branch 64994                                             // 000000058048: BFA0FDE2 <_ZN7halogen12_GLOBAL__N_110k_dnc_att8EPKfS2_S2_Pfi+0x2d4>
	s_endpgm                                                   // 00000005804C: BFB00000
		...

