0000000000131200 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000131200: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 000000131204: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000013120C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 000000131214: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 000000131218: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000013121C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v3, 15, v0         // 000000131220: CA240100 0402008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000131228: BF8704C1
	v_lshlrev_b32_e32 v11, 2, v3                               // 00000013122C: 30160682
	s_waitcnt lgkmcnt(0)                                       // 000000131230: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 000000131234: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000013123C: 84928214
	s_add_u32 s25, s16, s18                                    // 000000131240: 80191210
	s_addc_u32 s28, s17, s19                                   // 000000131244: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 000000131248: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000013124C: BF870009
	s_add_u32 s25, s25, s20                                    // 000000131250: 80191419
	s_addc_u32 s30, s28, s21                                   // 000000131254: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 000000131258: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000013125C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 000000131264: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000013126C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 000000131270: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 000000131274: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000131278: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000013127C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 000000131280: 821E191E
	.long 0xd7001f01                                           // 000000131284: D7001F01
	v_cndmask_b32_e32 v1, s31, v11, vcc_lo                     // 000000131288: 0202161F
	v_add_co_ci_u32_e64 v2, null, s30, 0, s31                  // 00000013128C: D5207C02 007D001E
	s_mov_b32 s30, 0                                           // 000000131294: BE9E0080
	s_nop 0                                                    // 000000131298: BF800000
	s_nop 0                                                    // 00000013129C: BF800000
	s_nop 0                                                    // 0000001312A0: BF800000
	s_nop 0                                                    // 0000001312A4: BF800000
	s_nop 0                                                    // 0000001312A8: BF800000
	s_nop 0                                                    // 0000001312AC: BF800000
	s_nop 0                                                    // 0000001312B0: BF800000
	s_nop 0                                                    // 0000001312B4: BF800000
	s_nop 0                                                    // 0000001312B8: BF800000
	s_nop 0                                                    // 0000001312BC: BF800000
	v_lshrrev_b32_e32 v7, 4, v4                                // 0000001312C0: 320E0884
	v_add_nc_u32_e32 v9, 0x80, v4                              // 0000001312C4: 4A1208FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001312CC: BF870092
	v_lshlrev_b32_e32 v5, 9, v7                                // 0000001312D0: 300A0E89
	.long 0xd7006a05                                           // 0000001312D4: D7006A05
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 0000001312D8: 02020B01
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001312DC: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001312E0: D5207C06 01AA0480
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000001312E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v9                                       // 0000001312F0: 7E080309
	global_load_b32 v8, v[5:6], off                            // 0000001312F4: DC520000 087C0005
	v_mad_u64_u32 v[5:6], null, 0x44, v7, v[11:12]             // 0000001312FC: D6FE7C05 042E0EFF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 000000131308: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000013130C: BF8903F7
	ds_store_b32 v5, v8                                        // 000000131310: D8340000 00000805
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 000000131318: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000013131C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 000000131320: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 000000131324: F4000780 F8000058
	v_or_b32_e32 v50, 0xffffff80, v0                           // 00000013132C: 386400FF FFFFFF80
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000131334: 32020084
	s_mov_b32 s0, 0                                            // 000000131338: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000013133C: BF89FC07
	s_barrier                                                  // 000000131340: BFBD0000
	buffer_gl0_inv                                             // 000000131344: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000013134C: BF02801E
	s_cbranch_scc1 12                                          // 000000131350: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v2, 0x44, v1                             // 000000131354: 160402FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000013135C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000131364: BF870002
	v_lshl_add_u32 v49, v3, 2, v2                              // 000000131368: D6460031 04090503
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v51, 2, v3      // 000000131370: CA220080 02320682
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000131378: 916A007E
	s_cbranch_vccz 2                                           // 00000013137C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2962                                              // 000000131380: BFA00B92 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2fcc>
	v_lshlrev_b32_e32 v51, 2, v3                               // 000000131384: 30660682
	s_add_i32 s0, s30, 63                                      // 000000131388: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000013138C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 000000131394: 85218600
	s_add_u32 s34, s10, s24                                    // 000000131398: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000013139C: 8223190B
	s_lshl_b32 s10, s2, 7                                      // 0000001313A0: 840A8702
	v_mad_u32_u24 v49, 0x44, v1, v51                           // 0000001313A4: D60B0031 04CE02FF 00000044
	s_ashr_i32 s11, s10, 31                                    // 0000001313B0: 860B9F0A
	.long 0xd44c0000                                           // 0000001313B4: D44C0000
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 0000001313B8: 020200C0
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000001313BC: 848A810A
	.long 0xd44c0001                                           // 0000001313C0: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000001313C4: 020200FF 00000080
	s_add_u32 s22, s22, s10                                    // 0000001313CC: 80160A16
	s_addc_u32 s23, s23, s11                                   // 0000001313D0: 82170B17
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000001313D4: 848A811A
	v_or_b32_e32 v59, 0x2200, v11                              // 0000001313D8: 387616FF 00002200
	s_add_u32 s22, s22, s10                                    // 0000001313E0: 80160A16
	s_addc_u32 s23, s23, s11                                   // 0000001313E4: 82170B17
	s_movk_i32 s10, 0x204                                      // 0000001313E8: B00A0204
	.long 0xd7000b38                                           // 0000001313EC: D7000B38
	v_cndmask_b32_e32 v1, s34, v51, vcc_lo                     // 0000001313F0: 02026622
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001313F4: BF8704B1
	v_add_co_ci_u32_e64 v57, null, s35, 0, s11                 // 0000001313F8: D5207C39 002D0023
	v_mad_u32_u24 v58, v1, s10, 0x3300                         // 000000131400: D60B003A 03FC1501 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 00000013140C: 848A8902
	v_dual_mov_b32 v5, s11 :: v_dual_lshlrev_b32 v52, 2, v0    // 000000131410: CA22000B 05340082
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 1, v3       // 000000131418: CA220080 02020681
	v_lshlrev_b32_e32 v7, 8, v1                                // 000000131420: 300E0288
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000131424: BF870223
	v_add_nc_u32_e32 v53, 0x4320, v52                          // 000000131428: 4A6A68FF 00004320
	v_or_b32_e32 v4, s10, v52                                  // 000000131430: 3808680A
	v_dual_mov_b32 v9, v2 :: v_dual_add_nc_u32 v62, 0x800, v11 // 000000131434: CA200102 093E16FF 00000800
	.long 0xd7000a0d                                           // 000000131440: D7000A0D
	v_cndmask_b32_e32 v1, s22, v3, vcc_lo                      // 000000131444: 02020616
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131448: BF870093
	.long 0xd7006a03                                           // 00000013144C: D7006A03
	v_cndmask_b32_e32 v1, 0x30000, v4, vcc_lo                  // 000000131450: 020208FF 00030000
	v_add_co_ci_u32_e64 v6, null, 0, v5, vcc_lo                // 000000131458: D5207C06 01AA0A80
	.long 0xd7006a0f                                           // 000000131460: D7006A0F
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 000000131464: 0202080C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000131468: BF870211
	v_add_co_ci_u32_e64 v16, null, s13, v5, vcc_lo             // 00000013146C: D5207C10 01AA0A0D
	.long 0xd7006a11                                           // 000000131474: D7006A11
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                      // 000000131478: 0202060C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013147C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, s13, v6, vcc_lo             // 000000131480: D5207C12 01AA0C0D
	.long 0xd7006a13                                           // 000000131488: D7006A13
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 00000013148C: 02020804
	v_add_co_ci_u32_e64 v20, null, s5, v5, vcc_lo              // 000000131490: D5207C14 01AA0A05
	.long 0xd7006a15                                           // 000000131498: D7006A15
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 00000013149C: 02020604
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001314A0: BF8700A1
	v_add_co_ci_u32_e64 v22, null, s5, v6, vcc_lo              // 0000001314A4: D5207C16 01AA0C05
	.long 0xd7006a19                                           // 0000001314AC: D7006A19
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000001314B0: 02020806
	v_add_co_ci_u32_e64 v26, null, s7, v5, vcc_lo              // 0000001314B4: D5207C1A 01AA0A07
	.long 0xd7006a1b                                           // 0000001314BC: D7006A1B
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 0000001314C0: 02020606
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001314C4: BF870211
	v_add_co_ci_u32_e64 v28, null, s7, v6, vcc_lo              // 0000001314C8: D5207C1C 01AA0C07
	.long 0xd7006a1d                                           // 0000001314D0: D7006A1D
	v_cndmask_b32_e32 v1, 0x60000, v25, vcc_lo                 // 0000001314D4: 020232FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001314DC: BF8700A1
	v_add_co_ci_u32_e64 v30, null, 0, v26, vcc_lo              // 0000001314E0: D5207C1E 01AA3480
	.long 0xd7006a1f                                           // 0000001314E8: D7006A1F
	v_cndmask_b32_e32 v1, 0x90000, v25, vcc_lo                 // 0000001314EC: 020232FF 00090000
	v_add_co_ci_u32_e64 v32, null, 0, v26, vcc_lo              // 0000001314F4: D5207C20 01AA3480
	.long 0xd7006a21                                           // 0000001314FC: D7006A21
	v_cndmask_b32_e32 v1, 0xc0000, v25, vcc_lo                 // 000000131500: 020232FF 000C0000
	v_add_co_ci_u32_e64 v14, null, s23, 0, s10                 // 000000131508: D5207C0E 00290017
	s_lshl_b64 s[10:11], s[2:3], 14                            // 000000131510: 848A8E02
	v_add_co_ci_u32_e64 v34, null, 0, v26, vcc_lo              // 000000131514: D5207C22 01AA3480
	.long 0xd7006a23                                           // 00000013151C: D7006A23
	v_cndmask_b32_e32 v1, 0xf0000, v25, vcc_lo                 // 000000131520: 020232FF 000F0000
	s_add_u32 s4, s14, s10                                     // 000000131528: 80040A0E
	v_add_co_ci_u32_e64 v36, null, 0, v26, vcc_lo              // 00000013152C: D5207C24 01AA3480
	.long 0xd7006a25                                           // 000000131534: D7006A25
	v_cndmask_b32_e32 v1, 0x120000, v25, vcc_lo                // 000000131538: 020232FF 00120000
	v_dual_mov_b32 v3, v2 :: v_dual_add_nc_u32 v54, 0x4420, v52// 000000131540: CA200102 033668FF 00004420
	v_dual_mov_b32 v4, v2 :: v_dual_add_nc_u32 v55, 1, v1      // 00000013154C: CA200102 04360281
	v_dual_mov_b32 v5, v2 :: v_dual_add_nc_u32 v12, 0x2200, v49// 000000131554: CA200102 050C62FF 00002200
	s_addc_u32 s5, s15, s11                                    // 000000131560: 82050B0F
	v_add_co_ci_u32_e64 v38, null, 0, v26, vcc_lo              // 000000131564: D5207C26 01AA3480
	.long 0xd7006a27                                           // 00000013156C: D7006A27
	v_cndmask_b32_e32 v1, 0x150000, v25, vcc_lo                // 000000131570: 020232FF 00150000
	v_mov_b32_e32 v6, v2                                       // 000000131578: 7E0C0302
	v_mov_b32_e32 v8, v2                                       // 00000013157C: 7E100302
	.long 0xd7000417                                           // 000000131580: D7000417
	v_cndmask_b32_e32 v1, s4, v7, vcc_lo                       // 000000131584: 02020E04
	v_dual_mov_b32 v7, v2 :: v_dual_add_nc_u32 v60, 0x400, v11 // 000000131588: CA200102 073C16FF 00000400
	v_dual_mov_b32 v10, v9 :: v_dual_add_nc_u32 v61, 0x600, v11// 000000131594: CA200109 0A3C16FF 00000600
	v_add_co_ci_u32_e64 v24, null, s5, 0, s4                   // 0000001315A0: D5207C18 00110005
	v_add_co_ci_u32_e64 v40, null, 0, v26, vcc_lo              // 0000001315A8: D5207C28 01AA3480
	v_dual_mov_b32 v9, v8 :: v_dual_add_nc_u32 v64, 0xe00, v11 // 0000001315B0: CA200108 094016FF 00000E00
	v_dual_mov_b32 v8, v7 :: v_dual_add_nc_u32 v63, 0xc00, v11 // 0000001315BC: CA200107 083E16FF 00000C00
	v_dual_mov_b32 v7, v6 :: v_dual_add_nc_u32 v66, 0x1400, v11// 0000001315C8: CA200106 074216FF 00001400
	v_dual_mov_b32 v6, v5 :: v_dual_add_nc_u32 v65, 0x1000, v11// 0000001315D4: CA200105 064016FF 00001000
	v_dual_mov_b32 v5, v4 :: v_dual_add_nc_u32 v68, 0x1800, v11// 0000001315E0: CA200104 054416FF 00001800
	v_dual_mov_b32 v4, v3 :: v_dual_add_nc_u32 v67, 0x1600, v11// 0000001315EC: CA200103 044216FF 00001600
	v_add_nc_u32_e32 v69, 0x1c00, v11                          // 0000001315F8: 4A8A16FF 00001C00
	v_dual_mov_b32 v3, v2 :: v_dual_add_nc_u32 v70, 0x1e00, v11// 000000131600: CA200102 034616FF 00001E00
	v_add_nc_u32_e32 v71, 0x2000, v11                          // 00000013160C: 4A8E16FF 00002000
	s_mov_b32 s5, 0                                            // 000000131614: BE850080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000131618: BF870499
	s_mul_i32 s4, s5, 0xc00                                    // 00000013161C: 9604FF05 00000C00
	s_add_i32 s6, s31, s4                                      // 000000131624: 8106041F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000131628: BF870499
	s_ashr_i32 s7, s6, 31                                      // 00000013162C: 86079F06
	s_lshl_b64 s[10:11], s[6:7], 2                             // 000000131630: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 000000131634: 84078605
	s_add_u32 s10, s8, s10                                     // 000000131638: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 00000013163C: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 000000131640: F4000185 F8000000
	s_and_saveexec_b32 s4, s0                                  // 000000131648: BE842000
	s_cbranch_execz 69                                         // 00000013164C: BFA50045 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x564>
	v_or_b32_e32 v41, s7, v0                                   // 000000131650: 38520007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131654: BF870091
	v_mad_u64_u32 v[41:42], null, v41, 48, s[2:3]              // 000000131658: D6FE7C29 00096129
	v_ashrrev_i32_e32 v42, 31, v41                             // 000000131660: 3454529F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131664: BF870091
	.long 0xd73c0029                                           // 000000131668: D73C0029
	v_cndmask_b32_e32 v1, 2, v41, vcc_lo                       // 00000013166C: 02025282
	.long 0xd7006a29                                           // 000000131670: D7006A29
	v_cndmask_b32_e32 v1, s8, v41, vcc_lo                      // 000000131674: 02025208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000131678: BF8700C1
	v_add_co_ci_u32_e64 v42, null, s9, v42, vcc_lo             // 00000013167C: D5207C2A 01AA5409
	global_load_b32 v41, v[41:42], off                         // 000000131684: DC520000 297C0029
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000013168C: BF890007
	v_sub_f32_e32 v42, s6, v41                                 // 000000131690: 08545206
	v_dual_mul_f32 v44, 0x3fb8aa3b, v41 :: v_dual_mul_f32 v43, 0x3fb8aa3b, v42// 000000131694: C8C652FF 2C2A54FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001316A0: BF8701A1
	v_rndne_f32_e32 v48, v44                                   // 0000001316A4: 7E60472C
	v_fma_f32 v47, 0x3fb8aa3b, v41, -v44                       // 0000001316A8: D613002F 84B252FF 3FB8AA3B
	v_fma_f32 v45, 0x3fb8aa3b, v42, -v43                       // 0000001316B4: D613002D 84AE54FF 3FB8AA3B
	v_rndne_f32_e32 v46, v43                                   // 0000001316C0: 7E5C472B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001316C4: BF870191
	v_dual_sub_f32 v44, v44, v48 :: v_dual_sub_f32 v43, v43, v46// 0000001316C8: C94A612C 2C2A5D2B
	v_fmac_f32_e32 v45, 0x32a5705f, v42                        // 0000001316D0: 565A54FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v42                  // 0000001316D8: 7C3654FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001316E0: BF8701B2
	v_add_f32_e32 v43, v43, v45                                // 0000001316E4: 06565B2B
	v_cvt_i32_f32_e32 v45, v46                                 // 0000001316E8: 7E5A112E
	v_cvt_i32_f32_e32 v46, v48                                 // 0000001316EC: 7E5C1130
	v_exp_f32_e32 v43, v43                                     // 0000001316F0: 7E564B2B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001316F4: BF870095
	.long 0xd71c002b                                           // 0000001316F8: D71C002B
	v_cndmask_b32_e32 v1, v43, v45, vcc_lo                     // 0000001316FC: 02025B2B
	v_cndmask_b32_e32 v43, 0, v43, vcc_lo                      // 000000131700: 02565680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v41                  // 000000131704: 7C3652FF C2CE8ED0
	v_fmac_f32_e32 v47, 0x32a5705f, v41                        // 00000013170C: 565E52FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131714: BF870091
	v_add_f32_e32 v44, v44, v47                                // 000000131718: 06585F2C
	v_exp_f32_e32 v44, v44                                     // 00000013171C: 7E584B2C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131720: BF870095
	.long 0xd71c002c                                           // 000000131724: D71C002C
	v_cndmask_b32_e32 v1, v44, v46, vcc_lo                     // 000000131728: 02025D2C
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 00000013172C: 02585880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v42                  // 000000131730: 7C3C54FF 42B17218
	v_cndmask_b32_e32 v42, 0x7f800000, v43, vcc_lo             // 000000131738: 025456FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v41                  // 000000131740: 7C3C52FF 42B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 000000131748: BF870004
	v_cndmask_b32_e32 v41, 0x7f800000, v44, vcc_lo             // 00000013174C: 025258FF 7F800000
	ds_store_b32 v53, v42                                      // 000000131754: D8340000 00002A35
	ds_store_b32 v54, v41                                      // 00000013175C: D8340000 00002936
	s_or_b32 exec_lo, exec_lo, s4                              // 000000131764: 8C7E047E
	v_dual_mov_b32 v42, v16 :: v_dual_mov_b32 v41, v15         // 000000131768: CA100110 2A28010F
	v_mov_b32_e32 v43, v50                                     // 000000131770: 7E560332
	s_mov_b32 s11, 0                                           // 000000131774: BE8B0080
	s_mov_b32 s10, 0                                           // 000000131778: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000013177C: BF89FC07
	s_barrier                                                  // 000000131780: BFBD0000
	buffer_gl0_inv                                             // 000000131784: E0AC0000 00000000
	s_nop 0                                                    // 00000013178C: BF800000
	s_nop 0                                                    // 000000131790: BF800000
	s_nop 0                                                    // 000000131794: BF800000
	s_nop 0                                                    // 000000131798: BF800000
	s_nop 0                                                    // 00000013179C: BF800000
	s_nop 0                                                    // 0000001317A0: BF800000
	s_nop 0                                                    // 0000001317A4: BF800000
	s_nop 0                                                    // 0000001317A8: BF800000
	s_nop 0                                                    // 0000001317AC: BF800000
	s_nop 0                                                    // 0000001317B0: BF800000
	s_nop 0                                                    // 0000001317B4: BF800000
	s_nop 0                                                    // 0000001317B8: BF800000
	s_nop 0                                                    // 0000001317BC: BF800000
	global_load_b32 v44, v[41:42], off                         // 0000001317C0: DC520000 2C7C0029
	v_add_nc_u32_e32 v43, 0x80, v43                            // 0000001317C8: 4A5656FF 00000080
	.long 0xd7006a29                                           // 0000001317D0: D7006A29
	v_cndmask_b32_e32 v1, 0x6000, v41, vcc_lo                  // 0000001317D4: 020252FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001317DC: BF870191
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 0000001317E0: D5207C2A 01AA5480
	.long 0xd4490004                                           // 0000001317E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v43, vcc_lo                   // 0000001317EC: 020256FF 0000037F
	s_mov_b32 m0, s11                                          // 0000001317F4: BEFD000B
	s_add_i32 s11, s11, 1                                      // 0000001317F8: 810B810B
	s_or_b32 s10, s4, s10                                      // 0000001317FC: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000131800: BF8903F7
	v_movreld_b32_e32 v3, v44                                  // 000000131804: 7E06852C
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000131808: 917E0A7E
	s_cbranch_execnz 65516                                     // 00000013180C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000131810: 8C7E0A7E
	v_or_b32_e32 v45, s7, v1                                   // 000000131814: 385A0207
	v_dual_mov_b32 v42, v18 :: v_dual_mov_b32 v41, v17         // 000000131818: CA100112 2A280111
	s_mov_b32 s10, 0                                           // 000000131820: BE8A0080
	s_branch 14                                                // 000000131824: BFA0000E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x660>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000131828: 8C7E047E
	.long 0xd7006a29                                           // 00000013182C: D7006A29
	v_cndmask_b32_e32 v1, 0x30000, v41, vcc_lo                 // 000000131830: 020252FF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000131838: BF870001
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 00000013183C: D5207C2A 01AA5480
	s_add_i32 s10, s10, 8                                      // 000000131844: 810A880A
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 000000131848: 916A0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000013184C: BF89FC07
	s_barrier                                                  // 000000131850: BFBD0000
	buffer_gl0_inv                                             // 000000131854: E0AC0000 00000000
	s_cbranch_vccz 720                                         // 00000013185C: BFA302D0 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11a0>
	v_dual_mov_b32 v43, v52 :: v_dual_mov_b32 v44, v50         // 000000131860: CA100134 2B2C0132
	s_mov_b32 s4, 0                                            // 000000131868: BE840080
	s_mov_b32 s11, 0                                           // 00000013186C: BE8B0080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131870: BF870099
	s_mov_b32 m0, s11                                          // 000000131874: BEFD000B
	v_add_nc_u32_e32 v44, 0x80, v44                            // 000000131878: 4A5858FF 00000080
	v_movrels_b32_e32 v46, v3                                  // 000000131880: 7E5C8703
	s_add_i32 s11, s11, 1                                      // 000000131884: 810B810B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000131888: BF8704C2
	v_cmp_lt_u32_e32 vcc_lo, 0x37f, v44                        // 00000013188C: 7C9258FF 0000037F
	ds_store_b32 v43, v46 offset:13056                         // 000000131894: D8343300 00002E2B
	v_add_nc_u32_e32 v43, 0x204, v43                           // 00000013189C: 4A5656FF 00000204
	s_or_b32 s4, vcc_lo, s4                                    // 0000001318A4: 8C04046A
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001318A8: 917E047E
	s_cbranch_execnz 65520                                     // 0000001318AC: BFA6FFF0 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x670>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001318B0: 8C7E047E
	s_cmp_gt_u32 s10, 55                                       // 0000001318B4: BF08B70A
	s_waitcnt lgkmcnt(0)                                       // 0000001318B8: BF89FC07
	s_cselect_b32 s11, -1, 0                                   // 0000001318BC: 980B80C1
	s_barrier                                                  // 0000001318C0: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s11                             // 0000001318C4: 8B6A0B7E
	buffer_gl0_inv                                             // 0000001318C8: E0AC0000 00000000
	s_cbranch_vccnz 32                                         // 0000001318D0: BFA40020 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x754>
	v_dual_mov_b32 v44, v42 :: v_dual_mov_b32 v43, v41         // 0000001318D4: CA10012A 2C2A0129
	v_mov_b32_e32 v46, v50                                     // 0000001318DC: 7E5C0332
	s_mov_b32 s13, 0                                           // 0000001318E0: BE8D0080
	s_mov_b32 s12, 0                                           // 0000001318E4: BE8C0080
	s_nop 0                                                    // 0000001318E8: BF800000
	s_nop 0                                                    // 0000001318EC: BF800000
	s_nop 0                                                    // 0000001318F0: BF800000
	s_nop 0                                                    // 0000001318F4: BF800000
	s_nop 0                                                    // 0000001318F8: BF800000
	s_nop 0                                                    // 0000001318FC: BF800000
	global_load_b32 v47, v[43:44], off                         // 000000131900: DC520000 2F7C002B
	v_add_nc_u32_e32 v46, 0x80, v46                            // 000000131908: 4A5C5CFF 00000080
	.long 0xd7006a2b                                           // 000000131910: D7006A2B
	v_cndmask_b32_e32 v1, 0x6000, v43, vcc_lo                  // 000000131914: 020256FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013191C: BF870191
	v_add_co_ci_u32_e64 v44, null, 0, v44, vcc_lo              // 000000131920: D5207C2C 01AA5880
	.long 0xd4490004                                           // 000000131928: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 00000013192C: 02025CFF 0000037F
	s_mov_b32 m0, s13                                          // 000000131934: BEFD000D
	s_add_i32 s13, s13, 1                                      // 000000131938: 810D810D
	s_or_b32 s12, s4, s12                                      // 00000013193C: 8C0C0C04
	s_waitcnt vmcnt(0)                                         // 000000131940: BF8903F7
	v_movreld_b32_e32 v3, v47                                  // 000000131944: 7E06852F
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000131948: 917E0C7E
	s_cbranch_execnz 65516                                     // 00000013194C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x700>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000131950: 8C7E0C7E
	s_and_saveexec_b32 s4, s1                                  // 000000131954: BE842001
	s_cbranch_execz 65459                                      // 000000131958: BFA5FFB3 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x628>
	ds_load_2addr_b32 v[43:44], v58 offset1:1                  // 00000013195C: D8DC0100 2B00003A
	ds_load_2addr_b32 v[46:47], v58 offset0:2 offset1:3        // 000000131964: D8DC0302 2E00003A
	ds_load_2addr_b32 v[72:73], v58 offset0:4 offset1:5        // 00000013196C: D8DC0504 4800003A
	ds_load_2addr_b32 v[74:75], v58 offset0:6 offset1:7        // 000000131974: D8DC0706 4A00003A
	ds_load_2addr_b32 v[76:77], v11 offset1:17                 // 00000013197C: D8DC1100 4C00000B
	ds_load_2addr_b32 v[78:79], v11 offset0:34 offset1:51      // 000000131984: D8DC3322 4E00000B
	ds_load_2addr_b32 v[80:81], v11 offset0:68 offset1:85      // 00000013198C: D8DC5544 5000000B
	ds_load_2addr_b32 v[82:83], v11 offset0:102 offset1:119    // 000000131994: D8DC7766 5200000B
	ds_load_2addr_b32 v[86:87], v58 offset0:14 offset1:15      // 00000013199C: D8DC0F0E 5600003A
	ds_load_2addr_b32 v[88:89], v11 offset0:136 offset1:153    // 0000001319A4: D8DC9988 5800000B
	ds_load_2addr_b32 v[90:91], v11 offset0:170 offset1:187    // 0000001319AC: D8DCBBAA 5A00000B
	ds_load_2addr_b32 v[92:93], v11 offset0:204 offset1:221    // 0000001319B4: D8DCDDCC 5C00000B
	ds_load_2addr_b32 v[94:95], v11 offset0:238 offset1:255    // 0000001319BC: D8DCFFEE 5E00000B
	v_or_b32_e32 v48, s10, v45                                 // 0000001319C4: 38605A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001319C8: BF870091
	v_mad_u64_u32 v[84:85], null, v48, 48, s[2:3]              // 0000001319CC: D6FE7C54 00096130
	.long 0xd73c0054                                           // 0000001319D4: D73C0054
	v_cndmask_b32_e32 v1, 9, v84, vcc_lo                       // 0000001319D8: 0202A889
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001319DC: BF870091
	.long 0xd7006a54                                           // 0000001319E0: D7006A54
	v_cndmask_b32_e32 v1, v56, v84, vcc_lo                     // 0000001319E4: 0202A938
	v_add_co_ci_u32_e64 v85, null, v57, v85, vcc_lo            // 0000001319E8: D5207C55 01AAAB39
	global_load_b32 v48, v[84:85], off                         // 0000001319F0: DC520000 307C0054
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 0000001319F8: BF890087
	v_fma_f32 v43, -v43, v76, v48                              // 0000001319FC: D613002B 24C2992B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000131A04: BF8700A1
	v_fma_f32 v43, -v44, v77, v43                              // 000000131A08: D613002B 24AE9B2C
	s_waitcnt lgkmcnt(7)                                       // 000000131A10: BF89FC77
	v_fma_f32 v46, -v46, v78, v43                              // 000000131A14: D613002E 24AE9D2E
	ds_load_2addr_b32 v[43:44], v58 offset0:8 offset1:9        // 000000131A1C: D8DC0908 2B00003A
	ds_load_2addr_b32 v[76:77], v58 offset0:10 offset1:11      // 000000131A24: D8DC0B0A 4C00003A
	ds_load_2addr_b32 v[84:85], v58 offset0:12 offset1:13      // 000000131A2C: D8DC0D0C 5400003A
	v_fma_f32 v46, -v47, v79, v46                              // 000000131A34: D613002E 24BA9F2F
	s_waitcnt lgkmcnt(9)                                       // 000000131A3C: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131A40: BF870091
	v_fma_f32 v46, -v72, v80, v46                              // 000000131A44: D613002E 24BAA148
	v_fma_f32 v46, -v73, v81, v46                              // 000000131A4C: D613002E 24BAA349
	s_waitcnt lgkmcnt(8)                                       // 000000131A54: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131A58: BF870091
	v_fma_f32 v46, -v74, v82, v46                              // 000000131A5C: D613002E 24BAA54A
	v_fma_f32 v46, -v75, v83, v46                              // 000000131A64: D613002E 24BAA74B
	s_waitcnt lgkmcnt(2)                                       // 000000131A6C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131A70: BF870091
	v_fma_f32 v43, -v43, v88, v46                              // 000000131A74: D613002B 24BAB12B
	v_fma_f32 v43, -v44, v89, v43                              // 000000131A7C: D613002B 24AEB32C
	s_waitcnt lgkmcnt(1)                                       // 000000131A84: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000131A88: BF870001
	v_fma_f32 v48, -v76, v90, v43                              // 000000131A8C: D6130030 24AEB54C
	ds_load_2addr_b32 v[43:44], v58 offset0:16 offset1:17      // 000000131A94: D8DC1110 2B00003A
	ds_load_2addr_b32 v[46:47], v58 offset0:18 offset1:19      // 000000131A9C: D8DC1312 2E00003A
	ds_load_2addr_b32 v[72:73], v58 offset0:20 offset1:21      // 000000131AA4: D8DC1514 4800003A
	ds_load_2addr_b32 v[74:75], v58 offset0:22 offset1:23      // 000000131AAC: D8DC1716 4A00003A
	ds_load_2addr_b32 v[78:79], v60 offset0:16 offset1:33      // 000000131AB4: D8DC2110 4E00003C
	ds_load_2addr_b32 v[80:81], v60 offset0:50 offset1:67      // 000000131ABC: D8DC4332 5000003C
	ds_load_2addr_b32 v[82:83], v60 offset0:84 offset1:101     // 000000131AC4: D8DC6554 5200003C
	ds_load_2addr_b32 v[88:89], v60 offset0:118 offset1:135    // 000000131ACC: D8DC8776 5800003C
	v_fma_f32 v48, -v77, v91, v48                              // 000000131AD4: D6130030 24C2B74D
	s_waitcnt lgkmcnt(8)                                       // 000000131ADC: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131AE0: BF870091
	v_fma_f32 v48, -v84, v92, v48                              // 000000131AE4: D6130030 24C2B954
	v_fma_f32 v48, -v85, v93, v48                              // 000000131AEC: D6130030 24C2BB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131AF4: BF870091
	v_fma_f32 v48, -v86, v94, v48                              // 000000131AF8: D6130030 24C2BD56
	v_fma_f32 v48, -v87, v95, v48                              // 000000131B00: D6130030 24C2BF57
	s_waitcnt lgkmcnt(3)                                       // 000000131B08: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131B0C: BF870091
	v_fma_f32 v43, -v43, v78, v48                              // 000000131B10: D613002B 24C29D2B
	v_fma_f32 v43, -v44, v79, v43                              // 000000131B18: D613002B 24AE9F2C
	s_waitcnt lgkmcnt(2)                                       // 000000131B20: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000131B24: BF870001
	v_fma_f32 v46, -v46, v80, v43                              // 000000131B28: D613002E 24AEA12E
	ds_load_2addr_b32 v[43:44], v58 offset0:24 offset1:25      // 000000131B30: D8DC1918 2B00003A
	ds_load_2addr_b32 v[76:77], v58 offset0:26 offset1:27      // 000000131B38: D8DC1B1A 4C00003A
	ds_load_2addr_b32 v[78:79], v58 offset0:28 offset1:29      // 000000131B40: D8DC1D1C 4E00003A
	ds_load_2addr_b32 v[84:85], v58 offset0:30 offset1:31      // 000000131B48: D8DC1F1E 5400003A
	ds_load_2addr_b32 v[86:87], v60 offset0:152 offset1:169    // 000000131B50: D8DCA998 5600003C
	ds_load_2addr_b32 v[90:91], v60 offset0:186 offset1:203    // 000000131B58: D8DCCBBA 5A00003C
	ds_load_2addr_b32 v[92:93], v60 offset0:220 offset1:237    // 000000131B60: D8DCEDDC 5C00003C
	ds_load_2addr_b32 v[94:95], v61 offset0:126 offset1:143    // 000000131B68: D8DC8F7E 5E00003D
	v_fma_f32 v46, -v47, v81, v46                              // 000000131B70: D613002E 24BAA32F
	s_waitcnt lgkmcnt(9)                                       // 000000131B78: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131B7C: BF870091
	v_fma_f32 v46, -v72, v82, v46                              // 000000131B80: D613002E 24BAA548
	v_fma_f32 v46, -v73, v83, v46                              // 000000131B88: D613002E 24BAA749
	s_waitcnt lgkmcnt(8)                                       // 000000131B90: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131B94: BF870091
	v_fma_f32 v46, -v74, v88, v46                              // 000000131B98: D613002E 24BAB14A
	v_fma_f32 v46, -v75, v89, v46                              // 000000131BA0: D613002E 24BAB34B
	s_waitcnt lgkmcnt(3)                                       // 000000131BA8: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131BAC: BF870091
	v_fma_f32 v43, -v43, v86, v46                              // 000000131BB0: D613002B 24BAAD2B
	v_fma_f32 v43, -v44, v87, v43                              // 000000131BB8: D613002B 24AEAF2C
	s_waitcnt lgkmcnt(2)                                       // 000000131BC0: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000131BC4: BF870001
	v_fma_f32 v48, -v76, v90, v43                              // 000000131BC8: D6130030 24AEB54C
	ds_load_2addr_b32 v[43:44], v58 offset0:32 offset1:33      // 000000131BD0: D8DC2120 2B00003A
	ds_load_2addr_b32 v[46:47], v58 offset0:34 offset1:35      // 000000131BD8: D8DC2322 2E00003A
	ds_load_2addr_b32 v[72:73], v58 offset0:36 offset1:37      // 000000131BE0: D8DC2524 4800003A
	ds_load_2addr_b32 v[74:75], v58 offset0:38 offset1:39      // 000000131BE8: D8DC2726 4A00003A
	ds_load_2addr_b32 v[80:81], v62 offset0:32 offset1:49      // 000000131BF0: D8DC3120 5000003E
	ds_load_2addr_b32 v[82:83], v62 offset0:66 offset1:83      // 000000131BF8: D8DC5342 5200003E
	ds_load_2addr_b32 v[86:87], v62 offset0:100 offset1:117    // 000000131C00: D8DC7564 5600003E
	ds_load_2addr_b32 v[88:89], v62 offset0:134 offset1:151    // 000000131C08: D8DC9786 5800003E
	v_fma_f32 v48, -v77, v91, v48                              // 000000131C10: D6130030 24C2B74D
	s_waitcnt lgkmcnt(9)                                       // 000000131C18: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131C1C: BF870091
	v_fma_f32 v48, -v78, v92, v48                              // 000000131C20: D6130030 24C2B94E
	v_fma_f32 v48, -v79, v93, v48                              // 000000131C28: D6130030 24C2BB4F
	s_waitcnt lgkmcnt(8)                                       // 000000131C30: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131C34: BF870091
	v_fma_f32 v48, -v84, v94, v48                              // 000000131C38: D6130030 24C2BD54
	v_fma_f32 v48, -v85, v95, v48                              // 000000131C40: D6130030 24C2BF55
	s_waitcnt lgkmcnt(3)                                       // 000000131C48: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131C4C: BF870091
	v_fma_f32 v43, -v43, v80, v48                              // 000000131C50: D613002B 24C2A12B
	v_fma_f32 v43, -v44, v81, v43                              // 000000131C58: D613002B 24AEA32C
	s_waitcnt lgkmcnt(2)                                       // 000000131C60: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000131C64: BF870001
	v_fma_f32 v46, -v46, v82, v43                              // 000000131C68: D613002E 24AEA52E
	ds_load_2addr_b32 v[43:44], v58 offset0:40 offset1:41      // 000000131C70: D8DC2928 2B00003A
	ds_load_2addr_b32 v[76:77], v58 offset0:42 offset1:43      // 000000131C78: D8DC2B2A 4C00003A
	ds_load_2addr_b32 v[78:79], v58 offset0:44 offset1:45      // 000000131C80: D8DC2D2C 4E00003A
	ds_load_2addr_b32 v[80:81], v58 offset0:46 offset1:47      // 000000131C88: D8DC2F2E 5000003A
	ds_load_2addr_b32 v[84:85], v62 offset0:168 offset1:185    // 000000131C90: D8DCB9A8 5400003E
	ds_load_2addr_b32 v[90:91], v62 offset0:202 offset1:219    // 000000131C98: D8DCDBCA 5A00003E
	ds_load_2addr_b32 v[92:93], v62 offset0:236 offset1:253    // 000000131CA0: D8DCFDEC 5C00003E
	ds_load_2addr_b32 v[94:95], v63 offset0:14 offset1:31      // 000000131CA8: D8DC1F0E 5E00003F
	v_fma_f32 v46, -v47, v83, v46                              // 000000131CB0: D613002E 24BAA72F
	s_waitcnt lgkmcnt(9)                                       // 000000131CB8: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131CBC: BF870091
	v_fma_f32 v46, -v72, v86, v46                              // 000000131CC0: D613002E 24BAAD48
	v_fma_f32 v46, -v73, v87, v46                              // 000000131CC8: D613002E 24BAAF49
	s_waitcnt lgkmcnt(8)                                       // 000000131CD0: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131CD4: BF870091
	v_fma_f32 v46, -v74, v88, v46                              // 000000131CD8: D613002E 24BAB14A
	v_fma_f32 v46, -v75, v89, v46                              // 000000131CE0: D613002E 24BAB34B
	s_waitcnt lgkmcnt(3)                                       // 000000131CE8: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131CEC: BF870091
	v_fma_f32 v43, -v43, v84, v46                              // 000000131CF0: D613002B 24BAA92B
	v_fma_f32 v43, -v44, v85, v43                              // 000000131CF8: D613002B 24AEAB2C
	s_waitcnt lgkmcnt(2)                                       // 000000131D00: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000131D04: BF870001
	v_fma_f32 v48, -v76, v90, v43                              // 000000131D08: D6130030 24AEB54C
	ds_load_2addr_b32 v[43:44], v58 offset0:48 offset1:49      // 000000131D10: D8DC3130 2B00003A
	ds_load_2addr_b32 v[46:47], v58 offset0:50 offset1:51      // 000000131D18: D8DC3332 2E00003A
	ds_load_2addr_b32 v[72:73], v58 offset0:52 offset1:53      // 000000131D20: D8DC3534 4800003A
	ds_load_2addr_b32 v[74:75], v58 offset0:54 offset1:55      // 000000131D28: D8DC3736 4A00003A
	ds_load_2addr_b32 v[82:83], v63 offset0:48 offset1:65      // 000000131D30: D8DC4130 5200003F
	ds_load_2addr_b32 v[84:85], v63 offset0:82 offset1:99      // 000000131D38: D8DC6352 5400003F
	ds_load_2addr_b32 v[86:87], v63 offset0:116 offset1:133    // 000000131D40: D8DC8574 5600003F
	ds_load_2addr_b32 v[88:89], v63 offset0:150 offset1:167    // 000000131D48: D8DCA796 5800003F
	v_fma_f32 v48, -v77, v91, v48                              // 000000131D50: D6130030 24C2B74D
	s_waitcnt lgkmcnt(9)                                       // 000000131D58: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131D5C: BF870091
	v_fma_f32 v48, -v78, v92, v48                              // 000000131D60: D6130030 24C2B94E
	v_fma_f32 v48, -v79, v93, v48                              // 000000131D68: D6130030 24C2BB4F
	s_waitcnt lgkmcnt(8)                                       // 000000131D70: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131D74: BF870091
	v_fma_f32 v48, -v80, v94, v48                              // 000000131D78: D6130030 24C2BD50
	v_fma_f32 v48, -v81, v95, v48                              // 000000131D80: D6130030 24C2BF51
	s_waitcnt lgkmcnt(3)                                       // 000000131D88: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131D8C: BF870091
	v_fma_f32 v43, -v43, v82, v48                              // 000000131D90: D613002B 24C2A52B
	v_fma_f32 v43, -v44, v83, v43                              // 000000131D98: D613002B 24AEA72C
	s_waitcnt lgkmcnt(2)                                       // 000000131DA0: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000131DA4: BF870001
	v_fma_f32 v46, -v46, v84, v43                              // 000000131DA8: D613002E 24AEA92E
	ds_load_2addr_b32 v[43:44], v58 offset0:56 offset1:57      // 000000131DB0: D8DC3938 2B00003A
	ds_load_2addr_b32 v[76:77], v58 offset0:58 offset1:59      // 000000131DB8: D8DC3B3A 4C00003A
	ds_load_2addr_b32 v[78:79], v58 offset0:60 offset1:61      // 000000131DC0: D8DC3D3C 4E00003A
	ds_load_2addr_b32 v[80:81], v58 offset0:62 offset1:63      // 000000131DC8: D8DC3F3E 5000003A
	ds_load_2addr_b32 v[82:83], v63 offset0:184 offset1:201    // 000000131DD0: D8DCC9B8 5200003F
	ds_load_2addr_b32 v[90:91], v63 offset0:218 offset1:235    // 000000131DD8: D8DCEBDA 5A00003F
	ds_load_2addr_b32 v[92:93], v64 offset0:124 offset1:141    // 000000131DE0: D8DC8D7C 5C000040
	ds_load_2addr_b32 v[94:95], v65 offset0:30 offset1:47      // 000000131DE8: D8DC2F1E 5E000041
	v_fma_f32 v46, -v47, v85, v46                              // 000000131DF0: D613002E 24BAAB2F
	s_waitcnt lgkmcnt(9)                                       // 000000131DF8: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131DFC: BF870091
	v_fma_f32 v46, -v72, v86, v46                              // 000000131E00: D613002E 24BAAD48
	v_fma_f32 v46, -v73, v87, v46                              // 000000131E08: D613002E 24BAAF49
	s_waitcnt lgkmcnt(8)                                       // 000000131E10: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131E14: BF870091
	v_fma_f32 v46, -v74, v88, v46                              // 000000131E18: D613002E 24BAB14A
	v_fma_f32 v46, -v75, v89, v46                              // 000000131E20: D613002E 24BAB34B
	s_waitcnt lgkmcnt(3)                                       // 000000131E28: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131E2C: BF870091
	v_fma_f32 v43, -v43, v82, v46                              // 000000131E30: D613002B 24BAA52B
	v_fma_f32 v43, -v44, v83, v43                              // 000000131E38: D613002B 24AEA72C
	s_waitcnt lgkmcnt(2)                                       // 000000131E40: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000131E44: BF870001
	v_fma_f32 v48, -v76, v90, v43                              // 000000131E48: D6130030 24AEB54C
	ds_load_2addr_b32 v[43:44], v58 offset0:64 offset1:65      // 000000131E50: D8DC4140 2B00003A
	ds_load_2addr_b32 v[46:47], v58 offset0:66 offset1:67      // 000000131E58: D8DC4342 2E00003A
	ds_load_2addr_b32 v[72:73], v58 offset0:68 offset1:69      // 000000131E60: D8DC4544 4800003A
	ds_load_2addr_b32 v[74:75], v58 offset0:70 offset1:71      // 000000131E68: D8DC4746 4A00003A
	ds_load_2addr_b32 v[82:83], v65 offset0:64 offset1:81      // 000000131E70: D8DC5140 52000041
	ds_load_2addr_b32 v[84:85], v65 offset0:98 offset1:115     // 000000131E78: D8DC7362 54000041
	ds_load_2addr_b32 v[86:87], v65 offset0:132 offset1:149    // 000000131E80: D8DC9584 56000041
	ds_load_2addr_b32 v[88:89], v65 offset0:166 offset1:183    // 000000131E88: D8DCB7A6 58000041
	v_fma_f32 v48, -v77, v91, v48                              // 000000131E90: D6130030 24C2B74D
	s_waitcnt lgkmcnt(9)                                       // 000000131E98: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131E9C: BF870091
	v_fma_f32 v48, -v78, v92, v48                              // 000000131EA0: D6130030 24C2B94E
	v_fma_f32 v48, -v79, v93, v48                              // 000000131EA8: D6130030 24C2BB4F
	s_waitcnt lgkmcnt(8)                                       // 000000131EB0: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131EB4: BF870091
	v_fma_f32 v48, -v80, v94, v48                              // 000000131EB8: D6130030 24C2BD50
	v_fma_f32 v48, -v81, v95, v48                              // 000000131EC0: D6130030 24C2BF51
	s_waitcnt lgkmcnt(3)                                       // 000000131EC8: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131ECC: BF870091
	v_fma_f32 v43, -v43, v82, v48                              // 000000131ED0: D613002B 24C2A52B
	v_fma_f32 v43, -v44, v83, v43                              // 000000131ED8: D613002B 24AEA72C
	s_waitcnt lgkmcnt(2)                                       // 000000131EE0: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000131EE4: BF870001
	v_fma_f32 v46, -v46, v84, v43                              // 000000131EE8: D613002E 24AEA92E
	ds_load_2addr_b32 v[43:44], v58 offset0:72 offset1:73      // 000000131EF0: D8DC4948 2B00003A
	ds_load_2addr_b32 v[76:77], v58 offset0:74 offset1:75      // 000000131EF8: D8DC4B4A 4C00003A
	ds_load_2addr_b32 v[78:79], v58 offset0:76 offset1:77      // 000000131F00: D8DC4D4C 4E00003A
	ds_load_2addr_b32 v[80:81], v58 offset0:78 offset1:79      // 000000131F08: D8DC4F4E 5000003A
	ds_load_2addr_b32 v[82:83], v65 offset0:200 offset1:217    // 000000131F10: D8DCD9C8 52000041
	ds_load_2addr_b32 v[90:91], v65 offset0:234 offset1:251    // 000000131F18: D8DCFBEA 5A000041
	ds_load_2addr_b32 v[92:93], v66 offset0:12 offset1:29      // 000000131F20: D8DC1D0C 5C000042
	ds_load_2addr_b32 v[94:95], v66 offset0:46 offset1:63      // 000000131F28: D8DC3F2E 5E000042
	v_fma_f32 v46, -v47, v85, v46                              // 000000131F30: D613002E 24BAAB2F
	s_waitcnt lgkmcnt(9)                                       // 000000131F38: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131F3C: BF870091
	v_fma_f32 v46, -v72, v86, v46                              // 000000131F40: D613002E 24BAAD48
	v_fma_f32 v46, -v73, v87, v46                              // 000000131F48: D613002E 24BAAF49
	s_waitcnt lgkmcnt(8)                                       // 000000131F50: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131F54: BF870091
	v_fma_f32 v46, -v74, v88, v46                              // 000000131F58: D613002E 24BAB14A
	v_fma_f32 v46, -v75, v89, v46                              // 000000131F60: D613002E 24BAB34B
	s_waitcnt lgkmcnt(3)                                       // 000000131F68: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131F6C: BF870091
	v_fma_f32 v43, -v43, v82, v46                              // 000000131F70: D613002B 24BAA52B
	v_fma_f32 v43, -v44, v83, v43                              // 000000131F78: D613002B 24AEA72C
	s_waitcnt lgkmcnt(2)                                       // 000000131F80: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000131F84: BF870001
	v_fma_f32 v48, -v76, v90, v43                              // 000000131F88: D6130030 24AEB54C
	ds_load_2addr_b32 v[43:44], v58 offset0:80 offset1:81      // 000000131F90: D8DC5150 2B00003A
	ds_load_2addr_b32 v[46:47], v58 offset0:82 offset1:83      // 000000131F98: D8DC5352 2E00003A
	ds_load_2addr_b32 v[72:73], v58 offset0:84 offset1:85      // 000000131FA0: D8DC5554 4800003A
	ds_load_2addr_b32 v[74:75], v58 offset0:86 offset1:87      // 000000131FA8: D8DC5756 4A00003A
	ds_load_2addr_b32 v[82:83], v66 offset0:80 offset1:97      // 000000131FB0: D8DC6150 52000042
	ds_load_2addr_b32 v[84:85], v66 offset0:114 offset1:131    // 000000131FB8: D8DC8372 54000042
	ds_load_2addr_b32 v[86:87], v66 offset0:148 offset1:165    // 000000131FC0: D8DCA594 56000042
	ds_load_2addr_b32 v[88:89], v66 offset0:182 offset1:199    // 000000131FC8: D8DCC7B6 58000042
	v_fma_f32 v48, -v77, v91, v48                              // 000000131FD0: D6130030 24C2B74D
	s_waitcnt lgkmcnt(9)                                       // 000000131FD8: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131FDC: BF870091
	v_fma_f32 v48, -v78, v92, v48                              // 000000131FE0: D6130030 24C2B94E
	v_fma_f32 v48, -v79, v93, v48                              // 000000131FE8: D6130030 24C2BB4F
	s_waitcnt lgkmcnt(8)                                       // 000000131FF0: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131FF4: BF870091
	v_fma_f32 v48, -v80, v94, v48                              // 000000131FF8: D6130030 24C2BD50
	v_fma_f32 v48, -v81, v95, v48                              // 000000132000: D6130030 24C2BF51
	s_waitcnt lgkmcnt(3)                                       // 000000132008: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013200C: BF870091
	v_fma_f32 v43, -v43, v82, v48                              // 000000132010: D613002B 24C2A52B
	v_fma_f32 v43, -v44, v83, v43                              // 000000132018: D613002B 24AEA72C
	s_waitcnt lgkmcnt(2)                                       // 000000132020: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132024: BF870001
	v_fma_f32 v46, -v46, v84, v43                              // 000000132028: D613002E 24AEA92E
	ds_load_2addr_b32 v[43:44], v58 offset0:88 offset1:89      // 000000132030: D8DC5958 2B00003A
	ds_load_2addr_b32 v[76:77], v58 offset0:90 offset1:91      // 000000132038: D8DC5B5A 4C00003A
	ds_load_2addr_b32 v[78:79], v58 offset0:92 offset1:93      // 000000132040: D8DC5D5C 4E00003A
	ds_load_2addr_b32 v[80:81], v58 offset0:94 offset1:95      // 000000132048: D8DC5F5E 5000003A
	ds_load_2addr_b32 v[82:83], v66 offset0:216 offset1:233    // 000000132050: D8DCE9D8 52000042
	ds_load_2addr_b32 v[90:91], v67 offset0:122 offset1:139    // 000000132058: D8DC8B7A 5A000043
	ds_load_2addr_b32 v[92:93], v68 offset0:28 offset1:45      // 000000132060: D8DC2D1C 5C000044
	ds_load_2addr_b32 v[94:95], v68 offset0:62 offset1:79      // 000000132068: D8DC4F3E 5E000044
	v_fma_f32 v46, -v47, v85, v46                              // 000000132070: D613002E 24BAAB2F
	s_waitcnt lgkmcnt(9)                                       // 000000132078: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013207C: BF870091
	v_fma_f32 v46, -v72, v86, v46                              // 000000132080: D613002E 24BAAD48
	v_fma_f32 v46, -v73, v87, v46                              // 000000132088: D613002E 24BAAF49
	s_waitcnt lgkmcnt(8)                                       // 000000132090: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132094: BF870091
	v_fma_f32 v46, -v74, v88, v46                              // 000000132098: D613002E 24BAB14A
	v_fma_f32 v46, -v75, v89, v46                              // 0000001320A0: D613002E 24BAB34B
	s_waitcnt lgkmcnt(3)                                       // 0000001320A8: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001320AC: BF870091
	v_fma_f32 v43, -v43, v82, v46                              // 0000001320B0: D613002B 24BAA52B
	v_fma_f32 v43, -v44, v83, v43                              // 0000001320B8: D613002B 24AEA72C
	s_waitcnt lgkmcnt(2)                                       // 0000001320C0: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001320C4: BF870001
	v_fma_f32 v48, -v76, v90, v43                              // 0000001320C8: D6130030 24AEB54C
	ds_load_2addr_b32 v[43:44], v58 offset0:96 offset1:97      // 0000001320D0: D8DC6160 2B00003A
	ds_load_2addr_b32 v[46:47], v58 offset0:98 offset1:99      // 0000001320D8: D8DC6362 2E00003A
	ds_load_2addr_b32 v[72:73], v58 offset0:100 offset1:101    // 0000001320E0: D8DC6564 4800003A
	ds_load_2addr_b32 v[74:75], v58 offset0:102 offset1:103    // 0000001320E8: D8DC6766 4A00003A
	ds_load_2addr_b32 v[82:83], v68 offset0:96 offset1:113     // 0000001320F0: D8DC7160 52000044
	ds_load_2addr_b32 v[84:85], v68 offset0:130 offset1:147    // 0000001320F8: D8DC9382 54000044
	ds_load_2addr_b32 v[86:87], v68 offset0:164 offset1:181    // 000000132100: D8DCB5A4 56000044
	ds_load_2addr_b32 v[88:89], v68 offset0:198 offset1:215    // 000000132108: D8DCD7C6 58000044
	v_fma_f32 v48, -v77, v91, v48                              // 000000132110: D6130030 24C2B74D
	s_waitcnt lgkmcnt(9)                                       // 000000132118: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013211C: BF870091
	v_fma_f32 v48, -v78, v92, v48                              // 000000132120: D6130030 24C2B94E
	v_fma_f32 v48, -v79, v93, v48                              // 000000132128: D6130030 24C2BB4F
	s_waitcnt lgkmcnt(8)                                       // 000000132130: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132134: BF870091
	v_fma_f32 v48, -v80, v94, v48                              // 000000132138: D6130030 24C2BD50
	v_fma_f32 v48, -v81, v95, v48                              // 000000132140: D6130030 24C2BF51
	s_waitcnt lgkmcnt(3)                                       // 000000132148: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013214C: BF870091
	v_fma_f32 v43, -v43, v82, v48                              // 000000132150: D613002B 24C2A52B
	v_fma_f32 v43, -v44, v83, v43                              // 000000132158: D613002B 24AEA72C
	s_waitcnt lgkmcnt(2)                                       // 000000132160: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132164: BF870001
	v_fma_f32 v46, -v46, v84, v43                              // 000000132168: D613002E 24AEA92E
	ds_load_2addr_b32 v[43:44], v58 offset0:104 offset1:105    // 000000132170: D8DC6968 2B00003A
	ds_load_2addr_b32 v[76:77], v58 offset0:106 offset1:107    // 000000132178: D8DC6B6A 4C00003A
	ds_load_2addr_b32 v[78:79], v58 offset0:108 offset1:109    // 000000132180: D8DC6D6C 4E00003A
	ds_load_2addr_b32 v[80:81], v58 offset0:110 offset1:111    // 000000132188: D8DC6F6E 5000003A
	ds_load_2addr_b32 v[82:83], v68 offset0:232 offset1:249    // 000000132190: D8DCF9E8 52000044
	ds_load_2addr_b32 v[90:91], v69 offset0:10 offset1:27      // 000000132198: D8DC1B0A 5A000045
	ds_load_2addr_b32 v[92:93], v69 offset0:44 offset1:61      // 0000001321A0: D8DC3D2C 5C000045
	ds_load_2addr_b32 v[94:95], v69 offset0:78 offset1:95      // 0000001321A8: D8DC5F4E 5E000045
	v_fma_f32 v46, -v47, v85, v46                              // 0000001321B0: D613002E 24BAAB2F
	s_waitcnt lgkmcnt(9)                                       // 0000001321B8: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001321BC: BF870091
	v_fma_f32 v46, -v72, v86, v46                              // 0000001321C0: D613002E 24BAAD48
	v_fma_f32 v46, -v73, v87, v46                              // 0000001321C8: D613002E 24BAAF49
	s_waitcnt lgkmcnt(8)                                       // 0000001321D0: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001321D4: BF870091
	v_fma_f32 v46, -v74, v88, v46                              // 0000001321D8: D613002E 24BAB14A
	v_fma_f32 v46, -v75, v89, v46                              // 0000001321E0: D613002E 24BAB34B
	s_waitcnt lgkmcnt(3)                                       // 0000001321E8: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001321EC: BF870091
	v_fma_f32 v43, -v43, v82, v46                              // 0000001321F0: D613002B 24BAA52B
	v_fma_f32 v43, -v44, v83, v43                              // 0000001321F8: D613002B 24AEA72C
	s_waitcnt lgkmcnt(2)                                       // 000000132200: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132204: BF870001
	v_fma_f32 v48, -v76, v90, v43                              // 000000132208: D6130030 24AEB54C
	ds_load_2addr_b32 v[43:44], v58 offset0:112 offset1:113    // 000000132210: D8DC7170 2B00003A
	ds_load_2addr_b32 v[46:47], v58 offset0:114 offset1:115    // 000000132218: D8DC7372 2E00003A
	ds_load_2addr_b32 v[72:73], v58 offset0:116 offset1:117    // 000000132220: D8DC7574 4800003A
	ds_load_2addr_b32 v[74:75], v58 offset0:118 offset1:119    // 000000132228: D8DC7776 4A00003A
	ds_load_2addr_b32 v[82:83], v69 offset0:112 offset1:129    // 000000132230: D8DC8170 52000045
	ds_load_2addr_b32 v[84:85], v69 offset0:146 offset1:163    // 000000132238: D8DCA392 54000045
	ds_load_2addr_b32 v[86:87], v69 offset0:180 offset1:197    // 000000132240: D8DCC5B4 56000045
	ds_load_2addr_b32 v[88:89], v69 offset0:214 offset1:231    // 000000132248: D8DCE7D6 58000045
	v_fma_f32 v48, -v77, v91, v48                              // 000000132250: D6130030 24C2B74D
	s_waitcnt lgkmcnt(9)                                       // 000000132258: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013225C: BF870091
	v_fma_f32 v48, -v78, v92, v48                              // 000000132260: D6130030 24C2B94E
	v_fma_f32 v48, -v79, v93, v48                              // 000000132268: D6130030 24C2BB4F
	s_waitcnt lgkmcnt(8)                                       // 000000132270: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132274: BF870091
	v_fma_f32 v48, -v80, v94, v48                              // 000000132278: D6130030 24C2BD50
	v_fma_f32 v48, -v81, v95, v48                              // 000000132280: D6130030 24C2BF51
	s_waitcnt lgkmcnt(3)                                       // 000000132288: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013228C: BF870091
	v_fma_f32 v43, -v43, v82, v48                              // 000000132290: D613002B 24C2A52B
	v_fma_f32 v43, -v44, v83, v43                              // 000000132298: D613002B 24AEA72C
	s_waitcnt lgkmcnt(2)                                       // 0000001322A0: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001322A4: BF870001
	v_fma_f32 v46, -v46, v84, v43                              // 0000001322A8: D613002E 24AEA92E
	ds_load_2addr_b32 v[43:44], v58 offset0:120 offset1:121    // 0000001322B0: D8DC7978 2B00003A
	ds_load_2addr_b32 v[76:77], v58 offset0:122 offset1:123    // 0000001322B8: D8DC7B7A 4C00003A
	ds_load_2addr_b32 v[78:79], v58 offset0:124 offset1:125    // 0000001322C0: D8DC7D7C 4E00003A
	ds_load_2addr_b32 v[80:81], v58 offset0:126 offset1:127    // 0000001322C8: D8DC7F7E 5000003A
	ds_load_2addr_b32 v[82:83], v70 offset0:120 offset1:137    // 0000001322D0: D8DC8978 52000046
	ds_load_2addr_b32 v[90:91], v71 offset0:26 offset1:43      // 0000001322D8: D8DC2B1A 5A000047
	ds_load_2addr_b32 v[92:93], v71 offset0:60 offset1:77      // 0000001322E0: D8DC4D3C 5C000047
	ds_load_2addr_b32 v[94:95], v71 offset0:94 offset1:111     // 0000001322E8: D8DC6F5E 5E000047
	v_fma_f32 v46, -v47, v85, v46                              // 0000001322F0: D613002E 24BAAB2F
	s_waitcnt lgkmcnt(9)                                       // 0000001322F8: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001322FC: BF870091
	v_fma_f32 v46, -v72, v86, v46                              // 000000132300: D613002E 24BAAD48
	v_fma_f32 v46, -v73, v87, v46                              // 000000132308: D613002E 24BAAF49
	s_waitcnt lgkmcnt(8)                                       // 000000132310: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132314: BF870091
	v_fma_f32 v46, -v74, v88, v46                              // 000000132318: D613002E 24BAB14A
	v_fma_f32 v46, -v75, v89, v46                              // 000000132320: D613002E 24BAB34B
	s_waitcnt lgkmcnt(3)                                       // 000000132328: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013232C: BF870091
	v_fma_f32 v43, -v43, v82, v46                              // 000000132330: D613002B 24BAA52B
	v_fma_f32 v43, -v44, v83, v43                              // 000000132338: D613002B 24AEA72C
	s_waitcnt lgkmcnt(2)                                       // 000000132340: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132344: BF870091
	v_fma_f32 v43, -v76, v90, v43                              // 000000132348: D613002B 24AEB54C
	v_fma_f32 v43, -v77, v91, v43                              // 000000132350: D613002B 24AEB74D
	s_waitcnt lgkmcnt(1)                                       // 000000132358: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013235C: BF870091
	v_fma_f32 v43, -v78, v92, v43                              // 000000132360: D613002B 24AEB94E
	v_fma_f32 v43, -v79, v93, v43                              // 000000132368: D613002B 24AEBB4F
	s_waitcnt lgkmcnt(0)                                       // 000000132370: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132374: BF870121
	v_fma_f32 v46, -v80, v94, v43                              // 000000132378: D613002E 24AEBD50
	v_mad_u64_u32 v[43:44], null, 0x44, s10, v[12:13]          // 000000132380: D6FE7C2B 043014FF 00000044
	v_fma_f32 v44, -v81, v95, v46                              // 00000013238C: D613002C 24BABF51
	ds_store_b32 v43, v44                                      // 000000132394: D8340000 00002C2B
	s_branch 64802                                             // 00000013239C: BFA0FD22 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x628>
	v_dual_mov_b32 v42, v20 :: v_dual_mov_b32 v41, v19         // 0000001323A0: CA100114 2A280113
	v_mov_b32_e32 v43, v50                                     // 0000001323A8: 7E560332
	s_mov_b32 s11, 0                                           // 0000001323AC: BE8B0080
	s_mov_b32 s10, 0                                           // 0000001323B0: BE8A0080
	s_nop 0                                                    // 0000001323B4: BF800000
	s_nop 0                                                    // 0000001323B8: BF800000
	s_nop 0                                                    // 0000001323BC: BF800000
	global_load_b32 v44, v[41:42], off                         // 0000001323C0: DC520000 2C7C0029
	v_add_nc_u32_e32 v43, 0x80, v43                            // 0000001323C8: 4A5656FF 00000080
	.long 0xd7006a29                                           // 0000001323D0: D7006A29
	v_cndmask_b32_e32 v1, 0x6000, v41, vcc_lo                  // 0000001323D4: 020252FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001323DC: BF870191
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 0000001323E0: D5207C2A 01AA5480
	.long 0xd4490004                                           // 0000001323E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v43, vcc_lo                   // 0000001323EC: 020256FF 0000037F
	s_mov_b32 m0, s11                                          // 0000001323F4: BEFD000B
	s_add_i32 s11, s11, 1                                      // 0000001323F8: 810B810B
	s_or_b32 s10, s4, s10                                      // 0000001323FC: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000132400: BF8903F7
	v_movreld_b32_e32 v3, v44                                  // 000000132404: 7E06852C
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000132408: 917E0A7E
	s_cbranch_execnz 65516                                     // 00000013240C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000132410: 8C7E0A7E
	v_mov_b32_e32 v42, v24                                     // 000000132414: 7E540318
	v_dual_mov_b32 v44, v22 :: v_dual_mov_b32 v41, v23         // 000000132418: CA100116 2C280117
	v_mov_b32_e32 v43, v21                                     // 000000132420: 7E560315
	v_mov_b32_e32 v47, v55                                     // 000000132424: 7E5E0337
	s_mov_b32 s10, 0                                           // 000000132428: BE8A0080
	s_branch 20                                                // 00000013242C: BFA00014 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1280>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000132430: 8C7E0C7E
	.long 0xd7006a2b                                           // 000000132434: D7006A2B
	v_cndmask_b32_e32 v1, 0x30000, v43, vcc_lo                 // 000000132438: 020256FF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132440: BF870001
	v_add_co_ci_u32_e64 v44, null, 0, v44, vcc_lo              // 000000132444: D5207C2C 01AA5880
	.long 0xd7006a29                                           // 00000013244C: D7006A29
	v_cndmask_b32_e32 v1, 0x800, v41, vcc_lo                   // 000000132450: 020252FF 00000800
	v_add_nc_u32_e32 v47, 8, v47                               // 000000132458: 4A5E5E88
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 00000013245C: D5207C2A 01AA5480
	s_add_i32 s10, s10, 8                                      // 000000132464: 810A880A
	s_and_b32 vcc_lo, exec_lo, s11                             // 000000132468: 8B6A0B7E
	s_waitcnt_vscnt null, 0x0                                  // 00000013246C: BC7C0000
	s_barrier                                                  // 000000132470: BFBD0000
	buffer_gl0_inv                                             // 000000132474: E0AC0000 00000000
	s_cbranch_vccnz 640                                        // 00000013247C: BFA40280 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c80>
	v_dual_mov_b32 v45, v52 :: v_dual_mov_b32 v46, v50         // 000000132480: CA100134 2D2E0132
	s_mov_b32 s4, 0                                            // 000000132488: BE840080
	s_mov_b32 s11, 0                                           // 00000013248C: BE8B0080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132490: BF870099
	s_mov_b32 m0, s11                                          // 000000132494: BEFD000B
	v_add_nc_u32_e32 v46, 0x80, v46                            // 000000132498: 4A5C5CFF 00000080
	v_movrels_b32_e32 v48, v3                                  // 0000001324A0: 7E608703
	s_add_i32 s11, s11, 1                                      // 0000001324A4: 810B810B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000001324A8: BF8704C2
	v_cmp_lt_u32_e32 vcc_lo, 0x37f, v46                        // 0000001324AC: 7C925CFF 0000037F
	ds_store_b32 v45, v48 offset:13056                         // 0000001324B4: D8343300 0000302D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 0000001324BC: 4A5A5AFF 00000204
	s_or_b32 s4, vcc_lo, s4                                    // 0000001324C4: 8C04046A
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001324C8: 917E047E
	s_cbranch_execnz 65520                                     // 0000001324CC: BFA6FFF0 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1290>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001324D0: 8C7E047E
	s_cmp_gt_u32 s10, 55                                       // 0000001324D4: BF08B70A
	s_waitcnt lgkmcnt(0)                                       // 0000001324D8: BF89FC07
	s_cselect_b32 s11, -1, 0                                   // 0000001324DC: 980B80C1
	s_barrier                                                  // 0000001324E0: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s11                             // 0000001324E4: 8B6A0B7E
	buffer_gl0_inv                                             // 0000001324E8: E0AC0000 00000000
	s_cbranch_vccnz 40                                         // 0000001324F0: BFA40028 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1394>
	v_dual_mov_b32 v46, v44 :: v_dual_mov_b32 v45, v43         // 0000001324F4: CA10012C 2E2C012B
	v_mov_b32_e32 v48, v50                                     // 0000001324FC: 7E600332
	s_mov_b32 s13, 0                                           // 000000132500: BE8D0080
	s_mov_b32 s12, 0                                           // 000000132504: BE8C0080
	s_nop 0                                                    // 000000132508: BF800000
	s_nop 0                                                    // 00000013250C: BF800000
	s_nop 0                                                    // 000000132510: BF800000
	s_nop 0                                                    // 000000132514: BF800000
	s_nop 0                                                    // 000000132518: BF800000
	s_nop 0                                                    // 00000013251C: BF800000
	s_nop 0                                                    // 000000132520: BF800000
	s_nop 0                                                    // 000000132524: BF800000
	s_nop 0                                                    // 000000132528: BF800000
	s_nop 0                                                    // 00000013252C: BF800000
	s_nop 0                                                    // 000000132530: BF800000
	s_nop 0                                                    // 000000132534: BF800000
	s_nop 0                                                    // 000000132538: BF800000
	s_nop 0                                                    // 00000013253C: BF800000
	global_load_b32 v72, v[45:46], off                         // 000000132540: DC520000 487C002D
	v_add_nc_u32_e32 v48, 0x80, v48                            // 000000132548: 4A6060FF 00000080
	.long 0xd7006a2d                                           // 000000132550: D7006A2D
	v_cndmask_b32_e32 v1, 0x6000, v45, vcc_lo                  // 000000132554: 02025AFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013255C: BF870191
	v_add_co_ci_u32_e64 v46, null, 0, v46, vcc_lo              // 000000132560: D5207C2E 01AA5C80
	.long 0xd4490004                                           // 000000132568: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v48, vcc_lo                   // 00000013256C: 020260FF 0000037F
	s_mov_b32 m0, s13                                          // 000000132574: BEFD000D
	s_add_i32 s13, s13, 1                                      // 000000132578: 810D810D
	s_or_b32 s12, s4, s12                                      // 00000013257C: 8C0C0C04
	s_waitcnt vmcnt(0)                                         // 000000132580: BF8903F7
	v_movreld_b32_e32 v3, v72                                  // 000000132584: 7E068548
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000132588: 917E0C7E
	s_cbranch_execnz 65516                                     // 00000013258C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1340>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000132590: 8C7E0C7E
	s_and_saveexec_b32 s12, s1                                 // 000000132594: BE8C2001
	s_cbranch_execz 65445                                      // 000000132598: BFA5FFA5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1230>
	v_or_b32_e32 v45, s10, v1                                  // 00000013259C: 385A020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001325A0: BF870091
	v_or_b32_e32 v48, s7, v45                                  // 0000001325A4: 38605A07
	v_cmp_gt_i32_e32 vcc_lo, s30, v48                          // 0000001325A8: 7C88601E
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000001325AC: 8B7E6A7E
	s_cbranch_execz 65439                                      // 0000001325B0: BFA5FF9F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1230>
	ds_load_2addr_b32 v[72:73], v58 offset1:1                  // 0000001325B4: D8DC0100 4800003A
	ds_load_2addr_b32 v[74:75], v11 offset1:17                 // 0000001325BC: D8DC1100 4A00000B
	ds_load_2addr_b32 v[76:77], v58 offset0:2 offset1:3        // 0000001325C4: D8DC0302 4C00003A
	ds_load_2addr_b32 v[78:79], v11 offset0:34 offset1:51      // 0000001325CC: D8DC3322 4E00000B
	ds_load_2addr_b32 v[80:81], v58 offset0:4 offset1:5        // 0000001325D4: D8DC0504 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:6 offset1:7        // 0000001325DC: D8DC0706 5200003A
	ds_load_2addr_b32 v[84:85], v11 offset0:68 offset1:85      // 0000001325E4: D8DC5544 5400000B
	ds_load_2addr_b32 v[86:87], v11 offset0:102 offset1:119    // 0000001325EC: D8DC7766 5600000B
	s_mov_b32 s13, 0                                           // 0000001325F4: BE8D0080
	s_waitcnt lgkmcnt(6)                                       // 0000001325F8: BF89FC67
	v_fma_f32 v88, v72, v74, 0                                 // 0000001325FC: D6130058 02029548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132604: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132608: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 00000013260C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132610: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132614: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132618: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 00000013261C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 000000132620: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132624: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 000000132628: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 00000013262C: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 000000132630: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132634: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 000000132638: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:8 offset1:9        // 00000013263C: D8DC0908 4800003A
	ds_load_2addr_b32 v[74:75], v11 offset0:136 offset1:153    // 000000132644: D8DC9988 4A00000B
	ds_load_2addr_b32 v[76:77], v58 offset0:10 offset1:11      // 00000013264C: D8DC0B0A 4C00003A
	ds_load_2addr_b32 v[78:79], v11 offset0:170 offset1:187    // 000000132654: D8DCBBAA 4E00000B
	ds_load_2addr_b32 v[80:81], v58 offset0:12 offset1:13      // 00000013265C: D8DC0D0C 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:14 offset1:15      // 000000132664: D8DC0F0E 5200003A
	ds_load_2addr_b32 v[84:85], v11 offset0:204 offset1:221    // 00000013266C: D8DCDDCC 5400000B
	ds_load_2addr_b32 v[86:87], v11 offset0:238 offset1:255    // 000000132674: D8DCFFEE 5600000B
	s_waitcnt lgkmcnt(6)                                       // 00000013267C: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132680: 56B09548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132684: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132688: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 00000013268C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132690: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132694: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132698: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 00000013269C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 0000001326A0: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001326A4: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 0000001326A8: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 0000001326AC: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 0000001326B0: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001326B4: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 0000001326B8: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:16 offset1:17      // 0000001326BC: D8DC1110 4800003A
	ds_load_2addr_b32 v[74:75], v60 offset0:16 offset1:33      // 0000001326C4: D8DC2110 4A00003C
	ds_load_2addr_b32 v[76:77], v58 offset0:18 offset1:19      // 0000001326CC: D8DC1312 4C00003A
	ds_load_2addr_b32 v[78:79], v60 offset0:50 offset1:67      // 0000001326D4: D8DC4332 4E00003C
	ds_load_2addr_b32 v[80:81], v58 offset0:20 offset1:21      // 0000001326DC: D8DC1514 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:22 offset1:23      // 0000001326E4: D8DC1716 5200003A
	ds_load_2addr_b32 v[84:85], v60 offset0:84 offset1:101     // 0000001326EC: D8DC6554 5400003C
	ds_load_2addr_b32 v[86:87], v60 offset0:118 offset1:135    // 0000001326F4: D8DC8776 5600003C
	s_waitcnt lgkmcnt(6)                                       // 0000001326FC: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132700: 56B09548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132704: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132708: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 00000013270C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132710: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132714: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132718: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 00000013271C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 000000132720: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132724: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 000000132728: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 00000013272C: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 000000132730: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132734: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 000000132738: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:24 offset1:25      // 00000013273C: D8DC1918 4800003A
	ds_load_2addr_b32 v[74:75], v60 offset0:152 offset1:169    // 000000132744: D8DCA998 4A00003C
	ds_load_2addr_b32 v[76:77], v58 offset0:26 offset1:27      // 00000013274C: D8DC1B1A 4C00003A
	ds_load_2addr_b32 v[78:79], v60 offset0:186 offset1:203    // 000000132754: D8DCCBBA 4E00003C
	ds_load_2addr_b32 v[80:81], v58 offset0:28 offset1:29      // 00000013275C: D8DC1D1C 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:30 offset1:31      // 000000132764: D8DC1F1E 5200003A
	ds_load_2addr_b32 v[84:85], v60 offset0:220 offset1:237    // 00000013276C: D8DCEDDC 5400003C
	ds_load_2addr_b32 v[86:87], v61 offset0:126 offset1:143    // 000000132774: D8DC8F7E 5600003D
	s_waitcnt lgkmcnt(6)                                       // 00000013277C: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132780: 56B09548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132784: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132788: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 00000013278C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132790: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132794: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132798: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 00000013279C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 0000001327A0: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001327A4: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 0000001327A8: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 0000001327AC: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 0000001327B0: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001327B4: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 0000001327B8: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:32 offset1:33      // 0000001327BC: D8DC2120 4800003A
	ds_load_2addr_b32 v[74:75], v62 offset0:32 offset1:49      // 0000001327C4: D8DC3120 4A00003E
	ds_load_2addr_b32 v[76:77], v58 offset0:34 offset1:35      // 0000001327CC: D8DC2322 4C00003A
	ds_load_2addr_b32 v[78:79], v62 offset0:66 offset1:83      // 0000001327D4: D8DC5342 4E00003E
	ds_load_2addr_b32 v[80:81], v58 offset0:36 offset1:37      // 0000001327DC: D8DC2524 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:38 offset1:39      // 0000001327E4: D8DC2726 5200003A
	ds_load_2addr_b32 v[84:85], v62 offset0:100 offset1:117    // 0000001327EC: D8DC7564 5400003E
	ds_load_2addr_b32 v[86:87], v62 offset0:134 offset1:151    // 0000001327F4: D8DC9786 5600003E
	s_waitcnt lgkmcnt(6)                                       // 0000001327FC: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132800: 56B09548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132804: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132808: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 00000013280C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132810: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132814: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132818: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 00000013281C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 000000132820: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132824: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 000000132828: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 00000013282C: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 000000132830: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132834: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 000000132838: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:40 offset1:41      // 00000013283C: D8DC2928 4800003A
	ds_load_2addr_b32 v[74:75], v62 offset0:168 offset1:185    // 000000132844: D8DCB9A8 4A00003E
	ds_load_2addr_b32 v[76:77], v58 offset0:42 offset1:43      // 00000013284C: D8DC2B2A 4C00003A
	ds_load_2addr_b32 v[78:79], v62 offset0:202 offset1:219    // 000000132854: D8DCDBCA 4E00003E
	ds_load_2addr_b32 v[80:81], v58 offset0:44 offset1:45      // 00000013285C: D8DC2D2C 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:46 offset1:47      // 000000132864: D8DC2F2E 5200003A
	ds_load_2addr_b32 v[84:85], v62 offset0:236 offset1:253    // 00000013286C: D8DCFDEC 5400003E
	ds_load_2addr_b32 v[86:87], v63 offset0:14 offset1:31      // 000000132874: D8DC1F0E 5600003F
	s_waitcnt lgkmcnt(6)                                       // 00000013287C: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132880: 56B09548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132884: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132888: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 00000013288C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132890: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132894: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132898: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 00000013289C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 0000001328A0: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001328A4: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 0000001328A8: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 0000001328AC: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 0000001328B0: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001328B4: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 0000001328B8: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:48 offset1:49      // 0000001328BC: D8DC3130 4800003A
	ds_load_2addr_b32 v[74:75], v63 offset0:48 offset1:65      // 0000001328C4: D8DC4130 4A00003F
	ds_load_2addr_b32 v[76:77], v58 offset0:50 offset1:51      // 0000001328CC: D8DC3332 4C00003A
	ds_load_2addr_b32 v[78:79], v63 offset0:82 offset1:99      // 0000001328D4: D8DC6352 4E00003F
	ds_load_2addr_b32 v[80:81], v58 offset0:52 offset1:53      // 0000001328DC: D8DC3534 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:54 offset1:55      // 0000001328E4: D8DC3736 5200003A
	ds_load_2addr_b32 v[84:85], v63 offset0:116 offset1:133    // 0000001328EC: D8DC8574 5400003F
	ds_load_2addr_b32 v[86:87], v63 offset0:150 offset1:167    // 0000001328F4: D8DCA796 5600003F
	s_waitcnt lgkmcnt(6)                                       // 0000001328FC: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132900: 56B09548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132904: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132908: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 00000013290C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132910: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132914: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132918: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 00000013291C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 000000132920: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132924: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 000000132928: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 00000013292C: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 000000132930: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132934: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 000000132938: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:56 offset1:57      // 00000013293C: D8DC3938 4800003A
	ds_load_2addr_b32 v[74:75], v63 offset0:184 offset1:201    // 000000132944: D8DCC9B8 4A00003F
	ds_load_2addr_b32 v[76:77], v58 offset0:58 offset1:59      // 00000013294C: D8DC3B3A 4C00003A
	ds_load_2addr_b32 v[78:79], v63 offset0:218 offset1:235    // 000000132954: D8DCEBDA 4E00003F
	ds_load_2addr_b32 v[80:81], v58 offset0:60 offset1:61      // 00000013295C: D8DC3D3C 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:62 offset1:63      // 000000132964: D8DC3F3E 5200003A
	ds_load_2addr_b32 v[84:85], v64 offset0:124 offset1:141    // 00000013296C: D8DC8D7C 54000040
	ds_load_2addr_b32 v[86:87], v65 offset0:30 offset1:47      // 000000132974: D8DC2F1E 56000041
	s_waitcnt lgkmcnt(6)                                       // 00000013297C: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132980: 56B09548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132984: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132988: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 00000013298C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132990: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132994: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132998: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 00000013299C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 0000001329A0: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001329A4: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 0000001329A8: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 0000001329AC: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 0000001329B0: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001329B4: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 0000001329B8: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:64 offset1:65      // 0000001329BC: D8DC4140 4800003A
	ds_load_2addr_b32 v[74:75], v65 offset0:64 offset1:81      // 0000001329C4: D8DC5140 4A000041
	ds_load_2addr_b32 v[76:77], v58 offset0:66 offset1:67      // 0000001329CC: D8DC4342 4C00003A
	ds_load_2addr_b32 v[78:79], v65 offset0:98 offset1:115     // 0000001329D4: D8DC7362 4E000041
	ds_load_2addr_b32 v[80:81], v58 offset0:68 offset1:69      // 0000001329DC: D8DC4544 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:70 offset1:71      // 0000001329E4: D8DC4746 5200003A
	ds_load_2addr_b32 v[84:85], v65 offset0:132 offset1:149    // 0000001329EC: D8DC9584 54000041
	ds_load_2addr_b32 v[86:87], v65 offset0:166 offset1:183    // 0000001329F4: D8DCB7A6 56000041
	s_waitcnt lgkmcnt(6)                                       // 0000001329FC: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132A00: 56B09548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132A04: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132A08: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 000000132A0C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132A10: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132A14: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132A18: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 000000132A1C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 000000132A20: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132A24: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 000000132A28: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 000000132A2C: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 000000132A30: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132A34: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 000000132A38: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:72 offset1:73      // 000000132A3C: D8DC4948 4800003A
	ds_load_2addr_b32 v[74:75], v65 offset0:200 offset1:217    // 000000132A44: D8DCD9C8 4A000041
	ds_load_2addr_b32 v[76:77], v58 offset0:74 offset1:75      // 000000132A4C: D8DC4B4A 4C00003A
	ds_load_2addr_b32 v[78:79], v65 offset0:234 offset1:251    // 000000132A54: D8DCFBEA 4E000041
	ds_load_2addr_b32 v[80:81], v58 offset0:76 offset1:77      // 000000132A5C: D8DC4D4C 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:78 offset1:79      // 000000132A64: D8DC4F4E 5200003A
	ds_load_2addr_b32 v[84:85], v66 offset0:12 offset1:29      // 000000132A6C: D8DC1D0C 54000042
	ds_load_2addr_b32 v[86:87], v66 offset0:46 offset1:63      // 000000132A74: D8DC3F2E 56000042
	s_waitcnt lgkmcnt(6)                                       // 000000132A7C: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132A80: 56B09548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132A84: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132A88: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 000000132A8C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132A90: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132A94: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132A98: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 000000132A9C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 000000132AA0: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132AA4: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 000000132AA8: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 000000132AAC: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 000000132AB0: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132AB4: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 000000132AB8: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:80 offset1:81      // 000000132ABC: D8DC5150 4800003A
	ds_load_2addr_b32 v[74:75], v66 offset0:80 offset1:97      // 000000132AC4: D8DC6150 4A000042
	ds_load_2addr_b32 v[76:77], v58 offset0:82 offset1:83      // 000000132ACC: D8DC5352 4C00003A
	ds_load_2addr_b32 v[78:79], v66 offset0:114 offset1:131    // 000000132AD4: D8DC8372 4E000042
	ds_load_2addr_b32 v[80:81], v58 offset0:84 offset1:85      // 000000132ADC: D8DC5554 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:86 offset1:87      // 000000132AE4: D8DC5756 5200003A
	ds_load_2addr_b32 v[84:85], v66 offset0:148 offset1:165    // 000000132AEC: D8DCA594 54000042
	ds_load_2addr_b32 v[86:87], v66 offset0:182 offset1:199    // 000000132AF4: D8DCC7B6 56000042
	s_waitcnt lgkmcnt(6)                                       // 000000132AFC: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132B00: 56B09548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132B04: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132B08: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 000000132B0C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132B10: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132B14: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132B18: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 000000132B1C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 000000132B20: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132B24: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 000000132B28: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 000000132B2C: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 000000132B30: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132B34: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 000000132B38: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:88 offset1:89      // 000000132B3C: D8DC5958 4800003A
	ds_load_2addr_b32 v[74:75], v66 offset0:216 offset1:233    // 000000132B44: D8DCE9D8 4A000042
	ds_load_2addr_b32 v[76:77], v58 offset0:90 offset1:91      // 000000132B4C: D8DC5B5A 4C00003A
	ds_load_2addr_b32 v[78:79], v67 offset0:122 offset1:139    // 000000132B54: D8DC8B7A 4E000043
	ds_load_2addr_b32 v[80:81], v58 offset0:92 offset1:93      // 000000132B5C: D8DC5D5C 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:94 offset1:95      // 000000132B64: D8DC5F5E 5200003A
	ds_load_2addr_b32 v[84:85], v68 offset0:28 offset1:45      // 000000132B6C: D8DC2D1C 54000044
	ds_load_2addr_b32 v[86:87], v68 offset0:62 offset1:79      // 000000132B74: D8DC4F3E 56000044
	s_waitcnt lgkmcnt(6)                                       // 000000132B7C: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132B80: 56B09548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132B84: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132B88: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 000000132B8C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132B90: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132B94: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132B98: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 000000132B9C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 000000132BA0: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132BA4: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 000000132BA8: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 000000132BAC: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 000000132BB0: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132BB4: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 000000132BB8: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:96 offset1:97      // 000000132BBC: D8DC6160 4800003A
	ds_load_2addr_b32 v[74:75], v68 offset0:96 offset1:113     // 000000132BC4: D8DC7160 4A000044
	ds_load_2addr_b32 v[76:77], v58 offset0:98 offset1:99      // 000000132BCC: D8DC6362 4C00003A
	ds_load_2addr_b32 v[78:79], v68 offset0:130 offset1:147    // 000000132BD4: D8DC9382 4E000044
	ds_load_2addr_b32 v[80:81], v58 offset0:100 offset1:101    // 000000132BDC: D8DC6564 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:102 offset1:103    // 000000132BE4: D8DC6766 5200003A
	ds_load_2addr_b32 v[84:85], v68 offset0:164 offset1:181    // 000000132BEC: D8DCB5A4 54000044
	ds_load_2addr_b32 v[86:87], v68 offset0:198 offset1:215    // 000000132BF4: D8DCD7C6 56000044
	s_waitcnt lgkmcnt(6)                                       // 000000132BFC: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132C00: 56B09548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132C04: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132C08: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 000000132C0C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132C10: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132C14: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132C18: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 000000132C1C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 000000132C20: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132C24: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 000000132C28: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 000000132C2C: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 000000132C30: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132C34: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 000000132C38: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:104 offset1:105    // 000000132C3C: D8DC6968 4800003A
	ds_load_2addr_b32 v[74:75], v68 offset0:232 offset1:249    // 000000132C44: D8DCF9E8 4A000044
	ds_load_2addr_b32 v[76:77], v58 offset0:106 offset1:107    // 000000132C4C: D8DC6B6A 4C00003A
	ds_load_2addr_b32 v[78:79], v69 offset0:10 offset1:27      // 000000132C54: D8DC1B0A 4E000045
	ds_load_2addr_b32 v[80:81], v58 offset0:108 offset1:109    // 000000132C5C: D8DC6D6C 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:110 offset1:111    // 000000132C64: D8DC6F6E 5200003A
	ds_load_2addr_b32 v[84:85], v69 offset0:44 offset1:61      // 000000132C6C: D8DC3D2C 54000045
	ds_load_2addr_b32 v[86:87], v69 offset0:78 offset1:95      // 000000132C74: D8DC5F4E 56000045
	s_waitcnt lgkmcnt(6)                                       // 000000132C7C: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132C80: 56B09548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132C84: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132C88: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 000000132C8C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132C90: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132C94: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132C98: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 000000132C9C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 000000132CA0: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132CA4: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 000000132CA8: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 000000132CAC: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 000000132CB0: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132CB4: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 000000132CB8: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:112 offset1:113    // 000000132CBC: D8DC7170 4800003A
	ds_load_2addr_b32 v[74:75], v69 offset0:112 offset1:129    // 000000132CC4: D8DC8170 4A000045
	ds_load_2addr_b32 v[76:77], v58 offset0:114 offset1:115    // 000000132CCC: D8DC7372 4C00003A
	ds_load_2addr_b32 v[78:79], v69 offset0:146 offset1:163    // 000000132CD4: D8DCA392 4E000045
	ds_load_2addr_b32 v[80:81], v58 offset0:116 offset1:117    // 000000132CDC: D8DC7574 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:118 offset1:119    // 000000132CE4: D8DC7776 5200003A
	ds_load_2addr_b32 v[84:85], v69 offset0:180 offset1:197    // 000000132CEC: D8DCC5B4 54000045
	ds_load_2addr_b32 v[86:87], v69 offset0:214 offset1:231    // 000000132CF4: D8DCE7D6 56000045
	s_waitcnt lgkmcnt(6)                                       // 000000132CFC: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132D00: 56B09548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132D04: BF8700A1
	v_fmac_f32_e32 v88, v73, v75                               // 000000132D08: 56B09749
	s_waitcnt lgkmcnt(4)                                       // 000000132D0C: BF89FC47
	v_fmac_f32_e32 v88, v76, v78                               // 000000132D10: 56B09D4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132D14: BF8700A1
	v_fmac_f32_e32 v88, v77, v79                               // 000000132D18: 56B09F4D
	s_waitcnt lgkmcnt(1)                                       // 000000132D1C: BF89FC17
	v_fmac_f32_e32 v88, v80, v84                               // 000000132D20: 56B0A950
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132D24: BF8700A1
	v_fmac_f32_e32 v88, v81, v85                               // 000000132D28: 56B0AB51
	s_waitcnt lgkmcnt(0)                                       // 000000132D2C: BF89FC07
	v_fmac_f32_e32 v88, v82, v86                               // 000000132D30: 56B0AD52
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132D34: BF870001
	v_fmac_f32_e32 v88, v83, v87                               // 000000132D38: 56B0AF53
	ds_load_2addr_b32 v[72:73], v58 offset0:120 offset1:121    // 000000132D3C: D8DC7978 4800003A
	ds_load_2addr_b32 v[74:75], v70 offset0:120 offset1:137    // 000000132D44: D8DC8978 4A000046
	ds_load_2addr_b32 v[76:77], v58 offset0:122 offset1:123    // 000000132D4C: D8DC7B7A 4C00003A
	ds_load_2addr_b32 v[78:79], v71 offset0:26 offset1:43      // 000000132D54: D8DC2B1A 4E000047
	ds_load_2addr_b32 v[80:81], v58 offset0:124 offset1:125    // 000000132D5C: D8DC7D7C 5000003A
	ds_load_2addr_b32 v[82:83], v58 offset0:126 offset1:127    // 000000132D64: D8DC7F7E 5200003A
	ds_load_2addr_b32 v[84:85], v71 offset0:60 offset1:77      // 000000132D6C: D8DC4D3C 54000047
	ds_load_2addr_b32 v[86:87], v71 offset0:94 offset1:111     // 000000132D74: D8DC6F5E 56000047
	v_lshlrev_b32_e32 v45, 2, v45                              // 000000132D7C: 305A5A82
	s_waitcnt lgkmcnt(6)                                       // 000000132D80: BF89FC67
	v_fmac_f32_e32 v88, v72, v74                               // 000000132D84: 56B09548
	ds_load_b32 v72, v45 offset:17440                          // 000000132D88: D8D84420 4800002D
	v_dual_mov_b32 v46, v42 :: v_dual_mov_b32 v45, v41         // 000000132D90: CA10012A 2E2C0129
	v_mov_b32_e32 v74, v47                                     // 000000132D98: 7E94032F
	v_dual_fmac_f32 v88, v73, v75 :: v_dual_mov_b32 v73, v11   // 000000132D9C: C8109749 5848010B
	s_waitcnt lgkmcnt(5)                                       // 000000132DA4: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132DA8: BF870091
	v_fmac_f32_e32 v88, v76, v78                               // 000000132DAC: 56B09D4C
	v_fmac_f32_e32 v88, v77, v79                               // 000000132DB0: 56B09F4D
	s_waitcnt lgkmcnt(2)                                       // 000000132DB4: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132DB8: BF870091
	v_fmac_f32_e32 v88, v80, v84                               // 000000132DBC: 56B0A950
	v_fmac_f32_e32 v88, v81, v85                               // 000000132DC0: 56B0AB51
	s_waitcnt lgkmcnt(1)                                       // 000000132DC4: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132DC8: BF870091
	v_fmac_f32_e32 v88, v82, v86                               // 000000132DCC: 56B0AD52
	v_fmac_f32_e32 v88, v83, v87                               // 000000132DD0: 56B0AF53
	s_waitcnt lgkmcnt(0)                                       // 000000132DD4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132DD8: BF870001
	v_mul_f32_e32 v72, v88, v72                                // 000000132DDC: 10909158
	s_nop 0                                                    // 000000132DE0: BF800000
	s_nop 0                                                    // 000000132DE4: BF800000
	s_nop 0                                                    // 000000132DE8: BF800000
	s_nop 0                                                    // 000000132DEC: BF800000
	s_nop 0                                                    // 000000132DF0: BF800000
	s_nop 0                                                    // 000000132DF4: BF800000
	s_nop 0                                                    // 000000132DF8: BF800000
	s_nop 0                                                    // 000000132DFC: BF800000
	global_load_b32 v75, v[45:46], off                         // 000000132E00: DC520000 4B7C002D
	ds_load_b32 v76, v73 offset:8704                           // 000000132E08: D8D82200 4C000049
	v_add_nc_u32_e32 v74, -1, v74                              // 000000132E10: 4A9494C1
	.long 0xd7006a2d                                           // 000000132E14: D7006A2D
	v_cndmask_b32_e32 v0, v45, v132, vcc_lo                    // 000000132E18: 0201092D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000132E1C: BF870191
	v_add_co_ci_u32_e64 v46, null, 0, v46, vcc_lo              // 000000132E20: D5207C2E 01AA5C80
	.long 0xd44a0004                                           // 000000132E28: D44A0004
	v_cndmask_b32_e32 v1, 0, v74, vcc_lo                       // 000000132E2C: 02029480
	v_add_nc_u32_e32 v73, 0x44, v73                            // 000000132E30: 4A9292FF 00000044
	s_or_b32 s13, s4, s13                                      // 000000132E38: 8C0D0D04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000132E3C: BF890007
	v_fmac_f32_e32 v72, v75, v76                               // 000000132E40: 5690994B
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 000000132E44: 917E0D7E
	s_cbranch_execnz 65517                                     // 000000132E48: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_or_b32 exec_lo, exec_lo, s13                             // 000000132E4C: 8C7E0D7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132E50: BF870121
	v_bfe_u32 v73, v72, 16, 1                                  // 000000132E54: D6100049 02052148
	v_mad_u64_u32 v[45:46], null, 0x3000, v48, v[13:14]        // 000000132E5C: D6FE7C2D 043660FF 00003000
	v_add3_u32 v48, v72, v73, 0x7fff                           // 000000132E68: D6550030 03FE9348 00007FFF
	global_store_d16_hi_b16 v[45:46], v48, off                 // 000000132E74: DC960000 007C302D
	s_branch 64876                                             // 000000132E7C: BFA0FD6C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1230>
	s_mul_f32 s4, s6, 0x3fb8aa3b                               // 000000132E80: A204FF06 3FB8AA3B
	v_mov_b32_e32 v43, v50                                     // 000000132E88: 7E560332
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000132E8C: BF8704CA
	s_xor_b32 s7, s4, 0x80000000                               // 000000132E90: 8D07FF04 80000000
	s_rndne_f32 s10, s4                                        // 000000132E98: BE8A6304
	s_fmamk_f32 s7, s6, 0x3fb8aa3b, s7                         // 000000132E9C: A3070706 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 000000132EA4: BF4EFF06 C2CE8ED0
	s_sub_f32 s4, s4, s10                                      // 000000132EAC: A0840A04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000132EB0: BF8704B9
	s_fmamk_f32 s7, s6, 0x32a5705f, s7                         // 000000132EB4: A3070706 32A5705F
	s_cselect_b32 vcc_lo, -1, 0                                // 000000132EBC: 986A80C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 000000132EC0: BF4BFF06 42B17218
	s_add_f32 s4, s4, s7                                       // 000000132EC8: A0040704
	s_delay_alu instid0(SALU_CYCLE_3)                          // 000000132ECC: BF87000B
	v_exp_f32_e32 v41, s4                                      // 000000132ED0: 7E524A04
	s_cvt_i32_f32 s4, s10                                      // 000000132ED4: BE84660A
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000132ED8: BF870585
	.long 0xd71c0029                                           // 000000132EDC: D71C0029
	v_cndmask_b32_e32 v0, v41, v4, vcc_lo                      // 000000132EE0: 02000929
	s_mov_b32 s4, 0                                            // 000000132EE4: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132EE8: BF8700A1
	v_cndmask_b32_e32 v42, 0, v41, vcc_lo                      // 000000132EEC: 02545280
	s_cselect_b32 vcc_lo, -1, 0                                // 000000132EF0: 986A80C1
	v_dual_mov_b32 v41, v49 :: v_dual_cndmask_b32 v42, 0x7f800000, v42// 000000132EF4: CA120131 292A54FF 7F800000
	ds_load_b32 v44, v41                                       // 000000132F00: D8D80000 2C000029
	v_add_nc_u32_e32 v43, 0x80, v43                            // 000000132F08: 4A5656FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132F10: BF870001
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v43                        // 000000132F14: 7C9256FF 0000077F
	s_or_b32 s4, vcc_lo, s4                                    // 000000132F1C: 8C04046A
	s_waitcnt lgkmcnt(0)                                       // 000000132F20: BF89FC07
	v_mul_f32_e32 v44, v42, v44                                // 000000132F24: 1058592A
	ds_store_b32 v41, v44                                      // 000000132F28: D8340000 00002C29
	v_add_nc_u32_e32 v41, 0x220, v41                           // 000000132F30: 4A5252FF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000132F38: 917E047E
	s_cbranch_execnz 65520                                     // 000000132F3C: BFA6FFF0 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d00>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000132F40: 8C7E047E
	v_dual_mov_b32 v42, v26 :: v_dual_mov_b32 v41, v25         // 000000132F44: CA10011A 2A280119
	v_mov_b32_e32 v43, v50                                     // 000000132F4C: 7E560332
	s_mov_b32 s7, 0                                            // 000000132F50: BE870080
	s_mov_b32 s6, 0                                            // 000000132F54: BE860080
	s_nop 0                                                    // 000000132F58: BF800000
	s_nop 0                                                    // 000000132F5C: BF800000
	s_nop 0                                                    // 000000132F60: BF800000
	s_nop 0                                                    // 000000132F64: BF800000
	s_nop 0                                                    // 000000132F68: BF800000
	s_nop 0                                                    // 000000132F6C: BF800000
	s_nop 0                                                    // 000000132F70: BF800000
	s_nop 0                                                    // 000000132F74: BF800000
	s_nop 0                                                    // 000000132F78: BF800000
	s_nop 0                                                    // 000000132F7C: BF800000
	global_load_b32 v44, v[41:42], off                         // 000000132F80: DC520000 2C7C0029
	v_add_nc_u32_e32 v43, 0x80, v43                            // 000000132F88: 4A5656FF 00000080
	.long 0xd7006a29                                           // 000000132F90: D7006A29
	v_cndmask_b32_e32 v1, 0x6000, v41, vcc_lo                  // 000000132F94: 020252FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000132F9C: BF870191
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 000000132FA0: D5207C2A 01AA5480
	.long 0xd4490004                                           // 000000132FA8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v43, vcc_lo                   // 000000132FAC: 020256FF 0000037F
	s_mov_b32 m0, s7                                           // 000000132FB4: BEFD0007
	s_add_i32 s7, s7, 1                                        // 000000132FB8: 81078107
	s_or_b32 s6, s4, s6                                        // 000000132FBC: 8C060604
	s_waitcnt vmcnt(0)                                         // 000000132FC0: BF8903F7
	v_movreld_b32_e32 v3, v44                                  // 000000132FC4: 7E06852C
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000132FC8: 917E067E
	s_cbranch_execnz 65516                                     // 000000132FCC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d80>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000132FD0: 8C7E067E
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, v52           // 000000132FD4: CA100080 292A0134
	v_mov_b32_e32 v43, v50                                     // 000000132FDC: 7E560332
	s_mov_b32 s6, 0                                            // 000000132FE0: BE860080
	s_mov_b32 s4, 0                                            // 000000132FE4: BE840080
	s_waitcnt lgkmcnt(0)                                       // 000000132FE8: BF89FC07
	s_barrier                                                  // 000000132FEC: BFBD0000
	buffer_gl0_inv                                             // 000000132FF0: E0AC0000 00000000
	s_nop 0                                                    // 000000132FF8: BF800000
	s_nop 0                                                    // 000000132FFC: BF800000
	ds_load_b32 v44, v41 offset:17184                          // 000000133000: D8D84320 2C000029
	s_mov_b32 m0, s6                                           // 000000133008: BEFD0006
	v_add_nc_u32_e32 v43, 0x80, v43                            // 00000013300C: 4A5656FF 00000080
	v_movrels_b32_e32 v45, v3                                  // 000000133014: 7E5A8703
	v_add_nc_u32_e32 v41, 4, v41                               // 000000133018: 4A525284
	s_add_i32 s6, s6, 1                                        // 00000013301C: 81068106
	s_delay_alu instid0(VALU_DEP_3)                            // 000000133020: BF870003
	v_cmp_lt_u32_e32 vcc_lo, 0x37f, v43                        // 000000133024: 7C9256FF 0000037F
	s_or_b32 s4, vcc_lo, s4                                    // 00000013302C: 8C04046A
	s_waitcnt lgkmcnt(0)                                       // 000000133030: BF89FC07
	v_mul_f32_e32 v44, v45, v44                                // 000000133034: 1058592D
	ds_store_b32 v42, v44 offset:13056                         // 000000133038: D8343300 00002C2A
	v_add_nc_u32_e32 v42, 0x204, v42                           // 000000133040: 4A5454FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000133048: 917E047E
	s_cbranch_execnz 65516                                     // 00000013304C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e00>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000133050: 8C7E047E
	v_dual_mov_b32 v42, v28 :: v_dual_mov_b32 v41, v27         // 000000133054: CA10011C 2A28011B
	v_mov_b32_e32 v43, v50                                     // 00000013305C: 7E560332
	s_mov_b32 s7, 0                                            // 000000133060: BE870080
	s_mov_b32 s6, 0                                            // 000000133064: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000133068: BF89FC07
	s_barrier                                                  // 00000013306C: BFBD0000
	buffer_gl0_inv                                             // 000000133070: E0AC0000 00000000
	s_nop 0                                                    // 000000133078: BF800000
	s_nop 0                                                    // 00000013307C: BF800000
	global_load_b32 v44, v[41:42], off                         // 000000133080: DC520000 2C7C0029
	v_add_nc_u32_e32 v43, 0x80, v43                            // 000000133088: 4A5656FF 00000080
	.long 0xd7006a29                                           // 000000133090: D7006A29
	v_cndmask_b32_e32 v1, 0x6000, v41, vcc_lo                  // 000000133094: 020252FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013309C: BF870191
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 0000001330A0: D5207C2A 01AA5480
	.long 0xd4490004                                           // 0000001330A8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v43, vcc_lo                   // 0000001330AC: 020256FF 0000037F
	s_mov_b32 m0, s7                                           // 0000001330B4: BEFD0007
	s_add_i32 s7, s7, 1                                        // 0000001330B8: 81078107
	s_or_b32 s6, s4, s6                                        // 0000001330BC: 8C060604
	s_waitcnt vmcnt(0)                                         // 0000001330C0: BF8903F7
	v_movreld_b32_e32 v3, v44                                  // 0000001330C4: 7E06852C
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000001330C8: 917E067E
	s_cbranch_execnz 65516                                     // 0000001330CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e80>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001330D0: 8C7E067E
	ds_load_2addr_b32 v[41:42], v59 offset1:17                 // 0000001330D4: D8DC1100 2900003B
	ds_load_2addr_b32 v[43:44], v59 offset0:34 offset1:51      // 0000001330DC: D8DC3322 2B00003B
	ds_load_2addr_b32 v[45:46], v59 offset0:68 offset1:85      // 0000001330E4: D8DC5544 2D00003B
	ds_load_2addr_b32 v[47:48], v59 offset0:102 offset1:119    // 0000001330EC: D8DC7766 2F00003B
	v_mov_b32_e32 v72, v0                                      // 0000001330F4: 7E900300
	s_mov_b32 s4, 0                                            // 0000001330F8: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001330FC: BF840001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000133100: BF870121
	v_lshrrev_b32_e32 v73, 4, v72                              // 000000133104: 32929084
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v72                        // 000000133108: 7C9290FF 0000077F
	v_lshlrev_b32_e32 v80, 2, v73                              // 000000133110: 30A09282
	v_mad_u64_u32 v[73:74], null, 0x44, v73, v[11:12]          // 000000133114: D6FE7C49 042E92FF 00000044
	s_or_b32 s4, vcc_lo, s4                                    // 000000133120: 8C04046A
	v_add_nc_u32_e32 v74, 0x3200, v80                          // 000000133124: 4A94A0FF 00003200
	v_add_nc_u32_e32 v76, 0x3600, v80                          // 00000013312C: 4A98A0FF 00003600
	v_add_nc_u32_e32 v78, 0x3a00, v80                          // 000000133134: 4A9CA0FF 00003A00
	ds_load_b32 v81, v73                                       // 00000013313C: D8D80000 51000049
	ds_load_2addr_b32 v[74:75], v74 offset0:64 offset1:193     // 000000133144: D8DCC140 4A00004A
	ds_load_2addr_b32 v[76:77], v76 offset0:66 offset1:195     // 00000013314C: D8DCC342 4C00004C
	ds_load_2addr_b32 v[78:79], v78 offset0:68 offset1:197     // 000000133154: D8DCC544 4E00004E
	s_waitcnt lgkmcnt(2)                                       // 00000013315C: BF89FC27
	v_dual_fmac_f32 v81, v74, v41 :: v_dual_add_nc_u32 v74, 0x3e00, v80// 000000133160: C820534A 514AA0FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013316C: BF8700C1
	v_fmac_f32_e32 v81, v75, v42                               // 000000133170: 56A2554B
	ds_load_2addr_b32 v[74:75], v74 offset0:70 offset1:199     // 000000133174: D8DCC746 4A00004A
	s_waitcnt lgkmcnt(2)                                       // 00000013317C: BF89FC27
	v_fmac_f32_e32 v81, v76, v43                               // 000000133180: 56A2574C
	v_fmac_f32_e32 v81, v77, v44                               // 000000133184: 56A2594D
	s_waitcnt lgkmcnt(1)                                       // 000000133188: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013318C: BF870091
	v_fmac_f32_e32 v81, v78, v45                               // 000000133190: 56A25B4E
	v_fmac_f32_e32 v81, v79, v46                               // 000000133194: 56A25D4F
	s_waitcnt lgkmcnt(0)                                       // 000000133198: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013319C: BF870091
	v_dual_fmac_f32 v81, v74, v47 :: v_dual_add_nc_u32 v74, 0x80, v72// 0000001331A0: C8205F4A 514A90FF 00000080
	v_dual_fmac_f32 v81, v75, v48 :: v_dual_mov_b32 v72, v74   // 0000001331AC: C810614B 5148014A
	ds_store_b32 v73, v81                                      // 0000001331B4: D8340000 00005149
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001331BC: 917E047E
	s_cbranch_execnz 65487                                     // 0000001331C0: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f00>
	s_set_inst_prefetch_distance 0x2                           // 0000001331C4: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001331C8: 8C7E047E
	v_dual_mov_b32 v41, v52 :: v_dual_mov_b32 v42, 0           // 0000001331CC: CA100134 292A0080
	v_mov_b32_e32 v43, v50                                     // 0000001331D4: 7E560332
	s_mov_b32 s6, 0                                            // 0000001331D8: BE860080
	s_mov_b32 s4, 0                                            // 0000001331DC: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000001331E0: BF89FC07
	s_barrier                                                  // 0000001331E4: BFBD0000
	buffer_gl0_inv                                             // 0000001331E8: E0AC0000 00000000
	s_nop 0                                                    // 0000001331F0: BF800000
	s_nop 0                                                    // 0000001331F4: BF800000
	s_nop 0                                                    // 0000001331F8: BF800000
	s_nop 0                                                    // 0000001331FC: BF800000
	ds_load_b32 v44, v42 offset:17216                          // 000000133200: D8D84340 2C00002A
	s_mov_b32 m0, s6                                           // 000000133208: BEFD0006
	v_add_nc_u32_e32 v43, 0x80, v43                            // 00000013320C: 4A5656FF 00000080
	v_movrels_b32_e32 v45, v3                                  // 000000133214: 7E5A8703
	v_add_nc_u32_e32 v42, 4, v42                               // 000000133218: 4A545484
	s_add_i32 s6, s6, 1                                        // 00000013321C: 81068106
	s_delay_alu instid0(VALU_DEP_3)                            // 000000133220: BF870003
	v_cmp_lt_u32_e32 vcc_lo, 0x37f, v43                        // 000000133224: 7C9256FF 0000037F
	s_or_b32 s4, vcc_lo, s4                                    // 00000013322C: 8C04046A
	s_waitcnt lgkmcnt(0)                                       // 000000133230: BF89FC07
	v_mul_f32_e32 v44, v45, v44                                // 000000133234: 1058592D
	ds_store_b32 v41, v44 offset:13056                         // 000000133238: D8343300 00002C29
	v_add_nc_u32_e32 v41, 0x204, v41                           // 000000133240: 4A5252FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000133248: 917E047E
	s_cbranch_execnz 65516                                     // 00000013324C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2000>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000133250: 8C7E047E
	v_dual_mov_b32 v42, v30 :: v_dual_mov_b32 v41, v29         // 000000133254: CA10011E 2A28011D
	v_mov_b32_e32 v43, v50                                     // 00000013325C: 7E560332
	s_mov_b32 s7, 0                                            // 000000133260: BE870080
	s_mov_b32 s6, 0                                            // 000000133264: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000133268: BF89FC07
	s_barrier                                                  // 00000013326C: BFBD0000
	buffer_gl0_inv                                             // 000000133270: E0AC0000 00000000
	s_nop 0                                                    // 000000133278: BF800000
	s_nop 0                                                    // 00000013327C: BF800000
	global_load_b32 v44, v[41:42], off                         // 000000133280: DC520000 2C7C0029
	v_add_nc_u32_e32 v43, 0x80, v43                            // 000000133288: 4A5656FF 00000080
	.long 0xd7006a29                                           // 000000133290: D7006A29
	v_cndmask_b32_e32 v1, 0x6000, v41, vcc_lo                  // 000000133294: 020252FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013329C: BF870191
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 0000001332A0: D5207C2A 01AA5480
	.long 0xd4490004                                           // 0000001332A8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v43, vcc_lo                   // 0000001332AC: 020256FF 0000037F
	s_mov_b32 m0, s7                                           // 0000001332B4: BEFD0007
	s_add_i32 s7, s7, 1                                        // 0000001332B8: 81078107
	s_or_b32 s6, s4, s6                                        // 0000001332BC: 8C060604
	s_waitcnt vmcnt(0)                                         // 0000001332C0: BF8903F7
	v_movreld_b32_e32 v3, v44                                  // 0000001332C4: 7E06852C
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000001332C8: 917E067E
	s_cbranch_execnz 65516                                     // 0000001332CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2080>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001332D0: 8C7E067E
	ds_load_2addr_b32 v[41:42], v59 offset0:136 offset1:153    // 0000001332D4: D8DC9988 2900003B
	ds_load_2addr_b32 v[43:44], v59 offset0:170 offset1:187    // 0000001332DC: D8DCBBAA 2B00003B
	ds_load_2addr_b32 v[45:46], v59 offset0:204 offset1:221    // 0000001332E4: D8DCDDCC 2D00003B
	ds_load_2addr_b32 v[47:48], v59 offset0:238 offset1:255    // 0000001332EC: D8DCFFEE 2F00003B
	v_mov_b32_e32 v72, v0                                      // 0000001332F4: 7E900300
	s_mov_b32 s4, 0                                            // 0000001332F8: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001332FC: BF840001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000133300: BF870121
	v_lshrrev_b32_e32 v73, 4, v72                              // 000000133304: 32929084
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v72                        // 000000133308: 7C9290FF 0000077F
	v_lshlrev_b32_e32 v80, 2, v73                              // 000000133310: 30A09282
	v_mad_u64_u32 v[73:74], null, 0x44, v73, v[11:12]          // 000000133314: D6FE7C49 042E92FF 00000044
	s_or_b32 s4, vcc_lo, s4                                    // 000000133320: 8C04046A
	v_add_nc_u32_e32 v74, 0x3200, v80                          // 000000133324: 4A94A0FF 00003200
	v_add_nc_u32_e32 v76, 0x3600, v80                          // 00000013332C: 4A98A0FF 00003600
	v_add_nc_u32_e32 v78, 0x3a00, v80                          // 000000133334: 4A9CA0FF 00003A00
	ds_load_b32 v81, v73                                       // 00000013333C: D8D80000 51000049
	ds_load_2addr_b32 v[74:75], v74 offset0:64 offset1:193     // 000000133344: D8DCC140 4A00004A
	ds_load_2addr_b32 v[76:77], v76 offset0:66 offset1:195     // 00000013334C: D8DCC342 4C00004C
	ds_load_2addr_b32 v[78:79], v78 offset0:68 offset1:197     // 000000133354: D8DCC544 4E00004E
	s_waitcnt lgkmcnt(2)                                       // 00000013335C: BF89FC27
	v_dual_fmac_f32 v81, v74, v41 :: v_dual_add_nc_u32 v74, 0x3e00, v80// 000000133360: C820534A 514AA0FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013336C: BF8700C1
	v_fmac_f32_e32 v81, v75, v42                               // 000000133370: 56A2554B
	ds_load_2addr_b32 v[74:75], v74 offset0:70 offset1:199     // 000000133374: D8DCC746 4A00004A
	s_waitcnt lgkmcnt(2)                                       // 00000013337C: BF89FC27
	v_fmac_f32_e32 v81, v76, v43                               // 000000133380: 56A2574C
	v_fmac_f32_e32 v81, v77, v44                               // 000000133384: 56A2594D
	s_waitcnt lgkmcnt(1)                                       // 000000133388: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013338C: BF870091
	v_fmac_f32_e32 v81, v78, v45                               // 000000133390: 56A25B4E
	v_fmac_f32_e32 v81, v79, v46                               // 000000133394: 56A25D4F
	s_waitcnt lgkmcnt(0)                                       // 000000133398: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013339C: BF870091
	v_dual_fmac_f32 v81, v74, v47 :: v_dual_add_nc_u32 v74, 0x80, v72// 0000001333A0: C8205F4A 514A90FF 00000080
	v_dual_fmac_f32 v81, v75, v48 :: v_dual_mov_b32 v72, v74   // 0000001333AC: C810614B 5148014A
	ds_store_b32 v73, v81                                      // 0000001333B4: D8340000 00005149
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001333BC: 917E047E
	s_cbranch_execnz 65487                                     // 0000001333C0: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2100>
	s_set_inst_prefetch_distance 0x2                           // 0000001333C4: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001333C8: 8C7E047E
	v_dual_mov_b32 v41, v52 :: v_dual_mov_b32 v42, 0           // 0000001333CC: CA100134 292A0080
	v_mov_b32_e32 v43, v50                                     // 0000001333D4: 7E560332
	s_mov_b32 s6, 0                                            // 0000001333D8: BE860080
	s_mov_b32 s4, 0                                            // 0000001333DC: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000001333E0: BF89FC07
	s_barrier                                                  // 0000001333E4: BFBD0000
	buffer_gl0_inv                                             // 0000001333E8: E0AC0000 00000000
	s_nop 0                                                    // 0000001333F0: BF800000
	s_nop 0                                                    // 0000001333F4: BF800000
	s_nop 0                                                    // 0000001333F8: BF800000
	s_nop 0                                                    // 0000001333FC: BF800000
	ds_load_b32 v44, v42 offset:17248                          // 000000133400: D8D84360 2C00002A
	s_mov_b32 m0, s6                                           // 000000133408: BEFD0006
	v_add_nc_u32_e32 v43, 0x80, v43                            // 00000013340C: 4A5656FF 00000080
	v_movrels_b32_e32 v45, v3                                  // 000000133414: 7E5A8703
	v_add_nc_u32_e32 v42, 4, v42                               // 000000133418: 4A545484
	s_add_i32 s6, s6, 1                                        // 00000013341C: 81068106
	s_delay_alu instid0(VALU_DEP_3)                            // 000000133420: BF870003
	v_cmp_lt_u32_e32 vcc_lo, 0x37f, v43                        // 000000133424: 7C9256FF 0000037F
	s_or_b32 s4, vcc_lo, s4                                    // 00000013342C: 8C04046A
	s_waitcnt lgkmcnt(0)                                       // 000000133430: BF89FC07
	v_mul_f32_e32 v44, v45, v44                                // 000000133434: 1058592D
	ds_store_b32 v41, v44 offset:13056                         // 000000133438: D8343300 00002C29
	v_add_nc_u32_e32 v41, 0x204, v41                           // 000000133440: 4A5252FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000133448: 917E047E
	s_cbranch_execnz 65516                                     // 00000013344C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2200>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000133450: 8C7E047E
	v_dual_mov_b32 v42, v32 :: v_dual_mov_b32 v41, v31         // 000000133454: CA100120 2A28011F
	v_mov_b32_e32 v43, v50                                     // 00000013345C: 7E560332
	s_mov_b32 s7, 0                                            // 000000133460: BE870080
	s_mov_b32 s6, 0                                            // 000000133464: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000133468: BF89FC07
	s_barrier                                                  // 00000013346C: BFBD0000
	buffer_gl0_inv                                             // 000000133470: E0AC0000 00000000
	s_nop 0                                                    // 000000133478: BF800000
	s_nop 0                                                    // 00000013347C: BF800000
	global_load_b32 v44, v[41:42], off                         // 000000133480: DC520000 2C7C0029
	v_add_nc_u32_e32 v43, 0x80, v43                            // 000000133488: 4A5656FF 00000080
	.long 0xd7006a29                                           // 000000133490: D7006A29
	v_cndmask_b32_e32 v1, 0x6000, v41, vcc_lo                  // 000000133494: 020252FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013349C: BF870191
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 0000001334A0: D5207C2A 01AA5480
	.long 0xd4490004                                           // 0000001334A8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v43, vcc_lo                   // 0000001334AC: 020256FF 0000037F
	s_mov_b32 m0, s7                                           // 0000001334B4: BEFD0007
	s_add_i32 s7, s7, 1                                        // 0000001334B8: 81078107
	s_or_b32 s6, s4, s6                                        // 0000001334BC: 8C060604
	s_waitcnt vmcnt(0)                                         // 0000001334C0: BF8903F7
	v_movreld_b32_e32 v3, v44                                  // 0000001334C4: 7E06852C
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000001334C8: 917E067E
	s_cbranch_execnz 65516                                     // 0000001334CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2280>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001334D0: 8C7E067E
	v_dual_mov_b32 v73, v0 :: v_dual_add_nc_u32 v72, 0x400, v59// 0000001334D4: CA200100 494876FF 00000400
	s_mov_b32 s4, 0                                            // 0000001334E0: BE840080
	ds_load_2addr_b32 v[41:42], v72 offset0:16 offset1:33      // 0000001334E4: D8DC2110 29000048
	ds_load_2addr_b32 v[43:44], v72 offset0:50 offset1:67      // 0000001334EC: D8DC4332 2B000048
	ds_load_2addr_b32 v[45:46], v72 offset0:84 offset1:101     // 0000001334F4: D8DC6554 2D000048
	ds_load_2addr_b32 v[47:48], v72 offset0:118 offset1:135    // 0000001334FC: D8DC8776 2F000048
	s_set_inst_prefetch_distance 0x1                           // 000000133504: BF840001
	s_nop 0                                                    // 000000133508: BF800000
	s_nop 0                                                    // 00000013350C: BF800000
	s_nop 0                                                    // 000000133510: BF800000
	s_nop 0                                                    // 000000133514: BF800000
	s_nop 0                                                    // 000000133518: BF800000
	s_nop 0                                                    // 00000013351C: BF800000
	s_nop 0                                                    // 000000133520: BF800000
	s_nop 0                                                    // 000000133524: BF800000
	s_nop 0                                                    // 000000133528: BF800000
	s_nop 0                                                    // 00000013352C: BF800000
	s_nop 0                                                    // 000000133530: BF800000
	s_nop 0                                                    // 000000133534: BF800000
	s_nop 0                                                    // 000000133538: BF800000
	s_nop 0                                                    // 00000013353C: BF800000
	v_lshrrev_b32_e32 v74, 4, v73                              // 000000133540: 32949284
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v73                        // 000000133544: 7C9292FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000013354C: BF870002
	v_lshlrev_b32_e32 v81, 2, v74                              // 000000133550: 30A29482
	v_mad_u64_u32 v[74:75], null, 0x44, v74, v[11:12]          // 000000133554: D6FE7C4A 042E94FF 00000044
	s_or_b32 s4, vcc_lo, s4                                    // 000000133560: 8C04046A
	v_add_nc_u32_e32 v75, 0x3200, v81                          // 000000133564: 4A96A2FF 00003200
	v_add_nc_u32_e32 v77, 0x3600, v81                          // 00000013356C: 4A9AA2FF 00003600
	v_add_nc_u32_e32 v79, 0x3a00, v81                          // 000000133574: 4A9EA2FF 00003A00
	ds_load_b32 v82, v74                                       // 00000013357C: D8D80000 5200004A
	ds_load_2addr_b32 v[75:76], v75 offset0:64 offset1:193     // 000000133584: D8DCC140 4B00004B
	ds_load_2addr_b32 v[77:78], v77 offset0:66 offset1:195     // 00000013358C: D8DCC342 4D00004D
	ds_load_2addr_b32 v[79:80], v79 offset0:68 offset1:197     // 000000133594: D8DCC544 4F00004F
	s_waitcnt lgkmcnt(2)                                       // 00000013359C: BF89FC27
	v_fmac_f32_e32 v82, v75, v41                               // 0000001335A0: 56A4534B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001335A4: BF8700C1
	v_dual_fmac_f32 v82, v76, v42 :: v_dual_add_nc_u32 v75, 0x3e00, v81// 0000001335A8: C820554C 524AA2FF 00003E00
	ds_load_2addr_b32 v[75:76], v75 offset0:70 offset1:199     // 0000001335B4: D8DCC746 4B00004B
	s_waitcnt lgkmcnt(2)                                       // 0000001335BC: BF89FC27
	v_fmac_f32_e32 v82, v77, v43                               // 0000001335C0: 56A4574D
	v_fmac_f32_e32 v82, v78, v44                               // 0000001335C4: 56A4594E
	s_waitcnt lgkmcnt(1)                                       // 0000001335C8: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001335CC: BF870091
	v_fmac_f32_e32 v82, v79, v45                               // 0000001335D0: 56A45B4F
	v_fmac_f32_e32 v82, v80, v46                               // 0000001335D4: 56A45D50
	s_waitcnt lgkmcnt(0)                                       // 0000001335D8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001335DC: BF870091
	v_dual_fmac_f32 v82, v75, v47 :: v_dual_add_nc_u32 v75, 0x80, v73// 0000001335E0: C8205F4B 524A92FF 00000080
	v_dual_fmac_f32 v82, v76, v48 :: v_dual_mov_b32 v73, v75   // 0000001335EC: C810614C 5248014B
	ds_store_b32 v74, v82                                      // 0000001335F4: D8340000 0000524A
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001335FC: 917E047E
	s_cbranch_execnz 65487                                     // 000000133600: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2340>
	s_set_inst_prefetch_distance 0x2                           // 000000133604: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000133608: 8C7E047E
	v_dual_mov_b32 v41, v52 :: v_dual_mov_b32 v42, 0           // 00000013360C: CA100134 292A0080
	v_mov_b32_e32 v43, v50                                     // 000000133614: 7E560332
	s_mov_b32 s6, 0                                            // 000000133618: BE860080
	s_mov_b32 s4, 0                                            // 00000013361C: BE840080
	s_waitcnt lgkmcnt(0)                                       // 000000133620: BF89FC07
	s_barrier                                                  // 000000133624: BFBD0000
	buffer_gl0_inv                                             // 000000133628: E0AC0000 00000000
	s_nop 0                                                    // 000000133630: BF800000
	s_nop 0                                                    // 000000133634: BF800000
	s_nop 0                                                    // 000000133638: BF800000
	s_nop 0                                                    // 00000013363C: BF800000
	ds_load_b32 v44, v42 offset:17280                          // 000000133640: D8D84380 2C00002A
	s_mov_b32 m0, s6                                           // 000000133648: BEFD0006
	v_add_nc_u32_e32 v43, 0x80, v43                            // 00000013364C: 4A5656FF 00000080
	v_movrels_b32_e32 v45, v3                                  // 000000133654: 7E5A8703
	v_add_nc_u32_e32 v42, 4, v42                               // 000000133658: 4A545484
	s_add_i32 s6, s6, 1                                        // 00000013365C: 81068106
	s_delay_alu instid0(VALU_DEP_3)                            // 000000133660: BF870003
	v_cmp_lt_u32_e32 vcc_lo, 0x37f, v43                        // 000000133664: 7C9256FF 0000037F
	s_or_b32 s4, vcc_lo, s4                                    // 00000013366C: 8C04046A
	s_waitcnt lgkmcnt(0)                                       // 000000133670: BF89FC07
	v_mul_f32_e32 v44, v45, v44                                // 000000133674: 1058592D
	ds_store_b32 v41, v44 offset:13056                         // 000000133678: D8343300 00002C29
	v_add_nc_u32_e32 v41, 0x204, v41                           // 000000133680: 4A5252FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000133688: 917E047E
	s_cbranch_execnz 65516                                     // 00000013368C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000133690: 8C7E047E
	v_dual_mov_b32 v42, v34 :: v_dual_mov_b32 v41, v33         // 000000133694: CA100122 2A280121
	v_mov_b32_e32 v43, v50                                     // 00000013369C: 7E560332
	s_mov_b32 s7, 0                                            // 0000001336A0: BE870080
	s_mov_b32 s6, 0                                            // 0000001336A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000001336A8: BF89FC07
	s_barrier                                                  // 0000001336AC: BFBD0000
	buffer_gl0_inv                                             // 0000001336B0: E0AC0000 00000000
	s_nop 0                                                    // 0000001336B8: BF800000
	s_nop 0                                                    // 0000001336BC: BF800000
	global_load_b32 v44, v[41:42], off                         // 0000001336C0: DC520000 2C7C0029
	v_add_nc_u32_e32 v43, 0x80, v43                            // 0000001336C8: 4A5656FF 00000080
	.long 0xd7006a29                                           // 0000001336D0: D7006A29
	v_cndmask_b32_e32 v1, 0x6000, v41, vcc_lo                  // 0000001336D4: 020252FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001336DC: BF870191
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 0000001336E0: D5207C2A 01AA5480
	.long 0xd4490004                                           // 0000001336E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v43, vcc_lo                   // 0000001336EC: 020256FF 0000037F
	s_mov_b32 m0, s7                                           // 0000001336F4: BEFD0007
	s_add_i32 s7, s7, 1                                        // 0000001336F8: 81078107
	s_or_b32 s6, s4, s6                                        // 0000001336FC: 8C060604
	s_waitcnt vmcnt(0)                                         // 000000133700: BF8903F7
	v_movreld_b32_e32 v3, v44                                  // 000000133704: 7E06852C
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000133708: 917E067E
	s_cbranch_execnz 65516                                     // 00000013370C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x24c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000133710: 8C7E067E
	v_add_nc_u32_e32 v47, 0x600, v59                           // 000000133714: 4A5E76FF 00000600
	s_mov_b32 s4, 0                                            // 00000013371C: BE840080
	ds_load_2addr_b32 v[41:42], v72 offset0:152 offset1:169    // 000000133720: D8DCA998 29000048
	ds_load_2addr_b32 v[43:44], v72 offset0:186 offset1:203    // 000000133728: D8DCCBBA 2B000048
	ds_load_2addr_b32 v[45:46], v72 offset0:220 offset1:237    // 000000133730: D8DCEDDC 2D000048
	ds_load_2addr_b32 v[47:48], v47 offset0:126 offset1:143    // 000000133738: D8DC8F7E 2F00002F
	v_mov_b32_e32 v72, v0                                      // 000000133740: 7E900300
	s_set_inst_prefetch_distance 0x1                           // 000000133744: BF840001
	s_nop 0                                                    // 000000133748: BF800000
	s_nop 0                                                    // 00000013374C: BF800000
	s_nop 0                                                    // 000000133750: BF800000
	s_nop 0                                                    // 000000133754: BF800000
	s_nop 0                                                    // 000000133758: BF800000
	s_nop 0                                                    // 00000013375C: BF800000
	s_nop 0                                                    // 000000133760: BF800000
	s_nop 0                                                    // 000000133764: BF800000
	s_nop 0                                                    // 000000133768: BF800000
	s_nop 0                                                    // 00000013376C: BF800000
	s_nop 0                                                    // 000000133770: BF800000
	s_nop 0                                                    // 000000133774: BF800000
	s_nop 0                                                    // 000000133778: BF800000
	s_nop 0                                                    // 00000013377C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000133780: BF870121
	v_lshrrev_b32_e32 v73, 4, v72                              // 000000133784: 32929084
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v72                        // 000000133788: 7C9290FF 0000077F
	v_lshlrev_b32_e32 v80, 2, v73                              // 000000133790: 30A09282
	v_mad_u64_u32 v[73:74], null, 0x44, v73, v[11:12]          // 000000133794: D6FE7C49 042E92FF 00000044
	s_or_b32 s4, vcc_lo, s4                                    // 0000001337A0: 8C04046A
	v_add_nc_u32_e32 v74, 0x3200, v80                          // 0000001337A4: 4A94A0FF 00003200
	v_add_nc_u32_e32 v76, 0x3600, v80                          // 0000001337AC: 4A98A0FF 00003600
	v_add_nc_u32_e32 v78, 0x3a00, v80                          // 0000001337B4: 4A9CA0FF 00003A00
	ds_load_b32 v81, v73                                       // 0000001337BC: D8D80000 51000049
	ds_load_2addr_b32 v[74:75], v74 offset0:64 offset1:193     // 0000001337C4: D8DCC140 4A00004A
	ds_load_2addr_b32 v[76:77], v76 offset0:66 offset1:195     // 0000001337CC: D8DCC342 4C00004C
	ds_load_2addr_b32 v[78:79], v78 offset0:68 offset1:197     // 0000001337D4: D8DCC544 4E00004E
	s_waitcnt lgkmcnt(2)                                       // 0000001337DC: BF89FC27
	v_dual_fmac_f32 v81, v74, v41 :: v_dual_add_nc_u32 v74, 0x3e00, v80// 0000001337E0: C820534A 514AA0FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001337EC: BF8700C1
	v_fmac_f32_e32 v81, v75, v42                               // 0000001337F0: 56A2554B
	ds_load_2addr_b32 v[74:75], v74 offset0:70 offset1:199     // 0000001337F4: D8DCC746 4A00004A
	s_waitcnt lgkmcnt(2)                                       // 0000001337FC: BF89FC27
	v_fmac_f32_e32 v81, v76, v43                               // 000000133800: 56A2574C
	v_fmac_f32_e32 v81, v77, v44                               // 000000133804: 56A2594D
	s_waitcnt lgkmcnt(1)                                       // 000000133808: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013380C: BF870091
	v_fmac_f32_e32 v81, v78, v45                               // 000000133810: 56A25B4E
	v_fmac_f32_e32 v81, v79, v46                               // 000000133814: 56A25D4F
	s_waitcnt lgkmcnt(0)                                       // 000000133818: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013381C: BF870091
	v_dual_fmac_f32 v81, v74, v47 :: v_dual_add_nc_u32 v74, 0x80, v72// 000000133820: C8205F4A 514A90FF 00000080
	v_dual_fmac_f32 v81, v75, v48 :: v_dual_mov_b32 v72, v74   // 00000013382C: C810614B 5148014A
	ds_store_b32 v73, v81                                      // 000000133834: D8340000 00005149
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000013383C: 917E047E
	s_cbranch_execnz 65487                                     // 000000133840: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2580>
	s_set_inst_prefetch_distance 0x2                           // 000000133844: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000133848: 8C7E047E
	v_dual_mov_b32 v41, v52 :: v_dual_mov_b32 v42, 0           // 00000013384C: CA100134 292A0080
	v_mov_b32_e32 v43, v50                                     // 000000133854: 7E560332
	s_mov_b32 s6, 0                                            // 000000133858: BE860080
	s_mov_b32 s4, 0                                            // 00000013385C: BE840080
	s_waitcnt lgkmcnt(0)                                       // 000000133860: BF89FC07
	s_barrier                                                  // 000000133864: BFBD0000
	buffer_gl0_inv                                             // 000000133868: E0AC0000 00000000
	s_nop 0                                                    // 000000133870: BF800000
	s_nop 0                                                    // 000000133874: BF800000
	s_nop 0                                                    // 000000133878: BF800000
	s_nop 0                                                    // 00000013387C: BF800000
	ds_load_b32 v44, v42 offset:17312                          // 000000133880: D8D843A0 2C00002A
	s_mov_b32 m0, s6                                           // 000000133888: BEFD0006
	v_add_nc_u32_e32 v43, 0x80, v43                            // 00000013388C: 4A5656FF 00000080
	v_movrels_b32_e32 v45, v3                                  // 000000133894: 7E5A8703
	v_add_nc_u32_e32 v42, 4, v42                               // 000000133898: 4A545484
	s_add_i32 s6, s6, 1                                        // 00000013389C: 81068106
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001338A0: BF870003
	v_cmp_lt_u32_e32 vcc_lo, 0x37f, v43                        // 0000001338A4: 7C9256FF 0000037F
	s_or_b32 s4, vcc_lo, s4                                    // 0000001338AC: 8C04046A
	s_waitcnt lgkmcnt(0)                                       // 0000001338B0: BF89FC07
	v_mul_f32_e32 v44, v45, v44                                // 0000001338B4: 1058592D
	ds_store_b32 v41, v44 offset:13056                         // 0000001338B8: D8343300 00002C29
	v_add_nc_u32_e32 v41, 0x204, v41                           // 0000001338C0: 4A5252FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001338C8: 917E047E
	s_cbranch_execnz 65516                                     // 0000001338CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2680>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001338D0: 8C7E047E
	v_dual_mov_b32 v42, v36 :: v_dual_mov_b32 v41, v35         // 0000001338D4: CA100124 2A280123
	v_mov_b32_e32 v43, v50                                     // 0000001338DC: 7E560332
	s_mov_b32 s7, 0                                            // 0000001338E0: BE870080
	s_mov_b32 s6, 0                                            // 0000001338E4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000001338E8: BF89FC07
	s_barrier                                                  // 0000001338EC: BFBD0000
	buffer_gl0_inv                                             // 0000001338F0: E0AC0000 00000000
	s_nop 0                                                    // 0000001338F8: BF800000
	s_nop 0                                                    // 0000001338FC: BF800000
	global_load_b32 v44, v[41:42], off                         // 000000133900: DC520000 2C7C0029
	v_add_nc_u32_e32 v43, 0x80, v43                            // 000000133908: 4A5656FF 00000080
	.long 0xd7006a29                                           // 000000133910: D7006A29
	v_cndmask_b32_e32 v1, 0x6000, v41, vcc_lo                  // 000000133914: 020252FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013391C: BF870191
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 000000133920: D5207C2A 01AA5480
	.long 0xd4490004                                           // 000000133928: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v43, vcc_lo                   // 00000013392C: 020256FF 0000037F
	s_mov_b32 m0, s7                                           // 000000133934: BEFD0007
	s_add_i32 s7, s7, 1                                        // 000000133938: 81078107
	s_or_b32 s6, s4, s6                                        // 00000013393C: 8C060604
	s_waitcnt vmcnt(0)                                         // 000000133940: BF8903F7
	v_movreld_b32_e32 v3, v44                                  // 000000133944: 7E06852C
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000133948: 917E067E
	s_cbranch_execnz 65516                                     // 00000013394C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2700>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000133950: 8C7E067E
	v_dual_mov_b32 v72, v0 :: v_dual_add_nc_u32 v73, 0x800, v59// 000000133954: CA200100 484876FF 00000800
	s_mov_b32 s4, 0                                            // 000000133960: BE840080
	ds_load_2addr_b32 v[41:42], v73 offset0:32 offset1:49      // 000000133964: D8DC3120 29000049
	ds_load_2addr_b32 v[43:44], v73 offset0:66 offset1:83      // 00000013396C: D8DC5342 2B000049
	ds_load_2addr_b32 v[45:46], v73 offset0:100 offset1:117    // 000000133974: D8DC7564 2D000049
	ds_load_2addr_b32 v[47:48], v73 offset0:134 offset1:151    // 00000013397C: D8DC9786 2F000049
	s_set_inst_prefetch_distance 0x1                           // 000000133984: BF840001
	s_nop 0                                                    // 000000133988: BF800000
	s_nop 0                                                    // 00000013398C: BF800000
	s_nop 0                                                    // 000000133990: BF800000
	s_nop 0                                                    // 000000133994: BF800000
	s_nop 0                                                    // 000000133998: BF800000
	s_nop 0                                                    // 00000013399C: BF800000
	s_nop 0                                                    // 0000001339A0: BF800000
	s_nop 0                                                    // 0000001339A4: BF800000
	s_nop 0                                                    // 0000001339A8: BF800000
	s_nop 0                                                    // 0000001339AC: BF800000
	s_nop 0                                                    // 0000001339B0: BF800000
	s_nop 0                                                    // 0000001339B4: BF800000
	s_nop 0                                                    // 0000001339B8: BF800000
	s_nop 0                                                    // 0000001339BC: BF800000
	v_lshrrev_b32_e32 v74, 4, v72                              // 0000001339C0: 32949084
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v72                        // 0000001339C4: 7C9290FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001339CC: BF870002
	v_lshlrev_b32_e32 v81, 2, v74                              // 0000001339D0: 30A29482
	v_mad_u64_u32 v[74:75], null, 0x44, v74, v[11:12]          // 0000001339D4: D6FE7C4A 042E94FF 00000044
	s_or_b32 s4, vcc_lo, s4                                    // 0000001339E0: 8C04046A
	v_add_nc_u32_e32 v75, 0x3200, v81                          // 0000001339E4: 4A96A2FF 00003200
	v_add_nc_u32_e32 v77, 0x3600, v81                          // 0000001339EC: 4A9AA2FF 00003600
	v_add_nc_u32_e32 v79, 0x3a00, v81                          // 0000001339F4: 4A9EA2FF 00003A00
	ds_load_b32 v82, v74                                       // 0000001339FC: D8D80000 5200004A
	ds_load_2addr_b32 v[75:76], v75 offset0:64 offset1:193     // 000000133A04: D8DCC140 4B00004B
	ds_load_2addr_b32 v[77:78], v77 offset0:66 offset1:195     // 000000133A0C: D8DCC342 4D00004D
	ds_load_2addr_b32 v[79:80], v79 offset0:68 offset1:197     // 000000133A14: D8DCC544 4F00004F
	s_waitcnt lgkmcnt(2)                                       // 000000133A1C: BF89FC27
	v_fmac_f32_e32 v82, v75, v41                               // 000000133A20: 56A4534B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000133A24: BF8700C1
	v_dual_fmac_f32 v82, v76, v42 :: v_dual_add_nc_u32 v75, 0x3e00, v81// 000000133A28: C820554C 524AA2FF 00003E00
	ds_load_2addr_b32 v[75:76], v75 offset0:70 offset1:199     // 000000133A34: D8DCC746 4B00004B
	s_waitcnt lgkmcnt(2)                                       // 000000133A3C: BF89FC27
	v_fmac_f32_e32 v82, v77, v43                               // 000000133A40: 56A4574D
	v_fmac_f32_e32 v82, v78, v44                               // 000000133A44: 56A4594E
	s_waitcnt lgkmcnt(1)                                       // 000000133A48: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133A4C: BF870091
	v_fmac_f32_e32 v82, v79, v45                               // 000000133A50: 56A45B4F
	v_fmac_f32_e32 v82, v80, v46                               // 000000133A54: 56A45D50
	s_waitcnt lgkmcnt(0)                                       // 000000133A58: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133A5C: BF870091
	v_dual_fmac_f32 v82, v75, v47 :: v_dual_add_nc_u32 v75, 0x80, v72// 000000133A60: C8205F4B 524A90FF 00000080
	v_fmac_f32_e32 v82, v76, v48                               // 000000133A6C: 56A4614C
	s_delay_alu instid0(VALU_DEP_2)                            // 000000133A70: BF870002
	v_mov_b32_e32 v72, v75                                     // 000000133A74: 7E90034B
	ds_store_b32 v74, v82                                      // 000000133A78: D8340000 0000524A
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000133A80: 917E047E
	s_cbranch_execnz 65486                                     // 000000133A84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27c0>
	s_set_inst_prefetch_distance 0x2                           // 000000133A88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000133A8C: 8C7E047E
	v_dual_mov_b32 v41, v52 :: v_dual_mov_b32 v42, 0           // 000000133A90: CA100134 292A0080
	v_mov_b32_e32 v43, v50                                     // 000000133A98: 7E560332
	s_mov_b32 s6, 0                                            // 000000133A9C: BE860080
	s_mov_b32 s4, 0                                            // 000000133AA0: BE840080
	s_waitcnt lgkmcnt(0)                                       // 000000133AA4: BF89FC07
	s_barrier                                                  // 000000133AA8: BFBD0000
	buffer_gl0_inv                                             // 000000133AAC: E0AC0000 00000000
	s_nop 0                                                    // 000000133AB4: BF800000
	s_nop 0                                                    // 000000133AB8: BF800000
	s_nop 0                                                    // 000000133ABC: BF800000
	ds_load_b32 v44, v42 offset:17344                          // 000000133AC0: D8D843C0 2C00002A
	s_mov_b32 m0, s6                                           // 000000133AC8: BEFD0006
	v_add_nc_u32_e32 v43, 0x80, v43                            // 000000133ACC: 4A5656FF 00000080
	v_movrels_b32_e32 v45, v3                                  // 000000133AD4: 7E5A8703
	v_add_nc_u32_e32 v42, 4, v42                               // 000000133AD8: 4A545484
	s_add_i32 s6, s6, 1                                        // 000000133ADC: 81068106
	s_delay_alu instid0(VALU_DEP_3)                            // 000000133AE0: BF870003
	v_cmp_lt_u32_e32 vcc_lo, 0x37f, v43                        // 000000133AE4: 7C9256FF 0000037F
	s_or_b32 s4, vcc_lo, s4                                    // 000000133AEC: 8C04046A
	s_waitcnt lgkmcnt(0)                                       // 000000133AF0: BF89FC07
	v_mul_f32_e32 v44, v45, v44                                // 000000133AF4: 1058592D
	ds_store_b32 v41, v44 offset:13056                         // 000000133AF8: D8343300 00002C29
	v_add_nc_u32_e32 v41, 0x204, v41                           // 000000133B00: 4A5252FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000133B08: 917E047E
	s_cbranch_execnz 65516                                     // 000000133B0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x28c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000133B10: 8C7E047E
	v_dual_mov_b32 v42, v38 :: v_dual_mov_b32 v41, v37         // 000000133B14: CA100126 2A280125
	v_mov_b32_e32 v43, v50                                     // 000000133B1C: 7E560332
	s_mov_b32 s7, 0                                            // 000000133B20: BE870080
	s_mov_b32 s6, 0                                            // 000000133B24: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000133B28: BF89FC07
	s_barrier                                                  // 000000133B2C: BFBD0000
	buffer_gl0_inv                                             // 000000133B30: E0AC0000 00000000
	s_nop 0                                                    // 000000133B38: BF800000
	s_nop 0                                                    // 000000133B3C: BF800000
	global_load_b32 v44, v[41:42], off                         // 000000133B40: DC520000 2C7C0029
	v_add_nc_u32_e32 v43, 0x80, v43                            // 000000133B48: 4A5656FF 00000080
	.long 0xd7006a29                                           // 000000133B50: D7006A29
	v_cndmask_b32_e32 v1, 0x6000, v41, vcc_lo                  // 000000133B54: 020252FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000133B5C: BF870191
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 000000133B60: D5207C2A 01AA5480
	.long 0xd4490004                                           // 000000133B68: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v43, vcc_lo                   // 000000133B6C: 020256FF 0000037F
	s_mov_b32 m0, s7                                           // 000000133B74: BEFD0007
	s_add_i32 s7, s7, 1                                        // 000000133B78: 81078107
	s_or_b32 s6, s4, s6                                        // 000000133B7C: 8C060604
	s_waitcnt vmcnt(0)                                         // 000000133B80: BF8903F7
	v_movreld_b32_e32 v3, v44                                  // 000000133B84: 7E06852C
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000133B88: 917E067E
	s_cbranch_execnz 65516                                     // 000000133B8C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2940>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000133B90: 8C7E067E
	v_add_nc_u32_e32 v72, 0xc00, v59                           // 000000133B94: 4A9076FF 00000C00
	s_mov_b32 s4, 0                                            // 000000133B9C: BE840080
	ds_load_2addr_b32 v[41:42], v73 offset0:168 offset1:185    // 000000133BA0: D8DCB9A8 29000049
	ds_load_2addr_b32 v[43:44], v73 offset0:202 offset1:219    // 000000133BA8: D8DCDBCA 2B000049
	ds_load_2addr_b32 v[45:46], v73 offset0:236 offset1:253    // 000000133BB0: D8DCFDEC 2D000049
	ds_load_2addr_b32 v[47:48], v72 offset0:14 offset1:31      // 000000133BB8: D8DC1F0E 2F000048
	v_mov_b32_e32 v73, v0                                      // 000000133BC0: 7E920300
	s_set_inst_prefetch_distance 0x1                           // 000000133BC4: BF840001
	s_nop 0                                                    // 000000133BC8: BF800000
	s_nop 0                                                    // 000000133BCC: BF800000
	s_nop 0                                                    // 000000133BD0: BF800000
	s_nop 0                                                    // 000000133BD4: BF800000
	s_nop 0                                                    // 000000133BD8: BF800000
	s_nop 0                                                    // 000000133BDC: BF800000
	s_nop 0                                                    // 000000133BE0: BF800000
	s_nop 0                                                    // 000000133BE4: BF800000
	s_nop 0                                                    // 000000133BE8: BF800000
	s_nop 0                                                    // 000000133BEC: BF800000
	s_nop 0                                                    // 000000133BF0: BF800000
	s_nop 0                                                    // 000000133BF4: BF800000
	s_nop 0                                                    // 000000133BF8: BF800000
	s_nop 0                                                    // 000000133BFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000133C00: BF870121
	v_lshrrev_b32_e32 v74, 4, v73                              // 000000133C04: 32949284
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v73                        // 000000133C08: 7C9292FF 0000077F
	v_lshlrev_b32_e32 v81, 2, v74                              // 000000133C10: 30A29482
	v_mad_u64_u32 v[74:75], null, 0x44, v74, v[11:12]          // 000000133C14: D6FE7C4A 042E94FF 00000044
	s_or_b32 s4, vcc_lo, s4                                    // 000000133C20: 8C04046A
	v_add_nc_u32_e32 v75, 0x3200, v81                          // 000000133C24: 4A96A2FF 00003200
	v_add_nc_u32_e32 v77, 0x3600, v81                          // 000000133C2C: 4A9AA2FF 00003600
	v_add_nc_u32_e32 v79, 0x3a00, v81                          // 000000133C34: 4A9EA2FF 00003A00
	ds_load_b32 v82, v74                                       // 000000133C3C: D8D80000 5200004A
	ds_load_2addr_b32 v[75:76], v75 offset0:64 offset1:193     // 000000133C44: D8DCC140 4B00004B
	ds_load_2addr_b32 v[77:78], v77 offset0:66 offset1:195     // 000000133C4C: D8DCC342 4D00004D
	ds_load_2addr_b32 v[79:80], v79 offset0:68 offset1:197     // 000000133C54: D8DCC544 4F00004F
	s_waitcnt lgkmcnt(2)                                       // 000000133C5C: BF89FC27
	v_fmac_f32_e32 v82, v75, v41                               // 000000133C60: 56A4534B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000133C64: BF8700C1
	v_dual_fmac_f32 v82, v76, v42 :: v_dual_add_nc_u32 v75, 0x3e00, v81// 000000133C68: C820554C 524AA2FF 00003E00
	ds_load_2addr_b32 v[75:76], v75 offset0:70 offset1:199     // 000000133C74: D8DCC746 4B00004B
	s_waitcnt lgkmcnt(2)                                       // 000000133C7C: BF89FC27
	v_fmac_f32_e32 v82, v77, v43                               // 000000133C80: 56A4574D
	v_fmac_f32_e32 v82, v78, v44                               // 000000133C84: 56A4594E
	s_waitcnt lgkmcnt(1)                                       // 000000133C88: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133C8C: BF870091
	v_fmac_f32_e32 v82, v79, v45                               // 000000133C90: 56A45B4F
	v_fmac_f32_e32 v82, v80, v46                               // 000000133C94: 56A45D50
	s_waitcnt lgkmcnt(0)                                       // 000000133C98: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133C9C: BF870091
	v_dual_fmac_f32 v82, v75, v47 :: v_dual_add_nc_u32 v75, 0x80, v73// 000000133CA0: C8205F4B 524A92FF 00000080
	v_dual_fmac_f32 v82, v76, v48 :: v_dual_mov_b32 v73, v75   // 000000133CAC: C810614C 5248014B
	ds_store_b32 v74, v82                                      // 000000133CB4: D8340000 0000524A
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000133CBC: 917E047E
	s_cbranch_execnz 65487                                     // 000000133CC0: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a00>
	s_set_inst_prefetch_distance 0x2                           // 000000133CC4: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000133CC8: 8C7E047E
	v_dual_mov_b32 v41, v52 :: v_dual_mov_b32 v42, 0           // 000000133CCC: CA100134 292A0080
	v_mov_b32_e32 v43, v50                                     // 000000133CD4: 7E560332
	s_mov_b32 s6, 0                                            // 000000133CD8: BE860080
	s_mov_b32 s4, 0                                            // 000000133CDC: BE840080
	s_waitcnt lgkmcnt(0)                                       // 000000133CE0: BF89FC07
	s_barrier                                                  // 000000133CE4: BFBD0000
	buffer_gl0_inv                                             // 000000133CE8: E0AC0000 00000000
	s_nop 0                                                    // 000000133CF0: BF800000
	s_nop 0                                                    // 000000133CF4: BF800000
	s_nop 0                                                    // 000000133CF8: BF800000
	s_nop 0                                                    // 000000133CFC: BF800000
	ds_load_b32 v44, v42 offset:17376                          // 000000133D00: D8D843E0 2C00002A
	s_mov_b32 m0, s6                                           // 000000133D08: BEFD0006
	v_add_nc_u32_e32 v43, 0x80, v43                            // 000000133D0C: 4A5656FF 00000080
	v_movrels_b32_e32 v45, v3                                  // 000000133D14: 7E5A8703
	v_add_nc_u32_e32 v42, 4, v42                               // 000000133D18: 4A545484
	s_add_i32 s6, s6, 1                                        // 000000133D1C: 81068106
	s_delay_alu instid0(VALU_DEP_3)                            // 000000133D20: BF870003
	v_cmp_lt_u32_e32 vcc_lo, 0x37f, v43                        // 000000133D24: 7C9256FF 0000037F
	s_or_b32 s4, vcc_lo, s4                                    // 000000133D2C: 8C04046A
	s_waitcnt lgkmcnt(0)                                       // 000000133D30: BF89FC07
	v_mul_f32_e32 v44, v45, v44                                // 000000133D34: 1058592D
	ds_store_b32 v41, v44 offset:13056                         // 000000133D38: D8343300 00002C29
	v_add_nc_u32_e32 v41, 0x204, v41                           // 000000133D40: 4A5252FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000133D48: 917E047E
	s_cbranch_execnz 65516                                     // 000000133D4C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b00>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000133D50: 8C7E047E
	v_dual_mov_b32 v42, v40 :: v_dual_mov_b32 v41, v39         // 000000133D54: CA100128 2A280127
	v_mov_b32_e32 v43, v50                                     // 000000133D5C: 7E560332
	s_mov_b32 s7, 0                                            // 000000133D60: BE870080
	s_mov_b32 s6, 0                                            // 000000133D64: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000133D68: BF89FC07
	s_barrier                                                  // 000000133D6C: BFBD0000
	buffer_gl0_inv                                             // 000000133D70: E0AC0000 00000000
	s_nop 0                                                    // 000000133D78: BF800000
	s_nop 0                                                    // 000000133D7C: BF800000
	global_load_b32 v44, v[41:42], off                         // 000000133D80: DC520000 2C7C0029
	v_add_nc_u32_e32 v43, 0x80, v43                            // 000000133D88: 4A5656FF 00000080
	.long 0xd7006a29                                           // 000000133D90: D7006A29
	v_cndmask_b32_e32 v1, 0x6000, v41, vcc_lo                  // 000000133D94: 020252FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000133D9C: BF870191
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 000000133DA0: D5207C2A 01AA5480
	.long 0xd4490004                                           // 000000133DA8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v43, vcc_lo                   // 000000133DAC: 020256FF 0000037F
	s_mov_b32 m0, s7                                           // 000000133DB4: BEFD0007
	s_add_i32 s7, s7, 1                                        // 000000133DB8: 81078107
	s_or_b32 s6, s4, s6                                        // 000000133DBC: 8C060604
	s_waitcnt vmcnt(0)                                         // 000000133DC0: BF8903F7
	v_movreld_b32_e32 v3, v44                                  // 000000133DC4: 7E06852C
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000133DC8: 917E067E
	s_cbranch_execnz 65516                                     // 000000133DCC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b80>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000133DD0: 8C7E067E
	ds_load_2addr_b32 v[41:42], v72 offset0:48 offset1:65      // 000000133DD4: D8DC4130 29000048
	ds_load_2addr_b32 v[43:44], v72 offset0:82 offset1:99      // 000000133DDC: D8DC6352 2B000048
	ds_load_2addr_b32 v[45:46], v72 offset0:116 offset1:133    // 000000133DE4: D8DC8574 2D000048
	ds_load_2addr_b32 v[47:48], v72 offset0:150 offset1:167    // 000000133DEC: D8DCA796 2F000048
	v_mov_b32_e32 v73, v0                                      // 000000133DF4: 7E920300
	s_mov_b32 s4, 0                                            // 000000133DF8: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000133DFC: BF840001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000133E00: BF870121
	v_lshrrev_b32_e32 v74, 4, v73                              // 000000133E04: 32949284
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v73                        // 000000133E08: 7C9292FF 0000077F
	v_lshlrev_b32_e32 v81, 2, v74                              // 000000133E10: 30A29482
	v_mad_u64_u32 v[74:75], null, 0x44, v74, v[11:12]          // 000000133E14: D6FE7C4A 042E94FF 00000044
	s_or_b32 s4, vcc_lo, s4                                    // 000000133E20: 8C04046A
	v_add_nc_u32_e32 v75, 0x3200, v81                          // 000000133E24: 4A96A2FF 00003200
	v_add_nc_u32_e32 v77, 0x3600, v81                          // 000000133E2C: 4A9AA2FF 00003600
	v_add_nc_u32_e32 v79, 0x3a00, v81                          // 000000133E34: 4A9EA2FF 00003A00
	ds_load_b32 v82, v74                                       // 000000133E3C: D8D80000 5200004A
	ds_load_2addr_b32 v[75:76], v75 offset0:64 offset1:193     // 000000133E44: D8DCC140 4B00004B
	ds_load_2addr_b32 v[77:78], v77 offset0:66 offset1:195     // 000000133E4C: D8DCC342 4D00004D
	ds_load_2addr_b32 v[79:80], v79 offset0:68 offset1:197     // 000000133E54: D8DCC544 4F00004F
	s_waitcnt lgkmcnt(2)                                       // 000000133E5C: BF89FC27
	v_fmac_f32_e32 v82, v75, v41                               // 000000133E60: 56A4534B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000133E64: BF8700C1
	v_dual_fmac_f32 v82, v76, v42 :: v_dual_add_nc_u32 v75, 0x3e00, v81// 000000133E68: C820554C 524AA2FF 00003E00
	ds_load_2addr_b32 v[75:76], v75 offset0:70 offset1:199     // 000000133E74: D8DCC746 4B00004B
	s_waitcnt lgkmcnt(2)                                       // 000000133E7C: BF89FC27
	v_fmac_f32_e32 v82, v77, v43                               // 000000133E80: 56A4574D
	v_fmac_f32_e32 v82, v78, v44                               // 000000133E84: 56A4594E
	s_waitcnt lgkmcnt(1)                                       // 000000133E88: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133E8C: BF870091
	v_fmac_f32_e32 v82, v79, v45                               // 000000133E90: 56A45B4F
	v_fmac_f32_e32 v82, v80, v46                               // 000000133E94: 56A45D50
	s_waitcnt lgkmcnt(0)                                       // 000000133E98: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133E9C: BF870091
	v_dual_fmac_f32 v82, v75, v47 :: v_dual_add_nc_u32 v75, 0x80, v73// 000000133EA0: C8205F4B 524A92FF 00000080
	v_dual_fmac_f32 v82, v76, v48 :: v_dual_mov_b32 v73, v75   // 000000133EAC: C810614C 5248014B
	ds_store_b32 v74, v82                                      // 000000133EB4: D8340000 0000524A
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000133EBC: 917E047E
	s_cbranch_execnz 65487                                     // 000000133EC0: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c00>
	s_set_inst_prefetch_distance 0x2                           // 000000133EC4: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000133EC8: 8C7E047E
	v_dual_mov_b32 v41, v52 :: v_dual_mov_b32 v42, 0           // 000000133ECC: CA100134 292A0080
	v_mov_b32_e32 v43, v50                                     // 000000133ED4: 7E560332
	s_mov_b32 s6, 0                                            // 000000133ED8: BE860080
	s_mov_b32 s4, 0                                            // 000000133EDC: BE840080
	s_waitcnt lgkmcnt(0)                                       // 000000133EE0: BF89FC07
	s_barrier                                                  // 000000133EE4: BFBD0000
	buffer_gl0_inv                                             // 000000133EE8: E0AC0000 00000000
	s_nop 0                                                    // 000000133EF0: BF800000
	s_nop 0                                                    // 000000133EF4: BF800000
	s_nop 0                                                    // 000000133EF8: BF800000
	s_nop 0                                                    // 000000133EFC: BF800000
	ds_load_b32 v44, v42 offset:17408                          // 000000133F00: D8D84400 2C00002A
	s_mov_b32 m0, s6                                           // 000000133F08: BEFD0006
	v_add_nc_u32_e32 v43, 0x80, v43                            // 000000133F0C: 4A5656FF 00000080
	v_movrels_b32_e32 v45, v3                                  // 000000133F14: 7E5A8703
	v_add_nc_u32_e32 v42, 4, v42                               // 000000133F18: 4A545484
	s_add_i32 s6, s6, 1                                        // 000000133F1C: 81068106
	s_delay_alu instid0(VALU_DEP_3)                            // 000000133F20: BF870003
	v_cmp_lt_u32_e32 vcc_lo, 0x37f, v43                        // 000000133F24: 7C9256FF 0000037F
	s_or_b32 s4, vcc_lo, s4                                    // 000000133F2C: 8C04046A
	s_waitcnt lgkmcnt(0)                                       // 000000133F30: BF89FC07
	v_mul_f32_e32 v44, v45, v44                                // 000000133F34: 1058592D
	ds_store_b32 v41, v44 offset:13056                         // 000000133F38: D8343300 00002C29
	v_add_nc_u32_e32 v41, 0x204, v41                           // 000000133F40: 4A5252FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000133F48: 917E047E
	s_cbranch_execnz 65516                                     // 000000133F4C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d00>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000133F50: 8C7E047E
	v_add_nc_u32_e32 v45, 0xe00, v59                           // 000000133F54: 4A5A76FF 00000E00
	v_add_nc_u32_e32 v47, 0x1000, v59                          // 000000133F5C: 4A5E76FF 00001000
	s_waitcnt lgkmcnt(0)                                       // 000000133F64: BF89FC07
	s_barrier                                                  // 000000133F68: BFBD0000
	buffer_gl0_inv                                             // 000000133F6C: E0AC0000 00000000
	ds_load_2addr_b32 v[41:42], v72 offset0:184 offset1:201    // 000000133F74: D8DCC9B8 29000048
	ds_load_2addr_b32 v[43:44], v72 offset0:218 offset1:235    // 000000133F7C: D8DCEBDA 2B000048
	ds_load_2addr_b32 v[45:46], v45 offset0:124 offset1:141    // 000000133F84: D8DC8D7C 2D00002D
	ds_load_2addr_b32 v[47:48], v47 offset0:30 offset1:47      // 000000133F8C: D8DC2F1E 2F00002F
	v_mov_b32_e32 v72, v0                                      // 000000133F94: 7E900300
	s_mov_b32 s4, 0                                            // 000000133F98: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000133F9C: BF840001
	s_nop 0                                                    // 000000133FA0: BF800000
	s_nop 0                                                    // 000000133FA4: BF800000
	s_nop 0                                                    // 000000133FA8: BF800000
	s_nop 0                                                    // 000000133FAC: BF800000
	s_nop 0                                                    // 000000133FB0: BF800000
	s_nop 0                                                    // 000000133FB4: BF800000
	s_nop 0                                                    // 000000133FB8: BF800000
	s_nop 0                                                    // 000000133FBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000133FC0: BF870121
	v_lshrrev_b32_e32 v73, 4, v72                              // 000000133FC4: 32929084
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v72                        // 000000133FC8: 7C9290FF 0000077F
	v_lshlrev_b32_e32 v80, 2, v73                              // 000000133FD0: 30A09282
	v_mad_u64_u32 v[73:74], null, 0x44, v73, v[11:12]          // 000000133FD4: D6FE7C49 042E92FF 00000044
	s_or_b32 s4, vcc_lo, s4                                    // 000000133FE0: 8C04046A
	v_add_nc_u32_e32 v74, 0x3200, v80                          // 000000133FE4: 4A94A0FF 00003200
	v_add_nc_u32_e32 v76, 0x3600, v80                          // 000000133FEC: 4A98A0FF 00003600
	v_add_nc_u32_e32 v78, 0x3a00, v80                          // 000000133FF4: 4A9CA0FF 00003A00
	ds_load_b32 v81, v73                                       // 000000133FFC: D8D80000 51000049
	ds_load_2addr_b32 v[74:75], v74 offset0:64 offset1:193     // 000000134004: D8DCC140 4A00004A
	ds_load_2addr_b32 v[76:77], v76 offset0:66 offset1:195     // 00000013400C: D8DCC342 4C00004C
	ds_load_2addr_b32 v[78:79], v78 offset0:68 offset1:197     // 000000134014: D8DCC544 4E00004E
	s_waitcnt lgkmcnt(2)                                       // 00000013401C: BF89FC27
	v_dual_fmac_f32 v81, v74, v41 :: v_dual_add_nc_u32 v74, 0x3e00, v80// 000000134020: C820534A 514AA0FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013402C: BF8700C1
	v_fmac_f32_e32 v81, v75, v42                               // 000000134030: 56A2554B
	ds_load_2addr_b32 v[74:75], v74 offset0:70 offset1:199     // 000000134034: D8DCC746 4A00004A
	s_waitcnt lgkmcnt(2)                                       // 00000013403C: BF89FC27
	v_fmac_f32_e32 v81, v76, v43                               // 000000134040: 56A2574C
	v_fmac_f32_e32 v81, v77, v44                               // 000000134044: 56A2594D
	s_waitcnt lgkmcnt(1)                                       // 000000134048: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013404C: BF870091
	v_fmac_f32_e32 v81, v78, v45                               // 000000134050: 56A25B4E
	v_fmac_f32_e32 v81, v79, v46                               // 000000134054: 56A25D4F
	s_waitcnt lgkmcnt(0)                                       // 000000134058: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013405C: BF870091
	v_dual_fmac_f32 v81, v74, v47 :: v_dual_add_nc_u32 v74, 0x80, v72// 000000134060: C8205F4A 514A90FF 00000080
	v_dual_fmac_f32 v81, v75, v48 :: v_dual_mov_b32 v72, v74   // 00000013406C: C810614B 5148014A
	ds_store_b32 v73, v81                                      // 000000134074: D8340000 00005149
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000013407C: 917E047E
	s_cbranch_execnz 65487                                     // 000000134080: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2dc0>
	s_set_inst_prefetch_distance 0x2                           // 000000134084: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000134088: 8C7E047E
	.long 0xd7006a0f                                           // 00000013408C: D7006A0F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 000000134090: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000134098: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 00000013409C: D5207C10 01AA2080
	.long 0xd7006a11                                           // 0000001340A4: D7006A11
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000001340A8: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 0000001340B0: D5207C12 01AA2480
	.long 0xd7006a13                                           // 0000001340B8: D7006A13
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000001340BC: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001340C4: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, vcc_lo              // 0000001340C8: D5207C14 01AA2880
	.long 0xd7006a15                                           // 0000001340D0: D7006A15
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000001340D4: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 0000001340DC: D5207C16 01AA2C80
	.long 0xd7006a17                                           // 0000001340E4: D7006A17
	v_cndmask_b32_e32 v1, 0xc0000, v23, vcc_lo                 // 0000001340E8: 02022EFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001340F0: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, vcc_lo              // 0000001340F4: D5207C18 01AA3080
	.long 0xd7006a19                                           // 0000001340FC: D7006A19
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 000000134100: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, vcc_lo              // 000000134108: D5207C1A 01AA3480
	.long 0xd7006a1b                                           // 000000134110: D7006A1B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 000000134114: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013411C: BF8700A1
	v_add_co_ci_u32_e64 v28, null, 0, v28, vcc_lo              // 000000134120: D5207C1C 01AA3880
	.long 0xd7006a1d                                           // 000000134128: D7006A1D
	v_cndmask_b32_e32 v1, 0x180000, v29, vcc_lo                // 00000013412C: 02023AFF 00180000
	v_add_co_ci_u32_e64 v30, null, 0, v30, vcc_lo              // 000000134134: D5207C1E 01AA3C80
	.long 0xd7006a1f                                           // 00000013413C: D7006A1F
	v_cndmask_b32_e32 v1, 0x180000, v31, vcc_lo                // 000000134140: 02023EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000134148: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v32, vcc_lo              // 00000013414C: D5207C20 01AA4080
	.long 0xd7006a21                                           // 000000134154: D7006A21
	v_cndmask_b32_e32 v1, 0x180000, v33, vcc_lo                // 000000134158: 020242FF 00180000
	v_add_co_ci_u32_e64 v34, null, 0, v34, vcc_lo              // 000000134160: D5207C22 01AA4480
	.long 0xd7006a23                                           // 000000134168: D7006A23
	v_cndmask_b32_e32 v1, 0x180000, v35, vcc_lo                // 00000013416C: 020246FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000134174: BF8700A1
	v_add_co_ci_u32_e64 v36, null, 0, v36, vcc_lo              // 000000134178: D5207C24 01AA4880
	.long 0xd7006a25                                           // 000000134180: D7006A25
	v_cndmask_b32_e32 v1, 0x180000, v37, vcc_lo                // 000000134184: 02024AFF 00180000
	v_add_co_ci_u32_e64 v38, null, 0, v38, vcc_lo              // 00000013418C: D5207C26 01AA4C80
	.long 0xd7006a27                                           // 000000134194: D7006A27
	v_cndmask_b32_e32 v1, 0x180000, v39, vcc_lo                // 000000134198: 02024EFF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001341A0: BF870001
	v_add_co_ci_u32_e64 v40, null, 0, v40, vcc_lo              // 0000001341A4: D5207C28 01AA5080
	s_add_i32 s5, s5, 1                                        // 0000001341AC: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000001341B0: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000001341B4: BF062105
	s_barrier                                                  // 0000001341B8: BFBD0000
	buffer_gl0_inv                                             // 0000001341BC: E0AC0000 00000000
	s_cbranch_scc0 62740                                       // 0000001341C4: BFA1F514 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x418>
	v_mov_b32_e32 v4, v50                                      // 0000001341C8: 7E080332
	s_add_u32 s0, s28, s20                                     // 0000001341CC: 8000141C
	.long 0xd73c0000                                           // 0000001341D0: D73C0000
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001341D4: 02020289
	s_addc_u32 s1, s29, s21                                    // 0000001341D8: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000001341DC: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000001341E0: 82031319
	s_add_u32 s0, s2, s0                                       // 0000001341E4: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000001341E8: 82010103
	.long 0xd7006a00                                           // 0000001341EC: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000001341F0: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001341F4: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000001341F8: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000134200: BE810080
	.long 0xd7006a00                                           // 000000134204: D7006A00
	v_cndmask_b32_e32 v1, v0, v51, vcc_lo                      // 000000134208: 02026700
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000013420C: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000134214: BF870092
	.long 0xd7006a00                                           // 000000134218: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000013421C: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000134220: D5207C01 01AA0211
	s_nop 0                                                    // 000000134228: BF800000
	s_nop 0                                                    // 00000013422C: BF800000
	s_nop 0                                                    // 000000134230: BF800000
	s_nop 0                                                    // 000000134234: BF800000
	s_nop 0                                                    // 000000134238: BF800000
	s_nop 0                                                    // 00000013423C: BF800000
	ds_load_b32 v2, v49                                        // 000000134240: D8D80000 02000031
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000134248: 4A0808FF 00000080
	v_add_nc_u32_e32 v49, 0x220, v49                           // 000000134250: 4A6262FF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000134258: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000013425C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 000000134264: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 000000134268: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 00000013426C: DC6A0000 007C0200
	.long 0xd7000000                                           // 000000134274: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000134278: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 000000134280: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000134288: 917E017E
	s_cbranch_execnz 65516                                     // 00000013428C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3040>
	s_endpgm                                                   // 000000134290: BFB00000
		...

