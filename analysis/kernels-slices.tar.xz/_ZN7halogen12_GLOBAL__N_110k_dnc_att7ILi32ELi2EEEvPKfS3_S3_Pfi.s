0000000000227d00 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi2EEEvPKfS3_S3_Pfi>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi2EEEvPKfS3_S3_Pfi():
	s_load_b256 s[4:11], s[0:1], null                          // 000000227D00: F40C0100 F8000000
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 000000227D08: CA240100 040000FF 0000007F
	s_mov_b32 s28, s3                                          // 000000227D14: BE9C0003
	s_and_b32 s30, s2, 0xf8000001                              // 000000227D18: 8B1EFF02 F8000001
	s_lshr_b32 s3, s2, 1                                       // 000000227D20: 85038102
	s_delay_alu instid0(VALU_DEP_1)                            // 000000227D24: BF870001
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000227D28: 30020282
	s_lshl_b32 s2, s30, 5                                      // 000000227D2C: 8402851E
	s_lshl_b32 s0, s3, 6                                       // 000000227D30: 84008603
	s_ashr_i32 s29, s28, 31                                    // 000000227D34: 861D9F1C
	s_waitcnt lgkmcnt(0)                                       // 000000227D38: BF89FC07
	.long 0xd7000102                                           // 000000227D3C: D7000102
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 000000227D40: 02020206
	s_delay_alu instid0(VALU_DEP_1)                            // 000000227D44: BF870001
	v_add_co_ci_u32_e64 v3, null, s7, 0, s1                    // 000000227D48: D5207C03 00050007
	s_or_b32 s6, s0, s2                                        // 000000227D50: 8C060200
	s_mov_b32 s1, 0                                            // 000000227D54: BE810080
	s_nop 0                                                    // 000000227D58: BF800000
	s_nop 0                                                    // 000000227D5C: BF800000
	s_nop 0                                                    // 000000227D60: BF800000
	s_nop 0                                                    // 000000227D64: BF800000
	s_nop 0                                                    // 000000227D68: BF800000
	s_nop 0                                                    // 000000227D6C: BF800000
	s_nop 0                                                    // 000000227D70: BF800000
	s_nop 0                                                    // 000000227D74: BF800000
	s_nop 0                                                    // 000000227D78: BF800000
	s_nop 0                                                    // 000000227D7C: BF800000
	v_lshrrev_b32_e32 v7, 7, v4                                // 000000227D80: 320E0887
	v_add_nc_u32_e32 v9, 0x100, v4                             // 000000227D84: 4A1208FF 00000100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000227D8C: BF870092
	v_or_b32_e32 v5, s6, v7                                    // 000000227D90: 380A0E06
	v_mad_u64_u32 v[5:6], null, v5, 48, s[28:29]               // 000000227D94: D6FE7C05 00716105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000227D9C: BF870091
	.long 0xd73c0005                                           // 000000227DA0: D73C0005
	v_cndmask_b32_e32 v1, 9, v5, vcc_lo                        // 000000227DA4: 02020A89
	.long 0xd7006a05                                           // 000000227DA8: D7006A05
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 000000227DAC: 02020B02
	s_delay_alu instid0(VALU_DEP_1)                            // 000000227DB0: BF870001
	v_add_co_ci_u32_e64 v6, null, v3, v6, vcc_lo               // 000000227DB4: D5207C06 01AA0D03
	v_cmp_lt_u32_e32 vcc_lo, 0xeff, v4                         // 000000227DBC: 7C9208FF 00000EFF
	v_mov_b32_e32 v4, v9                                       // 000000227DC4: 7E080309
	global_load_b32 v8, v[5:6], off                            // 000000227DC8: DC520000 087C0005
	v_mad_u64_u32 v[5:6], null, 0x204, v7, v[1:2]              // 000000227DD0: D6FE7C05 04060EFF 00000204
	s_or_b32 s1, vcc_lo, s1                                    // 000000227DDC: 8C01016A
	s_waitcnt vmcnt(0)                                         // 000000227DE0: BF8903F7
	ds_store_b32 v5, v8                                        // 000000227DE4: D8340000 00000805
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000227DEC: 917E017E
	s_cbranch_execnz 65507                                     // 000000227DF0: BFA6FFE3 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi2EEEvPKfS3_S3_Pfi+0x80>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000227DF4: 8C7E017E
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000227DF8: 30060082
	s_mov_b32 s1, exec_lo                                      // 000000227DFC: BE81007E
	v_cmpx_gt_u32_e32 64, v0                                   // 000000227E00: 7D9800C0
	s_cbranch_execz 16                                         // 000000227E04: BFA50010 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi2EEEvPKfS3_S3_Pfi+0x148>
	v_or_b32_e32 v1, s0, v0                                    // 000000227E08: 38020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000227E0C: BF8704A1
	v_mad_u64_u32 v[1:2], null, 0xc0, v1, s[8:9]               // 000000227E10: D6FE7C01 002202FF 000000C0
	s_lshl_b64 s[8:9], s[28:29], 2                             // 000000227E1C: 8488821C
	.long 0xd7006a01                                           // 000000227E20: D7006A01
	v_cndmask_b32_e32 v0, v1, v8, vcc_lo                       // 000000227E24: 02001101
	s_delay_alu instid0(VALU_DEP_1)                            // 000000227E28: BF870001
	v_add_co_ci_u32_e64 v2, null, s9, v2, vcc_lo               // 000000227E2C: D5207C02 01AA0409
	global_load_b32 v1, v[1:2], off                            // 000000227E34: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000227E3C: BF8903F7
	ds_store_b32 v3, v1 offset:16512                           // 000000227E40: D8344080 00000103
	s_or_b32 exec_lo, exec_lo, s1                              // 000000227E48: 8C7E017E
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000227E4C: 32020084
	s_sub_i32 s7, 64, s2                                       // 000000227E50: 818702C0
	s_mov_b32 s8, 0                                            // 000000227E54: BE880080
	s_mov_b32 s9, exec_lo                                      // 000000227E58: BE89007E
	s_waitcnt lgkmcnt(0)                                       // 000000227E5C: BF89FC07
	v_and_b32_e32 v4, 14, v1                                   // 000000227E60: 3608028E
	s_barrier                                                  // 000000227E64: BFBD0000
	buffer_gl0_inv                                             // 000000227E68: E0AC0000 00000000
	.long 0xd4cc007e                                           // 000000227E70: D4CC007E
	v_cndmask_b32_e32 v1, s7, v4, vcc_lo                       // 000000227E74: 02020807
	s_cbranch_execz 201                                        // 000000227E78: BFA500C9 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi2EEEvPKfS3_S3_Pfi+0x4a0>
	v_dual_mov_b32 v2, 0 :: v_dual_and_b32 v5, 31, v0          // 000000227E7C: CA240080 0204009F
	s_mul_i32 s0, s3, 48                                       // 000000227E84: 9600B003
	s_mul_hi_u32 s1, s3, 48                                    // 000000227E88: 9681B003
	s_add_u32 s0, s0, s28                                      // 000000227E8C: 80001C00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000227E90: BF8704C1
	v_or_b32_e32 v6, s2, v5                                    // 000000227E94: 380C0A02
	s_addc_u32 s1, s1, s29                                     // 000000227E98: 82011D01
	v_mul_u32_u24_e32 v7, 0x204, v5                            // 000000227E9C: 160E0AFF 00000204
	s_lshl_b64 s[0:1], s[0:1], 14                              // 000000227EA4: 84808E00
	s_add_u32 s0, s10, s0                                      // 000000227EA8: 8000000A
	v_lshlrev_b32_e32 v1, 2, v6                                // 000000227EAC: 30020C82
	s_addc_u32 s1, s11, s1                                     // 000000227EB0: 8201010B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000227EB4: BF870091
	.long 0xd7000008                                           // 000000227EB8: D7000008
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 000000227EBC: 02020200
	v_add_co_ci_u32_e64 v9, null, s1, 0, s0                    // 000000227EC0: D5207C09 00010001
	v_add_nc_u32_e32 v10, 0x4080, v1                           // 000000227EC8: 4A1402FF 00004080
	s_branch 16                                                // 000000227ED0: BFA00010 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi2EEEvPKfS3_S3_Pfi+0x214>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000227ED4: 8C7E007E
	.long 0xd73c000b                                           // 000000227ED8: D73C000B
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 000000227EDC: 02020288
	v_add_nc_u32_e32 v4, 16, v4                                // 000000227EE0: 4A080890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000227EE4: BF870191
	v_cmp_le_u32_e32 vcc_lo, s7, v4                            // 000000227EE8: 7C960807
	.long 0xd700000b                                           // 000000227EEC: D700000B
	v_cndmask_b32_e32 v1, v8, v11, vcc_lo                      // 000000227EF0: 02021708
	s_delay_alu instid0(VALU_DEP_1)                            // 000000227EF4: BF870001
	v_add_co_ci_u32_e64 v12, null, v9, v12, s0                 // 000000227EF8: D5207C0C 00021909
	s_or_b32 s8, vcc_lo, s8                                    // 000000227F00: 8C08086A
	global_store_b32 v[11:12], v13, off                        // 000000227F04: DC6A0000 007C0D0B
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 000000227F0C: 917E087E
	s_cbranch_execz 163                                        // 000000227F10: BFA500A3 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi2EEEvPKfS3_S3_Pfi+0x4a0>
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v1, s6, v4      // 000000227F14: CA200080 0C000806
	v_mov_b32_e32 v11, 0                                       // 000000227F1C: 7E160280
	s_delay_alu instid0(VALU_DEP_2)                            // 000000227F20: BF870002
	v_readfirstlane_b32 s12, v1                                // 000000227F24: 7E180501
	v_mov_b32_e32 v1, v7                                       // 000000227F28: 7E020307
	s_mul_i32 s0, s12, 48                                      // 000000227F2C: 9600B00C
	s_mul_hi_i32 s1, s12, 48                                   // 000000227F30: 9701B00C
	s_add_u32 s0, s0, s28                                      // 000000227F34: 80001C00
	s_addc_u32 s1, s1, s29                                     // 000000227F38: 82011D01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000227F3C: BF870499
	s_lshl_b64 s[0:1], s[0:1], 9                               // 000000227F40: 84808900
	s_add_u32 s31, s4, s0                                      // 000000227F44: 801F0004
	s_addc_u32 s33, s5, s1                                     // 000000227F48: 82210105
	s_or_b32 s0, s12, 1                                        // 000000227F4C: 8C00810C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000227F50: BF8704C9
	s_mul_i32 s1, s0, 48                                       // 000000227F54: 9601B000
	s_mul_hi_i32 s12, s0, 48                                   // 000000227F58: 970CB000
	s_add_u32 s0, s1, s28                                      // 000000227F5C: 80001C01
	s_addc_u32 s1, s12, s29                                    // 000000227F60: 82011D0C
	s_lshl_b64 s[0:1], s[0:1], 9                               // 000000227F64: 84808900
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000227F68: BF870009
	s_add_u32 s34, s4, s0                                      // 000000227F6C: 80220004
	s_addc_u32 s35, s5, s1                                     // 000000227F70: 82230105
	s_mov_b64 s[0:1], 0                                        // 000000227F74: BE800180
	s_set_inst_prefetch_distance 0x1                           // 000000227F78: BF840001
	s_nop 0                                                    // 000000227F7C: BF800000
	s_add_u32 s12, s31, s0                                     // 000000227F80: 800C001F
	s_addc_u32 s13, s33, s1                                    // 000000227F84: 820D0121
	s_add_u32 s20, s34, s0                                     // 000000227F88: 80140022
	s_addc_u32 s21, s35, s1                                    // 000000227F8C: 82150123
	ds_load_2addr_b32 v[13:14], v1 offset1:1                   // 000000227F90: D8DC0100 0D000001
	s_clause 0x1                                               // 000000227F98: BF850001
	s_load_b256 s[12:19], s[12:13], null                       // 000000227F9C: F40C0306 F8000000
	s_load_b256 s[20:27], s[20:21], null                       // 000000227FA4: F40C050A F8000000
	ds_load_2addr_b32 v[15:16], v1 offset0:2 offset1:3         // 000000227FAC: D8DC0302 0F000001
	ds_load_2addr_b32 v[17:18], v1 offset0:4 offset1:5         // 000000227FB4: D8DC0504 11000001
	ds_load_2addr_b32 v[19:20], v1 offset0:6 offset1:7         // 000000227FBC: D8DC0706 13000001
	s_add_u32 s0, s0, 32                                       // 000000227FC4: 8000A000
	s_addc_u32 s1, s1, 0                                       // 000000227FC8: 82018001
	s_cmpk_eq_i32 s0, 0x200                                    // 000000227FCC: B1800200
	v_add_nc_u32_e32 v1, 32, v1                                // 000000227FD0: 4A0202A0
	s_waitcnt lgkmcnt(0)                                       // 000000227FD4: BF89FC07
	v_fmac_f32_e32 v11, s20, v13                               // 000000227FD8: 56161A14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000227FDC: BF870091
	v_dual_fmac_f32 v12, s12, v13 :: v_dual_fmac_f32 v11, s21, v14// 000000227FE0: C8001A0C 0C0A1C15
	v_dual_fmac_f32 v12, s13, v14 :: v_dual_fmac_f32 v11, s22, v15// 000000227FE8: C8001C0D 0C0A1E16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000227FF0: BF870091
	v_dual_fmac_f32 v12, s14, v15 :: v_dual_fmac_f32 v11, s23, v16// 000000227FF4: C8001E0E 0C0A2017
	v_dual_fmac_f32 v12, s15, v16 :: v_dual_fmac_f32 v11, s24, v17// 000000227FFC: C800200F 0C0A2218
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228004: BF870091
	v_dual_fmac_f32 v12, s16, v17 :: v_dual_fmac_f32 v11, s25, v18// 000000228008: C8002210 0C0A2419
	v_fmac_f32_e32 v12, s17, v18                               // 000000228010: 56182411
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228014: BF870091
	v_fmac_f32_e32 v12, s18, v19                               // 000000228018: 56182612
	v_dual_fmac_f32 v11, s26, v19 :: v_dual_fmac_f32 v12, s19, v20// 00000022801C: C800261A 0B0C2813
	s_delay_alu instid0(VALU_DEP_1)                            // 000000228024: BF870001
	v_fmac_f32_e32 v11, s27, v20                               // 000000228028: 5616281B
	s_cbranch_scc0 65492                                       // 00000022802C: BFA1FFD4 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi2EEEvPKfS3_S3_Pfi+0x280>
	s_set_inst_prefetch_distance 0x2                           // 000000228030: BF840002
	v_add_nc_u32_e32 v1, s2, v4                                // 000000228034: 4A020802
	v_mov_b32_e32 v13, 0                                       // 000000228038: 7E1A0280
	v_mov_b32_e32 v15, 0                                       // 00000022803C: 7E1E0280
	s_mov_b32 s0, exec_lo                                      // 000000228040: BE80007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000228044: BF870003
	v_lshlrev_b32_e32 v14, 2, v1                               // 000000228048: 301C0282
	.long 0xd4cb007e                                           // 00000022804C: D4CB007E
	v_cndmask_b32_e32 v1, v5, v4, vcc_lo                       // 000000228050: 02020905
	s_cbranch_execz 33                                         // 000000228054: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi2EEEvPKfS3_S3_Pfi+0x3dc>
	ds_load_b32 v15, v14 offset:16512                          // 000000228058: D8D84080 0F00000E
	ds_load_b32 v16, v10                                       // 000000228060: D8D80000 1000000A
	s_waitcnt lgkmcnt(0)                                       // 000000228068: BF89FC07
	v_sub_f32_e32 v15, v15, v16                                // 00000022806C: 081E210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228070: BF870091
	v_mul_f32_e32 v16, 0x3fb8aa3b, v15                         // 000000228074: 10201EFF 3FB8AA3B
	v_fma_f32 v17, 0x3fb8aa3b, v15, -v16                       // 00000022807C: D6130011 84421EFF 3FB8AA3B
	v_rndne_f32_e32 v18, v16                                   // 000000228088: 7E244710
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000022808C: BF870221
	v_sub_f32_e32 v16, v16, v18                                // 000000228090: 08202510
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v15                  // 000000228094: 7C361EFF C2CE8ED0
	v_fmac_f32_e32 v17, 0x32a5705f, v15                        // 00000022809C: 56221EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002280A4: BF870121
	v_add_f32_e32 v16, v16, v17                                // 0000002280A8: 06202310
	v_cvt_i32_f32_e32 v17, v18                                 // 0000002280AC: 7E221112
	v_exp_f32_e32 v16, v16                                     // 0000002280B0: 7E204B10
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002280B4: BF870095
	.long 0xd71c0010                                           // 0000002280B8: D71C0010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                     // 0000002280BC: 02022310
	v_cndmask_b32_e32 v16, 0, v16, vcc_lo                      // 0000002280C0: 02202080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v15                  // 0000002280C4: 7C3C1EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002280CC: BF870092
	v_cndmask_b32_e32 v15, 0x7f800000, v16, vcc_lo             // 0000002280D0: 021E20FF 7F800000
	v_mul_f32_e32 v15, v12, v15                                // 0000002280D8: 101E1F0C
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002280DC: 8C7E007E
	.long 0xd73c0010                                           // 0000002280E0: D73C0010
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000002280E4: 02020288
	v_or_b32_e32 v1, 1, v1                                     // 0000002280E8: 38020281
	s_mov_b32 s0, exec_lo                                      // 0000002280EC: BE80007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002280F0: BF870092
	.long 0xd7006a10                                           // 0000002280F4: D7006A10
	v_cndmask_b32_e32 v1, v8, v16, vcc_lo                      // 0000002280F8: 02022108
	v_add_co_ci_u32_e64 v17, null, v9, v17, vcc_lo             // 0000002280FC: D5207C11 01AA2309
	global_store_b32 v[16:17], v15, off                        // 000000228104: DC6A0000 007C0F10
	.long 0xd4cb007e                                           // 00000022810C: D4CB007E
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                       // 000000228110: 02020306
	s_cbranch_execz 65391                                      // 000000228114: BFA5FF6F <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi2EEEvPKfS3_S3_Pfi+0x1d4>
	ds_load_b32 v12, v14 offset:16516                          // 000000228118: D8D84084 0C00000E
	ds_load_b32 v13, v10                                       // 000000228120: D8D80000 0D00000A
	s_waitcnt lgkmcnt(0)                                       // 000000228128: BF89FC07
	v_sub_f32_e32 v12, v12, v13                                // 00000022812C: 08181B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228130: BF870091
	v_mul_f32_e32 v13, 0x3fb8aa3b, v12                         // 000000228134: 101A18FF 3FB8AA3B
	v_fma_f32 v14, 0x3fb8aa3b, v12, -v13                       // 00000022813C: D613000E 843618FF 3FB8AA3B
	v_rndne_f32_e32 v15, v13                                   // 000000228148: 7E1E470D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000022814C: BF870221
	v_sub_f32_e32 v13, v13, v15                                // 000000228150: 081A1F0D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v12                  // 000000228154: 7C3618FF C2CE8ED0
	v_fmac_f32_e32 v14, 0x32a5705f, v12                        // 00000022815C: 561C18FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000228164: BF870121
	v_add_f32_e32 v13, v13, v14                                // 000000228168: 061A1D0D
	v_cvt_i32_f32_e32 v14, v15                                 // 00000022816C: 7E1C110F
	v_exp_f32_e32 v13, v13                                     // 000000228170: 7E1A4B0D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228174: BF870095
	.long 0xd71c000d                                           // 000000228178: D71C000D
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                     // 00000022817C: 02021D0D
	v_cndmask_b32_e32 v13, 0, v13, vcc_lo                      // 000000228180: 021A1A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v12                  // 000000228184: 7C3C18FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022818C: BF870092
	v_cndmask_b32_e32 v12, 0x7f800000, v13, vcc_lo             // 000000228190: 02181AFF 7F800000
	v_mul_f32_e32 v13, v11, v12                                // 000000228198: 101A190B
	s_branch 65357                                             // 00000022819C: BFA0FF4D <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi2EEEvPKfS3_S3_Pfi+0x1d4>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000002281A0: 8C7E097E
	s_lshl_b32 s1, s30, 10                                     // 0000002281A4: 84018A1E
	s_mov_b32 s0, exec_lo                                      // 0000002281A8: BE80007E
	.long 0xd4cc007e                                           // 0000002281AC: D4CC007E
	v_cndmask_b32_e32 v1, s1, v0, vcc_lo                       // 0000002281B0: 02020001
	s_cbranch_execz 53                                         // 0000002281B4: BFA50035 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi2EEEvPKfS3_S3_Pfi+0x58c>
	s_mul_i32 s0, s3, 0xc0000                                  // 0000002281B8: 9600FF03 000C0000
	s_lshl_b64 s[4:5], s[28:29], 14                            // 0000002281C0: 84848E1C
	s_mul_hi_u32 s3, s3, 0xc0000                               // 0000002281C4: 9683FF03 000C0000
	s_add_u32 s0, s0, s4                                       // 0000002281CC: 80000400
	s_addc_u32 s3, s3, s5                                      // 0000002281D0: 82030503
	v_lshrrev_b32_e32 v4, 5, v0                                // 0000002281D4: 32080085
	s_add_u32 s0, s10, s0                                      // 0000002281D8: 8000000A
	s_addc_u32 s3, s11, s3                                     // 0000002281DC: 8203030B
	.long 0xd7000003                                           // 0000002281E0: D7000003
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000002281E4: 02020600
	v_mov_b32_e32 v2, 0                                        // 0000002281E8: 7E040280
	v_add_co_ci_u32_e64 v5, null, s3, 0, s0                    // 0000002281EC: D5207C05 00010003
	v_mov_b32_e32 v6, v4                                       // 0000002281F4: 7E0C0304
	s_mov_b32 s3, 0                                            // 0000002281F8: BE830080
	s_nop 0                                                    // 0000002281FC: BF800000
	v_lshl_or_b32 v1, v4, 6, s2                                // 000000228200: D6560001 00090D04
	v_add_nc_u32_e32 v0, 0x100, v0                             // 000000228208: 4A0000FF 00000100
	v_add_nc_u32_e32 v4, 8, v4                                 // 000000228210: 4A080888
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000228214: BF870223
	.long 0xd73c0007                                           // 000000228218: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000022821C: 02020282
	v_and_b32_e32 v1, 0x3ffffff, v6                            // 000000228220: 36020CFF 03FFFFFF
	v_cmp_le_u32_e32 vcc_lo, s1, v0                            // 000000228228: 7C960001
	v_add_nc_u32_e32 v6, 8, v6                                 // 00000022822C: 4A0C0C88
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000228230: BF8700A3
	.long 0xd73c0009                                           // 000000228234: D73C0009
	v_cndmask_b32_e32 v1, 7, v1, vcc_lo                        // 000000228238: 02020287
	s_or_b32 s3, vcc_lo, s3                                    // 00000022823C: 8C03036A
	.long 0xd7010001                                           // 000000228240: D7010001
	v_cndmask_b32_e32 v1, v7, v9, vcc_lo                       // 000000228244: 02021307
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000228248: BF870111
	v_sub_co_ci_u32_e64 v8, null, v8, v10, s0                  // 00000022824C: D5217C08 00021508
	.long 0xd7000007                                           // 000000228254: D7000007
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 000000228258: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000022825C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, v5, v8, s0                   // 000000228260: D5207C08 00021105
	.long 0xd7000003                                           // 000000228268: D7000003
	v_cndmask_b32_e32 v1, 0x400, v3, vcc_lo                    // 00000022826C: 020206FF 00000400
	v_add_co_ci_u32_e64 v5, null, 0, v5, s0                    // 000000228274: D5207C05 00020A80
	global_store_b32 v[7:8], v2, off                           // 00000022827C: DC6A0000 007C0207
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000228284: 917E037E
	s_cbranch_execnz 65501                                     // 000000228288: BFA6FFDD <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi2EEEvPKfS3_S3_Pfi+0x500>
	s_endpgm                                                   // 00000022828C: BFB00000
		...

