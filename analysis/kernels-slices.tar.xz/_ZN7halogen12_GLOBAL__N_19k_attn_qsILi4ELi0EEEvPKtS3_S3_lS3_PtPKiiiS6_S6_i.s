0000000000175900 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i():
	s_clause 0x1                                               // 000000175900: BF850001
	s_load_b64 s[4:5], s[0:1], 0x30                            // 000000175904: F4040100 F8000030
	s_load_b128 s[12:15], s[0:1], 0x40                         // 00000017590C: F4080300 F8000040
	s_mov_b32 s16, s3                                          // 000000175914: BE900003
	s_ashr_i32 s3, s2, 31                                      // 000000175918: 86039F02
	s_mov_b32 s19, exec_lo                                     // 00000017591C: BE93007E
	s_waitcnt lgkmcnt(0)                                       // 000000175920: BF89FC07
	s_load_b32 s17, s[4:5], null                               // 000000175924: F4000442 F8000000
	s_lshl_b64 s[4:5], s[2:3], 2                               // 00000017592C: 84848202
	s_waitcnt lgkmcnt(0)                                       // 000000175930: BF89FC07
	s_add_i32 s17, s17, s2                                     // 000000175934: 81110211
	s_add_u32 s4, s14, s4                                      // 000000175938: 8004040E
	s_addc_u32 s5, s15, s5                                     // 00000017593C: 8205050F
	s_add_i32 s14, s17, 1                                      // 000000175940: 810E8111
	s_load_b32 s3, s[4:5], null                                // 000000175944: F40000C2 F8000000
	s_load_b256 s[4:11], s[0:1], 0x10                          // 00000017594C: F40C0100 F8000010
	s_ashr_i32 s15, s14, 31                                    // 000000175954: 860F9F0E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000175958: BF870499
	s_lshr_b32 s15, s15, 30                                    // 00000017595C: 850F9E0F
	s_add_i32 s18, s14, s15                                    // 000000175960: 81120F0E
	s_waitcnt lgkmcnt(0)                                       // 000000175964: BF89FC07
	s_lshl_b32 s15, s3, 2                                      // 000000175968: 840F8203
	s_and_b32 s3, s18, -4                                      // 00000017596C: 8B03C412
	s_add_i32 s14, s14, s15                                    // 000000175970: 810E0F0E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000175974: BF870499
	s_sub_i32 s14, s14, s3                                     // 000000175978: 818E030E
	s_add_i32 s18, s14, 16                                     // 00000017597C: 8112900E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000175980: BF870009
	.long 0xd4c4007e                                           // 000000175984: D4C4007E
	v_cndmask_b32_e32 v1, s18, v0, vcc_lo                      // 000000175988: 02020012
	s_cbranch_execz 61                                         // 00000017598C: BFA5003D <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x184>
	s_load_b32 s21, s[0:1], 0x50                               // 000000175990: F4000540 F8000050
	v_and_b32_e32 v1, 0x7c, v0                                 // 000000175998: 360200FF 0000007C
	s_sub_i32 s20, s3, s15                                     // 0000001759A0: 81940F03
	v_and_b32_e32 v3, 3, v0                                    // 0000001759A4: 36060083
	v_dual_mov_b32 v5, v0 :: v_dual_lshlrev_b32 v4, 2, v0      // 0000001759A8: CA220100 05040082
	s_waitcnt lgkmcnt(0)                                       // 0000001759B0: BF89FC07
	s_mul_hi_i32 s23, s2, s21                                  // 0000001759B4: 97171502
	s_mul_i32 s22, s2, s21                                     // 0000001759B8: 96161502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001759BC: BF870499
	s_lshl_b64 s[22:23], s[22:23], 2                           // 0000001759C0: 84968216
	s_add_u32 s3, s12, s22                                     // 0000001759C4: 8003160C
	s_addc_u32 s12, s13, s23                                   // 0000001759C8: 820C170D
	.long 0xd7000301                                           // 0000001759CC: D7000301
	v_cndmask_b32_e32 v1, s3, v1, vcc_lo                       // 0000001759D0: 02020203
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001759D4: BF870001
	v_add_co_ci_u32_e64 v2, null, s12, 0, s3                   // 0000001759D8: D5207C02 000D000C
	s_mov_b32 s12, 0                                           // 0000001759E0: BE8C0080
	s_set_inst_prefetch_distance 0x1                           // 0000001759E4: BF840001
	s_branch 22                                                // 0000001759E8: BFA00016 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x144>
	s_nop 0                                                    // 0000001759EC: BF800000
	s_nop 0                                                    // 0000001759F0: BF800000
	s_nop 0                                                    // 0000001759F4: BF800000
	s_nop 0                                                    // 0000001759F8: BF800000
	s_nop 0                                                    // 0000001759FC: BF800000
	s_or_b32 exec_lo, exec_lo, s3                              // 000000175A00: 8C7E037E
	v_add_nc_u32_e32 v5, 0x80, v5                              // 000000175A04: 4A0A0AFF 00000080
	.long 0xd7000301                                           // 000000175A0C: D7000301
	v_cndmask_b32_e32 v1, 0x80, v1, vcc_lo                     // 000000175A10: 020202FF 00000080
	ds_store_b32 v4, v6 offset:51200                           // 000000175A18: D834C800 00000604
	v_add_co_ci_u32_e64 v2, null, 0, v2, s3                    // 000000175A20: D5207C02 000E0480
	v_cmp_le_i32_e32 vcc_lo, s18, v5                           // 000000175A28: 7C860A12
	v_add_nc_u32_e32 v4, 0x200, v4                             // 000000175A2C: 4A0808FF 00000200
	s_or_b32 s12, vcc_lo, s12                                  // 000000175A34: 8C0C0C6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000175A38: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000175A3C: 917E0C7E
	s_cbranch_execz 16                                         // 000000175A40: BFA50010 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x184>
	s_mov_b32 s3, exec_lo                                      // 000000175A44: BE83007E
	.long 0xd4c3007e                                           // 000000175A48: D4C3007E
	v_cndmask_b32_e32 v1, s15, v5, vcc_lo                      // 000000175A4C: 02020A0F
	s_xor_b32 s3, exec_lo, s3                                  // 000000175A50: 8D03037E
	v_add_nc_u32_e32 v6, s20, v5                               // 000000175A54: 4A0C0A14
	v_cmp_gt_i32_e32 vcc_lo, s14, v5                           // 000000175A58: 7C880A0E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000175A5C: BF870002
	v_cndmask_b32_e32 v6, s17, v6, vcc_lo                      // 000000175A60: 020C0C11
	s_and_not1_saveexec_b32 s3, s3                             // 000000175A64: BE833003
	s_cbranch_execz 65509                                      // 000000175A68: BFA5FFE5 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x100>
	global_load_b32 v6, v[1:2], off                            // 000000175A6C: DC520000 067C0001
	s_waitcnt vmcnt(0)                                         // 000000175A74: BF8903F7
	v_lshl_or_b32 v6, v6, 2, v3                                // 000000175A78: D6560006 040D0506
	s_branch 65503                                             // 000000175A80: BFA0FFDF <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x100>
	s_set_inst_prefetch_distance 0x2                           // 000000175A84: BF840002
	s_or_b32 exec_lo, exec_lo, s19                             // 000000175A88: 8C7E137E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000175A8C: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000175A90: BE83007E
	v_cmpx_eq_u32_e32 0, v0                                    // 000000175A94: 7D940080
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, s14             // 000000175A98: CA100080 0102000E
	ds_store_b32 v1, v2 offset:59984                           // 000000175AA0: D834EA50 00000201
	s_or_b32 exec_lo, exec_lo, s3                              // 000000175AA8: 8C7E037E
	v_lshrrev_b32_e32 v145, 5, v0                              // 000000175AAC: 33220085
	v_mov_b32_e32 v6, 0                                        // 000000175AB0: 7E0C0280
	s_waitcnt lgkmcnt(0)                                       // 000000175AB4: BF89FC07
	s_barrier                                                  // 000000175AB8: BFBD0000
	buffer_gl0_inv                                             // 000000175ABC: E0AC0000 00000000
	v_lshlrev_b32_e32 v149, 6, v145                            // 000000175AC4: 312B2286
	ds_load_b32 v7, v6 offset:59984                            // 000000175AC8: D8D8EA50 07000006
	v_dual_mov_b32 v5, v6 :: v_dual_and_b32 v148, 31, v0       // 000000175AD0: CA240106 0594009F
	v_dual_mov_b32 v3, v6 :: v_dual_and_b32 v146, 15, v0       // 000000175AD8: CA240106 0392008F
	v_bfe_u32 v147, v0, 4, 1                                   // 000000175AE0: D6100093 02050900
	v_dual_mov_b32 v150, 0xf149f2ca :: v_dual_mov_b32 v1, v6   // 000000175AE8: CA1000FF 96000106 F149F2CA
	v_mov_b32_e32 v4, v6                                       // 000000175AF4: 7E080306
	v_mov_b32_e32 v2, v6                                       // 000000175AF8: 7E040306
	v_mov_b32_e32 v14, v6                                      // 000000175AFC: 7E1C0306
	v_mov_b32_e32 v13, v6                                      // 000000175B00: 7E1A0306
	v_mov_b32_e32 v12, v6                                      // 000000175B04: 7E180306
	v_mov_b32_e32 v11, v6                                      // 000000175B08: 7E160306
	v_mov_b32_e32 v10, v6                                      // 000000175B0C: 7E140306
	v_mov_b32_e32 v9, v6                                       // 000000175B10: 7E120306
	v_mov_b32_e32 v30, v6                                      // 000000175B14: 7E3C0306
	v_mov_b32_e32 v29, v6                                      // 000000175B18: 7E3A0306
	v_mov_b32_e32 v28, v6                                      // 000000175B1C: 7E380306
	v_mov_b32_e32 v27, v6                                      // 000000175B20: 7E360306
	s_waitcnt lgkmcnt(0)                                       // 000000175B24: BF89FC07
	v_readfirstlane_b32 s3, v7                                 // 000000175B28: 7E060507
	v_mov_b32_e32 v26, v6                                      // 000000175B2C: 7E340306
	v_mov_b32_e32 v25, v6                                      // 000000175B30: 7E320306
	v_mov_b32_e32 v22, v6                                      // 000000175B34: 7E2C0306
	v_mov_b32_e32 v21, v6                                      // 000000175B38: 7E2A0306
	s_add_i32 s3, s3, 15                                       // 000000175B3C: 81038F03
	v_mov_b32_e32 v20, v6                                      // 000000175B40: 7E280306
	s_ashr_i32 s12, s3, 31                                     // 000000175B44: 860C9F03
	v_mov_b32_e32 v19, v6                                      // 000000175B48: 7E260306
	s_lshr_b32 s12, s12, 28                                    // 000000175B4C: 850C9C0C
	v_mov_b32_e32 v18, v6                                      // 000000175B50: 7E240306
	s_add_i32 s3, s3, s12                                      // 000000175B54: 81030C03
	v_mov_b32_e32 v17, v6                                      // 000000175B58: 7E220306
	s_ashr_i32 s18, s3, 4                                      // 000000175B5C: 86128403
	v_mov_b32_e32 v54, v6                                      // 000000175B60: 7E6C0306
	v_cmp_gt_i32_e32 vcc_lo, s18, v145                         // 000000175B64: 7C892212
	v_mov_b32_e32 v53, v6                                      // 000000175B68: 7E6A0306
	v_mov_b32_e32 v52, v6                                      // 000000175B6C: 7E680306
	v_mov_b32_e32 v51, v6                                      // 000000175B70: 7E660306
	v_mov_b32_e32 v50, v6                                      // 000000175B74: 7E640306
	v_mov_b32_e32 v49, v6                                      // 000000175B78: 7E620306
	v_mov_b32_e32 v38, v6                                      // 000000175B7C: 7E4C0306
	v_mov_b32_e32 v37, v6                                      // 000000175B80: 7E4A0306
	v_mov_b32_e32 v36, v6                                      // 000000175B84: 7E480306
	v_mov_b32_e32 v35, v6                                      // 000000175B88: 7E460306
	v_mov_b32_e32 v34, v6                                      // 000000175B8C: 7E440306
	v_mov_b32_e32 v33, v6                                      // 000000175B90: 7E420306
	v_mov_b32_e32 v70, v6                                      // 000000175B94: 7E8C0306
	v_mov_b32_e32 v69, v6                                      // 000000175B98: 7E8A0306
	v_mov_b32_e32 v68, v6                                      // 000000175B9C: 7E880306
	v_mov_b32_e32 v67, v6                                      // 000000175BA0: 7E860306
	v_mov_b32_e32 v66, v6                                      // 000000175BA4: 7E840306
	v_mov_b32_e32 v65, v6                                      // 000000175BA8: 7E820306
	v_mov_b32_e32 v46, v6                                      // 000000175BAC: 7E5C0306
	v_mov_b32_e32 v45, v6                                      // 000000175BB0: 7E5A0306
	v_mov_b32_e32 v44, v6                                      // 000000175BB4: 7E580306
	v_mov_b32_e32 v43, v6                                      // 000000175BB8: 7E560306
	v_mov_b32_e32 v42, v6                                      // 000000175BBC: 7E540306
	v_mov_b32_e32 v41, v6                                      // 000000175BC0: 7E520306
	v_mov_b32_e32 v86, v6                                      // 000000175BC4: 7EAC0306
	v_mov_b32_e32 v85, v6                                      // 000000175BC8: 7EAA0306
	v_mov_b32_e32 v84, v6                                      // 000000175BCC: 7EA80306
	v_mov_b32_e32 v83, v6                                      // 000000175BD0: 7EA60306
	v_mov_b32_e32 v82, v6                                      // 000000175BD4: 7EA40306
	v_mov_b32_e32 v81, v6                                      // 000000175BD8: 7EA20306
	v_mov_b32_e32 v62, v6                                      // 000000175BDC: 7E7C0306
	v_mov_b32_e32 v61, v6                                      // 000000175BE0: 7E7A0306
	v_mov_b32_e32 v60, v6                                      // 000000175BE4: 7E780306
	v_mov_b32_e32 v59, v6                                      // 000000175BE8: 7E760306
	v_mov_b32_e32 v58, v6                                      // 000000175BEC: 7E740306
	v_mov_b32_e32 v57, v6                                      // 000000175BF0: 7E720306
	v_mov_b32_e32 v102, v6                                     // 000000175BF4: 7ECC0306
	v_mov_b32_e32 v101, v6                                     // 000000175BF8: 7ECA0306
	v_mov_b32_e32 v100, v6                                     // 000000175BFC: 7EC80306
	v_mov_b32_e32 v99, v6                                      // 000000175C00: 7EC60306
	v_mov_b32_e32 v98, v6                                      // 000000175C04: 7EC40306
	v_mov_b32_e32 v97, v6                                      // 000000175C08: 7EC20306
	v_mov_b32_e32 v78, v6                                      // 000000175C0C: 7E9C0306
	v_mov_b32_e32 v77, v6                                      // 000000175C10: 7E9A0306
	v_mov_b32_e32 v76, v6                                      // 000000175C14: 7E980306
	v_mov_b32_e32 v75, v6                                      // 000000175C18: 7E960306
	v_mov_b32_e32 v74, v6                                      // 000000175C1C: 7E940306
	v_mov_b32_e32 v73, v6                                      // 000000175C20: 7E920306
	v_mov_b32_e32 v118, v6                                     // 000000175C24: 7EEC0306
	v_mov_b32_e32 v117, v6                                     // 000000175C28: 7EEA0306
	v_mov_b32_e32 v116, v6                                     // 000000175C2C: 7EE80306
	v_mov_b32_e32 v115, v6                                     // 000000175C30: 7EE60306
	v_mov_b32_e32 v114, v6                                     // 000000175C34: 7EE40306
	v_mov_b32_e32 v113, v6                                     // 000000175C38: 7EE20306
	v_mov_b32_e32 v94, v6                                      // 000000175C3C: 7EBC0306
	v_mov_b32_e32 v93, v6                                      // 000000175C40: 7EBA0306
	v_mov_b32_e32 v92, v6                                      // 000000175C44: 7EB80306
	v_mov_b32_e32 v91, v6                                      // 000000175C48: 7EB60306
	v_mov_b32_e32 v90, v6                                      // 000000175C4C: 7EB40306
	v_mov_b32_e32 v89, v6                                      // 000000175C50: 7EB20306
	v_mov_b32_e32 v126, v6                                     // 000000175C54: 7EFC0306
	v_mov_b32_e32 v125, v6                                     // 000000175C58: 7EFA0306
	v_mov_b32_e32 v124, v6                                     // 000000175C5C: 7EF80306
	v_mov_b32_e32 v123, v6                                     // 000000175C60: 7EF60306
	v_mov_b32_e32 v122, v6                                     // 000000175C64: 7EF40306
	v_mov_b32_e32 v121, v6                                     // 000000175C68: 7EF20306
	v_mov_b32_e32 v110, v6                                     // 000000175C6C: 7EDC0306
	v_mov_b32_e32 v109, v6                                     // 000000175C70: 7EDA0306
	v_mov_b32_e32 v108, v6                                     // 000000175C74: 7ED80306
	v_mov_b32_e32 v107, v6                                     // 000000175C78: 7ED60306
	v_mov_b32_e32 v106, v6                                     // 000000175C7C: 7ED40306
	v_mov_b32_e32 v105, v6                                     // 000000175C80: 7ED20306
	v_mov_b32_e32 v151, v6                                     // 000000175C84: 7F2E0306
	s_and_saveexec_b32 s3, vcc_lo                              // 000000175C88: BE83206A
	s_cbranch_execz 799                                        // 000000175C8C: BFA5031F <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x100c>
	s_load_b32 s1, s[0:1], 0x3c                                // 000000175C90: F4000040 F800003C
	v_mul_u32_u24_e32 v1, 0x3000, v145                         // 000000175C98: 160322FF 00003000
	s_ashr_i32 s17, s16, 31                                    // 000000175CA0: 86119F10
	v_dual_mov_b32 v151, 0 :: v_dual_lshlrev_b32 v2, 8, v147   // 000000175CA4: CA220080 97032688
	s_lshl_b64 s[12:13], s[16:17], 9                           // 000000175CAC: 848C8910
	s_delay_alu instid0(VALU_DEP_2)                            // 000000175CB0: BF870002
	v_or_b32_e32 v1, 0x800, v1                                 // 000000175CB4: 380202FF 00000800
	v_dual_mov_b32 v150, 0xf149f2ca :: v_dual_lshlrev_b32 v3, 9, v145// 000000175CBC: CA2200FF 96032289 F149F2CA
	v_dual_mov_b32 v163, v145 :: v_dual_add_nc_u32 v4, 0xe950, v149// 000000175CC8: CA200191 A3052AFF 0000E950
	v_mul_u32_u24_e32 v5, 48, v146                             // 000000175CD4: 160B24B0
	v_dual_mov_b32 v105, 0 :: v_dual_lshlrev_b32 v6, 4, v145   // 000000175CD8: CA220080 69072284
	v_mad_u32_u24 v8, 0x1800, v147, v1                         // 000000175CE0: D60B0008 040726FF 00001800
	.long 0xd44c0000                                           // 000000175CEC: D44C0000
	v_cndmask_b32_e32 v1, 12, v148, vcc_lo                     // 000000175CF0: 0203288C
	v_lshl_add_u32 v152, v148, 5, v3                           // 000000175CF4: D6460098 040D0B94
	v_lshl_add_u32 v153, v148, 2, v4                           // 000000175CFC: D6460099 04110594
	v_lshl_or_b32 v154, v147, 2, v4                            // 000000175D04: D656009A 04110593
	v_lshl_or_b32 v155, v146, 1, v8                            // 000000175D0C: D656009B 04210392
	s_waitcnt lgkmcnt(0)                                       // 000000175D14: BF89FC07
	s_add_i32 s17, s1, -1                                      // 000000175D18: 8111C101
	s_add_u32 s1, s4, s12                                      // 000000175D1C: 80010C04
	s_addc_u32 s4, s5, s13                                     // 000000175D20: 82040D05
	.long 0xd700019c                                           // 000000175D24: D700019C
	v_cndmask_b32_e32 v1, s1, v2, vcc_lo                       // 000000175D28: 02020401
	s_delay_alu instid0(VALU_DEP_1)                            // 000000175D2C: BF870001
	v_add_co_ci_u32_e64 v157, null, s4, 0, s1                  // 000000175D30: D5207C9D 00050004
	v_lshl_or_b32 v158, v146, 5, v3                            // 000000175D38: D656009E 040D0B92
	v_or_b32_e32 v159, v1, v5                                  // 000000175D40: 393E0B01
	v_lshl_or_b32 v160, v146, 2, v149                          // 000000175D44: D65600A0 06550592
	v_sub_nc_u32_e32 v161, v7, v6                              // 000000175D4C: 4D420D07
	v_dual_mov_b32 v162, 1.0 :: v_dual_mov_b32 v107, v151      // 000000175D50: CA1000F2 A26A0197
	v_dual_mov_b32 v106, v151 :: v_dual_mov_b32 v121, 0        // 000000175D58: CA100197 6A780080
	v_dual_mov_b32 v108, v151 :: v_dual_mov_b32 v89, 0         // 000000175D60: CA100197 6C580080
	v_mov_b32_e32 v109, v151                                   // 000000175D68: 7EDA0397
	v_dual_mov_b32 v110, v151 :: v_dual_mov_b32 v113, 0        // 000000175D6C: CA100197 6E700080
	v_mov_b32_e32 v111, v151                                   // 000000175D74: 7EDE0397
	v_dual_mov_b32 v112, v151 :: v_dual_mov_b32 v73, 0         // 000000175D78: CA100197 70480080
	v_dual_mov_b32 v122, v151 :: v_dual_mov_b32 v97, 0         // 000000175D80: CA100197 7A600080
	v_mov_b32_e32 v123, v151                                   // 000000175D88: 7EF60397
	v_dual_mov_b32 v124, v151 :: v_dual_mov_b32 v57, 0         // 000000175D8C: CA100197 7C380080
	v_mov_b32_e32 v125, v151                                   // 000000175D94: 7EFA0397
	v_dual_mov_b32 v126, v151 :: v_dual_mov_b32 v81, 0         // 000000175D98: CA100197 7E500080
	v_mov_b32_e32 v127, v151                                   // 000000175DA0: 7EFE0397
	v_dual_mov_b32 v128, v151 :: v_dual_mov_b32 v41, 0         // 000000175DA4: CA100197 80280080
	v_dual_mov_b32 v90, v151 :: v_dual_mov_b32 v65, 0          // 000000175DAC: CA100197 5A400080
	v_mov_b32_e32 v91, v151                                    // 000000175DB4: 7EB60397
	v_dual_mov_b32 v92, v151 :: v_dual_mov_b32 v33, 0          // 000000175DB8: CA100197 5C200080
	v_mov_b32_e32 v93, v151                                    // 000000175DC0: 7EBA0397
	v_dual_mov_b32 v94, v151 :: v_dual_mov_b32 v49, 0          // 000000175DC4: CA100197 5E300080
	v_mov_b32_e32 v95, v151                                    // 000000175DCC: 7EBE0397
	v_dual_mov_b32 v96, v151 :: v_dual_mov_b32 v17, 0          // 000000175DD0: CA100197 60100080
	v_dual_mov_b32 v114, v151 :: v_dual_mov_b32 v25, 0         // 000000175DD8: CA100197 72180080
	v_mov_b32_e32 v115, v151                                   // 000000175DE0: 7EE60397
	v_dual_mov_b32 v116, v151 :: v_dual_mov_b32 v9, 0          // 000000175DE4: CA100197 74080080
	v_mov_b32_e32 v117, v151                                   // 000000175DEC: 7EEA0397
	v_dual_mov_b32 v118, v151 :: v_dual_mov_b32 v1, 0          // 000000175DF0: CA100197 76000080
	v_mov_b32_e32 v119, v151                                   // 000000175DF8: 7EEE0397
	v_mov_b32_e32 v120, v151                                   // 000000175DFC: 7EF00397
	v_mov_b32_e32 v74, v151                                    // 000000175E00: 7E940397
	v_mov_b32_e32 v75, v151                                    // 000000175E04: 7E960397
	v_mov_b32_e32 v76, v151                                    // 000000175E08: 7E980397
	v_mov_b32_e32 v77, v151                                    // 000000175E0C: 7E9A0397
	v_mov_b32_e32 v78, v151                                    // 000000175E10: 7E9C0397
	v_mov_b32_e32 v79, v151                                    // 000000175E14: 7E9E0397
	v_mov_b32_e32 v80, v151                                    // 000000175E18: 7EA00397
	v_mov_b32_e32 v98, v151                                    // 000000175E1C: 7EC40397
	v_mov_b32_e32 v99, v151                                    // 000000175E20: 7EC60397
	v_mov_b32_e32 v100, v151                                   // 000000175E24: 7EC80397
	v_mov_b32_e32 v101, v151                                   // 000000175E28: 7ECA0397
	v_mov_b32_e32 v102, v151                                   // 000000175E2C: 7ECC0397
	v_mov_b32_e32 v103, v151                                   // 000000175E30: 7ECE0397
	v_mov_b32_e32 v104, v151                                   // 000000175E34: 7ED00397
	v_mov_b32_e32 v58, v151                                    // 000000175E38: 7E740397
	v_mov_b32_e32 v59, v151                                    // 000000175E3C: 7E760397
	v_mov_b32_e32 v60, v151                                    // 000000175E40: 7E780397
	v_mov_b32_e32 v61, v151                                    // 000000175E44: 7E7A0397
	v_mov_b32_e32 v62, v151                                    // 000000175E48: 7E7C0397
	v_mov_b32_e32 v63, v151                                    // 000000175E4C: 7E7E0397
	v_mov_b32_e32 v64, v151                                    // 000000175E50: 7E800397
	v_mov_b32_e32 v82, v151                                    // 000000175E54: 7EA40397
	v_mov_b32_e32 v83, v151                                    // 000000175E58: 7EA60397
	v_mov_b32_e32 v84, v151                                    // 000000175E5C: 7EA80397
	v_mov_b32_e32 v85, v151                                    // 000000175E60: 7EAA0397
	v_mov_b32_e32 v86, v151                                    // 000000175E64: 7EAC0397
	v_mov_b32_e32 v87, v151                                    // 000000175E68: 7EAE0397
	v_mov_b32_e32 v88, v151                                    // 000000175E6C: 7EB00397
	v_mov_b32_e32 v42, v151                                    // 000000175E70: 7E540397
	v_mov_b32_e32 v43, v151                                    // 000000175E74: 7E560397
	v_mov_b32_e32 v44, v151                                    // 000000175E78: 7E580397
	v_mov_b32_e32 v45, v151                                    // 000000175E7C: 7E5A0397
	v_mov_b32_e32 v46, v151                                    // 000000175E80: 7E5C0397
	v_mov_b32_e32 v47, v151                                    // 000000175E84: 7E5E0397
	v_mov_b32_e32 v48, v151                                    // 000000175E88: 7E600397
	v_mov_b32_e32 v66, v151                                    // 000000175E8C: 7E840397
	v_mov_b32_e32 v67, v151                                    // 000000175E90: 7E860397
	v_mov_b32_e32 v68, v151                                    // 000000175E94: 7E880397
	v_mov_b32_e32 v69, v151                                    // 000000175E98: 7E8A0397
	v_mov_b32_e32 v70, v151                                    // 000000175E9C: 7E8C0397
	v_mov_b32_e32 v71, v151                                    // 000000175EA0: 7E8E0397
	v_mov_b32_e32 v72, v151                                    // 000000175EA4: 7E900397
	v_mov_b32_e32 v34, v151                                    // 000000175EA8: 7E440397
	v_mov_b32_e32 v35, v151                                    // 000000175EAC: 7E460397
	v_mov_b32_e32 v36, v151                                    // 000000175EB0: 7E480397
	v_mov_b32_e32 v37, v151                                    // 000000175EB4: 7E4A0397
	v_mov_b32_e32 v38, v151                                    // 000000175EB8: 7E4C0397
	v_mov_b32_e32 v39, v151                                    // 000000175EBC: 7E4E0397
	v_mov_b32_e32 v40, v151                                    // 000000175EC0: 7E500397
	v_mov_b32_e32 v50, v151                                    // 000000175EC4: 7E640397
	v_mov_b32_e32 v51, v151                                    // 000000175EC8: 7E660397
	v_mov_b32_e32 v52, v151                                    // 000000175ECC: 7E680397
	v_mov_b32_e32 v53, v151                                    // 000000175ED0: 7E6A0397
	v_mov_b32_e32 v54, v151                                    // 000000175ED4: 7E6C0397
	v_mov_b32_e32 v55, v151                                    // 000000175ED8: 7E6E0397
	v_mov_b32_e32 v56, v151                                    // 000000175EDC: 7E700397
	v_mov_b32_e32 v18, v151                                    // 000000175EE0: 7E240397
	v_mov_b32_e32 v19, v151                                    // 000000175EE4: 7E260397
	v_mov_b32_e32 v20, v151                                    // 000000175EE8: 7E280397
	v_mov_b32_e32 v21, v151                                    // 000000175EEC: 7E2A0397
	v_mov_b32_e32 v22, v151                                    // 000000175EF0: 7E2C0397
	v_mov_b32_e32 v23, v151                                    // 000000175EF4: 7E2E0397
	v_mov_b32_e32 v24, v151                                    // 000000175EF8: 7E300397
	v_mov_b32_e32 v26, v151                                    // 000000175EFC: 7E340397
	v_mov_b32_e32 v27, v151                                    // 000000175F00: 7E360397
	v_mov_b32_e32 v28, v151                                    // 000000175F04: 7E380397
	v_mov_b32_e32 v29, v151                                    // 000000175F08: 7E3A0397
	v_mov_b32_e32 v30, v151                                    // 000000175F0C: 7E3C0397
	v_mov_b32_e32 v31, v151                                    // 000000175F10: 7E3E0397
	v_mov_b32_e32 v32, v151                                    // 000000175F14: 7E400397
	v_mov_b32_e32 v10, v151                                    // 000000175F18: 7E140397
	v_mov_b32_e32 v11, v151                                    // 000000175F1C: 7E160397
	v_mov_b32_e32 v12, v151                                    // 000000175F20: 7E180397
	v_mov_b32_e32 v13, v151                                    // 000000175F24: 7E1A0397
	v_mov_b32_e32 v14, v151                                    // 000000175F28: 7E1C0397
	v_mov_b32_e32 v15, v151                                    // 000000175F2C: 7E1E0397
	v_mov_b32_e32 v16, v151                                    // 000000175F30: 7E200397
	v_mov_b32_e32 v2, v151                                     // 000000175F34: 7E040397
	v_mov_b32_e32 v3, v151                                     // 000000175F38: 7E060397
	v_mov_b32_e32 v4, v151                                     // 000000175F3C: 7E080397
	v_mov_b32_e32 v5, v151                                     // 000000175F40: 7E0A0397
	v_mov_b32_e32 v6, v151                                     // 000000175F44: 7E0C0397
	v_mov_b32_e32 v7, v151                                     // 000000175F48: 7E0E0397
	v_mov_b32_e32 v8, v151                                     // 000000175F4C: 7E100397
	s_mov_b32 s4, 0                                            // 000000175F50: BE840080
	s_mov_b32 s12, 0x3f803f80                                  // 000000175F54: BE8C00FF 3F803F80
	v_cmp_gt_u32_e32 vcc_lo, 16, v148                          // 000000175F5C: 7C992890
	s_branch 273                                               // 000000175F60: BFA00111 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0xaa8>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000175F64: 8C7E017E
	ds_load_2addr_b32 v[143:144], v154 offset1:2               // 000000175F68: D8DC0200 8F00009A
	ds_load_2addr_b32 v[141:142], v154 offset0:4 offset1:6     // 000000175F70: D8DC0604 8D00009A
	ds_load_2addr_b32 v[139:140], v154 offset0:8 offset1:10    // 000000175F78: D8DC0A08 8B00009A
	ds_load_2addr_b32 v[137:138], v154 offset0:12 offset1:14   // 000000175F80: D8DC0E0C 8900009A
	v_min_i32_e32 v164, 16, v161                               // 000000175F88: 23494290
	ds_load_b128 v[129:132], v158                              // 000000175F8C: DBFC0000 8100009E
	ds_load_b128 v[133:136], v158 offset:16                    // 000000175F94: DBFC0010 8500009E
	ds_load_b128 v[192:195], v159 offset:3856                  // 000000175F9C: DBFC0F10 C000009F
	ds_load_b128 v[188:191], v159 offset:3840                  // 000000175FA4: DBFC0F00 BC00009F
	ds_load_b128 v[200:203], v159 offset:4624                  // 000000175FAC: DBFC1210 C800009F
	ds_load_b128 v[196:199], v159 offset:4608                  // 000000175FB4: DBFC1200 C400009F
	v_cndmask_b32_e64 v150, v150, 0, s0                        // 000000175FBC: D5010096 00010196
	v_add_nc_u32_e32 v160, 0x100, v160                         // 000000175FC4: 4B4140FF 00000100
	v_cvt_f32_i32_e32 v180, v164                               // 000000175FCC: 7F680BA4
	ds_load_b128 v[164:167], v159                              // 000000175FD0: DBFC0000 A400009F
	ds_load_b128 v[168:171], v159 offset:16                    // 000000175FD8: DBFC0010 A800009F
	ds_load_b128 v[176:179], v159 offset:784                   // 000000175FE0: DBFC0310 B000009F
	ds_load_b128 v[172:175], v159 offset:768                   // 000000175FE8: DBFC0300 AC00009F
	v_subrev_nc_u32_e32 v161, 64, v161                         // 000000175FF0: 4F4342C0
	v_dual_add_f32 v180, v151, v180 :: v_dual_add_nc_u32 v163, 4, v163// 000000175FF4: C9216997 B4A34684
	s_delay_alu instid0(VALU_DEP_1)                            // 000000175FFC: BF870001
	.long 0xd4430001                                           // 000000176000: D4430001
	v_cndmask_b32_e32 v1, s18, v163, vcc_lo                    // 000000176004: 02034612
	s_waitcnt lgkmcnt(13)                                      // 000000176008: BF89FCD7
	v_dual_mul_f32 v105, v143, v105 :: v_dual_mul_f32 v106, v144, v106// 00000017600C: C8C6D38F 696AD590
	s_waitcnt lgkmcnt(12)                                      // 000000176014: BF89FCC7
	v_dual_mul_f32 v107, v141, v107 :: v_dual_mul_f32 v108, v142, v108// 000000176018: C8C6D78D 6B6CD98E
	s_waitcnt lgkmcnt(11)                                      // 000000176020: BF89FCB7
	v_dual_mul_f32 v109, v139, v109 :: v_dual_mul_f32 v110, v140, v110// 000000176024: C8C6DB8B 6D6EDD8C
	s_waitcnt lgkmcnt(10)                                      // 00000017602C: BF89FCA7
	v_dual_mul_f32 v111, v137, v111 :: v_dual_mul_f32 v112, v138, v112// 000000176030: C8C6DF89 6F70E18A
	v_dual_mul_f32 v121, v143, v121 :: v_dual_mul_f32 v122, v144, v122// 000000176038: C8C6F38F 797AF590
	v_dual_mul_f32 v123, v141, v123 :: v_dual_mul_f32 v124, v142, v124// 000000176040: C8C6F78D 7B7CF98E
	v_dual_mul_f32 v125, v139, v125 :: v_dual_mul_f32 v126, v140, v126// 000000176048: C8C6FB8B 7D7EFD8C
	v_dual_mul_f32 v127, v137, v127 :: v_dual_mul_f32 v128, v138, v128// 000000176050: C8C6FF89 7F81018A
	v_mul_f32_e32 v89, v143, v89                               // 000000176058: 10B2B38F
	v_cndmask_b32_e64 v151, v151, v180, s0                     // 00000017605C: D5010097 00036997
	s_waitcnt lgkmcnt(2)                                       // 000000176064: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[105:112], v[129:136], v[164:171], v[105:112]// 000000176068: CC414069 1DA74981
	ds_load_b128 v[168:171], v159 offset:1552                  // 000000176070: DBFC0610 A800009F
	ds_load_b128 v[164:167], v159 offset:1536                  // 000000176078: DBFC0600 A400009F
	s_waitcnt lgkmcnt(2)                                       // 000000176080: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[121:128], v[129:136], v[172:179], v[121:128]// 000000176084: CC414079 1DE75981
	ds_load_b128 v[176:179], v159 offset:2320                  // 00000017608C: DBFC0910 B000009F
	ds_load_b128 v[172:175], v159 offset:2304                  // 000000176094: DBFC0900 AC00009F
	ds_load_b128 v[184:187], v159 offset:3088                  // 00000017609C: DBFC0C10 B800009F
	ds_load_b128 v[180:183], v159 offset:3072                  // 0000001760A4: DBFC0C00 B400009F
	v_dual_mul_f32 v90, v144, v90 :: v_dual_mul_f32 v91, v141, v91// 0000001760AC: C8C6B590 5A5AB78D
	v_dual_mul_f32 v92, v142, v92 :: v_dual_mul_f32 v93, v139, v93// 0000001760B4: C8C6B98E 5C5CBB8B
	v_dual_mul_f32 v94, v140, v94 :: v_dual_mul_f32 v95, v137, v95// 0000001760BC: C8C6BD8C 5E5EBF89
	v_dual_mul_f32 v96, v138, v96 :: v_dual_mul_f32 v113, v143, v113// 0000001760C4: C8C6C18A 6070E38F
	v_dual_mul_f32 v114, v144, v114 :: v_dual_mul_f32 v115, v141, v115// 0000001760CC: C8C6E590 7272E78D
	v_dual_mul_f32 v116, v142, v116 :: v_dual_mul_f32 v117, v139, v117// 0000001760D4: C8C6E98E 7474EB8B
	v_dual_mul_f32 v118, v140, v118 :: v_dual_mul_f32 v119, v137, v119// 0000001760DC: C8C6ED8C 7676EF89
	v_dual_mul_f32 v120, v138, v120 :: v_dual_mul_f32 v73, v143, v73// 0000001760E4: C8C6F18A 7848938F
	v_dual_mul_f32 v74, v144, v74 :: v_dual_mul_f32 v75, v141, v75// 0000001760EC: C8C69590 4A4A978D
	v_dual_mul_f32 v76, v142, v76 :: v_dual_mul_f32 v77, v139, v77// 0000001760F4: C8C6998E 4C4C9B8B
	v_dual_mul_f32 v78, v140, v78 :: v_dual_mul_f32 v79, v137, v79// 0000001760FC: C8C69D8C 4E4E9F89
	v_dual_mul_f32 v80, v138, v80 :: v_dual_mul_f32 v97, v143, v97// 000000176104: C8C6A18A 5060C38F
	v_dual_mul_f32 v98, v144, v98 :: v_dual_mul_f32 v99, v141, v99// 00000017610C: C8C6C590 6262C78D
	v_dual_mul_f32 v100, v142, v100 :: v_dual_mul_f32 v101, v139, v101// 000000176114: C8C6C98E 6464CB8B
	v_dual_mul_f32 v102, v140, v102 :: v_dual_mul_f32 v103, v137, v103// 00000017611C: C8C6CD8C 6666CF89
	v_dual_mul_f32 v104, v138, v104 :: v_dual_mul_f32 v57, v143, v57// 000000176124: C8C6D18A 6838738F
	v_dual_mul_f32 v58, v144, v58 :: v_dual_mul_f32 v59, v141, v59// 00000017612C: C8C67590 3A3A778D
	v_dual_mul_f32 v60, v142, v60 :: v_dual_mul_f32 v61, v139, v61// 000000176134: C8C6798E 3C3C7B8B
	v_dual_mul_f32 v62, v140, v62 :: v_dual_mul_f32 v63, v137, v63// 00000017613C: C8C67D8C 3E3E7F89
	v_dual_mul_f32 v64, v138, v64 :: v_dual_mul_f32 v81, v143, v81// 000000176144: C8C6818A 4050A38F
	s_waitcnt lgkmcnt(4)                                       // 00000017614C: BF89FC47
	v_wmma_f32_16x16x16_bf16 v[89:96], v[129:136], v[164:171], v[89:96]// 000000176150: CC414059 1D674981
	s_waitcnt lgkmcnt(2)                                       // 000000176158: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[113:120], v[129:136], v[172:179], v[113:120]// 00000017615C: CC414071 1DC75981
	s_waitcnt lgkmcnt(0)                                       // 000000176164: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[129:136], v[180:187], v[73:80]// 000000176168: CC414049 1D276981
	ds_load_b128 v[168:171], v159 offset:5392                  // 000000176170: DBFC1510 A800009F
	ds_load_b128 v[164:167], v159 offset:5376                  // 000000176178: DBFC1500 A400009F
	ds_load_b128 v[176:179], v159 offset:6160                  // 000000176180: DBFC1810 B000009F
	ds_load_b128 v[172:175], v159 offset:6144                  // 000000176188: DBFC1800 AC00009F
	ds_load_b128 v[184:187], v159 offset:6928                  // 000000176190: DBFC1B10 B800009F
	ds_load_b128 v[180:183], v159 offset:6912                  // 000000176198: DBFC1B00 B400009F
	v_wmma_f32_16x16x16_bf16 v[97:104], v[129:136], v[188:195], v[97:104]// 0000001761A0: CC414061 1D877981
	v_wmma_f32_16x16x16_bf16 v[57:64], v[129:136], v[196:203], v[57:64]// 0000001761A8: CC414039 1CE78981
	ds_load_b128 v[192:195], v159 offset:7696                  // 0000001761B0: DBFC1E10 C000009F
	ds_load_b128 v[188:191], v159 offset:7680                  // 0000001761B8: DBFC1E00 BC00009F
	ds_load_b128 v[200:203], v159 offset:8464                  // 0000001761C0: DBFC2110 C800009F
	ds_load_b128 v[196:199], v159 offset:8448                  // 0000001761C8: DBFC2100 C400009F
	v_dual_mul_f32 v82, v144, v82 :: v_dual_mul_f32 v83, v141, v83// 0000001761D0: C8C6A590 5252A78D
	v_dual_mul_f32 v84, v142, v84 :: v_dual_mul_f32 v85, v139, v85// 0000001761D8: C8C6A98E 5454AB8B
	v_dual_mul_f32 v86, v140, v86 :: v_dual_mul_f32 v87, v137, v87// 0000001761E0: C8C6AD8C 5656AF89
	v_dual_mul_f32 v88, v138, v88 :: v_dual_mul_f32 v41, v143, v41// 0000001761E8: C8C6B18A 5828538F
	v_dual_mul_f32 v42, v144, v42 :: v_dual_mul_f32 v43, v141, v43// 0000001761F0: C8C65590 2A2A578D
	v_dual_mul_f32 v44, v142, v44 :: v_dual_mul_f32 v45, v139, v45// 0000001761F8: C8C6598E 2C2C5B8B
	v_dual_mul_f32 v46, v140, v46 :: v_dual_mul_f32 v47, v137, v47// 000000176200: C8C65D8C 2E2E5F89
	v_dual_mul_f32 v48, v138, v48 :: v_dual_mul_f32 v65, v143, v65// 000000176208: C8C6618A 3040838F
	v_dual_mul_f32 v66, v144, v66 :: v_dual_mul_f32 v67, v141, v67// 000000176210: C8C68590 4242878D
	v_dual_mul_f32 v68, v142, v68 :: v_dual_mul_f32 v69, v139, v69// 000000176218: C8C6898E 44448B8B
	v_dual_mul_f32 v70, v140, v70 :: v_dual_mul_f32 v71, v137, v71// 000000176220: C8C68D8C 46468F89
	v_dual_mul_f32 v72, v138, v72 :: v_dual_mul_f32 v33, v143, v33// 000000176228: C8C6918A 4820438F
	v_dual_mul_f32 v34, v144, v34 :: v_dual_mul_f32 v35, v141, v35// 000000176230: C8C64590 2222478D
	v_dual_mul_f32 v36, v142, v36 :: v_dual_mul_f32 v37, v139, v37// 000000176238: C8C6498E 24244B8B
	v_dual_mul_f32 v38, v140, v38 :: v_dual_mul_f32 v39, v137, v39// 000000176240: C8C64D8C 26264F89
	v_dual_mul_f32 v40, v138, v40 :: v_dual_mul_f32 v49, v143, v49// 000000176248: C8C6518A 2830638F
	s_waitcnt lgkmcnt(8)                                       // 000000176250: BF89FC87
	v_wmma_f32_16x16x16_bf16 v[81:88], v[129:136], v[164:171], v[81:88]// 000000176254: CC414051 1D474981
	s_waitcnt lgkmcnt(6)                                       // 00000017625C: BF89FC67
	v_wmma_f32_16x16x16_bf16 v[41:48], v[129:136], v[172:179], v[41:48]// 000000176260: CC414029 1CA75981
	s_waitcnt lgkmcnt(4)                                       // 000000176268: BF89FC47
	v_wmma_f32_16x16x16_bf16 v[65:72], v[129:136], v[180:187], v[65:72]// 00000017626C: CC414041 1D076981
	s_waitcnt lgkmcnt(2)                                       // 000000176274: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[33:40], v[129:136], v[188:195], v[33:40]// 000000176278: CC414021 1C877981
	ds_load_b128 v[168:171], v159 offset:9232                  // 000000176280: DBFC2410 A800009F
	ds_load_b128 v[164:167], v159 offset:9216                  // 000000176288: DBFC2400 A400009F
	ds_load_b128 v[176:179], v159 offset:10000                 // 000000176290: DBFC2710 B000009F
	ds_load_b128 v[172:175], v159 offset:9984                  // 000000176298: DBFC2700 AC00009F
	ds_load_b128 v[184:187], v159 offset:10768                 // 0000001762A0: DBFC2A10 B800009F
	ds_load_b128 v[180:183], v159 offset:10752                 // 0000001762A8: DBFC2A00 B400009F
	ds_load_b128 v[192:195], v159 offset:11536                 // 0000001762B0: DBFC2D10 C000009F
	ds_load_b128 v[188:191], v159 offset:11520                 // 0000001762B8: DBFC2D00 BC00009F
	v_mul_f32_e32 v8, v138, v8                                 // 0000001762C0: 1010118A
	v_dual_mul_f32 v50, v144, v50 :: v_dual_mul_f32 v51, v141, v51// 0000001762C4: C8C66590 3232678D
	v_dual_mul_f32 v52, v142, v52 :: v_dual_mul_f32 v53, v139, v53// 0000001762CC: C8C6698E 34346B8B
	v_dual_mul_f32 v54, v140, v54 :: v_dual_mul_f32 v55, v137, v55// 0000001762D4: C8C66D8C 36366F89
	v_dual_mul_f32 v56, v138, v56 :: v_dual_mul_f32 v17, v143, v17// 0000001762DC: C8C6718A 3810238F
	v_dual_mul_f32 v18, v144, v18 :: v_dual_mul_f32 v19, v141, v19// 0000001762E4: C8C62590 1212278D
	v_dual_mul_f32 v20, v142, v20 :: v_dual_mul_f32 v21, v139, v21// 0000001762EC: C8C6298E 14142B8B
	v_dual_mul_f32 v22, v140, v22 :: v_dual_mul_f32 v23, v137, v23// 0000001762F4: C8C62D8C 16162F89
	v_dual_mul_f32 v24, v138, v24 :: v_dual_mul_f32 v25, v143, v25// 0000001762FC: C8C6318A 1818338F
	v_dual_mul_f32 v26, v144, v26 :: v_dual_mul_f32 v27, v141, v27// 000000176304: C8C63590 1A1A378D
	v_dual_mul_f32 v28, v142, v28 :: v_dual_mul_f32 v29, v139, v29// 00000017630C: C8C6398E 1C1C3B8B
	v_dual_mul_f32 v30, v140, v30 :: v_dual_mul_f32 v31, v137, v31// 000000176314: C8C63D8C 1E1E3F89
	v_dual_mul_f32 v32, v138, v32 :: v_dual_mul_f32 v9, v143, v9// 00000017631C: C8C6418A 2008138F
	v_dual_mul_f32 v10, v144, v10 :: v_dual_mul_f32 v11, v141, v11// 000000176324: C8C61590 0A0A178D
	v_dual_mul_f32 v12, v142, v12 :: v_dual_mul_f32 v13, v139, v13// 00000017632C: C8C6198E 0C0C1B8B
	v_dual_mul_f32 v14, v140, v14 :: v_dual_mul_f32 v15, v137, v15// 000000176334: C8C61D8C 0E0E1F89
	v_dual_mul_f32 v16, v138, v16 :: v_dual_mul_f32 v1, v143, v1// 00000017633C: C8C6218A 1000038F
	v_dual_mul_f32 v2, v144, v2 :: v_dual_mul_f32 v3, v141, v3 // 000000176344: C8C60590 0202078D
	v_dual_mul_f32 v4, v142, v4 :: v_dual_mul_f32 v5, v139, v5 // 00000017634C: C8C6098E 04040B8B
	v_dual_mul_f32 v6, v140, v6 :: v_dual_mul_f32 v7, v137, v7 // 000000176354: C8C60D8C 06060F89
	s_waitcnt lgkmcnt(8)                                       // 00000017635C: BF89FC87
	v_wmma_f32_16x16x16_bf16 v[49:56], v[129:136], v[196:203], v[49:56]// 000000176360: CC414031 1CC78981
	s_waitcnt lgkmcnt(6)                                       // 000000176368: BF89FC67
	v_wmma_f32_16x16x16_bf16 v[17:24], v[129:136], v[164:171], v[17:24]// 00000017636C: CC414011 1C474981
	s_waitcnt lgkmcnt(4)                                       // 000000176374: BF89FC47
	v_wmma_f32_16x16x16_bf16 v[25:32], v[129:136], v[172:179], v[25:32]// 000000176378: CC414019 1C675981
	s_waitcnt lgkmcnt(2)                                       // 000000176380: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[9:16], v[129:136], v[180:187], v[9:16]// 000000176384: CC414009 1C276981
	s_waitcnt lgkmcnt(0)                                       // 00000017638C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[129:136], v[188:195], v[1:8]// 000000176390: CC414001 1C077981
	s_or_b32 s4, s1, s4                                        // 000000176398: 8C040401
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017639C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001763A0: 917E047E
	s_cbranch_execz 344                                        // 0000001763A4: BFA50158 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1008>
	ds_load_b32 v129, v160 offset:51200                        // 0000001763A8: D8D8C800 810000A0
	s_waitcnt lgkmcnt(0)                                       // 0000001763B0: BF89FC07
	v_min_i32_e32 v129, s17, v129                              // 0000001763B4: 23030211
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001763B8: BF8701B1
	v_ashrrev_i32_e32 v131, 31, v129                           // 0000001763BC: 3507029F
	.long 0xd72c0084                                           // 0000001763C0: D72C0084
	v_cndmask_b32_e32 v1, s7, v129, vcc_lo                     // 0000001763C4: 02030207
	v_mad_u64_u32 v[129:130], null, s6, v129, 0                // 0000001763C8: D6FE7C81 02030206
	.long 0xd72c0083                                           // 0000001763D0: D72C0083
	v_cndmask_b32_e32 v1, s6, v131, vcc_lo                     // 0000001763D4: 02030606
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001763D8: BF870091
	v_add3_u32 v130, v130, v131, v132                          // 0000001763DC: D6550082 06130782
	.long 0xd73c0081                                           // 0000001763E4: D73C0081
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000001763E8: 02030281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001763EC: BF870091
	.long 0xd70001d0                                           // 0000001763F0: D70001D0
	v_cndmask_b32_e32 v1, v156, v129, vcc_lo                   // 0000001763F4: 0203039C
	v_add_co_ci_u32_e64 v209, null, v157, v130, s1             // 0000001763F8: D5207CD1 0007059D
	s_clause 0xf                                               // 000000176400: BF85000F
	global_load_b128 v[129:132], v[208:209], off               // 000000176404: DC5E0000 817C00D0
	global_load_b128 v[133:136], v[208:209], off offset:16     // 00000017640C: DC5E0010 857C00D0
	global_load_b128 v[137:140], v[208:209], off offset:32     // 000000176414: DC5E0020 897C00D0
	global_load_b128 v[141:144], v[208:209], off offset:48     // 00000017641C: DC5E0030 8D7C00D0
	global_load_b128 v[164:167], v[208:209], off offset:64     // 000000176424: DC5E0040 A47C00D0
	global_load_b128 v[168:171], v[208:209], off offset:80     // 00000017642C: DC5E0050 A87C00D0
	global_load_b128 v[172:175], v[208:209], off offset:96     // 000000176434: DC5E0060 AC7C00D0
	global_load_b128 v[176:179], v[208:209], off offset:112    // 00000017643C: DC5E0070 B07C00D0
	global_load_b128 v[180:183], v[208:209], off offset:128    // 000000176444: DC5E0080 B47C00D0
	global_load_b128 v[184:187], v[208:209], off offset:144    // 00000017644C: DC5E0090 B87C00D0
	global_load_b128 v[188:191], v[208:209], off offset:160    // 000000176454: DC5E00A0 BC7C00D0
	global_load_b128 v[192:195], v[208:209], off offset:176    // 00000017645C: DC5E00B0 C07C00D0
	global_load_b128 v[196:199], v[208:209], off offset:192    // 000000176464: DC5E00C0 C47C00D0
	global_load_b128 v[200:203], v[208:209], off offset:208    // 00000017646C: DC5E00D0 C87C00D0
	global_load_b128 v[204:207], v[208:209], off offset:224    // 000000176474: DC5E00E0 CC7C00D0
	global_load_b128 v[208:211], v[208:209], off offset:240    // 00000017647C: DC5E00F0 D07C00D0
	s_waitcnt vmcnt(15)                                        // 000000176484: BF893FF7
	ds_store_b16 v155, v129                                    // 000000176488: D87C0000 0000819B
	ds_store_b16_d16_hi v155, v129 offset:48                   // 000000176490: DA840030 0000819B
	ds_store_b16 v155, v130 offset:96                          // 000000176498: D87C0060 0000829B
	ds_store_b16_d16_hi v155, v130 offset:144                  // 0000001764A0: DA840090 0000829B
	ds_store_b16 v155, v131 offset:192                         // 0000001764A8: D87C00C0 0000839B
	ds_store_b16_d16_hi v155, v131 offset:240                  // 0000001764B0: DA8400F0 0000839B
	ds_store_b16 v155, v132 offset:288                         // 0000001764B8: D87C0120 0000849B
	ds_store_b16_d16_hi v155, v132 offset:336                  // 0000001764C0: DA840150 0000849B
	s_waitcnt vmcnt(14)                                        // 0000001764C8: BF893BF7
	ds_store_b16 v155, v133 offset:384                         // 0000001764CC: D87C0180 0000859B
	ds_store_b16_d16_hi v155, v133 offset:432                  // 0000001764D4: DA8401B0 0000859B
	ds_store_b16 v155, v134 offset:480                         // 0000001764DC: D87C01E0 0000869B
	ds_store_b16_d16_hi v155, v134 offset:528                  // 0000001764E4: DA840210 0000869B
	ds_store_b16 v155, v135 offset:576                         // 0000001764EC: D87C0240 0000879B
	ds_store_b16_d16_hi v155, v135 offset:624                  // 0000001764F4: DA840270 0000879B
	ds_store_b16 v155, v136 offset:672                         // 0000001764FC: D87C02A0 0000889B
	ds_store_b16_d16_hi v155, v136 offset:720                  // 000000176504: DA8402D0 0000889B
	s_waitcnt vmcnt(13)                                        // 00000017650C: BF8937F7
	ds_store_b16 v155, v137 offset:768                         // 000000176510: D87C0300 0000899B
	ds_store_b16_d16_hi v155, v137 offset:816                  // 000000176518: DA840330 0000899B
	ds_store_b16 v155, v138 offset:864                         // 000000176520: D87C0360 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:912                  // 000000176528: DA840390 00008A9B
	ds_store_b16 v155, v139 offset:960                         // 000000176530: D87C03C0 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:1008                 // 000000176538: DA8403F0 00008B9B
	ds_store_b16 v155, v140 offset:1056                        // 000000176540: D87C0420 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:1104                 // 000000176548: DA840450 00008C9B
	s_waitcnt vmcnt(12)                                        // 000000176550: BF8933F7
	ds_store_b16 v155, v141 offset:1152                        // 000000176554: D87C0480 00008D9B
	ds_store_b16_d16_hi v155, v141 offset:1200                 // 00000017655C: DA8404B0 00008D9B
	ds_store_b16 v155, v142 offset:1248                        // 000000176564: D87C04E0 00008E9B
	ds_store_b16_d16_hi v155, v142 offset:1296                 // 00000017656C: DA840510 00008E9B
	ds_store_b16 v155, v143 offset:1344                        // 000000176574: D87C0540 00008F9B
	ds_store_b16_d16_hi v155, v143 offset:1392                 // 00000017657C: DA840570 00008F9B
	ds_store_b16 v155, v144 offset:1440                        // 000000176584: D87C05A0 0000909B
	ds_store_b16_d16_hi v155, v144 offset:1488                 // 00000017658C: DA8405D0 0000909B
	s_waitcnt vmcnt(11)                                        // 000000176594: BF892FF7
	ds_store_b16 v155, v164 offset:1536                        // 000000176598: D87C0600 0000A49B
	ds_store_b16_d16_hi v155, v164 offset:1584                 // 0000001765A0: DA840630 0000A49B
	ds_store_b16 v155, v165 offset:1632                        // 0000001765A8: D87C0660 0000A59B
	ds_store_b16_d16_hi v155, v165 offset:1680                 // 0000001765B0: DA840690 0000A59B
	ds_store_b16 v155, v166 offset:1728                        // 0000001765B8: D87C06C0 0000A69B
	ds_store_b16_d16_hi v155, v166 offset:1776                 // 0000001765C0: DA8406F0 0000A69B
	ds_store_b16 v155, v167 offset:1824                        // 0000001765C8: D87C0720 0000A79B
	ds_store_b16_d16_hi v155, v167 offset:1872                 // 0000001765D0: DA840750 0000A79B
	s_waitcnt vmcnt(10)                                        // 0000001765D8: BF892BF7
	ds_store_b16 v155, v168 offset:1920                        // 0000001765DC: D87C0780 0000A89B
	ds_store_b16_d16_hi v155, v168 offset:1968                 // 0000001765E4: DA8407B0 0000A89B
	ds_store_b16 v155, v169 offset:2016                        // 0000001765EC: D87C07E0 0000A99B
	ds_store_b16_d16_hi v155, v169 offset:2064                 // 0000001765F4: DA840810 0000A99B
	ds_store_b16 v155, v170 offset:2112                        // 0000001765FC: D87C0840 0000AA9B
	ds_store_b16_d16_hi v155, v170 offset:2160                 // 000000176604: DA840870 0000AA9B
	ds_store_b16 v155, v171 offset:2208                        // 00000017660C: D87C08A0 0000AB9B
	ds_store_b16_d16_hi v155, v171 offset:2256                 // 000000176614: DA8408D0 0000AB9B
	s_waitcnt vmcnt(9)                                         // 00000017661C: BF8927F7
	ds_store_b16 v155, v172 offset:2304                        // 000000176620: D87C0900 0000AC9B
	ds_store_b16_d16_hi v155, v172 offset:2352                 // 000000176628: DA840930 0000AC9B
	ds_store_b16 v155, v173 offset:2400                        // 000000176630: D87C0960 0000AD9B
	ds_store_b16_d16_hi v155, v173 offset:2448                 // 000000176638: DA840990 0000AD9B
	ds_store_b16 v155, v174 offset:2496                        // 000000176640: D87C09C0 0000AE9B
	ds_store_b16_d16_hi v155, v174 offset:2544                 // 000000176648: DA8409F0 0000AE9B
	ds_store_b16 v155, v175 offset:2592                        // 000000176650: D87C0A20 0000AF9B
	ds_store_b16_d16_hi v155, v175 offset:2640                 // 000000176658: DA840A50 0000AF9B
	s_waitcnt vmcnt(8)                                         // 000000176660: BF8923F7
	ds_store_b16 v155, v176 offset:2688                        // 000000176664: D87C0A80 0000B09B
	ds_store_b16_d16_hi v155, v176 offset:2736                 // 00000017666C: DA840AB0 0000B09B
	ds_store_b16 v155, v177 offset:2784                        // 000000176674: D87C0AE0 0000B19B
	ds_store_b16_d16_hi v155, v177 offset:2832                 // 00000017667C: DA840B10 0000B19B
	ds_store_b16 v155, v178 offset:2880                        // 000000176684: D87C0B40 0000B29B
	ds_store_b16_d16_hi v155, v178 offset:2928                 // 00000017668C: DA840B70 0000B29B
	ds_store_b16 v155, v179 offset:2976                        // 000000176694: D87C0BA0 0000B39B
	ds_store_b16_d16_hi v155, v179 offset:3024                 // 00000017669C: DA840BD0 0000B39B
	s_waitcnt vmcnt(7)                                         // 0000001766A4: BF891FF7
	ds_store_b16 v155, v180 offset:3072                        // 0000001766A8: D87C0C00 0000B49B
	ds_store_b16_d16_hi v155, v180 offset:3120                 // 0000001766B0: DA840C30 0000B49B
	ds_store_b16 v155, v181 offset:3168                        // 0000001766B8: D87C0C60 0000B59B
	ds_store_b16_d16_hi v155, v181 offset:3216                 // 0000001766C0: DA840C90 0000B59B
	ds_store_b16 v155, v182 offset:3264                        // 0000001766C8: D87C0CC0 0000B69B
	ds_store_b16_d16_hi v155, v182 offset:3312                 // 0000001766D0: DA840CF0 0000B69B
	ds_store_b16 v155, v183 offset:3360                        // 0000001766D8: D87C0D20 0000B79B
	ds_store_b16_d16_hi v155, v183 offset:3408                 // 0000001766E0: DA840D50 0000B79B
	s_waitcnt vmcnt(6)                                         // 0000001766E8: BF891BF7
	ds_store_b16 v155, v184 offset:3456                        // 0000001766EC: D87C0D80 0000B89B
	ds_store_b16_d16_hi v155, v184 offset:3504                 // 0000001766F4: DA840DB0 0000B89B
	ds_store_b16 v155, v185 offset:3552                        // 0000001766FC: D87C0DE0 0000B99B
	ds_store_b16_d16_hi v155, v185 offset:3600                 // 000000176704: DA840E10 0000B99B
	ds_store_b16 v155, v186 offset:3648                        // 00000017670C: D87C0E40 0000BA9B
	ds_store_b16_d16_hi v155, v186 offset:3696                 // 000000176714: DA840E70 0000BA9B
	ds_store_b16 v155, v187 offset:3744                        // 00000017671C: D87C0EA0 0000BB9B
	ds_store_b16_d16_hi v155, v187 offset:3792                 // 000000176724: DA840ED0 0000BB9B
	s_waitcnt vmcnt(5)                                         // 00000017672C: BF8917F7
	ds_store_b16 v155, v188 offset:3840                        // 000000176730: D87C0F00 0000BC9B
	ds_store_b16_d16_hi v155, v188 offset:3888                 // 000000176738: DA840F30 0000BC9B
	ds_store_b16 v155, v189 offset:3936                        // 000000176740: D87C0F60 0000BD9B
	ds_store_b16_d16_hi v155, v189 offset:3984                 // 000000176748: DA840F90 0000BD9B
	ds_store_b16 v155, v190 offset:4032                        // 000000176750: D87C0FC0 0000BE9B
	ds_store_b16_d16_hi v155, v190 offset:4080                 // 000000176758: DA840FF0 0000BE9B
	ds_store_b16 v155, v191 offset:4128                        // 000000176760: D87C1020 0000BF9B
	ds_store_b16_d16_hi v155, v191 offset:4176                 // 000000176768: DA841050 0000BF9B
	s_waitcnt vmcnt(4)                                         // 000000176770: BF8913F7
	ds_store_b16 v155, v192 offset:4224                        // 000000176774: D87C1080 0000C09B
	ds_store_b16_d16_hi v155, v192 offset:4272                 // 00000017677C: DA8410B0 0000C09B
	ds_store_b16 v155, v193 offset:4320                        // 000000176784: D87C10E0 0000C19B
	ds_store_b16_d16_hi v155, v193 offset:4368                 // 00000017678C: DA841110 0000C19B
	ds_store_b16 v155, v194 offset:4416                        // 000000176794: D87C1140 0000C29B
	ds_store_b16_d16_hi v155, v194 offset:4464                 // 00000017679C: DA841170 0000C29B
	ds_store_b16 v155, v195 offset:4512                        // 0000001767A4: D87C11A0 0000C39B
	ds_store_b16_d16_hi v155, v195 offset:4560                 // 0000001767AC: DA8411D0 0000C39B
	s_waitcnt vmcnt(3)                                         // 0000001767B4: BF890FF7
	ds_store_b16 v155, v196 offset:4608                        // 0000001767B8: D87C1200 0000C49B
	ds_store_b16_d16_hi v155, v196 offset:4656                 // 0000001767C0: DA841230 0000C49B
	ds_store_b16 v155, v197 offset:4704                        // 0000001767C8: D87C1260 0000C59B
	ds_store_b16_d16_hi v155, v197 offset:4752                 // 0000001767D0: DA841290 0000C59B
	ds_store_b16 v155, v198 offset:4800                        // 0000001767D8: D87C12C0 0000C69B
	ds_store_b16_d16_hi v155, v198 offset:4848                 // 0000001767E0: DA8412F0 0000C69B
	ds_store_b16 v155, v199 offset:4896                        // 0000001767E8: D87C1320 0000C79B
	ds_store_b16_d16_hi v155, v199 offset:4944                 // 0000001767F0: DA841350 0000C79B
	s_waitcnt vmcnt(2)                                         // 0000001767F8: BF890BF7
	ds_store_b16 v155, v200 offset:4992                        // 0000001767FC: D87C1380 0000C89B
	ds_store_b16_d16_hi v155, v200 offset:5040                 // 000000176804: DA8413B0 0000C89B
	ds_store_b16 v155, v201 offset:5088                        // 00000017680C: D87C13E0 0000C99B
	ds_store_b16_d16_hi v155, v201 offset:5136                 // 000000176814: DA841410 0000C99B
	ds_store_b16 v155, v202 offset:5184                        // 00000017681C: D87C1440 0000CA9B
	ds_store_b16_d16_hi v155, v202 offset:5232                 // 000000176824: DA841470 0000CA9B
	ds_store_b16 v155, v203 offset:5280                        // 00000017682C: D87C14A0 0000CB9B
	ds_store_b16_d16_hi v155, v203 offset:5328                 // 000000176834: DA8414D0 0000CB9B
	s_waitcnt vmcnt(1)                                         // 00000017683C: BF8907F7
	ds_store_b16 v155, v204 offset:5376                        // 000000176840: D87C1500 0000CC9B
	ds_store_b16_d16_hi v155, v204 offset:5424                 // 000000176848: DA841530 0000CC9B
	ds_store_b16 v155, v205 offset:5472                        // 000000176850: D87C1560 0000CD9B
	ds_store_b16_d16_hi v155, v205 offset:5520                 // 000000176858: DA841590 0000CD9B
	ds_store_b16 v155, v206 offset:5568                        // 000000176860: D87C15C0 0000CE9B
	ds_store_b16_d16_hi v155, v206 offset:5616                 // 000000176868: DA8415F0 0000CE9B
	ds_store_b16 v155, v207 offset:5664                        // 000000176870: D87C1620 0000CF9B
	ds_store_b16_d16_hi v155, v207 offset:5712                 // 000000176878: DA841650 0000CF9B
	s_waitcnt vmcnt(0)                                         // 000000176880: BF8903F7
	ds_store_b16 v155, v208 offset:5760                        // 000000176884: D87C1680 0000D09B
	ds_store_b16_d16_hi v155, v208 offset:5808                 // 00000017688C: DA8416B0 0000D09B
	ds_store_b16 v155, v209 offset:5856                        // 000000176894: D87C16E0 0000D19B
	ds_store_b16_d16_hi v155, v209 offset:5904                 // 00000017689C: DA841710 0000D19B
	ds_store_b16 v155, v210 offset:5952                        // 0000001768A4: D87C1740 0000D29B
	ds_store_b16_d16_hi v155, v210 offset:6000                 // 0000001768AC: DA841770 0000D29B
	ds_store_b16 v155, v211 offset:6048                        // 0000001768B4: D87C17A0 0000D39B
	ds_store_b16_d16_hi v155, v211 offset:6096                 // 0000001768BC: DA8417D0 0000D39B
	s_and_saveexec_b32 s1, vcc_lo                              // 0000001768C4: BE81206A
	s_cbranch_execz 64934                                      // 0000001768C8: BFA5FDA6 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x664>
	s_mov_b32 s15, s12                                         // 0000001768CC: BE8F000C
	s_mov_b32 s13, s12                                         // 0000001768D0: BE8D000C
	s_mov_b32 s14, s12                                         // 0000001768D4: BE8E000C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001768D8: BF870009
	v_dual_mov_b32 v132, s15 :: v_dual_mov_b32 v131, s14       // 0000001768DC: CA10000F 8482000E
	v_dual_mov_b32 v130, s13 :: v_dual_mov_b32 v129, s12       // 0000001768E4: CA10000D 8280000C
	ds_store_b128 v152, v[129:132]                             // 0000001768EC: DB7C0000 00008198
	ds_store_b128 v152, v[129:132] offset:16                   // 0000001768F4: DB7C0010 00008198
	ds_store_b32 v153, v162                                    // 0000001768FC: D8340000 0000A299
	s_branch 64919                                             // 000000176904: BFA0FD97 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x664>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000176908: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000017690C: BF870499
	s_or_b32 exec_lo, exec_lo, s3                              // 000000176910: 8C7E037E
	s_mov_b32 s0, exec_lo                                      // 000000176914: BE80007E
	s_barrier                                                  // 000000176918: BFBD0000
	buffer_gl0_inv                                             // 00000017691C: E0AC0000 00000000
	v_cmpx_gt_u32_e32 12, v148                                 // 000000176924: 7D99288C
	v_lshl_add_u32 v7, v148, 2, v149                           // 000000176928: D6460007 06550594
	s_delay_alu instid0(VALU_DEP_1)                            // 000000176930: BF870001
	v_add_nc_u32_e32 v7, 0x50, v7                              // 000000176934: 4A0E0EFF 00000050
	ds_store_2addr_stride64_b32 v7, v151, v150 offset0:232 offset1:233// 00000017693C: D83CE9E8 00969707
	s_or_b32 exec_lo, exec_lo, s0                              // 000000176944: 8C7E007E
	v_mul_u32_u24_e32 v7, 12, v145                             // 000000176948: 160F228C
	s_mul_hi_i32 s1, s2, 0x1800                                // 00000017694C: 9701FF02 00001800
	s_mulk_i32 s2, 0x1800                                      // 000000176954: B8021800
	s_mul_i32 s3, s16, 12                                      // 000000176958: 96038C10
	s_mov_b32 s4, 0                                            // 00000017695C: BE840080
	v_or_b32_e32 v7, v7, v147                                  // 000000176960: 380F2707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176964: BF870091
	v_lshlrev_b32_e32 v7, 10, v7                               // 000000176968: 300E0E8A
	v_lshl_or_b32 v7, v146, 2, v7                              // 00000017696C: D6560007 041D0592
	s_delay_alu instid0(VALU_DEP_1)                            // 000000176974: BF870001
	v_add_nc_u32_e32 v8, 0x800, v7                             // 000000176978: 4A100EFF 00000800
	v_add_nc_u32_e32 v15, 0x1000, v7                           // 000000176980: 4A1E0EFF 00001000
	v_add_nc_u32_e32 v16, 0x1800, v7                           // 000000176988: 4A200EFF 00001800
	v_add_nc_u32_e32 v23, 0x2000, v7                           // 000000176990: 4A2E0EFF 00002000
	v_add_nc_u32_e32 v24, 0x2800, v7                           // 000000176998: 4A300EFF 00002800
	v_add_nc_u32_e32 v7, 0x3000, v7                            // 0000001769A0: 4A0E0EFF 00003000
	ds_store_2addr_b32 v8, v105, v121 offset1:16               // 0000001769A8: D8381000 00796908
	ds_store_2addr_b32 v15, v106, v122 offset1:16              // 0000001769B0: D8381000 007A6A0F
	ds_store_2addr_b32 v16, v107, v123 offset1:16              // 0000001769B8: D8381000 007B6B10
	ds_store_2addr_b32 v23, v108, v124 offset1:16              // 0000001769C0: D8381000 007C6C17
	ds_store_2addr_b32 v24, v109, v125 offset1:16              // 0000001769C8: D8381000 007D6D18
	ds_store_2addr_b32 v7, v110, v126 offset1:16               // 0000001769D0: D8381000 007E6E07
	ds_store_2addr_b32 v8, v89, v113 offset0:32 offset1:48     // 0000001769D8: D8383020 00715908
	ds_store_2addr_b32 v15, v90, v114 offset0:32 offset1:48    // 0000001769E0: D8383020 00725A0F
	ds_store_2addr_b32 v16, v91, v115 offset0:32 offset1:48    // 0000001769E8: D8383020 00735B10
	ds_store_2addr_b32 v23, v92, v116 offset0:32 offset1:48    // 0000001769F0: D8383020 00745C17
	ds_store_2addr_b32 v24, v93, v117 offset0:32 offset1:48    // 0000001769F8: D8383020 00755D18
	ds_store_2addr_b32 v7, v94, v118 offset0:32 offset1:48     // 000000176A00: D8383020 00765E07
	ds_store_2addr_b32 v8, v73, v97 offset0:64 offset1:80      // 000000176A08: D8385040 00614908
	ds_store_2addr_b32 v15, v74, v98 offset0:64 offset1:80     // 000000176A10: D8385040 00624A0F
	ds_store_2addr_b32 v16, v75, v99 offset0:64 offset1:80     // 000000176A18: D8385040 00634B10
	ds_store_2addr_b32 v23, v76, v100 offset0:64 offset1:80    // 000000176A20: D8385040 00644C17
	ds_store_2addr_b32 v24, v77, v101 offset0:64 offset1:80    // 000000176A28: D8385040 00654D18
	ds_store_2addr_b32 v7, v78, v102 offset0:64 offset1:80     // 000000176A30: D8385040 00664E07
	ds_store_2addr_b32 v8, v57, v81 offset0:96 offset1:112     // 000000176A38: D8387060 00513908
	ds_store_2addr_b32 v15, v58, v82 offset0:96 offset1:112    // 000000176A40: D8387060 00523A0F
	ds_store_2addr_b32 v16, v59, v83 offset0:96 offset1:112    // 000000176A48: D8387060 00533B10
	ds_store_2addr_b32 v23, v60, v84 offset0:96 offset1:112    // 000000176A50: D8387060 00543C17
	ds_store_2addr_b32 v24, v61, v85 offset0:96 offset1:112    // 000000176A58: D8387060 00553D18
	ds_store_2addr_b32 v7, v62, v86 offset0:96 offset1:112     // 000000176A60: D8387060 00563E07
	ds_store_2addr_b32 v8, v41, v65 offset0:128 offset1:144    // 000000176A68: D8389080 00412908
	ds_store_2addr_b32 v15, v42, v66 offset0:128 offset1:144   // 000000176A70: D8389080 00422A0F
	ds_store_2addr_b32 v16, v43, v67 offset0:128 offset1:144   // 000000176A78: D8389080 00432B10
	ds_store_2addr_b32 v23, v44, v68 offset0:128 offset1:144   // 000000176A80: D8389080 00442C17
	ds_store_2addr_b32 v24, v45, v69 offset0:128 offset1:144   // 000000176A88: D8389080 00452D18
	ds_store_2addr_b32 v7, v46, v70 offset0:128 offset1:144    // 000000176A90: D8389080 00462E07
	ds_store_2addr_b32 v8, v33, v49 offset0:160 offset1:176    // 000000176A98: D838B0A0 00312108
	ds_store_2addr_b32 v15, v34, v50 offset0:160 offset1:176   // 000000176AA0: D838B0A0 0032220F
	ds_store_2addr_b32 v16, v35, v51 offset0:160 offset1:176   // 000000176AA8: D838B0A0 00332310
	ds_store_2addr_b32 v23, v36, v52 offset0:160 offset1:176   // 000000176AB0: D838B0A0 00342417
	ds_store_2addr_b32 v24, v37, v53 offset0:160 offset1:176   // 000000176AB8: D838B0A0 00352518
	ds_store_2addr_b32 v7, v38, v54 offset0:160 offset1:176    // 000000176AC0: D838B0A0 00362607
	ds_store_2addr_b32 v8, v17, v25 offset0:192 offset1:208    // 000000176AC8: D838D0C0 00191108
	ds_store_2addr_b32 v15, v18, v26 offset0:192 offset1:208   // 000000176AD0: D838D0C0 001A120F
	ds_store_2addr_b32 v16, v19, v27 offset0:192 offset1:208   // 000000176AD8: D838D0C0 001B1310
	ds_store_2addr_b32 v23, v20, v28 offset0:192 offset1:208   // 000000176AE0: D838D0C0 001C1417
	ds_store_2addr_b32 v24, v21, v29 offset0:192 offset1:208   // 000000176AE8: D838D0C0 001D1518
	ds_store_2addr_b32 v7, v22, v30 offset0:192 offset1:208    // 000000176AF0: D838D0C0 001E1607
	ds_store_2addr_b32 v8, v9, v1 offset0:224 offset1:240      // 000000176AF8: D838F0E0 00010908
	ds_store_2addr_b32 v15, v10, v2 offset0:224 offset1:240    // 000000176B00: D838F0E0 00020A0F
	ds_store_2addr_b32 v16, v11, v3 offset0:224 offset1:240    // 000000176B08: D838F0E0 00030B10
	ds_store_2addr_b32 v23, v12, v4 offset0:224 offset1:240    // 000000176B10: D838F0E0 00040C17
	ds_store_2addr_b32 v24, v13, v5 offset0:224 offset1:240    // 000000176B18: D838F0E0 00050D18
	ds_store_2addr_b32 v7, v14, v6 offset0:224 offset1:240     // 000000176B20: D838F0E0 00060E07
	s_waitcnt lgkmcnt(0)                                       // 000000176B28: BF89FC07
	s_barrier                                                  // 000000176B2C: BFBD0000
	buffer_gl0_inv                                             // 000000176B30: E0AC0000 00000000
	s_branch 135                                               // 000000176B38: BFA00087 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1458>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000176B3C: 8C7E007E
	v_add_lshl_u32 v2, v5, s3, 8                               // 000000176B40: D6470002 02200705
	s_waitcnt lgkmcnt(5)                                       // 000000176B48: BF89FC57
	v_fma_f32 v7, v6, v7, 0                                    // 000000176B4C: D6130007 02020F06
	s_waitcnt lgkmcnt(4)                                       // 000000176B54: BF89FC47
	v_fma_f32 v6, v6, v8, 0                                    // 000000176B58: D6130006 02021106
	v_ashrrev_i32_e32 v5, 31, v2                               // 000000176B60: 340A049F
	.long 0xd7006a02                                           // 000000176B64: D7006A02
	v_cndmask_b32_e32 v1, s2, v2, vcc_lo                       // 000000176B68: 02020402
	s_waitcnt lgkmcnt(2)                                       // 000000176B6C: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 000000176B70: BF870003
	v_fmac_f32_e32 v6, v13, v14                                // 000000176B74: 560C1D0D
	v_fmac_f32_e32 v7, v13, v4                                 // 000000176B78: 560E090D
	v_add_co_ci_u32_e64 v11, null, s1, v5, vcc_lo              // 000000176B7C: D5207C0B 01AA0A01
	v_or_b32_e32 v10, v2, v10                                  // 000000176B84: 38141502
	ds_load_b32 v3, v3 offset:192                              // 000000176B88: D8D800C0 03000003
	ds_load_b32 v5, v9 offset:36864                            // 000000176B90: D8D89000 05000009
	s_waitcnt lgkmcnt(2)                                       // 000000176B98: BF89FC27
	v_fmac_f32_e32 v6, v12, v15                                // 000000176B9C: 560C1F0C
	v_fmac_f32_e32 v7, v12, v1                                 // 000000176BA0: 560E030C
	.long 0xd73c000a                                           // 000000176BA4: D73C000A
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 000000176BA8: 02021481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176BAC: BF870091
	.long 0xd7006a11                                           // 000000176BB0: D7006A11
	v_cndmask_b32_e32 v1, s8, v10, vcc_lo                      // 000000176BB4: 02021408
	v_add_co_ci_u32_e64 v18, null, s9, v11, vcc_lo             // 000000176BB8: D5207C12 01AA1609
	global_load_u16 v2, v[17:18], off                          // 000000176BC0: DC4A0000 027C0011
	s_waitcnt vmcnt(0) lgkmcnt(1)                              // 000000176BC8: BF890017
	v_dual_fmac_f32 v7, v16, v3 :: v_dual_lshlrev_b32 v2, 16, v2// 000000176BCC: C8220710 07020490
	s_waitcnt lgkmcnt(0)                                       // 000000176BD4: BF89FC07
	v_fmac_f32_e32 v6, v16, v5                                 // 000000176BD8: 560C0B10
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000176BDC: BF870122
	v_mul_f32_e32 v4, 0xbfb8aa3b, v2                           // 000000176BE0: 100804FF BFB8AA3B
	.long 0xd41e0000                                           // 000000176BE8: D41E0000
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v2, vcc_lo               // 000000176BEC: 020204FF 42CE8ED0
	v_fma_f32 v5, 0xbfb8aa3b, v2, -v4                          // 000000176BF4: D6130005 841204FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000176C00: BF870131
	v_fmac_f32_e32 v5, 0xb2a5705f, v2                          // 000000176C04: 560A04FF B2A5705F
	v_div_scale_f32 v1, null, v7, v7, v6                       // 000000176C0C: D6FC7C01 041A0F07
	v_div_scale_f32 v12, vcc_lo, v6, v7, v6                    // 000000176C14: D6FC6A0C 041A0F06
	v_rcp_f32_e32 v3, v1                                       // 000000176C1C: 7E065501
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176C20: BF870095
	v_fma_f32 v9, -v1, v3, 1.0                                 // 000000176C24: D6130009 23CA0701
	v_fmac_f32_e32 v3, v9, v3                                  // 000000176C2C: 56060709
	v_rndne_f32_e32 v8, v4                                     // 000000176C30: 7E104704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000176C34: BF870121
	v_sub_f32_e32 v4, v4, v8                                   // 000000176C38: 08081104
	v_cvt_i32_f32_e32 v8, v8                                   // 000000176C3C: 7E101108
	v_add_f32_e32 v4, v4, v5                                   // 000000176C40: 06080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000176C44: BF870291
	v_exp_f32_e32 v4, v4                                       // 000000176C48: 7E084B04
	.long 0xd71c0004                                           // 000000176C4C: D71C0004
	v_cndmask_b32_e32 v1, v4, v8, vcc_lo                       // 000000176C50: 02021104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000176C54: BF8700A1
	v_cndmask_b32_e64 v4, 0, v4, s0                            // 000000176C58: D5010004 00020880
	v_mul_f32_e32 v5, v12, v3                                  // 000000176C60: 100A070C
	v_fma_f32 v9, -v1, v5, v12                                 // 000000176C64: D6130009 24320B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176C6C: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 000000176C70: 560A0709
	v_fma_f32 v1, -v1, v5, v12                                 // 000000176C74: D6130001 24320B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000176C7C: BF870121
	v_div_fmas_f32 v1, v1, v3, v5                              // 000000176C80: D6370001 04160701
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v2                   // 000000176C88: 7C3604FF C2B17218
	v_div_fixup_f32 v1, v1, v7, v6                             // 000000176C90: D6270001 041A0F01
	v_cndmask_b32_e32 v2, 0x7f800000, v4, vcc_lo               // 000000176C98: 020408FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176CA0: BF870091
	v_add_f32_e32 v2, 1.0, v2                                  // 000000176CA4: 060404F2
	v_div_scale_f32 v3, null, v2, v2, v1                       // 000000176CA8: D6FC7C03 04060502
	v_div_scale_f32 v6, vcc_lo, v1, v2, v1                     // 000000176CB0: D6FC6A06 04060501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000176CB8: BF870292
	v_rcp_f32_e32 v4, v3                                       // 000000176CBC: 7E085503
	v_fma_f32 v5, -v3, v4, 1.0                                 // 000000176CC0: D6130005 23CA0903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176CC8: BF870091
	v_fmac_f32_e32 v4, v5, v4                                  // 000000176CCC: 56080905
	v_mul_f32_e32 v5, v6, v4                                   // 000000176CD0: 100A0906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176CD4: BF870091
	v_fma_f32 v7, -v3, v5, v6                                  // 000000176CD8: D6130007 241A0B03
	v_fmac_f32_e32 v5, v7, v4                                  // 000000176CE0: 560A0907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176CE4: BF870091
	v_fma_f32 v3, -v3, v5, v6                                  // 000000176CE8: D6130003 241A0B03
	v_div_fmas_f32 v3, v3, v4, v5                              // 000000176CF0: D6370003 04160903
	v_cmp_lt_u32_e32 vcc_lo, 0xb7f, v0                         // 000000176CF8: 7C9200FF 00000B7F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000176D00: BF870132
	v_div_fixup_f32 v1, v3, v2, v1                             // 000000176D04: D6270001 04060503
	v_add_nc_u32_e32 v3, 0x80, v0                              // 000000176D0C: 4A0600FF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 000000176D14: 8C04046A
	v_bfe_u32 v2, v1, 16, 1                                    // 000000176D18: D6100002 02052101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000176D20: BF870112
	v_mov_b32_e32 v0, v3                                       // 000000176D24: 7E000303
	v_add3_u32 v4, v1, v2, 0x7fff                              // 000000176D28: D6550004 03FE0501 00007FFF
	.long 0xd7000001                                           // 000000176D34: D7000001
	v_cndmask_b32_e32 v1, s10, v10, vcc_lo                     // 000000176D38: 0202140A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000176D3C: BF870001
	v_add_co_ci_u32_e64 v2, null, s11, v11, s0                 // 000000176D40: D5207C02 0002160B
	global_store_d16_hi_b16 v[1:2], v4, off                    // 000000176D48: DC960000 007C0401
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000176D50: 917E047E
	s_cbranch_execz 173                                        // 000000176D54: BFA500AD <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x170c>
	v_lshrrev_b32_e32 v5, 8, v0                                // 000000176D58: 320A0088
	s_mov_b32 s0, exec_lo                                      // 000000176D5C: BE80007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176D60: BF870091
	v_lshlrev_b32_e32 v7, 2, v5                                // 000000176D64: 300E0A82
	v_add_nc_u32_e32 v1, 0xe800, v7                            // 000000176D68: 4A020EFF 0000E800
	ds_load_2addr_b32 v[3:4], v1 offset0:84 offset1:100        // 000000176D70: D8DC6454 03000001
	ds_load_2addr_b32 v[1:2], v1 offset0:116 offset1:132       // 000000176D78: D8DC8474 01000001
	s_waitcnt lgkmcnt(1)                                       // 000000176D80: BF89FC17
	v_max3_f32 v6, v3, 0xf149f2ca, v4                          // 000000176D84: D61C0006 0411FF03 F149F2CA
	s_waitcnt lgkmcnt(0)                                       // 000000176D90: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000176D94: BF870001
	v_max3_f32 v11, v6, v1, v2                                 // 000000176D98: D61C000B 040A0306
	v_mov_b32_e32 v6, 0                                        // 000000176DA0: 7E0C0280
	v_cmpx_lt_f32_e32 0xefa18f08, v3                           // 000000176DA4: 7D2206FF EFA18F08
	s_cbranch_execz 27                                         // 000000176DAC: BFA5001B <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x151c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176DB0: BF870093
	v_sub_f32_e32 v3, v3, v11                                  // 000000176DB4: 08061703
	v_mul_f32_e32 v6, 0x3fb8aa3b, v3                           // 000000176DB8: 100C06FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000176DC0: BF8700A1
	v_fma_f32 v8, 0x3fb8aa3b, v3, -v6                          // 000000176DC4: D6130008 841A06FF 3FB8AA3B
	v_rndne_f32_e32 v9, v6                                     // 000000176DD0: 7E124706
	v_sub_f32_e32 v6, v6, v9                                   // 000000176DD4: 080C1306
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000176DD8: BF870123
	v_fmac_f32_e32 v8, 0x32a5705f, v3                          // 000000176DDC: 561006FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000176DE4: 7C3606FF C2CE8ED0
	v_add_f32_e32 v6, v6, v8                                   // 000000176DEC: 060C1106
	v_cvt_i32_f32_e32 v8, v9                                   // 000000176DF0: 7E101109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000176DF4: BF870292
	v_exp_f32_e32 v6, v6                                       // 000000176DF8: 7E0C4B06
	.long 0xd71c0006                                           // 000000176DFC: D71C0006
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 000000176E00: 02021106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000176E04: BF870121
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo                        // 000000176E08: 020C0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000176E0C: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v6, 0x7f800000, v6, vcc_lo               // 000000176E14: 020C0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 000000176E1C: 8C7E007E
	v_dual_mov_b32 v13, 0 :: v_dual_and_b32 v10, 0xff, v0      // 000000176E20: CA240080 0D0A00FF 000000FF
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v3, 0xe950, v7  // 000000176E2C: CA200080 0C020EFF 0000E950
	v_lshlrev_b32_e32 v8, 10, v5                               // 000000176E38: 30100A8A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000176E3C: BF8701A3
	v_lshl_or_b32 v7, v10, 2, 0x800                            // 000000176E40: D6560007 03FD050A 00000800
	s_mov_b32 s0, exec_lo                                      // 000000176E4C: BE80007E
	v_add_nc_u32_e32 v3, 0xffffff00, v3                        // 000000176E50: 4A0606FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_2)                            // 000000176E58: BF870002
	v_add_nc_u32_e32 v9, v7, v8                                // 000000176E5C: 4A121107
	ds_load_b32 v7, v3                                         // 000000176E60: D8D80000 07000003
	ds_load_b32 v8, v9                                         // 000000176E68: D8D80000 08000009
	v_cmpx_lt_f32_e32 0xefa18f08, v4                           // 000000176E70: 7D2208FF EFA18F08
	s_cbranch_execz 26                                         // 000000176E78: BFA5001A <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x15e4>
	v_sub_f32_e32 v4, v4, v11                                  // 000000176E7C: 08081704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176E80: BF870091
	v_mul_f32_e32 v13, 0x3fb8aa3b, v4                          // 000000176E84: 101A08FF 3FB8AA3B
	v_fma_f32 v14, 0x3fb8aa3b, v4, -v13                        // 000000176E8C: D613000E 843608FF 3FB8AA3B
	v_rndne_f32_e32 v15, v13                                   // 000000176E98: 7E1E470D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176E9C: BF870091
	v_dual_fmac_f32 v14, 0x32a5705f, v4 :: v_dual_sub_f32 v13, v13, v15// 000000176EA0: C80A08FF 0E0C1F0D 32A5705F
	v_add_f32_e32 v13, v13, v14                                // 000000176EAC: 061A1D0D
	v_cvt_i32_f32_e32 v14, v15                                 // 000000176EB0: 7E1C110F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 000000176EB4: 7C3608FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000176EBC: BF870293
	v_exp_f32_e32 v13, v13                                     // 000000176EC0: 7E1A4B0D
	.long 0xd71c000d                                           // 000000176EC4: D71C000D
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                     // 000000176EC8: 02021D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000176ECC: BF870121
	v_cndmask_b32_e32 v13, 0, v13, vcc_lo                      // 000000176ED0: 021A1A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 000000176ED4: 7C3C08FF 42B17218
	v_cndmask_b32_e32 v13, 0x7f800000, v13, vcc_lo             // 000000176EDC: 021A1AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 000000176EE4: 8C7E007E
	ds_load_b32 v4, v3 offset:64                               // 000000176EE8: D8D80040 04000003
	ds_load_b32 v14, v9 offset:12288                           // 000000176EF0: D8D83000 0E000009
	s_mov_b32 s0, exec_lo                                      // 000000176EF8: BE80007E
	v_cmpx_lt_f32_e32 0xefa18f08, v1                           // 000000176EFC: 7D2202FF EFA18F08
	s_cbranch_execz 27                                         // 000000176F04: BFA5001B <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1674>
	v_sub_f32_e32 v1, v1, v11                                  // 000000176F08: 08021701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176F0C: BF870091
	v_mul_f32_e32 v12, 0x3fb8aa3b, v1                          // 000000176F10: 101802FF 3FB8AA3B
	v_fma_f32 v15, 0x3fb8aa3b, v1, -v12                        // 000000176F18: D613000F 843202FF 3FB8AA3B
	v_rndne_f32_e32 v16, v12                                   // 000000176F24: 7E20470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000176F28: BF870221
	v_sub_f32_e32 v12, v12, v16                                // 000000176F2C: 0818210C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 000000176F30: 7C3602FF C2CE8ED0
	v_fmac_f32_e32 v15, 0x32a5705f, v1                         // 000000176F38: 561E02FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000176F40: BF870121
	v_add_f32_e32 v12, v12, v15                                // 000000176F44: 06181F0C
	v_cvt_i32_f32_e32 v15, v16                                 // 000000176F48: 7E1E1110
	v_exp_f32_e32 v12, v12                                     // 000000176F4C: 7E184B0C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176F50: BF870095
	.long 0xd71c000c                                           // 000000176F54: D71C000C
	v_cndmask_b32_e32 v1, v12, v15, vcc_lo                     // 000000176F58: 02021F0C
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 000000176F5C: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 000000176F60: 7C3C02FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000176F68: BF870002
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 000000176F6C: 021818FF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 000000176F74: 8C7E007E
	ds_load_b32 v1, v3 offset:128                              // 000000176F78: D8D80080 01000003
	ds_load_b32 v15, v9 offset:24576                           // 000000176F80: D8D86000 0F000009
	v_mov_b32_e32 v16, 0                                       // 000000176F88: 7E200280
	s_mov_b32 s0, exec_lo                                      // 000000176F8C: BE80007E
	v_cmpx_lt_f32_e32 0xefa18f08, v2                           // 000000176F90: 7D2204FF EFA18F08
	s_cbranch_execz 65256                                      // 000000176F98: BFA5FEE8 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x123c>
	v_sub_f32_e32 v2, v2, v11                                  // 000000176F9C: 08041702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176FA0: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v2                          // 000000176FA4: 101604FF 3FB8AA3B
	v_fma_f32 v16, 0x3fb8aa3b, v2, -v11                        // 000000176FAC: D6130010 842E04FF 3FB8AA3B
	v_rndne_f32_e32 v17, v11                                   // 000000176FB8: 7E22470B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000176FBC: BF870221
	v_sub_f32_e32 v11, v11, v17                                // 000000176FC0: 0816230B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2                   // 000000176FC4: 7C3604FF C2CE8ED0
	v_fmac_f32_e32 v16, 0x32a5705f, v2                         // 000000176FCC: 562004FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000176FD4: BF870121
	v_add_f32_e32 v11, v11, v16                                // 000000176FD8: 0616210B
	v_cvt_i32_f32_e32 v16, v17                                 // 000000176FDC: 7E201111
	v_exp_f32_e32 v11, v11                                     // 000000176FE0: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000176FE4: BF870095
	.long 0xd71c000b                                           // 000000176FE8: D71C000B
	v_cndmask_b32_e32 v1, v11, v16, vcc_lo                     // 000000176FEC: 0202210B
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000176FF0: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2                   // 000000176FF4: 7C3C04FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000176FFC: BF870002
	v_cndmask_b32_e32 v16, 0x7f800000, v11, vcc_lo             // 000000177000: 022016FF 7F800000
	s_branch 65228                                             // 000000177008: BFA0FECC <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi4ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x123c>
	s_nop 0                                                    // 00000017700C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000177010: BFB60003
	s_endpgm                                                   // 000000177014: BFB00000
		...

