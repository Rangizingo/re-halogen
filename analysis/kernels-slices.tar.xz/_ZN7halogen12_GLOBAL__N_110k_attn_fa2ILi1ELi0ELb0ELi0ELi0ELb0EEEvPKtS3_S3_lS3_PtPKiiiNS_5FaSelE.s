00000000000c4300 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 0000000C4300: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 0000000C4304: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 0000000C430C: F4080500 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 0000000C4314: 3706009F
	v_lshrrev_b32_e32 v150, 5, v0                              // 0000000C4318: 332C0085
	s_mov_b32 s24, s3                                          // 0000000C431C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C4320: BF870112
	.long 0xd44c0003                                           // 0000000C4324: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 0000000C4328: 02030690
	v_lshlrev_b32_e32 v132, 6, v150                            // 0000000C432C: 31092C86
	s_waitcnt lgkmcnt(0)                                       // 0000000C4330: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 0000000C4334: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 0000000C433C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C4340: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 0000000C4344: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 0000000C434C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:156 offset1:162// 0000000C4358: D83CA29C 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C4360: 8C7E047E
	v_mul_u32_u24_e32 v1, 0xab, v0                             // 0000000C4364: 160200FF 000000AB
	.long 0x7f043880                                           // 0000000C436C: 7F043880
	v_dual_mov_b32 v141, 0 :: v_dual_and_b32 v148, 15, v0      // 0000000C4370: CA240080 8D94008F
	s_cmp_eq_u64 s[14:15], 0                                   // 0000000C4378: BF10800E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000C437C: BF8704B3
	.long 0x7e043981                                           // 0000000C4380: 7E043981
	v_mov_b32_e32 v142, 0                                      // 0000000C4384: 7F1C0280
	s_cselect_b32 s25, -1, 0                                   // 0000000C4388: 981980C1
	s_and_b32 vcc_lo, exec_lo, s25                             // 0000000C438C: 8B6A197E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4390: BF870092
	v_add_lshl_u32 v149, s2, v2, 4                             // 0000000C4394: D6470095 02120402
	v_or_b32_e32 v129, v149, v148                              // 0000000C439C: 39032995
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C43A0: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000C43A4: 3505029F
	s_cbranch_vccnz 10                                         // 0000000C43A8: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xd4>
	v_mad_i64_i32 v[1:2], null, s23, v129, 0                   // 0000000C43AC: D6FF7C01 02030217
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C43B4: BF870091
	.long 0xd73c0001                                           // 0000000C43B8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000000C43BC: 02020282
	.long 0xd7006a8d                                           // 0000000C43C0: D7006A8D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000000C43C4: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C43C8: BF870001
	v_add_co_ci_u32_e64 v142, null, s15, v2, vcc_lo            // 0000000C43CC: D5207C8E 01AA040F
	s_clause 0x2                                               // 0000000C43D4: BF850002
	s_load_b64 s[14:15], s[0:1], 0x38                          // 0000000C43D8: F4040380 F8000038
	s_load_b128 s[16:19], s[0:1], 0x20                         // 0000000C43E0: F4080400 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000000C43E8: F40C0100 F8000000
	v_mov_b32_e32 v152, 0                                      // 0000000C43F0: 7F300280
	s_xor_b32 s0, s25, -1                                      // 0000000C43F4: 8D00C119
	s_waitcnt lgkmcnt(0)                                       // 0000000C43F8: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v129                         // 0000000C43FC: 7C89020E
	s_and_b32 s23, s0, vcc_lo                                  // 0000000C4400: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C4404: BF870009
	s_and_saveexec_b32 s0, s23                                 // 0000000C4408: BE802017
	s_cbranch_execz 9                                          // 0000000C440C: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x134>
	.long 0xd73c0001                                           // 0000000C4410: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 0000000C4414: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4418: BF870091
	.long 0xd7006a01                                           // 0000000C441C: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 0000000C4420: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 0000000C4424: D5207C02 01AA0415
	global_load_b32 v152, v[1:2], off                          // 0000000C442C: DC520000 987C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000C4434: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 0000000C4438: BF10800C
	s_mov_b64 s[20:21], 0                                      // 0000000C443C: BE940180
	s_cbranch_scc1 10                                          // 0000000C4440: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c>
	s_ashr_i32 s0, s22, 31                                     // 0000000C4444: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 0000000C4448: 96810216
	s_mul_i32 s0, s0, s2                                       // 0000000C444C: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000C4450: BF8704A9
	s_add_i32 s1, s1, s0                                       // 0000000C4454: 81010001
	s_mul_i32 s0, s22, s2                                      // 0000000C4458: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000000C445C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C4460: BF870009
	s_add_u32 s20, s12, s0                                     // 0000000C4464: 8014000C
	s_addc_u32 s21, s13, s1                                    // 0000000C4468: 8215010D
	.long 0xd7050001                                           // 0000000C446C: D7050001
	v_cndmask_b32_e32 v0, v150, v150, vcc_lo                   // 0000000C4470: 02012D96
	s_lshl_b32 s0, s2, 4                                       // 0000000C4474: 84008402
	s_add_i32 s1, s14, -1                                      // 0000000C4478: 8101C10E
	s_or_b32 s0, s0, 15                                        // 0000000C447C: 8C008F00
	v_lshrrev_b32_e32 v151, 4, v131                            // 0000000C4480: 332F0684
	.long 0xd7390001                                           // 0000000C4484: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000000C4488: 02020288
	s_min_i32 s0, s0, s1                                       // 0000000C448C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000C4490: BF870499
	s_add_i32 s0, s26, s0                                      // 0000000C4494: 8100001A
	s_cmp_lt_i32 s0, -15                                       // 0000000C4498: BF04CF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C449C: BF870091
	.long 0xd7050001                                           // 0000000C44A0: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 0000000C44A4: 02011901
	.long 0xd7040001                                           // 0000000C44A8: D7040001
	v_cndmask_b32_e32 v1, v150, v1, vcc_lo                     // 0000000C44AC: 02020396
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C44B0: BF870091
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 0000000C44B4: CA240080 480002FF 000000FF
	v_mov_b32_e32 v71, v72                                     // 0000000C44C0: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 0000000C44C4: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 0000000C44C8: 7E880348
	v_mov_b32_e32 v67, v72                                     // 0000000C44CC: 7E860348
	v_mad_u64_u32 v[138:139], null, s24, 12, v[1:2]            // 0000000C44D0: D6FE7C8A 04051818
	v_mov_b32_e32 v70, v72                                     // 0000000C44D8: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 0000000C44DC: 7E840348
	v_mov_b32_e32 v65, v72                                     // 0000000C44E0: 7E820348
	v_mov_b32_e32 v80, v72                                     // 0000000C44E4: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 0000000C44E8: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 0000000C44EC: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 0000000C44F0: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 0000000C44F4: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 0000000C44FC: 7E960348
	v_mov_b32_e32 v74, v72                                     // 0000000C4500: 7E940348
	v_mov_b32_e32 v73, v72                                     // 0000000C4504: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C4508: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000000C450C: 3404029F
	v_mov_b32_e32 v88, v72                                     // 0000000C4510: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 0000000C4514: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 0000000C4518: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 0000000C451C: 7EAA0348
	.long 0xd73c008b                                           // 0000000C4520: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000000C4524: 02020281
	v_mov_b32_e32 v84, v72                                     // 0000000C4528: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 0000000C452C: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 0000000C4530: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 0000000C4534: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 0000000C4538: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 0000000C453C: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 0000000C4540: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 0000000C4544: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 0000000C4548: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 0000000C454C: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 0000000C4550: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 0000000C4554: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 0000000C4558: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 0000000C455C: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 0000000C4560: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 0000000C4564: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 0000000C4568: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 0000000C456C: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 0000000C4570: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 0000000C4574: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 0000000C4578: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 0000000C457C: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 0000000C4580: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 0000000C4584: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 0000000C4588: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 0000000C458C: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 0000000C4590: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 0000000C4594: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 0000000C4598: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 0000000C459C: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 0000000C45A0: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 0000000C45A4: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 0000000C45A8: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 0000000C45AC: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 0000000C45B0: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 0000000C45B4: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 0000000C45B8: 7F000348
	v_mov_b32_e32 v127, v72                                    // 0000000C45BC: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 0000000C45C0: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 0000000C45C4: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 0000000C45C8: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 0000000C45CC: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 0000000C45D0: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 0000000C45D4: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 0000000C45D8: 7E800348
	v_mov_b32_e32 v63, v72                                     // 0000000C45DC: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 0000000C45E0: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 0000000C45E4: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 0000000C45E8: 7E780348
	v_mov_b32_e32 v59, v72                                     // 0000000C45EC: 7E760348
	v_mov_b32_e32 v58, v72                                     // 0000000C45F0: 7E740348
	v_mov_b32_e32 v57, v72                                     // 0000000C45F4: 7E720348
	v_mov_b32_e32 v56, v72                                     // 0000000C45F8: 7E700348
	v_mov_b32_e32 v55, v72                                     // 0000000C45FC: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 0000000C4600: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 0000000C4604: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 0000000C4608: 7E680348
	v_mov_b32_e32 v51, v72                                     // 0000000C460C: 7E660348
	v_mov_b32_e32 v50, v72                                     // 0000000C4610: 7E640348
	v_mov_b32_e32 v49, v72                                     // 0000000C4614: 7E620348
	v_mov_b32_e32 v48, v72                                     // 0000000C4618: 7E600348
	v_mov_b32_e32 v47, v72                                     // 0000000C461C: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 0000000C4620: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 0000000C4624: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 0000000C4628: 7E580348
	v_mov_b32_e32 v43, v72                                     // 0000000C462C: 7E560348
	v_mov_b32_e32 v42, v72                                     // 0000000C4630: 7E540348
	v_mov_b32_e32 v41, v72                                     // 0000000C4634: 7E520348
	v_mov_b32_e32 v40, v72                                     // 0000000C4638: 7E500348
	v_mov_b32_e32 v39, v72                                     // 0000000C463C: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 0000000C4640: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 0000000C4644: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 0000000C4648: 7E480348
	v_mov_b32_e32 v35, v72                                     // 0000000C464C: 7E460348
	v_mov_b32_e32 v34, v72                                     // 0000000C4650: 7E440348
	v_mov_b32_e32 v33, v72                                     // 0000000C4654: 7E420348
	v_mov_b32_e32 v32, v72                                     // 0000000C4658: 7E400348
	v_mov_b32_e32 v31, v72                                     // 0000000C465C: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 0000000C4660: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 0000000C4664: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 0000000C4668: 7E380348
	v_mov_b32_e32 v27, v72                                     // 0000000C466C: 7E360348
	v_mov_b32_e32 v26, v72                                     // 0000000C4670: 7E340348
	v_mov_b32_e32 v25, v72                                     // 0000000C4674: 7E320348
	v_mov_b32_e32 v24, v72                                     // 0000000C4678: 7E300348
	v_mov_b32_e32 v23, v72                                     // 0000000C467C: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 0000000C4680: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 0000000C4684: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 0000000C4688: 7E280348
	v_mov_b32_e32 v19, v72                                     // 0000000C468C: 7E260348
	v_mov_b32_e32 v18, v72                                     // 0000000C4690: 7E240348
	v_mov_b32_e32 v17, v72                                     // 0000000C4694: 7E220348
	v_mov_b32_e32 v16, v72                                     // 0000000C4698: 7E200348
	v_mov_b32_e32 v15, v72                                     // 0000000C469C: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 0000000C46A0: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 0000000C46A4: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 0000000C46A8: 7E180348
	v_mov_b32_e32 v11, v72                                     // 0000000C46AC: 7E160348
	v_mov_b32_e32 v10, v72                                     // 0000000C46B0: 7E140348
	v_mov_b32_e32 v9, v72                                      // 0000000C46B4: 7E120348
	v_mov_b32_e32 v8, v72                                      // 0000000C46B8: 7E100348
	v_mov_b32_e32 v7, v72                                      // 0000000C46BC: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 0000000C46C0: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 0000000C46C4: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 0000000C46C8: 7E080348
	v_mov_b32_e32 v3, v72                                      // 0000000C46CC: 7E060348
	v_mov_b32_e32 v2, v72                                      // 0000000C46D0: 7E040348
	v_mov_b32_e32 v1, v72                                      // 0000000C46D4: 7E020348
	s_cbranch_scc1 2215                                        // 0000000C46D8: BFA208A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2678>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[4:5]           // 0000000C46DC: D6FF7C01 001302FF 00003000
	s_ashr_i32 s1, s0, 31                                      // 0000000C46E8: 86019F00
	v_add3_u32 v156, v149, v131, s26                           // 0000000C46EC: D655009C 006B0795
	s_lshr_b32 s1, s1, 28                                      // 0000000C46F4: 85019C01
	v_mad_u32_u24 v164, v148, 48, 0x4b00                       // 0000000C46F8: D60B00A4 03FD6194 00004B00
	s_add_i32 s0, s0, s1                                       // 0000000C4704: 81000100
	s_movk_i32 s1, 0x440                                       // 0000000C4708: B0010440
	s_ashr_i32 s2, s0, 4                                       // 0000000C470C: 86028400
	.long 0xd7006a8f                                           // 0000000C4710: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 0000000C4714: 02031701
	v_add3_u32 v1, v129, s26, 1                                // 0000000C4718: D6550001 02043581
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 0000000C4720: D5207C90 01AB1902
	v_mad_u32_u24 v3, v150, s1, 0x1800                         // 0000000C4728: D60B0003 03FC0396 00001800
	s_cmp_eq_u64 s[20:21], 0                                   // 0000000C4734: BF108014
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000C4738: BF870003
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000000C473C: 3404029F
	v_mov_b32_e32 v129, 0                                      // 0000000C4740: 7F020280
	v_lshlrev_b32_e32 v5, 2, v131                              // 0000000C4744: 300B0682
	v_mad_u32_u24 v4, 0x44, v151, v3                           // 0000000C4748: D60B0004 040F2EFF 00000044
	s_cselect_b32 s4, -1, 0                                    // 0000000C4754: 980480C1
	v_lshrrev_b32_e32 v2, 30, v2                               // 0000000C4758: 3204049E
	s_cmp_lg_u64 s[20:21], 0                                   // 0000000C475C: BF118014
	v_add_nc_u32_e32 v6, 0x9f00, v132                          // 0000000C4760: 4A0D08FF 00009F00
	v_lshl_add_u32 v154, v148, 2, v4                           // 0000000C4768: D646009A 04110594
	v_lshlrev_b32_e32 v4, 9, v150                              // 0000000C4770: 30092C89
	v_dual_mov_b32 v146, 0 :: v_dual_add_nc_u32 v1, v1, v2     // 0000000C4774: CA200080 92000501
	v_add_nc_u32_e32 v2, v5, v132                              // 0000000C477C: 4A050905
	s_cselect_b32 s5, -1, 0                                    // 0000000C4780: 980580C1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C4784: BF870193
	v_lshl_add_u32 v159, v131, 5, v4                           // 0000000C4788: D646009F 04110B83
	v_ashrrev_i32_e32 v155, 2, v1                              // 0000000C4790: 35360282
	v_lshlrev_b32_e32 v1, 3, v0                                // 0000000C4794: 30020083
	v_lshl_or_b32 v163, v148, 5, v4                            // 0000000C4798: D65600A3 04110B94
	v_mov_b32_e32 v4, v129                                     // 0000000C47A0: 7E080381
	s_ashr_i32 s25, s24, 31                                    // 0000000C47A4: 86199F18
	v_add_nc_u32_e32 v157, 0x9c00, v2                          // 0000000C47A8: 4B3A04FF 00009C00
	v_dual_mov_b32 v8, v129 :: v_dual_and_b32 v1, 0xf8, v1     // 0000000C47B0: CA240181 080002FF 000000F8
	v_add_nc_u32_e32 v160, 0xa200, v2                          // 0000000C47BC: 4B4004FF 0000A200
	s_lshl_b64 s[24:25], s[24:25], 9                           // 0000000C47C4: 84988918
	s_add_i32 s12, s15, -1                                     // 0000000C47C8: 810CC10F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000C47CC: BF8700C2
	v_dual_mov_b32 v7, v129 :: v_dual_lshlrev_b32 v2, 1, v1    // 0000000C47D0: CA220181 07020281
	s_add_u32 s6, s6, s24                                      // 0000000C47D8: 80061806
	s_addc_u32 s1, s7, s25                                     // 0000000C47DC: 82011907
	s_add_u32 s7, s8, s24                                      // 0000000C47E0: 80071808
	.long 0xd70006a5                                           // 0000000C47E4: D70006A5
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000000C47E8: 02020406
	s_movk_i32 s8, 0x210                                       // 0000000C47EC: B0080210
	s_addc_u32 s9, s9, s25                                     // 0000000C47F0: 82091909
	v_add_co_ci_u32_e64 v166, null, s1, 0, s6                  // 0000000C47F4: D5207CA6 00190001
	.long 0xd70001a7                                           // 0000000C47FC: D70001A7
	v_cndmask_b32_e32 v1, s7, v2, vcc_lo                       // 0000000C4800: 02020407
	.long 0xd44c0000                                           // 0000000C4804: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000000C4808: 020200FF 00000200
	v_mad_u32_u24 v153, v148, s8, 0x7b00                       // 0000000C4810: D60B0099 03FC1194 00007B00
	v_mad_u32_u24 v158, 0x44, v131, v3                         // 0000000C481C: D60B009E 040F06FF 00000044
	v_dual_mov_b32 v12, v129 :: v_dual_add_nc_u32 v145, 0x7b00, v2// 0000000C4828: CA200181 0C9004FF 00007B00
	v_add_co_ci_u32_e64 v168, null, s9, 0, s1                  // 0000000C4834: D5207CA8 00050009
	v_mad_u32_u24 v169, v1, 48, 0x4b00                         // 0000000C483C: D60B00A9 03FD6101 00004B00
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, v129            // 0000000C4848: CA100080 01020181
	v_mov_b32_e32 v3, v129                                     // 0000000C4850: 7E060381
	v_dual_mov_b32 v10, v129 :: v_dual_add_nc_u32 v161, v6, v5 // 0000000C4854: CA200181 0AA00B06
	v_lshl_or_b32 v162, v151, 2, v6                            // 0000000C485C: D65600A2 04190597
	v_mov_b32_e32 v5, v129                                     // 0000000C4864: 7E0A0381
	v_dual_mov_b32 v6, v129 :: v_dual_mov_b32 v9, 0            // 0000000C4868: CA100181 06080080
	v_mov_b32_e32 v14, v129                                    // 0000000C4870: 7E1C0381
	v_mov_b32_e32 v11, v129                                    // 0000000C4874: 7E160381
	v_mov_b32_e32 v13, v129                                    // 0000000C4878: 7E1A0381
	v_mov_b32_e32 v15, v129                                    // 0000000C487C: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v17, 0          // 0000000C4880: CA100181 10100080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v25, 0          // 0000000C4888: CA100181 12180080
	v_mov_b32_e32 v19, v129                                    // 0000000C4890: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v33, 0          // 0000000C4894: CA100181 14200080
	v_mov_b32_e32 v21, v129                                    // 0000000C489C: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v41, 0          // 0000000C48A0: CA100181 16280080
	v_mov_b32_e32 v23, v129                                    // 0000000C48A8: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v49, 0          // 0000000C48AC: CA100181 18300080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v57, 0          // 0000000C48B4: CA100181 1A380080
	v_mov_b32_e32 v27, v129                                    // 0000000C48BC: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v121, 0         // 0000000C48C0: CA100181 1C780080
	v_mov_b32_e32 v29, v129                                    // 0000000C48C8: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v113, 0         // 0000000C48CC: CA100181 1E700080
	v_mov_b32_e32 v31, v129                                    // 0000000C48D4: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v105, 0         // 0000000C48D8: CA100181 20680080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v97, 0          // 0000000C48E0: CA100181 22600080
	v_mov_b32_e32 v35, v129                                    // 0000000C48E8: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v89, 0          // 0000000C48EC: CA100181 24580080
	v_mov_b32_e32 v37, v129                                    // 0000000C48F4: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v81, 0          // 0000000C48F8: CA100181 26500080
	v_mov_b32_e32 v39, v129                                    // 0000000C4900: 7E4E0381
	v_dual_mov_b32 v40, v129 :: v_dual_mov_b32 v73, 0          // 0000000C4904: CA100181 28480080
	v_dual_mov_b32 v42, v129 :: v_dual_mov_b32 v65, 0          // 0000000C490C: CA100181 2A400080
	v_mov_b32_e32 v43, v129                                    // 0000000C4914: 7E560381
	v_mov_b32_e32 v44, v129                                    // 0000000C4918: 7E580381
	v_mov_b32_e32 v45, v129                                    // 0000000C491C: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 0000000C4920: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 0000000C4924: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 0000000C4928: 7E600381
	v_mov_b32_e32 v50, v129                                    // 0000000C492C: 7E640381
	v_mov_b32_e32 v51, v129                                    // 0000000C4930: 7E660381
	v_mov_b32_e32 v52, v129                                    // 0000000C4934: 7E680381
	v_mov_b32_e32 v53, v129                                    // 0000000C4938: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 0000000C493C: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 0000000C4940: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 0000000C4944: 7E700381
	v_mov_b32_e32 v58, v129                                    // 0000000C4948: 7E740381
	v_mov_b32_e32 v59, v129                                    // 0000000C494C: 7E760381
	v_mov_b32_e32 v60, v129                                    // 0000000C4950: 7E780381
	v_mov_b32_e32 v61, v129                                    // 0000000C4954: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 0000000C4958: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 0000000C495C: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 0000000C4960: 7E800381
	v_mov_b32_e32 v122, v129                                   // 0000000C4964: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 0000000C4968: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 0000000C496C: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 0000000C4970: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 0000000C4974: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 0000000C4978: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 0000000C497C: 7F000381
	v_mov_b32_e32 v114, v129                                   // 0000000C4980: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 0000000C4984: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 0000000C4988: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 0000000C498C: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 0000000C4990: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 0000000C4994: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 0000000C4998: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 0000000C499C: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 0000000C49A0: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 0000000C49A4: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 0000000C49A8: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 0000000C49AC: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 0000000C49B0: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 0000000C49B4: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 0000000C49B8: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 0000000C49BC: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 0000000C49C0: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 0000000C49C4: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 0000000C49C8: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 0000000C49CC: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 0000000C49D0: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 0000000C49D4: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 0000000C49D8: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 0000000C49DC: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 0000000C49E0: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 0000000C49E4: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 0000000C49E8: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 0000000C49EC: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 0000000C49F0: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 0000000C49F4: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 0000000C49F8: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 0000000C49FC: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 0000000C4A00: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 0000000C4A04: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 0000000C4A08: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 0000000C4A0C: 7E940381
	v_mov_b32_e32 v75, v129                                    // 0000000C4A10: 7E960381
	v_mov_b32_e32 v76, v129                                    // 0000000C4A14: 7E980381
	v_mov_b32_e32 v77, v129                                    // 0000000C4A18: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 0000000C4A1C: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 0000000C4A20: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 0000000C4A24: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 0000000C4A28: 7E840381
	v_mov_b32_e32 v67, v129                                    // 0000000C4A2C: 7E860381
	v_mov_b32_e32 v68, v129                                    // 0000000C4A30: 7E880381
	v_mov_b32_e32 v69, v129                                    // 0000000C4A34: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 0000000C4A38: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 0000000C4A3C: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 0000000C4A40: 7E900381
	s_mov_b32 s6, 0                                            // 0000000C4A44: BE860080
	s_branch 298                                               // 0000000C4A48: BFA0012A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbf4>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C4A4C: 8C7E017E
	v_add_f32_e32 v131, v133, v132                             // 0000000C4A50: 07070985
	ds_load_b32 v132, v160                                     // 0000000C4A54: D8D80000 840000A0
	v_add_f32_e32 v131, v131, v135                             // 0000000C4A5C: 07070F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4A60: BF870091
	v_add_f32_e32 v131, v131, v134                             // 0000000C4A64: 07070D83
	v_add_f32_e32 v131, v131, v137                             // 0000000C4A68: 07071383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4A6C: BF870091
	v_add_f32_e32 v131, v131, v136                             // 0000000C4A70: 07071183
	v_add_f32_e32 v131, v131, v170                             // 0000000C4A74: 07075583
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4A78: BF870091
	v_add_f32_e32 v131, v131, v147                             // 0000000C4A7C: 07072783
	v_add_f32_e32 v131, v131, v172                             // 0000000C4A80: 07075983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4A84: BF870091
	v_add_f32_e32 v131, v131, v171                             // 0000000C4A88: 07075783
	v_add_f32_e32 v131, v131, v174                             // 0000000C4A8C: 07075D83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4A90: BF870091
	v_add_f32_e32 v131, v131, v173                             // 0000000C4A94: 07075B83
	v_add_f32_e32 v131, v131, v176                             // 0000000C4A98: 07076183
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4A9C: BF870091
	v_add_f32_e32 v131, v131, v175                             // 0000000C4AA0: 07075F83
	v_add_f32_e32 v131, v131, v178                             // 0000000C4AA4: 07076583
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C4AA8: BF8700A1
	v_add_f32_e32 v131, v131, v177                             // 0000000C4AAC: 07076383
	s_waitcnt lgkmcnt(0)                                       // 0000000C4AB0: BF89FC07
	v_fmac_f32_e32 v131, v179, v132                            // 0000000C4AB4: 570709B3
	ds_store_b32 v157, v130                                    // 0000000C4AB8: D8340000 0000829D
	ds_store_b32 v160, v131                                    // 0000000C4AC0: D8340000 000083A0
	ds_store_b32 v161, v179                                    // 0000000C4AC8: D8340000 0000B3A1
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C4AD0: 8C7E087E
	s_waitcnt lgkmcnt(0)                                       // 0000000C4AD4: BF89FC07
	s_barrier                                                  // 0000000C4AD8: BFBD0000
	buffer_gl0_inv                                             // 0000000C4ADC: E0AC0000 00000000
	ds_load_b128 v[130:133], v163                              // 0000000C4AE4: DBFC0000 820000A3
	ds_load_b128 v[134:137], v163 offset:16                    // 0000000C4AEC: DBFC0010 860000A3
	ds_load_b128 v[170:173], v164                              // 0000000C4AF4: DBFC0000 AA0000A4
	ds_load_b128 v[174:177], v164 offset:16                    // 0000000C4AFC: DBFC0010 AE0000A4
	ds_load_2addr_b32 v[178:179], v162 offset1:2               // 0000000C4B04: D8DC0200 B20000A2
	ds_load_2addr_b32 v[180:181], v162 offset0:4 offset1:6     // 0000000C4B0C: D8DC0604 B40000A2
	ds_load_2addr_b32 v[182:183], v162 offset0:8 offset1:10    // 0000000C4B14: D8DC0A08 B60000A2
	ds_load_2addr_b32 v[184:185], v162 offset0:12 offset1:14   // 0000000C4B1C: D8DC0E0C B80000A2
	s_waitcnt lgkmcnt(3)                                       // 0000000C4B24: BF89FC37
	v_dual_mul_f32 v121, v178, v121 :: v_dual_mul_f32 v122, v179, v122// 0000000C4B28: C8C6F3B2 797AF5B3
	s_waitcnt lgkmcnt(2)                                       // 0000000C4B30: BF89FC27
	v_dual_mul_f32 v123, v180, v123 :: v_dual_mul_f32 v124, v181, v124// 0000000C4B34: C8C6F7B4 7B7CF9B5
	s_waitcnt lgkmcnt(1)                                       // 0000000C4B3C: BF89FC17
	v_dual_mul_f32 v125, v182, v125 :: v_dual_mul_f32 v126, v183, v126// 0000000C4B40: C8C6FBB6 7D7EFDB7
	s_waitcnt lgkmcnt(0)                                       // 0000000C4B48: BF89FC07
	v_dual_mul_f32 v127, v184, v127 :: v_dual_mul_f32 v128, v185, v128// 0000000C4B4C: C8C6FFB8 7F8101B9
	v_dual_mul_f32 v113, v178, v113 :: v_dual_mul_f32 v114, v179, v114// 0000000C4B54: C8C6E3B2 7172E5B3
	v_dual_mul_f32 v115, v180, v115 :: v_dual_mul_f32 v116, v181, v116// 0000000C4B5C: C8C6E7B4 7374E9B5
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000C4B64: BF870003
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[170:177], v[121:128]// 0000000C4B68: CC414079 1DE75582
	ds_load_b128 v[174:177], v164 offset:784                   // 0000000C4B70: DBFC0310 AE0000A4
	ds_load_b128 v[170:173], v164 offset:768                   // 0000000C4B78: DBFC0300 AA0000A4
	v_dual_mul_f32 v117, v182, v117 :: v_dual_mul_f32 v118, v183, v118// 0000000C4B80: C8C6EBB6 7576EDB7
	v_dual_mul_f32 v119, v184, v119 :: v_dual_mul_f32 v120, v185, v120// 0000000C4B88: C8C6EFB8 7778F1B9
	v_dual_mul_f32 v105, v178, v105 :: v_dual_mul_f32 v106, v179, v106// 0000000C4B90: C8C6D3B2 696AD5B3
	v_dual_mul_f32 v107, v180, v107 :: v_dual_mul_f32 v108, v181, v108// 0000000C4B98: C8C6D7B4 6B6CD9B5
	v_dual_mul_f32 v109, v182, v109 :: v_dual_mul_f32 v110, v183, v110// 0000000C4BA0: C8C6DBB6 6D6EDDB7
	v_dual_mul_f32 v111, v184, v111 :: v_dual_mul_f32 v112, v185, v112// 0000000C4BA8: C8C6DFB8 6F70E1B9
	v_dual_mul_f32 v97, v178, v97 :: v_dual_mul_f32 v98, v179, v98// 0000000C4BB0: C8C6C3B2 6162C5B3
	v_dual_mul_f32 v99, v180, v99 :: v_dual_mul_f32 v100, v181, v100// 0000000C4BB8: C8C6C7B4 6364C9B5
	v_dual_mul_f32 v101, v182, v101 :: v_dual_mul_f32 v102, v183, v102// 0000000C4BC0: C8C6CBB6 6566CDB7
	v_dual_mul_f32 v103, v184, v103 :: v_dual_mul_f32 v104, v185, v104// 0000000C4BC8: C8C6CFB8 6768D1B9
	s_waitcnt lgkmcnt(0)                                       // 0000000C4BD0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[170:177], v[113:120]// 0000000C4BD4: CC414071 1DC75582
	ds_load_b128 v[174:177], v164 offset:1552                  // 0000000C4BDC: DBFC0610 AE0000A4
	ds_load_b128 v[170:173], v164 offset:1536                  // 0000000C4BE4: DBFC0600 AA0000A4
	v_dual_mul_f32 v89, v178, v89 :: v_dual_mul_f32 v90, v179, v90// 0000000C4BEC: C8C6B3B2 595AB5B3
	v_dual_mul_f32 v91, v180, v91 :: v_dual_mul_f32 v92, v181, v92// 0000000C4BF4: C8C6B7B4 5B5CB9B5
	v_dual_mul_f32 v93, v182, v93 :: v_dual_mul_f32 v94, v183, v94// 0000000C4BFC: C8C6BBB6 5D5EBDB7
	v_dual_mul_f32 v95, v184, v95 :: v_dual_mul_f32 v96, v185, v96// 0000000C4C04: C8C6BFB8 5F60C1B9
	v_dual_mul_f32 v81, v178, v81 :: v_dual_mul_f32 v82, v179, v82// 0000000C4C0C: C8C6A3B2 5152A5B3
	v_dual_mul_f32 v83, v180, v83 :: v_dual_mul_f32 v84, v181, v84// 0000000C4C14: C8C6A7B4 5354A9B5
	v_dual_mul_f32 v85, v182, v85 :: v_dual_mul_f32 v86, v183, v86// 0000000C4C1C: C8C6ABB6 5556ADB7
	v_dual_mul_f32 v87, v184, v87 :: v_dual_mul_f32 v88, v185, v88// 0000000C4C24: C8C6AFB8 5758B1B9
	v_dual_mul_f32 v73, v178, v73 :: v_dual_mul_f32 v74, v179, v74// 0000000C4C2C: C8C693B2 494A95B3
	v_dual_mul_f32 v75, v180, v75 :: v_dual_mul_f32 v76, v181, v76// 0000000C4C34: C8C697B4 4B4C99B5
	s_waitcnt lgkmcnt(0)                                       // 0000000C4C3C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[170:177], v[105:112]// 0000000C4C40: CC414069 1DA75582
	ds_load_b128 v[174:177], v164 offset:2320                  // 0000000C4C48: DBFC0910 AE0000A4
	ds_load_b128 v[170:173], v164 offset:2304                  // 0000000C4C50: DBFC0900 AA0000A4
	v_dual_mul_f32 v77, v182, v77 :: v_dual_mul_f32 v78, v183, v78// 0000000C4C58: C8C69BB6 4D4E9DB7
	v_dual_mul_f32 v79, v184, v79 :: v_dual_mul_f32 v80, v185, v80// 0000000C4C60: C8C69FB8 4F50A1B9
	v_dual_mul_f32 v65, v178, v65 :: v_dual_mul_f32 v66, v179, v66// 0000000C4C68: C8C683B2 414285B3
	v_dual_mul_f32 v67, v180, v67 :: v_dual_mul_f32 v68, v181, v68// 0000000C4C70: C8C687B4 434489B5
	v_dual_mul_f32 v69, v182, v69 :: v_dual_mul_f32 v70, v183, v70// 0000000C4C78: C8C68BB6 45468DB7
	v_dual_mul_f32 v71, v184, v71 :: v_dual_mul_f32 v72, v185, v72// 0000000C4C80: C8C68FB8 474891B9
	v_dual_mul_f32 v57, v178, v57 :: v_dual_mul_f32 v58, v179, v58// 0000000C4C88: C8C673B2 393A75B3
	v_dual_mul_f32 v59, v180, v59 :: v_dual_mul_f32 v60, v181, v60// 0000000C4C90: C8C677B4 3B3C79B5
	v_dual_mul_f32 v61, v182, v61 :: v_dual_mul_f32 v62, v183, v62// 0000000C4C98: C8C67BB6 3D3E7DB7
	v_dual_mul_f32 v63, v184, v63 :: v_dual_mul_f32 v64, v185, v64// 0000000C4CA0: C8C67FB8 3F4081B9
	s_waitcnt lgkmcnt(0)                                       // 0000000C4CA8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[170:177], v[97:104]// 0000000C4CAC: CC414061 1D875582
	ds_load_b128 v[174:177], v164 offset:3088                  // 0000000C4CB4: DBFC0C10 AE0000A4
	ds_load_b128 v[170:173], v164 offset:3072                  // 0000000C4CBC: DBFC0C00 AA0000A4
	v_dual_mul_f32 v49, v178, v49 :: v_dual_mul_f32 v50, v179, v50// 0000000C4CC4: C8C663B2 313265B3
	v_dual_mul_f32 v51, v180, v51 :: v_dual_mul_f32 v52, v181, v52// 0000000C4CCC: C8C667B4 333469B5
	v_dual_mul_f32 v53, v182, v53 :: v_dual_mul_f32 v54, v183, v54// 0000000C4CD4: C8C66BB6 35366DB7
	v_dual_mul_f32 v55, v184, v55 :: v_dual_mul_f32 v56, v185, v56// 0000000C4CDC: C8C66FB8 373871B9
	v_dual_mul_f32 v41, v178, v41 :: v_dual_mul_f32 v42, v179, v42// 0000000C4CE4: C8C653B2 292A55B3
	v_dual_mul_f32 v43, v180, v43 :: v_dual_mul_f32 v44, v181, v44// 0000000C4CEC: C8C657B4 2B2C59B5
	v_dual_mul_f32 v45, v182, v45 :: v_dual_mul_f32 v46, v183, v46// 0000000C4CF4: C8C65BB6 2D2E5DB7
	v_dual_mul_f32 v47, v184, v47 :: v_dual_mul_f32 v48, v185, v48// 0000000C4CFC: C8C65FB8 2F3061B9
	v_dual_mul_f32 v33, v178, v33 :: v_dual_mul_f32 v34, v179, v34// 0000000C4D04: C8C643B2 212245B3
	v_dual_mul_f32 v35, v180, v35 :: v_dual_mul_f32 v36, v181, v36// 0000000C4D0C: C8C647B4 232449B5
	s_waitcnt lgkmcnt(0)                                       // 0000000C4D14: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[170:177], v[89:96]// 0000000C4D18: CC414059 1D675582
	ds_load_b128 v[174:177], v164 offset:3856                  // 0000000C4D20: DBFC0F10 AE0000A4
	ds_load_b128 v[170:173], v164 offset:3840                  // 0000000C4D28: DBFC0F00 AA0000A4
	v_dual_mul_f32 v37, v182, v37 :: v_dual_mul_f32 v38, v183, v38// 0000000C4D30: C8C64BB6 25264DB7
	v_dual_mul_f32 v39, v184, v39 :: v_dual_mul_f32 v40, v185, v40// 0000000C4D38: C8C64FB8 272851B9
	v_dual_mul_f32 v25, v178, v25 :: v_dual_mul_f32 v26, v179, v26// 0000000C4D40: C8C633B2 191A35B3
	v_dual_mul_f32 v27, v180, v27 :: v_dual_mul_f32 v28, v181, v28// 0000000C4D48: C8C637B4 1B1C39B5
	v_dual_mul_f32 v29, v182, v29 :: v_dual_mul_f32 v30, v183, v30// 0000000C4D50: C8C63BB6 1D1E3DB7
	v_dual_mul_f32 v31, v184, v31 :: v_dual_mul_f32 v32, v185, v32// 0000000C4D58: C8C63FB8 1F2041B9
	v_dual_mul_f32 v17, v178, v17 :: v_dual_mul_f32 v18, v179, v18// 0000000C4D60: C8C623B2 111225B3
	v_dual_mul_f32 v19, v180, v19 :: v_dual_mul_f32 v20, v181, v20// 0000000C4D68: C8C627B4 131429B5
	v_dual_mul_f32 v21, v182, v21 :: v_dual_mul_f32 v22, v183, v22// 0000000C4D70: C8C62BB6 15162DB7
	v_dual_mul_f32 v23, v184, v23 :: v_dual_mul_f32 v24, v185, v24// 0000000C4D78: C8C62FB8 171831B9
	s_waitcnt lgkmcnt(0)                                       // 0000000C4D80: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[170:177], v[81:88]// 0000000C4D84: CC414051 1D475582
	ds_load_b128 v[174:177], v164 offset:4624                  // 0000000C4D8C: DBFC1210 AE0000A4
	ds_load_b128 v[170:173], v164 offset:4608                  // 0000000C4D94: DBFC1200 AA0000A4
	v_dual_mul_f32 v9, v178, v9 :: v_dual_mul_f32 v10, v179, v10// 0000000C4D9C: C8C613B2 090A15B3
	v_dual_mul_f32 v11, v180, v11 :: v_dual_mul_f32 v12, v181, v12// 0000000C4DA4: C8C617B4 0B0C19B5
	v_dual_mul_f32 v13, v182, v13 :: v_dual_mul_f32 v14, v183, v14// 0000000C4DAC: C8C61BB6 0D0E1DB7
	v_dual_mul_f32 v15, v184, v15 :: v_dual_mul_f32 v16, v185, v16// 0000000C4DB4: C8C61FB8 0F1021B9
	v_dual_mul_f32 v1, v178, v1 :: v_dual_mul_f32 v2, v179, v2 // 0000000C4DBC: C8C603B2 010205B3
	v_dual_mul_f32 v3, v180, v3 :: v_dual_mul_f32 v4, v181, v4 // 0000000C4DC4: C8C607B4 030409B5
	v_dual_mul_f32 v5, v182, v5 :: v_dual_mul_f32 v6, v183, v6 // 0000000C4DCC: C8C60BB6 05060DB7
	v_dual_mul_f32 v7, v184, v7 :: v_dual_mul_f32 v8, v185, v8 // 0000000C4DD4: C8C60FB8 070811B9
	s_waitcnt lgkmcnt(0)                                       // 0000000C4DDC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[170:177], v[73:80]// 0000000C4DE0: CC414049 1D275582
	ds_load_b128 v[174:177], v164 offset:5392                  // 0000000C4DE8: DBFC1510 AE0000A4
	ds_load_b128 v[170:173], v164 offset:5376                  // 0000000C4DF0: DBFC1500 AA0000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000C4DF8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[170:177], v[65:72]// 0000000C4DFC: CC414041 1D075582
	ds_load_b128 v[174:177], v164 offset:6160                  // 0000000C4E04: DBFC1810 AE0000A4
	ds_load_b128 v[170:173], v164 offset:6144                  // 0000000C4E0C: DBFC1800 AA0000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000C4E14: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[170:177], v[57:64]// 0000000C4E18: CC414039 1CE75582
	ds_load_b128 v[174:177], v164 offset:6928                  // 0000000C4E20: DBFC1B10 AE0000A4
	ds_load_b128 v[170:173], v164 offset:6912                  // 0000000C4E28: DBFC1B00 AA0000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000C4E30: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[170:177], v[49:56]// 0000000C4E34: CC414031 1CC75582
	ds_load_b128 v[174:177], v164 offset:7696                  // 0000000C4E3C: DBFC1E10 AE0000A4
	ds_load_b128 v[170:173], v164 offset:7680                  // 0000000C4E44: DBFC1E00 AA0000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000C4E4C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[170:177], v[41:48]// 0000000C4E50: CC414029 1CA75582
	ds_load_b128 v[174:177], v164 offset:8464                  // 0000000C4E58: DBFC2110 AE0000A4
	ds_load_b128 v[170:173], v164 offset:8448                  // 0000000C4E60: DBFC2100 AA0000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000C4E68: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[170:177], v[33:40]// 0000000C4E6C: CC414021 1C875582
	ds_load_b128 v[174:177], v164 offset:9232                  // 0000000C4E74: DBFC2410 AE0000A4
	ds_load_b128 v[170:173], v164 offset:9216                  // 0000000C4E7C: DBFC2400 AA0000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000C4E84: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[170:177], v[25:32]// 0000000C4E88: CC414019 1C675582
	ds_load_b128 v[174:177], v164 offset:10000                 // 0000000C4E90: DBFC2710 AE0000A4
	ds_load_b128 v[170:173], v164 offset:9984                  // 0000000C4E98: DBFC2700 AA0000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000C4EA0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[170:177], v[17:24]// 0000000C4EA4: CC414011 1C475582
	ds_load_b128 v[174:177], v164 offset:10768                 // 0000000C4EAC: DBFC2A10 AE0000A4
	ds_load_b128 v[170:173], v164 offset:10752                 // 0000000C4EB4: DBFC2A00 AA0000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000C4EBC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[170:177], v[9:16]// 0000000C4EC0: CC414009 1C275582
	ds_load_b128 v[174:177], v164 offset:11536                 // 0000000C4EC8: DBFC2D10 AE0000A4
	ds_load_b128 v[170:173], v164 offset:11520                 // 0000000C4ED0: DBFC2D00 AA0000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000C4ED8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[170:177], v[1:8]// 0000000C4EDC: CC414001 1C075582
	s_add_i32 s1, s6, 1                                        // 0000000C4EE4: 81018106
	s_cmp_eq_u32 s6, s2                                        // 0000000C4EE8: BF060206
	s_mov_b32 s6, s1                                           // 0000000C4EEC: BE860001
	s_cbranch_scc1 1697                                        // 0000000C4EF0: BFA206A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2678>
	s_and_not1_b32 vcc_lo, exec_lo, s5                         // 0000000C4EF4: 916A057E
	s_mov_b32 s1, s4                                           // 0000000C4EF8: BE810004
	s_cbranch_vccz 3                                           // 0000000C4EFC: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc0c>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000000C4F00: 916A017E
	s_cbranch_vccnz 65527                                      // 0000000C4F04: BFA4FFF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbe4>
	s_branch 15                                                // 0000000C4F08: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc48>
	s_lshr_b32 s1, s6, 3                                       // 0000000C4F0C: 85018306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000C4F10: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 0000000C4F14: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 0000000C4F1C: 7F040201
	global_load_b32 v130, v130, s[20:21]                       // 0000000C4F20: DC520000 82140082
	s_waitcnt vmcnt(0)                                         // 0000000C4F28: BF8903F7
	v_lshrrev_b32_e32 v130, s6, v130                           // 0000000C4F2C: 33050406
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4F30: BF870091
	v_and_b32_e32 v130, 1, v130                                // 0000000C4F34: 37050481
	.long 0xd44a0001                                           // 0000000C4F38: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000C4F3C: 02030481
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000000C4F40: 916A017E
	s_cbranch_vccnz 65511                                      // 0000000C4F44: BFA4FFE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbe4>
	s_lshl_b32 s7, s6, 4                                       // 0000000C4F48: 84078406
	s_waitcnt vmcnt(0)                                         // 0000000C4F4C: BF8903F7
	s_barrier                                                  // 0000000C4F50: BFBD0000
	buffer_gl0_inv                                             // 0000000C4F54: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000000C4F5C: BE812000
	s_cbranch_execz 67                                         // 0000000C4F60: BFA50043 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xd70>
	v_mov_b32_e32 v130, v0                                     // 0000000C4F64: 7F040300
	s_mov_b32 s8, 0                                            // 0000000C4F68: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C4F6C: BF870121
	v_lshrrev_b32_e32 v137, 5, v130                            // 0000000C4F70: 33130485
	v_add_nc_u32_e32 v147, 0x180, v130                         // 0000000C4F74: 4B2704FF 00000180
	v_or_b32_e32 v131, s7, v137                                // 0000000C4F7C: 39071207
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4F80: BF870091
	v_min_i32_e32 v131, s12, v131                              // 0000000C4F84: 2307060C
	v_ashrrev_i32_e32 v133, 31, v131                           // 0000000C4F88: 350B069F
	.long 0xd72c0086                                           // 0000000C4F8C: D72C0086
	v_cndmask_b32_e32 v1, s11, v131, vcc_lo                    // 0000000C4F90: 0203060B
	v_mad_u64_u32 v[131:132], null, s10, v131, 0               // 0000000C4F94: D6FE7C83 0203060A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4F9C: BF870093
	.long 0xd72c0085                                           // 0000000C4FA0: D72C0085
	v_cndmask_b32_e32 v1, s10, v133, vcc_lo                    // 0000000C4FA4: 02030A0A
	v_add3_u32 v132, v132, v133, v134                          // 0000000C4FA8: D6550084 061B0B84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4FB0: BF870091
	.long 0xd73c0083                                           // 0000000C4FB4: D73C0083
	v_cndmask_b32_e32 v1, 1, v131, vcc_lo                      // 0000000C4FB8: 02030681
	.long 0xd7006a85                                           // 0000000C4FBC: D7006A85
	v_cndmask_b32_e32 v1, v165, v131, vcc_lo                   // 0000000C4FC0: 020307A5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C4FC4: BF8700A1
	v_add_co_ci_u32_e64 v134, null, v166, v132, vcc_lo         // 0000000C4FC8: D5207C86 01AB09A6
	.long 0xd7006a87                                           // 0000000C4FD0: D7006A87
	v_cndmask_b32_e32 v1, v167, v131, vcc_lo                   // 0000000C4FD4: 020307A7
	v_add_co_ci_u32_e64 v136, null, v168, v132, vcc_lo         // 0000000C4FD8: D5207C88 01AB09A8
	global_load_b128 v[131:134], v[133:134], off               // 0000000C4FE0: DC5E0000 837C0085
	global_load_b128 v[170:173], v[135:136], off               // 0000000C4FE8: DC5E0000 AA7C0087
	v_mad_u64_u32 v[135:136], null, 0x210, v137, v[145:146]    // 0000000C4FF0: D6FE7C87 064712FF 00000210
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v130                        // 0000000C4FFC: 7C9304FF 0000007F
	v_mov_b32_e32 v130, v147                                   // 0000000C5004: 7F040393
	v_lshl_add_u32 v136, v137, 1, v169                         // 0000000C5008: D6460088 06A50389
	s_waitcnt vmcnt(1)                                         // 0000000C5010: BF8907F7
	ds_store_b128 v135, v[131:134]                             // 0000000C5014: DB7C0000 00008387
	s_waitcnt vmcnt(0)                                         // 0000000C501C: BF8903F7
	ds_store_b16 v136, v170                                    // 0000000C5020: D87C0000 0000AA88
	ds_store_b16_d16_hi v136, v170 offset:48                   // 0000000C5028: DA840030 0000AA88
	ds_store_b16 v136, v171 offset:96                          // 0000000C5030: D87C0060 0000AB88
	ds_store_b16_d16_hi v136, v171 offset:144                  // 0000000C5038: DA840090 0000AB88
	ds_store_b16 v136, v172 offset:192                         // 0000000C5040: D87C00C0 0000AC88
	ds_store_b16_d16_hi v136, v172 offset:240                  // 0000000C5048: DA8400F0 0000AC88
	ds_store_b16 v136, v173 offset:288                         // 0000000C5050: D87C0120 0000AD88
	ds_store_b16_d16_hi v136, v173 offset:336                  // 0000000C5058: DA840150 0000AD88
	s_or_b32 s8, vcc_lo, s8                                    // 0000000C5060: 8C08086A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5064: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000000C5068: 917E087E
	s_cbranch_execnz 65471                                     // 0000000C506C: BFA6FFBF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc6c>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5070: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 0000000C5074: BF89FC07
	s_barrier                                                  // 0000000C5078: BFBD0000
	buffer_gl0_inv                                             // 0000000C507C: E0AC0000 00000000
	s_clause 0x3                                               // 0000000C5084: BF850003
	global_load_b128 v[174:177], v[143:144], off offset:16     // 0000000C5088: DC5E0010 AE7C008F
	global_load_b128 v[170:173], v[143:144], off               // 0000000C5090: DC5E0000 AA7C008F
	global_load_b128 v[182:185], v[143:144], off offset:48     // 0000000C5098: DC5E0030 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:32     // 0000000C50A0: DC5E0020 B27C008F
	ds_load_b128 v[186:189], v153                              // 0000000C50A8: DBFC0000 BA000099
	ds_load_b128 v[190:193], v153 offset:16                    // 0000000C50B0: DBFC0010 BE000099
	v_mov_b32_e32 v136, v129                                   // 0000000C50B8: 7F100381
	v_mov_b32_e32 v130, v129                                   // 0000000C50BC: 7F040381
	v_mov_b32_e32 v131, v129                                   // 0000000C50C0: 7F060381
	v_mov_b32_e32 v132, v129                                   // 0000000C50C4: 7F080381
	v_mov_b32_e32 v133, v129                                   // 0000000C50C8: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 0000000C50CC: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 0000000C50D0: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 0000000C50D4: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000C50D8: BF870212
	v_mov_b32_e32 v136, v135                                   // 0000000C50DC: 7F100387
	v_mov_b32_e32 v135, v134                                   // 0000000C50E0: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 0000000C50E4: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 0000000C50E8: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 0000000C50EC: 7F080383
	v_mov_b32_e32 v131, v130                                   // 0000000C50F0: 7F060382
	v_mov_b32_e32 v130, v129                                   // 0000000C50F4: 7F040381
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C50F8: BF890807
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C50FC: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[186:193], v[130:137]// 0000000C5100: CC414082 1E0B75AA
	s_clause 0x1                                               // 0000000C5108: BF850001
	global_load_b128 v[174:177], v[143:144], off offset:80     // 0000000C510C: DC5E0050 AE7C008F
	global_load_b128 v[170:173], v[143:144], off offset:64     // 0000000C5114: DC5E0040 AA7C008F
	ds_load_b128 v[186:189], v153 offset:32                    // 0000000C511C: DBFC0020 BA000099
	ds_load_b128 v[190:193], v153 offset:48                    // 0000000C5124: DBFC0030 BE000099
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C512C: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000C5130: CC414082 1E0B75B2
	s_clause 0x1                                               // 0000000C5138: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:112    // 0000000C513C: DC5E0070 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:96     // 0000000C5144: DC5E0060 B27C008F
	ds_load_b128 v[190:193], v153 offset:80                    // 0000000C514C: DBFC0050 BE000099
	ds_load_b128 v[186:189], v153 offset:64                    // 0000000C5154: DBFC0040 BA000099
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C515C: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[186:193], v[130:137]// 0000000C5160: CC414082 1E0B75AA
	s_clause 0x1                                               // 0000000C5168: BF850001
	global_load_b128 v[174:177], v[143:144], off offset:144    // 0000000C516C: DC5E0090 AE7C008F
	global_load_b128 v[170:173], v[143:144], off offset:128    // 0000000C5174: DC5E0080 AA7C008F
	ds_load_b128 v[190:193], v153 offset:112                   // 0000000C517C: DBFC0070 BE000099
	ds_load_b128 v[186:189], v153 offset:96                    // 0000000C5184: DBFC0060 BA000099
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C518C: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000C5190: CC414082 1E0B75B2
	s_clause 0x1                                               // 0000000C5198: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:176    // 0000000C519C: DC5E00B0 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:160    // 0000000C51A4: DC5E00A0 B27C008F
	ds_load_b128 v[190:193], v153 offset:144                   // 0000000C51AC: DBFC0090 BE000099
	ds_load_b128 v[186:189], v153 offset:128                   // 0000000C51B4: DBFC0080 BA000099
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C51BC: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[186:193], v[130:137]// 0000000C51C0: CC414082 1E0B75AA
	s_clause 0x1                                               // 0000000C51C8: BF850001
	global_load_b128 v[174:177], v[143:144], off offset:208    // 0000000C51CC: DC5E00D0 AE7C008F
	global_load_b128 v[170:173], v[143:144], off offset:192    // 0000000C51D4: DC5E00C0 AA7C008F
	ds_load_b128 v[190:193], v153 offset:176                   // 0000000C51DC: DBFC00B0 BE000099
	ds_load_b128 v[186:189], v153 offset:160                   // 0000000C51E4: DBFC00A0 BA000099
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C51EC: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000C51F0: CC414082 1E0B75B2
	s_clause 0x1                                               // 0000000C51F8: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:240    // 0000000C51FC: DC5E00F0 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:224    // 0000000C5204: DC5E00E0 B27C008F
	ds_load_b128 v[190:193], v153 offset:208                   // 0000000C520C: DBFC00D0 BE000099
	ds_load_b128 v[186:189], v153 offset:192                   // 0000000C5214: DBFC00C0 BA000099
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C521C: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[186:193], v[130:137]// 0000000C5220: CC414082 1E0B75AA
	s_clause 0x1                                               // 0000000C5228: BF850001
	global_load_b128 v[174:177], v[143:144], off offset:272    // 0000000C522C: DC5E0110 AE7C008F
	global_load_b128 v[170:173], v[143:144], off offset:256    // 0000000C5234: DC5E0100 AA7C008F
	ds_load_b128 v[190:193], v153 offset:240                   // 0000000C523C: DBFC00F0 BE000099
	ds_load_b128 v[186:189], v153 offset:224                   // 0000000C5244: DBFC00E0 BA000099
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C524C: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000C5250: CC414082 1E0B75B2
	s_clause 0x1                                               // 0000000C5258: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:304    // 0000000C525C: DC5E0130 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:288    // 0000000C5264: DC5E0120 B27C008F
	ds_load_b128 v[190:193], v153 offset:272                   // 0000000C526C: DBFC0110 BE000099
	ds_load_b128 v[186:189], v153 offset:256                   // 0000000C5274: DBFC0100 BA000099
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C527C: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[186:193], v[130:137]// 0000000C5280: CC414082 1E0B75AA
	s_clause 0x1                                               // 0000000C5288: BF850001
	global_load_b128 v[174:177], v[143:144], off offset:336    // 0000000C528C: DC5E0150 AE7C008F
	global_load_b128 v[170:173], v[143:144], off offset:320    // 0000000C5294: DC5E0140 AA7C008F
	ds_load_b128 v[190:193], v153 offset:304                   // 0000000C529C: DBFC0130 BE000099
	ds_load_b128 v[186:189], v153 offset:288                   // 0000000C52A4: DBFC0120 BA000099
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C52AC: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000C52B0: CC414082 1E0B75B2
	s_clause 0x1                                               // 0000000C52B8: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:368    // 0000000C52BC: DC5E0170 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:352    // 0000000C52C4: DC5E0160 B27C008F
	ds_load_b128 v[190:193], v153 offset:336                   // 0000000C52CC: DBFC0150 BE000099
	ds_load_b128 v[186:189], v153 offset:320                   // 0000000C52D4: DBFC0140 BA000099
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C52DC: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[186:193], v[130:137]// 0000000C52E0: CC414082 1E0B75AA
	s_clause 0x1                                               // 0000000C52E8: BF850001
	global_load_b128 v[174:177], v[143:144], off offset:400    // 0000000C52EC: DC5E0190 AE7C008F
	global_load_b128 v[170:173], v[143:144], off offset:384    // 0000000C52F4: DC5E0180 AA7C008F
	ds_load_b128 v[190:193], v153 offset:368                   // 0000000C52FC: DBFC0170 BE000099
	ds_load_b128 v[186:189], v153 offset:352                   // 0000000C5304: DBFC0160 BA000099
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C530C: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000C5310: CC414082 1E0B75B2
	ds_load_b128 v[182:185], v153 offset:400                   // 0000000C5318: DBFC0190 B6000099
	ds_load_b128 v[178:181], v153 offset:384                   // 0000000C5320: DBFC0180 B2000099
	s_clause 0x1                                               // 0000000C5328: BF850001
	global_load_b128 v[190:193], v[143:144], off offset:432    // 0000000C532C: DC5E01B0 BE7C008F
	global_load_b128 v[186:189], v[143:144], off offset:416    // 0000000C5334: DC5E01A0 BA7C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C533C: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[178:185], v[130:137]// 0000000C5340: CC414082 1E0B65AA
	s_clause 0x1                                               // 0000000C5348: BF850001
	global_load_b128 v[174:177], v[143:144], off offset:464    // 0000000C534C: DC5E01D0 AE7C008F
	global_load_b128 v[170:173], v[143:144], off offset:448    // 0000000C5354: DC5E01C0 AA7C008F
	ds_load_b128 v[182:185], v153 offset:432                   // 0000000C535C: DBFC01B0 B6000099
	ds_load_b128 v[178:181], v153 offset:416                   // 0000000C5364: DBFC01A0 B2000099
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C536C: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[186:193], v[178:185], v[130:137]// 0000000C5370: CC414082 1E0B65BA
	ds_load_b128 v[182:185], v153 offset:464                   // 0000000C5378: DBFC01D0 B6000099
	ds_load_b128 v[178:181], v153 offset:448                   // 0000000C5380: DBFC01C0 B2000099
	s_clause 0x1                                               // 0000000C5388: BF850001
	global_load_b128 v[190:193], v[143:144], off offset:496    // 0000000C538C: DC5E01F0 BE7C008F
	global_load_b128 v[186:189], v[143:144], off offset:480    // 0000000C5394: DC5E01E0 BA7C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000C539C: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[178:185], v[130:137]// 0000000C53A0: CC414082 1E0B65AA
	ds_load_b128 v[174:177], v153 offset:496                   // 0000000C53A8: DBFC01F0 AE000099
	ds_load_b128 v[170:173], v153 offset:480                   // 0000000C53B0: DBFC01E0 AA000099
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C53B8: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[186:193], v[170:177], v[130:137]// 0000000C53BC: CC414082 1E0B55BA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C53C4: BF870111
	v_dual_mul_f32 v130, 0x3d800000, v130 :: v_dual_mul_f32 v131, 0x3d800000, v131// 0000000C53C8: C8C704FF 828306FF 3D800000
	v_mul_f32_e32 v147, 0x3d800000, v133                       // 0000000C53D4: 11270AFF 3D800000
	v_mov_b32_e32 v133, 0xffff                                 // 0000000C53DC: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C53E4: BF870004
	v_mul_f32_e32 v132, 0x3d800000, v132                       // 0000000C53E8: 110908FF 3D800000
	v_dual_mul_f32 v134, 0x3d800000, v134 :: v_dual_mul_f32 v135, 0x3d800000, v135// 0000000C53F0: C8C70CFF 86870EFF 3D800000
	v_dual_mul_f32 v136, 0x3d800000, v136 :: v_dual_mul_f32 v137, 0x3d800000, v137// 0000000C53FC: C8C710FF 888912FF 3D800000
	ds_store_2addr_b32 v154, v130, v131 offset1:34             // 0000000C5408: D8382200 0083829A
	ds_store_2addr_b32 v154, v132, v147 offset0:68 offset1:102 // 0000000C5410: D8386644 0093849A
	ds_store_2addr_b32 v154, v134, v135 offset0:136 offset1:170// 0000000C5418: D838AA88 0087869A
	ds_store_2addr_b32 v154, v136, v137 offset0:204 offset1:238// 0000000C5420: D838EECC 0089889A
	s_waitcnt lgkmcnt(0)                                       // 0000000C5428: BF89FC07
	s_barrier                                                  // 0000000C542C: BFBD0000
	buffer_gl0_inv                                             // 0000000C5430: E0AC0000 00000000
	s_and_saveexec_b32 s8, s23                                 // 0000000C5438: BE882017
	s_cbranch_execz 356                                        // 0000000C543C: BFA50164 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16d0>
	s_lshl_b32 s9, s6, 2                                       // 0000000C5440: 84098206
	s_mov_b32 s13, exec_lo                                     // 0000000C5444: BE8D007E
	.long 0xd4c1007e                                           // 0000000C5448: D4C1007E
	v_cndmask_b32_e32 v1, v146, v152, vcc_lo                   // 0000000C544C: 02033192
	s_cbranch_execz 41                                         // 0000000C5450: BFA50029 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11f8>
	v_ashrrev_i32_e32 v147, 31, v146                           // 0000000C5454: 3527249F
	s_mov_b32 s15, 0                                           // 0000000C5458: BE8F0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C545C: BF870091
	.long 0xd73c0082                                           // 0000000C5460: D73C0082
	v_cndmask_b32_e32 v1, 2, v146, vcc_lo                      // 0000000C5464: 02032482
	.long 0xd7006a82                                           // 0000000C5468: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 0000000C546C: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5470: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 0000000C5474: D5207C83 01AB078E
	s_branch 8                                                 // 0000000C547C: BFA00008 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11a0>
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000C5480: 8C7E187E
	v_dual_mov_b32 v133, v146 :: v_dual_mov_b32 v146, v132     // 0000000C5484: CA100192 85920184
	s_and_b32 s1, exec_lo, s22                                 // 0000000C548C: 8B01167E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000C5490: BF870499
	s_or_b32 s15, s1, s15                                      // 0000000C5494: 8C0F0F01
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000000C5498: 917E0F7E
	s_cbranch_execz 20                                         // 0000000C549C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11f0>
	global_load_b32 v132, v[130:131], off                      // 0000000C54A0: DC520000 847C0082
	s_or_b32 s22, s22, exec_lo                                 // 0000000C54A8: 8C167E16
	s_waitcnt vmcnt(0)                                         // 0000000C54AC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s9, v132                          // 0000000C54B0: 7C890809
	s_and_saveexec_b32 s24, vcc_lo                             // 0000000C54B4: BE98206A
	s_cbranch_execz 65521                                      // 0000000C54B8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	v_add_nc_u32_e32 v132, 1, v146                             // 0000000C54BC: 4B092481
	.long 0xd7000182                                           // 0000000C54C0: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 0000000C54C4: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C54C8: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 0000000C54CC: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v152, v132                        // 0000000C54D4: 7C950998
	v_mov_b32_e32 v146, v152                                   // 0000000C54D8: 7F240398
	s_and_not1_b32 s1, s22, exec_lo                            // 0000000C54DC: 91017E16
	s_and_b32 s22, vcc_lo, exec_lo                             // 0000000C54E0: 8B167E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C54E4: BF870009
	s_or_b32 s22, s1, s22                                      // 0000000C54E8: 8C161601
	s_branch 65508                                             // 0000000C54EC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000000C54F0: 8C7E0F7E
	v_mov_b32_e32 v146, v133                                   // 0000000C54F4: 7F240385
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000C54F8: 8C7E0D7E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C54FC: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v146       // 0000000C5500: CA10008F 85820192
	s_mov_b32 s1, exec_lo                                      // 0000000C5508: BE81007E
	.long 0xd4c1007e                                           // 0000000C550C: D4C1007E
	v_cndmask_b32_e32 v1, s9, v155, vcc_lo                     // 0000000C5510: 02033609
	s_cbranch_execz 62                                         // 0000000C5514: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1310>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v146        // 0000000C5518: CA100080 85820192
	s_mov_b32 s13, exec_lo                                     // 0000000C5520: BE8D007E
	.long 0xd4c1007e                                           // 0000000C5524: D4C1007E
	v_cndmask_b32_e32 v1, v146, v152, vcc_lo                   // 0000000C5528: 02033192
	s_cbranch_execz 54                                         // 0000000C552C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1308>
	v_mov_b32_e32 v130, v146                                   // 0000000C5530: 7F040392
	s_mov_b32 s22, 0                                           // 0000000C5534: BE960080
	s_set_inst_prefetch_distance 0x1                           // 0000000C5538: BF840001
	s_branch 10                                                // 0000000C553C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1268>
	s_or_b32 exec_lo, exec_lo, s26                             // 0000000C5540: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000C5544: BF870499
	s_and_b32 s26, exec_lo, s25                                // 0000000C5548: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 0000000C554C: 8C16161A
	s_and_not1_b32 s15, s15, exec_lo                           // 0000000C5550: 910F7E0F
	s_and_b32 s26, s24, exec_lo                                // 0000000C5554: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5558: BF870009
	s_or_b32 s15, s15, s26                                     // 0000000C555C: 8C0F1A0F
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000000C5560: 917E167E
	s_cbranch_execz 28                                         // 0000000C5564: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000C5568: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 0000000C556C: 7F060382
	s_or_b32 s24, s24, exec_lo                                 // 0000000C5570: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 0000000C5574: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 0000000C5578: BE9A007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000C557C: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5580: BF870091
	.long 0xd73c0084                                           // 0000000C5584: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000C5588: 02030682
	.long 0xd7006a84                                           // 0000000C558C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 0000000C5590: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5594: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 0000000C5598: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 0000000C55A0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 0000000C55A8: BF8903F7
	.long 0xd4c4007e                                           // 0000000C55AC: D4C4007E
	v_cndmask_b32_e32 v1, s9, v132, vcc_lo                     // 0000000C55B0: 02030809
	s_cbranch_execz 65506                                      // 0000000C55B4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000C55B8: 4B050681
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000C55BC: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 0000000C55C0: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000C55C4: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v152, v130                        // 0000000C55C8: 7C950598
	s_and_b32 s27, vcc_lo, exec_lo                             // 0000000C55CC: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 0000000C55D0: 8C191B19
	s_branch 65498                                             // 0000000C55D4: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	s_set_inst_prefetch_distance 0x2                           // 0000000C55D8: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000C55DC: 8C7E167E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v152        // 0000000C55E0: CA100080 85820198
	s_and_saveexec_b32 s22, s15                                // 0000000C55E8: BE96200F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C55EC: BF870009
	s_xor_b32 s15, exec_lo, s22                                // 0000000C55F0: 8D0F167E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 0000000C55F4: 7C950809
	v_mov_b32_e32 v130, v131                                   // 0000000C55F8: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 0000000C55FC: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s15                             // 0000000C5604: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5608: BF870009
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000C560C: 8C7E0D7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5610: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5614: 8C7E017E
	s_or_b32 s13, s9, 1                                        // 0000000C5618: 8C0D8109
	s_mov_b32 s1, exec_lo                                      // 0000000C561C: BE81007E
	.long 0xd4c6007e                                           // 0000000C5620: D4C6007E
	v_cndmask_b32_e32 v1, s13, v155, vcc_lo                    // 0000000C5624: 0203360D
	s_xor_b32 s1, exec_lo, s1                                  // 0000000C5628: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 0000000C562C: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 0000000C5634: BE813001
	s_cbranch_execz 70                                         // 0000000C5638: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1454>
	s_mov_b32 s15, exec_lo                                     // 0000000C563C: BE8F007E
	.long 0xd4c1007e                                           // 0000000C5640: D4C1007E
	v_cndmask_b32_e32 v1, v130, v152, vcc_lo                   // 0000000C5644: 02033182
	s_cbranch_execz 64                                         // 0000000C5648: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x144c>
	s_mov_b32 s24, 0                                           // 0000000C564C: BE980080
	s_set_inst_prefetch_distance 0x1                           // 0000000C5650: BF840001
	s_branch 20                                                // 0000000C5654: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13a8>
	s_nop 0                                                    // 0000000C5658: BF800000
	s_nop 0                                                    // 0000000C565C: BF800000
	s_nop 0                                                    // 0000000C5660: BF800000
	s_nop 0                                                    // 0000000C5664: BF800000
	s_nop 0                                                    // 0000000C5668: BF800000
	s_nop 0                                                    // 0000000C566C: BF800000
	s_nop 0                                                    // 0000000C5670: BF800000
	s_nop 0                                                    // 0000000C5674: BF800000
	s_nop 0                                                    // 0000000C5678: BF800000
	s_nop 0                                                    // 0000000C567C: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 0000000C5680: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000C5684: BF870499
	s_and_b32 s27, exec_lo, s26                                // 0000000C5688: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 0000000C568C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 0000000C5690: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 0000000C5694: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5698: BF870009
	s_or_b32 s22, s22, s27                                     // 0000000C569C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 0000000C56A0: 917E187E
	s_cbranch_execz 27                                         // 0000000C56A4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1414>
	v_mov_b32_e32 v131, v130                                   // 0000000C56A8: 7F060382
	s_or_b32 s25, s25, exec_lo                                 // 0000000C56AC: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 0000000C56B0: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 0000000C56B4: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C56B8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000C56BC: 3509069F
	.long 0xd73c0086                                           // 0000000C56C0: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000C56C4: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C56C8: BF870091
	.long 0xd7006a86                                           // 0000000C56CC: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 0000000C56D0: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 0000000C56D4: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 0000000C56DC: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 0000000C56E4: BF8903F7
	.long 0xd4c6007e                                           // 0000000C56E8: D4C6007E
	v_cndmask_b32_e32 v1, s9, v132, vcc_lo                     // 0000000C56EC: 02030809
	s_cbranch_execz 65507                                      // 0000000C56F0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1380>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000C56F4: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000C56F8: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000C56FC: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000C5700: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v152, v130                        // 0000000C5704: 7C950598
	s_and_b32 s28, vcc_lo, exec_lo                             // 0000000C5708: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 0000000C570C: 8C1A1C1A
	s_branch 65499                                             // 0000000C5710: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1380>
	s_set_inst_prefetch_distance 0x2                           // 0000000C5714: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000C5718: 8C7E187E
	v_mov_b32_e32 v130, v152                                   // 0000000C571C: 7F040398
	s_and_saveexec_b32 s24, s22                                // 0000000C5720: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5724: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 0000000C5728: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s13, v132                         // 0000000C572C: 7C95080D
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 0000000C5730: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C573C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000C5740: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 0000000C5744: 7F040383
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000C5748: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C574C: BF870009
	s_or_b32 exec_lo, exec_lo, s15                             // 0000000C5750: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5754: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5758: 8C7E017E
	s_or_b32 s13, s9, 2                                        // 0000000C575C: 8C0D8209
	s_mov_b32 s1, exec_lo                                      // 0000000C5760: BE81007E
	.long 0xd4c6007e                                           // 0000000C5764: D4C6007E
	v_cndmask_b32_e32 v1, s13, v155, vcc_lo                    // 0000000C5768: 0203360D
	s_xor_b32 s1, exec_lo, s1                                  // 0000000C576C: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 0000000C5770: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 0000000C5778: BE813001
	s_cbranch_execz 69                                         // 0000000C577C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1594>
	s_mov_b32 s15, exec_lo                                     // 0000000C5780: BE8F007E
	.long 0xd4c1007e                                           // 0000000C5784: D4C1007E
	v_cndmask_b32_e32 v1, v130, v152, vcc_lo                   // 0000000C5788: 02033182
	s_cbranch_execz 63                                         // 0000000C578C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x158c>
	s_mov_b32 s24, 0                                           // 0000000C5790: BE980080
	s_set_inst_prefetch_distance 0x1                           // 0000000C5794: BF840001
	s_branch 19                                                // 0000000C5798: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14e8>
	s_nop 0                                                    // 0000000C579C: BF800000
	s_nop 0                                                    // 0000000C57A0: BF800000
	s_nop 0                                                    // 0000000C57A4: BF800000
	s_nop 0                                                    // 0000000C57A8: BF800000
	s_nop 0                                                    // 0000000C57AC: BF800000
	s_nop 0                                                    // 0000000C57B0: BF800000
	s_nop 0                                                    // 0000000C57B4: BF800000
	s_nop 0                                                    // 0000000C57B8: BF800000
	s_nop 0                                                    // 0000000C57BC: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 0000000C57C0: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000C57C4: BF870499
	s_and_b32 s27, exec_lo, s26                                // 0000000C57C8: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 0000000C57CC: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 0000000C57D0: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 0000000C57D4: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C57D8: BF870009
	s_or_b32 s22, s22, s27                                     // 0000000C57DC: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 0000000C57E0: 917E187E
	s_cbranch_execz 27                                         // 0000000C57E4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1554>
	v_mov_b32_e32 v131, v130                                   // 0000000C57E8: 7F060382
	s_or_b32 s25, s25, exec_lo                                 // 0000000C57EC: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 0000000C57F0: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 0000000C57F4: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C57F8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000C57FC: 3509069F
	.long 0xd73c0086                                           // 0000000C5800: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000C5804: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5808: BF870091
	.long 0xd7006a86                                           // 0000000C580C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 0000000C5810: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 0000000C5814: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 0000000C581C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 0000000C5824: BF8903F7
	.long 0xd4c4007e                                           // 0000000C5828: D4C4007E
	v_cndmask_b32_e32 v1, s13, v132, vcc_lo                    // 0000000C582C: 0203080D
	s_cbranch_execz 65507                                      // 0000000C5830: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000C5834: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000C5838: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000C583C: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000C5840: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v152, v130                        // 0000000C5844: 7C950598
	s_and_b32 s28, vcc_lo, exec_lo                             // 0000000C5848: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 0000000C584C: 8C1A1C1A
	s_branch 65499                                             // 0000000C5850: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000C5854: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000C5858: 8C7E187E
	v_mov_b32_e32 v130, v152                                   // 0000000C585C: 7F040398
	s_and_saveexec_b32 s24, s22                                // 0000000C5860: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5864: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 0000000C5868: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s13, v132                         // 0000000C586C: 7C95080D
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 0000000C5870: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C587C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000C5880: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 0000000C5884: 7F040383
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000C5888: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C588C: BF870009
	s_or_b32 exec_lo, exec_lo, s15                             // 0000000C5890: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5894: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5898: 8C7E017E
	s_or_b32 s9, s9, 3                                         // 0000000C589C: 8C098309
	s_mov_b32 s1, exec_lo                                      // 0000000C58A0: BE81007E
	.long 0xd4c6007e                                           // 0000000C58A4: D4C6007E
	v_cndmask_b32_e32 v1, s9, v155, vcc_lo                     // 0000000C58A8: 02033609
	s_xor_b32 s1, exec_lo, s1                                  // 0000000C58AC: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 0000000C58B0: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 0000000C58B8: BE813001
	s_cbranch_execz 66                                         // 0000000C58BC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c8>
	s_mov_b32 s13, exec_lo                                     // 0000000C58C0: BE8D007E
	.long 0xd4c1007e                                           // 0000000C58C4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v152, vcc_lo                   // 0000000C58C8: 02033182
	s_cbranch_execz 60                                         // 0000000C58CC: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c0>
	s_mov_b32 s22, 0                                           // 0000000C58D0: BE960080
	s_set_inst_prefetch_distance 0x1                           // 0000000C58D4: BF840001
	s_branch 19                                                // 0000000C58D8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1628>
	s_nop 0                                                    // 0000000C58DC: BF800000
	s_nop 0                                                    // 0000000C58E0: BF800000
	s_nop 0                                                    // 0000000C58E4: BF800000
	s_nop 0                                                    // 0000000C58E8: BF800000
	s_nop 0                                                    // 0000000C58EC: BF800000
	s_nop 0                                                    // 0000000C58F0: BF800000
	s_nop 0                                                    // 0000000C58F4: BF800000
	s_nop 0                                                    // 0000000C58F8: BF800000
	s_nop 0                                                    // 0000000C58FC: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 0000000C5900: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000C5904: BF870499
	s_and_b32 s26, exec_lo, s25                                // 0000000C5908: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 0000000C590C: 8C16161A
	s_and_not1_b32 s15, s15, exec_lo                           // 0000000C5910: 910F7E0F
	s_and_b32 s26, s24, exec_lo                                // 0000000C5914: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5918: BF870009
	s_or_b32 s15, s15, s26                                     // 0000000C591C: 8C0F1A0F
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000000C5920: 917E167E
	s_cbranch_execz 26                                         // 0000000C5924: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1690>
	v_ashrrev_i32_e32 v131, 31, v130                           // 0000000C5928: 3507049F
	s_or_b32 s24, s24, exec_lo                                 // 0000000C592C: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 0000000C5930: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 0000000C5934: BE9A007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5938: BF870091
	.long 0xd73c0083                                           // 0000000C593C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 0000000C5940: 02030482
	.long 0xd7006a83                                           // 0000000C5944: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 0000000C5948: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C594C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 0000000C5950: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 0000000C5958: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 0000000C5960: BF8903F7
	.long 0xd4c4007e                                           // 0000000C5964: D4C4007E
	v_cndmask_b32_e32 v1, s9, v131, vcc_lo                     // 0000000C5968: 02030609
	s_cbranch_execz 65508                                      // 0000000C596C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1600>
	v_add_nc_u32_e32 v130, 1, v130                             // 0000000C5970: 4B050481
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000C5974: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 0000000C5978: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000C597C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v152, v130                        // 0000000C5980: 7C950598
	s_and_b32 s27, vcc_lo, exec_lo                             // 0000000C5984: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 0000000C5988: 8C191B19
	s_branch 65500                                             // 0000000C598C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1600>
	s_set_inst_prefetch_distance 0x2                           // 0000000C5990: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000C5994: 8C7E167E
	s_and_saveexec_b32 s22, s15                                // 0000000C5998: BE96200F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C599C: BF870009
	s_xor_b32 s15, exec_lo, s22                                // 0000000C59A0: 8D0F167E
	v_cmp_eq_u32_e32 vcc_lo, s9, v131                          // 0000000C59A4: 7C950609
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 0000000C59A8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C59B4: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000C59B8: 390B0B82
	s_or_b32 exec_lo, exec_lo, s15                             // 0000000C59BC: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C59C0: BF870009
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000C59C4: 8C7E0D7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C59C8: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C59CC: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C59D0: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C59D4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C59D8: BE882003
	s_cbranch_execz 64572                                      // 0000000C59DC: BFA5FC3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7d0>
	ds_load_b32 v131, v157                                     // 0000000C59E0: D8D80000 8300009D
	v_and_b32_e32 v130, 1, v133                                // 0000000C59E8: 37050A81
	v_cmp_le_i32_e32 vcc_lo, s7, v156                          // 0000000C59EC: 7C873807
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C59F0: BF870002
	.long 0xd44a0001                                           // 0000000C59F4: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000C59F8: 02030481
	s_and_b32 s35, vcc_lo, s1                                  // 0000000C59FC: 8B23016A
	s_waitcnt lgkmcnt(0)                                       // 0000000C5A00: BF89FC07
	v_mov_b32_e32 v130, v131                                   // 0000000C5A04: 7F040383
	s_and_saveexec_b32 s1, s35                                 // 0000000C5A08: BE812023
	s_cbranch_execz 7                                          // 0000000C5A0C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x172c>
	ds_load_b32 v130, v158                                     // 0000000C5A10: D8D80000 8200009E
	v_max_f32_e32 v132, v131, v131                             // 0000000C5A18: 21090783
	s_waitcnt lgkmcnt(0)                                       // 0000000C5A1C: BF89FC07
	v_max_f32_e32 v130, v130, v130                             // 0000000C5A20: 21050582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5A24: BF870001
	v_max_f32_e32 v130, v132, v130                             // 0000000C5A28: 21050584
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5A2C: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 0000000C5A30: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s7, v156                          // 0000000C5A34: 7C833807
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000C5A38: BF8704A2
	.long 0xd44d0001                                           // 0000000C5A3C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5A40: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 0000000C5A44: 8B22016A
	s_and_saveexec_b32 s1, s34                                 // 0000000C5A48: BE812022
	s_cbranch_execz 7                                          // 0000000C5A4C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x176c>
	ds_load_b32 v132, v158 offset:4                            // 0000000C5A50: D8D80004 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5A58: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5A5C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5A60: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5A64: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5A68: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5A6C: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 0000000C5A70: 37090A84
	s_or_b32 s1, s7, 2                                         // 0000000C5A74: 8C018207
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5A78: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v156                          // 0000000C5A7C: 7C873801
	.long 0xd44d0001                                           // 0000000C5A80: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5A84: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 0000000C5A88: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5A8C: BF870009
	s_and_saveexec_b32 s1, s33                                 // 0000000C5A90: BE812021
	s_cbranch_execz 7                                          // 0000000C5A94: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17b4>
	ds_load_b32 v132, v158 offset:8                            // 0000000C5A98: D8D80008 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5AA0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5AA4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5AA8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5AAC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5AB0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5AB4: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 0000000C5AB8: 37090A88
	s_or_b32 s1, s7, 3                                         // 0000000C5ABC: 8C018307
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5AC0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v156                          // 0000000C5AC4: 7C873801
	.long 0xd44d0001                                           // 0000000C5AC8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5ACC: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 0000000C5AD0: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5AD4: BF870009
	s_and_saveexec_b32 s1, s31                                 // 0000000C5AD8: BE81201F
	s_cbranch_execz 7                                          // 0000000C5ADC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17fc>
	ds_load_b32 v132, v158 offset:12                           // 0000000C5AE0: D8D8000C 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5AE8: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5AEC: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5AF0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5AF4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5AF8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5AFC: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 0000000C5B00: 37090A90
	s_or_b32 s1, s7, 4                                         // 0000000C5B04: 8C018407
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5B08: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v156                          // 0000000C5B0C: 7C873801
	.long 0xd44d0001                                           // 0000000C5B10: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5B14: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 0000000C5B18: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5B1C: BF870009
	s_and_saveexec_b32 s1, s30                                 // 0000000C5B20: BE81201E
	s_cbranch_execz 7                                          // 0000000C5B24: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1844>
	ds_load_b32 v132, v158 offset:16                           // 0000000C5B28: D8D80010 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5B30: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5B34: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5B38: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5B3C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5B40: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5B44: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 0000000C5B48: 37090AA0
	s_or_b32 s1, s7, 5                                         // 0000000C5B4C: 8C018507
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5B50: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v156                          // 0000000C5B54: 7C873801
	.long 0xd44d0001                                           // 0000000C5B58: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5B5C: 02030880
	s_and_b32 s29, vcc_lo, s1                                  // 0000000C5B60: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5B64: BF870009
	s_and_saveexec_b32 s1, s29                                 // 0000000C5B68: BE81201D
	s_cbranch_execz 7                                          // 0000000C5B6C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x188c>
	ds_load_b32 v132, v158 offset:20                           // 0000000C5B70: D8D80014 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5B78: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5B7C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5B80: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5B84: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5B88: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5B8C: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 0000000C5B90: 37090AC0
	s_or_b32 s1, s7, 6                                         // 0000000C5B94: 8C018607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5B98: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v156                          // 0000000C5B9C: 7C873801
	.long 0xd44d0001                                           // 0000000C5BA0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5BA4: 02030880
	s_and_b32 s28, vcc_lo, s1                                  // 0000000C5BA8: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5BAC: BF870009
	s_and_saveexec_b32 s1, s28                                 // 0000000C5BB0: BE81201C
	s_cbranch_execz 7                                          // 0000000C5BB4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18d4>
	ds_load_b32 v132, v158 offset:24                           // 0000000C5BB8: D8D80018 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5BC0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5BC4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5BC8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5BCC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5BD0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5BD4: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 0000000C5BD8: 37090AFF 00000080
	s_or_b32 s1, s7, 7                                         // 0000000C5BE0: 8C018707
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5BE4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v156                          // 0000000C5BE8: 7C873801
	.long 0xd44d0001                                           // 0000000C5BEC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5BF0: 02030880
	s_and_b32 s27, vcc_lo, s1                                  // 0000000C5BF4: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5BF8: BF870009
	s_and_saveexec_b32 s1, s27                                 // 0000000C5BFC: BE81201B
	s_cbranch_execz 7                                          // 0000000C5C00: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1920>
	ds_load_b32 v132, v158 offset:28                           // 0000000C5C04: D8D8001C 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5C0C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5C10: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5C14: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5C18: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5C1C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5C20: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 0000000C5C24: 37090AFF 00000100
	s_or_b32 s1, s7, 8                                         // 0000000C5C2C: 8C018807
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5C30: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v156                          // 0000000C5C34: 7C873801
	.long 0xd44d0001                                           // 0000000C5C38: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5C3C: 02030880
	s_and_b32 s26, vcc_lo, s1                                  // 0000000C5C40: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5C44: BF870009
	s_and_saveexec_b32 s1, s26                                 // 0000000C5C48: BE81201A
	s_cbranch_execz 7                                          // 0000000C5C4C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x196c>
	ds_load_b32 v132, v158 offset:32                           // 0000000C5C50: D8D80020 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5C58: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5C5C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5C60: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5C64: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5C68: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5C6C: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 0000000C5C70: 37090AFF 00000200
	s_or_b32 s1, s7, 9                                         // 0000000C5C78: 8C018907
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5C7C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v156                          // 0000000C5C80: 7C873801
	.long 0xd44d0001                                           // 0000000C5C84: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5C88: 02030880
	s_and_b32 s25, vcc_lo, s1                                  // 0000000C5C8C: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5C90: BF870009
	s_and_saveexec_b32 s1, s25                                 // 0000000C5C94: BE812019
	s_cbranch_execz 7                                          // 0000000C5C98: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19b8>
	ds_load_b32 v132, v158 offset:36                           // 0000000C5C9C: D8D80024 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5CA4: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5CA8: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5CAC: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5CB0: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5CB4: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5CB8: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 0000000C5CBC: 37090AFF 00000400
	s_or_b32 s1, s7, 10                                        // 0000000C5CC4: 8C018A07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5CC8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v156                          // 0000000C5CCC: 7C873801
	.long 0xd44d0001                                           // 0000000C5CD0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5CD4: 02030880
	s_and_b32 s24, vcc_lo, s1                                  // 0000000C5CD8: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5CDC: BF870009
	s_and_saveexec_b32 s1, s24                                 // 0000000C5CE0: BE812018
	s_cbranch_execz 7                                          // 0000000C5CE4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a04>
	ds_load_b32 v132, v158 offset:40                           // 0000000C5CE8: D8D80028 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5CF0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5CF4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5CF8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5CFC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5D00: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5D04: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 0000000C5D08: 37090AFF 00000800
	s_or_b32 s1, s7, 11                                        // 0000000C5D10: 8C018B07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5D14: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v156                          // 0000000C5D18: 7C873801
	.long 0xd44d0001                                           // 0000000C5D1C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5D20: 02030880
	s_and_b32 s22, vcc_lo, s1                                  // 0000000C5D24: 8B16016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5D28: BF870009
	s_and_saveexec_b32 s1, s22                                 // 0000000C5D2C: BE812016
	s_cbranch_execz 7                                          // 0000000C5D30: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a50>
	ds_load_b32 v132, v158 offset:44                           // 0000000C5D34: D8D8002C 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5D3C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5D40: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5D44: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5D48: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5D4C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5D50: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 0000000C5D54: 37090AFF 00001000
	s_or_b32 s1, s7, 12                                        // 0000000C5D5C: 8C018C07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5D60: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v156                          // 0000000C5D64: 7C873801
	.long 0xd44d0001                                           // 0000000C5D68: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5D6C: 02030880
	s_and_b32 s15, vcc_lo, s1                                  // 0000000C5D70: 8B0F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5D74: BF870009
	s_and_saveexec_b32 s1, s15                                 // 0000000C5D78: BE81200F
	s_cbranch_execz 7                                          // 0000000C5D7C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a9c>
	ds_load_b32 v132, v158 offset:48                           // 0000000C5D80: D8D80030 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5D88: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5D8C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5D90: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5D94: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5D98: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5D9C: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 0000000C5DA0: 37090AFF 00002000
	s_or_b32 s1, s7, 13                                        // 0000000C5DA8: 8C018D07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5DAC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v156                          // 0000000C5DB0: 7C873801
	.long 0xd44d0001                                           // 0000000C5DB4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5DB8: 02030880
	s_and_b32 s13, vcc_lo, s1                                  // 0000000C5DBC: 8B0D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5DC0: BF870009
	s_and_saveexec_b32 s1, s13                                 // 0000000C5DC4: BE81200D
	s_cbranch_execz 7                                          // 0000000C5DC8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ae8>
	ds_load_b32 v132, v158 offset:52                           // 0000000C5DCC: D8D80034 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5DD4: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5DD8: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5DDC: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5DE0: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5DE4: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5DE8: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 0000000C5DEC: 37090AFF 00004000
	s_or_b32 s1, s7, 14                                        // 0000000C5DF4: 8C018E07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5DF8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v156                          // 0000000C5DFC: 7C873801
	.long 0xd44d0001                                           // 0000000C5E00: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5E04: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 0000000C5E08: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5E0C: BF870009
	s_and_saveexec_b32 s1, s9                                  // 0000000C5E10: BE812009
	s_cbranch_execz 7                                          // 0000000C5E14: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b34>
	ds_load_b32 v132, v158 offset:56                           // 0000000C5E18: D8D80038 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5E20: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5E24: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5E28: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5E2C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5E30: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C5E34: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 0000000C5E38: 37090AFF 00008000
	s_or_b32 s7, s7, 15                                        // 0000000C5E40: 8C078F07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5E44: BF870119
	v_cmp_le_i32_e32 vcc_lo, s7, v156                          // 0000000C5E48: 7C873807
	.long 0xd44d0001                                           // 0000000C5E4C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000C5E50: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 0000000C5E54: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C5E58: BF870009
	s_and_saveexec_b32 s7, s1                                  // 0000000C5E5C: BE872001
	s_cbranch_execz 7                                          // 0000000C5E60: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b80>
	ds_load_b32 v132, v158 offset:60                           // 0000000C5E64: D8D8003C 8400009E
	v_max_f32_e32 v130, v130, v130                             // 0000000C5E6C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000C5E70: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000C5E74: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5E78: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000C5E7C: 21050982
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C5E80: 8C7E077E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 0000000C5E84: CA100080 84840080
	s_and_saveexec_b32 s7, s35                                 // 0000000C5E8C: BE872023
	s_cbranch_execz 30                                         // 0000000C5E90: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c0c>
	ds_load_b32 v133, v158                                     // 0000000C5E94: D8D80000 8500009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C5E9C: BF89FC07
	v_sub_f32_e32 v133, v133, v130                             // 0000000C5EA0: 090B0585
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5EA4: BF870091
	v_mul_f32_e32 v134, 0x3fb8aa3b, v133                       // 0000000C5EA8: 110D0AFF 3FB8AA3B
	v_fma_f32 v135, 0x3fb8aa3b, v133, -v134                    // 0000000C5EB0: D6130087 861B0AFF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 0000000C5EBC: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C5EC0: BF870221
	v_sub_f32_e32 v134, v134, v136                             // 0000000C5EC4: 090D1186
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 0000000C5EC8: 7C370AFF C2CE8ED0
	v_fmac_f32_e32 v135, 0x32a5705f, v133                      // 0000000C5ED0: 570F0AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C5ED8: BF870121
	v_add_f32_e32 v134, v134, v135                             // 0000000C5EDC: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 0000000C5EE0: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 0000000C5EE4: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5EE8: BF870095
	.long 0xd71c0086                                           // 0000000C5EEC: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 0000000C5EF0: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000000C5EF4: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 0000000C5EF8: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C5F00: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v134, vcc_lo           // 0000000C5F04: 030B0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C5F0C: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5F10: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 0000000C5F14: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 0000000C5F1C: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v159, v134                             // 0000000C5F28: DA840000 0000869F
	s_and_saveexec_b32 s7, s34                                 // 0000000C5F30: BE872022
	s_cbranch_execz 30                                         // 0000000C5F34: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1cb0>
	ds_load_b32 v132, v158 offset:4                            // 0000000C5F38: D8D80004 8400009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C5F40: BF89FC07
	v_sub_f32_e32 v132, v132, v130                             // 0000000C5F44: 09090584
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C5F48: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v132                       // 0000000C5F4C: 110D08FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v132                 // 0000000C5F54: 7C3708FF C2CE8ED0
	v_fma_f32 v135, 0x3fb8aa3b, v132, -v134                    // 0000000C5F5C: D6130087 861B08FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 0000000C5F68: 7F104786
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C5F6C: BF870112
	v_fmac_f32_e32 v135, 0x32a5705f, v132                      // 0000000C5F70: 570F08FF 32A5705F
	v_sub_f32_e32 v134, v134, v136                             // 0000000C5F78: 090D1186
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C5F7C: BF870121
	v_add_f32_e32 v134, v134, v135                             // 0000000C5F80: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 0000000C5F84: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 0000000C5F88: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5F8C: BF870095
	.long 0xd71c0086                                           // 0000000C5F90: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 0000000C5F94: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000000C5F98: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v132                 // 0000000C5F9C: 7C3D08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C5FA4: BF870002
	v_cndmask_b32_e32 v132, 0x7f800000, v134, vcc_lo           // 0000000C5FA8: 03090CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C5FB0: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C5FB4: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 0000000C5FB8: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 0000000C5FC0: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 0000000C5FC4: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 0000000C5FD0: 7F0C0280
	ds_store_b16_d16_hi v159, v136 offset:2                    // 0000000C5FD4: DA840002 0000889F
	s_and_saveexec_b32 s7, s33                                 // 0000000C5FDC: BE872021
	s_cbranch_execz 30                                         // 0000000C5FE0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d5c>
	ds_load_b32 v135, v158 offset:8                            // 0000000C5FE4: D8D80008 8700009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C5FEC: BF89FC07
	v_sub_f32_e32 v135, v135, v130                             // 0000000C5FF0: 090F0587
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5FF4: BF870091
	v_mul_f32_e32 v136, 0x3fb8aa3b, v135                       // 0000000C5FF8: 11110EFF 3FB8AA3B
	v_fma_f32 v137, 0x3fb8aa3b, v135, -v136                    // 0000000C6000: D6130089 86230EFF 3FB8AA3B
	v_rndne_f32_e32 v147, v136                                 // 0000000C600C: 7F264788
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C6010: BF870221
	v_sub_f32_e32 v136, v136, v147                             // 0000000C6014: 09112788
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 0000000C6018: 7C370EFF C2CE8ED0
	v_fmac_f32_e32 v137, 0x32a5705f, v135                      // 0000000C6020: 57130EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6028: BF870121
	v_add_f32_e32 v136, v136, v137                             // 0000000C602C: 07111388
	v_cvt_i32_f32_e32 v137, v147                               // 0000000C6030: 7F121193
	v_exp_f32_e32 v136, v136                                   // 0000000C6034: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6038: BF870095
	.long 0xd71c0088                                           // 0000000C603C: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 0000000C6040: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000000C6044: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 0000000C6048: 7C3D0EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C6050: BF870002
	v_cndmask_b32_e32 v135, 0x7f800000, v136, vcc_lo           // 0000000C6054: 030F10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C605C: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6060: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 0000000C6064: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 0000000C606C: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v159, v136 offset:4                    // 0000000C6078: DA840004 0000889F
	s_and_saveexec_b32 s7, s31                                 // 0000000C6080: BE87201F
	s_cbranch_execz 29                                         // 0000000C6084: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1dfc>
	ds_load_b32 v134, v158 offset:12                           // 0000000C6088: D8D8000C 8600009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C6090: BF89FC07
	v_sub_f32_e32 v134, v134, v130                             // 0000000C6094: 090D0586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6098: BF870121
	v_mul_f32_e32 v136, 0x3fb8aa3b, v134                       // 0000000C609C: 11110CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 0000000C60A4: 7C370CFF C2CE8ED0
	v_fma_f32 v137, 0x3fb8aa3b, v134, -v136                    // 0000000C60AC: D6130089 86230CFF 3FB8AA3B
	v_rndne_f32_e32 v147, v136                                 // 0000000C60B8: 7F264788
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C60BC: BF870091
	v_dual_fmac_f32 v137, 0x32a5705f, v134 :: v_dual_sub_f32 v136, v136, v147// 0000000C60C0: C80B0CFF 89892788 32A5705F
	v_add_f32_e32 v136, v136, v137                             // 0000000C60CC: 07111388
	v_cvt_i32_f32_e32 v137, v147                               // 0000000C60D0: 7F121193
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C60D4: BF870292
	v_exp_f32_e32 v136, v136                                   // 0000000C60D8: 7F104B88
	.long 0xd71c0088                                           // 0000000C60DC: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 0000000C60E0: 02031388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C60E4: BF870121
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000000C60E8: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 0000000C60EC: 7C3D0CFF 42B17218
	v_cndmask_b32_e32 v134, 0x7f800000, v136, vcc_lo           // 0000000C60F4: 030D10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C60FC: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6100: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 0000000C6104: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 0000000C610C: 7F120280
	v_add3_u32 v147, v134, v136, 0x7fff                        // 0000000C6110: D6550093 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 0000000C611C: 7F100280
	ds_store_b16_d16_hi v159, v147 offset:6                    // 0000000C6120: DA840006 0000939F
	s_and_saveexec_b32 s7, s30                                 // 0000000C6128: BE87201E
	s_cbranch_execz 29                                         // 0000000C612C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ea4>
	ds_load_b32 v137, v158 offset:16                           // 0000000C6130: D8D80010 8900009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C6138: BF89FC07
	v_sub_f32_e32 v137, v137, v130                             // 0000000C613C: 09130589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6140: BF870121
	v_mul_f32_e32 v147, 0x3fb8aa3b, v137                       // 0000000C6144: 112712FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v137                 // 0000000C614C: 7C3712FF C2CE8ED0
	v_fma_f32 v170, 0x3fb8aa3b, v137, -v147                    // 0000000C6154: D61300AA 864F12FF 3FB8AA3B
	v_rndne_f32_e32 v171, v147                                 // 0000000C6160: 7F564793
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6164: BF870091
	v_dual_fmac_f32 v170, 0x32a5705f, v137 :: v_dual_sub_f32 v147, v147, v171// 0000000C6168: C80B12FF AA935793 32A5705F
	v_add_f32_e32 v147, v147, v170                             // 0000000C6174: 07275593
	v_cvt_i32_f32_e32 v170, v171                               // 0000000C6178: 7F5411AB
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C617C: BF870292
	v_exp_f32_e32 v147, v147                                   // 0000000C6180: 7F264B93
	.long 0xd71c0093                                           // 0000000C6184: D71C0093
	v_cndmask_b32_e32 v1, v147, v170, vcc_lo                   // 0000000C6188: 02035593
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C618C: BF870121
	v_cndmask_b32_e32 v147, 0, v147, vcc_lo                    // 0000000C6190: 03272680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v137                 // 0000000C6194: 7C3D12FF 42B17218
	v_cndmask_b32_e32 v137, 0x7f800000, v147, vcc_lo           // 0000000C619C: 031326FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C61A4: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C61A8: BF870091
	v_bfe_u32 v147, v137, 16, 1                                // 0000000C61AC: D6100093 02052189
	v_add3_u32 v147, v137, v147, 0x7fff                        // 0000000C61B4: D6550093 03FF2789 00007FFF
	ds_store_b16_d16_hi v159, v147 offset:8                    // 0000000C61C0: DA840008 0000939F
	s_and_saveexec_b32 s7, s29                                 // 0000000C61C8: BE87201D
	s_cbranch_execz 30                                         // 0000000C61CC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f48>
	ds_load_b32 v136, v158 offset:20                           // 0000000C61D0: D8D80014 8800009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C61D8: BF89FC07
	v_sub_f32_e32 v136, v136, v130                             // 0000000C61DC: 09110588
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C61E0: BF870091
	v_mul_f32_e32 v147, 0x3fb8aa3b, v136                       // 0000000C61E4: 112710FF 3FB8AA3B
	v_fma_f32 v170, 0x3fb8aa3b, v136, -v147                    // 0000000C61EC: D61300AA 864F10FF 3FB8AA3B
	v_rndne_f32_e32 v171, v147                                 // 0000000C61F8: 7F564793
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C61FC: BF870221
	v_sub_f32_e32 v147, v147, v171                             // 0000000C6200: 09275793
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 0000000C6204: 7C3710FF C2CE8ED0
	v_fmac_f32_e32 v170, 0x32a5705f, v136                      // 0000000C620C: 575510FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6214: BF870121
	v_add_f32_e32 v147, v147, v170                             // 0000000C6218: 07275593
	v_cvt_i32_f32_e32 v170, v171                               // 0000000C621C: 7F5411AB
	v_exp_f32_e32 v147, v147                                   // 0000000C6220: 7F264B93
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6224: BF870095
	.long 0xd71c0093                                           // 0000000C6228: D71C0093
	v_cndmask_b32_e32 v1, v147, v170, vcc_lo                   // 0000000C622C: 02035593
	v_cndmask_b32_e32 v147, 0, v147, vcc_lo                    // 0000000C6230: 03272680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 0000000C6234: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C623C: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v147, vcc_lo           // 0000000C6240: 031126FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C6248: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C624C: BF870121
	v_bfe_u32 v147, v136, 16, 1                                // 0000000C6250: D6100093 02052188
	v_mov_b32_e32 v170, 0                                      // 0000000C6258: 7F540280
	v_add3_u32 v171, v136, v147, 0x7fff                        // 0000000C625C: D65500AB 03FF2788 00007FFF
	v_mov_b32_e32 v147, 0                                      // 0000000C6268: 7F260280
	ds_store_b16_d16_hi v159, v171 offset:10                   // 0000000C626C: DA84000A 0000AB9F
	s_and_saveexec_b32 s7, s28                                 // 0000000C6274: BE87201C
	s_cbranch_execz 30                                         // 0000000C6278: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ff4>
	ds_load_b32 v170, v158 offset:24                           // 0000000C627C: D8D80018 AA00009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C6284: BF89FC07
	v_sub_f32_e32 v170, v170, v130                             // 0000000C6288: 095505AA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C628C: BF870091
	v_mul_f32_e32 v171, 0x3fb8aa3b, v170                       // 0000000C6290: 115754FF 3FB8AA3B
	v_fma_f32 v172, 0x3fb8aa3b, v170, -v171                    // 0000000C6298: D61300AC 86AF54FF 3FB8AA3B
	v_rndne_f32_e32 v173, v171                                 // 0000000C62A4: 7F5A47AB
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C62A8: BF870221
	v_sub_f32_e32 v171, v171, v173                             // 0000000C62AC: 09575BAB
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v170                 // 0000000C62B0: 7C3754FF C2CE8ED0
	v_fmac_f32_e32 v172, 0x32a5705f, v170                      // 0000000C62B8: 575954FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C62C0: BF870121
	v_add_f32_e32 v171, v171, v172                             // 0000000C62C4: 075759AB
	v_cvt_i32_f32_e32 v172, v173                               // 0000000C62C8: 7F5811AD
	v_exp_f32_e32 v171, v171                                   // 0000000C62CC: 7F564BAB
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C62D0: BF870095
	.long 0xd71c00ab                                           // 0000000C62D4: D71C00AB
	v_cndmask_b32_e32 v1, v171, v172, vcc_lo                   // 0000000C62D8: 020359AB
	v_cndmask_b32_e32 v171, 0, v171, vcc_lo                    // 0000000C62DC: 03575680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v170                 // 0000000C62E0: 7C3D54FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C62E8: BF870002
	v_cndmask_b32_e32 v170, 0x7f800000, v171, vcc_lo           // 0000000C62EC: 035556FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C62F4: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C62F8: BF870091
	v_bfe_u32 v171, v170, 16, 1                                // 0000000C62FC: D61000AB 020521AA
	v_add3_u32 v171, v170, v171, 0x7fff                        // 0000000C6304: D65500AB 03FF57AA 00007FFF
	ds_store_b16_d16_hi v159, v171 offset:12                   // 0000000C6310: DA84000C 0000AB9F
	s_and_saveexec_b32 s7, s27                                 // 0000000C6318: BE87201B
	s_cbranch_execz 29                                         // 0000000C631C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2094>
	ds_load_b32 v147, v158 offset:28                           // 0000000C6320: D8D8001C 9300009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C6328: BF89FC07
	v_sub_f32_e32 v147, v147, v130                             // 0000000C632C: 09270593
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6330: BF870121
	v_mul_f32_e32 v171, 0x3fb8aa3b, v147                       // 0000000C6334: 115726FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 0000000C633C: 7C3726FF C2CE8ED0
	v_fma_f32 v172, 0x3fb8aa3b, v147, -v171                    // 0000000C6344: D61300AC 86AF26FF 3FB8AA3B
	v_rndne_f32_e32 v173, v171                                 // 0000000C6350: 7F5A47AB
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6354: BF870091
	v_dual_fmac_f32 v172, 0x32a5705f, v147 :: v_dual_sub_f32 v171, v171, v173// 0000000C6358: C80B26FF ACAB5BAB 32A5705F
	v_add_f32_e32 v171, v171, v172                             // 0000000C6364: 075759AB
	v_cvt_i32_f32_e32 v172, v173                               // 0000000C6368: 7F5811AD
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C636C: BF870292
	v_exp_f32_e32 v171, v171                                   // 0000000C6370: 7F564BAB
	.long 0xd71c00ab                                           // 0000000C6374: D71C00AB
	v_cndmask_b32_e32 v1, v171, v172, vcc_lo                   // 0000000C6378: 020359AB
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C637C: BF870121
	v_cndmask_b32_e32 v171, 0, v171, vcc_lo                    // 0000000C6380: 03575680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 0000000C6384: 7C3D26FF 42B17218
	v_cndmask_b32_e32 v147, 0x7f800000, v171, vcc_lo           // 0000000C638C: 032756FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C6394: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6398: BF870121
	v_bfe_u32 v171, v147, 16, 1                                // 0000000C639C: D61000AB 02052193
	v_mov_b32_e32 v172, 0                                      // 0000000C63A4: 7F580280
	v_add3_u32 v173, v147, v171, 0x7fff                        // 0000000C63A8: D65500AD 03FF5793 00007FFF
	v_mov_b32_e32 v171, 0                                      // 0000000C63B4: 7F560280
	ds_store_b16_d16_hi v159, v173 offset:14                   // 0000000C63B8: DA84000E 0000AD9F
	s_and_saveexec_b32 s7, s26                                 // 0000000C63C0: BE87201A
	s_cbranch_execz 30                                         // 0000000C63C4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2140>
	ds_load_b32 v172, v158 offset:32                           // 0000000C63C8: D8D80020 AC00009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C63D0: BF89FC07
	v_sub_f32_e32 v172, v172, v130                             // 0000000C63D4: 095905AC
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C63D8: BF870091
	v_mul_f32_e32 v173, 0x3fb8aa3b, v172                       // 0000000C63DC: 115B58FF 3FB8AA3B
	v_fma_f32 v174, 0x3fb8aa3b, v172, -v173                    // 0000000C63E4: D61300AE 86B758FF 3FB8AA3B
	v_rndne_f32_e32 v175, v173                                 // 0000000C63F0: 7F5E47AD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C63F4: BF870221
	v_sub_f32_e32 v173, v173, v175                             // 0000000C63F8: 095B5FAD
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v172                 // 0000000C63FC: 7C3758FF C2CE8ED0
	v_fmac_f32_e32 v174, 0x32a5705f, v172                      // 0000000C6404: 575D58FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C640C: BF870121
	v_add_f32_e32 v173, v173, v174                             // 0000000C6410: 075B5DAD
	v_cvt_i32_f32_e32 v174, v175                               // 0000000C6414: 7F5C11AF
	v_exp_f32_e32 v173, v173                                   // 0000000C6418: 7F5A4BAD
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C641C: BF870095
	.long 0xd71c00ad                                           // 0000000C6420: D71C00AD
	v_cndmask_b32_e32 v1, v173, v174, vcc_lo                   // 0000000C6424: 02035DAD
	v_cndmask_b32_e32 v173, 0, v173, vcc_lo                    // 0000000C6428: 035B5A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v172                 // 0000000C642C: 7C3D58FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C6434: BF870002
	v_cndmask_b32_e32 v172, 0x7f800000, v173, vcc_lo           // 0000000C6438: 03595AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C6440: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6444: BF870091
	v_bfe_u32 v173, v172, 16, 1                                // 0000000C6448: D61000AD 020521AC
	v_add3_u32 v173, v172, v173, 0x7fff                        // 0000000C6450: D65500AD 03FF5BAC 00007FFF
	ds_store_b16_d16_hi v159, v173 offset:16                   // 0000000C645C: DA840010 0000AD9F
	s_and_saveexec_b32 s7, s25                                 // 0000000C6464: BE872019
	s_cbranch_execz 30                                         // 0000000C6468: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21e4>
	ds_load_b32 v171, v158 offset:36                           // 0000000C646C: D8D80024 AB00009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C6474: BF89FC07
	v_sub_f32_e32 v171, v171, v130                             // 0000000C6478: 095705AB
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C647C: BF870121
	v_mul_f32_e32 v173, 0x3fb8aa3b, v171                       // 0000000C6480: 115B56FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v171                 // 0000000C6488: 7C3756FF C2CE8ED0
	v_fma_f32 v174, 0x3fb8aa3b, v171, -v173                    // 0000000C6490: D61300AE 86B756FF 3FB8AA3B
	v_rndne_f32_e32 v175, v173                                 // 0000000C649C: 7F5E47AD
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C64A0: BF870112
	v_fmac_f32_e32 v174, 0x32a5705f, v171                      // 0000000C64A4: 575D56FF 32A5705F
	v_sub_f32_e32 v173, v173, v175                             // 0000000C64AC: 095B5FAD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C64B0: BF870121
	v_add_f32_e32 v173, v173, v174                             // 0000000C64B4: 075B5DAD
	v_cvt_i32_f32_e32 v174, v175                               // 0000000C64B8: 7F5C11AF
	v_exp_f32_e32 v173, v173                                   // 0000000C64BC: 7F5A4BAD
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C64C0: BF870095
	.long 0xd71c00ad                                           // 0000000C64C4: D71C00AD
	v_cndmask_b32_e32 v1, v173, v174, vcc_lo                   // 0000000C64C8: 02035DAD
	v_cndmask_b32_e32 v173, 0, v173, vcc_lo                    // 0000000C64CC: 035B5A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v171                 // 0000000C64D0: 7C3D56FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C64D8: BF870002
	v_cndmask_b32_e32 v171, 0x7f800000, v173, vcc_lo           // 0000000C64DC: 03575AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C64E4: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C64E8: BF870121
	v_bfe_u32 v173, v171, 16, 1                                // 0000000C64EC: D61000AD 020521AB
	v_mov_b32_e32 v174, 0                                      // 0000000C64F4: 7F5C0280
	v_add3_u32 v175, v171, v173, 0x7fff                        // 0000000C64F8: D65500AF 03FF5BAB 00007FFF
	v_mov_b32_e32 v173, 0                                      // 0000000C6504: 7F5A0280
	ds_store_b16_d16_hi v159, v175 offset:18                   // 0000000C6508: DA840012 0000AF9F
	s_and_saveexec_b32 s7, s24                                 // 0000000C6510: BE872018
	s_cbranch_execz 30                                         // 0000000C6514: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2290>
	ds_load_b32 v174, v158 offset:40                           // 0000000C6518: D8D80028 AE00009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C6520: BF89FC07
	v_sub_f32_e32 v174, v174, v130                             // 0000000C6524: 095D05AE
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6528: BF870091
	v_mul_f32_e32 v175, 0x3fb8aa3b, v174                       // 0000000C652C: 115F5CFF 3FB8AA3B
	v_fma_f32 v176, 0x3fb8aa3b, v174, -v175                    // 0000000C6534: D61300B0 86BF5CFF 3FB8AA3B
	v_rndne_f32_e32 v177, v175                                 // 0000000C6540: 7F6247AF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C6544: BF870221
	v_sub_f32_e32 v175, v175, v177                             // 0000000C6548: 095F63AF
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v174                 // 0000000C654C: 7C375CFF C2CE8ED0
	v_fmac_f32_e32 v176, 0x32a5705f, v174                      // 0000000C6554: 57615CFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C655C: BF870121
	v_add_f32_e32 v175, v175, v176                             // 0000000C6560: 075F61AF
	v_cvt_i32_f32_e32 v176, v177                               // 0000000C6564: 7F6011B1
	v_exp_f32_e32 v175, v175                                   // 0000000C6568: 7F5E4BAF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C656C: BF870095
	.long 0xd71c00af                                           // 0000000C6570: D71C00AF
	v_cndmask_b32_e32 v1, v175, v176, vcc_lo                   // 0000000C6574: 020361AF
	v_cndmask_b32_e32 v175, 0, v175, vcc_lo                    // 0000000C6578: 035F5E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v174                 // 0000000C657C: 7C3D5CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C6584: BF870002
	v_cndmask_b32_e32 v174, 0x7f800000, v175, vcc_lo           // 0000000C6588: 035D5EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C6590: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6594: BF870091
	v_bfe_u32 v175, v174, 16, 1                                // 0000000C6598: D61000AF 020521AE
	v_add3_u32 v175, v174, v175, 0x7fff                        // 0000000C65A0: D65500AF 03FF5FAE 00007FFF
	ds_store_b16_d16_hi v159, v175 offset:20                   // 0000000C65AC: DA840014 0000AF9F
	s_and_saveexec_b32 s7, s22                                 // 0000000C65B4: BE872016
	s_cbranch_execz 30                                         // 0000000C65B8: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2334>
	ds_load_b32 v173, v158 offset:44                           // 0000000C65BC: D8D8002C AD00009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C65C4: BF89FC07
	v_sub_f32_e32 v173, v173, v130                             // 0000000C65C8: 095B05AD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C65CC: BF870121
	v_mul_f32_e32 v175, 0x3fb8aa3b, v173                       // 0000000C65D0: 115F5AFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v173                 // 0000000C65D8: 7C375AFF C2CE8ED0
	v_fma_f32 v176, 0x3fb8aa3b, v173, -v175                    // 0000000C65E0: D61300B0 86BF5AFF 3FB8AA3B
	v_rndne_f32_e32 v177, v175                                 // 0000000C65EC: 7F6247AF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C65F0: BF870112
	v_fmac_f32_e32 v176, 0x32a5705f, v173                      // 0000000C65F4: 57615AFF 32A5705F
	v_sub_f32_e32 v175, v175, v177                             // 0000000C65FC: 095F63AF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6600: BF870121
	v_add_f32_e32 v175, v175, v176                             // 0000000C6604: 075F61AF
	v_cvt_i32_f32_e32 v176, v177                               // 0000000C6608: 7F6011B1
	v_exp_f32_e32 v175, v175                                   // 0000000C660C: 7F5E4BAF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6610: BF870095
	.long 0xd71c00af                                           // 0000000C6614: D71C00AF
	v_cndmask_b32_e32 v1, v175, v176, vcc_lo                   // 0000000C6618: 020361AF
	v_cndmask_b32_e32 v175, 0, v175, vcc_lo                    // 0000000C661C: 035F5E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v173                 // 0000000C6620: 7C3D5AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C6628: BF870002
	v_cndmask_b32_e32 v173, 0x7f800000, v175, vcc_lo           // 0000000C662C: 035B5EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C6634: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6638: BF870121
	v_bfe_u32 v175, v173, 16, 1                                // 0000000C663C: D61000AF 020521AD
	v_mov_b32_e32 v176, 0                                      // 0000000C6644: 7F600280
	v_add3_u32 v177, v173, v175, 0x7fff                        // 0000000C6648: D65500B1 03FF5FAD 00007FFF
	v_mov_b32_e32 v175, 0                                      // 0000000C6654: 7F5E0280
	ds_store_b16_d16_hi v159, v177 offset:22                   // 0000000C6658: DA840016 0000B19F
	s_and_saveexec_b32 s7, s15                                 // 0000000C6660: BE87200F
	s_cbranch_execz 30                                         // 0000000C6664: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x23e0>
	ds_load_b32 v176, v158 offset:48                           // 0000000C6668: D8D80030 B000009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C6670: BF89FC07
	v_sub_f32_e32 v176, v176, v130                             // 0000000C6674: 096105B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6678: BF870091
	v_mul_f32_e32 v177, 0x3fb8aa3b, v176                       // 0000000C667C: 116360FF 3FB8AA3B
	v_fma_f32 v178, 0x3fb8aa3b, v176, -v177                    // 0000000C6684: D61300B2 86C760FF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 0000000C6690: 7F6647B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C6694: BF870221
	v_sub_f32_e32 v177, v177, v179                             // 0000000C6698: 096367B1
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v176                 // 0000000C669C: 7C3760FF C2CE8ED0
	v_fmac_f32_e32 v178, 0x32a5705f, v176                      // 0000000C66A4: 576560FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C66AC: BF870121
	v_add_f32_e32 v177, v177, v178                             // 0000000C66B0: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 0000000C66B4: 7F6411B3
	v_exp_f32_e32 v177, v177                                   // 0000000C66B8: 7F624BB1
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C66BC: BF870095
	.long 0xd71c00b1                                           // 0000000C66C0: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 0000000C66C4: 020365B1
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 0000000C66C8: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v176                 // 0000000C66CC: 7C3D60FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C66D4: BF870002
	v_cndmask_b32_e32 v176, 0x7f800000, v177, vcc_lo           // 0000000C66D8: 036162FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C66E0: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C66E4: BF870091
	v_bfe_u32 v177, v176, 16, 1                                // 0000000C66E8: D61000B1 020521B0
	v_add3_u32 v177, v176, v177, 0x7fff                        // 0000000C66F0: D65500B1 03FF63B0 00007FFF
	ds_store_b16_d16_hi v159, v177 offset:24                   // 0000000C66FC: DA840018 0000B19F
	s_and_saveexec_b32 s7, s13                                 // 0000000C6704: BE87200D
	s_cbranch_execz 30                                         // 0000000C6708: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2484>
	ds_load_b32 v175, v158 offset:52                           // 0000000C670C: D8D80034 AF00009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C6714: BF89FC07
	v_sub_f32_e32 v175, v175, v130                             // 0000000C6718: 095F05AF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C671C: BF870121
	v_mul_f32_e32 v177, 0x3fb8aa3b, v175                       // 0000000C6720: 11635EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v175                 // 0000000C6728: 7C375EFF C2CE8ED0
	v_fma_f32 v178, 0x3fb8aa3b, v175, -v177                    // 0000000C6730: D61300B2 86C75EFF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 0000000C673C: 7F6647B1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C6740: BF870112
	v_fmac_f32_e32 v178, 0x32a5705f, v175                      // 0000000C6744: 57655EFF 32A5705F
	v_sub_f32_e32 v177, v177, v179                             // 0000000C674C: 096367B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6750: BF870121
	v_add_f32_e32 v177, v177, v178                             // 0000000C6754: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 0000000C6758: 7F6411B3
	v_exp_f32_e32 v177, v177                                   // 0000000C675C: 7F624BB1
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6760: BF870095
	.long 0xd71c00b1                                           // 0000000C6764: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 0000000C6768: 020365B1
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 0000000C676C: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v175                 // 0000000C6770: 7C3D5EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C6778: BF870002
	v_cndmask_b32_e32 v175, 0x7f800000, v177, vcc_lo           // 0000000C677C: 035F62FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C6784: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6788: BF870121
	v_bfe_u32 v177, v175, 16, 1                                // 0000000C678C: D61000B1 020521AF
	v_mov_b32_e32 v178, 0                                      // 0000000C6794: 7F640280
	v_add3_u32 v179, v175, v177, 0x7fff                        // 0000000C6798: D65500B3 03FF63AF 00007FFF
	v_mov_b32_e32 v177, 0                                      // 0000000C67A4: 7F620280
	ds_store_b16_d16_hi v159, v179 offset:26                   // 0000000C67A8: DA84001A 0000B39F
	s_and_saveexec_b32 s7, s9                                  // 0000000C67B0: BE872009
	s_cbranch_execz 30                                         // 0000000C67B4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2530>
	ds_load_b32 v178, v158 offset:56                           // 0000000C67B8: D8D80038 B200009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C67C0: BF89FC07
	v_sub_f32_e32 v178, v178, v130                             // 0000000C67C4: 096505B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C67C8: BF870091
	v_mul_f32_e32 v179, 0x3fb8aa3b, v178                       // 0000000C67CC: 116764FF 3FB8AA3B
	v_fma_f32 v180, 0x3fb8aa3b, v178, -v179                    // 0000000C67D4: D61300B4 86CF64FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000C67E0: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C67E4: BF870221
	v_sub_f32_e32 v179, v179, v181                             // 0000000C67E8: 09676BB3
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 0000000C67EC: 7C3764FF C2CE8ED0
	v_fmac_f32_e32 v180, 0x32a5705f, v178                      // 0000000C67F4: 576964FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C67FC: BF870121
	v_add_f32_e32 v179, v179, v180                             // 0000000C6800: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000C6804: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 0000000C6808: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C680C: BF870095
	.long 0xd71c00b3                                           // 0000000C6810: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000C6814: 020369B3
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000C6818: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 0000000C681C: 7C3D64FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C6824: BF870002
	v_cndmask_b32_e32 v178, 0x7f800000, v179, vcc_lo           // 0000000C6828: 036566FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C6830: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6834: BF870091
	v_bfe_u32 v179, v178, 16, 1                                // 0000000C6838: D61000B3 020521B2
	v_add3_u32 v179, v178, v179, 0x7fff                        // 0000000C6840: D65500B3 03FF67B2 00007FFF
	ds_store_b16_d16_hi v159, v179 offset:28                   // 0000000C684C: DA84001C 0000B39F
	s_and_saveexec_b32 s7, s1                                  // 0000000C6854: BE872001
	s_cbranch_execz 30                                         // 0000000C6858: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x25d4>
	ds_load_b32 v177, v158 offset:60                           // 0000000C685C: D8D8003C B100009E
	s_waitcnt lgkmcnt(0)                                       // 0000000C6864: BF89FC07
	v_sub_f32_e32 v177, v177, v130                             // 0000000C6868: 096305B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C686C: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v177                       // 0000000C6870: 116762FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v177                 // 0000000C6878: 7C3762FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v177, -v179                    // 0000000C6880: D61300B4 86CF62FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000C688C: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C6890: BF870112
	v_fmac_f32_e32 v180, 0x32a5705f, v177                      // 0000000C6894: 576962FF 32A5705F
	v_sub_f32_e32 v179, v179, v181                             // 0000000C689C: 09676BB3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C68A0: BF870121
	v_add_f32_e32 v179, v179, v180                             // 0000000C68A4: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000C68A8: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 0000000C68AC: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C68B0: BF870095
	.long 0xd71c00b3                                           // 0000000C68B4: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000C68B8: 020369B3
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000C68BC: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v177                 // 0000000C68C0: 7C3D62FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C68C8: BF870002
	v_cndmask_b32_e32 v177, 0x7f800000, v179, vcc_lo           // 0000000C68CC: 036366FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C68D4: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C68D8: BF8700A1
	v_bfe_u32 v179, v177, 16, 1                                // 0000000C68DC: D61000B3 020521B1
	s_mov_b32 s1, exec_lo                                      // 0000000C68E4: BE81007E
	v_add3_u32 v180, v177, v179, 0x7fff                        // 0000000C68E8: D65500B4 03FF67B1 00007FFF
	v_mov_b32_e32 v179, 0                                      // 0000000C68F4: 7F660280
	ds_store_b16_d16_hi v159, v180 offset:30                   // 0000000C68F8: DA84001E 0000B49F
	v_cmpx_lt_f32_e32 0xefa18f08, v131                         // 0000000C6900: 7D2306FF EFA18F08
	s_cbranch_execz 63568                                      // 0000000C6908: BFA5F850 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x74c>
	v_sub_f32_e32 v131, v131, v130                             // 0000000C690C: 09070583
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6910: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v131                       // 0000000C6914: 116706FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 0000000C691C: 7C3706FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v131, -v179                    // 0000000C6924: D61300B4 86CF06FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000C6930: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6934: BF870091
	v_dual_fmac_f32 v180, 0x32a5705f, v131 :: v_dual_sub_f32 v179, v179, v181// 0000000C6938: C80B06FF B4B36BB3 32A5705F
	v_add_f32_e32 v179, v179, v180                             // 0000000C6944: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000C6948: 7F6811B5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C694C: BF870292
	v_exp_f32_e32 v179, v179                                   // 0000000C6950: 7F664BB3
	.long 0xd71c00b3                                           // 0000000C6954: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000C6958: 020369B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C695C: BF870121
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000C6960: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 0000000C6964: 7C3D06FF 42B17218
	v_cndmask_b32_e32 v179, 0x7f800000, v179, vcc_lo           // 0000000C696C: 036766FF 7F800000
	s_branch 63541                                             // 0000000C6974: BFA0F835 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x74c>
	v_lshlrev_b32_e32 v0, 2, v151                              // 0000000C6978: 30012E82
	v_lshlrev_b32_e32 v147, 1, v148                            // 0000000C697C: 31272881
	.long 0xd700008b                                           // 0000000C6980: D700008B
	v_cndmask_b32_e32 v1, s18, v139, vcc_lo                    // 0000000C6984: 02031612
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000C6988: BF870211
	v_add_co_ci_u32_e64 v140, null, s19, v140, s0              // 0000000C698C: D5207C8C 00031813
	v_lshl_or_b32 v0, v150, 6, v0                              // 0000000C6994: D6560000 04010D96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000000C699C: BF870151
	v_add_nc_u32_e32 v133, 0xa000, v0                          // 0000000C69A0: 4B0A00FF 0000A000
	ds_load_2addr_b32 v[141:142], v133 offset0:128 offset1:130 // 0000000C69A8: D8DC8280 8D000085
	s_waitcnt lgkmcnt(0)                                       // 0000000C69B0: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 0000000C69B4: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 0000000C69BC: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 0000000C69C4: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000000C69C8: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 0000000C69CC: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 0000000C69D4: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:132 offset1:134 // 0000000C69D8: D8DC8684 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:136 offset1:138 // 0000000C69E0: D8DC8A88 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:140 offset1:142 // 0000000C69E8: D8DC8E8C 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 0000000C69F0: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000C69F4: 3505029F
	v_or_b32_e32 v0, v149, v151                                // 0000000C69F8: 38012F95
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C69FC: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 0000000C6A00: 11252191
	.long 0xd73c0083                                           // 0000000C6A04: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000000C6A08: 02030281
	.long 0xd7000081                                           // 0000000C6A0C: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 0000000C6A10: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000C6A14: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 0000000C6A18: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 0000000C6A20: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6A28: BF870094
	.long 0xd7000083                                           // 0000000C6A2C: D7000083
	v_cndmask_b32_e32 v1, s16, v131, vcc_lo                    // 0000000C6A30: 02030610
	v_add_co_ci_u32_e64 v132, null, s17, v132, s0              // 0000000C6A34: D5207C84 00030811
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6A3C: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 0000000C6A40: 57252194
	.long 0xd4440000                                           // 0000000C6A44: D4440000
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 0000000C6A48: 0202000E
	v_fma_f32 v139, -v143, v146, v145                          // 0000000C6A4C: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C6A54: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 0000000C6A58: D637008B 064B218B
	.long 0xd7006a83                                           // 0000000C6A60: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 0000000C6A64: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 0000000C6A68: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000C6A70: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 0000000C6A74: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 0000000C6A7C: BE812000
	s_cbranch_execz 70                                         // 0000000C6A80: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x289c>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C6A84: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 0000000C6A88: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 0000000C6A94: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 0000000C6A98: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 0000000C6AA0: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 0000000C6AA4: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6AA8: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 0000000C6AAC: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 0000000C6AB4: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 0000000C6AC0: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C6AC4: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 0000000C6AC8: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 0000000C6AD0: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000C6AD4: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 0000000C6AD8: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 0000000C6ADC: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 0000000C6AE0: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 0000000C6AE8: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6AEC: BF870095
	.long 0xd71c008d                                           // 0000000C6AF0: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 0000000C6AF4: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000C6AF8: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 0000000C6AFC: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6B04: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 0000000C6B08: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 0000000C6B10: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6B14: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 0000000C6B18: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 0000000C6B20: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6B24: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 0000000C6B28: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 0000000C6B30: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 0000000C6B34: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6B3C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000C6B40: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 0000000C6B44: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6B4C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000C6B50: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 0000000C6B54: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6B5C: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 0000000C6B60: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 0000000C6B68: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 0000000C6B70: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6B7C: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 0000000C6B80: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 0000000C6B88: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 0000000C6B94: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000C6B9C: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 0000000C6BA0: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 0000000C6BA8: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C6BB0: BF870292
	v_rcp_f32_e32 v140, v121                                   // 0000000C6BB4: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 0000000C6BB8: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6BC0: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 0000000C6BC4: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 0000000C6BC8: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6BCC: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 0000000C6BD0: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 0000000C6BD8: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6BDC: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 0000000C6BE0: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 0000000C6BE8: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 0000000C6BF0: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C6BF4: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 0000000C6BF8: D627008C 03CB1D8C
	.long 0xd4440001                                           // 0000000C6C00: D4440001
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 0000000C6C04: 0202F20E
	s_and_saveexec_b32 s2, s1                                  // 0000000C6C08: BE822001
	s_cbranch_execz 69                                         // 0000000C6C0C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2a24>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000000C6C10: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 0000000C6C1C: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 0000000C6C20: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000C6C28: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000C6C2C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6C30: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000C6C34: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000C6C3C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000C6C48: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C6C4C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000C6C50: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000C6C54: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000C6C5C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6C64: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000C6C68: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000C6C6C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000C6C70: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6C74: BF870095
	.long 0xd71c008e                                           // 0000000C6C78: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000C6C7C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000C6C80: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000C6C84: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6C8C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000C6C90: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000C6C98: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6C9C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 0000000C6CA0: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000C6CA8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6CAC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000C6CB0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000C6CB8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 0000000C6CBC: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6CC4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000C6CC8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000C6CCC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6CD4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000C6CD8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000C6CDC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6CE4: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000C6CE8: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 0000000C6CF0: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 0000000C6CF8: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6D04: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 0000000C6D08: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 0000000C6D10: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 0000000C6D1C: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000C6D24: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 0000000C6D28: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 0000000C6D2C: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 0000000C6D34: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C6D3C: BF870292
	v_rcp_f32_e32 v141, v122                                   // 0000000C6D40: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 0000000C6D44: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6D4C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000C6D50: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000C6D54: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6D58: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 0000000C6D5C: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 0000000C6D64: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6D68: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 0000000C6D6C: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 0000000C6D74: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 0000000C6D7C: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C6D80: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 0000000C6D84: D6270089 03CB138D
	.long 0xd4440002                                           // 0000000C6D8C: D4440002
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 0000000C6D90: 0202F40E
	s_and_saveexec_b32 s3, s2                                  // 0000000C6D94: BE832002
	s_cbranch_execz 69                                         // 0000000C6D98: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2bb0>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 0000000C6D9C: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 0000000C6DA8: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 0000000C6DAC: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000C6DB4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000C6DB8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6DBC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000C6DC0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000C6DC8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000C6DD4: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C6DD8: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000C6DDC: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000C6DE0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000C6DE8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6DF0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000C6DF4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000C6DF8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000C6DFC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6E00: BF870095
	.long 0xd71c008e                                           // 0000000C6E04: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000C6E08: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000C6E0C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000C6E10: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6E18: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000C6E1C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000C6E24: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6E28: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 0000000C6E2C: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000C6E34: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6E38: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000C6E3C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000C6E44: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 0000000C6E48: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6E50: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000C6E54: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000C6E58: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6E60: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000C6E64: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000C6E68: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6E70: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000C6E74: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 0000000C6E7C: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 0000000C6E84: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6E90: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 0000000C6E94: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 0000000C6E9C: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 0000000C6EA8: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000C6EB0: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 0000000C6EB4: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 0000000C6EBC: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C6EC4: BF870292
	v_rcp_f32_e32 v141, v123                                   // 0000000C6EC8: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 0000000C6ECC: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6ED4: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000C6ED8: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000C6EDC: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6EE0: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 0000000C6EE4: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 0000000C6EEC: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6EF0: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 0000000C6EF4: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 0000000C6EFC: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 0000000C6F04: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C6F08: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 0000000C6F0C: D627008A 03CB158D
	.long 0xd4440003                                           // 0000000C6F14: D4440003
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 0000000C6F18: 0202F60E
	s_and_saveexec_b32 s4, s3                                  // 0000000C6F1C: BE842003
	s_cbranch_execz 69                                         // 0000000C6F20: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2d38>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 0000000C6F24: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 0000000C6F30: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 0000000C6F34: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000C6F3C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000C6F40: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6F44: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000C6F48: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000C6F50: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000C6F5C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C6F60: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000C6F64: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000C6F68: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000C6F70: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C6F78: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000C6F7C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000C6F80: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000C6F84: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6F88: BF870095
	.long 0xd71c008e                                           // 0000000C6F8C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000C6F90: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000C6F94: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000C6F98: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6FA0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000C6FA4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000C6FAC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6FB0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 0000000C6FB4: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000C6FBC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6FC0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000C6FC4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000C6FCC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 0000000C6FD0: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6FD8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000C6FDC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000C6FE0: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6FE8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000C6FEC: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000C6FF0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C6FF8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000C6FFC: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 0000000C7004: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 0000000C700C: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7018: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 0000000C701C: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 0000000C7024: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 0000000C7030: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C7038: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 0000000C703C: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 0000000C7040: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 0000000C7048: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C7050: BF870292
	v_rcp_f32_e32 v141, v124                                   // 0000000C7054: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 0000000C7058: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7060: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000C7064: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000C7068: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C706C: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 0000000C7070: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 0000000C7078: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C707C: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 0000000C7080: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 0000000C7088: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 0000000C7090: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C7094: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 0000000C7098: D6270087 03CB0F8D
	.long 0xd4440004                                           // 0000000C70A0: D4440004
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 0000000C70A4: 0202F80E
	s_and_saveexec_b32 s5, s4                                  // 0000000C70A8: BE852004
	s_cbranch_execz 69                                         // 0000000C70AC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2ec4>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 0000000C70B0: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 0000000C70BC: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 0000000C70C0: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000C70C8: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000C70CC: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C70D0: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000C70D4: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000C70DC: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000C70E8: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C70EC: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000C70F0: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000C70F4: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000C70FC: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C7104: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000C7108: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000C710C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000C7110: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7114: BF870095
	.long 0xd71c008e                                           // 0000000C7118: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000C711C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000C7120: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000C7124: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C712C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000C7130: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000C7138: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C713C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 0000000C7140: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000C7148: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C714C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000C7150: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000C7158: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 0000000C715C: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7164: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000C7168: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000C716C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7174: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000C7178: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000C717C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7184: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000C7188: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 0000000C7190: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 0000000C7198: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C71A4: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 0000000C71A8: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 0000000C71B0: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 0000000C71BC: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000C71C4: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 0000000C71C8: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 0000000C71D0: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C71D8: BF870292
	v_rcp_f32_e32 v141, v125                                   // 0000000C71DC: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 0000000C71E0: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C71E8: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000C71EC: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000C71F0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C71F4: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 0000000C71F8: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 0000000C7200: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7204: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 0000000C7208: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 0000000C7210: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 0000000C7218: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C721C: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 0000000C7220: D6270088 03CB118D
	.long 0xd4440005                                           // 0000000C7228: D4440005
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 0000000C722C: 0202FA0E
	s_and_saveexec_b32 s6, s5                                  // 0000000C7230: BE862005
	s_cbranch_execz 69                                         // 0000000C7234: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x304c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 0000000C7238: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 0000000C7244: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 0000000C7248: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000C7250: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000C7254: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7258: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000C725C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000C7264: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000C7270: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C7274: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000C7278: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000C727C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000C7284: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C728C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000C7290: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000C7294: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000C7298: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C729C: BF870095
	.long 0xd71c008e                                           // 0000000C72A0: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000C72A4: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000C72A8: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000C72AC: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C72B4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000C72B8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000C72C0: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C72C4: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 0000000C72C8: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000C72D0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C72D4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000C72D8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000C72E0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 0000000C72E4: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C72EC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000C72F0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000C72F4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C72FC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000C7300: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000C7304: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C730C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000C7310: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 0000000C7318: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 0000000C7320: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C732C: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 0000000C7330: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 0000000C7338: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 0000000C7344: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000C734C: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000C7350: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 0000000C7354: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 0000000C735C: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C7364: BF870292
	v_rcp_f32_e32 v141, v126                                   // 0000000C7368: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 0000000C736C: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7374: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000C7378: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000C737C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7380: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 0000000C7384: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 0000000C738C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7390: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 0000000C7394: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 0000000C739C: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 0000000C73A4: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C73A8: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 0000000C73AC: D6270085 03CB0B8D
	.long 0xd4440006                                           // 0000000C73B4: D4440006
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 0000000C73B8: 0202FC0E
	s_and_saveexec_b32 s7, s6                                  // 0000000C73BC: BE872006
	s_cbranch_execz 69                                         // 0000000C73C0: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x31d8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 0000000C73C4: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 0000000C73D0: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 0000000C73D4: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000C73DC: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000C73E0: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C73E4: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000C73E8: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000C73F0: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000C73FC: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C7400: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000C7404: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000C7408: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000C7410: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C7418: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000C741C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000C7420: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000C7424: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7428: BF870095
	.long 0xd71c008e                                           // 0000000C742C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000C7430: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000C7434: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000C7438: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7440: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000C7444: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000C744C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7450: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 0000000C7454: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000C745C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7460: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000C7464: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000C746C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 0000000C7470: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7478: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000C747C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000C7480: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7488: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000C748C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000C7490: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7498: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000C749C: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 0000000C74A4: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 0000000C74AC: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C74B8: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 0000000C74BC: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 0000000C74C4: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 0000000C74D0: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000C74D8: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 0000000C74DC: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 0000000C74E4: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C74EC: BF870292
	v_rcp_f32_e32 v141, v127                                   // 0000000C74F0: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 0000000C74F4: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C74FC: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000C7500: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000C7504: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7508: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 0000000C750C: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 0000000C7514: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7518: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 0000000C751C: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 0000000C7524: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 0000000C752C: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C7530: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 0000000C7534: D6270086 03CB0D8D
	.long 0xd4440007                                           // 0000000C753C: D4440007
	v_cndmask_b32_e32 v1, s14, v127, vcc_lo                    // 0000000C7540: 0202FE0E
	s_and_saveexec_b32 s8, s7                                  // 0000000C7544: BE882007
	s_cbranch_execnz 363                                       // 0000000C7548: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C754C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C7550: BE882000
	s_cbranch_execnz 432                                       // 0000000C7554: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3918>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7558: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C755C: BE882001
	s_cbranch_execnz 501                                       // 0000000C7560: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a38>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7564: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C7568: BE882002
	s_cbranch_execnz 570                                       // 0000000C756C: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7570: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C7574: BE882003
	s_cbranch_execnz 639                                       // 0000000C7578: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c78>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C757C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C7580: BE882004
	s_cbranch_execnz 708                                       // 0000000C7584: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d98>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7588: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C758C: BE882005
	s_cbranch_execnz 777                                       // 0000000C7590: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eb8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7594: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C7598: BE882006
	s_cbranch_execnz 846                                       // 0000000C759C: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fd8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C75A0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C75A4: BE882007
	s_cbranch_execnz 915                                       // 0000000C75A8: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C75AC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C75B0: BE882000
	s_cbranch_execnz 984                                       // 0000000C75B4: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4218>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C75B8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C75BC: BE882001
	s_cbranch_execnz 1053                                      // 0000000C75C0: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4338>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C75C4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C75C8: BE882002
	s_cbranch_execnz 1122                                      // 0000000C75CC: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4458>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C75D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C75D4: BE882003
	s_cbranch_execnz 1191                                      // 0000000C75D8: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4578>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C75DC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C75E0: BE882004
	s_cbranch_execnz 1260                                      // 0000000C75E4: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4698>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C75E8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C75EC: BE882005
	s_cbranch_execnz 1329                                      // 0000000C75F0: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x47b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C75F4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C75F8: BE882006
	s_cbranch_execnz 1398                                      // 0000000C75FC: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x48d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7600: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C7604: BE882007
	s_cbranch_execnz 1467                                      // 0000000C7608: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x49f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C760C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C7610: BE882000
	s_cbranch_execnz 1536                                      // 0000000C7614: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4b18>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7618: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C761C: BE882001
	s_cbranch_execnz 1605                                      // 0000000C7620: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4c38>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7624: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C7628: BE882002
	s_cbranch_execnz 1674                                      // 0000000C762C: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4d58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7630: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C7634: BE882003
	s_cbranch_execnz 1743                                      // 0000000C7638: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4e78>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C763C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C7640: BE882004
	s_cbranch_execnz 1812                                      // 0000000C7644: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4f98>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7648: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C764C: BE882005
	s_cbranch_execnz 1881                                      // 0000000C7650: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x50b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7654: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C7658: BE882006
	s_cbranch_execnz 1950                                      // 0000000C765C: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x51d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7660: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C7664: BE882007
	s_cbranch_execnz 2019                                      // 0000000C7668: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x52f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C766C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C7670: BE882000
	s_cbranch_execnz 2088                                      // 0000000C7674: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5418>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7678: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C767C: BE882001
	s_cbranch_execnz 2157                                      // 0000000C7680: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5538>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7684: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C7688: BE882002
	s_cbranch_execnz 2226                                      // 0000000C768C: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5658>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7690: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C7694: BE882003
	s_cbranch_execnz 2295                                      // 0000000C7698: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5778>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C769C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C76A0: BE882004
	s_cbranch_execnz 2364                                      // 0000000C76A4: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5898>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C76A8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C76AC: BE882005
	s_cbranch_execnz 2433                                      // 0000000C76B0: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x59b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C76B4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C76B8: BE882006
	s_cbranch_execnz 2502                                      // 0000000C76BC: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5ad8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C76C0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C76C4: BE882007
	s_cbranch_execnz 2571                                      // 0000000C76C8: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5bf8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C76CC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C76D0: BE882000
	s_cbranch_execnz 2640                                      // 0000000C76D4: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5d18>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C76D8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C76DC: BE882001
	s_cbranch_execnz 2709                                      // 0000000C76E0: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5e38>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C76E4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C76E8: BE882002
	s_cbranch_execnz 2778                                      // 0000000C76EC: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5f58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C76F0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C76F4: BE882003
	s_cbranch_execnz 2847                                      // 0000000C76F8: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6078>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C76FC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C7700: BE882004
	s_cbranch_execnz 2916                                      // 0000000C7704: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6198>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7708: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C770C: BE882005
	s_cbranch_execnz 2985                                      // 0000000C7710: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x62b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7714: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C7718: BE882006
	s_cbranch_execnz 3054                                      // 0000000C771C: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x63d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7720: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C7724: BE882007
	s_cbranch_execnz 3123                                      // 0000000C7728: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x64f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C772C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C7730: BE882000
	s_cbranch_execnz 3192                                      // 0000000C7734: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6618>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7738: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C773C: BE882001
	s_cbranch_execnz 3261                                      // 0000000C7740: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6738>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7744: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C7748: BE882002
	s_cbranch_execnz 3330                                      // 0000000C774C: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6858>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7750: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C7754: BE882003
	s_cbranch_execnz 3399                                      // 0000000C7758: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6978>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C775C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C7760: BE882004
	s_cbranch_execnz 3468                                      // 0000000C7764: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6a98>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7768: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C776C: BE882005
	s_cbranch_execnz 3537                                      // 0000000C7770: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6bb8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7774: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C7778: BE882006
	s_cbranch_execnz 3606                                      // 0000000C777C: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6cd8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7780: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C7784: BE882007
	s_cbranch_execnz 3675                                      // 0000000C7788: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6df8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C778C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C7790: BE882000
	s_cbranch_execnz 3744                                      // 0000000C7794: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6f18>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7798: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C779C: BE882001
	s_cbranch_execnz 3813                                      // 0000000C77A0: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7038>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C77A4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C77A8: BE882002
	s_cbranch_execnz 3882                                      // 0000000C77AC: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7158>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C77B0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C77B4: BE882003
	s_cbranch_execnz 3951                                      // 0000000C77B8: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7278>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C77BC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C77C0: BE882004
	s_cbranch_execnz 4020                                      // 0000000C77C4: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7398>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C77C8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C77CC: BE882005
	s_cbranch_execnz 4089                                      // 0000000C77D0: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x74b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C77D4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C77D8: BE882006
	s_cbranch_execnz 4158                                      // 0000000C77DC: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x75d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C77E0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C77E4: BE882007
	s_cbranch_execnz 4227                                      // 0000000C77E8: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x76f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C77EC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C77F0: BE882000
	s_cbranch_execnz 4296                                      // 0000000C77F4: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7818>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C77F8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C77FC: BE882001
	s_cbranch_execnz 4365                                      // 0000000C7800: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7938>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7804: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C7808: BE882002
	s_cbranch_execnz 4434                                      // 0000000C780C: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7a58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7810: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C7814: BE882003
	s_cbranch_execnz 4503                                      // 0000000C7818: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7b78>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C781C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C7820: BE882004
	s_cbranch_execnz 4572                                      // 0000000C7824: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7c98>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7828: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C782C: BE882005
	s_cbranch_execnz 4641                                      // 0000000C7830: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7db8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7834: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C7838: BE882006
	s_cbranch_execnz 4710                                      // 0000000C783C: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7ed8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7840: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C7844: BE882007
	s_cbranch_execnz 4779                                      // 0000000C7848: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7ff8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C784C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C7850: BE882000
	s_cbranch_execnz 4848                                      // 0000000C7854: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8118>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7858: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C785C: BE882001
	s_cbranch_execnz 4917                                      // 0000000C7860: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8238>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7864: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C7868: BE882002
	s_cbranch_execnz 4986                                      // 0000000C786C: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8358>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7870: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C7874: BE882003
	s_cbranch_execnz 5055                                      // 0000000C7878: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8478>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C787C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C7880: BE882004
	s_cbranch_execnz 5124                                      // 0000000C7884: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8598>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7888: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C788C: BE882005
	s_cbranch_execnz 5193                                      // 0000000C7890: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x86b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7894: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C7898: BE882006
	s_cbranch_execnz 5262                                      // 0000000C789C: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x87d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C78A0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C78A4: BE882007
	s_cbranch_execnz 5331                                      // 0000000C78A8: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x88f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C78AC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C78B0: BE882000
	s_cbranch_execnz 5400                                      // 0000000C78B4: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8a18>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C78B8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C78BC: BE882001
	s_cbranch_execnz 5469                                      // 0000000C78C0: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b38>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C78C4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C78C8: BE882002
	s_cbranch_execnz 5538                                      // 0000000C78CC: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8c58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C78D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C78D4: BE882003
	s_cbranch_execnz 5607                                      // 0000000C78D8: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8d78>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C78DC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C78E0: BE882004
	s_cbranch_execnz 5676                                      // 0000000C78E4: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8e98>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C78E8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C78EC: BE882005
	s_cbranch_execnz 5745                                      // 0000000C78F0: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8fb8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C78F4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C78F8: BE882006
	s_cbranch_execnz 5814                                      // 0000000C78FC: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x90d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7900: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C7904: BE882007
	s_cbranch_execnz 5883                                      // 0000000C7908: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x91f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C790C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C7910: BE882000
	s_cbranch_execnz 5952                                      // 0000000C7914: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9318>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7918: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C791C: BE882001
	s_cbranch_execnz 6021                                      // 0000000C7920: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9438>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7924: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C7928: BE882002
	s_cbranch_execnz 6090                                      // 0000000C792C: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9558>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7930: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C7934: BE882003
	s_cbranch_execnz 6159                                      // 0000000C7938: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9678>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C793C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C7940: BE882004
	s_cbranch_execnz 6228                                      // 0000000C7944: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9798>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7948: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C794C: BE882005
	s_cbranch_execnz 6297                                      // 0000000C7950: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x98b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7954: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C7958: BE882006
	s_cbranch_execnz 6366                                      // 0000000C795C: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x99d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7960: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C7964: BE882007
	s_cbranch_execnz 6435                                      // 0000000C7968: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9af8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C796C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C7970: BE882000
	s_cbranch_execnz 6504                                      // 0000000C7974: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c18>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7978: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C797C: BE882001
	s_cbranch_execnz 6573                                      // 0000000C7980: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9d38>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7984: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C7988: BE882002
	s_cbranch_execnz 6642                                      // 0000000C798C: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9e58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7990: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C7994: BE882003
	s_cbranch_execnz 6711                                      // 0000000C7998: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9f78>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C799C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C79A0: BE882004
	s_cbranch_execnz 6780                                      // 0000000C79A4: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa098>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C79A8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C79AC: BE882005
	s_cbranch_execnz 6849                                      // 0000000C79B0: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa1b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C79B4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C79B8: BE882006
	s_cbranch_execnz 6918                                      // 0000000C79BC: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa2d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C79C0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C79C4: BE882007
	s_cbranch_execnz 6987                                      // 0000000C79C8: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa3f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C79CC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C79D0: BE882000
	s_cbranch_execnz 7056                                      // 0000000C79D4: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa518>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C79D8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C79DC: BE882001
	s_cbranch_execnz 7125                                      // 0000000C79E0: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa638>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C79E4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C79E8: BE882002
	s_cbranch_execnz 7194                                      // 0000000C79EC: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa758>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C79F0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C79F4: BE882003
	s_cbranch_execnz 7263                                      // 0000000C79F8: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa878>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C79FC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C7A00: BE882004
	s_cbranch_execnz 7332                                      // 0000000C7A04: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa998>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7A08: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C7A0C: BE882005
	s_cbranch_execnz 7401                                      // 0000000C7A10: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaab8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7A14: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C7A18: BE882006
	s_cbranch_execnz 7470                                      // 0000000C7A1C: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xabd8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7A20: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C7A24: BE882007
	s_cbranch_execnz 7539                                      // 0000000C7A28: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xacf8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7A2C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C7A30: BE882000
	s_cbranch_execnz 7608                                      // 0000000C7A34: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xae18>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7A38: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C7A3C: BE882001
	s_cbranch_execnz 7677                                      // 0000000C7A40: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaf38>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7A44: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C7A48: BE882002
	s_cbranch_execnz 7746                                      // 0000000C7A4C: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb058>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7A50: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C7A54: BE882003
	s_cbranch_execnz 7815                                      // 0000000C7A58: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb178>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7A5C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C7A60: BE882004
	s_cbranch_execnz 7884                                      // 0000000C7A64: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb298>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7A68: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C7A6C: BE882005
	s_cbranch_execnz 7953                                      // 0000000C7A70: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb3b8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7A74: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C7A78: BE882006
	s_cbranch_execnz 8022                                      // 0000000C7A7C: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb4d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7A80: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C7A84: BE882007
	s_cbranch_execnz 8091                                      // 0000000C7A88: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb5f8>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7A8C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C7A90: BE882000
	s_cbranch_execnz 8160                                      // 0000000C7A94: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb718>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7A98: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 0000000C7A9C: BE802001
	s_cbranch_execnz 8229                                      // 0000000C7AA0: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb838>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000C7AA4: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000C7AA8: BE802002
	s_cbranch_execnz 8298                                      // 0000000C7AAC: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb958>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000C7AB0: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000C7AB4: BE802003
	s_cbranch_execnz 8367                                      // 0000000C7AB8: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xba78>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000C7ABC: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000C7AC0: BE802004
	s_cbranch_execnz 8436                                      // 0000000C7AC4: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbb98>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000C7AC8: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000C7ACC: BE802005
	s_cbranch_execnz 8505                                      // 0000000C7AD0: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbcb8>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000C7AD4: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000C7AD8: BE802006
	s_cbranch_execnz 8574                                      // 0000000C7ADC: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbdd8>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000C7AE0: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000C7AE4: BE802007
	s_cbranch_execnz 8643                                      // 0000000C7AE8: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbef8>
	s_nop 0                                                    // 0000000C7AEC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000000C7AF0: BFB60003
	s_endpgm                                                   // 0000000C7AF4: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 0000000C7AF8: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 0000000C7B04: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 0000000C7B08: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000C7B10: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000C7B14: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7B18: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000C7B1C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000C7B24: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000C7B30: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C7B34: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000C7B38: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000C7B3C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000C7B44: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C7B4C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000C7B50: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000C7B54: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000C7B58: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7B5C: BF870095
	.long 0xd71c008e                                           // 0000000C7B60: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000C7B64: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000C7B68: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000C7B6C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7B74: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000C7B78: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000C7B80: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7B84: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 0000000C7B88: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000C7B90: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7B94: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000C7B98: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000C7BA0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 0000000C7BA4: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7BAC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000C7BB0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000C7BB4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7BBC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000C7BC0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000C7BC4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7BCC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000C7BD0: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 0000000C7BD8: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 0000000C7BE0: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7BEC: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 0000000C7BF0: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 0000000C7BF8: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 0000000C7C04: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7C0C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C7C10: BE882000
	s_cbranch_execz 65104                                      // 0000000C7C14: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3258>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 0000000C7C18: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 0000000C7C24: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 0000000C7C28: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 0000000C7C30: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 0000000C7C34: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7C38: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 0000000C7C3C: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 0000000C7C44: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 0000000C7C50: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C7C54: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 0000000C7C58: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 0000000C7C5C: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 0000000C7C64: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C7C6C: BF870121
	v_add_f32_e32 v141, v141, v142                             // 0000000C7C70: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 0000000C7C74: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 0000000C7C78: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7C7C: BF870095
	.long 0xd71c008d                                           // 0000000C7C80: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 0000000C7C84: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000C7C88: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 0000000C7C8C: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7C94: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 0000000C7C98: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 0000000C7CA0: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7CA4: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 0000000C7CA8: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 0000000C7CB0: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7CB4: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 0000000C7CB8: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 0000000C7CC0: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 0000000C7CC4: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7CCC: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 0000000C7CD0: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 0000000C7CD4: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7CDC: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 0000000C7CE0: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 0000000C7CE4: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7CEC: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 0000000C7CF0: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 0000000C7CF8: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 0000000C7D00: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7D0C: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 0000000C7D10: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 0000000C7D18: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 0000000C7D24: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7D2C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C7D30: BE882001
	s_cbranch_execz 65035                                      // 0000000C7D34: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3264>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000000C7D38: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 0000000C7D44: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 0000000C7D48: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 0000000C7D50: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000C7D54: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7D58: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 0000000C7D5C: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 0000000C7D64: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 0000000C7D70: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C7D74: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 0000000C7D78: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000C7D7C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 0000000C7D84: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C7D8C: BF870121
	v_add_f32_e32 v128, v128, v141                             // 0000000C7D90: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 0000000C7D94: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 0000000C7D98: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7D9C: BF870095
	.long 0xd71c0080                                           // 0000000C7DA0: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 0000000C7DA4: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 0000000C7DA8: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000C7DAC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7DB4: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 0000000C7DB8: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000C7DC0: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7DC4: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 0000000C7DC8: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 0000000C7DD0: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7DD4: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 0000000C7DD8: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 0000000C7DE0: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 0000000C7DE4: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7DEC: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 0000000C7DF0: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 0000000C7DF4: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7DFC: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 0000000C7E00: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 0000000C7E04: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7E0C: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 0000000C7E10: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 0000000C7E18: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 0000000C7E20: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7E2C: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 0000000C7E30: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 0000000C7E38: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 0000000C7E44: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7E4C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C7E50: BE882002
	s_cbranch_execz 64966                                      // 0000000C7E54: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3270>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 0000000C7E58: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000C7E64: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000C7E6C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000C7E70: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7E74: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000C7E78: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 0000000C7E80: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 0000000C7E8C: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C7E90: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 0000000C7E94: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 0000000C7E9C: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000C7EA0: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 0000000C7EA4: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 0000000C7EA8: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000C7EAC: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 0000000C7EB4: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7EB8: BF870095
	.long 0xd71c0072                                           // 0000000C7EBC: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 0000000C7EC0: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000C7EC4: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000C7EC8: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7ED0: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 0000000C7ED4: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000C7EE0: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7EE4: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000C7EE8: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 0000000C7EF0: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7EF4: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 0000000C7EF8: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 0000000C7F00: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 0000000C7F04: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7F0C: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 0000000C7F10: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 0000000C7F14: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7F1C: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 0000000C7F20: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 0000000C7F24: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7F2C: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 0000000C7F30: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000C7F38: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 0000000C7F40: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7F4C: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 0000000C7F50: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 0000000C7F58: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000C7F64: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C7F6C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C7F70: BE882003
	s_cbranch_execz 64897                                      // 0000000C7F74: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x327c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 0000000C7F78: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000C7F84: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000C7F8C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000C7F90: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7F94: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000C7F98: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000C7FA0: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 0000000C7FAC: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C7FB0: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 0000000C7FB4: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000C7FB8: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000C7FC0: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C7FC8: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000C7FCC: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 0000000C7FD0: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 0000000C7FD4: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7FD8: BF870095
	.long 0xd71c0072                                           // 0000000C7FDC: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000C7FE0: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000C7FE4: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000C7FE8: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C7FF0: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 0000000C7FF4: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000C8000: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8004: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000C8008: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000C8010: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8014: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 0000000C8018: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 0000000C8020: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 0000000C8024: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C802C: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 0000000C8030: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 0000000C8034: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C803C: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 0000000C8040: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 0000000C8044: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C804C: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 0000000C8050: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000C8058: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 0000000C8060: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C806C: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000C8070: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000C8078: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000C8084: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C808C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C8090: BE882004
	s_cbranch_execz 64828                                      // 0000000C8094: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3288>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 0000000C8098: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000C80A4: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000C80AC: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000C80B0: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C80B4: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000C80B8: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000C80C0: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000C80CC: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C80D0: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000C80D4: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000C80D8: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000C80E0: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C80E8: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000C80EC: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000C80F0: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000C80F4: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C80F8: BF870095
	.long 0xd71c0072                                           // 0000000C80FC: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000C8100: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000C8104: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000C8108: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8110: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 0000000C8114: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000C8120: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8124: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000C8128: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000C8130: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8134: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000C8138: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000C8140: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000C8144: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C814C: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 0000000C8150: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 0000000C8154: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C815C: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 0000000C8160: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 0000000C8164: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C816C: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 0000000C8170: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000C8178: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 0000000C8180: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C818C: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000C8190: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000C8198: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000C81A4: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C81AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C81B0: BE882005
	s_cbranch_execz 64759                                      // 0000000C81B4: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3294>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 0000000C81B8: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000C81C4: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000C81CC: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000C81D0: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C81D4: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000C81D8: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000C81E0: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000C81EC: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C81F0: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000C81F4: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000C81F8: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000C8200: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C8208: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000C820C: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000C8210: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000C8214: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8218: BF870095
	.long 0xd71c0072                                           // 0000000C821C: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000C8220: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000C8224: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000C8228: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8230: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000C8234: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 0000000C823C: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8244: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000C8248: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000C8250: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8254: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000C8258: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000C8260: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000C8264: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C826C: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000C8270: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 0000000C8274: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C827C: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 0000000C8280: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 0000000C8284: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C828C: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000C8290: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000C8298: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 0000000C82A0: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C82AC: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000C82B0: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000C82B8: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000C82C4: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C82CC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C82D0: BE882006
	s_cbranch_execz 64690                                      // 0000000C82D4: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32a0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 0000000C82D8: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000C82E4: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000C82EC: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000C82F0: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C82F4: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000C82F8: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000C8300: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000C830C: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C8310: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000C8314: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000C8318: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000C8320: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C8328: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000C832C: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000C8330: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000C8334: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8338: BF870095
	.long 0xd71c0072                                           // 0000000C833C: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000C8340: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000C8344: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000C8348: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8350: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 0000000C8354: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000C8360: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8364: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000C8368: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000C8370: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8374: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000C8378: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000C8380: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000C8384: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C838C: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000C8390: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000C8394: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C839C: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000C83A0: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000C83A4: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C83AC: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000C83B0: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000C83B8: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 0000000C83C0: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C83CC: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000C83D0: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000C83D8: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000C83E4: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C83EC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C83F0: BE882007
	s_cbranch_execz 64621                                      // 0000000C83F4: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32ac>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 0000000C83F8: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000C8404: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000C840C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000C8410: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8414: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000C8418: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000C8420: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000C842C: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C8430: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000C8434: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000C8438: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000C8440: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C8448: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000C844C: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000C8450: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000C8454: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8458: BF870095
	.long 0xd71c0072                                           // 0000000C845C: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000C8460: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000C8464: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000C8468: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8470: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 0000000C8474: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000C8480: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8484: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000C8488: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000C8490: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8494: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000C8498: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000C84A0: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000C84A4: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C84AC: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000C84B0: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000C84B4: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C84BC: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000C84C0: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000C84C4: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C84CC: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000C84D0: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000C84D8: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 0000000C84E0: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C84EC: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000C84F0: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000C84F8: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000C8504: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C850C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C8510: BE882000
	s_cbranch_execz 64552                                      // 0000000C8514: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32b8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 0000000C8518: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 0000000C8524: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 0000000C8528: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000C8530: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000C8534: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8538: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000C853C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000C8544: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000C8550: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C8554: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000C8558: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000C855C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000C8564: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C856C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000C8570: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000C8574: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000C8578: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C857C: BF870095
	.long 0xd71c0072                                           // 0000000C8580: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000C8584: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000C8588: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000C858C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8594: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000C8598: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000C85A0: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C85A4: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 0000000C85A8: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 0000000C85B0: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C85B4: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 0000000C85B8: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 0000000C85C0: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 0000000C85C4: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C85CC: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 0000000C85D0: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 0000000C85D4: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C85DC: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 0000000C85E0: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 0000000C85E4: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C85EC: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 0000000C85F0: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 0000000C85F8: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 0000000C8600: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C860C: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 0000000C8610: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 0000000C8618: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 0000000C8624: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C862C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C8630: BE882001
	s_cbranch_execz 64483                                      // 0000000C8634: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32c4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 0000000C8638: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 0000000C8644: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 0000000C8648: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 0000000C8650: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000C8654: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C8658: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 0000000C865C: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000C8664: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 0000000C866C: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000000C8678: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C867C: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 0000000C8680: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 0000000C8688: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C868C: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000000C8690: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000000C8694: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000000C8698: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C869C: BF870095
	.long 0xd71c0071                                           // 0000000C86A0: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000000C86A4: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000C86A8: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000C86AC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C86B4: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 0000000C86B8: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000C86C0: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C86C4: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 0000000C86C8: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 0000000C86D0: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C86D4: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 0000000C86D8: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 0000000C86E0: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 0000000C86E4: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C86EC: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 0000000C86F0: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 0000000C86F4: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C86FC: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 0000000C8700: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 0000000C8704: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C870C: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 0000000C8710: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 0000000C8718: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 0000000C8720: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C872C: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 0000000C8730: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 0000000C8738: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 0000000C8744: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C874C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C8750: BE882002
	s_cbranch_execz 64414                                      // 0000000C8754: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32d0>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 0000000C8758: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000C8764: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000C876C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000C8770: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8774: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000C8778: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 0000000C8780: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 0000000C878C: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C8790: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 0000000C8794: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000C8798: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 0000000C87A0: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C87A8: BF870121
	v_add_f32_e32 v106, v106, v113                             // 0000000C87AC: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 0000000C87B0: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 0000000C87B4: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C87B8: BF870095
	.long 0xd71c006a                                           // 0000000C87BC: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 0000000C87C0: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000C87C4: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000C87C8: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C87D0: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 0000000C87D4: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000C87E0: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C87E4: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000C87E8: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 0000000C87F0: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C87F4: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 0000000C87F8: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 0000000C8800: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 0000000C8804: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C880C: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 0000000C8810: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 0000000C8814: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C881C: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 0000000C8820: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 0000000C8824: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C882C: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 0000000C8830: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000C8838: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 0000000C8840: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C884C: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 0000000C8850: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 0000000C8858: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000C8864: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C886C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C8870: BE882003
	s_cbranch_execz 64345                                      // 0000000C8874: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32dc>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 0000000C8878: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000C8884: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000C888C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000C8890: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8894: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000C8898: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000C88A0: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 0000000C88AC: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C88B0: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 0000000C88B4: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 0000000C88C0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 0000000C88C4: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000C88C8: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C88D0: BF870293
	v_exp_f32_e32 v106, v106                                   // 0000000C88D4: 7ED44B6A
	.long 0xd71c006a                                           // 0000000C88D8: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000C88DC: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C88E0: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000C88E4: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000C88E8: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 0000000C88F0: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C88FC: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 0000000C8900: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000C8904: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C890C: BF870291
	v_rcp_f32_e32 v108, v107                                   // 0000000C8910: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 0000000C8914: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C891C: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 0000000C8920: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 0000000C8924: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 0000000C892C: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8930: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 0000000C8934: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 0000000C893C: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8940: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 0000000C8944: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 0000000C894C: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C8954: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000C8958: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 0000000C8960: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 0000000C896C: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C8974: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000C8978: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000C8984: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C898C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C8990: BE882004
	s_cbranch_execz 64276                                      // 0000000C8994: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32e8>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 0000000C8998: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000C89A4: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000C89AC: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000C89B0: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C89B4: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000C89B8: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000C89C0: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000C89CC: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C89D0: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000C89D4: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000C89D8: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000C89E0: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C89E8: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000C89EC: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000C89F0: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000C89F4: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C89F8: BF870095
	.long 0xd71c006a                                           // 0000000C89FC: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000C8A00: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000C8A04: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000C8A08: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8A10: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 0000000C8A14: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000C8A20: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8A24: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000C8A28: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000C8A30: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8A34: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000C8A38: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000C8A40: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000C8A44: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8A4C: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 0000000C8A50: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 0000000C8A54: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8A5C: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 0000000C8A60: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 0000000C8A64: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8A6C: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 0000000C8A70: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000C8A78: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 0000000C8A80: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8A8C: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000C8A90: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000C8A98: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000C8AA4: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C8AAC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C8AB0: BE882005
	s_cbranch_execz 64207                                      // 0000000C8AB4: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32f4>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 0000000C8AB8: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000C8AC4: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000C8ACC: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000C8AD0: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8AD4: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000C8AD8: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000C8AE0: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000C8AEC: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C8AF0: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000C8AF4: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000C8AF8: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000C8B00: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C8B08: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000C8B0C: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000C8B10: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000C8B14: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8B18: BF870095
	.long 0xd71c006a                                           // 0000000C8B1C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000C8B20: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000C8B24: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000C8B28: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8B30: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000000C8B34: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 0000000C8B3C: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8B44: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000C8B48: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000C8B50: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8B54: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000C8B58: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000C8B60: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000C8B64: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8B6C: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000C8B70: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 0000000C8B74: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8B7C: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 0000000C8B80: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 0000000C8B84: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8B8C: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000C8B90: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000C8B98: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 0000000C8BA0: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8BAC: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000C8BB0: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000C8BB8: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000C8BC4: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C8BCC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C8BD0: BE882006
	s_cbranch_execz 64138                                      // 0000000C8BD4: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3300>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 0000000C8BD8: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000C8BE4: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000C8BEC: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000C8BF0: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8BF4: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000C8BF8: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000C8C00: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000C8C0C: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C8C10: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000C8C14: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000C8C18: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000C8C20: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C8C28: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000C8C2C: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000C8C30: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000C8C34: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8C38: BF870095
	.long 0xd71c006a                                           // 0000000C8C3C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000C8C40: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000C8C44: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000C8C48: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8C50: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 0000000C8C54: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000C8C60: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8C64: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000C8C68: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000C8C70: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8C74: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000C8C78: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000C8C80: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000C8C84: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8C8C: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000C8C90: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 0000000C8C94: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8C9C: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 0000000C8CA0: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 0000000C8CA4: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8CAC: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000C8CB0: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000C8CB8: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 0000000C8CC0: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8CCC: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000C8CD0: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000C8CD8: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000C8CE4: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C8CEC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C8CF0: BE882007
	s_cbranch_execz 64069                                      // 0000000C8CF4: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x330c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 0000000C8CF8: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000C8D04: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000C8D0C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000C8D10: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8D14: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000C8D18: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000C8D20: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000C8D2C: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C8D30: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000C8D34: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000C8D38: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000C8D40: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C8D48: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000C8D4C: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000C8D50: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000C8D54: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8D58: BF870095
	.long 0xd71c006a                                           // 0000000C8D5C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000C8D60: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000C8D64: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000C8D68: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8D70: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 0000000C8D74: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000C8D80: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8D84: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000C8D88: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000C8D90: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8D94: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000C8D98: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000C8DA0: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000C8DA4: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8DAC: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000C8DB0: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 0000000C8DB4: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8DBC: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 0000000C8DC0: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 0000000C8DC4: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8DCC: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000C8DD0: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000C8DD8: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 0000000C8DE0: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8DEC: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000C8DF0: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000C8DF8: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000C8E04: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C8E0C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C8E10: BE882000
	s_cbranch_execz 64000                                      // 0000000C8E14: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3318>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 0000000C8E18: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 0000000C8E24: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 0000000C8E28: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000C8E30: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000C8E34: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8E38: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000C8E3C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000C8E44: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000C8E50: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C8E54: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000C8E58: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000C8E5C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000C8E64: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C8E6C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000C8E70: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000C8E74: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000C8E78: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8E7C: BF870095
	.long 0xd71c006a                                           // 0000000C8E80: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000C8E84: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000C8E88: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000C8E8C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8E94: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000000C8E98: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000C8EA0: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8EA4: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 0000000C8EA8: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 0000000C8EB0: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8EB4: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 0000000C8EB8: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 0000000C8EC0: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 0000000C8EC4: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8ECC: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 0000000C8ED0: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 0000000C8ED4: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8EDC: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 0000000C8EE0: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 0000000C8EE4: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8EEC: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 0000000C8EF0: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 0000000C8EF8: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 0000000C8F00: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8F0C: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 0000000C8F10: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 0000000C8F18: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 0000000C8F24: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C8F2C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C8F30: BE882001
	s_cbranch_execz 63931                                      // 0000000C8F34: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3324>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 0000000C8F38: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 0000000C8F44: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 0000000C8F48: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 0000000C8F50: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000C8F54: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C8F58: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 0000000C8F5C: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000C8F64: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 0000000C8F6C: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000000C8F78: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C8F7C: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 0000000C8F80: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 0000000C8F88: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C8F8C: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000000C8F90: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000000C8F94: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000000C8F98: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8F9C: BF870095
	.long 0xd71c0069                                           // 0000000C8FA0: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000000C8FA4: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000000C8FA8: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000C8FAC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8FB4: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 0000000C8FB8: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000C8FC0: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8FC4: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 0000000C8FC8: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 0000000C8FD0: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8FD4: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 0000000C8FD8: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 0000000C8FE0: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 0000000C8FE4: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8FEC: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 0000000C8FF0: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 0000000C8FF4: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8FFC: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 0000000C9000: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 0000000C9004: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C900C: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 0000000C9010: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 0000000C9018: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 0000000C9020: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C902C: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 0000000C9030: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 0000000C9038: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 0000000C9044: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C904C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C9050: BE882002
	s_cbranch_execz 63862                                      // 0000000C9054: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3330>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 0000000C9058: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000C9064: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000C906C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000C9070: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9074: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000C9078: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 0000000C9080: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 0000000C908C: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C9090: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 0000000C9094: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000C9098: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 0000000C90A0: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C90A8: BF870121
	v_add_f32_e32 v98, v98, v105                               // 0000000C90AC: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 0000000C90B0: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 0000000C90B4: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C90B8: BF870095
	.long 0xd71c0062                                           // 0000000C90BC: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 0000000C90C0: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000C90C4: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000C90C8: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C90D0: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 0000000C90D4: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000C90E0: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C90E4: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000C90E8: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 0000000C90F0: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C90F4: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 0000000C90F8: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 0000000C9100: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 0000000C9104: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C910C: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 0000000C9110: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 0000000C9114: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C911C: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 0000000C9120: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 0000000C9124: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C912C: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 0000000C9130: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000C9138: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 0000000C9140: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C914C: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 0000000C9150: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 0000000C9158: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000C9164: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C916C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C9170: BE882003
	s_cbranch_execz 63793                                      // 0000000C9174: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x333c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 0000000C9178: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000C9184: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000C918C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000C9190: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9194: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000C9198: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000C91A0: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 0000000C91AC: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C91B0: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 0000000C91B4: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 0000000C91C0: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 0000000C91C4: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000C91C8: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C91D0: BF870293
	v_exp_f32_e32 v98, v98                                     // 0000000C91D4: 7EC44B62
	.long 0xd71c0062                                           // 0000000C91D8: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000C91DC: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C91E0: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000C91E4: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000C91E8: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 0000000C91F0: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C91FC: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 0000000C9200: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000C9204: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C920C: BF870291
	v_rcp_f32_e32 v100, v99                                    // 0000000C9210: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 0000000C9214: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C921C: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 0000000C9220: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 0000000C9224: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 0000000C922C: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9230: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 0000000C9234: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 0000000C923C: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9240: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 0000000C9244: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 0000000C924C: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C9254: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000C9258: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 0000000C9260: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000C926C: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C9274: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000C9278: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000C9284: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C928C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C9290: BE882004
	s_cbranch_execz 63724                                      // 0000000C9294: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3348>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 0000000C9298: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000C92A4: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000C92AC: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000C92B0: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C92B4: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000C92B8: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000C92C0: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000C92CC: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C92D0: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000C92D4: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000C92D8: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000C92E0: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C92E8: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000C92EC: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000C92F0: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000C92F4: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C92F8: BF870095
	.long 0xd71c0062                                           // 0000000C92FC: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000C9300: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000C9304: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000C9308: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9310: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 0000000C9314: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000C9320: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9324: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000C9328: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000C9330: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9334: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000C9338: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000C9340: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000C9344: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C934C: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 0000000C9350: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 0000000C9354: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C935C: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 0000000C9360: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 0000000C9364: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C936C: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 0000000C9370: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000C9378: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 0000000C9380: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C938C: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000C9390: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000C9398: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000C93A4: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C93AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C93B0: BE882005
	s_cbranch_execz 63655                                      // 0000000C93B4: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3354>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 0000000C93B8: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000C93C4: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000C93CC: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000C93D0: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C93D4: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000C93D8: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000C93E0: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000C93EC: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C93F0: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000C93F4: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000C93F8: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000C9400: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C9408: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000C940C: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000C9410: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000C9414: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9418: BF870095
	.long 0xd71c0062                                           // 0000000C941C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000C9420: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000C9424: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000C9428: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9430: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000C9434: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 0000000C943C: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9444: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000C9448: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000C9450: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9454: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000C9458: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000C9460: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000C9464: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C946C: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000C9470: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 0000000C9474: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C947C: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 0000000C9480: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 0000000C9484: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C948C: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000C9490: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000C9498: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 0000000C94A0: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C94AC: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000C94B0: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000C94B8: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000C94C4: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C94CC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C94D0: BE882006
	s_cbranch_execz 63586                                      // 0000000C94D4: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3360>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 0000000C94D8: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000C94E4: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000C94EC: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000C94F0: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C94F4: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000C94F8: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000C9500: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000C950C: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C9510: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000C9514: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000C9518: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000C9520: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C9528: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000C952C: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000C9530: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000C9534: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9538: BF870095
	.long 0xd71c0062                                           // 0000000C953C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000C9540: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000C9544: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000C9548: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9550: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 0000000C9554: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000C9560: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9564: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000C9568: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000C9570: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9574: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000C9578: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000C9580: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000C9584: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C958C: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000C9590: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000C9594: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C959C: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000C95A0: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000C95A4: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C95AC: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000C95B0: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000C95B8: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 0000000C95C0: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C95CC: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000C95D0: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000C95D8: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000C95E4: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C95EC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C95F0: BE882007
	s_cbranch_execz 63517                                      // 0000000C95F4: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x336c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 0000000C95F8: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000C9604: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000C960C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000C9610: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9614: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000C9618: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000C9620: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000C962C: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C9630: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000C9634: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000C9638: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000C9640: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C9648: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000C964C: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000C9650: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000C9654: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9658: BF870095
	.long 0xd71c0062                                           // 0000000C965C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000C9660: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000C9664: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000C9668: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9670: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 0000000C9674: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000C9680: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9684: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000C9688: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000C9690: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9694: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000C9698: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000C96A0: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000C96A4: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C96AC: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000C96B0: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000C96B4: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C96BC: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000C96C0: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000C96C4: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C96CC: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000C96D0: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000C96D8: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 0000000C96E0: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C96EC: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000C96F0: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000C96F8: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000C9704: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C970C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000C9710: BE882000
	s_cbranch_execz 63448                                      // 0000000C9714: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3378>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 0000000C9718: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 0000000C9724: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 0000000C9728: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000C9730: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000C9734: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9738: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000C973C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000C9744: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000C9750: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C9754: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000C9758: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000C975C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000C9764: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C976C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000C9770: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000C9774: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000C9778: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C977C: BF870095
	.long 0xd71c0062                                           // 0000000C9780: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000C9784: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000C9788: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000C978C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9794: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000C9798: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000C97A0: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C97A4: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 0000000C97A8: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 0000000C97B0: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C97B4: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000000C97B8: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 0000000C97C0: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 0000000C97C4: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C97CC: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 0000000C97D0: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 0000000C97D4: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C97DC: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 0000000C97E0: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 0000000C97E4: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C97EC: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 0000000C97F0: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 0000000C97F8: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 0000000C9800: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C980C: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 0000000C9810: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 0000000C9818: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 0000000C9824: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C982C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000C9830: BE882001
	s_cbranch_execz 63379                                      // 0000000C9834: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3384>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 0000000C9838: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 0000000C9844: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 0000000C9848: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 0000000C9850: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000C9854: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C9858: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 0000000C985C: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000C9864: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 0000000C986C: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000000C9878: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C987C: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 0000000C9880: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 0000000C9888: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C988C: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000000C9890: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000000C9894: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000000C9898: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C989C: BF870095
	.long 0xd71c0061                                           // 0000000C98A0: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000000C98A4: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000C98A8: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000C98AC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C98B4: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 0000000C98B8: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000C98C0: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C98C4: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 0000000C98C8: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 0000000C98D0: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C98D4: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 0000000C98D8: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 0000000C98E0: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 0000000C98E4: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C98EC: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 0000000C98F0: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 0000000C98F4: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C98FC: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 0000000C9900: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 0000000C9904: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C990C: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 0000000C9910: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 0000000C9918: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 0000000C9920: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C992C: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 0000000C9930: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 0000000C9938: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 0000000C9944: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C994C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000C9950: BE882002
	s_cbranch_execz 63310                                      // 0000000C9954: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3390>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 0000000C9958: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000C9964: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000C996C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000C9970: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9974: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000C9978: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 0000000C9980: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 0000000C998C: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C9990: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 0000000C9994: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000C9998: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 0000000C99A0: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C99A8: BF870121
	v_add_f32_e32 v90, v90, v97                                // 0000000C99AC: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 0000000C99B0: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 0000000C99B4: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C99B8: BF870095
	.long 0xd71c005a                                           // 0000000C99BC: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 0000000C99C0: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000C99C4: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000C99C8: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C99D0: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 0000000C99D4: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000C99E0: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C99E4: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000C99E8: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 0000000C99F0: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C99F4: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 0000000C99F8: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 0000000C9A00: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 0000000C9A04: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9A0C: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 0000000C9A10: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 0000000C9A14: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9A1C: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 0000000C9A20: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 0000000C9A24: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9A2C: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 0000000C9A30: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000C9A38: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 0000000C9A40: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9A4C: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 0000000C9A50: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 0000000C9A58: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000C9A64: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C9A6C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000C9A70: BE882003
	s_cbranch_execz 63241                                      // 0000000C9A74: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x339c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 0000000C9A78: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000C9A84: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000C9A8C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000C9A90: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9A94: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000C9A98: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000C9AA0: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 0000000C9AAC: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9AB0: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 0000000C9AB4: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 0000000C9AC0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 0000000C9AC4: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000C9AC8: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C9AD0: BF870293
	v_exp_f32_e32 v90, v90                                     // 0000000C9AD4: 7EB44B5A
	.long 0xd71c005a                                           // 0000000C9AD8: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000C9ADC: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C9AE0: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000C9AE4: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000C9AE8: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 0000000C9AF0: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9AFC: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 0000000C9B00: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000C9B04: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C9B0C: BF870291
	v_rcp_f32_e32 v92, v91                                     // 0000000C9B10: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 0000000C9B14: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C9B1C: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 0000000C9B20: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 0000000C9B24: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 0000000C9B2C: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9B30: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 0000000C9B34: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 0000000C9B3C: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9B40: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 0000000C9B44: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 0000000C9B4C: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C9B54: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000C9B58: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 0000000C9B60: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000C9B6C: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C9B74: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000C9B78: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000C9B84: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C9B8C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000C9B90: BE882004
	s_cbranch_execz 63172                                      // 0000000C9B94: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33a8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 0000000C9B98: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000C9BA4: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000C9BAC: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000C9BB0: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9BB4: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000C9BB8: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000C9BC0: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000C9BCC: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C9BD0: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000C9BD4: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000C9BD8: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000C9BE0: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C9BE8: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000C9BEC: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000C9BF0: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000C9BF4: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9BF8: BF870095
	.long 0xd71c005a                                           // 0000000C9BFC: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000C9C00: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000C9C04: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000C9C08: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9C10: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 0000000C9C14: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000C9C20: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9C24: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000C9C28: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000C9C30: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9C34: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000C9C38: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000C9C40: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000C9C44: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9C4C: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 0000000C9C50: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 0000000C9C54: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9C5C: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 0000000C9C60: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 0000000C9C64: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9C6C: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 0000000C9C70: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000C9C78: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 0000000C9C80: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9C8C: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000C9C90: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000C9C98: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000C9CA4: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C9CAC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000C9CB0: BE882005
	s_cbranch_execz 63103                                      // 0000000C9CB4: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33b4>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 0000000C9CB8: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000C9CC4: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000C9CCC: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000C9CD0: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9CD4: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000C9CD8: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000C9CE0: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000C9CEC: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C9CF0: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000C9CF4: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000C9CF8: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000C9D00: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C9D08: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000C9D0C: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000C9D10: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000C9D14: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9D18: BF870095
	.long 0xd71c005a                                           // 0000000C9D1C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000C9D20: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000C9D24: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000C9D28: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9D30: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000000C9D34: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 0000000C9D3C: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9D44: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000C9D48: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000C9D50: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9D54: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000C9D58: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000C9D60: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000C9D64: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9D6C: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000C9D70: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 0000000C9D74: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9D7C: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 0000000C9D80: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 0000000C9D84: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9D8C: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000C9D90: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000C9D98: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 0000000C9DA0: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9DAC: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000C9DB0: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000C9DB8: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000C9DC4: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C9DCC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000C9DD0: BE882006
	s_cbranch_execz 63034                                      // 0000000C9DD4: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33c0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 0000000C9DD8: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000C9DE4: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000C9DEC: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000C9DF0: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9DF4: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000C9DF8: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000C9E00: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000C9E0C: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C9E10: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000C9E14: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000C9E18: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000C9E20: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C9E28: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000C9E2C: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000C9E30: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000C9E34: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9E38: BF870095
	.long 0xd71c005a                                           // 0000000C9E3C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000C9E40: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000C9E44: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000C9E48: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9E50: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 0000000C9E54: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000C9E60: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9E64: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000C9E68: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000C9E70: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9E74: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000C9E78: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000C9E80: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000C9E84: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9E8C: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000C9E90: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000000C9E94: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9E9C: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000000C9EA0: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000000C9EA4: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9EAC: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000C9EB0: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000C9EB8: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 0000000C9EC0: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9ECC: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000C9ED0: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000C9ED8: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000C9EE4: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000C9EEC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000C9EF0: BE882007
	s_cbranch_execz 62965                                      // 0000000C9EF4: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33cc>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 0000000C9EF8: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000C9F04: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000C9F0C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000C9F10: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9F14: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000C9F18: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000C9F20: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000C9F2C: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000C9F30: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000C9F34: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000C9F38: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000C9F40: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C9F48: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000C9F4C: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000C9F50: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000C9F54: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9F58: BF870095
	.long 0xd71c005a                                           // 0000000C9F5C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000C9F60: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000C9F64: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000C9F68: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9F70: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 0000000C9F74: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000C9F80: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9F84: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000C9F88: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000C9F90: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9F94: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000C9F98: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000C9FA0: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000C9FA4: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9FAC: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000C9FB0: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000000C9FB4: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9FBC: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000000C9FC0: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000000C9FC4: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9FCC: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000C9FD0: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000C9FD8: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 0000000C9FE0: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9FEC: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000C9FF0: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000C9FF8: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000CA004: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CA00C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000CA010: BE882000
	s_cbranch_execz 62896                                      // 0000000CA014: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33d8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 0000000CA018: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 0000000CA024: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 0000000CA028: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000CA030: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000CA034: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA038: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000CA03C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000CA044: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000CA050: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CA054: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000CA058: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000CA05C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000CA064: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CA06C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000CA070: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000CA074: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000CA078: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA07C: BF870095
	.long 0xd71c005a                                           // 0000000CA080: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000CA084: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000CA088: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000CA08C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA094: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000000CA098: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000CA0A0: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA0A4: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 0000000CA0A8: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 0000000CA0B0: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA0B4: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 0000000CA0B8: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 0000000CA0C0: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 0000000CA0C4: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA0CC: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 0000000CA0D0: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 0000000CA0D4: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA0DC: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 0000000CA0E0: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 0000000CA0E4: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA0EC: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 0000000CA0F0: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 0000000CA0F8: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 0000000CA100: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA10C: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 0000000CA110: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 0000000CA118: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 0000000CA124: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CA12C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000CA130: BE882001
	s_cbranch_execz 62827                                      // 0000000CA134: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33e4>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 0000000CA138: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 0000000CA144: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 0000000CA148: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 0000000CA150: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000CA154: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CA158: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 0000000CA15C: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000CA164: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 0000000CA16C: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000000CA178: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000CA17C: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 0000000CA180: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 0000000CA188: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CA18C: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000000CA190: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000000CA194: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000000CA198: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA19C: BF870095
	.long 0xd71c0059                                           // 0000000CA1A0: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000000CA1A4: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000CA1A8: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000CA1AC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA1B4: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 0000000CA1B8: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000CA1C0: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA1C4: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 0000000CA1C8: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 0000000CA1D0: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA1D4: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 0000000CA1D8: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 0000000CA1E0: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 0000000CA1E4: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA1EC: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 0000000CA1F0: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 0000000CA1F4: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA1FC: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 0000000CA200: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 0000000CA204: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA20C: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 0000000CA210: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 0000000CA218: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 0000000CA220: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA22C: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 0000000CA230: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 0000000CA238: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 0000000CA244: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CA24C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000CA250: BE882002
	s_cbranch_execz 62758                                      // 0000000CA254: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33f0>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 0000000CA258: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000CA264: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000CA26C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000CA270: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA274: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000CA278: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 0000000CA280: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 0000000CA28C: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CA290: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 0000000CA294: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000CA298: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 0000000CA2A0: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CA2A8: BF870121
	v_add_f32_e32 v82, v82, v89                                // 0000000CA2AC: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 0000000CA2B0: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 0000000CA2B4: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA2B8: BF870095
	.long 0xd71c0052                                           // 0000000CA2BC: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 0000000CA2C0: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000CA2C4: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000CA2C8: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA2D0: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 0000000CA2D4: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000CA2E0: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA2E4: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000CA2E8: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 0000000CA2F0: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA2F4: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 0000000CA2F8: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 0000000CA300: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 0000000CA304: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA30C: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 0000000CA310: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 0000000CA314: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA31C: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 0000000CA320: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 0000000CA324: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA32C: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 0000000CA330: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000CA338: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 0000000CA340: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA34C: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 0000000CA350: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 0000000CA358: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000CA364: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CA36C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000CA370: BE882003
	s_cbranch_execz 62689                                      // 0000000CA374: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33fc>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 0000000CA378: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000CA384: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000CA38C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000CA390: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA394: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000CA398: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000CA3A0: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 0000000CA3AC: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA3B0: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 0000000CA3B4: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 0000000CA3C0: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 0000000CA3C4: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000CA3C8: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CA3D0: BF870293
	v_exp_f32_e32 v82, v82                                     // 0000000CA3D4: 7EA44B52
	.long 0xd71c0052                                           // 0000000CA3D8: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000CA3DC: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CA3E0: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000CA3E4: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000CA3E8: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 0000000CA3F0: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA3FC: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 0000000CA400: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000CA404: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CA40C: BF870291
	v_rcp_f32_e32 v84, v83                                     // 0000000CA410: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 0000000CA414: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CA41C: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 0000000CA420: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 0000000CA424: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 0000000CA42C: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA430: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 0000000CA434: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 0000000CA43C: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA440: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 0000000CA444: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 0000000CA44C: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CA454: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000CA458: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 0000000CA460: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000CA46C: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CA474: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000CA478: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000CA484: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CA48C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000CA490: BE882004
	s_cbranch_execz 62620                                      // 0000000CA494: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3408>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 0000000CA498: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000CA4A4: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000CA4AC: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000CA4B0: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA4B4: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000CA4B8: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000CA4C0: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000CA4CC: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CA4D0: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000CA4D4: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000CA4D8: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000CA4E0: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CA4E8: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000CA4EC: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000CA4F0: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000CA4F4: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA4F8: BF870095
	.long 0xd71c0052                                           // 0000000CA4FC: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000CA500: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000CA504: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000CA508: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA510: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 0000000CA514: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000CA520: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA524: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000CA528: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000CA530: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA534: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000CA538: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000CA540: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000CA544: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA54C: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 0000000CA550: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 0000000CA554: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA55C: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 0000000CA560: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 0000000CA564: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA56C: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 0000000CA570: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000CA578: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 0000000CA580: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA58C: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000CA590: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000CA598: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000CA5A4: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CA5AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000CA5B0: BE882005
	s_cbranch_execz 62551                                      // 0000000CA5B4: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3414>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 0000000CA5B8: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000CA5C4: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000CA5CC: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000CA5D0: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA5D4: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000CA5D8: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000CA5E0: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000CA5EC: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CA5F0: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000CA5F4: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000CA5F8: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000CA600: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CA608: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000CA60C: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000CA610: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000CA614: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA618: BF870095
	.long 0xd71c0052                                           // 0000000CA61C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000CA620: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000CA624: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000CA628: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA630: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 0000000CA634: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 0000000CA63C: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA644: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000CA648: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000CA650: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA654: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000CA658: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000CA660: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000CA664: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA66C: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000CA670: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 0000000CA674: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA67C: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 0000000CA680: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 0000000CA684: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA68C: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000CA690: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000CA698: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 0000000CA6A0: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA6AC: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000CA6B0: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000CA6B8: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000CA6C4: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CA6CC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000CA6D0: BE882006
	s_cbranch_execz 62482                                      // 0000000CA6D4: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3420>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 0000000CA6D8: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000CA6E4: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000CA6EC: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000CA6F0: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA6F4: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000CA6F8: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000CA700: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000CA70C: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CA710: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000CA714: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000CA718: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000CA720: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CA728: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000CA72C: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000CA730: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000CA734: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA738: BF870095
	.long 0xd71c0052                                           // 0000000CA73C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000CA740: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000CA744: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000CA748: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA750: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 0000000CA754: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000CA760: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA764: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000CA768: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000CA770: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA774: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000CA778: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000CA780: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000CA784: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA78C: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000CA790: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000CA794: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA79C: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000CA7A0: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000CA7A4: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA7AC: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000CA7B0: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000CA7B8: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 0000000CA7C0: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA7CC: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000CA7D0: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000CA7D8: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000CA7E4: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CA7EC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000CA7F0: BE882007
	s_cbranch_execz 62413                                      // 0000000CA7F4: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x342c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 0000000CA7F8: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000CA804: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000CA80C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000CA810: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA814: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000CA818: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000CA820: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000CA82C: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CA830: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000CA834: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000CA838: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000CA840: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CA848: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000CA84C: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000CA850: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000CA854: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA858: BF870095
	.long 0xd71c0052                                           // 0000000CA85C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000CA860: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000CA864: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000CA868: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA870: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 0000000CA874: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000CA880: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA884: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000CA888: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000CA890: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA894: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000CA898: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000CA8A0: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000CA8A4: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA8AC: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000CA8B0: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000CA8B4: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA8BC: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000CA8C0: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000CA8C4: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA8CC: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000CA8D0: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000CA8D8: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 0000000CA8E0: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA8EC: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000CA8F0: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000CA8F8: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000CA904: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CA90C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000CA910: BE882000
	s_cbranch_execz 62344                                      // 0000000CA914: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3438>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 0000000CA918: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 0000000CA924: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 0000000CA928: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000CA930: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000CA934: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA938: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000CA93C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000CA944: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000CA950: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CA954: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000CA958: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000CA95C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000CA964: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CA96C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000CA970: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000CA974: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000CA978: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA97C: BF870095
	.long 0xd71c0052                                           // 0000000CA980: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000CA984: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000CA988: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000CA98C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA994: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 0000000CA998: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000CA9A0: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA9A4: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 0000000CA9A8: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 0000000CA9B0: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA9B4: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 0000000CA9B8: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 0000000CA9C0: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 0000000CA9C4: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA9CC: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 0000000CA9D0: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 0000000CA9D4: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA9DC: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 0000000CA9E0: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 0000000CA9E4: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA9EC: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 0000000CA9F0: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 0000000CA9F8: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 0000000CAA00: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAA0C: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 0000000CAA10: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 0000000CAA18: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 0000000CAA24: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CAA2C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000CAA30: BE882001
	s_cbranch_execz 62275                                      // 0000000CAA34: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3444>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 0000000CAA38: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 0000000CAA44: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 0000000CAA48: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 0000000CAA50: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000CAA54: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CAA58: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 0000000CAA5C: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000CAA64: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 0000000CAA6C: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 0000000CAA78: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000CAA7C: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 0000000CAA80: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 0000000CAA88: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CAA8C: BF870121
	v_add_f32_e32 v81, v81, v82                                // 0000000CAA90: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 0000000CAA94: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 0000000CAA98: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAA9C: BF870095
	.long 0xd71c0051                                           // 0000000CAAA0: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000000CAAA4: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000CAAA8: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000CAAAC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAAB4: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 0000000CAAB8: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000CAAC0: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAAC4: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 0000000CAAC8: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 0000000CAAD0: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAAD4: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 0000000CAAD8: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 0000000CAAE0: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 0000000CAAE4: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAAEC: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 0000000CAAF0: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 0000000CAAF4: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAAFC: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 0000000CAB00: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 0000000CAB04: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAB0C: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 0000000CAB10: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 0000000CAB18: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 0000000CAB20: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAB2C: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 0000000CAB30: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 0000000CAB38: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 0000000CAB44: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CAB4C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000CAB50: BE882002
	s_cbranch_execz 62206                                      // 0000000CAB54: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3450>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 0000000CAB58: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000CAB64: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000CAB6C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000CAB70: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAB74: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000CAB78: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 0000000CAB80: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 0000000CAB8C: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CAB90: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 0000000CAB94: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000CAB98: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 0000000CABA0: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CABA8: BF870121
	v_add_f32_e32 v74, v74, v81                                // 0000000CABAC: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 0000000CABB0: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 0000000CABB4: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CABB8: BF870095
	.long 0xd71c004a                                           // 0000000CABBC: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 0000000CABC0: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000CABC4: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000CABC8: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CABD0: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 0000000CABD4: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000CABE0: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CABE4: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000CABE8: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 0000000CABF0: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CABF4: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 0000000CABF8: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 0000000CAC00: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 0000000CAC04: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAC0C: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 0000000CAC10: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 0000000CAC14: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAC1C: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 0000000CAC20: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 0000000CAC24: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAC2C: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 0000000CAC30: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000CAC38: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 0000000CAC40: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAC4C: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 0000000CAC50: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 0000000CAC58: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000CAC64: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CAC6C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000CAC70: BE882003
	s_cbranch_execz 62137                                      // 0000000CAC74: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x345c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 0000000CAC78: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000CAC84: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000CAC8C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000CAC90: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAC94: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000CAC98: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000CACA0: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 0000000CACAC: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CACB0: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 0000000CACB4: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 0000000CACC0: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 0000000CACC4: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000CACC8: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CACD0: BF870293
	v_exp_f32_e32 v74, v74                                     // 0000000CACD4: 7E944B4A
	.long 0xd71c004a                                           // 0000000CACD8: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000CACDC: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CACE0: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000CACE4: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000CACE8: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 0000000CACF0: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CACFC: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 0000000CAD00: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000CAD04: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CAD0C: BF870291
	v_rcp_f32_e32 v76, v75                                     // 0000000CAD10: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 0000000CAD14: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CAD1C: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 0000000CAD20: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 0000000CAD24: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 0000000CAD2C: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAD30: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 0000000CAD34: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 0000000CAD3C: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAD40: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 0000000CAD44: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 0000000CAD4C: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CAD54: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000CAD58: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 0000000CAD60: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000CAD6C: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CAD74: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000CAD78: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000CAD84: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CAD8C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000CAD90: BE882004
	s_cbranch_execz 62068                                      // 0000000CAD94: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3468>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 0000000CAD98: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000CADA4: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000CADAC: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000CADB0: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CADB4: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000CADB8: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000CADC0: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000CADCC: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CADD0: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000CADD4: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000CADD8: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000CADE0: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CADE8: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000CADEC: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000CADF0: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000CADF4: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CADF8: BF870095
	.long 0xd71c004a                                           // 0000000CADFC: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000CAE00: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000CAE04: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000CAE08: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAE10: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 0000000CAE14: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000CAE20: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAE24: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000CAE28: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000CAE30: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAE34: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000CAE38: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000CAE40: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000CAE44: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAE4C: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 0000000CAE50: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 0000000CAE54: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAE5C: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 0000000CAE60: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 0000000CAE64: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAE6C: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 0000000CAE70: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000CAE78: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 0000000CAE80: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAE8C: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000CAE90: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000CAE98: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000CAEA4: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CAEAC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000CAEB0: BE882005
	s_cbranch_execz 61999                                      // 0000000CAEB4: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3474>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 0000000CAEB8: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000CAEC4: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000CAECC: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000CAED0: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAED4: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000CAED8: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000CAEE0: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000CAEEC: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CAEF0: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000CAEF4: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000CAEF8: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000CAF00: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CAF08: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000CAF0C: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000CAF10: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000CAF14: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAF18: BF870095
	.long 0xd71c004a                                           // 0000000CAF1C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000CAF20: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000CAF24: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000CAF28: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAF30: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000000CAF34: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 0000000CAF3C: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAF44: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000CAF48: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000CAF50: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAF54: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000CAF58: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000CAF60: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000CAF64: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAF6C: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000CAF70: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 0000000CAF74: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAF7C: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 0000000CAF80: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 0000000CAF84: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAF8C: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000CAF90: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000CAF98: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 0000000CAFA0: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAFAC: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000CAFB0: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000CAFB8: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000CAFC4: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CAFCC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000CAFD0: BE882006
	s_cbranch_execz 61930                                      // 0000000CAFD4: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3480>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 0000000CAFD8: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000CAFE4: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000CAFEC: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000CAFF0: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CAFF4: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000CAFF8: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000CB000: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000CB00C: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CB010: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000CB014: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000CB018: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000CB020: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CB028: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000CB02C: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000CB030: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000CB034: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB038: BF870095
	.long 0xd71c004a                                           // 0000000CB03C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000CB040: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000CB044: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000CB048: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB050: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 0000000CB054: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000CB060: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB064: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000CB068: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000CB070: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB074: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000CB078: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000CB080: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000CB084: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB08C: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000CB090: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000CB094: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB09C: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000CB0A0: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000CB0A4: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB0AC: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000CB0B0: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000CB0B8: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 0000000CB0C0: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB0CC: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000CB0D0: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000CB0D8: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000CB0E4: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CB0EC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000CB0F0: BE882007
	s_cbranch_execz 61861                                      // 0000000CB0F4: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x348c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 0000000CB0F8: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000CB104: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000CB10C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000CB110: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB114: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000CB118: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000CB120: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000CB12C: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CB130: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000CB134: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000CB138: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000CB140: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CB148: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000CB14C: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000CB150: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000CB154: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB158: BF870095
	.long 0xd71c004a                                           // 0000000CB15C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000CB160: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000CB164: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000CB168: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB170: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 0000000CB174: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000CB180: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB184: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000CB188: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000CB190: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB194: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000CB198: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000CB1A0: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000CB1A4: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB1AC: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000CB1B0: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000CB1B4: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB1BC: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000CB1C0: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000CB1C4: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB1CC: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000CB1D0: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000CB1D8: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 0000000CB1E0: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB1EC: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000CB1F0: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000CB1F8: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000CB204: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CB20C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000CB210: BE882000
	s_cbranch_execz 61792                                      // 0000000CB214: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3498>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 0000000CB218: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 0000000CB224: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 0000000CB228: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000CB230: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000CB234: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB238: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000CB23C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000CB244: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000CB250: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CB254: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000CB258: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000CB25C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000CB264: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CB26C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000CB270: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000CB274: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000CB278: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB27C: BF870095
	.long 0xd71c004a                                           // 0000000CB280: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000CB284: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000CB288: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000CB28C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB294: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000000CB298: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000CB2A0: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB2A4: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 0000000CB2A8: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 0000000CB2B0: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB2B4: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000000CB2B8: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000000CB2C0: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 0000000CB2C4: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB2CC: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 0000000CB2D0: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 0000000CB2D4: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB2DC: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 0000000CB2E0: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 0000000CB2E4: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB2EC: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 0000000CB2F0: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 0000000CB2F8: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 0000000CB300: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB30C: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 0000000CB310: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 0000000CB318: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 0000000CB324: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CB32C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000CB330: BE882001
	s_cbranch_execz 61723                                      // 0000000CB334: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34a4>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 0000000CB338: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 0000000CB344: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 0000000CB348: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 0000000CB350: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000CB354: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CB358: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 0000000CB35C: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000CB364: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 0000000CB36C: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000000CB378: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000CB37C: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 0000000CB380: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 0000000CB388: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CB38C: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000000CB390: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000000CB394: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000000CB398: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB39C: BF870095
	.long 0xd71c0049                                           // 0000000CB3A0: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000CB3A4: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000CB3A8: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000CB3AC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB3B4: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 0000000CB3B8: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000CB3C0: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB3C4: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 0000000CB3C8: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 0000000CB3D0: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB3D4: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 0000000CB3D8: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 0000000CB3E0: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 0000000CB3E4: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB3EC: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 0000000CB3F0: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 0000000CB3F4: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB3FC: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 0000000CB400: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 0000000CB404: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB40C: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 0000000CB410: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 0000000CB418: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 0000000CB420: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB42C: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 0000000CB430: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 0000000CB438: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 0000000CB444: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CB44C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000CB450: BE882002
	s_cbranch_execz 61654                                      // 0000000CB454: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34b0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 0000000CB458: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000CB464: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000CB46C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000CB470: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB474: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000CB478: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 0000000CB480: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 0000000CB48C: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CB490: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 0000000CB494: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000CB498: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 0000000CB4A0: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CB4A8: BF870121
	v_add_f32_e32 v66, v66, v73                                // 0000000CB4AC: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 0000000CB4B0: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 0000000CB4B4: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB4B8: BF870095
	.long 0xd71c0042                                           // 0000000CB4BC: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 0000000CB4C0: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000CB4C4: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000CB4C8: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB4D0: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 0000000CB4D4: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000CB4E0: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB4E4: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000CB4E8: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 0000000CB4F0: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB4F4: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 0000000CB4F8: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 0000000CB500: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 0000000CB504: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB50C: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 0000000CB510: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 0000000CB514: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB51C: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 0000000CB520: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 0000000CB524: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB52C: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 0000000CB530: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000CB538: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 0000000CB540: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB54C: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 0000000CB550: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 0000000CB558: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000CB564: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CB56C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000CB570: BE882003
	s_cbranch_execz 61585                                      // 0000000CB574: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34bc>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 0000000CB578: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000CB584: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000CB58C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000CB590: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB594: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000CB598: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000CB5A0: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 0000000CB5AC: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB5B0: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 0000000CB5B4: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 0000000CB5C0: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 0000000CB5C4: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000CB5C8: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CB5D0: BF870293
	v_exp_f32_e32 v66, v66                                     // 0000000CB5D4: 7E844B42
	.long 0xd71c0042                                           // 0000000CB5D8: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000CB5DC: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CB5E0: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000CB5E4: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000CB5E8: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 0000000CB5F0: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB5FC: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 0000000CB600: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000CB604: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CB60C: BF870291
	v_rcp_f32_e32 v68, v67                                     // 0000000CB610: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 0000000CB614: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CB61C: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 0000000CB620: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 0000000CB624: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 0000000CB62C: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB630: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 0000000CB634: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 0000000CB63C: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB640: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 0000000CB644: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 0000000CB64C: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CB654: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000CB658: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 0000000CB660: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000CB66C: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CB674: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000CB678: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000CB684: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CB68C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000CB690: BE882004
	s_cbranch_execz 61516                                      // 0000000CB694: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34c8>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 0000000CB698: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000CB6A4: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000CB6AC: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000CB6B0: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB6B4: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000CB6B8: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000CB6C0: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000CB6CC: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CB6D0: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000CB6D4: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000CB6D8: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000CB6E0: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CB6E8: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000CB6EC: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000CB6F0: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000CB6F4: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB6F8: BF870095
	.long 0xd71c0042                                           // 0000000CB6FC: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000CB700: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000CB704: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000CB708: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB710: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 0000000CB714: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000CB720: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB724: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000CB728: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000CB730: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB734: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000CB738: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000CB740: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000CB744: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB74C: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 0000000CB750: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 0000000CB754: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB75C: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 0000000CB760: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 0000000CB764: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB76C: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 0000000CB770: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000CB778: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 0000000CB780: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB78C: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000CB790: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000CB798: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000CB7A4: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CB7AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000CB7B0: BE882005
	s_cbranch_execz 61447                                      // 0000000CB7B4: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34d4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 0000000CB7B8: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000CB7C4: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000CB7CC: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000CB7D0: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB7D4: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000CB7D8: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000CB7E0: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000CB7EC: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CB7F0: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000CB7F4: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000CB7F8: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000CB800: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CB808: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000CB80C: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000CB810: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000CB814: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB818: BF870095
	.long 0xd71c0042                                           // 0000000CB81C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000CB820: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000CB824: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000CB828: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB830: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 0000000CB834: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 0000000CB83C: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB844: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000CB848: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000CB850: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB854: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000CB858: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000CB860: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000CB864: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB86C: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000CB870: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 0000000CB874: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB87C: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 0000000CB880: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 0000000CB884: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB88C: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000CB890: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000CB898: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 0000000CB8A0: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB8AC: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000CB8B0: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000CB8B8: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000CB8C4: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CB8CC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000CB8D0: BE882006
	s_cbranch_execz 61378                                      // 0000000CB8D4: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34e0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 0000000CB8D8: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000CB8E4: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000CB8EC: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000CB8F0: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB8F4: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000CB8F8: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000CB900: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000CB90C: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CB910: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000CB914: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000CB918: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000CB920: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CB928: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000CB92C: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000CB930: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000CB934: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB938: BF870095
	.long 0xd71c0042                                           // 0000000CB93C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000CB940: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000CB944: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000CB948: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB950: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 0000000CB954: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000CB960: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB964: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000CB968: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000CB970: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB974: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000CB978: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000CB980: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000CB984: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB98C: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000CB990: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000CB994: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB99C: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000CB9A0: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000CB9A4: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB9AC: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000CB9B0: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000CB9B8: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 0000000CB9C0: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CB9CC: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000CB9D0: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000CB9D8: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000CB9E4: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CB9EC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000CB9F0: BE882007
	s_cbranch_execz 61309                                      // 0000000CB9F4: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34ec>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 0000000CB9F8: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000CBA04: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000CBA0C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000CBA10: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBA14: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000CBA18: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000CBA20: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000CBA2C: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CBA30: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000CBA34: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000CBA38: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000CBA40: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CBA48: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000CBA4C: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000CBA50: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000CBA54: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBA58: BF870095
	.long 0xd71c0042                                           // 0000000CBA5C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000CBA60: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000CBA64: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000CBA68: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBA70: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 0000000CBA74: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000CBA80: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBA84: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000CBA88: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000CBA90: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBA94: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000CBA98: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000CBAA0: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000CBAA4: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBAAC: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000CBAB0: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000CBAB4: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBABC: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000CBAC0: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000CBAC4: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBACC: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000CBAD0: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000CBAD8: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 0000000CBAE0: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBAEC: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000CBAF0: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000CBAF8: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000CBB04: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CBB0C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000CBB10: BE882000
	s_cbranch_execz 61240                                      // 0000000CBB14: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34f8>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 0000000CBB18: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 0000000CBB24: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 0000000CBB28: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000CBB30: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000CBB34: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBB38: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000CBB3C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000CBB44: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000CBB50: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CBB54: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000CBB58: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000CBB5C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000CBB64: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CBB6C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000CBB70: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000CBB74: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000CBB78: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBB7C: BF870095
	.long 0xd71c0042                                           // 0000000CBB80: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000CBB84: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000CBB88: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000CBB8C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBB94: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 0000000CBB98: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000CBBA0: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBBA4: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 0000000CBBA8: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 0000000CBBB0: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBBB4: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 0000000CBBB8: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 0000000CBBC0: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 0000000CBBC4: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBBCC: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 0000000CBBD0: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 0000000CBBD4: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBBDC: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 0000000CBBE0: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 0000000CBBE4: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBBEC: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 0000000CBBF0: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 0000000CBBF8: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 0000000CBC00: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBC0C: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 0000000CBC10: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 0000000CBC18: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 0000000CBC24: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CBC2C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000CBC30: BE882001
	s_cbranch_execz 61171                                      // 0000000CBC34: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3504>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 0000000CBC38: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 0000000CBC44: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 0000000CBC48: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 0000000CBC50: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000CBC54: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CBC58: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 0000000CBC5C: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000CBC64: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 0000000CBC6C: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 0000000CBC78: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000CBC7C: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 0000000CBC80: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 0000000CBC88: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CBC8C: BF870121
	v_add_f32_e32 v65, v65, v66                                // 0000000CBC90: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 0000000CBC94: 7E841143
	v_exp_f32_e32 v65, v65                                     // 0000000CBC98: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBC9C: BF870095
	.long 0xd71c0041                                           // 0000000CBCA0: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 0000000CBCA4: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 0000000CBCA8: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000CBCAC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBCB4: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 0000000CBCB8: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000CBCC0: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBCC4: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 0000000CBCC8: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 0000000CBCD0: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBCD4: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 0000000CBCD8: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 0000000CBCE0: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 0000000CBCE4: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBCEC: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 0000000CBCF0: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 0000000CBCF4: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBCFC: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 0000000CBD00: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 0000000CBD04: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBD0C: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 0000000CBD10: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 0000000CBD18: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 0000000CBD20: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBD2C: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 0000000CBD30: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 0000000CBD38: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 0000000CBD44: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CBD4C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000CBD50: BE882002
	s_cbranch_execz 61102                                      // 0000000CBD54: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3510>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 0000000CBD58: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000CBD64: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000CBD6C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000CBD70: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBD74: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000CBD78: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 0000000CBD80: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 0000000CBD8C: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CBD90: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 0000000CBD94: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000CBD98: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 0000000CBDA0: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CBDA8: BF870121
	v_add_f32_e32 v58, v58, v65                                // 0000000CBDAC: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 0000000CBDB0: 7E821142
	v_exp_f32_e32 v58, v58                                     // 0000000CBDB4: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBDB8: BF870095
	.long 0xd71c003a                                           // 0000000CBDBC: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 0000000CBDC0: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000CBDC4: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000CBDC8: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBDD0: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 0000000CBDD4: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000CBDE0: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBDE4: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000CBDE8: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 0000000CBDF0: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBDF4: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 0000000CBDF8: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 0000000CBE00: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 0000000CBE04: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBE0C: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 0000000CBE10: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 0000000CBE14: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBE1C: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 0000000CBE20: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 0000000CBE24: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBE2C: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 0000000CBE30: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000CBE38: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 0000000CBE40: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBE4C: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 0000000CBE50: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 0000000CBE58: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000CBE64: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CBE6C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000CBE70: BE882003
	s_cbranch_execz 61033                                      // 0000000CBE74: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x351c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 0000000CBE78: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000CBE84: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000CBE8C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000CBE90: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBE94: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000CBE98: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000CBEA0: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 0000000CBEAC: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBEB0: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 0000000CBEB4: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 0000000CBEC0: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 0000000CBEC4: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000CBEC8: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CBED0: BF870293
	v_exp_f32_e32 v58, v58                                     // 0000000CBED4: 7E744B3A
	.long 0xd71c003a                                           // 0000000CBED8: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000CBEDC: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CBEE0: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000CBEE4: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000CBEE8: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 0000000CBEF0: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBEFC: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 0000000CBF00: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000CBF04: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CBF0C: BF870291
	v_rcp_f32_e32 v60, v59                                     // 0000000CBF10: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 0000000CBF14: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CBF1C: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 0000000CBF20: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 0000000CBF24: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 0000000CBF2C: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBF30: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 0000000CBF34: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 0000000CBF3C: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBF40: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 0000000CBF44: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 0000000CBF4C: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CBF54: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000CBF58: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 0000000CBF60: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000CBF6C: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CBF74: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000CBF78: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000CBF84: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CBF8C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000CBF90: BE882004
	s_cbranch_execz 60964                                      // 0000000CBF94: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3528>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 0000000CBF98: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000CBFA4: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000CBFAC: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000CBFB0: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBFB4: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000CBFB8: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000CBFC0: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000CBFCC: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CBFD0: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000CBFD4: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000CBFD8: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000CBFE0: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CBFE8: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000CBFEC: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000CBFF0: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000CBFF4: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CBFF8: BF870095
	.long 0xd71c003a                                           // 0000000CBFFC: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000CC000: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000CC004: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000CC008: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC010: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 0000000CC014: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000CC020: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC024: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000CC028: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000CC030: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC034: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000CC038: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000CC040: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000CC044: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC04C: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 0000000CC050: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 0000000CC054: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC05C: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 0000000CC060: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 0000000CC064: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC06C: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 0000000CC070: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000CC078: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 0000000CC080: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC08C: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000CC090: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000CC098: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000CC0A4: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CC0AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000CC0B0: BE882005
	s_cbranch_execz 60895                                      // 0000000CC0B4: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3534>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 0000000CC0B8: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000CC0C4: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000CC0CC: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000CC0D0: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC0D4: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000CC0D8: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000CC0E0: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000CC0EC: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CC0F0: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000CC0F4: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000CC0F8: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000CC100: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CC108: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000CC10C: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000CC110: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000CC114: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC118: BF870095
	.long 0xd71c003a                                           // 0000000CC11C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000CC120: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000CC124: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000CC128: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC130: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000CC134: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 0000000CC13C: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC144: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000CC148: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000CC150: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC154: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000CC158: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000CC160: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000CC164: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC16C: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000CC170: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 0000000CC174: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC17C: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 0000000CC180: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 0000000CC184: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC18C: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000CC190: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000CC198: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 0000000CC1A0: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC1AC: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000CC1B0: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000CC1B8: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000CC1C4: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CC1CC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000CC1D0: BE882006
	s_cbranch_execz 60826                                      // 0000000CC1D4: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3540>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 0000000CC1D8: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000CC1E4: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000CC1EC: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000CC1F0: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC1F4: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000CC1F8: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000CC200: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000CC20C: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CC210: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000CC214: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000CC218: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000CC220: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CC228: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000CC22C: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000CC230: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000CC234: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC238: BF870095
	.long 0xd71c003a                                           // 0000000CC23C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000CC240: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000CC244: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000CC248: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC250: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 0000000CC254: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000CC260: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC264: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000CC268: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000CC270: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC274: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000CC278: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000CC280: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000CC284: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC28C: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000CC290: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000CC294: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC29C: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000CC2A0: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000CC2A4: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC2AC: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000CC2B0: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000CC2B8: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 0000000CC2C0: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC2CC: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000CC2D0: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000CC2D8: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000CC2E4: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CC2EC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000CC2F0: BE882007
	s_cbranch_execz 60757                                      // 0000000CC2F4: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x354c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 0000000CC2F8: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000CC304: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000CC30C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000CC310: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC314: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000CC318: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000CC320: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000CC32C: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CC330: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000CC334: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000CC338: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000CC340: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CC348: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000CC34C: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000CC350: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000CC354: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC358: BF870095
	.long 0xd71c003a                                           // 0000000CC35C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000CC360: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000CC364: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000CC368: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC370: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 0000000CC374: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000CC380: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC384: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000CC388: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000CC390: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC394: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000CC398: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000CC3A0: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000CC3A4: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC3AC: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000CC3B0: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000CC3B4: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC3BC: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000CC3C0: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000CC3C4: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC3CC: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000CC3D0: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000CC3D8: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 0000000CC3E0: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC3EC: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000CC3F0: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000CC3F8: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000CC404: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CC40C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000CC410: BE882000
	s_cbranch_execz 60688                                      // 0000000CC414: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3558>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 0000000CC418: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 0000000CC424: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 0000000CC428: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000CC430: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000CC434: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC438: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000CC43C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000CC444: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000CC450: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CC454: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000CC458: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000CC45C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000CC464: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CC46C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000CC470: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000CC474: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000CC478: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC47C: BF870095
	.long 0xd71c003a                                           // 0000000CC480: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000CC484: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000CC488: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000CC48C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC494: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000CC498: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000CC4A0: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC4A4: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 0000000CC4A8: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 0000000CC4B0: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC4B4: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 0000000CC4B8: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 0000000CC4C0: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 0000000CC4C4: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC4CC: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 0000000CC4D0: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 0000000CC4D4: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC4DC: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 0000000CC4E0: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 0000000CC4E4: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC4EC: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 0000000CC4F0: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 0000000CC4F8: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 0000000CC500: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC50C: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 0000000CC510: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 0000000CC518: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 0000000CC524: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CC52C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000CC530: BE882001
	s_cbranch_execz 60619                                      // 0000000CC534: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3564>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 0000000CC538: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 0000000CC544: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 0000000CC548: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 0000000CC550: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000CC554: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CC558: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 0000000CC55C: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000CC564: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 0000000CC56C: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 0000000CC578: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000CC57C: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 0000000CC580: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 0000000CC588: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CC58C: BF870121
	v_add_f32_e32 v57, v57, v58                                // 0000000CC590: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 0000000CC594: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 0000000CC598: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC59C: BF870095
	.long 0xd71c0039                                           // 0000000CC5A0: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000000CC5A4: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000CC5A8: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000CC5AC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC5B4: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 0000000CC5B8: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000CC5C0: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC5C4: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 0000000CC5C8: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 0000000CC5D0: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC5D4: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 0000000CC5D8: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 0000000CC5E0: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 0000000CC5E4: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC5EC: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 0000000CC5F0: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 0000000CC5F4: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC5FC: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 0000000CC600: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 0000000CC604: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC60C: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 0000000CC610: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 0000000CC618: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 0000000CC620: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC62C: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 0000000CC630: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000000CC638: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 0000000CC644: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CC64C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000CC650: BE882002
	s_cbranch_execz 60550                                      // 0000000CC654: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3570>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 0000000CC658: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000CC664: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000CC66C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000CC670: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC674: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000CC678: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 0000000CC680: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 0000000CC68C: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CC690: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 0000000CC694: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000CC698: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 0000000CC6A0: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CC6A8: BF870121
	v_add_f32_e32 v50, v50, v57                                // 0000000CC6AC: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 0000000CC6B0: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 0000000CC6B4: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC6B8: BF870095
	.long 0xd71c0032                                           // 0000000CC6BC: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 0000000CC6C0: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000CC6C4: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000CC6C8: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC6D0: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 0000000CC6D4: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000CC6E0: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC6E4: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000CC6E8: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 0000000CC6F0: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC6F4: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 0000000CC6F8: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 0000000CC700: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 0000000CC704: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC70C: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 0000000CC710: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 0000000CC714: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC71C: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 0000000CC720: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 0000000CC724: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC72C: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 0000000CC730: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000CC738: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 0000000CC740: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC74C: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 0000000CC750: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 0000000CC758: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000CC764: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CC76C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000CC770: BE882003
	s_cbranch_execz 60481                                      // 0000000CC774: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x357c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 0000000CC778: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000CC784: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000CC78C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000CC790: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC794: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000CC798: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000CC7A0: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 0000000CC7AC: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC7B0: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 0000000CC7B4: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 0000000CC7C0: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 0000000CC7C4: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000CC7C8: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CC7D0: BF870293
	v_exp_f32_e32 v50, v50                                     // 0000000CC7D4: 7E644B32
	.long 0xd71c0032                                           // 0000000CC7D8: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000CC7DC: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CC7E0: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000CC7E4: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000CC7E8: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 0000000CC7F0: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC7FC: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 0000000CC800: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000CC804: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CC80C: BF870291
	v_rcp_f32_e32 v52, v51                                     // 0000000CC810: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 0000000CC814: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CC81C: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 0000000CC820: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 0000000CC824: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 0000000CC82C: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC830: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 0000000CC834: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 0000000CC83C: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC840: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 0000000CC844: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 0000000CC84C: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CC854: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000CC858: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 0000000CC860: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000CC86C: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CC874: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000CC878: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000CC884: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CC88C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000CC890: BE882004
	s_cbranch_execz 60412                                      // 0000000CC894: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3588>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 0000000CC898: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000CC8A4: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000CC8AC: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000CC8B0: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC8B4: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000CC8B8: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000CC8C0: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000CC8CC: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CC8D0: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000CC8D4: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000CC8D8: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000CC8E0: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CC8E8: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000CC8EC: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000CC8F0: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000CC8F4: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC8F8: BF870095
	.long 0xd71c0032                                           // 0000000CC8FC: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000CC900: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000CC904: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000CC908: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC910: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 0000000CC914: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000CC920: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC924: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000CC928: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000CC930: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC934: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000CC938: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000CC940: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000CC944: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC94C: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 0000000CC950: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 0000000CC954: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC95C: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 0000000CC960: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 0000000CC964: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC96C: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 0000000CC970: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000CC978: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 0000000CC980: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC98C: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000CC990: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000CC998: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000CC9A4: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CC9AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000CC9B0: BE882005
	s_cbranch_execz 60343                                      // 0000000CC9B4: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3594>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 0000000CC9B8: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000CC9C4: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000CC9CC: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000CC9D0: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CC9D4: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000CC9D8: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000CC9E0: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000CC9EC: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CC9F0: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000CC9F4: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000CC9F8: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000CCA00: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CCA08: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000CCA0C: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000CCA10: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000CCA14: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCA18: BF870095
	.long 0xd71c0032                                           // 0000000CCA1C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000CCA20: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000CCA24: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000CCA28: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCA30: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 0000000CCA34: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 0000000CCA3C: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCA44: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000CCA48: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000CCA50: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCA54: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000CCA58: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000CCA60: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000CCA64: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCA6C: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000CCA70: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 0000000CCA74: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCA7C: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 0000000CCA80: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 0000000CCA84: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCA8C: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000CCA90: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000CCA98: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 0000000CCAA0: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCAAC: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000CCAB0: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000CCAB8: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000CCAC4: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CCACC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000CCAD0: BE882006
	s_cbranch_execz 60274                                      // 0000000CCAD4: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35a0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 0000000CCAD8: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000CCAE4: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000CCAEC: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000CCAF0: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCAF4: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000CCAF8: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000CCB00: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000CCB0C: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CCB10: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000CCB14: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000CCB18: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000CCB20: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CCB28: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000CCB2C: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000CCB30: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000CCB34: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCB38: BF870095
	.long 0xd71c0032                                           // 0000000CCB3C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000CCB40: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000CCB44: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000CCB48: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCB50: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 0000000CCB54: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000CCB60: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCB64: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000CCB68: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000CCB70: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCB74: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000CCB78: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000CCB80: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000CCB84: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCB8C: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000CCB90: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 0000000CCB94: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCB9C: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 0000000CCBA0: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000CCBA4: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCBAC: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000CCBB0: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000CCBB8: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 0000000CCBC0: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCBCC: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000CCBD0: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000CCBD8: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000CCBE4: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CCBEC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000CCBF0: BE882007
	s_cbranch_execz 60205                                      // 0000000CCBF4: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35ac>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 0000000CCBF8: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000CCC04: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000CCC0C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000CCC10: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCC14: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000CCC18: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000CCC20: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000CCC2C: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CCC30: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000CCC34: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000CCC38: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000CCC40: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CCC48: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000CCC4C: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000CCC50: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000CCC54: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCC58: BF870095
	.long 0xd71c0032                                           // 0000000CCC5C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000CCC60: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000CCC64: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000CCC68: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCC70: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 0000000CCC74: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000CCC80: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCC84: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000CCC88: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000CCC90: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCC94: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000CCC98: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000CCCA0: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000CCCA4: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCCAC: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000CCCB0: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 0000000CCCB4: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCCBC: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 0000000CCCC0: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000CCCC4: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCCCC: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000CCCD0: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000CCCD8: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 0000000CCCE0: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCCEC: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000CCCF0: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000CCCF8: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000CCD04: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CCD0C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000CCD10: BE882000
	s_cbranch_execz 60136                                      // 0000000CCD14: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35b8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 0000000CCD18: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 0000000CCD24: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 0000000CCD28: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000CCD30: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000CCD34: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCD38: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000CCD3C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000CCD44: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000CCD50: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CCD54: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000CCD58: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000CCD5C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000CCD64: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CCD6C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000CCD70: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000CCD74: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000CCD78: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCD7C: BF870095
	.long 0xd71c0032                                           // 0000000CCD80: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000CCD84: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000CCD88: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000CCD8C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCD94: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 0000000CCD98: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000CCDA0: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCDA4: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 0000000CCDA8: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 0000000CCDB0: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCDB4: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 0000000CCDB8: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 0000000CCDC0: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 0000000CCDC4: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCDCC: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 0000000CCDD0: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 0000000CCDD4: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCDDC: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 0000000CCDE0: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 0000000CCDE4: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCDEC: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 0000000CCDF0: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 0000000CCDF8: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 0000000CCE00: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCE0C: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 0000000CCE10: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 0000000CCE18: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 0000000CCE24: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CCE2C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000CCE30: BE882001
	s_cbranch_execz 60067                                      // 0000000CCE34: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35c4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 0000000CCE38: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 0000000CCE44: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 0000000CCE48: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 0000000CCE50: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000CCE54: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CCE58: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 0000000CCE5C: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000CCE64: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 0000000CCE6C: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 0000000CCE78: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000CCE7C: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 0000000CCE80: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 0000000CCE88: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CCE8C: BF870121
	v_add_f32_e32 v49, v49, v50                                // 0000000CCE90: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 0000000CCE94: 7E641133
	v_exp_f32_e32 v49, v49                                     // 0000000CCE98: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCE9C: BF870095
	.long 0xd71c0031                                           // 0000000CCEA0: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 0000000CCEA4: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000000CCEA8: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000CCEAC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCEB4: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 0000000CCEB8: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000CCEC0: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCEC4: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 0000000CCEC8: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 0000000CCED0: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCED4: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 0000000CCED8: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 0000000CCEE0: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 0000000CCEE4: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCEEC: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 0000000CCEF0: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 0000000CCEF4: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCEFC: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 0000000CCF00: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 0000000CCF04: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCF0C: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 0000000CCF10: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 0000000CCF18: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 0000000CCF20: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCF2C: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 0000000CCF30: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 0000000CCF38: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 0000000CCF44: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CCF4C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000CCF50: BE882002
	s_cbranch_execz 59998                                      // 0000000CCF54: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35d0>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 0000000CCF58: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000CCF64: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000CCF6C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000CCF70: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCF74: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000CCF78: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 0000000CCF80: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 0000000CCF8C: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CCF90: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 0000000CCF94: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000CCF98: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 0000000CCFA0: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CCFA8: BF870121
	v_add_f32_e32 v42, v42, v49                                // 0000000CCFAC: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 0000000CCFB0: 7E621132
	v_exp_f32_e32 v42, v42                                     // 0000000CCFB4: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCFB8: BF870095
	.long 0xd71c002a                                           // 0000000CCFBC: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 0000000CCFC0: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000CCFC4: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000CCFC8: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCFD0: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 0000000CCFD4: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000CCFE0: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCFE4: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000CCFE8: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 0000000CCFF0: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CCFF4: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 0000000CCFF8: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 0000000CD000: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 0000000CD004: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD00C: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 0000000CD010: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 0000000CD014: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD01C: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 0000000CD020: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 0000000CD024: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD02C: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 0000000CD030: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000CD038: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 0000000CD040: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD04C: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 0000000CD050: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 0000000CD058: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000CD064: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CD06C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000CD070: BE882003
	s_cbranch_execz 59929                                      // 0000000CD074: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35dc>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 0000000CD078: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000CD084: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000CD08C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000CD090: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD094: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000CD098: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000CD0A0: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 0000000CD0AC: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD0B0: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 0000000CD0B4: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 0000000CD0C0: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 0000000CD0C4: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000CD0C8: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CD0D0: BF870293
	v_exp_f32_e32 v42, v42                                     // 0000000CD0D4: 7E544B2A
	.long 0xd71c002a                                           // 0000000CD0D8: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000CD0DC: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CD0E0: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000CD0E4: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000CD0E8: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 0000000CD0F0: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD0FC: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 0000000CD100: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000CD104: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CD10C: BF870291
	v_rcp_f32_e32 v44, v43                                     // 0000000CD110: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 0000000CD114: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CD11C: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 0000000CD120: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 0000000CD124: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 0000000CD12C: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD130: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 0000000CD134: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 0000000CD13C: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD140: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 0000000CD144: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 0000000CD14C: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CD154: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000CD158: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 0000000CD160: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000CD16C: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CD174: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000CD178: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000CD184: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CD18C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000CD190: BE882004
	s_cbranch_execz 59860                                      // 0000000CD194: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35e8>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 0000000CD198: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000CD1A4: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000CD1AC: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000CD1B0: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD1B4: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000CD1B8: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000CD1C0: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000CD1CC: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CD1D0: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000CD1D4: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000CD1D8: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000CD1E0: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CD1E8: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000CD1EC: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000CD1F0: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000CD1F4: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD1F8: BF870095
	.long 0xd71c002a                                           // 0000000CD1FC: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000CD200: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000CD204: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000CD208: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD210: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 0000000CD214: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000CD220: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD224: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000CD228: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000CD230: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD234: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000CD238: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000CD240: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000CD244: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD24C: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 0000000CD250: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 0000000CD254: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD25C: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 0000000CD260: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 0000000CD264: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD26C: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 0000000CD270: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000CD278: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 0000000CD280: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD28C: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000CD290: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000CD298: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000CD2A4: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CD2AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000CD2B0: BE882005
	s_cbranch_execz 59791                                      // 0000000CD2B4: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35f4>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 0000000CD2B8: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000CD2C4: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000CD2CC: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000CD2D0: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD2D4: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000CD2D8: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000CD2E0: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000CD2EC: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CD2F0: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000CD2F4: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000CD2F8: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000CD300: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CD308: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000CD30C: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000CD310: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000CD314: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD318: BF870095
	.long 0xd71c002a                                           // 0000000CD31C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000CD320: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000CD324: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000CD328: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD330: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000CD334: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 0000000CD33C: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD344: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000CD348: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000CD350: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD354: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000CD358: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000CD360: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000CD364: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD36C: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000CD370: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 0000000CD374: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD37C: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 0000000CD380: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 0000000CD384: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD38C: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000CD390: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000CD398: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 0000000CD3A0: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD3AC: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000CD3B0: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000CD3B8: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000CD3C4: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CD3CC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000CD3D0: BE882006
	s_cbranch_execz 59722                                      // 0000000CD3D4: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3600>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 0000000CD3D8: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000CD3E4: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000CD3EC: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000CD3F0: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD3F4: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000CD3F8: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000CD400: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000CD40C: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CD410: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000CD414: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000CD418: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000CD420: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CD428: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000CD42C: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000CD430: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000CD434: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD438: BF870095
	.long 0xd71c002a                                           // 0000000CD43C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000CD440: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000CD444: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000CD448: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD450: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 0000000CD454: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000CD460: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD464: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000CD468: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000CD470: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD474: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000CD478: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000CD480: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000CD484: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD48C: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000CD490: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000CD494: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD49C: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000CD4A0: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000CD4A4: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD4AC: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000CD4B0: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000CD4B8: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 0000000CD4C0: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD4CC: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000CD4D0: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000CD4D8: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000CD4E4: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CD4EC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000CD4F0: BE882007
	s_cbranch_execz 59653                                      // 0000000CD4F4: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x360c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 0000000CD4F8: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000CD504: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000CD50C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000CD510: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD514: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000CD518: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000CD520: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000CD52C: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CD530: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000CD534: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000CD538: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000CD540: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CD548: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000CD54C: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000CD550: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000CD554: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD558: BF870095
	.long 0xd71c002a                                           // 0000000CD55C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000CD560: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000CD564: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000CD568: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD570: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 0000000CD574: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000CD580: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD584: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000CD588: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000CD590: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD594: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000CD598: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000CD5A0: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000CD5A4: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD5AC: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000CD5B0: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000CD5B4: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD5BC: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000CD5C0: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000CD5C4: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD5CC: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000CD5D0: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000CD5D8: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 0000000CD5E0: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD5EC: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000CD5F0: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000CD5F8: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000CD604: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CD60C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000CD610: BE882000
	s_cbranch_execz 59584                                      // 0000000CD614: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3618>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 0000000CD618: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 0000000CD624: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 0000000CD628: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000CD630: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000CD634: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD638: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000CD63C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000CD644: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000CD650: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CD654: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000CD658: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000CD65C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000CD664: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CD66C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000CD670: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000CD674: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000CD678: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD67C: BF870095
	.long 0xd71c002a                                           // 0000000CD680: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000CD684: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000CD688: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000CD68C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD694: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000CD698: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000CD6A0: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD6A4: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 0000000CD6A8: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 0000000CD6B0: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD6B4: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000000CD6B8: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000000CD6C0: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 0000000CD6C4: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD6CC: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 0000000CD6D0: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 0000000CD6D4: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD6DC: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 0000000CD6E0: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 0000000CD6E4: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD6EC: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 0000000CD6F0: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 0000000CD6F8: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 0000000CD700: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD70C: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 0000000CD710: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 0000000CD718: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 0000000CD724: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CD72C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000CD730: BE882001
	s_cbranch_execz 59515                                      // 0000000CD734: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3624>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 0000000CD738: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 0000000CD744: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 0000000CD748: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 0000000CD750: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000CD754: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CD758: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 0000000CD75C: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000CD764: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 0000000CD76C: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000000CD778: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000CD77C: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 0000000CD780: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 0000000CD788: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CD78C: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000000CD790: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000000CD794: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 0000000CD798: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD79C: BF870095
	.long 0xd71c0029                                           // 0000000CD7A0: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000000CD7A4: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000CD7A8: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000CD7AC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD7B4: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 0000000CD7B8: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000CD7C0: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD7C4: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 0000000CD7C8: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 0000000CD7D0: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD7D4: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 0000000CD7D8: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 0000000CD7E0: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 0000000CD7E4: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD7EC: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 0000000CD7F0: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 0000000CD7F4: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD7FC: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 0000000CD800: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 0000000CD804: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD80C: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 0000000CD810: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 0000000CD818: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 0000000CD820: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD82C: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 0000000CD830: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 0000000CD838: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 0000000CD844: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CD84C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000CD850: BE882002
	s_cbranch_execz 59446                                      // 0000000CD854: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3630>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 0000000CD858: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000CD864: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000CD86C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000CD870: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD874: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000CD878: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 0000000CD880: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 0000000CD88C: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CD890: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 0000000CD894: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000CD898: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 0000000CD8A0: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CD8A8: BF870121
	v_add_f32_e32 v34, v34, v41                                // 0000000CD8AC: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 0000000CD8B0: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 0000000CD8B4: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD8B8: BF870095
	.long 0xd71c0022                                           // 0000000CD8BC: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 0000000CD8C0: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000CD8C4: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000CD8C8: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD8D0: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 0000000CD8D4: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000CD8E0: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD8E4: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000CD8E8: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 0000000CD8F0: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD8F4: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 0000000CD8F8: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 0000000CD900: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 0000000CD904: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD90C: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 0000000CD910: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 0000000CD914: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD91C: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 0000000CD920: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 0000000CD924: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD92C: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 0000000CD930: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000CD938: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 0000000CD940: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD94C: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 0000000CD950: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 0000000CD958: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000CD964: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CD96C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000CD970: BE882003
	s_cbranch_execz 59377                                      // 0000000CD974: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x363c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 0000000CD978: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000CD984: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000CD98C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000CD990: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD994: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000CD998: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000CD9A0: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 0000000CD9AC: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD9B0: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 0000000CD9B4: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 0000000CD9C0: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 0000000CD9C4: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000CD9C8: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CD9D0: BF870293
	v_exp_f32_e32 v34, v34                                     // 0000000CD9D4: 7E444B22
	.long 0xd71c0022                                           // 0000000CD9D8: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000CD9DC: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CD9E0: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000CD9E4: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000CD9E8: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 0000000CD9F0: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD9FC: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 0000000CDA00: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000CDA04: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CDA0C: BF870291
	v_rcp_f32_e32 v36, v35                                     // 0000000CDA10: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 0000000CDA14: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CDA1C: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 0000000CDA20: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 0000000CDA24: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 0000000CDA2C: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDA30: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 0000000CDA34: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 0000000CDA3C: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDA40: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 0000000CDA44: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 0000000CDA4C: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CDA54: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000CDA58: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 0000000CDA60: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000CDA6C: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CDA74: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000CDA78: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000CDA84: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CDA8C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000CDA90: BE882004
	s_cbranch_execz 59308                                      // 0000000CDA94: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3648>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 0000000CDA98: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000CDAA4: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000CDAAC: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000CDAB0: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDAB4: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000CDAB8: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000CDAC0: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000CDACC: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CDAD0: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000CDAD4: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000CDAD8: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000CDAE0: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CDAE8: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000CDAEC: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000CDAF0: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000CDAF4: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDAF8: BF870095
	.long 0xd71c0022                                           // 0000000CDAFC: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000CDB00: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000CDB04: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000CDB08: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDB10: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 0000000CDB14: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000CDB20: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDB24: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000CDB28: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000CDB30: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDB34: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000CDB38: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000CDB40: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000CDB44: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDB4C: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 0000000CDB50: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 0000000CDB54: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDB5C: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 0000000CDB60: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 0000000CDB64: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDB6C: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 0000000CDB70: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000CDB78: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 0000000CDB80: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDB8C: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000CDB90: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000CDB98: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000CDBA4: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CDBAC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000CDBB0: BE882005
	s_cbranch_execz 59239                                      // 0000000CDBB4: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3654>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 0000000CDBB8: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000CDBC4: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000CDBCC: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000CDBD0: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDBD4: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000CDBD8: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000CDBE0: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000CDBEC: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CDBF0: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000CDBF4: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000CDBF8: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000CDC00: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CDC08: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000CDC0C: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000CDC10: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000CDC14: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDC18: BF870095
	.long 0xd71c0022                                           // 0000000CDC1C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000CDC20: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000CDC24: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000CDC28: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDC30: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000000CDC34: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 0000000CDC3C: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDC44: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000CDC48: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000CDC50: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDC54: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000CDC58: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000CDC60: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000CDC64: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDC6C: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000CDC70: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 0000000CDC74: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDC7C: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 0000000CDC80: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 0000000CDC84: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDC8C: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000CDC90: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000CDC98: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 0000000CDCA0: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDCAC: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000CDCB0: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000CDCB8: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000CDCC4: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CDCCC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000CDCD0: BE882006
	s_cbranch_execz 59170                                      // 0000000CDCD4: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3660>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 0000000CDCD8: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000CDCE4: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000CDCEC: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000CDCF0: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDCF4: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000CDCF8: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000CDD00: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000CDD0C: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CDD10: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000CDD14: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000CDD18: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000CDD20: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CDD28: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000CDD2C: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000CDD30: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000CDD34: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDD38: BF870095
	.long 0xd71c0022                                           // 0000000CDD3C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000CDD40: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000CDD44: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000CDD48: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDD50: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 0000000CDD54: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000CDD60: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDD64: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000CDD68: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000CDD70: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDD74: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000CDD78: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000CDD80: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000CDD84: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDD8C: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000CDD90: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 0000000CDD94: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDD9C: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 0000000CDDA0: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000000CDDA4: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDDAC: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000CDDB0: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000CDDB8: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 0000000CDDC0: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDDCC: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000CDDD0: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000CDDD8: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000CDDE4: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CDDEC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000CDDF0: BE882007
	s_cbranch_execz 59101                                      // 0000000CDDF4: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x366c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 0000000CDDF8: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000CDE04: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000CDE0C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000CDE10: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDE14: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000CDE18: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000CDE20: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000CDE2C: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CDE30: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000CDE34: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000CDE38: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000CDE40: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CDE48: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000CDE4C: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000CDE50: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000CDE54: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDE58: BF870095
	.long 0xd71c0022                                           // 0000000CDE5C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000CDE60: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000CDE64: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000CDE68: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDE70: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 0000000CDE74: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000CDE80: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDE84: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000CDE88: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000CDE90: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDE94: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000CDE98: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000CDEA0: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000CDEA4: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDEAC: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000CDEB0: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 0000000CDEB4: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDEBC: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 0000000CDEC0: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000000CDEC4: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDECC: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000CDED0: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000CDED8: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 0000000CDEE0: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDEEC: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000CDEF0: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000CDEF8: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000CDF04: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CDF0C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000CDF10: BE882000
	s_cbranch_execz 59032                                      // 0000000CDF14: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3678>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 0000000CDF18: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 0000000CDF24: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 0000000CDF28: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000CDF30: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000CDF34: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDF38: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000CDF3C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000CDF44: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000CDF50: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CDF54: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000CDF58: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000CDF5C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000CDF64: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CDF6C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000CDF70: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000CDF74: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000CDF78: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDF7C: BF870095
	.long 0xd71c0022                                           // 0000000CDF80: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000CDF84: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000CDF88: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000CDF8C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDF94: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000000CDF98: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000CDFA0: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDFA4: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 0000000CDFA8: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 0000000CDFB0: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDFB4: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000000CDFB8: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000000CDFC0: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 0000000CDFC4: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDFCC: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 0000000CDFD0: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 0000000CDFD4: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDFDC: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 0000000CDFE0: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 0000000CDFE4: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDFEC: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 0000000CDFF0: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 0000000CDFF8: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 0000000CE000: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE00C: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 0000000CE010: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 0000000CE018: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 0000000CE024: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CE02C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000CE030: BE882001
	s_cbranch_execz 58963                                      // 0000000CE034: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3684>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 0000000CE038: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 0000000CE044: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 0000000CE048: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 0000000CE050: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000CE054: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CE058: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 0000000CE05C: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000CE064: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 0000000CE06C: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000000CE078: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000CE07C: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 0000000CE080: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 0000000CE088: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CE08C: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000000CE090: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 0000000CE094: 7E441123
	v_exp_f32_e32 v33, v33                                     // 0000000CE098: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE09C: BF870095
	.long 0xd71c0021                                           // 0000000CE0A0: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000CE0A4: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000CE0A8: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000CE0AC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE0B4: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 0000000CE0B8: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000CE0C0: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE0C4: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 0000000CE0C8: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 0000000CE0D0: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE0D4: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 0000000CE0D8: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 0000000CE0E0: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 0000000CE0E4: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE0EC: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 0000000CE0F0: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 0000000CE0F4: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE0FC: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 0000000CE100: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 0000000CE104: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE10C: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 0000000CE110: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 0000000CE118: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 0000000CE120: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE12C: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 0000000CE130: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 0000000CE138: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 0000000CE144: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CE14C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000CE150: BE882002
	s_cbranch_execz 58894                                      // 0000000CE154: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3690>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 0000000CE158: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000CE164: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000CE16C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000CE170: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE174: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000CE178: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 0000000CE180: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 0000000CE18C: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CE190: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 0000000CE194: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000CE198: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 0000000CE1A0: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CE1A8: BF870121
	v_add_f32_e32 v26, v26, v33                                // 0000000CE1AC: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000CE1B0: 7E421122
	v_exp_f32_e32 v26, v26                                     // 0000000CE1B4: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE1B8: BF870095
	.long 0xd71c001a                                           // 0000000CE1BC: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 0000000CE1C0: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000CE1C4: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000CE1C8: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE1D0: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 0000000CE1D4: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000CE1E0: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE1E4: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000CE1E8: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 0000000CE1F0: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE1F4: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 0000000CE1F8: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 0000000CE200: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 0000000CE204: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE20C: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 0000000CE210: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 0000000CE214: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE21C: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 0000000CE220: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 0000000CE224: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE22C: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 0000000CE230: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000CE238: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 0000000CE240: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE24C: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 0000000CE250: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 0000000CE258: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000CE264: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CE26C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000CE270: BE882003
	s_cbranch_execz 58825                                      // 0000000CE274: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x369c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 0000000CE278: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000CE284: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000CE28C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000CE290: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE294: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000CE298: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000CE2A0: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 0000000CE2AC: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE2B0: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 0000000CE2B4: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 0000000CE2C0: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 0000000CE2C4: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000CE2C8: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CE2D0: BF870293
	v_exp_f32_e32 v26, v26                                     // 0000000CE2D4: 7E344B1A
	.long 0xd71c001a                                           // 0000000CE2D8: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000CE2DC: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CE2E0: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000CE2E4: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000CE2E8: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 0000000CE2F0: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE2FC: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 0000000CE300: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000CE304: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CE30C: BF870291
	v_rcp_f32_e32 v28, v27                                     // 0000000CE310: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 0000000CE314: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE31C: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 0000000CE320: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 0000000CE324: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 0000000CE32C: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE330: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 0000000CE334: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 0000000CE33C: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE340: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 0000000CE344: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 0000000CE34C: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CE354: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000CE358: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 0000000CE360: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000CE36C: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE374: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000CE378: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000CE384: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CE38C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000CE390: BE882004
	s_cbranch_execz 58756                                      // 0000000CE394: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36a8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 0000000CE398: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000CE3A4: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000CE3AC: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000CE3B0: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE3B4: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000CE3B8: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000CE3C0: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000CE3CC: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CE3D0: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000CE3D4: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000CE3D8: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000CE3E0: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CE3E8: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000CE3EC: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000CE3F0: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000CE3F4: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE3F8: BF870095
	.long 0xd71c001a                                           // 0000000CE3FC: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000CE400: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000CE404: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000CE408: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE410: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 0000000CE414: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000CE420: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE424: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000CE428: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000CE430: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE434: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000CE438: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000CE440: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000CE444: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE44C: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 0000000CE450: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 0000000CE454: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE45C: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 0000000CE460: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 0000000CE464: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE46C: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 0000000CE470: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000CE478: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 0000000CE480: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE48C: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000CE490: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000CE498: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000CE4A4: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CE4AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000CE4B0: BE882005
	s_cbranch_execz 58687                                      // 0000000CE4B4: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36b4>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 0000000CE4B8: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000CE4C4: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000CE4CC: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000CE4D0: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE4D4: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000CE4D8: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000CE4E0: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000CE4EC: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CE4F0: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000CE4F4: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000CE4F8: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000CE500: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CE508: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000CE50C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000CE510: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000CE514: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE518: BF870095
	.long 0xd71c001a                                           // 0000000CE51C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000CE520: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000CE524: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000CE528: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE530: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 0000000CE534: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 0000000CE53C: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE544: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000CE548: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000CE550: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE554: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000CE558: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000CE560: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000CE564: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE56C: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000CE570: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 0000000CE574: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE57C: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 0000000CE580: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 0000000CE584: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE58C: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000CE590: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000CE598: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 0000000CE5A0: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE5AC: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000CE5B0: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000CE5B8: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000CE5C4: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CE5CC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000CE5D0: BE882006
	s_cbranch_execz 58618                                      // 0000000CE5D4: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36c0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 0000000CE5D8: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000CE5E4: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000CE5EC: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000CE5F0: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE5F4: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000CE5F8: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000CE600: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000CE60C: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CE610: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000CE614: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000CE618: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000CE620: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CE628: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000CE62C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000CE630: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000CE634: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE638: BF870095
	.long 0xd71c001a                                           // 0000000CE63C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000CE640: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000CE644: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000CE648: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE650: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 0000000CE654: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000CE660: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE664: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000CE668: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000CE670: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE674: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000CE678: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000CE680: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000CE684: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE68C: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000CE690: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000CE694: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE69C: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000CE6A0: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000CE6A4: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE6AC: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000CE6B0: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000CE6B8: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 0000000CE6C0: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE6CC: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000CE6D0: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000CE6D8: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000CE6E4: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CE6EC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000CE6F0: BE882007
	s_cbranch_execz 58549                                      // 0000000CE6F4: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36cc>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 0000000CE6F8: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000CE704: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000CE70C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000CE710: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE714: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000CE718: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000CE720: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000CE72C: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CE730: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000CE734: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000CE738: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000CE740: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CE748: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000CE74C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000CE750: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000CE754: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE758: BF870095
	.long 0xd71c001a                                           // 0000000CE75C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000CE760: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000CE764: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000CE768: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE770: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 0000000CE774: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000CE780: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE784: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000CE788: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000CE790: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE794: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000CE798: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000CE7A0: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000CE7A4: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE7AC: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000CE7B0: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000CE7B4: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE7BC: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000CE7C0: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000CE7C4: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE7CC: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000CE7D0: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000CE7D8: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 0000000CE7E0: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE7EC: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000CE7F0: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000CE7F8: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000CE804: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CE80C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000CE810: BE882000
	s_cbranch_execz 58480                                      // 0000000CE814: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36d8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 0000000CE818: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 0000000CE824: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 0000000CE828: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000CE830: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000CE834: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE838: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000CE83C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000CE844: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000CE850: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CE854: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000CE858: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000CE85C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000CE864: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CE86C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000CE870: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000CE874: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000CE878: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE87C: BF870095
	.long 0xd71c001a                                           // 0000000CE880: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000CE884: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000CE888: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000CE88C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE894: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 0000000CE898: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000CE8A0: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE8A4: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 0000000CE8A8: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 0000000CE8B0: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE8B4: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 0000000CE8B8: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 0000000CE8C0: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 0000000CE8C4: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE8CC: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 0000000CE8D0: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 0000000CE8D4: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE8DC: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 0000000CE8E0: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 0000000CE8E4: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE8EC: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 0000000CE8F0: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 0000000CE8F8: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 0000000CE900: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE90C: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 0000000CE910: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 0000000CE918: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 0000000CE924: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CE92C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000CE930: BE882001
	s_cbranch_execz 58411                                      // 0000000CE934: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36e4>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 0000000CE938: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 0000000CE944: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 0000000CE948: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 0000000CE950: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000CE954: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CE958: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 0000000CE95C: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000CE964: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 0000000CE96C: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 0000000CE978: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000CE97C: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 0000000CE980: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 0000000CE988: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CE98C: BF870121
	v_add_f32_e32 v25, v25, v26                                // 0000000CE990: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 0000000CE994: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 0000000CE998: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE99C: BF870095
	.long 0xd71c0019                                           // 0000000CE9A0: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000000CE9A4: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000000CE9A8: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000CE9AC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE9B4: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 0000000CE9B8: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000CE9C0: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE9C4: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 0000000CE9C8: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 0000000CE9D0: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE9D4: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 0000000CE9D8: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 0000000CE9E0: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 0000000CE9E4: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE9EC: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 0000000CE9F0: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 0000000CE9F4: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE9FC: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 0000000CEA00: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 0000000CEA04: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEA0C: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 0000000CEA10: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 0000000CEA18: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 0000000CEA20: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEA2C: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 0000000CEA30: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000000CEA38: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 0000000CEA44: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CEA4C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000CEA50: BE882002
	s_cbranch_execz 58342                                      // 0000000CEA54: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36f0>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 0000000CEA58: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000CEA64: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000CEA6C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000CEA70: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEA74: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000CEA78: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 0000000CEA80: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 0000000CEA8C: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CEA90: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 0000000CEA94: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000CEA98: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 0000000CEAA0: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CEAA8: BF870121
	v_add_f32_e32 v18, v18, v25                                // 0000000CEAAC: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 0000000CEAB0: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 0000000CEAB4: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEAB8: BF870095
	.long 0xd71c0012                                           // 0000000CEABC: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 0000000CEAC0: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000CEAC4: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000CEAC8: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEAD0: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 0000000CEAD4: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000CEAE0: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEAE4: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000CEAE8: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 0000000CEAF0: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEAF4: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 0000000CEAF8: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 0000000CEB00: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 0000000CEB04: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEB0C: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 0000000CEB10: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 0000000CEB14: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEB1C: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 0000000CEB20: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 0000000CEB24: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEB2C: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 0000000CEB30: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000CEB38: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 0000000CEB40: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEB4C: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 0000000CEB50: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 0000000CEB58: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000CEB64: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CEB6C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000CEB70: BE882003
	s_cbranch_execz 58273                                      // 0000000CEB74: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36fc>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 0000000CEB78: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000CEB84: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000CEB8C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000CEB90: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEB94: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000CEB98: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000CEBA0: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 0000000CEBAC: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEBB0: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 0000000CEBB4: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 0000000CEBC0: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 0000000CEBC4: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000CEBC8: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CEBD0: BF870293
	v_exp_f32_e32 v18, v18                                     // 0000000CEBD4: 7E244B12
	.long 0xd71c0012                                           // 0000000CEBD8: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000CEBDC: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CEBE0: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000CEBE4: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000CEBE8: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 0000000CEBF0: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEBFC: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 0000000CEC00: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000CEC04: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CEC0C: BF870291
	v_rcp_f32_e32 v20, v19                                     // 0000000CEC10: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 0000000CEC14: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEC1C: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 0000000CEC20: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 0000000CEC24: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 0000000CEC2C: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEC30: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 0000000CEC34: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 0000000CEC3C: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEC40: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 0000000CEC44: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 0000000CEC4C: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CEC54: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000CEC58: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 0000000CEC60: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000CEC6C: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CEC74: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000CEC78: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000CEC84: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CEC8C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000CEC90: BE882004
	s_cbranch_execz 58204                                      // 0000000CEC94: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3708>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 0000000CEC98: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000CECA4: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000CECAC: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000CECB0: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CECB4: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000CECB8: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000CECC0: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000CECCC: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CECD0: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000CECD4: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000CECD8: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000CECE0: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CECE8: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000CECEC: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000CECF0: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000CECF4: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CECF8: BF870095
	.long 0xd71c0012                                           // 0000000CECFC: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000CED00: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000CED04: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000CED08: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CED10: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 0000000CED14: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000CED20: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CED24: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000CED28: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000CED30: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CED34: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000CED38: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000CED40: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000CED44: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CED4C: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 0000000CED50: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 0000000CED54: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CED5C: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 0000000CED60: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 0000000CED64: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CED6C: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 0000000CED70: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000CED78: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 0000000CED80: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CED8C: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000CED90: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000CED98: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000CEDA4: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CEDAC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000CEDB0: BE882005
	s_cbranch_execz 58135                                      // 0000000CEDB4: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3714>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 0000000CEDB8: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000CEDC4: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000CEDCC: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000CEDD0: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEDD4: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000CEDD8: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000CEDE0: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000CEDEC: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CEDF0: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000CEDF4: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000CEDF8: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000CEE00: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CEE08: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000CEE0C: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000CEE10: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000CEE14: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEE18: BF870095
	.long 0xd71c0012                                           // 0000000CEE1C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000CEE20: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000CEE24: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000CEE28: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEE30: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000CEE34: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 0000000CEE3C: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEE44: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000CEE48: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000CEE50: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEE54: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000CEE58: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000CEE60: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000CEE64: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEE6C: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000CEE70: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 0000000CEE74: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEE7C: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 0000000CEE80: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 0000000CEE84: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEE8C: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000CEE90: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000CEE98: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 0000000CEEA0: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEEAC: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000CEEB0: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000CEEB8: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000CEEC4: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CEECC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000CEED0: BE882006
	s_cbranch_execz 58066                                      // 0000000CEED4: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3720>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 0000000CEED8: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000CEEE4: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000CEEEC: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000CEEF0: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEEF4: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000CEEF8: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000CEF00: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000CEF0C: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CEF10: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000CEF14: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000CEF18: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000CEF20: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CEF28: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000CEF2C: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000CEF30: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000CEF34: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEF38: BF870095
	.long 0xd71c0012                                           // 0000000CEF3C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000CEF40: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000CEF44: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000CEF48: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEF50: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 0000000CEF54: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000CEF60: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEF64: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000CEF68: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000CEF70: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEF74: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000CEF78: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000CEF80: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000CEF84: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEF8C: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000CEF90: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000CEF94: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEF9C: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000CEFA0: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000CEFA4: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEFAC: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000CEFB0: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000CEFB8: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 0000000CEFC0: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEFCC: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000CEFD0: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000CEFD8: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000CEFE4: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CEFEC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000CEFF0: BE882007
	s_cbranch_execz 57997                                      // 0000000CEFF4: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x372c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 0000000CEFF8: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000CF004: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000CF00C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000CF010: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF014: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000CF018: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000CF020: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000CF02C: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CF030: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000CF034: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000CF038: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000CF040: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CF048: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000CF04C: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000CF050: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000CF054: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF058: BF870095
	.long 0xd71c0012                                           // 0000000CF05C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000CF060: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000CF064: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000CF068: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF070: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 0000000CF074: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000CF080: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF084: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000CF088: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000CF090: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF094: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000CF098: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000CF0A0: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000CF0A4: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF0AC: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000CF0B0: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000CF0B4: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF0BC: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000CF0C0: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000CF0C4: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF0CC: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000CF0D0: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000CF0D8: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 0000000CF0E0: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF0EC: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000CF0F0: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000CF0F8: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000CF104: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CF10C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000CF110: BE882000
	s_cbranch_execz 57928                                      // 0000000CF114: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3738>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 0000000CF118: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 0000000CF124: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 0000000CF128: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000CF130: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000CF134: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF138: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000CF13C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000CF144: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000CF150: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CF154: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000CF158: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000CF15C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000CF164: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CF16C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000CF170: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000CF174: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000CF178: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF17C: BF870095
	.long 0xd71c0012                                           // 0000000CF180: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000CF184: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000CF188: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000CF18C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF194: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000CF198: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000CF1A0: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF1A4: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 0000000CF1A8: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 0000000CF1B0: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF1B4: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000000CF1B8: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 0000000CF1C0: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 0000000CF1C4: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF1CC: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 0000000CF1D0: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 0000000CF1D4: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF1DC: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 0000000CF1E0: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 0000000CF1E4: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF1EC: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 0000000CF1F0: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 0000000CF1F8: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 0000000CF200: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF20C: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 0000000CF210: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 0000000CF218: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 0000000CF224: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CF22C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000CF230: BE882001
	s_cbranch_execz 57859                                      // 0000000CF234: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3744>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 0000000CF238: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 0000000CF244: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 0000000CF248: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 0000000CF250: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000CF254: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CF258: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 0000000CF25C: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000CF264: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 0000000CF26C: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 0000000CF278: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000CF27C: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 0000000CF280: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 0000000CF288: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CF28C: BF870121
	v_add_f32_e32 v17, v17, v18                                // 0000000CF290: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 0000000CF294: 7E241113
	v_exp_f32_e32 v17, v17                                     // 0000000CF298: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF29C: BF870095
	.long 0xd71c0011                                           // 0000000CF2A0: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000000CF2A4: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000000CF2A8: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000CF2AC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF2B4: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 0000000CF2B8: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000CF2C0: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF2C4: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 0000000CF2C8: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 0000000CF2D0: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF2D4: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 0000000CF2D8: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 0000000CF2E0: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 0000000CF2E4: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF2EC: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 0000000CF2F0: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 0000000CF2F4: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF2FC: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 0000000CF300: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 0000000CF304: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF30C: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 0000000CF310: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 0000000CF318: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 0000000CF320: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF32C: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 0000000CF330: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000000CF338: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 0000000CF344: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CF34C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000CF350: BE882002
	s_cbranch_execz 57790                                      // 0000000CF354: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3750>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 0000000CF358: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000CF364: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000CF36C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000CF370: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF374: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000CF378: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 0000000CF380: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 0000000CF38C: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CF390: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 0000000CF394: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000CF398: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 0000000CF3A0: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CF3A8: BF870121
	v_add_f32_e32 v10, v10, v17                                // 0000000CF3AC: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 0000000CF3B0: 7E221112
	v_exp_f32_e32 v10, v10                                     // 0000000CF3B4: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF3B8: BF870095
	.long 0xd71c000a                                           // 0000000CF3BC: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 0000000CF3C0: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000CF3C4: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000CF3C8: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF3D0: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 0000000CF3D4: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000CF3E0: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF3E4: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000CF3E8: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 0000000CF3F0: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF3F4: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 0000000CF3F8: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 0000000CF400: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 0000000CF404: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF40C: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 0000000CF410: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 0000000CF414: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF41C: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 0000000CF420: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 0000000CF424: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF42C: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 0000000CF430: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000CF438: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 0000000CF440: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF44C: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 0000000CF450: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 0000000CF458: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000CF464: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CF46C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000CF470: BE882003
	s_cbranch_execz 57721                                      // 0000000CF474: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x375c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 0000000CF478: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000CF484: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000CF48C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000CF490: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF494: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000CF498: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000CF4A0: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 0000000CF4AC: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF4B0: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 0000000CF4B4: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 0000000CF4C0: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 0000000CF4C4: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000CF4C8: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CF4D0: BF870293
	v_exp_f32_e32 v10, v10                                     // 0000000CF4D4: 7E144B0A
	.long 0xd71c000a                                           // 0000000CF4D8: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000CF4DC: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CF4E0: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000CF4E4: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000CF4E8: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 0000000CF4F0: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF4FC: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000CF500: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000CF504: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000CF50C: BF870291
	v_rcp_f32_e32 v12, v11                                     // 0000000CF510: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 0000000CF514: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CF51C: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 0000000CF520: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 0000000CF524: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 0000000CF52C: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF530: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 0000000CF534: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 0000000CF53C: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF540: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 0000000CF544: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 0000000CF54C: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CF554: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000CF558: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 0000000CF560: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000CF56C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CF574: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000CF578: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000CF584: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CF58C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000CF590: BE882004
	s_cbranch_execz 57652                                      // 0000000CF594: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3768>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 0000000CF598: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000CF5A4: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000CF5AC: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000CF5B0: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF5B4: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000CF5B8: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000CF5C0: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000CF5CC: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CF5D0: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000CF5D4: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000CF5D8: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000CF5E0: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CF5E8: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000CF5EC: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000CF5F0: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000CF5F4: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF5F8: BF870095
	.long 0xd71c000a                                           // 0000000CF5FC: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000CF600: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000CF604: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000CF608: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF610: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 0000000CF614: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000CF620: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF624: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000CF628: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000CF630: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF634: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000CF638: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000CF640: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000CF644: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF64C: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 0000000CF650: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 0000000CF654: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF65C: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 0000000CF660: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 0000000CF664: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF66C: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 0000000CF670: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000CF678: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 0000000CF680: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF68C: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000CF690: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000CF698: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000CF6A4: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CF6AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000CF6B0: BE882005
	s_cbranch_execz 57583                                      // 0000000CF6B4: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3774>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 0000000CF6B8: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000CF6C4: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000CF6CC: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000CF6D0: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF6D4: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000CF6D8: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000CF6E0: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000CF6EC: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CF6F0: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000CF6F4: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000CF6F8: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000CF700: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CF708: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000CF70C: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000CF710: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000CF714: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF718: BF870095
	.long 0xd71c000a                                           // 0000000CF71C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000CF720: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000CF724: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000CF728: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF730: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 0000000CF734: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 0000000CF73C: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF744: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000CF748: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000CF750: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF754: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000CF758: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000CF760: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000CF764: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF76C: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000CF770: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 0000000CF774: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF77C: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 0000000CF780: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 0000000CF784: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF78C: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000CF790: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000CF798: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 0000000CF7A0: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF7AC: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000CF7B0: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000CF7B8: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000CF7C4: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CF7CC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000CF7D0: BE882006
	s_cbranch_execz 57514                                      // 0000000CF7D4: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3780>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 0000000CF7D8: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000CF7E4: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000CF7EC: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000CF7F0: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF7F4: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000CF7F8: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000CF800: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000CF80C: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CF810: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000CF814: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000CF818: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000CF820: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CF828: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000CF82C: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000CF830: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000CF834: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF838: BF870095
	.long 0xd71c000a                                           // 0000000CF83C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000CF840: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000CF844: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000CF848: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF850: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 0000000CF854: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000CF860: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF864: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000CF868: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000CF870: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF874: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000CF878: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000CF880: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000CF884: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF88C: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000CF890: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000000CF894: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF89C: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000CF8A0: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000CF8A4: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF8AC: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000CF8B0: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000CF8B8: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 0000000CF8C0: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF8CC: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000CF8D0: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000CF8D8: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000CF8E4: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CF8EC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000CF8F0: BE882007
	s_cbranch_execz 57445                                      // 0000000CF8F4: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x378c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 0000000CF8F8: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000CF904: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000CF90C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000CF910: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF914: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000CF918: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000CF920: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000CF92C: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CF930: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000CF934: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000CF938: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000CF940: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CF948: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000CF94C: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000CF950: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000CF954: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF958: BF870095
	.long 0xd71c000a                                           // 0000000CF95C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000CF960: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000CF964: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000CF968: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF970: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 0000000CF974: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000CF980: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF984: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000CF988: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000CF990: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF994: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000CF998: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000CF9A0: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000CF9A4: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF9AC: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000CF9B0: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000000CF9B4: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF9BC: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000CF9C0: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000CF9C4: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF9CC: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000CF9D0: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000CF9D8: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 0000000CF9E0: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF9EC: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000CF9F0: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000CF9F8: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000CFA04: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CFA0C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000CFA10: BE882000
	s_cbranch_execz 57376                                      // 0000000CFA14: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3798>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 0000000CFA18: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 0000000CFA24: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 0000000CFA28: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000CFA30: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000CFA34: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFA38: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000CFA3C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000CFA44: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000CFA50: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CFA54: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000CFA58: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000CFA5C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000CFA64: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CFA6C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000CFA70: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000CFA74: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000CFA78: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFA7C: BF870095
	.long 0xd71c000a                                           // 0000000CFA80: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000CFA84: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000CFA88: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000CFA8C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFA94: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 0000000CFA98: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000CFAA0: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFAA4: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 0000000CFAA8: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 0000000CFAB0: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFAB4: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 0000000CFAB8: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 0000000CFAC0: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 0000000CFAC4: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFACC: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 0000000CFAD0: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 0000000CFAD4: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFADC: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 0000000CFAE0: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 0000000CFAE4: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFAEC: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 0000000CFAF0: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 0000000CFAF8: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 0000000CFB00: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFB0C: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 0000000CFB10: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000000CFB18: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 0000000CFB24: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000CFB2C: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 0000000CFB30: BE802001
	s_cbranch_execz 57307                                      // 0000000CFB34: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37a4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 0000000CFB38: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000CFB44: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000CFB4C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000CFB50: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFB54: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000CFB58: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 0000000CFB60: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 0000000CFB6C: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CFB70: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 0000000CFB74: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 0000000CFB78: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000CFB80: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CFB88: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 0000000CFB8C: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 0000000CFB90: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 0000000CFB94: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFB98: BF870095
	.long 0xd71c0001                                           // 0000000CFB9C: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 0000000CFBA0: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000CFBA4: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000CFBA8: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFBB0: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 0000000CFBB4: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000CFBC0: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFBC4: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000CFBC8: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 0000000CFBD0: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFBD4: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 0000000CFBD8: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 0000000CFBE0: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 0000000CFBE4: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFBEC: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 0000000CFBF0: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 0000000CFBF4: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFBFC: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 0000000CFC00: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 0000000CFC04: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFC0C: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 0000000CFC10: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000CFC18: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 0000000CFC20: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFC2C: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 0000000CFC30: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 0000000CFC38: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000CFC44: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000CFC4C: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000CFC50: BE802002
	s_cbranch_execz 57238                                      // 0000000CFC54: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37b0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 0000000CFC58: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000CFC64: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000CFC6C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000CFC70: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFC74: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000CFC78: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000CFC80: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 0000000CFC8C: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CFC90: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 0000000CFC94: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000CFC98: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000CFCA0: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CFCA8: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000CFCAC: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 0000000CFCB0: 7E041109
	v_exp_f32_e32 v1, v1                                       // 0000000CFCB4: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFCB8: BF870095
	.long 0xd71c0001                                           // 0000000CFCBC: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000CFCC0: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000CFCC4: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000CFCC8: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFCD0: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 0000000CFCD4: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000CFCE0: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFCE4: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000CFCE8: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000CFCF0: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFCF4: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 0000000CFCF8: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 0000000CFD00: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 0000000CFD04: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFD0C: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 0000000CFD10: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 0000000CFD14: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFD1C: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 0000000CFD20: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 0000000CFD24: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFD2C: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 0000000CFD30: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000CFD38: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 0000000CFD40: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFD4C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000CFD50: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000CFD58: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000CFD64: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000CFD6C: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000CFD70: BE802003
	s_cbranch_execz 57169                                      // 0000000CFD74: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37bc>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 0000000CFD78: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000CFD84: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000CFD8C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000CFD90: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFD94: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000CFD98: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000CFDA0: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000CFDAC: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CFDB0: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000CFDB4: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000CFDB8: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000CFDC0: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CFDC8: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000CFDCC: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000CFDD0: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000CFDD4: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFDD8: BF870095
	.long 0xd71c0001                                           // 0000000CFDDC: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000CFDE0: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000CFDE4: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000CFDE8: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFDF0: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 0000000CFDF4: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000CFE00: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFE04: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000CFE08: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000CFE10: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFE14: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000CFE18: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000CFE20: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000CFE24: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFE2C: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 0000000CFE30: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 0000000CFE34: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFE3C: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 0000000CFE40: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 0000000CFE44: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFE4C: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 0000000CFE50: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000CFE58: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 0000000CFE60: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFE6C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000CFE70: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000CFE78: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000CFE84: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000CFE8C: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000CFE90: BE802004
	s_cbranch_execz 57100                                      // 0000000CFE94: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37c8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 0000000CFE98: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000CFEA4: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000CFEAC: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000CFEB0: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFEB4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000CFEB8: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000CFEC0: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000CFECC: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CFED0: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000CFED4: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000CFED8: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000CFEE0: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CFEE8: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000CFEEC: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000CFEF0: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000CFEF4: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFEF8: BF870095
	.long 0xd71c0001                                           // 0000000CFEFC: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000CFF00: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000CFF04: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000CFF08: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFF10: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 0000000CFF14: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 0000000CFF1C: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFF24: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000CFF28: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000CFF30: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFF34: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000CFF38: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000CFF40: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000CFF44: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFF4C: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000CFF50: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 0000000CFF54: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFF5C: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 0000000CFF60: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000CFF64: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFF6C: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000CFF70: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000CFF78: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 0000000CFF80: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFF8C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000CFF90: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000CFF98: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000CFFA4: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000CFFAC: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000CFFB0: BE802005
	s_cbranch_execz 57031                                      // 0000000CFFB4: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37d4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 0000000CFFB8: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000CFFC4: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000CFFCC: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000CFFD0: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFFD4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000CFFD8: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000CFFE0: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000CFFEC: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000CFFF0: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000CFFF4: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000CFFF8: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000D0000: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D0008: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000D000C: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000D0010: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000D0014: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0018: BF870095
	.long 0xd71c0001                                           // 0000000D001C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000D0020: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000D0024: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000D0028: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0030: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 0000000D0034: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000D0040: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0044: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000D0048: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000D0050: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0054: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000D0058: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000D0060: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000D0064: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D006C: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000D0070: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000D0074: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D007C: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000D0080: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000D0084: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D008C: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000D0090: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000D0098: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 0000000D00A0: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D00AC: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000D00B0: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000D00B8: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000D00C4: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000D00CC: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000D00D0: BE802006
	s_cbranch_execz 56962                                      // 0000000D00D4: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37e0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 0000000D00D8: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000D00E4: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000D00EC: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000D00F0: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D00F4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000D00F8: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000D0100: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000D010C: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000D0110: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000D0114: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000D0118: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000D0120: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D0128: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000D012C: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000D0130: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000D0134: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0138: BF870095
	.long 0xd71c0001                                           // 0000000D013C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000D0140: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000D0144: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000D0148: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0150: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 0000000D0154: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000D0160: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0164: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000D0168: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000D0170: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0174: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000D0178: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000D0180: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000D0184: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D018C: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000D0190: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000D0194: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D019C: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000D01A0: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000D01A4: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D01AC: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000D01B0: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000D01B8: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 0000000D01C0: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D01CC: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000D01D0: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000D01D8: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000D01E4: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000D01EC: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000D01F0: BE802007
	s_cbranch_execz 56893                                      // 0000000D01F4: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi0ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37ec>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 0000000D01F8: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000D0204: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000D020C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000D0210: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0214: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000D0218: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000D0220: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000D022C: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000D0230: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000D0234: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000D0238: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000D0240: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D0248: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000D024C: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000D0250: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000D0254: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0258: BF870095
	.long 0xd71c0001                                           // 0000000D025C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000D0260: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000D0264: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000D0268: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0270: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 0000000D0274: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000D0280: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0284: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000D0288: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000D0290: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0294: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000D0298: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000D02A0: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000D02A4: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D02AC: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000D02B0: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000D02B4: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D02BC: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000D02C0: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000D02C4: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D02CC: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000D02D0: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000D02D8: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 0000000D02E0: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D02EC: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000D02F0: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000D02F8: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000D0304: DC9601E0 007C0200
	s_nop 0                                                    // 0000000D030C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000000D0310: BFB60003
	s_endpgm                                                   // 0000000D0314: BFB00000
		...

