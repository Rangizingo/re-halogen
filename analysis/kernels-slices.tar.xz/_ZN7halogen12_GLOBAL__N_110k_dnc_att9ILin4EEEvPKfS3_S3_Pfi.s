000000000021ac00 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi():
	s_mov_b32 s12, s3                                          // 00000021AC00: BE8C0003
	s_clause 0x1                                               // 00000021AC04: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 00000021AC08: F40C0100 F8000000
	s_load_b32 s3, s[0:1], 0x20                                // 00000021AC10: F40000C0 F8000020
	v_and_b32_e32 v1, 0x7f, v0                                 // 00000021AC18: 360200FF 0000007F
	s_lshl_b32 s0, s2, 6                                       // 00000021AC20: 84008602
	s_ashr_i32 s13, s12, 31                                    // 00000021AC24: 860D9F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000021AC28: BF8700B1
	v_dual_mov_b32 v5, v0 :: v_dual_lshlrev_b32 v2, 1, v1      // 00000021AC2C: CA220100 05020281
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000021AC34: 30060282
	s_waitcnt lgkmcnt(0)                                       // 00000021AC38: BF89FC07
	.long 0xd7000103                                           // 00000021AC3C: D7000103
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 00000021AC40: 02020606
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021AC44: BF870001
	v_add_co_ci_u32_e64 v4, null, s7, 0, s1                    // 00000021AC48: D5207C04 00050007
	s_mov_b32 s1, 0                                            // 00000021AC50: BE810080
	s_mov_b32 s6, 0x3d800000                                   // 00000021AC54: BE8600FF 3D800000
	s_set_inst_prefetch_distance 0x1                           // 00000021AC5C: BF840001
	s_branch 22                                                // 00000021AC60: BFA00016 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xbc>
	s_nop 0                                                    // 00000021AC64: BF800000
	s_nop 0                                                    // 00000021AC68: BF800000
	s_nop 0                                                    // 00000021AC6C: BF800000
	s_nop 0                                                    // 00000021AC70: BF800000
	s_nop 0                                                    // 00000021AC74: BF800000
	s_nop 0                                                    // 00000021AC78: BF800000
	s_nop 0                                                    // 00000021AC7C: BF800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000021AC80: 8C7E077E
	v_add_nc_u32_e32 v8, 0x100, v5                             // 00000021AC84: 4A100AFF 00000100
	v_mad_u64_u32 v[6:7], null, 0x120, v6, v[2:3]              // 00000021AC8C: D6FE7C06 040A0CFF 00000120
	v_cmp_lt_u32_e32 vcc_lo, 0x1eff, v5                        // 00000021AC98: 7C920AFF 00001EFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000021ACA0: BF870003
	v_mov_b32_e32 v5, v8                                       // 00000021ACA4: 7E0A0308
	s_or_b32 s1, vcc_lo, s1                                    // 00000021ACA8: 8C01016A
	ds_store_b16 v6, v1                                        // 00000021ACAC: D87C0000 00000106
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000021ACB4: 917E017E
	s_cbranch_execz 24                                         // 00000021ACB8: BFA50018 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x11c>
	v_lshrrev_b32_e32 v6, 7, v5                                // 00000021ACBC: 320C0A87
	.long 0x7e023880                                           // 00000021ACC0: 7E023880
	s_mov_b32 s7, exec_lo                                      // 00000021ACC4: BE87007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021ACC8: BF870092
	v_or_b32_e32 v7, s0, v6                                    // 00000021ACCC: 380E0C00
	.long 0xd4c4007e                                           // 00000021ACD0: D4C4007E
	v_cndmask_b32_e32 v1, s3, v7, vcc_lo                       // 00000021ACD4: 02020E03
	s_cbranch_execz 65513                                      // 00000021ACD8: BFA5FFE9 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x80>
	v_mad_i64_i32 v[7:8], null, v7, 48, s[12:13]               // 00000021ACDC: D6FF7C07 00316107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021ACE4: BF870091
	.long 0xd73c0007                                           // 00000021ACE8: D73C0007
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 00000021ACEC: 02020E89
	.long 0xd7006a07                                           // 00000021ACF0: D7006A07
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 00000021ACF4: 02020F03
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021ACF8: BF870001
	v_add_co_ci_u32_e64 v8, null, v4, v8, vcc_lo               // 00000021ACFC: D5207C08 01AA1104
	global_load_b32 v1, v[7:8], off                            // 00000021AD04: DC520000 017C0007
	s_waitcnt vmcnt(0)                                         // 00000021AD0C: BF8903F7
	v_fma_mixlo_f16 v1, v1, s6, 0                              // 00000021AD10: CC210001 02000D01
	s_branch 65497                                             // 00000021AD18: BFA0FFD9 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x80>
	s_set_inst_prefetch_distance 0x2                           // 00000021AD1C: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021AD20: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000021AD24: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000021AD28: BE81007E
	v_cmpx_gt_u32_e32 64, v0                                   // 00000021AD2C: 7D9800C0
	s_cbranch_execz 17                                         // 00000021AD30: BFA50011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x178>
	v_or_b32_e32 v1, s0, v0                                    // 00000021AD34: 38020000
	s_lshl_b64 s[6:7], s[12:13], 2                             // 00000021AD38: 8486820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021AD3C: BF870091
	v_mad_i64_i32 v[1:2], null, 0xc0, v1, s[8:9]               // 00000021AD40: D6FF7C01 002202FF 000000C0
	.long 0xd7006a01                                           // 00000021AD4C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000021AD50: 02000D01
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021AD54: BF870001
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 00000021AD58: D5207C02 01AA0407
	global_load_b32 v1, v[1:2], off                            // 00000021AD60: DC520000 017C0001
	v_lshlrev_b32_e32 v2, 2, v0                                // 00000021AD68: 30040082
	s_waitcnt vmcnt(0)                                         // 00000021AD6C: BF8903F7
	ds_store_b32 v2, v1 offset:18432                           // 00000021AD70: D8344800 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021AD78: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 00000021AD7C: BF89FC07
	s_barrier                                                  // 00000021AD80: BFBD0000
	buffer_gl0_inv                                             // 00000021AD84: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 00000021AD8C: BE81007E
	v_cmpx_gt_u32_e32 0x200, v0                                // 00000021AD90: 7D9800FF 00000200
	s_cbranch_execz 1796                                       // 00000021AD98: BFA50704 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1dac>
	v_and_b32_e32 v1, 15, v0                                   // 00000021AD9C: 3602008F
	v_bfe_u32 v28, v0, 5, 2                                    // 00000021ADA0: D610001C 02090B00
	s_mul_i32 s1, s2, 48                                       // 00000021ADA8: 9601B002
	s_mul_hi_u32 s2, s2, 48                                    // 00000021ADAC: 9682B002
	s_add_u32 s6, s1, s12                                      // 00000021ADB0: 80060C01
	v_mul_u32_u24_e32 v2, 0x120, v1                            // 00000021ADB4: 160402FF 00000120
	v_lshl_or_b32 v29, v28, 4, v1                              // 00000021ADBC: D656001D 0405091C
	v_mul_u32_u24_e32 v3, 0x1200, v28                          // 00000021ADC4: 160638FF 00001200
	s_addc_u32 s7, s2, s13                                     // 00000021ADCC: 82070D02
	v_lshrrev_b32_e32 v33, 5, v0                               // 00000021ADD0: 32420085
	s_lshl_b64 s[6:7], s[6:7], 14                              // 00000021ADD4: 84868E06
	v_or_b32_e32 v30, s0, v1                                   // 00000021ADD8: 383C0200
	v_bfe_u32 v31, v0, 4, 1                                    // 00000021ADDC: D610001F 02050900
	v_lshl_or_b32 v32, v29, 2, 0x4800                          // 00000021ADE4: D6560020 03FD051D 00004800
	v_dual_mov_b32 v1, 0 :: v_dual_add_nc_u32 v34, v2, v3      // 00000021ADF0: CA200080 01220702
	s_add_u32 s2, s10, s6                                      // 00000021ADF8: 8002060A
	s_addc_u32 s6, s11, s7                                     // 00000021ADFC: 8206070B
	s_mov_b32 s7, 0                                            // 00000021AE00: BE870080
	s_mov_b32 s8, 0x3d800000                                   // 00000021AE04: BE8800FF 3D800000
	s_branch 19                                                // 00000021AE0C: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x25c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021AE10: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 00000021AE14: D6560000 04750D03
	v_cmp_lt_u32_e32 vcc_lo, 7, v33                            // 00000021AE1C: 7C924287
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000021AE20: BF8700B2
	.long 0xd73c0003                                           // 00000021AE24: D73C0003
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021AE28: 02020082
	v_add_nc_u32_e32 v0, 8, v33                                // 00000021AE2C: 4A004288
	s_or_b32 s7, vcc_lo, s7                                    // 00000021AE30: 8C07076A
	v_mov_b32_e32 v33, v0                                      // 00000021AE34: 7E420300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021AE38: BF870093
	.long 0xd7000003                                           // 00000021AE3C: D7000003
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 00000021AE40: 02020602
	v_add_co_ci_u32_e64 v4, null, s6, v4, s0                   // 00000021AE44: D5207C04 00020806
	global_store_b32 v[3:4], v2, off                           // 00000021AE4C: DC6A0000 007C0203
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 00000021AE54: 917E077E
	s_cbranch_execz 1748                                       // 00000021AE58: BFA506D4 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1dac>
	v_lshrrev_b32_e32 v0, 2, v33                               // 00000021AE5C: 32004282
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 00000021AE60: CA100080 09080080
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v5, 0               // 00000021AE68: CA100080 06040080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000021AE70: BF870003
	v_cmp_lt_u32_e32 vcc_lo, v0, v28                           // 00000021AE74: 7C923900
	.long 0xd44e0000                                           // 00000021AE78: D44E0000
	v_cndmask_b32_e32 v1, v0, v28, vcc_lo                      // 00000021AE7C: 02023900
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v0, 4, v0       // 00000021AE80: CA220080 07000084
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 00000021AE88: CA100080 04020080
	v_mov_b32_e32 v2, 0                                        // 00000021AE90: 7E040280
	s_and_saveexec_b32 s9, s0                                  // 00000021AE94: BE892000
	s_cbranch_execz 1301                                       // 00000021AE98: BFA50515 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x16f0>
	v_add_nc_u32_e32 v4, v0, v30                               // 00000021AE9C: 4A083D00
	.long 0x7f143880                                           // 00000021AEA0: 7F143880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000021AEA4: BF8701A2
	v_mad_i64_i32 v[2:3], null, v4, 48, s[12:13]               // 00000021AEA8: D6FF7C02 00316104
	.long 0xd4440000                                           // 00000021AEB0: D4440000
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 00000021AEB4: 02020803
	.long 0x7e14398a                                           // 00000021AEB8: 7E14398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021AEBC: BF870093
	.long 0xd73c0002                                           // 00000021AEC0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000021AEC4: 02020489
	.long 0xd700011a                                           // 00000021AEC8: D700011A
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000021AECC: 02020404
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021AED0: BF870001
	v_add_co_ci_u32_e64 v27, null, s5, v3, s1                  // 00000021AED4: D5207C1B 00060605
	s_and_saveexec_b32 s1, s0                                  // 00000021AEDC: BE812000
	s_cbranch_execz 5                                          // 00000021AEE0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x2f8>
	global_load_b32 v2, v[26:27], off                          // 00000021AEE4: DC520000 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021AEEC: BF8903F7
	v_fma_mixlo_f16 v10, v2, s8, 0                             // 00000021AEF0: CC21000A 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021AEF8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021AEFC: BE812000
	s_cbranch_execz 5                                          // 00000021AF00: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x318>
	global_load_b32 v2, v[26:27], off offset:4                 // 00000021AF04: DC520004 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021AF0C: BF8903F7
	v_fma_mixhi_f16 v10, v2, s8, 0                             // 00000021AF10: CC22000A 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021AF18: 8C7E017E
	.long 0x7f163880                                           // 00000021AF1C: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021AF20: BF870001
	.long 0x7e16398b                                           // 00000021AF24: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 00000021AF28: BE812000
	s_cbranch_execz 5                                          // 00000021AF2C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x344>
	global_load_b32 v2, v[26:27], off offset:8                 // 00000021AF30: DC520008 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021AF38: BF8903F7
	v_fma_mixlo_f16 v11, v2, s8, 0                             // 00000021AF3C: CC21000B 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021AF44: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021AF48: BE812000
	s_cbranch_execz 5                                          // 00000021AF4C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x364>
	global_load_b32 v2, v[26:27], off offset:12                // 00000021AF50: DC52000C 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021AF58: BF8903F7
	v_fma_mixhi_f16 v11, v2, s8, 0                             // 00000021AF5C: CC22000B 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021AF64: 8C7E017E
	.long 0x7f183880                                           // 00000021AF68: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021AF6C: BF870001
	.long 0x7e18398c                                           // 00000021AF70: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000021AF74: BE812000
	s_cbranch_execz 5                                          // 00000021AF78: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x390>
	global_load_b32 v2, v[26:27], off offset:16                // 00000021AF7C: DC520010 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021AF84: BF8903F7
	v_fma_mixlo_f16 v12, v2, s8, 0                             // 00000021AF88: CC21000C 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021AF90: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021AF94: BE812000
	s_cbranch_execz 5                                          // 00000021AF98: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x3b0>
	global_load_b32 v2, v[26:27], off offset:20                // 00000021AF9C: DC520014 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021AFA4: BF8903F7
	v_fma_mixhi_f16 v12, v2, s8, 0                             // 00000021AFA8: CC22000C 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021AFB0: 8C7E017E
	.long 0x7f1a3880                                           // 00000021AFB4: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021AFB8: BF870001
	.long 0x7e1a398d                                           // 00000021AFBC: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 00000021AFC0: BE812000
	s_cbranch_execz 5                                          // 00000021AFC4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x3dc>
	global_load_b32 v2, v[26:27], off offset:24                // 00000021AFC8: DC520018 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021AFD0: BF8903F7
	v_fma_mixlo_f16 v13, v2, s8, 0                             // 00000021AFD4: CC21000D 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021AFDC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021AFE0: BE812000
	s_cbranch_execz 5                                          // 00000021AFE4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x3fc>
	global_load_b32 v2, v[26:27], off offset:28                // 00000021AFE8: DC52001C 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021AFF0: BF8903F7
	v_fma_mixhi_f16 v13, v2, s8, 0                             // 00000021AFF4: CC22000D 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021AFFC: 8C7E017E
	.long 0x7f1c3880                                           // 00000021B000: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B004: BF870001
	.long 0x7e1c398e                                           // 00000021B008: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000021B00C: BE812000
	s_cbranch_execz 5                                          // 00000021B010: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x428>
	global_load_b32 v2, v[26:27], off offset:32                // 00000021B014: DC520020 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021B01C: BF8903F7
	v_fma_mixlo_f16 v14, v2, s8, 0                             // 00000021B020: CC21000E 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B028: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B02C: BE812000
	s_cbranch_execz 5                                          // 00000021B030: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x448>
	global_load_b32 v2, v[26:27], off offset:36                // 00000021B034: DC520024 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021B03C: BF8903F7
	v_fma_mixhi_f16 v14, v2, s8, 0                             // 00000021B040: CC22000E 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B048: 8C7E017E
	.long 0x7f1e3880                                           // 00000021B04C: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B050: BF870001
	.long 0x7e1e398f                                           // 00000021B054: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 00000021B058: BE812000
	s_cbranch_execz 5                                          // 00000021B05C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x474>
	global_load_b32 v2, v[26:27], off offset:40                // 00000021B060: DC520028 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021B068: BF8903F7
	v_fma_mixlo_f16 v15, v2, s8, 0                             // 00000021B06C: CC21000F 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B074: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B078: BE812000
	s_cbranch_execz 5                                          // 00000021B07C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x494>
	global_load_b32 v2, v[26:27], off offset:44                // 00000021B080: DC52002C 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021B088: BF8903F7
	v_fma_mixhi_f16 v15, v2, s8, 0                             // 00000021B08C: CC22000F 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B094: 8C7E017E
	.long 0x7f203880                                           // 00000021B098: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B09C: BF870001
	.long 0x7e203990                                           // 00000021B0A0: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 00000021B0A4: BE812000
	s_cbranch_execz 5                                          // 00000021B0A8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x4c0>
	global_load_b32 v2, v[26:27], off offset:48                // 00000021B0AC: DC520030 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021B0B4: BF8903F7
	v_fma_mixlo_f16 v16, v2, s8, 0                             // 00000021B0B8: CC210010 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B0C0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B0C4: BE812000
	s_cbranch_execz 5                                          // 00000021B0C8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x4e0>
	global_load_b32 v2, v[26:27], off offset:52                // 00000021B0CC: DC520034 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021B0D4: BF8903F7
	v_fma_mixhi_f16 v16, v2, s8, 0                             // 00000021B0D8: CC220010 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B0E0: 8C7E017E
	.long 0x7f223880                                           // 00000021B0E4: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B0E8: BF870001
	.long 0x7e223991                                           // 00000021B0EC: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 00000021B0F0: BE812000
	s_cbranch_execz 5                                          // 00000021B0F4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x50c>
	global_load_b32 v2, v[26:27], off offset:56                // 00000021B0F8: DC520038 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021B100: BF8903F7
	v_fma_mixlo_f16 v17, v2, s8, 0                             // 00000021B104: CC210011 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B10C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B110: BE812000
	s_cbranch_execz 5                                          // 00000021B114: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x52c>
	global_load_b32 v2, v[26:27], off offset:60                // 00000021B118: DC52003C 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021B120: BF8903F7
	v_fma_mixhi_f16 v17, v2, s8, 0                             // 00000021B124: CC220011 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B12C: 8C7E017E
	ds_load_b128 v[35:38], v34                                 // 00000021B130: DBFC0000 23000022
	ds_load_b128 v[39:42], v34 offset:16                       // 00000021B138: DBFC0010 27000022
	v_mov_b32_e32 v8, v1                                       // 00000021B140: 7E100301
	v_mov_b32_e32 v2, v1                                       // 00000021B144: 7E040301
	v_mov_b32_e32 v3, v1                                       // 00000021B148: 7E060301
	v_mov_b32_e32 v4, v1                                       // 00000021B14C: 7E080301
	v_mov_b32_e32 v5, v1                                       // 00000021B150: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 00000021B154: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000021B158: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 00000021B15C: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000021B160: BF870212
	v_mov_b32_e32 v8, v7                                       // 00000021B164: 7E100307
	v_mov_b32_e32 v7, v6                                       // 00000021B168: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 00000021B16C: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 00000021B170: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 00000021B174: 7E080303
	v_mov_b32_e32 v3, v2                                       // 00000021B178: 7E060302
	v_mov_b32_e32 v2, v1                                       // 00000021B17C: 7E040301
	.long 0x7f243880                                           // 00000021B180: 7F243880
	s_waitcnt lgkmcnt(0)                                       // 00000021B184: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021B188: BF870112
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000021B18C: CC404002 1C0A470A
	.long 0x7e243992                                           // 00000021B194: 7E243992
	s_and_saveexec_b32 s1, s0                                  // 00000021B198: BE812000
	s_cbranch_execz 5                                          // 00000021B19C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x5b4>
	global_load_b32 v10, v[26:27], off offset:64               // 00000021B1A0: DC520040 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B1A8: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 00000021B1AC: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B1B4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B1B8: BE812000
	s_cbranch_execz 5                                          // 00000021B1BC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x5d4>
	global_load_b32 v10, v[26:27], off offset:68               // 00000021B1C0: DC520044 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B1C8: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 00000021B1CC: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B1D4: 8C7E017E
	.long 0x7f263880                                           // 00000021B1D8: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B1DC: BF870001
	.long 0x7e263993                                           // 00000021B1E0: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000021B1E4: BE812000
	s_cbranch_execz 5                                          // 00000021B1E8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x600>
	global_load_b32 v10, v[26:27], off offset:72               // 00000021B1EC: DC520048 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B1F4: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 00000021B1F8: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B200: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B204: BE812000
	s_cbranch_execz 5                                          // 00000021B208: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x620>
	global_load_b32 v10, v[26:27], off offset:76               // 00000021B20C: DC52004C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B214: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 00000021B218: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B220: 8C7E017E
	.long 0x7f283880                                           // 00000021B224: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B228: BF870001
	.long 0x7e283994                                           // 00000021B22C: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000021B230: BE812000
	s_cbranch_execz 5                                          // 00000021B234: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x64c>
	global_load_b32 v10, v[26:27], off offset:80               // 00000021B238: DC520050 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B240: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 00000021B244: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B24C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B250: BE812000
	s_cbranch_execz 5                                          // 00000021B254: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x66c>
	global_load_b32 v10, v[26:27], off offset:84               // 00000021B258: DC520054 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B260: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 00000021B264: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B26C: 8C7E017E
	.long 0x7f2a3880                                           // 00000021B270: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B274: BF870001
	.long 0x7e2a3995                                           // 00000021B278: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000021B27C: BE812000
	s_cbranch_execz 5                                          // 00000021B280: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x698>
	global_load_b32 v10, v[26:27], off offset:88               // 00000021B284: DC520058 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B28C: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 00000021B290: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B298: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B29C: BE812000
	s_cbranch_execz 5                                          // 00000021B2A0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x6b8>
	global_load_b32 v10, v[26:27], off offset:92               // 00000021B2A4: DC52005C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B2AC: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 00000021B2B0: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B2B8: 8C7E017E
	.long 0x7f2c3880                                           // 00000021B2BC: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B2C0: BF870001
	.long 0x7e2c3996                                           // 00000021B2C4: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000021B2C8: BE812000
	s_cbranch_execz 5                                          // 00000021B2CC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x6e4>
	global_load_b32 v10, v[26:27], off offset:96               // 00000021B2D0: DC520060 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B2D8: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 00000021B2DC: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B2E4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B2E8: BE812000
	s_cbranch_execz 5                                          // 00000021B2EC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x704>
	global_load_b32 v10, v[26:27], off offset:100              // 00000021B2F0: DC520064 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B2F8: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 00000021B2FC: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B304: 8C7E017E
	.long 0x7f2e3880                                           // 00000021B308: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B30C: BF870001
	.long 0x7e2e3997                                           // 00000021B310: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000021B314: BE812000
	s_cbranch_execz 5                                          // 00000021B318: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x730>
	global_load_b32 v10, v[26:27], off offset:104              // 00000021B31C: DC520068 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B324: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 00000021B328: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B330: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B334: BE812000
	s_cbranch_execz 5                                          // 00000021B338: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x750>
	global_load_b32 v10, v[26:27], off offset:108              // 00000021B33C: DC52006C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B344: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 00000021B348: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B350: 8C7E017E
	.long 0x7f303880                                           // 00000021B354: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B358: BF870001
	.long 0x7e303998                                           // 00000021B35C: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000021B360: BE812000
	s_cbranch_execz 5                                          // 00000021B364: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x77c>
	global_load_b32 v10, v[26:27], off offset:112              // 00000021B368: DC520070 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B370: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 00000021B374: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B37C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B380: BE812000
	s_cbranch_execz 5                                          // 00000021B384: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x79c>
	global_load_b32 v10, v[26:27], off offset:116              // 00000021B388: DC520074 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B390: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 00000021B394: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B39C: 8C7E017E
	.long 0x7f323880                                           // 00000021B3A0: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B3A4: BF870001
	.long 0x7e323999                                           // 00000021B3A8: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000021B3AC: BE812000
	s_cbranch_execz 5                                          // 00000021B3B0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x7c8>
	global_load_b32 v10, v[26:27], off offset:120              // 00000021B3B4: DC520078 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B3BC: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 00000021B3C0: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B3C8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B3CC: BE812000
	s_cbranch_execz 5                                          // 00000021B3D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x7e8>
	global_load_b32 v10, v[26:27], off offset:124              // 00000021B3D4: DC52007C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B3DC: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 00000021B3E0: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B3E8: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:32                       // 00000021B3EC: DBFC0020 23000022
	ds_load_b128 v[39:42], v34 offset:48                       // 00000021B3F4: DBFC0030 27000022
	.long 0x7f143880                                           // 00000021B3FC: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B400: BF870001
	.long 0x7e14398a                                           // 00000021B404: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 00000021B408: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 00000021B40C: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 00000021B414: BE812000
	s_cbranch_execz 5                                          // 00000021B418: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x830>
	global_load_b32 v11, v[26:27], off offset:128              // 00000021B41C: DC520080 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B424: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 00000021B428: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B430: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B434: BE812000
	s_cbranch_execz 5                                          // 00000021B438: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x850>
	global_load_b32 v11, v[26:27], off offset:132              // 00000021B43C: DC520084 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B444: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 00000021B448: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B450: 8C7E017E
	.long 0x7f163880                                           // 00000021B454: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B458: BF870001
	.long 0x7e16398b                                           // 00000021B45C: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 00000021B460: BE812000
	s_cbranch_execz 5                                          // 00000021B464: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x87c>
	global_load_b32 v12, v[26:27], off offset:136              // 00000021B468: DC520088 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B470: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 00000021B474: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B47C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B480: BE812000
	s_cbranch_execz 5                                          // 00000021B484: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x89c>
	global_load_b32 v12, v[26:27], off offset:140              // 00000021B488: DC52008C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B490: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 00000021B494: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B49C: 8C7E017E
	.long 0x7f183880                                           // 00000021B4A0: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B4A4: BF870001
	.long 0x7e18398c                                           // 00000021B4A8: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000021B4AC: BE812000
	s_cbranch_execz 5                                          // 00000021B4B0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x8c8>
	global_load_b32 v13, v[26:27], off offset:144              // 00000021B4B4: DC520090 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B4BC: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 00000021B4C0: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B4C8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B4CC: BE812000
	s_cbranch_execz 5                                          // 00000021B4D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x8e8>
	global_load_b32 v13, v[26:27], off offset:148              // 00000021B4D4: DC520094 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B4DC: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 00000021B4E0: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B4E8: 8C7E017E
	.long 0x7f1a3880                                           // 00000021B4EC: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B4F0: BF870001
	.long 0x7e1a398d                                           // 00000021B4F4: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 00000021B4F8: BE812000
	s_cbranch_execz 5                                          // 00000021B4FC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x914>
	global_load_b32 v14, v[26:27], off offset:152              // 00000021B500: DC520098 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B508: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 00000021B50C: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B514: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B518: BE812000
	s_cbranch_execz 5                                          // 00000021B51C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x934>
	global_load_b32 v14, v[26:27], off offset:156              // 00000021B520: DC52009C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B528: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 00000021B52C: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B534: 8C7E017E
	.long 0x7f1c3880                                           // 00000021B538: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B53C: BF870001
	.long 0x7e1c398e                                           // 00000021B540: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000021B544: BE812000
	s_cbranch_execz 5                                          // 00000021B548: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x960>
	global_load_b32 v15, v[26:27], off offset:160              // 00000021B54C: DC5200A0 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B554: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 00000021B558: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B560: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B564: BE812000
	s_cbranch_execz 5                                          // 00000021B568: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x980>
	global_load_b32 v15, v[26:27], off offset:164              // 00000021B56C: DC5200A4 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B574: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 00000021B578: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B580: 8C7E017E
	.long 0x7f1e3880                                           // 00000021B584: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B588: BF870001
	.long 0x7e1e398f                                           // 00000021B58C: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 00000021B590: BE812000
	s_cbranch_execz 5                                          // 00000021B594: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x9ac>
	global_load_b32 v16, v[26:27], off offset:168              // 00000021B598: DC5200A8 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021B5A0: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 00000021B5A4: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B5AC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B5B0: BE812000
	s_cbranch_execz 5                                          // 00000021B5B4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x9cc>
	global_load_b32 v16, v[26:27], off offset:172              // 00000021B5B8: DC5200AC 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021B5C0: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 00000021B5C4: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B5CC: 8C7E017E
	.long 0x7f203880                                           // 00000021B5D0: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B5D4: BF870001
	.long 0x7e203990                                           // 00000021B5D8: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 00000021B5DC: BE812000
	s_cbranch_execz 5                                          // 00000021B5E0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x9f8>
	global_load_b32 v17, v[26:27], off offset:176              // 00000021B5E4: DC5200B0 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021B5EC: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 00000021B5F0: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B5F8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B5FC: BE812000
	s_cbranch_execz 5                                          // 00000021B600: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xa18>
	global_load_b32 v17, v[26:27], off offset:180              // 00000021B604: DC5200B4 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021B60C: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 00000021B610: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B618: 8C7E017E
	.long 0x7f223880                                           // 00000021B61C: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B620: BF870001
	.long 0x7e223991                                           // 00000021B624: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 00000021B628: BE812000
	s_cbranch_execz 5                                          // 00000021B62C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xa44>
	global_load_b32 v18, v[26:27], off offset:184              // 00000021B630: DC5200B8 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021B638: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 00000021B63C: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B644: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B648: BE812000
	s_cbranch_execz 5                                          // 00000021B64C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xa64>
	global_load_b32 v18, v[26:27], off offset:188              // 00000021B650: DC5200BC 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021B658: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 00000021B65C: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B664: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:64                       // 00000021B668: DBFC0040 23000022
	ds_load_b128 v[39:42], v34 offset:80                       // 00000021B670: DBFC0050 27000022
	.long 0x7f243880                                           // 00000021B678: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B67C: BF870001
	.long 0x7e243992                                           // 00000021B680: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 00000021B684: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000021B688: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 00000021B690: BE812000
	s_cbranch_execz 5                                          // 00000021B694: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xaac>
	global_load_b32 v10, v[26:27], off offset:192              // 00000021B698: DC5200C0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B6A0: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 00000021B6A4: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B6AC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B6B0: BE812000
	s_cbranch_execz 5                                          // 00000021B6B4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xacc>
	global_load_b32 v10, v[26:27], off offset:196              // 00000021B6B8: DC5200C4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B6C0: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 00000021B6C4: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B6CC: 8C7E017E
	.long 0x7f263880                                           // 00000021B6D0: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B6D4: BF870001
	.long 0x7e263993                                           // 00000021B6D8: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000021B6DC: BE812000
	s_cbranch_execz 5                                          // 00000021B6E0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xaf8>
	global_load_b32 v10, v[26:27], off offset:200              // 00000021B6E4: DC5200C8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B6EC: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 00000021B6F0: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B6F8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B6FC: BE812000
	s_cbranch_execz 5                                          // 00000021B700: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xb18>
	global_load_b32 v10, v[26:27], off offset:204              // 00000021B704: DC5200CC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B70C: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 00000021B710: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B718: 8C7E017E
	.long 0x7f283880                                           // 00000021B71C: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B720: BF870001
	.long 0x7e283994                                           // 00000021B724: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000021B728: BE812000
	s_cbranch_execz 5                                          // 00000021B72C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xb44>
	global_load_b32 v10, v[26:27], off offset:208              // 00000021B730: DC5200D0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B738: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 00000021B73C: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B744: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B748: BE812000
	s_cbranch_execz 5                                          // 00000021B74C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xb64>
	global_load_b32 v10, v[26:27], off offset:212              // 00000021B750: DC5200D4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B758: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 00000021B75C: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B764: 8C7E017E
	.long 0x7f2a3880                                           // 00000021B768: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B76C: BF870001
	.long 0x7e2a3995                                           // 00000021B770: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000021B774: BE812000
	s_cbranch_execz 5                                          // 00000021B778: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xb90>
	global_load_b32 v10, v[26:27], off offset:216              // 00000021B77C: DC5200D8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B784: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 00000021B788: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B790: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B794: BE812000
	s_cbranch_execz 5                                          // 00000021B798: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xbb0>
	global_load_b32 v10, v[26:27], off offset:220              // 00000021B79C: DC5200DC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B7A4: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 00000021B7A8: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B7B0: 8C7E017E
	.long 0x7f2c3880                                           // 00000021B7B4: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B7B8: BF870001
	.long 0x7e2c3996                                           // 00000021B7BC: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000021B7C0: BE812000
	s_cbranch_execz 5                                          // 00000021B7C4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xbdc>
	global_load_b32 v10, v[26:27], off offset:224              // 00000021B7C8: DC5200E0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B7D0: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 00000021B7D4: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B7DC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B7E0: BE812000
	s_cbranch_execz 5                                          // 00000021B7E4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xbfc>
	global_load_b32 v10, v[26:27], off offset:228              // 00000021B7E8: DC5200E4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B7F0: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 00000021B7F4: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B7FC: 8C7E017E
	.long 0x7f2e3880                                           // 00000021B800: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B804: BF870001
	.long 0x7e2e3997                                           // 00000021B808: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000021B80C: BE812000
	s_cbranch_execz 5                                          // 00000021B810: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xc28>
	global_load_b32 v10, v[26:27], off offset:232              // 00000021B814: DC5200E8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B81C: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 00000021B820: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B828: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B82C: BE812000
	s_cbranch_execz 5                                          // 00000021B830: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xc48>
	global_load_b32 v10, v[26:27], off offset:236              // 00000021B834: DC5200EC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B83C: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 00000021B840: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B848: 8C7E017E
	.long 0x7f303880                                           // 00000021B84C: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B850: BF870001
	.long 0x7e303998                                           // 00000021B854: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000021B858: BE812000
	s_cbranch_execz 5                                          // 00000021B85C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xc74>
	global_load_b32 v10, v[26:27], off offset:240              // 00000021B860: DC5200F0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B868: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 00000021B86C: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B874: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B878: BE812000
	s_cbranch_execz 5                                          // 00000021B87C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xc94>
	global_load_b32 v10, v[26:27], off offset:244              // 00000021B880: DC5200F4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B888: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 00000021B88C: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B894: 8C7E017E
	.long 0x7f323880                                           // 00000021B898: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B89C: BF870001
	.long 0x7e323999                                           // 00000021B8A0: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000021B8A4: BE812000
	s_cbranch_execz 5                                          // 00000021B8A8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xcc0>
	global_load_b32 v10, v[26:27], off offset:248              // 00000021B8AC: DC5200F8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B8B4: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 00000021B8B8: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B8C0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B8C4: BE812000
	s_cbranch_execz 5                                          // 00000021B8C8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xce0>
	global_load_b32 v10, v[26:27], off offset:252              // 00000021B8CC: DC5200FC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B8D4: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 00000021B8D8: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B8E0: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:96                       // 00000021B8E4: DBFC0060 23000022
	ds_load_b128 v[39:42], v34 offset:112                      // 00000021B8EC: DBFC0070 27000022
	.long 0x7f143880                                           // 00000021B8F4: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B8F8: BF870001
	.long 0x7e14398a                                           // 00000021B8FC: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 00000021B900: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 00000021B904: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 00000021B90C: BE812000
	s_cbranch_execz 5                                          // 00000021B910: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xd28>
	global_load_b32 v11, v[26:27], off offset:256              // 00000021B914: DC520100 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B91C: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 00000021B920: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B928: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B92C: BE812000
	s_cbranch_execz 5                                          // 00000021B930: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xd48>
	global_load_b32 v11, v[26:27], off offset:260              // 00000021B934: DC520104 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B93C: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 00000021B940: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B948: 8C7E017E
	.long 0x7f163880                                           // 00000021B94C: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B950: BF870001
	.long 0x7e16398b                                           // 00000021B954: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 00000021B958: BE812000
	s_cbranch_execz 5                                          // 00000021B95C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xd74>
	global_load_b32 v12, v[26:27], off offset:264              // 00000021B960: DC520108 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B968: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 00000021B96C: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B974: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B978: BE812000
	s_cbranch_execz 5                                          // 00000021B97C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xd94>
	global_load_b32 v12, v[26:27], off offset:268              // 00000021B980: DC52010C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B988: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 00000021B98C: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B994: 8C7E017E
	.long 0x7f183880                                           // 00000021B998: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B99C: BF870001
	.long 0x7e18398c                                           // 00000021B9A0: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000021B9A4: BE812000
	s_cbranch_execz 5                                          // 00000021B9A8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xdc0>
	global_load_b32 v13, v[26:27], off offset:272              // 00000021B9AC: DC520110 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B9B4: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 00000021B9B8: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B9C0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021B9C4: BE812000
	s_cbranch_execz 5                                          // 00000021B9C8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xde0>
	global_load_b32 v13, v[26:27], off offset:276              // 00000021B9CC: DC520114 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021B9D4: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 00000021B9D8: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021B9E0: 8C7E017E
	.long 0x7f1a3880                                           // 00000021B9E4: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021B9E8: BF870001
	.long 0x7e1a398d                                           // 00000021B9EC: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 00000021B9F0: BE812000
	s_cbranch_execz 5                                          // 00000021B9F4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xe0c>
	global_load_b32 v14, v[26:27], off offset:280              // 00000021B9F8: DC520118 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BA00: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 00000021BA04: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BA0C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BA10: BE812000
	s_cbranch_execz 5                                          // 00000021BA14: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xe2c>
	global_load_b32 v14, v[26:27], off offset:284              // 00000021BA18: DC52011C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BA20: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 00000021BA24: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BA2C: 8C7E017E
	.long 0x7f1c3880                                           // 00000021BA30: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BA34: BF870001
	.long 0x7e1c398e                                           // 00000021BA38: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000021BA3C: BE812000
	s_cbranch_execz 5                                          // 00000021BA40: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xe58>
	global_load_b32 v15, v[26:27], off offset:288              // 00000021BA44: DC520120 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BA4C: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 00000021BA50: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BA58: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BA5C: BE812000
	s_cbranch_execz 5                                          // 00000021BA60: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xe78>
	global_load_b32 v15, v[26:27], off offset:292              // 00000021BA64: DC520124 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BA6C: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 00000021BA70: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BA78: 8C7E017E
	.long 0x7f1e3880                                           // 00000021BA7C: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BA80: BF870001
	.long 0x7e1e398f                                           // 00000021BA84: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 00000021BA88: BE812000
	s_cbranch_execz 5                                          // 00000021BA8C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xea4>
	global_load_b32 v16, v[26:27], off offset:296              // 00000021BA90: DC520128 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021BA98: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 00000021BA9C: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BAA4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BAA8: BE812000
	s_cbranch_execz 5                                          // 00000021BAAC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xec4>
	global_load_b32 v16, v[26:27], off offset:300              // 00000021BAB0: DC52012C 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021BAB8: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 00000021BABC: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BAC4: 8C7E017E
	.long 0x7f203880                                           // 00000021BAC8: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BACC: BF870001
	.long 0x7e203990                                           // 00000021BAD0: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 00000021BAD4: BE812000
	s_cbranch_execz 5                                          // 00000021BAD8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xef0>
	global_load_b32 v17, v[26:27], off offset:304              // 00000021BADC: DC520130 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021BAE4: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 00000021BAE8: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BAF0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BAF4: BE812000
	s_cbranch_execz 5                                          // 00000021BAF8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xf10>
	global_load_b32 v17, v[26:27], off offset:308              // 00000021BAFC: DC520134 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021BB04: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 00000021BB08: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BB10: 8C7E017E
	.long 0x7f223880                                           // 00000021BB14: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BB18: BF870001
	.long 0x7e223991                                           // 00000021BB1C: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 00000021BB20: BE812000
	s_cbranch_execz 5                                          // 00000021BB24: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xf3c>
	global_load_b32 v18, v[26:27], off offset:312              // 00000021BB28: DC520138 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021BB30: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 00000021BB34: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BB3C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BB40: BE812000
	s_cbranch_execz 5                                          // 00000021BB44: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xf5c>
	global_load_b32 v18, v[26:27], off offset:316              // 00000021BB48: DC52013C 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021BB50: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 00000021BB54: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BB5C: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:128                      // 00000021BB60: DBFC0080 23000022
	ds_load_b128 v[39:42], v34 offset:144                      // 00000021BB68: DBFC0090 27000022
	.long 0x7f243880                                           // 00000021BB70: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BB74: BF870001
	.long 0x7e243992                                           // 00000021BB78: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 00000021BB7C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000021BB80: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 00000021BB88: BE812000
	s_cbranch_execz 5                                          // 00000021BB8C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xfa4>
	global_load_b32 v10, v[26:27], off offset:320              // 00000021BB90: DC520140 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BB98: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 00000021BB9C: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BBA4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BBA8: BE812000
	s_cbranch_execz 5                                          // 00000021BBAC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xfc4>
	global_load_b32 v10, v[26:27], off offset:324              // 00000021BBB0: DC520144 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BBB8: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 00000021BBBC: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BBC4: 8C7E017E
	.long 0x7f263880                                           // 00000021BBC8: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BBCC: BF870001
	.long 0x7e263993                                           // 00000021BBD0: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000021BBD4: BE812000
	s_cbranch_execz 5                                          // 00000021BBD8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0xff0>
	global_load_b32 v10, v[26:27], off offset:328              // 00000021BBDC: DC520148 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BBE4: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 00000021BBE8: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BBF0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BBF4: BE812000
	s_cbranch_execz 5                                          // 00000021BBF8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1010>
	global_load_b32 v10, v[26:27], off offset:332              // 00000021BBFC: DC52014C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BC04: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 00000021BC08: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BC10: 8C7E017E
	.long 0x7f283880                                           // 00000021BC14: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BC18: BF870001
	.long 0x7e283994                                           // 00000021BC1C: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000021BC20: BE812000
	s_cbranch_execz 5                                          // 00000021BC24: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x103c>
	global_load_b32 v10, v[26:27], off offset:336              // 00000021BC28: DC520150 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BC30: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 00000021BC34: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BC3C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BC40: BE812000
	s_cbranch_execz 5                                          // 00000021BC44: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x105c>
	global_load_b32 v10, v[26:27], off offset:340              // 00000021BC48: DC520154 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BC50: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 00000021BC54: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BC5C: 8C7E017E
	.long 0x7f2a3880                                           // 00000021BC60: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BC64: BF870001
	.long 0x7e2a3995                                           // 00000021BC68: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000021BC6C: BE812000
	s_cbranch_execz 5                                          // 00000021BC70: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1088>
	global_load_b32 v10, v[26:27], off offset:344              // 00000021BC74: DC520158 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BC7C: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 00000021BC80: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BC88: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BC8C: BE812000
	s_cbranch_execz 5                                          // 00000021BC90: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x10a8>
	global_load_b32 v10, v[26:27], off offset:348              // 00000021BC94: DC52015C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BC9C: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 00000021BCA0: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BCA8: 8C7E017E
	.long 0x7f2c3880                                           // 00000021BCAC: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BCB0: BF870001
	.long 0x7e2c3996                                           // 00000021BCB4: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000021BCB8: BE812000
	s_cbranch_execz 5                                          // 00000021BCBC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x10d4>
	global_load_b32 v10, v[26:27], off offset:352              // 00000021BCC0: DC520160 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BCC8: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 00000021BCCC: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BCD4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BCD8: BE812000
	s_cbranch_execz 5                                          // 00000021BCDC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x10f4>
	global_load_b32 v10, v[26:27], off offset:356              // 00000021BCE0: DC520164 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BCE8: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 00000021BCEC: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BCF4: 8C7E017E
	.long 0x7f2e3880                                           // 00000021BCF8: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BCFC: BF870001
	.long 0x7e2e3997                                           // 00000021BD00: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000021BD04: BE812000
	s_cbranch_execz 5                                          // 00000021BD08: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1120>
	global_load_b32 v10, v[26:27], off offset:360              // 00000021BD0C: DC520168 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BD14: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 00000021BD18: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BD20: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BD24: BE812000
	s_cbranch_execz 5                                          // 00000021BD28: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1140>
	global_load_b32 v10, v[26:27], off offset:364              // 00000021BD2C: DC52016C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BD34: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 00000021BD38: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BD40: 8C7E017E
	.long 0x7f303880                                           // 00000021BD44: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BD48: BF870001
	.long 0x7e303998                                           // 00000021BD4C: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000021BD50: BE812000
	s_cbranch_execz 5                                          // 00000021BD54: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x116c>
	global_load_b32 v10, v[26:27], off offset:368              // 00000021BD58: DC520170 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BD60: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 00000021BD64: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BD6C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BD70: BE812000
	s_cbranch_execz 5                                          // 00000021BD74: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x118c>
	global_load_b32 v10, v[26:27], off offset:372              // 00000021BD78: DC520174 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BD80: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 00000021BD84: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BD8C: 8C7E017E
	.long 0x7f323880                                           // 00000021BD90: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BD94: BF870001
	.long 0x7e323999                                           // 00000021BD98: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000021BD9C: BE812000
	s_cbranch_execz 5                                          // 00000021BDA0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x11b8>
	global_load_b32 v10, v[26:27], off offset:376              // 00000021BDA4: DC520178 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BDAC: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 00000021BDB0: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BDB8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BDBC: BE812000
	s_cbranch_execz 5                                          // 00000021BDC0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x11d8>
	global_load_b32 v10, v[26:27], off offset:380              // 00000021BDC4: DC52017C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BDCC: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 00000021BDD0: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BDD8: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:160                      // 00000021BDDC: DBFC00A0 23000022
	ds_load_b128 v[39:42], v34 offset:176                      // 00000021BDE4: DBFC00B0 27000022
	.long 0x7f143880                                           // 00000021BDEC: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BDF0: BF870001
	.long 0x7e14398a                                           // 00000021BDF4: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 00000021BDF8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 00000021BDFC: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 00000021BE04: BE812000
	s_cbranch_execz 5                                          // 00000021BE08: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1220>
	global_load_b32 v11, v[26:27], off offset:384              // 00000021BE0C: DC520180 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BE14: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 00000021BE18: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BE20: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BE24: BE812000
	s_cbranch_execz 5                                          // 00000021BE28: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1240>
	global_load_b32 v11, v[26:27], off offset:388              // 00000021BE2C: DC520184 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BE34: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 00000021BE38: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BE40: 8C7E017E
	.long 0x7f163880                                           // 00000021BE44: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BE48: BF870001
	.long 0x7e16398b                                           // 00000021BE4C: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 00000021BE50: BE812000
	s_cbranch_execz 5                                          // 00000021BE54: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x126c>
	global_load_b32 v12, v[26:27], off offset:392              // 00000021BE58: DC520188 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BE60: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 00000021BE64: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BE6C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BE70: BE812000
	s_cbranch_execz 5                                          // 00000021BE74: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x128c>
	global_load_b32 v12, v[26:27], off offset:396              // 00000021BE78: DC52018C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BE80: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 00000021BE84: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BE8C: 8C7E017E
	.long 0x7f183880                                           // 00000021BE90: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BE94: BF870001
	.long 0x7e18398c                                           // 00000021BE98: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000021BE9C: BE812000
	s_cbranch_execz 5                                          // 00000021BEA0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x12b8>
	global_load_b32 v13, v[26:27], off offset:400              // 00000021BEA4: DC520190 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BEAC: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 00000021BEB0: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BEB8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BEBC: BE812000
	s_cbranch_execz 5                                          // 00000021BEC0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x12d8>
	global_load_b32 v13, v[26:27], off offset:404              // 00000021BEC4: DC520194 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BECC: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 00000021BED0: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BED8: 8C7E017E
	.long 0x7f1a3880                                           // 00000021BEDC: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BEE0: BF870001
	.long 0x7e1a398d                                           // 00000021BEE4: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 00000021BEE8: BE812000
	s_cbranch_execz 5                                          // 00000021BEEC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1304>
	global_load_b32 v14, v[26:27], off offset:408              // 00000021BEF0: DC520198 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BEF8: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 00000021BEFC: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BF04: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BF08: BE812000
	s_cbranch_execz 5                                          // 00000021BF0C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1324>
	global_load_b32 v14, v[26:27], off offset:412              // 00000021BF10: DC52019C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BF18: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 00000021BF1C: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BF24: 8C7E017E
	.long 0x7f1c3880                                           // 00000021BF28: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BF2C: BF870001
	.long 0x7e1c398e                                           // 00000021BF30: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000021BF34: BE812000
	s_cbranch_execz 5                                          // 00000021BF38: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1350>
	global_load_b32 v15, v[26:27], off offset:416              // 00000021BF3C: DC5201A0 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BF44: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 00000021BF48: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BF50: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BF54: BE812000
	s_cbranch_execz 5                                          // 00000021BF58: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1370>
	global_load_b32 v15, v[26:27], off offset:420              // 00000021BF5C: DC5201A4 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021BF64: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 00000021BF68: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BF70: 8C7E017E
	.long 0x7f1e3880                                           // 00000021BF74: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BF78: BF870001
	.long 0x7e1e398f                                           // 00000021BF7C: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 00000021BF80: BE812000
	s_cbranch_execz 5                                          // 00000021BF84: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x139c>
	global_load_b32 v16, v[26:27], off offset:424              // 00000021BF88: DC5201A8 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021BF90: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 00000021BF94: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BF9C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BFA0: BE812000
	s_cbranch_execz 5                                          // 00000021BFA4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x13bc>
	global_load_b32 v16, v[26:27], off offset:428              // 00000021BFA8: DC5201AC 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021BFB0: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 00000021BFB4: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BFBC: 8C7E017E
	.long 0x7f203880                                           // 00000021BFC0: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021BFC4: BF870001
	.long 0x7e203990                                           // 00000021BFC8: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 00000021BFCC: BE812000
	s_cbranch_execz 5                                          // 00000021BFD0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x13e8>
	global_load_b32 v17, v[26:27], off offset:432              // 00000021BFD4: DC5201B0 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021BFDC: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 00000021BFE0: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021BFE8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021BFEC: BE812000
	s_cbranch_execz 5                                          // 00000021BFF0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1408>
	global_load_b32 v17, v[26:27], off offset:436              // 00000021BFF4: DC5201B4 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021BFFC: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 00000021C000: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C008: 8C7E017E
	.long 0x7f223880                                           // 00000021C00C: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C010: BF870001
	.long 0x7e223991                                           // 00000021C014: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 00000021C018: BE812000
	s_cbranch_execz 5                                          // 00000021C01C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1434>
	global_load_b32 v18, v[26:27], off offset:440              // 00000021C020: DC5201B8 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021C028: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 00000021C02C: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C034: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021C038: BE812000
	s_cbranch_execz 5                                          // 00000021C03C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1454>
	global_load_b32 v18, v[26:27], off offset:444              // 00000021C040: DC5201BC 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021C048: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 00000021C04C: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C054: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:192                      // 00000021C058: DBFC00C0 23000022
	ds_load_b128 v[39:42], v34 offset:208                      // 00000021C060: DBFC00D0 27000022
	.long 0x7f243880                                           // 00000021C068: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C06C: BF870001
	.long 0x7e243992                                           // 00000021C070: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 00000021C074: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000021C078: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 00000021C080: BE812000
	s_cbranch_execz 5                                          // 00000021C084: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x149c>
	global_load_b32 v10, v[26:27], off offset:448              // 00000021C088: DC5201C0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C090: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 00000021C094: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C09C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021C0A0: BE812000
	s_cbranch_execz 5                                          // 00000021C0A4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x14bc>
	global_load_b32 v10, v[26:27], off offset:452              // 00000021C0A8: DC5201C4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C0B0: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 00000021C0B4: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C0BC: 8C7E017E
	.long 0x7f263880                                           // 00000021C0C0: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C0C4: BF870001
	.long 0x7e263993                                           // 00000021C0C8: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000021C0CC: BE812000
	s_cbranch_execz 5                                          // 00000021C0D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x14e8>
	global_load_b32 v10, v[26:27], off offset:456              // 00000021C0D4: DC5201C8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C0DC: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 00000021C0E0: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C0E8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021C0EC: BE812000
	s_cbranch_execz 5                                          // 00000021C0F0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1508>
	global_load_b32 v10, v[26:27], off offset:460              // 00000021C0F4: DC5201CC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C0FC: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 00000021C100: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C108: 8C7E017E
	.long 0x7f283880                                           // 00000021C10C: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C110: BF870001
	.long 0x7e283994                                           // 00000021C114: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000021C118: BE812000
	s_cbranch_execz 5                                          // 00000021C11C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1534>
	global_load_b32 v10, v[26:27], off offset:464              // 00000021C120: DC5201D0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C128: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 00000021C12C: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C134: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021C138: BE812000
	s_cbranch_execz 5                                          // 00000021C13C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1554>
	global_load_b32 v10, v[26:27], off offset:468              // 00000021C140: DC5201D4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C148: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 00000021C14C: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C154: 8C7E017E
	.long 0x7f2a3880                                           // 00000021C158: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C15C: BF870001
	.long 0x7e2a3995                                           // 00000021C160: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000021C164: BE812000
	s_cbranch_execz 5                                          // 00000021C168: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1580>
	global_load_b32 v10, v[26:27], off offset:472              // 00000021C16C: DC5201D8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C174: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 00000021C178: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C180: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021C184: BE812000
	s_cbranch_execz 5                                          // 00000021C188: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x15a0>
	global_load_b32 v10, v[26:27], off offset:476              // 00000021C18C: DC5201DC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C194: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 00000021C198: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C1A0: 8C7E017E
	.long 0x7f2c3880                                           // 00000021C1A4: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C1A8: BF870001
	.long 0x7e2c3996                                           // 00000021C1AC: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000021C1B0: BE812000
	s_cbranch_execz 5                                          // 00000021C1B4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x15cc>
	global_load_b32 v10, v[26:27], off offset:480              // 00000021C1B8: DC5201E0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C1C0: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 00000021C1C4: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C1CC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021C1D0: BE812000
	s_cbranch_execz 5                                          // 00000021C1D4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x15ec>
	global_load_b32 v10, v[26:27], off offset:484              // 00000021C1D8: DC5201E4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C1E0: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 00000021C1E4: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C1EC: 8C7E017E
	.long 0x7f2e3880                                           // 00000021C1F0: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C1F4: BF870001
	.long 0x7e2e3997                                           // 00000021C1F8: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000021C1FC: BE812000
	s_cbranch_execz 5                                          // 00000021C200: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1618>
	global_load_b32 v10, v[26:27], off offset:488              // 00000021C204: DC5201E8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C20C: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 00000021C210: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C218: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021C21C: BE812000
	s_cbranch_execz 5                                          // 00000021C220: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1638>
	global_load_b32 v10, v[26:27], off offset:492              // 00000021C224: DC5201EC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C22C: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 00000021C230: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C238: 8C7E017E
	.long 0x7f303880                                           // 00000021C23C: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C240: BF870001
	.long 0x7e303998                                           // 00000021C244: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000021C248: BE812000
	s_cbranch_execz 5                                          // 00000021C24C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1664>
	global_load_b32 v10, v[26:27], off offset:496              // 00000021C250: DC5201F0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C258: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 00000021C25C: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C264: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021C268: BE812000
	s_cbranch_execz 5                                          // 00000021C26C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1684>
	global_load_b32 v10, v[26:27], off offset:500              // 00000021C270: DC5201F4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C278: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 00000021C27C: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C284: 8C7E017E
	.long 0x7f323880                                           // 00000021C288: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C28C: BF870001
	.long 0x7e323999                                           // 00000021C290: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000021C294: BE812000
	s_cbranch_execz 5                                          // 00000021C298: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x16b0>
	global_load_b32 v10, v[26:27], off offset:504              // 00000021C29C: DC5201F8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C2A4: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 00000021C2A8: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C2B0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021C2B4: BE812000
	s_cbranch_execz 5                                          // 00000021C2B8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x16d0>
	global_load_b32 v10, v[26:27], off offset:508              // 00000021C2BC: DC5201FC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021C2C4: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 00000021C2C8: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021C2D0: 8C7E017E
	ds_load_b128 v[10:13], v34 offset:224                      // 00000021C2D4: DBFC00E0 0A000022
	ds_load_b128 v[14:17], v34 offset:240                      // 00000021C2DC: DBFC00F0 0E000022
	s_waitcnt lgkmcnt(0)                                       // 00000021C2E4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[10:17], v[2:9] // 00000021C2E8: CC404002 1C0A1512
	s_or_b32 exec_lo, exec_lo, s9                              // 00000021C2F0: 8C7E097E
	v_or_b32_e32 v11, v0, v31                                  // 00000021C2F4: 38163F00
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 00000021C2F8: CA100080 0C0C0080
	s_xor_b32 s1, vcc_lo, -1                                   // 00000021C300: 8D01C16A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000021C304: BF8704B2
	.long 0xd44b0000                                           // 00000021C308: D44B0000
	v_cndmask_b32_e32 v1, v29, v11, vcc_lo                     // 00000021C30C: 0202171D
	v_lshlrev_b32_e32 v10, 2, v11                              // 00000021C310: 30141682
	s_and_b32 s9, s1, s0                                       // 00000021C314: 8B090001
	s_and_saveexec_b32 s0, s9                                  // 00000021C318: BE802009
	s_cbranch_execz 36                                         // 00000021C31C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x17b0>
	ds_load_b32 v0, v10 offset:18432                           // 00000021C320: D8D84800 0000000A
	ds_load_b32 v13, v32                                       // 00000021C328: D8D80000 0D000020
	s_waitcnt lgkmcnt(0)                                       // 00000021C330: BF89FC07
	v_sub_f32_e32 v0, v0, v13                                  // 00000021C334: 08001B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C338: BF870091
	v_mul_f32_e32 v13, 0x3fb8aa3b, v0                          // 00000021C33C: 101A00FF 3FB8AA3B
	v_fma_f32 v14, 0x3fb8aa3b, v0, -v13                        // 00000021C344: D613000E 843600FF 3FB8AA3B
	v_rndne_f32_e32 v15, v13                                   // 00000021C350: 7E1E470D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000021C354: BF870221
	v_sub_f32_e32 v13, v13, v15                                // 00000021C358: 081A1F0D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021C35C: 7C3600FF C2CE8ED0
	v_fmac_f32_e32 v14, 0x32a5705f, v0                         // 00000021C364: 561C00FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021C36C: BF870121
	v_add_f32_e32 v13, v13, v14                                // 00000021C370: 061A1D0D
	v_cvt_i32_f32_e32 v14, v15                                 // 00000021C374: 7E1C110F
	v_exp_f32_e32 v13, v13                                     // 00000021C378: 7E1A4B0D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C37C: BF870095
	.long 0xd71c000d                                           // 00000021C380: D71C000D
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                     // 00000021C384: 02021D0D
	v_cndmask_b32_e32 v13, 0, v13, vcc_lo                      // 00000021C388: 021A1A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021C38C: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C394: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v13, vcc_lo              // 00000021C398: 02001AFF 7F800000
	v_mul_f32_e32 v0, 0x43800000, v0                           // 00000021C3A0: 100000FF 43800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C3A8: BF870001
	v_mul_f32_e32 v13, v2, v0                                  // 00000021C3AC: 101A0102
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021C3B0: 8C7E007E
	v_lshl_or_b32 v0, v11, 6, v29                              // 00000021C3B4: D6560000 04750D0B
	v_or_b32_e32 v2, 2, v11                                    // 00000021C3BC: 38041682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021C3C0: BF870112
	.long 0xd73c000e                                           // 00000021C3C4: D73C000E
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021C3C8: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v2                           // 00000021C3CC: 7C96051D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021C3D0: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C3D4: BF870092
	.long 0xd700000e                                           // 00000021C3D8: D700000E
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 00000021C3DC: 02021C02
	v_add_co_ci_u32_e64 v15, null, s6, v15, s0                 // 00000021C3E0: D5207C0F 00021E06
	global_store_b32 v[14:15], v13, off                        // 00000021C3E8: DC6A0000 007C0D0E
	s_and_saveexec_b32 s0, s9                                  // 00000021C3F0: BE802009
	s_cbranch_execz 35                                         // 00000021C3F4: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1884>
	ds_load_b32 v0, v10 offset:18440                           // 00000021C3F8: D8D84808 0000000A
	ds_load_b32 v12, v32                                       // 00000021C400: D8D80000 0C000020
	s_waitcnt lgkmcnt(0)                                       // 00000021C408: BF89FC07
	v_sub_f32_e32 v0, v0, v12                                  // 00000021C40C: 08001900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021C410: BF870121
	v_mul_f32_e32 v12, 0x3fb8aa3b, v0                          // 00000021C414: 101800FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021C41C: 7C3600FF C2CE8ED0
	v_fma_f32 v13, 0x3fb8aa3b, v0, -v12                        // 00000021C424: D613000D 843200FF 3FB8AA3B
	v_rndne_f32_e32 v14, v12                                   // 00000021C430: 7E1C470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C434: BF870091
	v_dual_fmac_f32 v13, 0x32a5705f, v0 :: v_dual_sub_f32 v12, v12, v14// 00000021C438: C80A00FF 0D0C1D0C 32A5705F
	v_add_f32_e32 v12, v12, v13                                // 00000021C444: 06181B0C
	v_cvt_i32_f32_e32 v13, v14                                 // 00000021C448: 7E1A110E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000021C44C: BF870292
	v_exp_f32_e32 v12, v12                                     // 00000021C450: 7E184B0C
	.long 0xd71c000c                                           // 00000021C454: D71C000C
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                     // 00000021C458: 02021B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021C45C: BF870121
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 00000021C460: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021C464: 7C3C00FF 42B17218
	v_cndmask_b32_e32 v0, 0x7f800000, v12, vcc_lo              // 00000021C46C: 020018FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C474: BF870091
	v_mul_f32_e32 v0, 0x43800000, v0                           // 00000021C478: 100000FF 43800000
	v_mul_f32_e32 v12, v3, v0                                  // 00000021C480: 10180103
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021C484: 8C7E007E
	v_lshl_or_b32 v0, v2, 6, v29                               // 00000021C488: D6560000 04750D02
	v_or_b32_e32 v3, 4, v11                                    // 00000021C490: 38061684
	v_mov_b32_e32 v2, 0                                        // 00000021C494: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000021C498: BF870193
	.long 0xd73c000d                                           // 00000021C49C: D73C000D
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021C4A0: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 00000021C4A4: 7C96071D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021C4A8: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C4AC: BF870092
	.long 0xd700000f                                           // 00000021C4B0: D700000F
	v_cndmask_b32_e32 v1, s2, v13, vcc_lo                      // 00000021C4B4: 02021A02
	v_add_co_ci_u32_e64 v16, null, s6, v14, s0                 // 00000021C4B8: D5207C10 00021C06
	v_mov_b32_e32 v13, 0                                       // 00000021C4C0: 7E1A0280
	global_store_b32 v[15:16], v12, off                        // 00000021C4C4: DC6A0000 007C0C0F
	s_and_saveexec_b32 s0, s9                                  // 00000021C4CC: BE802009
	s_cbranch_execz 35                                         // 00000021C4D0: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1960>
	ds_load_b32 v0, v10 offset:18448                           // 00000021C4D4: D8D84810 0000000A
	ds_load_b32 v12, v32                                       // 00000021C4DC: D8D80000 0C000020
	s_waitcnt lgkmcnt(0)                                       // 00000021C4E4: BF89FC07
	v_sub_f32_e32 v0, v0, v12                                  // 00000021C4E8: 08001900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021C4EC: BF870121
	v_mul_f32_e32 v12, 0x3fb8aa3b, v0                          // 00000021C4F0: 101800FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021C4F8: 7C3600FF C2CE8ED0
	v_fma_f32 v13, 0x3fb8aa3b, v0, -v12                        // 00000021C500: D613000D 843200FF 3FB8AA3B
	v_rndne_f32_e32 v14, v12                                   // 00000021C50C: 7E1C470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C510: BF870091
	v_dual_fmac_f32 v13, 0x32a5705f, v0 :: v_dual_sub_f32 v12, v12, v14// 00000021C514: C80A00FF 0D0C1D0C 32A5705F
	v_add_f32_e32 v12, v12, v13                                // 00000021C520: 06181B0C
	v_cvt_i32_f32_e32 v13, v14                                 // 00000021C524: 7E1A110E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000021C528: BF870292
	v_exp_f32_e32 v12, v12                                     // 00000021C52C: 7E184B0C
	.long 0xd71c000c                                           // 00000021C530: D71C000C
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                     // 00000021C534: 02021B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021C538: BF870121
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 00000021C53C: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021C540: 7C3C00FF 42B17218
	v_cndmask_b32_e32 v0, 0x7f800000, v12, vcc_lo              // 00000021C548: 020018FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C550: BF870091
	v_mul_f32_e32 v0, 0x43800000, v0                           // 00000021C554: 100000FF 43800000
	v_mul_f32_e32 v13, v4, v0                                  // 00000021C55C: 101A0104
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021C560: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 00000021C564: D6560000 04750D03
	v_or_b32_e32 v3, 6, v11                                    // 00000021C56C: 38061686
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021C570: BF870112
	.long 0xd73c000e                                           // 00000021C574: D73C000E
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021C578: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 00000021C57C: 7C96071D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021C580: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C584: BF870092
	.long 0xd700000e                                           // 00000021C588: D700000E
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 00000021C58C: 02021C02
	v_add_co_ci_u32_e64 v15, null, s6, v15, s0                 // 00000021C590: D5207C0F 00021E06
	global_store_b32 v[14:15], v13, off                        // 00000021C598: DC6A0000 007C0D0E
	s_and_saveexec_b32 s0, s9                                  // 00000021C5A0: BE802009
	s_cbranch_execz 36                                         // 00000021C5A4: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1a38>
	ds_load_b32 v0, v10 offset:18456                           // 00000021C5A8: D8D84818 0000000A
	ds_load_b32 v2, v32                                        // 00000021C5B0: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 00000021C5B8: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 00000021C5BC: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021C5C0: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 00000021C5C4: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021C5CC: 7C3600FF C2CE8ED0
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v2                          // 00000021C5D4: D6130004 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v12, v2                                    // 00000021C5E0: 7E184702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021C5E4: BF870112
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 00000021C5E8: 560800FF 32A5705F
	v_sub_f32_e32 v2, v2, v12                                  // 00000021C5F0: 08041902
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021C5F4: BF870121
	v_add_f32_e32 v2, v2, v4                                   // 00000021C5F8: 06040902
	v_cvt_i32_f32_e32 v4, v12                                  // 00000021C5FC: 7E08110C
	v_exp_f32_e32 v2, v2                                       // 00000021C600: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C604: BF870095
	.long 0xd71c0002                                           // 00000021C608: D71C0002
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000021C60C: 02020902
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000021C610: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021C614: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C61C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 00000021C620: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x43800000, v0                           // 00000021C628: 100000FF 43800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C630: BF870001
	v_mul_f32_e32 v2, v5, v0                                   // 00000021C634: 10040105
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021C638: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 00000021C63C: D6560000 04750D03
	v_or_b32_e32 v4, 8, v11                                    // 00000021C644: 38081688
	v_mov_b32_e32 v3, 0                                        // 00000021C648: 7E060280
	v_mov_b32_e32 v5, 0                                        // 00000021C64C: 7E0A0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000021C650: BF870214
	.long 0xd73c000c                                           // 00000021C654: D73C000C
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021C658: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v4                           // 00000021C65C: 7C96091D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021C660: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C664: BF870092
	.long 0xd700000c                                           // 00000021C668: D700000C
	v_cndmask_b32_e32 v1, s2, v12, vcc_lo                      // 00000021C66C: 02021802
	v_add_co_ci_u32_e64 v13, null, s6, v13, s0                 // 00000021C670: D5207C0D 00021A06
	global_store_b32 v[12:13], v2, off                         // 00000021C678: DC6A0000 007C020C
	s_and_saveexec_b32 s0, s9                                  // 00000021C680: BE802009
	s_cbranch_execz 36                                         // 00000021C684: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1b18>
	ds_load_b32 v0, v10 offset:18464                           // 00000021C688: D8D84820 0000000A
	ds_load_b32 v2, v32                                        // 00000021C690: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 00000021C698: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 00000021C69C: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021C6A0: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 00000021C6A4: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021C6AC: 7C3600FF C2CE8ED0
	v_fma_f32 v5, 0x3fb8aa3b, v0, -v2                          // 00000021C6B4: D6130005 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v12, v2                                    // 00000021C6C0: 7E184702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021C6C4: BF870112
	v_fmac_f32_e32 v5, 0x32a5705f, v0                          // 00000021C6C8: 560A00FF 32A5705F
	v_sub_f32_e32 v2, v2, v12                                  // 00000021C6D0: 08041902
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021C6D4: BF870121
	v_add_f32_e32 v2, v2, v5                                   // 00000021C6D8: 06040B02
	v_cvt_i32_f32_e32 v5, v12                                  // 00000021C6DC: 7E0A110C
	v_exp_f32_e32 v2, v2                                       // 00000021C6E0: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C6E4: BF870095
	.long 0xd71c0002                                           // 00000021C6E8: D71C0002
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 00000021C6EC: 02020B02
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000021C6F0: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021C6F4: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C6FC: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 00000021C700: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x43800000, v0                           // 00000021C708: 100000FF 43800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C710: BF870001
	v_mul_f32_e32 v5, v6, v0                                   // 00000021C714: 100A0106
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021C718: 8C7E007E
	v_lshl_or_b32 v0, v4, 6, v29                               // 00000021C71C: D6560000 04750D04
	v_or_b32_e32 v2, 10, v11                                   // 00000021C724: 3804168A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021C728: BF870112
	.long 0xd73c000c                                           // 00000021C72C: D73C000C
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021C730: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v2                           // 00000021C734: 7C96051D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021C738: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C73C: BF870092
	.long 0xd700000c                                           // 00000021C740: D700000C
	v_cndmask_b32_e32 v1, s2, v12, vcc_lo                      // 00000021C744: 02021802
	v_add_co_ci_u32_e64 v13, null, s6, v13, s0                 // 00000021C748: D5207C0D 00021A06
	global_store_b32 v[12:13], v5, off                         // 00000021C750: DC6A0000 007C050C
	s_and_saveexec_b32 s0, s9                                  // 00000021C758: BE802009
	s_cbranch_execz 36                                         // 00000021C75C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1bf0>
	ds_load_b32 v0, v10 offset:18472                           // 00000021C760: D8D84828 0000000A
	ds_load_b32 v3, v32                                        // 00000021C768: D8D80000 03000020
	s_waitcnt lgkmcnt(0)                                       // 00000021C770: BF89FC07
	v_sub_f32_e32 v0, v0, v3                                   // 00000021C774: 08000700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C778: BF870091
	v_mul_f32_e32 v3, 0x3fb8aa3b, v0                           // 00000021C77C: 100600FF 3FB8AA3B
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v3                          // 00000021C784: D6130004 840E00FF 3FB8AA3B
	v_rndne_f32_e32 v5, v3                                     // 00000021C790: 7E0A4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000021C794: BF870221
	v_sub_f32_e32 v3, v3, v5                                   // 00000021C798: 08060B03
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021C79C: 7C3600FF C2CE8ED0
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 00000021C7A4: 560800FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021C7AC: BF870121
	v_add_f32_e32 v3, v3, v4                                   // 00000021C7B0: 06060903
	v_cvt_i32_f32_e32 v4, v5                                   // 00000021C7B4: 7E081105
	v_exp_f32_e32 v3, v3                                       // 00000021C7B8: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C7BC: BF870095
	.long 0xd71c0003                                           // 00000021C7C0: D71C0003
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 00000021C7C4: 02020903
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 00000021C7C8: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021C7CC: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C7D4: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v3, vcc_lo               // 00000021C7D8: 020006FF 7F800000
	v_mul_f32_e32 v0, 0x43800000, v0                           // 00000021C7E0: 100000FF 43800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C7E8: BF870001
	v_mul_f32_e32 v3, v7, v0                                   // 00000021C7EC: 10060107
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021C7F0: 8C7E007E
	v_lshl_or_b32 v0, v2, 6, v29                               // 00000021C7F4: D6560000 04750D02
	v_or_b32_e32 v4, 12, v11                                   // 00000021C7FC: 3808168C
	v_mov_b32_e32 v2, 0                                        // 00000021C800: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000021C804: BF870193
	.long 0xd73c0005                                           // 00000021C808: D73C0005
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021C80C: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v4                           // 00000021C810: 7C96091D
	s_and_b32 s9, s1, vcc_lo                                   // 00000021C814: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C818: BF870092
	.long 0xd700000c                                           // 00000021C81C: D700000C
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000021C820: 02020A02
	v_add_co_ci_u32_e64 v13, null, s6, v6, s0                  // 00000021C824: D5207C0D 00020C06
	v_mov_b32_e32 v5, 0                                        // 00000021C82C: 7E0A0280
	global_store_b32 v[12:13], v3, off                         // 00000021C830: DC6A0000 007C030C
	s_and_saveexec_b32 s0, s9                                  // 00000021C838: BE802009
	s_cbranch_execz 36                                         // 00000021C83C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x1cd0>
	ds_load_b32 v0, v10 offset:18480                           // 00000021C840: D8D84830 0000000A
	ds_load_b32 v3, v32                                        // 00000021C848: D8D80000 03000020
	s_waitcnt lgkmcnt(0)                                       // 00000021C850: BF89FC07
	v_sub_f32_e32 v0, v0, v3                                   // 00000021C854: 08000700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C858: BF870091
	v_mul_f32_e32 v3, 0x3fb8aa3b, v0                           // 00000021C85C: 100600FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v0, -v3                          // 00000021C864: D6130005 840E00FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 00000021C870: 7E0C4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000021C874: BF870191
	v_sub_f32_e32 v3, v3, v6                                   // 00000021C878: 08060D03
	v_fmac_f32_e32 v5, 0x32a5705f, v0                          // 00000021C87C: 560A00FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021C884: 7C3600FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021C88C: BF870122
	v_add_f32_e32 v3, v3, v5                                   // 00000021C890: 06060B03
	v_cvt_i32_f32_e32 v5, v6                                   // 00000021C894: 7E0A1106
	v_exp_f32_e32 v3, v3                                       // 00000021C898: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C89C: BF870095
	.long 0xd71c0003                                           // 00000021C8A0: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000021C8A4: 02020B03
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 00000021C8A8: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021C8AC: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C8B4: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v3, vcc_lo               // 00000021C8B8: 020006FF 7F800000
	v_mul_f32_e32 v0, 0x43800000, v0                           // 00000021C8C0: 100000FF 43800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C8C8: BF870001
	v_mul_f32_e32 v5, v8, v0                                   // 00000021C8CC: 100A0108
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021C8D0: 8C7E007E
	v_lshl_or_b32 v0, v4, 6, v29                               // 00000021C8D4: D6560000 04750D04
	v_or_b32_e32 v3, 14, v11                                   // 00000021C8DC: 3806168E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021C8E0: BF870112
	.long 0xd73c0006                                           // 00000021C8E4: D73C0006
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021C8E8: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 00000021C8EC: 7C96071D
	s_and_b32 s1, s1, vcc_lo                                   // 00000021C8F0: 8B016A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C8F4: BF870092
	.long 0xd7000006                                           // 00000021C8F8: D7000006
	v_cndmask_b32_e32 v1, s2, v6, vcc_lo                       // 00000021C8FC: 02020C02
	v_add_co_ci_u32_e64 v7, null, s6, v7, s0                   // 00000021C900: D5207C07 00020E06
	global_store_b32 v[6:7], v5, off                           // 00000021C908: DC6A0000 007C0506
	s_and_saveexec_b32 s0, s1                                  // 00000021C910: BE802001
	s_cbranch_execz 63806                                      // 00000021C914: BFA5F93E <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x210>
	ds_load_b32 v0, v10 offset:18488                           // 00000021C918: D8D84838 0000000A
	ds_load_b32 v2, v32                                        // 00000021C920: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 00000021C928: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 00000021C92C: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021C930: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 00000021C934: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021C93C: 7C3600FF C2CE8ED0
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v2                          // 00000021C944: D6130004 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v5, v2                                     // 00000021C950: 7E0A4702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021C954: BF870112
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 00000021C958: 560800FF 32A5705F
	v_sub_f32_e32 v2, v2, v5                                   // 00000021C960: 08040B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021C964: BF870121
	v_add_f32_e32 v2, v2, v4                                   // 00000021C968: 06040902
	v_cvt_i32_f32_e32 v4, v5                                   // 00000021C96C: 7E081105
	v_exp_f32_e32 v2, v2                                       // 00000021C970: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C974: BF870095
	.long 0xd71c0002                                           // 00000021C978: D71C0002
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000021C97C: 02020902
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000021C980: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021C984: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021C98C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 00000021C990: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x43800000, v0                           // 00000021C998: 100000FF 43800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021C9A0: BF870001
	v_mul_f32_e32 v2, v9, v0                                   // 00000021C9A4: 10040109
	s_branch 63769                                             // 00000021C9A8: BFA0F919 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILin4EEEvPKfS3_S3_Pfi+0x210>
	s_endpgm                                                   // 00000021C9AC: BFB00000
		...

