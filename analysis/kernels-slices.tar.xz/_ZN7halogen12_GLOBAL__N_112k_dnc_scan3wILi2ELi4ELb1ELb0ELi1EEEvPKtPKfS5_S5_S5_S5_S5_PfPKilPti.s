0000000000143c00 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000143C00: BF850001
	s_load_b256 s[12:19], s[0:1], 0x30                         // 000000143C04: F40C0300 F8000030
	s_load_b64 s[6:7], s[0:1], 0x50                            // 000000143C0C: F4040180 F8000050
	s_lshl_b32 s4, s3, 6                                       // 000000143C14: 84048603
	s_ashr_i32 s3, s2, 31                                      // 000000143C18: 86039F02
	s_ashr_i32 s5, s4, 31                                      // 000000143C1C: 86059F04
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v73, 63, v0        // 000000143C20: CA240100 044800BF
	s_movk_i32 s9, 0x210                                       // 000000143C28: B0090210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000143C2C: BF8704D1
	v_lshlrev_b32_e32 v2, 2, v73                               // 000000143C30: 30049282
	v_mad_u32_u24 v1, v73, s9, 0x3200                          // 000000143C34: D60B0001 03FC1349 00003200
	s_waitcnt lgkmcnt(0)                                       // 000000143C40: BF89FC07
	s_load_b32 s8, s[16:17], null                              // 000000143C44: F4000208 F8000000
	s_lshl_b64 s[34:35], s[18:19], 2                           // 000000143C4C: 84A28212
	s_add_u32 s10, s14, s34                                    // 000000143C50: 800A220E
	s_addc_u32 s11, s15, s35                                   // 000000143C54: 820B230F
	s_lshl_b64 s[36:37], s[2:3], 16                            // 000000143C58: 84A49002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000143C5C: BF870009
	s_add_u32 s10, s10, s36                                    // 000000143C60: 800A240A
	s_addc_u32 s11, s11, s37                                   // 000000143C64: 820B250B
	s_waitcnt lgkmcnt(0)                                       // 000000143C68: BF89FC07
	s_mul_i32 s33, s8, 0x9000000                               // 000000143C6C: 9621FF08 09000000
	s_mul_hi_i32 s40, s8, 0x9000000                            // 000000143C74: 9728FF08 09000000
	s_add_u32 s8, s10, s33                                     // 000000143C7C: 8008210A
	s_addc_u32 s10, s11, s40                                   // 000000143C80: 820A280B
	s_lshl_b64 s[38:39], s[4:5], 2                             // 000000143C84: 84A68204
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000143C88: BF8700B9
	s_add_u32 s8, s8, s38                                      // 000000143C8C: 80082608
	s_addc_u32 s9, s10, s39                                    // 000000143C90: 8209270A
	.long 0xd7000802                                           // 000000143C94: D7000802
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 000000143C98: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, 0, s8                    // 000000143C9C: D5207C03 00210009
	s_mov_b32 s8, 0                                            // 000000143CA4: BE880080
	s_nop 0                                                    // 000000143CA8: BF800000
	s_nop 0                                                    // 000000143CAC: BF800000
	s_nop 0                                                    // 000000143CB0: BF800000
	s_nop 0                                                    // 000000143CB4: BF800000
	s_nop 0                                                    // 000000143CB8: BF800000
	s_nop 0                                                    // 000000143CBC: BF800000
	v_lshrrev_b32_e32 v7, 6, v4                                // 000000143CC0: 320E0886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000143CC4: BF870121
	v_lshlrev_b32_e32 v5, 9, v7                                // 000000143CC8: 300A0E89
	v_lshl_add_u32 v7, v7, 2, v1                               // 000000143CCC: D6460007 04050507
	.long 0xd7006a05                                           // 000000143CD4: D7006A05
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 000000143CD8: 02020B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000143CDC: BF8700D1
	v_add_co_ci_u32_e64 v6, null, 0, v3, vcc_lo                // 000000143CE0: D5207C06 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 000000143CE8: 7C9208FF 00001F7F
	global_load_b32 v5, v[5:6], off                            // 000000143CF0: DC520000 057C0005
	v_add_nc_u32_e32 v6, 0x80, v4                              // 000000143CF8: 4A0C08FF 00000080
	s_or_b32 s8, vcc_lo, s8                                    // 000000143D00: 8C08086A
	v_mov_b32_e32 v4, v6                                       // 000000143D04: 7E080306
	s_waitcnt vmcnt(0)                                         // 000000143D08: BF8903F7
	ds_store_b32 v7, v5                                        // 000000143D0C: D8340000 00000507
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 000000143D14: 917E087E
	s_cbranch_execnz 65513                                     // 000000143D18: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000143D1C: 8C7E087E
	s_load_b32 s41, s[0:1], 0x58                               // 000000143D20: F4000A40 F8000058
	v_or_b32_e32 v74, 0xffffff80, v0                           // 000000143D28: 389400FF FFFFFF80
	v_lshrrev_b32_e32 v1, 6, v0                                // 000000143D30: 32020086
	s_mov_b32 s8, 0                                            // 000000143D34: BE880080
	s_waitcnt lgkmcnt(0)                                       // 000000143D38: BF89FC07
	s_barrier                                                  // 000000143D3C: BFBD0000
	buffer_gl0_inv                                             // 000000143D40: E0AC0000 00000000
	s_cmp_gt_i32 s41, 0                                        // 000000143D48: BF028029
	s_cbranch_scc1 9                                           // 000000143D4C: BFA20009 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x174>
	v_lshrrev_b32_e32 v67, 6, v0                               // 000000143D50: 32860086
	v_or_b32_e32 v2, 0xffffff80, v0                            // 000000143D54: 380400FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000143D5C: BF870002
	v_dual_mov_b32 v68, 0 :: v_dual_mov_b32 v3, v67            // 000000143D60: CA100080 44020143
	s_and_not1_b32 vcc_lo, exec_lo, s8                         // 000000143D68: 916A087E
	s_cbranch_vccz 1                                           // 000000143D6C: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x174>
	s_branch 4268                                              // 000000143D70: BFA010AC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4424>
	s_load_b256 s[16:23], s[0:1], 0x8                          // 000000143D74: F40C0400 F8000008
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 000000143D7C: CA220080 02020082
	v_lshlrev_b32_e32 v6, 8, v0                                // 000000143D84: 300C0088
	s_add_i32 s0, s41, 63                                      // 000000143D88: 8100BF29
	v_lshrrev_b32_e32 v75, 5, v0                               // 000000143D8C: 32960085
	v_and_b32_e32 v4, 15, v0                                   // 000000143D90: 3608008F
	s_add_i32 s42, s2, 0xbd0                                   // 000000143D94: 812AFF02 00000BD0
	s_lshr_b32 s43, s0, 6                                      // 000000143D9C: 852B8600
	s_movk_i32 s1, 0x210                                       // 000000143DA0: B0010210
	v_or_b32_e32 v76, 0xb600, v3                               // 000000143DA4: 389806FF 0000B600
	v_add_nc_u32_e32 v77, 0xb700, v3                           // 000000143DAC: 4A9A06FF 0000B700
	v_and_b32_e32 v3, 0xf00, v6                                // 000000143DB4: 36060CFF 00000F00
	v_dual_mov_b32 v68, v2 :: v_dual_lshlrev_b32 v7, 4, v75    // 000000143DBC: CA220102 44069684
	v_mov_b32_e32 v67, v1                                      // 000000143DC4: 7E860301
	v_mad_u32_u24 v78, v4, s1, 0x3200                          // 000000143DC8: D60B004E 03FC0304 00003200
	s_delay_alu instid0(VALU_DEP_4)                            // 000000143DD4: BF870004
	v_lshl_or_b32 v3, v75, 12, v3                              // 000000143DD8: D6560003 040D194B
	v_lshlrev_b32_e32 v6, 2, v4                                // 000000143DE0: 300C0882
	v_bfe_u32 v5, v0, 4, 1                                     // 000000143DE4: D6100005 02050900
	s_waitcnt lgkmcnt(0)                                       // 000000143DEC: BF89FC07
	s_add_u32 s8, s22, s38                                     // 000000143DF0: 80082616
	s_addc_u32 s9, s23, s39                                    // 000000143DF4: 82092717
	s_lshl_b32 s0, s2, 7                                       // 000000143DF8: 84008702
	.long 0xd7000a51                                           // 000000143DFC: D7000A51
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                      // 000000143E00: 0202060C
	s_ashr_i32 s1, s0, 31                                      // 000000143E04: 86019F00
	v_mad_u32_u24 v3, 0x2100, v75, v78                         // 000000143E08: D60B0003 053A96FF 00002100
	s_lshl_b64 s[0:1], s[0:1], 1                               // 000000143E14: 84808100
	v_or_b32_e32 v79, v7, v5                                   // 000000143E18: 389E0B07
	s_add_u32 s6, s6, s0                                       // 000000143E1C: 80060006
	s_addc_u32 s7, s7, s1                                      // 000000143E20: 82070107
	s_lshl_b64 s[0:1], s[4:5], 1                               // 000000143E24: 84808104
	v_or_b32_e32 v80, v7, v4                                   // 000000143E28: 38A00907
	s_add_u32 s4, s6, s0                                       // 000000143E2C: 80040006
	s_movk_i32 s0, 0x2800                                      // 000000143E30: B0002800
	s_addc_u32 s5, s7, s1                                      // 000000143E34: 82050107
	v_mad_u32_u24 v84, 0xa0, v4, s0                            // 000000143E38: D60B0054 000208FF 000000A0
	.long 0xd7000056                                           // 000000143E44: D7000056
	v_cndmask_b32_e32 v1, s8, v6, vcc_lo                       // 000000143E48: 02020C08
	s_delay_alu instid0(VALU_DEP_1)                            // 000000143E4C: BF870001
	v_add_co_ci_u32_e64 v87, null, s9, 0, s0                   // 000000143E50: D5207C57 00010009
	s_lshl_b64 s[0:1], s[2:3], 9                               // 000000143E58: 84808902
	v_mul_u32_u24_e32 v83, 0xa0, v4                            // 000000143E5C: 16A608FF 000000A0
	v_lshl_or_b32 v85, v5, 2, v3                               // 000000143E64: D6560055 040D0505
	v_lshlrev_b32_e32 v5, 1, v4                                // 000000143E6C: 300A0881
	v_mad_u64_u32 v[3:4], null, 0x6000, v73, s[0:1]            // 000000143E70: D6FE7C03 000292FF 00006000
	v_mul_u32_u24_e32 v7, 0xa00, v75                           // 000000143E7C: 160E96FF 00000A00
	v_mul_u32_u24_e32 v6, 0xa0, v1                             // 000000143E84: 160C02FF 000000A0
	v_add_co_ci_u32_e64 v82, null, s13, 0, s10                 // 000000143E8C: D5207C52 0029000D
	.long 0xd7000045                                           // 000000143E94: D7000045
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000143E98: 02020A04
	s_delay_alu instid0(VALU_DEP_1)                            // 000000143E9C: BF870001
	v_add_co_ci_u32_e64 v70, null, s5, 0, s0                   // 000000143EA0: D5207C46 00010005
	v_lshl_or_b32 v3, v1, 2, v3                                // 000000143EA8: D6560003 040D0501
	v_lshl_add_u32 v88, v79, 1, v83                            // 000000143EB0: D6460058 054D034F
	v_lshl_or_b32 v89, v79, 2, 0xb700                          // 000000143EB8: D6560059 03FD054F 0000B700
	v_lshl_or_b32 v90, v73, 2, 0xb600                          // 000000143EC4: D656005A 03FD0549 0000B600
	v_lshl_add_u32 v91, v73, 1, v6                             // 000000143ED0: D646005B 04190349
	.long 0xd7000047                                           // 000000143ED8: D7000047
	v_cndmask_b32_e32 v1, s18, v3, vcc_lo                      // 000000143EDC: 02020612
	s_delay_alu instid0(VALU_DEP_1)                            // 000000143EE0: BF870001
	v_add_co_ci_u32_e64 v72, null, s19, v4, s0                 // 000000143EE4: D5207C48 00020813
	v_add_nc_u32_e32 v92, v83, v7                              // 000000143EEC: 4AB80F53
	s_mov_b32 s13, 0                                           // 000000143EF0: BE8D0080
	s_mov_b32 s18, 0x41800000                                  // 000000143EF4: BE9200FF 41800000
	s_mov_b32 s24, s13                                         // 000000143EFC: BE98000D
	s_mov_b32 s25, s13                                         // 000000143F00: BE99000D
	s_mov_b32 s26, s13                                         // 000000143F04: BE9A000D
	s_mov_b32 s27, s13                                         // 000000143F08: BE9B000D
	s_mov_b32 s28, s13                                         // 000000143F0C: BE9C000D
	s_mov_b32 s29, s13                                         // 000000143F10: BE9D000D
	s_mov_b32 s30, s13                                         // 000000143F14: BE9E000D
	s_mov_b32 s31, s13                                         // 000000143F18: BE9F000D
	s_mov_b32 s19, 0                                           // 000000143F1C: BE930080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 000000143F20: 7C9800C0
	s_branch 13                                                // 000000143F24: BFA0000D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x35c>
	.long 0xd7000047                                           // 000000143F28: D7000047
	v_cndmask_b32_e32 v1, 0x180000, v71, vcc_lo                // 000000143F2C: 02028EFF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000143F34: BF870001
	v_add_co_ci_u32_e64 v72, null, 0, v72, s0                  // 000000143F38: D5207C48 00029080
	s_add_i32 s19, s19, 1                                      // 000000143F40: 81138113
	s_waitcnt lgkmcnt(0)                                       // 000000143F44: BF89FC07
	s_cmp_eq_u32 s19, s43                                      // 000000143F48: BF062B13
	s_barrier                                                  // 000000143F4C: BFBD0000
	buffer_gl0_inv                                             // 000000143F50: E0AC0000 00000000
	s_cbranch_scc1 4144                                        // 000000143F58: BFA21030 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x441c>
	s_mul_i32 s0, s19, 0xc00                                   // 000000143F5C: 9600FF13 00000C00
	s_lshl_b32 s22, s19, 6                                     // 000000143F64: 84168613
	s_add_i32 s0, s42, s0                                      // 000000143F68: 8100002A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000143F6C: BF870499
	s_ashr_i32 s1, s0, 31                                      // 000000143F70: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 000000143F74: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000143F78: BF870009
	s_add_u32 s0, s20, s0                                      // 000000143F7C: 80000014
	s_addc_u32 s1, s21, s1                                     // 000000143F80: 82010115
	global_load_b32 v3, v2, s[0:1]                             // 000000143F84: DC520000 03000002
	s_waitcnt vmcnt(0)                                         // 000000143F8C: BF8903F7
	v_readfirstlane_b32 s23, v3                                // 000000143F90: 7E2E0503
	s_and_saveexec_b32 s1, vcc_lo                              // 000000143F94: BE81206A
	s_cbranch_execz 77                                         // 000000143F98: BFA5004D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4d0>
	v_or_b32_e32 v3, s22, v0                                   // 000000143F9C: 38060016
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000143FA0: BF870091
	v_mad_u64_u32 v[3:4], null, v3, 48, s[2:3]                 // 000000143FA4: D6FE7C03 00096103
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000143FAC: 3408069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000143FB0: BF870091
	.long 0xd73c0003                                           // 000000143FB4: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000143FB8: 02020682
	.long 0xd7000003                                           // 000000143FBC: D7000003
	v_cndmask_b32_e32 v1, s20, v3, vcc_lo                      // 000000143FC0: 02020614
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000143FC4: BF8700C1
	v_add_co_ci_u32_e64 v4, null, s21, v4, s0                  // 000000143FC8: D5207C04 00020815
	global_load_b32 v3, v[3:4], off                            // 000000143FD0: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000143FD8: BF8903F7
	v_sub_f32_e32 v4, s23, v3                                  // 000000143FDC: 08080617
	v_dual_mul_f32 v6, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, 0x3fb8aa3b, v4// 000000143FE0: C8C606FF 060408FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000143FEC: BF8701A1
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v6                          // 000000143FF0: D6130009 841A06FF 3FB8AA3B
	v_rndne_f32_e32 v10, v6                                    // 000000143FFC: 7E144706
	v_fma_f32 v7, 0x3fb8aa3b, v4, -v5                          // 000000144000: D6130007 841608FF 3FB8AA3B
	v_rndne_f32_e32 v8, v5                                     // 00000014400C: 7E104705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000144010: BF870113
	v_dual_fmac_f32 v9, 0x32a5705f, v3 :: v_dual_sub_f32 v6, v6, v10// 000000144014: C80A06FF 09061506 32A5705F
	v_sub_f32_e32 v5, v5, v8                                   // 000000144020: 080A1105
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000144024: BF870124
	v_fmac_f32_e32 v7, 0x32a5705f, v4                          // 000000144028: 560E08FF 32A5705F
	.long 0xd41b0000                                           // 000000144030: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v4, vcc_lo               // 000000144034: 020208FF C2CE8ED0
	v_dual_add_f32 v6, v6, v9 :: v_dual_add_f32 v5, v5, v7     // 00000014403C: C9081306 06040F05
	v_cvt_i32_f32_e32 v7, v8                                   // 000000144044: 7E0E1108
	v_cvt_i32_f32_e32 v8, v10                                  // 000000144048: 7E10110A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000014404C: BF870193
	v_exp_f32_e32 v6, v6                                       // 000000144050: 7E0C4B06
	v_exp_f32_e32 v5, v5                                       // 000000144054: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000144058: BF870296
	.long 0xd71c0006                                           // 00000014405C: D71C0006
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 000000144060: 02021106
	.long 0xd71c0005                                           // 000000144064: D71C0005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000144068: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000014406C: BF8700A1
	v_cndmask_b32_e64 v5, 0, v5, s0                            // 000000144070: D5010005 00020A80
	.long 0xd41b0000                                           // 000000144078: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v3, vcc_lo               // 00000014407C: 020206FF C2CE8ED0
	v_cndmask_b32_e64 v6, 0, v6, s0                            // 000000144084: D5010006 00020C80
	.long 0xd41e0000                                           // 00000014408C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v4, vcc_lo               // 000000144090: 020208FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000144098: BF8700A1
	v_cndmask_b32_e64 v4, 0x7f800000, v5, s0                   // 00000014409C: D5010004 00020AFF 7F800000
	.long 0xd41e0000                                           // 0000001440A8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v3, vcc_lo               // 0000001440AC: 020206FF 42B17218
	v_cndmask_b32_e64 v3, 0x7f800000, v6, s0                   // 0000001440B4: D5010003 00020CFF 7F800000
	ds_store_b32 v76, v4                                       // 0000001440C0: D8340000 0000044C
	ds_store_b32 v77, v3                                       // 0000001440C8: D8340000 0000034D
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001440D0: 8C7E017E
	v_add_nc_u32_e32 v93, s22, v79                             // 0000001440D4: 4ABA9E16
	.long 0x7e063880                                           // 0000001440D8: 7E063880
	s_waitcnt lgkmcnt(0)                                       // 0000001440DC: BF89FC07
	s_barrier                                                  // 0000001440E0: BFBD0000
	buffer_gl0_inv                                             // 0000001440E4: E0AC0000 00000000
	.long 0xd4440000                                           // 0000001440EC: D4440000
	v_cndmask_b32_e32 v1, s41, v93, vcc_lo                     // 0000001440F0: 0202BA29
	.long 0x7f063903                                           // 0000001440F4: 7F063903
	s_and_saveexec_b32 s4, s0                                  // 0000001440F8: BE842000
	s_cbranch_execz 15                                         // 0000001440FC: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x53c>
	v_mad_u64_u32 v[4:5], null, v93, 48, s[2:3]                // 000000144100: D6FE7C04 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144108: BF870091
	.long 0xd73c0004                                           // 00000014410C: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000144110: 02020889
	.long 0xd7000104                                           // 000000144114: D7000104
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 000000144118: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014411C: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s1                  // 000000144120: D5207C05 00060B57
	global_load_b32 v4, v[4:5], off                            // 000000144128: DC520000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000144130: BF8903F7
	v_fma_mixhi_f16 v3, v4, s18, 0                             // 000000144134: CC220003 02002504
	s_or_b32 exec_lo, exec_lo, s4                              // 00000014413C: 8C7E047E
	v_add_nc_u32_e32 v94, 2, v93                               // 000000144140: 4ABCBA82
	ds_store_b16_d16_hi v88, v3                                // 000000144144: DA840000 00000358
	.long 0xd4440001                                           // 00000014414C: D4440001
	v_cndmask_b32_e32 v1, s41, v94, vcc_lo                     // 000000144150: 0202BC29
	s_and_saveexec_b32 s5, s1                                  // 000000144154: BE852001
	s_cbranch_execz 15                                         // 000000144158: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x598>
	v_mad_u64_u32 v[3:4], null, v94, 48, s[2:3]                // 00000014415C: D6FE7C03 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144164: BF870091
	.long 0xd73c0003                                           // 000000144168: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014416C: 02020689
	.long 0xd7000403                                           // 000000144170: D7000403
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 000000144174: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144178: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s4                  // 00000014417C: D5207C04 00120957
	global_load_b32 v3, v[3:4], off                            // 000000144184: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014418C: BF8903F7
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 000000144190: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s5                              // 000000144198: 8C7E057E
	v_add_nc_u32_e32 v95, 4, v93                               // 00000014419C: 4ABEBA84
	.long 0x7f063880                                           // 0000001441A0: 7F063880
	ds_store_b16 v88, v3 offset:4                              // 0000001441A4: D87C0004 00000358
	.long 0xd4440004                                           // 0000001441AC: D4440004
	v_cndmask_b32_e32 v1, s41, v95, vcc_lo                     // 0000001441B0: 0202BE29
	.long 0x7e083983                                           // 0000001441B4: 7E083983
	s_and_saveexec_b32 s6, s4                                  // 0000001441B8: BE862004
	s_cbranch_execz 15                                         // 0000001441BC: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5fc>
	v_mad_u64_u32 v[4:5], null, v95, 48, s[2:3]                // 0000001441C0: D6FE7C04 0009615F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001441C8: BF870091
	.long 0xd73c0004                                           // 0000001441CC: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 0000001441D0: 02020889
	.long 0xd7000504                                           // 0000001441D4: D7000504
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 0000001441D8: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001441DC: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s5                  // 0000001441E0: D5207C05 00160B57
	global_load_b32 v4, v[4:5], off                            // 0000001441E8: DC520000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000001441F0: BF8903F7
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 0000001441F4: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001441FC: 8C7E067E
	v_add_nc_u32_e32 v96, 6, v93                               // 000000144200: 4AC0BA86
	ds_store_b16 v88, v4 offset:8                              // 000000144204: D87C0008 00000458
	.long 0xd4440005                                           // 00000014420C: D4440005
	v_cndmask_b32_e32 v1, s41, v96, vcc_lo                     // 000000144210: 0202C029
	s_and_saveexec_b32 s7, s5                                  // 000000144214: BE872005
	s_cbranch_execz 15                                         // 000000144218: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x658>
	v_mad_u64_u32 v[3:4], null, v96, 48, s[2:3]                // 00000014421C: D6FE7C03 00096160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144224: BF870091
	.long 0xd73c0003                                           // 000000144228: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014422C: 02020689
	.long 0xd7000603                                           // 000000144230: D7000603
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 000000144234: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144238: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s6                  // 00000014423C: D5207C04 001A0957
	global_load_b32 v3, v[3:4], off                            // 000000144244: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014424C: BF8903F7
	v_fma_mixhi_f16 v3, v3, s18, 0                             // 000000144250: CC220003 02002503
	s_or_b32 exec_lo, exec_lo, s7                              // 000000144258: 8C7E077E
	v_add_nc_u32_e32 v97, 8, v93                               // 00000014425C: 4AC2BA88
	.long 0x7e063880                                           // 000000144260: 7E063880
	ds_store_b16_d16_hi v88, v3 offset:12                      // 000000144264: DA84000C 00000358
	.long 0xd4440006                                           // 00000014426C: D4440006
	v_cndmask_b32_e32 v1, s41, v97, vcc_lo                     // 000000144270: 0202C229
	.long 0x7e083903                                           // 000000144274: 7E083903
	s_and_saveexec_b32 s8, s6                                  // 000000144278: BE882006
	s_cbranch_execz 15                                         // 00000014427C: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6bc>
	v_mad_u64_u32 v[4:5], null, v97, 48, s[2:3]                // 000000144280: D6FE7C04 00096161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144288: BF870091
	.long 0xd73c0004                                           // 00000014428C: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000144290: 02020889
	.long 0xd7000704                                           // 000000144294: D7000704
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 000000144298: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014429C: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s7                  // 0000001442A0: D5207C05 001E0B57
	global_load_b32 v4, v[4:5], off                            // 0000001442A8: DC520000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000001442B0: BF8903F7
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 0000001442B4: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001442BC: 8C7E087E
	v_add_nc_u32_e32 v98, 10, v93                              // 0000001442C0: 4AC4BA8A
	ds_store_b16 v88, v4 offset:16                             // 0000001442C4: D87C0010 00000458
	.long 0xd4440007                                           // 0000001442CC: D4440007
	v_cndmask_b32_e32 v1, s41, v98, vcc_lo                     // 0000001442D0: 0202C429
	s_and_saveexec_b32 s9, s7                                  // 0000001442D4: BE892007
	s_cbranch_execz 15                                         // 0000001442D8: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x718>
	v_mad_u64_u32 v[3:4], null, v98, 48, s[2:3]                // 0000001442DC: D6FE7C03 00096162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001442E4: BF870091
	.long 0xd73c0003                                           // 0000001442E8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001442EC: 02020689
	.long 0xd7000803                                           // 0000001442F0: D7000803
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 0000001442F4: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001442F8: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s8                  // 0000001442FC: D5207C04 00220957
	global_load_b32 v3, v[3:4], off                            // 000000144304: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014430C: BF8903F7
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 000000144310: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s9                              // 000000144318: 8C7E097E
	v_add_nc_u32_e32 v99, 12, v93                              // 00000014431C: 4AC6BA8C
	.long 0x7f063880                                           // 000000144320: 7F063880
	ds_store_b16 v88, v3 offset:20                             // 000000144324: D87C0014 00000358
	.long 0xd4440008                                           // 00000014432C: D4440008
	v_cndmask_b32_e32 v1, s41, v99, vcc_lo                     // 000000144330: 0202C629
	.long 0x7e083983                                           // 000000144334: 7E083983
	s_and_saveexec_b32 s10, s8                                 // 000000144338: BE8A2008
	s_cbranch_execz 15                                         // 00000014433C: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x77c>
	v_mad_u64_u32 v[4:5], null, v99, 48, s[2:3]                // 000000144340: D6FE7C04 00096163
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144348: BF870091
	.long 0xd73c0004                                           // 00000014434C: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000144350: 02020889
	.long 0xd7000904                                           // 000000144354: D7000904
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 000000144358: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014435C: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s9                  // 000000144360: D5207C05 00260B57
	global_load_b32 v4, v[4:5], off                            // 000000144368: DC520000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000144370: BF8903F7
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 000000144374: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014437C: 8C7E0A7E
	v_add_nc_u32_e32 v100, 14, v93                             // 000000144380: 4AC8BA8E
	ds_store_b16 v88, v4 offset:24                             // 000000144384: D87C0018 00000458
	.long 0xd4440009                                           // 00000014438C: D4440009
	v_cndmask_b32_e32 v1, s41, v100, vcc_lo                    // 000000144390: 0202C829
	s_and_saveexec_b32 s11, s9                                 // 000000144394: BE8B2009
	s_cbranch_execz 15                                         // 000000144398: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x7d8>
	v_mad_u64_u32 v[3:4], null, v100, 48, s[2:3]               // 00000014439C: D6FE7C03 00096164
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001443A4: BF870091
	.long 0xd73c0003                                           // 0000001443A8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001443AC: 02020689
	.long 0xd7000a03                                           // 0000001443B0: D7000A03
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 0000001443B4: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001443B8: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s10                 // 0000001443BC: D5207C04 002A0957
	global_load_b32 v3, v[3:4], off                            // 0000001443C4: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000001443CC: BF8903F7
	v_fma_mixhi_f16 v3, v3, s18, 0                             // 0000001443D0: CC220003 02002503
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001443D8: 8C7E0B7E
	.long 0x7e063880                                           // 0000001443DC: 7E063880
	ds_store_b16_d16_hi v88, v3 offset:28                      // 0000001443E0: DA84001C 00000358
	.long 0x7e083903                                           // 0000001443E8: 7E083903
	s_and_saveexec_b32 s11, s0                                 // 0000001443EC: BE8B2000
	s_cbranch_execz 15                                         // 0000001443F0: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x830>
	v_mad_u64_u32 v[4:5], null, v93, 48, s[2:3]                // 0000001443F4: D6FE7C04 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001443FC: BF870091
	.long 0xd73c0004                                           // 000000144400: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000144404: 02020889
	.long 0xd7000a04                                           // 000000144408: D7000A04
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 00000014440C: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144410: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s10                 // 000000144414: D5207C05 002A0B57
	global_load_b32 v4, v[4:5], off offset:64                  // 00000014441C: DC520040 047C0004
	s_waitcnt vmcnt(0)                                         // 000000144424: BF8903F7
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 000000144428: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144430: 8C7E0B7E
	ds_store_b16 v88, v4 offset:2560                           // 000000144434: D87C0A00 00000458
	s_and_saveexec_b32 s11, s1                                 // 00000014443C: BE8B2001
	s_cbranch_execz 15                                         // 000000144440: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x880>
	v_mad_u64_u32 v[3:4], null, v94, 48, s[2:3]                // 000000144444: D6FE7C03 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014444C: BF870091
	.long 0xd73c0003                                           // 000000144450: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000144454: 02020689
	.long 0xd7000a03                                           // 000000144458: D7000A03
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 00000014445C: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144460: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s10                 // 000000144464: D5207C04 002A0957
	global_load_b32 v3, v[3:4], off offset:64                  // 00000014446C: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 000000144474: BF8903F7
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 000000144478: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144480: 8C7E0B7E
	.long 0x7f063880                                           // 000000144484: 7F063880
	ds_store_b16 v88, v3 offset:2564                           // 000000144488: D87C0A04 00000358
	.long 0x7e083983                                           // 000000144490: 7E083983
	s_and_saveexec_b32 s11, s4                                 // 000000144494: BE8B2004
	s_cbranch_execz 15                                         // 000000144498: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8d8>
	v_mad_u64_u32 v[4:5], null, v95, 48, s[2:3]                // 00000014449C: D6FE7C04 0009615F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001444A4: BF870091
	.long 0xd73c0004                                           // 0000001444A8: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 0000001444AC: 02020889
	.long 0xd7000a04                                           // 0000001444B0: D7000A04
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 0000001444B4: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001444B8: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s10                 // 0000001444BC: D5207C05 002A0B57
	global_load_b32 v4, v[4:5], off offset:64                  // 0000001444C4: DC520040 047C0004
	s_waitcnt vmcnt(0)                                         // 0000001444CC: BF8903F7
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 0000001444D0: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001444D8: 8C7E0B7E
	ds_store_b16 v88, v4 offset:2568                           // 0000001444DC: D87C0A08 00000458
	s_and_saveexec_b32 s11, s5                                 // 0000001444E4: BE8B2005
	s_cbranch_execz 15                                         // 0000001444E8: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x928>
	v_mad_u64_u32 v[3:4], null, v96, 48, s[2:3]                // 0000001444EC: D6FE7C03 00096160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001444F4: BF870091
	.long 0xd73c0003                                           // 0000001444F8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001444FC: 02020689
	.long 0xd7000a03                                           // 000000144500: D7000A03
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 000000144504: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144508: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s10                 // 00000014450C: D5207C04 002A0957
	global_load_b32 v3, v[3:4], off offset:64                  // 000000144514: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014451C: BF8903F7
	v_fma_mixhi_f16 v3, v3, s18, 0                             // 000000144520: CC220003 02002503
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144528: 8C7E0B7E
	.long 0x7e063880                                           // 00000014452C: 7E063880
	ds_store_b16_d16_hi v88, v3 offset:2572                    // 000000144530: DA840A0C 00000358
	.long 0x7e083903                                           // 000000144538: 7E083903
	s_and_saveexec_b32 s11, s6                                 // 00000014453C: BE8B2006
	s_cbranch_execz 15                                         // 000000144540: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x980>
	v_mad_u64_u32 v[4:5], null, v97, 48, s[2:3]                // 000000144544: D6FE7C04 00096161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014454C: BF870091
	.long 0xd73c0004                                           // 000000144550: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000144554: 02020889
	.long 0xd7000a04                                           // 000000144558: D7000A04
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 00000014455C: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144560: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s10                 // 000000144564: D5207C05 002A0B57
	global_load_b32 v4, v[4:5], off offset:64                  // 00000014456C: DC520040 047C0004
	s_waitcnt vmcnt(0)                                         // 000000144574: BF8903F7
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 000000144578: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144580: 8C7E0B7E
	ds_store_b16 v88, v4 offset:2576                           // 000000144584: D87C0A10 00000458
	s_and_saveexec_b32 s11, s7                                 // 00000014458C: BE8B2007
	s_cbranch_execz 15                                         // 000000144590: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x9d0>
	v_mad_u64_u32 v[3:4], null, v98, 48, s[2:3]                // 000000144594: D6FE7C03 00096162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014459C: BF870091
	.long 0xd73c0003                                           // 0000001445A0: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001445A4: 02020689
	.long 0xd7000a03                                           // 0000001445A8: D7000A03
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 0000001445AC: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001445B0: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s10                 // 0000001445B4: D5207C04 002A0957
	global_load_b32 v3, v[3:4], off offset:64                  // 0000001445BC: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 0000001445C4: BF8903F7
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 0000001445C8: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001445D0: 8C7E0B7E
	.long 0x7f063880                                           // 0000001445D4: 7F063880
	ds_store_b16 v88, v3 offset:2580                           // 0000001445D8: D87C0A14 00000358
	.long 0x7e083983                                           // 0000001445E0: 7E083983
	s_and_saveexec_b32 s11, s8                                 // 0000001445E4: BE8B2008
	s_cbranch_execz 15                                         // 0000001445E8: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa28>
	v_mad_u64_u32 v[4:5], null, v99, 48, s[2:3]                // 0000001445EC: D6FE7C04 00096163
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001445F4: BF870091
	.long 0xd73c0004                                           // 0000001445F8: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 0000001445FC: 02020889
	.long 0xd7000a04                                           // 000000144600: D7000A04
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 000000144604: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144608: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s10                 // 00000014460C: D5207C05 002A0B57
	global_load_b32 v4, v[4:5], off offset:64                  // 000000144614: DC520040 047C0004
	s_waitcnt vmcnt(0)                                         // 00000014461C: BF8903F7
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 000000144620: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144628: 8C7E0B7E
	ds_store_b16 v88, v4 offset:2584                           // 00000014462C: D87C0A18 00000458
	s_and_saveexec_b32 s11, s9                                 // 000000144634: BE8B2009
	s_cbranch_execz 15                                         // 000000144638: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa78>
	v_mad_u64_u32 v[3:4], null, v100, 48, s[2:3]               // 00000014463C: D6FE7C03 00096164
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144644: BF870091
	.long 0xd73c0003                                           // 000000144648: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014464C: 02020689
	.long 0xd7000a03                                           // 000000144650: D7000A03
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 000000144654: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144658: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s10                 // 00000014465C: D5207C04 002A0957
	global_load_b32 v3, v[3:4], off offset:64                  // 000000144664: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014466C: BF8903F7
	v_fma_mixhi_f16 v3, v3, s18, 0                             // 000000144670: CC220003 02002503
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144678: 8C7E0B7E
	.long 0x7e063880                                           // 00000014467C: 7E063880
	ds_store_b16_d16_hi v88, v3 offset:2588                    // 000000144680: DA840A1C 00000358
	.long 0x7e083903                                           // 000000144688: 7E083903
	s_and_saveexec_b32 s11, s0                                 // 00000014468C: BE8B2000
	s_cbranch_execz 15                                         // 000000144690: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xad0>
	v_mad_u64_u32 v[4:5], null, v93, 48, s[2:3]                // 000000144694: D6FE7C04 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014469C: BF870091
	.long 0xd73c0004                                           // 0000001446A0: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 0000001446A4: 02020889
	.long 0xd7000a04                                           // 0000001446A8: D7000A04
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 0000001446AC: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001446B0: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s10                 // 0000001446B4: D5207C05 002A0B57
	global_load_b32 v4, v[4:5], off offset:128                 // 0000001446BC: DC520080 047C0004
	s_waitcnt vmcnt(0)                                         // 0000001446C4: BF8903F7
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 0000001446C8: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001446D0: 8C7E0B7E
	ds_store_b16 v88, v4 offset:5120                           // 0000001446D4: D87C1400 00000458
	s_and_saveexec_b32 s11, s1                                 // 0000001446DC: BE8B2001
	s_cbranch_execz 15                                         // 0000001446E0: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb20>
	v_mad_u64_u32 v[3:4], null, v94, 48, s[2:3]                // 0000001446E4: D6FE7C03 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001446EC: BF870091
	.long 0xd73c0003                                           // 0000001446F0: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001446F4: 02020689
	.long 0xd7000a03                                           // 0000001446F8: D7000A03
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 0000001446FC: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144700: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s10                 // 000000144704: D5207C04 002A0957
	global_load_b32 v3, v[3:4], off offset:128                 // 00000014470C: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 000000144714: BF8903F7
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 000000144718: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144720: 8C7E0B7E
	.long 0x7f063880                                           // 000000144724: 7F063880
	ds_store_b16 v88, v3 offset:5124                           // 000000144728: D87C1404 00000358
	.long 0x7e083983                                           // 000000144730: 7E083983
	s_and_saveexec_b32 s11, s4                                 // 000000144734: BE8B2004
	s_cbranch_execz 15                                         // 000000144738: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb78>
	v_mad_u64_u32 v[4:5], null, v95, 48, s[2:3]                // 00000014473C: D6FE7C04 0009615F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144744: BF870091
	.long 0xd73c0004                                           // 000000144748: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 00000014474C: 02020889
	.long 0xd7000a04                                           // 000000144750: D7000A04
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 000000144754: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144758: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s10                 // 00000014475C: D5207C05 002A0B57
	global_load_b32 v4, v[4:5], off offset:128                 // 000000144764: DC520080 047C0004
	s_waitcnt vmcnt(0)                                         // 00000014476C: BF8903F7
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 000000144770: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144778: 8C7E0B7E
	ds_store_b16 v88, v4 offset:5128                           // 00000014477C: D87C1408 00000458
	s_and_saveexec_b32 s11, s5                                 // 000000144784: BE8B2005
	s_cbranch_execz 15                                         // 000000144788: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xbc8>
	v_mad_u64_u32 v[3:4], null, v96, 48, s[2:3]                // 00000014478C: D6FE7C03 00096160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144794: BF870091
	.long 0xd73c0003                                           // 000000144798: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000014479C: 02020689
	.long 0xd7000a03                                           // 0000001447A0: D7000A03
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 0000001447A4: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001447A8: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s10                 // 0000001447AC: D5207C04 002A0957
	global_load_b32 v3, v[3:4], off offset:128                 // 0000001447B4: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 0000001447BC: BF8903F7
	v_fma_mixhi_f16 v3, v3, s18, 0                             // 0000001447C0: CC220003 02002503
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001447C8: 8C7E0B7E
	.long 0x7e063880                                           // 0000001447CC: 7E063880
	ds_store_b16_d16_hi v88, v3 offset:5132                    // 0000001447D0: DA84140C 00000358
	.long 0x7e083903                                           // 0000001447D8: 7E083903
	s_and_saveexec_b32 s11, s6                                 // 0000001447DC: BE8B2006
	s_cbranch_execz 15                                         // 0000001447E0: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc20>
	v_mad_u64_u32 v[4:5], null, v97, 48, s[2:3]                // 0000001447E4: D6FE7C04 00096161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001447EC: BF870091
	.long 0xd73c0004                                           // 0000001447F0: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 0000001447F4: 02020889
	.long 0xd7000a04                                           // 0000001447F8: D7000A04
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 0000001447FC: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144800: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s10                 // 000000144804: D5207C05 002A0B57
	global_load_b32 v4, v[4:5], off offset:128                 // 00000014480C: DC520080 047C0004
	s_waitcnt vmcnt(0)                                         // 000000144814: BF8903F7
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 000000144818: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144820: 8C7E0B7E
	ds_store_b16 v88, v4 offset:5136                           // 000000144824: D87C1410 00000458
	s_and_saveexec_b32 s11, s7                                 // 00000014482C: BE8B2007
	s_cbranch_execz 15                                         // 000000144830: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc70>
	v_mad_u64_u32 v[3:4], null, v98, 48, s[2:3]                // 000000144834: D6FE7C03 00096162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014483C: BF870091
	.long 0xd73c0003                                           // 000000144840: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000144844: 02020689
	.long 0xd7000a03                                           // 000000144848: D7000A03
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 00000014484C: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144850: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s10                 // 000000144854: D5207C04 002A0957
	global_load_b32 v3, v[3:4], off offset:128                 // 00000014485C: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 000000144864: BF8903F7
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 000000144868: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144870: 8C7E0B7E
	.long 0x7f063880                                           // 000000144874: 7F063880
	ds_store_b16 v88, v3 offset:5140                           // 000000144878: D87C1414 00000358
	.long 0x7e083983                                           // 000000144880: 7E083983
	s_and_saveexec_b32 s11, s8                                 // 000000144884: BE8B2008
	s_cbranch_execz 15                                         // 000000144888: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xcc8>
	v_mad_u64_u32 v[4:5], null, v99, 48, s[2:3]                // 00000014488C: D6FE7C04 00096163
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144894: BF870091
	.long 0xd73c0004                                           // 000000144898: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 00000014489C: 02020889
	.long 0xd7000a04                                           // 0000001448A0: D7000A04
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 0000001448A4: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001448A8: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s10                 // 0000001448AC: D5207C05 002A0B57
	global_load_b32 v4, v[4:5], off offset:128                 // 0000001448B4: DC520080 047C0004
	s_waitcnt vmcnt(0)                                         // 0000001448BC: BF8903F7
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 0000001448C0: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001448C8: 8C7E0B7E
	ds_store_b16 v88, v4 offset:5144                           // 0000001448CC: D87C1418 00000458
	s_and_saveexec_b32 s11, s9                                 // 0000001448D4: BE8B2009
	s_cbranch_execz 15                                         // 0000001448D8: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd18>
	v_mad_u64_u32 v[3:4], null, v100, 48, s[2:3]               // 0000001448DC: D6FE7C03 00096164
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001448E4: BF870091
	.long 0xd73c0003                                           // 0000001448E8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001448EC: 02020689
	.long 0xd7000a03                                           // 0000001448F0: D7000A03
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 0000001448F4: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001448F8: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s10                 // 0000001448FC: D5207C04 002A0957
	global_load_b32 v3, v[3:4], off offset:128                 // 000000144904: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 00000014490C: BF8903F7
	v_fma_mixhi_f16 v3, v3, s18, 0                             // 000000144910: CC220003 02002503
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144918: 8C7E0B7E
	.long 0x7e063880                                           // 00000014491C: 7E063880
	ds_store_b16_d16_hi v88, v3 offset:5148                    // 000000144920: DA84141C 00000358
	.long 0x7e083903                                           // 000000144928: 7E083903
	s_and_saveexec_b32 s11, s0                                 // 00000014492C: BE8B2000
	s_cbranch_execz 15                                         // 000000144930: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd70>
	v_mad_u64_u32 v[4:5], null, v93, 48, s[2:3]                // 000000144934: D6FE7C04 0009615D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014493C: BF870091
	.long 0xd73c0004                                           // 000000144940: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000144944: 02020889
	.long 0xd7000a04                                           // 000000144948: D7000A04
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 00000014494C: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144950: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s10                 // 000000144954: D5207C05 002A0B57
	global_load_b32 v4, v[4:5], off offset:192                 // 00000014495C: DC5200C0 047C0004
	s_waitcnt vmcnt(0)                                         // 000000144964: BF8903F7
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 000000144968: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144970: 8C7E0B7E
	ds_store_b16 v88, v4 offset:7680                           // 000000144974: D87C1E00 00000458
	s_and_saveexec_b32 s11, s1                                 // 00000014497C: BE8B2001
	s_cbranch_execz 15                                         // 000000144980: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xdc0>
	v_mad_u64_u32 v[3:4], null, v94, 48, s[2:3]                // 000000144984: D6FE7C03 0009615E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014498C: BF870091
	.long 0xd73c0003                                           // 000000144990: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000144994: 02020689
	.long 0xd7000a03                                           // 000000144998: D7000A03
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 00000014499C: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001449A0: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s10                 // 0000001449A4: D5207C04 002A0957
	global_load_b32 v3, v[3:4], off offset:192                 // 0000001449AC: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 0000001449B4: BF8903F7
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 0000001449B8: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001449C0: 8C7E0B7E
	.long 0x7f063880                                           // 0000001449C4: 7F063880
	ds_store_b16 v88, v3 offset:7684                           // 0000001449C8: D87C1E04 00000358
	.long 0x7e083983                                           // 0000001449D0: 7E083983
	s_and_saveexec_b32 s11, s4                                 // 0000001449D4: BE8B2004
	s_cbranch_execz 15                                         // 0000001449D8: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe18>
	v_mad_u64_u32 v[4:5], null, v95, 48, s[2:3]                // 0000001449DC: D6FE7C04 0009615F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001449E4: BF870091
	.long 0xd73c0004                                           // 0000001449E8: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 0000001449EC: 02020889
	.long 0xd7000a04                                           // 0000001449F0: D7000A04
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 0000001449F4: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001449F8: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s10                 // 0000001449FC: D5207C05 002A0B57
	global_load_b32 v4, v[4:5], off offset:192                 // 000000144A04: DC5200C0 047C0004
	s_waitcnt vmcnt(0)                                         // 000000144A0C: BF8903F7
	v_fma_mixlo_f16 v4, v4, s18, 0                             // 000000144A10: CC210004 02002504
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144A18: 8C7E0B7E
	ds_store_b16 v88, v4 offset:7688                           // 000000144A1C: D87C1E08 00000458
	s_and_saveexec_b32 s11, s5                                 // 000000144A24: BE8B2005
	s_cbranch_execz 15                                         // 000000144A28: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe68>
	v_mad_u64_u32 v[3:4], null, v96, 48, s[2:3]                // 000000144A2C: D6FE7C03 00096160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144A34: BF870091
	.long 0xd73c0003                                           // 000000144A38: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000144A3C: 02020689
	.long 0xd7000a03                                           // 000000144A40: D7000A03
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 000000144A44: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144A48: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s10                 // 000000144A4C: D5207C04 002A0957
	global_load_b32 v3, v[3:4], off offset:192                 // 000000144A54: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 000000144A5C: BF8903F7
	v_fma_mixhi_f16 v3, v3, s18, 0                             // 000000144A60: CC220003 02002503
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144A68: 8C7E0B7E
	.long 0x7e083880                                           // 000000144A6C: 7E083880
	ds_store_b16_d16_hi v88, v3 offset:7692                    // 000000144A70: DA841E0C 00000358
	.long 0x7e063904                                           // 000000144A78: 7E063904
	s_and_saveexec_b32 s11, s6                                 // 000000144A7C: BE8B2006
	s_cbranch_execz 15                                         // 000000144A80: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xec0>
	v_mad_u64_u32 v[5:6], null, v97, 48, s[2:3]                // 000000144A84: D6FE7C05 00096161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144A8C: BF870091
	.long 0xd73c0005                                           // 000000144A90: D73C0005
	v_cndmask_b32_e32 v1, 9, v5, vcc_lo                        // 000000144A94: 02020A89
	.long 0xd7000a05                                           // 000000144A98: D7000A05
	v_cndmask_b32_e32 v1, v86, v5, vcc_lo                      // 000000144A9C: 02020B56
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144AA0: BF870001
	v_add_co_ci_u32_e64 v6, null, v87, v6, s10                 // 000000144AA4: D5207C06 002A0D57
	global_load_b32 v3, v[5:6], off offset:192                 // 000000144AAC: DC5200C0 037C0005
	s_waitcnt vmcnt(0)                                         // 000000144AB4: BF8903F7
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 000000144AB8: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144AC0: 8C7E0B7E
	ds_store_b16 v88, v3 offset:7696                           // 000000144AC4: D87C1E10 00000358
	s_and_saveexec_b32 s11, s7                                 // 000000144ACC: BE8B2007
	s_cbranch_execz 15                                         // 000000144AD0: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xf10>
	v_mad_u64_u32 v[3:4], null, v98, 48, s[2:3]                // 000000144AD4: D6FE7C03 00096162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144ADC: BF870091
	.long 0xd73c0003                                           // 000000144AE0: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000144AE4: 02020689
	.long 0xd7000a03                                           // 000000144AE8: D7000A03
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 000000144AEC: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144AF0: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s10                 // 000000144AF4: D5207C04 002A0957
	global_load_b32 v3, v[3:4], off offset:192                 // 000000144AFC: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 000000144B04: BF8903F7
	v_fma_mixlo_f16 v4, v3, s18, 0                             // 000000144B08: CC210004 02002503
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144B10: 8C7E0B7E
	.long 0x7e063880                                           // 000000144B14: 7E063880
	ds_store_b16 v88, v4 offset:7700                           // 000000144B18: D87C1E14 00000458
	.long 0x7f063903                                           // 000000144B20: 7F063903
	s_and_saveexec_b32 s11, s8                                 // 000000144B24: BE8B2008
	s_cbranch_execz 15                                         // 000000144B28: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xf68>
	v_mad_u64_u32 v[4:5], null, v99, 48, s[2:3]                // 000000144B2C: D6FE7C04 00096163
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144B34: BF870091
	.long 0xd73c0004                                           // 000000144B38: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000144B3C: 02020889
	.long 0xd7000a04                                           // 000000144B40: D7000A04
	v_cndmask_b32_e32 v1, v86, v4, vcc_lo                      // 000000144B44: 02020956
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144B48: BF870001
	v_add_co_ci_u32_e64 v5, null, v87, v5, s10                 // 000000144B4C: D5207C05 002A0B57
	global_load_b32 v4, v[4:5], off offset:192                 // 000000144B54: DC5200C0 047C0004
	s_waitcnt vmcnt(0)                                         // 000000144B5C: BF8903F7
	v_fma_mixhi_f16 v3, v4, s18, 0                             // 000000144B60: CC220003 02002504
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144B68: 8C7E0B7E
	ds_store_b16_d16_hi v88, v3 offset:7704                    // 000000144B6C: DA841E18 00000358
	s_and_saveexec_b32 s11, s9                                 // 000000144B74: BE8B2009
	s_cbranch_execz 15                                         // 000000144B78: BFA5000F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfb8>
	v_mad_u64_u32 v[3:4], null, v100, 48, s[2:3]               // 000000144B7C: D6FE7C03 00096164
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144B84: BF870091
	.long 0xd73c0003                                           // 000000144B88: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000144B8C: 02020689
	.long 0xd7000a03                                           // 000000144B90: D7000A03
	v_cndmask_b32_e32 v1, v86, v3, vcc_lo                      // 000000144B94: 02020756
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144B98: BF870001
	v_add_co_ci_u32_e64 v4, null, v87, v4, s10                 // 000000144B9C: D5207C04 002A0957
	global_load_b32 v3, v[3:4], off offset:192                 // 000000144BA4: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 000000144BAC: BF8903F7
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 000000144BB0: CC210003 02002503
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144BB8: 8C7E0B7E
	v_add_nc_u32_e32 v6, s22, v80                              // 000000144BBC: 4A0CA016
	.long 0x7f5c3880                                           // 000000144BC0: 7F5C3880
	ds_store_b16 v88, v3 offset:7708                           // 000000144BC4: D87C1E1C 00000358
	s_waitcnt lgkmcnt(0)                                       // 000000144BCC: BF89FC07
	s_barrier                                                  // 000000144BD0: BFBD0000
	v_mad_u64_u32 v[4:5], null, v6, 48, s[2:3]                 // 000000144BD4: D6FE7C04 00096106
	.long 0xd444000a                                           // 000000144BDC: D444000A
	v_cndmask_b32_e32 v1, s41, v6, vcc_lo                      // 000000144BE0: 02020C29
	.long 0x7f5839ae                                           // 000000144BE4: 7F5839AE
	.long 0x7e5839ae                                           // 000000144BE8: 7E5839AE
	.long 0x7f5639ae                                           // 000000144BEC: 7F5639AE
	.long 0x7e5639ae                                           // 000000144BF0: 7E5639AE
	buffer_gl0_inv                                             // 000000144BF4: E0AC0000 00000000
	.long 0xd73c0004                                           // 000000144BFC: D73C0004
	v_cndmask_b32_e32 v1, 9, v4, vcc_lo                        // 000000144C00: 02020889
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000144C04: BF870091
	.long 0xd7000b35                                           // 000000144C08: D7000B35
	v_cndmask_b32_e32 v1, s16, v4, vcc_lo                      // 000000144C0C: 02020810
	v_add_co_ci_u32_e64 v54, null, s17, v5, s11                // 000000144C10: D5207C36 002E0A11
	s_and_saveexec_b32 s11, s10                                // 000000144C18: BE8B200A
	s_cbranch_execz 11                                         // 000000144C1C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x104c>
	global_load_b128 v[3:6], v[53:54], off                     // 000000144C20: DC5E0000 037C0035
	s_waitcnt vmcnt(0)                                         // 000000144C28: BF8903F7
	v_fma_mixlo_f16 v43, v3, s18, 0                            // 000000144C2C: CC21002B 02002503
	v_fma_mixhi_f16 v43, v4, s18, 0                            // 000000144C34: CC22002B 02002504
	v_fma_mixlo_f16 v44, v5, s18, 0                            // 000000144C3C: CC21002C 02002505
	v_fma_mixhi_f16 v44, v6, s18, 0                            // 000000144C44: CC22002C 02002506
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144C4C: 8C7E0B7E
	.long 0x7e5c39ae                                           // 000000144C50: 7E5C39AE
	.long 0x7f5a39ae                                           // 000000144C54: 7F5A39AE
	.long 0x7e5a39ae                                           // 000000144C58: 7E5A39AE
	s_and_saveexec_b32 s11, s10                                // 000000144C5C: BE8B200A
	s_cbranch_execz 11                                         // 000000144C60: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1090>
	global_load_b128 v[3:6], v[53:54], off offset:16           // 000000144C64: DC5E0010 037C0035
	s_waitcnt vmcnt(0)                                         // 000000144C6C: BF8903F7
	v_fma_mixlo_f16 v45, v3, s18, 0                            // 000000144C70: CC21002D 02002503
	v_fma_mixhi_f16 v45, v4, s18, 0                            // 000000144C78: CC22002D 02002504
	v_fma_mixlo_f16 v46, v5, s18, 0                            // 000000144C80: CC21002E 02002505
	v_fma_mixhi_f16 v46, v6, s18, 0                            // 000000144C88: CC22002E 02002506
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144C90: 8C7E0B7E
	.long 0x7f643880                                           // 000000144C94: 7F643880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000144C98: BF870001
	.long 0x7f6039b2                                           // 000000144C9C: 7F6039B2
	.long 0x7e6039b2                                           // 000000144CA0: 7E6039B2
	.long 0x7f5e39b2                                           // 000000144CA4: 7F5E39B2
	.long 0x7e5e39b2                                           // 000000144CA8: 7E5E39B2
	s_and_saveexec_b32 s11, s10                                // 000000144CAC: BE8B200A
	s_cbranch_execz 11                                         // 000000144CB0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e0>
	global_load_b128 v[3:6], v[53:54], off offset:32           // 000000144CB4: DC5E0020 037C0035
	s_waitcnt vmcnt(0)                                         // 000000144CBC: BF8903F7
	v_fma_mixlo_f16 v47, v3, s18, 0                            // 000000144CC0: CC21002F 02002503
	v_fma_mixhi_f16 v47, v4, s18, 0                            // 000000144CC8: CC22002F 02002504
	v_fma_mixlo_f16 v48, v5, s18, 0                            // 000000144CD0: CC210030 02002505
	v_fma_mixhi_f16 v48, v6, s18, 0                            // 000000144CD8: CC220030 02002506
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144CE0: 8C7E0B7E
	.long 0x7e6439b2                                           // 000000144CE4: 7E6439B2
	.long 0x7f6239b2                                           // 000000144CE8: 7F6239B2
	.long 0x7e6239b2                                           // 000000144CEC: 7E6239B2
	s_and_saveexec_b32 s11, s10                                // 000000144CF0: BE8B200A
	s_cbranch_execz 11                                         // 000000144CF4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1124>
	global_load_b128 v[3:6], v[53:54], off offset:48           // 000000144CF8: DC5E0030 037C0035
	s_waitcnt vmcnt(0)                                         // 000000144D00: BF8903F7
	v_fma_mixlo_f16 v49, v3, s18, 0                            // 000000144D04: CC210031 02002503
	v_fma_mixhi_f16 v49, v4, s18, 0                            // 000000144D0C: CC220031 02002504
	v_fma_mixlo_f16 v50, v5, s18, 0                            // 000000144D14: CC210032 02002505
	v_fma_mixhi_f16 v50, v6, s18, 0                            // 000000144D1C: CC220032 02002506
	s_or_b32 exec_lo, exec_lo, s11                             // 000000144D24: 8C7E0B7E
	ds_load_b128 v[3:6], v78                                   // 000000144D28: DBFC0000 0300004E
	ds_load_b128 v[7:10], v78 offset:16                        // 000000144D30: DBFC0010 0700004E
	ds_load_b128 v[11:14], v78 offset:32                       // 000000144D38: DBFC0020 0B00004E
	ds_load_b128 v[15:18], v78 offset:48                       // 000000144D40: DBFC0030 0F00004E
	ds_load_b128 v[19:22], v78 offset:8448                     // 000000144D48: DBFC2100 1300004E
	ds_load_b128 v[23:26], v78 offset:8464                     // 000000144D50: DBFC2110 1700004E
	ds_load_b128 v[27:30], v78 offset:8480                     // 000000144D58: DBFC2120 1B00004E
	ds_load_b128 v[31:34], v78 offset:8496                     // 000000144D60: DBFC2130 1F00004E
	ds_load_b128 v[35:38], v78 offset:16896                    // 000000144D68: DBFC4200 2300004E
	ds_load_b128 v[39:42], v78 offset:16912                    // 000000144D70: DBFC4210 2700004E
	v_dual_mov_b32 v62, s31 :: v_dual_mov_b32 v61, s30         // 000000144D78: CA10001F 3E3C001E
	v_dual_mov_b32 v60, s29 :: v_dual_mov_b32 v59, s28         // 000000144D80: CA10001D 3C3A001C
	v_dual_mov_b32 v58, s27 :: v_dual_mov_b32 v57, s26         // 000000144D88: CA10001B 3A38001A
	v_dual_mov_b32 v56, s25 :: v_dual_mov_b32 v55, s24         // 000000144D90: CA100019 38360018
	ds_load_b128 v[63:66], v78 offset:16928                    // 000000144D98: DBFC4220 3F00004E
	ds_load_b128 v[101:104], v78 offset:16944                  // 000000144DA0: DBFC4230 6500004E
	s_waitcnt lgkmcnt(11)                                      // 000000144DA8: BF89FCB7
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 000000144DAC: CC210003 02002503
	v_fma_mixhi_f16 v3, v4, s18, 0                             // 000000144DB4: CC220003 02002504
	v_fma_mixlo_f16 v4, v5, s18, 0                             // 000000144DBC: CC210004 02002505
	v_fma_mixhi_f16 v4, v6, s18, 0                             // 000000144DC4: CC220004 02002506
	s_waitcnt lgkmcnt(10)                                      // 000000144DCC: BF89FCA7
	v_fma_mixlo_f16 v5, v7, s18, 0                             // 000000144DD0: CC210005 02002507
	v_fma_mixhi_f16 v5, v8, s18, 0                             // 000000144DD8: CC220005 02002508
	v_fma_mixlo_f16 v6, v9, s18, 0                             // 000000144DE0: CC210006 02002509
	v_fma_mixhi_f16 v6, v10, s18, 0                            // 000000144DE8: CC220006 0200250A
	s_waitcnt lgkmcnt(9)                                       // 000000144DF0: BF89FC97
	v_fma_mixlo_f16 v7, v11, s18, 0                            // 000000144DF4: CC210007 0200250B
	v_fma_mixhi_f16 v7, v12, s18, 0                            // 000000144DFC: CC220007 0200250C
	v_fma_mixlo_f16 v8, v13, s18, 0                            // 000000144E04: CC210008 0200250D
	v_fma_mixhi_f16 v8, v14, s18, 0                            // 000000144E0C: CC220008 0200250E
	s_waitcnt lgkmcnt(8)                                       // 000000144E14: BF89FC87
	v_fma_mixlo_f16 v9, v15, s18, 0                            // 000000144E18: CC210009 0200250F
	v_fma_mixhi_f16 v9, v16, s18, 0                            // 000000144E20: CC220009 02002510
	v_fma_mixlo_f16 v10, v17, s18, 0                           // 000000144E28: CC21000A 02002511
	v_fma_mixhi_f16 v10, v18, s18, 0                           // 000000144E30: CC22000A 02002512
	s_waitcnt lgkmcnt(7)                                       // 000000144E38: BF89FC77
	v_fma_mixlo_f16 v11, v19, s18, 0                           // 000000144E3C: CC21000B 02002513
	v_fma_mixhi_f16 v11, v20, s18, 0                           // 000000144E44: CC22000B 02002514
	v_fma_mixlo_f16 v12, v21, s18, 0                           // 000000144E4C: CC21000C 02002515
	v_fma_mixhi_f16 v12, v22, s18, 0                           // 000000144E54: CC22000C 02002516
	s_waitcnt lgkmcnt(6)                                       // 000000144E5C: BF89FC67
	v_fma_mixlo_f16 v13, v23, s18, 0                           // 000000144E60: CC21000D 02002517
	v_fma_mixhi_f16 v13, v24, s18, 0                           // 000000144E68: CC22000D 02002518
	v_fma_mixlo_f16 v14, v25, s18, 0                           // 000000144E70: CC21000E 02002519
	v_fma_mixhi_f16 v14, v26, s18, 0                           // 000000144E78: CC22000E 0200251A
	s_waitcnt lgkmcnt(5)                                       // 000000144E80: BF89FC57
	v_fma_mixlo_f16 v15, v27, s18, 0                           // 000000144E84: CC21000F 0200251B
	v_fma_mixhi_f16 v15, v28, s18, 0                           // 000000144E8C: CC22000F 0200251C
	v_fma_mixlo_f16 v16, v29, s18, 0                           // 000000144E94: CC210010 0200251D
	v_fma_mixhi_f16 v16, v30, s18, 0                           // 000000144E9C: CC220010 0200251E
	s_waitcnt lgkmcnt(4)                                       // 000000144EA4: BF89FC47
	v_fma_mixlo_f16 v17, v31, s18, 0                           // 000000144EA8: CC210011 0200251F
	v_fma_mixhi_f16 v17, v32, s18, 0                           // 000000144EB0: CC220011 02002520
	v_fma_mixlo_f16 v18, v33, s18, 0                           // 000000144EB8: CC210012 02002521
	v_fma_mixhi_f16 v18, v34, s18, 0                           // 000000144EC0: CC220012 02002522
	v_wmma_f32_16x16x16_f16 v[27:34], v[43:50], v[3:10], v[55:62]// 000000144EC8: CC40401B 1CDE072B
	s_waitcnt lgkmcnt(3)                                       // 000000144ED0: BF89FC37
	v_fma_mixlo_f16 v3, v35, s18, 0                            // 000000144ED4: CC210003 02002523
	v_fma_mixhi_f16 v3, v36, s18, 0                            // 000000144EDC: CC220003 02002524
	v_wmma_f32_16x16x16_f16 v[19:26], v[43:50], v[11:18], v[55:62]// 000000144EE4: CC404013 1CDE172B
	ds_load_b128 v[11:14], v78 offset:25344                    // 000000144EEC: DBFC6300 0B00004E
	ds_load_b128 v[15:18], v78 offset:25360                    // 000000144EF4: DBFC6310 0F00004E
	v_fma_mixlo_f16 v4, v37, s18, 0                            // 000000144EFC: CC210004 02002525
	v_fma_mixhi_f16 v4, v38, s18, 0                            // 000000144F04: CC220004 02002526
	s_waitcnt lgkmcnt(4)                                       // 000000144F0C: BF89FC47
	v_fma_mixlo_f16 v5, v39, s18, 0                            // 000000144F10: CC210005 02002527
	v_fma_mixhi_f16 v5, v40, s18, 0                            // 000000144F18: CC220005 02002528
	ds_load_b128 v[35:38], v78 offset:25376                    // 000000144F20: DBFC6320 2300004E
	v_fma_mixlo_f16 v6, v41, s18, 0                            // 000000144F28: CC210006 02002529
	v_fma_mixhi_f16 v6, v42, s18, 0                            // 000000144F30: CC220006 0200252A
	ds_load_b128 v[39:42], v78 offset:25392                    // 000000144F38: DBFC6330 2700004E
	s_waitcnt lgkmcnt(5)                                       // 000000144F40: BF89FC57
	v_fma_mixlo_f16 v7, v63, s18, 0                            // 000000144F44: CC210007 0200253F
	v_fma_mixhi_f16 v7, v64, s18, 0                            // 000000144F4C: CC220007 02002540
	v_fma_mixlo_f16 v8, v65, s18, 0                            // 000000144F54: CC210008 02002541
	v_fma_mixhi_f16 v8, v66, s18, 0                            // 000000144F5C: CC220008 02002542
	s_waitcnt lgkmcnt(4)                                       // 000000144F64: BF89FC47
	v_fma_mixlo_f16 v9, v101, s18, 0                           // 000000144F68: CC210009 02002565
	v_fma_mixhi_f16 v9, v102, s18, 0                           // 000000144F70: CC220009 02002566
	v_fma_mixlo_f16 v10, v103, s18, 0                          // 000000144F78: CC21000A 02002567
	v_fma_mixhi_f16 v10, v104, s18, 0                          // 000000144F80: CC22000A 02002568
	s_waitcnt lgkmcnt(3)                                       // 000000144F88: BF89FC37
	v_fma_mixlo_f16 v101, v11, s18, 0                          // 000000144F8C: CC210065 0200250B
	v_fma_mixhi_f16 v101, v12, s18, 0                          // 000000144F94: CC220065 0200250C
	v_fma_mixlo_f16 v102, v13, s18, 0                          // 000000144F9C: CC210066 0200250D
	v_fma_mixhi_f16 v102, v14, s18, 0                          // 000000144FA4: CC220066 0200250E
	s_waitcnt lgkmcnt(2)                                       // 000000144FAC: BF89FC27
	v_fma_mixlo_f16 v103, v15, s18, 0                          // 000000144FB0: CC210067 0200250F
	v_fma_mixhi_f16 v103, v16, s18, 0                          // 000000144FB8: CC220067 02002510
	v_fma_mixlo_f16 v104, v17, s18, 0                          // 000000144FC0: CC210068 02002511
	v_fma_mixhi_f16 v104, v18, s18, 0                          // 000000144FC8: CC220068 02002512
	s_waitcnt lgkmcnt(1)                                       // 000000144FD0: BF89FC17
	v_fma_mixlo_f16 v105, v35, s18, 0                          // 000000144FD4: CC210069 02002523
	v_fma_mixhi_f16 v105, v36, s18, 0                          // 000000144FDC: CC220069 02002524
	v_fma_mixlo_f16 v106, v37, s18, 0                          // 000000144FE4: CC21006A 02002525
	v_fma_mixhi_f16 v106, v38, s18, 0                          // 000000144FEC: CC22006A 02002526
	s_waitcnt lgkmcnt(0)                                       // 000000144FF4: BF89FC07
	v_fma_mixlo_f16 v107, v39, s18, 0                          // 000000144FF8: CC21006B 02002527
	v_fma_mixhi_f16 v107, v40, s18, 0                          // 000000145000: CC22006B 02002528
	v_fma_mixlo_f16 v108, v41, s18, 0                          // 000000145008: CC21006C 02002529
	v_fma_mixhi_f16 v108, v42, s18, 0                          // 000000145010: CC22006C 0200252A
	.long 0x7f543880                                           // 000000145018: 7F543880
	v_wmma_f32_16x16x16_f16 v[11:18], v[43:50], v[3:10], v[55:62]// 00000014501C: CC40400B 1CDE072B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000145024: BF870193
	v_wmma_f32_16x16x16_f16 v[3:10], v[43:50], v[101:108], v[55:62]// 000000145028: CC404003 1CDECB2B
	.long 0x7f5039aa                                           // 000000145030: 7F5039AA
	.long 0x7e5039aa                                           // 000000145034: 7E5039AA
	.long 0x7f4e39aa                                           // 000000145038: 7F4E39AA
	.long 0x7e4e39aa                                           // 00000014503C: 7E4E39AA
	s_and_saveexec_b32 s11, s10                                // 000000145040: BE8B200A
	s_cbranch_execz 11                                         // 000000145044: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1474>
	global_load_b128 v[35:38], v[53:54], off offset:64         // 000000145048: DC5E0040 237C0035
	s_waitcnt vmcnt(0)                                         // 000000145050: BF8903F7
	v_fma_mixlo_f16 v39, v35, s18, 0                           // 000000145054: CC210027 02002523
	v_fma_mixhi_f16 v39, v36, s18, 0                           // 00000014505C: CC220027 02002524
	v_fma_mixlo_f16 v40, v37, s18, 0                           // 000000145064: CC210028 02002525
	v_fma_mixhi_f16 v40, v38, s18, 0                           // 00000014506C: CC220028 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 000000145074: 8C7E0B7E
	.long 0x7e5439aa                                           // 000000145078: 7E5439AA
	.long 0x7f5239aa                                           // 00000014507C: 7F5239AA
	.long 0x7e5239aa                                           // 000000145080: 7E5239AA
	s_and_saveexec_b32 s11, s10                                // 000000145084: BE8B200A
	s_cbranch_execz 11                                         // 000000145088: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14b8>
	global_load_b128 v[35:38], v[53:54], off offset:80         // 00000014508C: DC5E0050 237C0035
	s_waitcnt vmcnt(0)                                         // 000000145094: BF8903F7
	v_fma_mixlo_f16 v41, v35, s18, 0                           // 000000145098: CC210029 02002523
	v_fma_mixhi_f16 v41, v36, s18, 0                           // 0000001450A0: CC220029 02002524
	v_fma_mixlo_f16 v42, v37, s18, 0                           // 0000001450A8: CC21002A 02002525
	v_fma_mixhi_f16 v42, v38, s18, 0                           // 0000001450B0: CC22002A 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001450B8: 8C7E0B7E
	.long 0x7f5c3880                                           // 0000001450BC: 7F5C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001450C0: BF870001
	.long 0x7f5839ae                                           // 0000001450C4: 7F5839AE
	.long 0x7e5839ae                                           // 0000001450C8: 7E5839AE
	.long 0x7f5639ae                                           // 0000001450CC: 7F5639AE
	.long 0x7e5639ae                                           // 0000001450D0: 7E5639AE
	s_and_saveexec_b32 s11, s10                                // 0000001450D4: BE8B200A
	s_cbranch_execz 11                                         // 0000001450D8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1508>
	global_load_b128 v[35:38], v[53:54], off offset:96         // 0000001450DC: DC5E0060 237C0035
	s_waitcnt vmcnt(0)                                         // 0000001450E4: BF8903F7
	v_fma_mixlo_f16 v43, v35, s18, 0                           // 0000001450E8: CC21002B 02002523
	v_fma_mixhi_f16 v43, v36, s18, 0                           // 0000001450F0: CC22002B 02002524
	v_fma_mixlo_f16 v44, v37, s18, 0                           // 0000001450F8: CC21002C 02002525
	v_fma_mixhi_f16 v44, v38, s18, 0                           // 000000145100: CC22002C 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 000000145108: 8C7E0B7E
	.long 0x7e5c39ae                                           // 00000014510C: 7E5C39AE
	.long 0x7f5a39ae                                           // 000000145110: 7F5A39AE
	.long 0x7e5a39ae                                           // 000000145114: 7E5A39AE
	s_and_saveexec_b32 s11, s10                                // 000000145118: BE8B200A
	s_cbranch_execz 11                                         // 00000014511C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x154c>
	global_load_b128 v[35:38], v[53:54], off offset:112        // 000000145120: DC5E0070 237C0035
	s_waitcnt vmcnt(0)                                         // 000000145128: BF8903F7
	v_fma_mixlo_f16 v45, v35, s18, 0                           // 00000014512C: CC21002D 02002523
	v_fma_mixhi_f16 v45, v36, s18, 0                           // 000000145134: CC22002D 02002524
	v_fma_mixlo_f16 v46, v37, s18, 0                           // 00000014513C: CC21002E 02002525
	v_fma_mixhi_f16 v46, v38, s18, 0                           // 000000145144: CC22002E 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 00000014514C: 8C7E0B7E
	ds_load_b128 v[35:38], v78 offset:64                       // 000000145150: DBFC0040 2300004E
	ds_load_b128 v[47:50], v78 offset:80                       // 000000145158: DBFC0050 2F00004E
	ds_load_b128 v[59:62], v78 offset:96                       // 000000145160: DBFC0060 3B00004E
	ds_load_b128 v[63:66], v78 offset:112                      // 000000145168: DBFC0070 3F00004E
	ds_load_b128 v[101:104], v78 offset:8512                   // 000000145170: DBFC2140 6500004E
	ds_load_b128 v[105:108], v78 offset:8528                   // 000000145178: DBFC2150 6900004E
	ds_load_b128 v[109:112], v78 offset:8544                   // 000000145180: DBFC2160 6D00004E
	ds_load_b128 v[113:116], v78 offset:8560                   // 000000145188: DBFC2170 7100004E
	ds_load_b128 v[121:124], v78 offset:25408                  // 000000145190: DBFC6340 7900004E
	ds_load_b128 v[125:128], v78 offset:25424                  // 000000145198: DBFC6350 7D00004E
	ds_load_b128 v[117:120], v78 offset:17008                  // 0000001451A0: DBFC4270 7500004E
	s_waitcnt lgkmcnt(10)                                      // 0000001451A8: BF89FCA7
	v_fma_mixlo_f16 v55, v35, s18, 0                           // 0000001451AC: CC210037 02002523
	v_fma_mixhi_f16 v55, v36, s18, 0                           // 0000001451B4: CC220037 02002524
	v_fma_mixlo_f16 v56, v37, s18, 0                           // 0000001451BC: CC210038 02002525
	v_fma_mixhi_f16 v56, v38, s18, 0                           // 0000001451C4: CC220038 02002526
	s_waitcnt lgkmcnt(9)                                       // 0000001451CC: BF89FC97
	v_fma_mixlo_f16 v57, v47, s18, 0                           // 0000001451D0: CC210039 0200252F
	v_fma_mixhi_f16 v57, v48, s18, 0                           // 0000001451D8: CC220039 02002530
	v_fma_mixlo_f16 v58, v49, s18, 0                           // 0000001451E0: CC21003A 02002531
	v_fma_mixhi_f16 v58, v50, s18, 0                           // 0000001451E8: CC22003A 02002532
	ds_load_b128 v[35:38], v78 offset:16960                    // 0000001451F0: DBFC4240 2300004E
	ds_load_b128 v[47:50], v78 offset:16976                    // 0000001451F8: DBFC4250 2F00004E
	s_waitcnt lgkmcnt(10)                                      // 000000145200: BF89FCA7
	v_fma_mixlo_f16 v59, v59, s18, 0                           // 000000145204: CC21003B 0200253B
	v_fma_mixhi_f16 v59, v60, s18, 0                           // 00000014520C: CC22003B 0200253C
	v_fma_mixlo_f16 v60, v61, s18, 0                           // 000000145214: CC21003C 0200253D
	v_fma_mixhi_f16 v60, v62, s18, 0                           // 00000014521C: CC22003C 0200253E
	s_waitcnt lgkmcnt(9)                                       // 000000145224: BF89FC97
	v_fma_mixlo_f16 v61, v63, s18, 0                           // 000000145228: CC21003D 0200253F
	v_fma_mixhi_f16 v61, v64, s18, 0                           // 000000145230: CC22003D 02002540
	v_fma_mixlo_f16 v62, v65, s18, 0                           // 000000145238: CC21003E 02002541
	v_fma_mixhi_f16 v62, v66, s18, 0                           // 000000145240: CC22003E 02002542
	s_waitcnt lgkmcnt(8)                                       // 000000145248: BF89FC87
	v_fma_mixlo_f16 v101, v101, s18, 0                         // 00000014524C: CC210065 02002565
	v_fma_mixhi_f16 v101, v102, s18, 0                         // 000000145254: CC220065 02002566
	v_fma_mixlo_f16 v102, v103, s18, 0                         // 00000014525C: CC210066 02002567
	s_waitcnt lgkmcnt(7)                                       // 000000145264: BF89FC77
	v_fma_mixlo_f16 v103, v105, s18, 0                         // 000000145268: CC210067 02002569
	v_fma_mixhi_f16 v103, v106, s18, 0                         // 000000145270: CC220067 0200256A
	s_waitcnt lgkmcnt(6)                                       // 000000145278: BF89FC67
	v_fma_mixlo_f16 v105, v109, s18, 0                         // 00000014527C: CC210069 0200256D
	ds_load_b128 v[63:66], v78 offset:16992                    // 000000145284: DBFC4260 3F00004E
	v_fma_mixhi_f16 v105, v110, s18, 0                         // 00000014528C: CC220069 0200256E
	v_fma_mixlo_f16 v106, v111, s18, 0                         // 000000145294: CC21006A 0200256F
	v_fma_mixhi_f16 v106, v112, s18, 0                         // 00000014529C: CC22006A 02002570
	s_waitcnt lgkmcnt(2)                                       // 0000001452A4: BF89FC27
	v_fma_mixlo_f16 v109, v35, s18, 0                          // 0000001452A8: CC21006D 02002523
	v_fma_mixhi_f16 v109, v36, s18, 0                          // 0000001452B0: CC22006D 02002524
	v_fma_mixlo_f16 v110, v37, s18, 0                          // 0000001452B8: CC21006E 02002525
	v_fma_mixhi_f16 v110, v38, s18, 0                          // 0000001452C0: CC22006E 02002526
	s_waitcnt lgkmcnt(1)                                       // 0000001452C8: BF89FC17
	v_fma_mixlo_f16 v111, v47, s18, 0                          // 0000001452CC: CC21006F 0200252F
	v_fma_mixhi_f16 v111, v48, s18, 0                          // 0000001452D4: CC22006F 02002530
	ds_load_b128 v[35:38], v78 offset:25440                    // 0000001452DC: DBFC6360 2300004E
	v_fma_mixlo_f16 v112, v49, s18, 0                          // 0000001452E4: CC210070 02002531
	v_fma_mixhi_f16 v112, v50, s18, 0                          // 0000001452EC: CC220070 02002532
	ds_load_b128 v[47:50], v78 offset:25456                    // 0000001452F4: DBFC6370 2F00004E
	v_fma_mixhi_f16 v102, v104, s18, 0                         // 0000001452FC: CC220066 02002568
	v_fma_mixlo_f16 v104, v107, s18, 0                         // 000000145304: CC210068 0200256B
	v_fma_mixhi_f16 v104, v108, s18, 0                         // 00000014530C: CC220068 0200256C
	v_fma_mixlo_f16 v107, v113, s18, 0                         // 000000145314: CC21006B 02002571
	v_fma_mixhi_f16 v107, v114, s18, 0                         // 00000014531C: CC22006B 02002572
	v_fma_mixlo_f16 v108, v115, s18, 0                         // 000000145324: CC21006C 02002573
	v_fma_mixhi_f16 v108, v116, s18, 0                         // 00000014532C: CC22006C 02002574
	s_waitcnt lgkmcnt(2)                                       // 000000145334: BF89FC27
	v_fma_mixlo_f16 v113, v63, s18, 0                          // 000000145338: CC210071 0200253F
	v_fma_mixhi_f16 v113, v64, s18, 0                          // 000000145340: CC220071 02002540
	v_fma_mixlo_f16 v114, v65, s18, 0                          // 000000145348: CC210072 02002541
	v_fma_mixhi_f16 v114, v66, s18, 0                          // 000000145350: CC220072 02002542
	v_fma_mixlo_f16 v115, v117, s18, 0                         // 000000145358: CC210073 02002575
	v_fma_mixhi_f16 v115, v118, s18, 0                         // 000000145360: CC220073 02002576
	v_fma_mixlo_f16 v116, v119, s18, 0                         // 000000145368: CC210074 02002577
	v_fma_mixhi_f16 v116, v120, s18, 0                         // 000000145370: CC220074 02002578
	v_fma_mixlo_f16 v117, v121, s18, 0                         // 000000145378: CC210075 02002579
	v_fma_mixhi_f16 v117, v122, s18, 0                         // 000000145380: CC220075 0200257A
	v_fma_mixlo_f16 v118, v123, s18, 0                         // 000000145388: CC210076 0200257B
	v_fma_mixhi_f16 v118, v124, s18, 0                         // 000000145390: CC220076 0200257C
	v_fma_mixlo_f16 v119, v125, s18, 0                         // 000000145398: CC210077 0200257D
	v_fma_mixhi_f16 v119, v126, s18, 0                         // 0000001453A0: CC220077 0200257E
	v_fma_mixlo_f16 v120, v127, s18, 0                         // 0000001453A8: CC210078 0200257F
	v_fma_mixhi_f16 v120, v128, s18, 0                         // 0000001453B0: CC220078 02002580
	s_waitcnt lgkmcnt(1)                                       // 0000001453B8: BF89FC17
	v_fma_mixlo_f16 v121, v35, s18, 0                          // 0000001453BC: CC210079 02002523
	v_fma_mixhi_f16 v121, v36, s18, 0                          // 0000001453C4: CC220079 02002524
	v_fma_mixlo_f16 v122, v37, s18, 0                          // 0000001453CC: CC21007A 02002525
	v_fma_mixhi_f16 v122, v38, s18, 0                          // 0000001453D4: CC22007A 02002526
	s_waitcnt lgkmcnt(0)                                       // 0000001453DC: BF89FC07
	v_fma_mixlo_f16 v123, v47, s18, 0                          // 0000001453E0: CC21007B 0200252F
	v_fma_mixhi_f16 v123, v48, s18, 0                          // 0000001453E8: CC22007B 02002530
	v_fma_mixlo_f16 v124, v49, s18, 0                          // 0000001453F0: CC21007C 02002531
	v_fma_mixhi_f16 v124, v50, s18, 0                          // 0000001453F8: CC22007C 02002532
	.long 0x7f4c3880                                           // 000000145400: 7F4C3880
	v_wmma_f32_16x16x16_f16 v[27:34], v[39:46], v[55:62], v[27:34]// 000000145404: CC40401B 1C6E6F27
	v_wmma_f32_16x16x16_f16 v[19:26], v[39:46], v[101:108], v[19:26]// 00000014540C: CC404013 1C4ECB27
	v_wmma_f32_16x16x16_f16 v[11:18], v[39:46], v[109:116], v[11:18]// 000000145414: CC40400B 1C2EDB27
	v_wmma_f32_16x16x16_f16 v[3:10], v[39:46], v[117:124], v[3:10]// 00000014541C: CC404003 1C0EEB27
	.long 0x7f4839a6                                           // 000000145424: 7F4839A6
	.long 0x7e4839a6                                           // 000000145428: 7E4839A6
	.long 0x7f4639a6                                           // 00000014542C: 7F4639A6
	.long 0x7e4639a6                                           // 000000145430: 7E4639A6
	s_and_saveexec_b32 s11, s10                                // 000000145434: BE8B200A
	s_cbranch_execz 11                                         // 000000145438: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1868>
	global_load_b128 v[39:42], v[53:54], off offset:128        // 00000014543C: DC5E0080 277C0035
	s_waitcnt vmcnt(0)                                         // 000000145444: BF8903F7
	v_fma_mixlo_f16 v35, v39, s18, 0                           // 000000145448: CC210023 02002527
	v_fma_mixhi_f16 v35, v40, s18, 0                           // 000000145450: CC220023 02002528
	v_fma_mixlo_f16 v36, v41, s18, 0                           // 000000145458: CC210024 02002529
	v_fma_mixhi_f16 v36, v42, s18, 0                           // 000000145460: CC220024 0200252A
	s_or_b32 exec_lo, exec_lo, s11                             // 000000145468: 8C7E0B7E
	.long 0x7e4c39a6                                           // 00000014546C: 7E4C39A6
	.long 0x7f4a39a6                                           // 000000145470: 7F4A39A6
	.long 0x7e4a39a6                                           // 000000145474: 7E4A39A6
	s_and_saveexec_b32 s11, s10                                // 000000145478: BE8B200A
	s_cbranch_execz 11                                         // 00000014547C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18ac>
	global_load_b128 v[37:40], v[53:54], off offset:144        // 000000145480: DC5E0090 257C0035
	s_waitcnt vmcnt(0)                                         // 000000145488: BF8903F7
	v_fma_mixlo_f16 v37, v37, s18, 0                           // 00000014548C: CC210025 02002525
	v_fma_mixhi_f16 v37, v38, s18, 0                           // 000000145494: CC220025 02002526
	v_fma_mixlo_f16 v38, v39, s18, 0                           // 00000014549C: CC210026 02002527
	v_fma_mixhi_f16 v38, v40, s18, 0                           // 0000001454A4: CC220026 02002528
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001454AC: 8C7E0B7E
	.long 0x7f543880                                           // 0000001454B0: 7F543880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001454B4: BF870001
	.long 0x7f5039aa                                           // 0000001454B8: 7F5039AA
	.long 0x7e5039aa                                           // 0000001454BC: 7E5039AA
	.long 0x7f4e39aa                                           // 0000001454C0: 7F4E39AA
	.long 0x7e4e39aa                                           // 0000001454C4: 7E4E39AA
	s_and_saveexec_b32 s11, s10                                // 0000001454C8: BE8B200A
	s_cbranch_execz 11                                         // 0000001454CC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18fc>
	global_load_b128 v[43:46], v[53:54], off offset:160        // 0000001454D0: DC5E00A0 2B7C0035
	s_waitcnt vmcnt(0)                                         // 0000001454D8: BF8903F7
	v_fma_mixlo_f16 v39, v43, s18, 0                           // 0000001454DC: CC210027 0200252B
	v_fma_mixhi_f16 v39, v44, s18, 0                           // 0000001454E4: CC220027 0200252C
	v_fma_mixlo_f16 v40, v45, s18, 0                           // 0000001454EC: CC210028 0200252D
	v_fma_mixhi_f16 v40, v46, s18, 0                           // 0000001454F4: CC220028 0200252E
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001454FC: 8C7E0B7E
	.long 0x7e5439aa                                           // 000000145500: 7E5439AA
	.long 0x7f5239aa                                           // 000000145504: 7F5239AA
	.long 0x7e5239aa                                           // 000000145508: 7E5239AA
	s_and_saveexec_b32 s11, s10                                // 00000014550C: BE8B200A
	s_cbranch_execz 11                                         // 000000145510: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	global_load_b128 v[41:44], v[53:54], off offset:176        // 000000145514: DC5E00B0 297C0035
	s_waitcnt vmcnt(0)                                         // 00000014551C: BF8903F7
	v_fma_mixlo_f16 v41, v41, s18, 0                           // 000000145520: CC210029 02002529
	v_fma_mixhi_f16 v41, v42, s18, 0                           // 000000145528: CC220029 0200252A
	v_fma_mixlo_f16 v42, v43, s18, 0                           // 000000145530: CC21002A 0200252B
	v_fma_mixhi_f16 v42, v44, s18, 0                           // 000000145538: CC22002A 0200252C
	s_or_b32 exec_lo, exec_lo, s11                             // 000000145540: 8C7E0B7E
	ds_load_b128 v[44:47], v78 offset:128                      // 000000145544: DBFC0080 2C00004E
	ds_load_b128 v[48:51], v78 offset:144                      // 00000014554C: DBFC0090 3000004E
	ds_load_b128 v[55:58], v78 offset:160                      // 000000145554: DBFC00A0 3700004E
	ds_load_b128 v[59:62], v78 offset:176                      // 00000014555C: DBFC00B0 3B00004E
	ds_load_b128 v[63:66], v78 offset:8576                     // 000000145564: DBFC2180 3F00004E
	ds_load_b128 v[101:104], v78 offset:8592                   // 00000014556C: DBFC2190 6500004E
	ds_load_b128 v[105:108], v78 offset:8608                   // 000000145574: DBFC21A0 6900004E
	ds_load_b128 v[109:112], v78 offset:8624                   // 00000014557C: DBFC21B0 6D00004E
	ds_load_b128 v[113:116], v78 offset:17024                  // 000000145584: DBFC4280 7100004E
	ds_load_b128 v[117:120], v78 offset:17056                  // 00000014558C: DBFC42A0 7500004E
	ds_load_b128 v[121:124], v78 offset:17072                  // 000000145594: DBFC42B0 7900004E
	.long 0x7f563880                                           // 00000014559C: 7F563880
	ds_load_b128 v[125:128], v78 offset:25488                  // 0000001455A0: DBFC6390 7D00004E
	s_waitcnt lgkmcnt(11)                                      // 0000001455A8: BF89FCB7
	v_fma_mixlo_f16 v44, v44, s18, 0                           // 0000001455AC: CC21002C 0200252C
	v_fma_mixhi_f16 v44, v45, s18, 0                           // 0000001455B4: CC22002C 0200252D
	v_fma_mixlo_f16 v45, v46, s18, 0                           // 0000001455BC: CC21002D 0200252E
	s_waitcnt lgkmcnt(10)                                      // 0000001455C4: BF89FCA7
	v_fma_mixlo_f16 v46, v48, s18, 0                           // 0000001455C8: CC21002E 02002530
	s_waitcnt lgkmcnt(9)                                       // 0000001455D0: BF89FC97
	v_fma_mixlo_f16 v48, v55, s18, 0                           // 0000001455D4: CC210030 02002537
	v_fma_mixhi_f16 v48, v56, s18, 0                           // 0000001455DC: CC220030 02002538
	s_waitcnt lgkmcnt(7)                                       // 0000001455E4: BF89FC77
	v_fma_mixlo_f16 v55, v63, s18, 0                           // 0000001455E8: CC210037 0200253F
	v_fma_mixhi_f16 v55, v64, s18, 0                           // 0000001455F0: CC220037 02002540
	v_fma_mixlo_f16 v56, v65, s18, 0                           // 0000001455F8: CC210038 02002541
	v_fma_mixhi_f16 v56, v66, s18, 0                           // 000000145600: CC220038 02002542
	ds_load_b128 v[63:66], v78 offset:17040                    // 000000145608: DBFC4290 3F00004E
	v_fma_mixhi_f16 v45, v47, s18, 0                           // 000000145610: CC22002D 0200252F
	v_fma_mixhi_f16 v46, v49, s18, 0                           // 000000145618: CC22002E 02002531
	v_fma_mixhi_f16 v47, v51, s18, 0                           // 000000145620: CC22002F 02002533
	v_fma_mixlo_f16 v49, v57, s18, 0                           // 000000145628: CC210031 02002539
	v_fma_mixhi_f16 v49, v58, s18, 0                           // 000000145630: CC220031 0200253A
	v_fma_mixlo_f16 v51, v61, s18, 0                           // 000000145638: CC210033 0200253D
	v_fma_mixhi_f16 v51, v62, s18, 0                           // 000000145640: CC220033 0200253E
	s_waitcnt lgkmcnt(7)                                       // 000000145648: BF89FC77
	v_fma_mixlo_f16 v57, v101, s18, 0                          // 00000014564C: CC210039 02002565
	v_fma_mixhi_f16 v57, v102, s18, 0                          // 000000145654: CC220039 02002566
	v_fma_mixlo_f16 v58, v103, s18, 0                          // 00000014565C: CC21003A 02002567
	v_fma_mixhi_f16 v58, v104, s18, 0                          // 000000145664: CC22003A 02002568
	s_waitcnt lgkmcnt(5)                                       // 00000014566C: BF89FC57
	v_fma_mixlo_f16 v61, v109, s18, 0                          // 000000145670: CC21003D 0200256D
	v_fma_mixhi_f16 v61, v110, s18, 0                          // 000000145678: CC22003D 0200256E
	v_fma_mixlo_f16 v62, v111, s18, 0                          // 000000145680: CC21003E 0200256F
	v_fma_mixhi_f16 v62, v112, s18, 0                          // 000000145688: CC22003E 02002570
	ds_load_b128 v[109:112], v78 offset:25472                  // 000000145690: DBFC6380 6D00004E
	s_waitcnt lgkmcnt(5)                                       // 000000145698: BF89FC57
	v_fma_mixlo_f16 v101, v113, s18, 0                         // 00000014569C: CC210065 02002571
	v_fma_mixhi_f16 v101, v114, s18, 0                         // 0000001456A4: CC220065 02002572
	v_fma_mixlo_f16 v102, v115, s18, 0                         // 0000001456AC: CC210066 02002573
	v_fma_mixhi_f16 v102, v116, s18, 0                         // 0000001456B4: CC220066 02002574
	s_waitcnt lgkmcnt(1)                                       // 0000001456BC: BF89FC17
	v_fma_mixlo_f16 v103, v63, s18, 0                          // 0000001456C0: CC210067 0200253F
	v_fma_mixhi_f16 v103, v64, s18, 0                          // 0000001456C8: CC220067 02002540
	ds_load_b128 v[113:116], v78 offset:25504                  // 0000001456D0: DBFC63A0 7100004E
	v_fma_mixlo_f16 v104, v65, s18, 0                          // 0000001456D8: CC210068 02002541
	v_fma_mixhi_f16 v104, v66, s18, 0                          // 0000001456E0: CC220068 02002542
	ds_load_b128 v[63:66], v78 offset:25520                    // 0000001456E8: DBFC63B0 3F00004E
	v_fma_mixlo_f16 v47, v50, s18, 0                           // 0000001456F0: CC21002F 02002532
	v_fma_mixlo_f16 v50, v59, s18, 0                           // 0000001456F8: CC210032 0200253B
	v_fma_mixhi_f16 v50, v60, s18, 0                           // 000000145700: CC220032 0200253C
	v_fma_mixlo_f16 v59, v105, s18, 0                          // 000000145708: CC21003B 02002569
	v_fma_mixhi_f16 v59, v106, s18, 0                          // 000000145710: CC22003B 0200256A
	v_fma_mixlo_f16 v60, v107, s18, 0                          // 000000145718: CC21003C 0200256B
	v_fma_mixhi_f16 v60, v108, s18, 0                          // 000000145720: CC22003C 0200256C
	v_fma_mixlo_f16 v105, v117, s18, 0                         // 000000145728: CC210069 02002575
	v_fma_mixhi_f16 v105, v118, s18, 0                         // 000000145730: CC220069 02002576
	v_fma_mixlo_f16 v106, v119, s18, 0                         // 000000145738: CC21006A 02002577
	v_fma_mixhi_f16 v106, v120, s18, 0                         // 000000145740: CC22006A 02002578
	v_fma_mixlo_f16 v107, v121, s18, 0                         // 000000145748: CC21006B 02002579
	v_fma_mixhi_f16 v107, v122, s18, 0                         // 000000145750: CC22006B 0200257A
	v_fma_mixlo_f16 v108, v123, s18, 0                         // 000000145758: CC21006C 0200257B
	v_fma_mixhi_f16 v108, v124, s18, 0                         // 000000145760: CC22006C 0200257C
	s_waitcnt lgkmcnt(2)                                       // 000000145768: BF89FC27
	v_fma_mixlo_f16 v109, v109, s18, 0                         // 00000014576C: CC21006D 0200256D
	v_fma_mixhi_f16 v109, v110, s18, 0                         // 000000145774: CC22006D 0200256E
	v_fma_mixlo_f16 v110, v111, s18, 0                         // 00000014577C: CC21006E 0200256F
	v_fma_mixhi_f16 v110, v112, s18, 0                         // 000000145784: CC22006E 02002570
	v_fma_mixlo_f16 v111, v125, s18, 0                         // 00000014578C: CC21006F 0200257D
	v_fma_mixhi_f16 v111, v126, s18, 0                         // 000000145794: CC22006F 0200257E
	v_fma_mixlo_f16 v112, v127, s18, 0                         // 00000014579C: CC210070 0200257F
	v_fma_mixhi_f16 v112, v128, s18, 0                         // 0000001457A4: CC220070 02002580
	s_waitcnt lgkmcnt(1)                                       // 0000001457AC: BF89FC17
	v_fma_mixlo_f16 v113, v113, s18, 0                         // 0000001457B0: CC210071 02002571
	v_fma_mixhi_f16 v113, v114, s18, 0                         // 0000001457B8: CC220071 02002572
	v_fma_mixlo_f16 v114, v115, s18, 0                         // 0000001457C0: CC210072 02002573
	v_fma_mixhi_f16 v114, v116, s18, 0                         // 0000001457C8: CC220072 02002574
	s_waitcnt lgkmcnt(0)                                       // 0000001457D0: BF89FC07
	v_fma_mixlo_f16 v115, v63, s18, 0                          // 0000001457D4: CC210073 0200253F
	v_fma_mixhi_f16 v115, v64, s18, 0                          // 0000001457DC: CC220073 02002540
	v_fma_mixlo_f16 v116, v65, s18, 0                          // 0000001457E4: CC210074 02002541
	v_fma_mixhi_f16 v116, v66, s18, 0                          // 0000001457EC: CC220074 02002542
	v_wmma_f32_16x16x16_f16 v[27:34], v[35:42], v[44:51], v[27:34]// 0000001457F4: CC40401B 1C6E5923
	v_wmma_f32_16x16x16_f16 v[19:26], v[35:42], v[55:62], v[19:26]// 0000001457FC: CC404013 1C4E6F23
	v_wmma_f32_16x16x16_f16 v[11:18], v[35:42], v[101:108], v[11:18]// 000000145804: CC40400B 1C2ECB23
	s_delay_alu instid0(VALU_DEP_4)                            // 00000014580C: BF870004
	v_wmma_f32_16x16x16_f16 v[3:10], v[35:42], v[109:116], v[3:10]// 000000145810: CC404003 1C0EDB23
	.long 0x7f5239ab                                           // 000000145818: 7F5239AB
	.long 0x7e5239ab                                           // 00000014581C: 7E5239AB
	.long 0x7f5039ab                                           // 000000145820: 7F5039AB
	.long 0x7e5039ab                                           // 000000145824: 7E5039AB
	s_and_saveexec_b32 s11, s10                                // 000000145828: BE8B200A
	s_cbranch_execz 11                                         // 00000014582C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c5c>
	global_load_b128 v[35:38], v[53:54], off offset:192        // 000000145830: DC5E00C0 237C0035
	s_waitcnt vmcnt(0)                                         // 000000145838: BF8903F7
	v_fma_mixlo_f16 v40, v35, s18, 0                           // 00000014583C: CC210028 02002523
	v_fma_mixhi_f16 v40, v36, s18, 0                           // 000000145844: CC220028 02002524
	v_fma_mixlo_f16 v41, v37, s18, 0                           // 00000014584C: CC210029 02002525
	v_fma_mixhi_f16 v41, v38, s18, 0                           // 000000145854: CC220029 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 00000014585C: 8C7E0B7E
	.long 0x7e5639ab                                           // 000000145860: 7E5639AB
	.long 0x7f5439ab                                           // 000000145864: 7F5439AB
	.long 0x7e5439ab                                           // 000000145868: 7E5439AB
	s_and_saveexec_b32 s11, s10                                // 00000014586C: BE8B200A
	s_cbranch_execz 11                                         // 000000145870: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ca0>
	global_load_b128 v[35:38], v[53:54], off offset:208        // 000000145874: DC5E00D0 237C0035
	s_waitcnt vmcnt(0)                                         // 00000014587C: BF8903F7
	v_fma_mixlo_f16 v42, v35, s18, 0                           // 000000145880: CC21002A 02002523
	v_fma_mixhi_f16 v42, v36, s18, 0                           // 000000145888: CC22002A 02002524
	v_fma_mixlo_f16 v43, v37, s18, 0                           // 000000145890: CC21002B 02002525
	v_fma_mixhi_f16 v43, v38, s18, 0                           // 000000145898: CC22002B 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001458A0: 8C7E0B7E
	.long 0x7f5e3880                                           // 0000001458A4: 7F5E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001458A8: BF870001
	.long 0x7f5a39af                                           // 0000001458AC: 7F5A39AF
	.long 0x7e5a39af                                           // 0000001458B0: 7E5A39AF
	.long 0x7f5839af                                           // 0000001458B4: 7F5839AF
	.long 0x7e5839af                                           // 0000001458B8: 7E5839AF
	s_and_saveexec_b32 s11, s10                                // 0000001458BC: BE8B200A
	s_cbranch_execz 11                                         // 0000001458C0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cf0>
	global_load_b128 v[35:38], v[53:54], off offset:224        // 0000001458C4: DC5E00E0 237C0035
	s_waitcnt vmcnt(0)                                         // 0000001458CC: BF8903F7
	v_fma_mixlo_f16 v44, v35, s18, 0                           // 0000001458D0: CC21002C 02002523
	v_fma_mixhi_f16 v44, v36, s18, 0                           // 0000001458D8: CC22002C 02002524
	v_fma_mixlo_f16 v45, v37, s18, 0                           // 0000001458E0: CC21002D 02002525
	v_fma_mixhi_f16 v45, v38, s18, 0                           // 0000001458E8: CC22002D 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001458F0: 8C7E0B7E
	.long 0x7e5e39af                                           // 0000001458F4: 7E5E39AF
	.long 0x7f5c39af                                           // 0000001458F8: 7F5C39AF
	.long 0x7e5c39af                                           // 0000001458FC: 7E5C39AF
	s_and_saveexec_b32 s11, s10                                // 000000145900: BE8B200A
	s_cbranch_execz 11                                         // 000000145904: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d34>
	global_load_b128 v[35:38], v[53:54], off offset:240        // 000000145908: DC5E00F0 237C0035
	s_waitcnt vmcnt(0)                                         // 000000145910: BF8903F7
	v_fma_mixlo_f16 v46, v35, s18, 0                           // 000000145914: CC21002E 02002523
	v_fma_mixhi_f16 v46, v36, s18, 0                           // 00000014591C: CC22002E 02002524
	v_fma_mixlo_f16 v47, v37, s18, 0                           // 000000145924: CC21002F 02002525
	v_fma_mixhi_f16 v47, v38, s18, 0                           // 00000014592C: CC22002F 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 000000145934: 8C7E0B7E
	ds_load_b128 v[35:38], v78 offset:192                      // 000000145938: DBFC00C0 2300004E
	ds_load_b128 v[48:51], v78 offset:208                      // 000000145940: DBFC00D0 3000004E
	ds_load_b128 v[59:62], v78 offset:224                      // 000000145948: DBFC00E0 3B00004E
	ds_load_b128 v[63:66], v78 offset:240                      // 000000145950: DBFC00F0 3F00004E
	ds_load_b128 v[101:104], v78 offset:8640                   // 000000145958: DBFC21C0 6500004E
	ds_load_b128 v[105:108], v78 offset:8656                   // 000000145960: DBFC21D0 6900004E
	ds_load_b128 v[109:112], v78 offset:8672                   // 000000145968: DBFC21E0 6D00004E
	ds_load_b128 v[113:116], v78 offset:8688                   // 000000145970: DBFC21F0 7100004E
	ds_load_b128 v[121:124], v78 offset:25536                  // 000000145978: DBFC63C0 7900004E
	ds_load_b128 v[125:128], v78 offset:25552                  // 000000145980: DBFC63D0 7D00004E
	ds_load_b128 v[117:120], v78 offset:17136                  // 000000145988: DBFC42F0 7500004E
	s_waitcnt lgkmcnt(10)                                      // 000000145990: BF89FCA7
	v_fma_mixlo_f16 v55, v35, s18, 0                           // 000000145994: CC210037 02002523
	v_fma_mixhi_f16 v55, v36, s18, 0                           // 00000014599C: CC220037 02002524
	v_fma_mixlo_f16 v56, v37, s18, 0                           // 0000001459A4: CC210038 02002525
	v_fma_mixhi_f16 v56, v38, s18, 0                           // 0000001459AC: CC220038 02002526
	s_waitcnt lgkmcnt(9)                                       // 0000001459B4: BF89FC97
	v_fma_mixlo_f16 v57, v48, s18, 0                           // 0000001459B8: CC210039 02002530
	v_fma_mixhi_f16 v57, v49, s18, 0                           // 0000001459C0: CC220039 02002531
	v_fma_mixlo_f16 v58, v50, s18, 0                           // 0000001459C8: CC21003A 02002532
	v_fma_mixhi_f16 v58, v51, s18, 0                           // 0000001459D0: CC22003A 02002533
	ds_load_b128 v[35:38], v78 offset:17088                    // 0000001459D8: DBFC42C0 2300004E
	ds_load_b128 v[48:51], v78 offset:17104                    // 0000001459E0: DBFC42D0 3000004E
	s_waitcnt lgkmcnt(10)                                      // 0000001459E8: BF89FCA7
	v_fma_mixlo_f16 v59, v59, s18, 0                           // 0000001459EC: CC21003B 0200253B
	v_fma_mixhi_f16 v59, v60, s18, 0                           // 0000001459F4: CC22003B 0200253C
	v_fma_mixlo_f16 v60, v61, s18, 0                           // 0000001459FC: CC21003C 0200253D
	v_fma_mixhi_f16 v60, v62, s18, 0                           // 000000145A04: CC22003C 0200253E
	s_waitcnt lgkmcnt(9)                                       // 000000145A0C: BF89FC97
	v_fma_mixlo_f16 v61, v63, s18, 0                           // 000000145A10: CC21003D 0200253F
	v_fma_mixhi_f16 v61, v64, s18, 0                           // 000000145A18: CC22003D 02002540
	v_fma_mixlo_f16 v62, v65, s18, 0                           // 000000145A20: CC21003E 02002541
	v_fma_mixhi_f16 v62, v66, s18, 0                           // 000000145A28: CC22003E 02002542
	s_waitcnt lgkmcnt(8)                                       // 000000145A30: BF89FC87
	v_fma_mixlo_f16 v101, v101, s18, 0                         // 000000145A34: CC210065 02002565
	v_fma_mixhi_f16 v101, v102, s18, 0                         // 000000145A3C: CC220065 02002566
	v_fma_mixlo_f16 v102, v103, s18, 0                         // 000000145A44: CC210066 02002567
	s_waitcnt lgkmcnt(7)                                       // 000000145A4C: BF89FC77
	v_fma_mixlo_f16 v103, v105, s18, 0                         // 000000145A50: CC210067 02002569
	v_fma_mixhi_f16 v103, v106, s18, 0                         // 000000145A58: CC220067 0200256A
	s_waitcnt lgkmcnt(6)                                       // 000000145A60: BF89FC67
	v_fma_mixlo_f16 v105, v109, s18, 0                         // 000000145A64: CC210069 0200256D
	ds_load_b128 v[63:66], v78 offset:17120                    // 000000145A6C: DBFC42E0 3F00004E
	v_fma_mixhi_f16 v105, v110, s18, 0                         // 000000145A74: CC220069 0200256E
	v_fma_mixlo_f16 v106, v111, s18, 0                         // 000000145A7C: CC21006A 0200256F
	v_fma_mixhi_f16 v106, v112, s18, 0                         // 000000145A84: CC22006A 02002570
	s_waitcnt lgkmcnt(2)                                       // 000000145A8C: BF89FC27
	v_fma_mixlo_f16 v109, v35, s18, 0                          // 000000145A90: CC21006D 02002523
	v_fma_mixhi_f16 v109, v36, s18, 0                          // 000000145A98: CC22006D 02002524
	v_fma_mixlo_f16 v110, v37, s18, 0                          // 000000145AA0: CC21006E 02002525
	v_fma_mixhi_f16 v110, v38, s18, 0                          // 000000145AA8: CC22006E 02002526
	s_waitcnt lgkmcnt(1)                                       // 000000145AB0: BF89FC17
	v_fma_mixlo_f16 v111, v48, s18, 0                          // 000000145AB4: CC21006F 02002530
	v_fma_mixhi_f16 v111, v49, s18, 0                          // 000000145ABC: CC22006F 02002531
	ds_load_b128 v[35:38], v78 offset:25568                    // 000000145AC4: DBFC63E0 2300004E
	v_fma_mixlo_f16 v112, v50, s18, 0                          // 000000145ACC: CC210070 02002532
	v_fma_mixhi_f16 v112, v51, s18, 0                          // 000000145AD4: CC220070 02002533
	ds_load_b128 v[48:51], v78 offset:25584                    // 000000145ADC: DBFC63F0 3000004E
	v_fma_mixhi_f16 v102, v104, s18, 0                         // 000000145AE4: CC220066 02002568
	v_fma_mixlo_f16 v104, v107, s18, 0                         // 000000145AEC: CC210068 0200256B
	v_fma_mixhi_f16 v104, v108, s18, 0                         // 000000145AF4: CC220068 0200256C
	v_fma_mixlo_f16 v107, v113, s18, 0                         // 000000145AFC: CC21006B 02002571
	v_fma_mixhi_f16 v107, v114, s18, 0                         // 000000145B04: CC22006B 02002572
	v_fma_mixlo_f16 v108, v115, s18, 0                         // 000000145B0C: CC21006C 02002573
	v_fma_mixhi_f16 v108, v116, s18, 0                         // 000000145B14: CC22006C 02002574
	s_waitcnt lgkmcnt(2)                                       // 000000145B1C: BF89FC27
	v_fma_mixlo_f16 v113, v63, s18, 0                          // 000000145B20: CC210071 0200253F
	v_fma_mixhi_f16 v113, v64, s18, 0                          // 000000145B28: CC220071 02002540
	v_fma_mixlo_f16 v114, v65, s18, 0                          // 000000145B30: CC210072 02002541
	v_fma_mixhi_f16 v114, v66, s18, 0                          // 000000145B38: CC220072 02002542
	v_fma_mixlo_f16 v115, v117, s18, 0                         // 000000145B40: CC210073 02002575
	v_fma_mixhi_f16 v115, v118, s18, 0                         // 000000145B48: CC220073 02002576
	v_fma_mixlo_f16 v116, v119, s18, 0                         // 000000145B50: CC210074 02002577
	v_fma_mixhi_f16 v116, v120, s18, 0                         // 000000145B58: CC220074 02002578
	v_fma_mixlo_f16 v117, v121, s18, 0                         // 000000145B60: CC210075 02002579
	v_fma_mixhi_f16 v117, v122, s18, 0                         // 000000145B68: CC220075 0200257A
	v_fma_mixlo_f16 v118, v123, s18, 0                         // 000000145B70: CC210076 0200257B
	v_fma_mixhi_f16 v118, v124, s18, 0                         // 000000145B78: CC220076 0200257C
	v_fma_mixlo_f16 v119, v125, s18, 0                         // 000000145B80: CC210077 0200257D
	v_fma_mixhi_f16 v119, v126, s18, 0                         // 000000145B88: CC220077 0200257E
	v_fma_mixlo_f16 v120, v127, s18, 0                         // 000000145B90: CC210078 0200257F
	v_fma_mixhi_f16 v120, v128, s18, 0                         // 000000145B98: CC220078 02002580
	s_waitcnt lgkmcnt(1)                                       // 000000145BA0: BF89FC17
	v_fma_mixlo_f16 v121, v35, s18, 0                          // 000000145BA4: CC210079 02002523
	v_fma_mixhi_f16 v121, v36, s18, 0                          // 000000145BAC: CC220079 02002524
	v_fma_mixlo_f16 v122, v37, s18, 0                          // 000000145BB4: CC21007A 02002525
	v_fma_mixhi_f16 v122, v38, s18, 0                          // 000000145BBC: CC22007A 02002526
	s_waitcnt lgkmcnt(0)                                       // 000000145BC4: BF89FC07
	v_fma_mixlo_f16 v123, v48, s18, 0                          // 000000145BC8: CC21007B 02002530
	v_fma_mixhi_f16 v123, v49, s18, 0                          // 000000145BD0: CC22007B 02002531
	v_fma_mixlo_f16 v124, v50, s18, 0                          // 000000145BD8: CC21007C 02002532
	v_fma_mixhi_f16 v124, v51, s18, 0                          // 000000145BE0: CC22007C 02002533
	.long 0x7f4c3880                                           // 000000145BE8: 7F4C3880
	v_wmma_f32_16x16x16_f16 v[27:34], v[40:47], v[55:62], v[27:34]// 000000145BEC: CC40401B 1C6E6F28
	v_wmma_f32_16x16x16_f16 v[19:26], v[40:47], v[101:108], v[19:26]// 000000145BF4: CC404013 1C4ECB28
	v_wmma_f32_16x16x16_f16 v[11:18], v[40:47], v[109:116], v[11:18]// 000000145BFC: CC40400B 1C2EDB28
	v_wmma_f32_16x16x16_f16 v[3:10], v[40:47], v[117:124], v[3:10]// 000000145C04: CC404003 1C0EEB28
	.long 0x7f4839a6                                           // 000000145C0C: 7F4839A6
	.long 0x7e4839a6                                           // 000000145C10: 7E4839A6
	.long 0x7f4639a6                                           // 000000145C14: 7F4639A6
	.long 0x7e4639a6                                           // 000000145C18: 7E4639A6
	s_and_saveexec_b32 s11, s10                                // 000000145C1C: BE8B200A
	s_cbranch_execz 11                                         // 000000145C20: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2050>
	global_load_b128 v[39:42], v[53:54], off offset:256        // 000000145C24: DC5E0100 277C0035
	s_waitcnt vmcnt(0)                                         // 000000145C2C: BF8903F7
	v_fma_mixlo_f16 v35, v39, s18, 0                           // 000000145C30: CC210023 02002527
	v_fma_mixhi_f16 v35, v40, s18, 0                           // 000000145C38: CC220023 02002528
	v_fma_mixlo_f16 v36, v41, s18, 0                           // 000000145C40: CC210024 02002529
	v_fma_mixhi_f16 v36, v42, s18, 0                           // 000000145C48: CC220024 0200252A
	s_or_b32 exec_lo, exec_lo, s11                             // 000000145C50: 8C7E0B7E
	.long 0x7e4c39a6                                           // 000000145C54: 7E4C39A6
	.long 0x7f4a39a6                                           // 000000145C58: 7F4A39A6
	.long 0x7e4a39a6                                           // 000000145C5C: 7E4A39A6
	s_and_saveexec_b32 s11, s10                                // 000000145C60: BE8B200A
	s_cbranch_execz 11                                         // 000000145C64: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2094>
	global_load_b128 v[37:40], v[53:54], off offset:272        // 000000145C68: DC5E0110 257C0035
	s_waitcnt vmcnt(0)                                         // 000000145C70: BF8903F7
	v_fma_mixlo_f16 v37, v37, s18, 0                           // 000000145C74: CC210025 02002525
	v_fma_mixhi_f16 v37, v38, s18, 0                           // 000000145C7C: CC220025 02002526
	v_fma_mixlo_f16 v38, v39, s18, 0                           // 000000145C84: CC210026 02002527
	v_fma_mixhi_f16 v38, v40, s18, 0                           // 000000145C8C: CC220026 02002528
	s_or_b32 exec_lo, exec_lo, s11                             // 000000145C94: 8C7E0B7E
	.long 0x7f543880                                           // 000000145C98: 7F543880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000145C9C: BF870001
	.long 0x7f5039aa                                           // 000000145CA0: 7F5039AA
	.long 0x7e5039aa                                           // 000000145CA4: 7E5039AA
	.long 0x7f4e39aa                                           // 000000145CA8: 7F4E39AA
	.long 0x7e4e39aa                                           // 000000145CAC: 7E4E39AA
	s_and_saveexec_b32 s11, s10                                // 000000145CB0: BE8B200A
	s_cbranch_execz 11                                         // 000000145CB4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x20e4>
	global_load_b128 v[43:46], v[53:54], off offset:288        // 000000145CB8: DC5E0120 2B7C0035
	s_waitcnt vmcnt(0)                                         // 000000145CC0: BF8903F7
	v_fma_mixlo_f16 v39, v43, s18, 0                           // 000000145CC4: CC210027 0200252B
	v_fma_mixhi_f16 v39, v44, s18, 0                           // 000000145CCC: CC220027 0200252C
	v_fma_mixlo_f16 v40, v45, s18, 0                           // 000000145CD4: CC210028 0200252D
	v_fma_mixhi_f16 v40, v46, s18, 0                           // 000000145CDC: CC220028 0200252E
	s_or_b32 exec_lo, exec_lo, s11                             // 000000145CE4: 8C7E0B7E
	.long 0x7e5439aa                                           // 000000145CE8: 7E5439AA
	.long 0x7f5239aa                                           // 000000145CEC: 7F5239AA
	.long 0x7e5239aa                                           // 000000145CF0: 7E5239AA
	s_and_saveexec_b32 s11, s10                                // 000000145CF4: BE8B200A
	s_cbranch_execz 11                                         // 000000145CF8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2128>
	global_load_b128 v[41:44], v[53:54], off offset:304        // 000000145CFC: DC5E0130 297C0035
	s_waitcnt vmcnt(0)                                         // 000000145D04: BF8903F7
	v_fma_mixlo_f16 v41, v41, s18, 0                           // 000000145D08: CC210029 02002529
	v_fma_mixhi_f16 v41, v42, s18, 0                           // 000000145D10: CC220029 0200252A
	v_fma_mixlo_f16 v42, v43, s18, 0                           // 000000145D18: CC21002A 0200252B
	v_fma_mixhi_f16 v42, v44, s18, 0                           // 000000145D20: CC22002A 0200252C
	s_or_b32 exec_lo, exec_lo, s11                             // 000000145D28: 8C7E0B7E
	ds_load_b128 v[44:47], v78 offset:256                      // 000000145D2C: DBFC0100 2C00004E
	ds_load_b128 v[48:51], v78 offset:272                      // 000000145D34: DBFC0110 3000004E
	ds_load_b128 v[55:58], v78 offset:288                      // 000000145D3C: DBFC0120 3700004E
	ds_load_b128 v[59:62], v78 offset:304                      // 000000145D44: DBFC0130 3B00004E
	ds_load_b128 v[63:66], v78 offset:8704                     // 000000145D4C: DBFC2200 3F00004E
	ds_load_b128 v[101:104], v78 offset:8720                   // 000000145D54: DBFC2210 6500004E
	ds_load_b128 v[105:108], v78 offset:8736                   // 000000145D5C: DBFC2220 6900004E
	ds_load_b128 v[109:112], v78 offset:8752                   // 000000145D64: DBFC2230 6D00004E
	ds_load_b128 v[113:116], v78 offset:17152                  // 000000145D6C: DBFC4300 7100004E
	ds_load_b128 v[117:120], v78 offset:17184                  // 000000145D74: DBFC4320 7500004E
	ds_load_b128 v[121:124], v78 offset:17200                  // 000000145D7C: DBFC4330 7900004E
	.long 0x7f563880                                           // 000000145D84: 7F563880
	ds_load_b128 v[125:128], v78 offset:25616                  // 000000145D88: DBFC6410 7D00004E
	s_waitcnt lgkmcnt(11)                                      // 000000145D90: BF89FCB7
	v_fma_mixlo_f16 v44, v44, s18, 0                           // 000000145D94: CC21002C 0200252C
	v_fma_mixhi_f16 v44, v45, s18, 0                           // 000000145D9C: CC22002C 0200252D
	v_fma_mixlo_f16 v45, v46, s18, 0                           // 000000145DA4: CC21002D 0200252E
	s_waitcnt lgkmcnt(10)                                      // 000000145DAC: BF89FCA7
	v_fma_mixlo_f16 v46, v48, s18, 0                           // 000000145DB0: CC21002E 02002530
	s_waitcnt lgkmcnt(9)                                       // 000000145DB8: BF89FC97
	v_fma_mixlo_f16 v48, v55, s18, 0                           // 000000145DBC: CC210030 02002537
	v_fma_mixhi_f16 v48, v56, s18, 0                           // 000000145DC4: CC220030 02002538
	s_waitcnt lgkmcnt(7)                                       // 000000145DCC: BF89FC77
	v_fma_mixlo_f16 v55, v63, s18, 0                           // 000000145DD0: CC210037 0200253F
	v_fma_mixhi_f16 v55, v64, s18, 0                           // 000000145DD8: CC220037 02002540
	v_fma_mixlo_f16 v56, v65, s18, 0                           // 000000145DE0: CC210038 02002541
	v_fma_mixhi_f16 v56, v66, s18, 0                           // 000000145DE8: CC220038 02002542
	ds_load_b128 v[63:66], v78 offset:17168                    // 000000145DF0: DBFC4310 3F00004E
	v_fma_mixhi_f16 v45, v47, s18, 0                           // 000000145DF8: CC22002D 0200252F
	v_fma_mixhi_f16 v46, v49, s18, 0                           // 000000145E00: CC22002E 02002531
	v_fma_mixhi_f16 v47, v51, s18, 0                           // 000000145E08: CC22002F 02002533
	v_fma_mixlo_f16 v49, v57, s18, 0                           // 000000145E10: CC210031 02002539
	v_fma_mixhi_f16 v49, v58, s18, 0                           // 000000145E18: CC220031 0200253A
	v_fma_mixlo_f16 v51, v61, s18, 0                           // 000000145E20: CC210033 0200253D
	v_fma_mixhi_f16 v51, v62, s18, 0                           // 000000145E28: CC220033 0200253E
	s_waitcnt lgkmcnt(7)                                       // 000000145E30: BF89FC77
	v_fma_mixlo_f16 v57, v101, s18, 0                          // 000000145E34: CC210039 02002565
	v_fma_mixhi_f16 v57, v102, s18, 0                          // 000000145E3C: CC220039 02002566
	v_fma_mixlo_f16 v58, v103, s18, 0                          // 000000145E44: CC21003A 02002567
	v_fma_mixhi_f16 v58, v104, s18, 0                          // 000000145E4C: CC22003A 02002568
	s_waitcnt lgkmcnt(5)                                       // 000000145E54: BF89FC57
	v_fma_mixlo_f16 v61, v109, s18, 0                          // 000000145E58: CC21003D 0200256D
	v_fma_mixhi_f16 v61, v110, s18, 0                          // 000000145E60: CC22003D 0200256E
	v_fma_mixlo_f16 v62, v111, s18, 0                          // 000000145E68: CC21003E 0200256F
	v_fma_mixhi_f16 v62, v112, s18, 0                          // 000000145E70: CC22003E 02002570
	ds_load_b128 v[109:112], v78 offset:25600                  // 000000145E78: DBFC6400 6D00004E
	s_waitcnt lgkmcnt(5)                                       // 000000145E80: BF89FC57
	v_fma_mixlo_f16 v101, v113, s18, 0                         // 000000145E84: CC210065 02002571
	v_fma_mixhi_f16 v101, v114, s18, 0                         // 000000145E8C: CC220065 02002572
	v_fma_mixlo_f16 v102, v115, s18, 0                         // 000000145E94: CC210066 02002573
	v_fma_mixhi_f16 v102, v116, s18, 0                         // 000000145E9C: CC220066 02002574
	s_waitcnt lgkmcnt(1)                                       // 000000145EA4: BF89FC17
	v_fma_mixlo_f16 v103, v63, s18, 0                          // 000000145EA8: CC210067 0200253F
	v_fma_mixhi_f16 v103, v64, s18, 0                          // 000000145EB0: CC220067 02002540
	ds_load_b128 v[113:116], v78 offset:25632                  // 000000145EB8: DBFC6420 7100004E
	v_fma_mixlo_f16 v104, v65, s18, 0                          // 000000145EC0: CC210068 02002541
	v_fma_mixhi_f16 v104, v66, s18, 0                          // 000000145EC8: CC220068 02002542
	ds_load_b128 v[63:66], v78 offset:25648                    // 000000145ED0: DBFC6430 3F00004E
	v_fma_mixlo_f16 v47, v50, s18, 0                           // 000000145ED8: CC21002F 02002532
	v_fma_mixlo_f16 v50, v59, s18, 0                           // 000000145EE0: CC210032 0200253B
	v_fma_mixhi_f16 v50, v60, s18, 0                           // 000000145EE8: CC220032 0200253C
	v_fma_mixlo_f16 v59, v105, s18, 0                          // 000000145EF0: CC21003B 02002569
	v_fma_mixhi_f16 v59, v106, s18, 0                          // 000000145EF8: CC22003B 0200256A
	v_fma_mixlo_f16 v60, v107, s18, 0                          // 000000145F00: CC21003C 0200256B
	v_fma_mixhi_f16 v60, v108, s18, 0                          // 000000145F08: CC22003C 0200256C
	v_fma_mixlo_f16 v105, v117, s18, 0                         // 000000145F10: CC210069 02002575
	v_fma_mixhi_f16 v105, v118, s18, 0                         // 000000145F18: CC220069 02002576
	v_fma_mixlo_f16 v106, v119, s18, 0                         // 000000145F20: CC21006A 02002577
	v_fma_mixhi_f16 v106, v120, s18, 0                         // 000000145F28: CC22006A 02002578
	v_fma_mixlo_f16 v107, v121, s18, 0                         // 000000145F30: CC21006B 02002579
	v_fma_mixhi_f16 v107, v122, s18, 0                         // 000000145F38: CC22006B 0200257A
	v_fma_mixlo_f16 v108, v123, s18, 0                         // 000000145F40: CC21006C 0200257B
	v_fma_mixhi_f16 v108, v124, s18, 0                         // 000000145F48: CC22006C 0200257C
	s_waitcnt lgkmcnt(2)                                       // 000000145F50: BF89FC27
	v_fma_mixlo_f16 v109, v109, s18, 0                         // 000000145F54: CC21006D 0200256D
	v_fma_mixhi_f16 v109, v110, s18, 0                         // 000000145F5C: CC22006D 0200256E
	v_fma_mixlo_f16 v110, v111, s18, 0                         // 000000145F64: CC21006E 0200256F
	v_fma_mixhi_f16 v110, v112, s18, 0                         // 000000145F6C: CC22006E 02002570
	v_fma_mixlo_f16 v111, v125, s18, 0                         // 000000145F74: CC21006F 0200257D
	v_fma_mixhi_f16 v111, v126, s18, 0                         // 000000145F7C: CC22006F 0200257E
	v_fma_mixlo_f16 v112, v127, s18, 0                         // 000000145F84: CC210070 0200257F
	v_fma_mixhi_f16 v112, v128, s18, 0                         // 000000145F8C: CC220070 02002580
	s_waitcnt lgkmcnt(1)                                       // 000000145F94: BF89FC17
	v_fma_mixlo_f16 v113, v113, s18, 0                         // 000000145F98: CC210071 02002571
	v_fma_mixhi_f16 v113, v114, s18, 0                         // 000000145FA0: CC220071 02002572
	v_fma_mixlo_f16 v114, v115, s18, 0                         // 000000145FA8: CC210072 02002573
	v_fma_mixhi_f16 v114, v116, s18, 0                         // 000000145FB0: CC220072 02002574
	s_waitcnt lgkmcnt(0)                                       // 000000145FB8: BF89FC07
	v_fma_mixlo_f16 v115, v63, s18, 0                          // 000000145FBC: CC210073 0200253F
	v_fma_mixhi_f16 v115, v64, s18, 0                          // 000000145FC4: CC220073 02002540
	v_fma_mixlo_f16 v116, v65, s18, 0                          // 000000145FCC: CC210074 02002541
	v_fma_mixhi_f16 v116, v66, s18, 0                          // 000000145FD4: CC220074 02002542
	v_wmma_f32_16x16x16_f16 v[27:34], v[35:42], v[44:51], v[27:34]// 000000145FDC: CC40401B 1C6E5923
	v_wmma_f32_16x16x16_f16 v[19:26], v[35:42], v[55:62], v[19:26]// 000000145FE4: CC404013 1C4E6F23
	v_wmma_f32_16x16x16_f16 v[11:18], v[35:42], v[101:108], v[11:18]// 000000145FEC: CC40400B 1C2ECB23
	s_delay_alu instid0(VALU_DEP_4)                            // 000000145FF4: BF870004
	v_wmma_f32_16x16x16_f16 v[3:10], v[35:42], v[109:116], v[3:10]// 000000145FF8: CC404003 1C0EDB23
	.long 0x7f5239ab                                           // 000000146000: 7F5239AB
	.long 0x7e5239ab                                           // 000000146004: 7E5239AB
	.long 0x7f5039ab                                           // 000000146008: 7F5039AB
	.long 0x7e5039ab                                           // 00000014600C: 7E5039AB
	s_and_saveexec_b32 s11, s10                                // 000000146010: BE8B200A
	s_cbranch_execz 11                                         // 000000146014: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2444>
	global_load_b128 v[35:38], v[53:54], off offset:320        // 000000146018: DC5E0140 237C0035
	s_waitcnt vmcnt(0)                                         // 000000146020: BF8903F7
	v_fma_mixlo_f16 v40, v35, s18, 0                           // 000000146024: CC210028 02002523
	v_fma_mixhi_f16 v40, v36, s18, 0                           // 00000014602C: CC220028 02002524
	v_fma_mixlo_f16 v41, v37, s18, 0                           // 000000146034: CC210029 02002525
	v_fma_mixhi_f16 v41, v38, s18, 0                           // 00000014603C: CC220029 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 000000146044: 8C7E0B7E
	.long 0x7e5639ab                                           // 000000146048: 7E5639AB
	.long 0x7f5439ab                                           // 00000014604C: 7F5439AB
	.long 0x7e5439ab                                           // 000000146050: 7E5439AB
	s_and_saveexec_b32 s11, s10                                // 000000146054: BE8B200A
	s_cbranch_execz 11                                         // 000000146058: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2488>
	global_load_b128 v[35:38], v[53:54], off offset:336        // 00000014605C: DC5E0150 237C0035
	s_waitcnt vmcnt(0)                                         // 000000146064: BF8903F7
	v_fma_mixlo_f16 v42, v35, s18, 0                           // 000000146068: CC21002A 02002523
	v_fma_mixhi_f16 v42, v36, s18, 0                           // 000000146070: CC22002A 02002524
	v_fma_mixlo_f16 v43, v37, s18, 0                           // 000000146078: CC21002B 02002525
	v_fma_mixhi_f16 v43, v38, s18, 0                           // 000000146080: CC22002B 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 000000146088: 8C7E0B7E
	.long 0x7f5e3880                                           // 00000014608C: 7F5E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000146090: BF870001
	.long 0x7f5a39af                                           // 000000146094: 7F5A39AF
	.long 0x7e5a39af                                           // 000000146098: 7E5A39AF
	.long 0x7f5839af                                           // 00000014609C: 7F5839AF
	.long 0x7e5839af                                           // 0000001460A0: 7E5839AF
	s_and_saveexec_b32 s11, s10                                // 0000001460A4: BE8B200A
	s_cbranch_execz 11                                         // 0000001460A8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x24d8>
	global_load_b128 v[35:38], v[53:54], off offset:352        // 0000001460AC: DC5E0160 237C0035
	s_waitcnt vmcnt(0)                                         // 0000001460B4: BF8903F7
	v_fma_mixlo_f16 v44, v35, s18, 0                           // 0000001460B8: CC21002C 02002523
	v_fma_mixhi_f16 v44, v36, s18, 0                           // 0000001460C0: CC22002C 02002524
	v_fma_mixlo_f16 v45, v37, s18, 0                           // 0000001460C8: CC21002D 02002525
	v_fma_mixhi_f16 v45, v38, s18, 0                           // 0000001460D0: CC22002D 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001460D8: 8C7E0B7E
	.long 0x7e5e39af                                           // 0000001460DC: 7E5E39AF
	.long 0x7f5c39af                                           // 0000001460E0: 7F5C39AF
	.long 0x7e5c39af                                           // 0000001460E4: 7E5C39AF
	s_and_saveexec_b32 s11, s10                                // 0000001460E8: BE8B200A
	s_cbranch_execz 11                                         // 0000001460EC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x251c>
	global_load_b128 v[35:38], v[53:54], off offset:368        // 0000001460F0: DC5E0170 237C0035
	s_waitcnt vmcnt(0)                                         // 0000001460F8: BF8903F7
	v_fma_mixlo_f16 v46, v35, s18, 0                           // 0000001460FC: CC21002E 02002523
	v_fma_mixhi_f16 v46, v36, s18, 0                           // 000000146104: CC22002E 02002524
	v_fma_mixlo_f16 v47, v37, s18, 0                           // 00000014610C: CC21002F 02002525
	v_fma_mixhi_f16 v47, v38, s18, 0                           // 000000146114: CC22002F 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 00000014611C: 8C7E0B7E
	ds_load_b128 v[35:38], v78 offset:320                      // 000000146120: DBFC0140 2300004E
	ds_load_b128 v[48:51], v78 offset:336                      // 000000146128: DBFC0150 3000004E
	ds_load_b128 v[59:62], v78 offset:352                      // 000000146130: DBFC0160 3B00004E
	ds_load_b128 v[63:66], v78 offset:368                      // 000000146138: DBFC0170 3F00004E
	ds_load_b128 v[101:104], v78 offset:8768                   // 000000146140: DBFC2240 6500004E
	ds_load_b128 v[105:108], v78 offset:8784                   // 000000146148: DBFC2250 6900004E
	ds_load_b128 v[109:112], v78 offset:8800                   // 000000146150: DBFC2260 6D00004E
	ds_load_b128 v[113:116], v78 offset:8816                   // 000000146158: DBFC2270 7100004E
	ds_load_b128 v[121:124], v78 offset:25664                  // 000000146160: DBFC6440 7900004E
	ds_load_b128 v[125:128], v78 offset:25680                  // 000000146168: DBFC6450 7D00004E
	ds_load_b128 v[117:120], v78 offset:17264                  // 000000146170: DBFC4370 7500004E
	s_waitcnt lgkmcnt(10)                                      // 000000146178: BF89FCA7
	v_fma_mixlo_f16 v55, v35, s18, 0                           // 00000014617C: CC210037 02002523
	v_fma_mixhi_f16 v55, v36, s18, 0                           // 000000146184: CC220037 02002524
	v_fma_mixlo_f16 v56, v37, s18, 0                           // 00000014618C: CC210038 02002525
	v_fma_mixhi_f16 v56, v38, s18, 0                           // 000000146194: CC220038 02002526
	s_waitcnt lgkmcnt(9)                                       // 00000014619C: BF89FC97
	v_fma_mixlo_f16 v57, v48, s18, 0                           // 0000001461A0: CC210039 02002530
	v_fma_mixhi_f16 v57, v49, s18, 0                           // 0000001461A8: CC220039 02002531
	v_fma_mixlo_f16 v58, v50, s18, 0                           // 0000001461B0: CC21003A 02002532
	v_fma_mixhi_f16 v58, v51, s18, 0                           // 0000001461B8: CC22003A 02002533
	ds_load_b128 v[35:38], v78 offset:17216                    // 0000001461C0: DBFC4340 2300004E
	ds_load_b128 v[48:51], v78 offset:17232                    // 0000001461C8: DBFC4350 3000004E
	s_waitcnt lgkmcnt(10)                                      // 0000001461D0: BF89FCA7
	v_fma_mixlo_f16 v59, v59, s18, 0                           // 0000001461D4: CC21003B 0200253B
	v_fma_mixhi_f16 v59, v60, s18, 0                           // 0000001461DC: CC22003B 0200253C
	v_fma_mixlo_f16 v60, v61, s18, 0                           // 0000001461E4: CC21003C 0200253D
	v_fma_mixhi_f16 v60, v62, s18, 0                           // 0000001461EC: CC22003C 0200253E
	s_waitcnt lgkmcnt(9)                                       // 0000001461F4: BF89FC97
	v_fma_mixlo_f16 v61, v63, s18, 0                           // 0000001461F8: CC21003D 0200253F
	v_fma_mixhi_f16 v61, v64, s18, 0                           // 000000146200: CC22003D 02002540
	v_fma_mixlo_f16 v62, v65, s18, 0                           // 000000146208: CC21003E 02002541
	v_fma_mixhi_f16 v62, v66, s18, 0                           // 000000146210: CC22003E 02002542
	s_waitcnt lgkmcnt(8)                                       // 000000146218: BF89FC87
	v_fma_mixlo_f16 v101, v101, s18, 0                         // 00000014621C: CC210065 02002565
	v_fma_mixhi_f16 v101, v102, s18, 0                         // 000000146224: CC220065 02002566
	v_fma_mixlo_f16 v102, v103, s18, 0                         // 00000014622C: CC210066 02002567
	s_waitcnt lgkmcnt(7)                                       // 000000146234: BF89FC77
	v_fma_mixlo_f16 v103, v105, s18, 0                         // 000000146238: CC210067 02002569
	v_fma_mixhi_f16 v103, v106, s18, 0                         // 000000146240: CC220067 0200256A
	s_waitcnt lgkmcnt(6)                                       // 000000146248: BF89FC67
	v_fma_mixlo_f16 v105, v109, s18, 0                         // 00000014624C: CC210069 0200256D
	ds_load_b128 v[63:66], v78 offset:17248                    // 000000146254: DBFC4360 3F00004E
	v_fma_mixhi_f16 v105, v110, s18, 0                         // 00000014625C: CC220069 0200256E
	v_fma_mixlo_f16 v106, v111, s18, 0                         // 000000146264: CC21006A 0200256F
	v_fma_mixhi_f16 v106, v112, s18, 0                         // 00000014626C: CC22006A 02002570
	s_waitcnt lgkmcnt(2)                                       // 000000146274: BF89FC27
	v_fma_mixlo_f16 v109, v35, s18, 0                          // 000000146278: CC21006D 02002523
	v_fma_mixhi_f16 v109, v36, s18, 0                          // 000000146280: CC22006D 02002524
	v_fma_mixlo_f16 v110, v37, s18, 0                          // 000000146288: CC21006E 02002525
	v_fma_mixhi_f16 v110, v38, s18, 0                          // 000000146290: CC22006E 02002526
	s_waitcnt lgkmcnt(1)                                       // 000000146298: BF89FC17
	v_fma_mixlo_f16 v111, v48, s18, 0                          // 00000014629C: CC21006F 02002530
	v_fma_mixhi_f16 v111, v49, s18, 0                          // 0000001462A4: CC22006F 02002531
	ds_load_b128 v[35:38], v78 offset:25696                    // 0000001462AC: DBFC6460 2300004E
	v_fma_mixlo_f16 v112, v50, s18, 0                          // 0000001462B4: CC210070 02002532
	v_fma_mixhi_f16 v112, v51, s18, 0                          // 0000001462BC: CC220070 02002533
	ds_load_b128 v[48:51], v78 offset:25712                    // 0000001462C4: DBFC6470 3000004E
	v_fma_mixhi_f16 v102, v104, s18, 0                         // 0000001462CC: CC220066 02002568
	v_fma_mixlo_f16 v104, v107, s18, 0                         // 0000001462D4: CC210068 0200256B
	v_fma_mixhi_f16 v104, v108, s18, 0                         // 0000001462DC: CC220068 0200256C
	v_fma_mixlo_f16 v107, v113, s18, 0                         // 0000001462E4: CC21006B 02002571
	v_fma_mixhi_f16 v107, v114, s18, 0                         // 0000001462EC: CC22006B 02002572
	v_fma_mixlo_f16 v108, v115, s18, 0                         // 0000001462F4: CC21006C 02002573
	v_fma_mixhi_f16 v108, v116, s18, 0                         // 0000001462FC: CC22006C 02002574
	s_waitcnt lgkmcnt(2)                                       // 000000146304: BF89FC27
	v_fma_mixlo_f16 v113, v63, s18, 0                          // 000000146308: CC210071 0200253F
	v_fma_mixhi_f16 v113, v64, s18, 0                          // 000000146310: CC220071 02002540
	v_fma_mixlo_f16 v114, v65, s18, 0                          // 000000146318: CC210072 02002541
	v_fma_mixhi_f16 v114, v66, s18, 0                          // 000000146320: CC220072 02002542
	v_fma_mixlo_f16 v115, v117, s18, 0                         // 000000146328: CC210073 02002575
	v_fma_mixhi_f16 v115, v118, s18, 0                         // 000000146330: CC220073 02002576
	v_fma_mixlo_f16 v116, v119, s18, 0                         // 000000146338: CC210074 02002577
	v_fma_mixhi_f16 v116, v120, s18, 0                         // 000000146340: CC220074 02002578
	v_fma_mixlo_f16 v117, v121, s18, 0                         // 000000146348: CC210075 02002579
	v_fma_mixhi_f16 v117, v122, s18, 0                         // 000000146350: CC220075 0200257A
	v_fma_mixlo_f16 v118, v123, s18, 0                         // 000000146358: CC210076 0200257B
	v_fma_mixhi_f16 v118, v124, s18, 0                         // 000000146360: CC220076 0200257C
	v_fma_mixlo_f16 v119, v125, s18, 0                         // 000000146368: CC210077 0200257D
	v_fma_mixhi_f16 v119, v126, s18, 0                         // 000000146370: CC220077 0200257E
	v_fma_mixlo_f16 v120, v127, s18, 0                         // 000000146378: CC210078 0200257F
	v_fma_mixhi_f16 v120, v128, s18, 0                         // 000000146380: CC220078 02002580
	s_waitcnt lgkmcnt(1)                                       // 000000146388: BF89FC17
	v_fma_mixlo_f16 v121, v35, s18, 0                          // 00000014638C: CC210079 02002523
	v_fma_mixhi_f16 v121, v36, s18, 0                          // 000000146394: CC220079 02002524
	v_fma_mixlo_f16 v122, v37, s18, 0                          // 00000014639C: CC21007A 02002525
	v_fma_mixhi_f16 v122, v38, s18, 0                          // 0000001463A4: CC22007A 02002526
	s_waitcnt lgkmcnt(0)                                       // 0000001463AC: BF89FC07
	v_fma_mixlo_f16 v123, v48, s18, 0                          // 0000001463B0: CC21007B 02002530
	v_fma_mixhi_f16 v123, v49, s18, 0                          // 0000001463B8: CC22007B 02002531
	v_fma_mixlo_f16 v124, v50, s18, 0                          // 0000001463C0: CC21007C 02002532
	v_fma_mixhi_f16 v124, v51, s18, 0                          // 0000001463C8: CC22007C 02002533
	.long 0x7f603880                                           // 0000001463D0: 7F603880
	v_wmma_f32_16x16x16_f16 v[27:34], v[40:47], v[55:62], v[27:34]// 0000001463D4: CC40401B 1C6E6F28
	v_wmma_f32_16x16x16_f16 v[19:26], v[40:47], v[101:108], v[19:26]// 0000001463DC: CC404013 1C4ECB28
	v_wmma_f32_16x16x16_f16 v[11:18], v[40:47], v[109:116], v[11:18]// 0000001463E4: CC40400B 1C2EDB28
	v_wmma_f32_16x16x16_f16 v[3:10], v[40:47], v[117:124], v[3:10]// 0000001463EC: CC404003 1C0EEB28
	.long 0x7f5c39b0                                           // 0000001463F4: 7F5C39B0
	.long 0x7e5c39b0                                           // 0000001463F8: 7E5C39B0
	.long 0x7f5a39b0                                           // 0000001463FC: 7F5A39B0
	.long 0x7e5a39b0                                           // 000000146400: 7E5A39B0
	s_and_saveexec_b32 s11, s10                                // 000000146404: BE8B200A
	s_cbranch_execz 11                                         // 000000146408: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2838>
	global_load_b128 v[35:38], v[53:54], off offset:384        // 00000014640C: DC5E0180 237C0035
	s_waitcnt vmcnt(0)                                         // 000000146414: BF8903F7
	v_fma_mixlo_f16 v45, v35, s18, 0                           // 000000146418: CC21002D 02002523
	v_fma_mixhi_f16 v45, v36, s18, 0                           // 000000146420: CC22002D 02002524
	v_fma_mixlo_f16 v46, v37, s18, 0                           // 000000146428: CC21002E 02002525
	v_fma_mixhi_f16 v46, v38, s18, 0                           // 000000146430: CC22002E 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 000000146438: 8C7E0B7E
	.long 0x7e6039b0                                           // 00000014643C: 7E6039B0
	.long 0x7f5e39b0                                           // 000000146440: 7F5E39B0
	.long 0x7e5e39b0                                           // 000000146444: 7E5E39B0
	s_and_saveexec_b32 s11, s10                                // 000000146448: BE8B200A
	s_cbranch_execz 11                                         // 00000014644C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x287c>
	global_load_b128 v[35:38], v[53:54], off offset:400        // 000000146450: DC5E0190 237C0035
	s_waitcnt vmcnt(0)                                         // 000000146458: BF8903F7
	v_fma_mixlo_f16 v47, v35, s18, 0                           // 00000014645C: CC21002F 02002523
	v_fma_mixhi_f16 v47, v36, s18, 0                           // 000000146464: CC22002F 02002524
	v_fma_mixlo_f16 v48, v37, s18, 0                           // 00000014646C: CC210030 02002525
	v_fma_mixhi_f16 v48, v38, s18, 0                           // 000000146474: CC220030 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 00000014647C: 8C7E0B7E
	.long 0x7f683880                                           // 000000146480: 7F683880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000146484: BF870001
	.long 0x7f6439b4                                           // 000000146488: 7F6439B4
	.long 0x7e6439b4                                           // 00000014648C: 7E6439B4
	.long 0x7f6239b4                                           // 000000146490: 7F6239B4
	.long 0x7e6239b4                                           // 000000146494: 7E6239B4
	s_and_saveexec_b32 s11, s10                                // 000000146498: BE8B200A
	s_cbranch_execz 11                                         // 00000014649C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x28cc>
	global_load_b128 v[35:38], v[53:54], off offset:416        // 0000001464A0: DC5E01A0 237C0035
	s_waitcnt vmcnt(0)                                         // 0000001464A8: BF8903F7
	v_fma_mixlo_f16 v49, v35, s18, 0                           // 0000001464AC: CC210031 02002523
	v_fma_mixhi_f16 v49, v36, s18, 0                           // 0000001464B4: CC220031 02002524
	v_fma_mixlo_f16 v50, v37, s18, 0                           // 0000001464BC: CC210032 02002525
	v_fma_mixhi_f16 v50, v38, s18, 0                           // 0000001464C4: CC220032 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001464CC: 8C7E0B7E
	.long 0x7e6839b4                                           // 0000001464D0: 7E6839B4
	.long 0x7f6639b4                                           // 0000001464D4: 7F6639B4
	.long 0x7e6639b4                                           // 0000001464D8: 7E6639B4
	s_and_saveexec_b32 s11, s10                                // 0000001464DC: BE8B200A
	s_cbranch_execz 11                                         // 0000001464E0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2910>
	global_load_b128 v[35:38], v[53:54], off offset:432        // 0000001464E4: DC5E01B0 237C0035
	s_waitcnt vmcnt(0)                                         // 0000001464EC: BF8903F7
	v_fma_mixlo_f16 v51, v35, s18, 0                           // 0000001464F0: CC210033 02002523
	v_fma_mixhi_f16 v51, v36, s18, 0                           // 0000001464F8: CC220033 02002524
	v_fma_mixlo_f16 v52, v37, s18, 0                           // 000000146500: CC210034 02002525
	v_fma_mixhi_f16 v52, v38, s18, 0                           // 000000146508: CC220034 02002526
	s_or_b32 exec_lo, exec_lo, s11                             // 000000146510: 8C7E0B7E
	ds_load_b128 v[35:38], v78 offset:384                      // 000000146514: DBFC0180 2300004E
	ds_load_b128 v[39:42], v78 offset:400                      // 00000014651C: DBFC0190 2700004E
	ds_load_b128 v[59:62], v78 offset:416                      // 000000146524: DBFC01A0 3B00004E
	ds_load_b128 v[63:66], v78 offset:432                      // 00000014652C: DBFC01B0 3F00004E
	ds_load_b128 v[101:104], v78 offset:8832                   // 000000146534: DBFC2280 6500004E
	ds_load_b128 v[105:108], v78 offset:8848                   // 00000014653C: DBFC2290 6900004E
	ds_load_b128 v[109:112], v78 offset:8864                   // 000000146544: DBFC22A0 6D00004E
	ds_load_b128 v[113:116], v78 offset:8880                   // 00000014654C: DBFC22B0 7100004E
	ds_load_b128 v[121:124], v78 offset:25728                  // 000000146554: DBFC6480 7900004E
	ds_load_b128 v[125:128], v78 offset:25744                  // 00000014655C: DBFC6490 7D00004E
	ds_load_b128 v[117:120], v78 offset:17328                  // 000000146564: DBFC43B0 7500004E
	s_waitcnt lgkmcnt(10)                                      // 00000014656C: BF89FCA7
	v_fma_mixlo_f16 v55, v35, s18, 0                           // 000000146570: CC210037 02002523
	v_fma_mixhi_f16 v55, v36, s18, 0                           // 000000146578: CC220037 02002524
	v_fma_mixlo_f16 v56, v37, s18, 0                           // 000000146580: CC210038 02002525
	v_fma_mixhi_f16 v56, v38, s18, 0                           // 000000146588: CC220038 02002526
	s_waitcnt lgkmcnt(9)                                       // 000000146590: BF89FC97
	v_fma_mixlo_f16 v57, v39, s18, 0                           // 000000146594: CC210039 02002527
	v_fma_mixhi_f16 v57, v40, s18, 0                           // 00000014659C: CC220039 02002528
	v_fma_mixlo_f16 v58, v41, s18, 0                           // 0000001465A4: CC21003A 02002529
	v_fma_mixhi_f16 v58, v42, s18, 0                           // 0000001465AC: CC22003A 0200252A
	ds_load_b128 v[35:38], v78 offset:17280                    // 0000001465B4: DBFC4380 2300004E
	ds_load_b128 v[39:42], v78 offset:17296                    // 0000001465BC: DBFC4390 2700004E
	s_waitcnt lgkmcnt(10)                                      // 0000001465C4: BF89FCA7
	v_fma_mixlo_f16 v59, v59, s18, 0                           // 0000001465C8: CC21003B 0200253B
	v_fma_mixhi_f16 v59, v60, s18, 0                           // 0000001465D0: CC22003B 0200253C
	v_fma_mixlo_f16 v60, v61, s18, 0                           // 0000001465D8: CC21003C 0200253D
	v_fma_mixhi_f16 v60, v62, s18, 0                           // 0000001465E0: CC22003C 0200253E
	s_waitcnt lgkmcnt(9)                                       // 0000001465E8: BF89FC97
	v_fma_mixlo_f16 v61, v63, s18, 0                           // 0000001465EC: CC21003D 0200253F
	v_fma_mixhi_f16 v61, v64, s18, 0                           // 0000001465F4: CC22003D 02002540
	v_fma_mixlo_f16 v62, v65, s18, 0                           // 0000001465FC: CC21003E 02002541
	v_fma_mixhi_f16 v62, v66, s18, 0                           // 000000146604: CC22003E 02002542
	s_waitcnt lgkmcnt(8)                                       // 00000014660C: BF89FC87
	v_fma_mixlo_f16 v101, v101, s18, 0                         // 000000146610: CC210065 02002565
	v_fma_mixhi_f16 v101, v102, s18, 0                         // 000000146618: CC220065 02002566
	v_fma_mixlo_f16 v102, v103, s18, 0                         // 000000146620: CC210066 02002567
	s_waitcnt lgkmcnt(7)                                       // 000000146628: BF89FC77
	v_fma_mixlo_f16 v103, v105, s18, 0                         // 00000014662C: CC210067 02002569
	v_fma_mixhi_f16 v103, v106, s18, 0                         // 000000146634: CC220067 0200256A
	s_waitcnt lgkmcnt(6)                                       // 00000014663C: BF89FC67
	v_fma_mixlo_f16 v105, v109, s18, 0                         // 000000146640: CC210069 0200256D
	ds_load_b128 v[63:66], v78 offset:17312                    // 000000146648: DBFC43A0 3F00004E
	v_fma_mixhi_f16 v105, v110, s18, 0                         // 000000146650: CC220069 0200256E
	v_fma_mixlo_f16 v106, v111, s18, 0                         // 000000146658: CC21006A 0200256F
	v_fma_mixhi_f16 v106, v112, s18, 0                         // 000000146660: CC22006A 02002570
	s_waitcnt lgkmcnt(2)                                       // 000000146668: BF89FC27
	v_fma_mixlo_f16 v109, v35, s18, 0                          // 00000014666C: CC21006D 02002523
	v_fma_mixhi_f16 v109, v36, s18, 0                          // 000000146674: CC22006D 02002524
	v_fma_mixlo_f16 v110, v37, s18, 0                          // 00000014667C: CC21006E 02002525
	v_fma_mixhi_f16 v110, v38, s18, 0                          // 000000146684: CC22006E 02002526
	s_waitcnt lgkmcnt(1)                                       // 00000014668C: BF89FC17
	v_fma_mixlo_f16 v111, v39, s18, 0                          // 000000146690: CC21006F 02002527
	v_fma_mixhi_f16 v111, v40, s18, 0                          // 000000146698: CC22006F 02002528
	ds_load_b128 v[35:38], v78 offset:25760                    // 0000001466A0: DBFC64A0 2300004E
	v_fma_mixlo_f16 v112, v41, s18, 0                          // 0000001466A8: CC210070 02002529
	v_fma_mixhi_f16 v112, v42, s18, 0                          // 0000001466B0: CC220070 0200252A
	ds_load_b128 v[39:42], v78 offset:25776                    // 0000001466B8: DBFC64B0 2700004E
	v_fma_mixhi_f16 v102, v104, s18, 0                         // 0000001466C0: CC220066 02002568
	v_fma_mixlo_f16 v104, v107, s18, 0                         // 0000001466C8: CC210068 0200256B
	v_fma_mixhi_f16 v104, v108, s18, 0                         // 0000001466D0: CC220068 0200256C
	v_fma_mixlo_f16 v107, v113, s18, 0                         // 0000001466D8: CC21006B 02002571
	v_fma_mixhi_f16 v107, v114, s18, 0                         // 0000001466E0: CC22006B 02002572
	v_fma_mixlo_f16 v108, v115, s18, 0                         // 0000001466E8: CC21006C 02002573
	v_fma_mixhi_f16 v108, v116, s18, 0                         // 0000001466F0: CC22006C 02002574
	s_waitcnt lgkmcnt(2)                                       // 0000001466F8: BF89FC27
	v_fma_mixlo_f16 v113, v63, s18, 0                          // 0000001466FC: CC210071 0200253F
	v_fma_mixhi_f16 v113, v64, s18, 0                          // 000000146704: CC220071 02002540
	v_fma_mixlo_f16 v114, v65, s18, 0                          // 00000014670C: CC210072 02002541
	v_fma_mixhi_f16 v114, v66, s18, 0                          // 000000146714: CC220072 02002542
	v_fma_mixlo_f16 v115, v117, s18, 0                         // 00000014671C: CC210073 02002575
	v_fma_mixhi_f16 v115, v118, s18, 0                         // 000000146724: CC220073 02002576
	v_fma_mixlo_f16 v116, v119, s18, 0                         // 00000014672C: CC210074 02002577
	v_fma_mixhi_f16 v116, v120, s18, 0                         // 000000146734: CC220074 02002578
	v_fma_mixlo_f16 v117, v121, s18, 0                         // 00000014673C: CC210075 02002579
	v_fma_mixhi_f16 v117, v122, s18, 0                         // 000000146744: CC220075 0200257A
	v_fma_mixlo_f16 v118, v123, s18, 0                         // 00000014674C: CC210076 0200257B
	v_fma_mixhi_f16 v118, v124, s18, 0                         // 000000146754: CC220076 0200257C
	v_fma_mixlo_f16 v119, v125, s18, 0                         // 00000014675C: CC210077 0200257D
	v_fma_mixhi_f16 v119, v126, s18, 0                         // 000000146764: CC220077 0200257E
	v_fma_mixlo_f16 v120, v127, s18, 0                         // 00000014676C: CC210078 0200257F
	v_fma_mixhi_f16 v120, v128, s18, 0                         // 000000146774: CC220078 02002580
	s_waitcnt lgkmcnt(1)                                       // 00000014677C: BF89FC17
	v_fma_mixlo_f16 v121, v35, s18, 0                          // 000000146780: CC210079 02002523
	v_fma_mixhi_f16 v121, v36, s18, 0                          // 000000146788: CC220079 02002524
	v_fma_mixlo_f16 v122, v37, s18, 0                          // 000000146790: CC21007A 02002525
	v_fma_mixhi_f16 v122, v38, s18, 0                          // 000000146798: CC22007A 02002526
	s_waitcnt lgkmcnt(0)                                       // 0000001467A0: BF89FC07
	v_fma_mixlo_f16 v123, v39, s18, 0                          // 0000001467A4: CC21007B 02002527
	v_fma_mixhi_f16 v123, v40, s18, 0                          // 0000001467AC: CC22007B 02002528
	v_fma_mixlo_f16 v124, v41, s18, 0                          // 0000001467B4: CC21007C 02002529
	v_fma_mixhi_f16 v124, v42, s18, 0                          // 0000001467BC: CC22007C 0200252A
	.long 0x7f4c3880                                           // 0000001467C4: 7F4C3880
	v_wmma_f32_16x16x16_f16 v[27:34], v[45:52], v[55:62], v[27:34]// 0000001467C8: CC40401B 1C6E6F2D
	v_wmma_f32_16x16x16_f16 v[19:26], v[45:52], v[101:108], v[19:26]// 0000001467D0: CC404013 1C4ECB2D
	v_wmma_f32_16x16x16_f16 v[11:18], v[45:52], v[109:116], v[11:18]// 0000001467D8: CC40400B 1C2EDB2D
	v_wmma_f32_16x16x16_f16 v[3:10], v[45:52], v[117:124], v[3:10]// 0000001467E0: CC404003 1C0EEB2D
	.long 0x7f4839a6                                           // 0000001467E8: 7F4839A6
	.long 0x7e4839a6                                           // 0000001467EC: 7E4839A6
	.long 0x7f4639a6                                           // 0000001467F0: 7F4639A6
	.long 0x7e4639a6                                           // 0000001467F4: 7E4639A6
	s_and_saveexec_b32 s11, s10                                // 0000001467F8: BE8B200A
	s_cbranch_execz 11                                         // 0000001467FC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c2c>
	global_load_b128 v[39:42], v[53:54], off offset:448        // 000000146800: DC5E01C0 277C0035
	s_waitcnt vmcnt(0)                                         // 000000146808: BF8903F7
	v_fma_mixlo_f16 v35, v39, s18, 0                           // 00000014680C: CC210023 02002527
	v_fma_mixhi_f16 v35, v40, s18, 0                           // 000000146814: CC220023 02002528
	v_fma_mixlo_f16 v36, v41, s18, 0                           // 00000014681C: CC210024 02002529
	v_fma_mixhi_f16 v36, v42, s18, 0                           // 000000146824: CC220024 0200252A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000014682C: 8C7E0B7E
	.long 0x7e4c39a6                                           // 000000146830: 7E4C39A6
	.long 0x7f4a39a6                                           // 000000146834: 7F4A39A6
	.long 0x7e4a39a6                                           // 000000146838: 7E4A39A6
	s_and_saveexec_b32 s11, s10                                // 00000014683C: BE8B200A
	s_cbranch_execz 11                                         // 000000146840: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c70>
	global_load_b128 v[37:40], v[53:54], off offset:464        // 000000146844: DC5E01D0 257C0035
	s_waitcnt vmcnt(0)                                         // 00000014684C: BF8903F7
	v_fma_mixlo_f16 v37, v37, s18, 0                           // 000000146850: CC210025 02002525
	v_fma_mixhi_f16 v37, v38, s18, 0                           // 000000146858: CC220025 02002526
	v_fma_mixlo_f16 v38, v39, s18, 0                           // 000000146860: CC210026 02002527
	v_fma_mixhi_f16 v38, v40, s18, 0                           // 000000146868: CC220026 02002528
	s_or_b32 exec_lo, exec_lo, s11                             // 000000146870: 8C7E0B7E
	.long 0x7f543880                                           // 000000146874: 7F543880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000146878: BF870001
	.long 0x7f5039aa                                           // 00000014687C: 7F5039AA
	.long 0x7e5039aa                                           // 000000146880: 7E5039AA
	.long 0x7f4e39aa                                           // 000000146884: 7F4E39AA
	.long 0x7e4e39aa                                           // 000000146888: 7E4E39AA
	s_and_saveexec_b32 s11, s10                                // 00000014688C: BE8B200A
	s_cbranch_execz 11                                         // 000000146890: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2cc0>
	global_load_b128 v[43:46], v[53:54], off offset:480        // 000000146894: DC5E01E0 2B7C0035
	s_waitcnt vmcnt(0)                                         // 00000014689C: BF8903F7
	v_fma_mixlo_f16 v39, v43, s18, 0                           // 0000001468A0: CC210027 0200252B
	v_fma_mixhi_f16 v39, v44, s18, 0                           // 0000001468A8: CC220027 0200252C
	v_fma_mixlo_f16 v40, v45, s18, 0                           // 0000001468B0: CC210028 0200252D
	v_fma_mixhi_f16 v40, v46, s18, 0                           // 0000001468B8: CC220028 0200252E
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001468C0: 8C7E0B7E
	.long 0x7e5439aa                                           // 0000001468C4: 7E5439AA
	.long 0x7f5239aa                                           // 0000001468C8: 7F5239AA
	.long 0x7e5239aa                                           // 0000001468CC: 7E5239AA
	s_and_saveexec_b32 s11, s10                                // 0000001468D0: BE8B200A
	s_cbranch_execz 11                                         // 0000001468D4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d04>
	global_load_b128 v[41:44], v[53:54], off offset:496        // 0000001468D8: DC5E01F0 297C0035
	s_waitcnt vmcnt(0)                                         // 0000001468E0: BF8903F7
	v_fma_mixlo_f16 v41, v41, s18, 0                           // 0000001468E4: CC210029 02002529
	v_fma_mixhi_f16 v41, v42, s18, 0                           // 0000001468EC: CC220029 0200252A
	v_fma_mixlo_f16 v42, v43, s18, 0                           // 0000001468F4: CC21002A 0200252B
	v_fma_mixhi_f16 v42, v44, s18, 0                           // 0000001468FC: CC22002A 0200252C
	s_or_b32 exec_lo, exec_lo, s11                             // 000000146904: 8C7E0B7E
	ds_load_b128 v[43:46], v78 offset:448                      // 000000146908: DBFC01C0 2B00004E
	ds_load_b128 v[47:50], v78 offset:464                      // 000000146910: DBFC01D0 2F00004E
	ds_load_b128 v[51:54], v78 offset:480                      // 000000146918: DBFC01E0 3300004E
	ds_load_b128 v[55:58], v78 offset:496                      // 000000146920: DBFC01F0 3700004E
	ds_load_b128 v[59:62], v78 offset:8896                     // 000000146928: DBFC22C0 3B00004E
	ds_load_b128 v[63:66], v78 offset:8912                     // 000000146930: DBFC22D0 3F00004E
	ds_load_b128 v[101:104], v78 offset:8928                   // 000000146938: DBFC22E0 6500004E
	ds_load_b128 v[105:108], v78 offset:8944                   // 000000146940: DBFC22F0 6900004E
	ds_load_b128 v[109:112], v78 offset:17344                  // 000000146948: DBFC43C0 6D00004E
	ds_load_b128 v[113:116], v78 offset:17360                  // 000000146950: DBFC43D0 7100004E
	ds_load_b128 v[117:120], v78 offset:25808                  // 000000146958: DBFC64D0 7500004E
	s_mul_i32 s10, s19, 48                                     // 000000146960: 960AB013
	s_mul_hi_u32 s11, s19, 48                                  // 000000146964: 968BB013
	s_add_u32 s10, s10, s2                                     // 000000146968: 800A020A
	s_addc_u32 s11, s11, s3                                    // 00000014696C: 820B030B
	s_mov_b32 s44, 0                                           // 000000146970: BEAC0080
	s_lshl_b64 s[10:11], s[10:11], 14                          // 000000146974: 848A8E0A
	s_waitcnt lgkmcnt(10)                                      // 000000146978: BF89FCA7
	v_fma_mixlo_f16 v43, v43, s18, 0                           // 00000014697C: CC21002B 0200252B
	v_fma_mixhi_f16 v43, v44, s18, 0                           // 000000146984: CC22002B 0200252C
	v_fma_mixlo_f16 v44, v45, s18, 0                           // 00000014698C: CC21002C 0200252D
	v_fma_mixhi_f16 v44, v46, s18, 0                           // 000000146994: CC22002C 0200252E
	s_waitcnt lgkmcnt(9)                                       // 00000014699C: BF89FC97
	v_fma_mixhi_f16 v45, v48, s18, 0                           // 0000001469A0: CC22002D 02002530
	v_fma_mixlo_f16 v46, v49, s18, 0                           // 0000001469A8: CC21002E 02002531
	s_waitcnt lgkmcnt(8)                                       // 0000001469B0: BF89FC87
	v_fma_mixlo_f16 v48, v53, s18, 0                           // 0000001469B4: CC210030 02002535
	v_fma_mixhi_f16 v48, v54, s18, 0                           // 0000001469BC: CC220030 02002536
	s_waitcnt lgkmcnt(7)                                       // 0000001469C4: BF89FC77
	v_fma_mixlo_f16 v49, v55, s18, 0                           // 0000001469C8: CC210031 02002537
	v_fma_mixhi_f16 v49, v56, s18, 0                           // 0000001469D0: CC220031 02002538
	s_waitcnt lgkmcnt(5)                                       // 0000001469D8: BF89FC57
	v_fma_mixlo_f16 v53, v63, s18, 0                           // 0000001469DC: CC210035 0200253F
	v_fma_mixhi_f16 v53, v64, s18, 0                           // 0000001469E4: CC220035 02002540
	v_fma_mixlo_f16 v54, v65, s18, 0                           // 0000001469EC: CC210036 02002541
	v_fma_mixhi_f16 v54, v66, s18, 0                           // 0000001469F4: CC220036 02002542
	s_waitcnt lgkmcnt(4)                                       // 0000001469FC: BF89FC47
	v_fma_mixlo_f16 v55, v101, s18, 0                          // 000000146A00: CC210037 02002565
	ds_load_b128 v[63:66], v78 offset:17376                    // 000000146A08: DBFC43E0 3F00004E
	v_fma_mixhi_f16 v55, v102, s18, 0                          // 000000146A10: CC220037 02002566
	v_fma_mixlo_f16 v56, v103, s18, 0                          // 000000146A18: CC210038 02002567
	v_fma_mixhi_f16 v56, v104, s18, 0                          // 000000146A20: CC220038 02002568
	ds_load_b128 v[101:104], v78 offset:17392                  // 000000146A28: DBFC43F0 6500004E
	v_fma_mixlo_f16 v45, v47, s18, 0                           // 000000146A30: CC21002D 0200252F
	v_fma_mixhi_f16 v46, v50, s18, 0                           // 000000146A38: CC22002E 02002532
	v_fma_mixlo_f16 v47, v51, s18, 0                           // 000000146A40: CC21002F 02002533
	v_fma_mixhi_f16 v47, v52, s18, 0                           // 000000146A48: CC22002F 02002534
	v_fma_mixlo_f16 v50, v57, s18, 0                           // 000000146A50: CC210032 02002539
	v_fma_mixhi_f16 v50, v58, s18, 0                           // 000000146A58: CC220032 0200253A
	v_fma_mixlo_f16 v51, v59, s18, 0                           // 000000146A60: CC210033 0200253B
	v_fma_mixhi_f16 v51, v60, s18, 0                           // 000000146A68: CC220033 0200253C
	v_fma_mixlo_f16 v52, v61, s18, 0                           // 000000146A70: CC210034 0200253D
	v_fma_mixhi_f16 v52, v62, s18, 0                           // 000000146A78: CC220034 0200253E
	s_waitcnt lgkmcnt(5)                                       // 000000146A80: BF89FC57
	v_fma_mixlo_f16 v57, v105, s18, 0                          // 000000146A84: CC210039 02002569
	v_fma_mixhi_f16 v57, v106, s18, 0                          // 000000146A8C: CC220039 0200256A
	v_fma_mixlo_f16 v58, v107, s18, 0                          // 000000146A94: CC21003A 0200256B
	v_fma_mixhi_f16 v58, v108, s18, 0                          // 000000146A9C: CC22003A 0200256C
	ds_load_b128 v[105:108], v78 offset:25792                  // 000000146AA4: DBFC64C0 6900004E
	s_waitcnt lgkmcnt(5)                                       // 000000146AAC: BF89FC57
	v_fma_mixlo_f16 v59, v109, s18, 0                          // 000000146AB0: CC21003B 0200256D
	v_fma_mixhi_f16 v59, v110, s18, 0                          // 000000146AB8: CC22003B 0200256E
	v_fma_mixlo_f16 v60, v111, s18, 0                          // 000000146AC0: CC21003C 0200256F
	v_fma_mixhi_f16 v60, v112, s18, 0                          // 000000146AC8: CC22003C 02002570
	s_waitcnt lgkmcnt(4)                                       // 000000146AD0: BF89FC47
	v_fma_mixlo_f16 v61, v113, s18, 0                          // 000000146AD4: CC21003D 02002571
	v_fma_mixhi_f16 v61, v114, s18, 0                          // 000000146ADC: CC22003D 02002572
	ds_load_b128 v[109:112], v78 offset:25824                  // 000000146AE4: DBFC64E0 6D00004E
	v_fma_mixlo_f16 v62, v115, s18, 0                          // 000000146AEC: CC21003E 02002573
	v_fma_mixhi_f16 v62, v116, s18, 0                          // 000000146AF4: CC22003E 02002574
	ds_load_b128 v[113:116], v78 offset:25840                  // 000000146AFC: DBFC64F0 7100004E
	s_waitcnt lgkmcnt(4)                                       // 000000146B04: BF89FC47
	v_fma_mixlo_f16 v63, v63, s18, 0                           // 000000146B08: CC21003F 0200253F
	v_fma_mixhi_f16 v63, v64, s18, 0                           // 000000146B10: CC22003F 02002540
	v_fma_mixlo_f16 v64, v65, s18, 0                           // 000000146B18: CC210040 02002541
	v_fma_mixhi_f16 v64, v66, s18, 0                           // 000000146B20: CC220040 02002542
	s_waitcnt lgkmcnt(3)                                       // 000000146B28: BF89FC37
	v_fma_mixlo_f16 v65, v101, s18, 0                          // 000000146B2C: CC210041 02002565
	v_fma_mixhi_f16 v65, v102, s18, 0                          // 000000146B34: CC220041 02002566
	v_fma_mixlo_f16 v66, v103, s18, 0                          // 000000146B3C: CC210042 02002567
	v_fma_mixhi_f16 v66, v104, s18, 0                          // 000000146B44: CC220042 02002568
	v_fma_mixlo_f16 v103, v117, s18, 0                         // 000000146B4C: CC210067 02002575
	s_waitcnt lgkmcnt(2)                                       // 000000146B54: BF89FC27
	v_fma_mixlo_f16 v101, v105, s18, 0                         // 000000146B58: CC210065 02002569
	v_fma_mixhi_f16 v101, v106, s18, 0                         // 000000146B60: CC220065 0200256A
	v_fma_mixlo_f16 v102, v107, s18, 0                         // 000000146B68: CC210066 0200256B
	v_fma_mixhi_f16 v102, v108, s18, 0                         // 000000146B70: CC220066 0200256C
	v_fma_mixhi_f16 v103, v118, s18, 0                         // 000000146B78: CC220067 02002576
	v_fma_mixlo_f16 v104, v119, s18, 0                         // 000000146B80: CC210068 02002577
	v_fma_mixhi_f16 v104, v120, s18, 0                         // 000000146B88: CC220068 02002578
	s_waitcnt lgkmcnt(1)                                       // 000000146B90: BF89FC17
	v_fma_mixlo_f16 v105, v109, s18, 0                         // 000000146B94: CC210069 0200256D
	v_fma_mixhi_f16 v105, v110, s18, 0                         // 000000146B9C: CC220069 0200256E
	v_fma_mixlo_f16 v106, v111, s18, 0                         // 000000146BA4: CC21006A 0200256F
	v_fma_mixhi_f16 v106, v112, s18, 0                         // 000000146BAC: CC22006A 02002570
	s_waitcnt lgkmcnt(0)                                       // 000000146BB4: BF89FC07
	v_fma_mixlo_f16 v107, v113, s18, 0                         // 000000146BB8: CC21006B 02002571
	v_fma_mixhi_f16 v107, v114, s18, 0                         // 000000146BC0: CC22006B 02002572
	v_fma_mixlo_f16 v108, v115, s18, 0                         // 000000146BC8: CC21006C 02002573
	v_fma_mixhi_f16 v108, v116, s18, 0                         // 000000146BD0: CC22006C 02002574
	v_wmma_f32_16x16x16_f16 v[11:18], v[35:42], v[59:66], v[11:18]// 000000146BD8: CC40400B 1C2E7723
	v_mov_b32_e32 v59, 0                                       // 000000146BE0: 7E760280
	v_wmma_f32_16x16x16_f16 v[27:34], v[35:42], v[43:50], v[27:34]// 000000146BE4: CC40401B 1C6E5723
	v_wmma_f32_16x16x16_f16 v[19:26], v[35:42], v[51:58], v[19:26]// 000000146BEC: CC404013 1C4E6723
	v_wmma_f32_16x16x16_f16 v[3:10], v[35:42], v[101:108], v[3:10]// 000000146BF4: CC404003 1C0ECB23
	.long 0xd7000a65                                           // 000000146BFC: D7000A65
	v_cndmask_b32_e32 v0, v81, v10, vcc_lo                     // 000000146C00: 02001551
	s_delay_alu instid0(VALU_DEP_1)                            // 000000146C04: BF870001
	v_add_co_ci_u32_e64 v102, null, s11, v82, s10              // 000000146C08: D5207C66 002AA40B
	v_mov_b32_e32 v60, v59                                     // 000000146C10: 7E78033B
	v_mov_b32_e32 v61, v59                                     // 000000146C14: 7E7A033B
	v_mov_b32_e32 v62, v59                                     // 000000146C18: 7E7C033B
	v_mov_b32_e32 v63, v59                                     // 000000146C1C: 7E7E033B
	v_mov_b32_e32 v64, v59                                     // 000000146C20: 7E80033B
	v_mov_b32_e32 v65, v59                                     // 000000146C24: 7E82033B
	v_mov_b32_e32 v66, v59                                     // 000000146C28: 7E84033B
	v_mov_b32_e32 v51, v59                                     // 000000146C2C: 7E66033B
	v_mov_b32_e32 v52, v59                                     // 000000146C30: 7E68033B
	v_mov_b32_e32 v53, v59                                     // 000000146C34: 7E6A033B
	v_mov_b32_e32 v54, v59                                     // 000000146C38: 7E6C033B
	v_mov_b32_e32 v55, v59                                     // 000000146C3C: 7E6E033B
	v_mov_b32_e32 v56, v59                                     // 000000146C40: 7E70033B
	v_mov_b32_e32 v57, v59                                     // 000000146C44: 7E72033B
	v_mov_b32_e32 v58, v59                                     // 000000146C48: 7E74033B
	v_mov_b32_e32 v43, v59                                     // 000000146C4C: 7E56033B
	v_mov_b32_e32 v44, v59                                     // 000000146C50: 7E58033B
	v_mov_b32_e32 v45, v59                                     // 000000146C54: 7E5A033B
	v_mov_b32_e32 v46, v59                                     // 000000146C58: 7E5C033B
	v_mov_b32_e32 v47, v59                                     // 000000146C5C: 7E5E033B
	v_mov_b32_e32 v48, v59                                     // 000000146C60: 7E60033B
	v_mov_b32_e32 v49, v59                                     // 000000146C64: 7E62033B
	v_mov_b32_e32 v50, v59                                     // 000000146C68: 7E64033B
	v_mov_b32_e32 v35, v59                                     // 000000146C6C: 7E46033B
	v_mov_b32_e32 v36, v59                                     // 000000146C70: 7E48033B
	v_mov_b32_e32 v37, v59                                     // 000000146C74: 7E4A033B
	v_mov_b32_e32 v38, v59                                     // 000000146C78: 7E4C033B
	v_mov_b32_e32 v39, v59                                     // 000000146C7C: 7E4E033B
	v_mov_b32_e32 v40, v59                                     // 000000146C80: 7E50033B
	v_mov_b32_e32 v41, v59                                     // 000000146C84: 7E52033B
	v_mov_b32_e32 v42, v59                                     // 000000146C88: 7E54033B
	s_mov_b32 s11, 0                                           // 000000146C8C: BE8B0080
	s_lshl_b32 s12, s44, 4                                     // 000000146C90: 840C842C
	v_lshl_add_u32 v127, s44, 5, v83                           // 000000146C94: D646007F 054D0A2C
	s_lshl_b64 s[46:47], s[12:13], 2                           // 000000146C9C: 84AE820C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000146CA0: BF870099
	.long 0xd7000a67                                           // 000000146CA4: D7000A67
	v_cndmask_b32_e32 v0, v101, v46, vcc_lo                    // 000000146CA8: 02005D65
	v_add_co_ci_u32_e64 v104, null, s47, v102, s10             // 000000146CAC: D5207C68 002ACC2F
	.long 0xd44a000a                                           // 000000146CB4: D44A000A
	v_cndmask_b32_e32 v1, s44, v75, vcc_lo                     // 000000146CB8: 0202962C
	s_add_i32 s44, s44, 1                                      // 000000146CBC: 812C812C
	s_clause 0x3                                               // 000000146CC0: BF850003
	global_load_b128 v[135:138], v[103:104], off               // 000000146CC4: DC5E0000 877C0067
	global_load_b128 v[139:142], v[103:104], off offset:16     // 000000146CCC: DC5E0010 8B7C0067
	global_load_b128 v[143:146], v[103:104], off offset:32     // 000000146CD4: DC5E0020 8F7C0067
	global_load_b128 v[147:150], v[103:104], off offset:48     // 000000146CDC: DC5E0030 937C0067
	ds_load_b128 v[103:106], v127                              // 000000146CE4: DBFC0000 6700007F
	ds_load_b128 v[107:110], v127 offset:16                    // 000000146CEC: DBFC0010 6B00007F
	ds_load_b128 v[115:118], v127 offset:2576                  // 000000146CF4: DBFC0A10 7300007F
	ds_load_b128 v[111:114], v127 offset:2560                  // 000000146CFC: DBFC0A00 6F00007F
	ds_load_b128 v[123:126], v127 offset:5136                  // 000000146D04: DBFC1410 7B00007F
	ds_load_b128 v[119:122], v127 offset:5120                  // 000000146D0C: DBFC1400 7700007F
	ds_load_b128 v[131:134], v127 offset:7696                  // 000000146D14: DBFC1E10 8300007F
	ds_load_b128 v[127:130], v127 offset:7680                  // 000000146D1C: DBFC1E00 7F00007F
	s_or_b32 s11, s10, s11                                     // 000000146D24: 8C0B0B0A
	s_waitcnt vmcnt(3)                                         // 000000146D28: BF890FF7
	v_fma_mixlo_f16 v135, v135, s18, 0                         // 000000146D2C: CC210087 02002587
	v_fma_mixhi_f16 v135, v136, s18, 0                         // 000000146D34: CC220087 02002588
	v_fma_mixlo_f16 v136, v137, s18, 0                         // 000000146D3C: CC210088 02002589
	v_fma_mixhi_f16 v136, v138, s18, 0                         // 000000146D44: CC220088 0200258A
	s_waitcnt vmcnt(2)                                         // 000000146D4C: BF890BF7
	v_fma_mixlo_f16 v137, v139, s18, 0                         // 000000146D50: CC210089 0200258B
	v_fma_mixhi_f16 v137, v140, s18, 0                         // 000000146D58: CC220089 0200258C
	v_fma_mixlo_f16 v138, v141, s18, 0                         // 000000146D60: CC21008A 0200258D
	v_fma_mixhi_f16 v138, v142, s18, 0                         // 000000146D68: CC22008A 0200258E
	s_waitcnt vmcnt(1)                                         // 000000146D70: BF8907F7
	v_fma_mixlo_f16 v139, v143, s18, 0                         // 000000146D74: CC21008B 0200258F
	v_fma_mixhi_f16 v139, v144, s18, 0                         // 000000146D7C: CC22008B 02002590
	v_fma_mixlo_f16 v140, v145, s18, 0                         // 000000146D84: CC21008C 02002591
	v_fma_mixhi_f16 v140, v146, s18, 0                         // 000000146D8C: CC22008C 02002592
	s_waitcnt vmcnt(0)                                         // 000000146D94: BF8903F7
	v_fma_mixlo_f16 v141, v147, s18, 0                         // 000000146D98: CC21008D 02002593
	v_fma_mixhi_f16 v141, v148, s18, 0                         // 000000146DA0: CC22008D 02002594
	v_fma_mixlo_f16 v142, v149, s18, 0                         // 000000146DA8: CC21008E 02002595
	v_fma_mixhi_f16 v142, v150, s18, 0                         // 000000146DB0: CC22008E 02002596
	s_waitcnt lgkmcnt(6)                                       // 000000146DB8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 000000146DBC: BF870001
	v_wmma_f32_16x16x16_f16 v[59:66], v[135:142], v[103:110], v[59:66]// 000000146DC0: CC40403B 1CEECF87
	s_waitcnt lgkmcnt(4)                                       // 000000146DC8: BF89FC47
	v_wmma_f32_16x16x16_f16 v[51:58], v[135:142], v[111:118], v[51:58]// 000000146DCC: CC404033 1CCEDF87
	s_waitcnt lgkmcnt(2)                                       // 000000146DD4: BF89FC27
	v_wmma_f32_16x16x16_f16 v[43:50], v[135:142], v[119:126], v[43:50]// 000000146DD8: CC40402B 1CAEEF87
	s_waitcnt lgkmcnt(0)                                       // 000000146DE0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[35:42], v[135:142], v[127:134], v[35:42]// 000000146DE4: CC404023 1C8EFF87
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 000000146DEC: 917E0B7E
	s_cbranch_execnz 65447                                     // 000000146DF0: BFA6FFA7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3090>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000146DF4: 8C7E0B7E
	s_and_saveexec_b32 s10, s0                                 // 000000146DF8: BE8A2000
	s_cbranch_execnz 479                                       // 000000146DFC: BFA601DF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x397c>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146E00: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 000000146E04: BE8A2001
	s_cbranch_execnz 498                                       // 000000146E08: BFA601F2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x39d4>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146E0C: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 000000146E10: BE8A2004
	s_cbranch_execnz 517                                       // 000000146E14: BFA60205 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a2c>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146E18: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 000000146E1C: BE8A2005
	s_cbranch_execnz 536                                       // 000000146E20: BFA60218 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a84>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146E24: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 000000146E28: BE8A2006
	s_cbranch_execnz 555                                       // 000000146E2C: BFA6022B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3adc>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146E30: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 000000146E34: BE8A2007
	s_cbranch_execnz 574                                       // 000000146E38: BFA6023E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b34>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146E3C: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 000000146E40: BE8A2008
	s_cbranch_execnz 593                                       // 000000146E44: BFA60251 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b8c>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146E48: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 000000146E4C: BE8A2009
	s_cbranch_execnz 612                                       // 000000146E50: BFA60264 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3be4>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146E54: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 000000146E58: BE8A2000
	s_cbranch_execnz 630                                       // 000000146E5C: BFA60276 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3c38>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146E60: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 000000146E64: BE8A2001
	s_cbranch_execnz 649                                       // 000000146E68: BFA60289 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3c90>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146E6C: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 000000146E70: BE8A2004
	s_cbranch_execnz 668                                       // 000000146E74: BFA6029C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ce8>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146E78: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 000000146E7C: BE8A2005
	s_cbranch_execnz 687                                       // 000000146E80: BFA602AF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d40>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146E84: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 000000146E88: BE8A2006
	s_cbranch_execnz 706                                       // 000000146E8C: BFA602C2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d98>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146E90: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 000000146E94: BE8A2007
	s_cbranch_execnz 725                                       // 000000146E98: BFA602D5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3df0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146E9C: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 000000146EA0: BE8A2008
	s_cbranch_execnz 744                                       // 000000146EA4: BFA602E8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3e48>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146EA8: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 000000146EAC: BE8A2009
	s_cbranch_execnz 763                                       // 000000146EB0: BFA602FB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ea0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146EB4: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 000000146EB8: BE8A2000
	s_cbranch_execnz 781                                       // 000000146EBC: BFA6030D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ef4>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146EC0: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 000000146EC4: BE8A2001
	s_cbranch_execnz 800                                       // 000000146EC8: BFA60320 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3f4c>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146ECC: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 000000146ED0: BE8A2004
	s_cbranch_execnz 819                                       // 000000146ED4: BFA60333 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3fa4>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146ED8: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 000000146EDC: BE8A2005
	s_cbranch_execnz 838                                       // 000000146EE0: BFA60346 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ffc>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146EE4: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 000000146EE8: BE8A2006
	s_cbranch_execnz 857                                       // 000000146EEC: BFA60359 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4054>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146EF0: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 000000146EF4: BE8A2007
	s_cbranch_execnz 876                                       // 000000146EF8: BFA6036C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x40ac>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146EFC: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 000000146F00: BE8A2008
	s_cbranch_execnz 895                                       // 000000146F04: BFA6037F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4104>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146F08: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 000000146F0C: BE8A2009
	s_cbranch_execnz 914                                       // 000000146F10: BFA60392 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x415c>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146F14: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 000000146F18: BE8A2000
	s_cbranch_execnz 932                                       // 000000146F1C: BFA603A4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41b0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000146F20: 8C7E0A7E
	s_and_saveexec_b32 s0, s1                                  // 000000146F24: BE802001
	s_cbranch_execnz 951                                       // 000000146F28: BFA603B7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4208>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000146F2C: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000146F30: BE802004
	s_cbranch_execnz 970                                       // 000000146F34: BFA603CA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4260>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000146F38: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000146F3C: BE802005
	s_cbranch_execnz 989                                       // 000000146F40: BFA603DD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42b8>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000146F44: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000146F48: BE802006
	s_cbranch_execnz 1008                                      // 000000146F4C: BFA603F0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4310>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000146F50: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000146F54: BE802007
	s_cbranch_execnz 1027                                      // 000000146F58: BFA60403 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4368>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000146F5C: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 000000146F60: BE802008
	s_cbranch_execnz 1046                                      // 000000146F64: BFA60416 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x43c0>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000146F68: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000146F6C: BE802009
	s_cbranch_execz 18                                         // 000000146F70: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33bc>
	ds_load_b32 v3, v89 offset:56                              // 000000146F74: D8D80038 03000059
	s_waitcnt lgkmcnt(0)                                       // 000000146F7C: BF89FC07
	v_fmac_f32_e32 v42, v10, v3                                // 000000146F80: 5654070A
	v_mad_u64_u32 v[3:4], null, 0x3000, v100, v[69:70]         // 000000146F84: D6FE7C03 0516C8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000146F90: BF870092
	v_mul_f32_e32 v5, 0x3b800000, v42                          // 000000146F94: 100A54FF 3B800000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000146F9C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000146FA4: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000146FA8: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000146FB4: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000146FBC: 8C7E007E
	s_mul_f32 s0, s23, 0x3fb8aa3b                              // 000000146FC0: A200FF17 3FB8AA3B
	v_or_b32_e32 v4, s22, v73                                  // 000000146FC8: 38089216
	v_dual_mov_b32 v10, v71 :: v_dual_mov_b32 v11, v72         // 000000146FCC: CA100147 0A0A0148
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000146FD4: BF870009
	s_xor_b32 s1, s0, 0x80000000                               // 000000146FD8: 8D01FF00 80000000
	s_rndne_f32 s4, s0                                         // 000000146FE0: BE846300
	s_fmamk_f32 s1, s23, 0x3fb8aa3b, s1                        // 000000146FE4: A3010117 3FB8AA3B
	s_cmp_nlt_f32 s23, 0xc2ce8ed0                              // 000000146FEC: BF4EFF17 C2CE8ED0
	s_mov_b32 s5, 0                                            // 000000146FF4: BE850080
	s_sub_f32 s0, s0, s4                                       // 000000146FF8: A0800400
	s_fmamk_f32 s1, s23, 0x32a5705f, s1                        // 000000146FFC: A3010117 32A5705F
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000147004: BF87059B
	s_add_f32 s0, s0, s1                                       // 000000147008: A0000100
	v_exp_f32_e32 v3, s0                                       // 00000014700C: 7E064A00
	s_cvt_i32_f32 s0, s4                                       // 000000147010: BE806604
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000147014: BF870585
	.long 0xd71c0003                                           // 000000147018: D71C0003
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 00000014701C: 02000103
	s_cselect_b32 s0, -1, 0                                    // 000000147020: 980080C1
	s_cmp_ngt_f32 s23, 0x42b17218                              // 000000147024: BF4BFF17 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000014702C: BF870131
	v_cndmask_b32_e64 v3, 0, v3, s0                            // 000000147030: D5010003 00020680
	s_cselect_b32 s1, -1, 0                                    // 000000147038: 980180C1
	.long 0xd4440000                                           // 00000014703C: D4440000
	v_cndmask_b32_e32 v1, s41, v4, vcc_lo                      // 000000147040: 02020829
	v_cndmask_b32_e64 v12, 0x7f800000, v3, s1                  // 000000147044: D501000C 000606FF 7F800000
	s_branch 120                                               // 000000147050: BFA00078 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3634>
	s_set_inst_prefetch_distance 0x2                           // 000000147054: BF840002
	s_or_b32 exec_lo, exec_lo, s6                              // 000000147058: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000014705C: BF89FC07
	s_barrier                                                  // 000000147060: BFBD0000
	buffer_gl0_inv                                             // 000000147064: E0AC0000 00000000
	ds_load_b128 v[14:17], v84                                 // 00000014706C: DBFC0000 0E000054
	ds_load_b128 v[18:21], v84 offset:16                       // 000000147074: DBFC0010 12000054
	ds_load_b128 v[22:25], v92                                 // 00000014707C: DBFC0000 1600005C
	ds_load_b128 v[26:29], v92 offset:16                       // 000000147084: DBFC0010 1A00005C
	ds_load_b128 v[30:33], v84 offset:32                       // 00000014708C: DBFC0020 1E000054
	ds_load_b128 v[34:37], v84 offset:48                       // 000000147094: DBFC0030 22000054
	ds_load_b128 v[38:41], v92 offset:32                       // 00000014709C: DBFC0020 2600005C
	ds_load_b128 v[42:45], v92 offset:48                       // 0000001470A4: DBFC0030 2A00005C
	v_mov_b32_e32 v9, v2                                       // 0000001470AC: 7E120302
	v_mov_b32_e32 v3, v2                                       // 0000001470B0: 7E060302
	v_mov_b32_e32 v4, v2                                       // 0000001470B4: 7E080302
	v_mov_b32_e32 v5, v2                                       // 0000001470B8: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 0000001470BC: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 0000001470C0: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 0000001470C4: 7E100302
	v_mov_b32_e32 v53, v9                                      // 0000001470C8: 7E6A0309
	v_dual_mov_b32 v49, v5 :: v_dual_mov_b32 v48, v4           // 0000001470CC: CA100105 31300104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001470D4: BF870214
	v_dual_mov_b32 v51, v7 :: v_dual_mov_b32 v50, v6           // 0000001470D8: CA100107 33320106
	v_dual_mov_b32 v52, v8 :: v_dual_mov_b32 v47, v3           // 0000001470E0: CA100108 342E0103
	v_mov_b32_e32 v46, v2                                      // 0000001470E8: 7E5C0302
	ds_load_b128 v[58:61], v84 offset:80                       // 0000001470EC: DBFC0050 3A000054
	ds_load_b128 v[54:57], v84 offset:64                       // 0000001470F4: DBFC0040 36000054
	ds_load_b128 v[97:100], v92 offset:80                      // 0000001470FC: DBFC0050 6100005C
	ds_load_b128 v[93:96], v92 offset:64                       // 000000147104: DBFC0040 5D00005C
	ds_load_b128 v[105:108], v84 offset:112                    // 00000014710C: DBFC0070 69000054
	ds_load_b128 v[101:104], v84 offset:96                     // 000000147114: DBFC0060 65000054
	ds_load_2addr_b32 v[3:4], v13 offset0:16 offset1:18        // 00000014711C: D8DC1210 0300000D
	ds_load_b128 v[113:116], v92 offset:112                    // 000000147124: DBFC0070 7100005C
	ds_load_b128 v[109:112], v92 offset:96                     // 00000014712C: DBFC0060 6D00005C
	ds_load_2addr_b32 v[5:6], v13 offset0:20 offset1:22        // 000000147134: D8DC1614 0500000D
	ds_load_2addr_b32 v[7:8], v13 offset0:24 offset1:26        // 00000014713C: D8DC1A18 0700000D
	.long 0xd700010a                                           // 000000147144: D700010A
	v_cndmask_b32_e32 v1, 0x80, v10, vcc_lo                    // 000000147148: 020214FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147150: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v11, s1                  // 000000147154: D5207C0B 00061680
	s_waitcnt lgkmcnt(15)                                      // 00000014715C: BF89FCF7
	v_wmma_f32_16x16x16_f16 v[46:53], v[14:21], v[22:29], v[46:53]// 000000147160: CC40402E 1CBA2D0E
	ds_load_2addr_b32 v[14:15], v13 offset0:28 offset1:30      // 000000147168: D8DC1E1C 0E00000D
	s_add_i32 s1, s5, 32                                       // 000000147170: 8101A005
	s_cmpk_gt_u32 s5, 0x5f                                     // 000000147174: B585005F
	s_mov_b32 s5, s1                                           // 000000147178: BE850001
	s_waitcnt lgkmcnt(12)                                      // 00000014717C: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[46:53], v[30:37], v[38:45], v[46:53]// 000000147180: CC40402E 1CBA4D1E
	s_waitcnt lgkmcnt(8)                                       // 000000147188: BF89FC87
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014718C: BF870001
	v_wmma_f32_16x16x16_f16 v[46:53], v[54:61], v[93:100], v[46:53]// 000000147190: CC40402E 1CBABB36
	s_waitcnt lgkmcnt(5)                                       // 000000147198: BF89FC57
	v_mul_f32_e32 v3, v12, v3                                  // 00000014719C: 1006070C
	v_mul_f32_e32 v4, v12, v4                                  // 0000001471A0: 1008090C
	s_waitcnt lgkmcnt(2)                                       // 0000001471A4: BF89FC27
	v_mul_f32_e32 v5, v12, v5                                  // 0000001471A8: 100A0B0C
	v_wmma_f32_16x16x16_f16 v[46:53], v[101:108], v[109:116], v[46:53]// 0000001471AC: CC40402E 1CBADB65
	s_waitcnt lgkmcnt(1)                                       // 0000001471B4: BF89FC17
	v_mul_f32_e32 v7, v12, v7                                  // 0000001471B8: 100E0F0C
	v_mul_f32_e32 v6, v12, v6                                  // 0000001471BC: 100C0D0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001471C0: BF870193
	v_dual_mul_f32 v8, v12, v8 :: v_dual_fmac_f32 v3, 0x3b800000, v46// 0000001471C4: C8C0110C 08025CFF 3B800000
	v_fmac_f32_e32 v7, 0x3b800000, v50                         // 0000001471D0: 560E64FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 0000001471D8: BF89FC07
	v_mul_f32_e32 v9, v12, v14                                 // 0000001471DC: 10121D0C
	v_mul_f32_e32 v14, v12, v15                                // 0000001471E0: 101C1F0C
	v_dual_fmac_f32 v4, 0x3b800000, v47 :: v_dual_fmac_f32 v5, 0x3b800000, v48// 0000001471E4: C8005EFF 040460FF 3B800000
	v_fmac_f32_e32 v8, 0x3b800000, v51                         // 0000001471F0: 561066FF 3B800000
	v_fmac_f32_e32 v6, 0x3b800000, v49                         // 0000001471F8: 560C62FF 3B800000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000147200: BF870004
	v_dual_fmac_f32 v14, 0x3b800000, v53 :: v_dual_fmac_f32 v9, 0x3b800000, v52// 000000147204: C8006AFF 0E0868FF 3B800000
	ds_store_2addr_b32 v13, v3, v4 offset0:16 offset1:18       // 000000147210: D8381210 0004030D
	ds_store_2addr_b32 v13, v5, v6 offset0:20 offset1:22       // 000000147218: D8381614 0006050D
	ds_store_2addr_b32 v13, v7, v8 offset0:24 offset1:26       // 000000147220: D8381A18 0008070D
	ds_store_2addr_b32 v13, v9, v14 offset0:28 offset1:30      // 000000147228: D8381E1C 000E090D
	s_cbranch_scc1 62269                                       // 000000147230: BFA2F33D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x328>
	v_dual_mov_b32 v4, v10 :: v_dual_mov_b32 v5, v11           // 000000147234: CA10010A 0404010B
	v_dual_mov_b32 v6, v91 :: v_dual_mov_b32 v7, v74           // 00000014723C: CA10015B 0606014A
	s_mov_b32 s6, 0                                            // 000000147244: BE860080
	s_waitcnt_vscnt null, 0x0                                  // 000000147248: BC7C0000
	s_barrier                                                  // 00000014724C: BFBD0000
	buffer_gl0_inv                                             // 000000147250: E0AC0000 00000000
	s_set_inst_prefetch_distance 0x1                           // 000000147258: BF840001
	s_branch 26                                                // 00000014725C: BFA0001A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x36c8>
	s_nop 0                                                    // 000000147260: BF800000
	s_nop 0                                                    // 000000147264: BF800000
	s_nop 0                                                    // 000000147268: BF800000
	s_nop 0                                                    // 00000014726C: BF800000
	s_nop 0                                                    // 000000147270: BF800000
	s_nop 0                                                    // 000000147274: BF800000
	s_nop 0                                                    // 000000147278: BF800000
	s_nop 0                                                    // 00000014727C: BF800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000147280: 8C7E017E
	v_add_nc_u32_e32 v7, 0x80, v7                              // 000000147284: 4A0E0EFF 00000080
	.long 0xd7000404                                           // 00000014728C: D7000404
	v_cndmask_b32_e32 v0, v4, v136, vcc_lo                     // 000000147290: 02011104
	ds_store_b16 v6, v3 offset:10240                           // 000000147294: D87C2800 00000306
	v_add_nc_u32_e32 v6, 0x140, v6                             // 00000014729C: 4A0C0CFF 00000140
	.long 0xd4490001                                           // 0000001472A4: D4490001
	v_cndmask_b32_e32 v1, 0x37f, v7, vcc_lo                    // 0000001472A8: 02020EFF 0000037F
	v_add_co_ci_u32_e64 v5, null, 0, v5, s4                    // 0000001472B0: D5207C05 00120A80
	s_or_b32 s6, s1, s6                                        // 0000001472B8: 8C060601
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001472BC: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000001472C0: 917E067E
	s_cbranch_execz 13                                         // 0000001472C4: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x36fc>
	.long 0x7e063880                                           // 0000001472C8: 7E063880
	s_and_saveexec_b32 s1, s0                                  // 0000001472CC: BE812000
	s_cbranch_execz 65515                                      // 0000001472D0: BFA5FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3680>
	global_load_b32 v3, v[4:5], off                            // 0000001472D4: DC520000 037C0004
	ds_load_b32 v8, v90                                        // 0000001472DC: D8D80000 0800005A
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001472E4: BF890007
	v_mul_f32_e32 v3, v3, v8                                   // 0000001472E8: 10061103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001472EC: BF870001
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 0000001472F0: CC210003 02002503
	s_branch 65505                                             // 0000001472F8: BFA0FFE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3680>
	s_set_inst_prefetch_distance 0x2                           // 0000001472FC: BF840002
	s_or_b32 exec_lo, exec_lo, s6                              // 000000147300: 8C7E067E
	v_lshl_add_u32 v13, s5, 2, v85                             // 000000147304: D646000D 05550405
	s_waitcnt lgkmcnt(0)                                       // 00000014730C: BF89FC07
	s_barrier                                                  // 000000147310: BFBD0000
	buffer_gl0_inv                                             // 000000147314: E0AC0000 00000000
	ds_load_b128 v[14:17], v84                                 // 00000014731C: DBFC0000 0E000054
	ds_load_b128 v[18:21], v84 offset:16                       // 000000147324: DBFC0010 12000054
	ds_load_b128 v[22:25], v84 offset:32                       // 00000014732C: DBFC0020 16000054
	ds_load_b128 v[26:29], v84 offset:48                       // 000000147334: DBFC0030 1A000054
	ds_load_b128 v[30:33], v92                                 // 00000014733C: DBFC0000 1E00005C
	ds_load_b128 v[34:37], v92 offset:16                       // 000000147344: DBFC0010 2200005C
	ds_load_b128 v[38:41], v92 offset:32                       // 00000014734C: DBFC0020 2600005C
	ds_load_b128 v[42:45], v92 offset:48                       // 000000147354: DBFC0030 2A00005C
	ds_load_b128 v[50:53], v84 offset:80                       // 00000014735C: DBFC0050 32000054
	ds_load_b128 v[46:49], v84 offset:64                       // 000000147364: DBFC0040 2E000054
	ds_load_b128 v[58:61], v92 offset:80                       // 00000014736C: DBFC0050 3A00005C
	ds_load_b128 v[54:57], v92 offset:64                       // 000000147374: DBFC0040 3600005C
	ds_load_b128 v[97:100], v84 offset:112                     // 00000014737C: DBFC0070 61000054
	ds_load_b128 v[93:96], v84 offset:96                       // 000000147384: DBFC0060 5D000054
	ds_load_b128 v[105:108], v92 offset:112                    // 00000014738C: DBFC0070 6900005C
	ds_load_b128 v[101:104], v92 offset:96                     // 000000147394: DBFC0060 6500005C
	ds_load_2addr_b32 v[62:63], v13 offset1:2                  // 00000014739C: D8DC0200 3E00000D
	ds_load_2addr_b32 v[64:65], v13 offset0:4 offset1:6        // 0000001473A4: D8DC0604 4000000D
	ds_load_2addr_b32 v[117:118], v13 offset0:8 offset1:10     // 0000001473AC: D8DC0A08 7500000D
	ds_load_2addr_b32 v[119:120], v13 offset0:12 offset1:14    // 0000001473B4: D8DC0E0C 7700000D
	v_mov_b32_e32 v9, v2                                       // 0000001473BC: 7E120302
	v_mov_b32_e32 v3, v2                                       // 0000001473C0: 7E060302
	v_mov_b32_e32 v4, v2                                       // 0000001473C4: 7E080302
	v_mov_b32_e32 v5, v2                                       // 0000001473C8: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 0000001473CC: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 0000001473D0: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 0000001473D4: 7E100302
	v_mov_b32_e32 v116, v9                                     // 0000001473D8: 7EE80309
	v_dual_mov_b32 v112, v5 :: v_dual_mov_b32 v111, v4         // 0000001473DC: CA100105 706E0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001473E4: BF870214
	v_dual_mov_b32 v114, v7 :: v_dual_mov_b32 v113, v6         // 0000001473E8: CA100107 72700106
	v_dual_mov_b32 v115, v8 :: v_dual_mov_b32 v110, v3         // 0000001473F0: CA100108 736E0103
	v_mov_b32_e32 v109, v2                                     // 0000001473F8: 7EDA0302
	s_waitcnt lgkmcnt(3)                                       // 0000001473FC: BF89FC37
	v_dual_mov_b32 v4, v10 :: v_dual_mul_f32 v3, v12, v62      // 000000147400: CA06010A 04027D0C
	v_mul_f32_e32 v8, v12, v63                                 // 000000147408: 10107F0C
	s_waitcnt lgkmcnt(2)                                       // 00000014740C: BF89FC27
	v_mul_f32_e32 v9, v12, v64                                 // 000000147410: 1012810C
	v_wmma_f32_16x16x16_f16 v[109:116], v[14:21], v[30:37], v[109:116]// 000000147414: CC40406D 1DB63D0E
	v_mul_f32_e32 v14, v12, v65                                // 00000014741C: 101C830C
	s_waitcnt lgkmcnt(1)                                       // 000000147420: BF89FC17
	v_mul_f32_e32 v15, v12, v117                               // 000000147424: 101EEB0C
	v_dual_mul_f32 v16, v12, v118 :: v_dual_mov_b32 v5, v11    // 000000147428: C8D0ED0C 1004010B
	v_wmma_f32_16x16x16_f16 v[109:116], v[22:29], v[38:45], v[109:116]// 000000147430: CC40406D 1DB64D16
	v_dual_mov_b32 v6, v91 :: v_dual_mov_b32 v7, v74           // 000000147438: CA10015B 0606014A
	s_mov_b32 s6, 0                                            // 000000147440: BE860080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000147444: BF870092
	v_wmma_f32_16x16x16_f16 v[109:116], v[46:53], v[54:61], v[109:116]// 000000147448: CC40406D 1DB66D2E
	v_wmma_f32_16x16x16_f16 v[109:116], v[93:100], v[101:108], v[109:116]// 000000147450: CC40406D 1DB6CB5D
	s_waitcnt lgkmcnt(0)                                       // 000000147458: BF89FC07
	v_mul_f32_e32 v17, v12, v119                               // 00000014745C: 1022EF0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000147460: BF870192
	v_dual_mul_f32 v18, v12, v120 :: v_dual_fmac_f32 v3, 0x3b800000, v109// 000000147464: C8C0F10C 1202DAFF 3B800000
	v_dual_fmac_f32 v8, 0x3b800000, v110 :: v_dual_fmac_f32 v9, 0x3b800000, v111// 000000147470: C800DCFF 0808DEFF 3B800000
	v_dual_fmac_f32 v14, 0x3b800000, v112 :: v_dual_fmac_f32 v15, 0x3b800000, v113// 00000014747C: C800E0FF 0E0EE2FF 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000147488: BF870214
	v_dual_fmac_f32 v16, 0x3b800000, v114 :: v_dual_fmac_f32 v17, 0x3b800000, v115// 00000014748C: C800E4FF 1010E6FF 3B800000
	v_fmac_f32_e32 v18, 0x3b800000, v116                       // 000000147498: 5624E8FF 3B800000
	ds_store_2addr_b32 v13, v3, v8 offset1:2                   // 0000001474A0: D8380200 0008030D
	ds_store_2addr_b32 v13, v9, v14 offset0:4 offset1:6        // 0000001474A8: D8380604 000E090D
	ds_store_2addr_b32 v13, v15, v16 offset0:8 offset1:10      // 0000001474B0: D8380A08 00100F0D
	ds_store_2addr_b32 v13, v17, v18 offset0:12 offset1:14     // 0000001474B8: D8380E0C 0012110D
	s_waitcnt lgkmcnt(0)                                       // 0000001474C0: BF89FC07
	s_barrier                                                  // 0000001474C4: BFBD0000
	buffer_gl0_inv                                             // 0000001474C8: E0AC0000 00000000
	s_set_inst_prefetch_distance 0x1                           // 0000001474D0: BF840001
	s_branch 28                                                // 0000001474D4: BFA0001C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3948>
	s_nop 0                                                    // 0000001474D8: BF800000
	s_nop 0                                                    // 0000001474DC: BF800000
	s_nop 0                                                    // 0000001474E0: BF800000
	s_nop 0                                                    // 0000001474E4: BF800000
	s_nop 0                                                    // 0000001474E8: BF800000
	s_nop 0                                                    // 0000001474EC: BF800000
	s_nop 0                                                    // 0000001474F0: BF800000
	s_nop 0                                                    // 0000001474F4: BF800000
	s_nop 0                                                    // 0000001474F8: BF800000
	s_nop 0                                                    // 0000001474FC: BF800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000147500: 8C7E017E
	v_add_nc_u32_e32 v7, 0x80, v7                              // 000000147504: 4A0E0EFF 00000080
	.long 0xd7000404                                           // 00000014750C: D7000404
	v_cndmask_b32_e32 v0, v4, v136, vcc_lo                     // 000000147510: 02011104
	ds_store_b16 v6, v3 offset:10240                           // 000000147514: D87C2800 00000306
	v_add_nc_u32_e32 v6, 0x140, v6                             // 00000014751C: 4A0C0CFF 00000140
	.long 0xd4490001                                           // 000000147524: D4490001
	v_cndmask_b32_e32 v1, 0x37f, v7, vcc_lo                    // 000000147528: 02020EFF 0000037F
	v_add_co_ci_u32_e64 v5, null, 0, v5, s4                    // 000000147530: D5207C05 00120A80
	s_or_b32 s6, s1, s6                                        // 000000147538: 8C060601
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014753C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000147540: 917E067E
	s_cbranch_execz 65219                                      // 000000147544: BFA5FEC3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3454>
	.long 0x7e063880                                           // 000000147548: 7E063880
	s_and_saveexec_b32 s1, s0                                  // 00000014754C: BE812000
	s_cbranch_execz 65515                                      // 000000147550: BFA5FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3900>
	global_load_b32 v3, v[4:5], off offset:64                  // 000000147554: DC520040 037C0004
	ds_load_b32 v8, v90                                        // 00000014755C: D8D80000 0800005A
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000147564: BF890007
	v_mul_f32_e32 v3, v3, v8                                   // 000000147568: 10061103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014756C: BF870001
	v_fma_mixlo_f16 v3, v3, s18, 0                             // 000000147570: CC210003 02002503
	s_branch 65505                                             // 000000147578: BFA0FFE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3900>
	ds_load_b32 v101, v89                                      // 00000014757C: D8D80000 65000059
	s_waitcnt lgkmcnt(0)                                       // 000000147584: BF89FC07
	v_fma_f32 v27, v27, v101, v59                              // 000000147588: D613001B 04EECB1B
	v_mad_u64_u32 v[101:102], null, 0x3000, v93, v[69:70]      // 000000147590: D6FE7C65 0516BAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014759C: BF870092
	v_mul_f32_e32 v27, 0x3b800000, v27                         // 0000001475A0: 103636FF 3B800000
	v_bfe_u32 v59, v27, 16, 1                                  // 0000001475A8: D610003B 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001475B0: BF870001
	v_add3_u32 v27, v27, v59, 0x7fff                           // 0000001475B4: D655001B 03FE771B 00007FFF
	global_store_d16_hi_b16 v[101:102], v27, off               // 0000001475C0: DC960000 007C1B65
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001475C8: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 0000001475CC: BE8A2001
	s_cbranch_execz 65038                                      // 0000001475D0: BFA5FE0E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x320c>
	ds_load_b32 v27, v89 offset:8                              // 0000001475D4: D8D80008 1B000059
	s_waitcnt lgkmcnt(0)                                       // 0000001475DC: BF89FC07
	v_fma_f32 v27, v28, v27, v60                               // 0000001475E0: D613001B 04F2371C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001475E8: BF870121
	v_mul_f32_e32 v59, 0x3b800000, v27                         // 0000001475EC: 107636FF 3B800000
	v_mad_u64_u32 v[27:28], null, 0x3000, v94, v[69:70]        // 0000001475F4: D6FE7C1B 0516BCFF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 000000147600: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147608: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000014760C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[27:28], v59, off                 // 000000147618: DC960000 007C3B1B
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147620: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 000000147624: BE8A2004
	s_cbranch_execz 65019                                      // 000000147628: BFA5FDFB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3218>
	ds_load_b32 v27, v89 offset:16                             // 00000014762C: D8D80010 1B000059
	s_waitcnt lgkmcnt(0)                                       // 000000147634: BF89FC07
	v_fma_f32 v27, v29, v27, v61                               // 000000147638: D613001B 04F6371D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147640: BF870121
	v_mul_f32_e32 v29, 0x3b800000, v27                         // 000000147644: 103A36FF 3B800000
	v_mad_u64_u32 v[27:28], null, 0x3000, v95, v[69:70]        // 00000014764C: D6FE7C1B 0516BEFF 00003000
	v_bfe_u32 v59, v29, 16, 1                                  // 000000147658: D610003B 0205211D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147660: BF870001
	v_add3_u32 v29, v29, v59, 0x7fff                           // 000000147664: D655001D 03FE771D 00007FFF
	global_store_d16_hi_b16 v[27:28], v29, off                 // 000000147670: DC960000 007C1D1B
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147678: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 00000014767C: BE8A2005
	s_cbranch_execz 65000                                      // 000000147680: BFA5FDE8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3224>
	ds_load_b32 v27, v89 offset:24                             // 000000147684: D8D80018 1B000059
	s_waitcnt lgkmcnt(0)                                       // 00000014768C: BF89FC07
	v_fma_f32 v27, v30, v27, v62                               // 000000147690: D613001B 04FA371E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147698: BF870121
	v_mul_f32_e32 v29, 0x3b800000, v27                         // 00000014769C: 103A36FF 3B800000
	v_mad_u64_u32 v[27:28], null, 0x3000, v96, v[69:70]        // 0000001476A4: D6FE7C1B 0516C0FF 00003000
	v_bfe_u32 v30, v29, 16, 1                                  // 0000001476B0: D610001E 0205211D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001476B8: BF870001
	v_add3_u32 v29, v29, v30, 0x7fff                           // 0000001476BC: D655001D 03FE3D1D 00007FFF
	global_store_d16_hi_b16 v[27:28], v29, off                 // 0000001476C8: DC960000 007C1D1B
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001476D0: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 0000001476D4: BE8A2006
	s_cbranch_execz 64981                                      // 0000001476D8: BFA5FDD5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3230>
	ds_load_b32 v27, v89 offset:32                             // 0000001476DC: D8D80020 1B000059
	s_waitcnt lgkmcnt(0)                                       // 0000001476E4: BF89FC07
	v_fma_f32 v27, v31, v27, v63                               // 0000001476E8: D613001B 04FE371F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001476F0: BF870121
	v_mul_f32_e32 v29, 0x3b800000, v27                         // 0000001476F4: 103A36FF 3B800000
	v_mad_u64_u32 v[27:28], null, 0x3000, v97, v[69:70]        // 0000001476FC: D6FE7C1B 0516C2FF 00003000
	v_bfe_u32 v30, v29, 16, 1                                  // 000000147708: D610001E 0205211D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147710: BF870001
	v_add3_u32 v29, v29, v30, 0x7fff                           // 000000147714: D655001D 03FE3D1D 00007FFF
	global_store_d16_hi_b16 v[27:28], v29, off                 // 000000147720: DC960000 007C1D1B
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147728: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 00000014772C: BE8A2007
	s_cbranch_execz 64962                                      // 000000147730: BFA5FDC2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x323c>
	ds_load_b32 v27, v89 offset:40                             // 000000147734: D8D80028 1B000059
	s_waitcnt lgkmcnt(0)                                       // 00000014773C: BF89FC07
	v_fma_f32 v27, v32, v27, v64                               // 000000147740: D613001B 05023720
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147748: BF870121
	v_mul_f32_e32 v29, 0x3b800000, v27                         // 00000014774C: 103A36FF 3B800000
	v_mad_u64_u32 v[27:28], null, 0x3000, v98, v[69:70]        // 000000147754: D6FE7C1B 0516C4FF 00003000
	v_bfe_u32 v30, v29, 16, 1                                  // 000000147760: D610001E 0205211D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147768: BF870001
	v_add3_u32 v29, v29, v30, 0x7fff                           // 00000014776C: D655001D 03FE3D1D 00007FFF
	global_store_d16_hi_b16 v[27:28], v29, off                 // 000000147778: DC960000 007C1D1B
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147780: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 000000147784: BE8A2008
	s_cbranch_execz 64943                                      // 000000147788: BFA5FDAF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3248>
	ds_load_b32 v27, v89 offset:48                             // 00000014778C: D8D80030 1B000059
	s_waitcnt lgkmcnt(0)                                       // 000000147794: BF89FC07
	v_fma_f32 v27, v33, v27, v65                               // 000000147798: D613001B 05063721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001477A0: BF870121
	v_mul_f32_e32 v29, 0x3b800000, v27                         // 0000001477A4: 103A36FF 3B800000
	v_mad_u64_u32 v[27:28], null, 0x3000, v99, v[69:70]        // 0000001477AC: D6FE7C1B 0516C6FF 00003000
	v_bfe_u32 v30, v29, 16, 1                                  // 0000001477B8: D610001E 0205211D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001477C0: BF870001
	v_add3_u32 v29, v29, v30, 0x7fff                           // 0000001477C4: D655001D 03FE3D1D 00007FFF
	global_store_d16_hi_b16 v[27:28], v29, off                 // 0000001477D0: DC960000 007C1D1B
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001477D8: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 0000001477DC: BE8A2009
	s_cbranch_execz 64924                                      // 0000001477E0: BFA5FD9C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3254>
	ds_load_b32 v27, v89 offset:56                             // 0000001477E4: D8D80038 1B000059
	s_waitcnt lgkmcnt(0)                                       // 0000001477EC: BF89FC07
	v_fmac_f32_e32 v66, v34, v27                               // 0000001477F0: 56843722
	v_mad_u64_u32 v[27:28], null, 0x3000, v100, v[69:70]       // 0000001477F4: D6FE7C1B 0516C8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000147800: BF870092
	v_mul_f32_e32 v29, 0x3b800000, v66                         // 000000147804: 103A84FF 3B800000
	v_bfe_u32 v30, v29, 16, 1                                  // 00000014780C: D610001E 0205211D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147814: BF870001
	v_add3_u32 v29, v29, v30, 0x7fff                           // 000000147818: D655001D 03FE3D1D 00007FFF
	global_store_d16_hi_b16 v[27:28], v29, off                 // 000000147824: DC960000 007C1D1B
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014782C: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 000000147830: BE8A2000
	s_cbranch_execz 64906                                      // 000000147834: BFA5FD8A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3260>
	ds_load_b32 v27, v89                                       // 000000147838: D8D80000 1B000059
	s_waitcnt lgkmcnt(0)                                       // 000000147840: BF89FC07
	v_fma_f32 v19, v19, v27, v51                               // 000000147844: D6130013 04CE3713
	v_mad_u64_u32 v[27:28], null, 0x3000, v93, v[69:70]        // 00000014784C: D6FE7C1B 0516BAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000147858: BF870092
	v_mul_f32_e32 v19, 0x3b800000, v19                         // 00000014785C: 102626FF 3B800000
	v_bfe_u32 v29, v19, 16, 1                                  // 000000147864: D610001D 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014786C: BF870001
	v_add3_u32 v19, v19, v29, 0x7fff                           // 000000147870: D6550013 03FE3B13 00007FFF
	global_store_d16_hi_b16 v[27:28], v19, off offset:32       // 00000014787C: DC960020 007C131B
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147884: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 000000147888: BE8A2001
	s_cbranch_execz 64887                                      // 00000014788C: BFA5FD77 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x326c>
	ds_load_b32 v19, v89 offset:8                              // 000000147890: D8D80008 13000059
	s_waitcnt lgkmcnt(0)                                       // 000000147898: BF89FC07
	v_fma_f32 v19, v20, v19, v52                               // 00000014789C: D6130013 04D22714
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001478A4: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v19                         // 0000001478A8: 103626FF 3B800000
	v_mad_u64_u32 v[19:20], null, 0x3000, v94, v[69:70]        // 0000001478B0: D6FE7C13 0516BCFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001478BC: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001478C4: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001478C8: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[19:20], v27, off offset:32       // 0000001478D4: DC960020 007C1B13
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001478DC: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 0000001478E0: BE8A2004
	s_cbranch_execz 64868                                      // 0000001478E4: BFA5FD64 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3278>
	ds_load_b32 v19, v89 offset:16                             // 0000001478E8: D8D80010 13000059
	s_waitcnt lgkmcnt(0)                                       // 0000001478F0: BF89FC07
	v_fma_f32 v19, v21, v19, v53                               // 0000001478F4: D6130013 04D62715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001478FC: BF870121
	v_mul_f32_e32 v21, 0x3b800000, v19                         // 000000147900: 102A26FF 3B800000
	v_mad_u64_u32 v[19:20], null, 0x3000, v95, v[69:70]        // 000000147908: D6FE7C13 0516BEFF 00003000
	v_bfe_u32 v27, v21, 16, 1                                  // 000000147914: D610001B 02052115
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014791C: BF870001
	v_add3_u32 v21, v21, v27, 0x7fff                           // 000000147920: D6550015 03FE3715 00007FFF
	global_store_d16_hi_b16 v[19:20], v21, off offset:32       // 00000014792C: DC960020 007C1513
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147934: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 000000147938: BE8A2005
	s_cbranch_execz 64849                                      // 00000014793C: BFA5FD51 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3284>
	ds_load_b32 v19, v89 offset:24                             // 000000147940: D8D80018 13000059
	s_waitcnt lgkmcnt(0)                                       // 000000147948: BF89FC07
	v_fma_f32 v19, v22, v19, v54                               // 00000014794C: D6130013 04DA2716
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147954: BF870121
	v_mul_f32_e32 v21, 0x3b800000, v19                         // 000000147958: 102A26FF 3B800000
	v_mad_u64_u32 v[19:20], null, 0x3000, v96, v[69:70]        // 000000147960: D6FE7C13 0516C0FF 00003000
	v_bfe_u32 v22, v21, 16, 1                                  // 00000014796C: D6100016 02052115
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147974: BF870001
	v_add3_u32 v21, v21, v22, 0x7fff                           // 000000147978: D6550015 03FE2D15 00007FFF
	global_store_d16_hi_b16 v[19:20], v21, off offset:32       // 000000147984: DC960020 007C1513
	s_or_b32 exec_lo, exec_lo, s10                             // 00000014798C: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 000000147990: BE8A2006
	s_cbranch_execz 64830                                      // 000000147994: BFA5FD3E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3290>
	ds_load_b32 v19, v89 offset:32                             // 000000147998: D8D80020 13000059
	s_waitcnt lgkmcnt(0)                                       // 0000001479A0: BF89FC07
	v_fma_f32 v19, v23, v19, v55                               // 0000001479A4: D6130013 04DE2717
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001479AC: BF870121
	v_mul_f32_e32 v21, 0x3b800000, v19                         // 0000001479B0: 102A26FF 3B800000
	v_mad_u64_u32 v[19:20], null, 0x3000, v97, v[69:70]        // 0000001479B8: D6FE7C13 0516C2FF 00003000
	v_bfe_u32 v22, v21, 16, 1                                  // 0000001479C4: D6100016 02052115
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001479CC: BF870001
	v_add3_u32 v21, v21, v22, 0x7fff                           // 0000001479D0: D6550015 03FE2D15 00007FFF
	global_store_d16_hi_b16 v[19:20], v21, off offset:32       // 0000001479DC: DC960020 007C1513
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001479E4: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 0000001479E8: BE8A2007
	s_cbranch_execz 64811                                      // 0000001479EC: BFA5FD2B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x329c>
	ds_load_b32 v19, v89 offset:40                             // 0000001479F0: D8D80028 13000059
	s_waitcnt lgkmcnt(0)                                       // 0000001479F8: BF89FC07
	v_fma_f32 v19, v24, v19, v56                               // 0000001479FC: D6130013 04E22718
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147A04: BF870121
	v_mul_f32_e32 v21, 0x3b800000, v19                         // 000000147A08: 102A26FF 3B800000
	v_mad_u64_u32 v[19:20], null, 0x3000, v98, v[69:70]        // 000000147A10: D6FE7C13 0516C4FF 00003000
	v_bfe_u32 v22, v21, 16, 1                                  // 000000147A1C: D6100016 02052115
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147A24: BF870001
	v_add3_u32 v21, v21, v22, 0x7fff                           // 000000147A28: D6550015 03FE2D15 00007FFF
	global_store_d16_hi_b16 v[19:20], v21, off offset:32       // 000000147A34: DC960020 007C1513
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147A3C: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 000000147A40: BE8A2008
	s_cbranch_execz 64792                                      // 000000147A44: BFA5FD18 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x32a8>
	ds_load_b32 v19, v89 offset:48                             // 000000147A48: D8D80030 13000059
	s_waitcnt lgkmcnt(0)                                       // 000000147A50: BF89FC07
	v_fma_f32 v19, v25, v19, v57                               // 000000147A54: D6130013 04E62719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147A5C: BF870121
	v_mul_f32_e32 v21, 0x3b800000, v19                         // 000000147A60: 102A26FF 3B800000
	v_mad_u64_u32 v[19:20], null, 0x3000, v99, v[69:70]        // 000000147A68: D6FE7C13 0516C6FF 00003000
	v_bfe_u32 v22, v21, 16, 1                                  // 000000147A74: D6100016 02052115
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147A7C: BF870001
	v_add3_u32 v21, v21, v22, 0x7fff                           // 000000147A80: D6550015 03FE2D15 00007FFF
	global_store_d16_hi_b16 v[19:20], v21, off offset:32       // 000000147A8C: DC960020 007C1513
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147A94: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 000000147A98: BE8A2009
	s_cbranch_execz 64773                                      // 000000147A9C: BFA5FD05 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x32b4>
	ds_load_b32 v19, v89 offset:56                             // 000000147AA0: D8D80038 13000059
	s_waitcnt lgkmcnt(0)                                       // 000000147AA8: BF89FC07
	v_fmac_f32_e32 v58, v26, v19                               // 000000147AAC: 5674271A
	v_mad_u64_u32 v[19:20], null, 0x3000, v100, v[69:70]       // 000000147AB0: D6FE7C13 0516C8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000147ABC: BF870092
	v_mul_f32_e32 v21, 0x3b800000, v58                         // 000000147AC0: 102A74FF 3B800000
	v_bfe_u32 v22, v21, 16, 1                                  // 000000147AC8: D6100016 02052115
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147AD0: BF870001
	v_add3_u32 v21, v21, v22, 0x7fff                           // 000000147AD4: D6550015 03FE2D15 00007FFF
	global_store_d16_hi_b16 v[19:20], v21, off offset:32       // 000000147AE0: DC960020 007C1513
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147AE8: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 000000147AEC: BE8A2000
	s_cbranch_execz 64755                                      // 000000147AF0: BFA5FCF3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x32c0>
	ds_load_b32 v19, v89                                       // 000000147AF4: D8D80000 13000059
	s_waitcnt lgkmcnt(0)                                       // 000000147AFC: BF89FC07
	v_fma_f32 v11, v11, v19, v43                               // 000000147B00: D613000B 04AE270B
	v_mad_u64_u32 v[19:20], null, 0x3000, v93, v[69:70]        // 000000147B08: D6FE7C13 0516BAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000147B14: BF870092
	v_mul_f32_e32 v11, 0x3b800000, v11                         // 000000147B18: 101616FF 3B800000
	v_bfe_u32 v21, v11, 16, 1                                  // 000000147B20: D6100015 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147B28: BF870001
	v_add3_u32 v11, v11, v21, 0x7fff                           // 000000147B2C: D655000B 03FE2B0B 00007FFF
	global_store_d16_hi_b16 v[19:20], v11, off offset:64       // 000000147B38: DC960040 007C0B13
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147B40: 8C7E0A7E
	s_and_saveexec_b32 s10, s1                                 // 000000147B44: BE8A2001
	s_cbranch_execz 64736                                      // 000000147B48: BFA5FCE0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x32cc>
	ds_load_b32 v11, v89 offset:8                              // 000000147B4C: D8D80008 0B000059
	s_waitcnt lgkmcnt(0)                                       // 000000147B54: BF89FC07
	v_fma_f32 v11, v12, v11, v44                               // 000000147B58: D613000B 04B2170C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147B60: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v11                         // 000000147B64: 102616FF 3B800000
	v_mad_u64_u32 v[11:12], null, 0x3000, v94, v[69:70]        // 000000147B6C: D6FE7C0B 0516BCFF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 000000147B78: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147B80: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000147B84: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[11:12], v19, off offset:64       // 000000147B90: DC960040 007C130B
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147B98: 8C7E0A7E
	s_and_saveexec_b32 s10, s4                                 // 000000147B9C: BE8A2004
	s_cbranch_execz 64717                                      // 000000147BA0: BFA5FCCD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x32d8>
	ds_load_b32 v11, v89 offset:16                             // 000000147BA4: D8D80010 0B000059
	s_waitcnt lgkmcnt(0)                                       // 000000147BAC: BF89FC07
	v_fma_f32 v11, v13, v11, v45                               // 000000147BB0: D613000B 04B6170D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147BB8: BF870121
	v_mul_f32_e32 v13, 0x3b800000, v11                         // 000000147BBC: 101A16FF 3B800000
	v_mad_u64_u32 v[11:12], null, 0x3000, v95, v[69:70]        // 000000147BC4: D6FE7C0B 0516BEFF 00003000
	v_bfe_u32 v19, v13, 16, 1                                  // 000000147BD0: D6100013 0205210D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147BD8: BF870001
	v_add3_u32 v13, v13, v19, 0x7fff                           // 000000147BDC: D655000D 03FE270D 00007FFF
	global_store_d16_hi_b16 v[11:12], v13, off offset:64       // 000000147BE8: DC960040 007C0D0B
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147BF0: 8C7E0A7E
	s_and_saveexec_b32 s10, s5                                 // 000000147BF4: BE8A2005
	s_cbranch_execz 64698                                      // 000000147BF8: BFA5FCBA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x32e4>
	ds_load_b32 v11, v89 offset:24                             // 000000147BFC: D8D80018 0B000059
	s_waitcnt lgkmcnt(0)                                       // 000000147C04: BF89FC07
	v_fma_f32 v11, v14, v11, v46                               // 000000147C08: D613000B 04BA170E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147C10: BF870121
	v_mul_f32_e32 v13, 0x3b800000, v11                         // 000000147C14: 101A16FF 3B800000
	v_mad_u64_u32 v[11:12], null, 0x3000, v96, v[69:70]        // 000000147C1C: D6FE7C0B 0516C0FF 00003000
	v_bfe_u32 v14, v13, 16, 1                                  // 000000147C28: D610000E 0205210D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147C30: BF870001
	v_add3_u32 v13, v13, v14, 0x7fff                           // 000000147C34: D655000D 03FE1D0D 00007FFF
	global_store_d16_hi_b16 v[11:12], v13, off offset:64       // 000000147C40: DC960040 007C0D0B
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147C48: 8C7E0A7E
	s_and_saveexec_b32 s10, s6                                 // 000000147C4C: BE8A2006
	s_cbranch_execz 64679                                      // 000000147C50: BFA5FCA7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x32f0>
	ds_load_b32 v11, v89 offset:32                             // 000000147C54: D8D80020 0B000059
	s_waitcnt lgkmcnt(0)                                       // 000000147C5C: BF89FC07
	v_fma_f32 v11, v15, v11, v47                               // 000000147C60: D613000B 04BE170F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147C68: BF870121
	v_mul_f32_e32 v13, 0x3b800000, v11                         // 000000147C6C: 101A16FF 3B800000
	v_mad_u64_u32 v[11:12], null, 0x3000, v97, v[69:70]        // 000000147C74: D6FE7C0B 0516C2FF 00003000
	v_bfe_u32 v14, v13, 16, 1                                  // 000000147C80: D610000E 0205210D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147C88: BF870001
	v_add3_u32 v13, v13, v14, 0x7fff                           // 000000147C8C: D655000D 03FE1D0D 00007FFF
	global_store_d16_hi_b16 v[11:12], v13, off offset:64       // 000000147C98: DC960040 007C0D0B
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147CA0: 8C7E0A7E
	s_and_saveexec_b32 s10, s7                                 // 000000147CA4: BE8A2007
	s_cbranch_execz 64660                                      // 000000147CA8: BFA5FC94 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x32fc>
	ds_load_b32 v11, v89 offset:40                             // 000000147CAC: D8D80028 0B000059
	s_waitcnt lgkmcnt(0)                                       // 000000147CB4: BF89FC07
	v_fma_f32 v11, v16, v11, v48                               // 000000147CB8: D613000B 04C21710
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147CC0: BF870121
	v_mul_f32_e32 v13, 0x3b800000, v11                         // 000000147CC4: 101A16FF 3B800000
	v_mad_u64_u32 v[11:12], null, 0x3000, v98, v[69:70]        // 000000147CCC: D6FE7C0B 0516C4FF 00003000
	v_bfe_u32 v14, v13, 16, 1                                  // 000000147CD8: D610000E 0205210D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147CE0: BF870001
	v_add3_u32 v13, v13, v14, 0x7fff                           // 000000147CE4: D655000D 03FE1D0D 00007FFF
	global_store_d16_hi_b16 v[11:12], v13, off offset:64       // 000000147CF0: DC960040 007C0D0B
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147CF8: 8C7E0A7E
	s_and_saveexec_b32 s10, s8                                 // 000000147CFC: BE8A2008
	s_cbranch_execz 64641                                      // 000000147D00: BFA5FC81 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3308>
	ds_load_b32 v11, v89 offset:48                             // 000000147D04: D8D80030 0B000059
	s_waitcnt lgkmcnt(0)                                       // 000000147D0C: BF89FC07
	v_fma_f32 v11, v17, v11, v49                               // 000000147D10: D613000B 04C61711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147D18: BF870121
	v_mul_f32_e32 v13, 0x3b800000, v11                         // 000000147D1C: 101A16FF 3B800000
	v_mad_u64_u32 v[11:12], null, 0x3000, v99, v[69:70]        // 000000147D24: D6FE7C0B 0516C6FF 00003000
	v_bfe_u32 v14, v13, 16, 1                                  // 000000147D30: D610000E 0205210D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147D38: BF870001
	v_add3_u32 v13, v13, v14, 0x7fff                           // 000000147D3C: D655000D 03FE1D0D 00007FFF
	global_store_d16_hi_b16 v[11:12], v13, off offset:64       // 000000147D48: DC960040 007C0D0B
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147D50: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 000000147D54: BE8A2009
	s_cbranch_execz 64622                                      // 000000147D58: BFA5FC6E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3314>
	ds_load_b32 v11, v89 offset:56                             // 000000147D5C: D8D80038 0B000059
	s_waitcnt lgkmcnt(0)                                       // 000000147D64: BF89FC07
	v_fmac_f32_e32 v50, v18, v11                               // 000000147D68: 56641712
	v_mad_u64_u32 v[11:12], null, 0x3000, v100, v[69:70]       // 000000147D6C: D6FE7C0B 0516C8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000147D78: BF870092
	v_mul_f32_e32 v13, 0x3b800000, v50                         // 000000147D7C: 101A64FF 3B800000
	v_bfe_u32 v14, v13, 16, 1                                  // 000000147D84: D610000E 0205210D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147D8C: BF870001
	v_add3_u32 v13, v13, v14, 0x7fff                           // 000000147D90: D655000D 03FE1D0D 00007FFF
	global_store_d16_hi_b16 v[11:12], v13, off offset:64       // 000000147D9C: DC960040 007C0D0B
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147DA4: 8C7E0A7E
	s_and_saveexec_b32 s10, s0                                 // 000000147DA8: BE8A2000
	s_cbranch_execz 64604                                      // 000000147DAC: BFA5FC5C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3320>
	ds_load_b32 v11, v89                                       // 000000147DB0: D8D80000 0B000059
	s_waitcnt lgkmcnt(0)                                       // 000000147DB8: BF89FC07
	v_fma_f32 v3, v3, v11, v35                                 // 000000147DBC: D6130003 048E1703
	v_mad_u64_u32 v[11:12], null, 0x3000, v93, v[69:70]        // 000000147DC4: D6FE7C0B 0516BAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000147DD0: BF870092
	v_mul_f32_e32 v3, 0x3b800000, v3                           // 000000147DD4: 100606FF 3B800000
	v_bfe_u32 v13, v3, 16, 1                                   // 000000147DDC: D610000D 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147DE4: BF870001
	v_add3_u32 v3, v3, v13, 0x7fff                             // 000000147DE8: D6550003 03FE1B03 00007FFF
	global_store_d16_hi_b16 v[11:12], v3, off offset:96        // 000000147DF4: DC960060 007C030B
	s_or_b32 exec_lo, exec_lo, s10                             // 000000147DFC: 8C7E0A7E
	s_and_saveexec_b32 s0, s1                                  // 000000147E00: BE802001
	s_cbranch_execz 64585                                      // 000000147E04: BFA5FC49 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x332c>
	ds_load_b32 v3, v89 offset:8                               // 000000147E08: D8D80008 03000059
	s_waitcnt lgkmcnt(0)                                       // 000000147E10: BF89FC07
	v_fma_f32 v3, v4, v3, v36                                  // 000000147E14: D6130003 04920704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147E1C: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v3                          // 000000147E20: 101606FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v94, v[69:70]          // 000000147E28: D6FE7C03 0516BCFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 000000147E34: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147E3C: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000147E40: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[3:4], v11, off offset:96         // 000000147E4C: DC960060 007C0B03
	s_or_b32 exec_lo, exec_lo, s0                              // 000000147E54: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000147E58: BE802004
	s_cbranch_execz 64566                                      // 000000147E5C: BFA5FC36 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3338>
	ds_load_b32 v3, v89 offset:16                              // 000000147E60: D8D80010 03000059
	s_waitcnt lgkmcnt(0)                                       // 000000147E68: BF89FC07
	v_fma_f32 v3, v5, v3, v37                                  // 000000147E6C: D6130003 04960705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147E74: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000147E78: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v95, v[69:70]          // 000000147E80: D6FE7C03 0516BEFF 00003000
	v_bfe_u32 v11, v5, 16, 1                                   // 000000147E8C: D610000B 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147E94: BF870001
	v_add3_u32 v5, v5, v11, 0x7fff                             // 000000147E98: D6550005 03FE1705 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000147EA4: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000147EAC: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000147EB0: BE802005
	s_cbranch_execz 64547                                      // 000000147EB4: BFA5FC23 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3344>
	ds_load_b32 v3, v89 offset:24                              // 000000147EB8: D8D80018 03000059
	s_waitcnt lgkmcnt(0)                                       // 000000147EC0: BF89FC07
	v_fma_f32 v3, v6, v3, v38                                  // 000000147EC4: D6130003 049A0706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147ECC: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000147ED0: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v96, v[69:70]          // 000000147ED8: D6FE7C03 0516C0FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000147EE4: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147EEC: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000147EF0: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000147EFC: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000147F04: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000147F08: BE802006
	s_cbranch_execz 64528                                      // 000000147F0C: BFA5FC10 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3350>
	ds_load_b32 v3, v89 offset:32                              // 000000147F10: D8D80020 03000059
	s_waitcnt lgkmcnt(0)                                       // 000000147F18: BF89FC07
	v_fma_f32 v3, v7, v3, v39                                  // 000000147F1C: D6130003 049E0707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147F24: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000147F28: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v97, v[69:70]          // 000000147F30: D6FE7C03 0516C2FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000147F3C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147F44: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000147F48: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000147F54: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000147F5C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000147F60: BE802007
	s_cbranch_execz 64509                                      // 000000147F64: BFA5FBFD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x335c>
	ds_load_b32 v3, v89 offset:40                              // 000000147F68: D8D80028 03000059
	s_waitcnt lgkmcnt(0)                                       // 000000147F70: BF89FC07
	v_fma_f32 v3, v8, v3, v40                                  // 000000147F74: D6130003 04A20708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147F7C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000147F80: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v98, v[69:70]          // 000000147F88: D6FE7C03 0516C4FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000147F94: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147F9C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000147FA0: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000147FAC: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000147FB4: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 000000147FB8: BE802008
	s_cbranch_execz 64490                                      // 000000147FBC: BFA5FBEA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3368>
	ds_load_b32 v3, v89 offset:48                              // 000000147FC0: D8D80030 03000059
	s_waitcnt lgkmcnt(0)                                       // 000000147FC8: BF89FC07
	v_fma_f32 v3, v9, v3, v41                                  // 000000147FCC: D6130003 04A60709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000147FD4: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 000000147FD8: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v99, v[69:70]          // 000000147FE0: D6FE7C03 0516C6FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000147FEC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000147FF4: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000147FF8: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 000000148004: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014800C: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 000000148010: BE802009
	s_cbranch_execnz 64471                                     // 000000148014: BFA6FBD7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3374>
	s_branch 64488                                             // 000000148018: BFA0FBE8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33bc>
	v_dual_mov_b32 v2, v74 :: v_dual_mov_b32 v3, v1            // 00000014801C: CA10014A 02020101
	s_add_u32 s0, s33, s36                                     // 000000148024: 80002421
	.long 0xd73c0000                                           // 000000148028: D73C0000
	v_cndmask_b32_e32 v1, 9, v67, vcc_lo                       // 00000014802C: 02028689
	s_addc_u32 s1, s40, s37                                    // 000000148030: 82012528
	s_add_u32 s2, s38, s34                                     // 000000148034: 80022226
	s_addc_u32 s3, s39, s35                                    // 000000148038: 82032327
	s_add_u32 s0, s2, s0                                       // 00000014803C: 80000002
	s_addc_u32 s1, s3, s1                                      // 000000148040: 82010103
	v_lshlrev_b32_e32 v4, 2, v73                               // 000000148044: 30089282
	.long 0xd7006a00                                           // 000000148048: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000014804C: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000148050: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000148054: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000014805C: BE810080
	.long 0xd7006a00                                           // 000000148060: D7006A00
	v_cndmask_b32_e32 v1, v0, v4, vcc_lo                       // 000000148064: 02020900
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000148068: D5207C01 01AA0280
	v_mul_u32_u24_e32 v4, 0x210, v73                           // 000000148070: 160892FF 00000210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000148078: BF870093
	.long 0xd7006a00                                           // 00000014807C: D7006A00
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 000000148080: 0202000E
	v_add_co_ci_u32_e64 v1, null, s15, v1, vcc_lo              // 000000148084: D5207C01 01AA020F
	s_delay_alu instid0(VALU_DEP_3)                            // 00000014808C: BF870003
	v_lshl_add_u32 v3, v3, 2, v4                               // 000000148090: D6460003 04110503
	s_nop 0                                                    // 000000148098: BF800000
	s_nop 0                                                    // 00000014809C: BF800000
	s_nop 0                                                    // 0000001480A0: BF800000
	s_nop 0                                                    // 0000001480A4: BF800000
	s_nop 0                                                    // 0000001480A8: BF800000
	s_nop 0                                                    // 0000001480AC: BF800000
	s_nop 0                                                    // 0000001480B0: BF800000
	s_nop 0                                                    // 0000001480B4: BF800000
	s_nop 0                                                    // 0000001480B8: BF800000
	s_nop 0                                                    // 0000001480BC: BF800000
	ds_load_b32 v4, v3 offset:12800                            // 0000001480C0: D8D83200 04000003
	v_add_nc_u32_e32 v2, 0x80, v2                              // 0000001480C8: 4A0404FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001480D0: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001480D4: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v2                        // 0000001480D8: 7C9204FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001480E0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001480E4: BF89FC07
	global_store_b32 v[0:1], v4, off                           // 0000001480E8: DC6A0000 007C0400
	.long 0xd7000000                                           // 0000001480F0: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 0000001480F4: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000001480FC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000148104: 917E017E
	s_cbranch_execnz 65517                                     // 000000148108: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi1EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x44c0>
	s_nop 0                                                    // 00000014810C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000148110: BFB60003
	s_endpgm                                                   // 000000148114: BFB00000
		...

