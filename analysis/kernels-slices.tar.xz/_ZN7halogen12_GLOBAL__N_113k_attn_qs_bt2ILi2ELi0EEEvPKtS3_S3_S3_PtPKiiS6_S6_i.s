0000000000197800 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 000000197800: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 000000197804: F4080300 F8000020
	s_load_b128 s[16:19], s[0:1], 0x38                         // 00000019780C: F4080400 F8000038
	s_mov_b32 s20, s3                                          // 000000197814: BE940003
	s_ashr_i32 s3, s2, 31                                      // 000000197818: 86039F02
	s_load_b32 s21, s[0:1], 0x48                               // 00000019781C: F4000540 F8000048
	s_waitcnt lgkmcnt(0)                                       // 000000197824: BF89FC07
	s_load_b32 s14, s[14:15], null                             // 000000197828: F4000387 F8000000
	s_load_b256 s[4:11], s[0:1], null                          // 000000197830: F40C0100 F8000000
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000197838: 84808202
	s_waitcnt lgkmcnt(0)                                       // 00000019783C: BF89FC07
	s_add_i32 s3, s14, s2                                      // 000000197840: 8103020E
	s_add_u32 s0, s18, s0                                      // 000000197844: 80000012
	s_addc_u32 s1, s19, s1                                     // 000000197848: 82010113
	s_add_i32 s15, s3, 1                                       // 00000019784C: 810F8103
	s_load_b32 s14, s[0:1], null                               // 000000197850: F4000380 F8000000
	s_ashr_i32 s0, s15, 31                                     // 000000197858: 86009F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000019785C: BF870499
	s_lshr_b32 s0, s0, 30                                      // 000000197860: 85009E00
	s_add_i32 s0, s15, s0                                      // 000000197864: 8100000F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000197868: BF870009
	s_and_b32 s1, s0, -4                                       // 00000019786C: 8B01C400
	s_ashr_i32 s18, s0, 2                                      // 000000197870: 86128200
	s_sub_i32 s15, s3, s1                                      // 000000197874: 818F0103
	s_mul_hi_i32 s1, s21, s2                                   // 000000197878: 97010215
	s_cmp_gt_i32 s15, -1                                       // 00000019787C: BF02C10F
	s_mul_i32 s0, s21, s2                                      // 000000197880: 96000215
	s_cselect_b32 s3, -1, 0                                    // 000000197884: 980380C1
	s_mov_b32 s19, s18                                         // 000000197888: BE930012
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000019788C: 8B6A037E
	s_cbranch_vccnz 15                                         // 000000197890: BFA4000F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd0>
	s_lshl_b64 s[22:23], s[0:1], 2                             // 000000197894: 84968200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000197898: BF8704D9
	s_add_u32 s19, s16, s22                                    // 00000019789C: 80131610
	s_addc_u32 s21, s17, s23                                   // 0000001978A0: 82151711
	s_waitcnt lgkmcnt(0)                                       // 0000001978A4: BF89FC07
	s_max_i32 s22, s14, 1                                      // 0000001978A8: 8A16810E
	s_mov_b32 s23, 0                                           // 0000001978AC: BE970080
	s_lshl_b64 s[22:23], s[22:23], 2                           // 0000001978B0: 84968216
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001978B4: BF870009
	s_add_u32 s19, s19, s22                                    // 0000001978B8: 80131613
	s_addc_u32 s21, s21, s23                                   // 0000001978BC: 82151715
	s_add_u32 s22, s19, -4                                     // 0000001978C0: 8016C413
	s_addc_u32 s23, s21, -1                                    // 0000001978C4: 8217C115
	s_load_b32 s19, s[22:23], null                             // 0000001978C8: F40004CB F8000000
	v_cndmask_b32_e64 v1, 0, 1, s3                             // 0000001978D0: D5010001 000D0280
	s_mov_b32 s23, exec_lo                                     // 0000001978D8: BE97007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001978DC: BF8704B1
	v_readfirstlane_b32 s3, v1                                 // 0000001978E0: 7E060501
	s_waitcnt lgkmcnt(0)                                       // 0000001978E4: BF89FC07
	s_add_i32 s21, s14, s3                                     // 0000001978E8: 8115030E
	s_add_i32 s3, s21, 3                                       // 0000001978EC: 81038315
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001978F0: BF870499
	s_and_b32 s22, s3, -4                                      // 0000001978F4: 8B16C403
	.long 0xd4c4007e                                           // 0000001978F8: D4C4007E
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 0000001978FC: 02020016
	s_cbranch_execz 45                                         // 000000197900: BFA5002D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v3, 2, v0      // 000000197904: CA220100 04020082
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000019790C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000197910: BF8700A9
	s_add_u32 s0, s16, s0                                      // 000000197914: 80000010
	s_addc_u32 s1, s17, s1                                     // 000000197918: 82010111
	.long 0xd7000001                                           // 00000019791C: D7000001
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 000000197920: 02020600
	s_delay_alu instid0(VALU_DEP_1)                            // 000000197924: BF870001
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 000000197928: D5207C02 00010001
	s_mov_b32 s1, 0                                            // 000000197930: BE810080
	s_set_inst_prefetch_distance 0x1                           // 000000197934: BF840001
	s_branch 18                                                // 000000197938: BFA00012 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x184>
	s_nop 0                                                    // 00000019793C: BF800000
	s_or_b32 exec_lo, exec_lo, s0                              // 000000197940: 8C7E007E
	v_add_nc_u32_e32 v4, 64, v4                                // 000000197944: 4A0808C0
	.long 0xd7000001                                           // 000000197948: D7000001
	v_cndmask_b32_e32 v1, 0x100, v1, vcc_lo                    // 00000019794C: 020202FF 00000100
	s_waitcnt vmcnt(0)                                         // 000000197954: BF8903F7
	ds_store_b32 v3, v5 offset:1024                            // 000000197958: D8340400 00000503
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 000000197960: D5207C02 00020480
	v_cmp_le_i32_e32 vcc_lo, s22, v4                           // 000000197968: 7C860816
	v_add_nc_u32_e32 v3, 0x100, v3                             // 00000019796C: 4A0606FF 00000100
	s_or_b32 s1, vcc_lo, s1                                    // 000000197974: 8C01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000197978: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000019797C: 917E017E
	s_cbranch_execz 13                                         // 000000197980: BFA5000D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	s_mov_b32 s0, exec_lo                                      // 000000197984: BE80007E
	.long 0xd4c3007e                                           // 000000197988: D4C3007E
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 00000019798C: 0202080E
	s_xor_b32 s0, exec_lo, s0                                  // 000000197990: 8D00007E
	v_mov_b32_e32 v5, s18                                      // 000000197994: 7E0A0212
	v_cmp_gt_i32_e32 vcc_lo, s21, v4                           // 000000197998: 7C880815
	s_delay_alu instid0(VALU_DEP_2)                            // 00000019799C: BF870002
	v_cndmask_b32_e32 v5, s19, v5, vcc_lo                      // 0000001979A0: 020A0A13
	s_and_not1_saveexec_b32 s0, s0                             // 0000001979A4: BE803000
	s_cbranch_execz 65509                                      // 0000001979A8: BFA5FFE5 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	global_load_b32 v5, v[1:2], off                            // 0000001979AC: DC520000 057C0001
	s_branch 65506                                             // 0000001979B4: BFA0FFE2 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	s_set_inst_prefetch_distance 0x2                           // 0000001979B8: BF840002
	s_or_b32 exec_lo, exec_lo, s23                             // 0000001979BC: 8C7E177E
	v_lshrrev_b32_e32 v7, 5, v0                                // 0000001979C0: 320E0085
	s_mov_b32 s1, exec_lo                                      // 0000001979C4: BE81007E
	v_cmpx_gt_u32_e32 0x180, v0                                // 0000001979C8: 7D9800FF 00000180
	s_cbranch_execz 48                                         // 0000001979D0: BFA50030 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x294>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001979D4: BF870002
	v_mul_u32_u24_e32 v1, 0x210, v7                            // 0000001979D8: 16020EFF 00000210
	v_and_b32_e32 v2, 31, v0                                   // 0000001979E0: 3604009F
	s_mul_i32 s16, s20, 0xc00                                  // 0000001979E4: 9610FF14 00000C00
	s_mul_i32 s18, s2, 0x3000                                  // 0000001979EC: 9612FF02 00003000
	s_ashr_i32 s17, s16, 31                                    // 0000001979F4: 86119F10
	s_mul_hi_i32 s0, s2, 0x3000                                // 0000001979F8: 9700FF02 00003000
	s_lshl_b64 s[16:17], s[16:17], 1                           // 000000197A00: 84908110
	v_lshl_add_u32 v4, v2, 4, v1                               // 000000197A04: D6460004 04050902
	v_lshlrev_b32_e32 v1, 4, v0                                // 000000197A0C: 30020084
	s_add_u32 s4, s4, s16                                      // 000000197A10: 80041004
	s_addc_u32 s5, s5, s17                                     // 000000197A14: 82051105
	s_add_u32 s4, s4, s18                                      // 000000197A18: 80041204
	s_addc_u32 s0, s5, s0                                      // 000000197A1C: 82000005
	.long 0xd7000401                                           // 000000197A20: D7000401
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000197A24: 02020204
	v_lshl_or_b32 v3, v0, 3, 0xfffffe00                        // 000000197A28: D6560003 03FD0700 FFFFFE00
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 000000197A34: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 000000197A3C: BE840080
	global_load_b128 v[8:11], v[1:2], off                      // 000000197A40: DC5E0000 087C0001
	v_add_nc_u32_e32 v3, 0x200, v3                             // 000000197A48: 4A0606FF 00000200
	.long 0xd7006a01                                           // 000000197A50: D7006A01
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 000000197A54: 020202FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000197A5C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000197A60: D5207C02 01AA0480
	.long 0xd4490000                                           // 000000197A68: D4490000
	v_cndmask_b32_e32 v1, 0x9ff, v3, vcc_lo                    // 000000197A6C: 020206FF 000009FF
	s_or_b32 s4, s0, s4                                        // 000000197A74: 8C040400
	s_waitcnt vmcnt(0)                                         // 000000197A78: BF8903F7
	ds_store_b128 v4, v[8:11] offset:9232                      // 000000197A7C: DB7C2410 00000804
	v_add_nc_u32_e32 v4, 0x420, v4                             // 000000197A84: 4A0808FF 00000420
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000197A8C: 917E047E
	s_cbranch_execnz 65515                                     // 000000197A90: BFA6FFEB <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x240>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000197A94: 8C7E017E
	v_lshlrev_b32_e32 v147, 7, v7                              // 000000197A98: 31260E87
	s_ashr_i32 s3, s3, 2                                       // 000000197A9C: 86038203
	s_mov_b32 s0, 0                                            // 000000197AA0: BE800080
	s_cmp_gt_i32 s3, 0                                         // 000000197AA4: BF028003
	s_waitcnt lgkmcnt(0)                                       // 000000197AA8: BF89FC07
	s_barrier                                                  // 000000197AAC: BFBD0000
	buffer_gl0_inv                                             // 000000197AB0: E0AC0000 00000000
	s_cbranch_scc1 2                                           // 000000197AB8: BFA20002 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x2c4>
	v_lshlrev_b32_e32 v8, 7, v7                                // 000000197ABC: 30100E87
	s_branch 1                                                 // 000000197AC0: BFA00001 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x2c8>
	s_mov_b32 s0, -1                                           // 000000197AC4: BE8000C1
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v145, 15, v0        // 000000197AC8: CA240080 0690008F
	v_bfe_u32 v146, v0, 4, 1                                   // 000000197AD0: D6100092 02050900
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000197AD8: 916A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000197ADC: BF870002
	v_mov_b32_e32 v5, v6                                       // 000000197AE0: 7E0A0306
	v_mov_b32_e32 v4, v6                                       // 000000197AE4: 7E080306
	v_mov_b32_e32 v3, v6                                       // 000000197AE8: 7E060306
	v_mov_b32_e32 v2, v6                                       // 000000197AEC: 7E040306
	v_mov_b32_e32 v1, v6                                       // 000000197AF0: 7E020306
	v_mov_b32_e32 v14, v6                                      // 000000197AF4: 7E1C0306
	v_mov_b32_e32 v13, v6                                      // 000000197AF8: 7E1A0306
	v_mov_b32_e32 v12, v6                                      // 000000197AFC: 7E180306
	v_mov_b32_e32 v11, v6                                      // 000000197B00: 7E160306
	v_mov_b32_e32 v10, v6                                      // 000000197B04: 7E140306
	v_mov_b32_e32 v9, v6                                       // 000000197B08: 7E120306
	v_mov_b32_e32 v22, v6                                      // 000000197B0C: 7E2C0306
	v_mov_b32_e32 v21, v6                                      // 000000197B10: 7E2A0306
	v_mov_b32_e32 v20, v6                                      // 000000197B14: 7E280306
	v_mov_b32_e32 v19, v6                                      // 000000197B18: 7E260306
	v_mov_b32_e32 v18, v6                                      // 000000197B1C: 7E240306
	v_mov_b32_e32 v17, v6                                      // 000000197B20: 7E220306
	v_mov_b32_e32 v30, v6                                      // 000000197B24: 7E3C0306
	v_mov_b32_e32 v29, v6                                      // 000000197B28: 7E3A0306
	v_mov_b32_e32 v28, v6                                      // 000000197B2C: 7E380306
	v_mov_b32_e32 v27, v6                                      // 000000197B30: 7E360306
	v_mov_b32_e32 v26, v6                                      // 000000197B34: 7E340306
	v_mov_b32_e32 v25, v6                                      // 000000197B38: 7E320306
	v_mov_b32_e32 v38, v6                                      // 000000197B3C: 7E4C0306
	v_mov_b32_e32 v37, v6                                      // 000000197B40: 7E4A0306
	v_mov_b32_e32 v36, v6                                      // 000000197B44: 7E480306
	v_mov_b32_e32 v35, v6                                      // 000000197B48: 7E460306
	v_mov_b32_e32 v34, v6                                      // 000000197B4C: 7E440306
	v_mov_b32_e32 v33, v6                                      // 000000197B50: 7E420306
	v_mov_b32_e32 v46, v6                                      // 000000197B54: 7E5C0306
	v_mov_b32_e32 v45, v6                                      // 000000197B58: 7E5A0306
	v_mov_b32_e32 v44, v6                                      // 000000197B5C: 7E580306
	v_mov_b32_e32 v43, v6                                      // 000000197B60: 7E560306
	v_mov_b32_e32 v42, v6                                      // 000000197B64: 7E540306
	v_mov_b32_e32 v41, v6                                      // 000000197B68: 7E520306
	v_mov_b32_e32 v54, v6                                      // 000000197B6C: 7E6C0306
	v_mov_b32_e32 v53, v6                                      // 000000197B70: 7E6A0306
	v_mov_b32_e32 v52, v6                                      // 000000197B74: 7E680306
	v_mov_b32_e32 v51, v6                                      // 000000197B78: 7E660306
	v_mov_b32_e32 v50, v6                                      // 000000197B7C: 7E640306
	v_mov_b32_e32 v49, v6                                      // 000000197B80: 7E620306
	v_mov_b32_e32 v62, v6                                      // 000000197B84: 7E7C0306
	v_mov_b32_e32 v61, v6                                      // 000000197B88: 7E7A0306
	v_mov_b32_e32 v60, v6                                      // 000000197B8C: 7E780306
	v_mov_b32_e32 v59, v6                                      // 000000197B90: 7E760306
	v_mov_b32_e32 v58, v6                                      // 000000197B94: 7E740306
	v_mov_b32_e32 v57, v6                                      // 000000197B98: 7E720306
	v_mov_b32_e32 v134, v6                                     // 000000197B9C: 7F0C0306
	v_mov_b32_e32 v133, v6                                     // 000000197BA0: 7F0A0306
	v_mov_b32_e32 v132, v6                                     // 000000197BA4: 7F080306
	v_mov_b32_e32 v131, v6                                     // 000000197BA8: 7F060306
	v_mov_b32_e32 v148, v6                                     // 000000197BAC: 7F280306
	v_mov_b32_e32 v130, v6                                     // 000000197BB0: 7F040306
	s_cbranch_vccnz 1576                                       // 000000197BB4: BFA40628 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1c58>
	s_ashr_i32 s21, s20, 31                                    // 000000197BB8: 86159F14
	s_lshl2_add_u32 s4, s14, s15                               // 000000197BBC: 87840F0E
	s_lshl_b64 s[0:1], s[20:21], 11                            // 000000197BC0: 84808B14
	s_add_i32 s4, s4, 1                                        // 000000197BC4: 81048104
	s_add_u32 s5, s6, s0                                       // 000000197BC8: 80050006
	s_addc_u32 s6, s7, s1                                      // 000000197BCC: 82060107
	s_lshl_b64 s[0:1], s[20:21], 8                             // 000000197BD0: 84808814
	v_or_b32_e32 v23, 16, v147                                 // 000000197BD4: 382F2690
	v_or_b32_e32 v6, s0, v145                                  // 000000197BD8: 380D2200
	v_mov_b32_e32 v4, s1                                       // 000000197BDC: 7E080201
	v_mov_b32_e32 v10, s1                                      // 000000197BE0: 7E140201
	v_mov_b32_e32 v16, s1                                      // 000000197BE4: 7E200201
	v_or_b32_e32 v31, 32, v147                                 // 000000197BE8: 383F26A0
	v_or_b32_e32 v3, v6, v147                                  // 000000197BEC: 38072706
	.long 0xd7006a41                                           // 000000197BF0: D7006A41
	v_cndmask_b32_e32 v1, 0x200, v6, vcc_lo                    // 000000197BF4: 02020CFF 00000200
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000197BFC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v10, vcc_lo               // 000000197C00: D5207C02 01AA1480
	.long 0xd73c0008                                           // 000000197C08: D73C0008
	v_cndmask_b32_e32 v1, 3, v3, vcc_lo                        // 000000197C0C: 02020683
	.long 0xd7006a42                                           // 000000197C10: D7006A42
	v_cndmask_b32_e32 v1, 0x400, v6, vcc_lo                    // 000000197C14: 02020CFF 00000400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000197C1C: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v10, vcc_lo               // 000000197C20: D5207C05 01AA1480
	.long 0xd7006a43                                           // 000000197C28: D7006A43
	v_cndmask_b32_e32 v1, 0x600, v6, vcc_lo                    // 000000197C2C: 02020CFF 00000600
	v_or_b32_e32 v1, v65, v147                                 // 000000197C34: 38032741
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 000000197C38: D5207C0A 01AA1480
	v_or_b32_e32 v4, v66, v147                                 // 000000197C40: 38092742
	.long 0xd7006a0d                                           // 000000197C44: D7006A0D
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000197C48: 02021008
	s_delay_alu instid0(VALU_DEP_1)                            // 000000197C4C: BF870001
	v_add_co_ci_u32_e64 v14, null, s9, v9, vcc_lo              // 000000197C50: D5207C0E 01AA1209
	v_or_b32_e32 v9, v67, v147                                 // 000000197C58: 38132743
	.long 0xd73c000b                                           // 000000197C5C: D73C000B
	v_cndmask_b32_e32 v1, 3, v1, vcc_lo                        // 000000197C60: 02020283
	.long 0xd73c0003                                           // 000000197C64: D73C0003
	v_cndmask_b32_e32 v1, 3, v4, vcc_lo                        // 000000197C68: 02020883
	v_or_b32_e32 v15, v6, v23                                  // 000000197C6C: 381E2F06
	v_or_b32_e32 v1, v65, v23                                  // 000000197C70: 38022F41
	.long 0xd73c0008                                           // 000000197C74: D73C0008
	v_cndmask_b32_e32 v1, 3, v9, vcc_lo                        // 000000197C78: 02021283
	v_dual_mov_b32 v24, s1 :: v_dual_mov_b32 v129, 0           // 000000197C7C: CA100001 18800080
	.long 0xd7006a0b                                           // 000000197C84: D7006A0B
	v_cndmask_b32_e32 v1, s8, v11, vcc_lo                      // 000000197C88: 02021608
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000197C8C: BF8700A1
	v_add_co_ci_u32_e64 v12, null, s9, v12, vcc_lo             // 000000197C90: D5207C0C 01AA1809
	.long 0xd7006a11                                           // 000000197C98: D7006A11
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000197C9C: 02020608
	v_add_co_ci_u32_e64 v18, null, s9, v4, vcc_lo              // 000000197CA0: D5207C12 01AA0809
	.long 0xd7006a13                                           // 000000197CA8: D7006A13
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000197CAC: 02021008
	v_or_b32_e32 v4, v66, v23                                  // 000000197CB0: 38082F42
	.long 0xd73c000f                                           // 000000197CB4: D73C000F
	v_cndmask_b32_e32 v1, 3, v15, vcc_lo                       // 000000197CB8: 02021E83
	v_add_co_ci_u32_e64 v20, null, s9, v9, vcc_lo              // 000000197CBC: D5207C14 01AA1209
	v_or_b32_e32 v9, v67, v23                                  // 000000197CC4: 38122F43
	.long 0xd73c0015                                           // 000000197CC8: D73C0015
	v_cndmask_b32_e32 v1, 3, v1, vcc_lo                        // 000000197CCC: 02020283
	.long 0xd73c0003                                           // 000000197CD0: D73C0003
	v_cndmask_b32_e32 v1, 3, v4, vcc_lo                        // 000000197CD4: 02020883
	.long 0xd7006a0f                                           // 000000197CD8: D7006A0F
	v_cndmask_b32_e32 v1, s8, v15, vcc_lo                      // 000000197CDC: 02021E08
	s_delay_alu instid0(VALU_DEP_4)                            // 000000197CE0: BF870004
	.long 0xd73c0008                                           // 000000197CE4: D73C0008
	v_cndmask_b32_e32 v1, 3, v9, vcc_lo                        // 000000197CE8: 02021283
	v_add_co_ci_u32_e64 v16, null, s9, v16, vcc_lo             // 000000197CEC: D5207C10 01AA2009
	.long 0xd7006a15                                           // 000000197CF4: D7006A15
	v_cndmask_b32_e32 v1, s8, v21, vcc_lo                      // 000000197CF8: 02022A08
	v_or_b32_e32 v23, v6, v31                                  // 000000197CFC: 382E3F06
	v_add_co_ci_u32_e64 v22, null, s9, v22, vcc_lo             // 000000197D00: D5207C16 01AA2C09
	.long 0xd7006a19                                           // 000000197D08: D7006A19
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000197D0C: 02020608
	v_or_b32_e32 v1, v65, v31                                  // 000000197D10: 38023F41
	v_add_co_ci_u32_e64 v26, null, s9, v4, vcc_lo              // 000000197D14: D5207C1A 01AA0809
	.long 0xd7006a1b                                           // 000000197D1C: D7006A1B
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000197D20: 02021008
	v_or_b32_e32 v4, v66, v31                                  // 000000197D24: 38083F42
	.long 0xd73c0017                                           // 000000197D28: D73C0017
	v_cndmask_b32_e32 v1, 3, v23, vcc_lo                       // 000000197D2C: 02022E83
	v_add_co_ci_u32_e64 v28, null, s9, v9, vcc_lo              // 000000197D30: D5207C1C 01AA1209
	v_or_b32_e32 v9, v67, v31                                  // 000000197D38: 38123F43
	.long 0xd73c001d                                           // 000000197D3C: D73C001D
	v_cndmask_b32_e32 v1, 3, v1, vcc_lo                        // 000000197D40: 02020283
	v_or_b32_e32 v39, 48, v147                                 // 000000197D44: 384F26B0
	.long 0xd73c0003                                           // 000000197D48: D73C0003
	v_cndmask_b32_e32 v1, 3, v4, vcc_lo                        // 000000197D4C: 02020883
	.long 0xd7006a17                                           // 000000197D50: D7006A17
	v_cndmask_b32_e32 v1, s8, v23, vcc_lo                      // 000000197D54: 02022E08
	.long 0xd73c0008                                           // 000000197D58: D73C0008
	v_cndmask_b32_e32 v1, 3, v9, vcc_lo                        // 000000197D5C: 02021283
	v_add_co_ci_u32_e64 v24, null, s9, v24, vcc_lo             // 000000197D60: D5207C18 01AA3009
	.long 0xd7006a1d                                           // 000000197D68: D7006A1D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 000000197D6C: 02023A08
	v_or_b32_e32 v31, v6, v39                                  // 000000197D70: 383E4F06
	v_mov_b32_e32 v32, s1                                      // 000000197D74: 7E400201
	v_add_co_ci_u32_e64 v30, null, s9, v30, vcc_lo             // 000000197D78: D5207C1E 01AA3C09
	.long 0xd7006a21                                           // 000000197D80: D7006A21
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000197D84: 02020608
	v_or_b32_e32 v1, v65, v39                                  // 000000197D88: 38024F41
	v_add_co_ci_u32_e64 v34, null, s9, v4, vcc_lo              // 000000197D8C: D5207C22 01AA0809
	.long 0xd7006a23                                           // 000000197D94: D7006A23
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000197D98: 02021008
	v_or_b32_e32 v4, v66, v39                                  // 000000197D9C: 38084F42
	.long 0xd73c001f                                           // 000000197DA0: D73C001F
	v_cndmask_b32_e32 v1, 3, v31, vcc_lo                       // 000000197DA4: 02023E83
	v_add_co_ci_u32_e64 v36, null, s9, v9, vcc_lo              // 000000197DA8: D5207C24 01AA1209
	v_or_b32_e32 v9, v67, v39                                  // 000000197DB0: 38124F43
	.long 0xd73c0025                                           // 000000197DB4: D73C0025
	v_cndmask_b32_e32 v1, 3, v1, vcc_lo                        // 000000197DB8: 02020283
	v_or_b32_e32 v47, 64, v147                                 // 000000197DBC: 385F26C0
	.long 0xd73c0003                                           // 000000197DC0: D73C0003
	v_cndmask_b32_e32 v1, 3, v4, vcc_lo                        // 000000197DC4: 02020883
	.long 0xd7006a1f                                           // 000000197DC8: D7006A1F
	v_cndmask_b32_e32 v1, s8, v31, vcc_lo                      // 000000197DCC: 02023E08
	.long 0xd73c0008                                           // 000000197DD0: D73C0008
	v_cndmask_b32_e32 v1, 3, v9, vcc_lo                        // 000000197DD4: 02021283
	v_add_co_ci_u32_e64 v32, null, s9, v32, vcc_lo             // 000000197DD8: D5207C20 01AA4009
	.long 0xd7006a25                                           // 000000197DE0: D7006A25
	v_cndmask_b32_e32 v1, s8, v37, vcc_lo                      // 000000197DE4: 02024A08
	v_or_b32_e32 v39, v6, v47                                  // 000000197DE8: 384E5F06
	v_dual_mov_b32 v40, s1 :: v_dual_mov_b32 v173, 0xf149f2ca  // 000000197DEC: CA100001 28AC00FF F149F2CA
	v_add_co_ci_u32_e64 v38, null, s9, v38, vcc_lo             // 000000197DF8: D5207C26 01AA4C09
	.long 0xd7006a29                                           // 000000197E00: D7006A29
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000197E04: 02020608
	v_or_b32_e32 v1, v65, v47                                  // 000000197E08: 38025F41
	v_add_co_ci_u32_e64 v42, null, s9, v4, vcc_lo              // 000000197E0C: D5207C2A 01AA0809
	.long 0xd7006a2b                                           // 000000197E14: D7006A2B
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000197E18: 02021008
	v_or_b32_e32 v4, v66, v47                                  // 000000197E1C: 38085F42
	.long 0xd73c0027                                           // 000000197E20: D73C0027
	v_cndmask_b32_e32 v1, 3, v39, vcc_lo                       // 000000197E24: 02024E83
	v_add_co_ci_u32_e64 v44, null, s9, v9, vcc_lo              // 000000197E28: D5207C2C 01AA1209
	v_or_b32_e32 v9, v67, v47                                  // 000000197E30: 38125F43
	.long 0xd73c002d                                           // 000000197E34: D73C002D
	v_cndmask_b32_e32 v1, 3, v1, vcc_lo                        // 000000197E38: 02020283
	v_or_b32_e32 v55, 0x50, v147                               // 000000197E3C: 386F26FF 00000050
	.long 0xd73c0003                                           // 000000197E44: D73C0003
	v_cndmask_b32_e32 v1, 3, v4, vcc_lo                        // 000000197E48: 02020883
	.long 0xd7006a27                                           // 000000197E4C: D7006A27
	v_cndmask_b32_e32 v1, s8, v39, vcc_lo                      // 000000197E50: 02024E08
	.long 0xd73c0008                                           // 000000197E54: D73C0008
	v_cndmask_b32_e32 v1, 3, v9, vcc_lo                        // 000000197E58: 02021283
	v_add_co_ci_u32_e64 v40, null, s9, v40, vcc_lo             // 000000197E5C: D5207C28 01AA5009
	.long 0xd7006a2d                                           // 000000197E64: D7006A2D
	v_cndmask_b32_e32 v1, s8, v45, vcc_lo                      // 000000197E68: 02025A08
	v_or_b32_e32 v47, v6, v55                                  // 000000197E6C: 385E6F06
	v_mov_b32_e32 v48, s1                                      // 000000197E70: 7E600201
	v_add_co_ci_u32_e64 v46, null, s9, v46, vcc_lo             // 000000197E74: D5207C2E 01AA5C09
	.long 0xd7006a31                                           // 000000197E7C: D7006A31
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000197E80: 02020608
	v_or_b32_e32 v1, v65, v55                                  // 000000197E84: 38026F41
	v_add_co_ci_u32_e64 v50, null, s9, v4, vcc_lo              // 000000197E88: D5207C32 01AA0809
	.long 0xd7006a33                                           // 000000197E90: D7006A33
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000197E94: 02021008
	v_or_b32_e32 v4, v66, v55                                  // 000000197E98: 38086F42
	.long 0xd73c002f                                           // 000000197E9C: D73C002F
	v_cndmask_b32_e32 v1, 3, v47, vcc_lo                       // 000000197EA0: 02025E83
	v_add_co_ci_u32_e64 v52, null, s9, v9, vcc_lo              // 000000197EA4: D5207C34 01AA1209
	v_or_b32_e32 v9, v67, v55                                  // 000000197EAC: 38126F43
	.long 0xd73c0035                                           // 000000197EB0: D73C0035
	v_cndmask_b32_e32 v1, 3, v1, vcc_lo                        // 000000197EB4: 02020283
	v_or_b32_e32 v63, 0x60, v147                               // 000000197EB8: 387F26FF 00000060
	.long 0xd73c0003                                           // 000000197EC0: D73C0003
	v_cndmask_b32_e32 v1, 3, v4, vcc_lo                        // 000000197EC4: 02020883
	.long 0xd7006a2f                                           // 000000197EC8: D7006A2F
	v_cndmask_b32_e32 v1, s8, v47, vcc_lo                      // 000000197ECC: 02025E08
	.long 0xd73c0008                                           // 000000197ED0: D73C0008
	v_cndmask_b32_e32 v1, 3, v9, vcc_lo                        // 000000197ED4: 02021283
	v_add_co_ci_u32_e64 v48, null, s9, v48, vcc_lo             // 000000197ED8: D5207C30 01AA6009
	.long 0xd7006a35                                           // 000000197EE0: D7006A35
	v_cndmask_b32_e32 v1, s8, v53, vcc_lo                      // 000000197EE4: 02026A08
	v_or_b32_e32 v55, v6, v63                                  // 000000197EE8: 386E7F06
	v_dual_mov_b32 v56, s1 :: v_dual_mov_b32 v169, 0xf149f2ca  // 000000197EEC: CA100001 38A800FF F149F2CA
	v_add_co_ci_u32_e64 v54, null, s9, v54, vcc_lo             // 000000197EF8: D5207C36 01AA6C09
	.long 0xd7006a39                                           // 000000197F00: D7006A39
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000197F04: 02020608
	v_or_b32_e32 v1, v65, v63                                  // 000000197F08: 38027F41
	v_add_co_ci_u32_e64 v58, null, s9, v4, vcc_lo              // 000000197F0C: D5207C3A 01AA0809
	.long 0xd7006a3b                                           // 000000197F14: D7006A3B
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000197F18: 02021008
	v_or_b32_e32 v4, v66, v63                                  // 000000197F1C: 38087F42
	.long 0xd73c0037                                           // 000000197F20: D73C0037
	v_cndmask_b32_e32 v1, 3, v55, vcc_lo                       // 000000197F24: 02026E83
	v_add_co_ci_u32_e64 v60, null, s9, v9, vcc_lo              // 000000197F28: D5207C3C 01AA1209
	v_or_b32_e32 v9, v67, v63                                  // 000000197F30: 38127F43
	.long 0xd73c003d                                           // 000000197F34: D73C003D
	v_cndmask_b32_e32 v1, 3, v1, vcc_lo                        // 000000197F38: 02020283
	v_or_b32_e32 v68, 0x70, v147                               // 000000197F3C: 388926FF 00000070
	.long 0xd73c0003                                           // 000000197F44: D73C0003
	v_cndmask_b32_e32 v1, 3, v4, vcc_lo                        // 000000197F48: 02020883
	.long 0xd7006a37                                           // 000000197F4C: D7006A37
	v_cndmask_b32_e32 v1, s8, v55, vcc_lo                      // 000000197F50: 02026E08
	.long 0xd73c0008                                           // 000000197F54: D73C0008
	v_cndmask_b32_e32 v1, 3, v9, vcc_lo                        // 000000197F58: 02021283
	v_add_co_ci_u32_e64 v56, null, s9, v56, vcc_lo             // 000000197F5C: D5207C38 01AA7009
	.long 0xd7006a3d                                           // 000000197F64: D7006A3D
	v_cndmask_b32_e32 v1, s8, v61, vcc_lo                      // 000000197F68: 02027A08
	v_or_b32_e32 v63, v6, v68                                  // 000000197F6C: 387E8906
	v_dual_mov_b32 v64, s1 :: v_dual_mov_b32 v167, 0xf149f2ca  // 000000197F70: CA100001 40A600FF F149F2CA
	v_add_co_ci_u32_e64 v62, null, s9, v62, vcc_lo             // 000000197F7C: D5207C3E 01AA7C09
	.long 0xd7006a75                                           // 000000197F84: D7006A75
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000197F88: 02020608
	v_or_b32_e32 v1, v65, v68                                  // 000000197F8C: 38028941
	v_add_co_ci_u32_e64 v118, null, s9, v4, vcc_lo             // 000000197F90: D5207C76 01AA0809
	.long 0xd7006a77                                           // 000000197F98: D7006A77
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000197F9C: 02021008
	v_or_b32_e32 v4, v66, v68                                  // 000000197FA0: 38088942
	.long 0xd73c003f                                           // 000000197FA4: D73C003F
	v_cndmask_b32_e32 v1, 3, v63, vcc_lo                       // 000000197FA8: 02027E83
	v_add_co_ci_u32_e64 v120, null, s9, v9, vcc_lo             // 000000197FAC: D5207C78 01AA1209
	v_or_b32_e32 v9, v67, v68                                  // 000000197FB4: 38128943
	.long 0xd73c0001                                           // 000000197FB8: D73C0001
	v_cndmask_b32_e32 v1, 3, v1, vcc_lo                        // 000000197FBC: 02020283
	.long 0xd73c0003                                           // 000000197FC0: D73C0003
	v_cndmask_b32_e32 v1, 3, v4, vcc_lo                        // 000000197FC4: 02020883
	.long 0xd7006a3f                                           // 000000197FC8: D7006A3F
	v_cndmask_b32_e32 v1, s8, v63, vcc_lo                      // 000000197FCC: 02027E08
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000197FD0: BF8700B4
	.long 0xd73c0005                                           // 000000197FD4: D73C0005
	v_cndmask_b32_e32 v1, 3, v9, vcc_lo                        // 000000197FD8: 02021283
	v_add_co_ci_u32_e64 v64, null, s9, v64, vcc_lo             // 000000197FDC: D5207C40 01AA8009
	.long 0xd7006a01                                           // 000000197FE4: D7006A01
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000197FE8: 02020208
	v_add_co_ci_u32_e64 v2, null, s9, v2, vcc_lo               // 000000197FEC: D5207C02 01AA0409
	.long 0xd7006a03                                           // 000000197FF4: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000197FF8: 02020608
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000197FFC: BF8700A1
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000198000: D5207C04 01AA0809
	.long 0xd7006a05                                           // 000000198008: D7006A05
	v_cndmask_b32_e32 v1, s8, v5, vcc_lo                       // 00000019800C: 02020A08
	v_add_co_ci_u32_e64 v6, null, s9, v6, vcc_lo               // 000000198010: D5207C06 01AA0C09
	s_clause 0x1f                                              // 000000198018: BF85001F
	global_load_b64 v[65:66], v[13:14], off                    // 00000019801C: DC560000 417C000D
	global_load_b64 v[67:68], v[11:12], off                    // 000000198024: DC560000 437C000B
	global_load_b64 v[69:70], v[17:18], off                    // 00000019802C: DC560000 457C0011
	global_load_b64 v[71:72], v[19:20], off                    // 000000198034: DC560000 477C0013
	global_load_b64 v[73:74], v[15:16], off                    // 00000019803C: DC560000 497C000F
	global_load_b64 v[75:76], v[21:22], off                    // 000000198044: DC560000 4B7C0015
	global_load_b64 v[77:78], v[25:26], off                    // 00000019804C: DC560000 4D7C0019
	global_load_b64 v[79:80], v[27:28], off                    // 000000198054: DC560000 4F7C001B
	global_load_b64 v[81:82], v[23:24], off                    // 00000019805C: DC560000 517C0017
	global_load_b64 v[83:84], v[29:30], off                    // 000000198064: DC560000 537C001D
	global_load_b64 v[85:86], v[33:34], off                    // 00000019806C: DC560000 557C0021
	global_load_b64 v[87:88], v[35:36], off                    // 000000198074: DC560000 577C0023
	global_load_b64 v[89:90], v[31:32], off                    // 00000019807C: DC560000 597C001F
	global_load_b64 v[91:92], v[37:38], off                    // 000000198084: DC560000 5B7C0025
	global_load_b64 v[93:94], v[41:42], off                    // 00000019808C: DC560000 5D7C0029
	global_load_b64 v[95:96], v[43:44], off                    // 000000198094: DC560000 5F7C002B
	global_load_b64 v[97:98], v[39:40], off                    // 00000019809C: DC560000 617C0027
	global_load_b64 v[99:100], v[45:46], off                   // 0000001980A4: DC560000 637C002D
	global_load_b64 v[101:102], v[49:50], off                  // 0000001980AC: DC560000 657C0031
	global_load_b64 v[103:104], v[51:52], off                  // 0000001980B4: DC560000 677C0033
	global_load_b64 v[105:106], v[47:48], off                  // 0000001980BC: DC560000 697C002F
	global_load_b64 v[107:108], v[53:54], off                  // 0000001980C4: DC560000 6B7C0035
	global_load_b64 v[109:110], v[57:58], off                  // 0000001980CC: DC560000 6D7C0039
	global_load_b64 v[111:112], v[59:60], off                  // 0000001980D4: DC560000 6F7C003B
	global_load_b64 v[113:114], v[55:56], off                  // 0000001980DC: DC560000 717C0037
	global_load_b64 v[115:116], v[61:62], off                  // 0000001980E4: DC560000 737C003D
	global_load_b64 v[117:118], v[117:118], off                // 0000001980EC: DC560000 757C0075
	global_load_b64 v[119:120], v[119:120], off                // 0000001980F4: DC560000 777C0077
	global_load_b64 v[121:122], v[63:64], off                  // 0000001980FC: DC560000 797C003F
	global_load_b64 v[123:124], v[1:2], off                    // 000000198104: DC560000 7B7C0001
	global_load_b64 v[125:126], v[3:4], off                    // 00000019810C: DC560000 7D7C0003
	global_load_b64 v[127:128], v[5:6], off                    // 000000198114: DC560000 7F7C0005
	v_dual_mov_b32 v165, 0xf149f2ca :: v_dual_lshlrev_b32 v0, 5, v0// 00000019811C: CA2200FF A5000085 F149F2CA
	v_lshlrev_b32_e32 v3, 10, v7                               // 000000198128: 30060E8A
	v_lshlrev_b32_e32 v1, 2, v145                              // 00000019812C: 30032282
	v_cmp_gt_u32_e32 vcc_lo, 12, v145                          // 000000198130: 7C99228C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000198134: BF870214
	v_dual_mov_b32 v161, 0 :: v_dual_and_b32 v0, 0x60, v0      // 000000198138: CA240080 A10000FF 00000060
	.long 0xd7000005                                           // 000000198144: D7000005
	v_cndmask_b32_e32 v1, s5, v3, vcc_lo                       // 000000198148: 02020605
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000019814C: BF870234
	v_lshl_or_b32 v1, v146, 6, v1                              // 000000198150: D6560001 04050D92
	v_dual_cndmask_b32 v2, 0, v145 :: v_dual_mov_b32 v157, 0   // 000000198158: CA512280 029C0080
	v_add_co_ci_u32_e64 v6, null, s6, 0, s0                    // 000000198160: D5207C06 00010006
	.long 0xd7006a00                                           // 000000198168: D7006A00
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 00000019816C: 02020105
	s_movk_i32 s0, 0x210                                       // 000000198170: B0000210
	v_add_nc_u32_e32 v1, 0x3cd0, v1                            // 000000198174: 4A0202FF 00003CD0
	v_dual_mov_b32 v159, 0 :: v_dual_lshlrev_b32 v4, 9, v7     // 00000019817C: CA220080 9F040E89
	v_add_co_ci_u32_e64 v149, null, 0, v6, vcc_lo              // 000000198184: D5207C95 01AA0C80
	v_xor_b32_e32 v5, 1, v7                                    // 00000019818C: 3A0A0E81
	v_dual_mov_b32 v163, 0 :: v_dual_lshlrev_b32 v6, 5, v146   // 000000198190: CA220080 A3072485
	v_dual_mov_b32 v57, 0 :: v_dual_lshlrev_b32 v8, 1, v145    // 000000198198: CA220080 39092281
	v_mad_u32_u24 v2, v2, s0, 0x2410                           // 0000001981A0: D60B0002 03FC0102 00002410
	v_lshlrev_b32_e32 v7, 8, v7                                // 0000001981AC: 300E0E88
	v_dual_mov_b32 v49, 0 :: v_dual_add_nc_u32 v150, v1, v3    // 0000001981B0: CA200080 31960701
	v_lshl_add_u32 v151, v5, 10, v1                            // 0000001981B8: D6460097 04051505
	v_or3_b32 v152, v4, v6, v8                                 // 0000001981C0: D6580098 04220D04
	v_lshl_or_b32 v153, v145, 5, v4                            // 0000001981C8: D6560099 04110B91
	v_dual_mov_b32 v59, v129 :: v_dual_and_b32 v154, 12, v145  // 0000001981D0: CA240181 3B9B228C
	v_dual_mov_b32 v172, 0xf149f2ca :: v_dual_add_nc_u32 v155, v2, v7// 0000001981D8: CA2000FF AC9A0F02 F149F2CA
	v_dual_mov_b32 v61, v129 :: v_dual_mov_b32 v170, 0xf149f2ca// 0000001981E4: CA100181 3DAA00FF F149F2CA
	v_dual_mov_b32 v63, v129 :: v_dual_mov_b32 v166, 0xf149f2ca// 0000001981F0: CA100181 3FA600FF F149F2CA
	v_dual_mov_b32 v51, v129 :: v_dual_mov_b32 v164, 0xf149f2ca// 0000001981FC: CA100181 33A400FF F149F2CA
	v_dual_mov_b32 v53, v129 :: v_dual_mov_b32 v158, 0         // 000000198208: CA100181 359E0080
	v_dual_mov_b32 v55, v129 :: v_dual_mov_b32 v160, 0         // 000000198210: CA100181 37A00080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v162, 0            // 000000198218: CA100080 29A20080
	v_dual_mov_b32 v43, v129 :: v_dual_mov_b32 v156, 0         // 000000198220: CA100181 2B9C0080
	v_mov_b32_e32 v45, v129                                    // 000000198228: 7E5A0381
	v_dual_mov_b32 v58, v129 :: v_dual_mov_b32 v33, 0          // 00000019822C: CA100181 3A200080
	v_dual_mov_b32 v60, v129 :: v_dual_mov_b32 v25, 0          // 000000198234: CA100181 3C180080
	v_dual_mov_b32 v62, v129 :: v_dual_mov_b32 v17, 0          // 00000019823C: CA100181 3E100080
	v_dual_mov_b32 v64, v129 :: v_dual_mov_b32 v9, 0           // 000000198244: CA100181 40080080
	v_dual_mov_b32 v50, v129 :: v_dual_mov_b32 v1, 0           // 00000019824C: CA100181 32000080
	v_mov_b32_e32 v52, v129                                    // 000000198254: 7E680381
	v_mov_b32_e32 v54, v129                                    // 000000198258: 7E6C0381
	v_mov_b32_e32 v56, v129                                    // 00000019825C: 7E700381
	v_mov_b32_e32 v42, v129                                    // 000000198260: 7E540381
	v_mov_b32_e32 v44, v129                                    // 000000198264: 7E580381
	v_mov_b32_e32 v46, v129                                    // 000000198268: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 00000019826C: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 000000198270: 7E600381
	v_mov_b32_e32 v34, v129                                    // 000000198274: 7E440381
	v_mov_b32_e32 v35, v129                                    // 000000198278: 7E460381
	v_mov_b32_e32 v36, v129                                    // 00000019827C: 7E480381
	v_mov_b32_e32 v37, v129                                    // 000000198280: 7E4A0381
	v_mov_b32_e32 v38, v129                                    // 000000198284: 7E4C0381
	v_mov_b32_e32 v39, v129                                    // 000000198288: 7E4E0381
	v_mov_b32_e32 v40, v129                                    // 00000019828C: 7E500381
	v_mov_b32_e32 v26, v129                                    // 000000198290: 7E340381
	v_mov_b32_e32 v27, v129                                    // 000000198294: 7E360381
	v_mov_b32_e32 v28, v129                                    // 000000198298: 7E380381
	v_mov_b32_e32 v29, v129                                    // 00000019829C: 7E3A0381
	v_mov_b32_e32 v30, v129                                    // 0000001982A0: 7E3C0381
	v_mov_b32_e32 v31, v129                                    // 0000001982A4: 7E3E0381
	v_mov_b32_e32 v32, v129                                    // 0000001982A8: 7E400381
	v_mov_b32_e32 v18, v129                                    // 0000001982AC: 7E240381
	v_mov_b32_e32 v19, v129                                    // 0000001982B0: 7E260381
	v_mov_b32_e32 v20, v129                                    // 0000001982B4: 7E280381
	v_mov_b32_e32 v21, v129                                    // 0000001982B8: 7E2A0381
	v_mov_b32_e32 v22, v129                                    // 0000001982BC: 7E2C0381
	v_mov_b32_e32 v23, v129                                    // 0000001982C0: 7E2E0381
	v_mov_b32_e32 v24, v129                                    // 0000001982C4: 7E300381
	v_mov_b32_e32 v10, v129                                    // 0000001982C8: 7E140381
	v_mov_b32_e32 v11, v129                                    // 0000001982CC: 7E160381
	v_mov_b32_e32 v12, v129                                    // 0000001982D0: 7E180381
	v_mov_b32_e32 v13, v129                                    // 0000001982D4: 7E1A0381
	v_mov_b32_e32 v14, v129                                    // 0000001982D8: 7E1C0381
	v_mov_b32_e32 v15, v129                                    // 0000001982DC: 7E1E0381
	v_mov_b32_e32 v16, v129                                    // 0000001982E0: 7E200381
	v_mov_b32_e32 v2, v129                                     // 0000001982E4: 7E040381
	v_mov_b32_e32 v3, v129                                     // 0000001982E8: 7E060381
	v_mov_b32_e32 v4, v129                                     // 0000001982EC: 7E080381
	v_mov_b32_e32 v5, v129                                     // 0000001982F0: 7E0A0381
	v_mov_b32_e32 v6, v129                                     // 0000001982F4: 7E0C0381
	v_mov_b32_e32 v7, v129                                     // 0000001982F8: 7E0E0381
	v_mov_b32_e32 v8, v129                                     // 0000001982FC: 7E100381
	s_branch 126                                               // 000000198300: BFA0007E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xcfc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000198304: 8C7E007E
	v_bfe_u32 v164, v166, 16, 1                                // 000000198308: D61000A4 020521A6
	v_dual_fmac_f32 v130, v157, v171 :: v_dual_fmac_f32 v131, v159, v172// 000000198310: C801579D 8283599F
	v_dual_fmac_f32 v148, v158, v173 :: v_dual_fmac_f32 v141, v163, v138// 000000198318: C8015B9E 948D15A3
	s_delay_alu instid0(VALU_DEP_3)                            // 000000198320: BF870003
	v_add3_u32 v164, v166, v164, 0x7fff                        // 000000198324: D65500A4 03FF49A6 00007FFF
	v_dual_fmac_f32 v132, v160, v170 :: v_dual_fmac_f32 v133, v161, v169// 000000198330: C80155A0 848553A1
	v_dual_fmac_f32 v134, v162, v167 :: v_dual_mul_f32 v59, v59, v172// 000000198338: C8074FA2 863B593B
	ds_store_b16_d16_hi v152, v164 offset:448                  // 000000198340: DA8401C0 0000A498
	ds_load_b128 v[174:177], v153                              // 000000198348: DBFC0000 AE000099
	ds_load_b128 v[178:181], v153 offset:16                    // 000000198350: DBFC0010 B2000099
	v_dual_mul_f32 v57, v57, v171 :: v_dual_mul_f32 v58, v58, v173// 000000198358: C8C75739 393B5B3A
	v_dual_mul_f32 v60, v60, v170 :: v_dual_mul_f32 v61, v61, v169// 000000198360: C8C7553C 3C3D533D
	v_dual_mul_f32 v62, v62, v167 :: v_dual_mul_f32 v63, v63, v138// 000000198368: C8C74F3E 3E3F153F
	v_dual_mul_f32 v64, v64, v139 :: v_dual_mul_f32 v51, v51, v172// 000000198370: C8C71740 40335933
	v_dual_mul_f32 v49, v49, v171 :: v_dual_mul_f32 v50, v50, v173// 000000198378: C8C75731 31335B32
	v_dual_mul_f32 v52, v52, v170 :: v_dual_mul_f32 v53, v53, v169// 000000198380: C8C75534 34355335
	v_dual_mul_f32 v54, v54, v167 :: v_dual_mul_f32 v55, v55, v138// 000000198388: C8C74F36 36371537
	v_dual_mul_f32 v56, v56, v139 :: v_dual_mul_f32 v43, v43, v172// 000000198390: C8C71738 382B592B
	v_dual_mul_f32 v41, v41, v171 :: v_dual_mul_f32 v42, v42, v173// 000000198398: C8C75729 292B5B2A
	v_dual_mul_f32 v44, v44, v170 :: v_dual_mul_f32 v45, v45, v169// 0000001983A0: C8C7552C 2C2D532D
	v_dual_mul_f32 v46, v46, v167 :: v_dual_mul_f32 v47, v47, v138// 0000001983A8: C8C74F2E 2E2F152F
	v_dual_mul_f32 v48, v48, v139 :: v_dual_mul_f32 v35, v35, v172// 0000001983B0: C8C71730 30235923
	v_dual_mul_f32 v33, v33, v171 :: v_dual_mul_f32 v34, v34, v173// 0000001983B8: C8C75721 21235B22
	v_dual_mul_f32 v36, v36, v170 :: v_dual_mul_f32 v37, v37, v169// 0000001983C0: C8C75524 24255325
	v_dual_mul_f32 v38, v38, v167 :: v_dual_mul_f32 v39, v39, v138// 0000001983C8: C8C74F26 26271527
	v_dual_mul_f32 v40, v40, v139 :: v_dual_mul_f32 v27, v27, v172// 0000001983D0: C8C71728 281B591B
	v_dual_mul_f32 v25, v25, v171 :: v_dual_mul_f32 v26, v26, v173// 0000001983D8: C8C75719 191B5B1A
	v_dual_mul_f32 v28, v28, v170 :: v_dual_mul_f32 v29, v29, v169// 0000001983E0: C8C7551C 1C1D531D
	v_dual_mul_f32 v30, v30, v167 :: v_dual_mul_f32 v31, v31, v138// 0000001983E8: C8C74F1E 1E1F151F
	v_dual_mul_f32 v32, v32, v139 :: v_dual_mul_f32 v19, v19, v172// 0000001983F0: C8C71720 20135913
	v_dual_mul_f32 v17, v17, v171 :: v_dual_mul_f32 v18, v18, v173// 0000001983F8: C8C75711 11135B12
	v_dual_mul_f32 v20, v20, v170 :: v_dual_mul_f32 v21, v21, v169// 000000198400: C8C75514 14155315
	v_dual_mul_f32 v22, v22, v167 :: v_dual_mul_f32 v23, v23, v138// 000000198408: C8C74F16 16171517
	v_dual_mul_f32 v24, v24, v139 :: v_dual_mul_f32 v11, v11, v172// 000000198410: C8C71718 180B590B
	v_dual_mul_f32 v9, v9, v171 :: v_dual_mul_f32 v10, v10, v173// 000000198418: C8C75709 090B5B0A
	v_dual_mul_f32 v12, v12, v170 :: v_dual_mul_f32 v13, v13, v169// 000000198420: C8C7550C 0C0D530D
	v_dual_mul_f32 v14, v14, v167 :: v_dual_mul_f32 v15, v15, v138// 000000198428: C8C74F0E 0E0F150F
	v_dual_mul_f32 v16, v16, v139 :: v_dual_mul_f32 v3, v3, v172// 000000198430: C8C71710 10035903
	v_dual_mul_f32 v1, v1, v171 :: v_dual_mul_f32 v2, v2, v173 // 000000198438: C8C75701 01035B02
	v_dual_mul_f32 v4, v4, v170 :: v_dual_mul_f32 v5, v5, v169 // 000000198440: C8C75504 04055305
	v_dual_mul_f32 v6, v6, v167 :: v_dual_mul_f32 v7, v7, v138 // 000000198448: C8C74F06 06071507
	v_dual_mul_f32 v8, v8, v139 :: v_dual_mov_b32 v169, v143   // 000000198450: C8D11708 08A8018F
	v_fma_f32 v156, v156, v139, v166                           // 000000198458: D613009C 069B179C
	v_dual_mov_b32 v173, v168 :: v_dual_add_nc_u32 v154, 16, v154// 000000198460: CA2001A8 AD9B3490
	v_dual_mov_b32 v172, v144 :: v_dual_mov_b32 v157, v130     // 000000198468: CA100190 AC9C0182
	v_dual_mov_b32 v170, v142 :: v_dual_mov_b32 v167, v140     // 000000198470: CA10018E AAA6018C
	v_dual_mov_b32 v166, v135 :: v_dual_mov_b32 v165, v136     // 000000198478: CA100187 A6A40188
	v_dual_mov_b32 v164, v137 :: v_dual_mov_b32 v159, v131     // 000000198480: CA100189 A49E0183
	v_dual_mov_b32 v158, v148 :: v_dual_mov_b32 v161, v133     // 000000198488: CA100194 9EA00185
	v_dual_mov_b32 v160, v132 :: v_dual_mov_b32 v163, v141     // 000000198490: CA100184 A0A2018D
	v_mov_b32_e32 v162, v134                                   // 000000198498: 7F440386
	s_waitcnt lgkmcnt(0)                                       // 00000019849C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[174:181], v[65:72], v[57:64]// 0000001984A0: CC414039 1CE683AE
	v_wmma_f32_16x16x16_bf16 v[49:56], v[174:181], v[73:80], v[49:56]// 0000001984A8: CC414031 1CC693AE
	v_wmma_f32_16x16x16_bf16 v[41:48], v[174:181], v[81:88], v[41:48]// 0000001984B0: CC414029 1CA6A3AE
	v_wmma_f32_16x16x16_bf16 v[33:40], v[174:181], v[89:96], v[33:40]// 0000001984B8: CC414021 1C86B3AE
	v_wmma_f32_16x16x16_bf16 v[25:32], v[174:181], v[97:104], v[25:32]// 0000001984C0: CC414019 1C66C3AE
	v_wmma_f32_16x16x16_bf16 v[17:24], v[174:181], v[105:112], v[17:24]// 0000001984C8: CC414011 1C46D3AE
	v_wmma_f32_16x16x16_bf16 v[9:16], v[174:181], v[113:120], v[9:16]// 0000001984D0: CC414009 1C26E3AE
	v_wmma_f32_16x16x16_bf16 v[1:8], v[174:181], v[121:128], v[1:8]// 0000001984D8: CC414001 1C06F3AE
	s_add_i32 s3, s3, -1                                       // 0000001984E0: 8103C103
	s_add_i32 s4, s4, -16                                      // 0000001984E4: 8104D004
	s_cmp_lg_u32 s3, 0                                         // 0000001984E8: BF078003
	s_barrier                                                  // 0000001984EC: BFBD0000
	buffer_gl0_inv                                             // 0000001984F0: E0AC0000 00000000
	s_cbranch_scc0 982                                         // 0000001984F8: BFA103D6 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1c54>
	ds_load_b32 v130, v154 offset:1024                         // 0000001984FC: D8D80400 8200009A
	ds_load_b128 v[182:185], v155                              // 000000198504: DBFC0000 B600009B
	ds_load_b128 v[186:189], v155 offset:16                    // 00000019850C: DBFC0010 BA00009B
	v_mov_b32_e32 v136, v129                                   // 000000198514: 7F100381
	v_mov_b32_e32 v132, v129                                   // 000000198518: 7F080381
	v_mov_b32_e32 v133, v129                                   // 00000019851C: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 000000198520: 7F0C0381
	s_waitcnt lgkmcnt(2)                                       // 000000198524: BF89FC27
	v_ashrrev_i32_e32 v131, 31, v130                           // 000000198528: 3507049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019852C: BF870091
	.long 0xd73c0082                                           // 000000198530: D73C0082
	v_cndmask_b32_e32 v1, 12, v130, vcc_lo                     // 000000198534: 0203048C
	.long 0xd7006a8a                                           // 000000198538: D7006A8A
	v_cndmask_b32_e32 v1, v0, v130, vcc_lo                     // 00000019853C: 02030500
	s_delay_alu instid0(VALU_DEP_1)                            // 000000198540: BF870001
	v_add_co_ci_u32_e64 v139, null, v149, v131, vcc_lo         // 000000198544: D5207C8B 01AB0795
	v_mov_b32_e32 v130, v129                                   // 00000019854C: 7F040381
	v_mov_b32_e32 v131, v129                                   // 000000198550: 7F060381
	v_cmp_gt_i32_e32 vcc_lo, s4, v145                          // 000000198554: 7C892204
	s_clause 0x1                                               // 000000198558: BF850001
	global_load_b128 v[178:181], v[138:139], off offset:16     // 00000019855C: DC5E0010 B27C008A
	global_load_b128 v[174:177], v[138:139], off               // 000000198564: DC5E0000 AE7C008A
	v_mov_b32_e32 v135, v129                                   // 00000019856C: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 000000198570: 7F120388
	s_delay_alu instid0(VALU_DEP_2)                            // 000000198574: BF870002
	v_mov_b32_e32 v136, v135                                   // 000000198578: 7F100387
	v_mov_b32_e32 v135, v134                                   // 00000019857C: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 000000198580: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 000000198584: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 000000198588: 7F080383
	v_mov_b32_e32 v131, v130                                   // 00000019858C: 7F060382
	v_mov_b32_e32 v130, v129                                   // 000000198590: 7F040381
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000198594: BF890007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000198598: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[182:189], v[174:181], v[130:137]// 00000019859C: CC414082 1E0B5DB6
	s_clause 0x1                                               // 0000001985A4: BF850001
	global_load_b128 v[178:181], v[138:139], off offset:144    // 0000001985A8: DC5E0090 B27C008A
	global_load_b128 v[174:177], v[138:139], off offset:128    // 0000001985B0: DC5E0080 AE7C008A
	ds_load_b128 v[182:185], v155 offset:32                    // 0000001985B8: DBFC0020 B600009B
	ds_load_b128 v[186:189], v155 offset:48                    // 0000001985C0: DBFC0030 BA00009B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001985C8: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[182:189], v[174:181], v[130:137]// 0000001985CC: CC414082 1E0B5DB6
	s_clause 0x1                                               // 0000001985D4: BF850001
	global_load_b128 v[178:181], v[138:139], off offset:272    // 0000001985D8: DC5E0110 B27C008A
	global_load_b128 v[174:177], v[138:139], off offset:256    // 0000001985E0: DC5E0100 AE7C008A
	ds_load_b128 v[186:189], v155 offset:80                    // 0000001985E8: DBFC0050 BA00009B
	ds_load_b128 v[182:185], v155 offset:64                    // 0000001985F0: DBFC0040 B600009B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001985F8: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[182:189], v[174:181], v[130:137]// 0000001985FC: CC414082 1E0B5DB6
	s_clause 0x1                                               // 000000198604: BF850001
	global_load_b128 v[178:181], v[138:139], off offset:400    // 000000198608: DC5E0190 B27C008A
	global_load_b128 v[174:177], v[138:139], off offset:384    // 000000198610: DC5E0180 AE7C008A
	ds_load_b128 v[186:189], v155 offset:112                   // 000000198618: DBFC0070 BA00009B
	ds_load_b128 v[182:185], v155 offset:96                    // 000000198620: DBFC0060 B600009B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000198628: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[182:189], v[174:181], v[130:137]// 00000019862C: CC414082 1E0B5DB6
	s_clause 0x1                                               // 000000198634: BF850001
	global_load_b128 v[178:181], v[138:139], off offset:528    // 000000198638: DC5E0210 B27C008A
	global_load_b128 v[174:177], v[138:139], off offset:512    // 000000198640: DC5E0200 AE7C008A
	ds_load_b128 v[186:189], v155 offset:144                   // 000000198648: DBFC0090 BA00009B
	ds_load_b128 v[182:185], v155 offset:128                   // 000000198650: DBFC0080 B600009B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000198658: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[182:189], v[174:181], v[130:137]// 00000019865C: CC414082 1E0B5DB6
	s_clause 0x1                                               // 000000198664: BF850001
	global_load_b128 v[178:181], v[138:139], off offset:656    // 000000198668: DC5E0290 B27C008A
	global_load_b128 v[174:177], v[138:139], off offset:640    // 000000198670: DC5E0280 AE7C008A
	ds_load_b128 v[186:189], v155 offset:176                   // 000000198678: DBFC00B0 BA00009B
	ds_load_b128 v[182:185], v155 offset:160                   // 000000198680: DBFC00A0 B600009B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000198688: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[182:189], v[174:181], v[130:137]// 00000019868C: CC414082 1E0B5DB6
	s_clause 0x1                                               // 000000198694: BF850001
	global_load_b128 v[178:181], v[138:139], off offset:784    // 000000198698: DC5E0310 B27C008A
	global_load_b128 v[174:177], v[138:139], off offset:768    // 0000001986A0: DC5E0300 AE7C008A
	ds_load_b128 v[186:189], v155 offset:208                   // 0000001986A8: DBFC00D0 BA00009B
	ds_load_b128 v[182:185], v155 offset:192                   // 0000001986B0: DBFC00C0 B600009B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001986B8: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[182:189], v[174:181], v[130:137]// 0000001986BC: CC414082 1E0B5DB6
	s_clause 0x1                                               // 0000001986C4: BF850001
	global_load_b128 v[178:181], v[138:139], off offset:912    // 0000001986C8: DC5E0390 B27C008A
	global_load_b128 v[174:177], v[138:139], off offset:896    // 0000001986D0: DC5E0380 AE7C008A
	ds_load_b128 v[186:189], v155 offset:240                   // 0000001986D8: DBFC00F0 BA00009B
	ds_load_b128 v[182:185], v155 offset:224                   // 0000001986E0: DBFC00E0 B600009B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001986E8: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[182:189], v[174:181], v[130:137]// 0000001986EC: CC414082 1E0B5DB6
	ds_store_2addr_b32 v150, v130, v131 offset1:32             // 0000001986F4: D8382000 00838296
	ds_store_2addr_b32 v150, v132, v133 offset0:64 offset1:96  // 0000001986FC: D8386040 00858496
	ds_store_2addr_b32 v150, v134, v135 offset0:128 offset1:160// 000000198704: D838A080 00878696
	ds_store_2addr_b32 v150, v136, v137 offset0:192 offset1:224// 00000019870C: D838E0C0 00898896
	s_waitcnt lgkmcnt(0)                                       // 000000198714: BF89FC07
	s_barrier                                                  // 000000198718: BFBD0000
	buffer_gl0_inv                                             // 00000019871C: E0AC0000 00000000
	ds_load_2addr_b32 v[143:144], v151 offset1:32              // 000000198724: D8DC2000 8F000097
	s_waitcnt lgkmcnt(0)                                       // 00000019872C: BF89FC07
	v_add_f32_e32 v130, v130, v143                             // 000000198730: 07051F82
	ds_load_2addr_b32 v[142:143], v151 offset0:64 offset1:96   // 000000198734: D8DC6040 8E000097
	ds_load_2addr_b32 v[140:141], v151 offset0:128 offset1:160 // 00000019873C: D8DCA080 8C000097
	v_mul_f32_e32 v148, 0x3d800000, v130                       // 000000198744: 112904FF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019874C: BF870091
	v_cndmask_b32_e32 v130, 0xf149f2ca, v148, vcc_lo           // 000000198750: 030528FF F149F2CA
	v_mov_b32_dpp v138, v130 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198758: 7F1402FA FF096182
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198760: BF870091
	v_max_f32_e32 v138, v138, v138                             // 000000198764: 2115158A
	v_max_f32_e32 v130, v130, v138                             // 000000198768: 21051582
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019876C: BF870091
	v_mov_b32_dpp v138, v130 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198770: 7F1402FA FF096282
	v_max_f32_e32 v138, v138, v138                             // 000000198778: 2115158A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019877C: BF870091
	v_max_f32_e32 v130, v130, v138                             // 000000198780: 21051582
	v_mov_b32_dpp v138, v130 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198784: 7F1402FA FF096482
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000019878C: BF8700B1
	v_max_f32_e32 v168, v138, v138                             // 000000198790: 2151158A
	ds_load_2addr_b32 v[138:139], v151 offset0:192 offset1:224 // 000000198794: D8DCE0C0 8A000097
	v_max_f32_e32 v130, v130, v168                             // 00000019879C: 21055182
	v_mov_b32_dpp v168, v130 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001987A0: 7F5002FA FF096882
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001987A8: BF870001
	v_max3_f32 v168, v173, v130, v168                          // 0000001987AC: D61C00A8 06A305AD
	v_mov_b32_e32 v130, 0                                      // 0000001987B4: 7F040280
	s_and_saveexec_b32 s1, vcc_lo                              // 0000001987B8: BE81206A
	s_cbranch_execz 31                                         // 0000001987BC: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x103c>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001987C0: BF870092
	v_sub_f32_e32 v130, v148, v168                             // 0000001987C4: 09055194
	v_mul_f32_e32 v148, 0x3fb8aa3b, v130                       // 0000001987C8: 112904FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001987D0: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v130, vcc_lo             // 0000001987D4: 020304FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001987DC: BF870122
	v_fma_f32 v171, 0x3fb8aa3b, v130, -v148                    // 0000001987E0: D61300AB 865304FF 3FB8AA3B
	v_rndne_f32_e32 v174, v148                                 // 0000001987EC: 7F5C4794
	v_fmac_f32_e32 v171, 0x32a5705f, v130                      // 0000001987F0: 575704FF 32A5705F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001987F8: BF870092
	v_sub_f32_e32 v148, v148, v174                             // 0000001987FC: 09295D94
	v_add_f32_e32 v148, v148, v171                             // 000000198800: 07295794
	v_cvt_i32_f32_e32 v171, v174                               // 000000198804: 7F5611AE
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000198808: BF870292
	v_exp_f32_e32 v148, v148                                   // 00000019880C: 7F284B94
	.long 0xd71c0094                                           // 000000198810: D71C0094
	v_cndmask_b32_e32 v1, v148, v171, vcc_lo                   // 000000198814: 02035794
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000198818: BF8700A1
	v_cndmask_b32_e64 v148, 0, v148, s0                        // 00000019881C: D5010094 00032880
	.long 0xd41e0000                                           // 000000198824: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v130, vcc_lo             // 000000198828: 020304FF 42B17218
	v_cndmask_b32_e64 v130, 0x7f800000, v148, s0               // 000000198830: D5010082 000328FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000019883C: 8C7E017E
	v_dual_mov_b32 v148, 0 :: v_dual_mov_b32 v171, 0           // 000000198840: CA100080 94AA0080
	s_mov_b32 s1, exec_lo                                      // 000000198848: BE81007E
	v_cmpx_lt_f32_e32 0xefa18f08, v173                         // 00000019884C: 7D235AFF EFA18F08
	s_cbranch_execz 31                                         // 000000198854: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x10d4>
	v_sub_f32_e32 v171, v173, v168                             // 000000198858: 095751AD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019885C: BF870121
	v_mul_f32_e32 v173, 0x3fb8aa3b, v171                       // 000000198860: 115B56FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000198868: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v171, vcc_lo             // 00000019886C: 020356FF C2CE8ED0
	v_fma_f32 v174, 0x3fb8aa3b, v171, -v173                    // 000000198874: D61300AE 86B756FF 3FB8AA3B
	v_rndne_f32_e32 v175, v173                                 // 000000198880: 7F5E47AD
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000198884: BF870112
	v_fmac_f32_e32 v174, 0x32a5705f, v171                      // 000000198888: 575D56FF 32A5705F
	v_sub_f32_e32 v173, v173, v175                             // 000000198890: 095B5FAD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000198894: BF870121
	v_add_f32_e32 v173, v173, v174                             // 000000198898: 075B5DAD
	v_cvt_i32_f32_e32 v174, v175                               // 00000019889C: 7F5C11AF
	v_exp_f32_e32 v173, v173                                   // 0000001988A0: 7F5A4BAD
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001988A4: BF870095
	.long 0xd71c00ad                                           // 0000001988A8: D71C00AD
	v_cndmask_b32_e32 v1, v173, v174, vcc_lo                   // 0000001988AC: 02035DAD
	v_cndmask_b32_e64 v173, 0, v173, s0                        // 0000001988B0: D50100AD 00035A80
	.long 0xd41e0000                                           // 0000001988B8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v171, vcc_lo             // 0000001988BC: 020356FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001988C4: BF870001
	v_cndmask_b32_e64 v171, 0x7f800000, v173, s0               // 0000001988C8: D50100AB 00035AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001988D4: 8C7E017E
	v_add_f32_e32 v131, v131, v144                             // 0000001988D8: 07072183
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001988DC: BF870091
	v_mul_f32_e32 v131, 0x3d800000, v131                       // 0000001988E0: 110706FF 3D800000
	v_cndmask_b32_e32 v144, 0xf149f2ca, v131, vcc_lo           // 0000001988E8: 032106FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001988F0: BF870091
	v_mov_b32_dpp v173, v144 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001988F4: 7F5A02FA FF096190
	v_max_f32_e32 v173, v173, v173                             // 0000001988FC: 215B5BAD
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198900: BF870091
	v_max_f32_e32 v144, v144, v173                             // 000000198904: 21215B90
	v_mov_b32_dpp v173, v144 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198908: 7F5A02FA FF096290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198910: BF870091
	v_max_f32_e32 v173, v173, v173                             // 000000198914: 215B5BAD
	v_max_f32_e32 v144, v144, v173                             // 000000198918: 21215B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019891C: BF870091
	v_mov_b32_dpp v173, v144 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198920: 7F5A02FA FF096490
	v_max_f32_e32 v173, v173, v173                             // 000000198928: 215B5BAD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019892C: BF870121
	v_max_f32_e32 v144, v144, v173                             // 000000198930: 21215B90
	v_bfe_u32 v173, v130, 16, 1                                // 000000198934: D61000AD 02052182
	v_mov_b32_dpp v174, v144 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019893C: 7F5C02FA FF096890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000198944: BF870112
	v_add3_u32 v173, v130, v173, 0x7fff                        // 000000198948: D65500AD 03FF5B82 00007FFF
	v_max3_f32 v144, v172, v144, v174                          // 000000198954: D61C0090 06BB21AC
	ds_store_b16_d16_hi v152, v173                             // 00000019895C: DA840000 0000AD98
	s_and_saveexec_b32 s1, vcc_lo                              // 000000198964: BE81206A
	s_cbranch_execz 30                                         // 000000198968: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x11e4>
	v_sub_f32_e32 v131, v131, v144                             // 00000019896C: 09072183
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198970: BF870091
	v_mul_f32_e32 v148, 0x3fb8aa3b, v131                       // 000000198974: 112906FF 3FB8AA3B
	v_fma_f32 v173, 0x3fb8aa3b, v131, -v148                    // 00000019897C: D61300AD 865306FF 3FB8AA3B
	v_rndne_f32_e32 v174, v148                                 // 000000198988: 7F5C4794
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019898C: BF870121
	v_dual_sub_f32 v148, v148, v174 :: v_dual_fmac_f32 v173, 0x32a5705f, v131// 000000198990: C9415D94 94AD06FF 32A5705F
	.long 0xd41b0000                                           // 00000019899C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v131, vcc_lo             // 0000001989A0: 020306FF C2CE8ED0
	v_add_f32_e32 v148, v148, v173                             // 0000001989A8: 07295B94
	v_cvt_i32_f32_e32 v173, v174                               // 0000001989AC: 7F5A11AE
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001989B0: BF870292
	v_exp_f32_e32 v148, v148                                   // 0000001989B4: 7F284B94
	.long 0xd71c0094                                           // 0000001989B8: D71C0094
	v_cndmask_b32_e32 v1, v148, v173, vcc_lo                   // 0000001989BC: 02035B94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001989C0: BF8700A1
	v_cndmask_b32_e64 v148, 0, v148, s0                        // 0000001989C4: D5010094 00032880
	.long 0xd41e0000                                           // 0000001989CC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v131, vcc_lo             // 0000001989D0: 020306FF 42B17218
	v_cndmask_b32_e64 v148, 0x7f800000, v148, s0               // 0000001989D8: D5010094 000328FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001989E4: 8C7E017E
	v_mov_b32_e32 v131, 0                                      // 0000001989E8: 7F060280
	v_mov_b32_e32 v173, 0                                      // 0000001989EC: 7F5A0280
	s_mov_b32 s1, exec_lo                                      // 0000001989F0: BE81007E
	v_cmpx_lt_f32_e32 0xefa18f08, v172                         // 0000001989F4: 7D2358FF EFA18F08
	s_cbranch_execz 30                                         // 0000001989FC: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1278>
	v_sub_f32_e32 v172, v172, v144                             // 000000198A00: 095921AC
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198A04: BF870091
	v_mul_f32_e32 v173, 0x3fb8aa3b, v172                       // 000000198A08: 115B58FF 3FB8AA3B
	v_fma_f32 v174, 0x3fb8aa3b, v172, -v173                    // 000000198A10: D61300AE 86B758FF 3FB8AA3B
	v_rndne_f32_e32 v175, v173                                 // 000000198A1C: 7F5E47AD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000198A20: BF870121
	v_dual_sub_f32 v173, v173, v175 :: v_dual_fmac_f32 v174, 0x32a5705f, v172// 000000198A24: C9415FAD ADAF58FF 32A5705F
	.long 0xd41b0000                                           // 000000198A30: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v172, vcc_lo             // 000000198A34: 020358FF C2CE8ED0
	v_add_f32_e32 v173, v173, v174                             // 000000198A3C: 075B5DAD
	v_cvt_i32_f32_e32 v174, v175                               // 000000198A40: 7F5C11AF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000198A44: BF870292
	v_exp_f32_e32 v173, v173                                   // 000000198A48: 7F5A4BAD
	.long 0xd71c00ad                                           // 000000198A4C: D71C00AD
	v_cndmask_b32_e32 v1, v173, v174, vcc_lo                   // 000000198A50: 02035DAD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000198A54: BF8700A1
	v_cndmask_b32_e64 v173, 0, v173, s0                        // 000000198A58: D50100AD 00035A80
	.long 0xd41e0000                                           // 000000198A60: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v172, vcc_lo             // 000000198A64: 020358FF 42B17218
	v_cndmask_b32_e64 v173, 0x7f800000, v173, s0               // 000000198A6C: D50100AD 00035AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000198A78: 8C7E017E
	s_waitcnt lgkmcnt(3)                                       // 000000198A7C: BF89FC37
	v_add_f32_e32 v132, v132, v142                             // 000000198A80: 07091D84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198A84: BF870091
	v_mul_f32_e32 v132, 0x3d800000, v132                       // 000000198A88: 110908FF 3D800000
	v_cndmask_b32_e32 v142, 0xf149f2ca, v132, vcc_lo           // 000000198A90: 031D08FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198A98: BF870091
	v_mov_b32_dpp v172, v142 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198A9C: 7F5802FA FF09618E
	v_max_f32_e32 v172, v172, v172                             // 000000198AA4: 215959AC
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198AA8: BF870091
	v_max_f32_e32 v142, v142, v172                             // 000000198AAC: 211D598E
	v_mov_b32_dpp v172, v142 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198AB0: 7F5802FA FF09628E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198AB8: BF870091
	v_max_f32_e32 v172, v172, v172                             // 000000198ABC: 215959AC
	v_max_f32_e32 v142, v142, v172                             // 000000198AC0: 211D598E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198AC4: BF870091
	v_mov_b32_dpp v172, v142 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198AC8: 7F5802FA FF09648E
	v_max_f32_e32 v172, v172, v172                             // 000000198AD0: 215959AC
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000198AD4: BF870121
	v_max_f32_e32 v142, v142, v172                             // 000000198AD8: 211D598E
	v_bfe_u32 v172, v148, 16, 1                                // 000000198ADC: D61000AC 02052194
	v_mov_b32_dpp v174, v142 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198AE4: 7F5C02FA FF09688E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000198AEC: BF870112
	v_add3_u32 v172, v148, v172, 0x7fff                        // 000000198AF0: D65500AC 03FF5994 00007FFF
	v_max3_f32 v142, v170, v142, v174                          // 000000198AFC: D61C008E 06BB1DAA
	ds_store_b16_d16_hi v152, v172 offset:64                   // 000000198B04: DA840040 0000AC98
	s_and_saveexec_b32 s1, vcc_lo                              // 000000198B0C: BE81206A
	s_cbranch_execz 31                                         // 000000198B10: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1390>
	v_sub_f32_e32 v131, v132, v142                             // 000000198B14: 09071D84
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000198B18: BF870121
	v_mul_f32_e32 v132, 0x3fb8aa3b, v131                       // 000000198B1C: 110906FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000198B24: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v131, vcc_lo             // 000000198B28: 020306FF C2CE8ED0
	v_fma_f32 v172, 0x3fb8aa3b, v131, -v132                    // 000000198B30: D61300AC 861306FF 3FB8AA3B
	v_rndne_f32_e32 v174, v132                                 // 000000198B3C: 7F5C4784
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000198B40: BF870112
	v_fmac_f32_e32 v172, 0x32a5705f, v131                      // 000000198B44: 575906FF 32A5705F
	v_sub_f32_e32 v132, v132, v174                             // 000000198B4C: 09095D84
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000198B50: BF870121
	v_add_f32_e32 v132, v132, v172                             // 000000198B54: 07095984
	v_cvt_i32_f32_e32 v172, v174                               // 000000198B58: 7F5811AE
	v_exp_f32_e32 v132, v132                                   // 000000198B5C: 7F084B84
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198B60: BF870095
	.long 0xd71c0084                                           // 000000198B64: D71C0084
	v_cndmask_b32_e32 v1, v132, v172, vcc_lo                   // 000000198B68: 02035984
	v_cndmask_b32_e64 v132, 0, v132, s0                        // 000000198B6C: D5010084 00030880
	.long 0xd41e0000                                           // 000000198B74: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v131, vcc_lo             // 000000198B78: 020306FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000198B80: BF870001
	v_cndmask_b32_e64 v131, 0x7f800000, v132, s0               // 000000198B84: D5010083 000308FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000198B90: 8C7E017E
	v_mov_b32_e32 v132, 0                                      // 000000198B94: 7F080280
	v_mov_b32_e32 v172, 0                                      // 000000198B98: 7F580280
	s_mov_b32 s1, exec_lo                                      // 000000198B9C: BE81007E
	v_cmpx_lt_f32_e32 0xefa18f08, v170                         // 000000198BA0: 7D2354FF EFA18F08
	s_cbranch_execz 31                                         // 000000198BA8: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1428>
	v_sub_f32_e32 v170, v170, v142                             // 000000198BAC: 09551DAA
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000198BB0: BF870121
	v_mul_f32_e32 v172, 0x3fb8aa3b, v170                       // 000000198BB4: 115954FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000198BBC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v170, vcc_lo             // 000000198BC0: 020354FF C2CE8ED0
	v_fma_f32 v174, 0x3fb8aa3b, v170, -v172                    // 000000198BC8: D61300AE 86B354FF 3FB8AA3B
	v_rndne_f32_e32 v175, v172                                 // 000000198BD4: 7F5E47AC
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000198BD8: BF870112
	v_fmac_f32_e32 v174, 0x32a5705f, v170                      // 000000198BDC: 575D54FF 32A5705F
	v_sub_f32_e32 v172, v172, v175                             // 000000198BE4: 09595FAC
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000198BE8: BF870121
	v_add_f32_e32 v172, v172, v174                             // 000000198BEC: 07595DAC
	v_cvt_i32_f32_e32 v174, v175                               // 000000198BF0: 7F5C11AF
	v_exp_f32_e32 v172, v172                                   // 000000198BF4: 7F584BAC
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198BF8: BF870095
	.long 0xd71c00ac                                           // 000000198BFC: D71C00AC
	v_cndmask_b32_e32 v1, v172, v174, vcc_lo                   // 000000198C00: 02035DAC
	v_cndmask_b32_e64 v172, 0, v172, s0                        // 000000198C04: D50100AC 00035880
	.long 0xd41e0000                                           // 000000198C0C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v170, vcc_lo             // 000000198C10: 020354FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000198C18: BF870001
	v_cndmask_b32_e64 v172, 0x7f800000, v172, s0               // 000000198C1C: D50100AC 000358FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000198C28: 8C7E017E
	v_add_f32_e32 v133, v133, v143                             // 000000198C2C: 070B1F85
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198C30: BF870091
	v_mul_f32_e32 v133, 0x3d800000, v133                       // 000000198C34: 110B0AFF 3D800000
	v_cndmask_b32_e32 v143, 0xf149f2ca, v133, vcc_lo           // 000000198C3C: 031F0AFF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198C44: BF870091
	v_mov_b32_dpp v170, v143 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198C48: 7F5402FA FF09618F
	v_max_f32_e32 v170, v170, v170                             // 000000198C50: 215555AA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198C54: BF870091
	v_max_f32_e32 v143, v143, v170                             // 000000198C58: 211F558F
	v_mov_b32_dpp v170, v143 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198C5C: 7F5402FA FF09628F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198C64: BF870091
	v_max_f32_e32 v170, v170, v170                             // 000000198C68: 215555AA
	v_max_f32_e32 v143, v143, v170                             // 000000198C6C: 211F558F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198C70: BF870091
	v_mov_b32_dpp v170, v143 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198C74: 7F5402FA FF09648F
	v_max_f32_e32 v170, v170, v170                             // 000000198C7C: 215555AA
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000198C80: BF870121
	v_max_f32_e32 v143, v143, v170                             // 000000198C84: 211F558F
	v_bfe_u32 v170, v131, 16, 1                                // 000000198C88: D61000AA 02052183
	v_mov_b32_dpp v174, v143 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198C90: 7F5C02FA FF09688F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000198C98: BF870112
	v_add3_u32 v170, v131, v170, 0x7fff                        // 000000198C9C: D65500AA 03FF5583 00007FFF
	v_max3_f32 v143, v169, v143, v174                          // 000000198CA8: D61C008F 06BB1FA9
	ds_store_b16_d16_hi v152, v170 offset:128                  // 000000198CB0: DA840080 0000AA98
	s_and_saveexec_b32 s1, vcc_lo                              // 000000198CB8: BE81206A
	s_cbranch_execz 30                                         // 000000198CBC: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1538>
	v_sub_f32_e32 v132, v133, v143                             // 000000198CC0: 09091F85
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000198CC4: BF870121
	v_mul_f32_e32 v133, 0x3fb8aa3b, v132                       // 000000198CC8: 110B08FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000198CD0: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v132, vcc_lo             // 000000198CD4: 020308FF C2CE8ED0
	v_fma_f32 v170, 0x3fb8aa3b, v132, -v133                    // 000000198CDC: D61300AA 861708FF 3FB8AA3B
	v_rndne_f32_e32 v174, v133                                 // 000000198CE8: 7F5C4785
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198CEC: BF870091
	v_dual_fmac_f32 v170, 0x32a5705f, v132 :: v_dual_sub_f32 v133, v133, v174// 000000198CF0: C80B08FF AA855D85 32A5705F
	v_add_f32_e32 v133, v133, v170                             // 000000198CFC: 070B5585
	v_cvt_i32_f32_e32 v170, v174                               // 000000198D00: 7F5411AE
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000198D04: BF870292
	v_exp_f32_e32 v133, v133                                   // 000000198D08: 7F0A4B85
	.long 0xd71c0085                                           // 000000198D0C: D71C0085
	v_cndmask_b32_e32 v1, v133, v170, vcc_lo                   // 000000198D10: 02035585
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000198D14: BF8700A1
	v_cndmask_b32_e64 v133, 0, v133, s0                        // 000000198D18: D5010085 00030A80
	.long 0xd41e0000                                           // 000000198D20: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v132, vcc_lo             // 000000198D24: 020308FF 42B17218
	v_cndmask_b32_e64 v132, 0x7f800000, v133, s0               // 000000198D2C: D5010084 00030AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000198D38: 8C7E017E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v170, 0           // 000000198D3C: CA100080 85AA0080
	s_mov_b32 s1, exec_lo                                      // 000000198D44: BE81007E
	v_cmpx_lt_f32_e32 0xefa18f08, v169                         // 000000198D48: 7D2352FF EFA18F08
	s_cbranch_execz 31                                         // 000000198D50: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x15d0>
	v_sub_f32_e32 v169, v169, v143                             // 000000198D54: 09531FA9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198D58: BF870091
	v_mul_f32_e32 v170, 0x3fb8aa3b, v169                       // 000000198D5C: 115552FF 3FB8AA3B
	v_fma_f32 v174, 0x3fb8aa3b, v169, -v170                    // 000000198D64: D61300AE 86AB52FF 3FB8AA3B
	v_rndne_f32_e32 v175, v170                                 // 000000198D70: 7F5E47AA
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000198D74: BF870112
	v_fmac_f32_e32 v174, 0x32a5705f, v169                      // 000000198D78: 575D52FF 32A5705F
	v_sub_f32_e32 v170, v170, v175                             // 000000198D80: 09555FAA
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000198D84: BF8701B1
	v_add_f32_e32 v170, v170, v174                             // 000000198D88: 07555DAA
	v_cvt_i32_f32_e32 v174, v175                               // 000000198D8C: 7F5C11AF
	.long 0xd41b0000                                           // 000000198D90: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v169, vcc_lo             // 000000198D94: 020352FF C2CE8ED0
	v_exp_f32_e32 v170, v170                                   // 000000198D9C: 7F544BAA
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198DA0: BF870095
	.long 0xd71c00aa                                           // 000000198DA4: D71C00AA
	v_cndmask_b32_e32 v1, v170, v174, vcc_lo                   // 000000198DA8: 02035DAA
	v_cndmask_b32_e64 v170, 0, v170, s0                        // 000000198DAC: D50100AA 00035480
	.long 0xd41e0000                                           // 000000198DB4: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v169, vcc_lo             // 000000198DB8: 020352FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000198DC0: BF870001
	v_cndmask_b32_e64 v170, 0x7f800000, v170, s0               // 000000198DC4: D50100AA 000354FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000198DD0: 8C7E017E
	s_waitcnt lgkmcnt(4)                                       // 000000198DD4: BF89FC47
	v_add_f32_e32 v134, v134, v140                             // 000000198DD8: 070D1986
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198DDC: BF870091
	v_mul_f32_e32 v134, 0x3d800000, v134                       // 000000198DE0: 110D0CFF 3D800000
	v_cndmask_b32_e32 v140, 0xf149f2ca, v134, vcc_lo           // 000000198DE8: 03190CFF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198DF0: BF870091
	v_mov_b32_dpp v169, v140 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198DF4: 7F5202FA FF09618C
	v_max_f32_e32 v169, v169, v169                             // 000000198DFC: 215353A9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198E00: BF870091
	v_max_f32_e32 v140, v140, v169                             // 000000198E04: 2119538C
	v_mov_b32_dpp v169, v140 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198E08: 7F5202FA FF09628C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198E10: BF870091
	v_max_f32_e32 v169, v169, v169                             // 000000198E14: 215353A9
	v_max_f32_e32 v140, v140, v169                             // 000000198E18: 2119538C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198E1C: BF870091
	v_mov_b32_dpp v169, v140 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198E20: 7F5202FA FF09648C
	v_max_f32_e32 v169, v169, v169                             // 000000198E28: 215353A9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000198E2C: BF870121
	v_max_f32_e32 v140, v140, v169                             // 000000198E30: 2119538C
	v_bfe_u32 v169, v132, 16, 1                                // 000000198E34: D61000A9 02052184
	v_mov_b32_dpp v174, v140 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198E3C: 7F5C02FA FF09688C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000198E44: BF870112
	v_add3_u32 v169, v132, v169, 0x7fff                        // 000000198E48: D65500A9 03FF5384 00007FFF
	v_max3_f32 v140, v167, v140, v174                          // 000000198E54: D61C008C 06BB19A7
	ds_store_b16_d16_hi v152, v169 offset:192                  // 000000198E5C: DA8400C0 0000A998
	s_and_saveexec_b32 s1, vcc_lo                              // 000000198E64: BE81206A
	s_cbranch_execz 30                                         // 000000198E68: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x16e4>
	v_sub_f32_e32 v133, v134, v140                             // 000000198E6C: 090B1986
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000198E70: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v133                       // 000000198E74: 110D0AFF 3FB8AA3B
	.long 0xd41b0000                                           // 000000198E7C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v133, vcc_lo             // 000000198E80: 02030AFF C2CE8ED0
	v_fma_f32 v169, 0x3fb8aa3b, v133, -v134                    // 000000198E88: D61300A9 861B0AFF 3FB8AA3B
	v_rndne_f32_e32 v174, v134                                 // 000000198E94: 7F5C4786
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198E98: BF870091
	v_dual_fmac_f32 v169, 0x32a5705f, v133 :: v_dual_sub_f32 v134, v134, v174// 000000198E9C: C80B0AFF A9875D86 32A5705F
	v_add_f32_e32 v134, v134, v169                             // 000000198EA8: 070D5386
	v_cvt_i32_f32_e32 v169, v174                               // 000000198EAC: 7F5211AE
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000198EB0: BF870292
	v_exp_f32_e32 v134, v134                                   // 000000198EB4: 7F0C4B86
	.long 0xd71c0086                                           // 000000198EB8: D71C0086
	v_cndmask_b32_e32 v1, v134, v169, vcc_lo                   // 000000198EBC: 02035386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000198EC0: BF8700A1
	v_cndmask_b32_e64 v134, 0, v134, s0                        // 000000198EC4: D5010086 00030C80
	.long 0xd41e0000                                           // 000000198ECC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v133, vcc_lo             // 000000198ED0: 02030AFF 42B17218
	v_cndmask_b32_e64 v133, 0x7f800000, v134, s0               // 000000198ED8: D5010085 00030CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000198EE4: 8C7E017E
	v_dual_mov_b32 v134, 0 :: v_dual_mov_b32 v169, 0           // 000000198EE8: CA100080 86A80080
	s_mov_b32 s1, exec_lo                                      // 000000198EF0: BE81007E
	v_cmpx_lt_f32_e32 0xefa18f08, v167                         // 000000198EF4: 7D234EFF EFA18F08
	s_cbranch_execz 31                                         // 000000198EFC: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x177c>
	v_sub_f32_e32 v167, v167, v140                             // 000000198F00: 094F19A7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000198F04: BF870121
	v_mul_f32_e32 v169, 0x3fb8aa3b, v167                       // 000000198F08: 11534EFF 3FB8AA3B
	.long 0xd41b0000                                           // 000000198F10: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v167, vcc_lo             // 000000198F14: 02034EFF C2CE8ED0
	v_fma_f32 v174, 0x3fb8aa3b, v167, -v169                    // 000000198F1C: D61300AE 86A74EFF 3FB8AA3B
	v_rndne_f32_e32 v175, v169                                 // 000000198F28: 7F5E47A9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000198F2C: BF870112
	v_fmac_f32_e32 v174, 0x32a5705f, v167                      // 000000198F30: 575D4EFF 32A5705F
	v_sub_f32_e32 v169, v169, v175                             // 000000198F38: 09535FA9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000198F3C: BF870121
	v_add_f32_e32 v169, v169, v174                             // 000000198F40: 07535DA9
	v_cvt_i32_f32_e32 v174, v175                               // 000000198F44: 7F5C11AF
	v_exp_f32_e32 v169, v169                                   // 000000198F48: 7F524BA9
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198F4C: BF870095
	.long 0xd71c00a9                                           // 000000198F50: D71C00A9
	v_cndmask_b32_e32 v1, v169, v174, vcc_lo                   // 000000198F54: 02035DA9
	v_cndmask_b32_e64 v169, 0, v169, s0                        // 000000198F58: D50100A9 00035280
	.long 0xd41e0000                                           // 000000198F60: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v167, vcc_lo             // 000000198F64: 02034EFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000198F6C: BF870001
	v_cndmask_b32_e64 v169, 0x7f800000, v169, s0               // 000000198F70: D50100A9 000352FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000198F7C: 8C7E017E
	v_add_f32_e32 v135, v135, v141                             // 000000198F80: 070F1B87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198F84: BF870091
	v_mul_f32_e32 v141, 0x3d800000, v135                       // 000000198F88: 111B0EFF 3D800000
	v_cndmask_b32_e32 v135, 0xf149f2ca, v141, vcc_lo           // 000000198F90: 030F1AFF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198F98: BF870091
	v_mov_b32_dpp v167, v135 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198F9C: 7F4E02FA FF096187
	v_max_f32_e32 v167, v167, v167                             // 000000198FA4: 214F4FA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198FA8: BF870091
	v_max_f32_e32 v135, v135, v167                             // 000000198FAC: 210F4F87
	v_mov_b32_dpp v167, v135 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198FB0: 7F4E02FA FF096287
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198FB8: BF870091
	v_max_f32_e32 v167, v167, v167                             // 000000198FBC: 214F4FA7
	v_max_f32_e32 v135, v135, v167                             // 000000198FC0: 210F4F87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000198FC4: BF870091
	v_mov_b32_dpp v167, v135 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198FC8: 7F4E02FA FF096487
	v_max_f32_e32 v167, v167, v167                             // 000000198FD0: 214F4FA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000198FD4: BF870121
	v_max_f32_e32 v135, v135, v167                             // 000000198FD8: 210F4F87
	v_bfe_u32 v167, v133, 16, 1                                // 000000198FDC: D61000A7 02052185
	v_mov_b32_dpp v174, v135 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000198FE4: 7F5C02FA FF096887
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000198FEC: BF870112
	v_add3_u32 v167, v133, v167, 0x7fff                        // 000000198FF0: D65500A7 03FF4F85 00007FFF
	v_max3_f32 v135, v166, v135, v174                          // 000000198FFC: D61C0087 06BB0FA6
	ds_store_b16_d16_hi v152, v167 offset:256                  // 000000199004: DA840100 0000A798
	s_and_saveexec_b32 s1, vcc_lo                              // 00000019900C: BE81206A
	s_cbranch_execz 31                                         // 000000199010: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1890>
	v_sub_f32_e32 v134, v141, v135                             // 000000199014: 090D0F8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000199018: BF870121
	v_mul_f32_e32 v141, 0x3fb8aa3b, v134                       // 00000019901C: 111B0CFF 3FB8AA3B
	.long 0xd41b0000                                           // 000000199024: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v134, vcc_lo             // 000000199028: 02030CFF C2CE8ED0
	v_fma_f32 v167, 0x3fb8aa3b, v134, -v141                    // 000000199030: D61300A7 86370CFF 3FB8AA3B
	v_rndne_f32_e32 v174, v141                                 // 00000019903C: 7F5C478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000199040: BF870112
	v_fmac_f32_e32 v167, 0x32a5705f, v134                      // 000000199044: 574F0CFF 32A5705F
	v_sub_f32_e32 v141, v141, v174                             // 00000019904C: 091B5D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000199050: BF870121
	v_add_f32_e32 v141, v141, v167                             // 000000199054: 071B4F8D
	v_cvt_i32_f32_e32 v167, v174                               // 000000199058: 7F4E11AE
	v_exp_f32_e32 v141, v141                                   // 00000019905C: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000199060: BF870095
	.long 0xd71c008d                                           // 000000199064: D71C008D
	v_cndmask_b32_e32 v1, v141, v167, vcc_lo                   // 000000199068: 02034F8D
	v_cndmask_b32_e64 v141, 0, v141, s0                        // 00000019906C: D501008D 00031A80
	.long 0xd41e0000                                           // 000000199074: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v134, vcc_lo             // 000000199078: 02030CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000199080: BF870001
	v_cndmask_b32_e64 v134, 0x7f800000, v141, s0               // 000000199084: D5010086 00031AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000199090: 8C7E017E
	v_mov_b32_e32 v141, 0                                      // 000000199094: 7F1A0280
	v_mov_b32_e32 v167, 0                                      // 000000199098: 7F4E0280
	s_mov_b32 s1, exec_lo                                      // 00000019909C: BE81007E
	v_cmpx_lt_f32_e32 0xefa18f08, v166                         // 0000001990A0: 7D234CFF EFA18F08
	s_cbranch_execz 30                                         // 0000001990A8: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1924>
	v_sub_f32_e32 v166, v166, v135                             // 0000001990AC: 094D0FA6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001990B0: BF870091
	v_mul_f32_e32 v167, 0x3fb8aa3b, v166                       // 0000001990B4: 114F4CFF 3FB8AA3B
	v_fma_f32 v174, 0x3fb8aa3b, v166, -v167                    // 0000001990BC: D61300AE 869F4CFF 3FB8AA3B
	v_rndne_f32_e32 v175, v167                                 // 0000001990C8: 7F5E47A7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001990CC: BF870091
	v_dual_fmac_f32 v174, 0x32a5705f, v166 :: v_dual_sub_f32 v167, v167, v175// 0000001990D0: C80B4CFF AEA75FA7 32A5705F
	v_add_f32_e32 v167, v167, v174                             // 0000001990DC: 074F5DA7
	v_cvt_i32_f32_e32 v174, v175                               // 0000001990E0: 7F5C11AF
	.long 0xd41b0000                                           // 0000001990E4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v166, vcc_lo             // 0000001990E8: 02034CFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001990F0: BF870293
	v_exp_f32_e32 v167, v167                                   // 0000001990F4: 7F4E4BA7
	.long 0xd71c00a7                                           // 0000001990F8: D71C00A7
	v_cndmask_b32_e32 v1, v167, v174, vcc_lo                   // 0000001990FC: 02035DA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000199100: BF8700A1
	v_cndmask_b32_e64 v167, 0, v167, s0                        // 000000199104: D50100A7 00034E80
	.long 0xd41e0000                                           // 00000019910C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v166, vcc_lo             // 000000199110: 02034CFF 42B17218
	v_cndmask_b32_e64 v167, 0x7f800000, v167, s0               // 000000199118: D50100A7 00034EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000199124: 8C7E017E
	s_waitcnt lgkmcnt(5)                                       // 000000199128: BF89FC57
	v_add_f32_e32 v136, v136, v138                             // 00000019912C: 07111588
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000199130: BF870091
	v_mul_f32_e32 v138, 0x3d800000, v136                       // 000000199134: 111510FF 3D800000
	v_cndmask_b32_e32 v136, 0xf149f2ca, v138, vcc_lo           // 00000019913C: 031114FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000199144: BF870091
	v_mov_b32_dpp v166, v136 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199148: 7F4C02FA FF096188
	v_max_f32_e32 v166, v166, v166                             // 000000199150: 214D4DA6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000199154: BF870091
	v_max_f32_e32 v136, v136, v166                             // 000000199158: 21114D88
	v_mov_b32_dpp v166, v136 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019915C: 7F4C02FA FF096288
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000199164: BF870091
	v_max_f32_e32 v166, v166, v166                             // 000000199168: 214D4DA6
	v_max_f32_e32 v136, v136, v166                             // 00000019916C: 21114D88
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000199170: BF870091
	v_mov_b32_dpp v166, v136 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199174: 7F4C02FA FF096488
	v_max_f32_e32 v166, v166, v166                             // 00000019917C: 214D4DA6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000199180: BF870121
	v_max_f32_e32 v136, v136, v166                             // 000000199184: 21114D88
	v_bfe_u32 v166, v134, 16, 1                                // 000000199188: D61000A6 02052186
	v_mov_b32_dpp v174, v136 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199190: 7F5C02FA FF096888
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000199198: BF870112
	v_add3_u32 v166, v134, v166, 0x7fff                        // 00000019919C: D65500A6 03FF4D86 00007FFF
	v_max3_f32 v136, v165, v136, v174                          // 0000001991A8: D61C0088 06BB11A5
	ds_store_b16_d16_hi v152, v166 offset:320                  // 0000001991B0: DA840140 0000A698
	s_and_saveexec_b32 s1, vcc_lo                              // 0000001991B8: BE81206A
	s_cbranch_execz 31                                         // 0000001991BC: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1a3c>
	v_sub_f32_e32 v138, v138, v136                             // 0000001991C0: 0915118A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001991C4: BF870091
	v_mul_f32_e32 v141, 0x3fb8aa3b, v138                       // 0000001991C8: 111B14FF 3FB8AA3B
	v_fma_f32 v166, 0x3fb8aa3b, v138, -v141                    // 0000001991D0: D61300A6 863714FF 3FB8AA3B
	v_rndne_f32_e32 v174, v141                                 // 0000001991DC: 7F5C478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001991E0: BF870191
	v_sub_f32_e32 v141, v141, v174                             // 0000001991E4: 091B5D8D
	v_fmac_f32_e32 v166, 0x32a5705f, v138                      // 0000001991E8: 574D14FF 32A5705F
	.long 0xd41b0000                                           // 0000001991F0: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v138, vcc_lo             // 0000001991F4: 020314FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001991FC: BF870122
	v_add_f32_e32 v141, v141, v166                             // 000000199200: 071B4D8D
	v_cvt_i32_f32_e32 v166, v174                               // 000000199204: 7F4C11AE
	v_exp_f32_e32 v141, v141                                   // 000000199208: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019920C: BF870095
	.long 0xd71c008d                                           // 000000199210: D71C008D
	v_cndmask_b32_e32 v1, v141, v166, vcc_lo                   // 000000199214: 02034D8D
	v_cndmask_b32_e64 v141, 0, v141, s0                        // 000000199218: D501008D 00031A80
	.long 0xd41e0000                                           // 000000199220: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v138, vcc_lo             // 000000199224: 020314FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019922C: BF870001
	v_cndmask_b32_e64 v141, 0x7f800000, v141, s0               // 000000199230: D501008D 00031AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000019923C: 8C7E017E
	v_mov_b32_e32 v166, 0                                      // 000000199240: 7F4C0280
	v_mov_b32_e32 v138, 0                                      // 000000199244: 7F140280
	s_mov_b32 s1, exec_lo                                      // 000000199248: BE81007E
	v_cmpx_lt_f32_e32 0xefa18f08, v165                         // 00000019924C: 7D234AFF EFA18F08
	s_cbranch_execz 30                                         // 000000199254: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1ad0>
	v_sub_f32_e32 v138, v165, v136                             // 000000199258: 091511A5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019925C: BF870121
	v_mul_f32_e32 v165, 0x3fb8aa3b, v138                       // 000000199260: 114B14FF 3FB8AA3B
	.long 0xd41b0000                                           // 000000199268: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v138, vcc_lo             // 00000019926C: 020314FF C2CE8ED0
	v_fma_f32 v174, 0x3fb8aa3b, v138, -v165                    // 000000199274: D61300AE 869714FF 3FB8AA3B
	v_rndne_f32_e32 v175, v165                                 // 000000199280: 7F5E47A5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000199284: BF870091
	v_dual_fmac_f32 v174, 0x32a5705f, v138 :: v_dual_sub_f32 v165, v165, v175// 000000199288: C80B14FF AEA55FA5 32A5705F
	v_add_f32_e32 v165, v165, v174                             // 000000199294: 074B5DA5
	v_cvt_i32_f32_e32 v174, v175                               // 000000199298: 7F5C11AF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019929C: BF870292
	v_exp_f32_e32 v165, v165                                   // 0000001992A0: 7F4A4BA5
	.long 0xd71c00a5                                           // 0000001992A4: D71C00A5
	v_cndmask_b32_e32 v1, v165, v174, vcc_lo                   // 0000001992A8: 02035DA5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001992AC: BF8700A1
	v_cndmask_b32_e64 v165, 0, v165, s0                        // 0000001992B0: D50100A5 00034A80
	.long 0xd41e0000                                           // 0000001992B8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v138, vcc_lo             // 0000001992BC: 020314FF 42B17218
	v_cndmask_b32_e64 v138, 0x7f800000, v165, s0               // 0000001992C4: D501008A 00034AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001992D0: 8C7E017E
	v_add_f32_e32 v137, v137, v139                             // 0000001992D4: 07131789
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001992D8: BF870091
	v_mul_f32_e32 v139, 0x3d800000, v137                       // 0000001992DC: 111712FF 3D800000
	v_cndmask_b32_e32 v137, 0xf149f2ca, v139, vcc_lo           // 0000001992E4: 031316FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001992EC: BF870091
	v_mov_b32_dpp v165, v137 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001992F0: 7F4A02FA FF096189
	v_max_f32_e32 v165, v165, v165                             // 0000001992F8: 214B4BA5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001992FC: BF870091
	v_max_f32_e32 v137, v137, v165                             // 000000199300: 21134B89
	v_mov_b32_dpp v165, v137 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199304: 7F4A02FA FF096289
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019930C: BF870091
	v_max_f32_e32 v165, v165, v165                             // 000000199310: 214B4BA5
	v_max_f32_e32 v137, v137, v165                             // 000000199314: 21134B89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000199318: BF870091
	v_mov_b32_dpp v165, v137 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019931C: 7F4A02FA FF096489
	v_max_f32_e32 v165, v165, v165                             // 000000199324: 214B4BA5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000199328: BF870121
	v_max_f32_e32 v137, v137, v165                             // 00000019932C: 21134B89
	v_bfe_u32 v165, v141, 16, 1                                // 000000199330: D61000A5 0205218D
	v_mov_b32_dpp v174, v137 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199338: 7F5C02FA FF096889
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000199340: BF870112
	v_add3_u32 v165, v141, v165, 0x7fff                        // 000000199344: D65500A5 03FF4B8D 00007FFF
	v_max3_f32 v137, v164, v137, v174                          // 000000199350: D61C0089 06BB13A4
	ds_store_b16_d16_hi v152, v165 offset:384                  // 000000199358: DA840180 0000A598
	s_and_saveexec_b32 s0, vcc_lo                              // 000000199360: BE80206A
	s_cbranch_execz 26                                         // 000000199364: BFA5001A <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1bd0>
	v_sub_f32_e32 v139, v139, v137                             // 000000199368: 0917138B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019936C: BF870121
	v_mul_f32_e32 v165, 0x3fb8aa3b, v139                       // 000000199370: 114B16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v139                 // 000000199378: 7C3716FF C2CE8ED0
	v_fma_f32 v166, 0x3fb8aa3b, v139, -v165                    // 000000199380: D61300A6 869716FF 3FB8AA3B
	v_rndne_f32_e32 v174, v165                                 // 00000019938C: 7F5C47A5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000199390: BF870091
	v_dual_fmac_f32 v166, 0x32a5705f, v139 :: v_dual_sub_f32 v165, v165, v174// 000000199394: C80B16FF A6A55DA5 32A5705F
	v_add_f32_e32 v165, v165, v166                             // 0000001993A0: 074B4DA5
	v_cvt_i32_f32_e32 v166, v174                               // 0000001993A4: 7F4C11AE
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001993A8: BF870292
	v_exp_f32_e32 v165, v165                                   // 0000001993AC: 7F4A4BA5
	.long 0xd71c00a5                                           // 0000001993B0: D71C00A5
	v_cndmask_b32_e32 v1, v165, v166, vcc_lo                   // 0000001993B4: 02034DA5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001993B8: BF870121
	v_cndmask_b32_e32 v165, 0, v165, vcc_lo                    // 0000001993BC: 034B4A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v139                 // 0000001993C0: 7C3D16FF 42B17218
	v_cndmask_b32_e32 v166, 0x7f800000, v165, vcc_lo           // 0000001993C8: 034D4AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001993D0: 8C7E007E
	v_mov_b32_e32 v139, 0                                      // 0000001993D4: 7F160280
	s_mov_b32 s0, exec_lo                                      // 0000001993D8: BE80007E
	v_cmpx_lt_f32_e32 0xefa18f08, v164                         // 0000001993DC: 7D2348FF EFA18F08
	s_cbranch_execz 64455                                      // 0000001993E4: BFA5FBC7 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xb04>
	v_sub_f32_e32 v139, v164, v137                             // 0000001993E8: 091713A4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001993EC: BF870121
	v_mul_f32_e32 v164, 0x3fb8aa3b, v139                       // 0000001993F0: 114916FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v139                 // 0000001993F8: 7C3716FF C2CE8ED0
	v_fma_f32 v165, 0x3fb8aa3b, v139, -v164                    // 000000199400: D61300A5 869316FF 3FB8AA3B
	v_rndne_f32_e32 v174, v164                                 // 00000019940C: 7F5C47A4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000199410: BF870091
	v_dual_fmac_f32 v165, 0x32a5705f, v139 :: v_dual_sub_f32 v164, v164, v174// 000000199414: C80B16FF A5A55DA4 32A5705F
	v_add_f32_e32 v164, v164, v165                             // 000000199420: 07494BA4
	v_cvt_i32_f32_e32 v165, v174                               // 000000199424: 7F4A11AE
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000199428: BF870292
	v_exp_f32_e32 v164, v164                                   // 00000019942C: 7F484BA4
	.long 0xd71c00a4                                           // 000000199430: D71C00A4
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                   // 000000199434: 02034BA4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000199438: BF870121
	v_cndmask_b32_e32 v164, 0, v164, vcc_lo                    // 00000019943C: 03494880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v139                 // 000000199440: 7C3D16FF 42B17218
	v_cndmask_b32_e32 v139, 0x7f800000, v164, vcc_lo           // 000000199448: 031748FF 7F800000
	s_branch 64428                                             // 000000199450: BFA0FBAC <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi2ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xb04>
	v_mov_b32_e32 v8, v147                                     // 000000199454: 7E100393
	s_mul_i32 s0, s20, 12                                      // 000000199458: 96008C14
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019945C: BF870001
	v_or_b32_e32 v7, v8, v145                                  // 000000199460: 380F2308
	v_or_b32_e32 v0, s0, v146                                  // 000000199464: 38012400
	v_mov_b32_dpp v78, v134 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199468: 7E9C02FA FF096186
	v_mov_b32_dpp v75, v132 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199470: 7E9602FA FF096184
	v_mov_b32_dpp v74, v131 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199478: 7E9402FA FF096183
	v_mov_b32_dpp v76, v133 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199480: 7E9802FA FF096185
	v_lshlrev_b32_e32 v0, 8, v0                                // 000000199488: 30000088
	v_mov_b32_e32 v8, 0                                        // 00000019948C: 7E100280
	v_dual_add_f32 v78, v134, v78 :: v_dual_add_f32 v81, v132, v75// 000000199490: C9089D86 4E509784
	v_add_f32_e32 v83, v131, v74                               // 000000199498: 06A69583
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019949C: BF870214
	v_add_nc_u32_e32 v23, 0x400, v0                            // 0000001994A0: 4A2E00FF 00000400
	v_mad_i64_i32 v[7:8], null, 0x1800, s2, v[7:8]             // 0000001994A8: D6FF7C07 041C04FF 00001800
	v_ashrrev_i32_e32 v16, 31, v0                              // 0000001994B4: 3420009F
	v_add_nc_u32_e32 v31, 0x600, v0                            // 0000001994B8: 4A3E00FF 00000600
	v_add_nc_u32_e32 v39, 0x800, v0                            // 0000001994C0: 4A4E00FF 00000800
	v_ashrrev_i32_e32 v24, 31, v23                             // 0000001994C8: 34302E9F
	v_or_b32_e32 v65, 0x200, v0                                // 0000001994CC: 388200FF 00000200
	v_add_f32_dpp v81, v81, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001994D4: 06A2A2FA FF096251
	v_ashrrev_i32_e32 v32, 31, v31                             // 0000001994DC: 34403E9F
	.long 0xd7006a0f                                           // 0000001994E0: D7006A0F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000001994E4: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001994E8: BF8700A1
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 0000001994EC: D5207C10 01AA2108
	.long 0xd7006a17                                           // 0000001994F4: D7006A17
	v_cndmask_b32_e32 v1, v7, v23, vcc_lo                      // 0000001994F8: 02022F07
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 0000001994FC: D5207C18 01AA3108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000199504: BF870233
	.long 0xd73c000f                                           // 000000199508: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 00000019950C: 02021E81
	v_add_nc_u32_e32 v0, 0xa00, v0                             // 000000199510: 4A0000FF 00000A00
	v_ashrrev_i32_e32 v40, 31, v39                             // 000000199518: 34504E9F
	.long 0xd73c0017                                           // 00000019951C: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 000000199520: 02022E81
	v_ashrrev_i32_e32 v66, 31, v65                             // 000000199524: 3484829F
	v_add_f32_dpp v78, v78, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199528: 069C9CFA FF09624E
	.long 0xd7006a45                                           // 000000199530: D7006A45
	v_cndmask_b32_e32 v1, s10, v15, vcc_lo                     // 000000199534: 02021E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000199538: BF8700A1
	v_add_co_ci_u32_e64 v70, null, s11, v16, vcc_lo            // 00000019953C: D5207C46 01AA200B
	.long 0xd7006a1f                                           // 000000199544: D7006A1F
	v_cndmask_b32_e32 v1, v7, v31, vcc_lo                      // 000000199548: 02023F07
	v_add_co_ci_u32_e64 v32, null, v8, v32, vcc_lo             // 00000019954C: D5207C20 01AA4108
	.long 0xd7006a37                                           // 000000199554: D7006A37
	v_cndmask_b32_e32 v1, s10, v23, vcc_lo                     // 000000199558: 02022E0A
	v_ashrrev_i32_e32 v48, 31, v0                              // 00000019955C: 3460009F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000199560: BF8700B3
	.long 0xd73c001f                                           // 000000199564: D73C001F
	v_cndmask_b32_e32 v1, 1, v31, vcc_lo                       // 000000199568: 02023E81
	v_add_co_ci_u32_e64 v56, null, s11, v24, vcc_lo            // 00000019956C: D5207C38 01AA300B
	.long 0xd7006a27                                           // 000000199574: D7006A27
	v_cndmask_b32_e32 v1, v7, v39, vcc_lo                      // 000000199578: 02024F07
	v_add_co_ci_u32_e64 v40, null, v8, v40, vcc_lo             // 00000019957C: D5207C28 01AA5108
	.long 0xd7006a2f                                           // 000000199584: D7006A2F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 000000199588: 02020107
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019958C: BF870001
	v_add_co_ci_u32_e64 v48, null, v8, v48, vcc_lo             // 000000199590: D5207C30 01AA6108
	.long 0xd7006a3f                                           // 000000199598: D7006A3F
	v_cndmask_b32_e32 v1, s10, v31, vcc_lo                     // 00000019959C: 02023E0A
	global_load_u16 v73, v[69:70], off offset:1024             // 0000001995A0: DC4A0400 497C0045
	v_add_co_ci_u32_e64 v64, null, s11, v32, vcc_lo            // 0000001995A8: D5207C40 01AA400B
	.long 0xd7006a07                                           // 0000001995B0: D7006A07
	v_cndmask_b32_e32 v1, v7, v65, vcc_lo                      // 0000001995B4: 02028307
	s_clause 0x2                                               // 0000001995B8: BF850002
	global_load_u16 v80, v[69:70], off                         // 0000001995BC: DC4A0000 507C0045
	global_load_u16 v82, v[69:70], off offset:32               // 0000001995C4: DC4A0020 527C0045
	global_load_u16 v103, v[69:70], off offset:64              // 0000001995CC: DC4A0040 677C0045
	v_add_co_ci_u32_e64 v8, null, v8, v66, vcc_lo              // 0000001995D4: D5207C08 01AA8508
	.long 0xd73c0027                                           // 0000001995DC: D73C0027
	v_cndmask_b32_e32 v1, 1, v39, vcc_lo                       // 0000001995E0: 02024E81
	.long 0xd73c002f                                           // 0000001995E4: D73C002F
	v_cndmask_b32_e32 v1, 1, v47, vcc_lo                       // 0000001995E8: 02025E81
	v_add_f32_dpp v81, v81, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001995EC: 06A2A2FA FF096451
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001995F4: BF8700C4
	.long 0xd73c0056                                           // 0000001995F8: D73C0056
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000001995FC: 02020E81
	v_mov_b32_dpp v8, v148 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199600: 7E1002FA FF096194
	v_mov_b32_dpp v7, v130 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199608: 7E0E02FA FF096182
	.long 0xd7006a43                                           // 000000199610: D7006A43
	v_cndmask_b32_e32 v1, s10, v39, vcc_lo                     // 000000199614: 02024E0A
	v_add_co_ci_u32_e64 v68, null, s11, v40, vcc_lo            // 000000199618: D5207C44 01AA500B
	.long 0xd7006a41                                           // 000000199620: D7006A41
	v_cndmask_b32_e32 v1, s10, v47, vcc_lo                     // 000000199624: 02025E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000199628: BF8700A1
	v_add_co_ci_u32_e64 v66, null, s11, v48, vcc_lo            // 00000019962C: D5207C42 01AA600B
	.long 0xd7006a47                                           // 000000199634: D7006A47
	v_cndmask_b32_e32 v1, s10, v86, vcc_lo                     // 000000199638: 0202AC0A
	v_add_co_ci_u32_e64 v72, null, s11, v87, vcc_lo            // 00000019963C: D5207C48 01AAAE0B
	s_clause 0x9                                               // 000000199644: BF850009
	global_load_u16 v99, v[63:64], off                         // 000000199648: DC4A0000 637C003F
	global_load_u16 v98, v[55:56], off                         // 000000199650: DC4A0000 627C0037
	global_load_u16 v101, v[65:66], off                        // 000000199658: DC4A0000 657C0041
	global_load_u16 v100, v[67:68], off                        // 000000199660: DC4A0000 647C0043
	global_load_u16 v102, v[71:72], off offset:32              // 000000199668: DC4A0020 667C0047
	global_load_u16 v94, v[63:64], off offset:32               // 000000199670: DC4A0020 5E7C003F
	global_load_u16 v93, v[55:56], off offset:32               // 000000199678: DC4A0020 5D7C0037
	global_load_u16 v96, v[65:66], off offset:32               // 000000199680: DC4A0020 607C0041
	global_load_u16 v95, v[67:68], off offset:32               // 000000199688: DC4A0020 5F7C0043
	global_load_u16 v97, v[71:72], off offset:64               // 000000199690: DC4A0040 617C0047
	v_dual_add_f32 v8, v148, v8 :: v_dual_add_f32 v7, v130, v7 // 000000199698: C9081194 08060F82
	v_add_f32_dpp v78, v78, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001996A0: 069C9CFA FF09644E
	v_add_f32_dpp v88, v81, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001996A8: 06B0A2FA FF096851
	v_add_f32_dpp v83, v83, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001996B0: 06A6A6FA FF096253
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001996B8: BF870004
	v_add_f32_dpp v8, v8, v8 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001996BC: 061010FA FF096208
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001996C4: 060E0EFA FF096207
	v_add_f32_dpp v81, v78, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001996CC: 06A29CFA FF09684E
	v_div_scale_f32 v110, null, v88, v88, 1.0                  // 0000001996D4: D6FC7C6E 03CAB158
	v_add_f32_dpp v83, v83, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001996DC: 06A6A6FA FF096453
	v_add_f32_dpp v8, v8, v8 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001996E4: 061010FA FF096408
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001996EC: 060E0EFA FF096407
	v_div_scale_f32 v115, null, v81, v81, 1.0                  // 0000001996F4: D6FC7C73 03CAA351
	v_rcp_f32_e32 v90, v110                                    // 0000001996FC: 7EB4556E
	v_add_f32_dpp v89, v83, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199700: 06B2A6FA FF096853
	v_add_f32_dpp v107, v8, v8 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199708: 06D610FA FF096808
	v_add_f32_dpp v108, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199710: 06D80EFA FF096807
	.long 0xd7000507                                           // 000000199718: D7000507
	v_cndmask_b32_e32 v1, s12, v15, vcc_lo                     // 00000019971C: 02021E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000199720: BF870211
	v_add_co_ci_u32_e64 v8, null, s13, v16, s5                 // 000000199724: D5207C08 0016200D
	v_div_scale_f32 v118, null, v107, v107, 1.0                // 00000019972C: D6FC7C76 03CAD76B
	.long 0xd700050f                                           // 000000199734: D700050F
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 000000199738: 02022E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019973C: BF870191
	v_add_co_ci_u32_e64 v16, null, s13, v24, s5                // 000000199740: D5207C10 0016300D
	v_rcp_f32_e32 v121, v118                                   // 000000199748: 7EF25576
	.long 0xd7000517                                           // 00000019974C: D7000517
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 000000199750: 02023E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000199754: BF8700A1
	v_add_co_ci_u32_e64 v24, null, s13, v32, s5                // 000000199758: D5207C18 0016400D
	.long 0xd700051f                                           // 000000199760: D700051F
	v_cndmask_b32_e32 v1, s12, v39, vcc_lo                     // 000000199764: 02024E0C
	v_add_co_ci_u32_e64 v32, null, s13, v40, s5                // 000000199768: D5207C20 0016500D
	.long 0xd7000527                                           // 000000199770: D7000527
	v_cndmask_b32_e32 v1, s12, v47, vcc_lo                     // 000000199774: 02025E0C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000199778: BF870001
	v_add_co_ci_u32_e64 v40, null, s13, v48, s5                // 00000019977C: D5207C28 0016600D
	.long 0xd700052f                                           // 000000199784: D700052F
	v_cndmask_b32_e32 v1, s12, v86, vcc_lo                     // 000000199788: 0202AC0C
	v_add_f32_e32 v84, v133, v76                               // 00000019978C: 06A89985
	v_add_co_ci_u32_e64 v48, null, s13, v87, s5                // 000000199790: D5207C30 0016AE0D
	s_clause 0x1f                                              // 000000199798: BF85001F
	global_load_u16 v78, v[69:70], off offset:96               // 00000019979C: DC4A0060 4E7C0045
	global_load_u16 v86, v[69:70], off offset:128              // 0000001997A4: DC4A0080 567C0045
	global_load_u16 v87, v[69:70], off offset:160              // 0000001997AC: DC4A00A0 577C0045
	global_load_u16 v92, v[69:70], off offset:192              // 0000001997B4: DC4A00C0 5C7C0045
	global_load_u16 v69, v[69:70], off offset:224              // 0000001997BC: DC4A00E0 457C0045
	global_load_u16 v138, v[55:56], off offset:64              // 0000001997C4: DC4A0040 8A7C0037
	global_load_u16 v133, v[55:56], off offset:96              // 0000001997CC: DC4A0060 857C0037
	global_load_u16 v128, v[55:56], off offset:128             // 0000001997D4: DC4A0080 807C0037
	global_load_u16 v124, v[55:56], off offset:160             // 0000001997DC: DC4A00A0 7C7C0037
	global_load_u16 v104, v[55:56], off offset:192             // 0000001997E4: DC4A00C0 687C0037
	global_load_u16 v137, v[63:64], off offset:64              // 0000001997EC: DC4A0040 897C003F
	global_load_u16 v132, v[63:64], off offset:96              // 0000001997F4: DC4A0060 847C003F
	global_load_u16 v127, v[63:64], off offset:128             // 0000001997FC: DC4A0080 7F7C003F
	global_load_u16 v123, v[63:64], off offset:160             // 000000199804: DC4A00A0 7B7C003F
	global_load_u16 v70, v[63:64], off offset:192              // 00000019980C: DC4A00C0 467C003F
	global_load_u16 v56, v[55:56], off offset:224              // 000000199814: DC4A00E0 387C0037
	global_load_u16 v140, v[67:68], off offset:64              // 00000019981C: DC4A0040 8C7C0043
	global_load_u16 v135, v[67:68], off offset:96              // 000000199824: DC4A0060 877C0043
	global_load_u16 v130, v[67:68], off offset:128             // 00000019982C: DC4A0080 827C0043
	global_load_u16 v126, v[67:68], off offset:160             // 000000199834: DC4A00A0 7E7C0043
	global_load_u16 v106, v[67:68], off offset:192             // 00000019983C: DC4A00C0 6A7C0043
	global_load_u16 v55, v[63:64], off offset:224              // 000000199844: DC4A00E0 377C003F
	global_load_u16 v139, v[65:66], off offset:64              // 00000019984C: DC4A0040 8B7C0041
	global_load_u16 v134, v[65:66], off offset:96              // 000000199854: DC4A0060 867C0041
	global_load_u16 v129, v[65:66], off offset:128             // 00000019985C: DC4A0080 817C0041
	global_load_u16 v125, v[65:66], off offset:160             // 000000199864: DC4A00A0 7D7C0041
	global_load_u16 v105, v[65:66], off offset:192             // 00000019986C: DC4A00C0 697C0041
	global_load_u16 v63, v[67:68], off offset:224              // 000000199874: DC4A00E0 3F7C0043
	global_load_u16 v141, v[71:72], off offset:96              // 00000019987C: DC4A0060 8D7C0047
	global_load_u16 v136, v[71:72], off offset:128             // 000000199884: DC4A0080 887C0047
	global_load_u16 v131, v[71:72], off offset:160             // 00000019988C: DC4A00A0 837C0047
	global_load_u16 v68, v[71:72], off offset:192              // 000000199894: DC4A00C0 447C0047
	s_clause 0x1                                               // 00000019989C: BF850001
	global_load_u16 v67, v[71:72], off offset:224              // 0000001998A0: DC4A00E0 437C0047
	global_load_u16 v64, v[65:66], off offset:224              // 0000001998A8: DC4A00E0 407C0041
	v_fma_f32 v66, -v118, v121, 1.0                            // 0000001998B0: D6130042 23CAF376
	v_div_scale_f32 v117, null, v108, v108, 1.0                // 0000001998B8: D6FC7C75 03CAD96C
	v_div_scale_f32 v119, vcc_lo, 1.0, v108, 1.0               // 0000001998C0: D6FC6A77 03CAD8F2
	v_div_scale_f32 v120, s4, 1.0, v107, 1.0                   // 0000001998C8: D6FC0478 03CAD6F2
	v_div_scale_f32 v109, null, v89, v89, 1.0                  // 0000001998D0: D6FC7C6D 03CAB359
	v_fmac_f32_e32 v121, v66, v121                             // 0000001998D8: 56F2F342
	v_add_f32_dpp v84, v84, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001998DC: 06A8A8FA FF096254
	v_rcp_f32_e32 v122, v117                                   // 0000001998E4: 7EF45575
	v_div_scale_f32 v112, s2, 1.0, v89, 1.0                    // 0000001998E8: D6FC0270 03CAB2F2
	v_rcp_f32_e32 v91, v109                                    // 0000001998F0: 7EB6556D
	v_mul_f32_e32 v66, v120, v121                              // 0000001998F4: 1084F378
	v_add_f32_dpp v84, v84, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001998F8: 06A8A8FA FF096454
	v_div_scale_f32 v116, s1, 1.0, v81, 1.0                    // 000000199900: D6FC0174 03CAA2F2
	v_fma_f32 v72, -v110, v90, 1.0                             // 000000199908: D6130048 23CAB56E
	v_div_scale_f32 v113, s3, 1.0, v88, 1.0                    // 000000199910: D6FC0371 03CAB0F2
	v_fma_f32 v145, -v118, v66, v120                           // 000000199918: D6130091 25E28576
	v_add_f32_dpp v83, v84, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000199920: 06A6A8FA FF096854
	v_fma_f32 v65, -v117, v122, 1.0                            // 000000199928: D6130041 23CAF575
	v_rcp_f32_e32 v84, v115                                    // 000000199930: 7EA85573
	v_fma_f32 v71, -v109, v91, 1.0                             // 000000199934: D6130047 23CAB76D
	v_fmac_f32_e32 v66, v145, v121                             // 00000019993C: 5684F391
	v_div_scale_f32 v111, null, v83, v83, 1.0                  // 000000199940: D6FC7C6F 03CAA753
	v_fmac_f32_e32 v122, v65, v122                             // 000000199948: 56F4F541
	v_div_scale_f32 v114, s0, 1.0, v83, 1.0                    // 00000019994C: D6FC0072 03CAA6F2
	v_dual_fmac_f32 v91, v71, v91 :: v_dual_fmac_f32 v90, v72, v90// 000000199954: C800B747 5B5AB548
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019995C: BF870194
	v_rcp_f32_e32 v85, v111                                    // 000000199960: 7EAA556F
	v_mul_f32_e32 v65, v119, v122                              // 000000199964: 1082F577
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000199968: BF870236
	v_fma_f32 v143, -v115, v84, 1.0                            // 00000019996C: D613008F 23CAA973
	v_fma_f32 v118, -v118, v66, v120                           // 000000199974: D6130076 25E28576
	v_dual_mul_f32 v71, v112, v91 :: v_dual_mul_f32 v72, v113, v90// 00000019997C: C8C6B770 4748B571
	v_fma_f32 v144, -v117, v65, v119                           // 000000199984: D6130090 25DE8375
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019998C: BF870224
	v_fmac_f32_e32 v84, v143, v84                              // 000000199990: 56A8A98F
	.long 0x7f003880                                           // 000000199994: 7F003880
	v_fma_f32 v146, -v109, v71, v112                           // 000000199998: D6130092 25C28F6D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001999A0: BF870005
	v_fma_f32 v142, -v111, v85, 1.0                            // 0000001999A4: D613008E 23CAAB6F
	v_fmac_f32_e32 v65, v144, v122                             // 0000001999AC: 5682F590
	v_mul_f32_e32 v143, v116, v84                              // 0000001999B0: 111EA974
	v_fma_f32 v147, -v110, v72, v113                           // 0000001999B4: D6130093 25C6916E
	v_fmac_f32_e32 v71, v146, v91                              // 0000001999BC: 568EB792
	v_fmac_f32_e32 v85, v142, v85                              // 0000001999C0: 56AAAB8E
	v_fma_f32 v117, -v117, v65, v119                           // 0000001999C4: D6130075 25DE8375
	v_fma_f32 v144, -v115, v143, v116                          // 0000001999CC: D6130090 25D31F73
	v_fmac_f32_e32 v72, v147, v90                              // 0000001999D4: 5690B593
	v_fma_f32 v109, -v109, v71, v112                           // 0000001999D8: D613006D 25C28F6D
	v_mul_f32_e32 v142, v114, v85                              // 0000001999E0: 111CAB72
	v_div_fmas_f32 v65, v117, v122, v65                        // 0000001999E4: D6370041 0506F575
	s_mov_b32 vcc_lo, s4                                       // 0000001999EC: BEEA0004
	.long 0x7f9e3980                                           // 0000001999F0: 7F9E3980
	v_div_fmas_f32 v117, v118, v121, v66                       // 0000001999F4: D6370075 050AF376
	v_fma_f32 v148, -v111, v142, v114                          // 0000001999FC: D6130094 25CB1D6F
	v_div_fixup_f32 v66, v65, v108, 1.0                        // 000000199A04: D6270042 03CAD941
	v_fma_f32 v108, -v110, v72, v113                           // 000000199A0C: D613006C 25C6916E
	.long 0x7f983980                                           // 000000199A14: 7F983980
	v_div_fixup_f32 v65, v117, v107, 1.0                       // 000000199A18: D6270041 03CAD775
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000199A20: BF870234
	v_dual_fmac_f32 v142, v148, v85 :: v_dual_mul_f32 v57, v57, v66// 000000199A24: C806AB94 8E388539
	v_fmac_f32_e32 v143, v144, v84                             // 000000199A2C: 571EA990
	.long 0x7f9a3980                                           // 000000199A30: 7F9A3980
	v_mul_f32_e32 v58, v58, v65                                // 000000199A34: 1074833A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000199A38: BF870004
	v_fma_f32 v107, -v111, v142, v114                          // 000000199A3C: D613006B 25CB1D6F
	v_mul_f32_e32 v111, v49, v66                               // 000000199A44: 10DE8531
	v_fma_f32 v110, -v115, v143, v116                          // 000000199A48: D613006E 25D31F73
	.long 0x7f963980                                           // 000000199A50: 7F963980
	.long 0x7f943980                                           // 000000199A54: 7F943980
	v_dual_mul_f32 v33, v33, v66 :: v_dual_mul_f32 v26, v26, v65// 000000199A58: C8C68521 211A831A
	v_mul_f32_e32 v25, v25, v66                                // 000000199A60: 10328519
	v_mul_f32_e32 v17, v17, v66                                // 000000199A64: 10228511
	v_mul_f32_e32 v9, v9, v66                                  // 000000199A68: 10128509
	v_dual_mul_f32 v1, v1, v66 :: v_dual_mul_f32 v18, v18, v65 // 000000199A6C: C8C68501 01128312
	v_mul_f32_e32 v42, v42, v65                                // 000000199A74: 1054832A
	v_mul_f32_e32 v34, v34, v65                                // 000000199A78: 10448322
	v_mul_f32_e32 v10, v10, v65                                // 000000199A7C: 1014830A
	v_mul_f32_e32 v2, v2, v65                                  // 000000199A80: 10048302
	s_waitcnt vmcnt(47)                                        // 000000199A84: BF89BFF7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000199A88: 30929290
	s_waitcnt vmcnt(46)                                        // 000000199A8C: BF89BBF7
	v_dual_mul_f32 v80, v50, v65 :: v_dual_lshlrev_b32 v49, 16, v80// 000000199A90: C8E28332 5030A090
	s_waitcnt vmcnt(45)                                        // 000000199A98: BF89B7F7
	v_lshlrev_b32_e32 v50, 16, v82                             // 000000199A9C: 3064A490
	s_waitcnt vmcnt(44)                                        // 000000199AA0: BF89B3F7
	v_lshlrev_b32_e32 v82, 16, v103                            // 000000199AA4: 30A4CE90
	s_delay_alu instid0(VALU_DEP_1)                            // 000000199AA8: BF870001
	v_mul_f32_e32 v114, 0xbfb8aa3b, v82                        // 000000199AAC: 10E4A4FF BFB8AA3B
	v_mul_f32_e32 v112, 0xbfb8aa3b, v73                        // 000000199AB4: 10E092FF BFB8AA3B
	v_mul_f32_e32 v103, 0xbfb8aa3b, v49                        // 000000199ABC: 10CE62FF BFB8AA3B
	v_mul_f32_e32 v113, 0xbfb8aa3b, v50                        // 000000199AC4: 10E264FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000199ACC: 7C3C62FF 42CE8ED0
	v_rndne_f32_e32 v152, v114                                 // 000000199AD4: 7F304772
	v_fma_f32 v117, 0xbfb8aa3b, v73, -v112                     // 000000199AD8: D6130075 85C292FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v49, -v103                     // 000000199AE4: D6130073 859E62FF BFB8AA3B
	v_rndne_f32_e32 v116, v103                                 // 000000199AF0: 7EE84767
	s_waitcnt vmcnt(40)                                        // 000000199AF4: BF89A3F7
	v_lshlrev_b32_e32 v100, 16, v100                           // 000000199AF8: 30C8C890
	v_lshlrev_b32_e32 v98, 16, v98                             // 000000199AFC: 30C4C490
	v_rndne_f32_e32 v118, v112                                 // 000000199B00: 7EEC4770
	v_lshlrev_b32_e32 v101, 16, v101                           // 000000199B04: 30CACA90
	v_lshlrev_b32_e32 v99, 16, v99                             // 000000199B08: 30C6C690
	s_waitcnt vmcnt(37)                                        // 000000199B0C: BF8997F7
	v_lshlrev_b32_e32 v93, 16, v93                             // 000000199B10: 30BABA90
	v_dual_mul_f32 v121, 0xbfb8aa3b, v100 :: v_dual_lshlrev_b32 v102, 16, v102// 000000199B14: C8E2C8FF 7966CC90 BFB8AA3B
	v_mul_f32_e32 v119, 0xbfb8aa3b, v98                        // 000000199B20: 10EEC4FF BFB8AA3B
	v_fma_f32 v151, 0xbfb8aa3b, v82, -v114                     // 000000199B28: D6130097 85CAA4FF BFB8AA3B
	v_dual_fmac_f32 v115, 0xb2a5705f, v49 :: v_dual_sub_f32 v112, v112, v118// 000000199B34: C80A62FF 7370ED70 B2A5705F
	v_dual_fmac_f32 v117, 0xb2a5705f, v73 :: v_dual_sub_f32 v114, v114, v152// 000000199B40: C80A92FF 75733172 B2A5705F
	v_dual_sub_f32 v103, v103, v116 :: v_dual_mul_f32 v122, 0xbfb8aa3b, v101// 000000199B4C: C946E967 677ACAFF BFB8AA3B
	v_mul_f32_e32 v120, 0xbfb8aa3b, v99                        // 000000199B58: 10F0C6FF BFB8AA3B
	v_fma_f32 v145, 0xbfb8aa3b, v50, -v113                     // 000000199B60: D6130091 85C664FF BFB8AA3B
	v_rndne_f32_e32 v146, v113                                 // 000000199B6C: 7F244771
	v_dual_mul_f32 v147, 0xbfb8aa3b, v93 :: v_dual_mul_f32 v144, 0xbfb8aa3b, v102// 000000199B70: C8C6BAFF 9390CCFF BFB8AA3B
	v_fma_f32 v154, 0xbfb8aa3b, v98, -v119                     // 000000199B7C: D613009A 85DEC4FF BFB8AA3B
	v_dual_add_f32 v112, v112, v117 :: v_dual_add_f32 v103, v103, v115// 000000199B88: C908EB70 7066E767
	v_fma_f32 v156, 0xbfb8aa3b, v99, -v120                     // 000000199B90: D613009C 85E2C6FF BFB8AA3B
	v_fma_f32 v158, 0xbfb8aa3b, v100, -v121                    // 000000199B9C: D613009E 85E6C8FF BFB8AA3B
	v_rndne_f32_e32 v163, v144                                 // 000000199BA8: 7F464790
	v_fmac_f32_e32 v145, 0xb2a5705f, v50                       // 000000199BAC: 572264FF B2A5705F
	v_sub_f32_e32 v113, v113, v146                             // 000000199BB4: 08E32571
	v_fmac_f32_e32 v154, 0xb2a5705f, v98                       // 000000199BB8: 5734C4FF B2A5705F
	v_exp_f32_e32 v103, v103                                   // 000000199BC0: 7ECE4B67
	s_waitcnt vmcnt(35)                                        // 000000199BC4: BF898FF7
	v_lshlrev_b32_e32 v95, 16, v95                             // 000000199BC8: 30BEBE90
	s_waitcnt vmcnt(34)                                        // 000000199BCC: BF898BF7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000199BD0: 30C2C290
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000199BD4: 30C0C090
	v_cvt_i32_f32_e32 v116, v116                               // 000000199BD8: 7EE81174
	v_rndne_f32_e32 v155, v119                                 // 000000199BDC: 7F364777
	v_fma_f32 v160, 0xbfb8aa3b, v101, -v122                    // 000000199BE0: D61300A0 85EACAFF BFB8AA3B
	v_rndne_f32_e32 v161, v122                                 // 000000199BEC: 7F42477A
	v_fma_f32 v162, 0xbfb8aa3b, v102, -v144                    // 000000199BF0: D61300A2 8642CCFF BFB8AA3B
	v_fmac_f32_e32 v156, 0xb2a5705f, v99                       // 000000199BFC: 5738C6FF B2A5705F
	v_fmac_f32_e32 v158, 0xb2a5705f, v100                      // 000000199C04: 573CC8FF B2A5705F
	v_dual_sub_f32 v144, v144, v163 :: v_dual_add_f32 v113, v113, v145// 000000199C0C: C9494790 90712371
	v_exp_f32_e32 v112, v112                                   // 000000199C14: 7EE04B70
	v_dual_mul_f32 v149, 0xbfb8aa3b, v95 :: v_dual_lshlrev_b32 v94, 16, v94// 000000199C18: C8E2BEFF 955EBC90 BFB8AA3B
	v_dual_mul_f32 v153, 0xbfb8aa3b, v97 :: v_dual_mul_f32 v150, 0xbfb8aa3b, v96// 000000199C24: C8C6C2FF 9996C0FF BFB8AA3B
	v_cvt_i32_f32_e32 v118, v118                               // 000000199C30: 7EEC1176
	v_rndne_f32_e32 v157, v120                                 // 000000199C34: 7F3A4778
	v_dual_fmac_f32 v151, 0xb2a5705f, v82 :: v_dual_fmac_f32 v160, 0xb2a5705f, v101// 000000199C38: C800A4FF 97A0CAFF B2A5705F
	v_dual_sub_f32 v115, v119, v155 :: v_dual_sub_f32 v122, v122, v161// 000000199C44: C94B3777 737B437A
	v_exp_f32_e32 v113, v113                                   // 000000199C4C: 7EE24B71
	.long 0xd71c0067                                           // 000000199C50: D71C0067
	v_cndmask_b32_e32 v1, v103, v116, vcc_lo                   // 000000199C54: 0202E967
	v_mul_f32_e32 v148, 0xbfb8aa3b, v94                        // 000000199C58: 1128BCFF BFB8AA3B
	v_rndne_f32_e32 v159, v121                                 // 000000199C60: 7F3E4779
	v_cvt_i32_f32_e32 v146, v146                               // 000000199C64: 7F241192
	v_fma_f32 v164, 0xbfb8aa3b, v93, -v147                     // 000000199C68: D61300A4 864EBAFF BFB8AA3B
	v_fma_f32 v168, 0xbfb8aa3b, v95, -v149                     // 000000199C74: D61300A8 8656BEFF BFB8AA3B
	v_fma_f32 v170, 0xbfb8aa3b, v96, -v150                     // 000000199C80: D61300AA 865AC0FF BFB8AA3B
	v_rndne_f32_e32 v171, v150                                 // 000000199C8C: 7F564796
	v_dual_sub_f32 v119, v120, v157 :: v_dual_fmac_f32 v162, 0xb2a5705f, v102// 000000199C90: C9413B78 77A2CCFF B2A5705F
	v_dual_add_f32 v122, v122, v160 :: v_dual_cndmask_b32 v103, 0, v103// 000000199C9C: C913417A 7A66CE80
	.long 0xd71c0070                                           // 000000199CA4: D71C0070
	v_cndmask_b32_e32 v1, v112, v118, vcc_lo                   // 000000199CA8: 0202ED70
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000199CAC: 7C3C92FF 42CE8ED0
	v_rndne_f32_e32 v165, v147                                 // 000000199CB4: 7F4A4793
	v_fma_f32 v166, 0xbfb8aa3b, v94, -v148                     // 000000199CB8: D61300A6 8652BCFF BFB8AA3B
	v_dual_sub_f32 v121, v121, v159 :: v_dual_fmac_f32 v164, 0xb2a5705f, v93// 000000199CC4: C9413F79 79A4BAFF B2A5705F
	v_dual_fmac_f32 v168, 0xb2a5705f, v95 :: v_dual_add_f32 v115, v115, v154// 000000199CD0: C808BEFF A8733573 B2A5705F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000199CDC: BF870002
	v_dual_fmac_f32 v170, 0xb2a5705f, v96 :: v_dual_add_f32 v121, v121, v158// 000000199CE0: C808C0FF AA793D79 B2A5705F
	v_dual_sub_f32 v150, v150, v171 :: v_dual_add_f32 v119, v119, v156// 000000199CEC: C9495796 96773977
	.long 0xd71c0071                                           // 000000199CF4: D71C0071
	v_cndmask_b32_e32 v1, v113, v146, vcc_lo                   // 000000199CF8: 02032571
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 000000199CFC: 02E0E080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v50                  // 000000199D00: 7C3C64FF 42CE8ED0
	v_dual_sub_f32 v145, v147, v165 :: v_dual_fmac_f32 v166, 0xb2a5705f, v94// 000000199D08: C9414B93 91A6BCFF B2A5705F
	v_add_f32_e32 v144, v144, v162                             // 000000199D14: 07214590
	v_dual_add_f32 v150, v150, v170 :: v_dual_cndmask_b32 v113, 0, v113// 000000199D18: C9135596 9670E280
	v_exp_f32_e32 v115, v115                                   // 000000199D20: 7EE64B73
	v_exp_f32_e32 v119, v119                                   // 000000199D24: 7EEE4B77
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000199D28: 7C3662FF C2B17218
	v_cvt_i32_f32_e32 v117, v155                               // 000000199D30: 7EEA119B
	v_cvt_i32_f32_e32 v120, v157                               // 000000199D34: 7EF0119D
	v_add_f32_e32 v145, v145, v164                             // 000000199D38: 07234991
	v_exp_f32_e32 v144, v144                                   // 000000199D3C: 7F204B90
	v_cndmask_b32_e32 v49, 0x7f800000, v103, vcc_lo            // 000000199D40: 0262CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000199D48: 7C3692FF C2B17218
	v_cvt_i32_f32_e32 v155, v159                               // 000000199D50: 7F36119F
	v_cvt_i32_f32_e32 v159, v163                               // 000000199D54: 7F3E11A3
	v_exp_f32_e32 v121, v121                                   // 000000199D58: 7EF24B79
	.long 0xd71c0073                                           // 000000199D5C: D71C0073
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                   // 000000199D60: 0202EB73
	.long 0xd71c0075                                           // 000000199D64: D71C0075
	v_cndmask_b32_e32 v1, v119, v120, vcc_lo                   // 000000199D68: 0202F177
	v_cndmask_b32_e32 v73, 0x7f800000, v112, vcc_lo            // 000000199D6C: 0292E0FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v98                  // 000000199D74: 7C3CC4FF 42CE8ED0
	v_exp_f32_e32 v122, v122                                   // 000000199D7C: 7EF44B7A
	.long 0xd71c0078                                           // 000000199D80: D71C0078
	v_cndmask_b32_e32 v1, v144, v159, vcc_lo                   // 000000199D84: 02033F90
	v_rndne_f32_e32 v167, v148                                 // 000000199D88: 7F4E4794
	v_cvt_i32_f32_e32 v157, v161                               // 000000199D8C: 7F3A11A1
	v_cndmask_b32_e32 v103, 0, v115, vcc_lo                    // 000000199D90: 02CEE680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v99                  // 000000199D94: 7C3CC6FF 42CE8ED0
	.long 0xd71c0076                                           // 000000199D9C: D71C0076
	v_cndmask_b32_e32 v1, v121, v155, vcc_lo                   // 000000199DA0: 02033779
	v_rndne_f32_e32 v169, v149                                 // 000000199DA4: 7F524795
	v_sub_f32_e32 v148, v148, v167                             // 000000199DA8: 09294F94
	v_exp_f32_e32 v145, v145                                   // 000000199DAC: 7F224B91
	v_cndmask_b32_e32 v112, 0, v117, vcc_lo                    // 000000199DB0: 02E0EA80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 000000199DB4: 7C3CC8FF 42CE8ED0
	.long 0xd71c0077                                           // 000000199DBC: D71C0077
	v_cndmask_b32_e32 v1, v122, v157, vcc_lo                   // 000000199DC0: 02033B7A
	v_dual_sub_f32 v149, v149, v169 :: v_dual_add_f32 v148, v148, v166// 000000199DC4: C9495395 95954D94
	v_cvt_i32_f32_e32 v147, v165                               // 000000199DCC: 7F2611A5
	v_cndmask_b32_e32 v115, 0, v118, vcc_lo                    // 000000199DD0: 02E6EC80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v101                 // 000000199DD4: 7C3CCAFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000199DDC: BF870004
	v_add_f32_e32 v149, v149, v168                             // 000000199DE0: 072B5195
	v_exp_f32_e32 v148, v148                                   // 000000199DE4: 7F284B94
	v_exp_f32_e32 v116, v150                                   // 000000199DE8: 7EE84B96
	v_cvt_i32_f32_e32 v161, v167                               // 000000199DEC: 7F4211A7
	v_cndmask_b32_e32 v117, 0, v119, vcc_lo                    // 000000199DF0: 02EAEE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 000000199DF4: 7C3CCCFF 42CE8ED0
	v_cvt_i32_f32_e32 v165, v171                               // 000000199DFC: 7F4A11AB
	v_exp_f32_e32 v149, v149                                   // 000000199E00: 7F2A4B95
	.long 0xd71c0079                                           // 000000199E04: D71C0079
	v_cndmask_b32_e32 v1, v145, v147, vcc_lo                   // 000000199E08: 02032791
	v_cvt_i32_f32_e32 v163, v169                               // 000000199E0C: 7F4611A9
	v_cndmask_b32_e32 v118, 0, v120, vcc_lo                    // 000000199E10: 02ECF080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v50                  // 000000199E14: 7C3664FF C2B17218
	.long 0xd71c007a                                           // 000000199E1C: D71C007A
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 000000199E20: 02034394
	.long 0xd71c0074                                           // 000000199E24: D71C0074
	v_cndmask_b32_e32 v1, v116, v165, vcc_lo                   // 000000199E28: 02034B74
	v_add_f32_e32 v120, 1.0, v49                               // 000000199E2C: 06F062F2
	.long 0xd41b0005                                           // 000000199E30: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v94, vcc_lo              // 000000199E34: 0202BCFF C2B17218
	v_cndmask_b32_e32 v50, 0x7f800000, v113, vcc_lo            // 000000199E3C: 0264E2FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v93                  // 000000199E44: 7C3CBAFF 42CE8ED0
	.long 0xd71c0090                                           // 000000199E4C: D71C0090
	v_cndmask_b32_e32 v1, v149, v163, vcc_lo                   // 000000199E50: 02034795
	v_cndmask_b32_e32 v113, 0, v121, vcc_lo                    // 000000199E54: 02E2F280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v94                  // 000000199E58: 7C3CBCFF 42CE8ED0
	v_div_scale_f32 v121, null, v120, v120, v57                // 000000199E60: D6FC7C79 04E6F178
	v_cndmask_b32_e32 v119, 0, v122, vcc_lo                    // 000000199E68: 02EEF480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v95                  // 000000199E6C: 7C3CBEFF 42CE8ED0
	v_cndmask_b32_e32 v49, 0, v144, vcc_lo                     // 000000199E74: 02632080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 000000199E78: 7C3CC0FF 42CE8ED0
	v_cndmask_b32_e32 v116, 0, v116, vcc_lo                    // 000000199E80: 02E8E880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v98                  // 000000199E84: 7C36C4FF C2B17218
	v_cndmask_b32_e32 v98, 0x7f800000, v103, vcc_lo            // 000000199E8C: 02C4CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v99                  // 000000199E94: 7C36C6FF C2B17218
	v_rcp_f32_e32 v103, v121                                   // 000000199E9C: 7ECE5579
	v_cndmask_b32_e64 v94, 0x7f800000, v119, s5                // 000000199EA0: D501005E 0016EEFF 7F800000
	.long 0xd41b0005                                           // 000000199EAC: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v95, vcc_lo              // 000000199EB0: 0202BEFF C2B17218
	v_dual_add_f32 v98, 1.0, v98 :: v_dual_cndmask_b32 v99, 0x7f800000, v112// 000000199EB8: C912C4F2 6262E0FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 000000199EC4: 7C36C8FF C2B17218
	v_dual_add_f32 v73, 1.0, v73 :: v_dual_cndmask_b32 v100, 0x7f800000, v115// 000000199ECC: C91292F2 4964E6FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000199ED8: BF870121
	v_div_scale_f32 v122, null, v73, v73, v58                  // 000000199EDC: D6FC7C7A 04EA9349
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v101                 // 000000199EE4: 7C36CAFF C2B17218
	v_rcp_f32_e32 v112, v122                                   // 000000199EEC: 7EE0557A
	v_cndmask_b32_e32 v101, 0x7f800000, v117, vcc_lo           // 000000199EF0: 02CAEAFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 000000199EF8: 7C36CCFF C2B17218
	v_cndmask_b32_e32 v102, 0x7f800000, v118, vcc_lo           // 000000199F00: 02CCECFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v93                  // 000000199F08: 7C36BAFF C2B17218
	v_div_scale_f32 v118, s4, v58, v73, v58                    // 000000199F10: D6FC0476 04EA933A
	v_cndmask_b32_e64 v95, 0x7f800000, v49, s5                 // 000000199F18: D501005F 001662FF 7F800000
	.long 0xd41b0005                                           // 000000199F24: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v96, vcc_lo              // 000000199F28: 0202C0FF C2B17218
	v_dual_add_f32 v102, 1.0, v102 :: v_dual_cndmask_b32 v93, 0x7f800000, v113// 000000199F30: C912CCF2 665CE2FF 7F800000
	v_div_scale_f32 v117, vcc_lo, v57, v120, v57               // 000000199F3C: D6FC6A75 04E6F139
	v_add_f32_e32 v115, 1.0, v50                               // 000000199F44: 06E664F2
	v_fma_f32 v50, -v121, v103, 1.0                            // 000000199F48: D6130032 23CACF79
	v_fma_f32 v113, -v122, v112, 1.0                           // 000000199F50: D6130071 23CAE17A
	v_div_scale_f32 v119, null, v102, v102, v80                // 000000199F58: D6FC7C77 0542CD66
	v_cndmask_b32_e64 v96, 0x7f800000, v116, s5                // 000000199F60: D5010060 0016E8FF 7F800000
	v_dual_add_f32 v94, 1.0, v94 :: v_dual_add_f32 v95, 1.0, v95// 000000199F6C: C908BCF2 5E5EBEF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000199F74: BF870214
	v_dual_fmac_f32 v103, v50, v103 :: v_dual_fmac_f32 v112, v113, v112// 000000199F78: C800CF32 6770E171
	v_rcp_f32_e32 v146, v119                                   // 000000199F80: 7F245577
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000199F84: BF870111
	v_mul_f32_e32 v50, v117, v103                              // 000000199F88: 1064CF75
	v_mul_f32_e32 v144, v118, v112                             // 000000199F8C: 1120E176
	v_div_scale_f32 v113, null, v115, v115, v111               // 000000199F90: D6FC7C71 05BEE773
	v_div_scale_f32 v116, s5, v111, v115, v111                 // 000000199F98: D6FC0574 05BEE76F
	v_add_f32_e32 v93, 1.0, v93                                // 000000199FA0: 06BABAF2
	v_fma_f32 v49, -v121, v50, v117                            // 000000199FA4: D6130031 25D66579
	v_fma_f32 v147, -v122, v144, v118                          // 000000199FAC: D6130093 25DB217A
	v_rcp_f32_e32 v145, v113                                   // 000000199FB4: 7F225571
	v_add_f32_e32 v99, 1.0, v99                                // 000000199FB8: 06C6C6F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000199FBC: BF870193
	v_fmac_f32_e32 v50, v49, v103                              // 000000199FC0: 5664CF31
	v_fmac_f32_e32 v144, v147, v112                            // 000000199FC4: 5720E193
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000199FC8: BF870112
	v_fma_f32 v117, -v121, v50, v117                           // 000000199FCC: D6130075 25D66579
	v_fma_f32 v118, -v122, v144, v118                          // 000000199FD4: D6130076 25DB217A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000199FDC: BF870225
	v_fma_f32 v49, -v113, v145, 1.0                            // 000000199FE0: D6130031 23CB2371
	v_fma_f32 v121, -v119, v146, 1.0                           // 000000199FE8: D6130079 23CB2577
	v_div_fmas_f32 v103, v117, v103, v50                       // 000000199FF0: D6370067 04CACF75
	s_mov_b32 vcc_lo, s4                                       // 000000199FF8: BEEA0004
	s_delay_alu instid0(VALU_DEP_3)                            // 000000199FFC: BF870003
	v_fmac_f32_e32 v145, v49, v145                             // 00000019A000: 57232331
	v_div_fmas_f32 v112, v118, v112, v144                      // 00000019A004: D6370070 0642E176
	s_mov_b32 vcc_lo, s2                                       // 00000019A00C: BEEA0002
	v_fmac_f32_e32 v146, v121, v146                            // 00000019A010: 57252579
	v_div_fmas_f32 v50, v109, v91, v71                         // 00000019A014: D6370032 051EB76D
	s_mov_b32 vcc_lo, s3                                       // 00000019A01C: BEEA0003
	v_div_fixup_f32 v57, v103, v120, v57                       // 00000019A020: D6270039 04E6F167
	v_div_fmas_f32 v71, v108, v90, v72                         // 00000019A028: D6370047 0522B56C
	v_div_scale_f32 v72, s2, v80, v102, v80                    // 00000019A030: D6FC0248 0542CD50
	v_div_fixup_f32 v50, v50, v89, 1.0                         // 00000019A038: D6270032 03CAB332
	v_add_f32_e32 v90, 1.0, v100                               // 00000019A040: 06B4C8F2
	v_add_f32_e32 v96, 1.0, v96                                // 00000019A044: 06C0C0F2
	v_div_fixup_f32 v49, v71, v88, 1.0                         // 00000019A048: D6270031 03CAB147
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000019A050: BF870244
	v_dual_mul_f32 v88, v116, v145 :: v_dual_mul_f32 v59, v59, v50// 00000019A054: C8C72374 583A653B
	v_add_f32_e32 v71, 1.0, v101                               // 00000019A05C: 068ECAF2
	v_mul_f32_e32 v103, v51, v50                               // 00000019A060: 10CE6533
	.long 0x7e9e39b9                                           // 00000019A064: 7E9E39B9
	v_fma_f32 v91, -v113, v88, v116                            // 00000019A068: D613005B 25D2B171
	v_mul_f32_e32 v89, v72, v146                               // 00000019A070: 10B32548
	v_div_scale_f32 v100, null, v98, v98, v59                  // 00000019A074: D6FC7C64 04EEC562
	v_div_fixup_f32 v58, v112, v73, v58                        // 00000019A07C: D627003A 04EA9370
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019A084: BF870214
	v_dual_fmac_f32 v88, v91, v145 :: v_dual_and_b32 v79, 1, v79// 00000019A088: C825235B 584E9E81
	v_fma_f32 v101, -v119, v89, v72                            // 00000019A090: D6130065 2522B377
	v_mul_f32_e32 v60, v60, v49                                // 00000019A098: 1078633C
	v_rcp_f32_e32 v91, v100                                    // 00000019A09C: 7EB65564
	.long 0x7e0039ba                                           // 00000019A0A0: 7E0039BA
	v_fma_f32 v109, -v113, v88, v116                           // 00000019A0A4: D613006D 25D2B171
	v_fmac_f32_e32 v89, v101, v146                             // 00000019A0AC: 56B32565
	v_div_scale_f32 v108, null, v99, v99, v60                  // 00000019A0B0: D6FC7C6C 04F2C763
	v_mul_f32_e32 v113, v52, v49                               // 00000019A0B8: 10E26334
	v_div_scale_f32 v116, vcc_lo, v59, v98, v59                // 00000019A0BC: D6FC6A74 04EEC53B
	v_div_scale_f32 v122, s4, v103, v93, v103                  // 00000019A0C4: D6FC047A 059EBB67
	v_div_scale_f32 v117, null, v93, v93, v103                 // 00000019A0CC: D6FC7C75 059EBB5D
	v_rcp_f32_e32 v101, v108                                   // 00000019A0D4: 7ECA556C
	v_fma_f32 v51, -v100, v91, 1.0                             // 00000019A0D8: D6130033 23CAB764
	v_fma_f32 v72, -v119, v89, v72                             // 00000019A0E0: D6130048 2522B377
	v_add3_u32 v57, v57, v79, 0x7fff                           // 00000019A0E8: D6550039 03FE9F39 00007FFF
	v_rcp_f32_e32 v112, v117                                   // 00000019A0F4: 7EE05575
	v_dual_mul_f32 v43, v43, v50 :: v_dual_mul_f32 v44, v44, v49// 00000019A0F8: C8C6652B 2B2C632C
	v_dual_mul_f32 v36, v36, v49 :: v_dual_mul_f32 v35, v35, v50// 00000019A100: C8C66324 24226523
	v_mul_f32_e32 v28, v28, v49                                // 00000019A108: 1038631C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000019A10C: BF870246
	v_fma_f32 v52, -v108, v101, 1.0                            // 00000019A110: D6130034 23CACB6C
	v_dual_mul_f32 v20, v20, v49 :: v_dual_mul_f32 v27, v27, v50// 00000019A118: C8C66314 141A651B
	v_dual_mul_f32 v12, v12, v49 :: v_dual_mul_f32 v19, v19, v50// 00000019A120: C8C6630C 0C126513
	v_mul_f32_e32 v4, v4, v49                                  // 00000019A128: 10086304
	v_fmac_f32_e32 v101, v52, v101                             // 00000019A12C: 56CACB34
	v_fmac_f32_e32 v91, v51, v91                               // 00000019A130: 56B6B733
	v_div_scale_f32 v51, s3, v60, v99, v60                     // 00000019A134: D6FC0333 04F2C73C
	v_mul_f32_e32 v11, v11, v50                                // 00000019A13C: 1016650B
	v_mul_f32_e32 v3, v3, v50                                  // 00000019A140: 10066503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019A144: BF870093
	v_mul_f32_e32 v118, v51, v101                              // 00000019A148: 10ECCB33
	v_fma_f32 v121, -v108, v118, v51                           // 00000019A14C: D6130079 24CEED6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019A154: BF870121
	v_fmac_f32_e32 v118, v121, v101                            // 00000019A158: 56ECCB79
	v_mul_f32_e32 v52, v116, v91                               // 00000019A15C: 1068B774
	v_fma_f32 v51, -v108, v118, v51                            // 00000019A160: D6130033 24CEED6C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019A168: BF870092
	v_fma_f32 v120, -v100, v52, v116                           // 00000019A16C: D6130078 25D26964
	v_fmac_f32_e32 v52, v120, v91                              // 00000019A174: 5668B778
	v_fma_f32 v120, -v117, v112, 1.0                           // 00000019A178: D6130078 23CAE175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019A180: BF870092
	v_fma_f32 v100, -v100, v52, v116                           // 00000019A184: D6130064 25D26964
	v_div_fmas_f32 v91, v100, v91, v52                         // 00000019A18C: D637005B 04D2B764
	s_mov_b32 vcc_lo, s3                                       // 00000019A194: BEEA0003
	v_div_fmas_f32 v100, v51, v101, v118                       // 00000019A198: D6370064 05DACB33
	s_mov_b32 vcc_lo, s0                                       // 00000019A1A0: BEEA0000
	s_delay_alu instid0(VALU_DEP_2)                            // 00000019A1A4: BF870002
	v_div_fixup_f32 v59, v91, v98, v59                         // 00000019A1A8: D627003B 04EEC55B
	v_div_fmas_f32 v51, v107, v85, v142                        // 00000019A1B0: D6370033 063AAB6B
	s_mov_b32 vcc_lo, s1                                       // 00000019A1B8: BEEA0001
	v_div_fixup_f32 v60, v100, v99, v60                        // 00000019A1BC: D627003C 04F2C764
	v_div_fmas_f32 v84, v110, v84, v143                        // 00000019A1C4: D6370054 063EA96E
	v_and_b32_e32 v85, 1, v0                                   // 00000019A1CC: 36AA0081
	v_div_fixup_f32 v52, v51, v83, 1.0                         // 00000019A1D0: D6270034 03CAA733
	.long 0x7e9a39bb                                           // 00000019A1D8: 7E9A39BB
	.long 0x7e0039bc                                           // 00000019A1DC: 7E0039BC
	v_div_fixup_f32 v51, v84, v81, 1.0                         // 00000019A1E0: D6270033 03CAA354
	v_add3_u32 v58, v58, v85, 0x7fff                           // 00000019A1E8: D655003A 03FEAB3A 00007FFF
	v_mul_f32_e32 v61, v61, v52                                // 00000019A1F4: 107A693D
	s_clause 0x1                                               // 00000019A1F8: BF850001
	global_store_d16_hi_b16 v[7:8], v57, off                   // 00000019A1FC: DC960000 007C3907
	global_store_d16_hi_b16 v[7:8], v58, off offset:1024       // 00000019A204: DC960400 007C3A07
	v_mul_f32_e32 v62, v62, v51                                // 00000019A20C: 107C673E
	v_div_scale_f32 v73, null, v94, v94, v113                  // 00000019A210: D6FC7C49 05C6BD5E
	v_div_scale_f32 v121, s6, v113, v94, v113                  // 00000019A218: D6FC0679 05C6BD71
	v_mul_f32_e32 v54, v54, v51                                // 00000019A220: 106C6736
	v_div_scale_f32 v85, null, v90, v90, v61                   // 00000019A224: D6FC7C55 04F6B55A
	v_mul_f32_e32 v53, v53, v52                                // 00000019A22C: 106A6935
	v_rcp_f32_e32 v119, v73                                    // 00000019A230: 7EEE5549
	v_div_scale_f32 v99, vcc_lo, v61, v90, v61                 // 00000019A234: D6FC6A63 04F6B53D
	v_div_scale_f32 v116, null, v96, v96, v54                  // 00000019A23C: D6FC7C74 04DAC160
	v_mul_f32_e32 v37, v37, v52                                // 00000019A244: 104A6925
	v_div_scale_f32 v100, null, v95, v95, v53                  // 00000019A248: D6FC7C64 04D6BF5F
	v_div_scale_f32 v110, s1, v53, v95, v53                    // 00000019A250: D6FC016E 04D6BF35
	v_dual_mul_f32 v22, v22, v51 :: v_dual_mul_f32 v29, v29, v52// 00000019A258: C8C66716 161C691D
	v_mul_f32_e32 v14, v14, v51                                // 00000019A260: 101C670E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000019A264: BF870314
	v_rcp_f32_e32 v107, v100                                   // 00000019A268: 7ED65564
	v_fma_f32 v144, -v73, v119, 1.0                            // 00000019A26C: D6130090 23CAEF49
	v_mul_f32_e32 v21, v21, v52                                // 00000019A274: 102A6915
	v_mul_f32_e32 v13, v13, v52                                // 00000019A278: 101A690D
	v_dual_mul_f32 v5, v5, v52 :: v_dual_mul_f32 v6, v6, v51   // 00000019A27C: C8C66905 05066706
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019A284: BF870094
	v_fmac_f32_e32 v119, v144, v119                            // 00000019A288: 56EEEF90
	v_dual_fmac_f32 v112, v120, v112 :: v_dual_mul_f32 v81, v121, v119// 00000019A28C: C806E178 7050EF79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019A294: BF870111
	v_mul_f32_e32 v83, v122, v112                              // 00000019A298: 10A6E17A
	v_fma_f32 v84, -v73, v81, v121                             // 00000019A29C: D6130054 25E6A349
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019A2A4: BF870092
	v_fma_f32 v79, -v117, v83, v122                            // 00000019A2A8: D613004F 25EAA775
	v_fmac_f32_e32 v83, v79, v112                              // 00000019A2B0: 56A6E14F
	v_div_scale_f32 v79, null, v71, v71, v62                   // 00000019A2B4: D6FC7C4F 04FA8F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019A2BC: BF870291
	v_rcp_f32_e32 v91, v79                                     // 00000019A2C0: 7EB6554F
	v_fma_f32 v98, -v79, v91, 1.0                              // 00000019A2C4: D6130062 23CAB74F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000019A2CC: BF870131
	v_dual_fmac_f32 v91, v98, v91 :: v_dual_and_b32 v98, 1, v0 // 00000019A2D0: C824B762 5B620081
	v_fmac_f32_e32 v81, v84, v119                              // 00000019A2D8: 56A2EF54
	v_rcp_f32_e32 v84, v85                                     // 00000019A2DC: 7EA85555
	v_add3_u32 v60, v60, v98, 0x7fff                           // 00000019A2E0: D655003C 03FEC53C 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019A2EC: BF870292
	v_fma_f32 v58, -v73, v81, v121                             // 00000019A2F0: D613003A 25E6A349
	v_fma_f32 v73, -v85, v84, 1.0                              // 00000019A2F8: D6130049 23CAA955
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019A300: BF8700A1
	v_fmac_f32_e32 v84, v73, v84                               // 00000019A304: 56A8A949
	v_div_scale_f32 v73, s0, v62, v71, v62                     // 00000019A308: D6FC0049 04FA8F3E
	v_dual_mul_f32 v101, v99, v84 :: v_dual_mul_f32 v108, v73, v91// 00000019A310: C8C6A963 656CB749
	v_fma_f32 v57, -v117, v83, v122                            // 00000019A318: D6130039 25EAA775
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019A320: BF870092
	v_fma_f32 v117, -v79, v108, v73                            // 00000019A324: D6130075 2526D94F
	v_dual_fmac_f32 v108, v117, v91 :: v_dual_and_b32 v77, 1, v77// 00000019A32C: C824B775 6C4C9A81
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019A334: BF870001
	v_add3_u32 v59, v59, v77, 0x7fff                           // 00000019A338: D655003B 03FE9B3B 00007FFF
	v_fma_f32 v77, -v85, v101, v99                             // 00000019A344: D613004D 258ECB55
	global_store_d16_hi_b16 v[15:16], v59, off                 // 00000019A34C: DC960000 007C3B0F
	v_fma_f32 v59, -v100, v107, 1.0                            // 00000019A354: D613003B 23CAD764
	global_store_d16_hi_b16 v[23:24], v60, off                 // 00000019A35C: DC960000 007C3C17
	v_fmac_f32_e32 v107, v59, v107                             // 00000019A364: 56D6D73B
	v_fmac_f32_e32 v101, v77, v84                              // 00000019A368: 56CAA94D
	v_fma_f32 v59, -v79, v108, v73                             // 00000019A36C: D613003B 2526D94F
	v_rcp_f32_e32 v77, v116                                    // 00000019A374: 7E9A5574
	s_waitcnt vmcnt(23)                                        // 00000019A378: BF895FF7
	v_lshlrev_b32_e32 v79, 16, v137                            // 00000019A37C: 309F1290
	v_mul_f32_e32 v41, v41, v66                                // 00000019A380: 10528529
	v_fma_f32 v60, -v85, v101, v99                             // 00000019A384: D613003C 258ECB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000019A38C: BF870141
	v_div_fmas_f32 v60, v60, v84, v101                         // 00000019A390: D637003C 0596A93C
	s_mov_b32 vcc_lo, s0                                       // 00000019A398: BEEA0000
	v_div_fmas_f32 v59, v59, v91, v108                         // 00000019A39C: D637003B 05B2B73B
	s_mov_b32 vcc_lo, s2                                       // 00000019A3A4: BEEA0002
	v_div_fixup_f32 v60, v60, v90, v61                         // 00000019A3A8: D627003C 04F6B53C
	v_div_fmas_f32 v72, v72, v146, v89                         // 00000019A3B0: D6370048 05672548
	s_mov_b32 vcc_lo, s5                                       // 00000019A3B8: BEEA0005
	v_div_fixup_f32 v59, v59, v71, v62                         // 00000019A3BC: D627003B 04FA8F3B
	v_div_fmas_f32 v61, v109, v145, v88                        // 00000019A3C4: D637003D 0563236D
	.long 0x7e9839bc                                           // 00000019A3CC: 7E9839BC
	v_div_fixup_f32 v62, v72, v102, v80                        // 00000019A3D0: D627003E 0542CD48
	s_mov_b32 vcc_lo, s4                                       // 00000019A3D8: BEEA0004
	.long 0x7e0039bb                                           // 00000019A3DC: 7E0039BB
	v_div_fixup_f32 v61, v61, v115, v111                       // 00000019A3E0: D627003D 05BEE73D
	v_and_b32_e32 v72, 1, v76                                  // 00000019A3E8: 36909881
	.long 0x7e9639be                                           // 00000019A3EC: 7E9639BE
	v_div_fmas_f32 v57, v57, v112, v83                         // 00000019A3F0: D6370039 054EE139
	v_and_b32_e32 v71, 1, v0                                   // 00000019A3F8: 368E0081
	.long 0x7e0039bd                                           // 00000019A3FC: 7E0039BD
	v_add3_u32 v60, v60, v72, 0x7fff                           // 00000019A400: D655003C 03FE913C 00007FFF
	v_fma_f32 v72, 0xbfb8aa3b, v97, -v153                      // 00000019A40C: D6130048 8666C2FF BFB8AA3B
	s_mov_b32 vcc_lo, s6                                       // 00000019A418: BEEA0006
	v_add3_u32 v59, v59, v71, 0x7fff                           // 00000019A41C: D655003B 03FE8F3B 00007FFF
	v_div_fmas_f32 v58, v58, v119, v81                         // 00000019A428: D637003A 0546EF3A
	v_div_fixup_f32 v57, v57, v93, v103                        // 00000019A430: D6270039 059EBB39
	v_dual_fmac_f32 v72, 0xb2a5705f, v97 :: v_dual_and_b32 v73, 1, v75// 00000019A438: C824C2FF 48489681 B2A5705F
	v_and_b32_e32 v75, 1, v0                                   // 00000019A444: 36960081
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019A448: BF870004
	v_div_fixup_f32 v58, v58, v94, v113                        // 00000019A44C: D627003A 05C6BD3A
	s_clause 0x1                                               // 00000019A454: BF850001
	global_store_d16_hi_b16 v[31:32], v60, off                 // 00000019A458: DC960000 007C3C1F
	global_store_d16_hi_b16 v[39:40], v59, off                 // 00000019A460: DC960000 007C3B27
	v_fma_f32 v60, -v116, v77, 1.0                             // 00000019A468: D613003C 23CA9B74
	v_add3_u32 v62, v62, v73, 0x7fff                           // 00000019A470: D655003E 03FE933E 00007FFF
	v_add3_u32 v61, v61, v75, 0x7fff                           // 00000019A47C: D655003D 03FE973D 00007FFF
	s_clause 0x1                                               // 00000019A488: BF850001
	global_store_d16_hi_b16 v[7:8], v61, off offset:32         // 00000019A48C: DC960020 007C3D07
	global_store_d16_hi_b16 v[47:48], v62, off offset:32       // 00000019A494: DC960020 007C3E2F
	v_add_f32_e32 v61, v114, v151                              // 00000019A49C: 067B2F72
	.long 0x7e0039ba                                           // 00000019A4A0: 7E0039BA
	.long 0x7e9439b9                                           // 00000019A4A4: 7E9439B9
	v_rndne_f32_e32 v73, v153                                  // 00000019A4A8: 7E924799
	v_fmac_f32_e32 v77, v60, v77                               // 00000019A4AC: 569A9B3C
	v_exp_f32_e32 v60, v61                                     // 00000019A4B0: 7E784B3D
	v_div_scale_f32 v61, s0, v54, v96, v54                     // 00000019A4B4: D6FC003D 04DAC136
	v_and_b32_e32 v59, 1, v0                                   // 00000019A4BC: 36760081
	v_dual_sub_f32 v74, v153, v73 :: v_dual_and_b32 v71, 1, v74// 00000019A4C0: C9649399 4A469481
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v82                  // 00000019A4C8: 7C3CA4FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019A4D0: BF870004
	v_mul_f32_e32 v76, v61, v77                                // 00000019A4D4: 10989B3D
	v_mul_f32_e32 v62, v110, v107                              // 00000019A4D8: 107CD76E
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000019A4DC: D655003A 03FE773A 00007FFF
	v_cvt_i32_f32_e32 v59, v152                                // 00000019A4E8: 7E761198
	v_add_f32_e32 v72, v74, v72                                // 00000019A4EC: 0690914A
	v_add3_u32 v57, v57, v71, 0x7fff                           // 00000019A4F0: D6550039 03FE8F39 00007FFF
	v_fma_f32 v75, -v100, v62, v110                            // 00000019A4FC: D613004B 25BA7D64
	v_mul_f32_e32 v80, 0xbfb8aa3b, v79                         // 00000019A504: 10A09EFF BFB8AA3B
	.long 0xd71c003b                                           // 00000019A50C: D71C003B
	v_cndmask_b32_e32 v1, v60, v59, vcc_lo                     // 00000019A510: 0202773C
	v_fma_f32 v60, -v116, v76, v61                             // 00000019A514: D613003C 24F69974
	v_exp_f32_e32 v71, v72                                     // 00000019A51C: 7E8E4B48
	v_fmac_f32_e32 v62, v75, v107                              // 00000019A520: 567CD74B
	global_store_d16_hi_b16 v[15:16], v57, off offset:32       // 00000019A524: DC960020 007C390F
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 00000019A52C: 02767680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v82                  // 00000019A530: 7C36A4FF C2B17218
	v_fmac_f32_e32 v76, v60, v77                               // 00000019A538: 56989B3C
	v_fma_f32 v72, -v100, v62, v110                            // 00000019A53C: D6130048 25BA7D64
	v_cvt_i32_f32_e32 v60, v73                                 // 00000019A544: 7E781149
	global_store_d16_hi_b16 v[23:24], v58, off offset:32       // 00000019A548: DC960020 007C3A17
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 00000019A550: 027676FF 7F800000
	s_mov_b32 vcc_lo, s1                                       // 00000019A558: BEEA0001
	v_fma_f32 v61, -v116, v76, v61                             // 00000019A55C: D613003D 24F69974
	v_div_fmas_f32 v62, v72, v107, v62                         // 00000019A564: D637003E 04FAD748
	.long 0xd71c003c                                           // 00000019A56C: D71C003C
	v_cndmask_b32_e32 v1, v71, v60, vcc_lo                     // 00000019A570: 02027947
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000019A574: 7C3CC2FF 42CE8ED0
	.long 0x7f903980                                           // 00000019A57C: 7F903980
	v_fma_f32 v82, 0xbfb8aa3b, v79, -v80                       // 00000019A580: D6130052 85429EFF BFB8AA3B
	v_div_fixup_f32 v53, v62, v95, v53                         // 00000019A58C: D6270035 04D6BF3E
	v_rndne_f32_e32 v83, v80                                   // 00000019A594: 7EA64750
	v_cndmask_b32_e32 v60, 0, v60, vcc_lo                      // 00000019A598: 02787880
	s_mov_b32 vcc_lo, s0                                       // 00000019A59C: BEEA0000
	v_div_fmas_f32 v61, v61, v77, v76                          // 00000019A5A0: D637003D 05329B3D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000019A5A8: 7C36C2FF C2B17218
	.long 0x7e9039b5                                           // 00000019A5B0: 7E9039B5
	v_sub_f32_e32 v80, v80, v83                                // 00000019A5B4: 08A0A750
	v_fmac_f32_e32 v82, 0xb2a5705f, v79                        // 00000019A5B8: 56A49EFF B2A5705F
	v_div_fixup_f32 v54, v61, v96, v54                         // 00000019A5C0: D6270036 04DAC13D
	v_dual_cndmask_b32 v60, 0x7f800000, v60 :: v_dual_lshlrev_b32 v61, 16, v138// 00000019A5C8: CA6278FF 3C3D1490 7F800000
	v_and_b32_e32 v72, 1, v72                                  // 00000019A5D4: 36909081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019A5D8: BF870214
	v_add_f32_e32 v80, v80, v82                                // 00000019A5DC: 06A0A550
	.long 0x7e0039b6                                           // 00000019A5E0: 7E0039B6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000019A5E4: BF870234
	v_add_f32_e32 v60, 1.0, v60                                // 00000019A5E8: 067878F2
	v_mul_f32_e32 v62, 0xbfb8aa3b, v61                         // 00000019A5EC: 107C7AFF BFB8AA3B
	v_add3_u32 v53, v53, v72, 0x7fff                           // 00000019A5F4: D6550035 03FE9135 00007FFF
	v_and_b32_e32 v77, 1, v0                                   // 00000019A600: 369A0081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019A604: BF870214
	v_div_scale_f32 v58, null, v60, v60, v42                   // 00000019A608: D6FC7C3A 04AA793C
	v_fma_f32 v75, 0xbfb8aa3b, v61, -v62                       // 00000019A610: D613004B 84FA7AFF BFB8AA3B
	v_rndne_f32_e32 v76, v62                                   // 00000019A61C: 7E98473E
	global_store_d16_hi_b16 v[31:32], v53, off offset:32       // 00000019A620: DC960020 007C351F
	v_add3_u32 v54, v54, v77, 0x7fff                           // 00000019A628: D6550036 03FE9B36 00007FFF
	v_rcp_f32_e32 v74, v58                                     // 00000019A634: 7E94553A
	v_sub_f32_e32 v62, v62, v76                                // 00000019A638: 087C993E
	v_cvt_i32_f32_e32 v76, v76                                 // 00000019A63C: 7E98114C
	global_store_d16_hi_b16 v[39:40], v54, off offset:32       // 00000019A640: DC960020 007C3627
	v_fma_f32 v81, -v58, v74, 1.0                              // 00000019A648: D6130051 23CA953A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019A650: BF870091
	v_dual_add_f32 v59, 1.0, v59 :: v_dual_fmac_f32 v74, v81, v74// 00000019A654: C90076F2 3B4A9551
	v_div_scale_f32 v71, null, v59, v59, v41                   // 00000019A65C: D6FC7C47 04A6773B
	v_div_scale_f32 v81, s0, v42, v60, v42                     // 00000019A664: D6FC0051 04AA792A
	v_fmac_f32_e32 v75, 0xb2a5705f, v61                        // 00000019A66C: 56967AFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019A674: BF870113
	v_rcp_f32_e32 v57, v71                                     // 00000019A678: 7E725547
	v_mul_f32_e32 v84, v81, v74                                // 00000019A67C: 10A89551
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019A680: BF8701A2
	v_add_f32_e32 v62, v62, v75                                // 00000019A684: 067C973E
	.long 0xd41e0001                                           // 00000019A688: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v61, vcc_lo              // 00000019A68C: 02027AFF 42CE8ED0
	v_fma_f32 v72, -v58, v84, v81                              // 00000019A694: D6130048 2546A93A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000019A69C: BF870313
	v_exp_f32_e32 v62, v62                                     // 00000019A6A0: 7E7C4B3E
	v_fma_f32 v73, -v71, v57, 1.0                              // 00000019A6A4: D6130049 23CA7347
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019A6AC: BF8701A2
	v_fmac_f32_e32 v84, v72, v74                               // 00000019A6B0: 56A89548
	v_cvt_i32_f32_e32 v72, v83                                 // 00000019A6B4: 7E901153
	v_fmac_f32_e32 v57, v73, v57                               // 00000019A6B8: 56727349
	v_div_scale_f32 v73, vcc_lo, v41, v59, v41                 // 00000019A6BC: D6FC6A49 04A67729
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000019A6C4: BF8701B5
	.long 0xd71c003e                                           // 00000019A6C8: D71C003E
	v_cndmask_b32_e32 v1, v62, v76, vcc_lo                     // 00000019A6CC: 0202993E
	v_exp_f32_e32 v76, v80                                     // 00000019A6D0: 7E984B50
	v_fma_f32 v58, -v58, v84, v81                              // 00000019A6D4: D613003A 2546A93A
	v_mul_f32_e32 v75, v73, v57                                // 00000019A6DC: 10967349
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019A6E0: BF8701A3
	v_cndmask_b32_e64 v62, 0, v62, s1                          // 00000019A6E4: D501003E 00067C80
	.long 0xd41b0001                                           // 00000019A6EC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v61, vcc_lo              // 00000019A6F0: 02027AFF C2B17218
	v_fma_f32 v77, -v71, v75, v73                              // 00000019A6F8: D613004D 25269747
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019A700: BF870292
	v_cndmask_b32_e64 v61, 0x7f800000, v62, s1                 // 00000019A704: D501003D 00067CFF 7F800000
	.long 0xd71c003e                                           // 00000019A710: D71C003E
	v_cndmask_b32_e32 v1, v76, v72, vcc_lo                     // 00000019A714: 0202914C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019A718: BF870093
	v_fmac_f32_e32 v75, v77, v57                               // 00000019A71C: 5696734D
	v_fma_f32 v71, -v71, v75, v73                              // 00000019A720: D6130047 25269747
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019A728: BF870121
	v_div_fmas_f32 v57, v71, v57, v75                          // 00000019A72C: D6370039 052E7347
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v79                  // 00000019A734: 7C3C9EFF 42CE8ED0
	v_div_fixup_f32 v41, v57, v59, v41                         // 00000019A73C: D6270029 04A67739
	v_cndmask_b32_e32 v62, 0, v62, vcc_lo                      // 00000019A744: 027C7C80
	s_mov_b32 vcc_lo, s0                                       // 00000019A748: BEEA0000
	.long 0x7f763980                                           // 00000019A74C: 7F763980
	v_div_fmas_f32 v58, v58, v74, v84                          // 00000019A750: D637003A 0552953A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v79                  // 00000019A758: 7C369EFF C2B17218
	v_add_f32_e32 v61, 1.0, v61                                // 00000019A760: 067A7AF2
	.long 0x7e7639a9                                           // 00000019A764: 7E7639A9
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019A768: BF870224
	v_div_fixup_f32 v42, v58, v60, v42                         // 00000019A76C: D627002A 04AA793A
	v_cndmask_b32_e32 v62, 0x7f800000, v62, vcc_lo             // 00000019A774: 027C7CFF 7F800000
	v_div_scale_f32 v71, null, v61, v61, v43                   // 00000019A77C: D6FC7C47 04AE7B3D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019A784: BF870113
	.long 0x7e0039aa                                           // 00000019A788: 7E0039AA
	v_rcp_f32_e32 v53, v71                                     // 00000019A78C: 7E6A5547
	s_waitcnt vmcnt(17)                                        // 00000019A790: BF8947F7
	v_lshlrev_b32_e32 v60, 16, v140                            // 00000019A794: 30791890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019A798: BF870092
	v_dual_add_f32 v58, 1.0, v62 :: v_dual_and_b32 v75, 1, v0  // 00000019A79C: C9247CF2 3A4A0081
	v_add3_u32 v42, v42, v75, 0x7fff                           // 00000019A7A4: D655002A 03FE972A 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019A7B0: BF870095
	v_fma_f32 v62, -v71, v53, 1.0                              // 00000019A7B4: D613003E 23CA6B47
	v_fmac_f32_e32 v53, v62, v53                               // 00000019A7BC: 566A6B3E
	v_mul_f32_e32 v57, 0xbfb8aa3b, v60                         // 00000019A7C0: 107278FF BFB8AA3B
	v_div_scale_f32 v54, null, v58, v58, v44                   // 00000019A7C8: D6FC7C36 04B2753A
	v_div_scale_f32 v62, vcc_lo, v43, v61, v43                 // 00000019A7D0: D6FC6A3E 04AE7B2B
	.long 0xd41e0001                                           // 00000019A7D8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v60, vcc_lo              // 00000019A7DC: 020278FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019A7E4: BF870214
	v_fma_f32 v73, 0xbfb8aa3b, v60, -v57                       // 00000019A7E8: D6130049 84E678FF BFB8AA3B
	v_rcp_f32_e32 v72, v54                                     // 00000019A7F4: 7E905536
	v_rndne_f32_e32 v74, v57                                   // 00000019A7F8: 7E944739
	s_waitcnt vmcnt(11)                                        // 00000019A7FC: BF892FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019A800: BF870092
	v_dual_fmac_f32 v73, 0xb2a5705f, v60 :: v_dual_lshlrev_b32 v76, 16, v139// 00000019A804: C82278FF 494D1690 B2A5705F
	v_mul_f32_e32 v77, 0xbfb8aa3b, v76                         // 00000019A810: 109A98FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019A818: BF8701A5
	v_fma_f32 v79, -v54, v72, 1.0                              // 00000019A81C: D613004F 23CA9136
	v_sub_f32_e32 v57, v57, v74                                // 00000019A824: 08729539
	v_fma_f32 v80, 0xbfb8aa3b, v76, -v77                       // 00000019A828: D6130050 853698FF BFB8AA3B
	v_and_b32_e32 v59, 1, v59                                  // 00000019A834: 36767681
	v_rndne_f32_e32 v81, v77                                   // 00000019A838: 7EA2474D
	v_fmac_f32_e32 v72, v79, v72                               // 00000019A83C: 5690914F
	v_div_scale_f32 v79, s0, v44, v58, v44                     // 00000019A840: D6FC004F 04B2752C
	v_dual_add_f32 v57, v57, v73 :: v_dual_fmac_f32 v80, 0xb2a5705f, v76// 00000019A848: C9009339 395098FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019A854: BF870224
	v_sub_f32_e32 v77, v77, v81                                // 00000019A858: 089AA34D
	v_add3_u32 v41, v41, v59, 0x7fff                           // 00000019A85C: D6550029 03FE7729 00007FFF
	v_mul_f32_e32 v82, v79, v72                                // 00000019A868: 10A4914F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019A86C: BF870004
	v_exp_f32_e32 v57, v57                                     // 00000019A870: 7E724B39
	v_cvt_i32_f32_e32 v74, v74                                 // 00000019A874: 7E94114A
	v_add_f32_e32 v77, v77, v80                                // 00000019A878: 069AA14D
	global_store_d16_hi_b16 v[7:8], v41, off offset:64         // 00000019A87C: DC960040 007C2907
	v_fma_f32 v59, -v54, v82, v79                              // 00000019A884: D613003B 253EA536
	v_mul_f32_e32 v73, v62, v53                                // 00000019A88C: 10926B3E
	global_store_d16_hi_b16 v[47:48], v42, off offset:64       // 00000019A890: DC960040 007C2A2F
	v_fmac_f32_e32 v82, v59, v72                               // 00000019A898: 56A4913B
	v_fma_f32 v75, -v71, v73, v62                              // 00000019A89C: D613004B 24FA9347
	.long 0xd71c0039                                           // 00000019A8A4: D71C0039
	v_cndmask_b32_e32 v1, v57, v74, vcc_lo                     // 00000019A8A8: 02029539
	v_exp_f32_e32 v74, v77                                     // 00000019A8AC: 7E944B4D
	v_cvt_i32_f32_e32 v59, v81                                 // 00000019A8B0: 7E761151
	v_fma_f32 v54, -v54, v82, v79                              // 00000019A8B4: D6130036 253EA536
	v_fmac_f32_e32 v73, v75, v53                               // 00000019A8BC: 56926B4B
	v_cndmask_b32_e64 v57, 0, v57, s1                          // 00000019A8C0: D5010039 00067280
	.long 0xd41b0001                                           // 00000019A8C8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v60, vcc_lo              // 00000019A8CC: 020278FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019A8D4: BF870293
	v_fma_f32 v62, -v71, v73, v62                              // 00000019A8D8: D613003E 24FA9347
	.long 0xd71c003b                                           // 00000019A8E0: D71C003B
	v_cndmask_b32_e32 v1, v74, v59, vcc_lo                     // 00000019A8E4: 0202774A
	s_waitcnt vmcnt(5)                                         // 00000019A8E8: BF8917F7
	v_lshlrev_b32_e32 v74, 16, v141                            // 00000019A8EC: 30951A90
	v_cndmask_b32_e64 v57, 0x7f800000, v57, s1                 // 00000019A8F0: D5010039 000672FF 7F800000
	v_div_fmas_f32 v53, v62, v53, v73                          // 00000019A8FC: D6370035 05266B3E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v76                  // 00000019A904: 7C3C98FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019A90C: BF870194
	v_mul_f32_e32 v75, 0xbfb8aa3b, v74                         // 00000019A910: 109694FF BFB8AA3B
	v_div_fixup_f32 v43, v53, v61, v43                         // 00000019A918: D627002B 04AE7B35
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 00000019A920: 02767680
	s_mov_b32 vcc_lo, s0                                       // 00000019A924: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000019A928: BF8701B3
	v_fma_f32 v77, 0xbfb8aa3b, v74, -v75                       // 00000019A92C: D613004D 852E94FF BFB8AA3B
	v_div_fmas_f32 v54, v54, v72, v82                          // 00000019A938: D6370036 054A9136
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v76                  // 00000019A940: 7C3698FF C2B17218
	v_fmac_f32_e32 v77, 0xb2a5705f, v74                        // 00000019A948: 569A94FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019A950: BF870003
	v_div_fixup_f32 v41, v54, v58, v44                         // 00000019A954: D6270029 04B27536
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 00000019A95C: 027676FF 7F800000
	v_mul_f32_e32 v44, v46, v51                                // 00000019A964: 1058672E
	v_lshlrev_b32_e32 v58, 16, v78                             // 00000019A968: 30749C90
	v_rndne_f32_e32 v78, v75                                   // 00000019A96C: 7E9C474B
	.long 0x7e0039a9                                           // 00000019A970: 7E0039A9
	v_add_f32_e32 v54, 1.0, v59                                // 00000019A974: 066C76F2
	.long 0x7e7639ab                                           // 00000019A978: 7E7639AB
	v_mul_f32_e32 v53, 0xbfb8aa3b, v58                         // 00000019A97C: 106A74FF BFB8AA3B
	.long 0x7f763980                                           // 00000019A984: 7F763980
	v_sub_f32_e32 v75, v75, v78                                // 00000019A988: 08969D4B
	v_div_scale_f32 v42, null, v54, v54, v44                   // 00000019A98C: D6FC7C2A 04B26D36
	.long 0xd41e0001                                           // 00000019A994: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v58, vcc_lo              // 00000019A998: 020274FF 42CE8ED0
	v_fma_f32 v71, 0xbfb8aa3b, v58, -v53                       // 00000019A9A0: D6130047 84D674FF BFB8AA3B
	v_rndne_f32_e32 v72, v53                                   // 00000019A9AC: 7E904735
	v_and_b32_e32 v59, 1, v59                                  // 00000019A9B0: 36767681
	v_rcp_f32_e32 v62, v42                                     // 00000019A9B4: 7E7C552A
	v_add_f32_e32 v75, v75, v77                                // 00000019A9B8: 06969B4B
	v_fmac_f32_e32 v71, 0xb2a5705f, v58                        // 00000019A9BC: 568E74FF B2A5705F
	v_sub_f32_e32 v53, v53, v72                                // 00000019A9C4: 086A9135
	v_cvt_i32_f32_e32 v72, v72                                 // 00000019A9C8: 7E901148
	v_add3_u32 v43, v43, v59, 0x7fff                           // 00000019A9CC: D655002B 03FE772B 00007FFF
	v_and_b32_e32 v73, 1, v0                                   // 00000019A9D8: 36920081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019A9DC: BF870294
	v_add_f32_e32 v53, v53, v71                                // 00000019A9E0: 066A8F35
	v_fma_f32 v76, -v42, v62, 1.0                              // 00000019A9E4: D613004C 23CA7D2A
	v_mul_f32_e32 v45, v45, v52                                // 00000019A9EC: 105A692D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019A9F0: BF870214
	v_add3_u32 v41, v41, v73, 0x7fff                           // 00000019A9F4: D6550029 03FE9329 00007FFF
	v_exp_f32_e32 v53, v53                                     // 00000019AA00: 7E6A4B35
	global_store_d16_hi_b16 v[15:16], v43, off offset:64       // 00000019AA04: DC960040 007C2B0F
	v_fmac_f32_e32 v62, v76, v62                               // 00000019AA0C: 567C7D4C
	v_div_scale_f32 v76, s0, v44, v54, v44                     // 00000019AA10: D6FC004C 04B26D2C
	global_store_d16_hi_b16 v[23:24], v41, off offset:64       // 00000019AA18: DC960040 007C2917
	v_mul_f32_e32 v79, v76, v62                                // 00000019AA20: 109E7D4C
	.long 0xd71c0035                                           // 00000019AA24: D71C0035
	v_cndmask_b32_e32 v1, v53, v72, vcc_lo                     // 00000019AA28: 02029135
	v_exp_f32_e32 v72, v75                                     // 00000019AA2C: 7E904B4B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019AA30: BF870112
	v_fma_f32 v59, -v42, v79, v76                              // 00000019AA34: D613003B 25329F2A
	v_cndmask_b32_e64 v53, 0, v53, s1                          // 00000019AA3C: D5010035 00066A80
	.long 0xd41b0001                                           // 00000019AA44: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v58, vcc_lo              // 00000019AA48: 020274FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019AA50: BF8701A3
	v_fmac_f32_e32 v79, v59, v62                               // 00000019AA54: 569E7D3B
	v_cvt_i32_f32_e32 v59, v78                                 // 00000019AA58: 7E76114E
	v_cndmask_b32_e64 v53, 0x7f800000, v53, s1                 // 00000019AA5C: D5010035 00066AFF 7F800000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019AA68: BF870003
	v_fma_f32 v42, -v42, v79, v76                              // 00000019AA6C: D613002A 25329F2A
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 00000019AA74: BF870185
	.long 0xd71c003a                                           // 00000019AA78: D71C003A
	v_cndmask_b32_e32 v1, v72, v59, vcc_lo                     // 00000019AA7C: 02027748
	v_dual_add_f32 v57, 1.0, v57 :: v_dual_lshlrev_b32 v72, 16, v132// 00000019AA80: C92272F2 39490890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019AA88: BF870091
	v_div_scale_f32 v60, null, v57, v57, v45                   // 00000019AA8C: D6FC7C3C 04B67339
	v_rcp_f32_e32 v46, v60                                     // 00000019AA94: 7E5C553C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019AA98: BF870095
	v_fma_f32 v61, -v60, v46, 1.0                              // 00000019AA9C: D613003D 23CA5D3C
	v_fmac_f32_e32 v46, v61, v46                               // 00000019AAA4: 565C5D3D
	v_div_scale_f32 v61, vcc_lo, v45, v57, v45                 // 00000019AAA8: D6FC6A3D 04B6732D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019AAB0: BF870091
	v_mul_f32_e32 v71, v61, v46                                // 00000019AAB4: 108E5D3D
	v_fma_f32 v73, -v60, v71, v61                              // 00000019AAB8: D6130049 24F68F3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019AAC0: BF870121
	v_fmac_f32_e32 v71, v73, v46                               // 00000019AAC4: 568E5D49
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000019AAC8: 109290FF BFB8AA3B
	v_fma_f32 v60, -v60, v71, v61                              // 00000019AAD0: D613003C 24F68F3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019AAD8: BF8701A2
	v_fma_f32 v75, 0xbfb8aa3b, v72, -v73                       // 00000019AADC: D613004B 852690FF BFB8AA3B
	v_rndne_f32_e32 v76, v73                                   // 00000019AAE8: 7E984749
	v_div_fmas_f32 v46, v60, v46, v71                          // 00000019AAEC: D637002E 051E5D3C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v74                  // 00000019AAF4: 7C3C94FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019AAFC: BF870214
	v_fmac_f32_e32 v75, 0xb2a5705f, v72                        // 00000019AB00: 569690FF B2A5705F
	v_dual_sub_f32 v73, v73, v76 :: v_dual_cndmask_b32 v58, 0, v58// 00000019AB08: C9529949 493A7480
	s_mov_b32 vcc_lo, s0                                       // 00000019AB10: BEEA0000
	v_div_fixup_f32 v45, v46, v57, v45                         // 00000019AB14: D627002D 04B6732E
	v_div_fmas_f32 v42, v42, v62, v79                          // 00000019AB1C: D637002A 053E7D2A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v74                  // 00000019AB24: 7C3694FF C2B17218
	.long 0x7f723980                                           // 00000019AB2C: 7F723980
	v_add_f32_e32 v73, v73, v75                                // 00000019AB30: 06929749
	.long 0x7e7239ad                                           // 00000019AB34: 7E7239AD
	v_div_fixup_f32 v42, v42, v54, v44                         // 00000019AB38: D627002A 04B26D2A
	v_cndmask_b32_e32 v58, 0x7f800000, v58, vcc_lo             // 00000019AB40: 027474FF 7F800000
	v_lshlrev_b32_e32 v54, 16, v133                            // 00000019AB48: 306D0A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019AB4C: BF870214
	v_and_b32_e32 v57, 1, v57                                  // 00000019AB50: 36727281
	.long 0x7e0039aa                                           // 00000019AB54: 7E0039AA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019AB58: BF870214
	v_add_f32_e32 v44, 1.0, v58                                // 00000019AB5C: 065874F2
	v_mul_f32_e32 v46, 0xbfb8aa3b, v54                         // 00000019AB60: 105C6CFF BFB8AA3B
	.long 0xd41e0001                                           // 00000019AB68: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v54, vcc_lo              // 00000019AB6C: 02026CFF 42CE8ED0
	v_add3_u32 v45, v45, v57, 0x7fff                           // 00000019AB74: D655002D 03FE732D 00007FFF
	v_and_b32_e32 v71, 1, v0                                   // 00000019AB80: 368E0081
	v_div_scale_f32 v41, null, v44, v44, v34                   // 00000019AB84: D6FC7C29 048A592C
	v_fma_f32 v61, 0xbfb8aa3b, v54, -v46                       // 00000019AB8C: D613003D 84BA6CFF BFB8AA3B
	v_rndne_f32_e32 v62, v46                                   // 00000019AB98: 7E7C472E
	global_store_d16_hi_b16 v[31:32], v45, off offset:64       // 00000019AB9C: DC960040 007C2D1F
	v_add3_u32 v42, v42, v71, 0x7fff                           // 00000019ABA4: D655002A 03FE8F2A 00007FFF
	v_rcp_f32_e32 v60, v41                                     // 00000019ABB0: 7E785529
	v_fmac_f32_e32 v61, 0xb2a5705f, v54                        // 00000019ABB4: 567A6CFF B2A5705F
	v_sub_f32_e32 v46, v46, v62                                // 00000019ABBC: 085C7D2E
	v_cvt_i32_f32_e32 v62, v62                                 // 00000019ABC0: 7E7C113E
	v_lshlrev_b32_e32 v45, 16, v135                            // 00000019ABC4: 305B0E90
	global_store_d16_hi_b16 v[39:40], v42, off offset:64       // 00000019ABC8: DC960040 007C2A27
	v_add_f32_e32 v46, v46, v61                                // 00000019ABD0: 065C7B2E
	v_fma_f32 v74, -v41, v60, 1.0                              // 00000019ABD4: D613004A 23CA7929
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019ABDC: BF870092
	v_exp_f32_e32 v46, v46                                     // 00000019ABE0: 7E5C4B2E
	v_fmac_f32_e32 v60, v74, v60                               // 00000019ABE4: 5678794A
	v_div_scale_f32 v74, s0, v34, v44, v34                     // 00000019ABE8: D6FC004A 048A5922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019ABF0: BF870291
	v_mul_f32_e32 v77, v74, v60                                // 00000019ABF4: 109A794A
	.long 0xd71c002e                                           // 00000019ABF8: D71C002E
	v_cndmask_b32_e32 v1, v46, v62, vcc_lo                     // 00000019ABFC: 02027D2E
	v_exp_f32_e32 v62, v73                                     // 00000019AC00: 7E7C4B49
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019AC04: BF870112
	v_fma_f32 v57, -v41, v77, v74                              // 00000019AC08: D6130039 252A9B29
	v_cndmask_b32_e64 v46, 0, v46, s1                          // 00000019AC10: D501002E 00065C80
	.long 0xd41b0001                                           // 00000019AC18: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v54, vcc_lo              // 00000019AC1C: 02026CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019AC24: BF8701A3
	v_fmac_f32_e32 v77, v57, v60                               // 00000019AC28: 569A7939
	v_cvt_i32_f32_e32 v57, v76                                 // 00000019AC2C: 7E72114C
	v_cndmask_b32_e64 v46, 0x7f800000, v46, s1                 // 00000019AC30: D501002E 00065CFF 7F800000
	.long 0xd41e0001                                           // 00000019AC3C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v45, vcc_lo              // 00000019AC40: 02025AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019AC48: BF870004
	v_fma_f32 v41, -v41, v77, v74                              // 00000019AC4C: D6130029 252A9B29
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 00000019AC54: BF870205
	.long 0xd71c0036                                           // 00000019AC58: D71C0036
	v_cndmask_b32_e32 v1, v62, v57, vcc_lo                     // 00000019AC5C: 0202733E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019AC60: BF870124
	v_dual_add_f32 v53, 1.0, v53 :: v_dual_add_f32 v46, 1.0, v46// 00000019AC64: C9086AF2 352E5CF2
	v_lshlrev_b32_e32 v62, 16, v134                            // 00000019AC6C: 307D0C90
	v_div_scale_f32 v59, null, v53, v53, v33                   // 00000019AC70: D6FC7C3B 04866B35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019AC78: BF870113
	v_div_scale_f32 v57, null, v46, v46, v35                   // 00000019AC7C: D6FC7C39 048E5D2E
	v_rcp_f32_e32 v43, v59                                     // 00000019AC84: 7E56553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019AC88: BF870095
	v_fma_f32 v58, -v59, v43, 1.0                              // 00000019AC8C: D613003A 23CA573B
	v_fmac_f32_e32 v43, v58, v43                               // 00000019AC94: 5656573A
	v_div_scale_f32 v58, vcc_lo, v33, v53, v33                 // 00000019AC98: D6FC6A3A 04866B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019ACA0: BF870091
	v_mul_f32_e32 v61, v58, v43                                // 00000019ACA4: 107A573A
	v_fma_f32 v71, -v59, v61, v58                              // 00000019ACA8: D6130047 24EA7B3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019ACB0: BF870121
	v_fmac_f32_e32 v61, v71, v43                               // 00000019ACB4: 567A5747
	v_mul_f32_e32 v71, 0xbfb8aa3b, v62                         // 00000019ACB8: 108E7CFF BFB8AA3B
	v_fma_f32 v58, -v59, v61, v58                              // 00000019ACC0: D613003A 24EA7B3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019ACC8: BF8701A2
	v_fma_f32 v73, 0xbfb8aa3b, v62, -v71                       // 00000019ACCC: D6130049 851E7CFF BFB8AA3B
	v_rndne_f32_e32 v74, v71                                   // 00000019ACD8: 7E944747
	v_div_fmas_f32 v43, v58, v43, v61                          // 00000019ACDC: D637002B 04F6573A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000019ACE4: 7C3C90FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019ACEC: BF870214
	v_fmac_f32_e32 v73, 0xb2a5705f, v62                        // 00000019ACF0: 56927CFF B2A5705F
	v_sub_f32_e32 v71, v71, v74                                // 00000019ACF8: 088E9547
	v_cndmask_b32_e32 v54, 0, v54, vcc_lo                      // 00000019ACFC: 026C6C80
	s_mov_b32 vcc_lo, s0                                       // 00000019AD00: BEEA0000
	v_div_fixup_f32 v33, v43, v53, v33                         // 00000019AD04: D6270021 04866B2B
	v_div_fmas_f32 v41, v41, v60, v77                          // 00000019AD0C: D6370029 05367929
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000019AD14: 7C3690FF C2B17218
	v_mul_f32_e32 v43, 0xbfb8aa3b, v45                         // 00000019AD1C: 10565AFF BFB8AA3B
	.long 0x7f6a3980                                           // 00000019AD24: 7F6A3980
	.long 0x7e6a39a1                                           // 00000019AD28: 7E6A39A1
	v_div_fixup_f32 v34, v41, v44, v34                         // 00000019AD2C: D6270022 048A5929
	v_cndmask_b32_e32 v54, 0x7f800000, v54, vcc_lo             // 00000019AD34: 026C6CFF 7F800000
	v_rcp_f32_e32 v41, v57                                     // 00000019AD3C: 7E525539
	v_fma_f32 v59, 0xbfb8aa3b, v45, -v43                       // 00000019AD40: D613003B 84AE5AFF BFB8AA3B
	v_rndne_f32_e32 v60, v43                                   // 00000019AD4C: 7E78472B
	.long 0x7e0039a2                                           // 00000019AD50: 7E0039A2
	v_dual_add_f32 v44, 1.0, v54 :: v_dual_and_b32 v53, 1, v53 // 00000019AD54: C9246CF2 2C346A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019AD5C: BF870214
	v_fmac_f32_e32 v59, 0xb2a5705f, v45                        // 00000019AD60: 56765AFF B2A5705F
	v_sub_f32_e32 v43, v43, v60                                // 00000019AD68: 0856792B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019AD6C: BF870214
	v_and_b32_e32 v61, 1, v0                                   // 00000019AD70: 367A0081
	v_div_scale_f32 v42, null, v44, v44, v36                   // 00000019AD74: D6FC7C2A 0492592C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019AD7C: BF870005
	v_fma_f32 v54, -v57, v41, 1.0                              // 00000019AD80: D6130036 23CA5339
	v_cvt_i32_f32_e32 v60, v60                                 // 00000019AD88: 7E78113C
	v_add_f32_e32 v43, v43, v59                                // 00000019AD8C: 0656772B
	v_add3_u32 v34, v34, v61, 0x7fff                           // 00000019AD90: D6550022 03FE7B22 00007FFF
	v_rcp_f32_e32 v58, v42                                     // 00000019AD9C: 7E74552A
	v_fmac_f32_e32 v41, v54, v41                               // 00000019ADA0: 56525336
	v_div_scale_f32 v54, vcc_lo, v35, v46, v35                 // 00000019ADA4: D6FC6A36 048E5D23
	v_exp_f32_e32 v43, v43                                     // 00000019ADAC: 7E564B2B
	v_add_f32_e32 v71, v71, v73                                // 00000019ADB0: 068E9347
	v_add3_u32 v33, v33, v53, 0x7fff                           // 00000019ADB4: D6550021 03FE6B21 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000019ADC0: BF870313
	v_mul_f32_e32 v59, v54, v41                                // 00000019ADC4: 10765336
	v_fma_f32 v72, -v42, v58, 1.0                              // 00000019ADC8: D6130048 23CA752A
	global_store_d16_hi_b16 v[7:8], v33, off offset:96         // 00000019ADD0: DC960060 007C2107
	v_fma_f32 v61, -v57, v59, v54                              // 00000019ADD8: D613003D 24DA7739
	.long 0xd71c002b                                           // 00000019ADE0: D71C002B
	v_cndmask_b32_e32 v1, v43, v60, vcc_lo                     // 00000019ADE4: 0202792B
	v_exp_f32_e32 v60, v71                                     // 00000019ADE8: 7E784B47
	v_fmac_f32_e32 v58, v72, v58                               // 00000019ADEC: 56747548
	v_div_scale_f32 v72, s0, v36, v44, v36                     // 00000019ADF0: D6FC0048 04925924
	v_fmac_f32_e32 v59, v61, v41                               // 00000019ADF8: 5676533D
	v_cndmask_b32_e64 v43, 0, v43, s1                          // 00000019ADFC: D501002B 00065680
	.long 0xd41b0001                                           // 00000019AE04: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v45, vcc_lo              // 00000019AE08: 02025AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v34, off offset:96       // 00000019AE10: DC960060 007C222F
	v_mul_f32_e32 v75, v72, v58                                // 00000019AE18: 10967548
	v_fma_f32 v54, -v57, v59, v54                              // 00000019AE1C: D6130036 24DA7739
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 00000019AE24: D501002B 000656FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019AE30: BF870193
	v_fma_f32 v53, -v42, v75, v72                              // 00000019AE34: D6130035 2522972A
	v_div_fmas_f32 v41, v54, v41, v59                          // 00000019AE3C: D6370029 04EE5336
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v62                  // 00000019AE44: 7C3C7CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019AE4C: BF870214
	v_add_f32_e32 v43, 1.0, v43                                // 00000019AE50: 065656F2
	v_fmac_f32_e32 v75, v53, v58                               // 00000019AE54: 56967535
	v_cvt_i32_f32_e32 v53, v74                                 // 00000019AE58: 7E6A114A
	v_div_fixup_f32 v35, v41, v46, v35                         // 00000019AE5C: D6270023 048E5D29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019AE64: BF870193
	v_fma_f32 v42, -v42, v75, v72                              // 00000019AE68: D613002A 2522972A
	.long 0xd71c002d                                           // 00000019AE70: D71C002D
	v_cndmask_b32_e32 v1, v60, v53, vcc_lo                     // 00000019AE74: 02026B3C
	v_div_scale_f32 v53, null, v43, v43, v37                   // 00000019AE78: D6FC7C35 0496572B
	s_waitcnt vmcnt(4)                                         // 00000019AE80: BF8913F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019AE84: BF8700A2
	v_dual_cndmask_b32 v45, 0, v45 :: v_dual_lshlrev_b32 v60, 16, v136// 00000019AE88: CA625A80 2D3D1090
	s_mov_b32 vcc_lo, s0                                       // 00000019AE90: BEEA0000
	v_mul_f32_e32 v61, 0xbfb8aa3b, v60                         // 00000019AE94: 107A78FF BFB8AA3B
	v_div_fmas_f32 v42, v42, v58, v75                          // 00000019AE9C: D637002A 052E752A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v62                  // 00000019AEA4: 7C367CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019AEAC: BF870193
	v_fma_f32 v71, 0xbfb8aa3b, v60, -v61                       // 00000019AEB0: D6130047 84F678FF BFB8AA3B
	v_div_fixup_f32 v33, v42, v44, v36                         // 00000019AEBC: D6270021 0492592A
	v_dual_cndmask_b32 v45, 0x7f800000, v45 :: v_dual_mul_f32 v36, v38, v51// 00000019AEC4: CA465AFF 2D246726 7F800000
	v_lshlrev_b32_e32 v44, 16, v86                             // 00000019AED0: 3058AC90
	v_rcp_f32_e32 v38, v53                                     // 00000019AED4: 7E4C5535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019AED8: BF870193
	.long 0x7e0039a1                                           // 00000019AEDC: 7E0039A1
	v_add_f32_e32 v42, 1.0, v45                                // 00000019AEE0: 06545AF2
	v_rndne_f32_e32 v72, v61                                   // 00000019AEE4: 7E90473D
	v_mul_f32_e32 v41, 0xbfb8aa3b, v44                         // 00000019AEE8: 105258FF BFB8AA3B
	.long 0x7e5a39a3                                           // 00000019AEF0: 7E5A39A3
	.long 0x7f5a3980                                           // 00000019AEF4: 7F5A3980
	v_div_scale_f32 v34, null, v42, v42, v36                   // 00000019AEF8: D6FC7C22 0492552A
	v_and_b32_e32 v59, 1, v0                                   // 00000019AF00: 36760081
	v_fma_f32 v57, 0xbfb8aa3b, v44, -v41                       // 00000019AF04: D6130039 84A658FF BFB8AA3B
	v_rndne_f32_e32 v58, v41                                   // 00000019AF10: 7E744729
	v_fma_f32 v46, -v53, v38, 1.0                              // 00000019AF14: D613002E 23CA4D35
	v_rcp_f32_e32 v54, v34                                     // 00000019AF1C: 7E6C5522
	v_fmac_f32_e32 v71, 0xb2a5705f, v60                        // 00000019AF20: 568E78FF B2A5705F
	v_fmac_f32_e32 v57, 0xb2a5705f, v44                        // 00000019AF28: 567258FF B2A5705F
	v_sub_f32_e32 v41, v41, v58                                // 00000019AF30: 08527529
	v_fmac_f32_e32 v38, v46, v38                               // 00000019AF34: 564C4D2E
	v_div_scale_f32 v46, vcc_lo, v37, v43, v37                 // 00000019AF38: D6FC6A2E 04965725
	v_sub_f32_e32 v61, v61, v72                                // 00000019AF40: 087A913D
	v_and_b32_e32 v45, 1, v45                                  // 00000019AF44: 365A5A81
	v_add_f32_e32 v41, v41, v57                                // 00000019AF48: 06527329
	v_add3_u32 v33, v33, v59, 0x7fff                           // 00000019AF4C: D6550021 03FE7721 00007FFF
	v_fma_f32 v62, -v34, v54, 1.0                              // 00000019AF58: D613003E 23CA6D22
	v_mul_f32_e32 v57, v46, v38                                // 00000019AF60: 10724D2E
	v_cvt_i32_f32_e32 v58, v58                                 // 00000019AF64: 7E74113A
	v_exp_f32_e32 v41, v41                                     // 00000019AF68: 7E524B29
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000019AF6C: BF870253
	v_dual_add_f32 v61, v61, v71 :: v_dual_fmac_f32 v54, v62, v54// 00000019AF70: C9008F3D 3D366D3E
	v_div_scale_f32 v62, s0, v36, v42, v36                     // 00000019AF78: D6FC003E 04925524
	v_fma_f32 v59, -v53, v57, v46                              // 00000019AF80: D613003B 24BA7335
	v_add3_u32 v35, v35, v45, 0x7fff                           // 00000019AF88: D6550023 03FE5B23 00007FFF
	.long 0xd41e0001                                           // 00000019AF94: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v44, vcc_lo              // 00000019AF98: 020258FF 42CE8ED0
	v_mul_f32_e32 v73, v62, v54                                // 00000019AFA0: 10926D3E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019AFA4: BF870294
	v_fmac_f32_e32 v57, v59, v38                               // 00000019AFA8: 56724D3B
	.long 0xd71c0029                                           // 00000019AFAC: D71C0029
	v_cndmask_b32_e32 v1, v41, v58, vcc_lo                     // 00000019AFB0: 02027529
	v_exp_f32_e32 v58, v61                                     // 00000019AFB4: 7E744B3D
	global_store_d16_hi_b16 v[15:16], v35, off offset:96       // 00000019AFB8: DC960060 007C230F
	v_fma_f32 v45, -v34, v73, v62                              // 00000019AFC0: D613002D 24FA9322
	v_fma_f32 v46, -v53, v57, v46                              // 00000019AFC8: D613002E 24BA7335
	v_cndmask_b32_e64 v41, 0, v41, s1                          // 00000019AFD0: D5010029 00065280
	.long 0xd41b0001                                           // 00000019AFD8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v44, vcc_lo              // 00000019AFDC: 020258FF C2B17218
	global_store_d16_hi_b16 v[23:24], v33, off offset:96       // 00000019AFE4: DC960060 007C2117
	v_fmac_f32_e32 v73, v45, v54                               // 00000019AFEC: 56926D2D
	v_cvt_i32_f32_e32 v45, v72                                 // 00000019AFF0: 7E5A1148
	v_div_fmas_f32 v38, v46, v38, v57                          // 00000019AFF4: D6370026 04E64D2E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v60                  // 00000019AFFC: 7C3C78FF 42CE8ED0
	v_cndmask_b32_e64 v41, 0x7f800000, v41, s1                 // 00000019B004: D5010029 000652FF 7F800000
	v_fma_f32 v34, -v34, v73, v62                              // 00000019B010: D6130022 24FA9322
	.long 0xd71c002c                                           // 00000019B018: D71C002C
	v_cndmask_b32_e32 v1, v58, v45, vcc_lo                     // 00000019B01C: 02025B3A
	v_div_fixup_f32 v37, v38, v43, v37                         // 00000019B020: D6270025 04965726
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019B028: BF870224
	v_dual_add_f32 v41, 1.0, v41 :: v_dual_lshlrev_b32 v58, 16, v127// 00000019B02C: C92252F2 293AFE90
	.long 0x7f563980                                           // 00000019B034: 7F563980
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 00000019B038: 02585880
	s_mov_b32 vcc_lo, s0                                       // 00000019B03C: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019B040: BF870003
	v_mul_f32_e32 v59, 0xbfb8aa3b, v58                         // 00000019B044: 107674FF BFB8AA3B
	v_div_fmas_f32 v34, v34, v54, v73                          // 00000019B04C: D6370022 05266D22
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v60                  // 00000019B054: 7C3678FF C2B17218
	v_div_scale_f32 v45, null, v41, v41, v25                   // 00000019B05C: D6FC7C2D 04665329
	.long 0x7e5639a5                                           // 00000019B064: 7E5639A5
	v_fma_f32 v61, 0xbfb8aa3b, v58, -v59                       // 00000019B068: D613003D 84EE74FF BFB8AA3B
	v_div_fixup_f32 v34, v34, v42, v36                         // 00000019B074: D6270022 04925522
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo             // 00000019B07C: 025858FF 7F800000
	v_lshlrev_b32_e32 v42, 16, v128                            // 00000019B084: 30550090
	v_rcp_f32_e32 v35, v45                                     // 00000019B088: 7E46552D
	v_rndne_f32_e32 v62, v59                                   // 00000019B08C: 7E7C473B
	.long 0x7e0039a2                                           // 00000019B090: 7E0039A2
	v_add_f32_e32 v36, 1.0, v44                                // 00000019B094: 064858F2
	v_mul_f32_e32 v38, 0xbfb8aa3b, v42                         // 00000019B098: 104C54FF BFB8AA3B
	v_fmac_f32_e32 v61, 0xb2a5705f, v58                        // 00000019B0A0: 567A74FF B2A5705F
	v_sub_f32_e32 v59, v59, v62                                // 00000019B0A8: 08767D3B
	v_and_b32_e32 v57, 1, v0                                   // 00000019B0AC: 36720081
	v_div_scale_f32 v33, null, v36, v36, v26                   // 00000019B0B0: D6FC7C21 046A4924
	v_fma_f32 v53, 0xbfb8aa3b, v42, -v38                       // 00000019B0B8: D6130035 849A54FF BFB8AA3B
	v_rndne_f32_e32 v54, v38                                   // 00000019B0C4: 7E6C4726
	v_fma_f32 v44, -v45, v35, 1.0                              // 00000019B0C8: D613002C 23CA472D
	v_and_b32_e32 v43, 1, v43                                  // 00000019B0D0: 36565681
	v_rcp_f32_e32 v46, v33                                     // 00000019B0D4: 7E5C5521
	v_fmac_f32_e32 v53, 0xb2a5705f, v42                        // 00000019B0D8: 566A54FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000019B0E0: BF870243
	v_dual_sub_f32 v38, v38, v54 :: v_dual_fmac_f32 v35, v44, v35// 00000019B0E4: C9406D26 2622472C
	v_div_scale_f32 v44, vcc_lo, v25, v41, v25                 // 00000019B0EC: D6FC6A2C 04665319
	v_add3_u32 v34, v34, v57, 0x7fff                           // 00000019B0F4: D6550022 03FE7322 00007FFF
	v_cvt_i32_f32_e32 v54, v54                                 // 00000019B100: 7E6C1136
	v_add_f32_e32 v38, v38, v53                                // 00000019B104: 064C6B26
	v_add_f32_e32 v59, v59, v61                                // 00000019B108: 06767B3B
	v_mul_f32_e32 v53, v44, v35                                // 00000019B10C: 106A472C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019B110: BF870005
	v_fma_f32 v60, -v33, v46, 1.0                              // 00000019B114: D613003C 23CA5D21
	v_add3_u32 v37, v37, v43, 0x7fff                           // 00000019B11C: D6550025 03FE5725 00007FFF
	v_exp_f32_e32 v38, v38                                     // 00000019B128: 7E4C4B26
	.long 0xd41e0001                                           // 00000019B12C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v42, vcc_lo              // 00000019B130: 020254FF 42CE8ED0
	v_fma_f32 v57, -v45, v53, v44                              // 00000019B138: D6130039 24B26B2D
	v_fmac_f32_e32 v46, v60, v46                               // 00000019B140: 565C5D3C
	v_div_scale_f32 v60, s0, v26, v36, v26                     // 00000019B144: D6FC003C 046A491A
	global_store_d16_hi_b16 v[31:32], v37, off offset:96       // 00000019B14C: DC960060 007C251F
	v_lshlrev_b32_e32 v37, 16, v130                            // 00000019B154: 304B0490
	v_fmac_f32_e32 v53, v57, v35                               // 00000019B158: 566A4739
	global_store_d16_hi_b16 v[39:40], v34, off offset:96       // 00000019B15C: DC960060 007C2227
	v_mul_f32_e32 v71, v60, v46                                // 00000019B164: 108E5D3C
	.long 0xd71c0026                                           // 00000019B168: D71C0026
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 00000019B16C: 02026D26
	v_exp_f32_e32 v54, v59                                     // 00000019B170: 7E6C4B3B
	v_fma_f32 v44, -v45, v53, v44                              // 00000019B174: D613002C 24B26B2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019B17C: BF870193
	v_fma_f32 v43, -v33, v71, v60                              // 00000019B180: D613002B 24F28F21
	v_cndmask_b32_e64 v38, 0, v38, s1                          // 00000019B188: D5010026 00064C80
	.long 0xd41b0001                                           // 00000019B190: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v42, vcc_lo              // 00000019B194: 020254FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019B19C: BF870004
	v_div_fmas_f32 v35, v44, v35, v53                          // 00000019B1A0: D6370023 04D6472C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v58                  // 00000019B1A8: 7C3C74FF 42CE8ED0
	v_fmac_f32_e32 v71, v43, v46                               // 00000019B1B0: 568E5D2B
	v_cvt_i32_f32_e32 v43, v62                                 // 00000019B1B4: 7E56113E
	v_cndmask_b32_e64 v38, 0x7f800000, v38, s1                 // 00000019B1B8: D5010026 00064CFF 7F800000
	v_div_fixup_f32 v25, v35, v41, v25                         // 00000019B1C4: D6270019 04665323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v37                         // 00000019B1CC: 10464AFF BFB8AA3B
	v_fma_f32 v33, -v33, v71, v60                              // 00000019B1D4: D6130021 24F28F21
	.long 0xd71c002a                                           // 00000019B1DC: D71C002A
	v_cndmask_b32_e32 v1, v54, v43, vcc_lo                     // 00000019B1E0: 02025736
	v_add_f32_e32 v38, 1.0, v38                                // 00000019B1E4: 064C4CF2
	v_lshlrev_b32_e32 v54, 16, v129                            // 00000019B1E8: 306D0290
	v_fma_f32 v45, 0xbfb8aa3b, v37, -v35                       // 00000019B1EC: D613002D 848E4AFF BFB8AA3B
	.long 0x7e523999                                           // 00000019B1F8: 7E523999
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000019B1FC: 02545480
	s_mov_b32 vcc_lo, s0                                       // 00000019B200: BEEA0000
	v_div_scale_f32 v43, null, v38, v38, v27                   // 00000019B204: D6FC7C2B 046E4D26
	v_div_fmas_f32 v33, v33, v46, v71                          // 00000019B20C: D6370021 051E5D21
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v58                  // 00000019B214: 7C3674FF C2B17218
	v_rndne_f32_e32 v46, v35                                   // 00000019B21C: 7E5C4723
	v_fmac_f32_e32 v45, 0xb2a5705f, v37                        // 00000019B220: 565A4AFF B2A5705F
	v_mul_f32_e32 v57, 0xbfb8aa3b, v54                         // 00000019B228: 10726CFF BFB8AA3B
	v_div_fixup_f32 v26, v33, v36, v26                         // 00000019B230: D627001A 046A4921
	v_cndmask_b32_e32 v42, 0x7f800000, v42, vcc_lo             // 00000019B238: 025454FF 7F800000
	v_rcp_f32_e32 v33, v43                                     // 00000019B240: 7E42552B
	v_sub_f32_e32 v35, v35, v46                                // 00000019B244: 08465D23
	v_fma_f32 v59, 0xbfb8aa3b, v54, -v57                       // 00000019B248: D613003B 84E66CFF BFB8AA3B
	.long 0x7e00399a                                           // 00000019B254: 7E00399A
	v_add_f32_e32 v36, 1.0, v42                                // 00000019B258: 064854F2
	v_rndne_f32_e32 v60, v57                                   // 00000019B25C: 7E784739
	v_add_f32_e32 v35, v35, v45                                // 00000019B260: 06465B23
	.long 0x7f523980                                           // 00000019B264: 7F523980
	v_and_b32_e32 v53, 1, v0                                   // 00000019B268: 366A0081
	v_div_scale_f32 v34, null, v36, v36, v28                   // 00000019B26C: D6FC7C22 04724924
	v_fma_f32 v42, -v43, v33, 1.0                              // 00000019B274: D613002A 23CA432B
	v_exp_f32_e32 v35, v35                                     // 00000019B27C: 7E464B23
	v_fmac_f32_e32 v59, 0xb2a5705f, v54                        // 00000019B280: 56766CFF B2A5705F
	v_sub_f32_e32 v57, v57, v60                                // 00000019B288: 08727939
	v_rcp_f32_e32 v44, v34                                     // 00000019B28C: 7E585522
	v_fmac_f32_e32 v33, v42, v33                               // 00000019B290: 5642432A
	v_div_scale_f32 v42, vcc_lo, v27, v38, v27                 // 00000019B294: D6FC6A2A 046E4D1B
	v_and_b32_e32 v41, 1, v41                                  // 00000019B29C: 36525281
	v_add3_u32 v26, v26, v53, 0x7fff                           // 00000019B2A0: D655001A 03FE6B1A 00007FFF
	v_cvt_i32_f32_e32 v46, v46                                 // 00000019B2AC: 7E5C112E
	v_add_f32_e32 v57, v57, v59                                // 00000019B2B0: 06727739
	v_mul_f32_e32 v45, v42, v33                                // 00000019B2B4: 105A432A
	v_add3_u32 v25, v25, v41, 0x7fff                           // 00000019B2B8: D6550019 03FE5319 00007FFF
	.long 0xd41e0001                                           // 00000019B2C4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v37, vcc_lo              // 00000019B2C8: 02024AFF 42CE8ED0
	v_fma_f32 v58, -v34, v44, 1.0                              // 00000019B2D0: D613003A 23CA5922
	.long 0xd71c0023                                           // 00000019B2D8: D71C0023
	v_cndmask_b32_e32 v1, v35, v46, vcc_lo                     // 00000019B2DC: 02025D23
	v_fma_f32 v53, -v43, v45, v42                              // 00000019B2E0: D6130035 24AA5B2B
	v_exp_f32_e32 v46, v57                                     // 00000019B2E8: 7E5C4B39
	global_store_d16_hi_b16 v[7:8], v25, off offset:128        // 00000019B2EC: DC960080 007C1907
	v_fmac_f32_e32 v44, v58, v44                               // 00000019B2F4: 5658593A
	v_div_scale_f32 v58, s0, v28, v36, v28                     // 00000019B2F8: D6FC003A 0472491C
	v_fmac_f32_e32 v45, v53, v33                               // 00000019B300: 565A4335
	v_cndmask_b32_e64 v35, 0, v35, s1                          // 00000019B304: D5010023 00064680
	.long 0xd41b0001                                           // 00000019B30C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v37, vcc_lo              // 00000019B310: 02024AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v26, off offset:128      // 00000019B318: DC960080 007C1A2F
	v_mul_f32_e32 v61, v58, v44                                // 00000019B320: 107A593A
	v_fma_f32 v42, -v43, v45, v42                              // 00000019B324: D613002A 24AA5B2B
	v_cndmask_b32_e64 v35, 0x7f800000, v35, s1                 // 00000019B32C: D5010023 000646FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019B338: BF870193
	v_fma_f32 v41, -v34, v61, v58                              // 00000019B33C: D6130029 24EA7B22
	v_div_fmas_f32 v33, v42, v33, v45                          // 00000019B344: D6370021 04B6432A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v54                  // 00000019B34C: 7C3C6CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019B354: BF870214
	v_add_f32_e32 v35, 1.0, v35                                // 00000019B358: 064646F2
	v_fmac_f32_e32 v61, v41, v44                               // 00000019B35C: 567A5929
	v_cvt_i32_f32_e32 v41, v60                                 // 00000019B360: 7E52113C
	v_div_fixup_f32 v27, v33, v38, v27                         // 00000019B364: D627001B 046E4D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019B36C: BF870193
	v_fma_f32 v34, -v34, v61, v58                              // 00000019B370: D6130022 24EA7B22
	.long 0xd71c0025                                           // 00000019B378: D71C0025
	v_cndmask_b32_e32 v1, v46, v41, vcc_lo                     // 00000019B37C: 0202532E
	v_div_scale_f32 v41, null, v35, v35, v29                   // 00000019B380: D6FC7C29 04764723
	s_waitcnt vmcnt(3)                                         // 00000019B388: BF890FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019B38C: BF8700A2
	v_dual_cndmask_b32 v37, 0, v37 :: v_dual_lshlrev_b32 v46, 16, v131// 00000019B390: CA624A80 252F0690
	s_mov_b32 vcc_lo, s0                                       // 00000019B398: BEEA0000
	v_mul_f32_e32 v53, 0xbfb8aa3b, v46                         // 00000019B39C: 106A5CFF BFB8AA3B
	v_div_fmas_f32 v34, v34, v44, v61                          // 00000019B3A4: D6370022 04F65922
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v54                  // 00000019B3AC: 7C366CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019B3B4: BF870193
	v_fma_f32 v57, 0xbfb8aa3b, v46, -v53                       // 00000019B3B8: D6130039 84D65CFF BFB8AA3B
	v_div_fixup_f32 v25, v34, v36, v28                         // 00000019B3C4: D6270019 04724922
	v_dual_cndmask_b32 v37, 0x7f800000, v37 :: v_dual_mul_f32 v28, v30, v51// 00000019B3CC: CA464AFF 251C671E 7F800000
	v_lshlrev_b32_e32 v36, 16, v87                             // 00000019B3D8: 3048AE90
	v_rcp_f32_e32 v30, v41                                     // 00000019B3DC: 7E3C5529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019B3E0: BF870193
	.long 0x7e003999                                           // 00000019B3E4: 7E003999
	v_add_f32_e32 v34, 1.0, v37                                // 00000019B3E8: 06444AF2
	v_rndne_f32_e32 v58, v53                                   // 00000019B3EC: 7E744735
	v_mul_f32_e32 v33, 0xbfb8aa3b, v36                         // 00000019B3F0: 104248FF BFB8AA3B
	.long 0x7e4a399b                                           // 00000019B3F8: 7E4A399B
	.long 0x7f4a3980                                           // 00000019B3FC: 7F4A3980
	v_div_scale_f32 v26, null, v34, v34, v28                   // 00000019B400: D6FC7C1A 04724522
	v_and_b32_e32 v45, 1, v0                                   // 00000019B408: 365A0081
	v_fma_f32 v43, 0xbfb8aa3b, v36, -v33                       // 00000019B40C: D613002B 848648FF BFB8AA3B
	v_rndne_f32_e32 v44, v33                                   // 00000019B418: 7E584721
	v_fma_f32 v38, -v41, v30, 1.0                              // 00000019B41C: D6130026 23CA3D29
	v_rcp_f32_e32 v42, v26                                     // 00000019B424: 7E54551A
	v_fmac_f32_e32 v57, 0xb2a5705f, v46                        // 00000019B428: 56725CFF B2A5705F
	v_fmac_f32_e32 v43, 0xb2a5705f, v36                        // 00000019B430: 565648FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000019B438: BF870243
	v_dual_sub_f32 v33, v33, v44 :: v_dual_fmac_f32 v30, v38, v30// 00000019B43C: C9405921 211E3D26
	v_div_scale_f32 v38, vcc_lo, v29, v35, v29                 // 00000019B444: D6FC6A26 0476471D
	v_sub_f32_e32 v53, v53, v58                                // 00000019B44C: 086A7535
	v_and_b32_e32 v37, 1, v37                                  // 00000019B450: 364A4A81
	v_add_f32_e32 v33, v33, v43                                // 00000019B454: 06425721
	v_add3_u32 v25, v25, v45, 0x7fff                           // 00000019B458: D6550019 03FE5B19 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000019B464: BF8701C5
	v_fma_f32 v54, -v26, v42, 1.0                              // 00000019B468: D6130036 23CA551A
	v_mul_f32_e32 v43, v38, v30                                // 00000019B470: 10563D26
	v_cvt_i32_f32_e32 v44, v44                                 // 00000019B474: 7E58112C
	v_exp_f32_e32 v33, v33                                     // 00000019B478: 7E424B21
	v_dual_add_f32 v53, v53, v57 :: v_dual_fmac_f32 v42, v54, v42// 00000019B47C: C9007335 352A5536
	v_div_scale_f32 v54, s0, v28, v34, v28                     // 00000019B484: D6FC0036 0472451C
	v_fma_f32 v45, -v41, v43, v38                              // 00000019B48C: D613002D 249A5729
	v_add3_u32 v27, v27, v37, 0x7fff                           // 00000019B494: D655001B 03FE4B1B 00007FFF
	.long 0xd41e0001                                           // 00000019B4A0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v36, vcc_lo              // 00000019B4A4: 020248FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019B4AC: BF870214
	v_mul_f32_e32 v59, v54, v42                                // 00000019B4B0: 10765536
	v_fmac_f32_e32 v43, v45, v30                               // 00000019B4B4: 56563D2D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019B4B8: BF870005
	.long 0xd71c0021                                           // 00000019B4BC: D71C0021
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 00000019B4C0: 02025921
	v_exp_f32_e32 v44, v53                                     // 00000019B4C4: 7E584B35
	global_store_d16_hi_b16 v[15:16], v27, off offset:128      // 00000019B4C8: DC960080 007C1B0F
	v_fma_f32 v37, -v26, v59, v54                              // 00000019B4D0: D6130025 24DA771A
	v_fma_f32 v38, -v41, v43, v38                              // 00000019B4D8: D6130026 249A5729
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 00000019B4E0: D5010021 00064280
	.long 0xd41b0001                                           // 00000019B4E8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v36, vcc_lo              // 00000019B4EC: 020248FF C2B17218
	global_store_d16_hi_b16 v[23:24], v25, off offset:128      // 00000019B4F4: DC960080 007C1917
	v_fmac_f32_e32 v59, v37, v42                               // 00000019B4FC: 56765525
	v_cvt_i32_f32_e32 v37, v58                                 // 00000019B500: 7E4A113A
	v_div_fmas_f32 v30, v38, v30, v43                          // 00000019B504: D637001E 04AE3D26
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 00000019B50C: 7C3C5CFF 42CE8ED0
	v_cndmask_b32_e64 v33, 0x7f800000, v33, s1                 // 00000019B514: D5010021 000642FF 7F800000
	v_fma_f32 v26, -v26, v59, v54                              // 00000019B520: D613001A 24DA771A
	.long 0xd71c0024                                           // 00000019B528: D71C0024
	v_cndmask_b32_e32 v1, v44, v37, vcc_lo                     // 00000019B52C: 02024B2C
	v_div_fixup_f32 v29, v30, v35, v29                         // 00000019B530: D627001D 0476471E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019B538: BF870224
	v_dual_add_f32 v33, 1.0, v33 :: v_dual_lshlrev_b32 v44, 16, v123// 00000019B53C: C92242F2 212CF690
	.long 0x7f463980                                           // 00000019B544: 7F463980
	v_cndmask_b32_e32 v36, 0, v36, vcc_lo                      // 00000019B548: 02484880
	s_mov_b32 vcc_lo, s0                                       // 00000019B54C: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019B550: BF870003
	v_mul_f32_e32 v45, 0xbfb8aa3b, v44                         // 00000019B554: 105A58FF BFB8AA3B
	v_div_fmas_f32 v26, v26, v42, v59                          // 00000019B55C: D637001A 04EE551A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 00000019B564: 7C365CFF C2B17218
	v_div_scale_f32 v37, null, v33, v33, v17                   // 00000019B56C: D6FC7C25 04464321
	.long 0x7e46399d                                           // 00000019B574: 7E46399D
	v_fma_f32 v53, 0xbfb8aa3b, v44, -v45                       // 00000019B578: D6130035 84B658FF BFB8AA3B
	v_div_fixup_f32 v26, v26, v34, v28                         // 00000019B584: D627001A 0472451A
	v_cndmask_b32_e32 v36, 0x7f800000, v36, vcc_lo             // 00000019B58C: 024848FF 7F800000
	v_lshlrev_b32_e32 v34, 16, v124                            // 00000019B594: 3044F890
	v_rcp_f32_e32 v27, v37                                     // 00000019B598: 7E365525
	v_rndne_f32_e32 v54, v45                                   // 00000019B59C: 7E6C472D
	.long 0x7e00399a                                           // 00000019B5A0: 7E00399A
	v_add_f32_e32 v28, 1.0, v36                                // 00000019B5A4: 063848F2
	v_mul_f32_e32 v30, 0xbfb8aa3b, v34                         // 00000019B5A8: 103C44FF BFB8AA3B
	v_fmac_f32_e32 v53, 0xb2a5705f, v44                        // 00000019B5B0: 566A58FF B2A5705F
	v_sub_f32_e32 v45, v45, v54                                // 00000019B5B8: 085A6D2D
	v_and_b32_e32 v43, 1, v0                                   // 00000019B5BC: 36560081
	v_div_scale_f32 v25, null, v28, v28, v18                   // 00000019B5C0: D6FC7C19 044A391C
	v_fma_f32 v41, 0xbfb8aa3b, v34, -v30                       // 00000019B5C8: D6130029 847A44FF BFB8AA3B
	v_rndne_f32_e32 v42, v30                                   // 00000019B5D4: 7E54471E
	v_fma_f32 v36, -v37, v27, 1.0                              // 00000019B5D8: D6130024 23CA3725
	v_and_b32_e32 v35, 1, v35                                  // 00000019B5E0: 36464681
	v_rcp_f32_e32 v38, v25                                     // 00000019B5E4: 7E4C5519
	v_fmac_f32_e32 v41, 0xb2a5705f, v34                        // 00000019B5E8: 565244FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000019B5F0: BF870243
	v_dual_sub_f32 v30, v30, v42 :: v_dual_fmac_f32 v27, v36, v27// 00000019B5F4: C940551E 1E1A3724
	v_div_scale_f32 v36, vcc_lo, v17, v33, v17                 // 00000019B5FC: D6FC6A24 04464311
	v_add3_u32 v26, v26, v43, 0x7fff                           // 00000019B604: D655001A 03FE571A 00007FFF
	v_cvt_i32_f32_e32 v42, v42                                 // 00000019B610: 7E54112A
	v_add_f32_e32 v30, v30, v41                                // 00000019B614: 063C531E
	v_add_f32_e32 v45, v45, v53                                // 00000019B618: 065A6B2D
	v_mul_f32_e32 v41, v36, v27                                // 00000019B61C: 10523724
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019B620: BF870005
	v_fma_f32 v46, -v25, v38, 1.0                              // 00000019B624: D613002E 23CA4D19
	v_add3_u32 v29, v29, v35, 0x7fff                           // 00000019B62C: D655001D 03FE471D 00007FFF
	v_exp_f32_e32 v30, v30                                     // 00000019B638: 7E3C4B1E
	.long 0xd41e0001                                           // 00000019B63C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v34, vcc_lo              // 00000019B640: 020244FF 42CE8ED0
	v_fma_f32 v43, -v37, v41, v36                              // 00000019B648: D613002B 24925325
	v_fmac_f32_e32 v38, v46, v38                               // 00000019B650: 564C4D2E
	v_div_scale_f32 v46, s0, v18, v28, v18                     // 00000019B654: D6FC002E 044A3912
	s_clause 0x1                                               // 00000019B65C: BF850001
	global_store_d16_hi_b16 v[31:32], v29, off offset:128      // 00000019B660: DC960080 007C1D1F
	global_store_d16_hi_b16 v[39:40], v26, off offset:128      // 00000019B668: DC960080 007C1A27
	v_dual_fmac_f32 v41, v43, v27 :: v_dual_lshlrev_b32 v26, 16, v126// 00000019B670: C822372B 291AFC90
	v_mul_f32_e32 v57, v46, v38                                // 00000019B678: 10724D2E
	.long 0xd71c001e                                           // 00000019B67C: D71C001E
	v_cndmask_b32_e32 v1, v30, v42, vcc_lo                     // 00000019B680: 0202551E
	v_exp_f32_e32 v42, v45                                     // 00000019B684: 7E544B2D
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019B688: BF870003
	v_fma_f32 v36, -v37, v41, v36                              // 00000019B68C: D6130024 24925325
	.long 0x7f3a3980                                           // 00000019B694: 7F3A3980
	v_fma_f32 v35, -v25, v57, v46                              // 00000019B698: D6130023 24BA7319
	v_cndmask_b32_e64 v30, 0, v30, s1                          // 00000019B6A0: D501001E 00063C80
	.long 0xd41b0001                                           // 00000019B6A8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v34, vcc_lo              // 00000019B6AC: 020244FF C2B17218
	v_div_fmas_f32 v27, v36, v27, v41                          // 00000019B6B4: D637001B 04A63724
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v44                  // 00000019B6BC: 7C3C58FF 42CE8ED0
	v_fmac_f32_e32 v57, v35, v38                               // 00000019B6C4: 56724D23
	v_cvt_i32_f32_e32 v35, v54                                 // 00000019B6C8: 7E461136
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 00000019B6CC: D501001E 00063CFF 7F800000
	v_div_fixup_f32 v17, v27, v33, v17                         // 00000019B6D8: D6270011 0446431B
	v_mul_f32_e32 v33, 0xbfb8aa3b, v26                         // 00000019B6E0: 104234FF BFB8AA3B
	v_fma_f32 v25, -v25, v57, v46                              // 00000019B6E8: D6130019 24BA7319
	.long 0xd71c0022                                           // 00000019B6F0: D71C0022
	v_cndmask_b32_e32 v1, v42, v35, vcc_lo                     // 00000019B6F4: 0202472A
	v_add_f32_e32 v30, 1.0, v30                                // 00000019B6F8: 063C3CF2
	.long 0xd41e0001                                           // 00000019B6FC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v26, vcc_lo              // 00000019B700: 020234FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v26, -v33                       // 00000019B708: D6130029 848634FF BFB8AA3B
	v_rndne_f32_e32 v42, v33                                   // 00000019B714: 7E544721
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000019B718: 02444480
	s_mov_b32 vcc_lo, s0                                       // 00000019B71C: BEEA0000
	v_div_scale_f32 v35, null, v30, v30, v19                   // 00000019B720: D6FC7C23 044E3D1E
	v_div_fmas_f32 v25, v25, v38, v57                          // 00000019B728: D6370019 04E64D19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v44                  // 00000019B730: 7C3658FF C2B17218
	v_dual_fmac_f32 v41, 0xb2a5705f, v26 :: v_dual_lshlrev_b32 v38, 16, v125// 00000019B738: C82234FF 2926FA90 B2A5705F
	v_sub_f32_e32 v33, v33, v42                                // 00000019B744: 08425521
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019B748: BF870004
	v_div_fixup_f32 v18, v25, v28, v18                         // 00000019B74C: D6270012 044A3919
	v_cndmask_b32_e32 v34, 0x7f800000, v34, vcc_lo             // 00000019B754: 024444FF 7F800000
	v_rcp_f32_e32 v25, v35                                     // 00000019B75C: 7E325523
	v_mul_f32_e32 v43, 0xbfb8aa3b, v38                         // 00000019B760: 10564CFF BFB8AA3B
	v_add_f32_e32 v33, v33, v41                                // 00000019B768: 06425321
	.long 0x7e003992                                           // 00000019B76C: 7E003992
	v_add_f32_e32 v28, 1.0, v34                                // 00000019B770: 063844F2
	v_cvt_i32_f32_e32 v42, v42                                 // 00000019B774: 7E54112A
	v_fma_f32 v46, 0xbfb8aa3b, v38, -v43                       // 00000019B778: D613002E 84AE4CFF BFB8AA3B
	v_rndne_f32_e32 v53, v43                                   // 00000019B784: 7E6A472B
	v_exp_f32_e32 v33, v33                                     // 00000019B788: 7E424B21
	v_div_scale_f32 v27, null, v28, v28, v20                   // 00000019B78C: D6FC7C1B 0452391C
	v_fma_f32 v34, -v35, v25, 1.0                              // 00000019B794: D6130022 23CA3323
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019B79C: BF870223
	v_dual_fmac_f32 v46, 0xb2a5705f, v38 :: v_dual_sub_f32 v43, v43, v53// 00000019B7A0: C80A4CFF 2E2A6B2B B2A5705F
	v_div_scale_f32 v41, s0, v20, v28, v20                     // 00000019B7AC: D6FC0029 04523914
	v_rcp_f32_e32 v36, v27                                     // 00000019B7B4: 7E48551B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019B7B8: BF870003
	v_fmac_f32_e32 v25, v34, v25                               // 00000019B7BC: 56323322
	v_div_scale_f32 v34, vcc_lo, v19, v30, v19                 // 00000019B7C0: D6FC6A22 044E3D13
	v_and_b32_e32 v37, 1, v0                                   // 00000019B7C8: 364A0081
	v_add_f32_e32 v43, v43, v46                                // 00000019B7CC: 06565D2B
	.long 0xd71c0021                                           // 00000019B7D0: D71C0021
	v_cndmask_b32_e32 v1, v33, v42, vcc_lo                     // 00000019B7D4: 02025521
	.long 0x7e3a3991                                           // 00000019B7D8: 7E3A3991
	v_mul_f32_e32 v45, v34, v25                                // 00000019B7DC: 105A3322
	v_add3_u32 v18, v18, v37, 0x7fff                           // 00000019B7E0: D6550012 03FE4B12 00007FFF
	v_exp_f32_e32 v37, v43                                     // 00000019B7EC: 7E4A4B2B
	v_fma_f32 v44, -v27, v36, 1.0                              // 00000019B7F0: D613002C 23CA491B
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 00000019B7F8: D5010021 00064280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019B800: BF870122
	v_dual_fmac_f32 v36, v44, v36 :: v_dual_and_b32 v29, 1, v29// 00000019B804: C824492C 241C3A81
	v_fma_f32 v44, -v35, v45, v34                              // 00000019B80C: D613002C 248A5B23
	v_add3_u32 v17, v17, v29, 0x7fff                           // 00000019B814: D6550011 03FE3B11 00007FFF
	v_lshlrev_b32_e32 v29, 16, v92                             // 00000019B820: 303AB890
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019B824: BF870003
	v_dual_mul_f32 v54, v41, v36 :: v_dual_fmac_f32 v45, v44, v25// 00000019B828: C8C04929 362C332C
	s_clause 0x1                                               // 00000019B830: BF850001
	global_store_d16_hi_b16 v[7:8], v17, off offset:160        // 00000019B834: DC9600A0 007C1107
	global_store_d16_hi_b16 v[47:48], v18, off offset:160      // 00000019B83C: DC9600A0 007C122F
	v_fma_f32 v44, -v27, v54, v41                              // 00000019B844: D613002C 24A66D1B
	v_fma_f32 v34, -v35, v45, v34                              // 00000019B84C: D6130022 248A5B23
	v_cvt_i32_f32_e32 v35, v53                                 // 00000019B854: 7E461135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019B858: BF870193
	v_fmac_f32_e32 v54, v44, v36                               // 00000019B85C: 566C492C
	v_div_fmas_f32 v25, v34, v25, v45                          // 00000019B860: D6370019 04B63322
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v26                  // 00000019B868: 7C3634FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019B870: BF870004
	.long 0xd71c0022                                           // 00000019B874: D71C0022
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 00000019B878: 02024725
	v_mul_f32_e32 v35, 0xbfb8aa3b, v29                         // 00000019B87C: 10463AFF BFB8AA3B
	v_fma_f32 v27, -v27, v54, v41                              // 00000019B884: D613001B 24A66D1B
	v_div_fixup_f32 v17, v25, v30, v19                         // 00000019B88C: D6270011 044E3D19
	v_cndmask_b32_e32 v26, 0x7f800000, v33, vcc_lo             // 00000019B894: 023442FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 00000019B89C: 7C3C4CFF 42CE8ED0
	.long 0x7f3c3980                                           // 00000019B8A4: 7F3C3980
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019B8A8: BF870214
	.long 0x7e3c3991                                           // 00000019B8AC: 7E3C3991
	v_add_f32_e32 v26, 1.0, v26                                // 00000019B8B0: 063434F2
	v_cndmask_b32_e32 v33, 0, v34, vcc_lo                      // 00000019B8B4: 02424480
	s_mov_b32 vcc_lo, s0                                       // 00000019B8B8: BEEA0000
	v_div_fmas_f32 v27, v27, v36, v54                          // 00000019B8BC: D637001B 04DA491B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 00000019B8C4: 7C364CFF C2B17218
	v_rndne_f32_e32 v36, v35                                   // 00000019B8CC: 7E484723
	s_waitcnt vmcnt(2)                                         // 00000019B8D0: BF890BF7
	v_lshlrev_b32_e32 v38, 16, v68                             // 00000019B8D4: 304C8890
	v_and_b32_e32 v30, 1, v30                                  // 00000019B8D8: 363C3C81
	v_div_fixup_f32 v20, v27, v28, v20                         // 00000019B8DC: D6270014 0452391B
	v_cndmask_b32_e32 v33, 0x7f800000, v33, vcc_lo             // 00000019B8E4: 024242FF 7F800000
	v_div_scale_f32 v27, null, v26, v26, v21                   // 00000019B8EC: D6FC7C1B 0456351A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019B8F4: BF870214
	v_add3_u32 v17, v17, v30, 0x7fff                           // 00000019B8F8: D6550011 03FE3D11 00007FFF
	.long 0x7e003994                                           // 00000019B904: 7E003994
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019B908: BF870214
	v_add_f32_e32 v28, 1.0, v33                                // 00000019B90C: 063842F2
	v_rcp_f32_e32 v19, v27                                     // 00000019B910: 7E26551B
	global_store_d16_hi_b16 v[15:16], v17, off offset:160      // 00000019B914: DC9600A0 007C110F
	v_and_b32_e32 v33, 1, v0                                   // 00000019B91C: 36420081
	v_div_scale_f32 v25, null, v28, v28, v22                   // 00000019B920: D6FC7C19 045A391C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019B928: BF870112
	v_add3_u32 v20, v20, v33, 0x7fff                           // 00000019B92C: D6550014 03FE4314 00007FFF
	v_rcp_f32_e32 v34, v25                                     // 00000019B938: 7E445519
	v_fma_f32 v18, -v27, v19, 1.0                              // 00000019B93C: D6130012 23CA271B
	v_fma_f32 v33, 0xbfb8aa3b, v29, -v35                       // 00000019B944: D6130021 848E3AFF BFB8AA3B
	v_sub_f32_e32 v35, v35, v36                                // 00000019B950: 08464923
	v_cvt_i32_f32_e32 v36, v36                                 // 00000019B954: 7E481124
	global_store_d16_hi_b16 v[23:24], v20, off offset:160      // 00000019B958: DC9600A0 007C1417
	v_fmac_f32_e32 v19, v18, v19                               // 00000019B960: 56262712
	v_div_scale_f32 v18, vcc_lo, v21, v26, v21                 // 00000019B964: D6FC6A12 04563515
	v_fmac_f32_e32 v33, 0xb2a5705f, v29                        // 00000019B96C: 56423AFF B2A5705F
	v_fma_f32 v37, -v25, v34, 1.0                              // 00000019B974: D6130025 23CA4519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019B97C: BF870193
	v_mul_f32_e32 v41, v18, v19                                // 00000019B980: 10522712
	v_add_f32_e32 v33, v35, v33                                // 00000019B984: 06424323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v38                         // 00000019B988: 10464CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019B990: BF870004
	v_fmac_f32_e32 v34, v37, v34                               // 00000019B994: 56444525
	v_div_scale_f32 v37, s0, v22, v28, v22                     // 00000019B998: D6FC0025 045A3916
	v_fma_f32 v30, -v27, v41, v18                              // 00000019B9A0: D613001E 244A531B
	v_exp_f32_e32 v33, v33                                     // 00000019B9A8: 7E424B21
	v_fma_f32 v43, 0xbfb8aa3b, v38, -v35                       // 00000019B9AC: D613002B 848E4CFF BFB8AA3B
	v_rndne_f32_e32 v44, v35                                   // 00000019B9B8: 7E584723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019B9BC: BF870193
	v_dual_mul_f32 v42, v37, v34 :: v_dual_fmac_f32 v41, v30, v19// 00000019B9C0: C8C04525 2A28271E
	v_fmac_f32_e32 v43, 0xb2a5705f, v38                        // 00000019B9C8: 56564CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019B9D0: BF870193
	v_sub_f32_e32 v35, v35, v44                                // 00000019B9D4: 08465923
	v_fma_f32 v30, -v25, v42, v37                              // 00000019B9D8: D613001E 24965519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019B9E0: BF870294
	v_fma_f32 v17, -v27, v41, v18                              // 00000019B9E4: D6130011 244A531B
	.long 0xd71c0012                                           // 00000019B9EC: D71C0012
	v_cndmask_b32_e32 v1, v33, v36, vcc_lo                     // 00000019B9F0: 02024921
	v_cvt_i32_f32_e32 v20, v44                                 // 00000019B9F4: 7E28112C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019B9F8: BF870214
	v_dual_add_f32 v27, v35, v43 :: v_dual_fmac_f32 v42, v30, v34// 00000019B9FC: C9005723 1B2A451E
	v_div_fmas_f32 v17, v17, v19, v41                          // 00000019BA04: D6370011 04A62711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 00000019BA0C: 7C3C3AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019BA14: BF870213
	v_fma_f32 v19, -v25, v42, v37                              // 00000019BA18: D6130013 24965519
	v_exp_f32_e32 v25, v27                                     // 00000019BA20: 7E324B1B
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000019BA24: 02242480
	s_mov_b32 vcc_lo, s0                                       // 00000019BA28: BEEA0000
	v_div_fixup_f32 v17, v17, v26, v21                         // 00000019BA2C: D6270011 04563511
	v_div_fmas_f32 v19, v19, v34, v42                          // 00000019BA34: D6370013 04AA4513
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 00000019BA3C: 7C363AFF C2B17218
	.long 0x7f2a3980                                           // 00000019BA44: 7F2A3980
	v_lshlrev_b32_e32 v34, 16, v70                             // 00000019BA48: 30448C90
	.long 0x7e2a3991                                           // 00000019BA4C: 7E2A3991
	v_div_fixup_f32 v19, v19, v28, v22                         // 00000019BA50: D6270013 045A3913
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 00000019BA58: 022424FF 7F800000
	.long 0xd71c0014                                           // 00000019BA60: D71C0014
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 00000019BA64: 02022919
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 00000019BA68: 7C3C4CFF 42CE8ED0
	v_lshlrev_b32_e32 v25, 16, v104                            // 00000019BA70: 3032D090
	.long 0x7e003993                                           // 00000019BA74: 7E003993
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_and_b32 v21, 1, v21 // 00000019BA78: C92424F2 12142A81
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 00000019BA80: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 00000019BA84: 7C364CFF C2B17218
	v_mul_f32_e32 v27, 0xbfb8aa3b, v25                         // 00000019BA8C: 103632FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000019BA94: BF870234
	v_div_scale_f32 v22, null, v18, v18, v9                    // 00000019BA98: D6FC7C16 04262512
	v_dual_mul_f32 v37, 0xbfb8aa3b, v34 :: v_dual_and_b32 v28, 1, v0// 00000019BAA0: C8E444FF 251C0081 BFB8AA3B
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 00000019BAAC: 022828FF 7F800000
	v_fma_f32 v29, 0xbfb8aa3b, v25, -v27                       // 00000019BAB4: D613001D 846E32FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000019BAC0: BF8701B4
	v_rcp_f32_e32 v26, v22                                     // 00000019BAC4: 7E345516
	v_rndne_f32_e32 v30, v27                                   // 00000019BAC8: 7E3C471B
	v_add3_u32 v17, v17, v21, 0x7fff                           // 00000019BACC: D6550011 03FE2B11 00007FFF
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_fmac_f32 v29, 0xb2a5705f, v25// 00000019BAD8: C90028F2 141C32FF B2A5705F
	v_add3_u32 v19, v19, v28, 0x7fff                           // 00000019BAE4: D6550013 03FE3913 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019BAF0: BF870224
	v_sub_f32_e32 v27, v27, v30                                // 00000019BAF4: 08363D1B
	v_rndne_f32_e32 v28, v37                                   // 00000019BAF8: 7E384725
	v_div_scale_f32 v33, null, v20, v20, v10                   // 00000019BAFC: D6FC7C21 042A2914
	v_cvt_i32_f32_e32 v30, v30                                 // 00000019BB04: 7E3C111E
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019BB08: BF870005
	v_fma_f32 v35, -v22, v26, 1.0                              // 00000019BB0C: D6130023 23CA3516
	v_add_f32_e32 v21, v27, v29                                // 00000019BB14: 062A3B1B
	v_fma_f32 v27, 0xbfb8aa3b, v34, -v37                       // 00000019BB18: D613001B 849644FF BFB8AA3B
	v_rcp_f32_e32 v36, v33                                     // 00000019BB24: 7E485521
	v_div_scale_f32 v29, vcc_lo, v9, v18, v9                   // 00000019BB28: D6FC6A1D 04262509
	v_fmac_f32_e32 v26, v35, v26                               // 00000019BB30: 56343523
	v_exp_f32_e32 v21, v21                                     // 00000019BB34: 7E2A4B15
	v_fmac_f32_e32 v27, 0xb2a5705f, v34                        // 00000019BB38: 563644FF B2A5705F
	v_sub_f32_e32 v37, v37, v28                                // 00000019BB40: 084A3925
	global_store_d16_hi_b16 v[31:32], v17, off offset:160      // 00000019BB44: DC9600A0 007C111F
	v_mul_f32_e32 v38, v29, v26                                // 00000019BB4C: 104C351D
	.long 0xd41e0001                                           // 00000019BB50: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 00000019BB54: 020232FF 42CE8ED0
	v_cvt_i32_f32_e32 v28, v28                                 // 00000019BB5C: 7E38111C
	v_fma_f32 v35, -v33, v36, 1.0                              // 00000019BB60: D6130023 23CA4921
	v_add_f32_e32 v27, v37, v27                                // 00000019BB68: 06363725
	global_store_d16_hi_b16 v[39:40], v19, off offset:160      // 00000019BB6C: DC9600A0 007C1327
	.long 0xd71c0011                                           // 00000019BB74: D71C0011
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                     // 00000019BB78: 02023D15
	v_fma_f32 v21, -v22, v38, v29                              // 00000019BB7C: D6130015 24764D16
	v_fmac_f32_e32 v36, v35, v36                               // 00000019BB84: 56484923
	v_div_scale_f32 v35, s0, v10, v20, v10                     // 00000019BB88: D6FC0023 042A290A
	v_exp_f32_e32 v27, v27                                     // 00000019BB90: 7E364B1B
	v_cndmask_b32_e64 v17, 0, v17, s1                          // 00000019BB94: D5010011 00062280
	v_fmac_f32_e32 v38, v21, v26                               // 00000019BB9C: 564C3515
	.long 0xd41b0001                                           // 00000019BBA0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v25, vcc_lo              // 00000019BBA4: 020232FF C2B17218
	v_dual_mul_f32 v30, v35, v36 :: v_dual_lshlrev_b32 v19, 16, v106// 00000019BBAC: C8E24923 1E12D490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019BBB4: BF870193
	v_fma_f32 v22, -v22, v38, v29                              // 00000019BBB8: D6130016 24764D16
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 00000019BBC0: D5010011 000622FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019BBCC: BF870213
	v_fma_f32 v21, -v33, v30, v35                              // 00000019BBD0: D6130015 248E3D21
	.long 0xd41e0001                                           // 00000019BBD8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v19, vcc_lo              // 00000019BBDC: 020226FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019BBE4: BF870224
	v_div_fmas_f32 v22, v22, v26, v38                          // 00000019BBE8: D6370016 049A3516
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 00000019BBF0: 7C3C44FF 42CE8ED0
	v_fmac_f32_e32 v30, v21, v36                               // 00000019BBF8: 563C4915
	.long 0xd71c0015                                           // 00000019BBFC: D71C0015
	v_cndmask_b32_e32 v1, v27, v28, vcc_lo                     // 00000019BC00: 0202391B
	v_add_f32_e32 v17, 1.0, v17                                // 00000019BC04: 062222F2
	v_div_fixup_f32 v9, v22, v18, v9                           // 00000019BC08: D6270009 04262516
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019BC10: BF870214
	v_fma_f32 v25, -v33, v30, v35                              // 00000019BC14: D6130019 248E3D21
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 00000019BC1C: 022A2A80
	s_mov_b32 vcc_lo, s0                                       // 00000019BC20: BEEA0000
	v_div_scale_f32 v26, null, v17, v17, v11                   // 00000019BC24: D6FC7C1A 042E2311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000019BC2C: BF870233
	v_div_fmas_f32 v25, v25, v36, v30                          // 00000019BC30: D6370019 047A4919
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 00000019BC38: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v34, 16, v105                            // 00000019BC40: 3044D290
	v_rcp_f32_e32 v27, v26                                     // 00000019BC44: 7E36551A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019BC48: BF870003
	v_div_fixup_f32 v10, v25, v20, v10                         // 00000019BC4C: D627000A 042A2919
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 00000019BC54: 022A2AFF 7F800000
	v_mul_f32_e32 v25, 0xbfb8aa3b, v19                         // 00000019BC5C: 103226FF BFB8AA3B
	v_div_scale_f32 v33, vcc_lo, v11, v17, v11                 // 00000019BC64: D6FC6A21 042E230B
	v_mul_f32_e32 v36, 0xbfb8aa3b, v34                         // 00000019BC6C: 104844FF BFB8AA3B
	.long 0x7e00398a                                           // 00000019BC74: 7E00398A
	v_add_f32_e32 v18, 1.0, v21                                // 00000019BC78: 06242AF2
	v_fma_f32 v29, 0xbfb8aa3b, v19, -v25                       // 00000019BC7C: D613001D 846626FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019BC88: BF870005
	v_fma_f32 v21, -v26, v27, 1.0                              // 00000019BC8C: D6130015 23CA371A
	v_rndne_f32_e32 v30, v25                                   // 00000019BC94: 7E3C4719
	v_and_b32_e32 v28, 1, v0                                   // 00000019BC98: 36380081
	v_div_scale_f32 v22, null, v18, v18, v12                   // 00000019BC9C: D6FC7C16 04322512
	v_fmac_f32_e32 v29, 0xb2a5705f, v19                        // 00000019BCA4: 563A26FF B2A5705F
	v_fmac_f32_e32 v27, v21, v27                               // 00000019BCAC: 56363715
	v_sub_f32_e32 v25, v25, v30                                // 00000019BCB0: 08323D19
	.long 0x7e283989                                           // 00000019BCB4: 7E283989
	v_rcp_f32_e32 v21, v22                                     // 00000019BCB8: 7E2A5516
	.long 0x7f283980                                           // 00000019BCBC: 7F283980
	v_mul_f32_e32 v35, v33, v27                                // 00000019BCC0: 10463721
	v_add_f32_e32 v25, v25, v29                                // 00000019BCC4: 06323B19
	v_fma_f32 v37, 0xbfb8aa3b, v34, -v36                       // 00000019BCC8: D6130025 849244FF BFB8AA3B
	v_rndne_f32_e32 v38, v36                                   // 00000019BCD4: 7E4C4724
	v_add3_u32 v10, v10, v28, 0x7fff                           // 00000019BCD8: D655000A 03FE390A 00007FFF
	v_and_b32_e32 v20, 1, v20                                  // 00000019BCE4: 36282881
	v_fma_f32 v29, -v26, v35, v33                              // 00000019BCE8: D613001D 2486471A
	v_exp_f32_e32 v25, v25                                     // 00000019BCF0: 7E324B19
	v_fma_f32 v28, -v22, v21, 1.0                              // 00000019BCF4: D613001C 23CA2B16
	v_fmac_f32_e32 v37, 0xb2a5705f, v34                        // 00000019BCFC: 564A44FF B2A5705F
	v_sub_f32_e32 v36, v36, v38                                // 00000019BD04: 08484D24
	v_add3_u32 v9, v9, v20, 0x7fff                             // 00000019BD08: D6550009 03FE2909 00007FFF
	v_cvt_i32_f32_e32 v20, v30                                 // 00000019BD14: 7E28111E
	v_fmac_f32_e32 v21, v28, v21                               // 00000019BD18: 562A2B1C
	v_div_scale_f32 v28, s0, v12, v18, v12                     // 00000019BD1C: D6FC001C 0432250C
	v_dual_fmac_f32 v35, v29, v27 :: v_dual_add_f32 v30, v36, v37// 00000019BD24: C808371D 231E4B24
	global_store_d16_hi_b16 v[7:8], v9, off offset:192         // 00000019BD2C: DC9600C0 007C0907
	.long 0xd71c0009                                           // 00000019BD34: D71C0009
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 00000019BD38: 02022919
	v_mul_f32_e32 v29, v28, v21                                // 00000019BD3C: 103A2B1C
	v_fma_f32 v20, -v26, v35, v33                              // 00000019BD40: D6130014 2486471A
	v_exp_f32_e32 v26, v30                                     // 00000019BD48: 7E344B1E
	global_store_d16_hi_b16 v[47:48], v10, off offset:192      // 00000019BD4C: DC9600C0 007C0A2F
	v_cndmask_b32_e64 v9, 0, v9, s1                            // 00000019BD54: D5010009 00061280
	v_fma_f32 v25, -v22, v29, v28                              // 00000019BD5C: D6130019 24723B16
	v_div_fmas_f32 v20, v20, v27, v35                          // 00000019BD64: D6370014 048E3714
	v_cvt_i32_f32_e32 v27, v38                                 // 00000019BD6C: 7E361126
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v19                  // 00000019BD70: 7C3626FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019BD78: BF870214
	v_fmac_f32_e32 v29, v25, v21                               // 00000019BD7C: 563A2B19
	v_div_fixup_f32 v11, v20, v17, v11                         // 00000019BD80: D627000B 042E2314
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019BD88: BF870004
	.long 0xd71c0011                                           // 00000019BD8C: D71C0011
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000019BD90: 0202371A
	v_cndmask_b32_e32 v9, 0x7f800000, v9, vcc_lo               // 00000019BD94: 021212FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 00000019BD9C: 7C3C44FF 42CE8ED0
	v_fma_f32 v19, -v22, v29, v28                              // 00000019BDA4: D6130013 24723B16
	s_waitcnt vmcnt(1)                                         // 00000019BDAC: BF8907F7
	v_lshlrev_b32_e32 v25, 16, v67                             // 00000019BDB0: 30328690
	.long 0x7e2c398b                                           // 00000019BDB4: 7E2C398B
	v_add_f32_e32 v9, 1.0, v9                                  // 00000019BDB8: 061212F2
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000019BDBC: 02222280
	s_mov_b32 vcc_lo, s0                                       // 00000019BDC0: BEEA0000
	v_mul_f32_e32 v30, 0xbfb8aa3b, v25                         // 00000019BDC4: 103C32FF BFB8AA3B
	v_div_fmas_f32 v19, v19, v21, v29                          // 00000019BDCC: D6370013 04762B13
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 00000019BDD4: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v21, 16, v69                             // 00000019BDDC: 302A8A90
	v_div_scale_f32 v20, null, v9, v9, v13                     // 00000019BDE0: D6FC7C14 04361309
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v30                       // 00000019BDE8: D6130022 847A32FF BFB8AA3B
	v_div_fixup_f32 v12, v19, v18, v12                         // 00000019BDF4: D627000C 04322513
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 00000019BDFC: 022222FF 7F800000
	v_mul_f32_e32 v19, 0xbfb8aa3b, v21                         // 00000019BE04: 10262AFF BFB8AA3B
	v_rcp_f32_e32 v18, v20                                     // 00000019BE0C: 7E245514
	v_rndne_f32_e32 v35, v30                                   // 00000019BE10: 7E46471E
	v_fmac_f32_e32 v34, 0xb2a5705f, v25                        // 00000019BE14: 564432FF B2A5705F
	v_add_f32_e32 v17, 1.0, v17                                // 00000019BE1C: 062222F2
	v_fma_f32 v27, 0xbfb8aa3b, v21, -v19                       // 00000019BE20: D613001B 844E2AFF BFB8AA3B
	v_rndne_f32_e32 v28, v19                                   // 00000019BE2C: 7E384713
	.long 0xd41e0001                                           // 00000019BE30: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v21, vcc_lo              // 00000019BE34: 02022AFF 42CE8ED0
	.long 0x7e00398c                                           // 00000019BE3C: 7E00398C
	v_div_scale_f32 v26, null, v17, v17, v14                   // 00000019BE40: D6FC7C1A 043A2311
	v_fmac_f32_e32 v27, 0xb2a5705f, v21                        // 00000019BE48: 56362AFF B2A5705F
	v_sub_f32_e32 v19, v19, v28                                // 00000019BE50: 08263913
	v_fma_f32 v29, -v20, v18, 1.0                              // 00000019BE54: D613001D 23CA2514
	v_cvt_i32_f32_e32 v28, v28                                 // 00000019BE5C: 7E38111C
	v_rcp_f32_e32 v33, v26                                     // 00000019BE60: 7E42551A
	.long 0x7f2c3980                                           // 00000019BE64: 7F2C3980
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000019BE68: BF8701B3
	v_dual_add_f32 v19, v19, v27 :: v_dual_fmac_f32 v18, v29, v18// 00000019BE6C: C9003713 1312251D
	v_div_scale_f32 v27, vcc_lo, v13, v9, v13                  // 00000019BE74: D6FC6A1B 0436130D
	v_dual_sub_f32 v29, v30, v35 :: v_dual_and_b32 v36, 1, v0  // 00000019BE7C: C964471E 1D240081
	v_exp_f32_e32 v19, v19                                     // 00000019BE84: 7E264B13
	v_and_b32_e32 v22, 1, v22                                  // 00000019BE88: 362C2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000019BE8C: BF870313
	v_mul_f32_e32 v37, v27, v18                                // 00000019BE90: 104A251B
	v_fma_f32 v30, -v26, v33, 1.0                              // 00000019BE94: D613001E 23CA431A
	v_add_f32_e32 v29, v29, v34                                // 00000019BE9C: 063A451D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019BEA0: BF870214
	v_add3_u32 v10, v11, v22, 0x7fff                           // 00000019BEA4: D655000A 03FE2D0B 00007FFF
	v_fma_f32 v34, -v20, v37, v27                              // 00000019BEB0: D6130022 246E4B14
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019BEB8: BF870004
	v_fmac_f32_e32 v33, v30, v33                               // 00000019BEBC: 5642431E
	v_div_scale_f32 v30, s0, v14, v17, v14                     // 00000019BEC0: D6FC001E 043A230E
	v_exp_f32_e32 v29, v29                                     // 00000019BEC8: 7E3A4B1D
	.long 0xd71c0013                                           // 00000019BECC: D71C0013
	v_cndmask_b32_e32 v1, v19, v28, vcc_lo                     // 00000019BED0: 02023913
	v_fmac_f32_e32 v37, v34, v18                               // 00000019BED4: 564A2522
	v_cvt_i32_f32_e32 v34, v35                                 // 00000019BED8: 7E441123
	v_mul_f32_e32 v28, v30, v33                                // 00000019BEDC: 1038431E
	v_add3_u32 v11, v12, v36, 0x7fff                           // 00000019BEE0: D655000B 03FE490C 00007FFF
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 00000019BEEC: D5010013 00062680
	.long 0xd41b0001                                           // 00000019BEF4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v21, vcc_lo              // 00000019BEF8: 02022AFF C2B17218
	v_fma_f32 v20, -v20, v37, v27                              // 00000019BF00: D6130014 246E4B14
	v_fma_f32 v35, -v26, v28, v30                              // 00000019BF08: D6130023 247A391A
	.long 0xd71c001b                                           // 00000019BF10: D71C001B
	v_cndmask_b32_e32 v1, v29, v34, vcc_lo                     // 00000019BF14: 0202451D
	global_store_d16_hi_b16 v[15:16], v10, off offset:192      // 00000019BF18: DC9600C0 007C0A0F
	v_cndmask_b32_e64 v19, 0x7f800000, v19, s1                 // 00000019BF20: D5010013 000626FF 7F800000
	.long 0xd41e0001                                           // 00000019BF2C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 00000019BF30: 020232FF 42CE8ED0
	v_fmac_f32_e32 v28, v35, v33                               // 00000019BF38: 56384323
	v_div_fmas_f32 v18, v20, v18, v37                          // 00000019BF3C: D6370012 04962514
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000019BF44: 7C3632FF C2B17218
	v_add_f32_e32 v19, 1.0, v19                                // 00000019BF4C: 062626F2
	v_cndmask_b32_e64 v21, 0, v27, s1                          // 00000019BF50: D5010015 00063680
	v_fma_f32 v20, -v26, v28, v30                              // 00000019BF58: D6130014 247A391A
	v_div_fixup_f32 v9, v18, v9, v13                           // 00000019BF60: D6270009 04361312
	global_store_d16_hi_b16 v[23:24], v11, off offset:192      // 00000019BF68: DC9600C0 007C0B17
	v_div_scale_f32 v26, null, v19, v19, v1                    // 00000019BF70: D6FC7C1A 04062713
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 00000019BF78: 022A2AFF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 00000019BF80: BEEA0000
	v_lshlrev_b32_e32 v18, 16, v56                             // 00000019BF84: 30247090
	v_div_fmas_f32 v20, v20, v33, v28                          // 00000019BF88: D6370014 04724314
	v_rcp_f32_e32 v25, v26                                     // 00000019BF90: 7E32551A
	v_add_f32_e32 v21, 1.0, v21                                // 00000019BF94: 062A2AF2
	v_lshlrev_b32_e32 v29, 16, v55                             // 00000019BF98: 303A6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019BF9C: BF870223
	v_div_fixup_f32 v12, v20, v17, v14                         // 00000019BFA0: D627000C 043A2314
	.long 0x7e223989                                           // 00000019BFA8: 7E223989
	v_div_scale_f32 v14, null, v21, v21, v2                    // 00000019BFAC: D6FC7C0E 040A2B15
	.long 0x7f223980                                           // 00000019BFB4: 7F223980
	v_mul_f32_e32 v30, 0xbfb8aa3b, v29                         // 00000019BFB8: 103C3AFF BFB8AA3B
	.long 0x7e00398c                                           // 00000019BFC0: 7E00398C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000019BFC4: BF8701B5
	v_fma_f32 v10, -v26, v25, 1.0                              // 00000019BFC8: D613000A 23CA331A
	v_rcp_f32_e32 v13, v14                                     // 00000019BFD0: 7E1A550E
	v_and_b32_e32 v17, 1, v17                                  // 00000019BFD4: 36222281
	v_and_b32_e32 v11, 1, v0                                   // 00000019BFD8: 36160081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019BFDC: BF870223
	v_fmac_f32_e32 v25, v10, v25                               // 00000019BFE0: 5632330A
	v_div_scale_f32 v10, vcc_lo, v1, v19, v1                   // 00000019BFE4: D6FC6A0A 04062701
	v_add3_u32 v9, v9, v17, 0x7fff                             // 00000019BFEC: D6550009 03FE2309 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019BFF8: BF870224
	v_add3_u32 v11, v12, v11, 0x7fff                           // 00000019BFFC: D655000B 03FE170C 00007FFF
	v_mul_f32_e32 v12, 0xbfb8aa3b, v18                         // 00000019C008: 101824FF BFB8AA3B
	v_mul_f32_e32 v20, v10, v25                                // 00000019C010: 1028330A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019C014: BF870005
	v_fma_f32 v22, -v14, v13, 1.0                              // 00000019C018: D6130016 23CA1B0E
	s_clause 0x1                                               // 00000019C020: BF850001
	global_store_d16_hi_b16 v[31:32], v9, off offset:192       // 00000019C024: DC9600C0 007C091F
	global_store_d16_hi_b16 v[39:40], v11, off offset:192      // 00000019C02C: DC9600C0 007C0B27
	v_fma_f32 v27, 0xbfb8aa3b, v18, -v12                       // 00000019C034: D613001B 843224FF BFB8AA3B
	v_fma_f32 v17, -v26, v20, v10                              // 00000019C040: D6130011 242A291A
	v_fmac_f32_e32 v13, v22, v13                               // 00000019C048: 561A1B16
	v_div_scale_f32 v22, s0, v2, v21, v2                       // 00000019C04C: D6FC0016 040A2B02
	v_rndne_f32_e32 v28, v12                                   // 00000019C054: 7E38470C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019C058: BF870114
	v_dual_fmac_f32 v27, 0xb2a5705f, v18 :: v_dual_fmac_f32 v20, v17, v25// 00000019C05C: C80024FF 1B143311 B2A5705F
	v_dual_mul_f32 v17, v22, v13 :: v_dual_sub_f32 v12, v12, v28// 00000019C068: C8CA1B16 110C390C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019C070: BF8701A2
	v_fma_f32 v9, -v26, v20, v10                               // 00000019C074: D6130009 242A291A
	v_fma_f32 v26, 0xbfb8aa3b, v29, -v30                       // 00000019C07C: D613001A 847A3AFF BFB8AA3B
	v_fma_f32 v10, -v14, v17, v22                              // 00000019C088: D613000A 245A230E
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019C090: BF870004
	v_add_f32_e32 v12, v12, v27                                // 00000019C094: 0618370C
	v_rndne_f32_e32 v27, v30                                   // 00000019C098: 7E36471E
	v_div_fmas_f32 v9, v9, v25, v20                            // 00000019C09C: D6370009 04523309
	v_fmac_f32_e32 v26, 0xb2a5705f, v29                        // 00000019C0A4: 56343AFF B2A5705F
	v_fmac_f32_e32 v17, v10, v13                               // 00000019C0AC: 56221B0A
	v_exp_f32_e32 v10, v12                                     // 00000019C0B0: 7E144B0C
	v_sub_f32_e32 v12, v30, v27                                // 00000019C0B4: 0818371E
	v_lshlrev_b32_e32 v20, 16, v63                             // 00000019C0B8: 30287E90
	v_cvt_i32_f32_e32 v25, v28                                 // 00000019C0BC: 7E32111C
	v_fma_f32 v14, -v14, v17, v22                              // 00000019C0C0: D613000E 245A230E
	s_waitcnt vmcnt(0)                                         // 00000019C0C8: BF8903F7
	v_lshlrev_b32_e32 v22, 16, v64                             // 00000019C0CC: 302C8090
	v_add_f32_e32 v12, v12, v26                                // 00000019C0D0: 0618350C
	v_mul_f32_e32 v26, 0xbfb8aa3b, v20                         // 00000019C0D4: 103428FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v18                  // 00000019C0DC: 7C3C24FF 42CE8ED0
	v_cvt_i32_f32_e32 v27, v27                                 // 00000019C0E4: 7E36111B
	v_mul_f32_e32 v28, 0xbfb8aa3b, v22                         // 00000019C0E8: 10382CFF BFB8AA3B
	.long 0xd71c000a                                           // 00000019C0F0: D71C000A
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 00000019C0F4: 0202330A
	v_fma_f32 v25, 0xbfb8aa3b, v20, -v26                       // 00000019C0F8: D6130019 846A28FF BFB8AA3B
	v_rndne_f32_e32 v30, v26                                   // 00000019C104: 7E3C471A
	v_exp_f32_e32 v12, v12                                     // 00000019C108: 7E184B0C
	v_fma_f32 v33, 0xbfb8aa3b, v22, -v28                       // 00000019C10C: D6130021 84722CFF BFB8AA3B
	v_rndne_f32_e32 v34, v28                                   // 00000019C118: 7E44471C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019C11C: BF870223
	v_dual_fmac_f32 v25, 0xb2a5705f, v20 :: v_dual_sub_f32 v26, v26, v30// 00000019C120: C80A28FF 191A3D1A B2A5705F
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000019C12C: 02141480
	v_fmac_f32_e32 v33, 0xb2a5705f, v22                        // 00000019C130: 56422CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 00000019C138: BF8702B4
	v_sub_f32_e32 v28, v28, v34                                // 00000019C13C: 0838451C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v18                  // 00000019C140: 7C3624FF C2B17218
	v_add_f32_e32 v25, v26, v25                                // 00000019C148: 0632331A
	.long 0xd71c000c                                           // 00000019C14C: D71C000C
	v_cndmask_b32_e32 v1, v12, v27, vcc_lo                     // 00000019C150: 0202370C
	v_cvt_i32_f32_e32 v27, v34                                 // 00000019C154: 7E361122
	v_add_f32_e32 v26, v28, v33                                // 00000019C158: 0634431C
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo             // 00000019C15C: 021414FF 7F800000
	v_exp_f32_e32 v18, v25                                     // 00000019C164: 7E244B19
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 00000019C168: 7C3C3AFF 42CE8ED0
	v_div_fixup_f32 v1, v9, v19, v1                            // 00000019C170: D6270001 04062709
	v_exp_f32_e32 v25, v26                                     // 00000019C178: 7E324B1A
	v_cvt_i32_f32_e32 v26, v30                                 // 00000019C17C: 7E34111E
	v_add_f32_e32 v10, 1.0, v10                                // 00000019C180: 061414F2
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 00000019C184: 02181880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 00000019C188: 7C363AFF C2B17218
	.long 0x7e443981                                           // 00000019C190: 7E443981
	.long 0x7f443980                                           // 00000019C194: 7F443980
	.long 0xd71c0012                                           // 00000019C198: D71C0012
	v_cndmask_b32_e32 v1, v18, v26, vcc_lo                     // 00000019C19C: 02023512
	v_div_scale_f32 v26, null, v10, v10, v3                    // 00000019C1A0: D6FC7C1A 040E150A
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 00000019C1A8: 021818FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v20                  // 00000019C1B0: 7C3C28FF 42CE8ED0
	.long 0xd71c0019                                           // 00000019C1B8: D71C0019
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 00000019C1BC: 02023719
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019C1C0: BF870194
	v_rcp_f32_e32 v27, v26                                     // 00000019C1C4: 7E36551A
	v_add_f32_e32 v12, 1.0, v12                                // 00000019C1C8: 061818F2
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000019C1CC: 02242480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v22                  // 00000019C1D0: 7C3C2CFF 42CE8ED0
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000019C1D8: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v20                  // 00000019C1DC: 7C3628FF C2B17218
	v_div_scale_f32 v20, null, v12, v12, v4                    // 00000019C1E4: D6FC7C14 0412190C
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 00000019C1EC: 022424FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v22                  // 00000019C1F4: 7C362CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019C1FC: BF870113
	v_rcp_f32_e32 v28, v20                                     // 00000019C200: 7E385514
	v_add_f32_e32 v18, 1.0, v18                                // 00000019C204: 062424F2
	v_cndmask_b32_e32 v22, 0x7f800000, v25, vcc_lo             // 00000019C208: 022C32FF 7F800000
	v_fma_f32 v25, -v26, v27, 1.0                              // 00000019C210: D6130019 23CA371A
	s_mov_b32 vcc_lo, s0                                       // 00000019C218: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019C21C: BF870193
	v_div_scale_f32 v29, null, v18, v18, v5                    // 00000019C220: D6FC7C1D 04162512
	v_add_f32_e32 v22, 1.0, v22                                // 00000019C228: 062C2CF2
	v_div_fmas_f32 v13, v14, v13, v17                          // 00000019C22C: D637000D 04461B0E
	v_fmac_f32_e32 v27, v25, v27                               // 00000019C234: 56363719
	v_div_scale_f32 v17, vcc_lo, v3, v10, v3                   // 00000019C238: D6FC6A11 040E1503
	v_rcp_f32_e32 v14, v29                                     // 00000019C240: 7E1C551D
	v_div_scale_f32 v25, null, v22, v22, v6                    // 00000019C244: D6FC7C19 041A2D16
	v_fma_f32 v30, -v20, v28, 1.0                              // 00000019C24C: D613001E 23CA3914
	v_div_fixup_f32 v2, v13, v21, v2                           // 00000019C254: D6270002 040A2B0D
	v_mul_f32_e32 v11, v17, v27                                // 00000019C25C: 10163711
	v_div_scale_f32 v21, s0, v4, v12, v4                       // 00000019C260: D6FC0015 04121904
	v_rcp_f32_e32 v13, v25                                     // 00000019C268: 7E1A5519
	v_fmac_f32_e32 v28, v30, v28                               // 00000019C26C: 5638391E
	.long 0x7e003982                                           // 00000019C270: 7E003982
	v_fma_f32 v9, -v26, v11, v17                               // 00000019C274: D6130009 2446171A
	v_fma_f32 v30, -v29, v14, 1.0                              // 00000019C27C: D613001E 23CA1D1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019C284: BF870114
	v_mul_f32_e32 v19, v21, v28                                // 00000019C288: 10263915
	v_dual_fmac_f32 v11, v9, v27 :: v_dual_fmac_f32 v14, v30, v14// 00000019C28C: C8003709 0B0E1D1E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019C294: BF870225
	v_fma_f32 v33, -v25, v13, 1.0                              // 00000019C298: D6130021 23CA1B19
	v_div_scale_f32 v30, s1, v5, v18, v5                       // 00000019C2A0: D6FC011E 04162505
	v_fma_f32 v9, -v20, v19, v21                               // 00000019C2A8: D6130009 24562714
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019C2B0: BF870214
	v_fma_f32 v17, -v26, v11, v17                              // 00000019C2B4: D6130011 2446171A
	v_fmac_f32_e32 v13, v33, v13                               // 00000019C2BC: 561A1B21
	v_div_scale_f32 v33, s2, v6, v22, v6                       // 00000019C2C0: D6FC0221 041A2D06
	v_mul_f32_e32 v35, v30, v14                                // 00000019C2C8: 10461D1E
	v_fmac_f32_e32 v19, v9, v28                                // 00000019C2CC: 56263909
	v_div_fmas_f32 v11, v17, v27, v11                          // 00000019C2D0: D637000B 042E3711
	s_mov_b32 vcc_lo, s0                                       // 00000019C2D8: BEEA0000
	v_mul_f32_e32 v26, v33, v13                                // 00000019C2DC: 10341B21
	v_fma_f32 v9, -v29, v35, v30                               // 00000019C2E0: D6130009 247A471D
	v_fma_f32 v17, -v20, v19, v21                              // 00000019C2E8: D6130011 24562714
	v_div_fixup_f32 v3, v11, v10, v3                           // 00000019C2F0: D6270003 040E150B
	v_and_b32_e32 v11, 1, v34                                  // 00000019C2F8: 36164481
	v_fma_f32 v20, -v25, v26, v33                              // 00000019C2FC: D6130014 24863519
	v_fmac_f32_e32 v35, v9, v14                                // 00000019C304: 56461D09
	v_div_fmas_f32 v9, v17, v28, v19                           // 00000019C308: D6370009 044E3911
	s_mov_b32 vcc_lo, s1                                       // 00000019C310: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019C314: BF870193
	v_dual_fmac_f32 v26, v20, v13 :: v_dual_and_b32 v17, 1, v0 // 00000019C318: C8241B14 1A100081
	v_fma_f32 v10, -v29, v35, v30                              // 00000019C320: D613000A 247A471D
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019C328: BF870003
	v_div_fixup_f32 v4, v9, v12, v4                            // 00000019C32C: D6270004 04121909
	.long 0x7f183980                                           // 00000019C334: 7F183980
	v_add3_u32 v1, v1, v11, 0x7fff                             // 00000019C338: D6550001 03FE1701 00007FFF
	v_fma_f32 v9, -v25, v26, v33                               // 00000019C344: D6130009 24863519
	v_div_fmas_f32 v10, v10, v14, v35                          // 00000019C34C: D637000A 048E1D0A
	s_mov_b32 vcc_lo, s2                                       // 00000019C354: BEEA0002
	.long 0x7e003984                                           // 00000019C358: 7E003984
	v_add3_u32 v2, v2, v17, 0x7fff                             // 00000019C35C: D6550002 03FE2302 00007FFF
	v_div_fmas_f32 v9, v9, v13, v26                            // 00000019C368: D6370009 046A1B09
	v_div_fixup_f32 v5, v10, v18, v5                           // 00000019C370: D6270005 0416250A
	.long 0x7e143983                                           // 00000019C378: 7E143983
	.long 0x7f143980                                           // 00000019C37C: 7F143980
	global_store_d16_hi_b16 v[7:8], v1, off offset:224         // 00000019C380: DC9600E0 007C0107
	v_div_fixup_f32 v6, v9, v22, v6                            // 00000019C388: D6270006 041A2D09
	.long 0x7e183985                                           // 00000019C390: 7E183985
	v_and_b32_e32 v9, 1, v0                                    // 00000019C394: 36120081
	v_and_b32_e32 v10, 1, v10                                  // 00000019C398: 36141481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019C39C: BF870214
	.long 0x7e003986                                           // 00000019C3A0: 7E003986
	v_and_b32_e32 v11, 1, v12                                  // 00000019C3A4: 36161881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019C3A8: BF870223
	v_add3_u32 v1, v3, v10, 0x7fff                             // 00000019C3AC: D6550001 03FE1503 00007FFF
	v_add3_u32 v3, v4, v9, 0x7fff                              // 00000019C3B8: D6550003 03FE1304 00007FFF
	v_and_b32_e32 v0, 1, v0                                    // 00000019C3C4: 36000081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019C3C8: BF870114
	v_add3_u32 v4, v5, v11, 0x7fff                             // 00000019C3CC: D6550004 03FE1705 00007FFF
	v_add3_u32 v0, v6, v0, 0x7fff                              // 00000019C3D8: D6550000 03FE0106 00007FFF
	s_clause 0x4                                               // 00000019C3E4: BF850004
	global_store_d16_hi_b16 v[47:48], v2, off offset:224       // 00000019C3E8: DC9600E0 007C022F
	global_store_d16_hi_b16 v[15:16], v1, off offset:224       // 00000019C3F0: DC9600E0 007C010F
	global_store_d16_hi_b16 v[23:24], v3, off offset:224       // 00000019C3F8: DC9600E0 007C0317
	global_store_d16_hi_b16 v[31:32], v4, off offset:224       // 00000019C400: DC9600E0 007C041F
	global_store_d16_hi_b16 v[39:40], v0, off offset:224       // 00000019C408: DC9600E0 007C0027
	s_nop 0                                                    // 00000019C410: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000019C414: BFB60003
	s_endpgm                                                   // 00000019C418: BFB00000
		...

