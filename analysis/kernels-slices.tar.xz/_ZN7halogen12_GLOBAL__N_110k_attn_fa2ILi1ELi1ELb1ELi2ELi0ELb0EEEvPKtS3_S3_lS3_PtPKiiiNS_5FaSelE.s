0000000000055500 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 000000055500: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 000000055504: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 00000005550C: F4080500 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 000000055514: 3706009F
	v_lshrrev_b32_e32 v156, 5, v0                              // 000000055518: 33380085
	s_mov_b32 s24, s3                                          // 00000005551C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000055520: BF870112
	.long 0xd44c0003                                           // 000000055524: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 000000055528: 02030690
	v_lshlrev_b32_e32 v132, 6, v156                            // 00000005552C: 31093886
	s_waitcnt lgkmcnt(0)                                       // 000000055530: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 000000055534: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 00000005553C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 000000055540: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 000000055544: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 00000005554C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:156 offset1:162// 000000055558: D83CA29C 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 000000055560: 8C7E047E
	v_mul_u32_u24_e32 v1, 0xab, v0                             // 000000055564: 160200FF 000000AB
	.long 0x7f043880                                           // 00000005556C: 7F043880
	v_dual_mov_b32 v141, 0 :: v_dual_and_b32 v154, 15, v0      // 000000055570: CA240080 8D9A008F
	s_cmp_eq_u64 s[14:15], 0                                   // 000000055578: BF10800E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000005557C: BF8704B3
	.long 0x7e043981                                           // 000000055580: 7E043981
	v_mov_b32_e32 v142, 0                                      // 000000055584: 7F1C0280
	s_cselect_b32 s25, -1, 0                                   // 000000055588: 981980C1
	s_and_b32 vcc_lo, exec_lo, s25                             // 00000005558C: 8B6A197E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055590: BF870092
	v_add_lshl_u32 v155, s2, v2, 4                             // 000000055594: D647009B 02120402
	v_or_b32_e32 v129, v155, v154                              // 00000005559C: 3903359B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000555A0: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000555A4: 3505029F
	s_cbranch_vccnz 10                                         // 0000000555A8: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xd4>
	v_mad_i64_i32 v[1:2], null, s23, v129, 0                   // 0000000555AC: D6FF7C01 02030217
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000555B4: BF870091
	.long 0xd73c0001                                           // 0000000555B8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000000555BC: 02020282
	.long 0xd7006a8d                                           // 0000000555C0: D7006A8D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000000555C4: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000555C8: BF870001
	v_add_co_ci_u32_e64 v142, null, s15, v2, vcc_lo            // 0000000555CC: D5207C8E 01AA040F
	s_clause 0x2                                               // 0000000555D4: BF850002
	s_load_b64 s[14:15], s[0:1], 0x38                          // 0000000555D8: F4040380 F8000038
	s_load_b128 s[16:19], s[0:1], 0x20                         // 0000000555E0: F4080400 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000000555E8: F40C0100 F8000000
	v_mov_b32_e32 v158, 0                                      // 0000000555F0: 7F3C0280
	s_xor_b32 s0, s25, -1                                      // 0000000555F4: 8D00C119
	s_waitcnt lgkmcnt(0)                                       // 0000000555F8: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v129                         // 0000000555FC: 7C89020E
	s_and_b32 s23, s0, vcc_lo                                  // 000000055600: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000055604: BF870009
	s_and_saveexec_b32 s0, s23                                 // 000000055608: BE802017
	s_cbranch_execz 9                                          // 00000005560C: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x134>
	.long 0xd73c0001                                           // 000000055610: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 000000055614: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055618: BF870091
	.long 0xd7006a01                                           // 00000005561C: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 000000055620: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 000000055624: D5207C02 01AA0415
	global_load_b32 v158, v[1:2], off                          // 00000005562C: DC520000 9E7C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 000000055634: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 000000055638: BF10800C
	s_mov_b64 s[20:21], 0                                      // 00000005563C: BE940180
	s_cbranch_scc1 10                                          // 000000055640: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c>
	s_ashr_i32 s0, s22, 31                                     // 000000055644: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 000000055648: 96810216
	s_mul_i32 s0, s0, s2                                       // 00000005564C: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000055650: BF8704A9
	s_add_i32 s1, s1, s0                                       // 000000055654: 81010001
	s_mul_i32 s0, s22, s2                                      // 000000055658: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000005565C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000055660: BF870009
	s_add_u32 s20, s12, s0                                     // 000000055664: 8014000C
	s_addc_u32 s21, s13, s1                                    // 000000055668: 8215010D
	.long 0xd7050001                                           // 00000005566C: D7050001
	v_cndmask_b32_e32 v0, v156, v150, vcc_lo                   // 000000055670: 02012D9C
	s_lshl_b32 s0, s2, 4                                       // 000000055674: 84008402
	s_add_i32 s1, s14, -1                                      // 000000055678: 8101C10E
	s_or_b32 s0, s0, 15                                        // 00000005567C: 8C008F00
	v_lshrrev_b32_e32 v157, 4, v131                            // 000000055680: 333B0684
	.long 0xd7390001                                           // 000000055684: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 000000055688: 02020288
	s_min_i32 s0, s0, s1                                       // 00000005568C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000055690: BF870499
	s_add_i32 s0, s26, s0                                      // 000000055694: 8100001A
	s_cmp_lt_i32 s0, -15                                       // 000000055698: BF04CF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005569C: BF870091
	.long 0xd7050001                                           // 0000000556A0: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 0000000556A4: 02011901
	.long 0xd7040001                                           // 0000000556A8: D7040001
	v_cndmask_b32_e32 v1, v156, v1, vcc_lo                     // 0000000556AC: 0202039C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000556B0: BF870091
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 0000000556B4: CA240080 480002FF 000000FF
	v_mov_b32_e32 v71, v72                                     // 0000000556C0: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 0000000556C4: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 0000000556C8: 7E880348
	v_mov_b32_e32 v67, v72                                     // 0000000556CC: 7E860348
	v_mad_u64_u32 v[138:139], null, s24, 12, v[1:2]            // 0000000556D0: D6FE7C8A 04051818
	v_mov_b32_e32 v70, v72                                     // 0000000556D8: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 0000000556DC: 7E840348
	v_mov_b32_e32 v65, v72                                     // 0000000556E0: 7E820348
	v_mov_b32_e32 v80, v72                                     // 0000000556E4: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 0000000556E8: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 0000000556EC: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 0000000556F0: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 0000000556F4: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 0000000556FC: 7E960348
	v_mov_b32_e32 v74, v72                                     // 000000055700: 7E940348
	v_mov_b32_e32 v73, v72                                     // 000000055704: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 000000055708: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000005570C: 3404029F
	v_mov_b32_e32 v88, v72                                     // 000000055710: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 000000055714: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 000000055718: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 00000005571C: 7EAA0348
	.long 0xd73c008b                                           // 000000055720: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000055724: 02020281
	v_mov_b32_e32 v84, v72                                     // 000000055728: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 00000005572C: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 000000055730: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 000000055734: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 000000055738: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 00000005573C: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 000000055740: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 000000055744: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 000000055748: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 00000005574C: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 000000055750: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 000000055754: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 000000055758: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 00000005575C: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 000000055760: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 000000055764: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 000000055768: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 00000005576C: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 000000055770: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 000000055774: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 000000055778: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 00000005577C: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 000000055780: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 000000055784: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 000000055788: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 00000005578C: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 000000055790: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 000000055794: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 000000055798: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 00000005579C: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 0000000557A0: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 0000000557A4: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 0000000557A8: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 0000000557AC: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 0000000557B0: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 0000000557B4: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 0000000557B8: 7F000348
	v_mov_b32_e32 v127, v72                                    // 0000000557BC: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 0000000557C0: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 0000000557C4: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 0000000557C8: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 0000000557CC: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 0000000557D0: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 0000000557D4: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 0000000557D8: 7E800348
	v_mov_b32_e32 v63, v72                                     // 0000000557DC: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 0000000557E0: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 0000000557E4: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 0000000557E8: 7E780348
	v_mov_b32_e32 v59, v72                                     // 0000000557EC: 7E760348
	v_mov_b32_e32 v58, v72                                     // 0000000557F0: 7E740348
	v_mov_b32_e32 v57, v72                                     // 0000000557F4: 7E720348
	v_mov_b32_e32 v56, v72                                     // 0000000557F8: 7E700348
	v_mov_b32_e32 v55, v72                                     // 0000000557FC: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 000000055800: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 000000055804: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 000000055808: 7E680348
	v_mov_b32_e32 v51, v72                                     // 00000005580C: 7E660348
	v_mov_b32_e32 v50, v72                                     // 000000055810: 7E640348
	v_mov_b32_e32 v49, v72                                     // 000000055814: 7E620348
	v_mov_b32_e32 v48, v72                                     // 000000055818: 7E600348
	v_mov_b32_e32 v47, v72                                     // 00000005581C: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 000000055820: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 000000055824: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 000000055828: 7E580348
	v_mov_b32_e32 v43, v72                                     // 00000005582C: 7E560348
	v_mov_b32_e32 v42, v72                                     // 000000055830: 7E540348
	v_mov_b32_e32 v41, v72                                     // 000000055834: 7E520348
	v_mov_b32_e32 v40, v72                                     // 000000055838: 7E500348
	v_mov_b32_e32 v39, v72                                     // 00000005583C: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 000000055840: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 000000055844: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 000000055848: 7E480348
	v_mov_b32_e32 v35, v72                                     // 00000005584C: 7E460348
	v_mov_b32_e32 v34, v72                                     // 000000055850: 7E440348
	v_mov_b32_e32 v33, v72                                     // 000000055854: 7E420348
	v_mov_b32_e32 v32, v72                                     // 000000055858: 7E400348
	v_mov_b32_e32 v31, v72                                     // 00000005585C: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 000000055860: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 000000055864: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 000000055868: 7E380348
	v_mov_b32_e32 v27, v72                                     // 00000005586C: 7E360348
	v_mov_b32_e32 v26, v72                                     // 000000055870: 7E340348
	v_mov_b32_e32 v25, v72                                     // 000000055874: 7E320348
	v_mov_b32_e32 v24, v72                                     // 000000055878: 7E300348
	v_mov_b32_e32 v23, v72                                     // 00000005587C: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 000000055880: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 000000055884: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 000000055888: 7E280348
	v_mov_b32_e32 v19, v72                                     // 00000005588C: 7E260348
	v_mov_b32_e32 v18, v72                                     // 000000055890: 7E240348
	v_mov_b32_e32 v17, v72                                     // 000000055894: 7E220348
	v_mov_b32_e32 v16, v72                                     // 000000055898: 7E200348
	v_mov_b32_e32 v15, v72                                     // 00000005589C: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 0000000558A0: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 0000000558A4: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 0000000558A8: 7E180348
	v_mov_b32_e32 v11, v72                                     // 0000000558AC: 7E160348
	v_mov_b32_e32 v10, v72                                     // 0000000558B0: 7E140348
	v_mov_b32_e32 v9, v72                                      // 0000000558B4: 7E120348
	v_mov_b32_e32 v8, v72                                      // 0000000558B8: 7E100348
	v_mov_b32_e32 v7, v72                                      // 0000000558BC: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 0000000558C0: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 0000000558C4: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 0000000558C8: 7E080348
	v_mov_b32_e32 v3, v72                                      // 0000000558CC: 7E060348
	v_mov_b32_e32 v2, v72                                      // 0000000558D0: 7E040348
	v_mov_b32_e32 v1, v72                                      // 0000000558D4: 7E020348
	s_cbranch_scc1 2304                                        // 0000000558D8: BFA20900 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x27dc>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[4:5]           // 0000000558DC: D6FF7C01 001302FF 00003000
	v_add3_u32 v3, v129, s26, 1                                // 0000000558E8: D6550003 02043581
	s_ashr_i32 s1, s0, 31                                      // 0000000558F0: 86019F00
	v_dual_mov_b32 v129, 0 :: v_dual_lshlrev_b32 v4, 2, v131   // 0000000558F4: CA220080 81050682
	s_lshr_b32 s1, s1, 28                                      // 0000000558FC: 85019C01
	s_movk_i32 s2, 0x210                                       // 000000055900: B0020210
	s_add_i32 s0, s0, s1                                       // 000000055904: 81000100
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000055908: BF8701D3
	.long 0xd7006a8f                                           // 00000005590C: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 000000055910: 02031701
	v_ashrrev_i32_e32 v1, 31, v3                               // 000000055914: 3402069F
	s_movk_i32 s1, 0x440                                       // 000000055918: B0010440
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 00000005591C: D5207C90 01AB1902
	v_mad_u32_u24 v2, v156, s1, 0x1800                         // 000000055924: D60B0002 03FC039C 00001800
	v_lshrrev_b32_e32 v1, 30, v1                               // 000000055930: 3202029E
	s_ashr_i32 s12, s0, 4                                      // 000000055934: 860C8400
	s_cmp_eq_u64 s[20:21], 0                                   // 000000055938: BF108014
	v_mov_b32_e32 v176, v156                                   // 00000005593C: 7F60039C
	v_mad_u32_u24 v5, 0x44, v157, v2                           // 000000055940: D60B0005 040B3AFF 00000044
	v_add_nc_u32_e32 v1, v3, v1                                // 00000005594C: 4A020303
	v_mad_u32_u24 v164, 0x44, v131, v2                         // 000000055950: D60B00A4 040B06FF 00000044
	v_lshlrev_b32_e32 v2, 4, v0                                // 00000005595C: 30040084
	s_cselect_b32 s13, -1, 0                                   // 000000055960: 980D80C1
	v_lshl_add_u32 v160, v154, 2, v5                           // 000000055964: D64600A0 0415059A
	v_ashrrev_i32_e32 v161, 2, v1                              // 00000005596C: 35420282
	v_lshlrev_b32_e32 v1, 9, v156                              // 000000055970: 30033889
	v_dual_mov_b32 v8, v129 :: v_dual_add_nc_u32 v5, 0x9f00, v132// 000000055974: CA200181 080508FF 00009F00
	s_cmp_lg_u64 s[20:21], 0                                   // 000000055980: BF118014
	v_add_nc_u32_e32 v3, v4, v132                              // 000000055984: 4A070904
	s_cselect_b32 s22, -1, 0                                   // 000000055988: 981680C1
	s_ashr_i32 s25, s24, 31                                    // 00000005598C: 86199F18
	v_add_nc_u32_e32 v167, v5, v4                              // 000000055990: 4B4E0905
	v_mov_b32_e32 v4, v129                                     // 000000055994: 7E080381
	v_lshl_add_u32 v165, v131, 5, v1                           // 000000055998: D64600A5 04050B83
	v_lshl_or_b32 v169, v154, 5, v1                            // 0000000559A0: D65600A9 04050B9A
	v_dual_mov_b32 v10, v129 :: v_dual_and_b32 v1, 0x1f0, v2   // 0000000559A8: CA240181 0A0004FF 000001F0
	s_lshl_b64 s[4:5], s[24:25], 9                             // 0000000559B4: 84848918
	s_add_i32 s15, s15, -1                                     // 0000000559B8: 810FC10F
	v_mul_u32_u24_e32 v2, 0x210, v156                          // 0000000559BC: 160538FF 00000210
	s_add_u32 s1, s6, s4                                       // 0000000559C4: 80010406
	s_addc_u32 s6, s7, s5                                      // 0000000559C8: 82060507
	.long 0xd70001ab                                           // 0000000559CC: D70001AB
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 0000000559D0: 02020201
	.long 0xd44c0000                                           // 0000000559D4: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000000559D8: 020200FF 00000200
	v_mad_u32_u24 v159, v154, s2, 0x7b00                       // 0000000559E0: D60B009F 03FC059A 00007B00
	v_add3_u32 v162, v155, v131, s26                           // 0000000559EC: D65500A2 006B079B
	v_lshl_or_b32 v168, v157, 2, v5                            // 0000000559F4: D65600A8 0415059D
	v_mad_u32_u24 v170, v154, 48, 0x4b00                       // 0000000559FC: D60B00AA 03FD619A 00004B00
	v_add_co_ci_u32_e64 v172, null, s6, 0, s1                  // 000000055A08: D5207CAC 00050006
	v_lshl_or_b32 v173, v154, 1, 0x4b00                        // 000000055A10: D65600AD 03FD039A 00004B00
	v_dual_mov_b32 v5, v129 :: v_dual_add_nc_u32 v174, 0xfffffe80, v0// 000000055A1C: CA200181 05AE00FF FFFFFE80
	v_lshl_add_u32 v175, v131, 4, v2                           // 000000055A28: D64600AF 04090983
	v_lshrrev_b32_e32 v0, 1, v0                                // 000000055A30: 32000081
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, v129            // 000000055A34: CA100080 01020181
	v_dual_mov_b32 v6, v129 :: v_dual_add_nc_u32 v163, 0x9c00, v3// 000000055A3C: CA200181 06A206FF 00009C00
	v_dual_mov_b32 v3, v129 :: v_dual_add_nc_u32 v166, 0xa200, v3// 000000055A48: CA200181 03A606FF 0000A200
	v_mov_b32_e32 v7, v129                                     // 000000055A54: 7E0E0381
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v12, v129           // 000000055A58: CA100080 090C0181
	v_mov_b32_e32 v11, v129                                    // 000000055A60: 7E160381
	v_mov_b32_e32 v13, v129                                    // 000000055A64: 7E1A0381
	v_dual_mov_b32 v14, v129 :: v_dual_mov_b32 v17, 0          // 000000055A68: CA100181 0E100080
	v_mov_b32_e32 v15, v129                                    // 000000055A70: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v25, 0          // 000000055A74: CA100181 10180080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v33, 0          // 000000055A7C: CA100181 12200080
	v_mov_b32_e32 v19, v129                                    // 000000055A84: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v41, 0          // 000000055A88: CA100181 14280080
	v_mov_b32_e32 v21, v129                                    // 000000055A90: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v49, 0          // 000000055A94: CA100181 16300080
	v_mov_b32_e32 v23, v129                                    // 000000055A9C: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v57, 0          // 000000055AA0: CA100181 18380080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v121, 0         // 000000055AA8: CA100181 1A780080
	v_mov_b32_e32 v27, v129                                    // 000000055AB0: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v113, 0         // 000000055AB4: CA100181 1C700080
	v_mov_b32_e32 v29, v129                                    // 000000055ABC: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v105, 0         // 000000055AC0: CA100181 1E680080
	v_mov_b32_e32 v31, v129                                    // 000000055AC8: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v97, 0          // 000000055ACC: CA100181 20600080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v89, 0          // 000000055AD4: CA100181 22580080
	v_mov_b32_e32 v35, v129                                    // 000000055ADC: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v81, 0          // 000000055AE0: CA100181 24500080
	v_mov_b32_e32 v37, v129                                    // 000000055AE8: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v73, 0          // 000000055AEC: CA100181 26480080
	v_mov_b32_e32 v39, v129                                    // 000000055AF4: 7E4E0381
	v_dual_mov_b32 v40, v129 :: v_dual_mov_b32 v65, 0          // 000000055AF8: CA100181 28400080
	v_dual_mov_b32 v42, v129 :: v_dual_mov_b32 v145, 0         // 000000055B00: CA100181 2A900080
	v_mov_b32_e32 v43, v129                                    // 000000055B08: 7E560381
	v_mov_b32_e32 v44, v129                                    // 000000055B0C: 7E580381
	v_mov_b32_e32 v45, v129                                    // 000000055B10: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 000000055B14: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 000000055B18: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 000000055B1C: 7E600381
	v_mov_b32_e32 v50, v129                                    // 000000055B20: 7E640381
	v_mov_b32_e32 v51, v129                                    // 000000055B24: 7E660381
	v_mov_b32_e32 v52, v129                                    // 000000055B28: 7E680381
	v_mov_b32_e32 v53, v129                                    // 000000055B2C: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 000000055B30: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 000000055B34: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 000000055B38: 7E700381
	v_mov_b32_e32 v58, v129                                    // 000000055B3C: 7E740381
	v_mov_b32_e32 v59, v129                                    // 000000055B40: 7E760381
	v_mov_b32_e32 v60, v129                                    // 000000055B44: 7E780381
	v_mov_b32_e32 v61, v129                                    // 000000055B48: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 000000055B4C: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 000000055B50: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 000000055B54: 7E800381
	v_mov_b32_e32 v122, v129                                   // 000000055B58: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 000000055B5C: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 000000055B60: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 000000055B64: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 000000055B68: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 000000055B6C: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 000000055B70: 7F000381
	v_mov_b32_e32 v114, v129                                   // 000000055B74: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 000000055B78: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 000000055B7C: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 000000055B80: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 000000055B84: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 000000055B88: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 000000055B8C: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 000000055B90: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 000000055B94: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 000000055B98: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 000000055B9C: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 000000055BA0: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 000000055BA4: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 000000055BA8: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 000000055BAC: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 000000055BB0: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 000000055BB4: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 000000055BB8: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 000000055BBC: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 000000055BC0: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 000000055BC4: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 000000055BC8: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 000000055BCC: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 000000055BD0: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 000000055BD4: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 000000055BD8: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 000000055BDC: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 000000055BE0: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 000000055BE4: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 000000055BE8: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 000000055BEC: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 000000055BF0: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 000000055BF4: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 000000055BF8: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 000000055BFC: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 000000055C00: 7E940381
	v_mov_b32_e32 v75, v129                                    // 000000055C04: 7E960381
	v_mov_b32_e32 v76, v129                                    // 000000055C08: 7E980381
	v_mov_b32_e32 v77, v129                                    // 000000055C0C: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 000000055C10: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 000000055C14: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 000000055C18: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 000000055C1C: 7E840381
	v_mov_b32_e32 v67, v129                                    // 000000055C20: 7E860381
	v_mov_b32_e32 v68, v129                                    // 000000055C24: 7E880381
	v_mov_b32_e32 v69, v129                                    // 000000055C28: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 000000055C2C: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 000000055C30: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 000000055C34: 7E900381
	s_add_u32 s6, s8, s4                                       // 000000055C38: 80060408
	s_addc_u32 s5, s9, s5                                      // 000000055C3C: 82050509
	s_mov_b32 s7, 0                                            // 000000055C40: BE870080
	s_branch 117                                               // 000000055C44: BFA00075 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x91c>
	ds_load_b128 v[146:149], v170                              // 000000055C48: DBFC0000 920000AA
	ds_load_b128 v[150:153], v170 offset:16                    // 000000055C50: DBFC0010 960000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055C58: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[146:153], v[121:128]// 000000055C5C: CC414079 1DE72582
	ds_load_b128 v[150:153], v170 offset:784                   // 000000055C64: DBFC0310 960000AA
	ds_load_b128 v[146:149], v170 offset:768                   // 000000055C6C: DBFC0300 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055C74: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[146:153], v[113:120]// 000000055C78: CC414071 1DC72582
	ds_load_b128 v[150:153], v170 offset:1552                  // 000000055C80: DBFC0610 960000AA
	ds_load_b128 v[146:149], v170 offset:1536                  // 000000055C88: DBFC0600 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055C90: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[146:153], v[105:112]// 000000055C94: CC414069 1DA72582
	ds_load_b128 v[150:153], v170 offset:2320                  // 000000055C9C: DBFC0910 960000AA
	ds_load_b128 v[146:149], v170 offset:2304                  // 000000055CA4: DBFC0900 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055CAC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[146:153], v[97:104]// 000000055CB0: CC414061 1D872582
	ds_load_b128 v[150:153], v170 offset:3088                  // 000000055CB8: DBFC0C10 960000AA
	ds_load_b128 v[146:149], v170 offset:3072                  // 000000055CC0: DBFC0C00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055CC8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[146:153], v[89:96]// 000000055CCC: CC414059 1D672582
	ds_load_b128 v[150:153], v170 offset:3856                  // 000000055CD4: DBFC0F10 960000AA
	ds_load_b128 v[146:149], v170 offset:3840                  // 000000055CDC: DBFC0F00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055CE4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[146:153], v[81:88]// 000000055CE8: CC414051 1D472582
	ds_load_b128 v[150:153], v170 offset:4624                  // 000000055CF0: DBFC1210 960000AA
	ds_load_b128 v[146:149], v170 offset:4608                  // 000000055CF8: DBFC1200 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055D00: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[146:153], v[73:80]// 000000055D04: CC414049 1D272582
	ds_load_b128 v[150:153], v170 offset:5392                  // 000000055D0C: DBFC1510 960000AA
	ds_load_b128 v[146:149], v170 offset:5376                  // 000000055D14: DBFC1500 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055D1C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[146:153], v[65:72]// 000000055D20: CC414041 1D072582
	ds_load_b128 v[150:153], v170 offset:6160                  // 000000055D28: DBFC1810 960000AA
	ds_load_b128 v[146:149], v170 offset:6144                  // 000000055D30: DBFC1800 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055D38: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[146:153], v[57:64]// 000000055D3C: CC414039 1CE72582
	ds_load_b128 v[150:153], v170 offset:6928                  // 000000055D44: DBFC1B10 960000AA
	ds_load_b128 v[146:149], v170 offset:6912                  // 000000055D4C: DBFC1B00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055D54: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[146:153], v[49:56]// 000000055D58: CC414031 1CC72582
	ds_load_b128 v[150:153], v170 offset:7696                  // 000000055D60: DBFC1E10 960000AA
	ds_load_b128 v[146:149], v170 offset:7680                  // 000000055D68: DBFC1E00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055D70: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[146:153], v[41:48]// 000000055D74: CC414029 1CA72582
	ds_load_b128 v[150:153], v170 offset:8464                  // 000000055D7C: DBFC2110 960000AA
	ds_load_b128 v[146:149], v170 offset:8448                  // 000000055D84: DBFC2100 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055D8C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[146:153], v[33:40]// 000000055D90: CC414021 1C872582
	ds_load_b128 v[150:153], v170 offset:9232                  // 000000055D98: DBFC2410 960000AA
	ds_load_b128 v[146:149], v170 offset:9216                  // 000000055DA0: DBFC2400 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055DA8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[146:153], v[25:32]// 000000055DAC: CC414019 1C672582
	ds_load_b128 v[150:153], v170 offset:10000                 // 000000055DB4: DBFC2710 960000AA
	ds_load_b128 v[146:149], v170 offset:9984                  // 000000055DBC: DBFC2700 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055DC4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[146:153], v[17:24]// 000000055DC8: CC414011 1C472582
	ds_load_b128 v[150:153], v170 offset:10768                 // 000000055DD0: DBFC2A10 960000AA
	ds_load_b128 v[146:149], v170 offset:10752                 // 000000055DD8: DBFC2A00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055DE0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[146:153], v[9:16]// 000000055DE4: CC414009 1C272582
	ds_load_b128 v[150:153], v170 offset:11536                 // 000000055DEC: DBFC2D10 960000AA
	ds_load_b128 v[146:149], v170 offset:11520                 // 000000055DF4: DBFC2D00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 000000055DFC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[146:153], v[1:8]// 000000055E00: CC414001 1C072582
	v_add_nc_u32_e32 v176, 16, v176                            // 000000055E08: 4B616090
	s_add_i32 s1, s7, 1                                        // 000000055E0C: 81018107
	s_cmp_eq_u32 s7, s12                                       // 000000055E10: BF060C07
	s_mov_b32 s7, s1                                           // 000000055E14: BE870001
	s_cbranch_scc1 1968                                        // 000000055E18: BFA207B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x27dc>
	s_and_not1_b32 vcc_lo, exec_lo, s22                        // 000000055E1C: 916A167E
	s_mov_b32 s1, s13                                          // 000000055E20: BE81000D
	s_cbranch_vccnz 13                                         // 000000055E24: BFA4000D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x95c>
	s_lshr_b32 s1, s7, 3                                       // 000000055E28: 85018307
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000055E2C: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 000000055E30: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 000000055E38: 7F040201
	global_load_b32 v130, v130, s[20:21]                       // 000000055E3C: DC520000 82140082
	s_waitcnt vmcnt(0)                                         // 000000055E44: BF8903F7
	v_lshrrev_b32_e32 v130, s7, v130                           // 000000055E48: 33050407
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055E4C: BF870091
	v_and_b32_e32 v130, 1, v130                                // 000000055E50: 37050481
	.long 0xd44a0001                                           // 000000055E54: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 000000055E58: 02030481
	s_delay_alu instid0(VALU_DEP_1)                            // 000000055E5C: BF870001
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000055E60: 916A017E
	s_cbranch_vccnz 65512                                      // 000000055E64: BFA4FFE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x908>
	s_lshl_b32 s2, s7, 4                                       // 000000055E68: 84028407
	s_waitcnt vmcnt(0)                                         // 000000055E6C: BF8903F7
	s_barrier                                                  // 000000055E70: BFBD0000
	buffer_gl0_inv                                             // 000000055E74: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000055E7C: BE812000
	s_cbranch_execz 119                                        // 000000055E80: BFA50077 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb60>
	v_dual_mov_b32 v130, v176 :: v_dual_mov_b32 v131, v175     // 000000055E84: CA1001B0 828201AF
	v_mov_b32_e32 v132, v174                                   // 000000055E8C: 7F0803AE
	s_mov_b32 s4, 0                                            // 000000055E90: BE840080
	s_nop 0                                                    // 000000055E94: BF800000
	s_nop 0                                                    // 000000055E98: BF800000
	s_nop 0                                                    // 000000055E9C: BF800000
	s_nop 0                                                    // 000000055EA0: BF800000
	s_nop 0                                                    // 000000055EA4: BF800000
	s_nop 0                                                    // 000000055EA8: BF800000
	s_nop 0                                                    // 000000055EAC: BF800000
	s_nop 0                                                    // 000000055EB0: BF800000
	s_nop 0                                                    // 000000055EB4: BF800000
	s_nop 0                                                    // 000000055EB8: BF800000
	s_nop 0                                                    // 000000055EBC: BF800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000055EC0: BF870112
	v_min_i32_e32 v133, s15, v130                              // 000000055EC4: 230B040F
	v_add_nc_u32_e32 v132, 0x180, v132                         // 000000055EC8: 4B0908FF 00000180
	v_add_nc_u32_e32 v130, 12, v130                            // 000000055ED0: 4B05048C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000055ED4: BF8701B3
	v_ashrrev_i32_e32 v135, 31, v133                           // 000000055ED8: 350F0A9F
	.long 0xd72c0088                                           // 000000055EDC: D72C0088
	v_cndmask_b32_e32 v1, s11, v133, vcc_lo                    // 000000055EE0: 02030A0B
	v_mad_u64_u32 v[133:134], null, s10, v133, 0               // 000000055EE4: D6FE7C85 02030A0A
	.long 0xd72c0087                                           // 000000055EEC: D72C0087
	v_cndmask_b32_e32 v1, s10, v135, vcc_lo                    // 000000055EF0: 02030E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055EF4: BF870091
	v_add3_u32 v134, v134, v135, v136                          // 000000055EF8: D6550086 06230F86
	.long 0xd73c0085                                           // 000000055F00: D73C0085
	v_cndmask_b32_e32 v1, 1, v133, vcc_lo                      // 000000055F04: 02030A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055F08: BF870091
	.long 0xd7006a85                                           // 000000055F0C: D7006A85
	v_cndmask_b32_e32 v1, v171, v133, vcc_lo                   // 000000055F10: 02030BAB
	v_add_co_ci_u32_e64 v134, null, v172, v134, vcc_lo         // 000000055F14: D5207C86 01AB0DAC
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v132                        // 000000055F1C: 7C9308FF 0000007F
	global_load_b128 v[133:136], v[133:134], off               // 000000055F24: DC5E0000 857C0085
	s_or_b32 s4, vcc_lo, s4                                    // 000000055F2C: 8C04046A
	s_waitcnt vmcnt(0)                                         // 000000055F30: BF8903F7
	ds_store_b128 v131, v[133:136] offset:31488                // 000000055F34: DB7C7B00 00008583
	v_add_nc_u32_e32 v131, 0x18c0, v131                        // 000000055F3C: 4B0706FF 000018C0
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000055F44: 917E047E
	s_cbranch_execnz 65501                                     // 000000055F48: BFA6FFDD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000055F4C: 8C7E047E
	v_or_b32_e32 v130, s2, v154                                // 000000055F50: 39053402
	s_mov_b32 s4, 0                                            // 000000055F54: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055F58: BF870091
	v_min_i32_e32 v130, s15, v130                              // 000000055F5C: 2305040F
	v_ashrrev_i32_e32 v132, 31, v130                           // 000000055F60: 3509049F
	.long 0xd72c0085                                           // 000000055F64: D72C0085
	v_cndmask_b32_e32 v1, s11, v130, vcc_lo                    // 000000055F68: 0203040B
	v_mad_u64_u32 v[130:131], null, s10, v130, 0               // 000000055F6C: D6FE7C82 0203040A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055F74: BF870093
	.long 0xd72c0084                                           // 000000055F78: D72C0084
	v_cndmask_b32_e32 v1, s10, v132, vcc_lo                    // 000000055F7C: 0203080A
	v_add3_u32 v131, v131, v132, v133                          // 000000055F80: D6550083 06170983
	v_mov_b32_e32 v133, v174                                   // 000000055F88: 7F0A03AE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000055F8C: BF870122
	.long 0xd73c0083                                           // 000000055F90: D73C0083
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 000000055F94: 02030481
	v_mov_b32_e32 v130, v0                                     // 000000055F98: 7F040300
	.long 0xd7006a83                                           // 000000055F9C: D7006A83
	v_cndmask_b32_e32 v1, s6, v131, vcc_lo                     // 000000055FA0: 02030606
	s_delay_alu instid0(VALU_DEP_1)                            // 000000055FA4: BF870001
	v_add_co_ci_u32_e64 v132, null, s5, v132, vcc_lo           // 000000055FA8: D5207C84 01AB0805
	s_set_inst_prefetch_distance 0x1                           // 000000055FB0: BF840001
	s_nop 0                                                    // 000000055FB4: BF800000
	s_nop 0                                                    // 000000055FB8: BF800000
	s_nop 0                                                    // 000000055FBC: BF800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000055FC0: BF8701B3
	v_and_b32_e32 v146, 0xf8, v130                             // 000000055FC4: 372504FF 000000F8
	v_add_nc_u32_e32 v133, 0x180, v133                         // 000000055FCC: 4B0B0AFF 00000180
	v_add_nc_u32_e32 v130, 0xc0, v130                          // 000000055FD4: 4B0504FF 000000C0
	v_lshlrev_b32_e32 v134, 1, v146                            // 000000055FDC: 310D2481
	v_mad_u32_u24 v146, v146, 48, v173                         // 000000055FE0: D60B0092 06B56192
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055FE8: BF870092
	.long 0xd7006a86                                           // 000000055FEC: D7006A86
	v_cndmask_b32_e32 v1, v131, v134, vcc_lo                   // 000000055FF0: 02030D83
	v_add_co_ci_u32_e64 v135, null, 0, v132, vcc_lo            // 000000055FF4: D5207C87 01AB0880
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v133                        // 000000055FFC: 7C930AFF 0000007F
	global_load_b128 v[134:137], v[134:135], off               // 000000056004: DC5E0000 867C0086
	s_waitcnt vmcnt(0)                                         // 00000005600C: BF8903F7
	ds_store_b16 v146, v134                                    // 000000056010: D87C0000 00008692
	ds_store_b16_d16_hi v146, v134 offset:48                   // 000000056018: DA840030 00008692
	ds_store_b16 v146, v135 offset:96                          // 000000056020: D87C0060 00008792
	ds_store_b16_d16_hi v146, v135 offset:144                  // 000000056028: DA840090 00008792
	ds_store_b16 v146, v136 offset:192                         // 000000056030: D87C00C0 00008892
	ds_store_b16_d16_hi v146, v136 offset:240                  // 000000056038: DA8400F0 00008892
	ds_store_b16 v146, v137 offset:288                         // 000000056040: D87C0120 00008992
	ds_store_b16_d16_hi v146, v137 offset:336                  // 000000056048: DA840150 00008992
	s_or_b32 s4, vcc_lo, s4                                    // 000000056050: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056054: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000056058: 917E047E
	s_cbranch_execnz 65496                                     // 00000005605C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac0>
	s_set_inst_prefetch_distance 0x2                           // 000000056060: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056064: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 000000056068: BF89FC07
	s_barrier                                                  // 00000005606C: BFBD0000
	buffer_gl0_inv                                             // 000000056070: E0AC0000 00000000
	s_clause 0x3                                               // 000000056078: BF850003
	global_load_b128 v[150:153], v[143:144], off offset:16     // 00000005607C: DC5E0010 967C008F
	global_load_b128 v[146:149], v[143:144], off               // 000000056084: DC5E0000 927C008F
	global_load_b128 v[181:184], v[143:144], off offset:48     // 00000005608C: DC5E0030 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:32     // 000000056094: DC5E0020 B17C008F
	ds_load_b128 v[185:188], v159                              // 00000005609C: DBFC0000 B900009F
	ds_load_b128 v[189:192], v159 offset:16                    // 0000000560A4: DBFC0010 BD00009F
	v_mov_b32_e32 v136, v129                                   // 0000000560AC: 7F100381
	v_mov_b32_e32 v130, v129                                   // 0000000560B0: 7F040381
	v_mov_b32_e32 v131, v129                                   // 0000000560B4: 7F060381
	v_mov_b32_e32 v132, v129                                   // 0000000560B8: 7F080381
	v_mov_b32_e32 v133, v129                                   // 0000000560BC: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 0000000560C0: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 0000000560C4: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 0000000560C8: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000560CC: BF870212
	v_mov_b32_e32 v136, v135                                   // 0000000560D0: 7F100387
	v_mov_b32_e32 v135, v134                                   // 0000000560D4: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 0000000560D8: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 0000000560DC: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 0000000560E0: 7F080383
	v_mov_b32_e32 v131, v130                                   // 0000000560E4: 7F060382
	v_mov_b32_e32 v130, v129                                   // 0000000560E8: 7F040381
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000560EC: BF890807
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000560F0: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 0000000560F4: CC414082 1E0B7392
	s_clause 0x1                                               // 0000000560FC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:80     // 000000056100: DC5E0050 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:64     // 000000056108: DC5E0040 927C008F
	ds_load_b128 v[185:188], v159 offset:32                    // 000000056110: DBFC0020 B900009F
	ds_load_b128 v[189:192], v159 offset:48                    // 000000056118: DBFC0030 BD00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000056120: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 000000056124: CC414082 1E0B73B1
	s_clause 0x1                                               // 00000005612C: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:112    // 000000056130: DC5E0070 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:96     // 000000056138: DC5E0060 B17C008F
	ds_load_b128 v[189:192], v159 offset:80                    // 000000056140: DBFC0050 BD00009F
	ds_load_b128 v[185:188], v159 offset:64                    // 000000056148: DBFC0040 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000056150: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 000000056154: CC414082 1E0B7392
	s_clause 0x1                                               // 00000005615C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:144    // 000000056160: DC5E0090 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:128    // 000000056168: DC5E0080 927C008F
	ds_load_b128 v[189:192], v159 offset:112                   // 000000056170: DBFC0070 BD00009F
	ds_load_b128 v[185:188], v159 offset:96                    // 000000056178: DBFC0060 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000056180: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 000000056184: CC414082 1E0B73B1
	s_clause 0x1                                               // 00000005618C: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:176    // 000000056190: DC5E00B0 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:160    // 000000056198: DC5E00A0 B17C008F
	ds_load_b128 v[189:192], v159 offset:144                   // 0000000561A0: DBFC0090 BD00009F
	ds_load_b128 v[185:188], v159 offset:128                   // 0000000561A8: DBFC0080 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000561B0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 0000000561B4: CC414082 1E0B7392
	s_clause 0x1                                               // 0000000561BC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:208    // 0000000561C0: DC5E00D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:192    // 0000000561C8: DC5E00C0 927C008F
	ds_load_b128 v[189:192], v159 offset:176                   // 0000000561D0: DBFC00B0 BD00009F
	ds_load_b128 v[185:188], v159 offset:160                   // 0000000561D8: DBFC00A0 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000561E0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000561E4: CC414082 1E0B73B1
	s_clause 0x1                                               // 0000000561EC: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:240    // 0000000561F0: DC5E00F0 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:224    // 0000000561F8: DC5E00E0 B17C008F
	ds_load_b128 v[189:192], v159 offset:208                   // 000000056200: DBFC00D0 BD00009F
	ds_load_b128 v[185:188], v159 offset:192                   // 000000056208: DBFC00C0 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000056210: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 000000056214: CC414082 1E0B7392
	s_clause 0x1                                               // 00000005621C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:272    // 000000056220: DC5E0110 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:256    // 000000056228: DC5E0100 927C008F
	ds_load_b128 v[189:192], v159 offset:240                   // 000000056230: DBFC00F0 BD00009F
	ds_load_b128 v[185:188], v159 offset:224                   // 000000056238: DBFC00E0 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000056240: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 000000056244: CC414082 1E0B73B1
	s_clause 0x1                                               // 00000005624C: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:304    // 000000056250: DC5E0130 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:288    // 000000056258: DC5E0120 B17C008F
	ds_load_b128 v[189:192], v159 offset:272                   // 000000056260: DBFC0110 BD00009F
	ds_load_b128 v[185:188], v159 offset:256                   // 000000056268: DBFC0100 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000056270: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 000000056274: CC414082 1E0B7392
	s_clause 0x1                                               // 00000005627C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:336    // 000000056280: DC5E0150 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:320    // 000000056288: DC5E0140 927C008F
	ds_load_b128 v[189:192], v159 offset:304                   // 000000056290: DBFC0130 BD00009F
	ds_load_b128 v[185:188], v159 offset:288                   // 000000056298: DBFC0120 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000562A0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000562A4: CC414082 1E0B73B1
	s_clause 0x1                                               // 0000000562AC: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:368    // 0000000562B0: DC5E0170 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:352    // 0000000562B8: DC5E0160 B17C008F
	ds_load_b128 v[189:192], v159 offset:336                   // 0000000562C0: DBFC0150 BD00009F
	ds_load_b128 v[185:188], v159 offset:320                   // 0000000562C8: DBFC0140 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000562D0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 0000000562D4: CC414082 1E0B7392
	s_clause 0x1                                               // 0000000562DC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:400    // 0000000562E0: DC5E0190 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:384    // 0000000562E8: DC5E0180 927C008F
	ds_load_b128 v[189:192], v159 offset:368                   // 0000000562F0: DBFC0170 BD00009F
	ds_load_b128 v[185:188], v159 offset:352                   // 0000000562F8: DBFC0160 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000056300: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 000000056304: CC414082 1E0B73B1
	ds_load_b128 v[181:184], v159 offset:400                   // 00000005630C: DBFC0190 B500009F
	ds_load_b128 v[177:180], v159 offset:384                   // 000000056314: DBFC0180 B100009F
	s_clause 0x1                                               // 00000005631C: BF850001
	global_load_b128 v[189:192], v[143:144], off offset:432    // 000000056320: DC5E01B0 BD7C008F
	global_load_b128 v[185:188], v[143:144], off offset:416    // 000000056328: DC5E01A0 B97C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000056330: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 000000056334: CC414082 1E0B6392
	s_clause 0x1                                               // 00000005633C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:464    // 000000056340: DC5E01D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:448    // 000000056348: DC5E01C0 927C008F
	ds_load_b128 v[181:184], v159 offset:432                   // 000000056350: DBFC01B0 B500009F
	ds_load_b128 v[177:180], v159 offset:416                   // 000000056358: DBFC01A0 B100009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000056360: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[185:192], v[177:184], v[130:137]// 000000056364: CC414082 1E0B63B9
	ds_load_b128 v[181:184], v159 offset:464                   // 00000005636C: DBFC01D0 B500009F
	ds_load_b128 v[177:180], v159 offset:448                   // 000000056374: DBFC01C0 B100009F
	s_clause 0x1                                               // 00000005637C: BF850001
	global_load_b128 v[189:192], v[143:144], off offset:496    // 000000056380: DC5E01F0 BD7C008F
	global_load_b128 v[185:188], v[143:144], off offset:480    // 000000056388: DC5E01E0 B97C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000056390: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 000000056394: CC414082 1E0B6392
	ds_load_b128 v[150:153], v159 offset:496                   // 00000005639C: DBFC01F0 9600009F
	ds_load_b128 v[146:149], v159 offset:480                   // 0000000563A4: DBFC01E0 9200009F
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000563AC: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[185:192], v[146:153], v[130:137]// 0000000563B0: CC414082 1E0B25B9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000563B8: BF870111
	v_dual_mul_f32 v130, 0x3d800000, v130 :: v_dual_mul_f32 v131, 0x3d800000, v131// 0000000563BC: C8C704FF 828306FF 3D800000
	v_mul_f32_e32 v146, 0x3d800000, v133                       // 0000000563C8: 11250AFF 3D800000
	v_mov_b32_e32 v133, 0xffff                                 // 0000000563D0: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000563D8: BF870004
	v_mul_f32_e32 v132, 0x3d800000, v132                       // 0000000563DC: 110908FF 3D800000
	v_dual_mul_f32 v134, 0x3d800000, v134 :: v_dual_mul_f32 v135, 0x3d800000, v135// 0000000563E4: C8C70CFF 86870EFF 3D800000
	v_dual_mul_f32 v136, 0x3d800000, v136 :: v_dual_mul_f32 v137, 0x3d800000, v137// 0000000563F0: C8C710FF 888912FF 3D800000
	ds_store_2addr_b32 v160, v130, v131 offset1:34             // 0000000563FC: D8382200 008382A0
	ds_store_2addr_b32 v160, v132, v146 offset0:68 offset1:102 // 000000056404: D8386644 009284A0
	ds_store_2addr_b32 v160, v134, v135 offset0:136 offset1:170// 00000005640C: D838AA88 008786A0
	ds_store_2addr_b32 v160, v136, v137 offset0:204 offset1:238// 000000056414: D838EECC 008988A0
	s_waitcnt lgkmcnt(0)                                       // 00000005641C: BF89FC07
	s_barrier                                                  // 000000056420: BFBD0000
	buffer_gl0_inv                                             // 000000056424: E0AC0000 00000000
	s_and_saveexec_b32 s4, s23                                 // 00000005642C: BE842017
	s_cbranch_execz 359                                        // 000000056430: BFA50167 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14d0>
	s_lshl_b32 s8, s7, 2                                       // 000000056434: 84088207
	s_mov_b32 s9, exec_lo                                      // 000000056438: BE89007E
	.long 0xd4c1007e                                           // 00000005643C: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 000000056440: 02033D91
	s_cbranch_execz 44                                         // 000000056444: BFA5002C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff8>
	v_ashrrev_i32_e32 v146, 31, v145                           // 000000056448: 3525229F
	s_mov_b32 s24, 0                                           // 00000005644C: BE980080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056450: BF870091
	.long 0xd73c0082                                           // 000000056454: D73C0082
	v_cndmask_b32_e32 v1, 2, v145, vcc_lo                      // 000000056458: 02032282
	.long 0xd7006a82                                           // 00000005645C: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 000000056460: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056464: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 000000056468: D5207C83 01AB078E
	s_branch 11                                                // 000000056470: BFA0000B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfa0>
	s_nop 0                                                    // 000000056474: BF800000
	s_nop 0                                                    // 000000056478: BF800000
	s_nop 0                                                    // 00000005647C: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 000000056480: 8C7E1A7E
	v_mov_b32_e32 v133, v145                                   // 000000056484: 7F0A0391
	v_mov_b32_e32 v145, v132                                   // 000000056488: 7F220384
	s_and_b32 s1, exec_lo, s25                                 // 00000005648C: 8B01197E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000056490: BF870499
	s_or_b32 s24, s1, s24                                      // 000000056494: 8C181801
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 000000056498: 917E187E
	s_cbranch_execz 20                                         // 00000005649C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff0>
	global_load_b32 v132, v[130:131], off                      // 0000000564A0: DC520000 847C0082
	s_or_b32 s25, s25, exec_lo                                 // 0000000564A8: 8C197E19
	s_waitcnt vmcnt(0)                                         // 0000000564AC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s8, v132                          // 0000000564B0: 7C890808
	s_and_saveexec_b32 s26, vcc_lo                             // 0000000564B4: BE9A206A
	s_cbranch_execz 65521                                      // 0000000564B8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	v_dual_mov_b32 v145, v158 :: v_dual_add_nc_u32 v132, 1, v145// 0000000564BC: CA20019E 91852281
	.long 0xd7000182                                           // 0000000564C4: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 0000000564C8: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000564CC: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 0000000564D0: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v158, v132                        // 0000000564D8: 7C95099E
	s_and_not1_b32 s1, s25, exec_lo                            // 0000000564DC: 91017E19
	s_and_b32 s25, vcc_lo, exec_lo                             // 0000000564E0: 8B197E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000564E4: BF870009
	s_or_b32 s25, s1, s25                                      // 0000000564E8: 8C191901
	s_branch 65508                                             // 0000000564EC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000564F0: 8C7E187E
	v_mov_b32_e32 v145, v133                                   // 0000000564F4: 7F220385
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000564F8: 8C7E097E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000564FC: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v145       // 000000056500: CA10008F 85820191
	s_mov_b32 s1, exec_lo                                      // 000000056508: BE81007E
	.long 0xd4c1007e                                           // 00000005650C: D4C1007E
	v_cndmask_b32_e32 v1, s8, v161, vcc_lo                     // 000000056510: 02034208
	s_cbranch_execz 62                                         // 000000056514: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1110>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v145        // 000000056518: CA100080 85820191
	s_mov_b32 s9, exec_lo                                      // 000000056520: BE89007E
	.long 0xd4c1007e                                           // 000000056524: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 000000056528: 02033D91
	s_cbranch_execz 54                                         // 00000005652C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1108>
	v_mov_b32_e32 v130, v145                                   // 000000056530: 7F040391
	s_mov_b32 s25, 0                                           // 000000056534: BE990080
	s_set_inst_prefetch_distance 0x1                           // 000000056538: BF840001
	s_branch 10                                                // 00000005653C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1068>
	s_or_b32 exec_lo, exec_lo, s28                             // 000000056540: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000056544: BF870499
	s_and_b32 s28, exec_lo, s27                                // 000000056548: 8B1C1B7E
	s_or_b32 s25, s28, s25                                     // 00000005654C: 8C19191C
	s_and_not1_b32 s24, s24, exec_lo                           // 000000056550: 91187E18
	s_and_b32 s28, s26, exec_lo                                // 000000056554: 8B1C7E1A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056558: BF870009
	s_or_b32 s24, s24, s28                                     // 00000005655C: 8C181C18
	s_and_not1_b32 exec_lo, exec_lo, s25                       // 000000056560: 917E197E
	s_cbranch_execz 28                                         // 000000056564: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000056568: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 00000005656C: 7F060382
	s_or_b32 s26, s26, exec_lo                                 // 000000056570: 8C1A7E1A
	s_or_b32 s27, s27, exec_lo                                 // 000000056574: 8C1B7E1B
	s_mov_b32 s28, exec_lo                                     // 000000056578: BE9C007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000005657C: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056580: BF870091
	.long 0xd73c0084                                           // 000000056584: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 000000056588: 02030682
	.long 0xd7006a84                                           // 00000005658C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 000000056590: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056594: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 000000056598: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 0000000565A0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 0000000565A8: BF8903F7
	.long 0xd4c4007e                                           // 0000000565AC: D4C4007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 0000000565B0: 02030808
	s_cbranch_execz 65506                                      // 0000000565B4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000565B8: 4B050681
	s_and_not1_b32 s27, s27, exec_lo                           // 0000000565BC: 911B7E1B
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000565C0: 911A7E1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000565C4: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000565C8: 7C95059E
	s_and_b32 s29, vcc_lo, exec_lo                             // 0000000565CC: 8B1D7E6A
	s_or_b32 s27, s27, s29                                     // 0000000565D0: 8C1B1D1B
	s_branch 65498                                             // 0000000565D4: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	s_set_inst_prefetch_distance 0x2                           // 0000000565D8: BF840002
	s_or_b32 exec_lo, exec_lo, s25                             // 0000000565DC: 8C7E197E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v158        // 0000000565E0: CA100080 8582019E
	s_and_saveexec_b32 s25, s24                                // 0000000565E8: BE992018
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000565EC: BF870009
	s_xor_b32 s24, exec_lo, s25                                // 0000000565F0: 8D18197E
	v_cmp_eq_u32_e32 vcc_lo, s8, v132                          // 0000000565F4: 7C950808
	v_mov_b32_e32 v130, v131                                   // 0000000565F8: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 0000000565FC: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s24                             // 000000056604: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056608: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 00000005660C: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056610: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056614: 8C7E017E
	s_or_b32 s9, s8, 1                                         // 000000056618: 8C098108
	s_mov_b32 s1, exec_lo                                      // 00000005661C: BE81007E
	.long 0xd4c6007e                                           // 000000056620: D4C6007E
	v_cndmask_b32_e32 v1, s9, v161, vcc_lo                     // 000000056624: 02034209
	s_xor_b32 s1, exec_lo, s1                                  // 000000056628: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 00000005662C: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 000000056634: BE813001
	s_cbranch_execz 70                                         // 000000056638: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1254>
	s_mov_b32 s24, exec_lo                                     // 00000005663C: BE98007E
	.long 0xd4c1007e                                           // 000000056640: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 000000056644: 02033D82
	s_cbranch_execz 64                                         // 000000056648: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x124c>
	s_mov_b32 s26, 0                                           // 00000005664C: BE9A0080
	s_set_inst_prefetch_distance 0x1                           // 000000056650: BF840001
	s_branch 20                                                // 000000056654: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11a8>
	s_nop 0                                                    // 000000056658: BF800000
	s_nop 0                                                    // 00000005665C: BF800000
	s_nop 0                                                    // 000000056660: BF800000
	s_nop 0                                                    // 000000056664: BF800000
	s_nop 0                                                    // 000000056668: BF800000
	s_nop 0                                                    // 00000005666C: BF800000
	s_nop 0                                                    // 000000056670: BF800000
	s_nop 0                                                    // 000000056674: BF800000
	s_nop 0                                                    // 000000056678: BF800000
	s_nop 0                                                    // 00000005667C: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 000000056680: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000056684: BF870499
	s_and_b32 s29, exec_lo, s28                                // 000000056688: 8B1D1C7E
	s_or_b32 s26, s29, s26                                     // 00000005668C: 8C1A1A1D
	s_and_not1_b32 s25, s25, exec_lo                           // 000000056690: 91197E19
	s_and_b32 s29, s27, exec_lo                                // 000000056694: 8B1D7E1B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056698: BF870009
	s_or_b32 s25, s25, s29                                     // 00000005669C: 8C191D19
	s_and_not1_b32 exec_lo, exec_lo, s26                       // 0000000566A0: 917E1A7E
	s_cbranch_execz 27                                         // 0000000566A4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1214>
	v_mov_b32_e32 v131, v130                                   // 0000000566A8: 7F060382
	s_or_b32 s27, s27, exec_lo                                 // 0000000566AC: 8C1B7E1B
	s_or_b32 s28, s28, exec_lo                                 // 0000000566B0: 8C1C7E1C
	s_mov_b32 s29, exec_lo                                     // 0000000566B4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000566B8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000566BC: 3509069F
	.long 0xd73c0086                                           // 0000000566C0: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000566C4: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000566C8: BF870091
	.long 0xd7006a86                                           // 0000000566CC: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 0000000566D0: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 0000000566D4: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 0000000566DC: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 0000000566E4: BF8903F7
	.long 0xd4c6007e                                           // 0000000566E8: D4C6007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 0000000566EC: 02030808
	s_cbranch_execz 65507                                      // 0000000566F0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000566F4: 4B050681
	s_and_not1_b32 s28, s28, exec_lo                           // 0000000566F8: 911C7E1C
	s_and_not1_b32 s27, s27, exec_lo                           // 0000000566FC: 911B7E1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000056700: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 000000056704: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 000000056708: 8B1E7E6A
	s_or_b32 s28, s28, s30                                     // 00000005670C: 8C1C1E1C
	s_branch 65499                                             // 000000056710: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	s_set_inst_prefetch_distance 0x2                           // 000000056714: BF840002
	s_or_b32 exec_lo, exec_lo, s26                             // 000000056718: 8C7E1A7E
	v_mov_b32_e32 v130, v158                                   // 00000005671C: 7F04039E
	s_and_saveexec_b32 s26, s25                                // 000000056720: BE9A2019
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056724: BF870009
	s_xor_b32 s25, exec_lo, s26                                // 000000056728: 8D191A7E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 00000005672C: 7C950809
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 000000056730: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005673C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 000000056740: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 000000056744: 7F040383
	s_or_b32 exec_lo, exec_lo, s25                             // 000000056748: 8C7E197E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005674C: BF870009
	s_or_b32 exec_lo, exec_lo, s24                             // 000000056750: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056754: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056758: 8C7E017E
	s_or_b32 s9, s8, 2                                         // 00000005675C: 8C098208
	s_mov_b32 s1, exec_lo                                      // 000000056760: BE81007E
	.long 0xd4c6007e                                           // 000000056764: D4C6007E
	v_cndmask_b32_e32 v1, s9, v161, vcc_lo                     // 000000056768: 02034209
	s_xor_b32 s1, exec_lo, s1                                  // 00000005676C: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 000000056770: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 000000056778: BE813001
	s_cbranch_execz 69                                         // 00000005677C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1394>
	s_mov_b32 s24, exec_lo                                     // 000000056780: BE98007E
	.long 0xd4c1007e                                           // 000000056784: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 000000056788: 02033D82
	s_cbranch_execz 63                                         // 00000005678C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x138c>
	s_mov_b32 s26, 0                                           // 000000056790: BE9A0080
	s_set_inst_prefetch_distance 0x1                           // 000000056794: BF840001
	s_branch 19                                                // 000000056798: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12e8>
	s_nop 0                                                    // 00000005679C: BF800000
	s_nop 0                                                    // 0000000567A0: BF800000
	s_nop 0                                                    // 0000000567A4: BF800000
	s_nop 0                                                    // 0000000567A8: BF800000
	s_nop 0                                                    // 0000000567AC: BF800000
	s_nop 0                                                    // 0000000567B0: BF800000
	s_nop 0                                                    // 0000000567B4: BF800000
	s_nop 0                                                    // 0000000567B8: BF800000
	s_nop 0                                                    // 0000000567BC: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 0000000567C0: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000567C4: BF870499
	s_and_b32 s29, exec_lo, s28                                // 0000000567C8: 8B1D1C7E
	s_or_b32 s26, s29, s26                                     // 0000000567CC: 8C1A1A1D
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000567D0: 91197E19
	s_and_b32 s29, s27, exec_lo                                // 0000000567D4: 8B1D7E1B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000567D8: BF870009
	s_or_b32 s25, s25, s29                                     // 0000000567DC: 8C191D19
	s_and_not1_b32 exec_lo, exec_lo, s26                       // 0000000567E0: 917E1A7E
	s_cbranch_execz 27                                         // 0000000567E4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1354>
	v_mov_b32_e32 v131, v130                                   // 0000000567E8: 7F060382
	s_or_b32 s27, s27, exec_lo                                 // 0000000567EC: 8C1B7E1B
	s_or_b32 s28, s28, exec_lo                                 // 0000000567F0: 8C1C7E1C
	s_mov_b32 s29, exec_lo                                     // 0000000567F4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000567F8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000567FC: 3509069F
	.long 0xd73c0086                                           // 000000056800: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 000000056804: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056808: BF870091
	.long 0xd7006a86                                           // 00000005680C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 000000056810: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 000000056814: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 00000005681C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 000000056824: BF8903F7
	.long 0xd4c4007e                                           // 000000056828: D4C4007E
	v_cndmask_b32_e32 v1, s9, v132, vcc_lo                     // 00000005682C: 02030809
	s_cbranch_execz 65507                                      // 000000056830: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 000000056834: 4B050681
	s_and_not1_b32 s28, s28, exec_lo                           // 000000056838: 911C7E1C
	s_and_not1_b32 s27, s27, exec_lo                           // 00000005683C: 911B7E1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000056840: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 000000056844: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 000000056848: 8B1E7E6A
	s_or_b32 s28, s28, s30                                     // 00000005684C: 8C1C1E1C
	s_branch 65499                                             // 000000056850: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	s_set_inst_prefetch_distance 0x2                           // 000000056854: BF840002
	s_or_b32 exec_lo, exec_lo, s26                             // 000000056858: 8C7E1A7E
	v_mov_b32_e32 v130, v158                                   // 00000005685C: 7F04039E
	s_and_saveexec_b32 s26, s25                                // 000000056860: BE9A2019
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056864: BF870009
	s_xor_b32 s25, exec_lo, s26                                // 000000056868: 8D191A7E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 00000005686C: 7C950809
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 000000056870: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005687C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 000000056880: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 000000056884: 7F040383
	s_or_b32 exec_lo, exec_lo, s25                             // 000000056888: 8C7E197E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005688C: BF870009
	s_or_b32 exec_lo, exec_lo, s24                             // 000000056890: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056894: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056898: 8C7E017E
	s_or_b32 s8, s8, 3                                         // 00000005689C: 8C088308
	s_mov_b32 s1, exec_lo                                      // 0000000568A0: BE81007E
	.long 0xd4c6007e                                           // 0000000568A4: D4C6007E
	v_cndmask_b32_e32 v1, s8, v161, vcc_lo                     // 0000000568A8: 02034208
	s_xor_b32 s1, exec_lo, s1                                  // 0000000568AC: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 0000000568B0: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 0000000568B8: BE813001
	s_cbranch_execz 66                                         // 0000000568BC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c8>
	s_mov_b32 s9, exec_lo                                      // 0000000568C0: BE89007E
	.long 0xd4c1007e                                           // 0000000568C4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 0000000568C8: 02033D82
	s_cbranch_execz 60                                         // 0000000568CC: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	s_mov_b32 s25, 0                                           // 0000000568D0: BE990080
	s_set_inst_prefetch_distance 0x1                           // 0000000568D4: BF840001
	s_branch 19                                                // 0000000568D8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1428>
	s_nop 0                                                    // 0000000568DC: BF800000
	s_nop 0                                                    // 0000000568E0: BF800000
	s_nop 0                                                    // 0000000568E4: BF800000
	s_nop 0                                                    // 0000000568E8: BF800000
	s_nop 0                                                    // 0000000568EC: BF800000
	s_nop 0                                                    // 0000000568F0: BF800000
	s_nop 0                                                    // 0000000568F4: BF800000
	s_nop 0                                                    // 0000000568F8: BF800000
	s_nop 0                                                    // 0000000568FC: BF800000
	s_or_b32 exec_lo, exec_lo, s28                             // 000000056900: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000056904: BF870499
	s_and_b32 s28, exec_lo, s27                                // 000000056908: 8B1C1B7E
	s_or_b32 s25, s28, s25                                     // 00000005690C: 8C19191C
	s_and_not1_b32 s24, s24, exec_lo                           // 000000056910: 91187E18
	s_and_b32 s28, s26, exec_lo                                // 000000056914: 8B1C7E1A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056918: BF870009
	s_or_b32 s24, s24, s28                                     // 00000005691C: 8C181C18
	s_and_not1_b32 exec_lo, exec_lo, s25                       // 000000056920: 917E197E
	s_cbranch_execz 26                                         // 000000056924: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1490>
	v_ashrrev_i32_e32 v131, 31, v130                           // 000000056928: 3507049F
	s_or_b32 s26, s26, exec_lo                                 // 00000005692C: 8C1A7E1A
	s_or_b32 s27, s27, exec_lo                                 // 000000056930: 8C1B7E1B
	s_mov_b32 s28, exec_lo                                     // 000000056934: BE9C007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056938: BF870091
	.long 0xd73c0083                                           // 00000005693C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 000000056940: 02030482
	.long 0xd7006a83                                           // 000000056944: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 000000056948: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005694C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 000000056950: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 000000056958: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 000000056960: BF8903F7
	.long 0xd4c4007e                                           // 000000056964: D4C4007E
	v_cndmask_b32_e32 v1, s8, v131, vcc_lo                     // 000000056968: 02030608
	s_cbranch_execz 65508                                      // 00000005696C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	v_add_nc_u32_e32 v130, 1, v130                             // 000000056970: 4B050481
	s_and_not1_b32 s27, s27, exec_lo                           // 000000056974: 911B7E1B
	s_and_not1_b32 s26, s26, exec_lo                           // 000000056978: 911A7E1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005697C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 000000056980: 7C95059E
	s_and_b32 s29, vcc_lo, exec_lo                             // 000000056984: 8B1D7E6A
	s_or_b32 s27, s27, s29                                     // 000000056988: 8C1B1D1B
	s_branch 65500                                             // 00000005698C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	s_set_inst_prefetch_distance 0x2                           // 000000056990: BF840002
	s_or_b32 exec_lo, exec_lo, s25                             // 000000056994: 8C7E197E
	s_and_saveexec_b32 s25, s24                                // 000000056998: BE992018
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005699C: BF870009
	s_xor_b32 s24, exec_lo, s25                                // 0000000569A0: 8D18197E
	v_cmp_eq_u32_e32 vcc_lo, s8, v131                          // 0000000569A4: 7C950608
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 0000000569A8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000569B4: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000569B8: 390B0B82
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000569BC: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000569C0: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000569C4: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000569C8: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000569CC: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000569D0: BF870009
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000569D4: 8C7E047E
	s_and_saveexec_b32 s4, s3                                  // 0000000569D8: BE842003
	s_cbranch_execz 1029                                       // 0000000569DC: BFA50405 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x24f4>
	ds_load_b32 v131, v163                                     // 0000000569E0: D8D80000 830000A3
	v_and_b32_e32 v130, 1, v133                                // 0000000569E8: 37050A81
	v_cmp_le_i32_e32 vcc_lo, s2, v162                          // 0000000569EC: 7C874402
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000569F0: BF870002
	.long 0xd44a0001                                           // 0000000569F4: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000569F8: 02030481
	s_and_b32 s37, vcc_lo, s1                                  // 0000000569FC: 8B25016A
	s_waitcnt lgkmcnt(0)                                       // 000000056A00: BF89FC07
	v_mov_b32_e32 v130, v131                                   // 000000056A04: 7F040383
	s_and_saveexec_b32 s1, s37                                 // 000000056A08: BE812025
	s_cbranch_execz 7                                          // 000000056A0C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x152c>
	ds_load_b32 v130, v164                                     // 000000056A10: D8D80000 820000A4
	v_max_f32_e32 v132, v131, v131                             // 000000056A18: 21090783
	s_waitcnt lgkmcnt(0)                                       // 000000056A1C: BF89FC07
	v_max_f32_e32 v130, v130, v130                             // 000000056A20: 21050582
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056A24: BF870001
	v_max_f32_e32 v130, v132, v130                             // 000000056A28: 21050584
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056A2C: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 000000056A30: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s2, v162                          // 000000056A34: 7C834402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000056A38: BF8704A2
	.long 0xd44d0001                                           // 000000056A3C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056A40: 02030880
	s_and_b32 s36, vcc_lo, s1                                  // 000000056A44: 8B24016A
	s_and_saveexec_b32 s1, s36                                 // 000000056A48: BE812024
	s_cbranch_execz 7                                          // 000000056A4C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x156c>
	ds_load_b32 v132, v164 offset:4                            // 000000056A50: D8D80004 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056A58: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056A5C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056A60: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056A64: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056A68: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056A6C: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 000000056A70: 37090A84
	s_or_b32 s1, s2, 2                                         // 000000056A74: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056A78: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000056A7C: 7C874401
	.long 0xd44d0001                                           // 000000056A80: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056A84: 02030880
	s_and_b32 s35, vcc_lo, s1                                  // 000000056A88: 8B23016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056A8C: BF870009
	s_and_saveexec_b32 s1, s35                                 // 000000056A90: BE812023
	s_cbranch_execz 7                                          // 000000056A94: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15b4>
	ds_load_b32 v132, v164 offset:8                            // 000000056A98: D8D80008 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056AA0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056AA4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056AA8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056AAC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056AB0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056AB4: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 000000056AB8: 37090A88
	s_or_b32 s1, s2, 3                                         // 000000056ABC: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056AC0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000056AC4: 7C874401
	.long 0xd44d0001                                           // 000000056AC8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056ACC: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 000000056AD0: 8B22016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056AD4: BF870009
	s_and_saveexec_b32 s1, s34                                 // 000000056AD8: BE812022
	s_cbranch_execz 7                                          // 000000056ADC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15fc>
	ds_load_b32 v132, v164 offset:12                           // 000000056AE0: D8D8000C 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056AE8: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056AEC: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056AF0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056AF4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056AF8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056AFC: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 000000056B00: 37090A90
	s_or_b32 s1, s2, 4                                         // 000000056B04: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056B08: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000056B0C: 7C874401
	.long 0xd44d0001                                           // 000000056B10: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056B14: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 000000056B18: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056B1C: BF870009
	s_and_saveexec_b32 s1, s33                                 // 000000056B20: BE812021
	s_cbranch_execz 7                                          // 000000056B24: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1644>
	ds_load_b32 v132, v164 offset:16                           // 000000056B28: D8D80010 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056B30: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056B34: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056B38: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056B3C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056B40: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056B44: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 000000056B48: 37090AA0
	s_or_b32 s1, s2, 5                                         // 000000056B4C: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056B50: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000056B54: 7C874401
	.long 0xd44d0001                                           // 000000056B58: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056B5C: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 000000056B60: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056B64: BF870009
	s_and_saveexec_b32 s1, s31                                 // 000000056B68: BE81201F
	s_cbranch_execz 7                                          // 000000056B6C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x168c>
	ds_load_b32 v132, v164 offset:20                           // 000000056B70: D8D80014 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056B78: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056B7C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056B80: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056B84: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056B88: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056B8C: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 000000056B90: 37090AC0
	s_or_b32 s1, s2, 6                                         // 000000056B94: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056B98: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000056B9C: 7C874401
	.long 0xd44d0001                                           // 000000056BA0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056BA4: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 000000056BA8: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056BAC: BF870009
	s_and_saveexec_b32 s1, s30                                 // 000000056BB0: BE81201E
	s_cbranch_execz 7                                          // 000000056BB4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16d4>
	ds_load_b32 v132, v164 offset:24                           // 000000056BB8: D8D80018 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056BC0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056BC4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056BC8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056BCC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056BD0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056BD4: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 000000056BD8: 37090AFF 00000080
	s_or_b32 s1, s2, 7                                         // 000000056BE0: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056BE4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000056BE8: 7C874401
	.long 0xd44d0001                                           // 000000056BEC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056BF0: 02030880
	s_and_b32 s29, vcc_lo, s1                                  // 000000056BF4: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056BF8: BF870009
	s_and_saveexec_b32 s1, s29                                 // 000000056BFC: BE81201D
	s_cbranch_execz 7                                          // 000000056C00: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1720>
	ds_load_b32 v132, v164 offset:28                           // 000000056C04: D8D8001C 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056C0C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056C10: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056C14: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056C18: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056C1C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056C20: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 000000056C24: 37090AFF 00000100
	s_or_b32 s1, s2, 8                                         // 000000056C2C: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056C30: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000056C34: 7C874401
	.long 0xd44d0001                                           // 000000056C38: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056C3C: 02030880
	s_and_b32 s28, vcc_lo, s1                                  // 000000056C40: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056C44: BF870009
	s_and_saveexec_b32 s1, s28                                 // 000000056C48: BE81201C
	s_cbranch_execz 7                                          // 000000056C4C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x176c>
	ds_load_b32 v132, v164 offset:32                           // 000000056C50: D8D80020 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056C58: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056C5C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056C60: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056C64: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056C68: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056C6C: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 000000056C70: 37090AFF 00000200
	s_or_b32 s1, s2, 9                                         // 000000056C78: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056C7C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000056C80: 7C874401
	.long 0xd44d0001                                           // 000000056C84: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056C88: 02030880
	s_and_b32 s27, vcc_lo, s1                                  // 000000056C8C: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056C90: BF870009
	s_and_saveexec_b32 s1, s27                                 // 000000056C94: BE81201B
	s_cbranch_execz 7                                          // 000000056C98: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17b8>
	ds_load_b32 v132, v164 offset:36                           // 000000056C9C: D8D80024 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056CA4: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056CA8: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056CAC: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056CB0: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056CB4: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056CB8: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 000000056CBC: 37090AFF 00000400
	s_or_b32 s1, s2, 10                                        // 000000056CC4: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056CC8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000056CCC: 7C874401
	.long 0xd44d0001                                           // 000000056CD0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056CD4: 02030880
	s_and_b32 s26, vcc_lo, s1                                  // 000000056CD8: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056CDC: BF870009
	s_and_saveexec_b32 s1, s26                                 // 000000056CE0: BE81201A
	s_cbranch_execz 7                                          // 000000056CE4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1804>
	ds_load_b32 v132, v164 offset:40                           // 000000056CE8: D8D80028 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056CF0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056CF4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056CF8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056CFC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056D00: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056D04: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 000000056D08: 37090AFF 00000800
	s_or_b32 s1, s2, 11                                        // 000000056D10: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056D14: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000056D18: 7C874401
	.long 0xd44d0001                                           // 000000056D1C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056D20: 02030880
	s_and_b32 s25, vcc_lo, s1                                  // 000000056D24: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056D28: BF870009
	s_and_saveexec_b32 s1, s25                                 // 000000056D2C: BE812019
	s_cbranch_execz 7                                          // 000000056D30: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1850>
	ds_load_b32 v132, v164 offset:44                           // 000000056D34: D8D8002C 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056D3C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056D40: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056D44: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056D48: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056D4C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056D50: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 000000056D54: 37090AFF 00001000
	s_or_b32 s1, s2, 12                                        // 000000056D5C: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056D60: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000056D64: 7C874401
	.long 0xd44d0001                                           // 000000056D68: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056D6C: 02030880
	s_and_b32 s24, vcc_lo, s1                                  // 000000056D70: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056D74: BF870009
	s_and_saveexec_b32 s1, s24                                 // 000000056D78: BE812018
	s_cbranch_execz 7                                          // 000000056D7C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x189c>
	ds_load_b32 v132, v164 offset:48                           // 000000056D80: D8D80030 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056D88: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056D8C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056D90: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056D94: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056D98: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056D9C: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 000000056DA0: 37090AFF 00002000
	s_or_b32 s1, s2, 13                                        // 000000056DA8: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056DAC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000056DB0: 7C874401
	.long 0xd44d0001                                           // 000000056DB4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056DB8: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 000000056DBC: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056DC0: BF870009
	s_and_saveexec_b32 s1, s9                                  // 000000056DC4: BE812009
	s_cbranch_execz 7                                          // 000000056DC8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18e8>
	ds_load_b32 v132, v164 offset:52                           // 000000056DCC: D8D80034 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056DD4: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056DD8: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056DDC: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056DE0: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056DE4: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056DE8: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 000000056DEC: 37090AFF 00004000
	s_or_b32 s1, s2, 14                                        // 000000056DF4: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056DF8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 000000056DFC: 7C874401
	.long 0xd44d0001                                           // 000000056E00: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056E04: 02030880
	s_and_b32 s8, vcc_lo, s1                                   // 000000056E08: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056E0C: BF870009
	s_and_saveexec_b32 s1, s8                                  // 000000056E10: BE812008
	s_cbranch_execz 7                                          // 000000056E14: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1934>
	ds_load_b32 v132, v164 offset:56                           // 000000056E18: D8D80038 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056E20: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056E24: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056E28: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056E2C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056E30: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 000000056E34: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 000000056E38: 37090AFF 00008000
	s_or_b32 s2, s2, 15                                        // 000000056E40: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056E44: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v162                          // 000000056E48: 7C874402
	.long 0xd44d0001                                           // 000000056E4C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000056E50: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 000000056E54: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000056E58: BF870009
	s_and_saveexec_b32 s2, s1                                  // 000000056E5C: BE822001
	s_cbranch_execz 7                                          // 000000056E60: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1980>
	ds_load_b32 v132, v164 offset:60                           // 000000056E64: D8D8003C 840000A4
	v_max_f32_e32 v130, v130, v130                             // 000000056E6C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 000000056E70: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 000000056E74: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056E78: BF870001
	v_max_f32_e32 v130, v130, v132                             // 000000056E7C: 21050982
	s_or_b32 exec_lo, exec_lo, s2                              // 000000056E80: 8C7E027E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 000000056E84: CA100080 84840080
	s_and_saveexec_b32 s2, s37                                 // 000000056E8C: BE822025
	s_cbranch_execz 30                                         // 000000056E90: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a0c>
	ds_load_b32 v133, v164                                     // 000000056E94: D8D80000 850000A4
	s_waitcnt lgkmcnt(0)                                       // 000000056E9C: BF89FC07
	v_sub_f32_e32 v133, v133, v130                             // 000000056EA0: 090B0585
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056EA4: BF870091
	v_mul_f32_e32 v134, 0x3fb8aa3b, v133                       // 000000056EA8: 110D0AFF 3FB8AA3B
	v_fma_f32 v135, 0x3fb8aa3b, v133, -v134                    // 000000056EB0: D6130087 861B0AFF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 000000056EBC: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000056EC0: BF870221
	v_sub_f32_e32 v134, v134, v136                             // 000000056EC4: 090D1186
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 000000056EC8: 7C370AFF C2CE8ED0
	v_fmac_f32_e32 v135, 0x32a5705f, v133                      // 000000056ED0: 570F0AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000056ED8: BF870121
	v_add_f32_e32 v134, v134, v135                             // 000000056EDC: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 000000056EE0: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 000000056EE4: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056EE8: BF870095
	.long 0xd71c0086                                           // 000000056EEC: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 000000056EF0: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 000000056EF4: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 000000056EF8: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000056F00: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v134, vcc_lo           // 000000056F04: 030B0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000056F0C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056F10: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 000000056F14: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 000000056F1C: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v165, v134                             // 000000056F28: DA840000 000086A5
	s_and_saveexec_b32 s2, s36                                 // 000000056F30: BE822024
	s_cbranch_execz 30                                         // 000000056F34: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ab0>
	ds_load_b32 v132, v164 offset:4                            // 000000056F38: D8D80004 840000A4
	s_waitcnt lgkmcnt(0)                                       // 000000056F40: BF89FC07
	v_sub_f32_e32 v132, v132, v130                             // 000000056F44: 09090584
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000056F48: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v132                       // 000000056F4C: 110D08FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v132                 // 000000056F54: 7C3708FF C2CE8ED0
	v_fma_f32 v135, 0x3fb8aa3b, v132, -v134                    // 000000056F5C: D6130087 861B08FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 000000056F68: 7F104786
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000056F6C: BF870112
	v_fmac_f32_e32 v135, 0x32a5705f, v132                      // 000000056F70: 570F08FF 32A5705F
	v_sub_f32_e32 v134, v134, v136                             // 000000056F78: 090D1186
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000056F7C: BF870121
	v_add_f32_e32 v134, v134, v135                             // 000000056F80: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 000000056F84: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 000000056F88: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056F8C: BF870095
	.long 0xd71c0086                                           // 000000056F90: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 000000056F94: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 000000056F98: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v132                 // 000000056F9C: 7C3D08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000056FA4: BF870002
	v_cndmask_b32_e32 v132, 0x7f800000, v134, vcc_lo           // 000000056FA8: 03090CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000056FB0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000056FB4: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 000000056FB8: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 000000056FC0: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 000000056FC4: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 000000056FD0: 7F0C0280
	ds_store_b16_d16_hi v165, v136 offset:2                    // 000000056FD4: DA840002 000088A5
	s_and_saveexec_b32 s2, s35                                 // 000000056FDC: BE822023
	s_cbranch_execz 29                                         // 000000056FE0: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b58>
	ds_load_b32 v135, v164 offset:8                            // 000000056FE4: D8D80008 870000A4
	s_waitcnt lgkmcnt(0)                                       // 000000056FEC: BF89FC07
	v_sub_f32_e32 v135, v135, v130                             // 000000056FF0: 090F0587
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056FF4: BF870091
	v_mul_f32_e32 v136, 0x3fb8aa3b, v135                       // 000000056FF8: 11110EFF 3FB8AA3B
	v_fma_f32 v137, 0x3fb8aa3b, v135, -v136                    // 000000057000: D6130089 86230EFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 00000005700C: 7F244788
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057010: BF870091
	v_dual_fmac_f32 v137, 0x32a5705f, v135 :: v_dual_sub_f32 v136, v136, v146// 000000057014: C80B0EFF 89892588 32A5705F
	v_add_f32_e32 v136, v136, v137                             // 000000057020: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 000000057024: 7F121192
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 000000057028: 7C370EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000057030: BF870293
	v_exp_f32_e32 v136, v136                                   // 000000057034: 7F104B88
	.long 0xd71c0088                                           // 000000057038: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 00000005703C: 02031388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057040: BF870121
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 000000057044: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 000000057048: 7C3D0EFF 42B17218
	v_cndmask_b32_e32 v135, 0x7f800000, v136, vcc_lo           // 000000057050: 030F10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000057058: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005705C: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 000000057060: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 000000057068: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v165, v136 offset:4                    // 000000057074: DA840004 000088A5
	s_and_saveexec_b32 s2, s34                                 // 00000005707C: BE822022
	s_cbranch_execz 30                                         // 000000057080: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1bfc>
	ds_load_b32 v134, v164 offset:12                           // 000000057084: D8D8000C 860000A4
	s_waitcnt lgkmcnt(0)                                       // 00000005708C: BF89FC07
	v_sub_f32_e32 v134, v134, v130                             // 000000057090: 090D0586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057094: BF870121
	v_mul_f32_e32 v136, 0x3fb8aa3b, v134                       // 000000057098: 11110CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 0000000570A0: 7C370CFF C2CE8ED0
	v_fma_f32 v137, 0x3fb8aa3b, v134, -v136                    // 0000000570A8: D6130089 86230CFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 0000000570B4: 7F244788
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000570B8: BF870112
	v_fmac_f32_e32 v137, 0x32a5705f, v134                      // 0000000570BC: 57130CFF 32A5705F
	v_sub_f32_e32 v136, v136, v146                             // 0000000570C4: 09112588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000570C8: BF870121
	v_add_f32_e32 v136, v136, v137                             // 0000000570CC: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 0000000570D0: 7F121192
	v_exp_f32_e32 v136, v136                                   // 0000000570D4: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000570D8: BF870095
	.long 0xd71c0088                                           // 0000000570DC: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 0000000570E0: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000000570E4: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 0000000570E8: 7C3D0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000570F0: BF870002
	v_cndmask_b32_e32 v134, 0x7f800000, v136, vcc_lo           // 0000000570F4: 030D10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000570FC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057100: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 000000057104: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 00000005710C: 7F120280
	v_add3_u32 v146, v134, v136, 0x7fff                        // 000000057110: D6550092 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 00000005711C: 7F100280
	ds_store_b16_d16_hi v165, v146 offset:6                    // 000000057120: DA840006 000092A5
	s_and_saveexec_b32 s2, s33                                 // 000000057128: BE822021
	s_cbranch_execz 30                                         // 00000005712C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ca8>
	ds_load_b32 v137, v164 offset:16                           // 000000057130: D8D80010 890000A4
	s_waitcnt lgkmcnt(0)                                       // 000000057138: BF89FC07
	v_sub_f32_e32 v137, v137, v130                             // 00000005713C: 09130589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057140: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 000000057144: 112512FF 3FB8AA3B
	v_fma_f32 v147, 0x3fb8aa3b, v137, -v146                    // 00000005714C: D6130093 864B12FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 000000057158: 7F284792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005715C: BF870221
	v_sub_f32_e32 v146, v146, v148                             // 000000057160: 09252992
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v137                 // 000000057164: 7C3712FF C2CE8ED0
	v_fmac_f32_e32 v147, 0x32a5705f, v137                      // 00000005716C: 572712FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057174: BF870121
	v_add_f32_e32 v146, v146, v147                             // 000000057178: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 00000005717C: 7F261194
	v_exp_f32_e32 v146, v146                                   // 000000057180: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057184: BF870095
	.long 0xd71c0092                                           // 000000057188: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 00000005718C: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 000000057190: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v137                 // 000000057194: 7C3D12FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000005719C: BF870002
	v_cndmask_b32_e32 v137, 0x7f800000, v146, vcc_lo           // 0000000571A0: 031324FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000571A8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000571AC: BF870091
	v_bfe_u32 v146, v137, 16, 1                                // 0000000571B0: D6100092 02052189
	v_add3_u32 v146, v137, v146, 0x7fff                        // 0000000571B8: D6550092 03FF2589 00007FFF
	ds_store_b16_d16_hi v165, v146 offset:8                    // 0000000571C4: DA840008 000092A5
	s_and_saveexec_b32 s2, s31                                 // 0000000571CC: BE82201F
	s_cbranch_execz 30                                         // 0000000571D0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d4c>
	ds_load_b32 v136, v164 offset:20                           // 0000000571D4: D8D80014 880000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000571DC: BF89FC07
	v_sub_f32_e32 v136, v136, v130                             // 0000000571E0: 09110588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000571E4: BF870121
	v_mul_f32_e32 v146, 0x3fb8aa3b, v136                       // 0000000571E8: 112510FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 0000000571F0: 7C3710FF C2CE8ED0
	v_fma_f32 v147, 0x3fb8aa3b, v136, -v146                    // 0000000571F8: D6130093 864B10FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 000000057204: 7F284792
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000057208: BF870112
	v_fmac_f32_e32 v147, 0x32a5705f, v136                      // 00000005720C: 572710FF 32A5705F
	v_sub_f32_e32 v146, v146, v148                             // 000000057214: 09252992
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057218: BF870121
	v_add_f32_e32 v146, v146, v147                             // 00000005721C: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 000000057220: 7F261194
	v_exp_f32_e32 v146, v146                                   // 000000057224: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057228: BF870095
	.long 0xd71c0092                                           // 00000005722C: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 000000057230: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 000000057234: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 000000057238: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000057240: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v146, vcc_lo           // 000000057244: 031124FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000005724C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057250: BF870121
	v_bfe_u32 v146, v136, 16, 1                                // 000000057254: D6100092 02052188
	v_mov_b32_e32 v147, 0                                      // 00000005725C: 7F260280
	v_add3_u32 v148, v136, v146, 0x7fff                        // 000000057260: D6550094 03FF2588 00007FFF
	v_mov_b32_e32 v146, 0                                      // 00000005726C: 7F240280
	ds_store_b16_d16_hi v165, v148 offset:10                   // 000000057270: DA84000A 000094A5
	s_and_saveexec_b32 s2, s30                                 // 000000057278: BE82201E
	s_cbranch_execz 29                                         // 00000005727C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1df4>
	ds_load_b32 v147, v164 offset:24                           // 000000057280: D8D80018 930000A4
	s_waitcnt lgkmcnt(0)                                       // 000000057288: BF89FC07
	v_sub_f32_e32 v147, v147, v130                             // 00000005728C: 09270593
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057290: BF870091
	v_mul_f32_e32 v148, 0x3fb8aa3b, v147                       // 000000057294: 112926FF 3FB8AA3B
	v_fma_f32 v149, 0x3fb8aa3b, v147, -v148                    // 00000005729C: D6130095 865326FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 0000000572A8: 7F2C4794
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000572AC: BF870091
	v_dual_fmac_f32 v149, 0x32a5705f, v147 :: v_dual_sub_f32 v148, v148, v150// 0000000572B0: C80B26FF 95952D94 32A5705F
	v_add_f32_e32 v148, v148, v149                             // 0000000572BC: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 0000000572C0: 7F2A1196
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 0000000572C4: 7C3726FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000572CC: BF870293
	v_exp_f32_e32 v148, v148                                   // 0000000572D0: 7F284B94
	.long 0xd71c0094                                           // 0000000572D4: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 0000000572D8: 02032B94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000572DC: BF870121
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 0000000572E0: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 0000000572E4: 7C3D26FF 42B17218
	v_cndmask_b32_e32 v147, 0x7f800000, v148, vcc_lo           // 0000000572EC: 032728FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000572F4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000572F8: BF870091
	v_bfe_u32 v148, v147, 16, 1                                // 0000000572FC: D6100094 02052193
	v_add3_u32 v148, v147, v148, 0x7fff                        // 000000057304: D6550094 03FF2993 00007FFF
	ds_store_b16_d16_hi v165, v148 offset:12                   // 000000057310: DA84000C 000094A5
	s_and_saveexec_b32 s2, s29                                 // 000000057318: BE82201D
	s_cbranch_execz 30                                         // 00000005731C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e98>
	ds_load_b32 v146, v164 offset:28                           // 000000057320: D8D8001C 920000A4
	s_waitcnt lgkmcnt(0)                                       // 000000057328: BF89FC07
	v_sub_f32_e32 v146, v146, v130                             // 00000005732C: 09250592
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057330: BF870121
	v_mul_f32_e32 v148, 0x3fb8aa3b, v146                       // 000000057334: 112924FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 00000005733C: 7C3724FF C2CE8ED0
	v_fma_f32 v149, 0x3fb8aa3b, v146, -v148                    // 000000057344: D6130095 865324FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 000000057350: 7F2C4794
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000057354: BF870112
	v_fmac_f32_e32 v149, 0x32a5705f, v146                      // 000000057358: 572B24FF 32A5705F
	v_sub_f32_e32 v148, v148, v150                             // 000000057360: 09292D94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057364: BF870121
	v_add_f32_e32 v148, v148, v149                             // 000000057368: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 00000005736C: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 000000057370: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057374: BF870095
	.long 0xd71c0094                                           // 000000057378: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 00000005737C: 02032B94
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 000000057380: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 000000057384: 7C3D24FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000005738C: BF870002
	v_cndmask_b32_e32 v146, 0x7f800000, v148, vcc_lo           // 000000057390: 032528FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000057398: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005739C: BF870121
	v_bfe_u32 v148, v146, 16, 1                                // 0000000573A0: D6100094 02052192
	v_mov_b32_e32 v149, 0                                      // 0000000573A8: 7F2A0280
	v_add3_u32 v150, v146, v148, 0x7fff                        // 0000000573AC: D6550096 03FF2992 00007FFF
	v_mov_b32_e32 v148, 0                                      // 0000000573B8: 7F280280
	ds_store_b16_d16_hi v165, v150 offset:14                   // 0000000573BC: DA84000E 000096A5
	s_and_saveexec_b32 s2, s28                                 // 0000000573C4: BE82201C
	s_cbranch_execz 30                                         // 0000000573C8: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f44>
	ds_load_b32 v149, v164 offset:32                           // 0000000573CC: D8D80020 950000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000573D4: BF89FC07
	v_sub_f32_e32 v149, v149, v130                             // 0000000573D8: 092B0595
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000573DC: BF870091
	v_mul_f32_e32 v150, 0x3fb8aa3b, v149                       // 0000000573E0: 112D2AFF 3FB8AA3B
	v_fma_f32 v151, 0x3fb8aa3b, v149, -v150                    // 0000000573E8: D6130097 865B2AFF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 0000000573F4: 7F304796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000573F8: BF870221
	v_sub_f32_e32 v150, v150, v152                             // 0000000573FC: 092D3196
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 000000057400: 7C372AFF C2CE8ED0
	v_fmac_f32_e32 v151, 0x32a5705f, v149                      // 000000057408: 572F2AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057410: BF870121
	v_add_f32_e32 v150, v150, v151                             // 000000057414: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 000000057418: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 00000005741C: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057420: BF870095
	.long 0xd71c0096                                           // 000000057424: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 000000057428: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 00000005742C: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 000000057430: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000057438: BF870002
	v_cndmask_b32_e32 v149, 0x7f800000, v150, vcc_lo           // 00000005743C: 032B2CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000057444: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057448: BF870091
	v_bfe_u32 v150, v149, 16, 1                                // 00000005744C: D6100096 02052195
	v_add3_u32 v150, v149, v150, 0x7fff                        // 000000057454: D6550096 03FF2D95 00007FFF
	ds_store_b16_d16_hi v165, v150 offset:16                   // 000000057460: DA840010 000096A5
	s_and_saveexec_b32 s2, s27                                 // 000000057468: BE82201B
	s_cbranch_execz 30                                         // 00000005746C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1fe8>
	ds_load_b32 v148, v164 offset:36                           // 000000057470: D8D80024 940000A4
	s_waitcnt lgkmcnt(0)                                       // 000000057478: BF89FC07
	v_sub_f32_e32 v148, v148, v130                             // 00000005747C: 09290594
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057480: BF870121
	v_mul_f32_e32 v150, 0x3fb8aa3b, v148                       // 000000057484: 112D28FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 00000005748C: 7C3728FF C2CE8ED0
	v_fma_f32 v151, 0x3fb8aa3b, v148, -v150                    // 000000057494: D6130097 865B28FF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 0000000574A0: 7F304796
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000574A4: BF870112
	v_fmac_f32_e32 v151, 0x32a5705f, v148                      // 0000000574A8: 572F28FF 32A5705F
	v_sub_f32_e32 v150, v150, v152                             // 0000000574B0: 092D3196
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000574B4: BF870121
	v_add_f32_e32 v150, v150, v151                             // 0000000574B8: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 0000000574BC: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 0000000574C0: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000574C4: BF870095
	.long 0xd71c0096                                           // 0000000574C8: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 0000000574CC: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 0000000574D0: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 0000000574D4: 7C3D28FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000574DC: BF870002
	v_cndmask_b32_e32 v148, 0x7f800000, v150, vcc_lo           // 0000000574E0: 03292CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000574E8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000574EC: BF870121
	v_bfe_u32 v150, v148, 16, 1                                // 0000000574F0: D6100096 02052194
	v_mov_b32_e32 v151, 0                                      // 0000000574F8: 7F2E0280
	v_add3_u32 v152, v148, v150, 0x7fff                        // 0000000574FC: D6550098 03FF2D94 00007FFF
	v_mov_b32_e32 v150, 0                                      // 000000057508: 7F2C0280
	ds_store_b16_d16_hi v165, v152 offset:18                   // 00000005750C: DA840012 000098A5
	s_and_saveexec_b32 s2, s26                                 // 000000057514: BE82201A
	s_cbranch_execz 30                                         // 000000057518: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2094>
	ds_load_b32 v151, v164 offset:40                           // 00000005751C: D8D80028 970000A4
	s_waitcnt lgkmcnt(0)                                       // 000000057524: BF89FC07
	v_sub_f32_e32 v151, v151, v130                             // 000000057528: 092F0597
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005752C: BF870091
	v_mul_f32_e32 v152, 0x3fb8aa3b, v151                       // 000000057530: 11312EFF 3FB8AA3B
	v_fma_f32 v153, 0x3fb8aa3b, v151, -v152                    // 000000057538: D6130099 86632EFF 3FB8AA3B
	v_rndne_f32_e32 v177, v152                                 // 000000057544: 7F624798
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000057548: BF870221
	v_sub_f32_e32 v152, v152, v177                             // 00000005754C: 09316398
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 000000057550: 7C372EFF C2CE8ED0
	v_fmac_f32_e32 v153, 0x32a5705f, v151                      // 000000057558: 57332EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057560: BF870121
	v_add_f32_e32 v152, v152, v153                             // 000000057564: 07313398
	v_cvt_i32_f32_e32 v153, v177                               // 000000057568: 7F3211B1
	v_exp_f32_e32 v152, v152                                   // 00000005756C: 7F304B98
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057570: BF870095
	.long 0xd71c0098                                           // 000000057574: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 000000057578: 02033398
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 00000005757C: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 000000057580: 7C3D2EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000057588: BF870002
	v_cndmask_b32_e32 v151, 0x7f800000, v152, vcc_lo           // 00000005758C: 032F30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000057594: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057598: BF870091
	v_bfe_u32 v152, v151, 16, 1                                // 00000005759C: D6100098 02052197
	v_add3_u32 v152, v151, v152, 0x7fff                        // 0000000575A4: D6550098 03FF3197 00007FFF
	ds_store_b16_d16_hi v165, v152 offset:20                   // 0000000575B0: DA840014 000098A5
	s_and_saveexec_b32 s2, s25                                 // 0000000575B8: BE822019
	s_cbranch_execz 29                                         // 0000000575BC: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2134>
	ds_load_b32 v150, v164 offset:44                           // 0000000575C0: D8D8002C 960000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000575C8: BF89FC07
	v_sub_f32_e32 v150, v150, v130                             // 0000000575CC: 092D0596
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000575D0: BF870121
	v_mul_f32_e32 v152, 0x3fb8aa3b, v150                       // 0000000575D4: 11312CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 0000000575DC: 7C372CFF C2CE8ED0
	v_fma_f32 v153, 0x3fb8aa3b, v150, -v152                    // 0000000575E4: D6130099 86632CFF 3FB8AA3B
	v_rndne_f32_e32 v177, v152                                 // 0000000575F0: 7F624798
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000575F4: BF870091
	v_dual_fmac_f32 v153, 0x32a5705f, v150 :: v_dual_sub_f32 v152, v152, v177// 0000000575F8: C80B2CFF 99996398 32A5705F
	v_add_f32_e32 v152, v152, v153                             // 000000057604: 07313398
	v_cvt_i32_f32_e32 v153, v177                               // 000000057608: 7F3211B1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005760C: BF870292
	v_exp_f32_e32 v152, v152                                   // 000000057610: 7F304B98
	.long 0xd71c0098                                           // 000000057614: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 000000057618: 02033398
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005761C: BF870121
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 000000057620: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 000000057624: 7C3D2CFF 42B17218
	v_cndmask_b32_e32 v150, 0x7f800000, v152, vcc_lo           // 00000005762C: 032D30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000057634: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057638: BF870121
	v_bfe_u32 v152, v150, 16, 1                                // 00000005763C: D6100098 02052196
	v_mov_b32_e32 v153, 0                                      // 000000057644: 7F320280
	v_add3_u32 v177, v150, v152, 0x7fff                        // 000000057648: D65500B1 03FF3196 00007FFF
	v_mov_b32_e32 v152, 0                                      // 000000057654: 7F300280
	ds_store_b16_d16_hi v165, v177 offset:22                   // 000000057658: DA840016 0000B1A5
	s_and_saveexec_b32 s2, s24                                 // 000000057660: BE822018
	s_cbranch_execz 29                                         // 000000057664: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21dc>
	ds_load_b32 v153, v164 offset:48                           // 000000057668: D8D80030 990000A4
	s_waitcnt lgkmcnt(0)                                       // 000000057670: BF89FC07
	v_sub_f32_e32 v153, v153, v130                             // 000000057674: 09330599
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057678: BF870121
	v_mul_f32_e32 v177, 0x3fb8aa3b, v153                       // 00000005767C: 116332FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 000000057684: 7C3732FF C2CE8ED0
	v_fma_f32 v178, 0x3fb8aa3b, v153, -v177                    // 00000005768C: D61300B2 86C732FF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 000000057698: 7F6647B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005769C: BF870091
	v_dual_fmac_f32 v178, 0x32a5705f, v153 :: v_dual_sub_f32 v177, v177, v179// 0000000576A0: C80B32FF B2B167B1 32A5705F
	v_add_f32_e32 v177, v177, v178                             // 0000000576AC: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 0000000576B0: 7F6411B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000576B4: BF870292
	v_exp_f32_e32 v177, v177                                   // 0000000576B8: 7F624BB1
	.long 0xd71c00b1                                           // 0000000576BC: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 0000000576C0: 020365B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000576C4: BF870121
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 0000000576C8: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 0000000576CC: 7C3D32FF 42B17218
	v_cndmask_b32_e32 v153, 0x7f800000, v177, vcc_lo           // 0000000576D4: 033362FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000576DC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000576E0: BF870091
	v_bfe_u32 v177, v153, 16, 1                                // 0000000576E4: D61000B1 02052199
	v_add3_u32 v177, v153, v177, 0x7fff                        // 0000000576EC: D65500B1 03FF6399 00007FFF
	ds_store_b16_d16_hi v165, v177 offset:24                   // 0000000576F8: DA840018 0000B1A5
	s_and_saveexec_b32 s2, s9                                  // 000000057700: BE822009
	s_cbranch_execz 30                                         // 000000057704: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2280>
	ds_load_b32 v152, v164 offset:52                           // 000000057708: D8D80034 980000A4
	s_waitcnt lgkmcnt(0)                                       // 000000057710: BF89FC07
	v_sub_f32_e32 v152, v152, v130                             // 000000057714: 09310598
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057718: BF870091
	v_mul_f32_e32 v177, 0x3fb8aa3b, v152                       // 00000005771C: 116330FF 3FB8AA3B
	v_fma_f32 v178, 0x3fb8aa3b, v152, -v177                    // 000000057724: D61300B2 86C730FF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 000000057730: 7F6647B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000057734: BF870221
	v_sub_f32_e32 v177, v177, v179                             // 000000057738: 096367B1
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 00000005773C: 7C3730FF C2CE8ED0
	v_fmac_f32_e32 v178, 0x32a5705f, v152                      // 000000057744: 576530FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005774C: BF870121
	v_add_f32_e32 v177, v177, v178                             // 000000057750: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 000000057754: 7F6411B3
	v_exp_f32_e32 v177, v177                                   // 000000057758: 7F624BB1
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005775C: BF870095
	.long 0xd71c00b1                                           // 000000057760: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 000000057764: 020365B1
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 000000057768: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 00000005776C: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000057774: BF870002
	v_cndmask_b32_e32 v152, 0x7f800000, v177, vcc_lo           // 000000057778: 033162FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000057780: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057784: BF870121
	v_bfe_u32 v177, v152, 16, 1                                // 000000057788: D61000B1 02052198
	v_mov_b32_e32 v178, 0                                      // 000000057790: 7F640280
	v_add3_u32 v179, v152, v177, 0x7fff                        // 000000057794: D65500B3 03FF6398 00007FFF
	v_mov_b32_e32 v177, 0                                      // 0000000577A0: 7F620280
	ds_store_b16_d16_hi v165, v179 offset:26                   // 0000000577A4: DA84001A 0000B3A5
	s_and_saveexec_b32 s2, s8                                  // 0000000577AC: BE822008
	s_cbranch_execz 30                                         // 0000000577B0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x232c>
	ds_load_b32 v178, v164 offset:56                           // 0000000577B4: D8D80038 B20000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000577BC: BF89FC07
	v_sub_f32_e32 v178, v178, v130                             // 0000000577C0: 096505B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000577C4: BF870091
	v_mul_f32_e32 v179, 0x3fb8aa3b, v178                       // 0000000577C8: 116764FF 3FB8AA3B
	v_fma_f32 v180, 0x3fb8aa3b, v178, -v179                    // 0000000577D0: D61300B4 86CF64FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000577DC: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000577E0: BF870221
	v_sub_f32_e32 v179, v179, v181                             // 0000000577E4: 09676BB3
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 0000000577E8: 7C3764FF C2CE8ED0
	v_fmac_f32_e32 v180, 0x32a5705f, v178                      // 0000000577F0: 576964FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000577F8: BF870121
	v_add_f32_e32 v179, v179, v180                             // 0000000577FC: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 000000057800: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 000000057804: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057808: BF870095
	.long 0xd71c00b3                                           // 00000005780C: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 000000057810: 020369B3
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 000000057814: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 000000057818: 7C3D64FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000057820: BF870002
	v_cndmask_b32_e32 v178, 0x7f800000, v179, vcc_lo           // 000000057824: 036566FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000005782C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057830: BF870091
	v_bfe_u32 v179, v178, 16, 1                                // 000000057834: D61000B3 020521B2
	v_add3_u32 v179, v178, v179, 0x7fff                        // 00000005783C: D65500B3 03FF67B2 00007FFF
	ds_store_b16_d16_hi v165, v179 offset:28                   // 000000057848: DA84001C 0000B3A5
	s_and_saveexec_b32 s2, s1                                  // 000000057850: BE822001
	s_cbranch_execz 30                                         // 000000057854: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x23d0>
	ds_load_b32 v177, v164 offset:60                           // 000000057858: D8D8003C B10000A4
	s_waitcnt lgkmcnt(0)                                       // 000000057860: BF89FC07
	v_sub_f32_e32 v177, v177, v130                             // 000000057864: 096305B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057868: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v177                       // 00000005786C: 116762FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v177                 // 000000057874: 7C3762FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v177, -v179                    // 00000005787C: D61300B4 86CF62FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 000000057888: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005788C: BF870112
	v_fmac_f32_e32 v180, 0x32a5705f, v177                      // 000000057890: 576962FF 32A5705F
	v_sub_f32_e32 v179, v179, v181                             // 000000057898: 09676BB3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005789C: BF870121
	v_add_f32_e32 v179, v179, v180                             // 0000000578A0: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000578A4: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 0000000578A8: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000578AC: BF870095
	.long 0xd71c00b3                                           // 0000000578B0: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000578B4: 020369B3
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000578B8: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v177                 // 0000000578BC: 7C3D62FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000578C4: BF870002
	v_cndmask_b32_e32 v177, 0x7f800000, v179, vcc_lo           // 0000000578C8: 036366FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000578D0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000578D4: BF8700A1
	v_bfe_u32 v179, v177, 16, 1                                // 0000000578D8: D61000B3 020521B1
	s_mov_b32 s1, exec_lo                                      // 0000000578E0: BE81007E
	v_add3_u32 v180, v177, v179, 0x7fff                        // 0000000578E4: D65500B4 03FF67B1 00007FFF
	v_mov_b32_e32 v179, 0                                      // 0000000578F0: 7F660280
	ds_store_b16_d16_hi v165, v180 offset:30                   // 0000000578F4: DA84001E 0000B4A5
	v_cmpx_lt_f32_e32 0xefa18f08, v131                         // 0000000578FC: 7D2306FF EFA18F08
	s_cbranch_execz 26                                         // 000000057904: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2470>
	v_sub_f32_e32 v131, v131, v130                             // 000000057908: 09070583
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005790C: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v131                       // 000000057910: 116706FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 000000057918: 7C3706FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v131, -v179                    // 000000057920: D61300B4 86CF06FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 00000005792C: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057930: BF870091
	v_dual_fmac_f32 v180, 0x32a5705f, v131 :: v_dual_sub_f32 v179, v179, v181// 000000057934: C80B06FF B4B36BB3 32A5705F
	v_add_f32_e32 v179, v179, v180                             // 000000057940: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 000000057944: 7F6811B5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000057948: BF870292
	v_exp_f32_e32 v179, v179                                   // 00000005794C: 7F664BB3
	.long 0xd71c00b3                                           // 000000057950: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 000000057954: 020369B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057958: BF870121
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 00000005795C: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 000000057960: 7C3D06FF 42B17218
	v_cndmask_b32_e32 v179, 0x7f800000, v179, vcc_lo           // 000000057968: 036766FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000057970: 8C7E017E
	v_add_f32_e32 v131, v133, v132                             // 000000057974: 07070985
	ds_load_b32 v132, v166                                     // 000000057978: D8D80000 840000A6
	v_add_f32_e32 v131, v131, v135                             // 000000057980: 07070F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057984: BF870091
	v_add_f32_e32 v131, v131, v134                             // 000000057988: 07070D83
	v_add_f32_e32 v131, v131, v137                             // 00000005798C: 07071383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057990: BF870091
	v_add_f32_e32 v131, v131, v136                             // 000000057994: 07071183
	v_add_f32_e32 v131, v131, v147                             // 000000057998: 07072783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005799C: BF870091
	v_add_f32_e32 v131, v131, v146                             // 0000000579A0: 07072583
	v_add_f32_e32 v131, v131, v149                             // 0000000579A4: 07072B83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000579A8: BF870091
	v_add_f32_e32 v131, v131, v148                             // 0000000579AC: 07072983
	v_add_f32_e32 v131, v131, v151                             // 0000000579B0: 07072F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000579B4: BF870091
	v_add_f32_e32 v131, v131, v150                             // 0000000579B8: 07072D83
	v_add_f32_e32 v131, v131, v153                             // 0000000579BC: 07073383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000579C0: BF870091
	v_add_f32_e32 v131, v131, v152                             // 0000000579C4: 07073183
	v_add_f32_e32 v131, v131, v178                             // 0000000579C8: 07076583
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000579CC: BF8700A1
	v_add_f32_e32 v131, v131, v177                             // 0000000579D0: 07076383
	s_waitcnt lgkmcnt(0)                                       // 0000000579D4: BF89FC07
	v_fmac_f32_e32 v131, v179, v132                            // 0000000579D8: 570709B3
	ds_store_b32 v163, v130                                    // 0000000579DC: D8340000 000082A3
	ds_store_b32 v166, v131                                    // 0000000579E4: D8340000 000083A6
	ds_store_b32 v167, v179                                    // 0000000579EC: D8340000 0000B3A7
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000579F4: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000579F8: BF89FC07
	s_barrier                                                  // 0000000579FC: BFBD0000
	buffer_gl0_inv                                             // 000000057A00: E0AC0000 00000000
	ds_load_2addr_b32 v[152:153], v168 offset1:2               // 000000057A08: D8DC0200 980000A8
	ds_load_2addr_b32 v[150:151], v168 offset0:4 offset1:6     // 000000057A10: D8DC0604 960000A8
	ds_load_2addr_b32 v[148:149], v168 offset0:8 offset1:10    // 000000057A18: D8DC0A08 940000A8
	ds_load_2addr_b32 v[146:147], v168 offset0:12 offset1:14   // 000000057A20: D8DC0E0C 920000A8
	s_waitcnt lgkmcnt(3)                                       // 000000057A28: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v152                         // 000000057A2C: 7C2530F2
	.long 0xd4120001                                           // 000000057A30: D4120001
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 000000057A34: 020332F2
	s_waitcnt lgkmcnt(2)                                       // 000000057A38: BF89FC27
	.long 0xd4120002                                           // 000000057A3C: D4120002
	v_cndmask_b32_e32 v1, 1.0, v150, vcc_lo                    // 000000057A40: 02032CF2
	.long 0xd4120004                                           // 000000057A44: D4120004
	v_cndmask_b32_e32 v1, 1.0, v151, vcc_lo                    // 000000057A48: 02032EF2
	s_and_b32 s1, vcc_lo, s1                                   // 000000057A4C: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 000000057A50: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v148                         // 000000057A54: 7C2528F2
	s_and_b32 s2, s1, s2                                       // 000000057A58: 8B020201
	.long 0xd4120001                                           // 000000057A5C: D4120001
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 000000057A60: 02032AF2
	s_and_b32 s4, s2, s4                                       // 000000057A64: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 000000057A68: BF89FC07
	.long 0xd4120002                                           // 000000057A6C: D4120002
	v_cndmask_b32_e32 v1, 1.0, v146, vcc_lo                    // 000000057A70: 020324F2
	s_and_b32 s4, s4, vcc_lo                                   // 000000057A74: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v147                         // 000000057A78: 7C2526F2
	s_and_b32 s1, s4, s1                                       // 000000057A7C: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000057A80: BF870499
	s_and_b32 s1, s1, s2                                       // 000000057A84: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 000000057A88: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057A8C: BF870099
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 000000057A90: D5010082 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v130                           // 000000057A98: 7C9B0480
	ds_load_b128 v[130:133], v169                              // 000000057A9C: DBFC0000 820000A9
	ds_load_b128 v[134:137], v169 offset:16                    // 000000057AA4: DBFC0010 860000A9
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 000000057AAC: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 000000057AB0: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057AB4: BF870099
	v_cndmask_b32_e64 v177, 0, 1, s1                           // 000000057AB8: D50100B1 00050280
	v_readfirstlane_b32 s1, v177                               // 000000057AC0: 7E0205B1
	s_bitcmp1_b32 s1, 0                                        // 000000057AC4: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 000000057AC8: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000057ACC: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000057AD0: 8B6A017E
	s_cbranch_vccnz 63580                                      // 000000057AD4: BFA4F85C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x748>
	v_dual_mul_f32 v121, v152, v121 :: v_dual_mul_f32 v122, v153, v122// 000000057AD8: C8C6F398 797AF599
	v_dual_mul_f32 v123, v150, v123 :: v_dual_mul_f32 v124, v151, v124// 000000057AE0: C8C6F796 7B7CF997
	v_dual_mul_f32 v125, v148, v125 :: v_dual_mul_f32 v126, v149, v126// 000000057AE8: C8C6FB94 7D7EFD95
	v_dual_mul_f32 v127, v146, v127 :: v_dual_mul_f32 v128, v147, v128// 000000057AF0: C8C6FF92 7F810193
	v_dual_mul_f32 v113, v152, v113 :: v_dual_mul_f32 v114, v153, v114// 000000057AF8: C8C6E398 7172E599
	v_dual_mul_f32 v115, v150, v115 :: v_dual_mul_f32 v116, v151, v116// 000000057B00: C8C6E796 7374E997
	v_dual_mul_f32 v117, v148, v117 :: v_dual_mul_f32 v118, v149, v118// 000000057B08: C8C6EB94 7576ED95
	v_dual_mul_f32 v119, v146, v119 :: v_dual_mul_f32 v120, v147, v120// 000000057B10: C8C6EF92 7778F193
	v_dual_mul_f32 v105, v152, v105 :: v_dual_mul_f32 v106, v153, v106// 000000057B18: C8C6D398 696AD599
	v_dual_mul_f32 v107, v150, v107 :: v_dual_mul_f32 v108, v151, v108// 000000057B20: C8C6D796 6B6CD997
	v_dual_mul_f32 v109, v148, v109 :: v_dual_mul_f32 v110, v149, v110// 000000057B28: C8C6DB94 6D6EDD95
	v_dual_mul_f32 v111, v146, v111 :: v_dual_mul_f32 v112, v147, v112// 000000057B30: C8C6DF92 6F70E193
	v_dual_mul_f32 v97, v152, v97 :: v_dual_mul_f32 v98, v153, v98// 000000057B38: C8C6C398 6162C599
	v_dual_mul_f32 v99, v150, v99 :: v_dual_mul_f32 v100, v151, v100// 000000057B40: C8C6C796 6364C997
	v_dual_mul_f32 v101, v148, v101 :: v_dual_mul_f32 v102, v149, v102// 000000057B48: C8C6CB94 6566CD95
	v_dual_mul_f32 v103, v146, v103 :: v_dual_mul_f32 v104, v147, v104// 000000057B50: C8C6CF92 6768D193
	v_dual_mul_f32 v89, v152, v89 :: v_dual_mul_f32 v90, v153, v90// 000000057B58: C8C6B398 595AB599
	v_dual_mul_f32 v91, v150, v91 :: v_dual_mul_f32 v92, v151, v92// 000000057B60: C8C6B796 5B5CB997
	v_dual_mul_f32 v93, v148, v93 :: v_dual_mul_f32 v94, v149, v94// 000000057B68: C8C6BB94 5D5EBD95
	v_dual_mul_f32 v95, v146, v95 :: v_dual_mul_f32 v96, v147, v96// 000000057B70: C8C6BF92 5F60C193
	v_dual_mul_f32 v81, v152, v81 :: v_dual_mul_f32 v82, v153, v82// 000000057B78: C8C6A398 5152A599
	v_dual_mul_f32 v83, v150, v83 :: v_dual_mul_f32 v84, v151, v84// 000000057B80: C8C6A796 5354A997
	v_dual_mul_f32 v85, v148, v85 :: v_dual_mul_f32 v86, v149, v86// 000000057B88: C8C6AB94 5556AD95
	v_dual_mul_f32 v87, v146, v87 :: v_dual_mul_f32 v88, v147, v88// 000000057B90: C8C6AF92 5758B193
	v_dual_mul_f32 v73, v152, v73 :: v_dual_mul_f32 v74, v153, v74// 000000057B98: C8C69398 494A9599
	v_dual_mul_f32 v75, v150, v75 :: v_dual_mul_f32 v76, v151, v76// 000000057BA0: C8C69796 4B4C9997
	v_dual_mul_f32 v77, v148, v77 :: v_dual_mul_f32 v78, v149, v78// 000000057BA8: C8C69B94 4D4E9D95
	v_dual_mul_f32 v79, v146, v79 :: v_dual_mul_f32 v80, v147, v80// 000000057BB0: C8C69F92 4F50A193
	v_dual_mul_f32 v65, v152, v65 :: v_dual_mul_f32 v66, v153, v66// 000000057BB8: C8C68398 41428599
	v_dual_mul_f32 v67, v150, v67 :: v_dual_mul_f32 v68, v151, v68// 000000057BC0: C8C68796 43448997
	v_dual_mul_f32 v69, v148, v69 :: v_dual_mul_f32 v70, v149, v70// 000000057BC8: C8C68B94 45468D95
	v_dual_mul_f32 v71, v146, v71 :: v_dual_mul_f32 v72, v147, v72// 000000057BD0: C8C68F92 47489193
	v_dual_mul_f32 v57, v152, v57 :: v_dual_mul_f32 v58, v153, v58// 000000057BD8: C8C67398 393A7599
	v_dual_mul_f32 v59, v150, v59 :: v_dual_mul_f32 v60, v151, v60// 000000057BE0: C8C67796 3B3C7997
	v_dual_mul_f32 v61, v148, v61 :: v_dual_mul_f32 v62, v149, v62// 000000057BE8: C8C67B94 3D3E7D95
	v_dual_mul_f32 v63, v146, v63 :: v_dual_mul_f32 v64, v147, v64// 000000057BF0: C8C67F92 3F408193
	v_dual_mul_f32 v49, v152, v49 :: v_dual_mul_f32 v50, v153, v50// 000000057BF8: C8C66398 31326599
	v_dual_mul_f32 v51, v150, v51 :: v_dual_mul_f32 v52, v151, v52// 000000057C00: C8C66796 33346997
	v_dual_mul_f32 v53, v148, v53 :: v_dual_mul_f32 v54, v149, v54// 000000057C08: C8C66B94 35366D95
	v_dual_mul_f32 v55, v146, v55 :: v_dual_mul_f32 v56, v147, v56// 000000057C10: C8C66F92 37387193
	v_dual_mul_f32 v41, v152, v41 :: v_dual_mul_f32 v42, v153, v42// 000000057C18: C8C65398 292A5599
	v_dual_mul_f32 v43, v150, v43 :: v_dual_mul_f32 v44, v151, v44// 000000057C20: C8C65796 2B2C5997
	v_dual_mul_f32 v45, v148, v45 :: v_dual_mul_f32 v46, v149, v46// 000000057C28: C8C65B94 2D2E5D95
	v_dual_mul_f32 v47, v146, v47 :: v_dual_mul_f32 v48, v147, v48// 000000057C30: C8C65F92 2F306193
	v_dual_mul_f32 v33, v152, v33 :: v_dual_mul_f32 v34, v153, v34// 000000057C38: C8C64398 21224599
	v_dual_mul_f32 v35, v150, v35 :: v_dual_mul_f32 v36, v151, v36// 000000057C40: C8C64796 23244997
	v_dual_mul_f32 v37, v148, v37 :: v_dual_mul_f32 v38, v149, v38// 000000057C48: C8C64B94 25264D95
	v_dual_mul_f32 v39, v146, v39 :: v_dual_mul_f32 v40, v147, v40// 000000057C50: C8C64F92 27285193
	v_dual_mul_f32 v25, v152, v25 :: v_dual_mul_f32 v26, v153, v26// 000000057C58: C8C63398 191A3599
	v_dual_mul_f32 v27, v150, v27 :: v_dual_mul_f32 v28, v151, v28// 000000057C60: C8C63796 1B1C3997
	v_dual_mul_f32 v29, v148, v29 :: v_dual_mul_f32 v30, v149, v30// 000000057C68: C8C63B94 1D1E3D95
	v_dual_mul_f32 v31, v146, v31 :: v_dual_mul_f32 v32, v147, v32// 000000057C70: C8C63F92 1F204193
	v_dual_mul_f32 v17, v152, v17 :: v_dual_mul_f32 v18, v153, v18// 000000057C78: C8C62398 11122599
	v_dual_mul_f32 v19, v150, v19 :: v_dual_mul_f32 v20, v151, v20// 000000057C80: C8C62796 13142997
	v_dual_mul_f32 v21, v148, v21 :: v_dual_mul_f32 v22, v149, v22// 000000057C88: C8C62B94 15162D95
	v_dual_mul_f32 v23, v146, v23 :: v_dual_mul_f32 v24, v147, v24// 000000057C90: C8C62F92 17183193
	v_dual_mul_f32 v9, v152, v9 :: v_dual_mul_f32 v10, v153, v10// 000000057C98: C8C61398 090A1599
	v_dual_mul_f32 v11, v150, v11 :: v_dual_mul_f32 v12, v151, v12// 000000057CA0: C8C61796 0B0C1997
	v_dual_mul_f32 v13, v148, v13 :: v_dual_mul_f32 v14, v149, v14// 000000057CA8: C8C61B94 0D0E1D95
	v_dual_mul_f32 v15, v146, v15 :: v_dual_mul_f32 v16, v147, v16// 000000057CB0: C8C61F92 0F102193
	v_dual_mul_f32 v1, v152, v1 :: v_dual_mul_f32 v2, v153, v2 // 000000057CB8: C8C60398 01020599
	v_dual_mul_f32 v3, v150, v3 :: v_dual_mul_f32 v4, v151, v4 // 000000057CC0: C8C60796 03040997
	v_dual_mul_f32 v5, v148, v5 :: v_dual_mul_f32 v6, v149, v6 // 000000057CC8: C8C60B94 05060D95
	v_dual_mul_f32 v7, v146, v7 :: v_dual_mul_f32 v8, v147, v8 // 000000057CD0: C8C60F92 07081193
	s_branch 63451                                             // 000000057CD8: BFA0F7DB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x748>
	v_lshlrev_b32_e32 v0, 2, v157                              // 000000057CDC: 30013A82
	.long 0xd700008b                                           // 000000057CE0: D700008B
	v_cndmask_b32_e32 v1, s18, v139, vcc_lo                    // 000000057CE4: 02031612
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000057CE8: BF870191
	v_add_co_ci_u32_e64 v140, null, s19, v140, s0              // 000000057CEC: D5207C8C 00031813
	v_lshl_or_b32 v0, v156, 6, v0                              // 000000057CF4: D6560000 04010D9C
	v_lshlrev_b32_e32 v147, 1, v154                            // 000000057CFC: 31273481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000057D00: BF870152
	v_add_nc_u32_e32 v133, 0xa000, v0                          // 000000057D04: 4B0A00FF 0000A000
	ds_load_2addr_b32 v[141:142], v133 offset0:128 offset1:130 // 000000057D0C: D8DC8280 8D000085
	s_waitcnt lgkmcnt(0)                                       // 000000057D14: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 000000057D18: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 000000057D20: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 000000057D28: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000057D2C: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 000000057D30: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 000000057D38: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:132 offset1:134 // 000000057D3C: D8DC8684 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:136 offset1:138 // 000000057D44: D8DC8A88 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:140 offset1:142 // 000000057D4C: D8DC8E8C 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 000000057D54: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 000000057D58: 3505029F
	v_or_b32_e32 v0, v155, v157                                // 000000057D5C: 38013B9B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000057D60: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 000000057D64: 11252191
	.long 0xd73c0083                                           // 000000057D68: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 000000057D6C: 02030281
	.long 0xd7000081                                           // 000000057D70: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 000000057D74: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000057D78: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 000000057D7C: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 000000057D84: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057D8C: BF870094
	.long 0xd7000083                                           // 000000057D90: D7000083
	v_cndmask_b32_e32 v1, s16, v131, vcc_lo                    // 000000057D94: 02030610
	v_add_co_ci_u32_e64 v132, null, s17, v132, s0              // 000000057D98: D5207C84 00030811
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057DA0: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 000000057DA4: 57252194
	.long 0xd4440000                                           // 000000057DA8: D4440000
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 000000057DAC: 0202000E
	v_fma_f32 v139, -v143, v146, v145                          // 000000057DB0: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000057DB8: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 000000057DBC: D637008B 064B218B
	.long 0xd7006a83                                           // 000000057DC4: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 000000057DC8: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 000000057DCC: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 000000057DD4: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 000000057DD8: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 000000057DE0: BE812000
	s_cbranch_execz 70                                         // 000000057DE4: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2a00>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000057DE8: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 000000057DEC: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 000000057DF8: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 000000057DFC: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 000000057E04: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 000000057E08: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057E0C: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 000000057E10: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 000000057E18: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 000000057E24: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000057E28: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 000000057E2C: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 000000057E34: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000057E38: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 000000057E3C: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 000000057E40: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 000000057E44: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 000000057E4C: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057E50: BF870095
	.long 0xd71c008d                                           // 000000057E54: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 000000057E58: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 000000057E5C: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 000000057E60: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057E68: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 000000057E6C: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 000000057E74: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057E78: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 000000057E7C: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 000000057E84: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057E88: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 000000057E8C: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 000000057E94: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 000000057E98: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057EA0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000057EA4: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 000000057EA8: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057EB0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000057EB4: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 000000057EB8: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057EC0: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 000000057EC4: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 000000057ECC: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 000000057ED4: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057EE0: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 000000057EE4: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 000000057EEC: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 000000057EF8: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000057F00: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 000000057F04: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 000000057F0C: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000057F14: BF870292
	v_rcp_f32_e32 v140, v121                                   // 000000057F18: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 000000057F1C: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057F24: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 000000057F28: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 000000057F2C: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057F30: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 000000057F34: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 000000057F3C: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057F40: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 000000057F44: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 000000057F4C: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 000000057F54: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000057F58: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 000000057F5C: D627008C 03CB1D8C
	.long 0xd4440001                                           // 000000057F64: D4440001
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 000000057F68: 0202F20E
	s_and_saveexec_b32 s2, s1                                  // 000000057F6C: BE822001
	s_cbranch_execz 69                                         // 000000057F70: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2b88>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 000000057F74: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 000000057F80: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 000000057F84: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000057F8C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000057F90: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057F94: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000057F98: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000057FA0: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000057FAC: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000057FB0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000057FB4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000057FB8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000057FC0: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057FC8: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000057FCC: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000057FD0: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000057FD4: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057FD8: BF870095
	.long 0xd71c008e                                           // 000000057FDC: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000057FE0: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000057FE4: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000057FE8: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057FF0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000057FF4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000057FFC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058000: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 000000058004: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000005800C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058010: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000058014: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000005801C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 000000058020: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058028: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000005802C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000058030: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058038: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000005803C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000058040: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058048: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000005804C: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 000000058054: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 00000005805C: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058068: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 00000005806C: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 000000058074: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 000000058080: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 000000058088: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 00000005808C: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 000000058090: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 000000058098: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000580A0: BF870292
	v_rcp_f32_e32 v141, v122                                   // 0000000580A4: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 0000000580A8: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000580B0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000580B4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000580B8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000580BC: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 0000000580C0: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 0000000580C8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000580CC: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 0000000580D0: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 0000000580D8: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 0000000580E0: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000580E4: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 0000000580E8: D6270089 03CB138D
	.long 0xd4440002                                           // 0000000580F0: D4440002
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 0000000580F4: 0202F40E
	s_and_saveexec_b32 s3, s2                                  // 0000000580F8: BE832002
	s_cbranch_execz 69                                         // 0000000580FC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2d14>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 000000058100: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 00000005810C: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 000000058110: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000058118: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000005811C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058120: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000058124: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000005812C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000058138: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005813C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000058140: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000058144: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000005814C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000058154: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000058158: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000005815C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000058160: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058164: BF870095
	.long 0xd71c008e                                           // 000000058168: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000005816C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000058170: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000058174: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005817C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000058180: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000058188: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005818C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 000000058190: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000058198: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005819C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000581A0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000581A8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 0000000581AC: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000581B4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000581B8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000581BC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000581C4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000581C8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000581CC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000581D4: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000581D8: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 0000000581E0: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 0000000581E8: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000581F4: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 0000000581F8: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 000000058200: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 00000005820C: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 000000058214: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 000000058218: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 000000058220: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000058228: BF870292
	v_rcp_f32_e32 v141, v123                                   // 00000005822C: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 000000058230: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058238: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000005823C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000058240: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058244: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 000000058248: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 000000058250: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058254: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 000000058258: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 000000058260: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 000000058268: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005826C: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 000000058270: D627008A 03CB158D
	.long 0xd4440003                                           // 000000058278: D4440003
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 00000005827C: 0202F60E
	s_and_saveexec_b32 s4, s3                                  // 000000058280: BE842003
	s_cbranch_execz 69                                         // 000000058284: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2e9c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 000000058288: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 000000058294: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 000000058298: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000582A0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000582A4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000582A8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000582AC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000582B4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000582C0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000582C4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000582C8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000582CC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000582D4: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000582DC: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000582E0: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000582E4: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000582E8: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000582EC: BF870095
	.long 0xd71c008e                                           // 0000000582F0: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000582F4: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000582F8: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000582FC: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058304: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000058308: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000058310: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058314: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 000000058318: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 000000058320: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058324: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000058328: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000058330: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 000000058334: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005833C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000058340: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000058344: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005834C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000058350: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000058354: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005835C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000058360: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 000000058368: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 000000058370: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005837C: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 000000058380: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 000000058388: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 000000058394: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000005839C: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 0000000583A0: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 0000000583A4: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 0000000583AC: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000583B4: BF870292
	v_rcp_f32_e32 v141, v124                                   // 0000000583B8: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 0000000583BC: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000583C4: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000583C8: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000583CC: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000583D0: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 0000000583D4: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 0000000583DC: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000583E0: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 0000000583E4: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 0000000583EC: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 0000000583F4: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000583F8: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 0000000583FC: D6270087 03CB0F8D
	.long 0xd4440004                                           // 000000058404: D4440004
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 000000058408: 0202F80E
	s_and_saveexec_b32 s5, s4                                  // 00000005840C: BE852004
	s_cbranch_execz 69                                         // 000000058410: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3028>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 000000058414: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 000000058420: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 000000058424: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000005842C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000058430: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058434: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000058438: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000058440: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000005844C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000058450: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000058454: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000058458: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000058460: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000058468: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000005846C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000058470: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000058474: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058478: BF870095
	.long 0xd71c008e                                           // 00000005847C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000058480: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000058484: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000058488: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058490: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000058494: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000005849C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000584A0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 0000000584A4: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000584AC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000584B0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000584B4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000584BC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 0000000584C0: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000584C8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000584CC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000584D0: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000584D8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000584DC: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000584E0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000584E8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000584EC: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 0000000584F4: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 0000000584FC: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058508: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 00000005850C: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 000000058514: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 000000058520: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 000000058528: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 00000005852C: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 000000058534: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005853C: BF870292
	v_rcp_f32_e32 v141, v125                                   // 000000058540: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 000000058544: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005854C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000058550: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000058554: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058558: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 00000005855C: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 000000058564: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058568: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 00000005856C: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 000000058574: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 00000005857C: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000058580: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 000000058584: D6270088 03CB118D
	.long 0xd4440005                                           // 00000005858C: D4440005
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 000000058590: 0202FA0E
	s_and_saveexec_b32 s6, s5                                  // 000000058594: BE862005
	s_cbranch_execz 69                                         // 000000058598: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x31b0>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 00000005859C: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 0000000585A8: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 0000000585AC: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000585B4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000585B8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000585BC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000585C0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000585C8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000585D4: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000585D8: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000585DC: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000585E0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000585E8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000585F0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000585F4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000585F8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000585FC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058600: BF870095
	.long 0xd71c008e                                           // 000000058604: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000058608: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000005860C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000058610: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058618: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000005861C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000058624: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058628: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 00000005862C: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000058634: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058638: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000005863C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000058644: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 000000058648: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058650: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000058654: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000058658: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058660: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000058664: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000058668: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058670: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000058674: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 00000005867C: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 000000058684: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058690: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 000000058694: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 00000005869C: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 0000000586A8: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000586B0: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000586B4: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 0000000586B8: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 0000000586C0: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000586C8: BF870292
	v_rcp_f32_e32 v141, v126                                   // 0000000586CC: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 0000000586D0: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000586D8: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000586DC: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000586E0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000586E4: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 0000000586E8: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 0000000586F0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000586F4: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 0000000586F8: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 000000058700: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 000000058708: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005870C: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 000000058710: D6270085 03CB0B8D
	.long 0xd4440006                                           // 000000058718: D4440006
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 00000005871C: 0202FC0E
	s_and_saveexec_b32 s7, s6                                  // 000000058720: BE872006
	s_cbranch_execz 69                                         // 000000058724: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x333c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 000000058728: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 000000058734: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 000000058738: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000058740: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000058744: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058748: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000005874C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000058754: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000058760: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000058764: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000058768: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000005876C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000058774: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005877C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000058780: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000058784: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000058788: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005878C: BF870095
	.long 0xd71c008e                                           // 000000058790: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000058794: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000058798: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000005879C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000587A4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000587A8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000587B0: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000587B4: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 0000000587B8: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000587C0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000587C4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000587C8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000587D0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 0000000587D4: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000587DC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000587E0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000587E4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000587EC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000587F0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000587F4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000587FC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000058800: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 000000058808: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 000000058810: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005881C: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 000000058820: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 000000058828: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 000000058834: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 00000005883C: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 000000058840: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 000000058848: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000058850: BF870292
	v_rcp_f32_e32 v141, v127                                   // 000000058854: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 000000058858: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058860: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000058864: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000058868: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005886C: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 000000058870: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 000000058878: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005887C: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 000000058880: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 000000058888: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 000000058890: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000058894: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 000000058898: D6270086 03CB0D8D
	.long 0xd4440007                                           // 0000000588A0: D4440007
	v_cndmask_b32_e32 v1, s14, v127, vcc_lo                    // 0000000588A4: 0202FE0E
	s_and_saveexec_b32 s8, s7                                  // 0000000588A8: BE882007
	s_cbranch_execnz 363                                       // 0000000588AC: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x395c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000588B0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000588B4: BE882000
	s_cbranch_execnz 432                                       // 0000000588B8: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000588BC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000588C0: BE882001
	s_cbranch_execnz 501                                       // 0000000588C4: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000588C8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000588CC: BE882002
	s_cbranch_execnz 570                                       // 0000000588D0: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000588D4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000588D8: BE882003
	s_cbranch_execnz 639                                       // 0000000588DC: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ddc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000588E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000588E4: BE882004
	s_cbranch_execnz 708                                       // 0000000588E8: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3efc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000588EC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000588F0: BE882005
	s_cbranch_execnz 777                                       // 0000000588F4: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x401c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000588F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000588FC: BE882006
	s_cbranch_execnz 846                                       // 000000058900: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x413c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058904: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000058908: BE882007
	s_cbranch_execnz 915                                       // 00000005890C: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x425c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058910: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000058914: BE882000
	s_cbranch_execnz 984                                       // 000000058918: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x437c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005891C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000058920: BE882001
	s_cbranch_execnz 1053                                      // 000000058924: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x449c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058928: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000005892C: BE882002
	s_cbranch_execnz 1122                                      // 000000058930: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x45bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058934: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000058938: BE882003
	s_cbranch_execnz 1191                                      // 00000005893C: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x46dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058940: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000058944: BE882004
	s_cbranch_execnz 1260                                      // 000000058948: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x47fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005894C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000058950: BE882005
	s_cbranch_execnz 1329                                      // 000000058954: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x491c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058958: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000005895C: BE882006
	s_cbranch_execnz 1398                                      // 000000058960: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4a3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058964: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000058968: BE882007
	s_cbranch_execnz 1467                                      // 00000005896C: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4b5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058970: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000058974: BE882000
	s_cbranch_execnz 1536                                      // 000000058978: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4c7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005897C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000058980: BE882001
	s_cbranch_execnz 1605                                      // 000000058984: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4d9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058988: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000005898C: BE882002
	s_cbranch_execnz 1674                                      // 000000058990: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4ebc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058994: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000058998: BE882003
	s_cbranch_execnz 1743                                      // 00000005899C: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4fdc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000589A0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000589A4: BE882004
	s_cbranch_execnz 1812                                      // 0000000589A8: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x50fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000589AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000589B0: BE882005
	s_cbranch_execnz 1881                                      // 0000000589B4: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x521c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000589B8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000589BC: BE882006
	s_cbranch_execnz 1950                                      // 0000000589C0: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x533c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000589C4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000589C8: BE882007
	s_cbranch_execnz 2019                                      // 0000000589CC: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x545c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000589D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000589D4: BE882000
	s_cbranch_execnz 2088                                      // 0000000589D8: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x557c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000589DC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000589E0: BE882001
	s_cbranch_execnz 2157                                      // 0000000589E4: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x569c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000589E8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000589EC: BE882002
	s_cbranch_execnz 2226                                      // 0000000589F0: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x57bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000589F4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000589F8: BE882003
	s_cbranch_execnz 2295                                      // 0000000589FC: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x58dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058A00: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000058A04: BE882004
	s_cbranch_execnz 2364                                      // 000000058A08: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x59fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058A0C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000058A10: BE882005
	s_cbranch_execnz 2433                                      // 000000058A14: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5b1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058A18: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000058A1C: BE882006
	s_cbranch_execnz 2502                                      // 000000058A20: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5c3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058A24: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000058A28: BE882007
	s_cbranch_execnz 2571                                      // 000000058A2C: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5d5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058A30: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000058A34: BE882000
	s_cbranch_execnz 2640                                      // 000000058A38: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5e7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058A3C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000058A40: BE882001
	s_cbranch_execnz 2709                                      // 000000058A44: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5f9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058A48: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000058A4C: BE882002
	s_cbranch_execnz 2778                                      // 000000058A50: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x60bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058A54: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000058A58: BE882003
	s_cbranch_execnz 2847                                      // 000000058A5C: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x61dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058A60: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000058A64: BE882004
	s_cbranch_execnz 2916                                      // 000000058A68: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x62fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058A6C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000058A70: BE882005
	s_cbranch_execnz 2985                                      // 000000058A74: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x641c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058A78: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000058A7C: BE882006
	s_cbranch_execnz 3054                                      // 000000058A80: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x653c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058A84: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000058A88: BE882007
	s_cbranch_execnz 3123                                      // 000000058A8C: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x665c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058A90: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000058A94: BE882000
	s_cbranch_execnz 3192                                      // 000000058A98: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x677c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058A9C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000058AA0: BE882001
	s_cbranch_execnz 3261                                      // 000000058AA4: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x689c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058AA8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000058AAC: BE882002
	s_cbranch_execnz 3330                                      // 000000058AB0: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x69bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058AB4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000058AB8: BE882003
	s_cbranch_execnz 3399                                      // 000000058ABC: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6adc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058AC0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000058AC4: BE882004
	s_cbranch_execnz 3468                                      // 000000058AC8: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6bfc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058ACC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000058AD0: BE882005
	s_cbranch_execnz 3537                                      // 000000058AD4: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6d1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058AD8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000058ADC: BE882006
	s_cbranch_execnz 3606                                      // 000000058AE0: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6e3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058AE4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000058AE8: BE882007
	s_cbranch_execnz 3675                                      // 000000058AEC: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6f5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058AF0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000058AF4: BE882000
	s_cbranch_execnz 3744                                      // 000000058AF8: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x707c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058AFC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000058B00: BE882001
	s_cbranch_execnz 3813                                      // 000000058B04: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x719c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058B08: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000058B0C: BE882002
	s_cbranch_execnz 3882                                      // 000000058B10: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x72bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058B14: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000058B18: BE882003
	s_cbranch_execnz 3951                                      // 000000058B1C: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x73dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058B20: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000058B24: BE882004
	s_cbranch_execnz 4020                                      // 000000058B28: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x74fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058B2C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000058B30: BE882005
	s_cbranch_execnz 4089                                      // 000000058B34: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x761c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058B38: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000058B3C: BE882006
	s_cbranch_execnz 4158                                      // 000000058B40: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x773c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058B44: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000058B48: BE882007
	s_cbranch_execnz 4227                                      // 000000058B4C: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x785c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058B50: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000058B54: BE882000
	s_cbranch_execnz 4296                                      // 000000058B58: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x797c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058B5C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000058B60: BE882001
	s_cbranch_execnz 4365                                      // 000000058B64: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7a9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058B68: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000058B6C: BE882002
	s_cbranch_execnz 4434                                      // 000000058B70: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7bbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058B74: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000058B78: BE882003
	s_cbranch_execnz 4503                                      // 000000058B7C: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7cdc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058B80: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000058B84: BE882004
	s_cbranch_execnz 4572                                      // 000000058B88: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7dfc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058B8C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000058B90: BE882005
	s_cbranch_execnz 4641                                      // 000000058B94: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7f1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058B98: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000058B9C: BE882006
	s_cbranch_execnz 4710                                      // 000000058BA0: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x803c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058BA4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000058BA8: BE882007
	s_cbranch_execnz 4779                                      // 000000058BAC: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x815c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058BB0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000058BB4: BE882000
	s_cbranch_execnz 4848                                      // 000000058BB8: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x827c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058BBC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000058BC0: BE882001
	s_cbranch_execnz 4917                                      // 000000058BC4: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x839c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058BC8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000058BCC: BE882002
	s_cbranch_execnz 4986                                      // 000000058BD0: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x84bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058BD4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000058BD8: BE882003
	s_cbranch_execnz 5055                                      // 000000058BDC: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x85dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058BE0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000058BE4: BE882004
	s_cbranch_execnz 5124                                      // 000000058BE8: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x86fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058BEC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000058BF0: BE882005
	s_cbranch_execnz 5193                                      // 000000058BF4: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x881c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058BF8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000058BFC: BE882006
	s_cbranch_execnz 5262                                      // 000000058C00: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x893c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058C04: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000058C08: BE882007
	s_cbranch_execnz 5331                                      // 000000058C0C: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8a5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058C10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000058C14: BE882000
	s_cbranch_execnz 5400                                      // 000000058C18: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058C1C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000058C20: BE882001
	s_cbranch_execnz 5469                                      // 000000058C24: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8c9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058C28: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000058C2C: BE882002
	s_cbranch_execnz 5538                                      // 000000058C30: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8dbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058C34: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000058C38: BE882003
	s_cbranch_execnz 5607                                      // 000000058C3C: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8edc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058C40: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000058C44: BE882004
	s_cbranch_execnz 5676                                      // 000000058C48: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8ffc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058C4C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000058C50: BE882005
	s_cbranch_execnz 5745                                      // 000000058C54: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x911c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058C58: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000058C5C: BE882006
	s_cbranch_execnz 5814                                      // 000000058C60: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x923c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058C64: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000058C68: BE882007
	s_cbranch_execnz 5883                                      // 000000058C6C: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x935c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058C70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000058C74: BE882000
	s_cbranch_execnz 5952                                      // 000000058C78: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x947c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058C7C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000058C80: BE882001
	s_cbranch_execnz 6021                                      // 000000058C84: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x959c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058C88: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000058C8C: BE882002
	s_cbranch_execnz 6090                                      // 000000058C90: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x96bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058C94: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000058C98: BE882003
	s_cbranch_execnz 6159                                      // 000000058C9C: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x97dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058CA0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000058CA4: BE882004
	s_cbranch_execnz 6228                                      // 000000058CA8: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x98fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058CAC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000058CB0: BE882005
	s_cbranch_execnz 6297                                      // 000000058CB4: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9a1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058CB8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000058CBC: BE882006
	s_cbranch_execnz 6366                                      // 000000058CC0: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9b3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058CC4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000058CC8: BE882007
	s_cbranch_execnz 6435                                      // 000000058CCC: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058CD0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000058CD4: BE882000
	s_cbranch_execnz 6504                                      // 000000058CD8: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9d7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058CDC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000058CE0: BE882001
	s_cbranch_execnz 6573                                      // 000000058CE4: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9e9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058CE8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000058CEC: BE882002
	s_cbranch_execnz 6642                                      // 000000058CF0: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9fbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058CF4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000058CF8: BE882003
	s_cbranch_execnz 6711                                      // 000000058CFC: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa0dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058D00: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000058D04: BE882004
	s_cbranch_execnz 6780                                      // 000000058D08: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa1fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058D0C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000058D10: BE882005
	s_cbranch_execnz 6849                                      // 000000058D14: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa31c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058D18: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000058D1C: BE882006
	s_cbranch_execnz 6918                                      // 000000058D20: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa43c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058D24: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000058D28: BE882007
	s_cbranch_execnz 6987                                      // 000000058D2C: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa55c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058D30: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000058D34: BE882000
	s_cbranch_execnz 7056                                      // 000000058D38: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa67c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058D3C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000058D40: BE882001
	s_cbranch_execnz 7125                                      // 000000058D44: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa79c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058D48: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000058D4C: BE882002
	s_cbranch_execnz 7194                                      // 000000058D50: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa8bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058D54: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000058D58: BE882003
	s_cbranch_execnz 7263                                      // 000000058D5C: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa9dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058D60: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000058D64: BE882004
	s_cbranch_execnz 7332                                      // 000000058D68: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaafc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058D6C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000058D70: BE882005
	s_cbranch_execnz 7401                                      // 000000058D74: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058D78: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000058D7C: BE882006
	s_cbranch_execnz 7470                                      // 000000058D80: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xad3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058D84: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000058D88: BE882007
	s_cbranch_execnz 7539                                      // 000000058D8C: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xae5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058D90: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000058D94: BE882000
	s_cbranch_execnz 7608                                      // 000000058D98: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaf7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058D9C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000058DA0: BE882001
	s_cbranch_execnz 7677                                      // 000000058DA4: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb09c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058DA8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000058DAC: BE882002
	s_cbranch_execnz 7746                                      // 000000058DB0: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb1bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058DB4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000058DB8: BE882003
	s_cbranch_execnz 7815                                      // 000000058DBC: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb2dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058DC0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000058DC4: BE882004
	s_cbranch_execnz 7884                                      // 000000058DC8: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb3fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058DCC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000058DD0: BE882005
	s_cbranch_execnz 7953                                      // 000000058DD4: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb51c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058DD8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000058DDC: BE882006
	s_cbranch_execnz 8022                                      // 000000058DE0: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb63c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058DE4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000058DE8: BE882007
	s_cbranch_execnz 8091                                      // 000000058DEC: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb75c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058DF0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000058DF4: BE882000
	s_cbranch_execnz 8160                                      // 000000058DF8: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb87c>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058DFC: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000058E00: BE802001
	s_cbranch_execnz 8229                                      // 000000058E04: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb99c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000058E08: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 000000058E0C: BE802002
	s_cbranch_execnz 8298                                      // 000000058E10: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbabc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000058E14: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 000000058E18: BE802003
	s_cbranch_execnz 8367                                      // 000000058E1C: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbbdc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000058E20: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000058E24: BE802004
	s_cbranch_execnz 8436                                      // 000000058E28: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbcfc>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000058E2C: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000058E30: BE802005
	s_cbranch_execnz 8505                                      // 000000058E34: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbe1c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000058E38: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000058E3C: BE802006
	s_cbranch_execnz 8574                                      // 000000058E40: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbf3c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000058E44: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000058E48: BE802007
	s_cbranch_execnz 8643                                      // 000000058E4C: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc05c>
	s_nop 0                                                    // 000000058E50: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000058E54: BFB60003
	s_endpgm                                                   // 000000058E58: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 000000058E5C: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 000000058E68: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 000000058E6C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000058E74: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000058E78: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058E7C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000058E80: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000058E88: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000058E94: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000058E98: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000058E9C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000058EA0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000058EA8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000058EB0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000058EB4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000058EB8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000058EBC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058EC0: BF870095
	.long 0xd71c008e                                           // 000000058EC4: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000058EC8: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000058ECC: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000058ED0: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058ED8: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000058EDC: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000058EE4: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058EE8: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 000000058EEC: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 000000058EF4: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058EF8: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000058EFC: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000058F04: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 000000058F08: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058F10: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000058F14: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000058F18: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058F20: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000058F24: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000058F28: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058F30: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000058F34: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 000000058F3C: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 000000058F44: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058F50: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 000000058F54: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 000000058F5C: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 000000058F68: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 000000058F70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000058F74: BE882000
	s_cbranch_execz 65104                                      // 000000058F78: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33bc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 000000058F7C: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 000000058F88: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 000000058F8C: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 000000058F94: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 000000058F98: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058F9C: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 000000058FA0: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 000000058FA8: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 000000058FB4: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000058FB8: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 000000058FBC: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 000000058FC0: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 000000058FC8: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000058FD0: BF870121
	v_add_f32_e32 v141, v141, v142                             // 000000058FD4: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 000000058FD8: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 000000058FDC: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058FE0: BF870095
	.long 0xd71c008d                                           // 000000058FE4: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 000000058FE8: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 000000058FEC: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 000000058FF0: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058FF8: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 000000058FFC: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 000000059004: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059008: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 00000005900C: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 000000059014: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059018: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 00000005901C: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 000000059024: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 000000059028: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059030: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 000000059034: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 000000059038: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059040: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 000000059044: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 000000059048: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059050: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 000000059054: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 00000005905C: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 000000059064: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059070: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 000000059074: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 00000005907C: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 000000059088: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 000000059090: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000059094: BE882001
	s_cbranch_execz 65035                                      // 000000059098: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33c8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 00000005909C: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 0000000590A8: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 0000000590AC: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 0000000590B4: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000590B8: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000590BC: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 0000000590C0: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 0000000590C8: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 0000000590D4: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000590D8: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 0000000590DC: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000590E0: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 0000000590E8: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000590F0: BF870121
	v_add_f32_e32 v128, v128, v141                             // 0000000590F4: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 0000000590F8: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 0000000590FC: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059100: BF870095
	.long 0xd71c0080                                           // 000000059104: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 000000059108: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 00000005910C: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000059110: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059118: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 00000005911C: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000059124: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059128: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 00000005912C: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 000000059134: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059138: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 00000005913C: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 000000059144: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 000000059148: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059150: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 000000059154: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 000000059158: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059160: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 000000059164: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 000000059168: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059170: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 000000059174: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 00000005917C: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 000000059184: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059190: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 000000059194: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 00000005919C: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 0000000591A8: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000591B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000591B4: BE882002
	s_cbranch_execz 64966                                      // 0000000591B8: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33d4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 0000000591BC: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000591C8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000591D0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000591D4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000591D8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000591DC: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 0000000591E4: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 0000000591F0: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000591F4: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 0000000591F8: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 000000059200: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000059204: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 000000059208: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 00000005920C: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000059210: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 000000059218: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005921C: BF870095
	.long 0xd71c0072                                           // 000000059220: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 000000059224: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000059228: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000005922C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059234: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 000000059238: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000059244: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059248: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000005924C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 000000059254: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059258: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 00000005925C: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 000000059264: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 000000059268: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059270: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 000000059274: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 000000059278: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059280: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 000000059284: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 000000059288: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059290: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 000000059294: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000005929C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 0000000592A4: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000592B0: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 0000000592B4: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 0000000592BC: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000592C8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000592D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000592D4: BE882003
	s_cbranch_execz 64897                                      // 0000000592D8: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33e0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 0000000592DC: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000592E8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000592F0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000592F4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000592F8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000592FC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000059304: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 000000059310: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000059314: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 000000059318: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000005931C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000059324: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005932C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000059330: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 000000059334: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 000000059338: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005933C: BF870095
	.long 0xd71c0072                                           // 000000059340: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000059344: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000059348: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000005934C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059354: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 000000059358: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000059364: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059368: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000005936C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000059374: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059378: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 00000005937C: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 000000059384: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 000000059388: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059390: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 000000059394: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 000000059398: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000593A0: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 0000000593A4: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 0000000593A8: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000593B0: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 0000000593B4: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000593BC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 0000000593C4: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000593D0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000593D4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000593DC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000593E8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000593F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000593F4: BE882004
	s_cbranch_execz 64828                                      // 0000000593F8: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33ec>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 0000000593FC: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000059408: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000059410: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000059414: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059418: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000005941C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000059424: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000059430: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000059434: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000059438: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000005943C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000059444: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005944C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000059450: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000059454: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000059458: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005945C: BF870095
	.long 0xd71c0072                                           // 000000059460: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000059464: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000059468: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000005946C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059474: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 000000059478: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000059484: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059488: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000005948C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000059494: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059498: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000005949C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000594A4: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000594A8: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000594B0: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 0000000594B4: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 0000000594B8: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000594C0: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 0000000594C4: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 0000000594C8: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000594D0: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 0000000594D4: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000594DC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 0000000594E4: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000594F0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000594F4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000594FC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000059508: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000059510: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000059514: BE882005
	s_cbranch_execz 64759                                      // 000000059518: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33f8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 00000005951C: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000059528: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000059530: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000059534: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059538: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000005953C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000059544: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000059550: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000059554: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000059558: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000005955C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000059564: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005956C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000059570: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000059574: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000059578: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005957C: BF870095
	.long 0xd71c0072                                           // 000000059580: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000059584: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000059588: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000005958C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059594: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 000000059598: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 0000000595A0: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000595A8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000595AC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000595B4: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000595B8: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000595BC: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000595C4: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000595C8: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000595D0: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000595D4: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 0000000595D8: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000595E0: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 0000000595E4: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 0000000595E8: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000595F0: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000595F4: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000595FC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 000000059604: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059610: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000059614: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000005961C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000059628: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000059630: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000059634: BE882006
	s_cbranch_execz 64690                                      // 000000059638: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3404>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 00000005963C: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000059648: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000059650: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000059654: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059658: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000005965C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000059664: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000059670: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000059674: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000059678: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000005967C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000059684: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005968C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000059690: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000059694: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000059698: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005969C: BF870095
	.long 0xd71c0072                                           // 0000000596A0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000596A4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000596A8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000596AC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000596B4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 0000000596B8: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000596C4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000596C8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000596CC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000596D4: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000596D8: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000596DC: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000596E4: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000596E8: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000596F0: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000596F4: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000596F8: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059700: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 000000059704: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 000000059708: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059710: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 000000059714: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000005971C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 000000059724: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059730: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000059734: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000005973C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000059748: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000059750: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000059754: BE882007
	s_cbranch_execz 64621                                      // 000000059758: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3410>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 00000005975C: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000059768: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000059770: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000059774: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059778: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000005977C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000059784: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000059790: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000059794: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000059798: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000005979C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000597A4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000597AC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000597B0: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000597B4: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000597B8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000597BC: BF870095
	.long 0xd71c0072                                           // 0000000597C0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000597C4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000597C8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000597CC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000597D4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 0000000597D8: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000597E4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000597E8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000597EC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000597F4: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000597F8: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000597FC: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 000000059804: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 000000059808: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059810: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 000000059814: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 000000059818: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059820: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 000000059824: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 000000059828: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059830: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 000000059834: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000005983C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 000000059844: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059850: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000059854: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000005985C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000059868: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000059870: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000059874: BE882000
	s_cbranch_execz 64552                                      // 000000059878: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x341c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 00000005987C: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 000000059888: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 00000005988C: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 000000059894: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000059898: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005989C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000598A0: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000598A8: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000598B4: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000598B8: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000598BC: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000598C0: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000598C8: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000598D0: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000598D4: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000598D8: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000598DC: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000598E0: BF870095
	.long 0xd71c0072                                           // 0000000598E4: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000598E8: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000598EC: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000598F0: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000598F8: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000598FC: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000059904: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059908: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 00000005990C: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 000000059914: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059918: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 00000005991C: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 000000059924: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 000000059928: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059930: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 000000059934: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 000000059938: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059940: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 000000059944: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 000000059948: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059950: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 000000059954: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 00000005995C: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 000000059964: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059970: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 000000059974: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 00000005997C: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 000000059988: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 000000059990: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000059994: BE882001
	s_cbranch_execz 64483                                      // 000000059998: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3428>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 00000005999C: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 0000000599A8: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 0000000599AC: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 0000000599B4: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000599B8: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000599BC: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 0000000599C0: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000599C8: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 0000000599D0: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000000599DC: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000599E0: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 0000000599E4: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 0000000599EC: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000599F0: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000000599F4: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000000599F8: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000000599FC: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059A00: BF870095
	.long 0xd71c0071                                           // 000000059A04: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 000000059A08: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 000000059A0C: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000059A10: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059A18: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 000000059A1C: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000059A24: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059A28: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 000000059A2C: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 000000059A34: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059A38: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 000000059A3C: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 000000059A44: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 000000059A48: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059A50: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 000000059A54: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 000000059A58: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059A60: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 000000059A64: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 000000059A68: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059A70: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 000000059A74: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 000000059A7C: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 000000059A84: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059A90: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 000000059A94: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 000000059A9C: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 000000059AA8: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 000000059AB0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000059AB4: BE882002
	s_cbranch_execz 64414                                      // 000000059AB8: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3434>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 000000059ABC: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000059AC8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000059AD0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000059AD4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059AD8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000059ADC: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 000000059AE4: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 000000059AF0: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000059AF4: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 000000059AF8: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000059AFC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 000000059B04: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000059B0C: BF870121
	v_add_f32_e32 v106, v106, v113                             // 000000059B10: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 000000059B14: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 000000059B18: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059B1C: BF870095
	.long 0xd71c006a                                           // 000000059B20: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 000000059B24: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000059B28: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000059B2C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059B34: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 000000059B38: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000059B44: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059B48: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000059B4C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 000000059B54: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059B58: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 000000059B5C: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 000000059B64: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 000000059B68: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059B70: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 000000059B74: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 000000059B78: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059B80: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 000000059B84: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 000000059B88: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059B90: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 000000059B94: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000059B9C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 000000059BA4: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059BB0: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 000000059BB4: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 000000059BBC: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000059BC8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000059BD0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000059BD4: BE882003
	s_cbranch_execz 64345                                      // 000000059BD8: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3440>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 000000059BDC: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000059BE8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000059BF0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000059BF4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059BF8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000059BFC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000059C04: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 000000059C10: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059C14: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 000000059C18: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 000000059C24: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 000000059C28: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000059C2C: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000059C34: BF870293
	v_exp_f32_e32 v106, v106                                   // 000000059C38: 7ED44B6A
	.long 0xd71c006a                                           // 000000059C3C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000059C40: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000059C44: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000059C48: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000059C4C: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 000000059C54: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059C60: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 000000059C64: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000059C68: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000059C70: BF870291
	v_rcp_f32_e32 v108, v107                                   // 000000059C74: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 000000059C78: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000059C80: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 000000059C84: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 000000059C88: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 000000059C90: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059C94: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 000000059C98: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 000000059CA0: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059CA4: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 000000059CA8: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 000000059CB0: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000059CB8: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000059CBC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 000000059CC4: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 000000059CD0: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000059CD8: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000059CDC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000059CE8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000059CF0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000059CF4: BE882004
	s_cbranch_execz 64276                                      // 000000059CF8: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x344c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 000000059CFC: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000059D08: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000059D10: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000059D14: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059D18: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000059D1C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000059D24: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000059D30: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000059D34: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000059D38: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000059D3C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000059D44: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000059D4C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000059D50: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000059D54: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000059D58: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059D5C: BF870095
	.long 0xd71c006a                                           // 000000059D60: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000059D64: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000059D68: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000059D6C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059D74: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 000000059D78: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000059D84: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059D88: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000059D8C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000059D94: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059D98: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000059D9C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000059DA4: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000059DA8: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059DB0: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 000000059DB4: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 000000059DB8: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059DC0: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 000000059DC4: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 000000059DC8: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059DD0: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 000000059DD4: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000059DDC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 000000059DE4: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059DF0: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000059DF4: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000059DFC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000059E08: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000059E10: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000059E14: BE882005
	s_cbranch_execz 64207                                      // 000000059E18: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3458>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 000000059E1C: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000059E28: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000059E30: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000059E34: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059E38: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000059E3C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000059E44: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000059E50: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000059E54: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000059E58: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000059E5C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000059E64: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000059E6C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000059E70: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000059E74: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000059E78: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059E7C: BF870095
	.long 0xd71c006a                                           // 000000059E80: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000059E84: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000059E88: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000059E8C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059E94: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 000000059E98: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 000000059EA0: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059EA8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000059EAC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000059EB4: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059EB8: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000059EBC: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000059EC4: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000059EC8: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059ED0: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000059ED4: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 000000059ED8: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059EE0: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 000000059EE4: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 000000059EE8: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059EF0: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000059EF4: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000059EFC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 000000059F04: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059F10: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000059F14: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000059F1C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000059F28: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000059F30: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000059F34: BE882006
	s_cbranch_execz 64138                                      // 000000059F38: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3464>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 000000059F3C: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000059F48: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000059F50: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000059F54: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059F58: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000059F5C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000059F64: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000059F70: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000059F74: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000059F78: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000059F7C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000059F84: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000059F8C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000059F90: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000059F94: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000059F98: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059F9C: BF870095
	.long 0xd71c006a                                           // 000000059FA0: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000059FA4: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000059FA8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000059FAC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059FB4: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 000000059FB8: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000059FC4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059FC8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000059FCC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000059FD4: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059FD8: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000059FDC: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000059FE4: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000059FE8: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059FF0: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000059FF4: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 000000059FF8: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A000: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 00000005A004: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 00000005A008: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A010: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000005A014: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000005A01C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 00000005A024: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A030: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000005A034: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000005A03C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000005A048: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005A050: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000005A054: BE882007
	s_cbranch_execz 64069                                      // 00000005A058: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3470>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 00000005A05C: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000005A068: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000005A070: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000005A074: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A078: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000005A07C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000005A084: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000005A090: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005A094: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000005A098: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000005A09C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000005A0A4: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005A0AC: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000005A0B0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000005A0B4: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000005A0B8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A0BC: BF870095
	.long 0xd71c006a                                           // 00000005A0C0: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000005A0C4: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000005A0C8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000005A0CC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A0D4: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 00000005A0D8: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000005A0E4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A0E8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000005A0EC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000005A0F4: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A0F8: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000005A0FC: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000005A104: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000005A108: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A110: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 00000005A114: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 00000005A118: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A120: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 00000005A124: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 00000005A128: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A130: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000005A134: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000005A13C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 00000005A144: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A150: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000005A154: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000005A15C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000005A168: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005A170: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000005A174: BE882000
	s_cbranch_execz 64000                                      // 00000005A178: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x347c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 00000005A17C: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 00000005A188: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 00000005A18C: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 00000005A194: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000005A198: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A19C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000005A1A0: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000005A1A8: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000005A1B4: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005A1B8: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000005A1BC: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000005A1C0: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000005A1C8: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005A1D0: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000005A1D4: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000005A1D8: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000005A1DC: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A1E0: BF870095
	.long 0xd71c006a                                           // 00000005A1E4: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000005A1E8: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000005A1EC: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000005A1F0: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A1F8: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 00000005A1FC: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000005A204: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A208: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 00000005A20C: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 00000005A214: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A218: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 00000005A21C: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 00000005A224: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 00000005A228: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A230: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 00000005A234: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 00000005A238: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A240: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 00000005A244: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 00000005A248: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A250: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 00000005A254: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 00000005A25C: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 00000005A264: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A270: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 00000005A274: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 00000005A27C: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 00000005A288: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005A290: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000005A294: BE882001
	s_cbranch_execz 63931                                      // 00000005A298: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3488>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 00000005A29C: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 00000005A2A8: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 00000005A2AC: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 00000005A2B4: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000005A2B8: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005A2BC: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 00000005A2C0: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000005A2C8: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 00000005A2D0: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 00000005A2DC: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005A2E0: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 00000005A2E4: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 00000005A2EC: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005A2F0: BF870121
	v_add_f32_e32 v105, v105, v106                             // 00000005A2F4: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 00000005A2F8: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 00000005A2FC: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A300: BF870095
	.long 0xd71c0069                                           // 00000005A304: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 00000005A308: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 00000005A30C: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000005A310: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A318: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 00000005A31C: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000005A324: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A328: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 00000005A32C: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 00000005A334: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A338: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 00000005A33C: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 00000005A344: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 00000005A348: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A350: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 00000005A354: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 00000005A358: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A360: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 00000005A364: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 00000005A368: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A370: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 00000005A374: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 00000005A37C: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 00000005A384: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A390: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 00000005A394: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 00000005A39C: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 00000005A3A8: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005A3B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000005A3B4: BE882002
	s_cbranch_execz 63862                                      // 00000005A3B8: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3494>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 00000005A3BC: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000005A3C8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000005A3D0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000005A3D4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A3D8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000005A3DC: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 00000005A3E4: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 00000005A3F0: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005A3F4: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 00000005A3F8: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000005A3FC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 00000005A404: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005A40C: BF870121
	v_add_f32_e32 v98, v98, v105                               // 00000005A410: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 00000005A414: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 00000005A418: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A41C: BF870095
	.long 0xd71c0062                                           // 00000005A420: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 00000005A424: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000005A428: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000005A42C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A434: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 00000005A438: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000005A444: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A448: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000005A44C: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 00000005A454: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A458: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 00000005A45C: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 00000005A464: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 00000005A468: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A470: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 00000005A474: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 00000005A478: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A480: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 00000005A484: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 00000005A488: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A490: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 00000005A494: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000005A49C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 00000005A4A4: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A4B0: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 00000005A4B4: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 00000005A4BC: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000005A4C8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005A4D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000005A4D4: BE882003
	s_cbranch_execz 63793                                      // 00000005A4D8: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34a0>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 00000005A4DC: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000005A4E8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000005A4F0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000005A4F4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A4F8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000005A4FC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000005A504: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 00000005A510: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A514: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 00000005A518: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 00000005A524: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 00000005A528: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000005A52C: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005A534: BF870293
	v_exp_f32_e32 v98, v98                                     // 00000005A538: 7EC44B62
	.long 0xd71c0062                                           // 00000005A53C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000005A540: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005A544: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000005A548: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000005A54C: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 00000005A554: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A560: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 00000005A564: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000005A568: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005A570: BF870291
	v_rcp_f32_e32 v100, v99                                    // 00000005A574: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 00000005A578: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005A580: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 00000005A584: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 00000005A588: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 00000005A590: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A594: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 00000005A598: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 00000005A5A0: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A5A4: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 00000005A5A8: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 00000005A5B0: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005A5B8: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000005A5BC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 00000005A5C4: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 00000005A5D0: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005A5D8: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000005A5DC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000005A5E8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005A5F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000005A5F4: BE882004
	s_cbranch_execz 63724                                      // 00000005A5F8: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34ac>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 00000005A5FC: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000005A608: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000005A610: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000005A614: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A618: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000005A61C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000005A624: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000005A630: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005A634: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000005A638: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000005A63C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000005A644: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005A64C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000005A650: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000005A654: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000005A658: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A65C: BF870095
	.long 0xd71c0062                                           // 00000005A660: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000005A664: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000005A668: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000005A66C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A674: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 00000005A678: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000005A684: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A688: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000005A68C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000005A694: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A698: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000005A69C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000005A6A4: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000005A6A8: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A6B0: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 00000005A6B4: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 00000005A6B8: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A6C0: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 00000005A6C4: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 00000005A6C8: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A6D0: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 00000005A6D4: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000005A6DC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 00000005A6E4: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A6F0: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000005A6F4: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000005A6FC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000005A708: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005A710: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000005A714: BE882005
	s_cbranch_execz 63655                                      // 00000005A718: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34b8>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 00000005A71C: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000005A728: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000005A730: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000005A734: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A738: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000005A73C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000005A744: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000005A750: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005A754: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000005A758: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000005A75C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000005A764: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005A76C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000005A770: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000005A774: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000005A778: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A77C: BF870095
	.long 0xd71c0062                                           // 00000005A780: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000005A784: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000005A788: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000005A78C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A794: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 00000005A798: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 00000005A7A0: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A7A8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000005A7AC: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000005A7B4: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A7B8: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000005A7BC: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000005A7C4: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000005A7C8: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A7D0: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 00000005A7D4: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 00000005A7D8: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A7E0: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 00000005A7E4: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 00000005A7E8: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A7F0: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 00000005A7F4: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000005A7FC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 00000005A804: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A810: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000005A814: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000005A81C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000005A828: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005A830: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000005A834: BE882006
	s_cbranch_execz 63586                                      // 00000005A838: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34c4>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 00000005A83C: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000005A848: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000005A850: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000005A854: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A858: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000005A85C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000005A864: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000005A870: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005A874: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000005A878: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000005A87C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000005A884: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005A88C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000005A890: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000005A894: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000005A898: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A89C: BF870095
	.long 0xd71c0062                                           // 00000005A8A0: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000005A8A4: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000005A8A8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000005A8AC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A8B4: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 00000005A8B8: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000005A8C4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A8C8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000005A8CC: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000005A8D4: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A8D8: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000005A8DC: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000005A8E4: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000005A8E8: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A8F0: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 00000005A8F4: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 00000005A8F8: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A900: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 00000005A904: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 00000005A908: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A910: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 00000005A914: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000005A91C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 00000005A924: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A930: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000005A934: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000005A93C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000005A948: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005A950: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000005A954: BE882007
	s_cbranch_execz 63517                                      // 00000005A958: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34d0>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 00000005A95C: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000005A968: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000005A970: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000005A974: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A978: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000005A97C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000005A984: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000005A990: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005A994: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000005A998: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000005A99C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000005A9A4: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005A9AC: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000005A9B0: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000005A9B4: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000005A9B8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A9BC: BF870095
	.long 0xd71c0062                                           // 00000005A9C0: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000005A9C4: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000005A9C8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000005A9CC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A9D4: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 00000005A9D8: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000005A9E4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A9E8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000005A9EC: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000005A9F4: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A9F8: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000005A9FC: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000005AA04: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000005AA08: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AA10: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 00000005AA14: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 00000005AA18: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AA20: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 00000005AA24: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 00000005AA28: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AA30: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 00000005AA34: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000005AA3C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 00000005AA44: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AA50: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000005AA54: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000005AA5C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000005AA68: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005AA70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000005AA74: BE882000
	s_cbranch_execz 63448                                      // 00000005AA78: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34dc>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 00000005AA7C: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 00000005AA88: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 00000005AA8C: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 00000005AA94: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000005AA98: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AA9C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000005AAA0: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000005AAA8: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000005AAB4: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005AAB8: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000005AABC: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000005AAC0: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000005AAC8: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005AAD0: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000005AAD4: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000005AAD8: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000005AADC: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AAE0: BF870095
	.long 0xd71c0062                                           // 00000005AAE4: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000005AAE8: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000005AAEC: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000005AAF0: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AAF8: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 00000005AAFC: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000005AB04: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AB08: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 00000005AB0C: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 00000005AB14: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AB18: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 00000005AB1C: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 00000005AB24: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 00000005AB28: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AB30: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 00000005AB34: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 00000005AB38: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AB40: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 00000005AB44: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 00000005AB48: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AB50: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 00000005AB54: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 00000005AB5C: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 00000005AB64: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AB70: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 00000005AB74: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 00000005AB7C: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 00000005AB88: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005AB90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000005AB94: BE882001
	s_cbranch_execz 63379                                      // 00000005AB98: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34e8>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 00000005AB9C: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 00000005ABA8: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 00000005ABAC: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 00000005ABB4: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000005ABB8: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005ABBC: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 00000005ABC0: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000005ABC8: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 00000005ABD0: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 00000005ABDC: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005ABE0: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 00000005ABE4: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 00000005ABEC: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005ABF0: BF870121
	v_add_f32_e32 v97, v97, v98                                // 00000005ABF4: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 00000005ABF8: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 00000005ABFC: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AC00: BF870095
	.long 0xd71c0061                                           // 00000005AC04: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 00000005AC08: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 00000005AC0C: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000005AC10: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AC18: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 00000005AC1C: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000005AC24: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AC28: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 00000005AC2C: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 00000005AC34: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AC38: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 00000005AC3C: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 00000005AC44: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 00000005AC48: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AC50: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 00000005AC54: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 00000005AC58: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AC60: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 00000005AC64: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 00000005AC68: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AC70: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 00000005AC74: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 00000005AC7C: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 00000005AC84: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AC90: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 00000005AC94: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 00000005AC9C: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 00000005ACA8: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005ACB0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000005ACB4: BE882002
	s_cbranch_execz 63310                                      // 00000005ACB8: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34f4>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 00000005ACBC: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000005ACC8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000005ACD0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000005ACD4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005ACD8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000005ACDC: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 00000005ACE4: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 00000005ACF0: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005ACF4: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 00000005ACF8: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000005ACFC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 00000005AD04: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005AD0C: BF870121
	v_add_f32_e32 v90, v90, v97                                // 00000005AD10: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 00000005AD14: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 00000005AD18: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AD1C: BF870095
	.long 0xd71c005a                                           // 00000005AD20: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 00000005AD24: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000005AD28: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000005AD2C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AD34: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 00000005AD38: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000005AD44: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AD48: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000005AD4C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 00000005AD54: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AD58: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 00000005AD5C: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 00000005AD64: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 00000005AD68: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AD70: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 00000005AD74: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 00000005AD78: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AD80: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 00000005AD84: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 00000005AD88: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AD90: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 00000005AD94: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000005AD9C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 00000005ADA4: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005ADB0: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 00000005ADB4: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 00000005ADBC: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000005ADC8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005ADD0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000005ADD4: BE882003
	s_cbranch_execz 63241                                      // 00000005ADD8: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3500>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 00000005ADDC: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000005ADE8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000005ADF0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000005ADF4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005ADF8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000005ADFC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000005AE04: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 00000005AE10: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AE14: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 00000005AE18: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 00000005AE24: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 00000005AE28: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000005AE2C: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005AE34: BF870293
	v_exp_f32_e32 v90, v90                                     // 00000005AE38: 7EB44B5A
	.long 0xd71c005a                                           // 00000005AE3C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000005AE40: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005AE44: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000005AE48: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000005AE4C: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 00000005AE54: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AE60: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 00000005AE64: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000005AE68: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005AE70: BF870291
	v_rcp_f32_e32 v92, v91                                     // 00000005AE74: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 00000005AE78: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005AE80: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 00000005AE84: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 00000005AE88: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 00000005AE90: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AE94: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 00000005AE98: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 00000005AEA0: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AEA4: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 00000005AEA8: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 00000005AEB0: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005AEB8: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000005AEBC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 00000005AEC4: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 00000005AED0: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005AED8: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000005AEDC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000005AEE8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005AEF0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000005AEF4: BE882004
	s_cbranch_execz 63172                                      // 00000005AEF8: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x350c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 00000005AEFC: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000005AF08: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000005AF10: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000005AF14: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AF18: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000005AF1C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000005AF24: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000005AF30: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005AF34: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000005AF38: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000005AF3C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000005AF44: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005AF4C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000005AF50: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000005AF54: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000005AF58: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AF5C: BF870095
	.long 0xd71c005a                                           // 00000005AF60: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000005AF64: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000005AF68: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000005AF6C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AF74: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 00000005AF78: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000005AF84: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AF88: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000005AF8C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000005AF94: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AF98: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000005AF9C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000005AFA4: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000005AFA8: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AFB0: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 00000005AFB4: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 00000005AFB8: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AFC0: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 00000005AFC4: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 00000005AFC8: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AFD0: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 00000005AFD4: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000005AFDC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 00000005AFE4: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AFF0: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000005AFF4: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000005AFFC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000005B008: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005B010: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000005B014: BE882005
	s_cbranch_execz 63103                                      // 00000005B018: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3518>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 00000005B01C: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000005B028: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000005B030: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000005B034: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B038: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000005B03C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000005B044: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000005B050: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005B054: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000005B058: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000005B05C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000005B064: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005B06C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000005B070: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000005B074: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000005B078: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B07C: BF870095
	.long 0xd71c005a                                           // 00000005B080: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000005B084: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000005B088: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000005B08C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B094: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 00000005B098: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 00000005B0A0: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B0A8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000005B0AC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000005B0B4: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B0B8: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000005B0BC: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000005B0C4: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000005B0C8: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B0D0: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 00000005B0D4: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 00000005B0D8: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B0E0: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 00000005B0E4: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 00000005B0E8: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B0F0: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 00000005B0F4: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000005B0FC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 00000005B104: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B110: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000005B114: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000005B11C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000005B128: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005B130: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000005B134: BE882006
	s_cbranch_execz 63034                                      // 00000005B138: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3524>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 00000005B13C: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000005B148: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000005B150: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000005B154: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B158: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000005B15C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000005B164: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000005B170: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005B174: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000005B178: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000005B17C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000005B184: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005B18C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000005B190: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000005B194: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000005B198: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B19C: BF870095
	.long 0xd71c005a                                           // 00000005B1A0: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000005B1A4: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000005B1A8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000005B1AC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B1B4: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 00000005B1B8: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000005B1C4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B1C8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000005B1CC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000005B1D4: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B1D8: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000005B1DC: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000005B1E4: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000005B1E8: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B1F0: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 00000005B1F4: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 00000005B1F8: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B200: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 00000005B204: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 00000005B208: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B210: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 00000005B214: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000005B21C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 00000005B224: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B230: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000005B234: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000005B23C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000005B248: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005B250: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000005B254: BE882007
	s_cbranch_execz 62965                                      // 00000005B258: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3530>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 00000005B25C: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000005B268: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000005B270: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000005B274: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B278: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000005B27C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000005B284: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000005B290: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005B294: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000005B298: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000005B29C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000005B2A4: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005B2AC: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000005B2B0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000005B2B4: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000005B2B8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B2BC: BF870095
	.long 0xd71c005a                                           // 00000005B2C0: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000005B2C4: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000005B2C8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000005B2CC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B2D4: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 00000005B2D8: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000005B2E4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B2E8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000005B2EC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000005B2F4: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B2F8: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000005B2FC: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000005B304: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000005B308: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B310: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 00000005B314: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 00000005B318: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B320: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 00000005B324: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 00000005B328: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B330: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 00000005B334: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000005B33C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 00000005B344: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B350: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000005B354: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000005B35C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000005B368: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005B370: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000005B374: BE882000
	s_cbranch_execz 62896                                      // 00000005B378: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x353c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 00000005B37C: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 00000005B388: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 00000005B38C: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 00000005B394: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000005B398: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B39C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000005B3A0: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000005B3A8: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000005B3B4: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005B3B8: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000005B3BC: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000005B3C0: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000005B3C8: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005B3D0: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000005B3D4: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000005B3D8: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000005B3DC: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B3E0: BF870095
	.long 0xd71c005a                                           // 00000005B3E4: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000005B3E8: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000005B3EC: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000005B3F0: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B3F8: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 00000005B3FC: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000005B404: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B408: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 00000005B40C: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 00000005B414: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B418: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 00000005B41C: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 00000005B424: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 00000005B428: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B430: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 00000005B434: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 00000005B438: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B440: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 00000005B444: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 00000005B448: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B450: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 00000005B454: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 00000005B45C: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 00000005B464: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B470: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 00000005B474: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 00000005B47C: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 00000005B488: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005B490: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000005B494: BE882001
	s_cbranch_execz 62827                                      // 00000005B498: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3548>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 00000005B49C: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 00000005B4A8: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 00000005B4AC: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 00000005B4B4: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000005B4B8: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005B4BC: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 00000005B4C0: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000005B4C8: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 00000005B4D0: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 00000005B4DC: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005B4E0: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 00000005B4E4: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 00000005B4EC: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005B4F0: BF870121
	v_add_f32_e32 v89, v89, v90                                // 00000005B4F4: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 00000005B4F8: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 00000005B4FC: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B500: BF870095
	.long 0xd71c0059                                           // 00000005B504: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 00000005B508: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000005B50C: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000005B510: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B518: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 00000005B51C: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000005B524: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B528: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 00000005B52C: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 00000005B534: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B538: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 00000005B53C: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 00000005B544: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 00000005B548: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B550: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 00000005B554: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 00000005B558: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B560: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 00000005B564: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 00000005B568: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B570: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 00000005B574: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 00000005B57C: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 00000005B584: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B590: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 00000005B594: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 00000005B59C: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 00000005B5A8: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005B5B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000005B5B4: BE882002
	s_cbranch_execz 62758                                      // 00000005B5B8: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3554>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 00000005B5BC: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000005B5C8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000005B5D0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000005B5D4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B5D8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000005B5DC: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 00000005B5E4: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 00000005B5F0: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005B5F4: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 00000005B5F8: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000005B5FC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 00000005B604: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005B60C: BF870121
	v_add_f32_e32 v82, v82, v89                                // 00000005B610: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 00000005B614: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 00000005B618: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B61C: BF870095
	.long 0xd71c0052                                           // 00000005B620: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 00000005B624: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000005B628: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000005B62C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B634: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 00000005B638: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000005B644: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B648: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000005B64C: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 00000005B654: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B658: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 00000005B65C: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 00000005B664: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 00000005B668: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B670: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 00000005B674: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 00000005B678: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B680: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 00000005B684: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 00000005B688: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B690: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 00000005B694: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000005B69C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 00000005B6A4: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B6B0: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 00000005B6B4: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 00000005B6BC: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000005B6C8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005B6D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000005B6D4: BE882003
	s_cbranch_execz 62689                                      // 00000005B6D8: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3560>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 00000005B6DC: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000005B6E8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000005B6F0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000005B6F4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B6F8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000005B6FC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000005B704: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 00000005B710: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B714: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 00000005B718: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 00000005B724: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 00000005B728: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000005B72C: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005B734: BF870293
	v_exp_f32_e32 v82, v82                                     // 00000005B738: 7EA44B52
	.long 0xd71c0052                                           // 00000005B73C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000005B740: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005B744: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000005B748: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000005B74C: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 00000005B754: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B760: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 00000005B764: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000005B768: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005B770: BF870291
	v_rcp_f32_e32 v84, v83                                     // 00000005B774: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 00000005B778: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B780: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 00000005B784: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 00000005B788: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 00000005B790: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B794: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 00000005B798: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 00000005B7A0: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B7A4: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 00000005B7A8: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 00000005B7B0: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005B7B8: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000005B7BC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 00000005B7C4: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 00000005B7D0: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005B7D8: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000005B7DC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000005B7E8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005B7F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000005B7F4: BE882004
	s_cbranch_execz 62620                                      // 00000005B7F8: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x356c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 00000005B7FC: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000005B808: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000005B810: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000005B814: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B818: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000005B81C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000005B824: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000005B830: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005B834: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000005B838: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000005B83C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000005B844: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005B84C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000005B850: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000005B854: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000005B858: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B85C: BF870095
	.long 0xd71c0052                                           // 00000005B860: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000005B864: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000005B868: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000005B86C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B874: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 00000005B878: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000005B884: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B888: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000005B88C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000005B894: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B898: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000005B89C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000005B8A4: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000005B8A8: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B8B0: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 00000005B8B4: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 00000005B8B8: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B8C0: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 00000005B8C4: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 00000005B8C8: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B8D0: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 00000005B8D4: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000005B8DC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 00000005B8E4: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B8F0: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000005B8F4: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000005B8FC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000005B908: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005B910: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000005B914: BE882005
	s_cbranch_execz 62551                                      // 00000005B918: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3578>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 00000005B91C: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000005B928: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000005B930: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000005B934: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B938: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000005B93C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000005B944: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000005B950: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005B954: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000005B958: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000005B95C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000005B964: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005B96C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000005B970: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000005B974: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000005B978: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B97C: BF870095
	.long 0xd71c0052                                           // 00000005B980: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000005B984: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000005B988: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000005B98C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B994: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 00000005B998: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 00000005B9A0: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B9A8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000005B9AC: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000005B9B4: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B9B8: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000005B9BC: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000005B9C4: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000005B9C8: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B9D0: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000005B9D4: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 00000005B9D8: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B9E0: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 00000005B9E4: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 00000005B9E8: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B9F0: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000005B9F4: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000005B9FC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 00000005BA04: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BA10: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000005BA14: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000005BA1C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000005BA28: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005BA30: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000005BA34: BE882006
	s_cbranch_execz 62482                                      // 00000005BA38: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3584>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 00000005BA3C: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000005BA48: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000005BA50: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000005BA54: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BA58: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000005BA5C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000005BA64: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000005BA70: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005BA74: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000005BA78: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000005BA7C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000005BA84: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005BA8C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000005BA90: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000005BA94: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000005BA98: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BA9C: BF870095
	.long 0xd71c0052                                           // 00000005BAA0: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000005BAA4: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000005BAA8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000005BAAC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BAB4: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 00000005BAB8: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000005BAC4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BAC8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000005BACC: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000005BAD4: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BAD8: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000005BADC: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000005BAE4: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000005BAE8: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BAF0: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000005BAF4: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 00000005BAF8: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BB00: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 00000005BB04: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 00000005BB08: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BB10: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000005BB14: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000005BB1C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 00000005BB24: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BB30: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000005BB34: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000005BB3C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000005BB48: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005BB50: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000005BB54: BE882007
	s_cbranch_execz 62413                                      // 00000005BB58: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3590>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 00000005BB5C: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000005BB68: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000005BB70: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000005BB74: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BB78: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000005BB7C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000005BB84: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000005BB90: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005BB94: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000005BB98: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000005BB9C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000005BBA4: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005BBAC: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000005BBB0: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000005BBB4: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000005BBB8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BBBC: BF870095
	.long 0xd71c0052                                           // 00000005BBC0: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000005BBC4: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000005BBC8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000005BBCC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BBD4: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 00000005BBD8: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000005BBE4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BBE8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000005BBEC: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000005BBF4: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BBF8: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000005BBFC: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000005BC04: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000005BC08: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BC10: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000005BC14: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 00000005BC18: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BC20: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 00000005BC24: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 00000005BC28: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BC30: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000005BC34: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000005BC3C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 00000005BC44: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BC50: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000005BC54: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000005BC5C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000005BC68: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005BC70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000005BC74: BE882000
	s_cbranch_execz 62344                                      // 00000005BC78: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x359c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 00000005BC7C: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 00000005BC88: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 00000005BC8C: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000005BC94: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000005BC98: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BC9C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000005BCA0: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000005BCA8: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000005BCB4: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005BCB8: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000005BCBC: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000005BCC0: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000005BCC8: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005BCD0: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000005BCD4: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000005BCD8: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000005BCDC: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BCE0: BF870095
	.long 0xd71c0052                                           // 00000005BCE4: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000005BCE8: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000005BCEC: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000005BCF0: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BCF8: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 00000005BCFC: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000005BD04: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BD08: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 00000005BD0C: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 00000005BD14: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BD18: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 00000005BD1C: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 00000005BD24: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 00000005BD28: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BD30: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 00000005BD34: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 00000005BD38: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BD40: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 00000005BD44: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 00000005BD48: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BD50: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 00000005BD54: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 00000005BD5C: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 00000005BD64: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BD70: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 00000005BD74: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 00000005BD7C: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 00000005BD88: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005BD90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000005BD94: BE882001
	s_cbranch_execz 62275                                      // 00000005BD98: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35a8>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 00000005BD9C: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 00000005BDA8: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 00000005BDAC: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 00000005BDB4: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000005BDB8: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005BDBC: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 00000005BDC0: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000005BDC8: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 00000005BDD0: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000005BDDC: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005BDE0: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 00000005BDE4: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 00000005BDEC: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005BDF0: BF870121
	v_add_f32_e32 v81, v81, v82                                // 00000005BDF4: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 00000005BDF8: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000005BDFC: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BE00: BF870095
	.long 0xd71c0051                                           // 00000005BE04: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000005BE08: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000005BE0C: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000005BE10: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BE18: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 00000005BE1C: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000005BE24: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BE28: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 00000005BE2C: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 00000005BE34: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BE38: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 00000005BE3C: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 00000005BE44: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 00000005BE48: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BE50: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 00000005BE54: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 00000005BE58: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BE60: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 00000005BE64: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 00000005BE68: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BE70: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 00000005BE74: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 00000005BE7C: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 00000005BE84: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BE90: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 00000005BE94: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 00000005BE9C: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 00000005BEA8: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005BEB0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000005BEB4: BE882002
	s_cbranch_execz 62206                                      // 00000005BEB8: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35b4>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 00000005BEBC: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000005BEC8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000005BED0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000005BED4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BED8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000005BEDC: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 00000005BEE4: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 00000005BEF0: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005BEF4: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 00000005BEF8: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000005BEFC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 00000005BF04: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005BF0C: BF870121
	v_add_f32_e32 v74, v74, v81                                // 00000005BF10: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 00000005BF14: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 00000005BF18: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BF1C: BF870095
	.long 0xd71c004a                                           // 00000005BF20: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 00000005BF24: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000005BF28: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000005BF2C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BF34: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 00000005BF38: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000005BF44: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BF48: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000005BF4C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 00000005BF54: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BF58: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 00000005BF5C: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 00000005BF64: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 00000005BF68: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BF70: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 00000005BF74: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 00000005BF78: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BF80: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 00000005BF84: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 00000005BF88: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BF90: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 00000005BF94: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000005BF9C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 00000005BFA4: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BFB0: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 00000005BFB4: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 00000005BFBC: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000005BFC8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005BFD0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000005BFD4: BE882003
	s_cbranch_execz 62137                                      // 00000005BFD8: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35c0>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 00000005BFDC: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000005BFE8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000005BFF0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000005BFF4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BFF8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000005BFFC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000005C004: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 00000005C010: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C014: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 00000005C018: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 00000005C024: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 00000005C028: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000005C02C: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005C034: BF870293
	v_exp_f32_e32 v74, v74                                     // 00000005C038: 7E944B4A
	.long 0xd71c004a                                           // 00000005C03C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000005C040: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005C044: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000005C048: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000005C04C: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 00000005C054: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C060: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 00000005C064: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000005C068: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005C070: BF870291
	v_rcp_f32_e32 v76, v75                                     // 00000005C074: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 00000005C078: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005C080: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 00000005C084: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 00000005C088: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 00000005C090: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C094: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 00000005C098: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 00000005C0A0: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C0A4: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 00000005C0A8: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 00000005C0B0: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005C0B8: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000005C0BC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 00000005C0C4: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 00000005C0D0: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005C0D8: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000005C0DC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000005C0E8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005C0F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000005C0F4: BE882004
	s_cbranch_execz 62068                                      // 00000005C0F8: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35cc>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 00000005C0FC: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000005C108: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000005C110: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000005C114: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C118: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000005C11C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000005C124: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000005C130: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005C134: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000005C138: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000005C13C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000005C144: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005C14C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000005C150: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000005C154: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000005C158: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C15C: BF870095
	.long 0xd71c004a                                           // 00000005C160: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000005C164: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000005C168: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000005C16C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C174: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 00000005C178: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000005C184: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C188: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000005C18C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000005C194: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C198: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000005C19C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000005C1A4: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 00000005C1A8: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C1B0: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 00000005C1B4: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 00000005C1B8: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C1C0: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 00000005C1C4: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 00000005C1C8: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C1D0: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 00000005C1D4: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000005C1DC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 00000005C1E4: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C1F0: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 00000005C1F4: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000005C1FC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000005C208: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005C210: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000005C214: BE882005
	s_cbranch_execz 61999                                      // 00000005C218: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35d8>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 00000005C21C: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000005C228: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000005C230: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000005C234: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C238: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000005C23C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000005C244: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000005C250: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005C254: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000005C258: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000005C25C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000005C264: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005C26C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000005C270: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000005C274: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000005C278: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C27C: BF870095
	.long 0xd71c004a                                           // 00000005C280: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000005C284: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000005C288: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000005C28C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C294: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 00000005C298: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 00000005C2A0: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C2A8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000005C2AC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000005C2B4: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C2B8: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000005C2BC: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000005C2C4: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 00000005C2C8: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C2D0: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 00000005C2D4: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 00000005C2D8: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C2E0: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 00000005C2E4: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 00000005C2E8: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C2F0: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 00000005C2F4: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000005C2FC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 00000005C304: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C310: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 00000005C314: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000005C31C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000005C328: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005C330: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000005C334: BE882006
	s_cbranch_execz 61930                                      // 00000005C338: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35e4>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 00000005C33C: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000005C348: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000005C350: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000005C354: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C358: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000005C35C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000005C364: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000005C370: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005C374: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000005C378: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000005C37C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000005C384: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005C38C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000005C390: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000005C394: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000005C398: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C39C: BF870095
	.long 0xd71c004a                                           // 00000005C3A0: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000005C3A4: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000005C3A8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000005C3AC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C3B4: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 00000005C3B8: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000005C3C4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C3C8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000005C3CC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000005C3D4: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C3D8: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000005C3DC: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000005C3E4: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 00000005C3E8: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C3F0: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 00000005C3F4: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 00000005C3F8: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C400: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 00000005C404: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 00000005C408: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C410: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 00000005C414: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000005C41C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 00000005C424: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C430: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 00000005C434: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000005C43C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000005C448: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005C450: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000005C454: BE882007
	s_cbranch_execz 61861                                      // 00000005C458: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35f0>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 00000005C45C: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000005C468: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000005C470: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000005C474: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C478: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000005C47C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000005C484: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000005C490: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005C494: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000005C498: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000005C49C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000005C4A4: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005C4AC: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000005C4B0: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000005C4B4: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000005C4B8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C4BC: BF870095
	.long 0xd71c004a                                           // 00000005C4C0: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000005C4C4: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000005C4C8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000005C4CC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C4D4: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 00000005C4D8: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000005C4E4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C4E8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000005C4EC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000005C4F4: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C4F8: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000005C4FC: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000005C504: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 00000005C508: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C510: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 00000005C514: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 00000005C518: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C520: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 00000005C524: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 00000005C528: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C530: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 00000005C534: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000005C53C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 00000005C544: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C550: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 00000005C554: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000005C55C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000005C568: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005C570: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000005C574: BE882000
	s_cbranch_execz 61792                                      // 00000005C578: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35fc>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 00000005C57C: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 00000005C588: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 00000005C58C: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000005C594: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000005C598: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C59C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000005C5A0: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000005C5A8: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000005C5B4: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005C5B8: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000005C5BC: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000005C5C0: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000005C5C8: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005C5D0: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000005C5D4: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000005C5D8: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000005C5DC: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C5E0: BF870095
	.long 0xd71c004a                                           // 00000005C5E4: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000005C5E8: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000005C5EC: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000005C5F0: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C5F8: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 00000005C5FC: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000005C604: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C608: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 00000005C60C: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 00000005C614: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C618: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 00000005C61C: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 00000005C624: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 00000005C628: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C630: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 00000005C634: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 00000005C638: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C640: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 00000005C644: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 00000005C648: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C650: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 00000005C654: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 00000005C65C: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 00000005C664: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C670: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 00000005C674: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 00000005C67C: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 00000005C688: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005C690: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000005C694: BE882001
	s_cbranch_execz 61723                                      // 00000005C698: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3608>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 00000005C69C: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 00000005C6A8: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 00000005C6AC: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 00000005C6B4: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000005C6B8: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005C6BC: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 00000005C6C0: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000005C6C8: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 00000005C6D0: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000005C6DC: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005C6E0: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 00000005C6E4: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 00000005C6EC: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005C6F0: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000005C6F4: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 00000005C6F8: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000005C6FC: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C700: BF870095
	.long 0xd71c0049                                           // 00000005C704: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000005C708: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000005C70C: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000005C710: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C718: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 00000005C71C: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000005C724: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C728: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 00000005C72C: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 00000005C734: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C738: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 00000005C73C: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 00000005C744: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 00000005C748: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C750: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 00000005C754: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 00000005C758: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C760: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 00000005C764: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 00000005C768: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C770: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 00000005C774: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 00000005C77C: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 00000005C784: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C790: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 00000005C794: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 00000005C79C: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 00000005C7A8: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005C7B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000005C7B4: BE882002
	s_cbranch_execz 61654                                      // 00000005C7B8: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3614>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 00000005C7BC: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 00000005C7C8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 00000005C7D0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000005C7D4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C7D8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000005C7DC: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 00000005C7E4: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 00000005C7F0: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005C7F4: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 00000005C7F8: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000005C7FC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 00000005C804: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005C80C: BF870121
	v_add_f32_e32 v66, v66, v73                                // 00000005C810: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 00000005C814: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 00000005C818: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C81C: BF870095
	.long 0xd71c0042                                           // 00000005C820: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 00000005C824: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000005C828: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000005C82C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C834: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 00000005C838: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000005C844: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C848: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000005C84C: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 00000005C854: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C858: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 00000005C85C: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 00000005C864: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 00000005C868: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C870: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 00000005C874: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 00000005C878: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C880: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 00000005C884: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 00000005C888: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C890: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 00000005C894: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000005C89C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 00000005C8A4: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C8B0: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 00000005C8B4: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 00000005C8BC: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 00000005C8C8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005C8D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000005C8D4: BE882003
	s_cbranch_execz 61585                                      // 00000005C8D8: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3620>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 00000005C8DC: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 00000005C8E8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 00000005C8F0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000005C8F4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C8F8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000005C8FC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000005C904: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 00000005C910: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C914: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 00000005C918: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 00000005C924: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 00000005C928: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000005C92C: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005C934: BF870293
	v_exp_f32_e32 v66, v66                                     // 00000005C938: 7E844B42
	.long 0xd71c0042                                           // 00000005C93C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 00000005C940: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005C944: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000005C948: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000005C94C: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 00000005C954: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C960: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 00000005C964: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000005C968: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005C970: BF870291
	v_rcp_f32_e32 v68, v67                                     // 00000005C974: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 00000005C978: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005C980: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 00000005C984: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 00000005C988: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 00000005C990: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C994: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 00000005C998: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 00000005C9A0: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C9A4: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 00000005C9A8: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 00000005C9B0: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005C9B8: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000005C9BC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 00000005C9C4: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 00000005C9D0: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005C9D8: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000005C9DC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 00000005C9E8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005C9F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000005C9F4: BE882004
	s_cbranch_execz 61516                                      // 00000005C9F8: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x362c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 00000005C9FC: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 00000005CA08: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 00000005CA10: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000005CA14: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CA18: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000005CA1C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000005CA24: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 00000005CA30: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005CA34: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 00000005CA38: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000005CA3C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 00000005CA44: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005CA4C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 00000005CA50: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 00000005CA54: 7E861144
	v_exp_f32_e32 v66, v66                                     // 00000005CA58: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CA5C: BF870095
	.long 0xd71c0042                                           // 00000005CA60: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 00000005CA64: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000005CA68: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000005CA6C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CA74: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 00000005CA78: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000005CA84: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CA88: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000005CA8C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 00000005CA94: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CA98: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000005CA9C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 00000005CAA4: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 00000005CAA8: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CAB0: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 00000005CAB4: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 00000005CAB8: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CAC0: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 00000005CAC4: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 00000005CAC8: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CAD0: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 00000005CAD4: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000005CADC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 00000005CAE4: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CAF0: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 00000005CAF4: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000005CAFC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 00000005CB08: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005CB10: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000005CB14: BE882005
	s_cbranch_execz 61447                                      // 00000005CB18: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3638>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 00000005CB1C: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 00000005CB28: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 00000005CB30: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000005CB34: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CB38: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000005CB3C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000005CB44: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 00000005CB50: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005CB54: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 00000005CB58: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000005CB5C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 00000005CB64: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005CB6C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 00000005CB70: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 00000005CB74: 7E861144
	v_exp_f32_e32 v66, v66                                     // 00000005CB78: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CB7C: BF870095
	.long 0xd71c0042                                           // 00000005CB80: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 00000005CB84: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000005CB88: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000005CB8C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CB94: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 00000005CB98: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 00000005CBA0: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CBA8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000005CBAC: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 00000005CBB4: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CBB8: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000005CBBC: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 00000005CBC4: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 00000005CBC8: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CBD0: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 00000005CBD4: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 00000005CBD8: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CBE0: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 00000005CBE4: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 00000005CBE8: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CBF0: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 00000005CBF4: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000005CBFC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 00000005CC04: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CC10: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 00000005CC14: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000005CC1C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 00000005CC28: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005CC30: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000005CC34: BE882006
	s_cbranch_execz 61378                                      // 00000005CC38: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3644>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 00000005CC3C: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 00000005CC48: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 00000005CC50: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000005CC54: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CC58: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000005CC5C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000005CC64: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 00000005CC70: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005CC74: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 00000005CC78: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000005CC7C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 00000005CC84: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005CC8C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 00000005CC90: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 00000005CC94: 7E861144
	v_exp_f32_e32 v66, v66                                     // 00000005CC98: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CC9C: BF870095
	.long 0xd71c0042                                           // 00000005CCA0: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 00000005CCA4: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000005CCA8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000005CCAC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CCB4: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 00000005CCB8: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000005CCC4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CCC8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000005CCCC: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 00000005CCD4: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CCD8: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000005CCDC: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 00000005CCE4: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 00000005CCE8: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CCF0: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 00000005CCF4: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 00000005CCF8: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CD00: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 00000005CD04: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 00000005CD08: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CD10: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 00000005CD14: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000005CD1C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 00000005CD24: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CD30: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 00000005CD34: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000005CD3C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 00000005CD48: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005CD50: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000005CD54: BE882007
	s_cbranch_execz 61309                                      // 00000005CD58: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3650>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 00000005CD5C: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 00000005CD68: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 00000005CD70: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000005CD74: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CD78: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000005CD7C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000005CD84: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 00000005CD90: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005CD94: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 00000005CD98: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000005CD9C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 00000005CDA4: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005CDAC: BF870121
	v_add_f32_e32 v66, v66, v67                                // 00000005CDB0: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 00000005CDB4: 7E861144
	v_exp_f32_e32 v66, v66                                     // 00000005CDB8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CDBC: BF870095
	.long 0xd71c0042                                           // 00000005CDC0: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 00000005CDC4: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000005CDC8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000005CDCC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CDD4: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 00000005CDD8: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000005CDE4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CDE8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000005CDEC: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 00000005CDF4: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CDF8: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000005CDFC: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 00000005CE04: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 00000005CE08: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CE10: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 00000005CE14: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 00000005CE18: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CE20: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 00000005CE24: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 00000005CE28: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CE30: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 00000005CE34: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000005CE3C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 00000005CE44: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CE50: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 00000005CE54: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000005CE5C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 00000005CE68: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005CE70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000005CE74: BE882000
	s_cbranch_execz 61240                                      // 00000005CE78: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x365c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 00000005CE7C: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 00000005CE88: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 00000005CE8C: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 00000005CE94: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000005CE98: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CE9C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000005CEA0: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000005CEA8: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 00000005CEB4: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005CEB8: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 00000005CEBC: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000005CEC0: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 00000005CEC8: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005CED0: BF870121
	v_add_f32_e32 v66, v66, v67                                // 00000005CED4: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 00000005CED8: 7E861144
	v_exp_f32_e32 v66, v66                                     // 00000005CEDC: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CEE0: BF870095
	.long 0xd71c0042                                           // 00000005CEE4: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 00000005CEE8: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000005CEEC: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000005CEF0: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CEF8: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 00000005CEFC: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000005CF04: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CF08: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 00000005CF0C: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 00000005CF14: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CF18: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 00000005CF1C: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 00000005CF24: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 00000005CF28: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CF30: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 00000005CF34: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 00000005CF38: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CF40: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 00000005CF44: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 00000005CF48: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CF50: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 00000005CF54: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 00000005CF5C: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 00000005CF64: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CF70: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 00000005CF74: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 00000005CF7C: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 00000005CF88: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005CF90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000005CF94: BE882001
	s_cbranch_execz 61171                                      // 00000005CF98: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3668>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 00000005CF9C: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 00000005CFA8: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 00000005CFAC: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 00000005CFB4: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000005CFB8: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005CFBC: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 00000005CFC0: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000005CFC8: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 00000005CFD0: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000005CFDC: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005CFE0: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 00000005CFE4: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 00000005CFEC: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005CFF0: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000005CFF4: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000005CFF8: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000005CFFC: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D000: BF870095
	.long 0xd71c0041                                           // 00000005D004: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000005D008: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000005D00C: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000005D010: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D018: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 00000005D01C: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000005D024: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D028: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 00000005D02C: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 00000005D034: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D038: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 00000005D03C: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 00000005D044: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 00000005D048: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D050: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 00000005D054: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 00000005D058: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D060: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 00000005D064: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 00000005D068: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D070: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 00000005D074: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 00000005D07C: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 00000005D084: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D090: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 00000005D094: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 00000005D09C: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 00000005D0A8: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005D0B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000005D0B4: BE882002
	s_cbranch_execz 61102                                      // 00000005D0B8: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3674>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 00000005D0BC: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000005D0C8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000005D0D0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000005D0D4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D0D8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000005D0DC: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 00000005D0E4: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 00000005D0F0: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005D0F4: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 00000005D0F8: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000005D0FC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 00000005D104: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D10C: BF870121
	v_add_f32_e32 v58, v58, v65                                // 00000005D110: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 00000005D114: 7E821142
	v_exp_f32_e32 v58, v58                                     // 00000005D118: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D11C: BF870095
	.long 0xd71c003a                                           // 00000005D120: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 00000005D124: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000005D128: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000005D12C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D134: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 00000005D138: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000005D144: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D148: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000005D14C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 00000005D154: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D158: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 00000005D15C: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 00000005D164: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 00000005D168: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D170: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 00000005D174: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 00000005D178: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D180: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 00000005D184: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 00000005D188: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D190: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 00000005D194: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000005D19C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 00000005D1A4: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D1B0: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 00000005D1B4: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 00000005D1BC: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000005D1C8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005D1D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000005D1D4: BE882003
	s_cbranch_execz 61033                                      // 00000005D1D8: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3680>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 00000005D1DC: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000005D1E8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000005D1F0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000005D1F4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D1F8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000005D1FC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000005D204: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 00000005D210: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D214: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 00000005D218: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 00000005D224: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 00000005D228: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000005D22C: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005D234: BF870293
	v_exp_f32_e32 v58, v58                                     // 00000005D238: 7E744B3A
	.long 0xd71c003a                                           // 00000005D23C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000005D240: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D244: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000005D248: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000005D24C: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 00000005D254: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D260: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 00000005D264: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000005D268: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005D270: BF870291
	v_rcp_f32_e32 v60, v59                                     // 00000005D274: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 00000005D278: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005D280: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 00000005D284: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 00000005D288: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 00000005D290: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D294: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 00000005D298: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 00000005D2A0: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D2A4: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 00000005D2A8: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 00000005D2B0: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D2B8: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000005D2BC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 00000005D2C4: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 00000005D2D0: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005D2D8: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000005D2DC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000005D2E8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005D2F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000005D2F4: BE882004
	s_cbranch_execz 60964                                      // 00000005D2F8: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x368c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 00000005D2FC: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000005D308: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000005D310: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000005D314: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D318: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000005D31C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000005D324: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000005D330: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005D334: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000005D338: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000005D33C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000005D344: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D34C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000005D350: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000005D354: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000005D358: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D35C: BF870095
	.long 0xd71c003a                                           // 00000005D360: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000005D364: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000005D368: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000005D36C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D374: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 00000005D378: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000005D384: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D388: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000005D38C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000005D394: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D398: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000005D39C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000005D3A4: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 00000005D3A8: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D3B0: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 00000005D3B4: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 00000005D3B8: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D3C0: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 00000005D3C4: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 00000005D3C8: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D3D0: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 00000005D3D4: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000005D3DC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 00000005D3E4: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D3F0: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000005D3F4: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000005D3FC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000005D408: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005D410: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000005D414: BE882005
	s_cbranch_execz 60895                                      // 00000005D418: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3698>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 00000005D41C: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000005D428: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000005D430: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000005D434: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D438: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000005D43C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000005D444: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000005D450: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005D454: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000005D458: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000005D45C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000005D464: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D46C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000005D470: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000005D474: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000005D478: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D47C: BF870095
	.long 0xd71c003a                                           // 00000005D480: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000005D484: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000005D488: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000005D48C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D494: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 00000005D498: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 00000005D4A0: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D4A8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000005D4AC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000005D4B4: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D4B8: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000005D4BC: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000005D4C4: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 00000005D4C8: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D4D0: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000005D4D4: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 00000005D4D8: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D4E0: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 00000005D4E4: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 00000005D4E8: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D4F0: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000005D4F4: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000005D4FC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 00000005D504: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D510: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000005D514: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000005D51C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000005D528: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005D530: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000005D534: BE882006
	s_cbranch_execz 60826                                      // 00000005D538: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36a4>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 00000005D53C: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000005D548: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000005D550: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000005D554: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D558: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000005D55C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000005D564: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000005D570: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005D574: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000005D578: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000005D57C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000005D584: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D58C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000005D590: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000005D594: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000005D598: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D59C: BF870095
	.long 0xd71c003a                                           // 00000005D5A0: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000005D5A4: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000005D5A8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000005D5AC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D5B4: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 00000005D5B8: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000005D5C4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D5C8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000005D5CC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000005D5D4: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D5D8: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000005D5DC: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000005D5E4: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 00000005D5E8: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D5F0: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000005D5F4: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 00000005D5F8: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D600: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 00000005D604: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 00000005D608: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D610: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000005D614: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000005D61C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 00000005D624: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D630: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000005D634: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000005D63C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000005D648: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005D650: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000005D654: BE882007
	s_cbranch_execz 60757                                      // 00000005D658: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36b0>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 00000005D65C: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000005D668: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000005D670: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000005D674: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D678: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000005D67C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000005D684: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000005D690: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005D694: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000005D698: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000005D69C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000005D6A4: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D6AC: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000005D6B0: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000005D6B4: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000005D6B8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D6BC: BF870095
	.long 0xd71c003a                                           // 00000005D6C0: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000005D6C4: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000005D6C8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000005D6CC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D6D4: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 00000005D6D8: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000005D6E4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D6E8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000005D6EC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000005D6F4: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D6F8: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000005D6FC: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000005D704: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 00000005D708: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D710: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000005D714: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 00000005D718: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D720: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 00000005D724: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 00000005D728: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D730: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000005D734: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000005D73C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 00000005D744: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D750: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000005D754: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000005D75C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000005D768: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005D770: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000005D774: BE882000
	s_cbranch_execz 60688                                      // 00000005D778: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36bc>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 00000005D77C: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 00000005D788: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 00000005D78C: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 00000005D794: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000005D798: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D79C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000005D7A0: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000005D7A8: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000005D7B4: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005D7B8: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000005D7BC: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000005D7C0: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000005D7C8: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D7D0: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000005D7D4: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000005D7D8: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000005D7DC: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D7E0: BF870095
	.long 0xd71c003a                                           // 00000005D7E4: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000005D7E8: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000005D7EC: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000005D7F0: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D7F8: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 00000005D7FC: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000005D804: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D808: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 00000005D80C: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 00000005D814: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D818: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000005D81C: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000005D824: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 00000005D828: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D830: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 00000005D834: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 00000005D838: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D840: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 00000005D844: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 00000005D848: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D850: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 00000005D854: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 00000005D85C: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 00000005D864: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D870: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 00000005D874: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 00000005D87C: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 00000005D888: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005D890: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000005D894: BE882001
	s_cbranch_execz 60619                                      // 00000005D898: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36c8>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 00000005D89C: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 00000005D8A8: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 00000005D8AC: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 00000005D8B4: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000005D8B8: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D8BC: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 00000005D8C0: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000005D8C8: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 00000005D8D0: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000005D8DC: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005D8E0: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 00000005D8E4: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 00000005D8EC: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D8F0: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000005D8F4: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000005D8F8: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000005D8FC: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D900: BF870095
	.long 0xd71c0039                                           // 00000005D904: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000005D908: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000005D90C: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000005D910: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D918: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 00000005D91C: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000005D924: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D928: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 00000005D92C: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 00000005D934: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D938: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 00000005D93C: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 00000005D944: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 00000005D948: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D950: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 00000005D954: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 00000005D958: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D960: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 00000005D964: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 00000005D968: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D970: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 00000005D974: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 00000005D97C: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 00000005D984: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D990: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 00000005D994: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 00000005D99C: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 00000005D9A8: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005D9B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000005D9B4: BE882002
	s_cbranch_execz 60550                                      // 00000005D9B8: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36d4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 00000005D9BC: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000005D9C8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000005D9D0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000005D9D4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D9D8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000005D9DC: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 00000005D9E4: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 00000005D9F0: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005D9F4: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 00000005D9F8: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000005D9FC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 00000005DA04: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DA0C: BF870121
	v_add_f32_e32 v50, v50, v57                                // 00000005DA10: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 00000005DA14: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 00000005DA18: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DA1C: BF870095
	.long 0xd71c0032                                           // 00000005DA20: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 00000005DA24: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000005DA28: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000005DA2C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DA34: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 00000005DA38: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000005DA44: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DA48: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000005DA4C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 00000005DA54: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DA58: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 00000005DA5C: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 00000005DA64: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 00000005DA68: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DA70: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 00000005DA74: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 00000005DA78: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DA80: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 00000005DA84: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 00000005DA88: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DA90: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 00000005DA94: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000005DA9C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 00000005DAA4: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DAB0: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 00000005DAB4: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 00000005DABC: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000005DAC8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005DAD0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000005DAD4: BE882003
	s_cbranch_execz 60481                                      // 00000005DAD8: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36e0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 00000005DADC: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000005DAE8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000005DAF0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000005DAF4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DAF8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000005DAFC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000005DB04: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 00000005DB10: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DB14: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 00000005DB18: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 00000005DB24: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 00000005DB28: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000005DB2C: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005DB34: BF870293
	v_exp_f32_e32 v50, v50                                     // 00000005DB38: 7E644B32
	.long 0xd71c0032                                           // 00000005DB3C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000005DB40: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DB44: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000005DB48: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000005DB4C: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 00000005DB54: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DB60: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 00000005DB64: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000005DB68: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005DB70: BF870291
	v_rcp_f32_e32 v52, v51                                     // 00000005DB74: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 00000005DB78: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005DB80: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 00000005DB84: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 00000005DB88: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 00000005DB90: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DB94: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 00000005DB98: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 00000005DBA0: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DBA4: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 00000005DBA8: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 00000005DBB0: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DBB8: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000005DBBC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 00000005DBC4: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 00000005DBD0: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005DBD8: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000005DBDC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000005DBE8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005DBF0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000005DBF4: BE882004
	s_cbranch_execz 60412                                      // 00000005DBF8: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36ec>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 00000005DBFC: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000005DC08: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000005DC10: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000005DC14: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DC18: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000005DC1C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000005DC24: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000005DC30: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005DC34: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000005DC38: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000005DC3C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000005DC44: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DC4C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000005DC50: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000005DC54: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000005DC58: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DC5C: BF870095
	.long 0xd71c0032                                           // 00000005DC60: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000005DC64: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000005DC68: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000005DC6C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DC74: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 00000005DC78: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000005DC84: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DC88: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000005DC8C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000005DC94: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DC98: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000005DC9C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000005DCA4: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 00000005DCA8: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DCB0: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 00000005DCB4: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 00000005DCB8: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DCC0: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 00000005DCC4: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 00000005DCC8: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DCD0: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 00000005DCD4: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000005DCDC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 00000005DCE4: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DCF0: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000005DCF4: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000005DCFC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000005DD08: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005DD10: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000005DD14: BE882005
	s_cbranch_execz 60343                                      // 00000005DD18: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36f8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 00000005DD1C: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000005DD28: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000005DD30: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000005DD34: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DD38: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000005DD3C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000005DD44: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000005DD50: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005DD54: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000005DD58: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000005DD5C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000005DD64: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DD6C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000005DD70: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000005DD74: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000005DD78: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DD7C: BF870095
	.long 0xd71c0032                                           // 00000005DD80: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000005DD84: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000005DD88: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000005DD8C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DD94: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 00000005DD98: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 00000005DDA0: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DDA8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000005DDAC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000005DDB4: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DDB8: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000005DDBC: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000005DDC4: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 00000005DDC8: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DDD0: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 00000005DDD4: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 00000005DDD8: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DDE0: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 00000005DDE4: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 00000005DDE8: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DDF0: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 00000005DDF4: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000005DDFC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 00000005DE04: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DE10: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000005DE14: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000005DE1C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000005DE28: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005DE30: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000005DE34: BE882006
	s_cbranch_execz 60274                                      // 00000005DE38: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3704>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 00000005DE3C: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000005DE48: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000005DE50: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000005DE54: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DE58: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000005DE5C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000005DE64: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000005DE70: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005DE74: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000005DE78: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000005DE7C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000005DE84: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DE8C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000005DE90: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000005DE94: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000005DE98: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DE9C: BF870095
	.long 0xd71c0032                                           // 00000005DEA0: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000005DEA4: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000005DEA8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000005DEAC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DEB4: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 00000005DEB8: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000005DEC4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DEC8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000005DECC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000005DED4: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DED8: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000005DEDC: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000005DEE4: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 00000005DEE8: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DEF0: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 00000005DEF4: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 00000005DEF8: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DF00: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 00000005DF04: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 00000005DF08: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DF10: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 00000005DF14: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000005DF1C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 00000005DF24: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DF30: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000005DF34: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000005DF3C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000005DF48: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005DF50: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000005DF54: BE882007
	s_cbranch_execz 60205                                      // 00000005DF58: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3710>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 00000005DF5C: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000005DF68: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000005DF70: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000005DF74: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DF78: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000005DF7C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000005DF84: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000005DF90: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005DF94: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000005DF98: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000005DF9C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000005DFA4: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DFAC: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000005DFB0: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000005DFB4: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000005DFB8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DFBC: BF870095
	.long 0xd71c0032                                           // 00000005DFC0: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000005DFC4: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000005DFC8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000005DFCC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DFD4: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 00000005DFD8: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000005DFE4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DFE8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000005DFEC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000005DFF4: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DFF8: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000005DFFC: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000005E004: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 00000005E008: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E010: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 00000005E014: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 00000005E018: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E020: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 00000005E024: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 00000005E028: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E030: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 00000005E034: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000005E03C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 00000005E044: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E050: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000005E054: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000005E05C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000005E068: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005E070: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000005E074: BE882000
	s_cbranch_execz 60136                                      // 00000005E078: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x371c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 00000005E07C: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 00000005E088: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 00000005E08C: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 00000005E094: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000005E098: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E09C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000005E0A0: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000005E0A8: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000005E0B4: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005E0B8: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 00000005E0BC: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000005E0C0: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000005E0C8: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005E0D0: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000005E0D4: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000005E0D8: 7E661134
	v_exp_f32_e32 v50, v50                                     // 00000005E0DC: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E0E0: BF870095
	.long 0xd71c0032                                           // 00000005E0E4: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000005E0E8: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 00000005E0EC: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000005E0F0: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E0F8: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 00000005E0FC: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000005E104: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E108: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 00000005E10C: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 00000005E114: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E118: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000005E11C: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000005E124: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 00000005E128: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E130: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 00000005E134: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 00000005E138: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E140: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 00000005E144: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 00000005E148: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E150: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 00000005E154: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 00000005E15C: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 00000005E164: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E170: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 00000005E174: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 00000005E17C: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 00000005E188: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005E190: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000005E194: BE882001
	s_cbranch_execz 60067                                      // 00000005E198: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3728>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 00000005E19C: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 00000005E1A8: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 00000005E1AC: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 00000005E1B4: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000005E1B8: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005E1BC: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 00000005E1C0: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000005E1C8: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 00000005E1D0: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000005E1DC: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005E1E0: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 00000005E1E4: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 00000005E1EC: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005E1F0: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000005E1F4: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000005E1F8: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000005E1FC: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E200: BF870095
	.long 0xd71c0031                                           // 00000005E204: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000005E208: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000005E20C: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000005E210: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E218: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 00000005E21C: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000005E224: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E228: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 00000005E22C: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 00000005E234: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E238: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 00000005E23C: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 00000005E244: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 00000005E248: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E250: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 00000005E254: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 00000005E258: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E260: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 00000005E264: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 00000005E268: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E270: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 00000005E274: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 00000005E27C: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 00000005E284: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E290: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 00000005E294: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 00000005E29C: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 00000005E2A8: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005E2B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000005E2B4: BE882002
	s_cbranch_execz 59998                                      // 00000005E2B8: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3734>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 00000005E2BC: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000005E2C8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000005E2D0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000005E2D4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E2D8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000005E2DC: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 00000005E2E4: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 00000005E2F0: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005E2F4: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 00000005E2F8: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000005E2FC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 00000005E304: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005E30C: BF870121
	v_add_f32_e32 v42, v42, v49                                // 00000005E310: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 00000005E314: 7E621132
	v_exp_f32_e32 v42, v42                                     // 00000005E318: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E31C: BF870095
	.long 0xd71c002a                                           // 00000005E320: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 00000005E324: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000005E328: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000005E32C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E334: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 00000005E338: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000005E344: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E348: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000005E34C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 00000005E354: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E358: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 00000005E35C: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 00000005E364: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 00000005E368: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E370: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 00000005E374: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 00000005E378: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E380: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 00000005E384: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 00000005E388: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E390: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 00000005E394: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000005E39C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 00000005E3A4: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E3B0: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 00000005E3B4: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 00000005E3BC: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000005E3C8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005E3D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000005E3D4: BE882003
	s_cbranch_execz 59929                                      // 00000005E3D8: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3740>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 00000005E3DC: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000005E3E8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000005E3F0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000005E3F4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E3F8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000005E3FC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000005E404: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 00000005E410: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E414: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 00000005E418: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 00000005E424: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 00000005E428: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000005E42C: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005E434: BF870293
	v_exp_f32_e32 v42, v42                                     // 00000005E438: 7E544B2A
	.long 0xd71c002a                                           // 00000005E43C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000005E440: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005E444: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000005E448: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000005E44C: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 00000005E454: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E460: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 00000005E464: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000005E468: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005E470: BF870291
	v_rcp_f32_e32 v44, v43                                     // 00000005E474: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 00000005E478: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005E480: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 00000005E484: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 00000005E488: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 00000005E490: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E494: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 00000005E498: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 00000005E4A0: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E4A4: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 00000005E4A8: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 00000005E4B0: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005E4B8: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000005E4BC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 00000005E4C4: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 00000005E4D0: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005E4D8: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000005E4DC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000005E4E8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005E4F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000005E4F4: BE882004
	s_cbranch_execz 59860                                      // 00000005E4F8: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x374c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 00000005E4FC: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000005E508: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000005E510: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000005E514: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E518: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000005E51C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000005E524: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000005E530: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005E534: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000005E538: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000005E53C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000005E544: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005E54C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000005E550: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000005E554: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000005E558: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E55C: BF870095
	.long 0xd71c002a                                           // 00000005E560: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000005E564: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000005E568: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000005E56C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E574: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 00000005E578: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000005E584: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E588: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000005E58C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000005E594: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E598: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000005E59C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000005E5A4: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 00000005E5A8: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E5B0: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 00000005E5B4: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 00000005E5B8: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E5C0: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 00000005E5C4: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 00000005E5C8: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E5D0: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 00000005E5D4: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000005E5DC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 00000005E5E4: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E5F0: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000005E5F4: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000005E5FC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000005E608: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005E610: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000005E614: BE882005
	s_cbranch_execz 59791                                      // 00000005E618: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3758>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 00000005E61C: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000005E628: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000005E630: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000005E634: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E638: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000005E63C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000005E644: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000005E650: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005E654: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000005E658: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000005E65C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000005E664: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005E66C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000005E670: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000005E674: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000005E678: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E67C: BF870095
	.long 0xd71c002a                                           // 00000005E680: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000005E684: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000005E688: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000005E68C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E694: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 00000005E698: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 00000005E6A0: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E6A8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000005E6AC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000005E6B4: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E6B8: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000005E6BC: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000005E6C4: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 00000005E6C8: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E6D0: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 00000005E6D4: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 00000005E6D8: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E6E0: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 00000005E6E4: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 00000005E6E8: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E6F0: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 00000005E6F4: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000005E6FC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 00000005E704: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E710: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000005E714: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000005E71C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000005E728: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005E730: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000005E734: BE882006
	s_cbranch_execz 59722                                      // 00000005E738: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3764>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 00000005E73C: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000005E748: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000005E750: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000005E754: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E758: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000005E75C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000005E764: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000005E770: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005E774: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000005E778: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000005E77C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000005E784: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005E78C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000005E790: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000005E794: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000005E798: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E79C: BF870095
	.long 0xd71c002a                                           // 00000005E7A0: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000005E7A4: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000005E7A8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000005E7AC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E7B4: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 00000005E7B8: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000005E7C4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E7C8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000005E7CC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000005E7D4: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E7D8: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000005E7DC: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000005E7E4: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 00000005E7E8: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E7F0: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 00000005E7F4: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 00000005E7F8: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E800: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 00000005E804: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 00000005E808: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E810: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 00000005E814: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000005E81C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 00000005E824: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E830: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000005E834: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000005E83C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000005E848: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005E850: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000005E854: BE882007
	s_cbranch_execz 59653                                      // 00000005E858: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3770>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 00000005E85C: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000005E868: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000005E870: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000005E874: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E878: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000005E87C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000005E884: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000005E890: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005E894: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000005E898: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000005E89C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000005E8A4: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005E8AC: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000005E8B0: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000005E8B4: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000005E8B8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E8BC: BF870095
	.long 0xd71c002a                                           // 00000005E8C0: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000005E8C4: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000005E8C8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000005E8CC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E8D4: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 00000005E8D8: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000005E8E4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E8E8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000005E8EC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000005E8F4: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E8F8: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000005E8FC: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000005E904: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 00000005E908: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E910: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 00000005E914: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 00000005E918: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E920: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 00000005E924: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 00000005E928: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E930: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 00000005E934: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000005E93C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 00000005E944: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E950: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000005E954: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000005E95C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000005E968: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005E970: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000005E974: BE882000
	s_cbranch_execz 59584                                      // 00000005E978: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x377c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 00000005E97C: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 00000005E988: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 00000005E98C: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 00000005E994: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000005E998: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E99C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000005E9A0: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000005E9A8: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000005E9B4: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005E9B8: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000005E9BC: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000005E9C0: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000005E9C8: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005E9D0: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000005E9D4: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000005E9D8: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000005E9DC: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E9E0: BF870095
	.long 0xd71c002a                                           // 00000005E9E4: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000005E9E8: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000005E9EC: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000005E9F0: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E9F8: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 00000005E9FC: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000005EA04: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EA08: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 00000005EA0C: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 00000005EA14: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EA18: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 00000005EA1C: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000005EA24: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 00000005EA28: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EA30: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 00000005EA34: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 00000005EA38: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EA40: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 00000005EA44: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 00000005EA48: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EA50: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 00000005EA54: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 00000005EA5C: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 00000005EA64: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EA70: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 00000005EA74: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 00000005EA7C: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 00000005EA88: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005EA90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000005EA94: BE882001
	s_cbranch_execz 59515                                      // 00000005EA98: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3788>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 00000005EA9C: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 00000005EAA8: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 00000005EAAC: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 00000005EAB4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000005EAB8: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005EABC: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 00000005EAC0: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000005EAC8: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 00000005EAD0: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000005EADC: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005EAE0: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 00000005EAE4: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 00000005EAEC: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005EAF0: BF870121
	v_add_f32_e32 v41, v41, v42                                // 00000005EAF4: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000005EAF8: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000005EAFC: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EB00: BF870095
	.long 0xd71c0029                                           // 00000005EB04: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000005EB08: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000005EB0C: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000005EB10: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EB18: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 00000005EB1C: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000005EB24: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EB28: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 00000005EB2C: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 00000005EB34: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EB38: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 00000005EB3C: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 00000005EB44: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 00000005EB48: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EB50: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 00000005EB54: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 00000005EB58: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EB60: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 00000005EB64: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 00000005EB68: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EB70: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 00000005EB74: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 00000005EB7C: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 00000005EB84: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EB90: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 00000005EB94: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 00000005EB9C: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 00000005EBA8: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005EBB0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000005EBB4: BE882002
	s_cbranch_execz 59446                                      // 00000005EBB8: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3794>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 00000005EBBC: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000005EBC8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000005EBD0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000005EBD4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EBD8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000005EBDC: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 00000005EBE4: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 00000005EBF0: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005EBF4: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 00000005EBF8: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000005EBFC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 00000005EC04: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005EC0C: BF870121
	v_add_f32_e32 v34, v34, v41                                // 00000005EC10: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 00000005EC14: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 00000005EC18: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EC1C: BF870095
	.long 0xd71c0022                                           // 00000005EC20: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 00000005EC24: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000005EC28: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000005EC2C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EC34: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 00000005EC38: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000005EC44: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EC48: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000005EC4C: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 00000005EC54: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EC58: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 00000005EC5C: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 00000005EC64: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 00000005EC68: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EC70: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 00000005EC74: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 00000005EC78: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EC80: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 00000005EC84: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 00000005EC88: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EC90: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 00000005EC94: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000005EC9C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 00000005ECA4: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005ECB0: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 00000005ECB4: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 00000005ECBC: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000005ECC8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005ECD0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000005ECD4: BE882003
	s_cbranch_execz 59377                                      // 00000005ECD8: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37a0>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 00000005ECDC: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000005ECE8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000005ECF0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000005ECF4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005ECF8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000005ECFC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000005ED04: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 00000005ED10: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005ED14: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 00000005ED18: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 00000005ED24: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 00000005ED28: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000005ED2C: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005ED34: BF870293
	v_exp_f32_e32 v34, v34                                     // 00000005ED38: 7E444B22
	.long 0xd71c0022                                           // 00000005ED3C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000005ED40: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005ED44: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000005ED48: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000005ED4C: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 00000005ED54: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005ED60: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 00000005ED64: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000005ED68: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005ED70: BF870291
	v_rcp_f32_e32 v36, v35                                     // 00000005ED74: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 00000005ED78: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005ED80: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 00000005ED84: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 00000005ED88: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 00000005ED90: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005ED94: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 00000005ED98: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 00000005EDA0: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EDA4: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 00000005EDA8: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 00000005EDB0: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005EDB8: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000005EDBC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 00000005EDC4: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 00000005EDD0: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005EDD8: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000005EDDC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000005EDE8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005EDF0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000005EDF4: BE882004
	s_cbranch_execz 59308                                      // 00000005EDF8: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37ac>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 00000005EDFC: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000005EE08: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000005EE10: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000005EE14: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EE18: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000005EE1C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000005EE24: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000005EE30: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005EE34: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000005EE38: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000005EE3C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000005EE44: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005EE4C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000005EE50: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000005EE54: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000005EE58: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EE5C: BF870095
	.long 0xd71c0022                                           // 00000005EE60: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000005EE64: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000005EE68: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000005EE6C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EE74: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 00000005EE78: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000005EE84: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EE88: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000005EE8C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000005EE94: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EE98: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000005EE9C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000005EEA4: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 00000005EEA8: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EEB0: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 00000005EEB4: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 00000005EEB8: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EEC0: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 00000005EEC4: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 00000005EEC8: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EED0: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 00000005EED4: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000005EEDC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 00000005EEE4: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EEF0: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000005EEF4: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000005EEFC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000005EF08: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005EF10: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000005EF14: BE882005
	s_cbranch_execz 59239                                      // 00000005EF18: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37b8>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 00000005EF1C: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000005EF28: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000005EF30: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000005EF34: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EF38: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000005EF3C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000005EF44: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000005EF50: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005EF54: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000005EF58: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000005EF5C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000005EF64: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005EF6C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000005EF70: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000005EF74: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000005EF78: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EF7C: BF870095
	.long 0xd71c0022                                           // 00000005EF80: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000005EF84: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000005EF88: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000005EF8C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EF94: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 00000005EF98: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 00000005EFA0: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EFA8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000005EFAC: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000005EFB4: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EFB8: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000005EFBC: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000005EFC4: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 00000005EFC8: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EFD0: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 00000005EFD4: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 00000005EFD8: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EFE0: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 00000005EFE4: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 00000005EFE8: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EFF0: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 00000005EFF4: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000005EFFC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 00000005F004: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F010: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000005F014: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000005F01C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000005F028: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005F030: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000005F034: BE882006
	s_cbranch_execz 59170                                      // 00000005F038: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37c4>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 00000005F03C: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000005F048: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000005F050: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000005F054: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F058: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000005F05C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000005F064: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000005F070: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005F074: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000005F078: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000005F07C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000005F084: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005F08C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000005F090: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000005F094: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000005F098: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F09C: BF870095
	.long 0xd71c0022                                           // 00000005F0A0: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000005F0A4: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000005F0A8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000005F0AC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F0B4: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 00000005F0B8: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000005F0C4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F0C8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000005F0CC: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000005F0D4: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F0D8: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000005F0DC: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000005F0E4: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 00000005F0E8: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F0F0: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 00000005F0F4: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 00000005F0F8: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F100: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 00000005F104: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 00000005F108: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F110: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 00000005F114: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000005F11C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 00000005F124: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F130: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000005F134: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000005F13C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000005F148: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005F150: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000005F154: BE882007
	s_cbranch_execz 59101                                      // 00000005F158: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37d0>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 00000005F15C: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000005F168: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000005F170: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000005F174: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F178: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000005F17C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000005F184: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000005F190: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005F194: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000005F198: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000005F19C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000005F1A4: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005F1AC: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000005F1B0: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000005F1B4: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000005F1B8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F1BC: BF870095
	.long 0xd71c0022                                           // 00000005F1C0: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000005F1C4: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000005F1C8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000005F1CC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F1D4: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 00000005F1D8: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000005F1E4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F1E8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000005F1EC: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000005F1F4: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F1F8: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000005F1FC: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000005F204: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 00000005F208: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F210: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 00000005F214: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 00000005F218: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F220: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 00000005F224: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 00000005F228: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F230: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 00000005F234: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000005F23C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 00000005F244: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F250: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000005F254: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000005F25C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000005F268: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005F270: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000005F274: BE882000
	s_cbranch_execz 59032                                      // 00000005F278: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37dc>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 00000005F27C: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 00000005F288: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 00000005F28C: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 00000005F294: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000005F298: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F29C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000005F2A0: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000005F2A8: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000005F2B4: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005F2B8: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000005F2BC: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000005F2C0: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000005F2C8: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005F2D0: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000005F2D4: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000005F2D8: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000005F2DC: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F2E0: BF870095
	.long 0xd71c0022                                           // 00000005F2E4: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000005F2E8: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000005F2EC: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000005F2F0: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F2F8: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 00000005F2FC: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000005F304: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F308: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 00000005F30C: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 00000005F314: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F318: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 00000005F31C: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 00000005F324: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 00000005F328: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F330: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 00000005F334: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 00000005F338: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F340: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 00000005F344: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 00000005F348: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F350: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 00000005F354: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 00000005F35C: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 00000005F364: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F370: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 00000005F374: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 00000005F37C: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 00000005F388: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005F390: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000005F394: BE882001
	s_cbranch_execz 58963                                      // 00000005F398: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37e8>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 00000005F39C: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 00000005F3A8: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 00000005F3AC: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 00000005F3B4: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000005F3B8: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005F3BC: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 00000005F3C0: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000005F3C8: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 00000005F3D0: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000005F3DC: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005F3E0: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 00000005F3E4: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 00000005F3EC: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005F3F0: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000005F3F4: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000005F3F8: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000005F3FC: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F400: BF870095
	.long 0xd71c0021                                           // 00000005F404: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000005F408: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000005F40C: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000005F410: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F418: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 00000005F41C: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000005F424: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F428: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 00000005F42C: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 00000005F434: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F438: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 00000005F43C: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 00000005F444: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 00000005F448: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F450: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 00000005F454: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 00000005F458: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F460: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 00000005F464: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 00000005F468: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F470: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 00000005F474: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 00000005F47C: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 00000005F484: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F490: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 00000005F494: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 00000005F49C: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 00000005F4A8: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005F4B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000005F4B4: BE882002
	s_cbranch_execz 58894                                      // 00000005F4B8: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37f4>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 00000005F4BC: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000005F4C8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000005F4D0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000005F4D4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F4D8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000005F4DC: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 00000005F4E4: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 00000005F4F0: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005F4F4: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 00000005F4F8: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000005F4FC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 00000005F504: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005F50C: BF870121
	v_add_f32_e32 v26, v26, v33                                // 00000005F510: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 00000005F514: 7E421122
	v_exp_f32_e32 v26, v26                                     // 00000005F518: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F51C: BF870095
	.long 0xd71c001a                                           // 00000005F520: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 00000005F524: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000005F528: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000005F52C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F534: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 00000005F538: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000005F544: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F548: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000005F54C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 00000005F554: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F558: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 00000005F55C: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 00000005F564: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 00000005F568: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F570: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 00000005F574: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 00000005F578: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F580: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 00000005F584: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 00000005F588: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F590: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 00000005F594: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000005F59C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 00000005F5A4: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F5B0: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 00000005F5B4: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 00000005F5BC: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000005F5C8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005F5D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000005F5D4: BE882003
	s_cbranch_execz 58825                                      // 00000005F5D8: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3800>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 00000005F5DC: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000005F5E8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000005F5F0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000005F5F4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F5F8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000005F5FC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000005F604: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 00000005F610: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F614: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 00000005F618: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 00000005F624: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 00000005F628: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000005F62C: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005F634: BF870293
	v_exp_f32_e32 v26, v26                                     // 00000005F638: 7E344B1A
	.long 0xd71c001a                                           // 00000005F63C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000005F640: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005F644: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000005F648: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000005F64C: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 00000005F654: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F660: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 00000005F664: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000005F668: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005F670: BF870291
	v_rcp_f32_e32 v28, v27                                     // 00000005F674: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 00000005F678: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005F680: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 00000005F684: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 00000005F688: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 00000005F690: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F694: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 00000005F698: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 00000005F6A0: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F6A4: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 00000005F6A8: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 00000005F6B0: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005F6B8: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000005F6BC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 00000005F6C4: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000005F6D0: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005F6D8: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000005F6DC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000005F6E8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005F6F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000005F6F4: BE882004
	s_cbranch_execz 58756                                      // 00000005F6F8: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x380c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 00000005F6FC: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000005F708: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000005F710: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000005F714: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F718: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000005F71C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000005F724: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000005F730: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005F734: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000005F738: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000005F73C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000005F744: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005F74C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000005F750: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000005F754: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000005F758: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F75C: BF870095
	.long 0xd71c001a                                           // 00000005F760: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000005F764: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000005F768: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000005F76C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F774: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 00000005F778: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000005F784: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F788: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000005F78C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000005F794: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F798: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000005F79C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000005F7A4: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000005F7A8: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F7B0: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 00000005F7B4: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 00000005F7B8: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F7C0: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 00000005F7C4: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 00000005F7C8: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F7D0: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 00000005F7D4: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000005F7DC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 00000005F7E4: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F7F0: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000005F7F4: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000005F7FC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000005F808: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005F810: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000005F814: BE882005
	s_cbranch_execz 58687                                      // 00000005F818: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3818>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 00000005F81C: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000005F828: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000005F830: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000005F834: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F838: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000005F83C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000005F844: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000005F850: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005F854: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000005F858: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000005F85C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000005F864: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005F86C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000005F870: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000005F874: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000005F878: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F87C: BF870095
	.long 0xd71c001a                                           // 00000005F880: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000005F884: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000005F888: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000005F88C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F894: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 00000005F898: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 00000005F8A0: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F8A8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000005F8AC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000005F8B4: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F8B8: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000005F8BC: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000005F8C4: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000005F8C8: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F8D0: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 00000005F8D4: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 00000005F8D8: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F8E0: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 00000005F8E4: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 00000005F8E8: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F8F0: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 00000005F8F4: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000005F8FC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 00000005F904: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F910: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000005F914: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000005F91C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000005F928: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005F930: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000005F934: BE882006
	s_cbranch_execz 58618                                      // 00000005F938: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3824>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 00000005F93C: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000005F948: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000005F950: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000005F954: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F958: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000005F95C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000005F964: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000005F970: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005F974: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000005F978: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000005F97C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000005F984: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005F98C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000005F990: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000005F994: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000005F998: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F99C: BF870095
	.long 0xd71c001a                                           // 00000005F9A0: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000005F9A4: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000005F9A8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000005F9AC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F9B4: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 00000005F9B8: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000005F9C4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F9C8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000005F9CC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000005F9D4: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F9D8: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000005F9DC: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000005F9E4: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000005F9E8: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F9F0: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 00000005F9F4: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 00000005F9F8: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FA00: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 00000005FA04: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 00000005FA08: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FA10: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 00000005FA14: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000005FA1C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 00000005FA24: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FA30: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000005FA34: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000005FA3C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000005FA48: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005FA50: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000005FA54: BE882007
	s_cbranch_execz 58549                                      // 00000005FA58: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3830>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 00000005FA5C: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000005FA68: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000005FA70: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000005FA74: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FA78: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000005FA7C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000005FA84: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000005FA90: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005FA94: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000005FA98: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000005FA9C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000005FAA4: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005FAAC: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000005FAB0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000005FAB4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000005FAB8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FABC: BF870095
	.long 0xd71c001a                                           // 00000005FAC0: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000005FAC4: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000005FAC8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000005FACC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FAD4: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 00000005FAD8: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000005FAE4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FAE8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000005FAEC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000005FAF4: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FAF8: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000005FAFC: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 00000005FB04: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000005FB08: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FB10: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 00000005FB14: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 00000005FB18: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FB20: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 00000005FB24: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 00000005FB28: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FB30: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 00000005FB34: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000005FB3C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 00000005FB44: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FB50: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 00000005FB54: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000005FB5C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000005FB68: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005FB70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000005FB74: BE882000
	s_cbranch_execz 58480                                      // 00000005FB78: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x383c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 00000005FB7C: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 00000005FB88: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 00000005FB8C: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 00000005FB94: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000005FB98: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FB9C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000005FBA0: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000005FBA8: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000005FBB4: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005FBB8: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000005FBBC: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000005FBC0: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000005FBC8: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005FBD0: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000005FBD4: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000005FBD8: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000005FBDC: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FBE0: BF870095
	.long 0xd71c001a                                           // 00000005FBE4: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000005FBE8: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000005FBEC: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000005FBF0: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FBF8: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 00000005FBFC: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000005FC04: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FC08: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 00000005FC0C: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 00000005FC14: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FC18: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 00000005FC1C: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 00000005FC24: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 00000005FC28: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FC30: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 00000005FC34: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 00000005FC38: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FC40: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 00000005FC44: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 00000005FC48: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FC50: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 00000005FC54: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 00000005FC5C: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 00000005FC64: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FC70: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 00000005FC74: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 00000005FC7C: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 00000005FC88: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005FC90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000005FC94: BE882001
	s_cbranch_execz 58411                                      // 00000005FC98: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3848>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 00000005FC9C: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 00000005FCA8: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 00000005FCAC: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 00000005FCB4: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000005FCB8: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005FCBC: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 00000005FCC0: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000005FCC8: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 00000005FCD0: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000005FCDC: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005FCE0: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 00000005FCE4: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 00000005FCEC: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005FCF0: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000005FCF4: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000005FCF8: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000005FCFC: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FD00: BF870095
	.long 0xd71c0019                                           // 00000005FD04: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000005FD08: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000005FD0C: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000005FD10: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FD18: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 00000005FD1C: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000005FD24: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FD28: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 00000005FD2C: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 00000005FD34: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FD38: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 00000005FD3C: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 00000005FD44: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 00000005FD48: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FD50: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 00000005FD54: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 00000005FD58: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FD60: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 00000005FD64: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 00000005FD68: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FD70: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 00000005FD74: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 00000005FD7C: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 00000005FD84: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FD90: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 00000005FD94: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 00000005FD9C: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 00000005FDA8: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005FDB0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000005FDB4: BE882002
	s_cbranch_execz 58342                                      // 00000005FDB8: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3854>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 00000005FDBC: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000005FDC8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000005FDD0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000005FDD4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FDD8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000005FDDC: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 00000005FDE4: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 00000005FDF0: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005FDF4: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 00000005FDF8: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000005FDFC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 00000005FE04: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005FE0C: BF870121
	v_add_f32_e32 v18, v18, v25                                // 00000005FE10: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 00000005FE14: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 00000005FE18: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FE1C: BF870095
	.long 0xd71c0012                                           // 00000005FE20: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 00000005FE24: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000005FE28: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000005FE2C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FE34: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 00000005FE38: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000005FE44: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FE48: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000005FE4C: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 00000005FE54: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FE58: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 00000005FE5C: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 00000005FE64: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 00000005FE68: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FE70: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 00000005FE74: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 00000005FE78: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FE80: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 00000005FE84: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 00000005FE88: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FE90: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 00000005FE94: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000005FE9C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 00000005FEA4: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FEB0: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 00000005FEB4: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 00000005FEBC: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000005FEC8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005FED0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000005FED4: BE882003
	s_cbranch_execz 58273                                      // 00000005FED8: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3860>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 00000005FEDC: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000005FEE8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000005FEF0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000005FEF4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FEF8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000005FEFC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000005FF04: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 00000005FF10: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FF14: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 00000005FF18: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 00000005FF24: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 00000005FF28: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000005FF2C: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005FF34: BF870293
	v_exp_f32_e32 v18, v18                                     // 00000005FF38: 7E244B12
	.long 0xd71c0012                                           // 00000005FF3C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000005FF40: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005FF44: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000005FF48: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000005FF4C: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 00000005FF54: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FF60: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 00000005FF64: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000005FF68: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005FF70: BF870291
	v_rcp_f32_e32 v20, v19                                     // 00000005FF74: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 00000005FF78: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005FF80: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 00000005FF84: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 00000005FF88: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 00000005FF90: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FF94: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 00000005FF98: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 00000005FFA0: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FFA4: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 00000005FFA8: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 00000005FFB0: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005FFB8: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000005FFBC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 00000005FFC4: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000005FFD0: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005FFD8: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000005FFDC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000005FFE8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000005FFF0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000005FFF4: BE882004
	s_cbranch_execz 58204                                      // 00000005FFF8: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x386c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 00000005FFFC: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000060008: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000060010: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000060014: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060018: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000006001C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000060024: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000060030: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000060034: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000060038: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000006003C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000060044: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006004C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000060050: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000060054: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000060058: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006005C: BF870095
	.long 0xd71c0012                                           // 000000060060: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000060064: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000060068: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000006006C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060074: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 000000060078: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000060084: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060088: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000006008C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000060094: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060098: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000006009C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000600A4: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000600A8: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000600B0: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 0000000600B4: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 0000000600B8: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000600C0: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 0000000600C4: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 0000000600C8: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000600D0: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 0000000600D4: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000600DC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 0000000600E4: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000600F0: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000600F4: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000600FC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000060108: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000060110: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000060114: BE882005
	s_cbranch_execz 58135                                      // 000000060118: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3878>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 00000006011C: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000060128: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000060130: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000060134: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060138: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000006013C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000060144: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000060150: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000060154: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000060158: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000006015C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000060164: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006016C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000060170: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000060174: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000060178: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006017C: BF870095
	.long 0xd71c0012                                           // 000000060180: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000060184: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000060188: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000006018C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060194: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 000000060198: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 0000000601A0: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000601A8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000601AC: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000601B4: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000601B8: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000601BC: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000601C4: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000601C8: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000601D0: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000601D4: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 0000000601D8: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000601E0: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 0000000601E4: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 0000000601E8: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000601F0: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000601F4: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000601FC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 000000060204: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060210: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000060214: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000006021C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000060228: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000060230: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000060234: BE882006
	s_cbranch_execz 58066                                      // 000000060238: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3884>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 00000006023C: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000060248: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000060250: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000060254: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060258: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000006025C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000060264: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000060270: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000060274: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000060278: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000006027C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000060284: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006028C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000060290: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000060294: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000060298: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006029C: BF870095
	.long 0xd71c0012                                           // 0000000602A0: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000602A4: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000602A8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000602AC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000602B4: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 0000000602B8: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000602C4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000602C8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000602CC: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000602D4: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000602D8: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000602DC: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000602E4: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000602E8: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000602F0: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000602F4: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000602F8: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060300: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 000000060304: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 000000060308: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060310: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000060314: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000006031C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 000000060324: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060330: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000060334: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000006033C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000060348: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000060350: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000060354: BE882007
	s_cbranch_execz 57997                                      // 000000060358: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3890>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 00000006035C: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000060368: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000060370: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000060374: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060378: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000006037C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000060384: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000060390: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000060394: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000060398: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000006039C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000603A4: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000603AC: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000603B0: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000603B4: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000603B8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000603BC: BF870095
	.long 0xd71c0012                                           // 0000000603C0: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000603C4: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000603C8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000603CC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000603D4: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 0000000603D8: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000603E4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000603E8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000603EC: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000603F4: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000603F8: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000603FC: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000060404: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000060408: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060410: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 000000060414: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 000000060418: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060420: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 000000060424: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 000000060428: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060430: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000060434: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000006043C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 000000060444: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060450: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000060454: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000006045C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000060468: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000060470: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000060474: BE882000
	s_cbranch_execz 57928                                      // 000000060478: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x389c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 00000006047C: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 000000060488: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 00000006048C: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000060494: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000060498: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006049C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000604A0: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000604A8: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000604B4: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000604B8: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000604BC: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000604C0: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000604C8: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000604D0: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000604D4: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000604D8: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000604DC: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000604E0: BF870095
	.long 0xd71c0012                                           // 0000000604E4: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000604E8: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000604EC: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000604F0: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000604F8: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000604FC: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000060504: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060508: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 00000006050C: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 000000060514: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060518: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 00000006051C: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 000000060524: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 000000060528: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060530: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 000000060534: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 000000060538: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060540: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 000000060544: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 000000060548: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060550: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 000000060554: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 00000006055C: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 000000060564: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060570: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 000000060574: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 00000006057C: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 000000060588: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 000000060590: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000060594: BE882001
	s_cbranch_execz 57859                                      // 000000060598: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38a8>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 00000006059C: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 0000000605A8: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 0000000605AC: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 0000000605B4: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000605B8: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000605BC: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 0000000605C0: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000605C8: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 0000000605D0: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 0000000605DC: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000605E0: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 0000000605E4: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 0000000605EC: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000605F0: BF870121
	v_add_f32_e32 v17, v17, v18                                // 0000000605F4: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 0000000605F8: 7E241113
	v_exp_f32_e32 v17, v17                                     // 0000000605FC: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060600: BF870095
	.long 0xd71c0011                                           // 000000060604: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000060608: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000006060C: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000060610: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060618: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 00000006061C: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000060624: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060628: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 00000006062C: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 000000060634: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060638: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 00000006063C: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 000000060644: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 000000060648: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060650: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 000000060654: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 000000060658: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060660: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 000000060664: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 000000060668: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060670: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 000000060674: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 00000006067C: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 000000060684: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060690: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 000000060694: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 00000006069C: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 0000000606A8: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000606B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000606B4: BE882002
	s_cbranch_execz 57790                                      // 0000000606B8: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38b4>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 0000000606BC: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000606C8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000606D0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000606D4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000606D8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000606DC: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 0000000606E4: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 0000000606F0: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000606F4: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 0000000606F8: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000606FC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 000000060704: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006070C: BF870121
	v_add_f32_e32 v10, v10, v17                                // 000000060710: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 000000060714: 7E221112
	v_exp_f32_e32 v10, v10                                     // 000000060718: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006071C: BF870095
	.long 0xd71c000a                                           // 000000060720: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 000000060724: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000060728: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000006072C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060734: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 000000060738: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000060744: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060748: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000006074C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 000000060754: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060758: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 00000006075C: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 000000060764: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 000000060768: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060770: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 000000060774: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 000000060778: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060780: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 000000060784: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 000000060788: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060790: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 000000060794: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000006079C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 0000000607A4: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000607B0: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 0000000607B4: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 0000000607BC: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000607C8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000607D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000607D4: BE882003
	s_cbranch_execz 57721                                      // 0000000607D8: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38c0>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 0000000607DC: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000607E8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000607F0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000607F4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000607F8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000607FC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000060804: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 000000060810: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060814: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 000000060818: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 000000060824: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 000000060828: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000006082C: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000060834: BF870293
	v_exp_f32_e32 v10, v10                                     // 000000060838: 7E144B0A
	.long 0xd71c000a                                           // 00000006083C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000060840: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000060844: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000060848: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000006084C: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 000000060854: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060860: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 000000060864: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000060868: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000060870: BF870291
	v_rcp_f32_e32 v12, v11                                     // 000000060874: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 000000060878: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060880: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 000000060884: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 000000060888: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 000000060890: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060894: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 000000060898: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 0000000608A0: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000608A4: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 0000000608A8: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 0000000608B0: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000608B8: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000608BC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 0000000608C4: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000608D0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000608D8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000608DC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000608E8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000608F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000608F4: BE882004
	s_cbranch_execz 57652                                      // 0000000608F8: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38cc>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 0000000608FC: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000060908: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000060910: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000060914: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060918: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000006091C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000060924: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000060930: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000060934: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000060938: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000006093C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000060944: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006094C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000060950: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000060954: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000060958: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006095C: BF870095
	.long 0xd71c000a                                           // 000000060960: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000060964: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000060968: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000006096C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060974: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 000000060978: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000060984: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060988: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000006098C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000060994: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060998: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000006099C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000609A4: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000609A8: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000609B0: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 0000000609B4: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 0000000609B8: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000609C0: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 0000000609C4: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 0000000609C8: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000609D0: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 0000000609D4: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000609DC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 0000000609E4: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000609F0: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000609F4: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000609FC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000060A08: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000060A10: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000060A14: BE882005
	s_cbranch_execz 57583                                      // 000000060A18: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38d8>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 000000060A1C: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000060A28: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000060A30: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000060A34: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060A38: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000060A3C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000060A44: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000060A50: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000060A54: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000060A58: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000060A5C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000060A64: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000060A6C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000060A70: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000060A74: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000060A78: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060A7C: BF870095
	.long 0xd71c000a                                           // 000000060A80: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000060A84: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000060A88: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000060A8C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060A94: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000060A98: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 000000060AA0: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060AA8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000060AAC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000060AB4: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060AB8: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000060ABC: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000060AC4: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000060AC8: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060AD0: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000060AD4: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 000000060AD8: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060AE0: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 000000060AE4: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 000000060AE8: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060AF0: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000060AF4: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000060AFC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 000000060B04: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060B10: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000060B14: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000060B1C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000060B28: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000060B30: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000060B34: BE882006
	s_cbranch_execz 57514                                      // 000000060B38: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38e4>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 000000060B3C: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000060B48: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000060B50: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000060B54: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060B58: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000060B5C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000060B64: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000060B70: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000060B74: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000060B78: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000060B7C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000060B84: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000060B8C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000060B90: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000060B94: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000060B98: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060B9C: BF870095
	.long 0xd71c000a                                           // 000000060BA0: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000060BA4: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000060BA8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000060BAC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060BB4: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 000000060BB8: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000060BC4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060BC8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000060BCC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000060BD4: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060BD8: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000060BDC: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000060BE4: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000060BE8: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060BF0: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000060BF4: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000060BF8: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060C00: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000060C04: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000060C08: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060C10: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000060C14: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000060C1C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 000000060C24: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060C30: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000060C34: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000060C3C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000060C48: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000060C50: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000060C54: BE882007
	s_cbranch_execz 57445                                      // 000000060C58: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38f0>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 000000060C5C: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000060C68: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000060C70: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000060C74: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060C78: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000060C7C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000060C84: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000060C90: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000060C94: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000060C98: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000060C9C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000060CA4: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000060CAC: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000060CB0: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000060CB4: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000060CB8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060CBC: BF870095
	.long 0xd71c000a                                           // 000000060CC0: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000060CC4: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000060CC8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000060CCC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060CD4: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 000000060CD8: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000060CE4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060CE8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000060CEC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000060CF4: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060CF8: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000060CFC: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000060D04: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000060D08: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060D10: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000060D14: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000060D18: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060D20: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000060D24: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000060D28: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060D30: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000060D34: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000060D3C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 000000060D44: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060D50: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000060D54: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000060D5C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000060D68: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000060D70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000060D74: BE882000
	s_cbranch_execz 57376                                      // 000000060D78: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38fc>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 000000060D7C: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 000000060D88: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 000000060D8C: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000060D94: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000060D98: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060D9C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000060DA0: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000060DA8: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000060DB4: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000060DB8: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000060DBC: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000060DC0: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000060DC8: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000060DD0: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000060DD4: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000060DD8: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000060DDC: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060DE0: BF870095
	.long 0xd71c000a                                           // 000000060DE4: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000060DE8: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000060DEC: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000060DF0: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060DF8: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000060DFC: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000060E04: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060E08: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 000000060E0C: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 000000060E14: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060E18: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 000000060E1C: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 000000060E24: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 000000060E28: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060E30: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 000000060E34: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 000000060E38: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060E40: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 000000060E44: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 000000060E48: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060E50: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 000000060E54: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 000000060E5C: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 000000060E64: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060E70: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 000000060E74: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 000000060E7C: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 000000060E88: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 000000060E90: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000060E94: BE802001
	s_cbranch_execz 57307                                      // 000000060E98: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3908>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 000000060E9C: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000060EA8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000060EB0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000060EB4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060EB8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000060EBC: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 000000060EC4: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 000000060ED0: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000060ED4: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 000000060ED8: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 000000060EDC: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000060EE4: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000060EEC: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 000000060EF0: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 000000060EF4: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 000000060EF8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060EFC: BF870095
	.long 0xd71c0001                                           // 000000060F00: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 000000060F04: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000060F08: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000060F0C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060F14: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 000000060F18: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000060F24: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060F28: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000060F2C: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 000000060F34: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060F38: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 000000060F3C: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 000000060F44: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 000000060F48: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060F50: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 000000060F54: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 000000060F58: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060F60: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 000000060F64: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 000000060F68: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060F70: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 000000060F74: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000060F7C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 000000060F84: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060F90: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 000000060F94: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 000000060F9C: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000060FA8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000060FB0: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 000000060FB4: BE802002
	s_cbranch_execz 57238                                      // 000000060FB8: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3914>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 000000060FBC: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000060FC8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000060FD0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000060FD4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060FD8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000060FDC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000060FE4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 000000060FF0: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000060FF4: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 000000060FF8: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000060FFC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000061004: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006100C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000061010: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 000000061014: 7E041109
	v_exp_f32_e32 v1, v1                                       // 000000061018: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006101C: BF870095
	.long 0xd71c0001                                           // 000000061020: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000061024: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000061028: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000006102C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061034: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 000000061038: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000061044: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061048: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000006104C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000061054: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061058: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 00000006105C: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 000000061064: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 000000061068: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061070: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 000000061074: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 000000061078: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061080: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 000000061084: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 000000061088: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061090: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 000000061094: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000006109C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 0000000610A4: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000610B0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000610B4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000610BC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000610C8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000610D0: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000610D4: BE802003
	s_cbranch_execz 57169                                      // 0000000610D8: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3920>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 0000000610DC: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000610E8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000610F0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000610F4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000610F8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000610FC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000061104: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000061110: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000061114: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000061118: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000006111C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000061124: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006112C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000061130: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000061134: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000061138: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006113C: BF870095
	.long 0xd71c0001                                           // 000000061140: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000061144: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000061148: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000006114C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061154: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 000000061158: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000061164: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061168: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000006116C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000061174: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061178: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000006117C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000061184: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000061188: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061190: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 000000061194: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 000000061198: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000611A0: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 0000000611A4: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 0000000611A8: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000611B0: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 0000000611B4: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000611BC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 0000000611C4: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000611D0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000611D4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000611DC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000611E8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000611F0: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000611F4: BE802004
	s_cbranch_execz 57100                                      // 0000000611F8: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x392c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 0000000611FC: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000061208: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000061210: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000061214: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061218: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000006121C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000061224: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000061230: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000061234: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000061238: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000006123C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000061244: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006124C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000061250: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000061254: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000061258: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006125C: BF870095
	.long 0xd71c0001                                           // 000000061260: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000061264: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000061268: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000006126C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061274: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 000000061278: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 000000061280: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061288: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000006128C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000061294: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061298: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000006129C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000612A4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000612A8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000612B0: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000612B4: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 0000000612B8: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000612C0: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 0000000612C4: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000612C8: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000612D0: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000612D4: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000612DC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 0000000612E4: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000612F0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000612F4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000612FC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000061308: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000061310: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000061314: BE802005
	s_cbranch_execz 57031                                      // 000000061318: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3938>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 00000006131C: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000061328: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000061330: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000061334: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061338: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000006133C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000061344: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000061350: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000061354: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000061358: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000006135C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000061364: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006136C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000061370: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000061374: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000061378: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006137C: BF870095
	.long 0xd71c0001                                           // 000000061380: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000061384: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000061388: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000006138C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061394: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 000000061398: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000613A4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000613A8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000613AC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000613B4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000613B8: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000613BC: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000613C4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000613C8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000613D0: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000613D4: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000613D8: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000613E0: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000613E4: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000613E8: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000613F0: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000613F4: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000613FC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 000000061404: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061410: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000061414: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000006141C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000061428: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000061430: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000061434: BE802006
	s_cbranch_execz 56962                                      // 000000061438: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3944>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 00000006143C: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000061448: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000061450: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000061454: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061458: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000006145C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000061464: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000061470: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000061474: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000061478: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000006147C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000061484: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006148C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000061490: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000061494: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000061498: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006149C: BF870095
	.long 0xd71c0001                                           // 0000000614A0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000614A4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000614A8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000614AC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000614B4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 0000000614B8: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000614C4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000614C8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000614CC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000614D4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000614D8: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000614DC: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000614E4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000614E8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000614F0: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000614F4: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000614F8: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061500: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 000000061504: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 000000061508: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061510: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000061514: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000006151C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 000000061524: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061530: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000061534: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000006153C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000061548: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000061550: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000061554: BE802007
	s_cbranch_execz 56893                                      // 000000061558: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi2ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3950>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 00000006155C: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000061568: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000061570: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000061574: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061578: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000006157C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000061584: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000061590: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000061594: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000061598: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000006159C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000615A4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000615AC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000615B0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000615B4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000615B8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000615BC: BF870095
	.long 0xd71c0001                                           // 0000000615C0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000615C4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000615C8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000615CC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000615D4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 0000000615D8: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000615E4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000615E8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000615EC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000615F4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000615F8: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000615FC: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000061604: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000061608: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061610: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000061614: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 000000061618: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061620: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 000000061624: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 000000061628: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061630: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000061634: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000006163C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 000000061644: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061650: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000061654: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000006165C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000061668: DC9601E0 007C0200
	s_nop 0                                                    // 000000061670: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000061674: BFB60003
	s_endpgm                                                   // 000000061678: BFB00000
		...

