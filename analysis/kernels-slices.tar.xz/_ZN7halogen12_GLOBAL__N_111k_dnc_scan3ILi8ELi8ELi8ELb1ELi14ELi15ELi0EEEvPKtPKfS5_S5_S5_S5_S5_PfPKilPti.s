00000000000c3b00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000C3B00: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000C3B04: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000C3B0C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000C3B14: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000C3B18: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000C3B1C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000C3B20: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000C3B28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000C3B2C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000C3B30: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000C3B34: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000C3B3C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000C3B40: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000C3B44: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000C3B48: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C3B4C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000C3B50: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000C3B54: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000C3B58: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000C3B5C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000C3B64: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000C3B6C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000C3B70: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000C3B74: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000C3B78: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000C3B7C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000C3B80: 821E191E
	.long 0xd7001f02                                           // 0000000C3B84: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000C3B88: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000C3B8C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000C3B94: BE9E0080
	s_nop 0                                                    // 0000000C3B98: BF800000
	s_nop 0                                                    // 0000000C3B9C: BF800000
	s_nop 0                                                    // 0000000C3BA0: BF800000
	s_nop 0                                                    // 0000000C3BA4: BF800000
	s_nop 0                                                    // 0000000C3BA8: BF800000
	s_nop 0                                                    // 0000000C3BAC: BF800000
	s_nop 0                                                    // 0000000C3BB0: BF800000
	s_nop 0                                                    // 0000000C3BB4: BF800000
	s_nop 0                                                    // 0000000C3BB8: BF800000
	s_nop 0                                                    // 0000000C3BBC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000C3BC0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000C3BC4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3BCC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000C3BD0: 300C1089
	.long 0xd7006a06                                           // 0000000C3BD4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000C3BD8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C3BDC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000C3BE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000C3BE8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000C3BF0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000C3BF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000C3BFC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000C3C08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000C3C0C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000C3C10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000C3C18: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000C3C1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000C3C20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000C3C24: F4000780 F8000058
	v_or_b32_e32 v36, 0xffffff80, v0                           // 0000000C3C2C: 384800FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000C3C34: 32040084
	s_mov_b32 s0, 0                                            // 0000000C3C38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000C3C3C: BF89FC07
	s_barrier                                                  // 0000000C3C40: BFBD0000
	buffer_gl0_inv                                             // 0000000C3C44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000C3C4C: BF02801E
	s_cbranch_scc1 12                                          // 0000000C3C50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000C3C54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000C3C5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C3C64: BF870002
	v_lshl_add_u32 v35, v5, 2, v3                              // 0000000C3C68: D6460023 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000C3C70: 7E060280
	v_lshlrev_b32_e32 v37, 2, v5                               // 0000000C3C74: 304A0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000C3C78: 916A007E
	s_cbranch_vccz 2                                           // 0000000C3C7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2201                                              // 0000000C3C80: BFA00899 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23e8>
	v_lshlrev_b32_e32 v37, 2, v5                               // 0000000C3C84: 304A0A82
	s_add_i32 s0, s30, 63                                      // 0000000C3C88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000C3C8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000C3C94: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000C3C98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000C3C9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000C3CA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v38, 2, v0      // 0000000C3CA4: CA220080 03260082
	s_ashr_i32 s1, s0, 31                                      // 0000000C3CAC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000C3CB0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000C3CB4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000C3CB8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000C3CBC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000C3CC0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000C3CC4: 848A811A
	v_mad_u32_u24 v35, 0x44, v2, v37                           // 0000000C3CC8: D60B0023 049604FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000C3CD4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000C3CD8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000C3CDC: B00A0204
	.long 0xd7000b2a                                           // 0000000C3CE0: D7000B2A
	v_cndmask_b32_e32 v1, s34, v37, vcc_lo                     // 0000000C3CE4: 02024A22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000C3CE8: BF8704B1
	v_add_co_ci_u32_e64 v43, null, s35, 0, s11                 // 0000000C3CEC: D5207C2B 002D0023
	v_mad_u32_u24 v44, v2, s10, 0x3300                         // 0000000C3CF4: D60B002C 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000C3D00: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v39, 0x4320, v38// 0000000C3D04: CA20000B 0C264CFF 00004320
	v_or_b32_e32 v11, s10, v38                                 // 0000000C3D10: 38164C0A
	.long 0xd7000a05                                           // 0000000C3D14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000C3D18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C3D1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000C3D20: D5207C06 00290001
	.long 0xd7000107                                           // 0000000C3D28: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000C3D2C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C3D30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000C3D34: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000C3D3C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000C3D40: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000C3D44: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000C3D4C: 84848E02
	.long 0xd700010b                                           // 0000000C3D50: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000C3D54: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000C3D58: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000C3D5C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000C3D64: 8205050F
	.long 0xd700010d                                           // 0000000C3D68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000C3D6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C3D70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000C3D74: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000C3D7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000C3D80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000C3D88: D5207C10 00061880
	.long 0xd7000111                                           // 0000000C3D90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000C3D94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C3D9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000C3DA0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000C3DA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000C3DAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000C3DB4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000C3DBC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000C3DC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000C3DC8: BF8700D1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000C3DCC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000C3DD4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000C3DD8: 020216FF 000F0000
	v_or_b32_e32 v45, 0x2200, v1                               // 0000000C3DE0: 385A02FF 00002200
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000C3DE8: D5207C18 00061880
	.long 0xd7000119                                           // 0000000C3DF0: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000C3DF4: 020216FF 00120000
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000C3DFC: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000C3E04: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000C3E08: 020216FF 00150000
	v_add_nc_u32_e32 v40, 0x4420, v38                          // 0000000C3E10: 4A504CFF 00004420
	.long 0xd44c0000                                           // 0000000C3E18: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000C3E1C: 020200FF 00000080
	v_add_nc_u32_e32 v41, 1, v2                                // 0000000C3E24: 4A520481
	v_add_nc_u32_e32 v4, 0x2200, v35                           // 0000000C3E28: 4A0846FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000C3E30: D5207C1C 00061880
	v_add_nc_u32_e32 v46, 0x400, v45                           // 0000000C3E38: 4A5C5AFF 00000400
	v_add_nc_u32_e32 v47, 0x600, v45                           // 0000000C3E40: 4A5E5AFF 00000600
	v_add_nc_u32_e32 v48, 0x800, v45                           // 0000000C3E48: 4A605AFF 00000800
	s_mov_b32 s5, 0                                            // 0000000C3E50: BE850080
	s_mov_b32 s6, 0x42800000                                   // 0000000C3E54: BE8600FF 42800000
	s_mov_b32 s7, 0x3c800000                                   // 0000000C3E5C: BE8700FF 3C800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000C3E64: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000C3E68: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000C3E70: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000C3E74: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000C3E78: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C3E7C: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000C3E80: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000C3E84: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000C3E88: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000C3E8C: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000C3E90: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000C3E98: BE84206A
	s_cbranch_execz 77                                         // 0000000C3E9C: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4d4>
	v_or_b32_e32 v29, s11, v0                                  // 0000000C3EA0: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3EA4: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000C3EA8: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000C3EB0: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3EB4: BF870091
	.long 0xd73c001d                                           // 0000000C3EB8: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000C3EBC: 02023A82
	.long 0xd700011d                                           // 0000000C3EC0: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000C3EC4: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000C3EC8: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000C3ECC: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000C3ED4: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C3EDC: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000C3EE0: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000C3EE4: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000C3EF0: BF8701A1
	v_fma_f32 v49, 0x3fb8aa3b, v29, -v32                       // 0000000C3EF4: D6130031 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v50, v32                                   // 0000000C3F00: 7E644720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000C3F04: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000C3F10: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C3F14: BF870113
	v_dual_fmac_f32 v49, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v50// 0000000C3F18: C80A3AFF 31206520 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000C3F24: 083E451F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C3F28: BF870122
	v_dual_fmac_f32 v33, 0x32a5705f, v30 :: v_dual_add_f32 v32, v32, v49// 0000000C3F2C: C8083CFF 21206320 32A5705F
	.long 0xd41b0001                                           // 0000000C3F38: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000C3F3C: 02023CFF C2CE8ED0
	v_add_f32_e32 v31, v31, v33                                // 0000000C3F44: 063E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000C3F48: 7E421122
	v_cvt_i32_f32_e32 v34, v50                                 // 0000000C3F4C: 7E441132
	v_exp_f32_e32 v32, v32                                     // 0000000C3F50: 7E404B20
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000000C3F54: BF870313
	v_exp_f32_e32 v31, v31                                     // 0000000C3F58: 7E3E4B1F
	.long 0xd71c0020                                           // 0000000C3F5C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000C3F60: 02024520
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C3F64: BF870095
	.long 0xd71c001f                                           // 0000000C3F68: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000C3F6C: 0202431F
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000C3F70: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000C3F78: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000C3F7C: 02023AFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C3F84: BF8700A1
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000C3F88: D5010020 00064080
	.long 0xd41e0001                                           // 0000000C3F90: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000C3F94: 02023CFF 42B17218
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000C3F9C: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000C3FA8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000C3FAC: 02023AFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C3FB4: BF870001
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000C3FB8: D501001D 000640FF 7F800000
	ds_store_b32 v39, v30                                      // 0000000C3FC4: D8340000 00001E27
	ds_store_b32 v40, v29                                      // 0000000C3FCC: D8340000 00001D28
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C3FD4: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000C3FD8: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000C3FE0: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C3FE4: BF89FC07
	s_barrier                                                  // 0000000C3FE8: BFBD0000
	buffer_gl0_inv                                             // 0000000C3FEC: E0AC0000 00000000
	s_branch 15                                                // 0000000C3FF4: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C3FF8: 8C7E047E
	.long 0xd700011d                                           // 0000000C3FFC: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000C4000: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C4008: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C400C: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000C4014: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000C4018: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000C401C: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000C4020: BF89FC07
	s_barrier                                                  // 0000000C4024: BFBD0000
	buffer_gl0_inv                                             // 0000000C4028: E0AC0000 00000000
	s_cbranch_scc1 185                                         // 0000000C4030: BFA200B9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x818>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000C4034: CA10011E 201E011D
	v_dual_mov_b32 v33, v38 :: v_dual_mov_b32 v34, v36         // 0000000C403C: CA100126 21220124
	s_mov_b32 s13, 0                                           // 0000000C4044: BE8D0080
	s_nop 0                                                    // 0000000C4048: BF800000
	s_nop 0                                                    // 0000000C404C: BF800000
	s_nop 0                                                    // 0000000C4050: BF800000
	s_nop 0                                                    // 0000000C4054: BF800000
	s_nop 0                                                    // 0000000C4058: BF800000
	s_nop 0                                                    // 0000000C405C: BF800000
	s_nop 0                                                    // 0000000C4060: BF800000
	s_nop 0                                                    // 0000000C4064: BF800000
	s_nop 0                                                    // 0000000C4068: BF800000
	s_nop 0                                                    // 0000000C406C: BF800000
	s_nop 0                                                    // 0000000C4070: BF800000
	s_nop 0                                                    // 0000000C4074: BF800000
	s_nop 0                                                    // 0000000C4078: BF800000
	s_nop 0                                                    // 0000000C407C: BF800000
	global_load_b32 v49, v[31:32], off                         // 0000000C4080: DC520000 317C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000C4088: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000C4090: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000C4094: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C409C: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000C40A0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000C40A8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000C40AC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000C40B4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000C40B8: BF8903F7
	ds_store_b32 v33, v49 offset:13056                         // 0000000C40BC: D8343300 00003121
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000C40C4: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000C40CC: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000C40D0: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000C40D4: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000C40D8: BF89FC07
	s_barrier                                                  // 0000000C40DC: BFBD0000
	buffer_gl0_inv                                             // 0000000C40E0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000C40E8: BE842000
	s_cbranch_execz 65474                                      // 0000000C40EC: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f8>
	v_or3_b32 v31, s12, s11, v2                                // 0000000C40F0: D658001F 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C40F8: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 0000000C40FC: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 0000000C4104: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 0000000C4108: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C410C: BF870091
	.long 0xd700011f                                           // 0000000C4110: D700011F
	v_cndmask_b32_e32 v1, v42, v31, vcc_lo                     // 0000000C4114: 02023F2A
	v_add_co_ci_u32_e64 v32, null, v43, v32, s1                // 0000000C4118: D5207C20 0006412B
	s_mov_b32 s1, 0                                            // 0000000C4120: BE810080
	global_load_b32 v31, v[31:32], off                         // 0000000C4124: DC520000 1F7C001F
	v_mad_u64_u32 v[32:33], null, 0x44, s1, v[1:2]             // 0000000C412C: D6FE7C20 040402FF 00000044
	s_add_i32 s13, s1, 8                                       // 0000000C4138: 810D8801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000C413C: B6810078
	ds_load_2addr_b32 v[33:34], v32 offset1:17                 // 0000000C4140: D8DC1100 21000020
	ds_load_2addr_b32 v[49:50], v32 offset0:34 offset1:51      // 0000000C4148: D8DC3322 31000020
	ds_load_2addr_b32 v[51:52], v32 offset0:68 offset1:85      // 0000000C4150: D8DC5544 33000020
	ds_load_2addr_b32 v[53:54], v32 offset0:102 offset1:119    // 0000000C4158: D8DC7766 35000020
	v_lshl_add_u32 v32, s1, 2, v44                             // 0000000C4160: D6460020 04B10401
	s_mov_b32 s1, s13                                          // 0000000C4168: BE81000D
	ds_load_2addr_b32 v[55:56], v32 offset1:1                  // 0000000C416C: D8DC0100 37000020
	ds_load_2addr_b32 v[57:58], v32 offset0:2 offset1:3        // 0000000C4174: D8DC0302 39000020
	ds_load_2addr_b32 v[59:60], v32 offset0:4 offset1:5        // 0000000C417C: D8DC0504 3B000020
	ds_load_2addr_b32 v[61:62], v32 offset0:6 offset1:7        // 0000000C4184: D8DC0706 3D000020
	s_waitcnt lgkmcnt(7)                                       // 0000000C418C: BF89FC77
	v_fma_mixlo_f16 v32, v33, s6, 0                            // 0000000C4190: CC210020 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000C4198: CC210022 02000D22
	s_waitcnt lgkmcnt(6)                                       // 0000000C41A0: BF89FC67
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000C41A4: CC210031 02000D31
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C41AC: BF870193
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C41B0: CC200020 8A000F20
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C41B8: CC200022 8A000F22
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000C41C0: BF870003
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C41C4: CC200031 8A000F31
	s_waitcnt lgkmcnt(3)                                       // 0000000C41CC: BF89FC37
	v_fma_mixlo_f16 v33, v55, s6, 0                            // 0000000C41D0: CC210021 02000D37
	v_fma_mixlo_f16 v55, v56, s6, 0                            // 0000000C41D8: CC210037 02000D38
	s_waitcnt lgkmcnt(2)                                       // 0000000C41E0: BF89FC27
	v_fma_mixlo_f16 v56, v57, s6, 0                            // 0000000C41E4: CC210038 02000D39
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C41EC: BF870193
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C41F0: CC200021 8A000F21
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C41F8: CC200037 8A000F37
	s_waitcnt vmcnt(0)                                         // 0000000C4200: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000C4204: BF870242
	v_fma_f32 v31, -v33, v32, v31                              // 0000000C4208: D613001F 247E4121
	v_fma_mixlo_f16 v32, v50, s6, 0                            // 0000000C4210: CC210020 02000D32
	v_fma_mixlo_f16 v33, v58, s6, 0                            // 0000000C4218: CC210021 02000D3A
	v_fma_mix_f32 v50, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4220: CC200032 8A000F38
	v_fma_f32 v31, -v55, v34, v31                              // 0000000C4228: D613001F 247E4537
	v_fma_mixlo_f16 v34, v51, s6, 0                            // 0000000C4230: CC210022 02000D33
	s_waitcnt lgkmcnt(1)                                       // 0000000C4238: BF89FC17
	v_fma_mixlo_f16 v51, v59, s6, 0                            // 0000000C423C: CC210033 02000D3B
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4244: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C424C: CC200021 8A000F21
	v_fma_f32 v31, -v50, v49, v31                              // 0000000C4254: D613001F 247E6332
	v_fma_mixlo_f16 v49, v52, s6, 0                            // 0000000C425C: CC210031 02000D34
	v_fma_mixlo_f16 v50, v60, s6, 0                            // 0000000C4264: CC210032 02000D3C
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C426C: CC200022 8A000F22
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4274: CC200033 8A000F33
	v_fma_f32 v31, -v33, v32, v31                              // 0000000C427C: D613001F 247E4121
	v_fma_mixlo_f16 v32, v53, s6, 0                            // 0000000C4284: CC210020 02000D35
	s_waitcnt lgkmcnt(0)                                       // 0000000C428C: BF89FC07
	v_fma_mixlo_f16 v33, v61, s6, 0                            // 0000000C4290: CC210021 02000D3D
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4298: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C42A0: CC200032 8A000F32
	v_fma_f32 v31, -v51, v34, v31                              // 0000000C42A8: D613001F 247E4533
	v_fma_mixlo_f16 v34, v54, s6, 0                            // 0000000C42B0: CC210022 02000D36
	v_fma_mixlo_f16 v51, v62, s6, 0                            // 0000000C42B8: CC210033 02000D3E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C42C0: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C42C8: CC200021 8A000F21
	v_fma_f32 v31, -v50, v49, v31                              // 0000000C42D0: D613001F 247E6332
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C42D8: CC200022 8A000F22
	v_fma_mix_f32 v49, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C42E0: CC200031 8A000F33
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C42E8: BF870093
	v_fma_f32 v31, -v33, v32, v31                              // 0000000C42EC: D613001F 247E4121
	v_fma_f32 v31, -v49, v34, v31                              // 0000000C42F4: D613001F 247E4531
	s_cbranch_scc1 65419                                       // 0000000C42FC: BFA2FF8B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x62c>
	v_mad_u64_u32 v[32:33], null, 0x44, s12, v[4:5]            // 0000000C4300: D6FE7C20 041018FF 00000044
	ds_store_b32 v32, v31                                      // 0000000C430C: D8340000 00001F20
	s_branch 65336                                             // 0000000C4314: BFA0FF38 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f8>
	v_mov_b32_e32 v30, v14                                     // 0000000C4318: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000C431C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000C4324: 7E3E0309
	v_mov_b32_e32 v49, v41                                     // 0000000C4328: 7E620329
	s_mov_b32 s12, 0                                           // 0000000C432C: BE8C0080
	s_branch 21                                                // 0000000C4330: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x888>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000C4334: 8C7E0D7E
	.long 0xd700011f                                           // 0000000C4338: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000C433C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C4344: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000C4348: D5207C20 00064080
	.long 0xd700011d                                           // 0000000C4350: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000C4354: 02023AFF 00000800
	v_add_nc_u32_e32 v49, 8, v49                               // 0000000C435C: 4A626288
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C4360: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000C4368: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000C436C: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000C4370: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000C4374: BC7C0000
	s_barrier                                                  // 0000000C4378: BFBD0000
	buffer_gl0_inv                                             // 0000000C437C: E0AC0000 00000000
	s_cbranch_scc1 217                                         // 0000000C4384: BFA200D9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xbec>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C4388: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000C438C: CA100120 2220011F
	v_dual_mov_b32 v50, v38 :: v_dual_mov_b32 v51, v36         // 0000000C4394: CA100126 32320124
	s_mov_b32 s13, 0                                           // 0000000C439C: BE8D0080
	s_nop 0                                                    // 0000000C43A0: BF800000
	s_nop 0                                                    // 0000000C43A4: BF800000
	s_nop 0                                                    // 0000000C43A8: BF800000
	s_nop 0                                                    // 0000000C43AC: BF800000
	s_nop 0                                                    // 0000000C43B0: BF800000
	s_nop 0                                                    // 0000000C43B4: BF800000
	s_nop 0                                                    // 0000000C43B8: BF800000
	s_nop 0                                                    // 0000000C43BC: BF800000
	global_load_b32 v52, v[33:34], off                         // 0000000C43C0: DC520000 347C0021
	v_add_nc_u32_e32 v51, 0x80, v51                            // 0000000C43C8: 4A6666FF 00000080
	.long 0xd7000121                                           // 0000000C43D0: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000C43D4: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C43DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000C43E0: D5207C22 00064480
	.long 0xd4490004                                           // 0000000C43E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v51, vcc_lo                   // 0000000C43EC: 020266FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000C43F4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000C43F8: BF8903F7
	ds_store_b32 v50, v52 offset:13056                         // 0000000C43FC: D8343300 00003432
	v_add_nc_u32_e32 v50, 0x204, v50                           // 0000000C4404: 4A6464FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000C440C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000C4410: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000C4414: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000C4418: BF89FC07
	s_barrier                                                  // 0000000C441C: BFBD0000
	buffer_gl0_inv                                             // 0000000C4420: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000C4428: BE8D2000
	s_cbranch_execz 65473                                      // 0000000C442C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	v_or_b32_e32 v33, s12, v2                                  // 0000000C4430: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4434: BF870091
	v_or_b32_e32 v50, s11, v33                                 // 0000000C4438: 3864420B
	.long 0xd4440001                                           // 0000000C443C: D4440001
	v_cndmask_b32_e32 v1, s30, v50, vcc_lo                     // 0000000C4440: 0202641E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000C4444: 8B7E017E
	s_cbranch_execz 65466                                      // 0000000C4448: BFA5FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	v_mov_b32_e32 v51, 0                                       // 0000000C444C: 7E660280
	s_mov_b32 s1, 0                                            // 0000000C4450: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C4454: BF870009
	v_lshl_add_u32 v34, s1, 2, v44                             // 0000000C4458: D6460022 04B10401
	s_add_i32 s4, s1, 8                                        // 0000000C4460: 81048801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000C4464: B6810078
	ds_load_2addr_b32 v[61:62], v34 offset1:1                  // 0000000C4468: D8DC0100 3D000022
	ds_load_2addr_b32 v[63:64], v34 offset0:2 offset1:3        // 0000000C4470: D8DC0302 3F000022
	ds_load_2addr_b32 v[65:66], v34 offset0:4 offset1:5        // 0000000C4478: D8DC0504 41000022
	ds_load_2addr_b32 v[67:68], v34 offset0:6 offset1:7        // 0000000C4480: D8DC0706 43000022
	v_mad_u64_u32 v[52:53], null, 0x44, s1, v[1:2]             // 0000000C4488: D6FE7C34 040402FF 00000044
	s_mov_b32 s1, s4                                           // 0000000C4494: BE810004
	ds_load_2addr_b32 v[53:54], v52 offset1:17                 // 0000000C4498: D8DC1100 35000034
	ds_load_2addr_b32 v[55:56], v52 offset0:34 offset1:51      // 0000000C44A0: D8DC3322 37000034
	ds_load_2addr_b32 v[57:58], v52 offset0:68 offset1:85      // 0000000C44A8: D8DC5544 39000034
	ds_load_2addr_b32 v[59:60], v52 offset0:102 offset1:119    // 0000000C44B0: D8DC7766 3B000034
	s_waitcnt lgkmcnt(7)                                       // 0000000C44B8: BF89FC77
	v_fma_mixlo_f16 v52, v61, s6, 0                            // 0000000C44BC: CC210034 02000D3D
	s_waitcnt lgkmcnt(6)                                       // 0000000C44C4: BF89FC67
	v_fma_mixlo_f16 v61, v63, s6, 0                            // 0000000C44C8: CC21003D 02000D3F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C44D0: BF870002
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C44D4: CC200034 8A000F34
	s_waitcnt lgkmcnt(3)                                       // 0000000C44DC: BF89FC37
	v_fma_mixlo_f16 v34, v53, s6, 0                            // 0000000C44E0: CC210022 02000D35
	v_fma_mixlo_f16 v53, v54, s6, 0                            // 0000000C44E8: CC210035 02000D36
	v_fma_mixlo_f16 v54, v62, s6, 0                            // 0000000C44F0: CC210036 02000D3E
	s_waitcnt lgkmcnt(2)                                       // 0000000C44F8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000C44FC: CC210037 02000D37
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4504: CC200022 8A000F22
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C450C: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4514: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000C451C: BF870214
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4520: CC200037 8A000F37
	v_fmac_f32_e32 v51, v52, v34                               // 0000000C4528: 56664534
	v_fma_mixlo_f16 v34, v56, s6, 0                            // 0000000C452C: CC210022 02000D38
	v_fma_mixlo_f16 v52, v64, s6, 0                            // 0000000C4534: CC210034 02000D40
	v_fma_mix_f32 v56, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C453C: CC200038 8A000F3D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C4544: BF870004
	v_fmac_f32_e32 v51, v54, v53                               // 0000000C4548: 56666B36
	s_waitcnt lgkmcnt(1)                                       // 0000000C454C: BF89FC17
	v_fma_mixlo_f16 v53, v57, s6, 0                            // 0000000C4550: CC210035 02000D39
	v_fma_mixlo_f16 v54, v65, s6, 0                            // 0000000C4558: CC210036 02000D41
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4560: CC200022 8A000F22
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4568: CC200034 8A000F34
	v_fmac_f32_e32 v51, v56, v55                               // 0000000C4570: 56666F38
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000C4574: CC210037 02000D3A
	v_fma_mixlo_f16 v56, v66, s6, 0                            // 0000000C457C: CC210038 02000D42
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4584: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C458C: CC200036 8A000F36
	v_fmac_f32_e32 v51, v52, v34                               // 0000000C4594: 56664534
	s_waitcnt lgkmcnt(0)                                       // 0000000C4598: BF89FC07
	v_fma_mixlo_f16 v34, v59, s6, 0                            // 0000000C459C: CC210022 02000D3B
	v_fma_mixlo_f16 v52, v67, s6, 0                            // 0000000C45A4: CC210034 02000D43
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C45AC: CC200037 8A000F37
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C45B4: CC200038 8A000F38
	v_fmac_f32_e32 v51, v54, v53                               // 0000000C45BC: 56666B36
	v_fma_mixlo_f16 v53, v60, s6, 0                            // 0000000C45C0: CC210035 02000D3C
	v_fma_mixlo_f16 v54, v68, s6, 0                            // 0000000C45C8: CC210036 02000D44
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C45D0: CC200022 8A000F22
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C45D8: CC200034 8A000F34
	v_fmac_f32_e32 v51, v56, v55                               // 0000000C45E0: 56666F38
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C45E4: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C45EC: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C45F4: BF870093
	v_fmac_f32_e32 v51, v52, v34                               // 0000000C45F8: 56664534
	v_fmac_f32_e32 v51, v54, v53                               // 0000000C45FC: 56666B36
	s_cbranch_scc1 65428                                       // 0000000C4600: BFA2FF94 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x954>
	v_dual_mov_b32 v52, v1 :: v_dual_lshlrev_b32 v33, 2, v33   // 0000000C4604: CA220101 34204282
	s_mov_b32 s14, 0                                           // 0000000C460C: BE8E0080
	ds_load_b32 v53, v33 offset:17440                          // 0000000C4610: D8D84420 35000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000C4618: CA10011E 2220011D
	s_waitcnt lgkmcnt(0)                                       // 0000000C4620: BF89FC07
	v_mul_f32_e32 v51, v51, v53                                // 0000000C4624: 10666B33
	v_mov_b32_e32 v53, v49                                     // 0000000C4628: 7E6A0331
	s_nop 0                                                    // 0000000C462C: BF800000
	s_nop 0                                                    // 0000000C4630: BF800000
	s_nop 0                                                    // 0000000C4634: BF800000
	s_nop 0                                                    // 0000000C4638: BF800000
	s_nop 0                                                    // 0000000C463C: BF800000
	global_load_b32 v54, v[33:34], off                         // 0000000C4640: DC520000 367C0021
	ds_load_b32 v55, v52 offset:8704                           // 0000000C4648: D8D82200 37000034
	v_add_nc_u32_e32 v53, -1, v53                              // 0000000C4650: 4A6A6AC1
	.long 0xd7000121                                           // 0000000C4654: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000C4658: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C465C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000C4660: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000C4668: D44A0004
	v_cndmask_b32_e32 v1, 0, v53, vcc_lo                       // 0000000C466C: 02026A80
	v_add_nc_u32_e32 v52, 0x44, v52                            // 0000000C4670: 4A6868FF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000C4678: 8C0E0E04
	s_waitcnt lgkmcnt(0)                                       // 0000000C467C: BF89FC07
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000C4680: CC210037 02000D37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000C4688: BF8700B1
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C468C: CC200037 8A000F37
	s_waitcnt vmcnt(0)                                         // 0000000C4694: BF8903F7
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000C4698: CC210036 02000D36
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C46A0: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C46A8: BF870001
	v_fmac_f32_e32 v51, v54, v55                               // 0000000C46AC: 56666F36
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000C46B0: 917E0E7E
	s_cbranch_execnz 65506                                     // 0000000C46B4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb40>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000C46B8: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C46BC: BF870121
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000C46C0: D6100034 02052133
	v_mad_u64_u32 v[33:34], null, 0x3000, v50, v[5:6]          // 0000000C46C8: D6FE7C21 041664FF 00003000
	v_add3_u32 v50, v51, v52, 0x7fff                           // 0000000C46D4: D6550032 03FE6933 00007FFF
	global_store_d16_hi_b16 v[33:34], v50, off                 // 0000000C46E0: DC960000 007C3221
	s_branch 65298                                             // 0000000C46E8: BFA0FF12 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000C46EC: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v36                                     // 0000000C46F4: 7E3E0324
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000C46F8: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000C46FC: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000C4704: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000C4708: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000C4710: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000C4718: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000C471C: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000C4720: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000C4728: A0010401
	s_mov_b32 s4, 0                                            // 0000000C472C: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000C4730: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000C4734: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000C4738: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000C473C: BF870585
	.long 0xd71c001d                                           // 0000000C4740: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000C4744: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000C4748: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000C474C: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000C4754: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000C4758: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000C4760: 980180C1
	v_mov_b32_e32 v29, v35                                     // 0000000C4764: 7E3A0323
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000C4768: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000C4774: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000C477C: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C4784: BF870001
	.long 0xd4490001                                           // 0000000C4788: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000C478C: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000C4794: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000C4798: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000C479C: 1040411E
	ds_store_b32 v29, v32                                      // 0000000C47A0: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000C47A8: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C47B0: 917E047E
	s_cbranch_execnz 65519                                     // 0000000C47B4: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc74>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C47B8: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000C47BC: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v38           // 0000000C47C4: CA100080 1F200126
	v_mov_b32_e32 v33, v36                                     // 0000000C47CC: 7E420324
	s_mov_b32 s10, 0                                           // 0000000C47D0: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C47D4: BF89FC07
	s_barrier                                                  // 0000000C47D8: BFBD0000
	buffer_gl0_inv                                             // 0000000C47DC: E0AC0000 00000000
	s_nop 0                                                    // 0000000C47E4: BF800000
	s_nop 0                                                    // 0000000C47E8: BF800000
	s_nop 0                                                    // 0000000C47EC: BF800000
	s_nop 0                                                    // 0000000C47F0: BF800000
	s_nop 0                                                    // 0000000C47F4: BF800000
	s_nop 0                                                    // 0000000C47F8: BF800000
	s_nop 0                                                    // 0000000C47FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000C4800: DC520000 227C001D
	ds_load_b32 v49, v31 offset:17184                          // 0000000C4808: D8D84320 3100001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000C4810: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000C4818: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C481C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000C4824: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C4828: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C4830: BF870004
	.long 0xd4490004                                           // 0000000C4834: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000C4838: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C4840: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C4844: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000C4848: 10446322
	ds_store_b32 v32, v34 offset:13056                         // 0000000C484C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000C4854: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C485C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C4860: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C4864: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000C4868: BF89FC07
	s_barrier                                                  // 0000000C486C: BFBD0000
	buffer_gl0_inv                                             // 0000000C4870: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v45 offset1:17                 // 0000000C4878: D8DC1100 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:34 offset1:51      // 0000000C4880: D8DC3322 1F00002D
	ds_load_2addr_b32 v[33:34], v45 offset0:68 offset1:85      // 0000000C4888: D8DC5544 2100002D
	ds_load_2addr_b32 v[49:50], v45 offset0:102 offset1:119    // 0000000C4890: D8DC7766 3100002D
	v_mov_b32_e32 v51, v0                                      // 0000000C4898: 7E660300
	s_mov_b32 s4, 0                                            // 0000000C489C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000C48A0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000C48A4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000C48AC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000C48B4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000C48B8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000C48C0: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000C48C8: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000C48CC: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000C48D4: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000C48DC: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000C48E0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000C48E8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C48F0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C48F8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4900: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4908: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4910: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4918: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4920: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4928: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000C4930: 326C6684
	.long 0xd4490001                                           // 0000000C4934: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000C4938: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C4940: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000C4944: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000C4948: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C4954: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000C4958: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000C4960: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000C4968: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000C4970: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000C4978: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000C4980: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000C4988: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000C4990: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000C4998: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000C499C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000C49A4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000C49A8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000C49B0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000C49B8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000C49C0: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000C49C4: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C49CC: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C49D4: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000C49DC: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C49E4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C49EC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C49F4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000C49FC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4A00: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000C4A04: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000C4A08: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000C4A0C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000C4A14: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000C4A18: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000C4A1C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000C4A20: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4A28: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000C4A30: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000C4A38: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C4A3C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4A40: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4A48: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4A50: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000C4A54: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000C4A58: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000C4A5C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C4A64: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000C4A68: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000C4A70: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C4A78: 917E047E
	s_cbranch_execnz 65452                                     // 0000000C4A7C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe30>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C4A80: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v31, v38         // 0000000C4A84: CA100110 1E1E0126
	v_dual_mov_b32 v29, v15 :: v_dual_mov_b32 v32, 0           // 0000000C4A8C: CA10010F 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000C4A94: 7E420324
	s_mov_b32 s10, 0                                           // 0000000C4A98: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C4A9C: BF89FC07
	s_barrier                                                  // 0000000C4AA0: BFBD0000
	buffer_gl0_inv                                             // 0000000C4AA4: E0AC0000 00000000
	s_nop 0                                                    // 0000000C4AAC: BF800000
	s_nop 0                                                    // 0000000C4AB0: BF800000
	s_nop 0                                                    // 0000000C4AB4: BF800000
	s_nop 0                                                    // 0000000C4AB8: BF800000
	s_nop 0                                                    // 0000000C4ABC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000C4AC0: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17216                          // 0000000C4AC8: D8D84340 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000C4AD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000C4AD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C4ADC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000C4AE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C4AE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C4AF0: BF870004
	.long 0xd4490004                                           // 0000000C4AF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000C4AF8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C4B00: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C4B04: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000C4B08: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000C4B0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000C4B14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C4B1C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C4B20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C4B24: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000C4B28: BF89FC07
	s_barrier                                                  // 0000000C4B2C: BFBD0000
	buffer_gl0_inv                                             // 0000000C4B30: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v45 offset0:136 offset1:153    // 0000000C4B38: D8DC9988 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:170 offset1:187    // 0000000C4B40: D8DCBBAA 1F00002D
	ds_load_2addr_b32 v[33:34], v45 offset0:204 offset1:221    // 0000000C4B48: D8DCDDCC 2100002D
	ds_load_2addr_b32 v[49:50], v45 offset0:238 offset1:255    // 0000000C4B50: D8DCFFEE 3100002D
	v_mov_b32_e32 v51, v0                                      // 0000000C4B58: 7E660300
	s_mov_b32 s4, 0                                            // 0000000C4B5C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000C4B60: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000C4B64: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000C4B6C: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000C4B74: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000C4B78: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000C4B80: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000C4B88: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000C4B8C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000C4B94: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000C4B9C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000C4BA0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000C4BA8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4BB0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4BB8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4BC0: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4BC8: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4BD0: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4BD8: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4BE0: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4BE8: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000C4BF0: 326C6684
	.long 0xd4490001                                           // 0000000C4BF4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000C4BF8: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C4C00: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000C4C04: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000C4C08: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C4C14: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000C4C18: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000C4C20: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000C4C28: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000C4C30: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000C4C38: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000C4C40: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000C4C48: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000C4C50: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000C4C58: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000C4C5C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000C4C64: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000C4C68: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000C4C70: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000C4C78: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000C4C80: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000C4C84: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4C8C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4C94: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000C4C9C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4CA4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4CAC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4CB4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000C4CBC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4CC0: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000C4CC4: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000C4CC8: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000C4CCC: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000C4CD4: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000C4CD8: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000C4CDC: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000C4CE0: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4CE8: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000C4CF0: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000C4CF8: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C4CFC: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4D00: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4D08: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4D10: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000C4D14: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000C4D18: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000C4D1C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C4D24: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000C4D28: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000C4D30: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C4D38: 917E047E
	s_cbranch_execnz 65452                                     // 0000000C4D3C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10f0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C4D40: 8C7E047E
	v_mov_b32_e32 v30, v18                                     // 0000000C4D44: 7E3C0312
	v_mov_b32_e32 v31, v38                                     // 0000000C4D48: 7E3E0326
	v_dual_mov_b32 v29, v17 :: v_dual_mov_b32 v32, 0           // 0000000C4D4C: CA100111 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000C4D54: 7E420324
	s_mov_b32 s10, 0                                           // 0000000C4D58: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C4D5C: BF89FC07
	s_barrier                                                  // 0000000C4D60: BFBD0000
	buffer_gl0_inv                                             // 0000000C4D64: E0AC0000 00000000
	s_nop 0                                                    // 0000000C4D6C: BF800000
	s_nop 0                                                    // 0000000C4D70: BF800000
	s_nop 0                                                    // 0000000C4D74: BF800000
	s_nop 0                                                    // 0000000C4D78: BF800000
	s_nop 0                                                    // 0000000C4D7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000C4D80: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17248                          // 0000000C4D88: D8D84360 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000C4D90: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000C4D98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C4D9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000C4DA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C4DA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C4DB0: BF870004
	.long 0xd4490004                                           // 0000000C4DB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000C4DB8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C4DC0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C4DC4: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000C4DC8: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000C4DCC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000C4DD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C4DDC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C4DE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1280>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C4DE4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000C4DE8: BF89FC07
	s_barrier                                                  // 0000000C4DEC: BFBD0000
	buffer_gl0_inv                                             // 0000000C4DF0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v46 offset0:16 offset1:33      // 0000000C4DF8: D8DC2110 1D00002E
	ds_load_2addr_b32 v[31:32], v46 offset0:50 offset1:67      // 0000000C4E00: D8DC4332 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:84 offset1:101     // 0000000C4E08: D8DC6554 2100002E
	ds_load_2addr_b32 v[49:50], v46 offset0:118 offset1:135    // 0000000C4E10: D8DC8776 3100002E
	v_mov_b32_e32 v51, v0                                      // 0000000C4E18: 7E660300
	s_mov_b32 s4, 0                                            // 0000000C4E1C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000C4E20: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000C4E24: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000C4E2C: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000C4E34: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000C4E38: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000C4E40: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000C4E48: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000C4E4C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000C4E54: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000C4E5C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000C4E60: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000C4E68: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4E70: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4E78: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4E80: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4E88: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4E90: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4E98: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4EA0: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4EA8: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000C4EB0: 326C6684
	.long 0xd4490001                                           // 0000000C4EB4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000C4EB8: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C4EC0: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000C4EC4: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000C4EC8: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C4ED4: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000C4ED8: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000C4EE0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000C4EE8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000C4EF0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000C4EF8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000C4F00: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000C4F08: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000C4F10: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000C4F18: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000C4F1C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000C4F24: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000C4F28: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000C4F30: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000C4F38: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000C4F40: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000C4F44: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4F4C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4F54: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000C4F5C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4F64: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4F6C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4F74: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000C4F7C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4F80: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000C4F84: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000C4F88: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000C4F8C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000C4F94: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000C4F98: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000C4F9C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000C4FA0: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4FA8: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000C4FB0: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000C4FB8: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C4FBC: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4FC0: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C4FC8: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C4FD0: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000C4FD4: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000C4FD8: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000C4FDC: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C4FE4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000C4FE8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000C4FF0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C4FF8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000C4FFC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13b0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C5000: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v31, v38         // 0000000C5004: CA100114 1E1E0126
	v_dual_mov_b32 v29, v19 :: v_dual_mov_b32 v32, 0           // 0000000C500C: CA100113 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000C5014: 7E420324
	s_mov_b32 s10, 0                                           // 0000000C5018: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C501C: BF89FC07
	s_barrier                                                  // 0000000C5020: BFBD0000
	buffer_gl0_inv                                             // 0000000C5024: E0AC0000 00000000
	s_nop 0                                                    // 0000000C502C: BF800000
	s_nop 0                                                    // 0000000C5030: BF800000
	s_nop 0                                                    // 0000000C5034: BF800000
	s_nop 0                                                    // 0000000C5038: BF800000
	s_nop 0                                                    // 0000000C503C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000C5040: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17280                          // 0000000C5048: D8D84380 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000C5050: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000C5058: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C505C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000C5064: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C5068: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C5070: BF870004
	.long 0xd4490004                                           // 0000000C5074: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000C5078: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C5080: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C5084: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000C5088: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000C508C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000C5094: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C509C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C50A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1540>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C50A4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000C50A8: BF89FC07
	s_barrier                                                  // 0000000C50AC: BFBD0000
	buffer_gl0_inv                                             // 0000000C50B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v46 offset0:152 offset1:169    // 0000000C50B8: D8DCA998 1D00002E
	ds_load_2addr_b32 v[31:32], v46 offset0:186 offset1:203    // 0000000C50C0: D8DCCBBA 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:220 offset1:237    // 0000000C50C8: D8DCEDDC 2100002E
	ds_load_2addr_b32 v[49:50], v47 offset0:126 offset1:143    // 0000000C50D0: D8DC8F7E 3100002F
	v_mov_b32_e32 v51, v0                                      // 0000000C50D8: 7E660300
	s_mov_b32 s4, 0                                            // 0000000C50DC: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000C50E0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000C50E4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000C50EC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000C50F4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000C50F8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000C5100: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000C5108: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000C510C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000C5114: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000C511C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000C5120: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000C5128: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5130: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5138: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5140: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5148: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5150: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5158: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5160: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5168: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000C5170: 326C6684
	.long 0xd4490001                                           // 0000000C5174: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000C5178: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C5180: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000C5184: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000C5188: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C5194: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000C5198: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000C51A0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000C51A8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000C51B0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000C51B8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000C51C0: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000C51C8: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000C51D0: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000C51D8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000C51DC: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000C51E4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000C51E8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000C51F0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000C51F8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000C5200: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000C5204: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C520C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5214: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000C521C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5224: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C522C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5234: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000C523C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5240: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000C5244: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000C5248: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000C524C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000C5254: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000C5258: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000C525C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000C5260: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5268: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000C5270: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000C5278: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C527C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5280: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5288: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5290: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000C5294: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000C5298: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000C529C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C52A4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000C52A8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000C52B0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C52B8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000C52BC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1670>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C52C0: 8C7E047E
	v_mov_b32_e32 v30, v22                                     // 0000000C52C4: 7E3C0316
	v_mov_b32_e32 v31, v38                                     // 0000000C52C8: 7E3E0326
	v_dual_mov_b32 v29, v21 :: v_dual_mov_b32 v32, 0           // 0000000C52CC: CA100115 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000C52D4: 7E420324
	s_mov_b32 s10, 0                                           // 0000000C52D8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C52DC: BF89FC07
	s_barrier                                                  // 0000000C52E0: BFBD0000
	buffer_gl0_inv                                             // 0000000C52E4: E0AC0000 00000000
	s_nop 0                                                    // 0000000C52EC: BF800000
	s_nop 0                                                    // 0000000C52F0: BF800000
	s_nop 0                                                    // 0000000C52F4: BF800000
	s_nop 0                                                    // 0000000C52F8: BF800000
	s_nop 0                                                    // 0000000C52FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000C5300: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17312                          // 0000000C5308: D8D843A0 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000C5310: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000C5318: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C531C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000C5324: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C5328: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C5330: BF870004
	.long 0xd4490004                                           // 0000000C5334: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000C5338: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C5340: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C5344: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000C5348: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000C534C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000C5354: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C535C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C5360: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1800>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C5364: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000C5368: BF89FC07
	s_barrier                                                  // 0000000C536C: BFBD0000
	buffer_gl0_inv                                             // 0000000C5370: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v48 offset0:32 offset1:49      // 0000000C5378: D8DC3120 1D000030
	ds_load_2addr_b32 v[31:32], v48 offset0:66 offset1:83      // 0000000C5380: D8DC5342 1F000030
	ds_load_2addr_b32 v[33:34], v48 offset0:100 offset1:117    // 0000000C5388: D8DC7564 21000030
	ds_load_2addr_b32 v[49:50], v48 offset0:134 offset1:151    // 0000000C5390: D8DC9786 31000030
	v_mov_b32_e32 v51, v0                                      // 0000000C5398: 7E660300
	s_mov_b32 s4, 0                                            // 0000000C539C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000C53A0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000C53A4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000C53AC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000C53B4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000C53B8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000C53C0: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000C53C8: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000C53CC: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000C53D4: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000C53DC: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000C53E0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000C53E8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C53F0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C53F8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5400: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5408: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5410: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5418: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5420: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5428: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000C5430: 326C6684
	.long 0xd4490001                                           // 0000000C5434: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000C5438: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C5440: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000C5444: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000C5448: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C5454: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000C5458: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000C5460: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000C5468: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000C5470: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000C5478: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000C5480: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000C5488: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000C5490: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000C5498: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000C549C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000C54A4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000C54A8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000C54B0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000C54B8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000C54C0: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000C54C4: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C54CC: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C54D4: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000C54DC: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C54E4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C54EC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C54F4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000C54FC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5500: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000C5504: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000C5508: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000C550C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000C5514: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000C5518: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000C551C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000C5520: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5528: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000C5530: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000C5538: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C553C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5540: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5548: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5550: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000C5554: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000C5558: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000C555C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5564: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000C5568: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000C5570: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C5578: 917E047E
	s_cbranch_execnz 65452                                     // 0000000C557C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1930>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C5580: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v31, v38         // 0000000C5584: CA100118 1E1E0126
	v_dual_mov_b32 v29, v23 :: v_dual_mov_b32 v32, 0           // 0000000C558C: CA100117 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000C5594: 7E420324
	s_mov_b32 s10, 0                                           // 0000000C5598: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C559C: BF89FC07
	s_barrier                                                  // 0000000C55A0: BFBD0000
	buffer_gl0_inv                                             // 0000000C55A4: E0AC0000 00000000
	s_nop 0                                                    // 0000000C55AC: BF800000
	s_nop 0                                                    // 0000000C55B0: BF800000
	s_nop 0                                                    // 0000000C55B4: BF800000
	s_nop 0                                                    // 0000000C55B8: BF800000
	s_nop 0                                                    // 0000000C55BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000C55C0: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17344                          // 0000000C55C8: D8D843C0 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000C55D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000C55D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C55DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000C55E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C55E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C55F0: BF870004
	.long 0xd4490004                                           // 0000000C55F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000C55F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C5600: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C5604: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000C5608: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000C560C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000C5614: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C561C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C5620: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ac0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C5624: 8C7E0A7E
	v_add_nc_u32_e32 v31, 0xc00, v45                           // 0000000C5628: 4A3E5AFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000C5630: BF89FC07
	s_barrier                                                  // 0000000C5634: BFBD0000
	buffer_gl0_inv                                             // 0000000C5638: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v48 offset0:168 offset1:185    // 0000000C5640: D8DCB9A8 1D000030
	ds_load_2addr_b32 v[32:33], v48 offset0:202 offset1:219    // 0000000C5648: D8DCDBCA 20000030
	ds_load_2addr_b32 v[49:50], v48 offset0:236 offset1:253    // 0000000C5650: D8DCFDEC 31000030
	ds_load_2addr_b32 v[51:52], v31 offset0:14 offset1:31      // 0000000C5658: D8DC1F0E 3300001F
	s_mov_b32 s4, 0                                            // 0000000C5660: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000C5664: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000C5668: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000C5670: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000C5678: BF89FC27
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000C567C: CC210020 02000D20
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000C5684: CC210021 02000D21
	s_waitcnt lgkmcnt(1)                                       // 0000000C568C: BF89FC17
	v_fma_mixlo_f16 v34, v49, s6, 0                            // 0000000C5690: CC210022 02000D31
	v_fma_mixlo_f16 v49, v50, s6, 0                            // 0000000C5698: CC210031 02000D32
	s_waitcnt lgkmcnt(0)                                       // 0000000C56A0: BF89FC07
	v_fma_mixlo_f16 v50, v51, s6, 0                            // 0000000C56A4: CC210032 02000D33
	v_fma_mixlo_f16 v51, v52, s6, 0                            // 0000000C56AC: CC210033 02000D34
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C56B4: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C56BC: CC20001E 8A000F1E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C56C4: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C56CC: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C56D4: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C56DC: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C56E4: CC200032 8A000F32
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C56EC: CC200033 8A000F33
	v_mov_b32_e32 v52, v0                                      // 0000000C56F4: 7E680300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C56F8: BF870121
	v_lshrrev_b32_e32 v55, 4, v52                              // 0000000C56FC: 326E6884
	.long 0xd4490001                                           // 0000000C5700: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v52, vcc_lo                   // 0000000C5704: 020268FF 0000077F
	v_lshlrev_b32_e32 v60, 2, v55                              // 0000000C570C: 30786E82
	v_mad_u64_u32 v[55:56], null, 0x44, v55, v[1:2]            // 0000000C5710: D6FE7C37 04066EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C571C: 8C040401
	v_add_nc_u32_e32 v53, 0x3200, v60                          // 0000000C5720: 4A6A78FF 00003200
	v_add_nc_u32_e32 v56, 0x3600, v60                          // 0000000C5728: 4A7078FF 00003600
	v_add_nc_u32_e32 v58, 0x3a00, v60                          // 0000000C5730: 4A7478FF 00003A00
	v_add_nc_u32_e32 v60, 0x3e00, v60                          // 0000000C5738: 4A7878FF 00003E00
	ds_load_b32 v61, v55                                       // 0000000C5740: D8D80000 3D000037
	ds_load_2addr_b32 v[56:57], v56 offset0:66 offset1:195     // 0000000C5748: D8DCC342 38000038
	ds_load_2addr_b32 v[53:54], v53 offset0:64 offset1:193     // 0000000C5750: D8DCC140 35000035
	ds_load_2addr_b32 v[58:59], v58 offset0:68 offset1:197     // 0000000C5758: D8DCC544 3A00003A
	s_waitcnt lgkmcnt(2)                                       // 0000000C5760: BF89FC27
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000C5764: CC210038 02000D38
	s_waitcnt lgkmcnt(1)                                       // 0000000C576C: BF89FC17
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000C5770: CC210035 02000D35
	v_fma_mixlo_f16 v62, v54, s6, 0                            // 0000000C5778: CC21003E 02000D36
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000C5780: CC210039 02000D39
	s_waitcnt lgkmcnt(0)                                       // 0000000C5788: BF89FC07
	v_fma_mixlo_f16 v58, v58, s6, 0                            // 0000000C578C: CC21003A 02000D3A
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5794: CC200038 8A000F38
	v_fma_mix_f32 v63, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C579C: CC20003F 8A000F35
	ds_load_2addr_b32 v[53:54], v60 offset0:70 offset1:199     // 0000000C57A4: D8DCC746 3500003C
	v_fma_mix_f32 v60, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C57AC: CC20003C 8A000F3E
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C57B4: CC200039 8A000F39
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C57BC: CC20003A 8A000F3A
	v_fmac_f32_e32 v61, v63, v29                               // 0000000C57C4: 567A3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C57C8: BF870091
	v_fmac_f32_e32 v61, v60, v30                               // 0000000C57CC: 567A3D3C
	v_fmac_f32_e32 v61, v56, v32                               // 0000000C57D0: 567A4138
	v_fma_mixlo_f16 v56, v59, s6, 0                            // 0000000C57D4: CC210038 02000D3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000C57DC: BF8701B2
	v_fmac_f32_e32 v61, v57, v33                               // 0000000C57E0: 567A4339
	s_waitcnt lgkmcnt(0)                                       // 0000000C57E4: BF89FC07
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000C57E8: CC210035 02000D35
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C57F0: CC200038 8A000F38
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000C57F8: CC210036 02000D36
	v_fmac_f32_e32 v61, v58, v34                               // 0000000C5800: 567A453A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C5804: BF870194
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5808: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5810: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5818: BF870093
	v_fmac_f32_e32 v61, v56, v49                               // 0000000C581C: 567A6338
	v_fmac_f32_e32 v61, v53, v50                               // 0000000C5820: 567A6535
	v_add_nc_u32_e32 v53, 0x80, v52                            // 0000000C5824: 4A6A68FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C582C: BF870001
	v_dual_fmac_f32 v61, v54, v51 :: v_dual_mov_b32 v52, v53   // 0000000C5830: C8106736 3D340135
	ds_store_b32 v55, v61                                      // 0000000C5838: D8340000 00003D37
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C5840: 917E047E
	s_cbranch_execnz 65452                                     // 0000000C5844: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1bf8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C5848: 8C7E047E
	v_mov_b32_e32 v30, v26                                     // 0000000C584C: 7E3C031A
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v29, v25         // 0000000C5850: CA100126 201C0119
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 0000000C5858: CA100080 21220124
	s_mov_b32 s10, 0                                           // 0000000C5860: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C5864: BF89FC07
	s_barrier                                                  // 0000000C5868: BFBD0000
	buffer_gl0_inv                                             // 0000000C586C: E0AC0000 00000000
	s_nop 0                                                    // 0000000C5874: BF800000
	s_nop 0                                                    // 0000000C5878: BF800000
	s_nop 0                                                    // 0000000C587C: BF800000
	global_load_b32 v49, v[29:30], off                         // 0000000C5880: DC520000 317C001D
	ds_load_b32 v50, v33 offset:17376                          // 0000000C5888: D8D843E0 32000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000C5890: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000C5898: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C589C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000C58A4: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C58A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C58B0: BF870004
	.long 0xd4490004                                           // 0000000C58B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000C58B8: 020244FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C58C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C58C4: BF890007
	v_mul_f32_e32 v49, v49, v50                                // 0000000C58C8: 10626531
	ds_store_b32 v32, v49 offset:13056                         // 0000000C58CC: D8343300 00003120
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000C58D4: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C58DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C58E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C58E4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000C58E8: BF89FC07
	s_barrier                                                  // 0000000C58EC: BFBD0000
	buffer_gl0_inv                                             // 0000000C58F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:48 offset1:65      // 0000000C58F8: D8DC4130 1D00001F
	ds_load_2addr_b32 v[32:33], v31 offset0:82 offset1:99      // 0000000C5900: D8DC6352 2000001F
	ds_load_2addr_b32 v[49:50], v31 offset0:116 offset1:133    // 0000000C5908: D8DC8574 3100001F
	ds_load_2addr_b32 v[51:52], v31 offset0:150 offset1:167    // 0000000C5910: D8DCA796 3300001F
	s_mov_b32 s4, 0                                            // 0000000C5918: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000C591C: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000C5920: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000C5928: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000C5930: BF89FC27
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000C5934: CC210020 02000D20
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000C593C: CC210021 02000D21
	s_waitcnt lgkmcnt(1)                                       // 0000000C5944: BF89FC17
	v_fma_mixlo_f16 v34, v49, s6, 0                            // 0000000C5948: CC210022 02000D31
	v_fma_mixlo_f16 v49, v50, s6, 0                            // 0000000C5950: CC210031 02000D32
	s_waitcnt lgkmcnt(0)                                       // 0000000C5958: BF89FC07
	v_fma_mixlo_f16 v50, v51, s6, 0                            // 0000000C595C: CC210032 02000D33
	v_fma_mixlo_f16 v51, v52, s6, 0                            // 0000000C5964: CC210033 02000D34
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C596C: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5974: CC20001E 8A000F1E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C597C: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5984: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C598C: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5994: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C599C: CC200032 8A000F32
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C59A4: CC200033 8A000F33
	v_mov_b32_e32 v52, v0                                      // 0000000C59AC: 7E680300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C59B0: BF870121
	v_lshrrev_b32_e32 v55, 4, v52                              // 0000000C59B4: 326E6884
	.long 0xd4490001                                           // 0000000C59B8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v52, vcc_lo                   // 0000000C59BC: 020268FF 0000077F
	v_lshlrev_b32_e32 v60, 2, v55                              // 0000000C59C4: 30786E82
	v_mad_u64_u32 v[55:56], null, 0x44, v55, v[1:2]            // 0000000C59C8: D6FE7C37 04066EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C59D4: 8C040401
	v_add_nc_u32_e32 v53, 0x3200, v60                          // 0000000C59D8: 4A6A78FF 00003200
	v_add_nc_u32_e32 v56, 0x3600, v60                          // 0000000C59E0: 4A7078FF 00003600
	v_add_nc_u32_e32 v58, 0x3a00, v60                          // 0000000C59E8: 4A7478FF 00003A00
	v_add_nc_u32_e32 v60, 0x3e00, v60                          // 0000000C59F0: 4A7878FF 00003E00
	ds_load_b32 v61, v55                                       // 0000000C59F8: D8D80000 3D000037
	ds_load_2addr_b32 v[56:57], v56 offset0:66 offset1:195     // 0000000C5A00: D8DCC342 38000038
	ds_load_2addr_b32 v[53:54], v53 offset0:64 offset1:193     // 0000000C5A08: D8DCC140 35000035
	ds_load_2addr_b32 v[58:59], v58 offset0:68 offset1:197     // 0000000C5A10: D8DCC544 3A00003A
	s_waitcnt lgkmcnt(2)                                       // 0000000C5A18: BF89FC27
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000C5A1C: CC210038 02000D38
	s_waitcnt lgkmcnt(1)                                       // 0000000C5A24: BF89FC17
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000C5A28: CC210035 02000D35
	v_fma_mixlo_f16 v62, v54, s6, 0                            // 0000000C5A30: CC21003E 02000D36
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000C5A38: CC210039 02000D39
	s_waitcnt lgkmcnt(0)                                       // 0000000C5A40: BF89FC07
	v_fma_mixlo_f16 v58, v58, s6, 0                            // 0000000C5A44: CC21003A 02000D3A
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5A4C: CC200038 8A000F38
	v_fma_mix_f32 v63, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5A54: CC20003F 8A000F35
	ds_load_2addr_b32 v[53:54], v60 offset0:70 offset1:199     // 0000000C5A5C: D8DCC746 3500003C
	v_fma_mix_f32 v60, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5A64: CC20003C 8A000F3E
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5A6C: CC200039 8A000F39
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5A74: CC20003A 8A000F3A
	v_fmac_f32_e32 v61, v63, v29                               // 0000000C5A7C: 567A3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5A80: BF870091
	v_fmac_f32_e32 v61, v60, v30                               // 0000000C5A84: 567A3D3C
	v_fmac_f32_e32 v61, v56, v32                               // 0000000C5A88: 567A4138
	v_fma_mixlo_f16 v56, v59, s6, 0                            // 0000000C5A8C: CC210038 02000D3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000C5A94: BF8701B2
	v_fmac_f32_e32 v61, v57, v33                               // 0000000C5A98: 567A4339
	s_waitcnt lgkmcnt(0)                                       // 0000000C5A9C: BF89FC07
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000C5AA0: CC210035 02000D35
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5AA8: CC200038 8A000F38
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000C5AB0: CC210036 02000D36
	v_fmac_f32_e32 v61, v58, v34                               // 0000000C5AB8: 567A453A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C5ABC: BF870194
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5AC0: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5AC8: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5AD0: BF870093
	v_fmac_f32_e32 v61, v56, v49                               // 0000000C5AD4: 567A6338
	v_fmac_f32_e32 v61, v53, v50                               // 0000000C5AD8: 567A6535
	v_add_nc_u32_e32 v53, 0x80, v52                            // 0000000C5ADC: 4A6A68FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5AE4: BF870001
	v_dual_fmac_f32 v61, v54, v51 :: v_dual_mov_b32 v52, v53   // 0000000C5AE8: C8106736 3D340135
	ds_store_b32 v55, v61                                      // 0000000C5AF0: D8340000 00003D37
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C5AF8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000C5AFC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1eb0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C5B00: 8C7E047E
	v_mov_b32_e32 v30, v28                                     // 0000000C5B04: 7E3C031C
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v29, v27         // 0000000C5B08: CA100126 201C011B
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 0000000C5B10: CA100080 21220124
	s_mov_b32 s10, 0                                           // 0000000C5B18: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C5B1C: BF89FC07
	s_barrier                                                  // 0000000C5B20: BFBD0000
	buffer_gl0_inv                                             // 0000000C5B24: E0AC0000 00000000
	s_nop 0                                                    // 0000000C5B2C: BF800000
	s_nop 0                                                    // 0000000C5B30: BF800000
	s_nop 0                                                    // 0000000C5B34: BF800000
	s_nop 0                                                    // 0000000C5B38: BF800000
	s_nop 0                                                    // 0000000C5B3C: BF800000
	global_load_b32 v49, v[29:30], off                         // 0000000C5B40: DC520000 317C001D
	ds_load_b32 v50, v33 offset:17408                          // 0000000C5B48: D8D84400 32000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000C5B50: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000C5B58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C5B5C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000C5B64: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C5B68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C5B70: BF870004
	.long 0xd4490004                                           // 0000000C5B74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000C5B78: 020244FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C5B80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C5B84: BF890007
	v_mul_f32_e32 v49, v49, v50                                // 0000000C5B88: 10626531
	ds_store_b32 v32, v49 offset:13056                         // 0000000C5B8C: D8343300 00003120
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000C5B94: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C5B9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C5BA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C5BA4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v45                           // 0000000C5BA8: 4A425AFF 00000E00
	v_add_nc_u32_e32 v49, 0x1000, v45                          // 0000000C5BB0: 4A625AFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000C5BB8: BF89FC07
	s_barrier                                                  // 0000000C5BBC: BFBD0000
	buffer_gl0_inv                                             // 0000000C5BC0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:184 offset1:201    // 0000000C5BC8: D8DCC9B8 1D00001F
	ds_load_2addr_b32 v[31:32], v31 offset0:218 offset1:235    // 0000000C5BD0: D8DCEBDA 1F00001F
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000C5BD8: D8DC8D7C 21000021
	ds_load_2addr_b32 v[49:50], v49 offset0:30 offset1:47      // 0000000C5BE0: D8DC2F1E 31000031
	v_mov_b32_e32 v51, v0                                      // 0000000C5BE8: 7E660300
	s_mov_b32 s4, 0                                            // 0000000C5BEC: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000C5BF0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000C5BF4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000C5BFC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000C5C04: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000C5C08: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000C5C10: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000C5C18: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000C5C1C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000C5C24: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000C5C2C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000C5C30: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000C5C38: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5C40: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5C48: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5C50: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5C58: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5C60: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5C68: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5C70: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5C78: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000C5C80: 326C6684
	.long 0xd4490001                                           // 0000000C5C84: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000C5C88: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C5C90: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000C5C94: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000C5C98: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C5CA4: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000C5CA8: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000C5CB0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000C5CB8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000C5CC0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000C5CC8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000C5CD0: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000C5CD8: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000C5CE0: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000C5CE8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000C5CEC: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000C5CF4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000C5CF8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000C5D00: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000C5D08: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000C5D10: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000C5D14: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5D1C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5D24: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000C5D2C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5D34: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5D3C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5D44: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000C5D4C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5D50: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000C5D54: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000C5D58: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000C5D5C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000C5D64: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000C5D68: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000C5D6C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000C5D70: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5D78: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000C5D80: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000C5D88: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C5D8C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5D90: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C5D98: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5DA0: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000C5DA4: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000C5DA8: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000C5DAC: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5DB4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000C5DB8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000C5DC0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C5DC8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000C5DCC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C5DD0: 8C7E047E
	.long 0xd7000107                                           // 0000000C5DD4: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000C5DD8: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C5DE0: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000C5DE4: D5207C08 00061080
	.long 0xd7000109                                           // 0000000C5DEC: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000C5DF0: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000C5DF8: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000C5E00: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000C5E04: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C5E0C: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000C5E10: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000C5E18: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000C5E1C: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000C5E24: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000C5E2C: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000C5E30: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C5E38: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000C5E3C: D5207C10 00062080
	.long 0xd7000111                                           // 0000000C5E44: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000C5E48: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000C5E50: D5207C12 00062480
	.long 0xd7000113                                           // 0000000C5E58: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000C5E5C: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C5E64: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000C5E68: D5207C14 00062880
	.long 0xd7000115                                           // 0000000C5E70: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000C5E74: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000C5E7C: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000C5E84: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000C5E88: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C5E90: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000C5E94: D5207C18 00063080
	.long 0xd7000119                                           // 0000000C5E9C: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000C5EA0: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000C5EA8: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000C5EB0: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000C5EB4: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C5EBC: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000C5EC0: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000C5EC8: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000C5ECC: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000C5ED0: BF062105
	s_barrier                                                  // 0000000C5ED4: BFBD0000
	buffer_gl0_inv                                             // 0000000C5ED8: E0AC0000 00000000
	s_cbranch_scc0 63457                                       // 0000000C5EE0: BFA1F7E1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x368>
	v_mov_b32_e32 v4, v36                                      // 0000000C5EE4: 7E080324
	s_add_u32 s0, s28, s20                                     // 0000000C5EE8: 8000141C
	.long 0xd73c0000                                           // 0000000C5EEC: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000C5EF0: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000C5EF4: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000C5EF8: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000C5EFC: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000C5F00: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000C5F04: 82010103
	.long 0xd7006a00                                           // 0000000C5F08: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000C5F0C: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000C5F10: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000C5F14: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000C5F1C: BE810080
	.long 0xd7006a00                                           // 0000000C5F20: D7006A00
	v_cndmask_b32_e32 v1, v0, v37, vcc_lo                      // 0000000C5F24: 02024B00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000C5F28: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C5F30: BF870092
	.long 0xd7006a00                                           // 0000000C5F34: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000C5F38: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000C5F3C: D5207C01 01AA0211
	s_nop 0                                                    // 0000000C5F44: BF800000
	s_nop 0                                                    // 0000000C5F48: BF800000
	s_nop 0                                                    // 0000000C5F4C: BF800000
	s_nop 0                                                    // 0000000C5F50: BF800000
	s_nop 0                                                    // 0000000C5F54: BF800000
	s_nop 0                                                    // 0000000C5F58: BF800000
	s_nop 0                                                    // 0000000C5F5C: BF800000
	s_nop 0                                                    // 0000000C5F60: BF800000
	s_nop 0                                                    // 0000000C5F64: BF800000
	s_nop 0                                                    // 0000000C5F68: BF800000
	s_nop 0                                                    // 0000000C5F6C: BF800000
	s_nop 0                                                    // 0000000C5F70: BF800000
	s_nop 0                                                    // 0000000C5F74: BF800000
	s_nop 0                                                    // 0000000C5F78: BF800000
	s_nop 0                                                    // 0000000C5F7C: BF800000
	ds_load_b32 v2, v35                                        // 0000000C5F80: D8D80000 02000023
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000C5F88: 4A0808FF 00000080
	v_add_nc_u32_e32 v35, 0x220, v35                           // 0000000C5F90: 4A4646FF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000C5F98: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000C5F9C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000C5FA4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000C5FA8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000C5FAC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000C5FB4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000C5FB8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000C5FC0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000C5FC8: 917E017E
	s_cbranch_execnz 65516                                     // 0000000C5FCC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2480>
	s_endpgm                                                   // 0000000C5FD0: BFB00000
		...

