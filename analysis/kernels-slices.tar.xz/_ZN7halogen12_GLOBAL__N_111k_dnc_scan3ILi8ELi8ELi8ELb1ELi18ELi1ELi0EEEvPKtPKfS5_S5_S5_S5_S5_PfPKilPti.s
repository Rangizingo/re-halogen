00000000000d2d00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000D2D00: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000D2D04: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000D2D0C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000D2D14: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000D2D18: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000D2D1C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000D2D20: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000D2D28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000D2D2C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000D2D30: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000D2D34: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000D2D3C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000D2D40: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000D2D44: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000D2D48: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000D2D4C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000D2D50: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000D2D54: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000D2D58: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000D2D5C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000D2D64: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000D2D6C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000D2D70: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000D2D74: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000D2D78: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000D2D7C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000D2D80: 821E191E
	.long 0xd7001f02                                           // 0000000D2D84: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000D2D88: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000D2D8C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000D2D94: BE9E0080
	s_nop 0                                                    // 0000000D2D98: BF800000
	s_nop 0                                                    // 0000000D2D9C: BF800000
	s_nop 0                                                    // 0000000D2DA0: BF800000
	s_nop 0                                                    // 0000000D2DA4: BF800000
	s_nop 0                                                    // 0000000D2DA8: BF800000
	s_nop 0                                                    // 0000000D2DAC: BF800000
	s_nop 0                                                    // 0000000D2DB0: BF800000
	s_nop 0                                                    // 0000000D2DB4: BF800000
	s_nop 0                                                    // 0000000D2DB8: BF800000
	s_nop 0                                                    // 0000000D2DBC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000D2DC0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000D2DC4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D2DCC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000D2DD0: 300C1089
	.long 0xd7006a06                                           // 0000000D2DD4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000D2DD8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D2DDC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000D2DE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000D2DE8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000D2DF0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000D2DF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000D2DFC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000D2E08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000D2E0C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000D2E10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000D2E18: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000D2E1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000D2E20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000D2E24: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 0000000D2E2C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000D2E34: 32040084
	s_mov_b32 s0, 0                                            // 0000000D2E38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000D2E3C: BF89FC07
	s_barrier                                                  // 0000000D2E40: BFBD0000
	buffer_gl0_inv                                             // 0000000D2E44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000D2E4C: BF02801E
	s_cbranch_scc1 12                                          // 0000000D2E50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000D2E54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000D2E5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D2E64: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 0000000D2E68: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000D2E70: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000D2E74: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000D2E78: 916A007E
	s_cbranch_vccz 2                                           // 0000000D2E7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2088                                              // 0000000D2E80: BFA00828 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2224>
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000D2E84: 304E0A82
	s_add_i32 s0, s30, 63                                      // 0000000D2E88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000D2E8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000D2E94: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000D2E98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000D2E9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000D2EA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000000D2EA4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000000D2EAC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000D2EB0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000D2EB4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000D2EB8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000D2EBC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000D2EC0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000D2EC4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000000D2EC8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000D2ED4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000D2ED8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000D2EDC: B00A0204
	.long 0xd7000b2c                                           // 0000000D2EE0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000000D2EE4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000D2EE8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000000D2EEC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000000D2EF4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000D2F00: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 0000000D2F04: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 0000000D2F10: 3816500A
	.long 0xd7000a05                                           // 0000000D2F14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000D2F18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D2F1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000D2F20: D5207C06 00290001
	.long 0xd7000107                                           // 0000000D2F28: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000D2F2C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D2F30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000D2F34: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000D2F3C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000D2F40: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000D2F44: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000D2F4C: 84848E02
	.long 0xd700010b                                           // 0000000D2F50: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000D2F54: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000D2F58: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000D2F5C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000D2F64: 8205050F
	.long 0xd700010d                                           // 0000000D2F68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000D2F6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D2F70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000D2F74: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000D2F7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000D2F80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000D2F88: D5207C10 00061880
	.long 0xd7000111                                           // 0000000D2F90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000D2F94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D2F9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000D2FA0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000D2FA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000D2FAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000D2FB4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000D2FBC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000D2FC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D2FC8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000D2FCC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000D2FD4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000D2FD8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000D2FE0: D5207C18 00061880
	.long 0xd7000119                                           // 0000000D2FE8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000D2FEC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D2FF4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000D2FF8: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000D3000: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000D3004: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 0000000D300C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 0000000D3014: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000D3018: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 0000000D3020: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 0000000D3024: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 0000000D302C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000D3034: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 0000000D303C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 0000000D3044: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 0000000D304C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 0000000D3054: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 0000000D305C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 0000000D3064: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 0000000D306C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 0000000D3074: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 0000000D307C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 0000000D3084: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 0000000D308C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 0000000D3094: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 0000000D309C: BE850080
	s_mov_b32 s6, 0x44800000                                   // 0000000D30A0: BE8600FF 44800000
	s_mov_b32 s7, 0x3a800000                                   // 0000000D30A8: BE8700FF 3A800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000D30B0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000D30B4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000D30BC: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000D30C0: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000D30C4: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000D30C8: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000D30CC: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000D30D0: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000D30D4: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000D30D8: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000D30DC: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000D30E4: BE84206A
	s_cbranch_execz 77                                         // 0000000D30E8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x520>
	v_or_b32_e32 v29, s11, v0                                  // 0000000D30EC: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D30F0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000D30F4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000D30FC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D3100: BF870091
	.long 0xd73c001d                                           // 0000000D3104: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000D3108: 02023A82
	.long 0xd700011d                                           // 0000000D310C: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000D3110: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D3114: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000D3118: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000D3120: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D3128: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000D312C: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000D3130: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000D313C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 0000000D3140: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 0000000D314C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000D3150: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000D315C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000D3160: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 0000000D3164: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000D3170: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D3174: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 0000000D3178: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 0000000D3180: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000D3184: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 0000000D318C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000D3194: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 0000000D3198: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D319C: BF870193
	v_exp_f32_e32 v32, v32                                     // 0000000D31A0: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 0000000D31A4: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000D31A8: BF870296
	.long 0xd71c0020                                           // 0000000D31AC: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000D31B0: 02024520
	.long 0xd71c001f                                           // 0000000D31B4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000D31B8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D31BC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000D31C0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000D31C8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000D31CC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000D31D4: D5010020 00064080
	.long 0xd41e0001                                           // 0000000D31DC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000D31E0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D31E8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000D31EC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000D31F8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000D31FC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000D3204: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 0000000D3210: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 0000000D3218: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D3220: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000D3224: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000D322C: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D3230: BF89FC07
	s_barrier                                                  // 0000000D3234: BFBD0000
	buffer_gl0_inv                                             // 0000000D3238: E0AC0000 00000000
	s_branch 15                                                // 0000000D3240: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D3244: 8C7E047E
	.long 0xd700011d                                           // 0000000D3248: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000D324C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D3254: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D3258: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000D3260: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000D3264: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000D3268: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000D326C: BF89FC07
	s_barrier                                                  // 0000000D3270: BFBD0000
	buffer_gl0_inv                                             // 0000000D3274: E0AC0000 00000000
	s_cbranch_scc1 182                                         // 0000000D327C: BFA200B6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x858>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000D3280: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 0000000D3288: CA100128 21220126
	s_mov_b32 s13, 0                                           // 0000000D3290: BE8D0080
	s_nop 0                                                    // 0000000D3294: BF800000
	s_nop 0                                                    // 0000000D3298: BF800000
	s_nop 0                                                    // 0000000D329C: BF800000
	s_nop 0                                                    // 0000000D32A0: BF800000
	s_nop 0                                                    // 0000000D32A4: BF800000
	s_nop 0                                                    // 0000000D32A8: BF800000
	s_nop 0                                                    // 0000000D32AC: BF800000
	s_nop 0                                                    // 0000000D32B0: BF800000
	s_nop 0                                                    // 0000000D32B4: BF800000
	s_nop 0                                                    // 0000000D32B8: BF800000
	s_nop 0                                                    // 0000000D32BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000000D32C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000D32C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000D32D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000D32D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D32DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000D32E0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000D32E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000D32EC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000D32F4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000D32F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000000D32FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000D3304: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000D330C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000D3310: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000D3314: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D3318: BF89FC07
	s_barrier                                                  // 0000000D331C: BFBD0000
	buffer_gl0_inv                                             // 0000000D3320: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000D3328: BE842000
	s_cbranch_execz 65477                                      // 0000000D332C: BFA5FFC5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	v_or3_b32 v31, s12, s11, v2                                // 0000000D3330: D658001F 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D3338: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 0000000D333C: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 0000000D3344: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 0000000D3348: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D334C: BF870091
	.long 0xd700011f                                           // 0000000D3350: D700011F
	v_cndmask_b32_e32 v1, v44, v31, vcc_lo                     // 0000000D3354: 02023F2C
	v_add_co_ci_u32_e64 v32, null, v45, v32, s1                // 0000000D3358: D5207C20 0006412D
	s_mov_b32 s1, 0                                            // 0000000D3360: BE810080
	global_load_b32 v31, v[31:32], off                         // 0000000D3364: DC520000 1F7C001F
	v_mad_u64_u32 v[32:33], null, 0x44, s1, v[1:2]             // 0000000D336C: D6FE7C20 040402FF 00000044
	s_add_i32 s13, s1, 8                                       // 0000000D3378: 810D8801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000D337C: B6810078
	ds_load_2addr_b32 v[33:34], v32 offset1:17                 // 0000000D3380: D8DC1100 21000020
	ds_load_2addr_b32 v[35:36], v32 offset0:34 offset1:51      // 0000000D3388: D8DC3322 23000020
	ds_load_2addr_b32 v[60:61], v32 offset0:68 offset1:85      // 0000000D3390: D8DC5544 3C000020
	ds_load_2addr_b32 v[62:63], v32 offset0:102 offset1:119    // 0000000D3398: D8DC7766 3E000020
	v_lshl_add_u32 v32, s1, 2, v46                             // 0000000D33A0: D6460020 04B90401
	s_mov_b32 s1, s13                                          // 0000000D33A8: BE81000D
	ds_load_2addr_b32 v[64:65], v32 offset1:1                  // 0000000D33AC: D8DC0100 40000020
	ds_load_2addr_b32 v[66:67], v32 offset0:2 offset1:3        // 0000000D33B4: D8DC0302 42000020
	ds_load_2addr_b32 v[68:69], v32 offset0:4 offset1:5        // 0000000D33BC: D8DC0504 44000020
	ds_load_2addr_b32 v[70:71], v32 offset0:6 offset1:7        // 0000000D33C4: D8DC0706 46000020
	s_waitcnt lgkmcnt(7)                                       // 0000000D33CC: BF89FC77
	v_fma_mixlo_f16 v32, v33, s6, 0                            // 0000000D33D0: CC210020 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000D33D8: CC210022 02000D22
	s_waitcnt lgkmcnt(6)                                       // 0000000D33E0: BF89FC67
	v_fma_mixlo_f16 v35, v35, s6, 0                            // 0000000D33E4: CC210023 02000D23
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D33EC: BF870193
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D33F0: CC200020 8A000F20
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D33F8: CC200022 8A000F22
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000D3400: BF870003
	v_fma_mix_f32 v35, v35, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D3404: CC200023 8A000F23
	s_waitcnt lgkmcnt(3)                                       // 0000000D340C: BF89FC37
	v_fma_mixlo_f16 v33, v64, s6, 0                            // 0000000D3410: CC210021 02000D40
	v_fma_mixlo_f16 v64, v65, s6, 0                            // 0000000D3418: CC210040 02000D41
	s_waitcnt lgkmcnt(2)                                       // 0000000D3420: BF89FC27
	v_fma_mixlo_f16 v65, v66, s6, 0                            // 0000000D3424: CC210041 02000D42
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D342C: BF870193
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D3430: CC200021 8A000F21
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D3438: CC200040 8A000F40
	s_waitcnt vmcnt(0)                                         // 0000000D3440: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000D3444: BF870242
	v_fma_f32 v31, -v33, v32, v31                              // 0000000D3448: D613001F 247E4121
	v_fma_mixlo_f16 v32, v36, s6, 0                            // 0000000D3450: CC210020 02000D24
	v_fma_mixlo_f16 v33, v67, s6, 0                            // 0000000D3458: CC210021 02000D43
	v_fma_mix_f32 v36, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D3460: CC200024 8A000F41
	v_fma_f32 v31, -v64, v34, v31                              // 0000000D3468: D613001F 247E4540
	v_fma_mixlo_f16 v34, v60, s6, 0                            // 0000000D3470: CC210022 02000D3C
	s_waitcnt lgkmcnt(1)                                       // 0000000D3478: BF89FC17
	v_fma_mixlo_f16 v60, v68, s6, 0                            // 0000000D347C: CC21003C 02000D44
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D3484: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D348C: CC200021 8A000F21
	v_fma_f32 v31, -v36, v35, v31                              // 0000000D3494: D613001F 247E4724
	v_fma_mixlo_f16 v35, v61, s6, 0                            // 0000000D349C: CC210023 02000D3D
	v_fma_mixlo_f16 v36, v69, s6, 0                            // 0000000D34A4: CC210024 02000D45
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D34AC: CC200022 8A000F22
	v_fma_mix_f32 v60, v60, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D34B4: CC20003C 8A000F3C
	v_fma_f32 v31, -v33, v32, v31                              // 0000000D34BC: D613001F 247E4121
	v_fma_mixlo_f16 v32, v62, s6, 0                            // 0000000D34C4: CC210020 02000D3E
	s_waitcnt lgkmcnt(0)                                       // 0000000D34CC: BF89FC07
	v_fma_mixlo_f16 v33, v70, s6, 0                            // 0000000D34D0: CC210021 02000D46
	v_fma_mix_f32 v35, v35, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D34D8: CC200023 8A000F23
	v_fma_mix_f32 v36, v36, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D34E0: CC200024 8A000F24
	v_fma_f32 v31, -v60, v34, v31                              // 0000000D34E8: D613001F 247E453C
	v_fma_mixlo_f16 v34, v63, s6, 0                            // 0000000D34F0: CC210022 02000D3F
	v_fma_mixlo_f16 v60, v71, s6, 0                            // 0000000D34F8: CC21003C 02000D47
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D3500: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D3508: CC200021 8A000F21
	v_fma_f32 v31, -v36, v35, v31                              // 0000000D3510: D613001F 247E4724
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D3518: CC200022 8A000F22
	v_fma_mix_f32 v35, v60, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D3520: CC200023 8A000F3C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D3528: BF870093
	v_fma_f32 v31, -v33, v32, v31                              // 0000000D352C: D613001F 247E4121
	v_fma_f32 v31, -v35, v34, v31                              // 0000000D3534: D613001F 247E4523
	s_cbranch_scc1 65419                                       // 0000000D353C: BFA2FF8B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x66c>
	v_mad_u64_u32 v[32:33], null, 0x44, s12, v[4:5]            // 0000000D3540: D6FE7C20 041018FF 00000044
	ds_store_b32 v32, v31                                      // 0000000D354C: D8340000 00001F20
	s_branch 65339                                             // 0000000D3554: BFA0FF3B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	v_mov_b32_e32 v30, v14                                     // 0000000D3558: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000D355C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000D3564: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 0000000D3568: 7E46032B
	s_mov_b32 s12, 0                                           // 0000000D356C: BE8C0080
	s_branch 21                                                // 0000000D3570: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8c8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000D3574: 8C7E0D7E
	.long 0xd700011f                                           // 0000000D3578: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000D357C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D3584: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000D3588: D5207C20 00064080
	.long 0xd700011d                                           // 0000000D3590: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000D3594: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000D359C: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D35A0: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000D35A8: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000D35AC: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000D35B0: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000D35B4: BC7C0000
	s_barrier                                                  // 0000000D35B8: BFBD0000
	buffer_gl0_inv                                             // 0000000D35BC: E0AC0000 00000000
	s_cbranch_scc1 606                                         // 0000000D35C4: BFA2025E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1240>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D35C8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000D35CC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000D35D4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000D35D8: 7E780326
	s_mov_b32 s13, 0                                           // 0000000D35DC: BE8D0080
	s_nop 0                                                    // 0000000D35E0: BF800000
	s_nop 0                                                    // 0000000D35E4: BF800000
	s_nop 0                                                    // 0000000D35E8: BF800000
	s_nop 0                                                    // 0000000D35EC: BF800000
	s_nop 0                                                    // 0000000D35F0: BF800000
	s_nop 0                                                    // 0000000D35F4: BF800000
	s_nop 0                                                    // 0000000D35F8: BF800000
	s_nop 0                                                    // 0000000D35FC: BF800000
	global_load_b32 v61, v[33:34], off                         // 0000000D3600: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000D3608: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000D3610: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000D3614: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D361C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000D3620: D5207C22 00064480
	.long 0xd4490004                                           // 0000000D3628: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000D362C: 020278FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000D3634: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000D3638: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000000D363C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 0000000D3644: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000D364C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000D3650: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x900>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000D3654: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D3658: BF89FC07
	s_barrier                                                  // 0000000D365C: BFBD0000
	buffer_gl0_inv                                             // 0000000D3660: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000D3668: BE8D2000
	s_cbranch_execz 65473                                      // 0000000D366C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x874>
	v_or_b32_e32 v33, s12, v2                                  // 0000000D3670: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D3674: BF870091
	v_or_b32_e32 v36, s11, v33                                 // 0000000D3678: 3848420B
	.long 0xd4440001                                           // 0000000D367C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 0000000D3680: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000D3684: 8B7E017E
	s_cbranch_execz 65466                                      // 0000000D3688: BFA5FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x874>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 0000000D368C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000D3694: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 0000000D369C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 0000000D36A4: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 0000000D36AC: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 0000000D36B4: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 0000000D36BC: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 0000000D36C4: D8DC7766 4A000001
	s_mov_b32 s14, 0                                           // 0000000D36CC: BE8E0080
	s_waitcnt lgkmcnt(6)                                       // 0000000D36D0: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 0000000D36D4: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D36DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D36E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D36E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D36E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D36EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D36F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D36F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D36F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D36FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3700: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3704: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3708: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D370C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3710: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:8 offset1:9        // 0000000D3714: D8DC0908 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 0000000D371C: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 0000000D3724: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 0000000D372C: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:12 offset1:13      // 0000000D3734: D8DC0D0C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 0000000D373C: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 0000000D3744: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 0000000D374C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 0000000D3754: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D3758: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D375C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D3760: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D3764: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D3768: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D376C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D3770: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D3774: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D3778: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D377C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3780: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3784: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3788: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D378C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3790: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 0000000D3794: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 0000000D379C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 0000000D37A4: D8DC1312 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000D37AC: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:20 offset1:21      // 0000000D37B4: D8DC1514 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 0000000D37BC: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 0000000D37C4: D8DC6554 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000D37CC: D8DC8776 4A000030
	s_waitcnt lgkmcnt(6)                                       // 0000000D37D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D37D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D37DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D37E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D37E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D37E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D37EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D37F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D37F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D37F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D37FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3800: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3804: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3808: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D380C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3810: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 0000000D3814: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 0000000D381C: D8DCA998 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 0000000D3824: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 0000000D382C: D8DCCBBA 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:28 offset1:29      // 0000000D3834: D8DC1D1C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000D383C: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 0000000D3844: D8DCEDDC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:126 offset1:143    // 0000000D384C: D8DC8F7E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 0000000D3854: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D3858: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D385C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D3860: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D3864: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D3868: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D386C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D3870: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D3874: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D3878: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D387C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3880: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3884: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3888: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D388C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3890: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 0000000D3894: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 0000000D389C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 0000000D38A4: D8DC2322 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:66 offset1:83      // 0000000D38AC: D8DC5342 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:36 offset1:37      // 0000000D38B4: D8DC2524 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 0000000D38BC: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000D38C4: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000D38CC: D8DC9786 4A000032
	s_waitcnt lgkmcnt(6)                                       // 0000000D38D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D38D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D38DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D38E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D38E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D38E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D38EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D38F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D38F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D38F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D38FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3900: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3904: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3908: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D390C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3910: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:40 offset1:41      // 0000000D3914: D8DC2928 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:168 offset1:185    // 0000000D391C: D8DCB9A8 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 0000000D3924: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:202 offset1:219    // 0000000D392C: D8DCDBCA 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:44 offset1:45      // 0000000D3934: D8DC2D2C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 0000000D393C: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 0000000D3944: D8DCFDEC 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:14 offset1:31      // 0000000D394C: D8DC1F0E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000D3954: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D3958: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D395C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D3960: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D3964: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D3968: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D396C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D3970: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D3974: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D3978: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D397C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3980: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3984: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3988: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D398C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3990: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 0000000D3994: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 0000000D399C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 0000000D39A4: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 0000000D39AC: D8DC6352 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:52 offset1:53      // 0000000D39B4: D8DC3534 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 0000000D39BC: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000D39C4: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000D39CC: D8DCA796 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000D39D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D39D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D39DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D39E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D39E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D39E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D39EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D39F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D39F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D39F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D39FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3A00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3A04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3A08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D3A0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3A10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:56 offset1:57      // 0000000D3A14: D8DC3938 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:184 offset1:201    // 0000000D3A1C: D8DCC9B8 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 0000000D3A24: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:218 offset1:235    // 0000000D3A2C: D8DCEBDA 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:60 offset1:61      // 0000000D3A34: D8DC3D3C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 0000000D3A3C: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 0000000D3A44: D8DC8D7C 48000034
	ds_load_2addr_b32 v[74:75], v53 offset0:30 offset1:47      // 0000000D3A4C: D8DC2F1E 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000D3A54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D3A58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3A5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D3A60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D3A64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D3A68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3A6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D3A70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D3A74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D3A78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3A7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3A80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3A84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3A88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D3A8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3A90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 0000000D3A94: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 0000000D3A9C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 0000000D3AA4: D8DC4342 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:98 offset1:115     // 0000000D3AAC: D8DC7362 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:68 offset1:69      // 0000000D3AB4: D8DC4544 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 0000000D3ABC: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000D3AC4: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000D3ACC: D8DCB7A6 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000D3AD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D3AD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3ADC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D3AE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D3AE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D3AE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3AEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D3AF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D3AF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D3AF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3AFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3B00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3B04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3B08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D3B0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3B10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 0000000D3B14: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 0000000D3B1C: D8DCD9C8 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 0000000D3B24: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 0000000D3B2C: D8DCFBEA 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:76 offset1:77      // 0000000D3B34: D8DC4D4C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 0000000D3B3C: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 0000000D3B44: D8DC1D0C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:46 offset1:63      // 0000000D3B4C: D8DC3F2E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000D3B54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D3B58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3B5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D3B60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D3B64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D3B68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3B6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D3B70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D3B74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D3B78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3B7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3B80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3B84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3B88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D3B8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3B90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 0000000D3B94: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 0000000D3B9C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 0000000D3BA4: D8DC5352 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:114 offset1:131    // 0000000D3BAC: D8DC8372 42000036
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:85      // 0000000D3BB4: D8DC5554 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 0000000D3BBC: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000D3BC4: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000D3BCC: D8DCC7B6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000D3BD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D3BD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3BDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D3BE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D3BE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D3BE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3BEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D3BF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D3BF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D3BF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3BFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3C00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3C04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3C08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D3C0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3C10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:88 offset1:89      // 0000000D3C14: D8DC5958 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:216 offset1:233    // 0000000D3C1C: D8DCE9D8 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:90 offset1:91      // 0000000D3C24: D8DC5B5A 4000002E
	ds_load_2addr_b32 v[66:67], v55 offset0:122 offset1:139    // 0000000D3C2C: D8DC8B7A 42000037
	ds_load_2addr_b32 v[68:69], v46 offset0:92 offset1:93      // 0000000D3C34: D8DC5D5C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 0000000D3C3C: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 0000000D3C44: D8DC2D1C 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:62 offset1:79      // 0000000D3C4C: D8DC4F3E 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000D3C54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D3C58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3C5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D3C60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D3C64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D3C68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3C6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D3C70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D3C74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D3C78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3C7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3C80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3C84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3C88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D3C8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3C90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 0000000D3C94: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 0000000D3C9C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 0000000D3CA4: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 0000000D3CAC: D8DC9382 42000038
	ds_load_2addr_b32 v[68:69], v46 offset0:100 offset1:101    // 0000000D3CB4: D8DC6564 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 0000000D3CBC: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000D3CC4: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000D3CCC: D8DCD7C6 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000D3CD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D3CD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3CDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D3CE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D3CE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D3CE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3CEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D3CF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D3CF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D3CF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3CFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3D00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3D04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3D08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D3D0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3D10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:104 offset1:105    // 0000000D3D14: D8DC6968 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:232 offset1:249    // 0000000D3D1C: D8DCF9E8 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 0000000D3D24: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:10 offset1:27      // 0000000D3D2C: D8DC1B0A 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:108 offset1:109    // 0000000D3D34: D8DC6D6C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 0000000D3D3C: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 0000000D3D44: D8DC3D2C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:78 offset1:95      // 0000000D3D4C: D8DC5F4E 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000D3D54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D3D58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3D5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D3D60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D3D64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D3D68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3D6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D3D70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D3D74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D3D78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3D7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3D80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3D84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3D88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D3D8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3D90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 0000000D3D94: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 0000000D3D9C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 0000000D3DA4: D8DC7372 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:146 offset1:163    // 0000000D3DAC: D8DCA392 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:116 offset1:117    // 0000000D3DB4: D8DC7574 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 0000000D3DBC: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000D3DC4: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000D3DCC: D8DCE7D6 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000D3DD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D3DD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3DDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D3DE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000D3DE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D3DE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3DEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D3DF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000D3DF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D3DF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D3DFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3E00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000D3E04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3E08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D3E0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3E10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 0000000D3E14: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 0000000D3E1C: D8DC8978 3E00003A
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 0000000D3E24: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:26 offset1:43      // 0000000D3E2C: D8DC2B1A 4200003B
	ds_load_2addr_b32 v[68:69], v46 offset0:124 offset1:125    // 0000000D3E34: D8DC7D7C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 0000000D3E3C: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 0000000D3E44: D8DC4D3C 4800003B
	ds_load_2addr_b32 v[74:75], v59 offset0:94 offset1:111     // 0000000D3E4C: D8DC6F5E 4A00003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000D3E54: 30424282
	s_waitcnt lgkmcnt(6)                                       // 0000000D3E58: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000D3E5C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 0000000D3E60: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000D3E68: CA10011E 2220011D
	v_mov_b32_e32 v62, v35                                     // 0000000D3E70: 7E7C0323
	v_fmac_f32_e32 v76, v61, v63                               // 0000000D3E74: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 0000000D3E78: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 0000000D3E7C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D3E80: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 0000000D3E84: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 0000000D3E88: 56988741
	s_waitcnt lgkmcnt(2)                                       // 0000000D3E8C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D3E90: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 0000000D3E94: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 0000000D3E98: 56989345
	s_waitcnt lgkmcnt(1)                                       // 0000000D3E9C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D3EA0: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 0000000D3EA4: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 0000000D3EA8: 56989747
	s_waitcnt lgkmcnt(0)                                       // 0000000D3EAC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D3EB0: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 0000000D3EB4: 1078794C
	s_nop 0                                                    // 0000000D3EB8: BF800000
	s_nop 0                                                    // 0000000D3EBC: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000D3EC0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000D3EC8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000D3ED0: 4A7C7CC1
	.long 0xd7000121                                           // 0000000D3ED4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000D3ED8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D3EDC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000D3EE0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000D3EE8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000D3EEC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000D3EF0: 4A7A7AFF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000D3EF8: 8C0E0E04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D3EFC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 0000000D3F00: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000D3F04: 917E0E7E
	s_cbranch_execnz 65517                                     // 0000000D3F08: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11c0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000D3F0C: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D3F10: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 0000000D3F14: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 0000000D3F1C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 0000000D3F28: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 0000000D3F34: DC960000 007C2421
	s_branch 64909                                             // 0000000D3F3C: BFA0FD8D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x874>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000D3F40: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 0000000D3F48: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000D3F4C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000D3F50: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000D3F58: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000D3F5C: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000D3F64: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000D3F6C: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000D3F70: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000D3F74: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000D3F7C: A0010401
	s_mov_b32 s4, 0                                            // 0000000D3F80: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000D3F84: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000D3F88: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000D3F8C: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000D3F90: BF870585
	.long 0xd71c001d                                           // 0000000D3F94: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000D3F98: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000D3F9C: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000D3FA0: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000D3FA8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000D3FAC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000D3FB4: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000000D3FB8: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000D3FBC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000D3FC8: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000D3FD0: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D3FD8: BF870001
	.long 0xd4490001                                           // 0000000D3FDC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000D3FE0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000D3FE8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000D3FEC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000D3FF0: 1040411E
	ds_store_b32 v29, v32                                      // 0000000D3FF4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000D3FFC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D4004: 917E047E
	s_cbranch_execnz 65519                                     // 0000000D4008: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x12c8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D400C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000D4010: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 0000000D4018: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 0000000D4020: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D4024: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D4028: BF89FC07
	s_barrier                                                  // 0000000D402C: BFBD0000
	buffer_gl0_inv                                             // 0000000D4030: E0AC0000 00000000
	s_nop 0                                                    // 0000000D4038: BF800000
	s_nop 0                                                    // 0000000D403C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D4040: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 0000000D4048: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D4050: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D4058: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D405C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000D4064: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D4068: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D4070: BF870004
	.long 0xd4490004                                           // 0000000D4074: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D4078: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D4080: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D4084: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D4088: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 0000000D408C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000D4094: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D409C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D40A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1340>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D40A4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D40A8: BF89FC07
	s_barrier                                                  // 0000000D40AC: BFBD0000
	buffer_gl0_inv                                             // 0000000D40B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000D40B8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000000D40C0: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000000D40C8: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000000D40D0: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000D40D8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000D40DC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D40E0: BF840001
	s_nop 0                                                    // 0000000D40E4: BF800000
	s_nop 0                                                    // 0000000D40E8: BF800000
	s_nop 0                                                    // 0000000D40EC: BF800000
	s_nop 0                                                    // 0000000D40F0: BF800000
	s_nop 0                                                    // 0000000D40F4: BF800000
	s_nop 0                                                    // 0000000D40F8: BF800000
	s_nop 0                                                    // 0000000D40FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D4100: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000D4104: 327A7884
	.long 0xd4490001                                           // 0000000D4108: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000D410C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000D4114: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000D4118: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D4124: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000D4128: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000D4130: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000D4138: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000D4140: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000D4148: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000D4150: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000D4158: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000D4160: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000D4164: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D4170: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000D4174: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000D4178: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000D4180: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000D4184: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000D4188: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000D418C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D4190: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000D4194: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000D4198: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000D419C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D41A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000D41A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000D41B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000D41B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D41C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000D41C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1400>
	s_set_inst_prefetch_distance 0x2                           // 0000000D41C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D41CC: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000000D41D0: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000D41D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000D41E0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D41E4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D41E8: BF89FC07
	s_barrier                                                  // 0000000D41EC: BFBD0000
	buffer_gl0_inv                                             // 0000000D41F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000D41F8: BF800000
	s_nop 0                                                    // 0000000D41FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D4200: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 0000000D4208: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D4210: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D4218: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D421C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D4224: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D4228: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D4230: BF870004
	.long 0xd4490004                                           // 0000000D4234: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D4238: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D4240: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D4244: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D4248: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000D424C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D4254: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D425C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D4260: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1500>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D4264: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D4268: BF89FC07
	s_barrier                                                  // 0000000D426C: BFBD0000
	buffer_gl0_inv                                             // 0000000D4270: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000D4278: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000000D4280: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000000D4288: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000000D4290: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000D4298: 7E780300
	s_mov_b32 s4, 0                                            // 0000000D429C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D42A0: BF840001
	s_nop 0                                                    // 0000000D42A4: BF800000
	s_nop 0                                                    // 0000000D42A8: BF800000
	s_nop 0                                                    // 0000000D42AC: BF800000
	s_nop 0                                                    // 0000000D42B0: BF800000
	s_nop 0                                                    // 0000000D42B4: BF800000
	s_nop 0                                                    // 0000000D42B8: BF800000
	s_nop 0                                                    // 0000000D42BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D42C0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000D42C4: 327A7884
	.long 0xd4490001                                           // 0000000D42C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000D42CC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000D42D4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000D42D8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D42E4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000D42E8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000D42F0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000D42F8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000D4300: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000D4308: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000D4310: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000D4318: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000D4320: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000D4324: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D4330: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000D4334: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000D4338: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000D4340: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000D4344: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000D4348: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000D434C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D4350: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000D4354: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000D4358: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000D435C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D4360: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000D4364: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000D4370: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000D4378: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D4380: 917E047E
	s_cbranch_execnz 65486                                     // 0000000D4384: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000D4388: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D438C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000000D4390: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000D4398: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000D43A0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D43A4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D43A8: BF89FC07
	s_barrier                                                  // 0000000D43AC: BFBD0000
	buffer_gl0_inv                                             // 0000000D43B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000D43B8: BF800000
	s_nop 0                                                    // 0000000D43BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D43C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000000D43C8: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D43D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D43D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D43DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D43E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D43E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D43F0: BF870004
	.long 0xd4490004                                           // 0000000D43F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D43F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D4400: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D4404: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D4408: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000D440C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D4414: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D441C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D4420: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D4424: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000D4428: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000D4430: BF89FC07
	s_barrier                                                  // 0000000D4434: BFBD0000
	buffer_gl0_inv                                             // 0000000D4438: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000D4440: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 0000000D4444: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 0000000D444C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 0000000D4454: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 0000000D445C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000D4464: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D4468: BF840001
	s_nop 0                                                    // 0000000D446C: BF800000
	s_nop 0                                                    // 0000000D4470: BF800000
	s_nop 0                                                    // 0000000D4474: BF800000
	s_nop 0                                                    // 0000000D4478: BF800000
	s_nop 0                                                    // 0000000D447C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000D4480: 327C7A84
	.long 0xd4490001                                           // 0000000D4484: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000D4488: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D4490: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000D4494: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000D4498: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D44A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000D44A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000D44B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000D44B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000D44C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000D44C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000D44D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000D44D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000D44E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000D44E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D44E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000D44EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000D44F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000D4500: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000D4504: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000D4508: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000D450C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D4510: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000D4514: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000D4518: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000D451C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D4520: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000D4524: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000D4530: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000D4538: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D4540: 917E047E
	s_cbranch_execnz 65486                                     // 0000000D4544: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1780>
	s_set_inst_prefetch_distance 0x2                           // 0000000D4548: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D454C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000D4550: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000D4558: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000D4560: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D4564: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D4568: BF89FC07
	s_barrier                                                  // 0000000D456C: BFBD0000
	buffer_gl0_inv                                             // 0000000D4570: E0AC0000 00000000
	s_nop 0                                                    // 0000000D4578: BF800000
	s_nop 0                                                    // 0000000D457C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D4580: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000000D4588: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D4590: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D4598: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D459C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D45A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D45A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D45B0: BF870004
	.long 0xd4490004                                           // 0000000D45B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D45B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D45C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D45C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D45C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000D45CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D45D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D45DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D45E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1880>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D45E4: 8C7E0A7E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000D45E8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000D45F0: BF89FC07
	s_barrier                                                  // 0000000D45F4: BFBD0000
	buffer_gl0_inv                                             // 0000000D45F8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 0000000D4600: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 0000000D4608: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 0000000D4610: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 0000000D4618: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000D4620: 7E780300
	s_mov_b32 s4, 0                                            // 0000000D4624: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D4628: BF840001
	s_nop 0                                                    // 0000000D462C: BF800000
	s_nop 0                                                    // 0000000D4630: BF800000
	s_nop 0                                                    // 0000000D4634: BF800000
	s_nop 0                                                    // 0000000D4638: BF800000
	s_nop 0                                                    // 0000000D463C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D4640: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000D4644: 327A7884
	.long 0xd4490001                                           // 0000000D4648: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000D464C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000D4654: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000D4658: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D4664: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000D4668: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000D4670: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000D4678: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000D4680: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000D4688: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000D4690: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000D4698: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000D46A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000D46A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D46B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000D46B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000D46B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000D46C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000D46C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000D46C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000D46CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D46D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000D46D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000D46D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000D46DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D46E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000D46E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000D46F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000D46F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D4700: 917E047E
	s_cbranch_execnz 65486                                     // 0000000D4704: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_set_inst_prefetch_distance 0x2                           // 0000000D4708: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D470C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 0000000D4710: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000D4718: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000D4720: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D4724: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D4728: BF89FC07
	s_barrier                                                  // 0000000D472C: BFBD0000
	buffer_gl0_inv                                             // 0000000D4730: E0AC0000 00000000
	s_nop 0                                                    // 0000000D4738: BF800000
	s_nop 0                                                    // 0000000D473C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D4740: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 0000000D4748: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D4750: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D4758: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D475C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D4764: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D4768: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D4770: BF870004
	.long 0xd4490004                                           // 0000000D4774: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D4778: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D4780: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D4784: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D4788: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000D478C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D4794: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D479C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D47A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D47A4: 8C7E0A7E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000000D47A8: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000D47B0: BF89FC07
	s_barrier                                                  // 0000000D47B4: BFBD0000
	buffer_gl0_inv                                             // 0000000D47B8: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000000D47C0: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000000D47C4: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000000D47CC: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000000D47D4: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000000D47DC: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000D47E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D47E8: BF840001
	s_nop 0                                                    // 0000000D47EC: BF800000
	s_nop 0                                                    // 0000000D47F0: BF800000
	s_nop 0                                                    // 0000000D47F4: BF800000
	s_nop 0                                                    // 0000000D47F8: BF800000
	s_nop 0                                                    // 0000000D47FC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 0000000D4800: 327C7884
	.long 0xd4490001                                           // 0000000D4804: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000D4808: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D4810: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000D4814: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000D4818: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D4824: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000D4828: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000D4830: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000D4838: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000D4840: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000D4848: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000D4850: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000D4858: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000D4860: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000D4864: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D4868: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000D486C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000D4878: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000D4880: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000D4884: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000D4888: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000D488C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D4890: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000D4894: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000D4898: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000D489C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D48A0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000000D48A4: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 0000000D48B0: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D48B4: BF870002
	v_mov_b32_e32 v60, v63                                     // 0000000D48B8: 7E78033F
	ds_store_b32 v62, v70                                      // 0000000D48BC: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D48C4: 917E047E
	s_cbranch_execnz 65485                                     // 0000000D48C8: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_set_inst_prefetch_distance 0x2                           // 0000000D48CC: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D48D0: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000000D48D4: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000D48DC: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000D48E4: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D48E8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D48EC: BF89FC07
	s_barrier                                                  // 0000000D48F0: BFBD0000
	buffer_gl0_inv                                             // 0000000D48F4: E0AC0000 00000000
	s_nop 0                                                    // 0000000D48FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D4900: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 0000000D4908: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D4910: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D4918: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D491C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D4924: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D4928: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D4930: BF870004
	.long 0xd4490004                                           // 0000000D4934: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D4938: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D4940: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D4944: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D4948: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000D494C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D4954: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D495C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D4960: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D4964: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000000D4968: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000D4970: BF89FC07
	s_barrier                                                  // 0000000D4974: BFBD0000
	buffer_gl0_inv                                             // 0000000D4978: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000000D4980: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000000D4988: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000000D4990: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000000D4998: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000D49A0: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000D49A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D49A8: BF840001
	s_nop 0                                                    // 0000000D49AC: BF800000
	s_nop 0                                                    // 0000000D49B0: BF800000
	s_nop 0                                                    // 0000000D49B4: BF800000
	s_nop 0                                                    // 0000000D49B8: BF800000
	s_nop 0                                                    // 0000000D49BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D49C0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000D49C4: 327C7A84
	.long 0xd4490001                                           // 0000000D49C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000D49CC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000D49D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000D49D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D49E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000D49E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000D49F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000D49F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000D4A00: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000D4A08: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000D4A10: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000D4A18: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000D4A20: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000D4A24: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D4A28: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000D4A2C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000D4A38: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000D4A40: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000D4A44: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000D4A48: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000D4A4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D4A50: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000D4A54: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000D4A58: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000D4A5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D4A60: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000D4A64: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000D4A70: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000D4A78: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D4A80: 917E047E
	s_cbranch_execnz 65486                                     // 0000000D4A84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_set_inst_prefetch_distance 0x2                           // 0000000D4A88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D4A8C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 0000000D4A90: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000D4A98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000D4AA0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D4AA4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D4AA8: BF89FC07
	s_barrier                                                  // 0000000D4AAC: BFBD0000
	buffer_gl0_inv                                             // 0000000D4AB0: E0AC0000 00000000
	s_nop 0                                                    // 0000000D4AB8: BF800000
	s_nop 0                                                    // 0000000D4ABC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D4AC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000D4AC8: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D4AD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D4AD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D4ADC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D4AE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D4AE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D4AF0: BF870004
	.long 0xd4490004                                           // 0000000D4AF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D4AF8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D4B00: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D4B04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D4B08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000D4B0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D4B14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D4B1C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D4B20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D4B24: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D4B28: BF89FC07
	s_barrier                                                  // 0000000D4B2C: BFBD0000
	buffer_gl0_inv                                             // 0000000D4B30: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 0000000D4B38: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 0000000D4B40: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 0000000D4B48: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 0000000D4B50: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000D4B58: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000D4B5C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D4B60: BF840001
	s_nop 0                                                    // 0000000D4B64: BF800000
	s_nop 0                                                    // 0000000D4B68: BF800000
	s_nop 0                                                    // 0000000D4B6C: BF800000
	s_nop 0                                                    // 0000000D4B70: BF800000
	s_nop 0                                                    // 0000000D4B74: BF800000
	s_nop 0                                                    // 0000000D4B78: BF800000
	s_nop 0                                                    // 0000000D4B7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D4B80: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000D4B84: 327C7A84
	.long 0xd4490001                                           // 0000000D4B88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000D4B8C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000D4B94: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000D4B98: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D4BA4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000D4BA8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000D4BB0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000D4BB8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000D4BC0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000D4BC8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000D4BD0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000D4BD8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000D4BE0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000D4BE4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D4BE8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000D4BEC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000D4BF8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000D4C00: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000D4C04: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000D4C08: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000D4C0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D4C10: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000D4C14: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000D4C18: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000D4C1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D4C20: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000D4C24: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000D4C30: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000D4C38: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D4C40: 917E047E
	s_cbranch_execnz 65486                                     // 0000000D4C44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e80>
	s_set_inst_prefetch_distance 0x2                           // 0000000D4C48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D4C4C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000D4C50: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000D4C58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000D4C60: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D4C64: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D4C68: BF89FC07
	s_barrier                                                  // 0000000D4C6C: BFBD0000
	buffer_gl0_inv                                             // 0000000D4C70: E0AC0000 00000000
	s_nop 0                                                    // 0000000D4C78: BF800000
	s_nop 0                                                    // 0000000D4C7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D4C80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000000D4C88: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D4C90: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D4C98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D4C9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D4CA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D4CA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D4CB0: BF870004
	.long 0xd4490004                                           // 0000000D4CB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D4CB8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D4CC0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D4CC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D4CC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000D4CCC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D4CD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D4CDC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D4CE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D4CE4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000D4CE8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000D4CF0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000D4CF8: BF89FC07
	s_barrier                                                  // 0000000D4CFC: BFBD0000
	buffer_gl0_inv                                             // 0000000D4D00: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 0000000D4D08: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 0000000D4D10: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000D4D18: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 0000000D4D20: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000D4D28: 7E780300
	s_mov_b32 s4, 0                                            // 0000000D4D2C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D4D30: BF840001
	s_nop 0                                                    // 0000000D4D34: BF800000
	s_nop 0                                                    // 0000000D4D38: BF800000
	s_nop 0                                                    // 0000000D4D3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D4D40: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000D4D44: 327A7884
	.long 0xd4490001                                           // 0000000D4D48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000D4D4C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000D4D54: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000D4D58: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D4D64: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000D4D68: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000D4D70: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000D4D78: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000D4D80: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000D4D88: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000D4D90: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000D4D98: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000D4DA0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000D4DA4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D4DB0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000D4DB4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000D4DB8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000D4DC0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000D4DC4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000D4DC8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000D4DCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D4DD0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000D4DD4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000D4DD8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000D4DDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D4DE0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000D4DE4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000D4DF0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000D4DF8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D4E00: 917E047E
	s_cbranch_execnz 65486                                     // 0000000D4E04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_set_inst_prefetch_distance 0x2                           // 0000000D4E08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D4E0C: 8C7E047E
	.long 0xd7000107                                           // 0000000D4E10: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000D4E14: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D4E1C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000D4E20: D5207C08 00061080
	.long 0xd7000109                                           // 0000000D4E28: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000D4E2C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000D4E34: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000D4E3C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000D4E40: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D4E48: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000D4E4C: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000D4E54: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000D4E58: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000D4E60: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000D4E68: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000D4E6C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D4E74: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000D4E78: D5207C10 00062080
	.long 0xd7000111                                           // 0000000D4E80: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000D4E84: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000D4E8C: D5207C12 00062480
	.long 0xd7000113                                           // 0000000D4E94: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000D4E98: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D4EA0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000D4EA4: D5207C14 00062880
	.long 0xd7000115                                           // 0000000D4EAC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000D4EB0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000D4EB8: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000D4EC0: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000D4EC4: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D4ECC: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000D4ED0: D5207C18 00063080
	.long 0xd7000119                                           // 0000000D4ED8: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000D4EDC: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000D4EE4: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000D4EEC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000D4EF0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D4EF8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000D4EFC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000D4F04: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000D4F08: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000D4F0C: BF062105
	s_barrier                                                  // 0000000D4F10: BFBD0000
	buffer_gl0_inv                                             // 0000000D4F14: E0AC0000 00000000
	s_cbranch_scc0 63589                                       // 0000000D4F1C: BFA1F865 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b4>
	v_mov_b32_e32 v4, v38                                      // 0000000D4F20: 7E080326
	s_add_u32 s0, s28, s20                                     // 0000000D4F24: 8000141C
	.long 0xd73c0000                                           // 0000000D4F28: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000D4F2C: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000D4F30: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000D4F34: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000D4F38: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000D4F3C: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000D4F40: 82010103
	.long 0xd7006a00                                           // 0000000D4F44: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000D4F48: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000D4F4C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000D4F50: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000D4F58: BE810080
	.long 0xd7006a00                                           // 0000000D4F5C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 0000000D4F60: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000D4F64: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D4F6C: BF870092
	.long 0xd7006a00                                           // 0000000D4F70: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000D4F74: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000D4F78: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 0000000D4F80: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000D4F88: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000000D4F90: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000D4F98: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000D4F9C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000D4FA4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000D4FA8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000D4FAC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000D4FB4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000D4FB8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000D4FC0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000D4FC8: 917E017E
	s_cbranch_execnz 65516                                     // 0000000D4FCC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2280>
	s_endpgm                                                   // 0000000D4FD0: BFB00000
		...

