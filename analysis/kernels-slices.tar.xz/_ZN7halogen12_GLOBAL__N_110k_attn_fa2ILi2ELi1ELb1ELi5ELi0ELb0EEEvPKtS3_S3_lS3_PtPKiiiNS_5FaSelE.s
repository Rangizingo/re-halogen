000000000011aa00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 00000011AA00: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 00000011AA04: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 00000011AA0C: F4080500 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 00000011AA14: 3706009F
	v_lshrrev_b32_e32 v155, 5, v0                              // 00000011AA18: 33360085
	s_mov_b32 s24, s3                                          // 00000011AA1C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011AA20: BF870112
	.long 0xd44c0003                                           // 00000011AA24: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 00000011AA28: 02030690
	v_lshlrev_b32_e32 v132, 6, v155                            // 00000011AA2C: 31093686
	s_waitcnt lgkmcnt(0)                                       // 00000011AA30: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 00000011AA34: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 00000011AA3C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011AA40: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 00000011AA44: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 00000011AA4C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:231 offset1:243// 00000011AA58: D83CF3E7 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 00000011AA60: 8C7E047E
	v_mul_u32_u24_e32 v1, 0x2ab, v0                            // 00000011AA64: 160200FF 000002AB
	s_lshl_b32 s25, s2, 5                                      // 00000011AA6C: 84198502
	v_dual_mov_b32 v141, 0 :: v_dual_and_b32 v154, 15, v0      // 00000011AA70: CA240080 8D9A008F
	s_cmp_eq_u64 s[14:15], 0                                   // 00000011AA78: BF10800E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000011AA7C: BF8704C2
	.long 0xd7381001                                           // 00000011AA80: D7381001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000011AA84: 02020282
	.long 0x7f023880                                           // 00000011AA88: 7F023880
	v_mov_b32_e32 v142, 0                                      // 00000011AA8C: 7F1C0280
	s_cselect_b32 s27, -1, 0                                   // 00000011AA90: 981B80C1
	s_and_b32 vcc_lo, exec_lo, s27                             // 00000011AA94: 8B6A1B7E
	.long 0xd7620001                                           // 00000011AA98: D7620001
	v_cndmask_b32_e32 v0, v1, v176, vcc_lo                     // 00000011AA9C: 02016101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011AAA0: BF870091
	v_add_nc_u32_e32 v156, s25, v1                             // 00000011AAA4: 4B380219
	v_or_b32_e32 v129, v156, v154                              // 00000011AAA8: 3903359C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011AAAC: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 00000011AAB0: 3505029F
	s_cbranch_vccnz 10                                         // 00000011AAB4: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xe0>
	v_mad_i64_i32 v[1:2], null, s23, v129, 0                   // 00000011AAB8: D6FF7C01 02030217
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011AAC0: BF870091
	.long 0xd73c0001                                           // 00000011AAC4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000011AAC8: 02020282
	.long 0xd7006a8d                                           // 00000011AACC: D7006A8D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000011AAD0: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011AAD4: BF870001
	v_add_co_ci_u32_e64 v142, null, s15, v2, vcc_lo            // 00000011AAD8: D5207C8E 01AA040F
	s_clause 0x2                                               // 00000011AAE0: BF850002
	s_load_b64 s[14:15], s[0:1], 0x38                          // 00000011AAE4: F4040380 F8000038
	s_load_b128 s[16:19], s[0:1], 0x20                         // 00000011AAEC: F4080400 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 00000011AAF4: F40C0100 F8000000
	v_mov_b32_e32 v158, 0                                      // 00000011AAFC: 7F3C0280
	s_xor_b32 s0, s27, -1                                      // 00000011AB00: 8D00C11B
	s_waitcnt lgkmcnt(0)                                       // 00000011AB04: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v129                         // 00000011AB08: 7C89020E
	s_and_b32 s23, s0, vcc_lo                                  // 00000011AB0C: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011AB10: BF870009
	s_and_saveexec_b32 s0, s23                                 // 00000011AB14: BE802017
	s_cbranch_execz 9                                          // 00000011AB18: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x140>
	.long 0xd73c0001                                           // 00000011AB1C: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 00000011AB20: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011AB24: BF870091
	.long 0xd7006a01                                           // 00000011AB28: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 00000011AB2C: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 00000011AB30: D5207C02 01AA0415
	global_load_b32 v158, v[1:2], off                          // 00000011AB38: DC520000 9E7C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 00000011AB40: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 00000011AB44: BF10800C
	s_mov_b64 s[20:21], 0                                      // 00000011AB48: BE940180
	s_cbranch_scc1 10                                          // 00000011AB4C: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x178>
	s_ashr_i32 s0, s22, 31                                     // 00000011AB50: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 00000011AB54: 96810216
	s_mul_i32 s0, s0, s2                                       // 00000011AB58: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000011AB5C: BF8704A9
	s_add_i32 s1, s1, s0                                       // 00000011AB60: 81010001
	s_mul_i32 s0, s22, s2                                      // 00000011AB64: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000011AB68: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011AB6C: BF870009
	s_add_u32 s20, s12, s0                                     // 00000011AB70: 8014000C
	s_addc_u32 s21, s13, s1                                    // 00000011AB74: 8215010D
	.long 0xd7050001                                           // 00000011AB78: D7050001
	v_cndmask_b32_e32 v0, v155, v150, vcc_lo                   // 00000011AB7C: 02012D9B
	s_or_b32 s25, s25, 31                                      // 00000011AB80: 8C199F19
	s_add_i32 s0, s14, -1                                      // 00000011AB84: 8100C10E
	v_lshrrev_b32_e32 v157, 4, v131                            // 00000011AB88: 333B0684
	s_min_i32 s0, s25, s0                                      // 00000011AB8C: 89000019
	.long 0xd7390001                                           // 00000011AB90: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 00000011AB94: 02020288
	s_add_i32 s0, s26, s0                                      // 00000011AB98: 8100001A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011AB9C: BF870099
	s_cmp_lt_i32 s0, -15                                       // 00000011ABA0: BF04CF00
	.long 0xd7050001                                           // 00000011ABA4: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 00000011ABA8: 02011901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011ABAC: BF870091
	.long 0xd7040001                                           // 00000011ABB0: D7040001
	v_cndmask_b32_e32 v1, v155, v1, vcc_lo                     // 00000011ABB4: 0202039B
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 00000011ABB8: CA240080 480002FF 000000FF
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011ABC4: BF870001
	v_mov_b32_e32 v71, v72                                     // 00000011ABC8: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 00000011ABCC: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 00000011ABD0: 7E880348
	v_mov_b32_e32 v67, v72                                     // 00000011ABD4: 7E860348
	v_mad_u64_u32 v[138:139], null, s24, 12, v[1:2]            // 00000011ABD8: D6FE7C8A 04051818
	v_mov_b32_e32 v70, v72                                     // 00000011ABE0: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 00000011ABE4: 7E840348
	v_mov_b32_e32 v65, v72                                     // 00000011ABE8: 7E820348
	v_mov_b32_e32 v80, v72                                     // 00000011ABEC: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 00000011ABF0: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 00000011ABF4: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 00000011ABF8: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 00000011ABFC: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 00000011AC04: 7E960348
	v_mov_b32_e32 v74, v72                                     // 00000011AC08: 7E940348
	v_mov_b32_e32 v73, v72                                     // 00000011AC0C: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 00000011AC10: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000011AC14: 3404029F
	v_mov_b32_e32 v88, v72                                     // 00000011AC18: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 00000011AC1C: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 00000011AC20: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 00000011AC24: 7EAA0348
	.long 0xd73c008b                                           // 00000011AC28: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000011AC2C: 02020281
	v_mov_b32_e32 v84, v72                                     // 00000011AC30: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 00000011AC34: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 00000011AC38: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 00000011AC3C: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 00000011AC40: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 00000011AC44: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 00000011AC48: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 00000011AC4C: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 00000011AC50: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 00000011AC54: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 00000011AC58: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 00000011AC5C: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 00000011AC60: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 00000011AC64: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 00000011AC68: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 00000011AC6C: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 00000011AC70: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 00000011AC74: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 00000011AC78: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 00000011AC7C: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 00000011AC80: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 00000011AC84: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 00000011AC88: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 00000011AC8C: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 00000011AC90: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 00000011AC94: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 00000011AC98: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 00000011AC9C: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 00000011ACA0: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 00000011ACA4: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 00000011ACA8: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 00000011ACAC: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 00000011ACB0: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 00000011ACB4: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 00000011ACB8: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 00000011ACBC: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 00000011ACC0: 7F000348
	v_mov_b32_e32 v127, v72                                    // 00000011ACC4: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 00000011ACC8: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 00000011ACCC: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 00000011ACD0: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 00000011ACD4: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 00000011ACD8: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 00000011ACDC: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 00000011ACE0: 7E800348
	v_mov_b32_e32 v63, v72                                     // 00000011ACE4: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 00000011ACE8: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 00000011ACEC: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 00000011ACF0: 7E780348
	v_mov_b32_e32 v59, v72                                     // 00000011ACF4: 7E760348
	v_mov_b32_e32 v58, v72                                     // 00000011ACF8: 7E740348
	v_mov_b32_e32 v57, v72                                     // 00000011ACFC: 7E720348
	v_mov_b32_e32 v56, v72                                     // 00000011AD00: 7E700348
	v_mov_b32_e32 v55, v72                                     // 00000011AD04: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 00000011AD08: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 00000011AD0C: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 00000011AD10: 7E680348
	v_mov_b32_e32 v51, v72                                     // 00000011AD14: 7E660348
	v_mov_b32_e32 v50, v72                                     // 00000011AD18: 7E640348
	v_mov_b32_e32 v49, v72                                     // 00000011AD1C: 7E620348
	v_mov_b32_e32 v48, v72                                     // 00000011AD20: 7E600348
	v_mov_b32_e32 v47, v72                                     // 00000011AD24: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 00000011AD28: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 00000011AD2C: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 00000011AD30: 7E580348
	v_mov_b32_e32 v43, v72                                     // 00000011AD34: 7E560348
	v_mov_b32_e32 v42, v72                                     // 00000011AD38: 7E540348
	v_mov_b32_e32 v41, v72                                     // 00000011AD3C: 7E520348
	v_mov_b32_e32 v40, v72                                     // 00000011AD40: 7E500348
	v_mov_b32_e32 v39, v72                                     // 00000011AD44: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 00000011AD48: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 00000011AD4C: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 00000011AD50: 7E480348
	v_mov_b32_e32 v35, v72                                     // 00000011AD54: 7E460348
	v_mov_b32_e32 v34, v72                                     // 00000011AD58: 7E440348
	v_mov_b32_e32 v33, v72                                     // 00000011AD5C: 7E420348
	v_mov_b32_e32 v32, v72                                     // 00000011AD60: 7E400348
	v_mov_b32_e32 v31, v72                                     // 00000011AD64: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 00000011AD68: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 00000011AD6C: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 00000011AD70: 7E380348
	v_mov_b32_e32 v27, v72                                     // 00000011AD74: 7E360348
	v_mov_b32_e32 v26, v72                                     // 00000011AD78: 7E340348
	v_mov_b32_e32 v25, v72                                     // 00000011AD7C: 7E320348
	v_mov_b32_e32 v24, v72                                     // 00000011AD80: 7E300348
	v_mov_b32_e32 v23, v72                                     // 00000011AD84: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 00000011AD88: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 00000011AD8C: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 00000011AD90: 7E280348
	v_mov_b32_e32 v19, v72                                     // 00000011AD94: 7E260348
	v_mov_b32_e32 v18, v72                                     // 00000011AD98: 7E240348
	v_mov_b32_e32 v17, v72                                     // 00000011AD9C: 7E220348
	v_mov_b32_e32 v16, v72                                     // 00000011ADA0: 7E200348
	v_mov_b32_e32 v15, v72                                     // 00000011ADA4: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 00000011ADA8: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 00000011ADAC: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 00000011ADB0: 7E180348
	v_mov_b32_e32 v11, v72                                     // 00000011ADB4: 7E160348
	v_mov_b32_e32 v10, v72                                     // 00000011ADB8: 7E140348
	v_mov_b32_e32 v9, v72                                      // 00000011ADBC: 7E120348
	v_mov_b32_e32 v8, v72                                      // 00000011ADC0: 7E100348
	v_mov_b32_e32 v7, v72                                      // 00000011ADC4: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 00000011ADC8: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 00000011ADCC: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 00000011ADD0: 7E080348
	v_mov_b32_e32 v3, v72                                      // 00000011ADD4: 7E060348
	v_mov_b32_e32 v2, v72                                      // 00000011ADD8: 7E040348
	v_mov_b32_e32 v1, v72                                      // 00000011ADDC: 7E020348
	s_cbranch_scc1 2865                                        // 00000011ADE0: BFA20B31 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x30a8>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[4:5]           // 00000011ADE4: D6FF7C01 001302FF 00003000
	v_lshlrev_b32_e32 v4, 2, v131                              // 00000011ADF0: 30090682
	s_movk_i32 s2, 0x440                                       // 00000011ADF4: B0020440
	s_ashr_i32 s1, s0, 31                                      // 00000011ADF8: 86019F00
	v_mad_u32_u24 v3, v155, s2, 0x3000                         // 00000011ADFC: D60B0003 03FC059B 00003000
	s_lshr_b32 s1, s1, 28                                      // 00000011AE08: 85019C01
	v_mad_u32_u24 v172, v154, 48, 0x9600                       // 00000011AE0C: D60B00AC 03FD619A 00009600
	s_add_i32 s0, s0, s1                                       // 00000011AE18: 81000100
	.long 0xd7006a8f                                           // 00000011AE1C: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 00000011AE20: 02031701
	v_add3_u32 v1, v129, s26, 1                                // 00000011AE24: D6550001 02043581
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 00000011AE2C: D5207C90 01AB1902
	v_mov_b32_e32 v129, 0                                      // 00000011AE34: 7F020280
	s_ashr_i32 s5, s0, 4                                       // 00000011AE38: 86058400
	s_delay_alu instid0(VALU_DEP_3)                            // 00000011AE3C: BF870003
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000011AE40: 3404029F
	.long 0xd44c0000                                           // 00000011AE44: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 00000011AE48: 020200FF 00000200
	v_mad_u32_u24 v5, 0x44, v157, v3                           // 00000011AE50: D60B0005 040F3AFF 00000044
	v_mad_u32_u24 v164, 0x44, v131, v3                         // 00000011AE5C: D60B00A4 040F06FF 00000044
	v_dual_mov_b32 v10, v129 :: v_dual_lshlrev_b32 v3, 4, v0   // 00000011AE68: CA220181 0A020084
	v_lshrrev_b32_e32 v2, 30, v2                               // 00000011AE70: 3204049E
	s_cmp_eq_u64 s[20:21], 0                                   // 00000011AE74: BF108014
	v_add_nc_u32_e32 v159, s26, v156                           // 00000011AE78: 4B3F381A
	s_cselect_b32 s12, -1, 0                                   // 00000011AE7C: 980C80C1
	s_cmp_lg_u64 s[20:21], 0                                   // 00000011AE80: BF118014
	v_add_nc_u32_e32 v1, v1, v2                                // 00000011AE84: 4A020501
	v_add_nc_u32_e32 v2, v132, v4                              // 00000011AE88: 4A040984
	v_lshl_add_u32 v160, v154, 2, v5                           // 00000011AE8C: D64600A0 0415059A
	v_lshlrev_b32_e32 v5, 9, v155                              // 00000011AE94: 300B3689
	v_add_nc_u32_e32 v6, 0xed00, v132                          // 00000011AE98: 4A0D08FF 0000ED00
	v_ashrrev_i32_e32 v161, 2, v1                              // 00000011AEA0: 35420282
	v_lshrrev_b32_e32 v1, 1, v0                                // 00000011AEA4: 32020081
	v_add_nc_u32_e32 v163, 0xe700, v2                          // 00000011AEA8: 4B4604FF 0000E700
	v_dual_mov_b32 v7, v129 :: v_dual_add_nc_u32 v0, 0xf300, v2// 00000011AEB0: CA200181 070004FF 0000F300
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000011AEBC: BF870143
	v_dual_mov_b32 v8, v129 :: v_dual_and_b32 v1, 0xf8, v1     // 00000011AEC0: CA240181 080002FF 000000F8
	s_cselect_b32 s13, -1, 0                                   // 00000011AECC: 980D80C1
	s_ashr_i32 s25, s24, 31                                    // 00000011AED0: 86199F18
	v_dual_mov_b32 v11, v129 :: v_dual_and_b32 v130, 0x1f0, v3 // 00000011AED4: CA240181 0B8206FF 000001F0
	v_mul_u32_u24_e32 v2, 48, v1                               // 00000011AEE0: 160402B0
	s_lshl_b64 s[24:25], s[24:25], 9                           // 00000011AEE4: 84988918
	s_add_i32 s15, s15, -1                                     // 00000011AEE8: 810FC10F
	v_dual_mov_b32 v9, 0 :: v_dual_add_nc_u32 v166, v6, v4     // 00000011AEEC: CA200080 09A60906
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011AEF4: BF870002
	v_lshl_or_b32 v2, v154, 1, v2                              // 00000011AEF8: D6560002 0409039A
	v_mov_b32_e32 v4, v129                                     // 00000011AF00: 7E080381
	v_lshl_add_u32 v165, v131, 5, v5                           // 00000011AF04: D64600A5 04150B83
	s_add_u32 s1, s6, s24                                      // 00000011AF0C: 80011806
	s_addc_u32 s4, s7, s25                                     // 00000011AF10: 82041907
	v_dual_mov_b32 v13, v129 :: v_dual_add_nc_u32 v170, 0x9600, v2// 00000011AF14: CA200181 0DAA04FF 00009600
	v_mov_b32_e32 v2, v129                                     // 00000011AF20: 7E040381
	v_add_nc_u32_e32 v162, v159, v131                          // 00000011AF24: 4B45079F
	v_dual_mov_b32 v12, v129 :: v_dual_lshlrev_b32 v131, 1, v1 // 00000011AF28: CA220181 0C820281
	v_mul_u32_u24_e32 v3, 0x210, v155                          // 00000011AF30: 160736FF 00000210
	s_add_u32 s2, s8, s24                                      // 00000011AF38: 80021808
	.long 0xd70001ad                                           // 00000011AF3C: D70001AD
	v_cndmask_b32_e32 v1, s1, v130, vcc_lo                     // 00000011AF40: 02030401
	s_addc_u32 s6, s9, s25                                     // 00000011AF44: 82061909
	s_movk_i32 s7, 0x210                                       // 00000011AF48: B0070210
	v_add_co_ci_u32_e64 v174, null, s4, 0, s1                  // 00000011AF4C: D5207CAE 00050004
	.long 0xd70001af                                           // 00000011AF54: D70001AF
	v_cndmask_b32_e32 v1, s2, v131, vcc_lo                     // 00000011AF58: 02030602
	v_lshl_or_b32 v168, v154, 5, v5                            // 00000011AF5C: D65600A8 04150B9A
	v_add3_u32 v169, v3, v130, 0xc600                          // 00000011AF64: D65500A9 03FF0503 0000C600
	v_mov_b32_e32 v1, 0                                        // 00000011AF70: 7E020280
	v_mov_b32_e32 v3, v129                                     // 00000011AF74: 7E060381
	v_mov_b32_e32 v5, v129                                     // 00000011AF78: 7E0A0381
	v_lshl_or_b32 v167, v157, 2, v6                            // 00000011AF7C: D65600A7 0419059D
	v_mov_b32_e32 v6, v129                                     // 00000011AF84: 7E0C0381
	v_dual_mov_b32 v14, v129 :: v_dual_mov_b32 v17, 0          // 00000011AF88: CA100181 0E100080
	v_mov_b32_e32 v15, v129                                    // 00000011AF90: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v25, 0          // 00000011AF94: CA100181 10180080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v33, 0          // 00000011AF9C: CA100181 12200080
	v_mov_b32_e32 v19, v129                                    // 00000011AFA4: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v41, 0          // 00000011AFA8: CA100181 14280080
	v_mov_b32_e32 v21, v129                                    // 00000011AFB0: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v49, 0          // 00000011AFB4: CA100181 16300080
	v_mov_b32_e32 v23, v129                                    // 00000011AFBC: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v57, 0          // 00000011AFC0: CA100181 18380080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v121, 0         // 00000011AFC8: CA100181 1A780080
	v_mov_b32_e32 v27, v129                                    // 00000011AFD0: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v113, 0         // 00000011AFD4: CA100181 1C700080
	v_mov_b32_e32 v29, v129                                    // 00000011AFDC: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v105, 0         // 00000011AFE0: CA100181 1E680080
	v_mov_b32_e32 v31, v129                                    // 00000011AFE8: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v97, 0          // 00000011AFEC: CA100181 20600080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v89, 0          // 00000011AFF4: CA100181 22580080
	v_mov_b32_e32 v35, v129                                    // 00000011AFFC: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v81, 0          // 00000011B000: CA100181 24500080
	v_mov_b32_e32 v37, v129                                    // 00000011B008: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v73, 0          // 00000011B00C: CA100181 26480080
	v_mov_b32_e32 v39, v129                                    // 00000011B014: 7E4E0381
	v_dual_mov_b32 v40, v129 :: v_dual_mov_b32 v65, 0          // 00000011B018: CA100181 28400080
	v_dual_mov_b32 v42, v129 :: v_dual_mov_b32 v145, 0         // 00000011B020: CA100181 2A900080
	v_mov_b32_e32 v43, v129                                    // 00000011B028: 7E560381
	v_mov_b32_e32 v44, v129                                    // 00000011B02C: 7E580381
	v_mov_b32_e32 v45, v129                                    // 00000011B030: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 00000011B034: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 00000011B038: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 00000011B03C: 7E600381
	v_mov_b32_e32 v50, v129                                    // 00000011B040: 7E640381
	v_mov_b32_e32 v51, v129                                    // 00000011B044: 7E660381
	v_mov_b32_e32 v52, v129                                    // 00000011B048: 7E680381
	v_mov_b32_e32 v53, v129                                    // 00000011B04C: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 00000011B050: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 00000011B054: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 00000011B058: 7E700381
	v_mov_b32_e32 v58, v129                                    // 00000011B05C: 7E740381
	v_mov_b32_e32 v59, v129                                    // 00000011B060: 7E760381
	v_mov_b32_e32 v60, v129                                    // 00000011B064: 7E780381
	v_mov_b32_e32 v61, v129                                    // 00000011B068: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 00000011B06C: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 00000011B070: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 00000011B074: 7E800381
	v_mov_b32_e32 v122, v129                                   // 00000011B078: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 00000011B07C: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 00000011B080: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 00000011B084: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 00000011B088: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 00000011B08C: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 00000011B090: 7F000381
	v_mov_b32_e32 v114, v129                                   // 00000011B094: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 00000011B098: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 00000011B09C: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 00000011B0A0: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 00000011B0A4: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 00000011B0A8: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 00000011B0AC: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 00000011B0B0: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 00000011B0B4: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 00000011B0B8: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 00000011B0BC: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 00000011B0C0: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 00000011B0C4: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 00000011B0C8: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 00000011B0CC: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 00000011B0D0: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 00000011B0D4: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 00000011B0D8: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 00000011B0DC: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 00000011B0E0: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 00000011B0E4: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 00000011B0E8: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 00000011B0EC: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 00000011B0F0: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 00000011B0F4: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 00000011B0F8: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 00000011B0FC: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 00000011B100: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 00000011B104: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 00000011B108: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 00000011B10C: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 00000011B110: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 00000011B114: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 00000011B118: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 00000011B11C: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 00000011B120: 7E940381
	v_mov_b32_e32 v75, v129                                    // 00000011B124: 7E960381
	v_mov_b32_e32 v76, v129                                    // 00000011B128: 7E980381
	v_mov_b32_e32 v77, v129                                    // 00000011B12C: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 00000011B130: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 00000011B134: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 00000011B138: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 00000011B13C: 7E840381
	v_mov_b32_e32 v67, v129                                    // 00000011B140: 7E860381
	v_mov_b32_e32 v68, v129                                    // 00000011B144: 7E880381
	v_mov_b32_e32 v69, v129                                    // 00000011B148: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 00000011B14C: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 00000011B150: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 00000011B154: 7E900381
	v_mad_u32_u24 v171, v154, s7, 0xc600                       // 00000011B158: D60B00AB 03FC0F9A 0000C600
	v_add_co_ci_u32_e64 v176, null, s6, 0, s1                  // 00000011B164: D5207CB0 00050006
	s_mov_b32 s6, 0                                            // 00000011B16C: BE860080
	s_branch 116                                               // 00000011B170: BFA00074 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x944>
	ds_load_b128 v[146:149], v172                              // 00000011B174: DBFC0000 920000AC
	ds_load_b128 v[150:153], v172 offset:16                    // 00000011B17C: DBFC0010 960000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B184: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[146:153], v[121:128]// 00000011B188: CC414079 1DE72582
	ds_load_b128 v[150:153], v172 offset:784                   // 00000011B190: DBFC0310 960000AC
	ds_load_b128 v[146:149], v172 offset:768                   // 00000011B198: DBFC0300 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B1A0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[146:153], v[113:120]// 00000011B1A4: CC414071 1DC72582
	ds_load_b128 v[150:153], v172 offset:1552                  // 00000011B1AC: DBFC0610 960000AC
	ds_load_b128 v[146:149], v172 offset:1536                  // 00000011B1B4: DBFC0600 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B1BC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[146:153], v[105:112]// 00000011B1C0: CC414069 1DA72582
	ds_load_b128 v[150:153], v172 offset:2320                  // 00000011B1C8: DBFC0910 960000AC
	ds_load_b128 v[146:149], v172 offset:2304                  // 00000011B1D0: DBFC0900 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B1D8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[146:153], v[97:104]// 00000011B1DC: CC414061 1D872582
	ds_load_b128 v[150:153], v172 offset:3088                  // 00000011B1E4: DBFC0C10 960000AC
	ds_load_b128 v[146:149], v172 offset:3072                  // 00000011B1EC: DBFC0C00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B1F4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[146:153], v[89:96]// 00000011B1F8: CC414059 1D672582
	ds_load_b128 v[150:153], v172 offset:3856                  // 00000011B200: DBFC0F10 960000AC
	ds_load_b128 v[146:149], v172 offset:3840                  // 00000011B208: DBFC0F00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B210: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[146:153], v[81:88]// 00000011B214: CC414051 1D472582
	ds_load_b128 v[150:153], v172 offset:4624                  // 00000011B21C: DBFC1210 960000AC
	ds_load_b128 v[146:149], v172 offset:4608                  // 00000011B224: DBFC1200 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B22C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[146:153], v[73:80]// 00000011B230: CC414049 1D272582
	ds_load_b128 v[150:153], v172 offset:5392                  // 00000011B238: DBFC1510 960000AC
	ds_load_b128 v[146:149], v172 offset:5376                  // 00000011B240: DBFC1500 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B248: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[146:153], v[65:72]// 00000011B24C: CC414041 1D072582
	ds_load_b128 v[150:153], v172 offset:6160                  // 00000011B254: DBFC1810 960000AC
	ds_load_b128 v[146:149], v172 offset:6144                  // 00000011B25C: DBFC1800 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B264: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[146:153], v[57:64]// 00000011B268: CC414039 1CE72582
	ds_load_b128 v[150:153], v172 offset:6928                  // 00000011B270: DBFC1B10 960000AC
	ds_load_b128 v[146:149], v172 offset:6912                  // 00000011B278: DBFC1B00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B280: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[146:153], v[49:56]// 00000011B284: CC414031 1CC72582
	ds_load_b128 v[150:153], v172 offset:7696                  // 00000011B28C: DBFC1E10 960000AC
	ds_load_b128 v[146:149], v172 offset:7680                  // 00000011B294: DBFC1E00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B29C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[146:153], v[41:48]// 00000011B2A0: CC414029 1CA72582
	ds_load_b128 v[150:153], v172 offset:8464                  // 00000011B2A8: DBFC2110 960000AC
	ds_load_b128 v[146:149], v172 offset:8448                  // 00000011B2B0: DBFC2100 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B2B8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[146:153], v[33:40]// 00000011B2BC: CC414021 1C872582
	ds_load_b128 v[150:153], v172 offset:9232                  // 00000011B2C4: DBFC2410 960000AC
	ds_load_b128 v[146:149], v172 offset:9216                  // 00000011B2CC: DBFC2400 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B2D4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[146:153], v[25:32]// 00000011B2D8: CC414019 1C672582
	ds_load_b128 v[150:153], v172 offset:10000                 // 00000011B2E0: DBFC2710 960000AC
	ds_load_b128 v[146:149], v172 offset:9984                  // 00000011B2E8: DBFC2700 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B2F0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[146:153], v[17:24]// 00000011B2F4: CC414011 1C472582
	ds_load_b128 v[150:153], v172 offset:10768                 // 00000011B2FC: DBFC2A10 960000AC
	ds_load_b128 v[146:149], v172 offset:10752                 // 00000011B304: DBFC2A00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B30C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[146:153], v[9:16]// 00000011B310: CC414009 1C272582
	ds_load_b128 v[150:153], v172 offset:11536                 // 00000011B318: DBFC2D10 960000AC
	ds_load_b128 v[146:149], v172 offset:11520                 // 00000011B320: DBFC2D00 920000AC
	s_waitcnt lgkmcnt(0)                                       // 00000011B328: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[146:153], v[1:8]// 00000011B32C: CC414001 1C072582
	s_add_i32 s1, s6, 1                                        // 00000011B334: 81018106
	s_cmp_eq_u32 s6, s5                                        // 00000011B338: BF060506
	s_mov_b32 s6, s1                                           // 00000011B33C: BE860001
	s_cbranch_scc1 2521                                        // 00000011B340: BFA209D9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x30a8>
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 00000011B344: 916A0D7E
	s_mov_b32 s1, s12                                          // 00000011B348: BE81000C
	s_cbranch_vccz 3                                           // 00000011B34C: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x95c>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000011B350: 916A017E
	s_cbranch_vccnz 65527                                      // 00000011B354: BFA4FFF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x934>
	s_branch 15                                                // 00000011B358: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x998>
	s_lshr_b32 s1, s6, 3                                       // 00000011B35C: 85018306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000011B360: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 00000011B364: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 00000011B36C: 7F040201
	global_load_b32 v130, v130, s[20:21]                       // 00000011B370: DC520000 82140082
	s_waitcnt vmcnt(0)                                         // 00000011B378: BF8903F7
	v_lshrrev_b32_e32 v130, s6, v130                           // 00000011B37C: 33050406
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011B380: BF870091
	v_and_b32_e32 v130, 1, v130                                // 00000011B384: 37050481
	.long 0xd44a0001                                           // 00000011B388: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000011B38C: 02030481
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000011B390: 916A017E
	s_cbranch_vccnz 65511                                      // 00000011B394: BFA4FFE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x934>
	s_lshl_b32 s2, s6, 4                                       // 00000011B398: 84028406
	s_waitcnt vmcnt(0)                                         // 00000011B39C: BF8903F7
	s_barrier                                                  // 00000011B3A0: BFBD0000
	buffer_gl0_inv                                             // 00000011B3A4: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000011B3AC: BE812000
	s_cbranch_execz 64                                         // 00000011B3B0: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xab4>
	v_or_b32_e32 v130, s2, v155                                // 00000011B3B4: 39053602
	v_or_b32_e32 v131, s2, v154                                // 00000011B3B8: 39073402
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011B3BC: BF870112
	v_min_i32_e32 v130, s15, v130                              // 00000011B3C0: 2305040F
	v_min_i32_e32 v132, s15, v131                              // 00000011B3C4: 2309060F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011B3C8: BF870112
	v_ashrrev_i32_e32 v133, 31, v130                           // 00000011B3CC: 350B049F
	v_ashrrev_i32_e32 v135, 31, v132                           // 00000011B3D0: 350F089F
	.long 0xd72c0086                                           // 00000011B3D4: D72C0086
	v_cndmask_b32_e32 v1, s11, v130, vcc_lo                    // 00000011B3D8: 0203040B
	v_mad_u64_u32 v[130:131], null, s10, v130, 0               // 00000011B3DC: D6FE7C82 0203040A
	.long 0xd72c0089                                           // 00000011B3E4: D72C0089
	v_cndmask_b32_e32 v1, s11, v132, vcc_lo                    // 00000011B3E8: 0203080B
	.long 0xd72c0088                                           // 00000011B3EC: D72C0088
	v_cndmask_b32_e32 v1, s10, v133, vcc_lo                    // 00000011B3F0: 02030A0A
	v_mad_u64_u32 v[132:133], null, s10, v132, 0               // 00000011B3F4: D6FE7C84 0203080A
	.long 0xd72c0087                                           // 00000011B3FC: D72C0087
	v_cndmask_b32_e32 v1, s10, v135, vcc_lo                    // 00000011B400: 02030E0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011B404: BF870113
	v_add3_u32 v131, v131, v136, v134                          // 00000011B408: D6550083 061B1183
	v_add3_u32 v133, v133, v135, v137                          // 00000011B410: D6550085 06270F85
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011B418: BF870112
	.long 0xd73c0082                                           // 00000011B41C: D73C0082
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000011B420: 02030481
	.long 0xd73c0084                                           // 00000011B424: D73C0084
	v_cndmask_b32_e32 v1, 1, v132, vcc_lo                      // 00000011B428: 02030881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011B42C: BF870092
	.long 0xd7006a82                                           // 00000011B430: D7006A82
	v_cndmask_b32_e32 v1, v173, v130, vcc_lo                   // 00000011B434: 020305AD
	v_add_co_ci_u32_e64 v131, null, v174, v131, vcc_lo         // 00000011B438: D5207C83 01AB07AE
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011B440: BF870093
	.long 0xd7006a86                                           // 00000011B444: D7006A86
	v_cndmask_b32_e32 v1, v175, v132, vcc_lo                   // 00000011B448: 020309AF
	v_add_co_ci_u32_e64 v135, null, v176, v133, vcc_lo         // 00000011B44C: D5207C87 01AB0BB0
	global_load_b128 v[130:133], v[130:131], off               // 00000011B454: DC5E0000 827C0082
	global_load_b128 v[134:137], v[134:135], off               // 00000011B45C: DC5E0000 867C0086
	s_waitcnt vmcnt(1)                                         // 00000011B464: BF8907F7
	ds_store_b128 v169, v[130:133]                             // 00000011B468: DB7C0000 000082A9
	s_waitcnt vmcnt(0)                                         // 00000011B470: BF8903F7
	ds_store_b16 v170, v134                                    // 00000011B474: D87C0000 000086AA
	ds_store_b16_d16_hi v170, v134 offset:48                   // 00000011B47C: DA840030 000086AA
	ds_store_b16 v170, v135 offset:96                          // 00000011B484: D87C0060 000087AA
	ds_store_b16_d16_hi v170, v135 offset:144                  // 00000011B48C: DA840090 000087AA
	ds_store_b16 v170, v136 offset:192                         // 00000011B494: D87C00C0 000088AA
	ds_store_b16_d16_hi v170, v136 offset:240                  // 00000011B49C: DA8400F0 000088AA
	ds_store_b16 v170, v137 offset:288                         // 00000011B4A4: D87C0120 000089AA
	ds_store_b16_d16_hi v170, v137 offset:336                  // 00000011B4AC: DA840150 000089AA
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011B4B4: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 00000011B4B8: BF89FC07
	s_barrier                                                  // 00000011B4BC: BFBD0000
	buffer_gl0_inv                                             // 00000011B4C0: E0AC0000 00000000
	s_clause 0x1                                               // 00000011B4C8: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:16     // 00000011B4CC: DC5E0010 967C008F
	global_load_b128 v[146:149], v[143:144], off               // 00000011B4D4: DC5E0000 927C008F
	ds_load_b128 v[177:180], v171                              // 00000011B4DC: DBFC0000 B10000AB
	ds_load_b128 v[181:184], v171 offset:16                    // 00000011B4E4: DBFC0010 B50000AB
	v_mov_b32_e32 v136, v129                                   // 00000011B4EC: 7F100381
	v_mov_b32_e32 v130, v129                                   // 00000011B4F0: 7F040381
	v_mov_b32_e32 v131, v129                                   // 00000011B4F4: 7F060381
	v_mov_b32_e32 v132, v129                                   // 00000011B4F8: 7F080381
	v_mov_b32_e32 v133, v129                                   // 00000011B4FC: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 00000011B500: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 00000011B504: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 00000011B508: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000011B50C: BF870212
	v_mov_b32_e32 v136, v135                                   // 00000011B510: 7F100387
	v_mov_b32_e32 v135, v134                                   // 00000011B514: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 00000011B518: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 00000011B51C: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 00000011B520: 7F080383
	v_mov_b32_e32 v131, v130                                   // 00000011B524: 7F060382
	v_mov_b32_e32 v130, v129                                   // 00000011B528: 7F040381
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B52C: BF890007
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011B530: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B534: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B53C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:48     // 00000011B540: DC5E0030 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:32     // 00000011B548: DC5E0020 927C008F
	ds_load_b128 v[177:180], v171 offset:32                    // 00000011B550: DBFC0020 B10000AB
	ds_load_b128 v[181:184], v171 offset:48                    // 00000011B558: DBFC0030 B50000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B560: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B564: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B56C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:80     // 00000011B570: DC5E0050 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:64     // 00000011B578: DC5E0040 927C008F
	ds_load_b128 v[181:184], v171 offset:80                    // 00000011B580: DBFC0050 B50000AB
	ds_load_b128 v[177:180], v171 offset:64                    // 00000011B588: DBFC0040 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B590: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B594: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B59C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:112    // 00000011B5A0: DC5E0070 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:96     // 00000011B5A8: DC5E0060 927C008F
	ds_load_b128 v[181:184], v171 offset:112                   // 00000011B5B0: DBFC0070 B50000AB
	ds_load_b128 v[177:180], v171 offset:96                    // 00000011B5B8: DBFC0060 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B5C0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B5C4: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B5CC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:144    // 00000011B5D0: DC5E0090 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:128    // 00000011B5D8: DC5E0080 927C008F
	ds_load_b128 v[181:184], v171 offset:144                   // 00000011B5E0: DBFC0090 B50000AB
	ds_load_b128 v[177:180], v171 offset:128                   // 00000011B5E8: DBFC0080 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B5F0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B5F4: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B5FC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:176    // 00000011B600: DC5E00B0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:160    // 00000011B608: DC5E00A0 927C008F
	ds_load_b128 v[181:184], v171 offset:176                   // 00000011B610: DBFC00B0 B50000AB
	ds_load_b128 v[177:180], v171 offset:160                   // 00000011B618: DBFC00A0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B620: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B624: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B62C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:208    // 00000011B630: DC5E00D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:192    // 00000011B638: DC5E00C0 927C008F
	ds_load_b128 v[181:184], v171 offset:208                   // 00000011B640: DBFC00D0 B50000AB
	ds_load_b128 v[177:180], v171 offset:192                   // 00000011B648: DBFC00C0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B650: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B654: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B65C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:240    // 00000011B660: DC5E00F0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:224    // 00000011B668: DC5E00E0 927C008F
	ds_load_b128 v[181:184], v171 offset:240                   // 00000011B670: DBFC00F0 B50000AB
	ds_load_b128 v[177:180], v171 offset:224                   // 00000011B678: DBFC00E0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B680: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B684: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B68C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:272    // 00000011B690: DC5E0110 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:256    // 00000011B698: DC5E0100 927C008F
	ds_load_b128 v[181:184], v171 offset:272                   // 00000011B6A0: DBFC0110 B50000AB
	ds_load_b128 v[177:180], v171 offset:256                   // 00000011B6A8: DBFC0100 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B6B0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B6B4: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B6BC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:304    // 00000011B6C0: DC5E0130 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:288    // 00000011B6C8: DC5E0120 927C008F
	ds_load_b128 v[181:184], v171 offset:304                   // 00000011B6D0: DBFC0130 B50000AB
	ds_load_b128 v[177:180], v171 offset:288                   // 00000011B6D8: DBFC0120 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B6E0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B6E4: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B6EC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:336    // 00000011B6F0: DC5E0150 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:320    // 00000011B6F8: DC5E0140 927C008F
	ds_load_b128 v[181:184], v171 offset:336                   // 00000011B700: DBFC0150 B50000AB
	ds_load_b128 v[177:180], v171 offset:320                   // 00000011B708: DBFC0140 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B710: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B714: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B71C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:368    // 00000011B720: DC5E0170 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:352    // 00000011B728: DC5E0160 927C008F
	ds_load_b128 v[181:184], v171 offset:368                   // 00000011B730: DBFC0170 B50000AB
	ds_load_b128 v[177:180], v171 offset:352                   // 00000011B738: DBFC0160 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B740: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B744: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B74C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:400    // 00000011B750: DC5E0190 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:384    // 00000011B758: DC5E0180 927C008F
	ds_load_b128 v[181:184], v171 offset:400                   // 00000011B760: DBFC0190 B50000AB
	ds_load_b128 v[177:180], v171 offset:384                   // 00000011B768: DBFC0180 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B770: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B774: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B77C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:432    // 00000011B780: DC5E01B0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:416    // 00000011B788: DC5E01A0 927C008F
	ds_load_b128 v[181:184], v171 offset:432                   // 00000011B790: DBFC01B0 B50000AB
	ds_load_b128 v[177:180], v171 offset:416                   // 00000011B798: DBFC01A0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B7A0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B7A4: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B7AC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:464    // 00000011B7B0: DC5E01D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:448    // 00000011B7B8: DC5E01C0 927C008F
	ds_load_b128 v[181:184], v171 offset:464                   // 00000011B7C0: DBFC01D0 B50000AB
	ds_load_b128 v[177:180], v171 offset:448                   // 00000011B7C8: DBFC01C0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B7D0: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B7D4: CC414082 1E0B6392
	s_clause 0x1                                               // 00000011B7DC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:496    // 00000011B7E0: DC5E01F0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:480    // 00000011B7E8: DC5E01E0 927C008F
	ds_load_b128 v[181:184], v171 offset:496                   // 00000011B7F0: DBFC01F0 B50000AB
	ds_load_b128 v[177:180], v171 offset:480                   // 00000011B7F8: DBFC01E0 B10000AB
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011B800: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 00000011B804: CC414082 1E0B6392
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011B80C: BF870111
	v_dual_mul_f32 v130, 0x3d800000, v130 :: v_dual_mul_f32 v131, 0x3d800000, v131// 00000011B810: C8C704FF 828306FF 3D800000
	v_mul_f32_e32 v146, 0x3d800000, v134                       // 00000011B81C: 11250CFF 3D800000
	v_mov_b32_e32 v134, 0xffff                                 // 00000011B824: 7F0C02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000011B82C: BF870004
	v_dual_mul_f32 v132, 0x3d800000, v132 :: v_dual_mul_f32 v133, 0x3d800000, v133// 00000011B830: C8C708FF 84850AFF 3D800000
	v_dual_mul_f32 v135, 0x3d800000, v135 :: v_dual_mul_f32 v136, 0x3d800000, v136// 00000011B83C: C8C70EFF 878910FF 3D800000
	v_mul_f32_e32 v137, 0x3d800000, v137                       // 00000011B848: 111312FF 3D800000
	ds_store_2addr_b32 v160, v130, v131 offset1:34             // 00000011B850: D8382200 008382A0
	ds_store_2addr_b32 v160, v132, v133 offset0:68 offset1:102 // 00000011B858: D8386644 008584A0
	ds_store_2addr_b32 v160, v146, v135 offset0:136 offset1:170// 00000011B860: D838AA88 008792A0
	ds_store_2addr_b32 v160, v136, v137 offset0:204 offset1:238// 00000011B868: D838EECC 008988A0
	s_and_saveexec_b32 s4, s23                                 // 00000011B870: BE842017
	s_cbranch_execz 358                                        // 00000011B874: BFA50166 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1410>
	s_lshl_b32 s7, s6, 2                                       // 00000011B878: 84078206
	s_mov_b32 s8, exec_lo                                      // 00000011B87C: BE88007E
	.long 0xd4c1007e                                           // 00000011B880: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 00000011B884: 02033D91
	s_cbranch_execz 43                                         // 00000011B888: BFA5002B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf38>
	v_ashrrev_i32_e32 v146, 31, v145                           // 00000011B88C: 3525229F
	s_mov_b32 s9, 0                                            // 00000011B890: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011B894: BF870091
	.long 0xd73c0082                                           // 00000011B898: D73C0082
	v_cndmask_b32_e32 v1, 2, v145, vcc_lo                      // 00000011B89C: 02032282
	.long 0xd7006a82                                           // 00000011B8A0: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 00000011B8A4: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011B8A8: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 00000011B8AC: D5207C83 01AB078E
	s_branch 10                                                // 00000011B8B4: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xee0>
	s_nop 0                                                    // 00000011B8B8: BF800000
	s_nop 0                                                    // 00000011B8BC: BF800000
	s_or_b32 exec_lo, exec_lo, s24                             // 00000011B8C0: 8C7E187E
	v_mov_b32_e32 v133, v145                                   // 00000011B8C4: 7F0A0391
	v_mov_b32_e32 v145, v132                                   // 00000011B8C8: 7F220384
	s_and_b32 s1, exec_lo, s22                                 // 00000011B8CC: 8B01167E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000011B8D0: BF870499
	s_or_b32 s9, s1, s9                                        // 00000011B8D4: 8C090901
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 00000011B8D8: 917E097E
	s_cbranch_execz 20                                         // 00000011B8DC: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf30>
	global_load_b32 v132, v[130:131], off                      // 00000011B8E0: DC520000 847C0082
	s_or_b32 s22, s22, exec_lo                                 // 00000011B8E8: 8C167E16
	s_waitcnt vmcnt(0)                                         // 00000011B8EC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s7, v132                          // 00000011B8F0: 7C890807
	s_and_saveexec_b32 s24, vcc_lo                             // 00000011B8F4: BE98206A
	s_cbranch_execz 65521                                      // 00000011B8F8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xec0>
	v_dual_mov_b32 v145, v158 :: v_dual_add_nc_u32 v132, 1, v145// 00000011B8FC: CA20019E 91852281
	.long 0xd7000182                                           // 00000011B904: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 00000011B908: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011B90C: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 00000011B910: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v158, v132                        // 00000011B918: 7C95099E
	s_and_not1_b32 s1, s22, exec_lo                            // 00000011B91C: 91017E16
	s_and_b32 s22, vcc_lo, exec_lo                             // 00000011B920: 8B167E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011B924: BF870009
	s_or_b32 s22, s1, s22                                      // 00000011B928: 8C161601
	s_branch 65508                                             // 00000011B92C: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xec0>
	s_or_b32 exec_lo, exec_lo, s9                              // 00000011B930: 8C7E097E
	v_mov_b32_e32 v145, v133                                   // 00000011B934: 7F220385
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011B938: 8C7E087E
	v_mov_b32_e32 v134, 15                                     // 00000011B93C: 7F0C028F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011B940: BF870002
	v_mov_b32_e32 v130, v145                                   // 00000011B944: 7F040391
	s_mov_b32 s1, exec_lo                                      // 00000011B948: BE81007E
	.long 0xd4c1007e                                           // 00000011B94C: D4C1007E
	v_cndmask_b32_e32 v1, s7, v161, vcc_lo                     // 00000011B950: 02034207
	s_cbranch_execz 62                                         // 00000011B954: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1050>
	v_mov_b32_e32 v134, 0                                      // 00000011B958: 7F0C0280
	v_mov_b32_e32 v130, v145                                   // 00000011B95C: 7F040391
	s_mov_b32 s8, exec_lo                                      // 00000011B960: BE88007E
	.long 0xd4c1007e                                           // 00000011B964: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 00000011B968: 02033D91
	s_cbranch_execz 54                                         // 00000011B96C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1048>
	v_mov_b32_e32 v130, v145                                   // 00000011B970: 7F040391
	s_mov_b32 s22, 0                                           // 00000011B974: BE960080
	s_set_inst_prefetch_distance 0x1                           // 00000011B978: BF840001
	s_branch 10                                                // 00000011B97C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfa8>
	s_or_b32 exec_lo, exec_lo, s26                             // 00000011B980: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000011B984: BF870499
	s_and_b32 s26, exec_lo, s25                                // 00000011B988: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 00000011B98C: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 00000011B990: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 00000011B994: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011B998: BF870009
	s_or_b32 s9, s9, s26                                       // 00000011B99C: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 00000011B9A0: 917E167E
	s_cbranch_execz 28                                         // 00000011B9A4: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1018>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011B9A8: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 00000011B9AC: 7F060382
	s_or_b32 s24, s24, exec_lo                                 // 00000011B9B0: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 00000011B9B4: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 00000011B9B8: BE9A007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000011B9BC: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011B9C0: BF870091
	.long 0xd73c0084                                           // 00000011B9C4: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000011B9C8: 02030682
	.long 0xd7006a84                                           // 00000011B9CC: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 00000011B9D0: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011B9D4: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 00000011B9D8: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 00000011B9E0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 00000011B9E8: BF8903F7
	.long 0xd4c4007e                                           // 00000011B9EC: D4C4007E
	v_cndmask_b32_e32 v1, s7, v132, vcc_lo                     // 00000011B9F0: 02030807
	s_cbranch_execz 65506                                      // 00000011B9F4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000011B9F8: 4B050681
	s_and_not1_b32 s25, s25, exec_lo                           // 00000011B9FC: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 00000011BA00: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000011BA04: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000011BA08: 7C95059E
	s_and_b32 s27, vcc_lo, exec_lo                             // 00000011BA0C: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 00000011BA10: 8C191B19
	s_branch 65498                                             // 00000011BA14: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	s_set_inst_prefetch_distance 0x2                           // 00000011BA18: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 00000011BA1C: 8C7E167E
	v_mov_b32_e32 v134, 0                                      // 00000011BA20: 7F0C0280
	v_mov_b32_e32 v130, v158                                   // 00000011BA24: 7F04039E
	s_and_saveexec_b32 s22, s9                                 // 00000011BA28: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BA2C: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 00000011BA30: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v132                          // 00000011BA34: 7C950807
	v_mov_b32_e32 v130, v131                                   // 00000011BA38: 7F040383
	v_cndmask_b32_e64 v134, 0, 15, vcc_lo                      // 00000011BA3C: D5010086 01A91E80
	s_or_b32 exec_lo, exec_lo, s9                              // 00000011BA44: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BA48: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011BA4C: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BA50: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011BA54: 8C7E017E
	s_or_b32 s8, s7, 1                                         // 00000011BA58: 8C088107
	s_mov_b32 s1, exec_lo                                      // 00000011BA5C: BE81007E
	.long 0xd4c6007e                                           // 00000011BA60: D4C6007E
	v_cndmask_b32_e32 v1, s8, v161, vcc_lo                     // 00000011BA64: 02034208
	s_xor_b32 s1, exec_lo, s1                                  // 00000011BA68: 8D01017E
	v_or_b32_e32 v134, 0xf0, v134                              // 00000011BA6C: 390D0CFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 00000011BA74: BE813001
	s_cbranch_execz 70                                         // 00000011BA78: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1194>
	s_mov_b32 s9, exec_lo                                      // 00000011BA7C: BE89007E
	.long 0xd4c1007e                                           // 00000011BA80: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000011BA84: 02033D82
	s_cbranch_execz 64                                         // 00000011BA88: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x118c>
	s_mov_b32 s24, 0                                           // 00000011BA8C: BE980080
	s_set_inst_prefetch_distance 0x1                           // 00000011BA90: BF840001
	s_branch 20                                                // 00000011BA94: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10e8>
	s_nop 0                                                    // 00000011BA98: BF800000
	s_nop 0                                                    // 00000011BA9C: BF800000
	s_nop 0                                                    // 00000011BAA0: BF800000
	s_nop 0                                                    // 00000011BAA4: BF800000
	s_nop 0                                                    // 00000011BAA8: BF800000
	s_nop 0                                                    // 00000011BAAC: BF800000
	s_nop 0                                                    // 00000011BAB0: BF800000
	s_nop 0                                                    // 00000011BAB4: BF800000
	s_nop 0                                                    // 00000011BAB8: BF800000
	s_nop 0                                                    // 00000011BABC: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 00000011BAC0: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000011BAC4: BF870499
	s_and_b32 s27, exec_lo, s26                                // 00000011BAC8: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 00000011BACC: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 00000011BAD0: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 00000011BAD4: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BAD8: BF870009
	s_or_b32 s22, s22, s27                                     // 00000011BADC: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 00000011BAE0: 917E187E
	s_cbranch_execz 27                                         // 00000011BAE4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1154>
	v_mov_b32_e32 v131, v130                                   // 00000011BAE8: 7F060382
	s_or_b32 s25, s25, exec_lo                                 // 00000011BAEC: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 00000011BAF0: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 00000011BAF4: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011BAF8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000011BAFC: 3509069F
	.long 0xd73c0084                                           // 00000011BB00: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000011BB04: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011BB08: BF870091
	.long 0xd7006a84                                           // 00000011BB0C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 00000011BB10: 0203098D
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 00000011BB14: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 00000011BB1C: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 00000011BB24: BF8903F7
	.long 0xd4c6007e                                           // 00000011BB28: D4C6007E
	v_cndmask_b32_e32 v1, s7, v132, vcc_lo                     // 00000011BB2C: 02030807
	s_cbranch_execz 65507                                      // 00000011BB30: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000011BB34: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 00000011BB38: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 00000011BB3C: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000011BB40: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000011BB44: 7C95059E
	s_and_b32 s28, vcc_lo, exec_lo                             // 00000011BB48: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 00000011BB4C: 8C1A1C1A
	s_branch 65499                                             // 00000011BB50: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10c0>
	s_set_inst_prefetch_distance 0x2                           // 00000011BB54: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 00000011BB58: 8C7E187E
	v_mov_b32_e32 v130, v158                                   // 00000011BB5C: 7F04039E
	s_and_saveexec_b32 s24, s22                                // 00000011BB60: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BB64: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 00000011BB68: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v132                          // 00000011BB6C: 7C950808
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 00000011BB70: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011BB7C: BF870001
	v_or_b32_e32 v134, v130, v134                              // 00000011BB80: 390D0D82
	v_mov_b32_e32 v130, v131                                   // 00000011BB84: 7F040383
	s_or_b32 exec_lo, exec_lo, s22                             // 00000011BB88: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BB8C: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 00000011BB90: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BB94: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011BB98: 8C7E017E
	s_or_b32 s8, s7, 2                                         // 00000011BB9C: 8C088207
	s_mov_b32 s1, exec_lo                                      // 00000011BBA0: BE81007E
	.long 0xd4c6007e                                           // 00000011BBA4: D4C6007E
	v_cndmask_b32_e32 v1, s8, v161, vcc_lo                     // 00000011BBA8: 02034208
	s_xor_b32 s1, exec_lo, s1                                  // 00000011BBAC: 8D01017E
	v_or_b32_e32 v134, 0xf00, v134                             // 00000011BBB0: 390D0CFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 00000011BBB8: BE813001
	s_cbranch_execz 69                                         // 00000011BBBC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12d4>
	s_mov_b32 s9, exec_lo                                      // 00000011BBC0: BE89007E
	.long 0xd4c1007e                                           // 00000011BBC4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000011BBC8: 02033D82
	s_cbranch_execz 63                                         // 00000011BBCC: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12cc>
	s_mov_b32 s24, 0                                           // 00000011BBD0: BE980080
	s_set_inst_prefetch_distance 0x1                           // 00000011BBD4: BF840001
	s_branch 19                                                // 00000011BBD8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1228>
	s_nop 0                                                    // 00000011BBDC: BF800000
	s_nop 0                                                    // 00000011BBE0: BF800000
	s_nop 0                                                    // 00000011BBE4: BF800000
	s_nop 0                                                    // 00000011BBE8: BF800000
	s_nop 0                                                    // 00000011BBEC: BF800000
	s_nop 0                                                    // 00000011BBF0: BF800000
	s_nop 0                                                    // 00000011BBF4: BF800000
	s_nop 0                                                    // 00000011BBF8: BF800000
	s_nop 0                                                    // 00000011BBFC: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 00000011BC00: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000011BC04: BF870499
	s_and_b32 s27, exec_lo, s26                                // 00000011BC08: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 00000011BC0C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 00000011BC10: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 00000011BC14: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BC18: BF870009
	s_or_b32 s22, s22, s27                                     // 00000011BC1C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 00000011BC20: 917E187E
	s_cbranch_execz 27                                         // 00000011BC24: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1294>
	v_mov_b32_e32 v131, v130                                   // 00000011BC28: 7F060382
	s_or_b32 s25, s25, exec_lo                                 // 00000011BC2C: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 00000011BC30: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 00000011BC34: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011BC38: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000011BC3C: 3509069F
	.long 0xd73c0084                                           // 00000011BC40: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000011BC44: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011BC48: BF870091
	.long 0xd7006a84                                           // 00000011BC4C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 00000011BC50: 0203098D
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 00000011BC54: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 00000011BC5C: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 00000011BC64: BF8903F7
	.long 0xd4c4007e                                           // 00000011BC68: D4C4007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 00000011BC6C: 02030808
	s_cbranch_execz 65507                                      // 00000011BC70: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1200>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000011BC74: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 00000011BC78: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 00000011BC7C: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000011BC80: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000011BC84: 7C95059E
	s_and_b32 s28, vcc_lo, exec_lo                             // 00000011BC88: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 00000011BC8C: 8C1A1C1A
	s_branch 65499                                             // 00000011BC90: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1200>
	s_set_inst_prefetch_distance 0x2                           // 00000011BC94: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 00000011BC98: 8C7E187E
	v_mov_b32_e32 v130, v158                                   // 00000011BC9C: 7F04039E
	s_and_saveexec_b32 s24, s22                                // 00000011BCA0: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BCA4: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 00000011BCA8: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v132                          // 00000011BCAC: 7C950808
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 00000011BCB0: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011BCBC: BF870001
	v_or_b32_e32 v134, v130, v134                              // 00000011BCC0: 390D0D82
	v_mov_b32_e32 v130, v131                                   // 00000011BCC4: 7F040383
	s_or_b32 exec_lo, exec_lo, s22                             // 00000011BCC8: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BCCC: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 00000011BCD0: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BCD4: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011BCD8: 8C7E017E
	s_or_b32 s7, s7, 3                                         // 00000011BCDC: 8C078307
	s_mov_b32 s1, exec_lo                                      // 00000011BCE0: BE81007E
	.long 0xd4c6007e                                           // 00000011BCE4: D4C6007E
	v_cndmask_b32_e32 v1, s7, v161, vcc_lo                     // 00000011BCE8: 02034207
	s_xor_b32 s1, exec_lo, s1                                  // 00000011BCEC: 8D01017E
	v_or_b32_e32 v134, 0xf000, v134                            // 00000011BCF0: 390D0CFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 00000011BCF8: BE813001
	s_cbranch_execz 66                                         // 00000011BCFC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1408>
	s_mov_b32 s8, exec_lo                                      // 00000011BD00: BE88007E
	.long 0xd4c1007e                                           // 00000011BD04: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000011BD08: 02033D82
	s_cbranch_execz 60                                         // 00000011BD0C: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	s_mov_b32 s22, 0                                           // 00000011BD10: BE960080
	s_set_inst_prefetch_distance 0x1                           // 00000011BD14: BF840001
	s_branch 19                                                // 00000011BD18: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1368>
	s_nop 0                                                    // 00000011BD1C: BF800000
	s_nop 0                                                    // 00000011BD20: BF800000
	s_nop 0                                                    // 00000011BD24: BF800000
	s_nop 0                                                    // 00000011BD28: BF800000
	s_nop 0                                                    // 00000011BD2C: BF800000
	s_nop 0                                                    // 00000011BD30: BF800000
	s_nop 0                                                    // 00000011BD34: BF800000
	s_nop 0                                                    // 00000011BD38: BF800000
	s_nop 0                                                    // 00000011BD3C: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 00000011BD40: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000011BD44: BF870499
	s_and_b32 s26, exec_lo, s25                                // 00000011BD48: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 00000011BD4C: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 00000011BD50: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 00000011BD54: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BD58: BF870009
	s_or_b32 s9, s9, s26                                       // 00000011BD5C: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 00000011BD60: 917E167E
	s_cbranch_execz 26                                         // 00000011BD64: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13d0>
	v_ashrrev_i32_e32 v131, 31, v130                           // 00000011BD68: 3507049F
	s_or_b32 s24, s24, exec_lo                                 // 00000011BD6C: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 00000011BD70: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 00000011BD74: BE9A007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011BD78: BF870091
	.long 0xd73c0083                                           // 00000011BD7C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 00000011BD80: 02030482
	.long 0xd7006a83                                           // 00000011BD84: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 00000011BD88: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011BD8C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 00000011BD90: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 00000011BD98: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 00000011BDA0: BF8903F7
	.long 0xd4c4007e                                           // 00000011BDA4: D4C4007E
	v_cndmask_b32_e32 v1, s7, v131, vcc_lo                     // 00000011BDA8: 02030607
	s_cbranch_execz 65508                                      // 00000011BDAC: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1340>
	v_add_nc_u32_e32 v130, 1, v130                             // 00000011BDB0: 4B050481
	s_and_not1_b32 s25, s25, exec_lo                           // 00000011BDB4: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 00000011BDB8: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000011BDBC: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000011BDC0: 7C95059E
	s_and_b32 s27, vcc_lo, exec_lo                             // 00000011BDC4: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 00000011BDC8: 8C191B19
	s_branch 65500                                             // 00000011BDCC: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1340>
	s_set_inst_prefetch_distance 0x2                           // 00000011BDD0: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 00000011BDD4: 8C7E167E
	s_and_saveexec_b32 s22, s9                                 // 00000011BDD8: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BDDC: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 00000011BDE0: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v131                          // 00000011BDE4: 7C950607
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 00000011BDE8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011BDF4: BF870001
	v_or_b32_e32 v134, v130, v134                              // 00000011BDF8: 390D0D82
	s_or_b32 exec_lo, exec_lo, s9                              // 00000011BDFC: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BE00: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011BE04: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BE08: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011BE0C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000011BE10: BF8704C9
	s_or_b32 exec_lo, exec_lo, s4                              // 00000011BE14: 8C7E047E
	v_cmp_eq_u32_e32 vcc_lo, 0xffff, v134                      // 00000011BE18: 7C950CFF 0000FFFF
	s_cmp_eq_u32 vcc_lo, -1                                    // 00000011BE20: BF06C16A
	s_cselect_b32 s1, -1, 0                                    // 00000011BE24: 980180C1
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 00000011BE28: D5010082 00050280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011BE30: BF870001
	v_readfirstlane_b32 s1, v130                               // 00000011BE34: 7E020582
	s_bitcmp0_b32 s1, 0                                        // 00000011BE38: BF0C8001
	s_mov_b32 s1, 0                                            // 00000011BE3C: BE810080
	s_cbranch_scc1 8                                           // 00000011BE40: BFA20008 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1464>
	s_or_b32 s1, s2, 15                                        // 00000011BE44: 8C018F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011BE48: BF8700A9
	v_cmp_le_i32_e32 vcc_lo, s1, v159                          // 00000011BE4C: 7C873E01
	v_cndmask_b32_e64 v130, 0, 1, vcc_lo                       // 00000011BE50: D5010082 01A90280
	v_readfirstlane_b32 s1, v130                               // 00000011BE58: 7E020582
	s_bitcmp1_b32 s1, 0                                        // 00000011BE5C: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 00000011BE60: 980180C1
	s_and_saveexec_b32 s4, s3                                  // 00000011BE64: BE842003
	s_cbranch_execz 1625                                       // 00000011BE68: BFA50659 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2dd0>
	ds_load_b32 v132, v163                                     // 00000011BE6C: D8D80000 840000A3
	s_xor_b32 s1, s1, -1                                       // 00000011BE74: 8D01C101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BE78: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000011BE7C: 916A017E
	s_mov_b32 s1, -1                                           // 00000011BE80: BE8100C1
	s_cbranch_vccnz 985                                        // 00000011BE84: BFA403D9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x23ec>
	s_waitcnt lgkmcnt(0)                                       // 00000011BE88: BF89FC07
	v_dual_mov_b32 v133, v132 :: v_dual_and_b32 v130, 1, v134  // 00000011BE8C: CA240184 85830C81
	v_cmp_le_i32_e32 vcc_lo, s2, v162                          // 00000011BE94: 7C874402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000011BE98: BF8704A2
	.long 0xd44a0001                                           // 00000011BE9C: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000011BEA0: 02030481
	s_and_b32 s35, vcc_lo, s1                                  // 00000011BEA4: 8B23016A
	s_and_saveexec_b32 s1, s35                                 // 00000011BEA8: BE812023
	s_cbranch_execz 7                                          // 00000011BEAC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14cc>
	ds_load_b32 v130, v164                                     // 00000011BEB0: D8D80000 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011BEB8: BF89FC07
	v_dual_max_f32 v131, v132, v132 :: v_dual_max_f32 v130, v130, v130// 00000011BEBC: CA950984 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011BEC4: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011BEC8: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011BECC: 8C7E017E
	v_and_b32_e32 v130, 2, v134                                // 00000011BED0: 37050C82
	v_cmp_lt_i32_e32 vcc_lo, s2, v162                          // 00000011BED4: 7C834402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000011BED8: BF8704A2
	.long 0xd44d0001                                           // 00000011BEDC: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011BEE0: 02030480
	s_and_b32 s34, vcc_lo, s1                                  // 00000011BEE4: 8B22016A
	s_and_saveexec_b32 s1, s34                                 // 00000011BEE8: BE812022
	s_cbranch_execz 7                                          // 00000011BEEC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x150c>
	ds_load_b32 v130, v164 offset:4                            // 00000011BEF0: D8D80004 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011BEF8: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011BEFC: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011BF04: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011BF08: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011BF0C: 8C7E017E
	v_and_b32_e32 v130, 4, v134                                // 00000011BF10: 37050C84
	s_or_b32 s1, s2, 2                                         // 00000011BF14: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011BF18: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000011BF1C: 7C874401
	.long 0xd44d0001                                           // 00000011BF20: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011BF24: 02030480
	s_and_b32 s33, vcc_lo, s1                                  // 00000011BF28: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BF2C: BF870009
	s_and_saveexec_b32 s1, s33                                 // 00000011BF30: BE812021
	s_cbranch_execz 7                                          // 00000011BF34: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1554>
	ds_load_b32 v130, v164 offset:8                            // 00000011BF38: D8D80008 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011BF40: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011BF44: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011BF4C: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011BF50: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011BF54: 8C7E017E
	v_and_b32_e32 v130, 8, v134                                // 00000011BF58: 37050C88
	s_or_b32 s1, s2, 3                                         // 00000011BF5C: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011BF60: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000011BF64: 7C874401
	.long 0xd44d0001                                           // 00000011BF68: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011BF6C: 02030480
	s_and_b32 s31, vcc_lo, s1                                  // 00000011BF70: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BF74: BF870009
	s_and_saveexec_b32 s1, s31                                 // 00000011BF78: BE81201F
	s_cbranch_execz 7                                          // 00000011BF7C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x159c>
	ds_load_b32 v130, v164 offset:12                           // 00000011BF80: D8D8000C 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011BF88: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011BF8C: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011BF94: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011BF98: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011BF9C: 8C7E017E
	v_and_b32_e32 v130, 16, v134                               // 00000011BFA0: 37050C90
	s_or_b32 s1, s2, 4                                         // 00000011BFA4: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011BFA8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000011BFAC: 7C874401
	.long 0xd44d0001                                           // 00000011BFB0: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011BFB4: 02030480
	s_and_b32 s30, vcc_lo, s1                                  // 00000011BFB8: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011BFBC: BF870009
	s_and_saveexec_b32 s1, s30                                 // 00000011BFC0: BE81201E
	s_cbranch_execz 7                                          // 00000011BFC4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15e4>
	ds_load_b32 v130, v164 offset:16                           // 00000011BFC8: D8D80010 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011BFD0: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011BFD4: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011BFDC: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011BFE0: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011BFE4: 8C7E017E
	v_and_b32_e32 v130, 32, v134                               // 00000011BFE8: 37050CA0
	s_or_b32 s1, s2, 5                                         // 00000011BFEC: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011BFF0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000011BFF4: 7C874401
	.long 0xd44d0001                                           // 00000011BFF8: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011BFFC: 02030480
	s_and_b32 s29, vcc_lo, s1                                  // 00000011C000: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011C004: BF870009
	s_and_saveexec_b32 s1, s29                                 // 00000011C008: BE81201D
	s_cbranch_execz 7                                          // 00000011C00C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x162c>
	ds_load_b32 v130, v164 offset:20                           // 00000011C010: D8D80014 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C018: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011C01C: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011C024: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011C028: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011C02C: 8C7E017E
	v_and_b32_e32 v130, 64, v134                               // 00000011C030: 37050CC0
	s_or_b32 s1, s2, 6                                         // 00000011C034: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011C038: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000011C03C: 7C874401
	.long 0xd44d0001                                           // 00000011C040: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011C044: 02030480
	s_and_b32 s28, vcc_lo, s1                                  // 00000011C048: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011C04C: BF870009
	s_and_saveexec_b32 s1, s28                                 // 00000011C050: BE81201C
	s_cbranch_execz 7                                          // 00000011C054: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1674>
	ds_load_b32 v130, v164 offset:24                           // 00000011C058: D8D80018 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C060: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011C064: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011C06C: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011C070: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011C074: 8C7E017E
	v_and_b32_e32 v130, 0x80, v134                             // 00000011C078: 37050CFF 00000080
	s_or_b32 s1, s2, 7                                         // 00000011C080: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011C084: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000011C088: 7C874401
	.long 0xd44d0001                                           // 00000011C08C: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011C090: 02030480
	s_and_b32 s27, vcc_lo, s1                                  // 00000011C094: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011C098: BF870009
	s_and_saveexec_b32 s1, s27                                 // 00000011C09C: BE81201B
	s_cbranch_execz 7                                          // 00000011C0A0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c0>
	ds_load_b32 v130, v164 offset:28                           // 00000011C0A4: D8D8001C 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C0AC: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011C0B0: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011C0B8: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011C0BC: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011C0C0: 8C7E017E
	v_and_b32_e32 v130, 0x100, v134                            // 00000011C0C4: 37050CFF 00000100
	s_or_b32 s1, s2, 8                                         // 00000011C0CC: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011C0D0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000011C0D4: 7C874401
	.long 0xd44d0001                                           // 00000011C0D8: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011C0DC: 02030480
	s_and_b32 s26, vcc_lo, s1                                  // 00000011C0E0: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011C0E4: BF870009
	s_and_saveexec_b32 s1, s26                                 // 00000011C0E8: BE81201A
	s_cbranch_execz 7                                          // 00000011C0EC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x170c>
	ds_load_b32 v130, v164 offset:32                           // 00000011C0F0: D8D80020 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C0F8: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011C0FC: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011C104: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011C108: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011C10C: 8C7E017E
	v_and_b32_e32 v130, 0x200, v134                            // 00000011C110: 37050CFF 00000200
	s_or_b32 s1, s2, 9                                         // 00000011C118: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011C11C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000011C120: 7C874401
	.long 0xd44d0001                                           // 00000011C124: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011C128: 02030480
	s_and_b32 s25, vcc_lo, s1                                  // 00000011C12C: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011C130: BF870009
	s_and_saveexec_b32 s1, s25                                 // 00000011C134: BE812019
	s_cbranch_execz 7                                          // 00000011C138: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1758>
	ds_load_b32 v130, v164 offset:36                           // 00000011C13C: D8D80024 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C144: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011C148: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011C150: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011C154: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011C158: 8C7E017E
	v_and_b32_e32 v130, 0x400, v134                            // 00000011C15C: 37050CFF 00000400
	s_or_b32 s1, s2, 10                                        // 00000011C164: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011C168: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000011C16C: 7C874401
	.long 0xd44d0001                                           // 00000011C170: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011C174: 02030480
	s_and_b32 s24, vcc_lo, s1                                  // 00000011C178: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011C17C: BF870009
	s_and_saveexec_b32 s1, s24                                 // 00000011C180: BE812018
	s_cbranch_execz 7                                          // 00000011C184: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17a4>
	ds_load_b32 v130, v164 offset:40                           // 00000011C188: D8D80028 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C190: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011C194: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011C19C: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011C1A0: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011C1A4: 8C7E017E
	v_and_b32_e32 v130, 0x800, v134                            // 00000011C1A8: 37050CFF 00000800
	s_or_b32 s1, s2, 11                                        // 00000011C1B0: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011C1B4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000011C1B8: 7C874401
	.long 0xd44d0001                                           // 00000011C1BC: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011C1C0: 02030480
	s_and_b32 s22, vcc_lo, s1                                  // 00000011C1C4: 8B16016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011C1C8: BF870009
	s_and_saveexec_b32 s1, s22                                 // 00000011C1CC: BE812016
	s_cbranch_execz 7                                          // 00000011C1D0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17f0>
	ds_load_b32 v130, v164 offset:44                           // 00000011C1D4: D8D8002C 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C1DC: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011C1E0: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011C1E8: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011C1EC: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011C1F0: 8C7E017E
	v_and_b32_e32 v130, 0x1000, v134                           // 00000011C1F4: 37050CFF 00001000
	s_or_b32 s1, s2, 12                                        // 00000011C1FC: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011C200: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000011C204: 7C874401
	.long 0xd44d0001                                           // 00000011C208: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011C20C: 02030480
	s_and_b32 s9, vcc_lo, s1                                   // 00000011C210: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011C214: BF870009
	s_and_saveexec_b32 s1, s9                                  // 00000011C218: BE812009
	s_cbranch_execz 7                                          // 00000011C21C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x183c>
	ds_load_b32 v130, v164 offset:48                           // 00000011C220: D8D80030 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C228: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011C22C: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011C234: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011C238: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011C23C: 8C7E017E
	v_and_b32_e32 v130, 0x2000, v134                           // 00000011C240: 37050CFF 00002000
	s_or_b32 s1, s2, 13                                        // 00000011C248: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011C24C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000011C250: 7C874401
	.long 0xd44d0001                                           // 00000011C254: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011C258: 02030480
	s_and_b32 s8, vcc_lo, s1                                   // 00000011C25C: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011C260: BF870009
	s_and_saveexec_b32 s1, s8                                  // 00000011C264: BE812008
	s_cbranch_execz 7                                          // 00000011C268: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1888>
	ds_load_b32 v130, v164 offset:52                           // 00000011C26C: D8D80034 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C274: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011C278: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011C280: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011C284: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011C288: 8C7E017E
	v_and_b32_e32 v130, 0x4000, v134                           // 00000011C28C: 37050CFF 00004000
	s_or_b32 s1, s2, 14                                        // 00000011C294: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011C298: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 00000011C29C: 7C874401
	.long 0xd44d0001                                           // 00000011C2A0: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011C2A4: 02030480
	s_and_b32 s7, vcc_lo, s1                                   // 00000011C2A8: 8B07016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011C2AC: BF870009
	s_and_saveexec_b32 s1, s7                                  // 00000011C2B0: BE812007
	s_cbranch_execz 7                                          // 00000011C2B4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18d4>
	ds_load_b32 v130, v164 offset:56                           // 00000011C2B8: D8D80038 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C2C0: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011C2C4: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011C2CC: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011C2D0: 210B0583
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011C2D4: 8C7E017E
	v_and_b32_e32 v130, 0x8000, v134                           // 00000011C2D8: 37050CFF 00008000
	s_or_b32 s2, s2, 15                                        // 00000011C2E0: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011C2E4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v162                          // 00000011C2E8: 7C874402
	.long 0xd44d0001                                           // 00000011C2EC: D44D0001
	v_cndmask_b32_e32 v1, 0, v130, vcc_lo                      // 00000011C2F0: 02030480
	s_and_b32 s1, vcc_lo, s1                                   // 00000011C2F4: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011C2F8: BF870009
	s_and_saveexec_b32 s2, s1                                  // 00000011C2FC: BE822001
	s_cbranch_execz 7                                          // 00000011C300: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1920>
	ds_load_b32 v130, v164 offset:60                           // 00000011C304: D8D8003C 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C30C: BF89FC07
	v_dual_max_f32 v131, v133, v133 :: v_dual_max_f32 v130, v130, v130// 00000011C310: CA950B85 83830582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011C318: BF870001
	v_max_f32_e32 v133, v131, v130                             // 00000011C31C: 210B0583
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011C320: 8C7E027E
	v_dual_mov_b32 v130, 0 :: v_dual_mov_b32 v131, 0           // 00000011C324: CA100080 82820080
	s_and_saveexec_b32 s2, s35                                 // 00000011C32C: BE822023
	s_cbranch_execz 30                                         // 00000011C330: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19ac>
	ds_load_b32 v131, v164                                     // 00000011C334: D8D80000 830000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C33C: BF89FC07
	v_sub_f32_e32 v131, v131, v133                             // 00000011C340: 09070B83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C344: BF870091
	v_mul_f32_e32 v134, 0x3fb8aa3b, v131                       // 00000011C348: 110D06FF 3FB8AA3B
	v_fma_f32 v135, 0x3fb8aa3b, v131, -v134                    // 00000011C350: D6130087 861B06FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 00000011C35C: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011C360: BF870221
	v_sub_f32_e32 v134, v134, v136                             // 00000011C364: 090D1186
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 00000011C368: 7C3706FF C2CE8ED0
	v_fmac_f32_e32 v135, 0x32a5705f, v131                      // 00000011C370: 570F06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C378: BF870121
	v_add_f32_e32 v134, v134, v135                             // 00000011C37C: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 00000011C380: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 00000011C384: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C388: BF870095
	.long 0xd71c0086                                           // 00000011C38C: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 00000011C390: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 00000011C394: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 00000011C398: 7C3D06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011C3A0: BF870002
	v_cndmask_b32_e32 v131, 0x7f800000, v134, vcc_lo           // 00000011C3A4: 03070CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011C3AC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C3B0: BF870091
	v_bfe_u32 v134, v131, 16, 1                                // 00000011C3B4: D6100086 02052183
	v_add3_u32 v134, v131, v134, 0x7fff                        // 00000011C3BC: D6550086 03FF0D83 00007FFF
	ds_store_b16_d16_hi v165, v134                             // 00000011C3C8: DA840000 000086A5
	s_and_saveexec_b32 s2, s34                                 // 00000011C3D0: BE822022
	s_cbranch_execz 29                                         // 00000011C3D4: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a4c>
	ds_load_b32 v130, v164 offset:4                            // 00000011C3D8: D8D80004 820000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C3E0: BF89FC07
	v_sub_f32_e32 v130, v130, v133                             // 00000011C3E4: 09050B82
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C3E8: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v130                       // 00000011C3EC: 110D04FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 00000011C3F4: 7C3704FF C2CE8ED0
	v_fma_f32 v135, 0x3fb8aa3b, v130, -v134                    // 00000011C3FC: D6130087 861B04FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 00000011C408: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C40C: BF870091
	v_dual_fmac_f32 v135, 0x32a5705f, v130 :: v_dual_sub_f32 v134, v134, v136// 00000011C410: C80B04FF 87871186 32A5705F
	v_add_f32_e32 v134, v134, v135                             // 00000011C41C: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 00000011C420: 7F0E1188
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011C424: BF870292
	v_exp_f32_e32 v134, v134                                   // 00000011C428: 7F0C4B86
	.long 0xd71c0086                                           // 00000011C42C: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 00000011C430: 02030F86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C434: BF870121
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 00000011C438: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 00000011C43C: 7C3D04FF 42B17218
	v_cndmask_b32_e32 v130, 0x7f800000, v134, vcc_lo           // 00000011C444: 03050CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011C44C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C450: BF870121
	v_bfe_u32 v134, v130, 16, 1                                // 00000011C454: D6100086 02052182
	v_mov_b32_e32 v135, 0                                      // 00000011C45C: 7F0E0280
	v_add3_u32 v136, v130, v134, 0x7fff                        // 00000011C460: D6550088 03FF0D82 00007FFF
	v_mov_b32_e32 v134, 0                                      // 00000011C46C: 7F0C0280
	ds_store_b16_d16_hi v165, v136 offset:2                    // 00000011C470: DA840002 000088A5
	s_and_saveexec_b32 s2, s33                                 // 00000011C478: BE822021
	s_cbranch_execz 30                                         // 00000011C47C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1af8>
	ds_load_b32 v135, v164 offset:8                            // 00000011C480: D8D80008 870000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C488: BF89FC07
	v_sub_f32_e32 v135, v135, v133                             // 00000011C48C: 090F0B87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C490: BF870091
	v_mul_f32_e32 v136, 0x3fb8aa3b, v135                       // 00000011C494: 11110EFF 3FB8AA3B
	v_fma_f32 v137, 0x3fb8aa3b, v135, -v136                    // 00000011C49C: D6130089 86230EFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 00000011C4A8: 7F244788
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011C4AC: BF870221
	v_sub_f32_e32 v136, v136, v146                             // 00000011C4B0: 09112588
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 00000011C4B4: 7C370EFF C2CE8ED0
	v_fmac_f32_e32 v137, 0x32a5705f, v135                      // 00000011C4BC: 57130EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C4C4: BF870121
	v_add_f32_e32 v136, v136, v137                             // 00000011C4C8: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 00000011C4CC: 7F121192
	v_exp_f32_e32 v136, v136                                   // 00000011C4D0: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C4D4: BF870095
	.long 0xd71c0088                                           // 00000011C4D8: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 00000011C4DC: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 00000011C4E0: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 00000011C4E4: 7C3D0EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011C4EC: BF870002
	v_cndmask_b32_e32 v135, 0x7f800000, v136, vcc_lo           // 00000011C4F0: 030F10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011C4F8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C4FC: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 00000011C500: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 00000011C508: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v165, v136 offset:4                    // 00000011C514: DA840004 000088A5
	s_and_saveexec_b32 s2, s31                                 // 00000011C51C: BE82201F
	s_cbranch_execz 30                                         // 00000011C520: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b9c>
	ds_load_b32 v134, v164 offset:12                           // 00000011C524: D8D8000C 860000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C52C: BF89FC07
	v_sub_f32_e32 v134, v134, v133                             // 00000011C530: 090D0B86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C534: BF870121
	v_mul_f32_e32 v136, 0x3fb8aa3b, v134                       // 00000011C538: 11110CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 00000011C540: 7C370CFF C2CE8ED0
	v_fma_f32 v137, 0x3fb8aa3b, v134, -v136                    // 00000011C548: D6130089 86230CFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 00000011C554: 7F244788
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011C558: BF870112
	v_fmac_f32_e32 v137, 0x32a5705f, v134                      // 00000011C55C: 57130CFF 32A5705F
	v_sub_f32_e32 v136, v136, v146                             // 00000011C564: 09112588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C568: BF870121
	v_add_f32_e32 v136, v136, v137                             // 00000011C56C: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 00000011C570: 7F121192
	v_exp_f32_e32 v136, v136                                   // 00000011C574: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C578: BF870095
	.long 0xd71c0088                                           // 00000011C57C: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 00000011C580: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 00000011C584: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 00000011C588: 7C3D0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011C590: BF870002
	v_cndmask_b32_e32 v134, 0x7f800000, v136, vcc_lo           // 00000011C594: 030D10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011C59C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C5A0: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 00000011C5A4: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 00000011C5AC: 7F120280
	v_add3_u32 v146, v134, v136, 0x7fff                        // 00000011C5B0: D6550092 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 00000011C5BC: 7F100280
	ds_store_b16_d16_hi v165, v146 offset:6                    // 00000011C5C0: DA840006 000092A5
	s_and_saveexec_b32 s2, s30                                 // 00000011C5C8: BE82201E
	s_cbranch_execz 30                                         // 00000011C5CC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c48>
	ds_load_b32 v137, v164 offset:16                           // 00000011C5D0: D8D80010 890000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C5D8: BF89FC07
	v_sub_f32_e32 v137, v137, v133                             // 00000011C5DC: 09130B89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C5E0: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 00000011C5E4: 112512FF 3FB8AA3B
	v_fma_f32 v147, 0x3fb8aa3b, v137, -v146                    // 00000011C5EC: D6130093 864B12FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 00000011C5F8: 7F284792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011C5FC: BF870221
	v_sub_f32_e32 v146, v146, v148                             // 00000011C600: 09252992
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v137                 // 00000011C604: 7C3712FF C2CE8ED0
	v_fmac_f32_e32 v147, 0x32a5705f, v137                      // 00000011C60C: 572712FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C614: BF870121
	v_add_f32_e32 v146, v146, v147                             // 00000011C618: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 00000011C61C: 7F261194
	v_exp_f32_e32 v146, v146                                   // 00000011C620: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C624: BF870095
	.long 0xd71c0092                                           // 00000011C628: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 00000011C62C: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 00000011C630: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v137                 // 00000011C634: 7C3D12FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011C63C: BF870002
	v_cndmask_b32_e32 v137, 0x7f800000, v146, vcc_lo           // 00000011C640: 031324FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011C648: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C64C: BF870091
	v_bfe_u32 v146, v137, 16, 1                                // 00000011C650: D6100092 02052189
	v_add3_u32 v146, v137, v146, 0x7fff                        // 00000011C658: D6550092 03FF2589 00007FFF
	ds_store_b16_d16_hi v165, v146 offset:8                    // 00000011C664: DA840008 000092A5
	s_and_saveexec_b32 s2, s29                                 // 00000011C66C: BE82201D
	s_cbranch_execz 30                                         // 00000011C670: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1cec>
	ds_load_b32 v136, v164 offset:20                           // 00000011C674: D8D80014 880000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C67C: BF89FC07
	v_sub_f32_e32 v136, v136, v133                             // 00000011C680: 09110B88
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C684: BF870121
	v_mul_f32_e32 v146, 0x3fb8aa3b, v136                       // 00000011C688: 112510FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 00000011C690: 7C3710FF C2CE8ED0
	v_fma_f32 v147, 0x3fb8aa3b, v136, -v146                    // 00000011C698: D6130093 864B10FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 00000011C6A4: 7F284792
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011C6A8: BF870112
	v_fmac_f32_e32 v147, 0x32a5705f, v136                      // 00000011C6AC: 572710FF 32A5705F
	v_sub_f32_e32 v146, v146, v148                             // 00000011C6B4: 09252992
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C6B8: BF870121
	v_add_f32_e32 v146, v146, v147                             // 00000011C6BC: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 00000011C6C0: 7F261194
	v_exp_f32_e32 v146, v146                                   // 00000011C6C4: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C6C8: BF870095
	.long 0xd71c0092                                           // 00000011C6CC: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 00000011C6D0: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 00000011C6D4: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 00000011C6D8: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011C6E0: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v146, vcc_lo           // 00000011C6E4: 031124FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011C6EC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C6F0: BF870121
	v_bfe_u32 v146, v136, 16, 1                                // 00000011C6F4: D6100092 02052188
	v_mov_b32_e32 v147, 0                                      // 00000011C6FC: 7F260280
	v_add3_u32 v148, v136, v146, 0x7fff                        // 00000011C700: D6550094 03FF2588 00007FFF
	v_mov_b32_e32 v146, 0                                      // 00000011C70C: 7F240280
	ds_store_b16_d16_hi v165, v148 offset:10                   // 00000011C710: DA84000A 000094A5
	s_and_saveexec_b32 s2, s28                                 // 00000011C718: BE82201C
	s_cbranch_execz 30                                         // 00000011C71C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d98>
	ds_load_b32 v147, v164 offset:24                           // 00000011C720: D8D80018 930000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C728: BF89FC07
	v_sub_f32_e32 v147, v147, v133                             // 00000011C72C: 09270B93
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C730: BF870091
	v_mul_f32_e32 v148, 0x3fb8aa3b, v147                       // 00000011C734: 112926FF 3FB8AA3B
	v_fma_f32 v149, 0x3fb8aa3b, v147, -v148                    // 00000011C73C: D6130095 865326FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 00000011C748: 7F2C4794
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011C74C: BF870221
	v_sub_f32_e32 v148, v148, v150                             // 00000011C750: 09292D94
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 00000011C754: 7C3726FF C2CE8ED0
	v_fmac_f32_e32 v149, 0x32a5705f, v147                      // 00000011C75C: 572B26FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C764: BF870121
	v_add_f32_e32 v148, v148, v149                             // 00000011C768: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 00000011C76C: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 00000011C770: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C774: BF870095
	.long 0xd71c0094                                           // 00000011C778: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 00000011C77C: 02032B94
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 00000011C780: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 00000011C784: 7C3D26FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011C78C: BF870002
	v_cndmask_b32_e32 v147, 0x7f800000, v148, vcc_lo           // 00000011C790: 032728FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011C798: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C79C: BF870091
	v_bfe_u32 v148, v147, 16, 1                                // 00000011C7A0: D6100094 02052193
	v_add3_u32 v148, v147, v148, 0x7fff                        // 00000011C7A8: D6550094 03FF2993 00007FFF
	ds_store_b16_d16_hi v165, v148 offset:12                   // 00000011C7B4: DA84000C 000094A5
	s_and_saveexec_b32 s2, s27                                 // 00000011C7BC: BE82201B
	s_cbranch_execz 30                                         // 00000011C7C0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e3c>
	ds_load_b32 v146, v164 offset:28                           // 00000011C7C4: D8D8001C 920000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C7CC: BF89FC07
	v_sub_f32_e32 v146, v146, v133                             // 00000011C7D0: 09250B92
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C7D4: BF870121
	v_mul_f32_e32 v148, 0x3fb8aa3b, v146                       // 00000011C7D8: 112924FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 00000011C7E0: 7C3724FF C2CE8ED0
	v_fma_f32 v149, 0x3fb8aa3b, v146, -v148                    // 00000011C7E8: D6130095 865324FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 00000011C7F4: 7F2C4794
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011C7F8: BF870112
	v_fmac_f32_e32 v149, 0x32a5705f, v146                      // 00000011C7FC: 572B24FF 32A5705F
	v_sub_f32_e32 v148, v148, v150                             // 00000011C804: 09292D94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C808: BF870121
	v_add_f32_e32 v148, v148, v149                             // 00000011C80C: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 00000011C810: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 00000011C814: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C818: BF870095
	.long 0xd71c0094                                           // 00000011C81C: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 00000011C820: 02032B94
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 00000011C824: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 00000011C828: 7C3D24FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011C830: BF870002
	v_cndmask_b32_e32 v146, 0x7f800000, v148, vcc_lo           // 00000011C834: 032528FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011C83C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C840: BF870121
	v_bfe_u32 v148, v146, 16, 1                                // 00000011C844: D6100094 02052192
	v_mov_b32_e32 v149, 0                                      // 00000011C84C: 7F2A0280
	v_add3_u32 v150, v146, v148, 0x7fff                        // 00000011C850: D6550096 03FF2992 00007FFF
	v_mov_b32_e32 v148, 0                                      // 00000011C85C: 7F280280
	ds_store_b16_d16_hi v165, v150 offset:14                   // 00000011C860: DA84000E 000096A5
	s_and_saveexec_b32 s2, s26                                 // 00000011C868: BE82201A
	s_cbranch_execz 30                                         // 00000011C86C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ee8>
	ds_load_b32 v149, v164 offset:32                           // 00000011C870: D8D80020 950000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C878: BF89FC07
	v_sub_f32_e32 v149, v149, v133                             // 00000011C87C: 092B0B95
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C880: BF870091
	v_mul_f32_e32 v150, 0x3fb8aa3b, v149                       // 00000011C884: 112D2AFF 3FB8AA3B
	v_fma_f32 v151, 0x3fb8aa3b, v149, -v150                    // 00000011C88C: D6130097 865B2AFF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 00000011C898: 7F304796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011C89C: BF870221
	v_sub_f32_e32 v150, v150, v152                             // 00000011C8A0: 092D3196
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 00000011C8A4: 7C372AFF C2CE8ED0
	v_fmac_f32_e32 v151, 0x32a5705f, v149                      // 00000011C8AC: 572F2AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C8B4: BF870121
	v_add_f32_e32 v150, v150, v151                             // 00000011C8B8: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 00000011C8BC: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 00000011C8C0: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C8C4: BF870095
	.long 0xd71c0096                                           // 00000011C8C8: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 00000011C8CC: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 00000011C8D0: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 00000011C8D4: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011C8DC: BF870002
	v_cndmask_b32_e32 v149, 0x7f800000, v150, vcc_lo           // 00000011C8E0: 032B2CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011C8E8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C8EC: BF870091
	v_bfe_u32 v150, v149, 16, 1                                // 00000011C8F0: D6100096 02052195
	v_add3_u32 v150, v149, v150, 0x7fff                        // 00000011C8F8: D6550096 03FF2D95 00007FFF
	ds_store_b16_d16_hi v165, v150 offset:16                   // 00000011C904: DA840010 000096A5
	s_and_saveexec_b32 s2, s25                                 // 00000011C90C: BE822019
	s_cbranch_execz 30                                         // 00000011C910: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f8c>
	ds_load_b32 v148, v164 offset:36                           // 00000011C914: D8D80024 940000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C91C: BF89FC07
	v_sub_f32_e32 v148, v148, v133                             // 00000011C920: 09290B94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C924: BF870121
	v_mul_f32_e32 v150, 0x3fb8aa3b, v148                       // 00000011C928: 112D28FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 00000011C930: 7C3728FF C2CE8ED0
	v_fma_f32 v151, 0x3fb8aa3b, v148, -v150                    // 00000011C938: D6130097 865B28FF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 00000011C944: 7F304796
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011C948: BF870112
	v_fmac_f32_e32 v151, 0x32a5705f, v148                      // 00000011C94C: 572F28FF 32A5705F
	v_sub_f32_e32 v150, v150, v152                             // 00000011C954: 092D3196
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C958: BF870121
	v_add_f32_e32 v150, v150, v151                             // 00000011C95C: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 00000011C960: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 00000011C964: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C968: BF870095
	.long 0xd71c0096                                           // 00000011C96C: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 00000011C970: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 00000011C974: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 00000011C978: 7C3D28FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011C980: BF870002
	v_cndmask_b32_e32 v148, 0x7f800000, v150, vcc_lo           // 00000011C984: 03292CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011C98C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C990: BF870121
	v_bfe_u32 v150, v148, 16, 1                                // 00000011C994: D6100096 02052194
	v_mov_b32_e32 v151, 0                                      // 00000011C99C: 7F2E0280
	v_add3_u32 v152, v148, v150, 0x7fff                        // 00000011C9A0: D6550098 03FF2D94 00007FFF
	v_mov_b32_e32 v150, 0                                      // 00000011C9AC: 7F2C0280
	ds_store_b16_d16_hi v165, v152 offset:18                   // 00000011C9B0: DA840012 000098A5
	s_and_saveexec_b32 s2, s24                                 // 00000011C9B8: BE822018
	s_cbranch_execz 29                                         // 00000011C9BC: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2034>
	ds_load_b32 v151, v164 offset:40                           // 00000011C9C0: D8D80028 970000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011C9C8: BF89FC07
	v_sub_f32_e32 v151, v151, v133                             // 00000011C9CC: 092F0B97
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011C9D0: BF870121
	v_mul_f32_e32 v152, 0x3fb8aa3b, v151                       // 00000011C9D4: 11312EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 00000011C9DC: 7C372EFF C2CE8ED0
	v_fma_f32 v153, 0x3fb8aa3b, v151, -v152                    // 00000011C9E4: D6130099 86632EFF 3FB8AA3B
	v_rndne_f32_e32 v177, v152                                 // 00000011C9F0: 7F624798
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011C9F4: BF870091
	v_dual_fmac_f32 v153, 0x32a5705f, v151 :: v_dual_sub_f32 v152, v152, v177// 00000011C9F8: C80B2EFF 99996398 32A5705F
	v_add_f32_e32 v152, v152, v153                             // 00000011CA04: 07313398
	v_cvt_i32_f32_e32 v153, v177                               // 00000011CA08: 7F3211B1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011CA0C: BF870292
	v_exp_f32_e32 v152, v152                                   // 00000011CA10: 7F304B98
	.long 0xd71c0098                                           // 00000011CA14: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 00000011CA18: 02033398
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011CA1C: BF870121
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 00000011CA20: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 00000011CA24: 7C3D2EFF 42B17218
	v_cndmask_b32_e32 v151, 0x7f800000, v152, vcc_lo           // 00000011CA2C: 032F30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011CA34: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CA38: BF870091
	v_bfe_u32 v152, v151, 16, 1                                // 00000011CA3C: D6100098 02052197
	v_add3_u32 v152, v151, v152, 0x7fff                        // 00000011CA44: D6550098 03FF3197 00007FFF
	ds_store_b16_d16_hi v165, v152 offset:20                   // 00000011CA50: DA840014 000098A5
	s_and_saveexec_b32 s2, s22                                 // 00000011CA58: BE822016
	s_cbranch_execz 29                                         // 00000011CA5C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x20d4>
	ds_load_b32 v150, v164 offset:44                           // 00000011CA60: D8D8002C 960000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011CA68: BF89FC07
	v_sub_f32_e32 v150, v150, v133                             // 00000011CA6C: 092D0B96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011CA70: BF870121
	v_mul_f32_e32 v152, 0x3fb8aa3b, v150                       // 00000011CA74: 11312CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 00000011CA7C: 7C372CFF C2CE8ED0
	v_fma_f32 v153, 0x3fb8aa3b, v150, -v152                    // 00000011CA84: D6130099 86632CFF 3FB8AA3B
	v_rndne_f32_e32 v177, v152                                 // 00000011CA90: 7F624798
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CA94: BF870091
	v_dual_fmac_f32 v153, 0x32a5705f, v150 :: v_dual_sub_f32 v152, v152, v177// 00000011CA98: C80B2CFF 99996398 32A5705F
	v_add_f32_e32 v152, v152, v153                             // 00000011CAA4: 07313398
	v_cvt_i32_f32_e32 v153, v177                               // 00000011CAA8: 7F3211B1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011CAAC: BF870292
	v_exp_f32_e32 v152, v152                                   // 00000011CAB0: 7F304B98
	.long 0xd71c0098                                           // 00000011CAB4: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 00000011CAB8: 02033398
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011CABC: BF870121
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 00000011CAC0: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 00000011CAC4: 7C3D2CFF 42B17218
	v_cndmask_b32_e32 v150, 0x7f800000, v152, vcc_lo           // 00000011CACC: 032D30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011CAD4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011CAD8: BF870121
	v_bfe_u32 v152, v150, 16, 1                                // 00000011CADC: D6100098 02052196
	v_mov_b32_e32 v153, 0                                      // 00000011CAE4: 7F320280
	v_add3_u32 v177, v150, v152, 0x7fff                        // 00000011CAE8: D65500B1 03FF3196 00007FFF
	v_mov_b32_e32 v152, 0                                      // 00000011CAF4: 7F300280
	ds_store_b16_d16_hi v165, v177 offset:22                   // 00000011CAF8: DA840016 0000B1A5
	s_and_saveexec_b32 s2, s9                                  // 00000011CB00: BE822009
	s_cbranch_execz 29                                         // 00000011CB04: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x217c>
	ds_load_b32 v153, v164 offset:48                           // 00000011CB08: D8D80030 990000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011CB10: BF89FC07
	v_sub_f32_e32 v153, v153, v133                             // 00000011CB14: 09330B99
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011CB18: BF870121
	v_mul_f32_e32 v177, 0x3fb8aa3b, v153                       // 00000011CB1C: 116332FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 00000011CB24: 7C3732FF C2CE8ED0
	v_fma_f32 v178, 0x3fb8aa3b, v153, -v177                    // 00000011CB2C: D61300B2 86C732FF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 00000011CB38: 7F6647B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CB3C: BF870091
	v_dual_fmac_f32 v178, 0x32a5705f, v153 :: v_dual_sub_f32 v177, v177, v179// 00000011CB40: C80B32FF B2B167B1 32A5705F
	v_add_f32_e32 v177, v177, v178                             // 00000011CB4C: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 00000011CB50: 7F6411B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011CB54: BF870292
	v_exp_f32_e32 v177, v177                                   // 00000011CB58: 7F624BB1
	.long 0xd71c00b1                                           // 00000011CB5C: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 00000011CB60: 020365B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011CB64: BF870121
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 00000011CB68: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 00000011CB6C: 7C3D32FF 42B17218
	v_cndmask_b32_e32 v153, 0x7f800000, v177, vcc_lo           // 00000011CB74: 033362FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011CB7C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CB80: BF870091
	v_bfe_u32 v177, v153, 16, 1                                // 00000011CB84: D61000B1 02052199
	v_add3_u32 v177, v153, v177, 0x7fff                        // 00000011CB8C: D65500B1 03FF6399 00007FFF
	ds_store_b16_d16_hi v165, v177 offset:24                   // 00000011CB98: DA840018 0000B1A5
	s_and_saveexec_b32 s2, s8                                  // 00000011CBA0: BE822008
	s_cbranch_execz 30                                         // 00000011CBA4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2220>
	ds_load_b32 v152, v164 offset:52                           // 00000011CBA8: D8D80034 980000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011CBB0: BF89FC07
	v_sub_f32_e32 v152, v152, v133                             // 00000011CBB4: 09310B98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CBB8: BF870091
	v_mul_f32_e32 v177, 0x3fb8aa3b, v152                       // 00000011CBBC: 116330FF 3FB8AA3B
	v_fma_f32 v178, 0x3fb8aa3b, v152, -v177                    // 00000011CBC4: D61300B2 86C730FF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 00000011CBD0: 7F6647B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011CBD4: BF870221
	v_sub_f32_e32 v177, v177, v179                             // 00000011CBD8: 096367B1
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 00000011CBDC: 7C3730FF C2CE8ED0
	v_fmac_f32_e32 v178, 0x32a5705f, v152                      // 00000011CBE4: 576530FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011CBEC: BF870121
	v_add_f32_e32 v177, v177, v178                             // 00000011CBF0: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 00000011CBF4: 7F6411B3
	v_exp_f32_e32 v177, v177                                   // 00000011CBF8: 7F624BB1
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CBFC: BF870095
	.long 0xd71c00b1                                           // 00000011CC00: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 00000011CC04: 020365B1
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 00000011CC08: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 00000011CC0C: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011CC14: BF870002
	v_cndmask_b32_e32 v152, 0x7f800000, v177, vcc_lo           // 00000011CC18: 033162FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011CC20: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011CC24: BF870121
	v_bfe_u32 v177, v152, 16, 1                                // 00000011CC28: D61000B1 02052198
	v_mov_b32_e32 v178, 0                                      // 00000011CC30: 7F640280
	v_add3_u32 v179, v152, v177, 0x7fff                        // 00000011CC34: D65500B3 03FF6398 00007FFF
	v_mov_b32_e32 v177, 0                                      // 00000011CC40: 7F620280
	ds_store_b16_d16_hi v165, v179 offset:26                   // 00000011CC44: DA84001A 0000B3A5
	s_and_saveexec_b32 s2, s7                                  // 00000011CC4C: BE822007
	s_cbranch_execz 29                                         // 00000011CC50: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x22c8>
	ds_load_b32 v178, v164 offset:56                           // 00000011CC54: D8D80038 B20000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011CC5C: BF89FC07
	v_sub_f32_e32 v178, v178, v133                             // 00000011CC60: 09650BB2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CC64: BF870091
	v_mul_f32_e32 v179, 0x3fb8aa3b, v178                       // 00000011CC68: 116764FF 3FB8AA3B
	v_fma_f32 v180, 0x3fb8aa3b, v178, -v179                    // 00000011CC70: D61300B4 86CF64FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 00000011CC7C: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CC80: BF870091
	v_dual_fmac_f32 v180, 0x32a5705f, v178 :: v_dual_sub_f32 v179, v179, v181// 00000011CC84: C80B64FF B4B36BB3 32A5705F
	v_add_f32_e32 v179, v179, v180                             // 00000011CC90: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 00000011CC94: 7F6811B5
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 00000011CC98: 7C3764FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011CCA0: BF870293
	v_exp_f32_e32 v179, v179                                   // 00000011CCA4: 7F664BB3
	.long 0xd71c00b3                                           // 00000011CCA8: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 00000011CCAC: 020369B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011CCB0: BF870121
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 00000011CCB4: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 00000011CCB8: 7C3D64FF 42B17218
	v_cndmask_b32_e32 v178, 0x7f800000, v179, vcc_lo           // 00000011CCC0: 036566FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011CCC8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CCCC: BF870091
	v_bfe_u32 v179, v178, 16, 1                                // 00000011CCD0: D61000B3 020521B2
	v_add3_u32 v179, v178, v179, 0x7fff                        // 00000011CCD8: D65500B3 03FF67B2 00007FFF
	ds_store_b16_d16_hi v165, v179 offset:28                   // 00000011CCE4: DA84001C 0000B3A5
	s_and_saveexec_b32 s2, s1                                  // 00000011CCEC: BE822001
	s_cbranch_execz 30                                         // 00000011CCF0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x236c>
	ds_load_b32 v177, v164 offset:60                           // 00000011CCF4: D8D8003C B10000A4
	s_waitcnt lgkmcnt(0)                                       // 00000011CCFC: BF89FC07
	v_sub_f32_e32 v177, v177, v133                             // 00000011CD00: 09630BB1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011CD04: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v177                       // 00000011CD08: 116762FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v177                 // 00000011CD10: 7C3762FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v177, -v179                    // 00000011CD18: D61300B4 86CF62FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 00000011CD24: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011CD28: BF870112
	v_fmac_f32_e32 v180, 0x32a5705f, v177                      // 00000011CD2C: 576962FF 32A5705F
	v_sub_f32_e32 v179, v179, v181                             // 00000011CD34: 09676BB3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011CD38: BF870121
	v_add_f32_e32 v179, v179, v180                             // 00000011CD3C: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 00000011CD40: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 00000011CD44: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CD48: BF870095
	.long 0xd71c00b3                                           // 00000011CD4C: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 00000011CD50: 020369B3
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 00000011CD54: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v177                 // 00000011CD58: 7C3D62FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011CD60: BF870002
	v_cndmask_b32_e32 v177, 0x7f800000, v179, vcc_lo           // 00000011CD64: 036366FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011CD6C: 8C7E027E
	v_add_f32_e32 v130, v131, v130                             // 00000011CD70: 07050583
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011CD74: BF870122
	v_bfe_u32 v131, v177, 16, 1                                // 00000011CD78: D6100083 020521B1
	s_mov_b32 s1, 0                                            // 00000011CD80: BE810080
	v_add_f32_e32 v130, v130, v135                             // 00000011CD84: 07050F82
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011CD88: BF870112
	v_add3_u32 v131, v177, v131, 0x7fff                        // 00000011CD8C: D6550083 03FF07B1 00007FFF
	v_add_f32_e32 v130, v130, v134                             // 00000011CD98: 07050D82
	ds_store_b16_d16_hi v165, v131 offset:30                   // 00000011CD9C: DA84001E 000083A5
	v_add_f32_e32 v130, v130, v137                             // 00000011CDA4: 07051382
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CDA8: BF870091
	v_add_f32_e32 v130, v130, v136                             // 00000011CDAC: 07051182
	v_add_f32_e32 v130, v130, v147                             // 00000011CDB0: 07052782
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CDB4: BF870091
	v_add_f32_e32 v130, v130, v146                             // 00000011CDB8: 07052582
	v_add_f32_e32 v130, v130, v149                             // 00000011CDBC: 07052B82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CDC0: BF870091
	v_add_f32_e32 v130, v130, v148                             // 00000011CDC4: 07052982
	v_add_f32_e32 v130, v130, v151                             // 00000011CDC8: 07052F82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CDCC: BF870091
	v_add_f32_e32 v130, v130, v150                             // 00000011CDD0: 07052D82
	v_add_f32_e32 v130, v130, v153                             // 00000011CDD4: 07053382
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011CDD8: BF870091
	v_add_f32_e32 v130, v130, v152                             // 00000011CDDC: 07053182
	v_add_f32_e32 v130, v130, v178                             // 00000011CDE0: 07056582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011CDE4: BF870001
	v_add_f32_e32 v130, v130, v177                             // 00000011CDE8: 07056382
	s_and_b32 vcc_lo, exec_lo, s1                              // 00000011CDEC: 8B6A017E
	s_cbranch_vccz 587                                         // 00000011CDF0: BFA3024B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2d20>
	ds_load_2addr_b32 v[135:136], v164 offset1:1               // 00000011CDF4: D8DC0100 870000A4
	ds_load_2addr_b32 v[146:147], v164 offset0:2 offset1:3     // 00000011CDFC: D8DC0302 920000A4
	ds_load_2addr_b32 v[148:149], v164 offset0:4 offset1:5     // 00000011CE04: D8DC0504 940000A4
	ds_load_2addr_b32 v[150:151], v164 offset0:6 offset1:7     // 00000011CE0C: D8DC0706 960000A4
	ds_load_2addr_b32 v[152:153], v164 offset0:8 offset1:9     // 00000011CE14: D8DC0908 980000A4
	ds_load_2addr_b32 v[177:178], v164 offset0:10 offset1:11   // 00000011CE1C: D8DC0B0A B10000A4
	.long 0xd59c4086                                           // 00000011CE24: D59C4086
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 00000011CE28: 02010080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011CE2C: BF8700D1
	.long 0xd59c4889                                           // 00000011CE30: D59C4889
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 00000011CE34: 02010186
	.long 0xd59c48b5                                           // 00000011CE38: D59C48B5
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 00000011CE3C: 02010186
	s_waitcnt lgkmcnt(5)                                       // 00000011CE40: BF89FC57
	v_max3_f32 v130, v132, v135, v136                          // 00000011CE44: D61C0082 06230F84
	s_waitcnt lgkmcnt(4)                                       // 00000011CE4C: BF89FC47
	v_max3_f32 v130, v130, v146, v147                          // 00000011CE50: D61C0082 064F2582
	s_waitcnt lgkmcnt(3)                                       // 00000011CE58: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011CE5C: BF870001
	v_max3_f32 v133, v130, v148, v149                          // 00000011CE60: D61C0085 06572982
	ds_load_2addr_b32 v[179:180], v164 offset0:12 offset1:13   // 00000011CE68: D8DC0D0C B30000A4
	ds_load_2addr_b32 v[130:131], v164 offset0:14 offset1:15   // 00000011CE70: D8DC0F0E 820000A4
	s_waitcnt lgkmcnt(4)                                       // 00000011CE78: BF89FC47
	v_max3_f32 v133, v133, v150, v151                          // 00000011CE7C: D61C0085 065F2D85
	s_waitcnt lgkmcnt(3)                                       // 00000011CE84: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011CE88: BF8700A1
	v_max3_f32 v133, v133, v152, v153                          // 00000011CE8C: D61C0085 06673185
	s_waitcnt lgkmcnt(2)                                       // 00000011CE94: BF89FC27
	v_max3_f32 v133, v133, v177, v178                          // 00000011CE98: D61C0085 06CB6385
	s_waitcnt lgkmcnt(1)                                       // 00000011CEA0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011CEA4: BF8700A1
	v_max3_f32 v133, v133, v179, v180                          // 00000011CEA8: D61C0085 06D36785
	s_waitcnt lgkmcnt(0)                                       // 00000011CEB0: BF89FC07
	v_max3_f32 v133, v133, v130, v131                          // 00000011CEB4: D61C0085 060F0585
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011CEBC: BF870001
	v_sub_f32_e32 v147, v147, v133                             // 00000011CEC0: 09270B93
	v_sub_f32_e32 v135, v135, v133                             // 00000011CEC4: 090F0B87
	v_sub_f32_e32 v146, v146, v133                             // 00000011CEC8: 09250B92
	v_sub_f32_e32 v136, v136, v133                             // 00000011CECC: 09110B88
	v_sub_f32_e32 v150, v150, v133                             // 00000011CED0: 092D0B96
	v_mul_f32_e32 v184, 0x3fb8aa3b, v147                       // 00000011CED4: 117126FF 3FB8AA3B
	v_mul_f32_e32 v182, 0x3fb8aa3b, v135                       // 00000011CEDC: 116D0EFF 3FB8AA3B
	v_dual_sub_f32 v148, v148, v133 :: v_dual_mul_f32 v185, 0x3fb8aa3b, v146// 00000011CEE4: C9470B94 94B924FF 3FB8AA3B
	v_mul_f32_e32 v183, 0x3fb8aa3b, v136                       // 00000011CEF0: 116F10FF 3FB8AA3B
	v_mul_f32_e32 v189, 0x3fb8aa3b, v150                       // 00000011CEF8: 117B2CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000011CF00: BF870004
	v_fma_f32 v190, 0x3fb8aa3b, v135, -v182                    // 00000011CF04: D61300BE 86DB0EFF 3FB8AA3B
	v_rndne_f32_e32 v191, v182                                 // 00000011CF10: 7F7E47B6
	v_sub_f32_e32 v151, v151, v133                             // 00000011CF14: 092F0B97
	v_mul_f32_e32 v187, 0x3fb8aa3b, v148                       // 00000011CF18: 117728FF 3FB8AA3B
	v_fma_f32 v192, 0x3fb8aa3b, v136, -v183                    // 00000011CF20: D61300C0 86DF10FF 3FB8AA3B
	v_rndne_f32_e32 v193, v183                                 // 00000011CF2C: 7F8247B7
	v_fmac_f32_e32 v190, 0x32a5705f, v135                      // 00000011CF30: 577D0EFF 32A5705F
	v_dual_sub_f32 v182, v182, v191 :: v_dual_sub_f32 v149, v149, v133// 00000011CF38: C94B7FB6 B6950B95
	v_mul_f32_e32 v188, 0x3fb8aa3b, v151                       // 00000011CF40: 11792EFF 3FB8AA3B
	v_fma_f32 v194, 0x3fb8aa3b, v147, -v184                    // 00000011CF48: D61300C2 86E326FF 3FB8AA3B
	v_rndne_f32_e32 v197, v185                                 // 00000011CF54: 7F8A47B9
	v_fma_f32 v200, 0x3fb8aa3b, v148, -v187                    // 00000011CF58: D61300C8 86EF28FF 3FB8AA3B
	v_rndne_f32_e32 v201, v187                                 // 00000011CF64: 7F9247BB
	v_dual_fmac_f32 v192, 0x32a5705f, v136 :: v_dual_sub_f32 v183, v183, v193// 00000011CF68: C80B10FF C0B783B7 32A5705F
	v_add_f32_e32 v182, v182, v190                             // 00000011CF74: 076D7DB6
	v_rndne_f32_e32 v195, v184                                 // 00000011CF78: 7F8647B8
	v_fma_f32 v196, 0x3fb8aa3b, v146, -v185                    // 00000011CF7C: D61300C4 86E724FF 3FB8AA3B
	v_dual_fmac_f32 v194, 0x32a5705f, v147 :: v_dual_sub_f32 v187, v187, v201// 00000011CF88: C80B26FF C2BB93BB 32A5705F
	v_sub_f32_e32 v185, v185, v197                             // 00000011CF94: 09738BB9
	v_dual_mul_f32 v186, 0x3fb8aa3b, v149 :: v_dual_add_f32 v183, v183, v192// 00000011CF98: C8C92AFF BAB781B7 3FB8AA3B
	v_fmac_f32_e32 v200, 0x32a5705f, v148                      // 00000011CFA4: 579128FF 32A5705F
	v_exp_f32_e32 v182, v182                                   // 00000011CFAC: 7F6C4BB6
	v_cvt_i32_f32_e32 v191, v191                               // 00000011CFB0: 7F7E11BF
	v_fmac_f32_e32 v196, 0x32a5705f, v146                      // 00000011CFB4: 578924FF 32A5705F
	v_exp_f32_e32 v183, v183                                   // 00000011CFBC: 7F6E4BB7
	v_dual_add_f32 v187, v187, v200 :: v_dual_sub_f32 v184, v184, v195// 00000011CFC0: C90B91BB BBB987B8
	v_fma_f32 v198, 0x3fb8aa3b, v149, -v186                    // 00000011CFC8: D61300C6 86EB2AFF 3FB8AA3B
	v_rndne_f32_e32 v199, v186                                 // 00000011CFD4: 7F8E47BA
	v_cvt_i32_f32_e32 v193, v193                               // 00000011CFD8: 7F8211C1
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000011CFDC: BF870314
	v_dual_add_f32 v185, v185, v196 :: v_dual_add_f32 v184, v184, v194// 00000011CFE0: C90989B9 B9B985B8
	.long 0xd71c00b6                                           // 00000011CFE8: D71C00B6
	v_cndmask_b32_e32 v1, v182, v191, vcc_lo                   // 00000011CFEC: 02037FB6
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 00000011CFF0: 7C370EFF C2CE8ED0
	v_rndne_f32_e32 v205, v189                                 // 00000011CFF8: 7F9A47BD
	v_sub_f32_e32 v186, v186, v199                             // 00000011CFFC: 09758FBA
	v_exp_f32_e32 v184, v184                                   // 00000011D000: 7F704BB8
	.long 0xd71c00b7                                           // 00000011D004: D71C00B7
	v_cndmask_b32_e32 v1, v183, v193, vcc_lo                   // 00000011D008: 020383B7
	v_cndmask_b32_e32 v182, 0, v182, vcc_lo                    // 00000011D00C: 036D6C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 00000011D010: 7C3710FF C2CE8ED0
	v_fmac_f32_e32 v198, 0x32a5705f, v149                      // 00000011D018: 578D2AFF 32A5705F
	v_fma_f32 v204, 0x3fb8aa3b, v150, -v189                    // 00000011D020: D61300CC 86F72CFF 3FB8AA3B
	v_cvt_i32_f32_e32 v195, v195                               // 00000011D02C: 7F8611C3
	v_exp_f32_e32 v185, v185                                   // 00000011D030: 7F724BB9
	v_sub_f32_e32 v189, v189, v205                             // 00000011D034: 097B9BBD
	v_dual_cndmask_b32 v183, 0, v183 :: v_dual_add_f32 v186, v186, v198// 00000011D038: CA496E80 B7BB8DBA
	v_cvt_i32_f32_e32 v197, v197                               // 00000011D040: 7F8A11C5
	.long 0xd71c00b8                                           // 00000011D044: D71C00B8
	v_cndmask_b32_e32 v1, v184, v195, vcc_lo                   // 00000011D048: 020387B8
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 00000011D04C: 7C3726FF C2CE8ED0
	v_cvt_i32_f32_e32 v199, v199                               // 00000011D054: 7F8E11C7
	v_exp_f32_e32 v186, v186                                   // 00000011D058: 7F744BBA
	v_rndne_f32_e32 v203, v188                                 // 00000011D05C: 7F9647BC
	s_delay_alu instid0(TRANS32_DEP_2)                         // 00000011D060: BF870006
	.long 0xd71c00b9                                           // 00000011D064: D71C00B9
	v_cndmask_b32_e32 v1, v185, v197, vcc_lo                   // 00000011D068: 02038BB9
	v_cndmask_b32_e32 v184, 0, v184, vcc_lo                    // 00000011D06C: 03717080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 00000011D070: 7C3724FF C2CE8ED0
	v_fma_f32 v202, 0x3fb8aa3b, v151, -v188                    // 00000011D078: D61300CA 86F32EFF 3FB8AA3B
	v_exp_f32_e32 v187, v187                                   // 00000011D084: 7F764BBB
	v_cvt_i32_f32_e32 v201, v201                               // 00000011D088: 7F9211C9
	v_sub_f32_e32 v179, v179, v133                             // 00000011D08C: 09670BB3
	v_cndmask_b32_e32 v185, 0, v185, vcc_lo                    // 00000011D090: 03737280
	.long 0xd71c00ba                                           // 00000011D094: D71C00BA
	v_cndmask_b32_e32 v1, v186, v199, vcc_lo                   // 00000011D098: 02038FBA
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 00000011D09C: 7C372AFF C2CE8ED0
	v_sub_f32_e32 v130, v130, v133                             // 00000011D0A4: 09050B82
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000011D0A8: BF8702A3
	v_dual_sub_f32 v153, v153, v133 :: v_dual_cndmask_b32 v186, 0, v186// 00000011D0AC: C9530B99 99BB7480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 00000011D0B4: 7C3D10FF 42B17218
	.long 0xd71c00bb                                           // 00000011D0BC: D71C00BB
	v_cndmask_b32_e32 v1, v187, v201, vcc_lo                   // 00000011D0C0: 020393BB
	v_cndmask_b32_e32 v136, 0x7f800000, v183, vcc_lo           // 00000011D0C4: 03116EFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 00000011D0CC: 7C3D0EFF 42B17218
	v_dual_sub_f32 v188, v188, v203 :: v_dual_cndmask_b32 v135, 0x7f800000, v182// 00000011D0D4: C95397BC BC876CFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 00000011D0E0: 7C3D24FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000011D0E8: BF8701C2
	v_add_f32_e32 v146, v135, v136                             // 00000011D0EC: 07251187
	v_cndmask_b32_e32 v182, 0x7f800000, v185, vcc_lo           // 00000011D0F0: 036D72FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 00000011D0F8: 7C3D26FF 42B17218
	.long 0xd59c0889                                           // 00000011D100: D59C0889
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 00000011D104: 02010187
	.long 0xd59c08b5                                           // 00000011D108: D59C08B5
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                   // 00000011D10C: 020101B6
	v_cndmask_b32_e32 v183, 0x7f800000, v184, vcc_lo           // 00000011D110: 036F70FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 00000011D118: 7C3728FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000011D120: BF870214
	v_and_b32_e32 v137, 1, v137                                // 00000011D124: 37131281
	v_dual_cndmask_b32 v184, 0, v187 :: v_dual_and_b32 v181, 1, v181// 00000011D128: CA657680 B8B56A81
	v_add_f32_e32 v187, v146, v182                             // 00000011D130: 07776D92
	.long 0xd59c0886                                           // 00000011D134: D59C0886
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 00000011D138: 02010188
	v_fmac_f32_e32 v202, 0x32a5705f, v151                      // 00000011D13C: 57952EFF 32A5705F
	v_fmac_f32_e32 v204, 0x32a5705f, v150                      // 00000011D144: 57992CFF 32A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 00000011D14C: 7C3D28FF 42B17218
	v_add3_u32 v135, v135, v137, 0x7fff                        // 00000011D154: D6550087 03FF1387 00007FFF
	v_and_b32_e32 v147, 1, v134                                // 00000011D160: 37270C81
	.long 0xd59c0886                                           // 00000011D164: D59C0886
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                   // 00000011D168: 020101B7
	v_dual_add_f32 v148, v188, v202 :: v_dual_cndmask_b32 v137, 0x7f800000, v184// 00000011D16C: C91395BC 948970FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 00000011D178: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000011D180: BF870214
	v_add3_u32 v146, v136, v147, 0x7fff                        // 00000011D184: D6550092 03FF2788 00007FFF
	v_and_b32_e32 v185, 1, v134                                // 00000011D190: 37730C81
	v_add3_u32 v136, v182, v181, 0x7fff                        // 00000011D194: D6550088 03FF6BB6 00007FFF
	v_exp_f32_e32 v148, v148                                   // 00000011D1A0: 7F284B94
	.long 0xd59c08b6                                           // 00000011D1A4: D59C08B6
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 00000011D1A8: 02010189
	.long 0xd59c48b6                                           // 00000011D1AC: D59C48B6
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 00000011D1B0: 02010186
	v_add3_u32 v147, v183, v185, 0x7fff                        // 00000011D1B4: D6550093 03FF73B7 00007FFF
	v_add_f32_e32 v183, v187, v183                             // 00000011D1C0: 076F6FBB
	v_add_f32_e32 v181, v189, v204                             // 00000011D1C4: 076B99BD
	v_cndmask_b32_e32 v149, 0x7f800000, v186, vcc_lo           // 00000011D1C8: 032B74FF 7F800000
	v_cvt_i32_f32_e32 v184, v203                               // 00000011D1D0: 7F7011CB
	v_cvt_i32_f32_e32 v186, v205                               // 00000011D1D4: 7F7411CD
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 00000011D1D8: 7C372EFF C2CE8ED0
	v_exp_f32_e32 v181, v181                                   // 00000011D1E0: 7F6A4BB5
	.long 0xd59c0886                                           // 00000011D1E4: D59C0886
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                   // 00000011D1E8: 02010195
	.long 0xd71c00b8                                           // 00000011D1EC: D71C00B8
	v_cndmask_b32_e32 v1, v148, v184, vcc_lo                   // 00000011D1F0: 02037194
	v_add_f32_e32 v183, v183, v137                             // 00000011D1F4: 076F13B7
	.long 0xd59c0893                                           // 00000011D1F8: D59C0893
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 00000011D1FC: 02010188
	.long 0xd59c0892                                           // 00000011D200: D59C0892
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 00000011D204: 02010187
	v_and_b32_e32 v185, 1, v134                                // 00000011D208: 37730C81
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000011D20C: BF8701A5
	.long 0xd71c00b5                                           // 00000011D210: D71C00B5
	v_cndmask_b32_e32 v1, v181, v186, vcc_lo                   // 00000011D214: 020375B5
	v_and_b32_e32 v182, 1, v182                                // 00000011D218: 376D6C81
	v_add3_u32 v148, v149, v185, 0x7fff                        // 00000011D21C: D6550094 03FF7395 00007FFF
	v_add_f32_e32 v149, v183, v149                             // 00000011D228: 072B2BB7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000011D22C: BF870243
	v_add3_u32 v137, v137, v182, 0x7fff                        // 00000011D230: D6550089 03FF6D89 00007FFF
	v_cndmask_b32_e32 v182, 0, v184, vcc_lo                    // 00000011D23C: 036D7080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 00000011D240: 7C372CFF C2CE8ED0
	.long 0xd59c48b8                                           // 00000011D248: D59C48B8
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 00000011D24C: 02010186
	.long 0xd59c0894                                           // 00000011D250: D59C0894
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 00000011D254: 02010189
	v_cndmask_b32_e32 v181, 0, v181, vcc_lo                    // 00000011D258: 036B6A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 00000011D25C: 7C3D2EFF 42B17218
	v_cndmask_b32_e32 v151, 0x7f800000, v182, vcc_lo           // 00000011D264: 032F6CFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 00000011D26C: 7C3D2CFF 42B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011D274: BF870194
	v_cndmask_b32_e32 v150, 0x7f800000, v181, vcc_lo           // 00000011D278: 032D6AFF 7F800000
	.long 0xd59c0886                                           // 00000011D280: D59C0886
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 00000011D284: 02010197
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 00000011D288: 7C3732FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011D290: BF870123
	.long 0xd59c08b8                                           // 00000011D294: D59C08B8
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                   // 00000011D298: 02010196
	v_sub_f32_e32 v152, v152, v133                             // 00000011D29C: 09310B98
	v_dual_add_f32 v186, v149, v150 :: v_dual_and_b32 v149, 1, v184// 00000011D2A0: C9252D95 BA957081
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000011D2A8: BF8701A2
	v_dual_mul_f32 v182, 0x3fb8aa3b, v153 :: v_dual_mul_f32 v185, 0x3fb8aa3b, v152// 00000011D2AC: C8C732FF B6B930FF 3FB8AA3B
	v_and_b32_e32 v184, 1, v134                                // 00000011D2B8: 37710C81
	v_add3_u32 v150, v150, v149, 0x7fff                        // 00000011D2BC: D6550096 03FF2B96 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000011D2C8: BF870253
	v_fma_f32 v181, 0x3fb8aa3b, v153, -v182                    // 00000011D2CC: D61300B5 86DB32FF 3FB8AA3B
	v_rndne_f32_e32 v183, v182                                 // 00000011D2D8: 7F6E47B6
	v_rndne_f32_e32 v187, v185                                 // 00000011D2DC: 7F7647B9
	v_add3_u32 v149, v151, v184, 0x7fff                        // 00000011D2E0: D6550095 03FF7197 00007FFF
	.long 0xd59c0895                                           // 00000011D2EC: D59C0895
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                   // 00000011D2F0: 02010196
	v_dual_fmac_f32 v181, 0x32a5705f, v153 :: v_dual_sub_f32 v182, v182, v183// 00000011D2F4: C80B32FF B5B76FB6 32A5705F
	v_cvt_i32_f32_e32 v136, v183                               // 00000011D300: 7F1011B7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000011D304: BF8701B2
	v_add_f32_e32 v181, v182, v181                             // 00000011D308: 076B6BB6
	v_fma_f32 v182, 0x3fb8aa3b, v152, -v185                    // 00000011D30C: D61300B6 86E730FF 3FB8AA3B
	v_add_f32_e32 v151, v186, v151                             // 00000011D318: 072F2FBA
	v_exp_f32_e32 v181, v181                                   // 00000011D31C: 7F6A4BB5
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011D320: BF870195
	.long 0xd71c0087                                           // 00000011D324: D71C0087
	v_cndmask_b32_e32 v1, v181, v136, vcc_lo                   // 00000011D328: 020311B5
	v_fmac_f32_e32 v182, 0x32a5705f, v152                      // 00000011D32C: 576D30FF 32A5705F
	v_cvt_i32_f32_e32 v181, v187                               // 00000011D334: 7F6A11BB
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000011D338: BF870133
	v_dual_cndmask_b32 v135, 0, v135 :: v_dual_sub_f32 v150, v177, v133// 00000011D33C: CA4B0E80 87970BB1
	v_dual_sub_f32 v184, v185, v187 :: v_dual_sub_f32 v177, v178, v133// 00000011D344: C94B77B9 B8B10BB2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 00000011D34C: 7C3730FF C2CE8ED0
	v_dual_add_f32 v137, v184, v182 :: v_dual_mul_f32 v178, 0x3fb8aa3b, v177// 00000011D354: C9076DB8 89B362FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011D360: BF870091
	v_exp_f32_e32 v136, v137                                   // 00000011D364: 7F104B89
	v_fma_f32 v184, 0x3fb8aa3b, v177, -v178                    // 00000011D368: D61300B8 86CB62FF 3FB8AA3B
	v_rndne_f32_e32 v185, v178                                 // 00000011D374: 7F7247B2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011D378: BF870115
	.long 0xd71c0088                                           // 00000011D37C: D71C0088
	v_cndmask_b32_e32 v1, v136, v181, vcc_lo                   // 00000011D380: 02036B88
	v_cvt_i32_f32_e32 v181, v185                               // 00000011D384: 7F6A11B9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000011D388: BF8701D2
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 00000011D38C: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 00000011D390: 7C3D32FF 42B17218
	v_cndmask_b32_e32 v135, 0x7f800000, v135, vcc_lo           // 00000011D398: 030F0EFF 7F800000
	v_mul_f32_e32 v137, 0x3fb8aa3b, v150                       // 00000011D3A0: 11132CFF 3FB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 00000011D3A8: 7C3D30FF 42B17218
	.long 0xd59c0886                                           // 00000011D3B0: D59C0886
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 00000011D3B4: 02010187
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000011D3B8: BF870253
	v_fma_f32 v182, 0x3fb8aa3b, v150, -v137                    // 00000011D3BC: D61300B6 86272CFF 3FB8AA3B
	v_rndne_f32_e32 v183, v137                                 // 00000011D3C8: 7F6E4789
	v_cndmask_b32_e32 v136, 0x7f800000, v136, vcc_lo           // 00000011D3CC: 031110FF 7F800000
	v_sub_f32_e32 v178, v178, v185                             // 00000011D3D4: 096573B2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 00000011D3D8: 7C372CFF C2CE8ED0
	v_dual_fmac_f32 v182, 0x32a5705f, v150 :: v_dual_sub_f32 v137, v137, v183// 00000011D3E0: C80B2CFF B6896F89 32A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011D3EC: BF870114
	v_dual_fmac_f32 v184, 0x32a5705f, v177 :: v_dual_add_f32 v151, v151, v136// 00000011D3F0: C80962FF B8971197 32A5705F
	v_add_f32_e32 v137, v137, v182                             // 00000011D3FC: 07136D89
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000011D400: BF870232
	v_dual_add_f32 v153, v178, v184 :: v_dual_and_b32 v182, 1, v134// 00000011D404: C92571B2 99B70C81
	v_cvt_i32_f32_e32 v178, v183                               // 00000011D40C: 7F6411B7
	v_mul_f32_e32 v184, 0x3fb8aa3b, v130                       // 00000011D410: 117104FF 3FB8AA3B
	v_exp_f32_e32 v137, v137                                   // 00000011D418: 7F124B89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000011D41C: BF870153
	v_exp_f32_e32 v152, v153                                   // 00000011D420: 7F304B99
	.long 0xd59c0899                                           // 00000011D424: D59C0899
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 00000011D428: 02010188
	.long 0xd59c4899                                           // 00000011D42C: D59C4899
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 00000011D430: 02010186
	v_fma_f32 v186, 0x3fb8aa3b, v130, -v184                    // 00000011D434: D61300BA 86E304FF 3FB8AA3B
	v_rndne_f32_e32 v187, v184                                 // 00000011D440: 7F7647B8
	v_dual_fmac_f32 v186, 0x32a5705f, v130 :: v_dual_and_b32 v153, 1, v153// 00000011D444: C82504FF BA993281 32A5705F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011D450: BF870296
	.long 0xd71c0089                                           // 00000011D454: D71C0089
	v_cndmask_b32_e32 v1, v137, v178, vcc_lo                   // 00000011D458: 02036589
	.long 0xd71c0098                                           // 00000011D45C: D71C0098
	v_cndmask_b32_e32 v1, v152, v181, vcc_lo                   // 00000011D460: 02036B98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011D464: BF870193
	v_add3_u32 v136, v136, v153, 0x7fff                        // 00000011D468: D6550088 03FF3388 00007FFF
	v_cndmask_b32_e32 v137, 0, v137, vcc_lo                    // 00000011D474: 03131280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v177                 // 00000011D478: 7C3762FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 00000011D480: BF870004
	v_dual_add_f32 v151, v151, v135 :: v_dual_cndmask_b32 v152, 0, v152// 00000011D484: C9130F97 97993080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 00000011D48C: 7C3D2CFF 42B17218
	v_add3_u32 v150, v135, v182, 0x7fff                        // 00000011D494: D6550096 03FF6D87 00007FFF
	v_mul_f32_e32 v182, 0x3fb8aa3b, v179                       // 00000011D4A0: 116D66FF 3FB8AA3B
	.long 0xd59c0896                                           // 00000011D4A8: D59C0896
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 00000011D4AC: 02010188
	v_cndmask_b32_e32 v137, 0x7f800000, v137, vcc_lo           // 00000011D4B0: 031312FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v177                 // 00000011D4B8: 7C3D62FF 42B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011D4C0: BF8700A4
	v_rndne_f32_e32 v183, v182                                 // 00000011D4C4: 7F6E47B6
	v_cndmask_b32_e32 v152, 0x7f800000, v152, vcc_lo           // 00000011D4C8: 033130FF 7F800000
	.long 0xd59c0886                                           // 00000011D4D0: D59C0886
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 00000011D4D4: 02010198
	v_sub_f32_e32 v178, v180, v133                             // 00000011D4D8: 09650BB4
	.long 0xd59c08b4                                           // 00000011D4DC: D59C08B4
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 00000011D4E0: 02010189
	.long 0xd59c48b4                                           // 00000011D4E4: D59C48B4
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 00000011D4E8: 02010186
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000011D4EC: BF870214
	v_and_b32_e32 v181, 1, v134                                // 00000011D4F0: 376B0C81
	v_mul_f32_e32 v177, 0x3fb8aa3b, v178                       // 00000011D4F4: 116364FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 00000011D4FC: 7C3764FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011D504: BF870194
	v_dual_add_f32 v135, v151, v137 :: v_dual_and_b32 v180, 1, v180// 00000011D508: C9251397 87B56881
	v_fma_f32 v151, 0x3fb8aa3b, v178, -v177                    // 00000011D510: D6130097 86C764FF 3FB8AA3B
	v_rndne_f32_e32 v153, v177                                 // 00000011D51C: 7F3247B1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011D520: BF870193
	v_add3_u32 v137, v137, v180, 0x7fff                        // 00000011D524: D6550089 03FF6989 00007FFF
	v_fmac_f32_e32 v151, 0x32a5705f, v178                      // 00000011D530: 572F64FF 32A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011D538: BF870123
	v_sub_f32_e32 v177, v177, v153                             // 00000011D53C: 096333B1
	v_cvt_i32_f32_e32 v153, v153                               // 00000011D540: 7F321199
	v_add_f32_e32 v151, v177, v151                             // 00000011D544: 072F2FB1
	v_fma_f32 v177, 0x3fb8aa3b, v179, -v182                    // 00000011D548: D61300B1 86DB66FF 3FB8AA3B
	v_sub_f32_e32 v182, v182, v183                             // 00000011D554: 096D6FB6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011D558: BF870113
	v_exp_f32_e32 v151, v151                                   // 00000011D55C: 7F2E4B97
	v_fmac_f32_e32 v177, 0x32a5705f, v179                      // 00000011D560: 576366FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000011D568: BF8702A1
	v_dual_add_f32 v177, v182, v177 :: v_dual_sub_f32 v182, v184, v187// 00000011D56C: C90B63B6 B1B777B8
	v_sub_f32_e32 v131, v131, v133                             // 00000011D574: 09070B83
	.long 0xd71c0097                                           // 00000011D578: D71C0097
	v_cndmask_b32_e32 v1, v151, v153, vcc_lo                   // 00000011D57C: 02033397
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011D580: BF870112
	v_dual_add_f32 v180, v182, v186 :: v_dual_mul_f32 v185, 0x3fb8aa3b, v131// 00000011D584: C90775B6 B4B906FF 3FB8AA3B
	v_cndmask_b32_e32 v151, 0, v151, vcc_lo                    // 00000011D590: 032F2E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 00000011D594: 7C3D64FF 42B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011D59C: BF870193
	v_exp_f32_e32 v153, v180                                   // 00000011D5A0: 7F324BB4
	v_fma_f32 v188, 0x3fb8aa3b, v131, -v185                    // 00000011D5A4: D61300BC 86E706FF 3FB8AA3B
	v_rndne_f32_e32 v189, v185                                 // 00000011D5B0: 7F7A47B9
	v_cvt_i32_f32_e32 v180, v183                               // 00000011D5B4: 7F6811B7
	v_dual_add_f32 v135, v135, v152 :: v_dual_cndmask_b32 v178, 0x7f800000, v151// 00000011D5B8: C9133187 87B32EFF 7F800000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000011D5C4: BF870004
	v_fmac_f32_e32 v188, 0x32a5705f, v131                      // 00000011D5C8: 577906FF 32A5705F
	v_exp_f32_e32 v177, v177                                   // 00000011D5D0: 7F624BB1
	v_sub_f32_e32 v184, v185, v189                             // 00000011D5D4: 09717BB9
	v_cvt_i32_f32_e32 v183, v187                               // 00000011D5D8: 7F6E11BB
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v179                 // 00000011D5DC: 7C3766FF C2CE8ED0
	.long 0xd59c0886                                           // 00000011D5E4: D59C0886
	v_cndmask_b32_e32 v0, v178, v128, vcc_lo                   // 00000011D5E8: 020101B2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000011D5EC: BF870214
	v_add_f32_e32 v182, v184, v188                             // 00000011D5F0: 076D79B8
	.long 0xd71c0097                                           // 00000011D5F4: D71C0097
	v_cndmask_b32_e32 v1, v153, v183, vcc_lo                   // 00000011D5F8: 02036F99
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011D5FC: BF870195
	.long 0xd71c00b1                                           // 00000011D600: D71C00B1
	v_cndmask_b32_e32 v1, v177, v180, vcc_lo                   // 00000011D604: 020369B1
	v_exp_f32_e32 v182, v182                                   // 00000011D608: 7F6C4BB6
	v_cvt_i32_f32_e32 v180, v189                               // 00000011D60C: 7F6811BD
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 00000011D610: BF8702C2
	v_cndmask_b32_e32 v153, 0, v177, vcc_lo                    // 00000011D614: 03336280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 00000011D618: 7C3704FF C2CE8ED0
	v_cndmask_b32_e32 v151, 0, v151, vcc_lo                    // 00000011D620: 032F2E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v179                 // 00000011D624: 7C3D66FF 42B17218
	.long 0xd71c00b1                                           // 00000011D62C: D71C00B1
	v_cndmask_b32_e32 v1, v182, v180, vcc_lo                   // 00000011D630: 020369B6
	v_and_b32_e32 v179, 1, v134                                // 00000011D634: 37670C81
	v_cndmask_b32_e32 v153, 0x7f800000, v153, vcc_lo           // 00000011D638: 033332FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 00000011D640: 7C3706FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 00000011D648: BF870004
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 00000011D64C: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 00000011D650: 7C3D04FF 42B17218
	v_cndmask_b32_e32 v130, 0x7f800000, v151, vcc_lo           // 00000011D658: 03052EFF 7F800000
	.long 0xd59c0897                                           // 00000011D660: D59C0897
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                   // 00000011D664: 02010199
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 00000011D668: 7C3D06FF 42B17218
	.long 0xd59c4897                                           // 00000011D670: D59C4897
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 00000011D674: 02010186
	v_cndmask_b32_e32 v131, 0x7f800000, v177, vcc_lo           // 00000011D678: 030762FF 7F800000
	.long 0xd59c08b1                                           // 00000011D680: D59C08B1
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                   // 00000011D684: 02010182
	.long 0xd59c48b1                                           // 00000011D688: D59C48B1
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 00000011D68C: 02010186
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000011D690: BF870214
	v_dual_add_f32 v135, v135, v153 :: v_dual_and_b32 v180, 1, v151// 00000011D694: C9253387 87B52E81
	.long 0xd59c0886                                           // 00000011D69C: D59C0886
	v_cndmask_b32_e32 v0, v131, v128, vcc_lo                   // 00000011D6A0: 02010183
	v_add3_u32 v151, v152, v181, 0x7fff                        // 00000011D6A4: D6550097 03FF6B98 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000011D6B0: BF870214
	v_and_b32_e32 v177, 1, v177                                // 00000011D6B4: 37636281
	v_add3_u32 v180, v153, v180, 0x7fff                        // 00000011D6B8: D65500B4 03FF6999 00007FFF
	v_add_f32_e32 v135, v135, v178                             // 00000011D6C4: 070F6587
	v_and_b32_e32 v134, 1, v134                                // 00000011D6C8: 370D0C81
	v_add3_u32 v152, v178, v179, 0x7fff                        // 00000011D6CC: D6550098 03FF67B2 00007FFF
	v_add3_u32 v177, v130, v177, 0x7fff                        // 00000011D6D8: D65500B1 03FF6382 00007FFF
	.long 0xd59c0898                                           // 00000011D6E4: D59C0898
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                   // 00000011D6E8: 020101B4
	v_add_f32_e32 v130, v135, v130                             // 00000011D6EC: 07050587
	v_add3_u32 v153, v131, v134, 0x7fff                        // 00000011D6F0: D6550099 03FF0D83 00007FFF
	.long 0xd59c0897                                           // 00000011D6FC: D59C0897
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 00000011D700: 02010189
	.long 0xd59c0899                                           // 00000011D704: D59C0899
	v_cndmask_b32_e32 v0, v177, v128, vcc_lo                   // 00000011D708: 020101B1
	ds_store_b128 v165, v[146:149]                             // 00000011D70C: DB7C0000 000092A5
	ds_store_b128 v165, v[150:153] offset:16                   // 00000011D714: DB7C0010 000096A5
	v_add_f32_e32 v130, v130, v131                             // 00000011D71C: 07050782
	v_mov_b32_e32 v131, 0                                      // 00000011D720: 7F060280
	s_mov_b32 s1, exec_lo                                      // 00000011D724: BE81007E
	s_waitcnt lgkmcnt(0)                                       // 00000011D728: BF89FC07
	v_cmpx_lt_f32_e32 0xefa18f08, v132                         // 00000011D72C: 7D2308FF EFA18F08
	s_cbranch_execz 27                                         // 00000011D734: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2da4>
	v_sub_f32_e32 v131, v132, v133                             // 00000011D738: 09070B84
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011D73C: BF870121
	v_mul_f32_e32 v132, 0x3fb8aa3b, v131                       // 00000011D740: 110906FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 00000011D748: 7C3706FF C2CE8ED0
	v_fma_f32 v134, 0x3fb8aa3b, v131, -v132                    // 00000011D750: D6130086 861306FF 3FB8AA3B
	v_rndne_f32_e32 v135, v132                                 // 00000011D75C: 7F0E4784
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011D760: BF870112
	v_fmac_f32_e32 v134, 0x32a5705f, v131                      // 00000011D764: 570D06FF 32A5705F
	v_sub_f32_e32 v132, v132, v135                             // 00000011D76C: 09090F84
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011D770: BF870121
	v_add_f32_e32 v132, v132, v134                             // 00000011D774: 07090D84
	v_cvt_i32_f32_e32 v134, v135                               // 00000011D778: 7F0C1187
	v_exp_f32_e32 v132, v132                                   // 00000011D77C: 7F084B84
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011D780: BF870095
	.long 0xd71c0084                                           // 00000011D784: D71C0084
	v_cndmask_b32_e32 v1, v132, v134, vcc_lo                   // 00000011D788: 02030D84
	v_cndmask_b32_e32 v132, 0, v132, vcc_lo                    // 00000011D78C: 03090880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 00000011D790: 7C3D06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011D798: BF870002
	v_cndmask_b32_e32 v131, 0x7f800000, v132, vcc_lo           // 00000011D79C: 030708FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011D7A4: 8C7E017E
	ds_load_b32 v132, v0                                       // 00000011D7A8: D8D80000 84000000
	s_waitcnt lgkmcnt(0)                                       // 00000011D7B0: BF89FC07
	v_fmac_f32_e32 v130, v131, v132                            // 00000011D7B4: 57050983
	ds_store_b32 v163, v133                                    // 00000011D7B8: D8340000 000085A3
	ds_store_b32 v0, v130                                      // 00000011D7C0: D8340000 00008200
	ds_store_b32 v166, v131                                    // 00000011D7C8: D8340000 000083A6
	s_or_b32 exec_lo, exec_lo, s4                              // 00000011D7D0: 8C7E047E
	ds_load_2addr_b32 v[152:153], v167 offset1:2               // 00000011D7D4: D8DC0200 980000A7
	ds_load_2addr_b32 v[150:151], v167 offset0:4 offset1:6     // 00000011D7DC: D8DC0604 960000A7
	ds_load_2addr_b32 v[148:149], v167 offset0:8 offset1:10    // 00000011D7E4: D8DC0A08 940000A7
	ds_load_2addr_b32 v[146:147], v167 offset0:12 offset1:14   // 00000011D7EC: D8DC0E0C 920000A7
	s_waitcnt lgkmcnt(3)                                       // 00000011D7F4: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v152                         // 00000011D7F8: 7C2530F2
	.long 0xd4120001                                           // 00000011D7FC: D4120001
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 00000011D800: 020332F2
	s_waitcnt lgkmcnt(2)                                       // 00000011D804: BF89FC27
	.long 0xd4120002                                           // 00000011D808: D4120002
	v_cndmask_b32_e32 v1, 1.0, v150, vcc_lo                    // 00000011D80C: 02032CF2
	.long 0xd4120004                                           // 00000011D810: D4120004
	v_cndmask_b32_e32 v1, 1.0, v151, vcc_lo                    // 00000011D814: 02032EF2
	s_and_b32 s1, vcc_lo, s1                                   // 00000011D818: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 00000011D81C: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v148                         // 00000011D820: 7C2528F2
	s_and_b32 s2, s1, s2                                       // 00000011D824: 8B020201
	.long 0xd4120001                                           // 00000011D828: D4120001
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 00000011D82C: 02032AF2
	s_and_b32 s4, s2, s4                                       // 00000011D830: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 00000011D834: BF89FC07
	.long 0xd4120002                                           // 00000011D838: D4120002
	v_cndmask_b32_e32 v1, 1.0, v146, vcc_lo                    // 00000011D83C: 020324F2
	s_and_b32 s4, s4, vcc_lo                                   // 00000011D840: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v147                         // 00000011D844: 7C2526F2
	s_and_b32 s1, s4, s1                                       // 00000011D848: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000011D84C: BF870499
	s_and_b32 s1, s1, s2                                       // 00000011D850: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 00000011D854: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011D858: BF870099
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 00000011D85C: D5010082 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v130                           // 00000011D864: 7C9B0480
	ds_load_b128 v[130:133], v168                              // 00000011D868: DBFC0000 820000A8
	ds_load_b128 v[134:137], v168 offset:16                    // 00000011D870: DBFC0010 860000A8
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 00000011D878: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 00000011D87C: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011D880: BF870099
	v_cndmask_b32_e64 v177, 0, 1, s1                           // 00000011D884: D50100B1 00050280
	v_readfirstlane_b32 s1, v177                               // 00000011D88C: 7E0205B1
	s_bitcmp1_b32 s1, 0                                        // 00000011D890: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 00000011D894: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011D898: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 00000011D89C: 8B6A017E
	s_cbranch_vccnz 63028                                      // 00000011D8A0: BFA4F634 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x774>
	v_dual_mul_f32 v121, v152, v121 :: v_dual_mul_f32 v122, v153, v122// 00000011D8A4: C8C6F398 797AF599
	v_dual_mul_f32 v123, v150, v123 :: v_dual_mul_f32 v124, v151, v124// 00000011D8AC: C8C6F796 7B7CF997
	v_dual_mul_f32 v125, v148, v125 :: v_dual_mul_f32 v126, v149, v126// 00000011D8B4: C8C6FB94 7D7EFD95
	v_dual_mul_f32 v127, v146, v127 :: v_dual_mul_f32 v128, v147, v128// 00000011D8BC: C8C6FF92 7F810193
	v_dual_mul_f32 v113, v152, v113 :: v_dual_mul_f32 v114, v153, v114// 00000011D8C4: C8C6E398 7172E599
	v_dual_mul_f32 v115, v150, v115 :: v_dual_mul_f32 v116, v151, v116// 00000011D8CC: C8C6E796 7374E997
	v_dual_mul_f32 v117, v148, v117 :: v_dual_mul_f32 v118, v149, v118// 00000011D8D4: C8C6EB94 7576ED95
	v_dual_mul_f32 v119, v146, v119 :: v_dual_mul_f32 v120, v147, v120// 00000011D8DC: C8C6EF92 7778F193
	v_dual_mul_f32 v105, v152, v105 :: v_dual_mul_f32 v106, v153, v106// 00000011D8E4: C8C6D398 696AD599
	v_dual_mul_f32 v107, v150, v107 :: v_dual_mul_f32 v108, v151, v108// 00000011D8EC: C8C6D796 6B6CD997
	v_dual_mul_f32 v109, v148, v109 :: v_dual_mul_f32 v110, v149, v110// 00000011D8F4: C8C6DB94 6D6EDD95
	v_dual_mul_f32 v111, v146, v111 :: v_dual_mul_f32 v112, v147, v112// 00000011D8FC: C8C6DF92 6F70E193
	v_dual_mul_f32 v97, v152, v97 :: v_dual_mul_f32 v98, v153, v98// 00000011D904: C8C6C398 6162C599
	v_dual_mul_f32 v99, v150, v99 :: v_dual_mul_f32 v100, v151, v100// 00000011D90C: C8C6C796 6364C997
	v_dual_mul_f32 v101, v148, v101 :: v_dual_mul_f32 v102, v149, v102// 00000011D914: C8C6CB94 6566CD95
	v_dual_mul_f32 v103, v146, v103 :: v_dual_mul_f32 v104, v147, v104// 00000011D91C: C8C6CF92 6768D193
	v_dual_mul_f32 v89, v152, v89 :: v_dual_mul_f32 v90, v153, v90// 00000011D924: C8C6B398 595AB599
	v_dual_mul_f32 v91, v150, v91 :: v_dual_mul_f32 v92, v151, v92// 00000011D92C: C8C6B796 5B5CB997
	v_dual_mul_f32 v93, v148, v93 :: v_dual_mul_f32 v94, v149, v94// 00000011D934: C8C6BB94 5D5EBD95
	v_dual_mul_f32 v95, v146, v95 :: v_dual_mul_f32 v96, v147, v96// 00000011D93C: C8C6BF92 5F60C193
	v_dual_mul_f32 v81, v152, v81 :: v_dual_mul_f32 v82, v153, v82// 00000011D944: C8C6A398 5152A599
	v_dual_mul_f32 v83, v150, v83 :: v_dual_mul_f32 v84, v151, v84// 00000011D94C: C8C6A796 5354A997
	v_dual_mul_f32 v85, v148, v85 :: v_dual_mul_f32 v86, v149, v86// 00000011D954: C8C6AB94 5556AD95
	v_dual_mul_f32 v87, v146, v87 :: v_dual_mul_f32 v88, v147, v88// 00000011D95C: C8C6AF92 5758B193
	v_dual_mul_f32 v73, v152, v73 :: v_dual_mul_f32 v74, v153, v74// 00000011D964: C8C69398 494A9599
	v_dual_mul_f32 v75, v150, v75 :: v_dual_mul_f32 v76, v151, v76// 00000011D96C: C8C69796 4B4C9997
	v_dual_mul_f32 v77, v148, v77 :: v_dual_mul_f32 v78, v149, v78// 00000011D974: C8C69B94 4D4E9D95
	v_dual_mul_f32 v79, v146, v79 :: v_dual_mul_f32 v80, v147, v80// 00000011D97C: C8C69F92 4F50A193
	v_dual_mul_f32 v65, v152, v65 :: v_dual_mul_f32 v66, v153, v66// 00000011D984: C8C68398 41428599
	v_dual_mul_f32 v67, v150, v67 :: v_dual_mul_f32 v68, v151, v68// 00000011D98C: C8C68796 43448997
	v_dual_mul_f32 v69, v148, v69 :: v_dual_mul_f32 v70, v149, v70// 00000011D994: C8C68B94 45468D95
	v_dual_mul_f32 v71, v146, v71 :: v_dual_mul_f32 v72, v147, v72// 00000011D99C: C8C68F92 47489193
	v_dual_mul_f32 v57, v152, v57 :: v_dual_mul_f32 v58, v153, v58// 00000011D9A4: C8C67398 393A7599
	v_dual_mul_f32 v59, v150, v59 :: v_dual_mul_f32 v60, v151, v60// 00000011D9AC: C8C67796 3B3C7997
	v_dual_mul_f32 v61, v148, v61 :: v_dual_mul_f32 v62, v149, v62// 00000011D9B4: C8C67B94 3D3E7D95
	v_dual_mul_f32 v63, v146, v63 :: v_dual_mul_f32 v64, v147, v64// 00000011D9BC: C8C67F92 3F408193
	v_dual_mul_f32 v49, v152, v49 :: v_dual_mul_f32 v50, v153, v50// 00000011D9C4: C8C66398 31326599
	v_dual_mul_f32 v51, v150, v51 :: v_dual_mul_f32 v52, v151, v52// 00000011D9CC: C8C66796 33346997
	v_dual_mul_f32 v53, v148, v53 :: v_dual_mul_f32 v54, v149, v54// 00000011D9D4: C8C66B94 35366D95
	v_dual_mul_f32 v55, v146, v55 :: v_dual_mul_f32 v56, v147, v56// 00000011D9DC: C8C66F92 37387193
	v_dual_mul_f32 v41, v152, v41 :: v_dual_mul_f32 v42, v153, v42// 00000011D9E4: C8C65398 292A5599
	v_dual_mul_f32 v43, v150, v43 :: v_dual_mul_f32 v44, v151, v44// 00000011D9EC: C8C65796 2B2C5997
	v_dual_mul_f32 v45, v148, v45 :: v_dual_mul_f32 v46, v149, v46// 00000011D9F4: C8C65B94 2D2E5D95
	v_dual_mul_f32 v47, v146, v47 :: v_dual_mul_f32 v48, v147, v48// 00000011D9FC: C8C65F92 2F306193
	v_dual_mul_f32 v33, v152, v33 :: v_dual_mul_f32 v34, v153, v34// 00000011DA04: C8C64398 21224599
	v_dual_mul_f32 v35, v150, v35 :: v_dual_mul_f32 v36, v151, v36// 00000011DA0C: C8C64796 23244997
	v_dual_mul_f32 v37, v148, v37 :: v_dual_mul_f32 v38, v149, v38// 00000011DA14: C8C64B94 25264D95
	v_dual_mul_f32 v39, v146, v39 :: v_dual_mul_f32 v40, v147, v40// 00000011DA1C: C8C64F92 27285193
	v_dual_mul_f32 v25, v152, v25 :: v_dual_mul_f32 v26, v153, v26// 00000011DA24: C8C63398 191A3599
	v_dual_mul_f32 v27, v150, v27 :: v_dual_mul_f32 v28, v151, v28// 00000011DA2C: C8C63796 1B1C3997
	v_dual_mul_f32 v29, v148, v29 :: v_dual_mul_f32 v30, v149, v30// 00000011DA34: C8C63B94 1D1E3D95
	v_dual_mul_f32 v31, v146, v31 :: v_dual_mul_f32 v32, v147, v32// 00000011DA3C: C8C63F92 1F204193
	v_dual_mul_f32 v17, v152, v17 :: v_dual_mul_f32 v18, v153, v18// 00000011DA44: C8C62398 11122599
	v_dual_mul_f32 v19, v150, v19 :: v_dual_mul_f32 v20, v151, v20// 00000011DA4C: C8C62796 13142997
	v_dual_mul_f32 v21, v148, v21 :: v_dual_mul_f32 v22, v149, v22// 00000011DA54: C8C62B94 15162D95
	v_dual_mul_f32 v23, v146, v23 :: v_dual_mul_f32 v24, v147, v24// 00000011DA5C: C8C62F92 17183193
	v_dual_mul_f32 v9, v152, v9 :: v_dual_mul_f32 v10, v153, v10// 00000011DA64: C8C61398 090A1599
	v_dual_mul_f32 v11, v150, v11 :: v_dual_mul_f32 v12, v151, v12// 00000011DA6C: C8C61796 0B0C1997
	v_dual_mul_f32 v13, v148, v13 :: v_dual_mul_f32 v14, v149, v14// 00000011DA74: C8C61B94 0D0E1D95
	v_dual_mul_f32 v15, v146, v15 :: v_dual_mul_f32 v16, v147, v16// 00000011DA7C: C8C61F92 0F102193
	v_dual_mul_f32 v1, v152, v1 :: v_dual_mul_f32 v2, v153, v2 // 00000011DA84: C8C60398 01020599
	v_dual_mul_f32 v3, v150, v3 :: v_dual_mul_f32 v4, v151, v4 // 00000011DA8C: C8C60796 03040997
	v_dual_mul_f32 v5, v148, v5 :: v_dual_mul_f32 v6, v149, v6 // 00000011DA94: C8C60B94 05060D95
	v_dual_mul_f32 v7, v146, v7 :: v_dual_mul_f32 v8, v147, v8 // 00000011DA9C: C8C60F92 07081193
	s_branch 62899                                             // 00000011DAA4: BFA0F5B3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x774>
	v_lshlrev_b32_e32 v0, 2, v157                              // 00000011DAA8: 30013A82
	.long 0xd700008b                                           // 00000011DAAC: D700008B
	v_cndmask_b32_e32 v1, s18, v139, vcc_lo                    // 00000011DAB0: 02031612
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011DAB4: BF870191
	v_add_co_ci_u32_e64 v140, null, s19, v140, s0              // 00000011DAB8: D5207C8C 00031813
	v_lshl_or_b32 v0, v155, 6, v0                              // 00000011DAC0: D6560000 04010D9B
	v_lshlrev_b32_e32 v147, 1, v154                            // 00000011DAC8: 31273481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000011DACC: BF870152
	v_add_nc_u32_e32 v133, 0xf000, v0                          // 00000011DAD0: 4B0A00FF 0000F000
	ds_load_2addr_b32 v[141:142], v133 offset0:192 offset1:194 // 00000011DAD8: D8DCC2C0 8D000085
	s_waitcnt lgkmcnt(0)                                       // 00000011DAE0: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 00000011DAE4: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 00000011DAEC: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 00000011DAF4: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000011DAF8: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 00000011DAFC: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 00000011DB04: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:196 offset1:198 // 00000011DB08: D8DCC6C4 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:200 offset1:202 // 00000011DB10: D8DCCAC8 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:204 offset1:206 // 00000011DB18: D8DCCECC 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 00000011DB20: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 00000011DB24: 3505029F
	v_or_b32_e32 v0, v156, v157                                // 00000011DB28: 38013B9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011DB2C: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 00000011DB30: 11252191
	.long 0xd73c0083                                           // 00000011DB34: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 00000011DB38: 02030281
	.long 0xd7000081                                           // 00000011DB3C: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 00000011DB40: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000011DB44: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 00000011DB48: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 00000011DB50: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DB58: BF870094
	.long 0xd7000083                                           // 00000011DB5C: D7000083
	v_cndmask_b32_e32 v1, s16, v131, vcc_lo                    // 00000011DB60: 02030610
	v_add_co_ci_u32_e64 v132, null, s17, v132, s0              // 00000011DB64: D5207C84 00030811
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011DB6C: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 00000011DB70: 57252194
	.long 0xd4440000                                           // 00000011DB74: D4440000
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 00000011DB78: 0202000E
	v_fma_f32 v139, -v143, v146, v145                          // 00000011DB7C: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011DB84: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 00000011DB88: D637008B 064B218B
	.long 0xd7006a83                                           // 00000011DB90: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 00000011DB94: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 00000011DB98: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 00000011DBA0: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 00000011DBA4: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 00000011DBAC: BE812000
	s_cbranch_execz 70                                         // 00000011DBB0: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32cc>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011DBB4: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 00000011DBB8: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 00000011DBC4: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 00000011DBC8: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 00000011DBD0: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 00000011DBD4: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DBD8: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 00000011DBDC: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 00000011DBE4: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 00000011DBF0: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011DBF4: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 00000011DBF8: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 00000011DC00: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000011DC04: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 00000011DC08: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 00000011DC0C: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 00000011DC10: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 00000011DC18: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DC1C: BF870095
	.long 0xd71c008d                                           // 00000011DC20: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 00000011DC24: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 00000011DC28: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 00000011DC2C: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DC34: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 00000011DC38: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 00000011DC40: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DC44: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 00000011DC48: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 00000011DC50: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DC54: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 00000011DC58: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 00000011DC60: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 00000011DC64: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DC6C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000011DC70: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 00000011DC74: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DC7C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000011DC80: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 00000011DC84: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DC8C: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 00000011DC90: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 00000011DC98: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 00000011DCA0: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DCAC: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 00000011DCB0: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 00000011DCB8: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 00000011DCC4: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000011DCCC: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 00000011DCD0: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 00000011DCD8: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011DCE0: BF870292
	v_rcp_f32_e32 v140, v121                                   // 00000011DCE4: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 00000011DCE8: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DCF0: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 00000011DCF4: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 00000011DCF8: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DCFC: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 00000011DD00: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 00000011DD08: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DD0C: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 00000011DD10: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 00000011DD18: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 00000011DD20: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011DD24: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 00000011DD28: D627008C 03CB1D8C
	.long 0xd4440001                                           // 00000011DD30: D4440001
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 00000011DD34: 0202F20E
	s_and_saveexec_b32 s2, s1                                  // 00000011DD38: BE822001
	s_cbranch_execz 69                                         // 00000011DD3C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3454>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 00000011DD40: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 00000011DD4C: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 00000011DD50: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000011DD58: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000011DD5C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DD60: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000011DD64: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000011DD6C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000011DD78: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011DD7C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000011DD80: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000011DD84: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000011DD8C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011DD94: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000011DD98: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000011DD9C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000011DDA0: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DDA4: BF870095
	.long 0xd71c008e                                           // 00000011DDA8: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000011DDAC: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000011DDB0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000011DDB4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DDBC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000011DDC0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000011DDC8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DDCC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 00000011DDD0: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000011DDD8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DDDC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000011DDE0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000011DDE8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 00000011DDEC: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DDF4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000011DDF8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000011DDFC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DE04: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000011DE08: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000011DE0C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DE14: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000011DE18: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 00000011DE20: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 00000011DE28: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DE34: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 00000011DE38: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 00000011DE40: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 00000011DE4C: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 00000011DE54: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 00000011DE58: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 00000011DE5C: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 00000011DE64: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011DE6C: BF870292
	v_rcp_f32_e32 v141, v122                                   // 00000011DE70: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 00000011DE74: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DE7C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000011DE80: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000011DE84: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DE88: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 00000011DE8C: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 00000011DE94: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DE98: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 00000011DE9C: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 00000011DEA4: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 00000011DEAC: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011DEB0: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 00000011DEB4: D6270089 03CB138D
	.long 0xd4440002                                           // 00000011DEBC: D4440002
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 00000011DEC0: 0202F40E
	s_and_saveexec_b32 s3, s2                                  // 00000011DEC4: BE832002
	s_cbranch_execz 69                                         // 00000011DEC8: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35e0>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 00000011DECC: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 00000011DED8: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 00000011DEDC: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000011DEE4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000011DEE8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DEEC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000011DEF0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000011DEF8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000011DF04: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011DF08: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000011DF0C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000011DF10: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000011DF18: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011DF20: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000011DF24: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000011DF28: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000011DF2C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DF30: BF870095
	.long 0xd71c008e                                           // 00000011DF34: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000011DF38: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000011DF3C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000011DF40: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DF48: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000011DF4C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000011DF54: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DF58: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 00000011DF5C: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000011DF64: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DF68: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000011DF6C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000011DF74: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 00000011DF78: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DF80: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000011DF84: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000011DF88: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DF90: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000011DF94: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000011DF98: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DFA0: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000011DFA4: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 00000011DFAC: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 00000011DFB4: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011DFC0: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 00000011DFC4: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 00000011DFCC: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 00000011DFD8: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 00000011DFE0: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 00000011DFE4: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 00000011DFEC: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011DFF4: BF870292
	v_rcp_f32_e32 v141, v123                                   // 00000011DFF8: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 00000011DFFC: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E004: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000011E008: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000011E00C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E010: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 00000011E014: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 00000011E01C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E020: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 00000011E024: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 00000011E02C: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 00000011E034: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011E038: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 00000011E03C: D627008A 03CB158D
	.long 0xd4440003                                           // 00000011E044: D4440003
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 00000011E048: 0202F60E
	s_and_saveexec_b32 s4, s3                                  // 00000011E04C: BE842003
	s_cbranch_execz 69                                         // 00000011E050: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3768>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 00000011E054: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 00000011E060: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 00000011E064: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000011E06C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000011E070: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E074: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000011E078: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000011E080: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000011E08C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011E090: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000011E094: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000011E098: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000011E0A0: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011E0A8: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000011E0AC: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000011E0B0: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000011E0B4: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E0B8: BF870095
	.long 0xd71c008e                                           // 00000011E0BC: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000011E0C0: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000011E0C4: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000011E0C8: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E0D0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000011E0D4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000011E0DC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E0E0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 00000011E0E4: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 00000011E0EC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E0F0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000011E0F4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000011E0FC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 00000011E100: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E108: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000011E10C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000011E110: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E118: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000011E11C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000011E120: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E128: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000011E12C: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 00000011E134: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 00000011E13C: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E148: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 00000011E14C: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 00000011E154: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 00000011E160: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000011E168: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 00000011E16C: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 00000011E170: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 00000011E178: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011E180: BF870292
	v_rcp_f32_e32 v141, v124                                   // 00000011E184: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 00000011E188: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E190: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000011E194: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000011E198: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E19C: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 00000011E1A0: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 00000011E1A8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E1AC: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 00000011E1B0: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 00000011E1B8: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 00000011E1C0: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011E1C4: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 00000011E1C8: D6270087 03CB0F8D
	.long 0xd4440004                                           // 00000011E1D0: D4440004
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 00000011E1D4: 0202F80E
	s_and_saveexec_b32 s5, s4                                  // 00000011E1D8: BE852004
	s_cbranch_execz 69                                         // 00000011E1DC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38f4>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 00000011E1E0: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 00000011E1EC: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 00000011E1F0: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000011E1F8: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000011E1FC: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E200: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000011E204: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000011E20C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000011E218: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011E21C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000011E220: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000011E224: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000011E22C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011E234: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000011E238: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000011E23C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000011E240: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E244: BF870095
	.long 0xd71c008e                                           // 00000011E248: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000011E24C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000011E250: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000011E254: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E25C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000011E260: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000011E268: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E26C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 00000011E270: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 00000011E278: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E27C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000011E280: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000011E288: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 00000011E28C: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E294: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000011E298: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000011E29C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E2A4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000011E2A8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000011E2AC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E2B4: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000011E2B8: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 00000011E2C0: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 00000011E2C8: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E2D4: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 00000011E2D8: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 00000011E2E0: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 00000011E2EC: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 00000011E2F4: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 00000011E2F8: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 00000011E300: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011E308: BF870292
	v_rcp_f32_e32 v141, v125                                   // 00000011E30C: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 00000011E310: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E318: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000011E31C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000011E320: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E324: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 00000011E328: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 00000011E330: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E334: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 00000011E338: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 00000011E340: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 00000011E348: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011E34C: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 00000011E350: D6270088 03CB118D
	.long 0xd4440005                                           // 00000011E358: D4440005
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 00000011E35C: 0202FA0E
	s_and_saveexec_b32 s6, s5                                  // 00000011E360: BE862005
	s_cbranch_execz 69                                         // 00000011E364: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a7c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 00000011E368: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 00000011E374: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 00000011E378: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000011E380: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000011E384: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E388: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000011E38C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000011E394: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000011E3A0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011E3A4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000011E3A8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000011E3AC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000011E3B4: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011E3BC: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000011E3C0: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000011E3C4: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000011E3C8: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E3CC: BF870095
	.long 0xd71c008e                                           // 00000011E3D0: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000011E3D4: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000011E3D8: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000011E3DC: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E3E4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000011E3E8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000011E3F0: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E3F4: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 00000011E3F8: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000011E400: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E404: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000011E408: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000011E410: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 00000011E414: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E41C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000011E420: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000011E424: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E42C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000011E430: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000011E434: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E43C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000011E440: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 00000011E448: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 00000011E450: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E45C: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 00000011E460: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 00000011E468: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 00000011E474: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 00000011E47C: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000011E480: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 00000011E484: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 00000011E48C: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011E494: BF870292
	v_rcp_f32_e32 v141, v126                                   // 00000011E498: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 00000011E49C: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E4A4: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000011E4A8: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000011E4AC: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E4B0: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 00000011E4B4: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 00000011E4BC: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E4C0: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 00000011E4C4: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 00000011E4CC: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 00000011E4D4: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011E4D8: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 00000011E4DC: D6270085 03CB0B8D
	.long 0xd4440006                                           // 00000011E4E4: D4440006
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 00000011E4E8: 0202FC0E
	s_and_saveexec_b32 s7, s6                                  // 00000011E4EC: BE872006
	s_cbranch_execz 69                                         // 00000011E4F0: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c08>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 00000011E4F4: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 00000011E500: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 00000011E504: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000011E50C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000011E510: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E514: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000011E518: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000011E520: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000011E52C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011E530: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000011E534: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000011E538: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000011E540: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011E548: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000011E54C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000011E550: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000011E554: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E558: BF870095
	.long 0xd71c008e                                           // 00000011E55C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000011E560: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000011E564: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000011E568: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E570: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000011E574: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000011E57C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E580: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 00000011E584: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000011E58C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E590: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000011E594: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000011E59C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 00000011E5A0: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E5A8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000011E5AC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000011E5B0: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E5B8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000011E5BC: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000011E5C0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E5C8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000011E5CC: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 00000011E5D4: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 00000011E5DC: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E5E8: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 00000011E5EC: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 00000011E5F4: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 00000011E600: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 00000011E608: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 00000011E60C: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 00000011E614: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011E61C: BF870292
	v_rcp_f32_e32 v141, v127                                   // 00000011E620: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 00000011E624: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E62C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000011E630: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000011E634: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E638: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 00000011E63C: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 00000011E644: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011E648: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 00000011E64C: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 00000011E654: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 00000011E65C: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011E660: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 00000011E664: D6270086 03CB0D8D
	.long 0xd4440007                                           // 00000011E66C: D4440007
	v_cndmask_b32_e32 v1, s14, v127, vcc_lo                    // 00000011E670: 0202FE0E
	s_and_saveexec_b32 s8, s7                                  // 00000011E674: BE882007
	s_cbranch_execnz 363                                       // 00000011E678: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4228>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E67C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011E680: BE882000
	s_cbranch_execnz 432                                       // 00000011E684: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4348>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E688: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011E68C: BE882001
	s_cbranch_execnz 501                                       // 00000011E690: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4468>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E694: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011E698: BE882002
	s_cbranch_execnz 570                                       // 00000011E69C: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4588>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E6A0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011E6A4: BE882003
	s_cbranch_execnz 639                                       // 00000011E6A8: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x46a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E6AC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011E6B0: BE882004
	s_cbranch_execnz 708                                       // 00000011E6B4: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x47c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E6B8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011E6BC: BE882005
	s_cbranch_execnz 777                                       // 00000011E6C0: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x48e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E6C4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011E6C8: BE882006
	s_cbranch_execnz 846                                       // 00000011E6CC: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4a08>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E6D0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011E6D4: BE882007
	s_cbranch_execnz 915                                       // 00000011E6D8: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4b28>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E6DC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011E6E0: BE882000
	s_cbranch_execnz 984                                       // 00000011E6E4: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4c48>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E6E8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011E6EC: BE882001
	s_cbranch_execnz 1053                                      // 00000011E6F0: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4d68>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E6F4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011E6F8: BE882002
	s_cbranch_execnz 1122                                      // 00000011E6FC: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4e88>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E700: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011E704: BE882003
	s_cbranch_execnz 1191                                      // 00000011E708: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4fa8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E70C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011E710: BE882004
	s_cbranch_execnz 1260                                      // 00000011E714: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x50c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E718: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011E71C: BE882005
	s_cbranch_execnz 1329                                      // 00000011E720: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x51e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E724: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011E728: BE882006
	s_cbranch_execnz 1398                                      // 00000011E72C: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5308>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E730: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011E734: BE882007
	s_cbranch_execnz 1467                                      // 00000011E738: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5428>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E73C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011E740: BE882000
	s_cbranch_execnz 1536                                      // 00000011E744: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5548>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E748: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011E74C: BE882001
	s_cbranch_execnz 1605                                      // 00000011E750: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5668>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E754: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011E758: BE882002
	s_cbranch_execnz 1674                                      // 00000011E75C: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5788>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E760: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011E764: BE882003
	s_cbranch_execnz 1743                                      // 00000011E768: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x58a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E76C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011E770: BE882004
	s_cbranch_execnz 1812                                      // 00000011E774: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x59c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E778: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011E77C: BE882005
	s_cbranch_execnz 1881                                      // 00000011E780: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5ae8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E784: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011E788: BE882006
	s_cbranch_execnz 1950                                      // 00000011E78C: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5c08>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E790: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011E794: BE882007
	s_cbranch_execnz 2019                                      // 00000011E798: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5d28>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E79C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011E7A0: BE882000
	s_cbranch_execnz 2088                                      // 00000011E7A4: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5e48>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E7A8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011E7AC: BE882001
	s_cbranch_execnz 2157                                      // 00000011E7B0: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5f68>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E7B4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011E7B8: BE882002
	s_cbranch_execnz 2226                                      // 00000011E7BC: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6088>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E7C0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011E7C4: BE882003
	s_cbranch_execnz 2295                                      // 00000011E7C8: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x61a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E7CC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011E7D0: BE882004
	s_cbranch_execnz 2364                                      // 00000011E7D4: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x62c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E7D8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011E7DC: BE882005
	s_cbranch_execnz 2433                                      // 00000011E7E0: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x63e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E7E4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011E7E8: BE882006
	s_cbranch_execnz 2502                                      // 00000011E7EC: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6508>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E7F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011E7F4: BE882007
	s_cbranch_execnz 2571                                      // 00000011E7F8: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6628>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E7FC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011E800: BE882000
	s_cbranch_execnz 2640                                      // 00000011E804: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6748>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E808: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011E80C: BE882001
	s_cbranch_execnz 2709                                      // 00000011E810: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6868>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E814: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011E818: BE882002
	s_cbranch_execnz 2778                                      // 00000011E81C: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6988>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E820: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011E824: BE882003
	s_cbranch_execnz 2847                                      // 00000011E828: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6aa8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E82C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011E830: BE882004
	s_cbranch_execnz 2916                                      // 00000011E834: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6bc8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E838: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011E83C: BE882005
	s_cbranch_execnz 2985                                      // 00000011E840: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6ce8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E844: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011E848: BE882006
	s_cbranch_execnz 3054                                      // 00000011E84C: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6e08>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E850: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011E854: BE882007
	s_cbranch_execnz 3123                                      // 00000011E858: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6f28>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E85C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011E860: BE882000
	s_cbranch_execnz 3192                                      // 00000011E864: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7048>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E868: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011E86C: BE882001
	s_cbranch_execnz 3261                                      // 00000011E870: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7168>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E874: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011E878: BE882002
	s_cbranch_execnz 3330                                      // 00000011E87C: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7288>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E880: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011E884: BE882003
	s_cbranch_execnz 3399                                      // 00000011E888: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x73a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E88C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011E890: BE882004
	s_cbranch_execnz 3468                                      // 00000011E894: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x74c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E898: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011E89C: BE882005
	s_cbranch_execnz 3537                                      // 00000011E8A0: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x75e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E8A4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011E8A8: BE882006
	s_cbranch_execnz 3606                                      // 00000011E8AC: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7708>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E8B0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011E8B4: BE882007
	s_cbranch_execnz 3675                                      // 00000011E8B8: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7828>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E8BC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011E8C0: BE882000
	s_cbranch_execnz 3744                                      // 00000011E8C4: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7948>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E8C8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011E8CC: BE882001
	s_cbranch_execnz 3813                                      // 00000011E8D0: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7a68>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E8D4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011E8D8: BE882002
	s_cbranch_execnz 3882                                      // 00000011E8DC: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7b88>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E8E0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011E8E4: BE882003
	s_cbranch_execnz 3951                                      // 00000011E8E8: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7ca8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E8EC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011E8F0: BE882004
	s_cbranch_execnz 4020                                      // 00000011E8F4: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7dc8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E8F8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011E8FC: BE882005
	s_cbranch_execnz 4089                                      // 00000011E900: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7ee8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E904: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011E908: BE882006
	s_cbranch_execnz 4158                                      // 00000011E90C: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8008>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E910: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011E914: BE882007
	s_cbranch_execnz 4227                                      // 00000011E918: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8128>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E91C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011E920: BE882000
	s_cbranch_execnz 4296                                      // 00000011E924: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8248>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E928: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011E92C: BE882001
	s_cbranch_execnz 4365                                      // 00000011E930: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8368>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E934: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011E938: BE882002
	s_cbranch_execnz 4434                                      // 00000011E93C: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8488>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E940: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011E944: BE882003
	s_cbranch_execnz 4503                                      // 00000011E948: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x85a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E94C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011E950: BE882004
	s_cbranch_execnz 4572                                      // 00000011E954: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x86c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E958: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011E95C: BE882005
	s_cbranch_execnz 4641                                      // 00000011E960: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x87e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E964: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011E968: BE882006
	s_cbranch_execnz 4710                                      // 00000011E96C: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8908>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E970: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011E974: BE882007
	s_cbranch_execnz 4779                                      // 00000011E978: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8a28>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E97C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011E980: BE882000
	s_cbranch_execnz 4848                                      // 00000011E984: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b48>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E988: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011E98C: BE882001
	s_cbranch_execnz 4917                                      // 00000011E990: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8c68>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E994: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011E998: BE882002
	s_cbranch_execnz 4986                                      // 00000011E99C: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8d88>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E9A0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011E9A4: BE882003
	s_cbranch_execnz 5055                                      // 00000011E9A8: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8ea8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E9AC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011E9B0: BE882004
	s_cbranch_execnz 5124                                      // 00000011E9B4: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8fc8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E9B8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011E9BC: BE882005
	s_cbranch_execnz 5193                                      // 00000011E9C0: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x90e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E9C4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011E9C8: BE882006
	s_cbranch_execnz 5262                                      // 00000011E9CC: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9208>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E9D0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011E9D4: BE882007
	s_cbranch_execnz 5331                                      // 00000011E9D8: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9328>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E9DC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011E9E0: BE882000
	s_cbranch_execnz 5400                                      // 00000011E9E4: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9448>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E9E8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011E9EC: BE882001
	s_cbranch_execnz 5469                                      // 00000011E9F0: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9568>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011E9F4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011E9F8: BE882002
	s_cbranch_execnz 5538                                      // 00000011E9FC: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9688>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EA00: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011EA04: BE882003
	s_cbranch_execnz 5607                                      // 00000011EA08: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x97a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EA0C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011EA10: BE882004
	s_cbranch_execnz 5676                                      // 00000011EA14: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x98c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EA18: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011EA1C: BE882005
	s_cbranch_execnz 5745                                      // 00000011EA20: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x99e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EA24: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011EA28: BE882006
	s_cbranch_execnz 5814                                      // 00000011EA2C: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9b08>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EA30: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011EA34: BE882007
	s_cbranch_execnz 5883                                      // 00000011EA38: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c28>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EA3C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011EA40: BE882000
	s_cbranch_execnz 5952                                      // 00000011EA44: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9d48>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EA48: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011EA4C: BE882001
	s_cbranch_execnz 6021                                      // 00000011EA50: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9e68>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EA54: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011EA58: BE882002
	s_cbranch_execnz 6090                                      // 00000011EA5C: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9f88>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EA60: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011EA64: BE882003
	s_cbranch_execnz 6159                                      // 00000011EA68: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa0a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EA6C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011EA70: BE882004
	s_cbranch_execnz 6228                                      // 00000011EA74: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa1c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EA78: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011EA7C: BE882005
	s_cbranch_execnz 6297                                      // 00000011EA80: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa2e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EA84: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011EA88: BE882006
	s_cbranch_execnz 6366                                      // 00000011EA8C: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa408>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EA90: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011EA94: BE882007
	s_cbranch_execnz 6435                                      // 00000011EA98: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa528>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EA9C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011EAA0: BE882000
	s_cbranch_execnz 6504                                      // 00000011EAA4: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa648>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EAA8: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011EAAC: BE882001
	s_cbranch_execnz 6573                                      // 00000011EAB0: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa768>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EAB4: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011EAB8: BE882002
	s_cbranch_execnz 6642                                      // 00000011EABC: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa888>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EAC0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011EAC4: BE882003
	s_cbranch_execnz 6711                                      // 00000011EAC8: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa9a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EACC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011EAD0: BE882004
	s_cbranch_execnz 6780                                      // 00000011EAD4: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaac8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EAD8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011EADC: BE882005
	s_cbranch_execnz 6849                                      // 00000011EAE0: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xabe8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EAE4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011EAE8: BE882006
	s_cbranch_execnz 6918                                      // 00000011EAEC: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xad08>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EAF0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011EAF4: BE882007
	s_cbranch_execnz 6987                                      // 00000011EAF8: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xae28>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EAFC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011EB00: BE882000
	s_cbranch_execnz 7056                                      // 00000011EB04: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaf48>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EB08: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011EB0C: BE882001
	s_cbranch_execnz 7125                                      // 00000011EB10: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb068>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EB14: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011EB18: BE882002
	s_cbranch_execnz 7194                                      // 00000011EB1C: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb188>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EB20: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011EB24: BE882003
	s_cbranch_execnz 7263                                      // 00000011EB28: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb2a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EB2C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011EB30: BE882004
	s_cbranch_execnz 7332                                      // 00000011EB34: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb3c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EB38: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011EB3C: BE882005
	s_cbranch_execnz 7401                                      // 00000011EB40: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb4e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EB44: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011EB48: BE882006
	s_cbranch_execnz 7470                                      // 00000011EB4C: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb608>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EB50: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011EB54: BE882007
	s_cbranch_execnz 7539                                      // 00000011EB58: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb728>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EB5C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011EB60: BE882000
	s_cbranch_execnz 7608                                      // 00000011EB64: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb848>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EB68: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011EB6C: BE882001
	s_cbranch_execnz 7677                                      // 00000011EB70: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb968>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EB74: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011EB78: BE882002
	s_cbranch_execnz 7746                                      // 00000011EB7C: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xba88>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EB80: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011EB84: BE882003
	s_cbranch_execnz 7815                                      // 00000011EB88: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbba8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EB8C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011EB90: BE882004
	s_cbranch_execnz 7884                                      // 00000011EB94: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbcc8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EB98: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011EB9C: BE882005
	s_cbranch_execnz 7953                                      // 00000011EBA0: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbde8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EBA4: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011EBA8: BE882006
	s_cbranch_execnz 8022                                      // 00000011EBAC: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbf08>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EBB0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011EBB4: BE882007
	s_cbranch_execnz 8091                                      // 00000011EBB8: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc028>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EBBC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011EBC0: BE882000
	s_cbranch_execnz 8160                                      // 00000011EBC4: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc148>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EBC8: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000011EBCC: BE802001
	s_cbranch_execnz 8229                                      // 00000011EBD0: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc268>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000011EBD4: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000011EBD8: BE802002
	s_cbranch_execnz 8298                                      // 00000011EBDC: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc388>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000011EBE0: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000011EBE4: BE802003
	s_cbranch_execnz 8367                                      // 00000011EBE8: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc4a8>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000011EBEC: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000011EBF0: BE802004
	s_cbranch_execnz 8436                                      // 00000011EBF4: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc5c8>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000011EBF8: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000011EBFC: BE802005
	s_cbranch_execnz 8505                                      // 00000011EC00: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc6e8>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000011EC04: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000011EC08: BE802006
	s_cbranch_execnz 8574                                      // 00000011EC0C: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc808>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000011EC10: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000011EC14: BE802007
	s_cbranch_execnz 8643                                      // 00000011EC18: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc928>
	s_nop 0                                                    // 00000011EC1C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000011EC20: BFB60003
	s_endpgm                                                   // 00000011EC24: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 00000011EC28: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 00000011EC34: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 00000011EC38: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000011EC40: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000011EC44: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EC48: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000011EC4C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000011EC54: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000011EC60: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011EC64: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000011EC68: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000011EC6C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000011EC74: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011EC7C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000011EC80: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000011EC84: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000011EC88: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EC8C: BF870095
	.long 0xd71c008e                                           // 00000011EC90: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000011EC94: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000011EC98: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000011EC9C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011ECA4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000011ECA8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000011ECB0: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011ECB4: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 00000011ECB8: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 00000011ECC0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011ECC4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000011ECC8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000011ECD0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 00000011ECD4: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011ECDC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000011ECE0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000011ECE4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011ECEC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000011ECF0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000011ECF4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011ECFC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000011ED00: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 00000011ED08: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 00000011ED10: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011ED1C: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 00000011ED20: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 00000011ED28: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 00000011ED34: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011ED3C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011ED40: BE882000
	s_cbranch_execz 65104                                      // 00000011ED44: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c88>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 00000011ED48: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 00000011ED54: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 00000011ED58: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 00000011ED60: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 00000011ED64: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011ED68: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 00000011ED6C: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 00000011ED74: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 00000011ED80: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011ED84: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 00000011ED88: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 00000011ED8C: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 00000011ED94: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011ED9C: BF870121
	v_add_f32_e32 v141, v141, v142                             // 00000011EDA0: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 00000011EDA4: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 00000011EDA8: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EDAC: BF870095
	.long 0xd71c008d                                           // 00000011EDB0: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 00000011EDB4: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 00000011EDB8: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 00000011EDBC: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EDC4: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 00000011EDC8: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 00000011EDD0: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EDD4: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 00000011EDD8: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 00000011EDE0: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EDE4: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 00000011EDE8: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 00000011EDF0: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 00000011EDF4: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EDFC: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 00000011EE00: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 00000011EE04: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EE0C: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 00000011EE10: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 00000011EE14: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EE1C: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 00000011EE20: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 00000011EE28: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 00000011EE30: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EE3C: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 00000011EE40: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 00000011EE48: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 00000011EE54: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EE5C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011EE60: BE882001
	s_cbranch_execz 65035                                      // 00000011EE64: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c94>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 00000011EE68: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 00000011EE74: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 00000011EE78: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 00000011EE80: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000011EE84: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EE88: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 00000011EE8C: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 00000011EE94: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 00000011EEA0: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011EEA4: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 00000011EEA8: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000011EEAC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 00000011EEB4: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011EEBC: BF870121
	v_add_f32_e32 v128, v128, v141                             // 00000011EEC0: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 00000011EEC4: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 00000011EEC8: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EECC: BF870095
	.long 0xd71c0080                                           // 00000011EED0: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 00000011EED4: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 00000011EED8: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000011EEDC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EEE4: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 00000011EEE8: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000011EEF0: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EEF4: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 00000011EEF8: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 00000011EF00: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EF04: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 00000011EF08: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 00000011EF10: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 00000011EF14: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EF1C: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 00000011EF20: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 00000011EF24: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EF2C: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 00000011EF30: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 00000011EF34: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EF3C: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 00000011EF40: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 00000011EF48: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 00000011EF50: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EF5C: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 00000011EF60: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 00000011EF68: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 00000011EF74: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011EF7C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011EF80: BE882002
	s_cbranch_execz 64966                                      // 00000011EF84: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ca0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 00000011EF88: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000011EF94: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000011EF9C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000011EFA0: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EFA4: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000011EFA8: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 00000011EFB0: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 00000011EFBC: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011EFC0: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 00000011EFC4: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 00000011EFCC: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000011EFD0: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 00000011EFD4: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 00000011EFD8: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000011EFDC: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 00000011EFE4: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EFE8: BF870095
	.long 0xd71c0072                                           // 00000011EFEC: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 00000011EFF0: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000011EFF4: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000011EFF8: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F000: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 00000011F004: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000011F010: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F014: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000011F018: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 00000011F020: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F024: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 00000011F028: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 00000011F030: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 00000011F034: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F03C: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 00000011F040: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 00000011F044: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F04C: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 00000011F050: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 00000011F054: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F05C: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 00000011F060: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000011F068: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 00000011F070: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F07C: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 00000011F080: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 00000011F088: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000011F094: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011F09C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011F0A0: BE882003
	s_cbranch_execz 64897                                      // 00000011F0A4: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cac>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 00000011F0A8: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000011F0B4: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000011F0BC: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000011F0C0: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F0C4: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000011F0C8: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000011F0D0: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 00000011F0DC: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011F0E0: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 00000011F0E4: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000011F0E8: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000011F0F0: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011F0F8: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000011F0FC: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 00000011F100: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 00000011F104: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F108: BF870095
	.long 0xd71c0072                                           // 00000011F10C: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000011F110: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000011F114: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000011F118: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F120: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 00000011F124: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000011F130: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F134: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000011F138: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000011F140: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F144: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 00000011F148: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 00000011F150: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 00000011F154: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F15C: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 00000011F160: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 00000011F164: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F16C: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 00000011F170: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 00000011F174: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F17C: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 00000011F180: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000011F188: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 00000011F190: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F19C: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000011F1A0: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000011F1A8: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000011F1B4: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011F1BC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011F1C0: BE882004
	s_cbranch_execz 64828                                      // 00000011F1C4: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cb8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 00000011F1C8: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000011F1D4: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000011F1DC: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000011F1E0: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F1E4: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000011F1E8: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000011F1F0: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000011F1FC: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011F200: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000011F204: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000011F208: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000011F210: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011F218: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000011F21C: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000011F220: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000011F224: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F228: BF870095
	.long 0xd71c0072                                           // 00000011F22C: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000011F230: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000011F234: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000011F238: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F240: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 00000011F244: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000011F250: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F254: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000011F258: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000011F260: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F264: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000011F268: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000011F270: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000011F274: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F27C: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 00000011F280: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 00000011F284: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F28C: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 00000011F290: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 00000011F294: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F29C: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 00000011F2A0: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000011F2A8: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 00000011F2B0: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F2BC: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000011F2C0: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000011F2C8: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000011F2D4: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011F2DC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011F2E0: BE882005
	s_cbranch_execz 64759                                      // 00000011F2E4: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cc4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 00000011F2E8: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000011F2F4: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000011F2FC: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000011F300: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F304: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000011F308: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000011F310: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000011F31C: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011F320: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000011F324: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000011F328: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000011F330: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011F338: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000011F33C: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000011F340: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000011F344: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F348: BF870095
	.long 0xd71c0072                                           // 00000011F34C: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000011F350: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000011F354: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000011F358: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F360: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 00000011F364: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 00000011F36C: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F374: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000011F378: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000011F380: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F384: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000011F388: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000011F390: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000011F394: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F39C: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000011F3A0: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 00000011F3A4: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F3AC: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 00000011F3B0: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 00000011F3B4: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F3BC: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000011F3C0: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000011F3C8: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 00000011F3D0: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F3DC: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000011F3E0: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000011F3E8: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000011F3F4: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011F3FC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011F400: BE882006
	s_cbranch_execz 64690                                      // 00000011F404: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cd0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 00000011F408: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000011F414: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000011F41C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000011F420: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F424: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000011F428: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000011F430: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000011F43C: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011F440: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000011F444: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000011F448: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000011F450: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011F458: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000011F45C: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000011F460: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000011F464: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F468: BF870095
	.long 0xd71c0072                                           // 00000011F46C: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000011F470: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000011F474: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000011F478: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F480: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 00000011F484: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000011F490: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F494: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000011F498: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000011F4A0: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F4A4: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000011F4A8: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000011F4B0: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000011F4B4: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F4BC: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000011F4C0: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 00000011F4C4: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F4CC: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 00000011F4D0: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 00000011F4D4: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F4DC: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000011F4E0: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000011F4E8: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 00000011F4F0: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F4FC: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000011F500: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000011F508: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000011F514: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011F51C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011F520: BE882007
	s_cbranch_execz 64621                                      // 00000011F524: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cdc>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 00000011F528: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000011F534: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000011F53C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000011F540: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F544: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000011F548: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000011F550: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000011F55C: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011F560: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000011F564: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000011F568: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000011F570: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011F578: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000011F57C: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000011F580: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000011F584: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F588: BF870095
	.long 0xd71c0072                                           // 00000011F58C: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000011F590: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000011F594: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000011F598: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F5A0: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 00000011F5A4: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000011F5B0: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F5B4: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000011F5B8: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000011F5C0: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F5C4: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000011F5C8: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000011F5D0: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000011F5D4: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F5DC: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000011F5E0: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 00000011F5E4: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F5EC: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 00000011F5F0: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 00000011F5F4: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F5FC: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000011F600: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000011F608: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 00000011F610: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F61C: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000011F620: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000011F628: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000011F634: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011F63C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011F640: BE882000
	s_cbranch_execz 64552                                      // 00000011F644: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ce8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 00000011F648: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 00000011F654: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 00000011F658: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 00000011F660: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000011F664: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F668: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000011F66C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000011F674: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000011F680: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011F684: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000011F688: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000011F68C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000011F694: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011F69C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000011F6A0: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000011F6A4: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000011F6A8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F6AC: BF870095
	.long 0xd71c0072                                           // 00000011F6B0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000011F6B4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000011F6B8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000011F6BC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F6C4: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 00000011F6C8: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000011F6D0: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F6D4: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 00000011F6D8: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 00000011F6E0: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F6E4: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 00000011F6E8: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 00000011F6F0: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 00000011F6F4: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F6FC: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 00000011F700: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 00000011F704: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F70C: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 00000011F710: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 00000011F714: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F71C: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 00000011F720: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 00000011F728: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 00000011F730: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F73C: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 00000011F740: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 00000011F748: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 00000011F754: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011F75C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000011F760: BE882001
	s_cbranch_execz 64483                                      // 00000011F764: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cf4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 00000011F768: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 00000011F774: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 00000011F778: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 00000011F780: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000011F784: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011F788: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 00000011F78C: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000011F794: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 00000011F79C: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 00000011F7A8: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011F7AC: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 00000011F7B0: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 00000011F7B8: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011F7BC: BF870121
	v_add_f32_e32 v113, v113, v114                             // 00000011F7C0: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 00000011F7C4: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 00000011F7C8: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F7CC: BF870095
	.long 0xd71c0071                                           // 00000011F7D0: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 00000011F7D4: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 00000011F7D8: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000011F7DC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F7E4: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 00000011F7E8: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000011F7F0: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F7F4: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 00000011F7F8: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 00000011F800: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F804: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 00000011F808: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 00000011F810: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 00000011F814: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F81C: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 00000011F820: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 00000011F824: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F82C: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 00000011F830: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 00000011F834: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F83C: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 00000011F840: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 00000011F848: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 00000011F850: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F85C: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 00000011F860: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 00000011F868: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 00000011F874: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011F87C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000011F880: BE882002
	s_cbranch_execz 64414                                      // 00000011F884: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d00>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 00000011F888: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000011F894: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000011F89C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000011F8A0: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F8A4: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000011F8A8: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 00000011F8B0: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 00000011F8BC: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011F8C0: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 00000011F8C4: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000011F8C8: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 00000011F8D0: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011F8D8: BF870121
	v_add_f32_e32 v106, v106, v113                             // 00000011F8DC: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 00000011F8E0: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 00000011F8E4: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F8E8: BF870095
	.long 0xd71c006a                                           // 00000011F8EC: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 00000011F8F0: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000011F8F4: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000011F8F8: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F900: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 00000011F904: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000011F910: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F914: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000011F918: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 00000011F920: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F924: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 00000011F928: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 00000011F930: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 00000011F934: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F93C: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 00000011F940: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 00000011F944: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F94C: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 00000011F950: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 00000011F954: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F95C: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 00000011F960: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000011F968: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 00000011F970: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F97C: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 00000011F980: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 00000011F988: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000011F994: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011F99C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000011F9A0: BE882003
	s_cbranch_execz 64345                                      // 00000011F9A4: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d0c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 00000011F9A8: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000011F9B4: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000011F9BC: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000011F9C0: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F9C4: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000011F9C8: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000011F9D0: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 00000011F9DC: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F9E0: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 00000011F9E4: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 00000011F9F0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 00000011F9F4: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000011F9F8: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011FA00: BF870293
	v_exp_f32_e32 v106, v106                                   // 00000011FA04: 7ED44B6A
	.long 0xd71c006a                                           // 00000011FA08: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000011FA0C: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011FA10: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000011FA14: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000011FA18: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 00000011FA20: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FA2C: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 00000011FA30: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000011FA34: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011FA3C: BF870291
	v_rcp_f32_e32 v108, v107                                   // 00000011FA40: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 00000011FA44: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011FA4C: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 00000011FA50: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 00000011FA54: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 00000011FA5C: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FA60: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 00000011FA64: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 00000011FA6C: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FA70: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 00000011FA74: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 00000011FA7C: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011FA84: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000011FA88: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 00000011FA90: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 00000011FA9C: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011FAA4: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000011FAA8: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000011FAB4: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011FABC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000011FAC0: BE882004
	s_cbranch_execz 64276                                      // 00000011FAC4: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d18>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 00000011FAC8: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000011FAD4: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000011FADC: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000011FAE0: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FAE4: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000011FAE8: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000011FAF0: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000011FAFC: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011FB00: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000011FB04: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000011FB08: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000011FB10: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011FB18: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000011FB1C: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000011FB20: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000011FB24: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FB28: BF870095
	.long 0xd71c006a                                           // 00000011FB2C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000011FB30: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000011FB34: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000011FB38: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FB40: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 00000011FB44: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000011FB50: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FB54: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000011FB58: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000011FB60: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FB64: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000011FB68: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000011FB70: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000011FB74: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FB7C: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 00000011FB80: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 00000011FB84: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FB8C: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 00000011FB90: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 00000011FB94: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FB9C: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 00000011FBA0: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000011FBA8: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 00000011FBB0: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FBBC: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000011FBC0: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000011FBC8: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000011FBD4: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011FBDC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000011FBE0: BE882005
	s_cbranch_execz 64207                                      // 00000011FBE4: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d24>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 00000011FBE8: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000011FBF4: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000011FBFC: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000011FC00: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FC04: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000011FC08: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000011FC10: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000011FC1C: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011FC20: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000011FC24: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000011FC28: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000011FC30: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011FC38: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000011FC3C: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000011FC40: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000011FC44: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FC48: BF870095
	.long 0xd71c006a                                           // 00000011FC4C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000011FC50: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000011FC54: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000011FC58: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FC60: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 00000011FC64: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 00000011FC6C: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FC74: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000011FC78: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000011FC80: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FC84: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000011FC88: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000011FC90: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000011FC94: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FC9C: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 00000011FCA0: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 00000011FCA4: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FCAC: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 00000011FCB0: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 00000011FCB4: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FCBC: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000011FCC0: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000011FCC8: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 00000011FCD0: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FCDC: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000011FCE0: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000011FCE8: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000011FCF4: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011FCFC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000011FD00: BE882006
	s_cbranch_execz 64138                                      // 00000011FD04: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d30>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 00000011FD08: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000011FD14: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000011FD1C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000011FD20: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FD24: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000011FD28: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000011FD30: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000011FD3C: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011FD40: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000011FD44: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000011FD48: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000011FD50: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011FD58: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000011FD5C: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000011FD60: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000011FD64: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FD68: BF870095
	.long 0xd71c006a                                           // 00000011FD6C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000011FD70: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000011FD74: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000011FD78: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FD80: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 00000011FD84: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000011FD90: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FD94: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000011FD98: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000011FDA0: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FDA4: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000011FDA8: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000011FDB0: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000011FDB4: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FDBC: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 00000011FDC0: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 00000011FDC4: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FDCC: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 00000011FDD0: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 00000011FDD4: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FDDC: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000011FDE0: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000011FDE8: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 00000011FDF0: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FDFC: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000011FE00: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000011FE08: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000011FE14: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011FE1C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000011FE20: BE882007
	s_cbranch_execz 64069                                      // 00000011FE24: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d3c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 00000011FE28: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000011FE34: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000011FE3C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000011FE40: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FE44: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000011FE48: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000011FE50: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000011FE5C: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011FE60: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000011FE64: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000011FE68: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000011FE70: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011FE78: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000011FE7C: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000011FE80: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000011FE84: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FE88: BF870095
	.long 0xd71c006a                                           // 00000011FE8C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000011FE90: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000011FE94: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000011FE98: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FEA0: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 00000011FEA4: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000011FEB0: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FEB4: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000011FEB8: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000011FEC0: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FEC4: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000011FEC8: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000011FED0: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000011FED4: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FEDC: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 00000011FEE0: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 00000011FEE4: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FEEC: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 00000011FEF0: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 00000011FEF4: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FEFC: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000011FF00: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000011FF08: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 00000011FF10: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FF1C: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000011FF20: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000011FF28: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000011FF34: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000011FF3C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000011FF40: BE882000
	s_cbranch_execz 64000                                      // 00000011FF44: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d48>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 00000011FF48: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 00000011FF54: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 00000011FF58: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 00000011FF60: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000011FF64: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FF68: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000011FF6C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000011FF74: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000011FF80: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000011FF84: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000011FF88: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000011FF8C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000011FF94: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011FF9C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000011FFA0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000011FFA4: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000011FFA8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FFAC: BF870095
	.long 0xd71c006a                                           // 00000011FFB0: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000011FFB4: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000011FFB8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000011FFBC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FFC4: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 00000011FFC8: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000011FFD0: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FFD4: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 00000011FFD8: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 00000011FFE0: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FFE4: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 00000011FFE8: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 00000011FFF0: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 00000011FFF4: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FFFC: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 000000120000: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 000000120004: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012000C: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 000000120010: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 000000120014: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012001C: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 000000120020: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 000000120028: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 000000120030: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012003C: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 000000120040: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 000000120048: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 000000120054: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012005C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000120060: BE882001
	s_cbranch_execz 63931                                      // 000000120064: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d54>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 000000120068: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 000000120074: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 000000120078: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 000000120080: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000120084: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120088: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 00000012008C: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000120094: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 00000012009C: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000001200A8: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001200AC: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 0000001200B0: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 0000001200B8: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001200BC: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000001200C0: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000001200C4: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000001200C8: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001200CC: BF870095
	.long 0xd71c0069                                           // 0000001200D0: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000001200D4: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000001200D8: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001200DC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001200E4: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 0000001200E8: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000001200F0: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001200F4: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 0000001200F8: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 000000120100: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120104: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 000000120108: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 000000120110: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 000000120114: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012011C: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 000000120120: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 000000120124: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012012C: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 000000120130: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 000000120134: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012013C: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 000000120140: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 000000120148: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 000000120150: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012015C: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 000000120160: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 000000120168: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 000000120174: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012017C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000120180: BE882002
	s_cbranch_execz 63862                                      // 000000120184: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d60>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 000000120188: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000120194: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000012019C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000001201A0: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001201A4: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000001201A8: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 0000001201B0: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 0000001201BC: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001201C0: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 0000001201C4: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001201C8: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 0000001201D0: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001201D8: BF870121
	v_add_f32_e32 v98, v98, v105                               // 0000001201DC: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 0000001201E0: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 0000001201E4: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001201E8: BF870095
	.long 0xd71c0062                                           // 0000001201EC: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 0000001201F0: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000001201F4: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001201F8: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120200: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 000000120204: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000120210: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120214: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000120218: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 000000120220: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120224: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 000000120228: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 000000120230: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 000000120234: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012023C: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 000000120240: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 000000120244: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012024C: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 000000120250: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 000000120254: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012025C: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 000000120260: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000120268: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 000000120270: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012027C: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 000000120280: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 000000120288: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000120294: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012029C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001202A0: BE882003
	s_cbranch_execz 63793                                      // 0000001202A4: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d6c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 0000001202A8: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000001202B4: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000001202BC: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000001202C0: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001202C4: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000001202C8: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000001202D0: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 0000001202DC: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001202E0: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 0000001202E4: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 0000001202F0: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 0000001202F4: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001202F8: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000120300: BF870293
	v_exp_f32_e32 v98, v98                                     // 000000120304: 7EC44B62
	.long 0xd71c0062                                           // 000000120308: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000012030C: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120310: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000120314: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000120318: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 000000120320: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012032C: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 000000120330: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000120334: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012033C: BF870291
	v_rcp_f32_e32 v100, v99                                    // 000000120340: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 000000120344: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012034C: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 000000120350: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 000000120354: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 00000012035C: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120360: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 000000120364: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 00000012036C: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120370: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 000000120374: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 00000012037C: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120384: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000120388: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 000000120390: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 00000012039C: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001203A4: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000001203A8: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000001203B4: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001203BC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001203C0: BE882004
	s_cbranch_execz 63724                                      // 0000001203C4: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d78>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 0000001203C8: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000001203D4: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000001203DC: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000001203E0: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001203E4: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000001203E8: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000001203F0: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000001203FC: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000120400: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000120404: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000120408: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000120410: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120418: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000012041C: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000120420: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000120424: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120428: BF870095
	.long 0xd71c0062                                           // 00000012042C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000120430: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000120434: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000120438: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120440: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 000000120444: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000120450: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120454: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000120458: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000120460: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120464: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000120468: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000120470: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000120474: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012047C: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 000000120480: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 000000120484: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012048C: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 000000120490: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 000000120494: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012049C: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 0000001204A0: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000001204A8: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 0000001204B0: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001204BC: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000001204C0: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000001204C8: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000001204D4: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001204DC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001204E0: BE882005
	s_cbranch_execz 63655                                      // 0000001204E4: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d84>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 0000001204E8: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000001204F4: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000001204FC: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000120500: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120504: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000120508: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000120510: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000012051C: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000120520: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000120524: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000120528: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000120530: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120538: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000012053C: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000120540: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000120544: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120548: BF870095
	.long 0xd71c0062                                           // 00000012054C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000120550: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000120554: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000120558: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120560: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 000000120564: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 00000012056C: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120574: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000120578: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000120580: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120584: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000120588: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000120590: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000120594: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012059C: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000001205A0: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 0000001205A4: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001205AC: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 0000001205B0: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 0000001205B4: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001205BC: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000001205C0: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000001205C8: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 0000001205D0: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001205DC: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000001205E0: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000001205E8: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000001205F4: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001205FC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000120600: BE882006
	s_cbranch_execz 63586                                      // 000000120604: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d90>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 000000120608: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000120614: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000012061C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000120620: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120624: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000120628: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000120630: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000012063C: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000120640: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000120644: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000120648: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000120650: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120658: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000012065C: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000120660: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000120664: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120668: BF870095
	.long 0xd71c0062                                           // 00000012066C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000120670: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000120674: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000120678: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120680: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 000000120684: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000120690: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120694: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000120698: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000001206A0: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001206A4: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000001206A8: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000001206B0: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000001206B4: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001206BC: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000001206C0: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000001206C4: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001206CC: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000001206D0: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000001206D4: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001206DC: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000001206E0: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000001206E8: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 0000001206F0: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001206FC: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000120700: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000120708: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000120714: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012071C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000120720: BE882007
	s_cbranch_execz 63517                                      // 000000120724: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d9c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 000000120728: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000120734: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000012073C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000120740: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120744: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000120748: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000120750: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000012075C: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000120760: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000120764: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000120768: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000120770: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120778: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000012077C: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000120780: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000120784: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120788: BF870095
	.long 0xd71c0062                                           // 00000012078C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000120790: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000120794: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000120798: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001207A0: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 0000001207A4: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000001207B0: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001207B4: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000001207B8: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000001207C0: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001207C4: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000001207C8: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000001207D0: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000001207D4: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001207DC: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000001207E0: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000001207E4: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001207EC: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000001207F0: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000001207F4: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001207FC: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 000000120800: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000120808: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 000000120810: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012081C: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000120820: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000120828: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000120834: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012083C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000120840: BE882000
	s_cbranch_execz 63448                                      // 000000120844: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3da8>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 000000120848: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 000000120854: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 000000120858: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 000000120860: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000120864: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120868: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000012086C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000120874: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000120880: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000120884: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000120888: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000012088C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000120894: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012089C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000001208A0: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000001208A4: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000001208A8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001208AC: BF870095
	.long 0xd71c0062                                           // 0000001208B0: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000001208B4: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000001208B8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001208BC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001208C4: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000001208C8: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000001208D0: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001208D4: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 0000001208D8: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 0000001208E0: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001208E4: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000001208E8: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 0000001208F0: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 0000001208F4: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001208FC: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 000000120900: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 000000120904: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012090C: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 000000120910: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 000000120914: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012091C: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 000000120920: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 000000120928: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 000000120930: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012093C: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 000000120940: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 000000120948: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 000000120954: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012095C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000120960: BE882001
	s_cbranch_execz 63379                                      // 000000120964: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3db4>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 000000120968: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 000000120974: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 000000120978: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 000000120980: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000120984: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120988: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 00000012098C: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000120994: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 00000012099C: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000001209A8: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001209AC: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 0000001209B0: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 0000001209B8: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001209BC: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000001209C0: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000001209C4: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000001209C8: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001209CC: BF870095
	.long 0xd71c0061                                           // 0000001209D0: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000001209D4: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000001209D8: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000001209DC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001209E4: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 0000001209E8: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000001209F0: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001209F4: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 0000001209F8: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 000000120A00: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120A04: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 000000120A08: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 000000120A10: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 000000120A14: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120A1C: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 000000120A20: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 000000120A24: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120A2C: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 000000120A30: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 000000120A34: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120A3C: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 000000120A40: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 000000120A48: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 000000120A50: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120A5C: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 000000120A60: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 000000120A68: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 000000120A74: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 000000120A7C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000120A80: BE882002
	s_cbranch_execz 63310                                      // 000000120A84: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dc0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 000000120A88: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000120A94: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000120A9C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000120AA0: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120AA4: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000120AA8: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 000000120AB0: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 000000120ABC: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000120AC0: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 000000120AC4: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000120AC8: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 000000120AD0: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120AD8: BF870121
	v_add_f32_e32 v90, v90, v97                                // 000000120ADC: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 000000120AE0: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 000000120AE4: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120AE8: BF870095
	.long 0xd71c005a                                           // 000000120AEC: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 000000120AF0: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000120AF4: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000120AF8: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120B00: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 000000120B04: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000120B10: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120B14: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000120B18: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 000000120B20: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120B24: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 000000120B28: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 000000120B30: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 000000120B34: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120B3C: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 000000120B40: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 000000120B44: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120B4C: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 000000120B50: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 000000120B54: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120B5C: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 000000120B60: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000120B68: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 000000120B70: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120B7C: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 000000120B80: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 000000120B88: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000120B94: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000120B9C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000120BA0: BE882003
	s_cbranch_execz 63241                                      // 000000120BA4: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dcc>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 000000120BA8: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000120BB4: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000120BBC: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000120BC0: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120BC4: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000120BC8: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000120BD0: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 000000120BDC: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120BE0: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 000000120BE4: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 000000120BF0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 000000120BF4: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000120BF8: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000120C00: BF870293
	v_exp_f32_e32 v90, v90                                     // 000000120C04: 7EB44B5A
	.long 0xd71c005a                                           // 000000120C08: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000120C0C: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120C10: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000120C14: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000120C18: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 000000120C20: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120C2C: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 000000120C30: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000120C34: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000120C3C: BF870291
	v_rcp_f32_e32 v92, v91                                     // 000000120C40: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 000000120C44: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000120C4C: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 000000120C50: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 000000120C54: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 000000120C5C: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120C60: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 000000120C64: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 000000120C6C: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120C70: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 000000120C74: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 000000120C7C: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120C84: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000120C88: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 000000120C90: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 000000120C9C: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000120CA4: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000120CA8: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000120CB4: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000120CBC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000120CC0: BE882004
	s_cbranch_execz 63172                                      // 000000120CC4: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dd8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 000000120CC8: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000120CD4: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000120CDC: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000120CE0: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120CE4: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000120CE8: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000120CF0: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000120CFC: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000120D00: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000120D04: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000120D08: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000120D10: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120D18: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000120D1C: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000120D20: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000120D24: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120D28: BF870095
	.long 0xd71c005a                                           // 000000120D2C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000120D30: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000120D34: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000120D38: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120D40: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 000000120D44: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000120D50: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120D54: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000120D58: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000120D60: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120D64: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000120D68: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000120D70: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000120D74: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120D7C: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 000000120D80: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 000000120D84: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120D8C: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 000000120D90: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 000000120D94: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120D9C: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 000000120DA0: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000120DA8: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 000000120DB0: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120DBC: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000120DC0: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000120DC8: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000120DD4: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000120DDC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000120DE0: BE882005
	s_cbranch_execz 63103                                      // 000000120DE4: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3de4>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 000000120DE8: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000120DF4: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000120DFC: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000120E00: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120E04: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000120E08: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000120E10: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000120E1C: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000120E20: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000120E24: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000120E28: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000120E30: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120E38: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000120E3C: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000120E40: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000120E44: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120E48: BF870095
	.long 0xd71c005a                                           // 000000120E4C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000120E50: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000120E54: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000120E58: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120E60: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 000000120E64: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 000000120E6C: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120E74: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000120E78: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000120E80: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120E84: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000120E88: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000120E90: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000120E94: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120E9C: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000120EA0: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 000000120EA4: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120EAC: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 000000120EB0: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 000000120EB4: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120EBC: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000120EC0: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000120EC8: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 000000120ED0: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120EDC: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000120EE0: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000120EE8: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000120EF4: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000120EFC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000120F00: BE882006
	s_cbranch_execz 63034                                      // 000000120F04: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3df0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 000000120F08: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000120F14: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000120F1C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000120F20: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120F24: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000120F28: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000120F30: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000120F3C: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000120F40: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000120F44: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000120F48: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000120F50: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120F58: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000120F5C: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000120F60: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000120F64: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120F68: BF870095
	.long 0xd71c005a                                           // 000000120F6C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000120F70: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000120F74: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000120F78: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120F80: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 000000120F84: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000120F90: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120F94: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000120F98: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000120FA0: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120FA4: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000120FA8: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000120FB0: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000120FB4: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120FBC: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000120FC0: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 000000120FC4: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120FCC: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 000000120FD0: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 000000120FD4: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120FDC: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000120FE0: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000120FE8: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 000000120FF0: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120FFC: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000121000: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000121008: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000121014: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012101C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000121020: BE882007
	s_cbranch_execz 62965                                      // 000000121024: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dfc>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 000000121028: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000121034: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000012103C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000121040: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121044: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000121048: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000121050: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000012105C: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000121060: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000121064: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000121068: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000121070: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121078: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000012107C: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000121080: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000121084: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121088: BF870095
	.long 0xd71c005a                                           // 00000012108C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000121090: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000121094: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000121098: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001210A0: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 0000001210A4: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000001210B0: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001210B4: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000001210B8: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000001210C0: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001210C4: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000001210C8: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000001210D0: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000001210D4: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001210DC: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000001210E0: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000001210E4: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001210EC: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000001210F0: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000001210F4: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001210FC: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000121100: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000121108: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 000000121110: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012111C: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000121120: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000121128: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000121134: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012113C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000121140: BE882000
	s_cbranch_execz 62896                                      // 000000121144: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e08>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 000000121148: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 000000121154: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 000000121158: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 000000121160: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000121164: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121168: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000012116C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000121174: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000121180: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000121184: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000121188: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000012118C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000121194: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012119C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000001211A0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000001211A4: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000001211A8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001211AC: BF870095
	.long 0xd71c005a                                           // 0000001211B0: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000001211B4: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000001211B8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000001211BC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001211C4: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000001211C8: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000001211D0: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001211D4: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 0000001211D8: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 0000001211E0: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001211E4: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 0000001211E8: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 0000001211F0: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 0000001211F4: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001211FC: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 000000121200: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 000000121204: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012120C: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 000000121210: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 000000121214: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012121C: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 000000121220: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 000000121228: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 000000121230: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012123C: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 000000121240: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 000000121248: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 000000121254: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012125C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000121260: BE882001
	s_cbranch_execz 62827                                      // 000000121264: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e14>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 000000121268: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 000000121274: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 000000121278: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 000000121280: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000121284: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121288: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 00000012128C: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000121294: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 00000012129C: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000001212A8: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001212AC: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 0000001212B0: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 0000001212B8: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001212BC: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000001212C0: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000001212C4: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000001212C8: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001212CC: BF870095
	.long 0xd71c0059                                           // 0000001212D0: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000001212D4: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000001212D8: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000001212DC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001212E4: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 0000001212E8: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000001212F0: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001212F4: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 0000001212F8: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 000000121300: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121304: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 000000121308: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 000000121310: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 000000121314: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012131C: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 000000121320: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 000000121324: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012132C: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 000000121330: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 000000121334: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012133C: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 000000121340: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 000000121348: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 000000121350: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012135C: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 000000121360: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 000000121368: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 000000121374: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012137C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000121380: BE882002
	s_cbranch_execz 62758                                      // 000000121384: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e20>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 000000121388: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000121394: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000012139C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000001213A0: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001213A4: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000001213A8: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 0000001213B0: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 0000001213BC: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001213C0: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 0000001213C4: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000001213C8: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 0000001213D0: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001213D8: BF870121
	v_add_f32_e32 v82, v82, v89                                // 0000001213DC: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 0000001213E0: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 0000001213E4: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001213E8: BF870095
	.long 0xd71c0052                                           // 0000001213EC: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 0000001213F0: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000001213F4: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000001213F8: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121400: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 000000121404: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000121410: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121414: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000121418: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 000000121420: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121424: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 000000121428: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 000000121430: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 000000121434: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012143C: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 000000121440: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 000000121444: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012144C: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 000000121450: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 000000121454: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012145C: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 000000121460: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000121468: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 000000121470: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012147C: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 000000121480: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 000000121488: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000121494: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012149C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001214A0: BE882003
	s_cbranch_execz 62689                                      // 0000001214A4: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e2c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 0000001214A8: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000001214B4: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000001214BC: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000001214C0: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001214C4: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000001214C8: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000001214D0: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 0000001214DC: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001214E0: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 0000001214E4: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 0000001214F0: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 0000001214F4: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000001214F8: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000121500: BF870293
	v_exp_f32_e32 v82, v82                                     // 000000121504: 7EA44B52
	.long 0xd71c0052                                           // 000000121508: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000012150C: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121510: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000121514: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000121518: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 000000121520: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012152C: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 000000121530: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000121534: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012153C: BF870291
	v_rcp_f32_e32 v84, v83                                     // 000000121540: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 000000121544: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012154C: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 000000121550: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 000000121554: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 00000012155C: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121560: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 000000121564: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 00000012156C: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121570: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 000000121574: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 00000012157C: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121584: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000121588: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 000000121590: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 00000012159C: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001215A4: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000001215A8: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000001215B4: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001215BC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001215C0: BE882004
	s_cbranch_execz 62620                                      // 0000001215C4: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e38>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 0000001215C8: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000001215D4: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000001215DC: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000001215E0: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001215E4: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000001215E8: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000001215F0: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000001215FC: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000121600: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000121604: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000121608: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000121610: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121618: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000012161C: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000121620: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000121624: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121628: BF870095
	.long 0xd71c0052                                           // 00000012162C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000121630: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000121634: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000121638: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121640: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 000000121644: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000121650: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121654: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000121658: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000121660: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121664: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000121668: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000121670: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000121674: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012167C: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 000000121680: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 000000121684: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012168C: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 000000121690: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 000000121694: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012169C: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 0000001216A0: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000001216A8: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 0000001216B0: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001216BC: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000001216C0: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000001216C8: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000001216D4: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001216DC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001216E0: BE882005
	s_cbranch_execz 62551                                      // 0000001216E4: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e44>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 0000001216E8: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000001216F4: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000001216FC: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000121700: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121704: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000121708: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000121710: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000012171C: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000121720: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000121724: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000121728: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000121730: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121738: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000012173C: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000121740: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000121744: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121748: BF870095
	.long 0xd71c0052                                           // 00000012174C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000121750: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000121754: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000121758: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121760: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 000000121764: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 00000012176C: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121774: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000121778: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000121780: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121784: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000121788: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000121790: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000121794: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012179C: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000001217A0: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 0000001217A4: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001217AC: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 0000001217B0: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 0000001217B4: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001217BC: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000001217C0: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000001217C8: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 0000001217D0: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001217DC: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000001217E0: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000001217E8: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000001217F4: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001217FC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000121800: BE882006
	s_cbranch_execz 62482                                      // 000000121804: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e50>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 000000121808: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000121814: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000012181C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000121820: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121824: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000121828: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000121830: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000012183C: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000121840: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000121844: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000121848: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000121850: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121858: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000012185C: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000121860: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000121864: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121868: BF870095
	.long 0xd71c0052                                           // 00000012186C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000121870: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000121874: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000121878: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121880: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 000000121884: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000121890: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121894: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000121898: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000001218A0: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001218A4: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000001218A8: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000001218B0: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000001218B4: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001218BC: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000001218C0: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000001218C4: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001218CC: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000001218D0: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000001218D4: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001218DC: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000001218E0: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000001218E8: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 0000001218F0: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001218FC: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000121900: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000121908: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000121914: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012191C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000121920: BE882007
	s_cbranch_execz 62413                                      // 000000121924: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e5c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 000000121928: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000121934: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000012193C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000121940: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121944: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000121948: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000121950: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000012195C: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000121960: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000121964: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000121968: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000121970: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121978: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000012197C: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000121980: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000121984: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121988: BF870095
	.long 0xd71c0052                                           // 00000012198C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000121990: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000121994: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000121998: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001219A0: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 0000001219A4: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000001219B0: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001219B4: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000001219B8: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000001219C0: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001219C4: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000001219C8: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000001219D0: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000001219D4: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001219DC: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000001219E0: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000001219E4: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001219EC: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000001219F0: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000001219F4: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001219FC: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 000000121A00: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000121A08: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 000000121A10: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121A1C: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000121A20: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000121A28: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000121A34: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000121A3C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000121A40: BE882000
	s_cbranch_execz 62344                                      // 000000121A44: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e68>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 000000121A48: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 000000121A54: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 000000121A58: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000121A60: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000121A64: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121A68: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000121A6C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000121A74: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000121A80: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000121A84: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000121A88: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000121A8C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000121A94: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121A9C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000121AA0: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000121AA4: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000121AA8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121AAC: BF870095
	.long 0xd71c0052                                           // 000000121AB0: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000121AB4: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000121AB8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000121ABC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121AC4: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 000000121AC8: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000121AD0: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121AD4: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 000000121AD8: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 000000121AE0: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121AE4: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 000000121AE8: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 000000121AF0: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 000000121AF4: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121AFC: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 000000121B00: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 000000121B04: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121B0C: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 000000121B10: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 000000121B14: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121B1C: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 000000121B20: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 000000121B28: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 000000121B30: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121B3C: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 000000121B40: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 000000121B48: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 000000121B54: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 000000121B5C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000121B60: BE882001
	s_cbranch_execz 62275                                      // 000000121B64: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e74>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 000000121B68: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 000000121B74: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 000000121B78: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 000000121B80: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000121B84: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121B88: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 000000121B8C: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000121B94: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 000000121B9C: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 000000121BA8: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000121BAC: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 000000121BB0: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 000000121BB8: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121BBC: BF870121
	v_add_f32_e32 v81, v81, v82                                // 000000121BC0: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 000000121BC4: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 000000121BC8: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121BCC: BF870095
	.long 0xd71c0051                                           // 000000121BD0: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 000000121BD4: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 000000121BD8: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000121BDC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121BE4: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 000000121BE8: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000121BF0: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121BF4: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 000000121BF8: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 000000121C00: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121C04: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 000000121C08: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 000000121C10: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 000000121C14: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121C1C: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 000000121C20: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 000000121C24: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121C2C: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 000000121C30: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 000000121C34: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121C3C: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 000000121C40: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 000000121C48: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 000000121C50: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121C5C: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 000000121C60: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 000000121C68: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 000000121C74: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 000000121C7C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000121C80: BE882002
	s_cbranch_execz 62206                                      // 000000121C84: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e80>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 000000121C88: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000121C94: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000121C9C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000121CA0: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121CA4: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000121CA8: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 000000121CB0: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 000000121CBC: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000121CC0: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 000000121CC4: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000121CC8: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 000000121CD0: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121CD8: BF870121
	v_add_f32_e32 v74, v74, v81                                // 000000121CDC: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 000000121CE0: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 000000121CE4: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121CE8: BF870095
	.long 0xd71c004a                                           // 000000121CEC: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 000000121CF0: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000121CF4: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000121CF8: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121D00: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 000000121D04: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000121D10: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121D14: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000121D18: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 000000121D20: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121D24: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 000000121D28: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 000000121D30: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 000000121D34: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121D3C: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 000000121D40: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 000000121D44: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121D4C: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 000000121D50: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 000000121D54: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121D5C: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 000000121D60: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000121D68: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 000000121D70: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121D7C: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 000000121D80: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 000000121D88: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000121D94: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000121D9C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000121DA0: BE882003
	s_cbranch_execz 62137                                      // 000000121DA4: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e8c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 000000121DA8: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000121DB4: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000121DBC: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000121DC0: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121DC4: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000121DC8: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000121DD0: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 000000121DDC: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121DE0: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 000000121DE4: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 000000121DF0: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 000000121DF4: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000121DF8: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000121E00: BF870293
	v_exp_f32_e32 v74, v74                                     // 000000121E04: 7E944B4A
	.long 0xd71c004a                                           // 000000121E08: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000121E0C: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121E10: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000121E14: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000121E18: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 000000121E20: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121E2C: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 000000121E30: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000121E34: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000121E3C: BF870291
	v_rcp_f32_e32 v76, v75                                     // 000000121E40: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 000000121E44: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000121E4C: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 000000121E50: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 000000121E54: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 000000121E5C: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121E60: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 000000121E64: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 000000121E6C: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121E70: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 000000121E74: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 000000121E7C: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121E84: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000121E88: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 000000121E90: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 000000121E9C: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000121EA4: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000121EA8: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000121EB4: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000121EBC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000121EC0: BE882004
	s_cbranch_execz 62068                                      // 000000121EC4: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e98>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 000000121EC8: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000121ED4: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000121EDC: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000121EE0: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121EE4: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000121EE8: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000121EF0: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000121EFC: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000121F00: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000121F04: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000121F08: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000121F10: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121F18: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000121F1C: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000121F20: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000121F24: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121F28: BF870095
	.long 0xd71c004a                                           // 000000121F2C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000121F30: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000121F34: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000121F38: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121F40: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 000000121F44: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000121F50: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121F54: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000121F58: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000121F60: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121F64: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000121F68: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000121F70: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000121F74: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121F7C: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 000000121F80: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 000000121F84: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121F8C: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 000000121F90: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 000000121F94: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121F9C: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 000000121FA0: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000121FA8: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 000000121FB0: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121FBC: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000121FC0: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000121FC8: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000121FD4: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000121FDC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000121FE0: BE882005
	s_cbranch_execz 61999                                      // 000000121FE4: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ea4>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 000000121FE8: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000121FF4: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000121FFC: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000122000: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122004: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000122008: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000122010: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000012201C: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000122020: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000122024: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000122028: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000122030: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122038: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000012203C: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000122040: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000122044: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122048: BF870095
	.long 0xd71c004a                                           // 00000012204C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000122050: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000122054: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000122058: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122060: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 000000122064: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 00000012206C: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122074: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000122078: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000122080: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122084: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000122088: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000122090: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000122094: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012209C: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000001220A0: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 0000001220A4: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001220AC: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 0000001220B0: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 0000001220B4: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001220BC: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000001220C0: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000001220C8: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 0000001220D0: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001220DC: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000001220E0: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000001220E8: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000001220F4: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001220FC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000122100: BE882006
	s_cbranch_execz 61930                                      // 000000122104: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eb0>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 000000122108: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000122114: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000012211C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000122120: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122124: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000122128: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000122130: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000012213C: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000122140: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000122144: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000122148: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000122150: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122158: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000012215C: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000122160: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000122164: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122168: BF870095
	.long 0xd71c004a                                           // 00000012216C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000122170: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000122174: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000122178: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122180: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 000000122184: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000122190: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122194: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000122198: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000001221A0: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001221A4: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000001221A8: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000001221B0: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000001221B4: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001221BC: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000001221C0: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000001221C4: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001221CC: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000001221D0: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000001221D4: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001221DC: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000001221E0: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000001221E8: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 0000001221F0: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001221FC: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000122200: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000122208: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000122214: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012221C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000122220: BE882007
	s_cbranch_execz 61861                                      // 000000122224: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ebc>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 000000122228: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000122234: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000012223C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000122240: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122244: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000122248: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000122250: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000012225C: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000122260: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000122264: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000122268: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000122270: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122278: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000012227C: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000122280: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000122284: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122288: BF870095
	.long 0xd71c004a                                           // 00000012228C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000122290: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000122294: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000122298: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001222A0: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 0000001222A4: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000001222B0: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001222B4: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000001222B8: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000001222C0: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001222C4: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000001222C8: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000001222D0: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000001222D4: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001222DC: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000001222E0: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000001222E4: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001222EC: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000001222F0: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000001222F4: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001222FC: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 000000122300: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000122308: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 000000122310: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012231C: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000122320: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000122328: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000122334: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012233C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000122340: BE882000
	s_cbranch_execz 61792                                      // 000000122344: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ec8>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 000000122348: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 000000122354: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 000000122358: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000122360: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000122364: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122368: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000012236C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000122374: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000122380: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000122384: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000122388: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000012238C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000122394: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012239C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000001223A0: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000001223A4: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000001223A8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001223AC: BF870095
	.long 0xd71c004a                                           // 0000001223B0: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000001223B4: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000001223B8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000001223BC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001223C4: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000001223C8: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000001223D0: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001223D4: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 0000001223D8: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 0000001223E0: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001223E4: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000001223E8: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000001223F0: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 0000001223F4: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001223FC: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 000000122400: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 000000122404: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012240C: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 000000122410: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 000000122414: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012241C: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 000000122420: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 000000122428: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 000000122430: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012243C: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 000000122440: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 000000122448: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 000000122454: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012245C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000122460: BE882001
	s_cbranch_execz 61723                                      // 000000122464: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ed4>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 000000122468: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 000000122474: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 000000122478: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 000000122480: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000122484: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122488: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 00000012248C: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000122494: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 00000012249C: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000001224A8: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001224AC: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 0000001224B0: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 0000001224B8: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001224BC: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000001224C0: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000001224C4: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000001224C8: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001224CC: BF870095
	.long 0xd71c0049                                           // 0000001224D0: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000001224D4: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000001224D8: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000001224DC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001224E4: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 0000001224E8: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000001224F0: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001224F4: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 0000001224F8: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 000000122500: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122504: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 000000122508: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 000000122510: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 000000122514: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012251C: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 000000122520: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 000000122524: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012252C: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 000000122530: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 000000122534: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012253C: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 000000122540: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 000000122548: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 000000122550: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012255C: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 000000122560: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 000000122568: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 000000122574: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012257C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000122580: BE882002
	s_cbranch_execz 61654                                      // 000000122584: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ee0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 000000122588: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000122594: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 00000012259C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000001225A0: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001225A4: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000001225A8: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 0000001225B0: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 0000001225BC: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001225C0: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 0000001225C4: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000001225C8: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 0000001225D0: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001225D8: BF870121
	v_add_f32_e32 v66, v66, v73                                // 0000001225DC: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 0000001225E0: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 0000001225E4: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001225E8: BF870095
	.long 0xd71c0042                                           // 0000001225EC: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 0000001225F0: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000001225F4: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000001225F8: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122600: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 000000122604: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000122610: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122614: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000122618: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 000000122620: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122624: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 000000122628: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 000000122630: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 000000122634: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012263C: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 000000122640: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 000000122644: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012264C: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 000000122650: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 000000122654: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012265C: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 000000122660: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000122668: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 000000122670: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012267C: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 000000122680: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 000000122688: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000122694: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012269C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001226A0: BE882003
	s_cbranch_execz 61585                                      // 0000001226A4: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eec>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 0000001226A8: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000001226B4: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000001226BC: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000001226C0: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001226C4: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000001226C8: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000001226D0: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 0000001226DC: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001226E0: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 0000001226E4: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 0000001226F0: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 0000001226F4: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000001226F8: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000122700: BF870293
	v_exp_f32_e32 v66, v66                                     // 000000122704: 7E844B42
	.long 0xd71c0042                                           // 000000122708: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 00000012270C: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122710: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000122714: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000122718: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 000000122720: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012272C: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 000000122730: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000122734: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012273C: BF870291
	v_rcp_f32_e32 v68, v67                                     // 000000122740: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 000000122744: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012274C: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 000000122750: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 000000122754: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 00000012275C: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122760: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 000000122764: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 00000012276C: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122770: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 000000122774: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 00000012277C: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122784: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000122788: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 000000122790: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 00000012279C: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001227A4: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000001227A8: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000001227B4: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001227BC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001227C0: BE882004
	s_cbranch_execz 61516                                      // 0000001227C4: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ef8>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 0000001227C8: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000001227D4: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000001227DC: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000001227E0: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001227E4: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000001227E8: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000001227F0: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000001227FC: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000122800: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000122804: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000122808: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000122810: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122818: BF870121
	v_add_f32_e32 v66, v66, v67                                // 00000012281C: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000122820: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000122824: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122828: BF870095
	.long 0xd71c0042                                           // 00000012282C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000122830: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000122834: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000122838: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122840: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 000000122844: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000122850: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122854: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000122858: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000122860: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122864: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000122868: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000122870: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000122874: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012287C: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 000000122880: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 000000122884: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012288C: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 000000122890: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 000000122894: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012289C: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 0000001228A0: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000001228A8: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 0000001228B0: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001228BC: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000001228C0: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000001228C8: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000001228D4: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001228DC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001228E0: BE882005
	s_cbranch_execz 61447                                      // 0000001228E4: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f04>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 0000001228E8: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000001228F4: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000001228FC: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000122900: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122904: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000122908: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000122910: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 00000012291C: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000122920: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000122924: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000122928: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000122930: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122938: BF870121
	v_add_f32_e32 v66, v66, v67                                // 00000012293C: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000122940: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000122944: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122948: BF870095
	.long 0xd71c0042                                           // 00000012294C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000122950: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000122954: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000122958: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122960: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000122964: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 00000012296C: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122974: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000122978: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000122980: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122984: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000122988: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000122990: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000122994: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012299C: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000001229A0: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 0000001229A4: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001229AC: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 0000001229B0: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 0000001229B4: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001229BC: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000001229C0: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000001229C8: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 0000001229D0: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001229DC: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000001229E0: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000001229E8: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000001229F4: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001229FC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000122A00: BE882006
	s_cbranch_execz 61378                                      // 000000122A04: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f10>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 000000122A08: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000122A14: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000122A1C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000122A20: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122A24: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000122A28: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000122A30: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000122A3C: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000122A40: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000122A44: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000122A48: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000122A50: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122A58: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000122A5C: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000122A60: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000122A64: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122A68: BF870095
	.long 0xd71c0042                                           // 000000122A6C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000122A70: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000122A74: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000122A78: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122A80: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 000000122A84: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000122A90: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122A94: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000122A98: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000122AA0: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122AA4: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000122AA8: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000122AB0: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000122AB4: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122ABC: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000122AC0: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000122AC4: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122ACC: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 000000122AD0: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000122AD4: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122ADC: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000122AE0: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000122AE8: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 000000122AF0: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122AFC: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000122B00: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000122B08: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000122B14: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000122B1C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000122B20: BE882007
	s_cbranch_execz 61309                                      // 000000122B24: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f1c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 000000122B28: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000122B34: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000122B3C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000122B40: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122B44: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000122B48: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000122B50: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000122B5C: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000122B60: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000122B64: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000122B68: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000122B70: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122B78: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000122B7C: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000122B80: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000122B84: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122B88: BF870095
	.long 0xd71c0042                                           // 000000122B8C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000122B90: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000122B94: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000122B98: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122BA0: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 000000122BA4: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000122BB0: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122BB4: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000122BB8: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000122BC0: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122BC4: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000122BC8: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000122BD0: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000122BD4: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122BDC: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000122BE0: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000122BE4: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122BEC: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 000000122BF0: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000122BF4: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122BFC: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000122C00: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000122C08: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 000000122C10: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122C1C: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000122C20: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000122C28: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000122C34: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000122C3C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000122C40: BE882000
	s_cbranch_execz 61240                                      // 000000122C44: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f28>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 000000122C48: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 000000122C54: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 000000122C58: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 000000122C60: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000122C64: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122C68: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000122C6C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000122C74: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000122C80: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000122C84: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000122C88: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000122C8C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000122C94: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122C9C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000122CA0: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000122CA4: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000122CA8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122CAC: BF870095
	.long 0xd71c0042                                           // 000000122CB0: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000122CB4: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000122CB8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000122CBC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122CC4: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000122CC8: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000122CD0: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122CD4: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 000000122CD8: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 000000122CE0: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122CE4: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 000000122CE8: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 000000122CF0: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 000000122CF4: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122CFC: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 000000122D00: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 000000122D04: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122D0C: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 000000122D10: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 000000122D14: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122D1C: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 000000122D20: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 000000122D28: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 000000122D30: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122D3C: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 000000122D40: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 000000122D48: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 000000122D54: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000122D5C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000122D60: BE882001
	s_cbranch_execz 61171                                      // 000000122D64: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f34>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 000000122D68: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 000000122D74: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 000000122D78: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 000000122D80: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000122D84: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122D88: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 000000122D8C: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000122D94: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 000000122D9C: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 000000122DA8: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000122DAC: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 000000122DB0: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 000000122DB8: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122DBC: BF870121
	v_add_f32_e32 v65, v65, v66                                // 000000122DC0: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000122DC4: 7E841143
	v_exp_f32_e32 v65, v65                                     // 000000122DC8: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122DCC: BF870095
	.long 0xd71c0041                                           // 000000122DD0: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000122DD4: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 000000122DD8: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000122DDC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122DE4: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 000000122DE8: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000122DF0: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122DF4: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 000000122DF8: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 000000122E00: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122E04: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 000000122E08: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 000000122E10: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 000000122E14: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122E1C: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 000000122E20: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 000000122E24: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122E2C: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 000000122E30: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 000000122E34: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122E3C: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 000000122E40: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 000000122E48: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 000000122E50: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122E5C: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 000000122E60: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 000000122E68: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 000000122E74: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000122E7C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000122E80: BE882002
	s_cbranch_execz 61102                                      // 000000122E84: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f40>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 000000122E88: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000122E94: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000122E9C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000122EA0: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122EA4: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000122EA8: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 000000122EB0: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 000000122EBC: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000122EC0: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 000000122EC4: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000122EC8: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 000000122ED0: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000122ED8: BF870121
	v_add_f32_e32 v58, v58, v65                                // 000000122EDC: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 000000122EE0: 7E821142
	v_exp_f32_e32 v58, v58                                     // 000000122EE4: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122EE8: BF870095
	.long 0xd71c003a                                           // 000000122EEC: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 000000122EF0: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000122EF4: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000122EF8: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122F00: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 000000122F04: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000122F10: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122F14: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000122F18: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 000000122F20: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122F24: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 000000122F28: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 000000122F30: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 000000122F34: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122F3C: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 000000122F40: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 000000122F44: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122F4C: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 000000122F50: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 000000122F54: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122F5C: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 000000122F60: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000122F68: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 000000122F70: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122F7C: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 000000122F80: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 000000122F88: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000122F94: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000122F9C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000122FA0: BE882003
	s_cbranch_execz 61033                                      // 000000122FA4: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f4c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 000000122FA8: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000122FB4: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000122FBC: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000122FC0: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122FC4: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000122FC8: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000122FD0: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 000000122FDC: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000122FE0: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 000000122FE4: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 000000122FF0: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 000000122FF4: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000122FF8: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000123000: BF870293
	v_exp_f32_e32 v58, v58                                     // 000000123004: 7E744B3A
	.long 0xd71c003a                                           // 000000123008: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000012300C: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123010: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000123014: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000123018: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 000000123020: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012302C: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 000000123030: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000123034: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012303C: BF870291
	v_rcp_f32_e32 v60, v59                                     // 000000123040: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 000000123044: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012304C: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 000000123050: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 000000123054: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 00000012305C: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123060: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 000000123064: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 00000012306C: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123070: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 000000123074: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 00000012307C: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123084: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000123088: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 000000123090: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 00000012309C: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001230A4: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000001230A8: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000001230B4: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001230BC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001230C0: BE882004
	s_cbranch_execz 60964                                      // 0000001230C4: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f58>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 0000001230C8: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000001230D4: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000001230DC: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000001230E0: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001230E4: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000001230E8: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000001230F0: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000001230FC: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000123100: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000123104: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000123108: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000123110: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123118: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000012311C: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000123120: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000123124: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123128: BF870095
	.long 0xd71c003a                                           // 00000012312C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000123130: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000123134: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000123138: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123140: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 000000123144: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000123150: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123154: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000123158: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000123160: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123164: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000123168: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000123170: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000123174: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012317C: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 000000123180: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 000000123184: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012318C: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 000000123190: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 000000123194: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012319C: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 0000001231A0: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000001231A8: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 0000001231B0: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001231BC: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000001231C0: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000001231C8: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000001231D4: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001231DC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001231E0: BE882005
	s_cbranch_execz 60895                                      // 0000001231E4: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f64>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 0000001231E8: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000001231F4: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000001231FC: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000123200: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123204: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000123208: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000123210: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000012321C: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000123220: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000123224: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000123228: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000123230: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123238: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000012323C: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000123240: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000123244: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123248: BF870095
	.long 0xd71c003a                                           // 00000012324C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000123250: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000123254: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000123258: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123260: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 000000123264: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 00000012326C: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123274: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000123278: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000123280: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123284: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000123288: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000123290: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000123294: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012329C: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000001232A0: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 0000001232A4: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001232AC: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 0000001232B0: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 0000001232B4: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001232BC: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000001232C0: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000001232C8: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 0000001232D0: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001232DC: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000001232E0: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000001232E8: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000001232F4: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001232FC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000123300: BE882006
	s_cbranch_execz 60826                                      // 000000123304: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f70>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 000000123308: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000123314: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000012331C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000123320: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123324: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000123328: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000123330: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000012333C: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000123340: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000123344: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000123348: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000123350: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123358: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000012335C: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000123360: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000123364: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123368: BF870095
	.long 0xd71c003a                                           // 00000012336C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000123370: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000123374: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000123378: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123380: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 000000123384: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000123390: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123394: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000123398: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000001233A0: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001233A4: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000001233A8: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000001233B0: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000001233B4: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001233BC: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000001233C0: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000001233C4: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001233CC: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000001233D0: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000001233D4: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001233DC: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000001233E0: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000001233E8: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 0000001233F0: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001233FC: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000123400: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000123408: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000123414: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012341C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000123420: BE882007
	s_cbranch_execz 60757                                      // 000000123424: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f7c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 000000123428: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000123434: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 00000012343C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000123440: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123444: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000123448: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000123450: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 00000012345C: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000123460: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000123464: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000123468: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000123470: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123478: BF870121
	v_add_f32_e32 v58, v58, v59                                // 00000012347C: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000123480: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000123484: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123488: BF870095
	.long 0xd71c003a                                           // 00000012348C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000123490: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000123494: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000123498: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001234A0: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 0000001234A4: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000001234B0: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001234B4: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000001234B8: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000001234C0: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001234C4: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000001234C8: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000001234D0: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000001234D4: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001234DC: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000001234E0: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000001234E4: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001234EC: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000001234F0: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000001234F4: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001234FC: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 000000123500: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000123508: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 000000123510: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012351C: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000123520: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000123528: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000123534: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012353C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000123540: BE882000
	s_cbranch_execz 60688                                      // 000000123544: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f88>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 000000123548: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 000000123554: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 000000123558: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 000000123560: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000123564: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123568: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000012356C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000123574: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000123580: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000123584: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000123588: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000012358C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000123594: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012359C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000001235A0: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000001235A4: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000001235A8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001235AC: BF870095
	.long 0xd71c003a                                           // 0000001235B0: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000001235B4: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000001235B8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000001235BC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001235C4: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000001235C8: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000001235D0: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001235D4: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 0000001235D8: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 0000001235E0: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001235E4: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 0000001235E8: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 0000001235F0: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 0000001235F4: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001235FC: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 000000123600: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 000000123604: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012360C: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 000000123610: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 000000123614: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012361C: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 000000123620: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 000000123628: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 000000123630: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012363C: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 000000123640: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 000000123648: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 000000123654: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012365C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000123660: BE882001
	s_cbranch_execz 60619                                      // 000000123664: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f94>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 000000123668: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 000000123674: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 000000123678: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 000000123680: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000123684: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123688: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 00000012368C: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000123694: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 00000012369C: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 0000001236A8: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001236AC: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 0000001236B0: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 0000001236B8: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001236BC: BF870121
	v_add_f32_e32 v57, v57, v58                                // 0000001236C0: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 0000001236C4: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 0000001236C8: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001236CC: BF870095
	.long 0xd71c0039                                           // 0000001236D0: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000001236D4: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000001236D8: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001236DC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001236E4: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 0000001236E8: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000001236F0: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001236F4: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 0000001236F8: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 000000123700: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123704: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 000000123708: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 000000123710: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 000000123714: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012371C: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 000000123720: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 000000123724: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012372C: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 000000123730: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 000000123734: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012373C: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 000000123740: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 000000123748: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 000000123750: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012375C: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 000000123760: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 000000123768: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 000000123774: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012377C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000123780: BE882002
	s_cbranch_execz 60550                                      // 000000123784: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fa0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 000000123788: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000123794: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 00000012379C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000001237A0: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001237A4: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000001237A8: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 0000001237B0: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 0000001237BC: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001237C0: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 0000001237C4: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001237C8: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 0000001237D0: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001237D8: BF870121
	v_add_f32_e32 v50, v50, v57                                // 0000001237DC: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 0000001237E0: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 0000001237E4: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001237E8: BF870095
	.long 0xd71c0032                                           // 0000001237EC: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 0000001237F0: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000001237F4: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001237F8: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123800: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 000000123804: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000123810: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123814: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000123818: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 000000123820: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123824: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 000000123828: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 000000123830: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 000000123834: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012383C: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 000000123840: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 000000123844: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012384C: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 000000123850: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 000000123854: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012385C: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 000000123860: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000123868: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 000000123870: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012387C: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 000000123880: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 000000123888: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000123894: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012389C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001238A0: BE882003
	s_cbranch_execz 60481                                      // 0000001238A4: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fac>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 0000001238A8: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000001238B4: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000001238BC: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000001238C0: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001238C4: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000001238C8: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000001238D0: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 0000001238DC: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001238E0: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 0000001238E4: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 0000001238F0: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 0000001238F4: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001238F8: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000123900: BF870293
	v_exp_f32_e32 v50, v50                                     // 000000123904: 7E644B32
	.long 0xd71c0032                                           // 000000123908: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000012390C: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123910: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000123914: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000123918: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 000000123920: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012392C: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 000000123930: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000123934: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012393C: BF870291
	v_rcp_f32_e32 v52, v51                                     // 000000123940: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 000000123944: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012394C: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 000000123950: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 000000123954: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 00000012395C: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123960: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 000000123964: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 00000012396C: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123970: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 000000123974: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 00000012397C: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123984: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000123988: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 000000123990: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 00000012399C: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001239A4: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000001239A8: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000001239B4: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001239BC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001239C0: BE882004
	s_cbranch_execz 60412                                      // 0000001239C4: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fb8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 0000001239C8: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000001239D4: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000001239DC: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000001239E0: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001239E4: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000001239E8: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000001239F0: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000001239FC: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000123A00: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000123A04: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000123A08: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000123A10: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123A18: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000123A1C: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000123A20: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000123A24: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123A28: BF870095
	.long 0xd71c0032                                           // 000000123A2C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000123A30: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000123A34: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000123A38: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123A40: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 000000123A44: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000123A50: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123A54: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000123A58: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000123A60: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123A64: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000123A68: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000123A70: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000123A74: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123A7C: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 000000123A80: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 000000123A84: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123A8C: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 000000123A90: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 000000123A94: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123A9C: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 000000123AA0: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000123AA8: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 000000123AB0: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123ABC: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000123AC0: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000123AC8: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000123AD4: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000123ADC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000123AE0: BE882005
	s_cbranch_execz 60343                                      // 000000123AE4: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fc4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 000000123AE8: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000123AF4: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000123AFC: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000123B00: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123B04: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000123B08: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000123B10: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000123B1C: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000123B20: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000123B24: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000123B28: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000123B30: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123B38: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000123B3C: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000123B40: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000123B44: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123B48: BF870095
	.long 0xd71c0032                                           // 000000123B4C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000123B50: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000123B54: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000123B58: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123B60: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000123B64: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 000000123B6C: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123B74: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000123B78: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000123B80: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123B84: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000123B88: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000123B90: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000123B94: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123B9C: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000123BA0: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 000000123BA4: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123BAC: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 000000123BB0: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 000000123BB4: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123BBC: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000123BC0: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000123BC8: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 000000123BD0: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123BDC: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000123BE0: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000123BE8: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000123BF4: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000123BFC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000123C00: BE882006
	s_cbranch_execz 60274                                      // 000000123C04: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fd0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 000000123C08: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000123C14: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000123C1C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000123C20: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123C24: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000123C28: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000123C30: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000123C3C: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000123C40: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000123C44: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000123C48: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000123C50: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123C58: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000123C5C: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000123C60: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000123C64: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123C68: BF870095
	.long 0xd71c0032                                           // 000000123C6C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000123C70: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000123C74: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000123C78: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123C80: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 000000123C84: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000123C90: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123C94: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000123C98: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000123CA0: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123CA4: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000123CA8: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000123CB0: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000123CB4: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123CBC: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000123CC0: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000123CC4: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123CCC: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 000000123CD0: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000123CD4: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123CDC: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000123CE0: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000123CE8: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 000000123CF0: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123CFC: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000123D00: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000123D08: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000123D14: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000123D1C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000123D20: BE882007
	s_cbranch_execz 60205                                      // 000000123D24: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fdc>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 000000123D28: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000123D34: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000123D3C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000123D40: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123D44: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000123D48: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000123D50: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000123D5C: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000123D60: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000123D64: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000123D68: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000123D70: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123D78: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000123D7C: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000123D80: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000123D84: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123D88: BF870095
	.long 0xd71c0032                                           // 000000123D8C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000123D90: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000123D94: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000123D98: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123DA0: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 000000123DA4: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000123DB0: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123DB4: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000123DB8: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000123DC0: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123DC4: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000123DC8: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000123DD0: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000123DD4: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123DDC: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000123DE0: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000123DE4: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123DEC: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 000000123DF0: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000123DF4: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123DFC: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000123E00: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000123E08: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 000000123E10: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123E1C: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000123E20: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000123E28: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000123E34: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000123E3C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000123E40: BE882000
	s_cbranch_execz 60136                                      // 000000123E44: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fe8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 000000123E48: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 000000123E54: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 000000123E58: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 000000123E60: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000123E64: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123E68: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000123E6C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000123E74: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000123E80: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000123E84: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000123E88: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000123E8C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000123E94: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123E9C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000123EA0: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000123EA4: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000123EA8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123EAC: BF870095
	.long 0xd71c0032                                           // 000000123EB0: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000123EB4: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000123EB8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000123EBC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123EC4: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000123EC8: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000123ED0: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123ED4: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 000000123ED8: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 000000123EE0: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123EE4: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 000000123EE8: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 000000123EF0: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 000000123EF4: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123EFC: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 000000123F00: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 000000123F04: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123F0C: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 000000123F10: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 000000123F14: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123F1C: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 000000123F20: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 000000123F28: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 000000123F30: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123F3C: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 000000123F40: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 000000123F48: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 000000123F54: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000123F5C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000123F60: BE882001
	s_cbranch_execz 60067                                      // 000000123F64: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ff4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 000000123F68: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 000000123F74: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 000000123F78: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 000000123F80: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000123F84: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123F88: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 000000123F8C: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000123F94: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 000000123F9C: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 000000123FA8: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000123FAC: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 000000123FB0: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 000000123FB8: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000123FBC: BF870121
	v_add_f32_e32 v49, v49, v50                                // 000000123FC0: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 000000123FC4: 7E641133
	v_exp_f32_e32 v49, v49                                     // 000000123FC8: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123FCC: BF870095
	.long 0xd71c0031                                           // 000000123FD0: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 000000123FD4: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 000000123FD8: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000123FDC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123FE4: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 000000123FE8: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000123FF0: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000123FF4: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 000000123FF8: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 000000124000: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124004: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 000000124008: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 000000124010: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 000000124014: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012401C: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 000000124020: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 000000124024: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012402C: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 000000124030: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 000000124034: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012403C: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 000000124040: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 000000124048: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 000000124050: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012405C: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 000000124060: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 000000124068: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 000000124074: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012407C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000124080: BE882002
	s_cbranch_execz 59998                                      // 000000124084: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4000>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 000000124088: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000124094: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000012409C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000001240A0: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001240A4: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000001240A8: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 0000001240B0: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 0000001240BC: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001240C0: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 0000001240C4: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000001240C8: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 0000001240D0: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001240D8: BF870121
	v_add_f32_e32 v42, v42, v49                                // 0000001240DC: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 0000001240E0: 7E621132
	v_exp_f32_e32 v42, v42                                     // 0000001240E4: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001240E8: BF870095
	.long 0xd71c002a                                           // 0000001240EC: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 0000001240F0: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000001240F4: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000001240F8: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124100: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 000000124104: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000124110: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124114: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000124118: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 000000124120: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124124: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 000000124128: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 000000124130: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 000000124134: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012413C: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 000000124140: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 000000124144: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012414C: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 000000124150: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 000000124154: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012415C: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 000000124160: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000124168: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 000000124170: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012417C: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 000000124180: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 000000124188: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000124194: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012419C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001241A0: BE882003
	s_cbranch_execz 59929                                      // 0000001241A4: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x400c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 0000001241A8: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000001241B4: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000001241BC: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000001241C0: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001241C4: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000001241C8: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000001241D0: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 0000001241DC: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001241E0: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 0000001241E4: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 0000001241F0: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 0000001241F4: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000001241F8: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000124200: BF870293
	v_exp_f32_e32 v42, v42                                     // 000000124204: 7E544B2A
	.long 0xd71c002a                                           // 000000124208: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000012420C: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000124210: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000124214: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000124218: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 000000124220: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012422C: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 000000124230: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000124234: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012423C: BF870291
	v_rcp_f32_e32 v44, v43                                     // 000000124240: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 000000124244: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012424C: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 000000124250: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 000000124254: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 00000012425C: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124260: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 000000124264: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 00000012426C: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124270: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 000000124274: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 00000012427C: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000124284: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000124288: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 000000124290: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 00000012429C: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001242A4: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000001242A8: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000001242B4: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001242BC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001242C0: BE882004
	s_cbranch_execz 59860                                      // 0000001242C4: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4018>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 0000001242C8: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000001242D4: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000001242DC: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000001242E0: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001242E4: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000001242E8: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000001242F0: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000001242FC: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000124300: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000124304: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000124308: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000124310: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000124318: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000012431C: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000124320: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000124324: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124328: BF870095
	.long 0xd71c002a                                           // 00000012432C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000124330: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000124334: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000124338: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124340: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 000000124344: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000124350: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124354: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000124358: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000124360: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124364: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000124368: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000124370: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000124374: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012437C: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 000000124380: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 000000124384: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012438C: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 000000124390: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 000000124394: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012439C: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 0000001243A0: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000001243A8: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 0000001243B0: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001243BC: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000001243C0: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000001243C8: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000001243D4: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001243DC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001243E0: BE882005
	s_cbranch_execz 59791                                      // 0000001243E4: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4024>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 0000001243E8: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000001243F4: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000001243FC: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000124400: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124404: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000124408: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000124410: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000012441C: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000124420: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000124424: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000124428: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000124430: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000124438: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000012443C: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000124440: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000124444: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124448: BF870095
	.long 0xd71c002a                                           // 00000012444C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000124450: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000124454: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000124458: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124460: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 000000124464: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 00000012446C: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124474: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000124478: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000124480: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124484: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000124488: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000124490: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000124494: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012449C: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000001244A0: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 0000001244A4: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001244AC: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 0000001244B0: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 0000001244B4: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001244BC: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000001244C0: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000001244C8: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 0000001244D0: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001244DC: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000001244E0: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000001244E8: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000001244F4: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001244FC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000124500: BE882006
	s_cbranch_execz 59722                                      // 000000124504: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4030>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 000000124508: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000124514: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000012451C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000124520: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124524: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000124528: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000124530: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000012453C: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000124540: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000124544: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000124548: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000124550: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000124558: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000012455C: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000124560: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000124564: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124568: BF870095
	.long 0xd71c002a                                           // 00000012456C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000124570: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000124574: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000124578: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124580: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 000000124584: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000124590: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124594: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000124598: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000001245A0: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001245A4: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000001245A8: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000001245B0: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000001245B4: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001245BC: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000001245C0: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000001245C4: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001245CC: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000001245D0: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000001245D4: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001245DC: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000001245E0: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000001245E8: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 0000001245F0: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001245FC: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000124600: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000124608: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000124614: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012461C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000124620: BE882007
	s_cbranch_execz 59653                                      // 000000124624: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x403c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 000000124628: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000124634: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 00000012463C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000124640: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124644: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000124648: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000124650: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 00000012465C: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000124660: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000124664: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000124668: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000124670: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000124678: BF870121
	v_add_f32_e32 v42, v42, v43                                // 00000012467C: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000124680: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000124684: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124688: BF870095
	.long 0xd71c002a                                           // 00000012468C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000124690: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000124694: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000124698: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001246A0: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 0000001246A4: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000001246B0: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001246B4: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000001246B8: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000001246C0: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001246C4: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000001246C8: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000001246D0: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000001246D4: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001246DC: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000001246E0: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000001246E4: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001246EC: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000001246F0: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000001246F4: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001246FC: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 000000124700: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000124708: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 000000124710: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012471C: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000124720: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000124728: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000124734: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012473C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000124740: BE882000
	s_cbranch_execz 59584                                      // 000000124744: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4048>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 000000124748: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 000000124754: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 000000124758: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 000000124760: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000124764: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124768: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000012476C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000124774: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000124780: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000124784: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000124788: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000012478C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000124794: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012479C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000001247A0: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000001247A4: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000001247A8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001247AC: BF870095
	.long 0xd71c002a                                           // 0000001247B0: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000001247B4: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000001247B8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000001247BC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001247C4: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000001247C8: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000001247D0: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001247D4: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 0000001247D8: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 0000001247E0: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001247E4: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000001247E8: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000001247F0: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 0000001247F4: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001247FC: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 000000124800: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 000000124804: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012480C: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 000000124810: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 000000124814: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012481C: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 000000124820: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 000000124828: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 000000124830: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012483C: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 000000124840: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 000000124848: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 000000124854: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012485C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000124860: BE882001
	s_cbranch_execz 59515                                      // 000000124864: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4054>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 000000124868: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 000000124874: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 000000124878: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 000000124880: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000124884: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000124888: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 00000012488C: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000124894: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 00000012489C: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000001248A8: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001248AC: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 0000001248B0: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 0000001248B8: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001248BC: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000001248C0: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000001248C4: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 0000001248C8: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001248CC: BF870095
	.long 0xd71c0029                                           // 0000001248D0: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000001248D4: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000001248D8: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000001248DC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001248E4: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 0000001248E8: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000001248F0: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001248F4: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 0000001248F8: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 000000124900: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124904: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 000000124908: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 000000124910: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 000000124914: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012491C: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 000000124920: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 000000124924: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012492C: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 000000124930: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 000000124934: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012493C: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 000000124940: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 000000124948: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 000000124950: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012495C: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 000000124960: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 000000124968: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 000000124974: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012497C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000124980: BE882002
	s_cbranch_execz 59446                                      // 000000124984: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4060>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 000000124988: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000124994: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 00000012499C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000001249A0: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001249A4: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000001249A8: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 0000001249B0: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 0000001249BC: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001249C0: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 0000001249C4: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000001249C8: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 0000001249D0: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001249D8: BF870121
	v_add_f32_e32 v34, v34, v41                                // 0000001249DC: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 0000001249E0: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 0000001249E4: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001249E8: BF870095
	.long 0xd71c0022                                           // 0000001249EC: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 0000001249F0: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000001249F4: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000001249F8: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124A00: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 000000124A04: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000124A10: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124A14: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000124A18: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 000000124A20: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124A24: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 000000124A28: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 000000124A30: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 000000124A34: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124A3C: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 000000124A40: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 000000124A44: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124A4C: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 000000124A50: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 000000124A54: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124A5C: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 000000124A60: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000124A68: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 000000124A70: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124A7C: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 000000124A80: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 000000124A88: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000124A94: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000124A9C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000124AA0: BE882003
	s_cbranch_execz 59377                                      // 000000124AA4: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x406c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 000000124AA8: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000124AB4: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000124ABC: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000124AC0: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124AC4: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000124AC8: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000124AD0: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 000000124ADC: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124AE0: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 000000124AE4: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 000000124AF0: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 000000124AF4: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000124AF8: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000124B00: BF870293
	v_exp_f32_e32 v34, v34                                     // 000000124B04: 7E444B22
	.long 0xd71c0022                                           // 000000124B08: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000124B0C: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000124B10: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000124B14: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000124B18: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 000000124B20: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124B2C: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 000000124B30: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000124B34: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000124B3C: BF870291
	v_rcp_f32_e32 v36, v35                                     // 000000124B40: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 000000124B44: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000124B4C: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 000000124B50: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 000000124B54: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 000000124B5C: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124B60: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 000000124B64: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 000000124B6C: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124B70: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 000000124B74: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 000000124B7C: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000124B84: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000124B88: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 000000124B90: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 000000124B9C: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 000000124BA4: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000124BA8: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000124BB4: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000124BBC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000124BC0: BE882004
	s_cbranch_execz 59308                                      // 000000124BC4: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4078>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 000000124BC8: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000124BD4: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000124BDC: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000124BE0: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124BE4: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000124BE8: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000124BF0: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000124BFC: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000124C00: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000124C04: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000124C08: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000124C10: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000124C18: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000124C1C: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000124C20: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000124C24: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124C28: BF870095
	.long 0xd71c0022                                           // 000000124C2C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000124C30: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000124C34: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000124C38: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124C40: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 000000124C44: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000124C50: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124C54: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000124C58: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000124C60: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124C64: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000124C68: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000124C70: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000124C74: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124C7C: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 000000124C80: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 000000124C84: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124C8C: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 000000124C90: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 000000124C94: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124C9C: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 000000124CA0: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000124CA8: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 000000124CB0: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124CBC: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000124CC0: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000124CC8: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000124CD4: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000124CDC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000124CE0: BE882005
	s_cbranch_execz 59239                                      // 000000124CE4: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4084>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 000000124CE8: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000124CF4: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000124CFC: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000124D00: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124D04: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000124D08: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000124D10: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000124D1C: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000124D20: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000124D24: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000124D28: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000124D30: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000124D38: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000124D3C: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000124D40: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000124D44: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124D48: BF870095
	.long 0xd71c0022                                           // 000000124D4C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000124D50: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000124D54: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000124D58: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124D60: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 000000124D64: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 000000124D6C: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124D74: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000124D78: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000124D80: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124D84: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000124D88: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000124D90: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000124D94: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124D9C: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000124DA0: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 000000124DA4: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124DAC: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 000000124DB0: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 000000124DB4: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124DBC: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000124DC0: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000124DC8: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 000000124DD0: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124DDC: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000124DE0: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000124DE8: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000124DF4: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000124DFC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000124E00: BE882006
	s_cbranch_execz 59170                                      // 000000124E04: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4090>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 000000124E08: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000124E14: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000124E1C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000124E20: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124E24: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000124E28: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000124E30: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000124E3C: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000124E40: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000124E44: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000124E48: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000124E50: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000124E58: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000124E5C: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000124E60: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000124E64: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124E68: BF870095
	.long 0xd71c0022                                           // 000000124E6C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000124E70: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000124E74: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000124E78: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124E80: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 000000124E84: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000124E90: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124E94: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000124E98: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000124EA0: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124EA4: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000124EA8: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000124EB0: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000124EB4: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124EBC: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000124EC0: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000124EC4: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124ECC: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 000000124ED0: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000124ED4: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124EDC: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000124EE0: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000124EE8: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 000000124EF0: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124EFC: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000124F00: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000124F08: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000124F14: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000124F1C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000124F20: BE882007
	s_cbranch_execz 59101                                      // 000000124F24: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x409c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 000000124F28: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000124F34: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000124F3C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000124F40: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124F44: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000124F48: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000124F50: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000124F5C: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000124F60: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000124F64: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000124F68: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000124F70: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000124F78: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000124F7C: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000124F80: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000124F84: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124F88: BF870095
	.long 0xd71c0022                                           // 000000124F8C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000124F90: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000124F94: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000124F98: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124FA0: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 000000124FA4: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000124FB0: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124FB4: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000124FB8: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000124FC0: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124FC4: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000124FC8: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000124FD0: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000124FD4: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124FDC: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000124FE0: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000124FE4: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124FEC: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 000000124FF0: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000124FF4: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124FFC: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000125000: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000125008: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 000000125010: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012501C: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000125020: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000125028: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000125034: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012503C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000125040: BE882000
	s_cbranch_execz 59032                                      // 000000125044: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40a8>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 000000125048: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 000000125054: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 000000125058: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 000000125060: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000125064: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125068: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000012506C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000125074: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000125080: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000125084: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000125088: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000012508C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000125094: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012509C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000001250A0: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000001250A4: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000001250A8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001250AC: BF870095
	.long 0xd71c0022                                           // 0000001250B0: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000001250B4: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000001250B8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000001250BC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001250C4: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000001250C8: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000001250D0: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001250D4: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 0000001250D8: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 0000001250E0: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001250E4: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000001250E8: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000001250F0: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 0000001250F4: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001250FC: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 000000125100: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 000000125104: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012510C: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 000000125110: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 000000125114: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012511C: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 000000125120: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 000000125128: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 000000125130: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012513C: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 000000125140: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 000000125148: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 000000125154: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012515C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000125160: BE882001
	s_cbranch_execz 58963                                      // 000000125164: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40b4>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 000000125168: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 000000125174: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 000000125178: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 000000125180: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000125184: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125188: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 00000012518C: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000125194: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 00000012519C: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000001251A8: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001251AC: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 0000001251B0: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 0000001251B8: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001251BC: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000001251C0: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 0000001251C4: 7E441123
	v_exp_f32_e32 v33, v33                                     // 0000001251C8: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001251CC: BF870095
	.long 0xd71c0021                                           // 0000001251D0: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000001251D4: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000001251D8: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001251DC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001251E4: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 0000001251E8: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000001251F0: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001251F4: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 0000001251F8: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 000000125200: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125204: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 000000125208: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 000000125210: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 000000125214: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012521C: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 000000125220: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 000000125224: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012522C: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 000000125230: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 000000125234: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012523C: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 000000125240: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 000000125248: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 000000125250: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012525C: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 000000125260: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 000000125268: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 000000125274: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012527C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000125280: BE882002
	s_cbranch_execz 58894                                      // 000000125284: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40c0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 000000125288: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000125294: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000012529C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000001252A0: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001252A4: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000001252A8: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 0000001252B0: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 0000001252BC: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001252C0: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 0000001252C4: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000001252C8: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 0000001252D0: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001252D8: BF870121
	v_add_f32_e32 v26, v26, v33                                // 0000001252DC: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 0000001252E0: 7E421122
	v_exp_f32_e32 v26, v26                                     // 0000001252E4: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001252E8: BF870095
	.long 0xd71c001a                                           // 0000001252EC: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 0000001252F0: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000001252F4: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001252F8: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125300: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 000000125304: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000125310: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125314: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000125318: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 000000125320: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125324: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 000000125328: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 000000125330: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 000000125334: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012533C: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 000000125340: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 000000125344: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012534C: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 000000125350: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 000000125354: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012535C: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 000000125360: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000125368: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 000000125370: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012537C: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 000000125380: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 000000125388: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000125394: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012539C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001253A0: BE882003
	s_cbranch_execz 58825                                      // 0000001253A4: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40cc>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 0000001253A8: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000001253B4: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000001253BC: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000001253C0: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001253C4: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000001253C8: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000001253D0: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 0000001253DC: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001253E0: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 0000001253E4: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 0000001253F0: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 0000001253F4: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000001253F8: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000125400: BF870293
	v_exp_f32_e32 v26, v26                                     // 000000125404: 7E344B1A
	.long 0xd71c001a                                           // 000000125408: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000012540C: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125410: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000125414: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000125418: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 000000125420: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012542C: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 000000125430: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000125434: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012543C: BF870291
	v_rcp_f32_e32 v28, v27                                     // 000000125440: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 000000125444: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012544C: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 000000125450: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 000000125454: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 00000012545C: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125460: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 000000125464: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 00000012546C: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125470: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 000000125474: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 00000012547C: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125484: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000125488: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 000000125490: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 00000012549C: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001254A4: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001254A8: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000001254B4: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001254BC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001254C0: BE882004
	s_cbranch_execz 58756                                      // 0000001254C4: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40d8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 0000001254C8: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000001254D4: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000001254DC: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000001254E0: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001254E4: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000001254E8: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000001254F0: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000001254FC: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000125500: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000125504: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000125508: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000125510: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125518: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000012551C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000125520: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000125524: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125528: BF870095
	.long 0xd71c001a                                           // 00000012552C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000125530: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000125534: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000125538: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125540: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 000000125544: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000125550: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125554: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000125558: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000125560: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125564: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000125568: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000125570: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000125574: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012557C: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 000000125580: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 000000125584: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012558C: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 000000125590: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 000000125594: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012559C: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 0000001255A0: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000001255A8: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 0000001255B0: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001255BC: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001255C0: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001255C8: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000001255D4: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001255DC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001255E0: BE882005
	s_cbranch_execz 58687                                      // 0000001255E4: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40e4>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 0000001255E8: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000001255F4: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000001255FC: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000125600: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125604: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000125608: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000125610: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000012561C: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000125620: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000125624: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000125628: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000125630: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125638: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000012563C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000125640: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000125644: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125648: BF870095
	.long 0xd71c001a                                           // 00000012564C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000125650: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000125654: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000125658: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125660: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 000000125664: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 00000012566C: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125674: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000125678: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000125680: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125684: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000125688: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000125690: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000125694: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012569C: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000001256A0: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 0000001256A4: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001256AC: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 0000001256B0: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 0000001256B4: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001256BC: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000001256C0: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000001256C8: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 0000001256D0: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001256DC: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001256E0: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001256E8: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000001256F4: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001256FC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000125700: BE882006
	s_cbranch_execz 58618                                      // 000000125704: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40f0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 000000125708: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000125714: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000012571C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000125720: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125724: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000125728: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000125730: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000012573C: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000125740: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000125744: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000125748: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000125750: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125758: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000012575C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000125760: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000125764: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125768: BF870095
	.long 0xd71c001a                                           // 00000012576C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000125770: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000125774: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000125778: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125780: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 000000125784: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000125790: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125794: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000125798: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000001257A0: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001257A4: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000001257A8: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000001257B0: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000001257B4: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001257BC: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000001257C0: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000001257C4: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001257CC: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000001257D0: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000001257D4: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001257DC: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000001257E0: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000001257E8: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 0000001257F0: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001257FC: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000125800: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000125808: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000125814: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012581C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000125820: BE882007
	s_cbranch_execz 58549                                      // 000000125824: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40fc>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 000000125828: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000125834: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 00000012583C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000125840: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125844: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000125848: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000125850: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000012585C: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000125860: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000125864: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000125868: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000125870: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125878: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000012587C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000125880: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000125884: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125888: BF870095
	.long 0xd71c001a                                           // 00000012588C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000125890: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000125894: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000125898: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001258A0: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 0000001258A4: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000001258B0: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001258B4: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000001258B8: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000001258C0: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001258C4: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000001258C8: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000001258D0: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000001258D4: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001258DC: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000001258E0: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000001258E4: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001258EC: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000001258F0: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000001258F4: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001258FC: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000125900: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000125908: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 000000125910: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012591C: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000125920: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000125928: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000125934: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012593C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000125940: BE882000
	s_cbranch_execz 58480                                      // 000000125944: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4108>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 000000125948: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 000000125954: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 000000125958: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 000000125960: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000125964: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125968: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000012596C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000125974: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000125980: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000125984: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000125988: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000012598C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000125994: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012599C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000001259A0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000001259A4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000001259A8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001259AC: BF870095
	.long 0xd71c001a                                           // 0000001259B0: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000001259B4: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000001259B8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001259BC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001259C4: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 0000001259C8: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000001259D0: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001259D4: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 0000001259D8: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 0000001259E0: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001259E4: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 0000001259E8: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 0000001259F0: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 0000001259F4: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001259FC: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 000000125A00: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 000000125A04: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125A0C: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 000000125A10: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 000000125A14: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125A1C: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 000000125A20: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 000000125A28: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 000000125A30: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125A3C: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 000000125A40: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 000000125A48: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 000000125A54: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 000000125A5C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000125A60: BE882001
	s_cbranch_execz 58411                                      // 000000125A64: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4114>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 000000125A68: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 000000125A74: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 000000125A78: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 000000125A80: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000125A84: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125A88: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 000000125A8C: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000125A94: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 000000125A9C: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 000000125AA8: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000125AAC: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 000000125AB0: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 000000125AB8: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125ABC: BF870121
	v_add_f32_e32 v25, v25, v26                                // 000000125AC0: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 000000125AC4: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 000000125AC8: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125ACC: BF870095
	.long 0xd71c0019                                           // 000000125AD0: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000125AD4: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000125AD8: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000125ADC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125AE4: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 000000125AE8: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000125AF0: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125AF4: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 000000125AF8: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 000000125B00: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125B04: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 000000125B08: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 000000125B10: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 000000125B14: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125B1C: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 000000125B20: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 000000125B24: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125B2C: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 000000125B30: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 000000125B34: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125B3C: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 000000125B40: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 000000125B48: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 000000125B50: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125B5C: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 000000125B60: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 000000125B68: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 000000125B74: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 000000125B7C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000125B80: BE882002
	s_cbranch_execz 58342                                      // 000000125B84: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4120>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 000000125B88: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000125B94: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000125B9C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000125BA0: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125BA4: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000125BA8: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 000000125BB0: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 000000125BBC: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000125BC0: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 000000125BC4: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000125BC8: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 000000125BD0: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125BD8: BF870121
	v_add_f32_e32 v18, v18, v25                                // 000000125BDC: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 000000125BE0: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 000000125BE4: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125BE8: BF870095
	.long 0xd71c0012                                           // 000000125BEC: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 000000125BF0: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000125BF4: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000125BF8: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125C00: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 000000125C04: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000125C10: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125C14: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000125C18: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 000000125C20: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125C24: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 000000125C28: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 000000125C30: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 000000125C34: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125C3C: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 000000125C40: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 000000125C44: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125C4C: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 000000125C50: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 000000125C54: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125C5C: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 000000125C60: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000125C68: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 000000125C70: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125C7C: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 000000125C80: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 000000125C88: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000125C94: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000125C9C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000125CA0: BE882003
	s_cbranch_execz 58273                                      // 000000125CA4: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x412c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 000000125CA8: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000125CB4: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000125CBC: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000125CC0: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125CC4: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000125CC8: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000125CD0: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 000000125CDC: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125CE0: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 000000125CE4: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 000000125CF0: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 000000125CF4: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000125CF8: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000125D00: BF870293
	v_exp_f32_e32 v18, v18                                     // 000000125D04: 7E244B12
	.long 0xd71c0012                                           // 000000125D08: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000125D0C: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125D10: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000125D14: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000125D18: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 000000125D20: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125D2C: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 000000125D30: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000125D34: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000125D3C: BF870291
	v_rcp_f32_e32 v20, v19                                     // 000000125D40: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 000000125D44: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000125D4C: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 000000125D50: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 000000125D54: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 000000125D5C: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125D60: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 000000125D64: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 000000125D6C: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125D70: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 000000125D74: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 000000125D7C: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125D84: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000125D88: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 000000125D90: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 000000125D9C: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000125DA4: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000125DA8: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000125DB4: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000125DBC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000125DC0: BE882004
	s_cbranch_execz 58204                                      // 000000125DC4: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4138>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 000000125DC8: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000125DD4: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000125DDC: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000125DE0: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125DE4: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000125DE8: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000125DF0: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000125DFC: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000125E00: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000125E04: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000125E08: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000125E10: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125E18: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000125E1C: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000125E20: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000125E24: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125E28: BF870095
	.long 0xd71c0012                                           // 000000125E2C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000125E30: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000125E34: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000125E38: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125E40: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 000000125E44: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000125E50: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125E54: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000125E58: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000125E60: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125E64: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000125E68: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000125E70: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000125E74: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125E7C: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 000000125E80: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 000000125E84: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125E8C: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 000000125E90: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 000000125E94: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125E9C: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 000000125EA0: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000125EA8: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 000000125EB0: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125EBC: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000125EC0: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000125EC8: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000125ED4: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000125EDC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000125EE0: BE882005
	s_cbranch_execz 58135                                      // 000000125EE4: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4144>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 000000125EE8: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000125EF4: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000125EFC: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000125F00: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125F04: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000125F08: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000125F10: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000125F1C: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000125F20: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000125F24: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000125F28: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000125F30: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125F38: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000125F3C: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000125F40: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000125F44: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125F48: BF870095
	.long 0xd71c0012                                           // 000000125F4C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000125F50: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000125F54: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000125F58: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125F60: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 000000125F64: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 000000125F6C: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125F74: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000125F78: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000125F80: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125F84: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000125F88: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000125F90: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000125F94: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125F9C: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 000000125FA0: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 000000125FA4: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125FAC: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 000000125FB0: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 000000125FB4: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125FBC: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000125FC0: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000125FC8: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 000000125FD0: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125FDC: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000125FE0: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000125FE8: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000125FF4: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000125FFC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000126000: BE882006
	s_cbranch_execz 58066                                      // 000000126004: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4150>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 000000126008: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000126014: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000012601C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000126020: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126024: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000126028: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000126030: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000012603C: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000126040: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000126044: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000126048: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000126050: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126058: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000012605C: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000126060: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000126064: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126068: BF870095
	.long 0xd71c0012                                           // 00000012606C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000126070: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000126074: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000126078: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126080: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 000000126084: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000126090: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126094: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000126098: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000001260A0: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001260A4: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000001260A8: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000001260B0: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000001260B4: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001260BC: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000001260C0: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000001260C4: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001260CC: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000001260D0: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000001260D4: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001260DC: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000001260E0: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000001260E8: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 0000001260F0: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001260FC: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000126100: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000126108: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000126114: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012611C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000126120: BE882007
	s_cbranch_execz 57997                                      // 000000126124: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x415c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 000000126128: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000126134: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000012613C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000126140: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126144: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000126148: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000126150: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000012615C: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000126160: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000126164: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000126168: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000126170: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126178: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000012617C: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000126180: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000126184: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126188: BF870095
	.long 0xd71c0012                                           // 00000012618C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000126190: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000126194: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000126198: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001261A0: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 0000001261A4: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000001261B0: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001261B4: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000001261B8: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000001261C0: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001261C4: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000001261C8: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000001261D0: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000001261D4: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001261DC: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000001261E0: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000001261E4: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001261EC: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000001261F0: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000001261F4: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001261FC: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000126200: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000126208: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 000000126210: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012621C: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000126220: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000126228: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000126234: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012623C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000126240: BE882000
	s_cbranch_execz 57928                                      // 000000126244: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4168>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 000000126248: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 000000126254: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 000000126258: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000126260: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000126264: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126268: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000012626C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000126274: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000126280: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000126284: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000126288: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000012628C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000126294: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012629C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000001262A0: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000001262A4: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000001262A8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001262AC: BF870095
	.long 0xd71c0012                                           // 0000001262B0: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000001262B4: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001262B8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000001262BC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001262C4: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000001262C8: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000001262D0: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001262D4: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 0000001262D8: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 0000001262E0: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001262E4: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000001262E8: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 0000001262F0: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 0000001262F4: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001262FC: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 000000126300: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 000000126304: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012630C: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 000000126310: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 000000126314: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012631C: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 000000126320: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 000000126328: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 000000126330: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012633C: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 000000126340: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 000000126348: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 000000126354: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012635C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000126360: BE882001
	s_cbranch_execz 57859                                      // 000000126364: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4174>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 000000126368: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 000000126374: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 000000126378: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 000000126380: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000126384: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126388: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 00000012638C: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000126394: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 00000012639C: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 0000001263A8: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001263AC: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 0000001263B0: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 0000001263B8: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001263BC: BF870121
	v_add_f32_e32 v17, v17, v18                                // 0000001263C0: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 0000001263C4: 7E241113
	v_exp_f32_e32 v17, v17                                     // 0000001263C8: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001263CC: BF870095
	.long 0xd71c0011                                           // 0000001263D0: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000001263D4: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000001263D8: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000001263DC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001263E4: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 0000001263E8: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000001263F0: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001263F4: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 0000001263F8: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 000000126400: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126404: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 000000126408: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 000000126410: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 000000126414: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012641C: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 000000126420: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 000000126424: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012642C: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 000000126430: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 000000126434: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012643C: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 000000126440: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 000000126448: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 000000126450: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012645C: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 000000126460: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 000000126468: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 000000126474: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012647C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000126480: BE882002
	s_cbranch_execz 57790                                      // 000000126484: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4180>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 000000126488: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000126494: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000012649C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000001264A0: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001264A4: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000001264A8: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 0000001264B0: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 0000001264BC: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001264C0: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 0000001264C4: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000001264C8: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 0000001264D0: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001264D8: BF870121
	v_add_f32_e32 v10, v10, v17                                // 0000001264DC: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 0000001264E0: 7E221112
	v_exp_f32_e32 v10, v10                                     // 0000001264E4: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001264E8: BF870095
	.long 0xd71c000a                                           // 0000001264EC: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 0000001264F0: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000001264F4: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000001264F8: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126500: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 000000126504: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000126510: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126514: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000126518: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 000000126520: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126524: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 000000126528: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 000000126530: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 000000126534: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012653C: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 000000126540: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 000000126544: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012654C: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 000000126550: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 000000126554: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012655C: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 000000126560: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000126568: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 000000126570: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012657C: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 000000126580: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 000000126588: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000126594: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012659C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001265A0: BE882003
	s_cbranch_execz 57721                                      // 0000001265A4: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x418c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 0000001265A8: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000001265B4: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000001265BC: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000001265C0: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001265C4: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000001265C8: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000001265D0: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 0000001265DC: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001265E0: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 0000001265E4: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 0000001265F0: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 0000001265F4: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000001265F8: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000126600: BF870293
	v_exp_f32_e32 v10, v10                                     // 000000126604: 7E144B0A
	.long 0xd71c000a                                           // 000000126608: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000012660C: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126610: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000126614: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000126618: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 000000126620: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012662C: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 000000126630: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000126634: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012663C: BF870291
	v_rcp_f32_e32 v12, v11                                     // 000000126640: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 000000126644: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012664C: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 000000126650: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 000000126654: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 00000012665C: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126660: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 000000126664: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 00000012666C: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126670: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 000000126674: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 00000012667C: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126684: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000126688: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 000000126690: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000012669C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001266A4: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001266A8: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000001266B4: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001266BC: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001266C0: BE882004
	s_cbranch_execz 57652                                      // 0000001266C4: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4198>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 0000001266C8: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000001266D4: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000001266DC: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000001266E0: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001266E4: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000001266E8: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000001266F0: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000001266FC: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000126700: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000126704: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000126708: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000126710: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126718: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000012671C: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000126720: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000126724: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126728: BF870095
	.long 0xd71c000a                                           // 00000012672C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000126730: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000126734: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000126738: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126740: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 000000126744: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000126750: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126754: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000126758: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000126760: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126764: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000126768: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000126770: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000126774: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012677C: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 000000126780: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 000000126784: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012678C: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 000000126790: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 000000126794: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012679C: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 0000001267A0: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000001267A8: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 0000001267B0: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001267BC: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001267C0: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001267C8: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000001267D4: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001267DC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001267E0: BE882005
	s_cbranch_execz 57583                                      // 0000001267E4: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41a4>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 0000001267E8: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000001267F4: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000001267FC: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000126800: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126804: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000126808: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000126810: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000012681C: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000126820: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000126824: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000126828: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000126830: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126838: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000012683C: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000126840: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000126844: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126848: BF870095
	.long 0xd71c000a                                           // 00000012684C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000126850: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000126854: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000126858: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126860: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000126864: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 00000012686C: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126874: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000126878: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000126880: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126884: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000126888: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000126890: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000126894: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012689C: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000001268A0: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 0000001268A4: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001268AC: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 0000001268B0: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 0000001268B4: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001268BC: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000001268C0: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000001268C8: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 0000001268D0: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001268DC: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001268E0: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001268E8: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000001268F4: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001268FC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000126900: BE882006
	s_cbranch_execz 57514                                      // 000000126904: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41b0>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 000000126908: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000126914: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000012691C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000126920: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126924: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000126928: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000126930: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000012693C: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000126940: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000126944: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000126948: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000126950: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126958: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000012695C: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000126960: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000126964: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126968: BF870095
	.long 0xd71c000a                                           // 00000012696C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000126970: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000126974: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000126978: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126980: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 000000126984: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000126990: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126994: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000126998: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000001269A0: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001269A4: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000001269A8: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000001269B0: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000001269B4: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001269BC: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000001269C0: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000001269C4: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001269CC: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000001269D0: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000001269D4: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001269DC: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000001269E0: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000001269E8: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 0000001269F0: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001269FC: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000126A00: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000126A08: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000126A14: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000126A1C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000126A20: BE882007
	s_cbranch_execz 57445                                      // 000000126A24: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41bc>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 000000126A28: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000126A34: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000126A3C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000126A40: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126A44: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000126A48: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000126A50: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000126A5C: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000126A60: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000126A64: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000126A68: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000126A70: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126A78: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000126A7C: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000126A80: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000126A84: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126A88: BF870095
	.long 0xd71c000a                                           // 000000126A8C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000126A90: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000126A94: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000126A98: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126AA0: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 000000126AA4: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000126AB0: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126AB4: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000126AB8: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000126AC0: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126AC4: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000126AC8: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000126AD0: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000126AD4: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126ADC: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000126AE0: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000126AE4: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126AEC: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000126AF0: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000126AF4: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126AFC: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000126B00: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000126B08: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 000000126B10: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126B1C: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000126B20: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000126B28: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000126B34: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000126B3C: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000126B40: BE882000
	s_cbranch_execz 57376                                      // 000000126B44: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41c8>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 000000126B48: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 000000126B54: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 000000126B58: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000126B60: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000126B64: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126B68: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000126B6C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000126B74: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000126B80: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000126B84: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000126B88: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000126B8C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000126B94: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126B9C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000126BA0: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000126BA4: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000126BA8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126BAC: BF870095
	.long 0xd71c000a                                           // 000000126BB0: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000126BB4: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000126BB8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000126BBC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126BC4: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000126BC8: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000126BD0: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126BD4: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 000000126BD8: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 000000126BE0: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126BE4: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 000000126BE8: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 000000126BF0: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 000000126BF4: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126BFC: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 000000126C00: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 000000126C04: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126C0C: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 000000126C10: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 000000126C14: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126C1C: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 000000126C20: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 000000126C28: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 000000126C30: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126C3C: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 000000126C40: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 000000126C48: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 000000126C54: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 000000126C5C: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000126C60: BE802001
	s_cbranch_execz 57307                                      // 000000126C64: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41d4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 000000126C68: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000126C74: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000126C7C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000126C80: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126C84: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000126C88: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 000000126C90: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 000000126C9C: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000126CA0: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 000000126CA4: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 000000126CA8: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000126CB0: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126CB8: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 000000126CBC: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 000000126CC0: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 000000126CC4: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126CC8: BF870095
	.long 0xd71c0001                                           // 000000126CCC: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 000000126CD0: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000126CD4: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000126CD8: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126CE0: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 000000126CE4: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000126CF0: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126CF4: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000126CF8: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 000000126D00: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126D04: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 000000126D08: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 000000126D10: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 000000126D14: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126D1C: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 000000126D20: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 000000126D24: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126D2C: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 000000126D30: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 000000126D34: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126D3C: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 000000126D40: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000126D48: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 000000126D50: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126D5C: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 000000126D60: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 000000126D68: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000126D74: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000126D7C: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 000000126D80: BE802002
	s_cbranch_execz 57238                                      // 000000126D84: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41e0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 000000126D88: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000126D94: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000126D9C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000126DA0: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126DA4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000126DA8: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000126DB0: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 000000126DBC: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000126DC0: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 000000126DC4: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000126DC8: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000126DD0: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126DD8: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000126DDC: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 000000126DE0: 7E041109
	v_exp_f32_e32 v1, v1                                       // 000000126DE4: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126DE8: BF870095
	.long 0xd71c0001                                           // 000000126DEC: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000126DF0: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000126DF4: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000126DF8: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126E00: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 000000126E04: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000126E10: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126E14: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000126E18: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000126E20: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126E24: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 000000126E28: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 000000126E30: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 000000126E34: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126E3C: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 000000126E40: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 000000126E44: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126E4C: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 000000126E50: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 000000126E54: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126E5C: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 000000126E60: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000126E68: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 000000126E70: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126E7C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000126E80: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000126E88: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000126E94: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000126E9C: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 000000126EA0: BE802003
	s_cbranch_execz 57169                                      // 000000126EA4: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41ec>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 000000126EA8: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000126EB4: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000126EBC: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000126EC0: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126EC4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000126EC8: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000126ED0: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000126EDC: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000126EE0: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000126EE4: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000126EE8: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000126EF0: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126EF8: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000126EFC: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000126F00: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000126F04: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126F08: BF870095
	.long 0xd71c0001                                           // 000000126F0C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000126F10: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000126F14: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000126F18: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126F20: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 000000126F24: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000126F30: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126F34: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000126F38: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000126F40: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126F44: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000126F48: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000126F50: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000126F54: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126F5C: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 000000126F60: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 000000126F64: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126F6C: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 000000126F70: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 000000126F74: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126F7C: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 000000126F80: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000126F88: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 000000126F90: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126F9C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000126FA0: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000126FA8: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000126FB4: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000126FBC: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000126FC0: BE802004
	s_cbranch_execz 57100                                      // 000000126FC4: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41f8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 000000126FC8: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000126FD4: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000126FDC: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000126FE0: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126FE4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000126FE8: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000126FF0: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000126FFC: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000127000: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000127004: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000127008: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000127010: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000127018: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000012701C: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000127020: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000127024: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127028: BF870095
	.long 0xd71c0001                                           // 00000012702C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000127030: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000127034: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000127038: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127040: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 000000127044: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 00000012704C: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127054: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000127058: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000127060: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127064: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000127068: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000127070: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000127074: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012707C: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000127080: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 000000127084: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012708C: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 000000127090: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 000000127094: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012709C: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000001270A0: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000001270A8: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 0000001270B0: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001270BC: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000001270C0: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000001270C8: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001270D4: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001270DC: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000001270E0: BE802005
	s_cbranch_execz 57031                                      // 0000001270E4: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4204>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 0000001270E8: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000001270F4: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000001270FC: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000127100: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127104: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000127108: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000127110: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000012711C: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000127120: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000127124: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000127128: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000127130: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000127138: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000012713C: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000127140: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000127144: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127148: BF870095
	.long 0xd71c0001                                           // 00000012714C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000127150: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000127154: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000127158: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127160: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 000000127164: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000127170: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127174: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000127178: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000127180: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127184: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000127188: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000127190: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000127194: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012719C: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000001271A0: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000001271A4: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001271AC: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000001271B0: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000001271B4: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001271BC: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000001271C0: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000001271C8: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 0000001271D0: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001271DC: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000001271E0: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000001271E8: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001271F4: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001271FC: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000127200: BE802006
	s_cbranch_execz 56962                                      // 000000127204: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4210>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 000000127208: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000127214: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000012721C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000127220: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127224: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000127228: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000127230: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000012723C: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000127240: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000127244: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000127248: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000127250: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000127258: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000012725C: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000127260: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000127264: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127268: BF870095
	.long 0xd71c0001                                           // 00000012726C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000127270: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000127274: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000127278: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127280: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 000000127284: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000127290: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127294: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000127298: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000001272A0: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001272A4: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000001272A8: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000001272B0: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000001272B4: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001272BC: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000001272C0: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000001272C4: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001272CC: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000001272D0: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000001272D4: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001272DC: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000001272E0: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000001272E8: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 0000001272F0: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001272FC: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000127300: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000127308: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000127314: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000012731C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000127320: BE802007
	s_cbranch_execz 56893                                      // 000000127324: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x421c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 000000127328: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000127334: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000012733C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000127340: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127344: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000127348: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000127350: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000012735C: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000127360: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000127364: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000127368: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000127370: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000127378: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000012737C: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000127380: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000127384: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127388: BF870095
	.long 0xd71c0001                                           // 00000012738C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000127390: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000127394: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000127398: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001273A0: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 0000001273A4: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000001273B0: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001273B4: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000001273B8: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000001273C0: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001273C4: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000001273C8: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000001273D0: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000001273D4: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001273DC: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000001273E0: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000001273E4: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001273EC: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000001273F0: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000001273F4: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001273FC: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000127400: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000127408: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 000000127410: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012741C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000127420: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000127428: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000127434: DC9601E0 007C0200
	s_nop 0                                                    // 00000012743C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000127440: BFB60003
	s_endpgm                                                   // 000000127444: BFB00000
		...

