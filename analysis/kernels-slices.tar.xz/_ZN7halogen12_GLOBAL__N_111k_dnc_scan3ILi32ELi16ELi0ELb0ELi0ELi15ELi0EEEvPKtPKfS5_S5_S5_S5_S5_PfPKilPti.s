00000000000f1a00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000F1A00: BF850001
	s_load_b512 s[8:23], s[0:1], 0x8                           // 0000000F1A04: F4100200 F8000008
	s_load_b128 s[24:27], s[0:1], 0x48                         // 0000000F1A0C: F4080600 F8000048
	s_mov_b32 s4, s3                                           // 0000000F1A14: BE840003
	s_ashr_i32 s3, s2, 31                                      // 0000000F1A18: 86039F02
	s_lshl_b32 s6, s4, 2                                       // 0000000F1A1C: 84068204
	s_lshl_b64 s[28:29], s[2:3], 14                            // 0000000F1A20: 849C8E02
	v_cmp_gt_u32_e32 vcc_lo, 0x200, v0                         // 0000000F1A24: 7C9800FF 00000200
	v_and_b32_e32 v39, 3, v0                                   // 0000000F1A2C: 364E0083
	v_or_b32_e32 v37, 0xffffff80, v0                           // 0000000F1A30: 384A00FF FFFFFF80
	v_lshrrev_b32_e32 v38, 2, v0                               // 0000000F1A38: 324C0082
	s_waitcnt lgkmcnt(0)                                       // 0000000F1A3C: BF89FC07
	s_load_b32 s5, s[22:23], null                              // 0000000F1A40: F400014B F8000000
	s_add_u32 s4, s24, s28                                     // 0000000F1A48: 80041C18
	s_addc_u32 s23, s25, s29                                   // 0000000F1A4C: 82171D19
	s_waitcnt lgkmcnt(0)                                       // 0000000F1A50: BF89FC07
	s_mul_hi_i32 s7, s5, 0x2400000                             // 0000000F1A54: 9707FF05 02400000
	s_mul_i32 s5, s5, 0x2400000                                // 0000000F1A5C: 9605FF05 02400000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F1A64: BF870009
	s_add_u32 s22, s4, s5                                      // 0000000F1A68: 80160504
	s_addc_u32 s23, s23, s7                                    // 0000000F1A6C: 82170717
	s_and_saveexec_b32 s24, vcc_lo                             // 0000000F1A70: BE98206A
	s_cbranch_execz 55                                         // 0000000F1A74: BFA50037 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x154>
	s_ashr_i32 s7, s6, 31                                      // 0000000F1A78: 86079F06
	v_lshlrev_b32_e32 v1, 9, v38                               // 0000000F1A7C: 30024C89
	s_lshl_b64 s[4:5], s[22:23], 2                             // 0000000F1A80: 84848216
	s_lshl_b64 s[30:31], s[6:7], 2                             // 0000000F1A84: 849E8206
	v_lshlrev_b32_e32 v2, 2, v39                               // 0000000F1A88: 30044E82
	s_add_u32 s4, s30, s4                                      // 0000000F1A8C: 8004041E
	s_addc_u32 s5, s31, s5                                     // 0000000F1A90: 8205051F
	.long 0xd7000401                                           // 0000000F1A94: D7000401
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000000F1A98: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000F1A9C: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 0000000F1AA0: D5207C04 00110005
	v_or_b32_e32 v3, 0xffffff80, v0                            // 0000000F1AA8: 380600FF FFFFFF80
	.long 0xd7000401                                           // 0000000F1AB0: D7000401
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000F1AB4: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000F1AB8: BF8701A1
	v_add_co_ci_u32_e64 v5, null, 0, v4, s4                    // 0000000F1ABC: D5207C05 00120880
	v_mad_u32_u24 v4, v38, 20, v2                              // 0000000F1AC4: D60B0004 04092926
	.long 0xd7000401                                           // 0000000F1ACC: D7000401
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 0000000F1AD0: 02020214
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F1AD4: BF870001
	v_add_co_ci_u32_e64 v2, null, s21, v5, s4                  // 0000000F1AD8: D5207C02 00120A15
	s_mov_b32 s7, 0                                            // 0000000F1AE0: BE870080
	s_nop 0                                                    // 0000000F1AE4: BF800000
	s_nop 0                                                    // 0000000F1AE8: BF800000
	s_nop 0                                                    // 0000000F1AEC: BF800000
	s_nop 0                                                    // 0000000F1AF0: BF800000
	s_nop 0                                                    // 0000000F1AF4: BF800000
	s_nop 0                                                    // 0000000F1AF8: BF800000
	s_nop 0                                                    // 0000000F1AFC: BF800000
	global_load_b32 v5, v[1:2], off                            // 0000000F1B00: DC520000 057C0001
	v_add_nc_u32_e32 v3, 0x80, v3                              // 0000000F1B08: 4A0606FF 00000080
	.long 0xd7000401                                           // 0000000F1B10: D7000401
	v_cndmask_b32_e32 v1, 0x4000, v1, vcc_lo                   // 0000000F1B14: 020202FF 00004000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F1B1C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, s4                    // 0000000F1B20: D5207C02 00120480
	.long 0xd4490005                                           // 0000000F1B28: D4490005
	v_cndmask_b32_e32 v1, 0x17f, v3, vcc_lo                    // 0000000F1B2C: 020206FF 0000017F
	s_or_b32 s7, s5, s7                                        // 0000000F1B34: 8C070705
	s_waitcnt vmcnt(0)                                         // 0000000F1B38: BF8903F7
	ds_store_b32 v4, v5 offset:8256                            // 0000000F1B3C: D8342040 00000504
	v_add_nc_u32_e32 v4, 0x280, v4                             // 0000000F1B44: 4A0808FF 00000280
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000000F1B4C: 917E077E
	s_cbranch_execnz 65515                                     // 0000000F1B50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x100>
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000F1B54: 8C7E187E
	s_load_b32 s5, s[0:1], 0x58                                // 0000000F1B58: F4000140 F8000058
	s_waitcnt lgkmcnt(0)                                       // 0000000F1B60: BF89FC07
	s_barrier                                                  // 0000000F1B64: BFBD0000
	buffer_gl0_inv                                             // 0000000F1B68: E0AC0000 00000000
	s_cmp_lt_i32 s5, 1                                         // 0000000F1B70: BF048105
	s_cbranch_scc1 2356                                        // 0000000F1B74: BFA20934 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2648>
	s_add_i32 s0, s5, 63                                       // 0000000F1B78: 8100BF05
	s_ashr_i32 s7, s6, 31                                      // 0000000F1B7C: 86079F06
	s_lshr_b32 s24, s0, 6                                      // 0000000F1B80: 85188600
	s_lshl_b64 s[0:1], s[6:7], 2                               // 0000000F1B84: 84808206
	s_add_i32 s25, s2, 0xbd0                                   // 0000000F1B88: 8119FF02 00000BD0
	s_add_u32 s4, s14, s0                                      // 0000000F1B90: 8004000E
	s_addc_u32 s1, s15, s1                                     // 0000000F1B94: 8201010F
	s_lshl_b32 s14, s2, 7                                      // 0000000F1B98: 840E8702
	v_lshlrev_b32_e32 v42, 2, v39                              // 0000000F1B9C: 30544E82
	s_ashr_i32 s15, s14, 31                                    // 0000000F1BA0: 860F9F0E
	v_and_b32_e32 v3, 0x7c, v0                                 // 0000000F1BA4: 360600FF 0000007C
	s_lshl_b64 s[14:15], s[14:15], 1                           // 0000000F1BAC: 848E810E
	v_lshlrev_b32_e32 v4, 1, v39                               // 0000000F1BB0: 30084E81
	s_add_u32 s26, s26, s14                                    // 0000000F1BB4: 801A0E1A
	s_addc_u32 s27, s27, s15                                   // 0000000F1BB8: 821B0F1B
	s_lshl_b64 s[14:15], s[6:7], 1                             // 0000000F1BBC: 848E8106
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000000F1BC0: 30020082
	s_add_u32 s7, s26, s14                                     // 0000000F1BC4: 80070E1A
	.long 0xd700042d                                           // 0000000F1BC8: D700042D
	v_cndmask_b32_e32 v1, s4, v42, vcc_lo                      // 0000000F1BCC: 02025404
	v_lshlrev_b32_e32 v5, 6, v0                                // 0000000F1BD0: 300A0086
	s_addc_u32 s14, s27, s15                                   // 0000000F1BD4: 820E0F1B
	v_add_co_ci_u32_e64 v46, null, s1, 0, s4                   // 0000000F1BD8: D5207C2E 00110001
	v_add_nc_u32_e32 v50, 0x3040, v3                           // 0000000F1BE0: 4A6406FF 00003040
	.long 0xd7000103                                           // 0000000F1BE8: D7000103
	v_cndmask_b32_e32 v1, s7, v4, vcc_lo                       // 0000000F1BEC: 02020807
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F1BF0: BF8700D1
	v_add_co_ci_u32_e64 v4, null, s14, 0, s1                   // 0000000F1BF4: D5207C04 0005000E
	.long 0xd7000136                                           // 0000000F1BFC: D7000136
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000000F1C00: 02020208
	v_and_b32_e32 v5, 0x1f00, v5                               // 0000000F1C04: 360A0AFF 00001F00
	v_add_co_ci_u32_e64 v55, null, s9, 0, s1                   // 0000000F1C0C: D5207C37 00050009
	.long 0xd7000138                                           // 0000000F1C14: D7000138
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000000F1C18: 0202020A
	v_add_co_ci_u32_e64 v57, null, s11, 0, s1                  // 0000000F1C1C: D5207C39 0005000B
	s_add_u32 s1, s18, s28                                     // 0000000F1C24: 80011C12
	s_addc_u32 s4, s19, s29                                    // 0000000F1C28: 82041D13
	.long 0xd7000105                                           // 0000000F1C2C: D7000105
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 0000000F1C30: 02020A01
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F1C34: BF870001
	v_add_co_ci_u32_e64 v6, null, s4, 0, s1                    // 0000000F1C38: D5207C06 00050004
	s_lshl_b64 s[8:9], s[2:3], 9                               // 0000000F1C40: 84888902
	.long 0xd7000107                                           // 0000000F1C44: D7000107
	v_cndmask_b32_e32 v1, 0x1000, v5, vcc_lo                   // 0000000F1C48: 02020AFF 00001000
	v_mov_b32_e32 v14, s9                                      // 0000000F1C50: 7E1C0209
	v_or_b32_e32 v13, s8, v1                                   // 0000000F1C54: 381A0208
	v_add_co_ci_u32_e64 v8, null, 0, v6, s1                    // 0000000F1C58: D5207C08 00060C80
	.long 0xd7000109                                           // 0000000F1C60: D7000109
	v_cndmask_b32_e32 v1, 0x2000, v5, vcc_lo                   // 0000000F1C64: 02020AFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F1C6C: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v6, s1                   // 0000000F1C70: D5207C0A 00060C80
	.long 0xd700010b                                           // 0000000F1C78: D700010B
	v_cndmask_b32_e32 v1, 0x3000, v5, vcc_lo                   // 0000000F1C7C: 02020AFF 00003000
	v_add_co_ci_u32_e64 v12, null, 0, v6, s1                   // 0000000F1C84: D5207C0C 00060C80
	.long 0xd700010d                                           // 0000000F1C8C: D700010D
	v_cndmask_b32_e32 v1, s10, v13, vcc_lo                     // 0000000F1C90: 02021A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000F1C94: BF8701A1
	v_add_co_ci_u32_e64 v14, null, s11, v14, s1                // 0000000F1C98: D5207C0E 00061C0B
	v_or_b32_e32 v47, 0x2a40, v42                              // 0000000F1CA0: 385E54FF 00002A40
	.long 0xd700010f                                           // 0000000F1CA8: D700010F
	v_cndmask_b32_e32 v1, 0x60000, v13, vcc_lo                 // 0000000F1CAC: 02021AFF 00060000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F1CB4: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v14, s1                  // 0000000F1CB8: D5207C10 00061C80
	.long 0xd7000111                                           // 0000000F1CC0: D7000111
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000F1CC4: 02021AFF 000C0000
	.long 0xd7000f2b                                           // 0000000F1CCC: D7000F2B
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 0000000F1CD0: 02020210
	v_add_co_ci_u32_e64 v18, null, 0, v14, s1                  // 0000000F1CD4: D5207C12 00061C80
	.long 0xd7000113                                           // 0000000F1CDC: D7000113
	v_cndmask_b32_e32 v1, 0x120000, v13, vcc_lo                // 0000000F1CE0: 02021AFF 00120000
	.long 0xd44c0000                                           // 0000000F1CE8: D44C0000
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 0000000F1CEC: 020200C0
	v_add_nc_u32_e32 v40, 0x2f40, v1                           // 0000000F1CF0: 4A5002FF 00002F40
	v_add_nc_u32_e32 v41, 0x3040, v1                           // 0000000F1CF8: 4A5202FF 00003040
	v_add_co_ci_u32_e64 v44, null, s17, 0, s15                 // 0000000F1D00: D5207C2C 003D0011
	v_mul_u32_u24_e32 v48, 0x204, v38                          // 0000000F1D08: 16604CFF 00000204
	v_or_b32_e32 v2, 0x2040, v42                               // 0000000F1D10: 380454FF 00002040
	v_mad_u32_u24 v49, v38, 20, v47                            // 0000000F1D18: D60B0031 04BD2926
	v_or_b32_e32 v51, 16, v38                                  // 0000000F1D20: 38664C90
	v_or_b32_e32 v52, 32, v38                                  // 0000000F1D24: 38684CA0
	v_or_b32_e32 v53, 48, v38                                  // 0000000F1D28: 386A4CB0
	v_add_nc_u32_e32 v58, 1, v38                               // 0000000F1D2C: 4A744C81
	v_add_nc_u32_e32 v59, 17, v38                              // 0000000F1D30: 4A764C91
	v_add_nc_u32_e32 v60, 33, v38                              // 0000000F1D34: 4A784CA1
	v_add_nc_u32_e32 v61, 49, v38                              // 0000000F1D38: 4A7A4CB1
	v_or_b32_e32 v62, 0xffffff80, v0                           // 0000000F1D3C: 387C00FF FFFFFF80
	v_add_co_ci_u32_e64 v20, null, 0, v14, s1                  // 0000000F1D44: D5207C14 00061C80
	s_mov_b32 s7, 0                                            // 0000000F1D4C: BE870080
	s_mov_b32 s8, 0                                            // 0000000F1D50: BE880080
	s_branch 52                                                // 0000000F1D54: BFA00034 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x428>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F1D58: 8C7E047E
	.long 0xd7000105                                           // 0000000F1D5C: D7000105
	v_cndmask_b32_e32 v1, 0xc0000, v5, vcc_lo                  // 0000000F1D60: 02020AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F1D68: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s1                    // 0000000F1D6C: D5207C06 00060C80
	.long 0xd7000107                                           // 0000000F1D74: D7000107
	v_cndmask_b32_e32 v1, 0xc0000, v7, vcc_lo                  // 0000000F1D78: 02020EFF 000C0000
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000F1D80: D5207C08 00061080
	.long 0xd7000109                                           // 0000000F1D88: D7000109
	v_cndmask_b32_e32 v1, 0xc0000, v9, vcc_lo                  // 0000000F1D8C: 020212FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F1D94: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000F1D98: D5207C0A 00061480
	.long 0xd700010b                                           // 0000000F1DA0: D700010B
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000F1DA4: 020216FF 000C0000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000F1DAC: D5207C0C 00061880
	.long 0xd700010d                                           // 0000000F1DB4: D700010D
	v_cndmask_b32_e32 v1, 0x180000, v13, vcc_lo                // 0000000F1DB8: 02021AFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F1DC0: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000F1DC4: D5207C0E 00061C80
	.long 0xd700010f                                           // 0000000F1DCC: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000F1DD0: 02021EFF 00180000
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000F1DD8: D5207C10 00062080
	.long 0xd7000111                                           // 0000000F1DE0: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000F1DE4: 020222FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F1DEC: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000F1DF0: D5207C12 00062480
	.long 0xd7000113                                           // 0000000F1DF8: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000F1DFC: 020226FF 00180000
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000F1E04: D5207C14 00062880
	s_add_i32 s8, s8, 1                                        // 0000000F1E0C: 81088108
	s_waitcnt lgkmcnt(0)                                       // 0000000F1E10: BF89FC07
	s_cmp_eq_u32 s8, s24                                       // 0000000F1E14: BF061808
	s_barrier                                                  // 0000000F1E18: BFBD0000
	buffer_gl0_inv                                             // 0000000F1E1C: E0AC0000 00000000
	s_cbranch_scc1 2184                                        // 0000000F1E24: BFA20888 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2648>
	s_mul_i32 s1, s8, 0xc00                                    // 0000000F1E28: 9601FF08 00000C00
	s_lshl_b32 s9, s8, 6                                       // 0000000F1E30: 84098608
	s_add_i32 s10, s25, s1                                     // 0000000F1E34: 810A0119
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000F1E38: BF870499
	s_ashr_i32 s11, s10, 31                                    // 0000000F1E3C: 860B9F0A
	s_lshl_b64 s[10:11], s[10:11], 2                           // 0000000F1E40: 848A820A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F1E44: BF870009
	s_add_u32 s10, s12, s10                                    // 0000000F1E48: 800A0A0C
	s_addc_u32 s11, s13, s11                                   // 0000000F1E4C: 820B0B0D
	s_load_b32 s10, s[10:11], null                             // 0000000F1E50: F4000285 F8000000
	s_and_saveexec_b32 s4, s0                                  // 0000000F1E58: BE842000
	s_cbranch_execz 77                                         // 0000000F1E5C: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x594>
	v_or_b32_e32 v21, s9, v0                                   // 0000000F1E60: 382A0009
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1E64: BF870091
	v_mad_u64_u32 v[21:22], null, v21, 48, s[2:3]              // 0000000F1E68: D6FE7C15 00096115
	v_ashrrev_i32_e32 v22, 31, v21                             // 0000000F1E70: 342C2A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1E74: BF870091
	.long 0xd73c0015                                           // 0000000F1E78: D73C0015
	v_cndmask_b32_e32 v1, 2, v21, vcc_lo                       // 0000000F1E7C: 02022A82
	.long 0xd7000115                                           // 0000000F1E80: D7000115
	v_cndmask_b32_e32 v1, s12, v21, vcc_lo                     // 0000000F1E84: 02022A0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F1E88: BF8700C1
	v_add_co_ci_u32_e64 v22, null, s13, v22, s1                // 0000000F1E8C: D5207C16 00062C0D
	global_load_b32 v21, v[21:22], off                         // 0000000F1E94: DC520000 157C0015
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F1E9C: BF890007
	v_sub_f32_e32 v22, s10, v21                                // 0000000F1EA0: 082C2A0A
	v_dual_mul_f32 v24, 0x3fb8aa3b, v21 :: v_dual_mul_f32 v23, 0x3fb8aa3b, v22// 0000000F1EA4: C8C62AFF 18162CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000F1EB0: BF8701A1
	v_fma_f32 v27, 0x3fb8aa3b, v21, -v24                       // 0000000F1EB4: D613001B 84622AFF 3FB8AA3B
	v_rndne_f32_e32 v28, v24                                   // 0000000F1EC0: 7E384718
	v_fma_f32 v25, 0x3fb8aa3b, v22, -v23                       // 0000000F1EC4: D6130019 845E2CFF 3FB8AA3B
	v_rndne_f32_e32 v26, v23                                   // 0000000F1ED0: 7E344717
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F1ED4: BF870113
	v_dual_fmac_f32 v27, 0x32a5705f, v21 :: v_dual_sub_f32 v24, v24, v28// 0000000F1ED8: C80A2AFF 1B183918 32A5705F
	v_sub_f32_e32 v23, v23, v26                                // 0000000F1EE4: 082E3517
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F1EE8: BF870124
	v_fmac_f32_e32 v25, 0x32a5705f, v22                        // 0000000F1EEC: 56322CFF 32A5705F
	.long 0xd41b0001                                           // 0000000F1EF4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v22, vcc_lo              // 0000000F1EF8: 02022CFF C2CE8ED0
	v_dual_add_f32 v24, v24, v27 :: v_dual_add_f32 v23, v23, v25// 0000000F1F00: C9083718 18163317
	v_cvt_i32_f32_e32 v25, v26                                 // 0000000F1F08: 7E32111A
	v_cvt_i32_f32_e32 v26, v28                                 // 0000000F1F0C: 7E34111C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F1F10: BF870193
	v_exp_f32_e32 v24, v24                                     // 0000000F1F14: 7E304B18
	v_exp_f32_e32 v23, v23                                     // 0000000F1F18: 7E2E4B17
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F1F1C: BF870296
	.long 0xd71c0018                                           // 0000000F1F20: D71C0018
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 0000000F1F24: 02023518
	.long 0xd71c0017                                           // 0000000F1F28: D71C0017
	v_cndmask_b32_e32 v1, v23, v25, vcc_lo                     // 0000000F1F2C: 02023317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F1F30: BF8700A1
	v_cndmask_b32_e64 v23, 0, v23, s1                          // 0000000F1F34: D5010017 00062E80
	.long 0xd41b0001                                           // 0000000F1F3C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v21, vcc_lo              // 0000000F1F40: 02022AFF C2CE8ED0
	v_cndmask_b32_e64 v24, 0, v24, s1                          // 0000000F1F48: D5010018 00063080
	.long 0xd41e0001                                           // 0000000F1F50: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v22, vcc_lo              // 0000000F1F54: 02022CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F1F5C: BF8700A1
	v_cndmask_b32_e64 v22, 0x7f800000, v23, s1                 // 0000000F1F60: D5010016 00062EFF 7F800000
	.long 0xd41e0001                                           // 0000000F1F6C: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v21, vcc_lo              // 0000000F1F70: 02022AFF 42B17218
	v_cndmask_b32_e64 v21, 0x7f800000, v24, s1                 // 0000000F1F78: D5010015 000630FF 7F800000
	ds_store_b32 v40, v22                                      // 0000000F1F84: D8340000 00001628
	ds_store_b32 v41, v21                                      // 0000000F1F8C: D8340000 00001529
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F1F94: 8C7E047E
	v_mov_b32_e32 v21, v0                                      // 0000000F1F98: 7E2A0300
	s_mov_b32 s4, 0                                            // 0000000F1F9C: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000F1FA0: BF89FC07
	s_barrier                                                  // 0000000F1FA4: BFBD0000
	buffer_gl0_inv                                             // 0000000F1FA8: E0AC0000 00000000
	s_nop 0                                                    // 0000000F1FB0: BF800000
	s_nop 0                                                    // 0000000F1FB4: BF800000
	s_nop 0                                                    // 0000000F1FB8: BF800000
	s_nop 0                                                    // 0000000F1FBC: BF800000
	v_lshrrev_b32_e32 v24, 7, v21                              // 0000000F1FC0: 32302A87
	v_add_nc_u32_e32 v26, 0x80, v21                            // 0000000F1FC4: 4A342AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1FCC: BF870092
	v_or_b32_e32 v22, s9, v24                                  // 0000000F1FD0: 382C3009
	v_mad_u64_u32 v[22:23], null, v22, 48, s[2:3]              // 0000000F1FD4: D6FE7C16 00096116
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F1FDC: BF870091
	.long 0xd73c0016                                           // 0000000F1FE0: D73C0016
	v_cndmask_b32_e32 v1, 9, v22, vcc_lo                       // 0000000F1FE4: 02022C89
	.long 0xd7000116                                           // 0000000F1FE8: D7000116
	v_cndmask_b32_e32 v1, v43, v22, vcc_lo                     // 0000000F1FEC: 02022D2B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F1FF0: BF870001
	v_add_co_ci_u32_e64 v23, null, v44, v23, s1                // 0000000F1FF4: D5207C17 00062F2C
	.long 0xd4490001                                           // 0000000F1FFC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v21, vcc_lo                   // 0000000F2000: 02022AFF 0000077F
	v_mov_b32_e32 v21, v26                                     // 0000000F2008: 7E2A031A
	global_load_b32 v25, v[22:23], off                         // 0000000F200C: DC520000 197C0016
	v_mad_u64_u32 v[22:23], null, 0x204, v24, v[1:2]           // 0000000F2014: D6FE7C16 040630FF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000F2020: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000F2024: BF8903F7
	ds_store_b32 v22, v25                                      // 0000000F2028: D8340000 00001916
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000F2030: 917E047E
	s_cbranch_execnz 65506                                     // 0000000F2034: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F2038: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000F203C: BF89FC07
	s_barrier                                                  // 0000000F2040: BFBD0000
	buffer_gl0_inv                                             // 0000000F2044: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000F204C: BE842000
	s_cbranch_execz 102                                        // 0000000F2050: BFA50066 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x7ec>
	v_or_b32_e32 v21, s9, v38                                  // 0000000F2054: 382A4C09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2058: BF870091
	v_mad_u64_u32 v[21:22], null, v21, 48, s[2:3]              // 0000000F205C: D6FE7C15 00096115
	.long 0xd73c0015                                           // 0000000F2064: D73C0015
	v_cndmask_b32_e32 v1, 9, v21, vcc_lo                       // 0000000F2068: 02022A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F206C: BF870091
	.long 0xd7000115                                           // 0000000F2070: D7000115
	v_cndmask_b32_e32 v1, v45, v21, vcc_lo                     // 0000000F2074: 02022B2D
	v_add_co_ci_u32_e64 v22, null, v46, v22, s1                // 0000000F2078: D5207C16 00062D2E
	s_movk_i32 s1, 0xf600                                      // 0000000F2080: B001F600
	global_load_b32 v22, v[21:22], off                         // 0000000F2084: DC520000 167C0015
	v_mov_b32_e32 v21, v48                                     // 0000000F208C: 7E2A0330
	v_add_nc_u32_e32 v23, s1, v42                              // 0000000F2090: 4A2E5401
	s_addk_i32 s1, 0x140                                       // 0000000F2094: B7810140
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2098: BF870099
	s_cmp_eq_u32 s1, 0                                         // 0000000F209C: BF068001
	v_add_nc_u32_e32 v63, 0x2800, v23                          // 0000000F20A0: 4A7E2EFF 00002800
	ds_load_2addr_b32 v[23:24], v21 offset1:1                  // 0000000F20A8: D8DC0100 17000015
	ds_load_2addr_b32 v[25:26], v63 offset0:144 offset1:149    // 0000000F20B0: D8DC9590 1900003F
	ds_load_2addr_b32 v[27:28], v21 offset0:2 offset1:3        // 0000000F20B8: D8DC0302 1B000015
	ds_load_2addr_b32 v[29:30], v63 offset0:154 offset1:159    // 0000000F20C0: D8DC9F9A 1D00003F
	ds_load_2addr_b32 v[31:32], v21 offset0:4 offset1:5        // 0000000F20C8: D8DC0504 1F000015
	ds_load_2addr_b32 v[33:34], v21 offset0:6 offset1:7        // 0000000F20D0: D8DC0706 21000015
	ds_load_2addr_b32 v[35:36], v63 offset0:164 offset1:169    // 0000000F20D8: D8DCA9A4 2300003F
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000F20E0: BF890057
	v_fma_f32 v22, -v23, v25, v22                              // 0000000F20E4: D6130016 245A3317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F20EC: BF8700C1
	v_fma_f32 v24, -v24, v26, v22                              // 0000000F20F0: D6130018 245A3518
	ds_load_2addr_b32 v[22:23], v63 offset0:174 offset1:179    // 0000000F20F8: D8DCB3AE 1600003F
	s_waitcnt lgkmcnt(4)                                       // 0000000F2100: BF89FC47
	v_fma_f32 v24, -v27, v29, v24                              // 0000000F2104: D6130018 24623B1B
	v_fma_f32 v28, -v28, v30, v24                              // 0000000F210C: D613001C 24623D1C
	ds_load_2addr_b32 v[24:25], v21 offset0:8 offset1:9        // 0000000F2114: D8DC0908 18000015
	ds_load_2addr_b32 v[26:27], v63 offset0:184 offset1:189    // 0000000F211C: D8DCBDB8 1A00003F
	s_waitcnt lgkmcnt(3)                                       // 0000000F2124: BF89FC37
	v_fma_f32 v28, -v31, v35, v28                              // 0000000F2128: D613001C 2472471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F2130: BF8700D1
	v_fma_f32 v32, -v32, v36, v28                              // 0000000F2134: D6130020 24724920
	ds_load_2addr_b32 v[28:29], v21 offset0:10 offset1:11      // 0000000F213C: D8DC0B0A 1C000015
	ds_load_2addr_b32 v[30:31], v63 offset0:194 offset1:199    // 0000000F2144: D8DCC7C2 1E00003F
	s_waitcnt lgkmcnt(4)                                       // 0000000F214C: BF89FC47
	v_fma_f32 v22, -v33, v22, v32                              // 0000000F2150: D6130016 24822D21
	v_fma_f32 v36, -v34, v23, v22                              // 0000000F2158: D6130024 245A2F22
	ds_load_2addr_b32 v[22:23], v21 offset0:12 offset1:13      // 0000000F2160: D8DC0D0C 16000015
	ds_load_2addr_b32 v[32:33], v21 offset0:14 offset1:15      // 0000000F2168: D8DC0F0E 20000015
	ds_load_2addr_b32 v[34:35], v63 offset0:204 offset1:209    // 0000000F2170: D8DCD1CC 2200003F
	v_add_nc_u32_e32 v21, 64, v21                              // 0000000F2178: 4A2A2AC0
	s_waitcnt lgkmcnt(5)                                       // 0000000F217C: BF89FC57
	v_fma_f32 v24, -v24, v26, v36                              // 0000000F2180: D6130018 24923518
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F2188: BF8700C1
	v_fma_f32 v26, -v25, v27, v24                              // 0000000F218C: D613001A 24623719
	ds_load_2addr_b32 v[24:25], v63 offset0:214 offset1:219    // 0000000F2194: D8DCDBD6 1800003F
	s_waitcnt lgkmcnt(4)                                       // 0000000F219C: BF89FC47
	v_fma_f32 v26, -v28, v30, v26                              // 0000000F21A0: D613001A 246A3D1C
	v_fma_f32 v26, -v29, v31, v26                              // 0000000F21A8: D613001A 246A3F1D
	s_waitcnt lgkmcnt(1)                                       // 0000000F21B0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F21B4: BF870091
	v_fma_f32 v22, -v22, v34, v26                              // 0000000F21B8: D6130016 246A4516
	v_fma_f32 v22, -v23, v35, v22                              // 0000000F21C0: D6130016 245A4717
	s_waitcnt lgkmcnt(0)                                       // 0000000F21C8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F21CC: BF870091
	v_fma_f32 v22, -v32, v24, v22                              // 0000000F21D0: D6130016 245A3120
	v_fma_f32 v22, -v33, v25, v22                              // 0000000F21D8: D6130016 245A3321
	s_cbranch_scc0 65451                                       // 0000000F21E0: BFA1FFAB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x690>
	ds_store_b32 v49, v22                                      // 0000000F21E4: D8340000 00001631
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F21EC: 8C7E047E
	v_mov_b32_e32 v21, v0                                      // 0000000F21F0: 7E2A0300
	s_or_b32 s15, s9, 16                                       // 0000000F21F4: 8C0F9009
	s_mov_b32 s4, 0                                            // 0000000F21F8: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000F21FC: BF89FC07
	s_barrier                                                  // 0000000F2200: BFBD0000
	buffer_gl0_inv                                             // 0000000F2204: E0AC0000 00000000
	s_nop 0                                                    // 0000000F220C: BF800000
	s_nop 0                                                    // 0000000F2210: BF800000
	s_nop 0                                                    // 0000000F2214: BF800000
	s_nop 0                                                    // 0000000F2218: BF800000
	s_nop 0                                                    // 0000000F221C: BF800000
	s_nop 0                                                    // 0000000F2220: BF800000
	s_nop 0                                                    // 0000000F2224: BF800000
	s_nop 0                                                    // 0000000F2228: BF800000
	s_nop 0                                                    // 0000000F222C: BF800000
	s_nop 0                                                    // 0000000F2230: BF800000
	s_nop 0                                                    // 0000000F2234: BF800000
	s_nop 0                                                    // 0000000F2238: BF800000
	s_nop 0                                                    // 0000000F223C: BF800000
	v_lshrrev_b32_e32 v24, 7, v21                              // 0000000F2240: 32302A87
	v_add_nc_u32_e32 v26, 0x80, v21                            // 0000000F2244: 4A342AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F224C: BF870092
	v_or_b32_e32 v22, s15, v24                                 // 0000000F2250: 382C300F
	v_mad_u64_u32 v[22:23], null, v22, 48, s[2:3]              // 0000000F2254: D6FE7C16 00096116
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F225C: BF870091
	.long 0xd73c0016                                           // 0000000F2260: D73C0016
	v_cndmask_b32_e32 v1, 9, v22, vcc_lo                       // 0000000F2264: 02022C89
	.long 0xd7000116                                           // 0000000F2268: D7000116
	v_cndmask_b32_e32 v1, v43, v22, vcc_lo                     // 0000000F226C: 02022D2B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F2270: BF870001
	v_add_co_ci_u32_e64 v23, null, v44, v23, s1                // 0000000F2274: D5207C17 00062F2C
	.long 0xd4490001                                           // 0000000F227C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v21, vcc_lo                   // 0000000F2280: 02022AFF 0000077F
	v_mov_b32_e32 v21, v26                                     // 0000000F2288: 7E2A031A
	global_load_b32 v25, v[22:23], off                         // 0000000F228C: DC520000 197C0016
	v_mad_u64_u32 v[22:23], null, 0x204, v24, v[1:2]           // 0000000F2294: D6FE7C16 040630FF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000F22A0: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000F22A4: BF8903F7
	ds_store_b32 v22, v25                                      // 0000000F22A8: D8340000 00001916
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000F22B0: 917E047E
	s_cbranch_execnz 65506                                     // 0000000F22B4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x840>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F22B8: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000F22BC: BF89FC07
	s_barrier                                                  // 0000000F22C0: BFBD0000
	buffer_gl0_inv                                             // 0000000F22C4: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000F22CC: BE842000
	s_cbranch_execz 102                                        // 0000000F22D0: BFA50066 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa6c>
	v_or_b32_e32 v21, s15, v38                                 // 0000000F22D4: 382A4C0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F22D8: BF870091
	v_mad_u64_u32 v[21:22], null, v21, 48, s[2:3]              // 0000000F22DC: D6FE7C15 00096115
	.long 0xd73c0015                                           // 0000000F22E4: D73C0015
	v_cndmask_b32_e32 v1, 9, v21, vcc_lo                       // 0000000F22E8: 02022A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F22EC: BF870091
	.long 0xd7000115                                           // 0000000F22F0: D7000115
	v_cndmask_b32_e32 v1, v45, v21, vcc_lo                     // 0000000F22F4: 02022B2D
	v_add_co_ci_u32_e64 v22, null, v46, v22, s1                // 0000000F22F8: D5207C16 00062D2E
	s_movk_i32 s1, 0xf600                                      // 0000000F2300: B001F600
	global_load_b32 v22, v[21:22], off                         // 0000000F2304: DC520000 167C0015
	v_mov_b32_e32 v21, v48                                     // 0000000F230C: 7E2A0330
	v_add_nc_u32_e32 v23, s1, v42                              // 0000000F2310: 4A2E5401
	s_addk_i32 s1, 0x140                                       // 0000000F2314: B7810140
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2318: BF870099
	s_cmp_lg_u32 s1, 0                                         // 0000000F231C: BF078001
	v_add_nc_u32_e32 v63, 0x2800, v23                          // 0000000F2320: 4A7E2EFF 00002800
	ds_load_2addr_b32 v[23:24], v21 offset1:1                  // 0000000F2328: D8DC0100 17000015
	ds_load_2addr_b32 v[25:26], v63 offset0:144 offset1:149    // 0000000F2330: D8DC9590 1900003F
	ds_load_2addr_b32 v[27:28], v21 offset0:2 offset1:3        // 0000000F2338: D8DC0302 1B000015
	ds_load_2addr_b32 v[29:30], v63 offset0:154 offset1:159    // 0000000F2340: D8DC9F9A 1D00003F
	ds_load_2addr_b32 v[31:32], v21 offset0:4 offset1:5        // 0000000F2348: D8DC0504 1F000015
	ds_load_2addr_b32 v[33:34], v21 offset0:6 offset1:7        // 0000000F2350: D8DC0706 21000015
	ds_load_2addr_b32 v[35:36], v63 offset0:164 offset1:169    // 0000000F2358: D8DCA9A4 2300003F
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000F2360: BF890057
	v_fma_f32 v22, -v23, v25, v22                              // 0000000F2364: D6130016 245A3317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F236C: BF8700C1
	v_fma_f32 v24, -v24, v26, v22                              // 0000000F2370: D6130018 245A3518
	ds_load_2addr_b32 v[22:23], v63 offset0:174 offset1:179    // 0000000F2378: D8DCB3AE 1600003F
	s_waitcnt lgkmcnt(4)                                       // 0000000F2380: BF89FC47
	v_fma_f32 v24, -v27, v29, v24                              // 0000000F2384: D6130018 24623B1B
	v_fma_f32 v28, -v28, v30, v24                              // 0000000F238C: D613001C 24623D1C
	ds_load_2addr_b32 v[24:25], v21 offset0:8 offset1:9        // 0000000F2394: D8DC0908 18000015
	ds_load_2addr_b32 v[26:27], v63 offset0:184 offset1:189    // 0000000F239C: D8DCBDB8 1A00003F
	s_waitcnt lgkmcnt(3)                                       // 0000000F23A4: BF89FC37
	v_fma_f32 v28, -v31, v35, v28                              // 0000000F23A8: D613001C 2472471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F23B0: BF8700D1
	v_fma_f32 v32, -v32, v36, v28                              // 0000000F23B4: D6130020 24724920
	ds_load_2addr_b32 v[28:29], v21 offset0:10 offset1:11      // 0000000F23BC: D8DC0B0A 1C000015
	ds_load_2addr_b32 v[30:31], v63 offset0:194 offset1:199    // 0000000F23C4: D8DCC7C2 1E00003F
	s_waitcnt lgkmcnt(4)                                       // 0000000F23CC: BF89FC47
	v_fma_f32 v22, -v33, v22, v32                              // 0000000F23D0: D6130016 24822D21
	v_fma_f32 v36, -v34, v23, v22                              // 0000000F23D8: D6130024 245A2F22
	ds_load_2addr_b32 v[22:23], v21 offset0:12 offset1:13      // 0000000F23E0: D8DC0D0C 16000015
	ds_load_2addr_b32 v[32:33], v21 offset0:14 offset1:15      // 0000000F23E8: D8DC0F0E 20000015
	ds_load_2addr_b32 v[34:35], v63 offset0:204 offset1:209    // 0000000F23F0: D8DCD1CC 2200003F
	v_add_nc_u32_e32 v21, 64, v21                              // 0000000F23F8: 4A2A2AC0
	s_waitcnt lgkmcnt(5)                                       // 0000000F23FC: BF89FC57
	v_fma_f32 v24, -v24, v26, v36                              // 0000000F2400: D6130018 24923518
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F2408: BF8700C1
	v_fma_f32 v26, -v25, v27, v24                              // 0000000F240C: D613001A 24623719
	ds_load_2addr_b32 v[24:25], v63 offset0:214 offset1:219    // 0000000F2414: D8DCDBD6 1800003F
	s_waitcnt lgkmcnt(4)                                       // 0000000F241C: BF89FC47
	v_fma_f32 v26, -v28, v30, v26                              // 0000000F2420: D613001A 246A3D1C
	v_fma_f32 v26, -v29, v31, v26                              // 0000000F2428: D613001A 246A3F1D
	s_waitcnt lgkmcnt(1)                                       // 0000000F2430: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2434: BF870091
	v_fma_f32 v22, -v22, v34, v26                              // 0000000F2438: D6130016 246A4516
	v_fma_f32 v22, -v23, v35, v22                              // 0000000F2440: D6130016 245A4717
	s_waitcnt lgkmcnt(0)                                       // 0000000F2448: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F244C: BF870091
	v_fma_f32 v22, -v32, v24, v22                              // 0000000F2450: D6130016 245A3120
	v_fma_f32 v22, -v33, v25, v22                              // 0000000F2458: D6130016 245A3321
	s_cbranch_scc1 65451                                       // 0000000F2460: BFA2FFAB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x910>
	ds_store_b32 v49, v22 offset:320                           // 0000000F2464: D8340140 00001631
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F246C: 8C7E047E
	v_mov_b32_e32 v21, v0                                      // 0000000F2470: 7E2A0300
	s_or_b32 s14, s9, 32                                       // 0000000F2474: 8C0EA009
	s_mov_b32 s4, 0                                            // 0000000F2478: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000F247C: BF89FC07
	s_barrier                                                  // 0000000F2480: BFBD0000
	buffer_gl0_inv                                             // 0000000F2484: E0AC0000 00000000
	s_nop 0                                                    // 0000000F248C: BF800000
	s_nop 0                                                    // 0000000F2490: BF800000
	s_nop 0                                                    // 0000000F2494: BF800000
	s_nop 0                                                    // 0000000F2498: BF800000
	s_nop 0                                                    // 0000000F249C: BF800000
	s_nop 0                                                    // 0000000F24A0: BF800000
	s_nop 0                                                    // 0000000F24A4: BF800000
	s_nop 0                                                    // 0000000F24A8: BF800000
	s_nop 0                                                    // 0000000F24AC: BF800000
	s_nop 0                                                    // 0000000F24B0: BF800000
	s_nop 0                                                    // 0000000F24B4: BF800000
	s_nop 0                                                    // 0000000F24B8: BF800000
	s_nop 0                                                    // 0000000F24BC: BF800000
	v_lshrrev_b32_e32 v24, 7, v21                              // 0000000F24C0: 32302A87
	v_add_nc_u32_e32 v26, 0x80, v21                            // 0000000F24C4: 4A342AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F24CC: BF870092
	v_or_b32_e32 v22, s14, v24                                 // 0000000F24D0: 382C300E
	v_mad_u64_u32 v[22:23], null, v22, 48, s[2:3]              // 0000000F24D4: D6FE7C16 00096116
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F24DC: BF870091
	.long 0xd73c0016                                           // 0000000F24E0: D73C0016
	v_cndmask_b32_e32 v1, 9, v22, vcc_lo                       // 0000000F24E4: 02022C89
	.long 0xd7000116                                           // 0000000F24E8: D7000116
	v_cndmask_b32_e32 v1, v43, v22, vcc_lo                     // 0000000F24EC: 02022D2B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F24F0: BF870001
	v_add_co_ci_u32_e64 v23, null, v44, v23, s1                // 0000000F24F4: D5207C17 00062F2C
	.long 0xd4490001                                           // 0000000F24FC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v21, vcc_lo                   // 0000000F2500: 02022AFF 0000077F
	v_mov_b32_e32 v21, v26                                     // 0000000F2508: 7E2A031A
	global_load_b32 v25, v[22:23], off                         // 0000000F250C: DC520000 197C0016
	v_mad_u64_u32 v[22:23], null, 0x204, v24, v[1:2]           // 0000000F2514: D6FE7C16 040630FF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000F2520: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000F2524: BF8903F7
	ds_store_b32 v22, v25                                      // 0000000F2528: D8340000 00001916
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000F2530: 917E047E
	s_cbranch_execnz 65506                                     // 0000000F2534: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xac0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F2538: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000F253C: BF89FC07
	s_barrier                                                  // 0000000F2540: BFBD0000
	buffer_gl0_inv                                             // 0000000F2544: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000F254C: BE842000
	s_cbranch_execz 102                                        // 0000000F2550: BFA50066 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xcec>
	v_or_b32_e32 v21, s14, v38                                 // 0000000F2554: 382A4C0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2558: BF870091
	v_mad_u64_u32 v[21:22], null, v21, 48, s[2:3]              // 0000000F255C: D6FE7C15 00096115
	.long 0xd73c0015                                           // 0000000F2564: D73C0015
	v_cndmask_b32_e32 v1, 9, v21, vcc_lo                       // 0000000F2568: 02022A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F256C: BF870091
	.long 0xd7000115                                           // 0000000F2570: D7000115
	v_cndmask_b32_e32 v1, v45, v21, vcc_lo                     // 0000000F2574: 02022B2D
	v_add_co_ci_u32_e64 v22, null, v46, v22, s1                // 0000000F2578: D5207C16 00062D2E
	s_movk_i32 s1, 0xf600                                      // 0000000F2580: B001F600
	global_load_b32 v22, v[21:22], off                         // 0000000F2584: DC520000 167C0015
	v_mov_b32_e32 v21, v48                                     // 0000000F258C: 7E2A0330
	v_add_nc_u32_e32 v23, s1, v42                              // 0000000F2590: 4A2E5401
	s_addk_i32 s1, 0x140                                       // 0000000F2594: B7810140
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2598: BF870099
	s_cmp_lg_u32 s1, 0                                         // 0000000F259C: BF078001
	v_add_nc_u32_e32 v63, 0x2800, v23                          // 0000000F25A0: 4A7E2EFF 00002800
	ds_load_2addr_b32 v[23:24], v21 offset1:1                  // 0000000F25A8: D8DC0100 17000015
	ds_load_2addr_b32 v[25:26], v63 offset0:144 offset1:149    // 0000000F25B0: D8DC9590 1900003F
	ds_load_2addr_b32 v[27:28], v21 offset0:2 offset1:3        // 0000000F25B8: D8DC0302 1B000015
	ds_load_2addr_b32 v[29:30], v63 offset0:154 offset1:159    // 0000000F25C0: D8DC9F9A 1D00003F
	ds_load_2addr_b32 v[31:32], v21 offset0:4 offset1:5        // 0000000F25C8: D8DC0504 1F000015
	ds_load_2addr_b32 v[33:34], v21 offset0:6 offset1:7        // 0000000F25D0: D8DC0706 21000015
	ds_load_2addr_b32 v[35:36], v63 offset0:164 offset1:169    // 0000000F25D8: D8DCA9A4 2300003F
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000F25E0: BF890057
	v_fma_f32 v22, -v23, v25, v22                              // 0000000F25E4: D6130016 245A3317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F25EC: BF8700C1
	v_fma_f32 v24, -v24, v26, v22                              // 0000000F25F0: D6130018 245A3518
	ds_load_2addr_b32 v[22:23], v63 offset0:174 offset1:179    // 0000000F25F8: D8DCB3AE 1600003F
	s_waitcnt lgkmcnt(4)                                       // 0000000F2600: BF89FC47
	v_fma_f32 v24, -v27, v29, v24                              // 0000000F2604: D6130018 24623B1B
	v_fma_f32 v28, -v28, v30, v24                              // 0000000F260C: D613001C 24623D1C
	ds_load_2addr_b32 v[24:25], v21 offset0:8 offset1:9        // 0000000F2614: D8DC0908 18000015
	ds_load_2addr_b32 v[26:27], v63 offset0:184 offset1:189    // 0000000F261C: D8DCBDB8 1A00003F
	s_waitcnt lgkmcnt(3)                                       // 0000000F2624: BF89FC37
	v_fma_f32 v28, -v31, v35, v28                              // 0000000F2628: D613001C 2472471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F2630: BF8700D1
	v_fma_f32 v32, -v32, v36, v28                              // 0000000F2634: D6130020 24724920
	ds_load_2addr_b32 v[28:29], v21 offset0:10 offset1:11      // 0000000F263C: D8DC0B0A 1C000015
	ds_load_2addr_b32 v[30:31], v63 offset0:194 offset1:199    // 0000000F2644: D8DCC7C2 1E00003F
	s_waitcnt lgkmcnt(4)                                       // 0000000F264C: BF89FC47
	v_fma_f32 v22, -v33, v22, v32                              // 0000000F2650: D6130016 24822D21
	v_fma_f32 v36, -v34, v23, v22                              // 0000000F2658: D6130024 245A2F22
	ds_load_2addr_b32 v[22:23], v21 offset0:12 offset1:13      // 0000000F2660: D8DC0D0C 16000015
	ds_load_2addr_b32 v[32:33], v21 offset0:14 offset1:15      // 0000000F2668: D8DC0F0E 20000015
	ds_load_2addr_b32 v[34:35], v63 offset0:204 offset1:209    // 0000000F2670: D8DCD1CC 2200003F
	v_add_nc_u32_e32 v21, 64, v21                              // 0000000F2678: 4A2A2AC0
	s_waitcnt lgkmcnt(5)                                       // 0000000F267C: BF89FC57
	v_fma_f32 v24, -v24, v26, v36                              // 0000000F2680: D6130018 24923518
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F2688: BF8700C1
	v_fma_f32 v26, -v25, v27, v24                              // 0000000F268C: D613001A 24623719
	ds_load_2addr_b32 v[24:25], v63 offset0:214 offset1:219    // 0000000F2694: D8DCDBD6 1800003F
	s_waitcnt lgkmcnt(4)                                       // 0000000F269C: BF89FC47
	v_fma_f32 v26, -v28, v30, v26                              // 0000000F26A0: D613001A 246A3D1C
	v_fma_f32 v26, -v29, v31, v26                              // 0000000F26A8: D613001A 246A3F1D
	s_waitcnt lgkmcnt(1)                                       // 0000000F26B0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F26B4: BF870091
	v_fma_f32 v22, -v22, v34, v26                              // 0000000F26B8: D6130016 246A4516
	v_fma_f32 v22, -v23, v35, v22                              // 0000000F26C0: D6130016 245A4717
	s_waitcnt lgkmcnt(0)                                       // 0000000F26C8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F26CC: BF870091
	v_fma_f32 v22, -v32, v24, v22                              // 0000000F26D0: D6130016 245A3120
	v_fma_f32 v22, -v33, v25, v22                              // 0000000F26D8: D6130016 245A3321
	s_cbranch_scc1 65451                                       // 0000000F26E0: BFA2FFAB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb90>
	ds_store_b32 v49, v22 offset:640                           // 0000000F26E4: D8340280 00001631
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F26EC: 8C7E047E
	v_mov_b32_e32 v21, v0                                      // 0000000F26F0: 7E2A0300
	s_or_b32 s11, s9, 48                                       // 0000000F26F4: 8C0BB009
	s_mov_b32 s4, 0                                            // 0000000F26F8: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000F26FC: BF89FC07
	s_barrier                                                  // 0000000F2700: BFBD0000
	buffer_gl0_inv                                             // 0000000F2704: E0AC0000 00000000
	s_nop 0                                                    // 0000000F270C: BF800000
	s_nop 0                                                    // 0000000F2710: BF800000
	s_nop 0                                                    // 0000000F2714: BF800000
	s_nop 0                                                    // 0000000F2718: BF800000
	s_nop 0                                                    // 0000000F271C: BF800000
	s_nop 0                                                    // 0000000F2720: BF800000
	s_nop 0                                                    // 0000000F2724: BF800000
	s_nop 0                                                    // 0000000F2728: BF800000
	s_nop 0                                                    // 0000000F272C: BF800000
	s_nop 0                                                    // 0000000F2730: BF800000
	s_nop 0                                                    // 0000000F2734: BF800000
	s_nop 0                                                    // 0000000F2738: BF800000
	s_nop 0                                                    // 0000000F273C: BF800000
	v_lshrrev_b32_e32 v24, 7, v21                              // 0000000F2740: 32302A87
	v_add_nc_u32_e32 v26, 0x80, v21                            // 0000000F2744: 4A342AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F274C: BF870092
	v_or_b32_e32 v22, s11, v24                                 // 0000000F2750: 382C300B
	v_mad_u64_u32 v[22:23], null, v22, 48, s[2:3]              // 0000000F2754: D6FE7C16 00096116
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F275C: BF870091
	.long 0xd73c0016                                           // 0000000F2760: D73C0016
	v_cndmask_b32_e32 v1, 9, v22, vcc_lo                       // 0000000F2764: 02022C89
	.long 0xd7000116                                           // 0000000F2768: D7000116
	v_cndmask_b32_e32 v1, v43, v22, vcc_lo                     // 0000000F276C: 02022D2B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F2770: BF870001
	v_add_co_ci_u32_e64 v23, null, v44, v23, s1                // 0000000F2774: D5207C17 00062F2C
	.long 0xd4490001                                           // 0000000F277C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v21, vcc_lo                   // 0000000F2780: 02022AFF 0000077F
	v_mov_b32_e32 v21, v26                                     // 0000000F2788: 7E2A031A
	global_load_b32 v25, v[22:23], off                         // 0000000F278C: DC520000 197C0016
	v_mad_u64_u32 v[22:23], null, 0x204, v24, v[1:2]           // 0000000F2794: D6FE7C16 040630FF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000F27A0: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000F27A4: BF8903F7
	ds_store_b32 v22, v25                                      // 0000000F27A8: D8340000 00001916
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000F27B0: 917E047E
	s_cbranch_execnz 65506                                     // 0000000F27B4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd40>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F27B8: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000F27BC: BF89FC07
	s_barrier                                                  // 0000000F27C0: BFBD0000
	buffer_gl0_inv                                             // 0000000F27C4: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000F27CC: BE842000
	s_cbranch_execz 102                                        // 0000000F27D0: BFA50066 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xf6c>
	v_or_b32_e32 v21, s11, v38                                 // 0000000F27D4: 382A4C0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F27D8: BF870091
	v_mad_u64_u32 v[21:22], null, v21, 48, s[2:3]              // 0000000F27DC: D6FE7C15 00096115
	.long 0xd73c0015                                           // 0000000F27E4: D73C0015
	v_cndmask_b32_e32 v1, 9, v21, vcc_lo                       // 0000000F27E8: 02022A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F27EC: BF870091
	.long 0xd7000115                                           // 0000000F27F0: D7000115
	v_cndmask_b32_e32 v1, v45, v21, vcc_lo                     // 0000000F27F4: 02022B2D
	v_add_co_ci_u32_e64 v22, null, v46, v22, s1                // 0000000F27F8: D5207C16 00062D2E
	s_movk_i32 s1, 0xf600                                      // 0000000F2800: B001F600
	global_load_b32 v22, v[21:22], off                         // 0000000F2804: DC520000 167C0015
	v_mov_b32_e32 v21, v48                                     // 0000000F280C: 7E2A0330
	v_add_nc_u32_e32 v23, s1, v42                              // 0000000F2810: 4A2E5401
	s_addk_i32 s1, 0x140                                       // 0000000F2814: B7810140
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2818: BF870099
	s_cmp_lg_u32 s1, 0                                         // 0000000F281C: BF078001
	v_add_nc_u32_e32 v63, 0x2800, v23                          // 0000000F2820: 4A7E2EFF 00002800
	ds_load_2addr_b32 v[23:24], v21 offset1:1                  // 0000000F2828: D8DC0100 17000015
	ds_load_2addr_b32 v[25:26], v63 offset0:144 offset1:149    // 0000000F2830: D8DC9590 1900003F
	ds_load_2addr_b32 v[27:28], v21 offset0:2 offset1:3        // 0000000F2838: D8DC0302 1B000015
	ds_load_2addr_b32 v[29:30], v63 offset0:154 offset1:159    // 0000000F2840: D8DC9F9A 1D00003F
	ds_load_2addr_b32 v[31:32], v21 offset0:4 offset1:5        // 0000000F2848: D8DC0504 1F000015
	ds_load_2addr_b32 v[33:34], v21 offset0:6 offset1:7        // 0000000F2850: D8DC0706 21000015
	ds_load_2addr_b32 v[35:36], v63 offset0:164 offset1:169    // 0000000F2858: D8DCA9A4 2300003F
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000F2860: BF890057
	v_fma_f32 v22, -v23, v25, v22                              // 0000000F2864: D6130016 245A3317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F286C: BF8700C1
	v_fma_f32 v24, -v24, v26, v22                              // 0000000F2870: D6130018 245A3518
	ds_load_2addr_b32 v[22:23], v63 offset0:174 offset1:179    // 0000000F2878: D8DCB3AE 1600003F
	s_waitcnt lgkmcnt(4)                                       // 0000000F2880: BF89FC47
	v_fma_f32 v24, -v27, v29, v24                              // 0000000F2884: D6130018 24623B1B
	v_fma_f32 v28, -v28, v30, v24                              // 0000000F288C: D613001C 24623D1C
	ds_load_2addr_b32 v[24:25], v21 offset0:8 offset1:9        // 0000000F2894: D8DC0908 18000015
	ds_load_2addr_b32 v[26:27], v63 offset0:184 offset1:189    // 0000000F289C: D8DCBDB8 1A00003F
	s_waitcnt lgkmcnt(3)                                       // 0000000F28A4: BF89FC37
	v_fma_f32 v28, -v31, v35, v28                              // 0000000F28A8: D613001C 2472471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F28B0: BF8700D1
	v_fma_f32 v32, -v32, v36, v28                              // 0000000F28B4: D6130020 24724920
	ds_load_2addr_b32 v[28:29], v21 offset0:10 offset1:11      // 0000000F28BC: D8DC0B0A 1C000015
	ds_load_2addr_b32 v[30:31], v63 offset0:194 offset1:199    // 0000000F28C4: D8DCC7C2 1E00003F
	s_waitcnt lgkmcnt(4)                                       // 0000000F28CC: BF89FC47
	v_fma_f32 v22, -v33, v22, v32                              // 0000000F28D0: D6130016 24822D21
	v_fma_f32 v36, -v34, v23, v22                              // 0000000F28D8: D6130024 245A2F22
	ds_load_2addr_b32 v[22:23], v21 offset0:12 offset1:13      // 0000000F28E0: D8DC0D0C 16000015
	ds_load_2addr_b32 v[32:33], v21 offset0:14 offset1:15      // 0000000F28E8: D8DC0F0E 20000015
	ds_load_2addr_b32 v[34:35], v63 offset0:204 offset1:209    // 0000000F28F0: D8DCD1CC 2200003F
	v_add_nc_u32_e32 v21, 64, v21                              // 0000000F28F8: 4A2A2AC0
	s_waitcnt lgkmcnt(5)                                       // 0000000F28FC: BF89FC57
	v_fma_f32 v24, -v24, v26, v36                              // 0000000F2900: D6130018 24923518
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F2908: BF8700C1
	v_fma_f32 v26, -v25, v27, v24                              // 0000000F290C: D613001A 24623719
	ds_load_2addr_b32 v[24:25], v63 offset0:214 offset1:219    // 0000000F2914: D8DCDBD6 1800003F
	s_waitcnt lgkmcnt(4)                                       // 0000000F291C: BF89FC47
	v_fma_f32 v26, -v28, v30, v26                              // 0000000F2920: D613001A 246A3D1C
	v_fma_f32 v26, -v29, v31, v26                              // 0000000F2928: D613001A 246A3F1D
	s_waitcnt lgkmcnt(1)                                       // 0000000F2930: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2934: BF870091
	v_fma_f32 v22, -v22, v34, v26                              // 0000000F2938: D6130016 246A4516
	v_fma_f32 v22, -v23, v35, v22                              // 0000000F2940: D6130016 245A4717
	s_waitcnt lgkmcnt(0)                                       // 0000000F2948: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F294C: BF870091
	v_fma_f32 v22, -v32, v24, v22                              // 0000000F2950: D6130016 245A3120
	v_fma_f32 v22, -v33, v25, v22                              // 0000000F2958: D6130016 245A3321
	s_cbranch_scc1 65451                                       // 0000000F2960: BFA2FFAB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe10>
	ds_store_b32 v49, v22 offset:960                           // 0000000F2964: D83403C0 00001631
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F296C: 8C7E047E
	v_mov_b32_e32 v21, v0                                      // 0000000F2970: 7E2A0300
	s_mov_b32 s4, 0                                            // 0000000F2974: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000F2978: BF89FC07
	s_barrier                                                  // 0000000F297C: BFBD0000
	buffer_gl0_inv                                             // 0000000F2980: E0AC0000 00000000
	s_nop 0                                                    // 0000000F2988: BF800000
	s_nop 0                                                    // 0000000F298C: BF800000
	s_nop 0                                                    // 0000000F2990: BF800000
	s_nop 0                                                    // 0000000F2994: BF800000
	s_nop 0                                                    // 0000000F2998: BF800000
	s_nop 0                                                    // 0000000F299C: BF800000
	s_nop 0                                                    // 0000000F29A0: BF800000
	s_nop 0                                                    // 0000000F29A4: BF800000
	s_nop 0                                                    // 0000000F29A8: BF800000
	s_nop 0                                                    // 0000000F29AC: BF800000
	s_nop 0                                                    // 0000000F29B0: BF800000
	s_nop 0                                                    // 0000000F29B4: BF800000
	s_nop 0                                                    // 0000000F29B8: BF800000
	s_nop 0                                                    // 0000000F29BC: BF800000
	v_lshrrev_b32_e32 v24, 7, v21                              // 0000000F29C0: 32302A87
	v_add_nc_u32_e32 v26, 0x80, v21                            // 0000000F29C4: 4A342AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F29CC: BF870092
	v_or_b32_e32 v22, s9, v24                                  // 0000000F29D0: 382C3009
	v_mad_u64_u32 v[22:23], null, v22, 48, s[2:3]              // 0000000F29D4: D6FE7C16 00096116
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F29DC: BF870091
	.long 0xd73c0016                                           // 0000000F29E0: D73C0016
	v_cndmask_b32_e32 v1, 9, v22, vcc_lo                       // 0000000F29E4: 02022C89
	.long 0xd7000116                                           // 0000000F29E8: D7000116
	v_cndmask_b32_e32 v1, v54, v22, vcc_lo                     // 0000000F29EC: 02022D36
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F29F0: BF870001
	v_add_co_ci_u32_e64 v23, null, v55, v23, s1                // 0000000F29F4: D5207C17 00062F37
	.long 0xd4490001                                           // 0000000F29FC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v21, vcc_lo                   // 0000000F2A00: 02022AFF 0000077F
	v_mov_b32_e32 v21, v26                                     // 0000000F2A08: 7E2A031A
	global_load_b32 v25, v[22:23], off                         // 0000000F2A0C: DC520000 197C0016
	v_mad_u64_u32 v[22:23], null, 0x204, v24, v[1:2]           // 0000000F2A14: D6FE7C16 040630FF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000F2A20: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000F2A24: BF8903F7
	ds_store_b32 v22, v25                                      // 0000000F2A28: D8340000 00001916
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000F2A30: 917E047E
	s_cbranch_execnz 65506                                     // 0000000F2A34: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F2A38: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000F2A3C: BF89FC07
	s_barrier                                                  // 0000000F2A40: BFBD0000
	buffer_gl0_inv                                             // 0000000F2A44: E0AC0000 00000000
	s_and_saveexec_b32 s16, s0                                 // 0000000F2A4C: BE902000
	s_cbranch_execz 118                                        // 0000000F2A50: BFA50076 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x122c>
	v_or_b32_e32 v23, s9, v38                                  // 0000000F2A54: 382E4C09
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F2A58: BF870001
	.long 0xd4440001                                           // 0000000F2A5C: D4440001
	v_cndmask_b32_e32 v1, s5, v23, vcc_lo                      // 0000000F2A60: 02022E05
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000F2A64: 8B7E017E
	s_cbranch_execz 112                                        // 0000000F2A68: BFA50070 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x122c>
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v21, v48           // 0000000F2A6C: CA100080 18140130
	s_movk_i32 s1, 0xf600                                      // 0000000F2A74: B001F600
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000F2A78: BF8704A9
	v_add_nc_u32_e32 v22, s1, v42                              // 0000000F2A7C: 4A2C5401
	s_addk_i32 s1, 0x140                                       // 0000000F2A80: B7810140
	s_cmp_eq_u32 s1, 0                                         // 0000000F2A84: BF068001
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F2A88: BF870001
	v_add_nc_u32_e32 v22, 0x2800, v22                          // 0000000F2A8C: 4A2C2CFF 00002800
	ds_load_2addr_b32 v[25:26], v21 offset1:1                  // 0000000F2A94: D8DC0100 19000015
	ds_load_2addr_b32 v[27:28], v22 offset0:144 offset1:149    // 0000000F2A9C: D8DC9590 1B000016
	ds_load_2addr_b32 v[29:30], v21 offset0:2 offset1:3        // 0000000F2AA4: D8DC0302 1D000015
	ds_load_2addr_b32 v[31:32], v22 offset0:154 offset1:159    // 0000000F2AAC: D8DC9F9A 1F000016
	ds_load_2addr_b32 v[33:34], v21 offset0:4 offset1:5        // 0000000F2AB4: D8DC0504 21000015
	ds_load_2addr_b32 v[35:36], v21 offset0:6 offset1:7        // 0000000F2ABC: D8DC0706 23000015
	ds_load_2addr_b32 v[63:64], v22 offset0:164 offset1:169    // 0000000F2AC4: D8DCA9A4 3F000016
	s_waitcnt lgkmcnt(5)                                       // 0000000F2ACC: BF89FC57
	v_fmac_f32_e32 v24, v25, v27                               // 0000000F2AD0: 56303719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F2AD4: BF8700C1
	v_fmac_f32_e32 v24, v26, v28                               // 0000000F2AD8: 5630391A
	ds_load_2addr_b32 v[25:26], v22 offset0:174 offset1:179    // 0000000F2ADC: D8DCB3AE 19000016
	s_waitcnt lgkmcnt(4)                                       // 0000000F2AE4: BF89FC47
	v_fmac_f32_e32 v24, v29, v31                               // 0000000F2AE8: 56303F1D
	v_fmac_f32_e32 v24, v30, v32                               // 0000000F2AEC: 5630411E
	ds_load_2addr_b32 v[27:28], v21 offset0:8 offset1:9        // 0000000F2AF0: D8DC0908 1B000015
	ds_load_2addr_b32 v[29:30], v22 offset0:184 offset1:189    // 0000000F2AF8: D8DCBDB8 1D000016
	s_waitcnt lgkmcnt(3)                                       // 0000000F2B00: BF89FC37
	v_fmac_f32_e32 v24, v33, v63                               // 0000000F2B04: 56307F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F2B08: BF8700D1
	v_fmac_f32_e32 v24, v34, v64                               // 0000000F2B0C: 56308122
	ds_load_2addr_b32 v[31:32], v21 offset0:10 offset1:11      // 0000000F2B10: D8DC0B0A 1F000015
	ds_load_2addr_b32 v[33:34], v22 offset0:194 offset1:199    // 0000000F2B18: D8DCC7C2 21000016
	s_waitcnt lgkmcnt(4)                                       // 0000000F2B20: BF89FC47
	v_fmac_f32_e32 v24, v35, v25                               // 0000000F2B24: 56303323
	v_fmac_f32_e32 v24, v36, v26                               // 0000000F2B28: 56303524
	ds_load_2addr_b32 v[25:26], v21 offset0:12 offset1:13      // 0000000F2B2C: D8DC0D0C 19000015
	ds_load_2addr_b32 v[35:36], v21 offset0:14 offset1:15      // 0000000F2B34: D8DC0F0E 23000015
	ds_load_2addr_b32 v[63:64], v22 offset0:204 offset1:209    // 0000000F2B3C: D8DCD1CC 3F000016
	v_add_nc_u32_e32 v21, 64, v21                              // 0000000F2B44: 4A2A2AC0
	s_waitcnt lgkmcnt(5)                                       // 0000000F2B48: BF89FC57
	v_fmac_f32_e32 v24, v27, v29                               // 0000000F2B4C: 56303B1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F2B50: BF8700C1
	v_fmac_f32_e32 v24, v28, v30                               // 0000000F2B54: 56303D1C
	ds_load_2addr_b32 v[27:28], v22 offset0:214 offset1:219    // 0000000F2B58: D8DCDBD6 1B000016
	s_waitcnt lgkmcnt(4)                                       // 0000000F2B60: BF89FC47
	v_fmac_f32_e32 v24, v31, v33                               // 0000000F2B64: 5630431F
	v_fmac_f32_e32 v24, v32, v34                               // 0000000F2B68: 56304520
	s_waitcnt lgkmcnt(1)                                       // 0000000F2B6C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2B70: BF870091
	v_fmac_f32_e32 v24, v25, v63                               // 0000000F2B74: 56307F19
	v_fmac_f32_e32 v24, v26, v64                               // 0000000F2B78: 5630811A
	s_waitcnt lgkmcnt(0)                                       // 0000000F2B7C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2B80: BF870091
	v_fmac_f32_e32 v24, v35, v27                               // 0000000F2B84: 56303723
	v_fmac_f32_e32 v24, v36, v28                               // 0000000F2B88: 56303924
	s_cbranch_scc0 65466                                       // 0000000F2B8C: BFA1FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	ds_load_b32 v26, v50                                       // 0000000F2B90: D8D80000 1A000032
	v_mov_b32_e32 v25, v42                                     // 0000000F2B98: 7E32032A
	v_dual_mov_b32 v22, v6 :: v_dual_mov_b32 v21, v5           // 0000000F2B9C: CA100106 16140105
	s_mov_b32 s17, 0                                           // 0000000F2BA4: BE910080
	s_waitcnt lgkmcnt(0)                                       // 0000000F2BA8: BF89FC07
	v_mul_f32_e32 v24, v24, v26                                // 0000000F2BAC: 10303518
	v_mov_b32_e32 v26, v58                                     // 0000000F2BB0: 7E34033A
	global_load_b32 v27, v[21:22], off                         // 0000000F2BB4: DC520000 1B7C0015
	ds_load_b32 v28, v25 offset:10816                          // 0000000F2BBC: D8D82A40 1C000019
	v_add_nc_u32_e32 v26, -1, v26                              // 0000000F2BC4: 4A3434C1
	.long 0xd7000115                                           // 0000000F2BC8: D7000115
	v_cndmask_b32_e32 v0, v21, v132, vcc_lo                    // 0000000F2BCC: 02010915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F2BD0: BF870191
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000F2BD4: D5207C16 00062C80
	.long 0xd44a0004                                           // 0000000F2BDC: D44A0004
	v_cndmask_b32_e32 v1, 0, v26, vcc_lo                       // 0000000F2BE0: 02023480
	v_add_nc_u32_e32 v25, 20, v25                              // 0000000F2BE4: 4A323294
	s_or_b32 s17, s4, s17                                      // 0000000F2BE8: 8C111104
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F2BEC: BF890007
	v_fmac_f32_e32 v24, v27, v28                               // 0000000F2BF0: 5630391B
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000000F2BF4: 917E117E
	s_cbranch_execnz 65518                                     // 0000000F2BF8: BFA6FFEE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11b4>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000000F2BFC: 8C7E117E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F2C00: BF870121
	v_bfe_u32 v25, v24, 16, 1                                  // 0000000F2C04: D6100019 02052118
	v_mad_u64_u32 v[21:22], null, 0x3000, v23, v[3:4]          // 0000000F2C0C: D6FE7C15 040E2EFF 00003000
	v_add3_u32 v23, v24, v25, 0x7fff                           // 0000000F2C18: D6550017 03FE3318 00007FFF
	global_store_d16_hi_b16 v[21:22], v23, off                 // 0000000F2C24: DC960000 007C1715
	s_or_b32 exec_lo, exec_lo, s16                             // 0000000F2C2C: 8C7E107E
	v_mov_b32_e32 v21, v0                                      // 0000000F2C30: 7E2A0300
	s_mov_b32 s4, 0                                            // 0000000F2C34: BE840080
	s_waitcnt_vscnt null, 0x0                                  // 0000000F2C38: BC7C0000
	s_barrier                                                  // 0000000F2C3C: BFBD0000
	buffer_gl0_inv                                             // 0000000F2C40: E0AC0000 00000000
	s_nop 0                                                    // 0000000F2C48: BF800000
	s_nop 0                                                    // 0000000F2C4C: BF800000
	s_nop 0                                                    // 0000000F2C50: BF800000
	s_nop 0                                                    // 0000000F2C54: BF800000
	s_nop 0                                                    // 0000000F2C58: BF800000
	s_nop 0                                                    // 0000000F2C5C: BF800000
	s_nop 0                                                    // 0000000F2C60: BF800000
	s_nop 0                                                    // 0000000F2C64: BF800000
	s_nop 0                                                    // 0000000F2C68: BF800000
	s_nop 0                                                    // 0000000F2C6C: BF800000
	s_nop 0                                                    // 0000000F2C70: BF800000
	s_nop 0                                                    // 0000000F2C74: BF800000
	s_nop 0                                                    // 0000000F2C78: BF800000
	s_nop 0                                                    // 0000000F2C7C: BF800000
	v_lshrrev_b32_e32 v24, 7, v21                              // 0000000F2C80: 32302A87
	v_add_nc_u32_e32 v26, 0x80, v21                            // 0000000F2C84: 4A342AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2C8C: BF870092
	v_or_b32_e32 v22, s15, v24                                 // 0000000F2C90: 382C300F
	v_mad_u64_u32 v[22:23], null, v22, 48, s[2:3]              // 0000000F2C94: D6FE7C16 00096116
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2C9C: BF870091
	.long 0xd73c0016                                           // 0000000F2CA0: D73C0016
	v_cndmask_b32_e32 v1, 9, v22, vcc_lo                       // 0000000F2CA4: 02022C89
	.long 0xd7000116                                           // 0000000F2CA8: D7000116
	v_cndmask_b32_e32 v1, v54, v22, vcc_lo                     // 0000000F2CAC: 02022D36
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F2CB0: BF870001
	v_add_co_ci_u32_e64 v23, null, v55, v23, s1                // 0000000F2CB4: D5207C17 00062F37
	.long 0xd4490001                                           // 0000000F2CBC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v21, vcc_lo                   // 0000000F2CC0: 02022AFF 0000077F
	v_mov_b32_e32 v21, v26                                     // 0000000F2CC8: 7E2A031A
	global_load_b32 v25, v[22:23], off                         // 0000000F2CCC: DC520000 197C0016
	v_mad_u64_u32 v[22:23], null, 0x204, v24, v[1:2]           // 0000000F2CD4: D6FE7C16 040630FF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000F2CE0: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000F2CE4: BF8903F7
	ds_store_b32 v22, v25                                      // 0000000F2CE8: D8340000 00001916
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000F2CF0: 917E047E
	s_cbranch_execnz 65506                                     // 0000000F2CF4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1280>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F2CF8: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000F2CFC: BF89FC07
	s_barrier                                                  // 0000000F2D00: BFBD0000
	buffer_gl0_inv                                             // 0000000F2D04: E0AC0000 00000000
	s_and_saveexec_b32 s15, s0                                 // 0000000F2D0C: BE8F2000
	s_cbranch_execz 118                                        // 0000000F2D10: BFA50076 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14ec>
	v_or_b32_e32 v23, s9, v51                                  // 0000000F2D14: 382E6609
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F2D18: BF870001
	.long 0xd4440001                                           // 0000000F2D1C: D4440001
	v_cndmask_b32_e32 v1, s5, v23, vcc_lo                      // 0000000F2D20: 02022E05
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000F2D24: 8B7E017E
	s_cbranch_execz 112                                        // 0000000F2D28: BFA50070 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14ec>
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v21, v48           // 0000000F2D2C: CA100080 18140130
	s_movk_i32 s1, 0xf600                                      // 0000000F2D34: B001F600
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000F2D38: BF8704A9
	v_add_nc_u32_e32 v22, s1, v42                              // 0000000F2D3C: 4A2C5401
	s_addk_i32 s1, 0x140                                       // 0000000F2D40: B7810140
	s_cmp_lg_u32 s1, 0                                         // 0000000F2D44: BF078001
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F2D48: BF870001
	v_add_nc_u32_e32 v22, 0x2800, v22                          // 0000000F2D4C: 4A2C2CFF 00002800
	ds_load_2addr_b32 v[25:26], v21 offset1:1                  // 0000000F2D54: D8DC0100 19000015
	ds_load_2addr_b32 v[27:28], v22 offset0:144 offset1:149    // 0000000F2D5C: D8DC9590 1B000016
	ds_load_2addr_b32 v[29:30], v21 offset0:2 offset1:3        // 0000000F2D64: D8DC0302 1D000015
	ds_load_2addr_b32 v[31:32], v22 offset0:154 offset1:159    // 0000000F2D6C: D8DC9F9A 1F000016
	ds_load_2addr_b32 v[33:34], v21 offset0:4 offset1:5        // 0000000F2D74: D8DC0504 21000015
	ds_load_2addr_b32 v[35:36], v21 offset0:6 offset1:7        // 0000000F2D7C: D8DC0706 23000015
	ds_load_2addr_b32 v[63:64], v22 offset0:164 offset1:169    // 0000000F2D84: D8DCA9A4 3F000016
	s_waitcnt lgkmcnt(5)                                       // 0000000F2D8C: BF89FC57
	v_fmac_f32_e32 v24, v25, v27                               // 0000000F2D90: 56303719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F2D94: BF8700C1
	v_fmac_f32_e32 v24, v26, v28                               // 0000000F2D98: 5630391A
	ds_load_2addr_b32 v[25:26], v22 offset0:174 offset1:179    // 0000000F2D9C: D8DCB3AE 19000016
	s_waitcnt lgkmcnt(4)                                       // 0000000F2DA4: BF89FC47
	v_fmac_f32_e32 v24, v29, v31                               // 0000000F2DA8: 56303F1D
	v_fmac_f32_e32 v24, v30, v32                               // 0000000F2DAC: 5630411E
	ds_load_2addr_b32 v[27:28], v21 offset0:8 offset1:9        // 0000000F2DB0: D8DC0908 1B000015
	ds_load_2addr_b32 v[29:30], v22 offset0:184 offset1:189    // 0000000F2DB8: D8DCBDB8 1D000016
	s_waitcnt lgkmcnt(3)                                       // 0000000F2DC0: BF89FC37
	v_fmac_f32_e32 v24, v33, v63                               // 0000000F2DC4: 56307F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F2DC8: BF8700D1
	v_fmac_f32_e32 v24, v34, v64                               // 0000000F2DCC: 56308122
	ds_load_2addr_b32 v[31:32], v21 offset0:10 offset1:11      // 0000000F2DD0: D8DC0B0A 1F000015
	ds_load_2addr_b32 v[33:34], v22 offset0:194 offset1:199    // 0000000F2DD8: D8DCC7C2 21000016
	s_waitcnt lgkmcnt(4)                                       // 0000000F2DE0: BF89FC47
	v_fmac_f32_e32 v24, v35, v25                               // 0000000F2DE4: 56303323
	v_fmac_f32_e32 v24, v36, v26                               // 0000000F2DE8: 56303524
	ds_load_2addr_b32 v[25:26], v21 offset0:12 offset1:13      // 0000000F2DEC: D8DC0D0C 19000015
	ds_load_2addr_b32 v[35:36], v21 offset0:14 offset1:15      // 0000000F2DF4: D8DC0F0E 23000015
	ds_load_2addr_b32 v[63:64], v22 offset0:204 offset1:209    // 0000000F2DFC: D8DCD1CC 3F000016
	v_add_nc_u32_e32 v21, 64, v21                              // 0000000F2E04: 4A2A2AC0
	s_waitcnt lgkmcnt(5)                                       // 0000000F2E08: BF89FC57
	v_fmac_f32_e32 v24, v27, v29                               // 0000000F2E0C: 56303B1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F2E10: BF8700C1
	v_fmac_f32_e32 v24, v28, v30                               // 0000000F2E14: 56303D1C
	ds_load_2addr_b32 v[27:28], v22 offset0:214 offset1:219    // 0000000F2E18: D8DCDBD6 1B000016
	s_waitcnt lgkmcnt(4)                                       // 0000000F2E20: BF89FC47
	v_fmac_f32_e32 v24, v31, v33                               // 0000000F2E24: 5630431F
	v_fmac_f32_e32 v24, v32, v34                               // 0000000F2E28: 56304520
	s_waitcnt lgkmcnt(1)                                       // 0000000F2E2C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2E30: BF870091
	v_fmac_f32_e32 v24, v25, v63                               // 0000000F2E34: 56307F19
	v_fmac_f32_e32 v24, v26, v64                               // 0000000F2E38: 5630811A
	s_waitcnt lgkmcnt(0)                                       // 0000000F2E3C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2E40: BF870091
	v_fmac_f32_e32 v24, v35, v27                               // 0000000F2E44: 56303723
	v_fmac_f32_e32 v24, v36, v28                               // 0000000F2E48: 56303924
	s_cbranch_scc1 65466                                       // 0000000F2E4C: BFA2FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1338>
	ds_load_b32 v26, v50 offset:64                             // 0000000F2E50: D8D80040 1A000032
	v_dual_mov_b32 v22, v8 :: v_dual_mov_b32 v21, v7           // 0000000F2E58: CA100108 16140107
	v_mov_b32_e32 v25, v42                                     // 0000000F2E60: 7E32032A
	s_mov_b32 s16, 0                                           // 0000000F2E64: BE900080
	s_waitcnt lgkmcnt(0)                                       // 0000000F2E68: BF89FC07
	v_mul_f32_e32 v24, v24, v26                                // 0000000F2E6C: 10303518
	v_mov_b32_e32 v26, v59                                     // 0000000F2E70: 7E34033B
	global_load_b32 v27, v[21:22], off                         // 0000000F2E74: DC520000 1B7C0015
	ds_load_b32 v28, v25 offset:10816                          // 0000000F2E7C: D8D82A40 1C000019
	v_add_nc_u32_e32 v26, -1, v26                              // 0000000F2E84: 4A3434C1
	.long 0xd7000115                                           // 0000000F2E88: D7000115
	v_cndmask_b32_e32 v0, v21, v132, vcc_lo                    // 0000000F2E8C: 02010915
	v_add_nc_u32_e32 v25, 20, v25                              // 0000000F2E90: 4A323294
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000F2E94: D5207C16 00062C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000F2E9C: BF870004
	.long 0xd44a0004                                           // 0000000F2EA0: D44A0004
	v_cndmask_b32_e32 v1, 0, v26, vcc_lo                       // 0000000F2EA4: 02023480
	s_or_b32 s16, s4, s16                                      // 0000000F2EA8: 8C101004
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F2EAC: BF890007
	v_fmac_f32_e32 v24, v27, v28                               // 0000000F2EB0: 5630391B
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000000F2EB4: 917E107E
	s_cbranch_execnz 65518                                     // 0000000F2EB8: BFA6FFEE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1474>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000000F2EBC: 8C7E107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F2EC0: BF870121
	v_bfe_u32 v25, v24, 16, 1                                  // 0000000F2EC4: D6100019 02052118
	v_mad_u64_u32 v[21:22], null, 0x3000, v23, v[3:4]          // 0000000F2ECC: D6FE7C15 040E2EFF 00003000
	v_add3_u32 v23, v24, v25, 0x7fff                           // 0000000F2ED8: D6550017 03FE3318 00007FFF
	global_store_d16_hi_b16 v[21:22], v23, off                 // 0000000F2EE4: DC960000 007C1715
	s_or_b32 exec_lo, exec_lo, s15                             // 0000000F2EEC: 8C7E0F7E
	v_mov_b32_e32 v21, v0                                      // 0000000F2EF0: 7E2A0300
	s_mov_b32 s4, 0                                            // 0000000F2EF4: BE840080
	s_waitcnt_vscnt null, 0x0                                  // 0000000F2EF8: BC7C0000
	s_barrier                                                  // 0000000F2EFC: BFBD0000
	buffer_gl0_inv                                             // 0000000F2F00: E0AC0000 00000000
	s_nop 0                                                    // 0000000F2F08: BF800000
	s_nop 0                                                    // 0000000F2F0C: BF800000
	s_nop 0                                                    // 0000000F2F10: BF800000
	s_nop 0                                                    // 0000000F2F14: BF800000
	s_nop 0                                                    // 0000000F2F18: BF800000
	s_nop 0                                                    // 0000000F2F1C: BF800000
	s_nop 0                                                    // 0000000F2F20: BF800000
	s_nop 0                                                    // 0000000F2F24: BF800000
	s_nop 0                                                    // 0000000F2F28: BF800000
	s_nop 0                                                    // 0000000F2F2C: BF800000
	s_nop 0                                                    // 0000000F2F30: BF800000
	s_nop 0                                                    // 0000000F2F34: BF800000
	s_nop 0                                                    // 0000000F2F38: BF800000
	s_nop 0                                                    // 0000000F2F3C: BF800000
	v_lshrrev_b32_e32 v24, 7, v21                              // 0000000F2F40: 32302A87
	v_add_nc_u32_e32 v26, 0x80, v21                            // 0000000F2F44: 4A342AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2F4C: BF870092
	v_or_b32_e32 v22, s14, v24                                 // 0000000F2F50: 382C300E
	v_mad_u64_u32 v[22:23], null, v22, 48, s[2:3]              // 0000000F2F54: D6FE7C16 00096116
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F2F5C: BF870091
	.long 0xd73c0016                                           // 0000000F2F60: D73C0016
	v_cndmask_b32_e32 v1, 9, v22, vcc_lo                       // 0000000F2F64: 02022C89
	.long 0xd7000116                                           // 0000000F2F68: D7000116
	v_cndmask_b32_e32 v1, v54, v22, vcc_lo                     // 0000000F2F6C: 02022D36
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F2F70: BF870001
	v_add_co_ci_u32_e64 v23, null, v55, v23, s1                // 0000000F2F74: D5207C17 00062F37
	.long 0xd4490001                                           // 0000000F2F7C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v21, vcc_lo                   // 0000000F2F80: 02022AFF 0000077F
	v_mov_b32_e32 v21, v26                                     // 0000000F2F88: 7E2A031A
	global_load_b32 v25, v[22:23], off                         // 0000000F2F8C: DC520000 197C0016
	v_mad_u64_u32 v[22:23], null, 0x204, v24, v[1:2]           // 0000000F2F94: D6FE7C16 040630FF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000F2FA0: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000F2FA4: BF8903F7
	ds_store_b32 v22, v25                                      // 0000000F2FA8: D8340000 00001916
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000F2FB0: 917E047E
	s_cbranch_execnz 65506                                     // 0000000F2FB4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1540>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F2FB8: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000F2FBC: BF89FC07
	s_barrier                                                  // 0000000F2FC0: BFBD0000
	buffer_gl0_inv                                             // 0000000F2FC4: E0AC0000 00000000
	s_and_saveexec_b32 s14, s0                                 // 0000000F2FCC: BE8E2000
	s_cbranch_execz 118                                        // 0000000F2FD0: BFA50076 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17ac>
	v_or_b32_e32 v23, s9, v52                                  // 0000000F2FD4: 382E6809
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F2FD8: BF870001
	.long 0xd4440001                                           // 0000000F2FDC: D4440001
	v_cndmask_b32_e32 v1, s5, v23, vcc_lo                      // 0000000F2FE0: 02022E05
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000F2FE4: 8B7E017E
	s_cbranch_execz 112                                        // 0000000F2FE8: BFA50070 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17ac>
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v21, v48           // 0000000F2FEC: CA100080 18140130
	s_movk_i32 s1, 0xf600                                      // 0000000F2FF4: B001F600
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000F2FF8: BF8704A9
	v_add_nc_u32_e32 v22, s1, v42                              // 0000000F2FFC: 4A2C5401
	s_addk_i32 s1, 0x140                                       // 0000000F3000: B7810140
	s_cmp_lg_u32 s1, 0                                         // 0000000F3004: BF078001
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F3008: BF870001
	v_add_nc_u32_e32 v22, 0x2800, v22                          // 0000000F300C: 4A2C2CFF 00002800
	ds_load_2addr_b32 v[25:26], v21 offset1:1                  // 0000000F3014: D8DC0100 19000015
	ds_load_2addr_b32 v[27:28], v22 offset0:144 offset1:149    // 0000000F301C: D8DC9590 1B000016
	ds_load_2addr_b32 v[29:30], v21 offset0:2 offset1:3        // 0000000F3024: D8DC0302 1D000015
	ds_load_2addr_b32 v[31:32], v22 offset0:154 offset1:159    // 0000000F302C: D8DC9F9A 1F000016
	ds_load_2addr_b32 v[33:34], v21 offset0:4 offset1:5        // 0000000F3034: D8DC0504 21000015
	ds_load_2addr_b32 v[35:36], v21 offset0:6 offset1:7        // 0000000F303C: D8DC0706 23000015
	ds_load_2addr_b32 v[63:64], v22 offset0:164 offset1:169    // 0000000F3044: D8DCA9A4 3F000016
	s_waitcnt lgkmcnt(5)                                       // 0000000F304C: BF89FC57
	v_fmac_f32_e32 v24, v25, v27                               // 0000000F3050: 56303719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F3054: BF8700C1
	v_fmac_f32_e32 v24, v26, v28                               // 0000000F3058: 5630391A
	ds_load_2addr_b32 v[25:26], v22 offset0:174 offset1:179    // 0000000F305C: D8DCB3AE 19000016
	s_waitcnt lgkmcnt(4)                                       // 0000000F3064: BF89FC47
	v_fmac_f32_e32 v24, v29, v31                               // 0000000F3068: 56303F1D
	v_fmac_f32_e32 v24, v30, v32                               // 0000000F306C: 5630411E
	ds_load_2addr_b32 v[27:28], v21 offset0:8 offset1:9        // 0000000F3070: D8DC0908 1B000015
	ds_load_2addr_b32 v[29:30], v22 offset0:184 offset1:189    // 0000000F3078: D8DCBDB8 1D000016
	s_waitcnt lgkmcnt(3)                                       // 0000000F3080: BF89FC37
	v_fmac_f32_e32 v24, v33, v63                               // 0000000F3084: 56307F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F3088: BF8700D1
	v_fmac_f32_e32 v24, v34, v64                               // 0000000F308C: 56308122
	ds_load_2addr_b32 v[31:32], v21 offset0:10 offset1:11      // 0000000F3090: D8DC0B0A 1F000015
	ds_load_2addr_b32 v[33:34], v22 offset0:194 offset1:199    // 0000000F3098: D8DCC7C2 21000016
	s_waitcnt lgkmcnt(4)                                       // 0000000F30A0: BF89FC47
	v_fmac_f32_e32 v24, v35, v25                               // 0000000F30A4: 56303323
	v_fmac_f32_e32 v24, v36, v26                               // 0000000F30A8: 56303524
	ds_load_2addr_b32 v[25:26], v21 offset0:12 offset1:13      // 0000000F30AC: D8DC0D0C 19000015
	ds_load_2addr_b32 v[35:36], v21 offset0:14 offset1:15      // 0000000F30B4: D8DC0F0E 23000015
	ds_load_2addr_b32 v[63:64], v22 offset0:204 offset1:209    // 0000000F30BC: D8DCD1CC 3F000016
	v_add_nc_u32_e32 v21, 64, v21                              // 0000000F30C4: 4A2A2AC0
	s_waitcnt lgkmcnt(5)                                       // 0000000F30C8: BF89FC57
	v_fmac_f32_e32 v24, v27, v29                               // 0000000F30CC: 56303B1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F30D0: BF8700C1
	v_fmac_f32_e32 v24, v28, v30                               // 0000000F30D4: 56303D1C
	ds_load_2addr_b32 v[27:28], v22 offset0:214 offset1:219    // 0000000F30D8: D8DCDBD6 1B000016
	s_waitcnt lgkmcnt(4)                                       // 0000000F30E0: BF89FC47
	v_fmac_f32_e32 v24, v31, v33                               // 0000000F30E4: 5630431F
	v_fmac_f32_e32 v24, v32, v34                               // 0000000F30E8: 56304520
	s_waitcnt lgkmcnt(1)                                       // 0000000F30EC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F30F0: BF870091
	v_fmac_f32_e32 v24, v25, v63                               // 0000000F30F4: 56307F19
	v_fmac_f32_e32 v24, v26, v64                               // 0000000F30F8: 5630811A
	s_waitcnt lgkmcnt(0)                                       // 0000000F30FC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F3100: BF870091
	v_fmac_f32_e32 v24, v35, v27                               // 0000000F3104: 56303723
	v_fmac_f32_e32 v24, v36, v28                               // 0000000F3108: 56303924
	s_cbranch_scc1 65466                                       // 0000000F310C: BFA2FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15f8>
	ds_load_b32 v26, v50 offset:128                            // 0000000F3110: D8D80080 1A000032
	v_dual_mov_b32 v22, v10 :: v_dual_mov_b32 v21, v9          // 0000000F3118: CA10010A 16140109
	v_mov_b32_e32 v25, v42                                     // 0000000F3120: 7E32032A
	s_mov_b32 s15, 0                                           // 0000000F3124: BE8F0080
	s_waitcnt lgkmcnt(0)                                       // 0000000F3128: BF89FC07
	v_mul_f32_e32 v24, v24, v26                                // 0000000F312C: 10303518
	v_mov_b32_e32 v26, v60                                     // 0000000F3130: 7E34033C
	global_load_b32 v27, v[21:22], off                         // 0000000F3134: DC520000 1B7C0015
	ds_load_b32 v28, v25 offset:10816                          // 0000000F313C: D8D82A40 1C000019
	v_add_nc_u32_e32 v26, -1, v26                              // 0000000F3144: 4A3434C1
	.long 0xd7000115                                           // 0000000F3148: D7000115
	v_cndmask_b32_e32 v0, v21, v132, vcc_lo                    // 0000000F314C: 02010915
	v_add_nc_u32_e32 v25, 20, v25                              // 0000000F3150: 4A323294
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000F3154: D5207C16 00062C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000F315C: BF870004
	.long 0xd44a0004                                           // 0000000F3160: D44A0004
	v_cndmask_b32_e32 v1, 0, v26, vcc_lo                       // 0000000F3164: 02023480
	s_or_b32 s15, s4, s15                                      // 0000000F3168: 8C0F0F04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F316C: BF890007
	v_fmac_f32_e32 v24, v27, v28                               // 0000000F3170: 5630391B
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000000F3174: 917E0F7E
	s_cbranch_execnz 65518                                     // 0000000F3178: BFA6FFEE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1734>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000000F317C: 8C7E0F7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F3180: BF870121
	v_bfe_u32 v25, v24, 16, 1                                  // 0000000F3184: D6100019 02052118
	v_mad_u64_u32 v[21:22], null, 0x3000, v23, v[3:4]          // 0000000F318C: D6FE7C15 040E2EFF 00003000
	v_add3_u32 v23, v24, v25, 0x7fff                           // 0000000F3198: D6550017 03FE3318 00007FFF
	global_store_d16_hi_b16 v[21:22], v23, off                 // 0000000F31A4: DC960000 007C1715
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000F31AC: 8C7E0E7E
	v_mov_b32_e32 v21, v0                                      // 0000000F31B0: 7E2A0300
	s_mov_b32 s4, 0                                            // 0000000F31B4: BE840080
	s_waitcnt_vscnt null, 0x0                                  // 0000000F31B8: BC7C0000
	s_barrier                                                  // 0000000F31BC: BFBD0000
	buffer_gl0_inv                                             // 0000000F31C0: E0AC0000 00000000
	s_nop 0                                                    // 0000000F31C8: BF800000
	s_nop 0                                                    // 0000000F31CC: BF800000
	s_nop 0                                                    // 0000000F31D0: BF800000
	s_nop 0                                                    // 0000000F31D4: BF800000
	s_nop 0                                                    // 0000000F31D8: BF800000
	s_nop 0                                                    // 0000000F31DC: BF800000
	s_nop 0                                                    // 0000000F31E0: BF800000
	s_nop 0                                                    // 0000000F31E4: BF800000
	s_nop 0                                                    // 0000000F31E8: BF800000
	s_nop 0                                                    // 0000000F31EC: BF800000
	s_nop 0                                                    // 0000000F31F0: BF800000
	s_nop 0                                                    // 0000000F31F4: BF800000
	s_nop 0                                                    // 0000000F31F8: BF800000
	s_nop 0                                                    // 0000000F31FC: BF800000
	v_lshrrev_b32_e32 v24, 7, v21                              // 0000000F3200: 32302A87
	v_add_nc_u32_e32 v26, 0x80, v21                            // 0000000F3204: 4A342AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F320C: BF870092
	v_or_b32_e32 v22, s11, v24                                 // 0000000F3210: 382C300B
	v_mad_u64_u32 v[22:23], null, v22, 48, s[2:3]              // 0000000F3214: D6FE7C16 00096116
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F321C: BF870091
	.long 0xd73c0016                                           // 0000000F3220: D73C0016
	v_cndmask_b32_e32 v1, 9, v22, vcc_lo                       // 0000000F3224: 02022C89
	.long 0xd7000116                                           // 0000000F3228: D7000116
	v_cndmask_b32_e32 v1, v54, v22, vcc_lo                     // 0000000F322C: 02022D36
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F3230: BF870001
	v_add_co_ci_u32_e64 v23, null, v55, v23, s1                // 0000000F3234: D5207C17 00062F37
	.long 0xd4490001                                           // 0000000F323C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v21, vcc_lo                   // 0000000F3240: 02022AFF 0000077F
	v_mov_b32_e32 v21, v26                                     // 0000000F3248: 7E2A031A
	global_load_b32 v25, v[22:23], off                         // 0000000F324C: DC520000 197C0016
	v_mad_u64_u32 v[22:23], null, 0x204, v24, v[1:2]           // 0000000F3254: D6FE7C16 040630FF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000F3260: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000F3264: BF8903F7
	ds_store_b32 v22, v25                                      // 0000000F3268: D8340000 00001916
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000F3270: 917E047E
	s_cbranch_execnz 65506                                     // 0000000F3274: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1800>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F3278: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000F327C: BF89FC07
	s_barrier                                                  // 0000000F3280: BFBD0000
	buffer_gl0_inv                                             // 0000000F3284: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 0000000F328C: BE8B2000
	s_cbranch_execz 118                                        // 0000000F3290: BFA50076 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a6c>
	v_or_b32_e32 v23, s9, v53                                  // 0000000F3294: 382E6A09
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F3298: BF870001
	.long 0xd4440001                                           // 0000000F329C: D4440001
	v_cndmask_b32_e32 v1, s5, v23, vcc_lo                      // 0000000F32A0: 02022E05
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000F32A4: 8B7E017E
	s_cbranch_execz 112                                        // 0000000F32A8: BFA50070 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a6c>
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v21, v48           // 0000000F32AC: CA100080 18140130
	s_movk_i32 s1, 0xf600                                      // 0000000F32B4: B001F600
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000F32B8: BF8704A9
	v_add_nc_u32_e32 v22, s1, v42                              // 0000000F32BC: 4A2C5401
	s_addk_i32 s1, 0x140                                       // 0000000F32C0: B7810140
	s_cmp_lg_u32 s1, 0                                         // 0000000F32C4: BF078001
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F32C8: BF870001
	v_add_nc_u32_e32 v22, 0x2800, v22                          // 0000000F32CC: 4A2C2CFF 00002800
	ds_load_2addr_b32 v[25:26], v21 offset1:1                  // 0000000F32D4: D8DC0100 19000015
	ds_load_2addr_b32 v[27:28], v22 offset0:144 offset1:149    // 0000000F32DC: D8DC9590 1B000016
	ds_load_2addr_b32 v[29:30], v21 offset0:2 offset1:3        // 0000000F32E4: D8DC0302 1D000015
	ds_load_2addr_b32 v[31:32], v22 offset0:154 offset1:159    // 0000000F32EC: D8DC9F9A 1F000016
	ds_load_2addr_b32 v[33:34], v21 offset0:4 offset1:5        // 0000000F32F4: D8DC0504 21000015
	ds_load_2addr_b32 v[35:36], v21 offset0:6 offset1:7        // 0000000F32FC: D8DC0706 23000015
	ds_load_2addr_b32 v[63:64], v22 offset0:164 offset1:169    // 0000000F3304: D8DCA9A4 3F000016
	s_waitcnt lgkmcnt(5)                                       // 0000000F330C: BF89FC57
	v_fmac_f32_e32 v24, v25, v27                               // 0000000F3310: 56303719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F3314: BF8700C1
	v_fmac_f32_e32 v24, v26, v28                               // 0000000F3318: 5630391A
	ds_load_2addr_b32 v[25:26], v22 offset0:174 offset1:179    // 0000000F331C: D8DCB3AE 19000016
	s_waitcnt lgkmcnt(4)                                       // 0000000F3324: BF89FC47
	v_fmac_f32_e32 v24, v29, v31                               // 0000000F3328: 56303F1D
	v_fmac_f32_e32 v24, v30, v32                               // 0000000F332C: 5630411E
	ds_load_2addr_b32 v[27:28], v21 offset0:8 offset1:9        // 0000000F3330: D8DC0908 1B000015
	ds_load_2addr_b32 v[29:30], v22 offset0:184 offset1:189    // 0000000F3338: D8DCBDB8 1D000016
	s_waitcnt lgkmcnt(3)                                       // 0000000F3340: BF89FC37
	v_fmac_f32_e32 v24, v33, v63                               // 0000000F3344: 56307F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F3348: BF8700D1
	v_fmac_f32_e32 v24, v34, v64                               // 0000000F334C: 56308122
	ds_load_2addr_b32 v[31:32], v21 offset0:10 offset1:11      // 0000000F3350: D8DC0B0A 1F000015
	ds_load_2addr_b32 v[33:34], v22 offset0:194 offset1:199    // 0000000F3358: D8DCC7C2 21000016
	s_waitcnt lgkmcnt(4)                                       // 0000000F3360: BF89FC47
	v_fmac_f32_e32 v24, v35, v25                               // 0000000F3364: 56303323
	v_fmac_f32_e32 v24, v36, v26                               // 0000000F3368: 56303524
	ds_load_2addr_b32 v[25:26], v21 offset0:12 offset1:13      // 0000000F336C: D8DC0D0C 19000015
	ds_load_2addr_b32 v[35:36], v21 offset0:14 offset1:15      // 0000000F3374: D8DC0F0E 23000015
	ds_load_2addr_b32 v[63:64], v22 offset0:204 offset1:209    // 0000000F337C: D8DCD1CC 3F000016
	v_add_nc_u32_e32 v21, 64, v21                              // 0000000F3384: 4A2A2AC0
	s_waitcnt lgkmcnt(5)                                       // 0000000F3388: BF89FC57
	v_fmac_f32_e32 v24, v27, v29                               // 0000000F338C: 56303B1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F3390: BF8700C1
	v_fmac_f32_e32 v24, v28, v30                               // 0000000F3394: 56303D1C
	ds_load_2addr_b32 v[27:28], v22 offset0:214 offset1:219    // 0000000F3398: D8DCDBD6 1B000016
	s_waitcnt lgkmcnt(4)                                       // 0000000F33A0: BF89FC47
	v_fmac_f32_e32 v24, v31, v33                               // 0000000F33A4: 5630431F
	v_fmac_f32_e32 v24, v32, v34                               // 0000000F33A8: 56304520
	s_waitcnt lgkmcnt(1)                                       // 0000000F33AC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F33B0: BF870091
	v_fmac_f32_e32 v24, v25, v63                               // 0000000F33B4: 56307F19
	v_fmac_f32_e32 v24, v26, v64                               // 0000000F33B8: 5630811A
	s_waitcnt lgkmcnt(0)                                       // 0000000F33BC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F33C0: BF870091
	v_fmac_f32_e32 v24, v35, v27                               // 0000000F33C4: 56303723
	v_fmac_f32_e32 v24, v36, v28                               // 0000000F33C8: 56303924
	s_cbranch_scc1 65466                                       // 0000000F33CC: BFA2FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18b8>
	ds_load_b32 v26, v50 offset:192                            // 0000000F33D0: D8D800C0 1A000032
	v_dual_mov_b32 v22, v12 :: v_dual_mov_b32 v21, v11         // 0000000F33D8: CA10010C 1614010B
	v_mov_b32_e32 v25, v42                                     // 0000000F33E0: 7E32032A
	s_mov_b32 s14, 0                                           // 0000000F33E4: BE8E0080
	s_waitcnt lgkmcnt(0)                                       // 0000000F33E8: BF89FC07
	v_mul_f32_e32 v24, v24, v26                                // 0000000F33EC: 10303518
	v_mov_b32_e32 v26, v61                                     // 0000000F33F0: 7E34033D
	global_load_b32 v27, v[21:22], off                         // 0000000F33F4: DC520000 1B7C0015
	ds_load_b32 v28, v25 offset:10816                          // 0000000F33FC: D8D82A40 1C000019
	v_add_nc_u32_e32 v26, -1, v26                              // 0000000F3404: 4A3434C1
	.long 0xd7000115                                           // 0000000F3408: D7000115
	v_cndmask_b32_e32 v0, v21, v132, vcc_lo                    // 0000000F340C: 02010915
	v_add_nc_u32_e32 v25, 20, v25                              // 0000000F3410: 4A323294
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000F3414: D5207C16 00062C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000F341C: BF870004
	.long 0xd44a0004                                           // 0000000F3420: D44A0004
	v_cndmask_b32_e32 v1, 0, v26, vcc_lo                       // 0000000F3424: 02023480
	s_or_b32 s14, s4, s14                                      // 0000000F3428: 8C0E0E04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F342C: BF890007
	v_fmac_f32_e32 v24, v27, v28                               // 0000000F3430: 5630391B
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000F3434: 917E0E7E
	s_cbranch_execnz 65518                                     // 0000000F3438: BFA6FFEE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19f4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000F343C: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F3440: BF870121
	v_bfe_u32 v25, v24, 16, 1                                  // 0000000F3444: D6100019 02052118
	v_mad_u64_u32 v[21:22], null, 0x3000, v23, v[3:4]          // 0000000F344C: D6FE7C15 040E2EFF 00003000
	v_add3_u32 v23, v24, v25, 0x7fff                           // 0000000F3458: D6550017 03FE3318 00007FFF
	global_store_d16_hi_b16 v[21:22], v23, off                 // 0000000F3464: DC960000 007C1715
	s_or_b32 exec_lo, exec_lo, s11                             // 0000000F346C: 8C7E0B7E
	s_waitcnt_vscnt null, 0x0                                  // 0000000F3470: BC7C0000
	s_barrier                                                  // 0000000F3474: BFBD0000
	buffer_gl0_inv                                             // 0000000F3478: E0AC0000 00000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000F3480: BE84206A
	s_cbranch_execz 65                                         // 0000000F3484: BFA50041 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b8c>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000F3488: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v22, v0                                      // 0000000F3490: 7E2C0300
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000F3494: BF8704CA
	s_xor_b32 s11, s1, 0x80000000                              // 0000000F3498: 8D0BFF01 80000000
	s_rndne_f32 s14, s1                                        // 0000000F34A0: BE8E6301
	s_fmamk_f32 s11, s10, 0x3fb8aa3b, s11                      // 0000000F34A4: A30B0B0A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000F34AC: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s14                                      // 0000000F34B4: A0810E01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000F34B8: BF870599
	s_fmamk_f32 s11, s10, 0x32a5705f, s11                      // 0000000F34BC: A30B0B0A 32A5705F
	s_add_f32 s1, s1, s11                                      // 0000000F34C4: A0010B01
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000000F34C8: BF87000B
	v_exp_f32_e32 v21, s1                                      // 0000000F34CC: 7E2A4A01
	s_cvt_i32_f32 s1, s14                                      // 0000000F34D0: BE81660E
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000F34D4: BF870585
	.long 0xd71c0015                                           // 0000000F34D8: D71C0015
	v_cndmask_b32_e32 v0, v21, v1, vcc_lo                      // 0000000F34DC: 02000315
	s_cselect_b32 s1, -1, 0                                    // 0000000F34E0: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000F34E4: BF4BFF0A 42B17218
	s_mov_b32 s10, 0                                           // 0000000F34EC: BE8A0080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F34F0: BF870001
	v_cndmask_b32_e64 v21, 0, v21, s1                          // 0000000F34F4: D5010015 00062A80
	s_cselect_b32 s1, -1, 0                                    // 0000000F34FC: 980180C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000F3500: BF870481
	v_cndmask_b32_e64 v21, 0x7f800000, v21, s1                 // 0000000F3504: D5010015 00062AFF 7F800000
	s_nop 0                                                    // 0000000F3510: BF800000
	s_nop 0                                                    // 0000000F3514: BF800000
	s_nop 0                                                    // 0000000F3518: BF800000
	s_nop 0                                                    // 0000000F351C: BF800000
	s_nop 0                                                    // 0000000F3520: BF800000
	s_nop 0                                                    // 0000000F3524: BF800000
	s_nop 0                                                    // 0000000F3528: BF800000
	s_nop 0                                                    // 0000000F352C: BF800000
	s_nop 0                                                    // 0000000F3530: BF800000
	s_nop 0                                                    // 0000000F3534: BF800000
	s_nop 0                                                    // 0000000F3538: BF800000
	s_nop 0                                                    // 0000000F353C: BF800000
	v_lshrrev_b32_e32 v23, 2, v22                              // 0000000F3540: 322E2C82
	.long 0xd4490001                                           // 0000000F3544: D4490001
	v_cndmask_b32_e32 v1, 0x17f, v22, vcc_lo                   // 0000000F3548: 02022CFF 0000017F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F3550: BF8700D2
	v_mad_u64_u32 v[23:24], null, v23, 20, v[2:3]              // 0000000F3554: D6FE7C17 04092917
	s_or_b32 s10, s1, s10                                      // 0000000F355C: 8C0A0A01
	ds_load_b32 v24, v23                                       // 0000000F3560: D8D80000 18000017
	s_waitcnt lgkmcnt(0)                                       // 0000000F3568: BF89FC07
	v_dual_mul_f32 v24, v21, v24 :: v_dual_add_nc_u32 v25, 0x80, v22// 0000000F356C: C8E03115 18182CFF 00000080
	v_mov_b32_e32 v22, v25                                     // 0000000F3578: 7E2C0319
	ds_store_b32 v23, v24                                      // 0000000F357C: D8340000 00001817
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000F3584: 917E0A7E
	s_cbranch_execnz 65517                                     // 0000000F3588: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b40>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F358C: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000F3590: BF89FC07
	s_barrier                                                  // 0000000F3594: BFBD0000
	buffer_gl0_inv                                             // 0000000F3598: E0AC0000 00000000
	s_and_saveexec_b32 s10, s7                                 // 0000000F35A0: BE8A2007
	s_cbranch_execz 30                                         // 0000000F35A4: BFA5001E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c20>
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, v14           // 0000000F35A8: CA100080 1716010E
	v_dual_mov_b32 v21, v13 :: v_dual_mov_b32 v24, 0           // 0000000F35B0: CA10010D 15180080
	v_mov_b32_e32 v25, v1                                      // 0000000F35B8: 7E320301
	s_mov_b32 s11, 0                                           // 0000000F35BC: BE8B0080
	global_load_b32 v26, v[21:22], off                         // 0000000F35C0: DC520000 1A7C0015
	ds_load_b32 v27, v24 offset:12096                          // 0000000F35C8: D8D82F40 1B000018
	v_add_nc_u32_e32 v23, -1, v23                              // 0000000F35D0: 4A2E2EC1
	.long 0xd7000115                                           // 0000000F35D4: D7000115
	v_cndmask_b32_e32 v1, 0x6000, v21, vcc_lo                  // 0000000F35D8: 02022AFF 00006000
	v_add_nc_u32_e32 v24, 4, v24                               // 0000000F35E0: 4A303084
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000F35E4: D5207C16 00062C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000F35EC: BF870004
	.long 0xd44a0004                                           // 0000000F35F0: D44A0004
	v_cndmask_b32_e32 v1, 0, v23, vcc_lo                       // 0000000F35F4: 02022E80
	s_or_b32 s11, s4, s11                                      // 0000000F35F8: 8C0B0B04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F35FC: BF890007
	v_mul_f32_e32 v26, v26, v27                                // 0000000F3600: 1034371A
	ds_store_b32 v25, v26                                      // 0000000F3604: D8340000 00001A19
	v_add_nc_u32_e32 v25, 0x204, v25                           // 0000000F360C: 4A3232FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000F3614: 917E0B7E
	s_cbranch_execnz 65513                                     // 0000000F3618: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1bc0>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000000F361C: 8C7E0B7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F3620: BF870009
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000F3624: 8C7E0A7E
	v_mov_b32_e32 v21, v0                                      // 0000000F3628: 7E2A0300
	s_mov_b32 s4, 0                                            // 0000000F362C: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000F3630: BF870241
	v_add_nc_u32_e32 v22, 0x80, v21                            // 0000000F3634: 4A2C2AFF 00000080
	v_add_nc_u32_e32 v23, 0x100, v21                           // 0000000F363C: 4A2E2AFF 00000100
	v_lshrrev_b32_e32 v30, 7, v21                              // 0000000F3644: 323C2A87
	v_add_nc_u32_e32 v24, 0x180, v21                           // 0000000F3648: 4A302AFF 00000180
	v_lshrrev_b32_e32 v31, 7, v22                              // 0000000F3650: 323E2C87
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000F3654: BF870214
	v_lshrrev_b32_e32 v32, 7, v23                              // 0000000F3658: 32402E87
	v_or_b32_e32 v22, s9, v30                                  // 0000000F365C: 382C3C09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000F3660: BF870214
	v_lshrrev_b32_e32 v33, 7, v24                              // 0000000F3664: 32423087
	v_or_b32_e32 v24, s9, v31                                  // 0000000F3668: 38303E09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000F366C: BF870214
	v_or_b32_e32 v26, s9, v32                                  // 0000000F3670: 38344009
	v_mad_u64_u32 v[22:23], null, v22, 48, s[2:3]              // 0000000F3674: D6FE7C16 00096116
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000F367C: BF870214
	v_or_b32_e32 v28, s9, v33                                  // 0000000F3680: 38384209
	v_mad_u64_u32 v[24:25], null, v24, 48, s[2:3]              // 0000000F3684: D6FE7C18 00096118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F368C: BF870194
	v_mad_u64_u32 v[26:27], null, v26, 48, s[2:3]              // 0000000F3690: D6FE7C1A 0009611A
	v_mad_u64_u32 v[28:29], null, v28, 48, s[2:3]              // 0000000F3698: D6FE7C1C 0009611C
	.long 0xd73c0016                                           // 0000000F36A0: D73C0016
	v_cndmask_b32_e32 v1, 9, v22, vcc_lo                       // 0000000F36A4: 02022C89
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000F36A8: BF870214
	.long 0xd73c0018                                           // 0000000F36AC: D73C0018
	v_cndmask_b32_e32 v1, 9, v24, vcc_lo                       // 0000000F36B0: 02023089
	.long 0xd73c001a                                           // 0000000F36B4: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 0000000F36B8: 02023489
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000F36BC: BF870214
	.long 0xd73c001c                                           // 0000000F36C0: D73C001C
	v_cndmask_b32_e32 v1, 9, v28, vcc_lo                       // 0000000F36C4: 02023889
	.long 0xd7000116                                           // 0000000F36C8: D7000116
	v_cndmask_b32_e32 v1, v56, v22, vcc_lo                     // 0000000F36CC: 02022D38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F36D0: BF8700A1
	v_add_co_ci_u32_e64 v23, null, v57, v23, s1                // 0000000F36D4: D5207C17 00062F39
	.long 0xd7000118                                           // 0000000F36DC: D7000118
	v_cndmask_b32_e32 v1, v56, v24, vcc_lo                     // 0000000F36E0: 02023138
	v_add_co_ci_u32_e64 v25, null, v57, v25, s1                // 0000000F36E4: D5207C19 00063339
	.long 0xd700011a                                           // 0000000F36EC: D700011A
	v_cndmask_b32_e32 v1, v56, v26, vcc_lo                     // 0000000F36F0: 02023538
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F36F4: BF8700A1
	v_add_co_ci_u32_e64 v27, null, v57, v27, s1                // 0000000F36F8: D5207C1B 00063739
	.long 0xd700011c                                           // 0000000F3700: D700011C
	v_cndmask_b32_e32 v1, v56, v28, vcc_lo                     // 0000000F3704: 02023938
	v_add_co_ci_u32_e64 v29, null, v57, v29, s1                // 0000000F3708: D5207C1D 00063B39
	s_clause 0x3                                               // 0000000F3710: BF850003
	global_load_b32 v34, v[22:23], off                         // 0000000F3714: DC520000 227C0016
	global_load_b32 v35, v[24:25], off                         // 0000000F371C: DC520000 237C0018
	global_load_b32 v27, v[26:27], off                         // 0000000F3724: DC520000 1B7C001A
	global_load_b32 v28, v[28:29], off                         // 0000000F372C: DC520000 1C7C001C
	v_lshlrev_b32_e32 v22, 2, v30                              // 0000000F3734: 302C3C82
	v_lshlrev_b32_e32 v23, 2, v31                              // 0000000F3738: 302E3E82
	v_lshlrev_b32_e32 v24, 2, v32                              // 0000000F373C: 30304082
	v_lshlrev_b32_e32 v25, 2, v33                              // 0000000F3740: 30324282
	ds_load_b32 v29, v22 offset:12096                          // 0000000F3744: D8D82F40 1D000016
	ds_load_b32 v36, v23 offset:12096                          // 0000000F374C: D8D82F40 24000017
	ds_load_b32 v63, v24 offset:12096                          // 0000000F3754: D8D82F40 3F000018
	ds_load_b32 v64, v25 offset:12096                          // 0000000F375C: D8D82F40 40000019
	v_mad_u64_u32 v[22:23], null, 0x204, v30, v[1:2]           // 0000000F3764: D6FE7C16 04063CFF 00000204
	v_mad_u64_u32 v[23:24], null, 0x204, v31, v[1:2]           // 0000000F3770: D6FE7C17 04063EFF 00000204
	.long 0xd4490001                                           // 0000000F377C: D4490001
	v_cndmask_b32_e32 v1, 0x5ff, v21, vcc_lo                   // 0000000F3780: 02022AFF 000005FF
	v_mad_u64_u32 v[24:25], null, 0x204, v32, v[1:2]           // 0000000F3788: D6FE7C18 040640FF 00000204
	v_mad_u64_u32 v[25:26], null, 0x204, v33, v[1:2]           // 0000000F3794: D6FE7C19 040642FF 00000204
	v_add_nc_u32_e32 v21, 0x200, v21                           // 0000000F37A0: 4A2A2AFF 00000200
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000F37A8: BF870004
	s_or_b32 s4, s1, s4                                        // 0000000F37AC: 8C040401
	s_waitcnt vmcnt(2) lgkmcnt(2)                              // 0000000F37B0: BF890827
	v_dual_mul_f32 v26, v34, v29 :: v_dual_mul_f32 v29, v35, v36// 0000000F37B4: C8C63B22 1A1C4923
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F37BC: BF890007
	v_dual_mul_f32 v27, v27, v63 :: v_dual_mul_f32 v28, v28, v64// 0000000F37C0: C8C67F1B 1B1C811C
	ds_store_b32 v22, v26                                      // 0000000F37C8: D8340000 00001A16
	ds_store_b32 v23, v29                                      // 0000000F37D0: D8340000 00001D17
	ds_store_b32 v24, v27                                      // 0000000F37D8: D8340000 00001B18
	ds_store_b32 v25, v28                                      // 0000000F37E0: D8340000 00001C19
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000F37E8: 917E047E
	s_cbranch_execnz 65424                                     // 0000000F37EC: BFA6FF90 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c30>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F37F0: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000F37F4: BF89FC07
	s_barrier                                                  // 0000000F37F8: BFBD0000
	buffer_gl0_inv                                             // 0000000F37FC: E0AC0000 00000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000F3804: BE84206A
	s_cbranch_execz 95                                         // 0000000F3808: BFA5005F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f88>
	ds_load_2addr_b32 v[21:22], v47 offset1:5                  // 0000000F380C: D8DC0500 1500002F
	ds_load_2addr_b32 v[23:24], v47 offset0:10 offset1:15      // 0000000F3814: D8DC0F0A 1700002F
	ds_load_2addr_b32 v[25:26], v47 offset0:20 offset1:25      // 0000000F381C: D8DC1914 1900002F
	ds_load_2addr_b32 v[27:28], v47 offset0:30 offset1:35      // 0000000F3824: D8DC231E 1B00002F
	ds_load_2addr_b32 v[29:30], v47 offset0:40 offset1:45      // 0000000F382C: D8DC2D28 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:50 offset1:55      // 0000000F3834: D8DC3732 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:60 offset1:65      // 0000000F383C: D8DC413C 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:70 offset1:75      // 0000000F3844: D8DC4B46 2300002F
	v_mov_b32_e32 v63, v0                                      // 0000000F384C: 7E7E0300
	s_mov_b32 s9, 0                                            // 0000000F3850: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000F3854: BF8701B1
	v_lshrrev_b32_e32 v64, 2, v63                              // 0000000F3858: 32807E82
	v_and_b32_e32 v71, -4, v63                                 // 0000000F385C: 368E7EC4
	.long 0xd4490001                                           // 0000000F3860: D4490001
	v_cndmask_b32_e32 v1, 0x17f, v63, vcc_lo                   // 0000000F3864: 02027EFF 0000017F
	v_mad_u64_u32 v[64:65], null, v64, 20, v[2:3]              // 0000000F386C: D6FE7C40 04092940
	ds_load_2addr_b32 v[65:66], v71 offset1:129                // 0000000F3874: D8DC8100 41000047
	ds_load_b32 v72, v64                                       // 0000000F387C: D8D80000 48000040
	s_or_b32 s9, s1, s9                                        // 0000000F3884: 8C090901
	s_waitcnt lgkmcnt(0)                                       // 0000000F3888: BF89FC07
	v_dual_fmac_f32 v72, v65, v21 :: v_dual_add_nc_u32 v67, 0x400, v71// 0000000F388C: C8202B41 48428EFF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F3898: BF8700C1
	v_fmac_f32_e32 v72, v66, v22                               // 0000000F389C: 56902D42
	ds_load_2addr_b32 v[67:68], v67 offset0:2 offset1:131      // 0000000F38A0: D8DC8302 43000043
	s_waitcnt lgkmcnt(0)                                       // 0000000F38A8: BF89FC07
	v_fmac_f32_e32 v72, v67, v23                               // 0000000F38AC: 56902F43
	v_dual_fmac_f32 v72, v68, v24 :: v_dual_add_nc_u32 v69, 0x800, v71// 0000000F38B0: C8203144 48448EFF 00000800
	ds_load_2addr_b32 v[69:70], v69 offset0:4 offset1:133      // 0000000F38BC: D8DC8504 45000045
	s_waitcnt lgkmcnt(0)                                       // 0000000F38C4: BF89FC07
	v_dual_fmac_f32 v72, v69, v25 :: v_dual_add_nc_u32 v65, 0xc00, v71// 0000000F38C8: C8203345 48408EFF 00000C00
	ds_load_2addr_b32 v[65:66], v65 offset0:6 offset1:135      // 0000000F38D4: D8DC8706 41000041
	v_dual_fmac_f32 v72, v70, v26 :: v_dual_add_nc_u32 v67, 0x1000, v71// 0000000F38DC: C8203546 48428EFF 00001000
	ds_load_2addr_b32 v[67:68], v67 offset0:8 offset1:137      // 0000000F38E8: D8DC8908 43000043
	s_waitcnt lgkmcnt(1)                                       // 0000000F38F0: BF89FC17
	v_fmac_f32_e32 v72, v65, v27                               // 0000000F38F4: 56903741
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F38F8: BF870001
	v_dual_fmac_f32 v72, v66, v28 :: v_dual_add_nc_u32 v69, 0x1400, v71// 0000000F38FC: C8203942 48448EFF 00001400
	ds_load_2addr_b32 v[69:70], v69 offset0:10 offset1:139     // 0000000F3908: D8DC8B0A 45000045
	s_waitcnt lgkmcnt(1)                                       // 0000000F3910: BF89FC17
	v_dual_fmac_f32 v72, v67, v29 :: v_dual_add_nc_u32 v65, 0x1800, v71// 0000000F3914: C8203B43 48408EFF 00001800
	v_add_nc_u32_e32 v67, 0x1c00, v71                          // 0000000F3920: 4A868EFF 00001C00
	ds_load_2addr_b32 v[65:66], v65 offset0:12 offset1:141     // 0000000F3928: D8DC8D0C 41000041
	v_fmac_f32_e32 v72, v68, v30                               // 0000000F3930: 56903D44
	ds_load_2addr_b32 v[67:68], v67 offset0:14 offset1:143     // 0000000F3934: D8DC8F0E 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000F393C: BF89FC27
	v_fmac_f32_e32 v72, v69, v31                               // 0000000F3940: 56903F45
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F3944: BF8700A1
	v_fmac_f32_e32 v72, v70, v32                               // 0000000F3948: 56904146
	s_waitcnt lgkmcnt(1)                                       // 0000000F394C: BF89FC17
	v_dual_fmac_f32 v72, v65, v33 :: v_dual_add_nc_u32 v65, 0x80, v63// 0000000F3950: C8204341 48407EFF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F395C: BF8700A1
	v_dual_fmac_f32 v72, v66, v34 :: v_dual_mov_b32 v63, v65   // 0000000F3960: C8104542 483E0141
	s_waitcnt lgkmcnt(0)                                       // 0000000F3968: BF89FC07
	v_fmac_f32_e32 v72, v67, v35                               // 0000000F396C: 56904743
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F3970: BF870001
	v_fmac_f32_e32 v72, v68, v36                               // 0000000F3974: 56904944
	ds_store_b32 v64, v72                                      // 0000000F3978: D8340000 00004840
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000F3980: 917E097E
	s_cbranch_execnz 65459                                     // 0000000F3984: BFA6FFB3 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e54>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F3988: 8C7E047E
	v_dual_mov_b32 v22, v16 :: v_dual_mov_b32 v21, v15         // 0000000F398C: CA100110 1614010F
	v_dual_mov_b32 v23, v1 :: v_dual_mov_b32 v24, 0            // 0000000F3994: CA100101 17180080
	v_mov_b32_e32 v25, v62                                     // 0000000F399C: 7E32033E
	s_mov_b32 s9, 0                                            // 0000000F39A0: BE890080
	s_waitcnt lgkmcnt(0)                                       // 0000000F39A4: BF89FC07
	s_barrier                                                  // 0000000F39A8: BFBD0000
	buffer_gl0_inv                                             // 0000000F39AC: E0AC0000 00000000
	s_nop 0                                                    // 0000000F39B4: BF800000
	s_nop 0                                                    // 0000000F39B8: BF800000
	s_nop 0                                                    // 0000000F39BC: BF800000
	global_load_b32 v26, v[21:22], off                         // 0000000F39C0: DC520000 1A7C0015
	ds_load_b32 v27, v24 offset:12160                          // 0000000F39C8: D8D82F80 1B000018
	v_add_nc_u32_e32 v25, 0x80, v25                            // 0000000F39D0: 4A3232FF 00000080
	.long 0xd7000115                                           // 0000000F39D8: D7000115
	v_cndmask_b32_e32 v1, 0x6000, v21, vcc_lo                  // 0000000F39DC: 02022AFF 00006000
	v_add_nc_u32_e32 v24, 4, v24                               // 0000000F39E4: 4A303084
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000F39E8: D5207C16 00062C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F39F0: BF890007
	v_mul_f32_e32 v26, v26, v27                                // 0000000F39F4: 1034371A
	.long 0xd4490004                                           // 0000000F39F8: D4490004
	v_cndmask_b32_e32 v1, 0x77f, v25, vcc_lo                   // 0000000F39FC: 020232FF 0000077F
	ds_store_b32 v23, v26                                      // 0000000F3A04: D8340000 00001A17
	v_add_nc_u32_e32 v23, 0x204, v23                           // 0000000F3A0C: 4A2E2EFF 00000204
	s_or_b32 s9, s4, s9                                        // 0000000F3A14: 8C090904
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F3A18: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000F3A1C: 917E097E
	s_cbranch_execnz 65511                                     // 0000000F3A20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fc0>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000F3A24: 8C7E097E
	s_waitcnt lgkmcnt(0)                                       // 0000000F3A28: BF89FC07
	s_barrier                                                  // 0000000F3A2C: BFBD0000
	buffer_gl0_inv                                             // 0000000F3A30: E0AC0000 00000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000F3A38: BE84206A
	s_cbranch_execz 95                                         // 0000000F3A3C: BFA5005F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x21bc>
	ds_load_2addr_b32 v[21:22], v47 offset0:80 offset1:85      // 0000000F3A40: D8DC5550 1500002F
	ds_load_2addr_b32 v[23:24], v47 offset0:90 offset1:95      // 0000000F3A48: D8DC5F5A 1700002F
	ds_load_2addr_b32 v[25:26], v47 offset0:100 offset1:105    // 0000000F3A50: D8DC6964 1900002F
	ds_load_2addr_b32 v[27:28], v47 offset0:110 offset1:115    // 0000000F3A58: D8DC736E 1B00002F
	ds_load_2addr_b32 v[29:30], v47 offset0:120 offset1:125    // 0000000F3A60: D8DC7D78 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:130 offset1:135    // 0000000F3A68: D8DC8782 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:140 offset1:145    // 0000000F3A70: D8DC918C 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:150 offset1:155    // 0000000F3A78: D8DC9B96 2300002F
	v_mov_b32_e32 v63, v0                                      // 0000000F3A80: 7E7E0300
	s_mov_b32 s9, 0                                            // 0000000F3A84: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000F3A88: BF8701B1
	v_lshrrev_b32_e32 v64, 2, v63                              // 0000000F3A8C: 32807E82
	v_and_b32_e32 v71, -4, v63                                 // 0000000F3A90: 368E7EC4
	.long 0xd4490001                                           // 0000000F3A94: D4490001
	v_cndmask_b32_e32 v1, 0x17f, v63, vcc_lo                   // 0000000F3A98: 02027EFF 0000017F
	v_mad_u64_u32 v[64:65], null, v64, 20, v[2:3]              // 0000000F3AA0: D6FE7C40 04092940
	ds_load_2addr_b32 v[65:66], v71 offset1:129                // 0000000F3AA8: D8DC8100 41000047
	ds_load_b32 v72, v64                                       // 0000000F3AB0: D8D80000 48000040
	s_or_b32 s9, s1, s9                                        // 0000000F3AB8: 8C090901
	s_waitcnt lgkmcnt(0)                                       // 0000000F3ABC: BF89FC07
	v_dual_fmac_f32 v72, v65, v21 :: v_dual_add_nc_u32 v67, 0x400, v71// 0000000F3AC0: C8202B41 48428EFF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F3ACC: BF8700C1
	v_fmac_f32_e32 v72, v66, v22                               // 0000000F3AD0: 56902D42
	ds_load_2addr_b32 v[67:68], v67 offset0:2 offset1:131      // 0000000F3AD4: D8DC8302 43000043
	s_waitcnt lgkmcnt(0)                                       // 0000000F3ADC: BF89FC07
	v_fmac_f32_e32 v72, v67, v23                               // 0000000F3AE0: 56902F43
	v_dual_fmac_f32 v72, v68, v24 :: v_dual_add_nc_u32 v69, 0x800, v71// 0000000F3AE4: C8203144 48448EFF 00000800
	ds_load_2addr_b32 v[69:70], v69 offset0:4 offset1:133      // 0000000F3AF0: D8DC8504 45000045
	s_waitcnt lgkmcnt(0)                                       // 0000000F3AF8: BF89FC07
	v_dual_fmac_f32 v72, v69, v25 :: v_dual_add_nc_u32 v65, 0xc00, v71// 0000000F3AFC: C8203345 48408EFF 00000C00
	ds_load_2addr_b32 v[65:66], v65 offset0:6 offset1:135      // 0000000F3B08: D8DC8706 41000041
	v_dual_fmac_f32 v72, v70, v26 :: v_dual_add_nc_u32 v67, 0x1000, v71// 0000000F3B10: C8203546 48428EFF 00001000
	ds_load_2addr_b32 v[67:68], v67 offset0:8 offset1:137      // 0000000F3B1C: D8DC8908 43000043
	s_waitcnt lgkmcnt(1)                                       // 0000000F3B24: BF89FC17
	v_fmac_f32_e32 v72, v65, v27                               // 0000000F3B28: 56903741
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F3B2C: BF870001
	v_dual_fmac_f32 v72, v66, v28 :: v_dual_add_nc_u32 v69, 0x1400, v71// 0000000F3B30: C8203942 48448EFF 00001400
	ds_load_2addr_b32 v[69:70], v69 offset0:10 offset1:139     // 0000000F3B3C: D8DC8B0A 45000045
	s_waitcnt lgkmcnt(1)                                       // 0000000F3B44: BF89FC17
	v_dual_fmac_f32 v72, v67, v29 :: v_dual_add_nc_u32 v65, 0x1800, v71// 0000000F3B48: C8203B43 48408EFF 00001800
	v_add_nc_u32_e32 v67, 0x1c00, v71                          // 0000000F3B54: 4A868EFF 00001C00
	ds_load_2addr_b32 v[65:66], v65 offset0:12 offset1:141     // 0000000F3B5C: D8DC8D0C 41000041
	v_fmac_f32_e32 v72, v68, v30                               // 0000000F3B64: 56903D44
	ds_load_2addr_b32 v[67:68], v67 offset0:14 offset1:143     // 0000000F3B68: D8DC8F0E 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000F3B70: BF89FC27
	v_fmac_f32_e32 v72, v69, v31                               // 0000000F3B74: 56903F45
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F3B78: BF8700A1
	v_fmac_f32_e32 v72, v70, v32                               // 0000000F3B7C: 56904146
	s_waitcnt lgkmcnt(1)                                       // 0000000F3B80: BF89FC17
	v_dual_fmac_f32 v72, v65, v33 :: v_dual_add_nc_u32 v65, 0x80, v63// 0000000F3B84: C8204341 48407EFF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F3B90: BF8700A1
	v_dual_fmac_f32 v72, v66, v34 :: v_dual_mov_b32 v63, v65   // 0000000F3B94: C8104542 483E0141
	s_waitcnt lgkmcnt(0)                                       // 0000000F3B9C: BF89FC07
	v_fmac_f32_e32 v72, v67, v35                               // 0000000F3BA0: 56904743
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F3BA4: BF870001
	v_fmac_f32_e32 v72, v68, v36                               // 0000000F3BA8: 56904944
	ds_store_b32 v64, v72                                      // 0000000F3BAC: D8340000 00004840
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000F3BB4: 917E097E
	s_cbranch_execnz 65459                                     // 0000000F3BB8: BFA6FFB3 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2088>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F3BBC: 8C7E047E
	v_dual_mov_b32 v22, v18 :: v_dual_mov_b32 v21, v17         // 0000000F3BC0: CA100112 16140111
	v_dual_mov_b32 v23, v1 :: v_dual_mov_b32 v24, 0            // 0000000F3BC8: CA100101 17180080
	v_mov_b32_e32 v25, v62                                     // 0000000F3BD0: 7E32033E
	s_mov_b32 s9, 0                                            // 0000000F3BD4: BE890080
	s_waitcnt lgkmcnt(0)                                       // 0000000F3BD8: BF89FC07
	s_barrier                                                  // 0000000F3BDC: BFBD0000
	buffer_gl0_inv                                             // 0000000F3BE0: E0AC0000 00000000
	s_nop 0                                                    // 0000000F3BE8: BF800000
	s_nop 0                                                    // 0000000F3BEC: BF800000
	s_nop 0                                                    // 0000000F3BF0: BF800000
	s_nop 0                                                    // 0000000F3BF4: BF800000
	s_nop 0                                                    // 0000000F3BF8: BF800000
	s_nop 0                                                    // 0000000F3BFC: BF800000
	global_load_b32 v26, v[21:22], off                         // 0000000F3C00: DC520000 1A7C0015
	ds_load_b32 v27, v24 offset:12224                          // 0000000F3C08: D8D82FC0 1B000018
	v_add_nc_u32_e32 v25, 0x80, v25                            // 0000000F3C10: 4A3232FF 00000080
	.long 0xd7000115                                           // 0000000F3C18: D7000115
	v_cndmask_b32_e32 v1, 0x6000, v21, vcc_lo                  // 0000000F3C1C: 02022AFF 00006000
	v_add_nc_u32_e32 v24, 4, v24                               // 0000000F3C24: 4A303084
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000F3C28: D5207C16 00062C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F3C30: BF890007
	v_mul_f32_e32 v26, v26, v27                                // 0000000F3C34: 1034371A
	.long 0xd4490004                                           // 0000000F3C38: D4490004
	v_cndmask_b32_e32 v1, 0x77f, v25, vcc_lo                   // 0000000F3C3C: 020232FF 0000077F
	ds_store_b32 v23, v26                                      // 0000000F3C44: D8340000 00001A17
	v_add_nc_u32_e32 v23, 0x204, v23                           // 0000000F3C4C: 4A2E2EFF 00000204
	s_or_b32 s9, s4, s9                                        // 0000000F3C54: 8C090904
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F3C58: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000F3C5C: 917E097E
	s_cbranch_execnz 65511                                     // 0000000F3C60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2200>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000F3C64: 8C7E097E
	s_waitcnt lgkmcnt(0)                                       // 0000000F3C68: BF89FC07
	s_barrier                                                  // 0000000F3C6C: BFBD0000
	buffer_gl0_inv                                             // 0000000F3C70: E0AC0000 00000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000F3C78: BE84206A
	s_cbranch_execz 95                                         // 0000000F3C7C: BFA5005F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23fc>
	ds_load_2addr_b32 v[21:22], v47 offset0:160 offset1:165    // 0000000F3C80: D8DCA5A0 1500002F
	ds_load_2addr_b32 v[23:24], v47 offset0:170 offset1:175    // 0000000F3C88: D8DCAFAA 1700002F
	ds_load_2addr_b32 v[25:26], v47 offset0:180 offset1:185    // 0000000F3C90: D8DCB9B4 1900002F
	ds_load_2addr_b32 v[27:28], v47 offset0:190 offset1:195    // 0000000F3C98: D8DCC3BE 1B00002F
	ds_load_2addr_b32 v[29:30], v47 offset0:200 offset1:205    // 0000000F3CA0: D8DCCDC8 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:210 offset1:215    // 0000000F3CA8: D8DCD7D2 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:220 offset1:225    // 0000000F3CB0: D8DCE1DC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:230 offset1:235    // 0000000F3CB8: D8DCEBE6 2300002F
	v_mov_b32_e32 v63, v0                                      // 0000000F3CC0: 7E7E0300
	s_mov_b32 s9, 0                                            // 0000000F3CC4: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000F3CC8: BF8701B1
	v_lshrrev_b32_e32 v64, 2, v63                              // 0000000F3CCC: 32807E82
	v_and_b32_e32 v71, -4, v63                                 // 0000000F3CD0: 368E7EC4
	.long 0xd4490001                                           // 0000000F3CD4: D4490001
	v_cndmask_b32_e32 v1, 0x17f, v63, vcc_lo                   // 0000000F3CD8: 02027EFF 0000017F
	v_mad_u64_u32 v[64:65], null, v64, 20, v[2:3]              // 0000000F3CE0: D6FE7C40 04092940
	ds_load_2addr_b32 v[65:66], v71 offset1:129                // 0000000F3CE8: D8DC8100 41000047
	ds_load_b32 v72, v64                                       // 0000000F3CF0: D8D80000 48000040
	s_or_b32 s9, s1, s9                                        // 0000000F3CF8: 8C090901
	s_waitcnt lgkmcnt(0)                                       // 0000000F3CFC: BF89FC07
	v_dual_fmac_f32 v72, v65, v21 :: v_dual_add_nc_u32 v67, 0x400, v71// 0000000F3D00: C8202B41 48428EFF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F3D0C: BF8700C1
	v_fmac_f32_e32 v72, v66, v22                               // 0000000F3D10: 56902D42
	ds_load_2addr_b32 v[67:68], v67 offset0:2 offset1:131      // 0000000F3D14: D8DC8302 43000043
	s_waitcnt lgkmcnt(0)                                       // 0000000F3D1C: BF89FC07
	v_fmac_f32_e32 v72, v67, v23                               // 0000000F3D20: 56902F43
	v_dual_fmac_f32 v72, v68, v24 :: v_dual_add_nc_u32 v69, 0x800, v71// 0000000F3D24: C8203144 48448EFF 00000800
	ds_load_2addr_b32 v[69:70], v69 offset0:4 offset1:133      // 0000000F3D30: D8DC8504 45000045
	s_waitcnt lgkmcnt(0)                                       // 0000000F3D38: BF89FC07
	v_dual_fmac_f32 v72, v69, v25 :: v_dual_add_nc_u32 v65, 0xc00, v71// 0000000F3D3C: C8203345 48408EFF 00000C00
	ds_load_2addr_b32 v[65:66], v65 offset0:6 offset1:135      // 0000000F3D48: D8DC8706 41000041
	v_dual_fmac_f32 v72, v70, v26 :: v_dual_add_nc_u32 v67, 0x1000, v71// 0000000F3D50: C8203546 48428EFF 00001000
	ds_load_2addr_b32 v[67:68], v67 offset0:8 offset1:137      // 0000000F3D5C: D8DC8908 43000043
	s_waitcnt lgkmcnt(1)                                       // 0000000F3D64: BF89FC17
	v_fmac_f32_e32 v72, v65, v27                               // 0000000F3D68: 56903741
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F3D6C: BF870001
	v_dual_fmac_f32 v72, v66, v28 :: v_dual_add_nc_u32 v69, 0x1400, v71// 0000000F3D70: C8203942 48448EFF 00001400
	ds_load_2addr_b32 v[69:70], v69 offset0:10 offset1:139     // 0000000F3D7C: D8DC8B0A 45000045
	s_waitcnt lgkmcnt(1)                                       // 0000000F3D84: BF89FC17
	v_dual_fmac_f32 v72, v67, v29 :: v_dual_add_nc_u32 v65, 0x1800, v71// 0000000F3D88: C8203B43 48408EFF 00001800
	v_add_nc_u32_e32 v67, 0x1c00, v71                          // 0000000F3D94: 4A868EFF 00001C00
	ds_load_2addr_b32 v[65:66], v65 offset0:12 offset1:141     // 0000000F3D9C: D8DC8D0C 41000041
	v_fmac_f32_e32 v72, v68, v30                               // 0000000F3DA4: 56903D44
	ds_load_2addr_b32 v[67:68], v67 offset0:14 offset1:143     // 0000000F3DA8: D8DC8F0E 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000F3DB0: BF89FC27
	v_fmac_f32_e32 v72, v69, v31                               // 0000000F3DB4: 56903F45
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F3DB8: BF8700A1
	v_fmac_f32_e32 v72, v70, v32                               // 0000000F3DBC: 56904146
	s_waitcnt lgkmcnt(1)                                       // 0000000F3DC0: BF89FC17
	v_dual_fmac_f32 v72, v65, v33 :: v_dual_add_nc_u32 v65, 0x80, v63// 0000000F3DC4: C8204341 48407EFF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F3DD0: BF8700A1
	v_dual_fmac_f32 v72, v66, v34 :: v_dual_mov_b32 v63, v65   // 0000000F3DD4: C8104542 483E0141
	s_waitcnt lgkmcnt(0)                                       // 0000000F3DDC: BF89FC07
	v_fmac_f32_e32 v72, v67, v35                               // 0000000F3DE0: 56904743
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F3DE4: BF870001
	v_fmac_f32_e32 v72, v68, v36                               // 0000000F3DE8: 56904944
	ds_store_b32 v64, v72                                      // 0000000F3DEC: D8340000 00004840
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000F3DF4: 917E097E
	s_cbranch_execnz 65459                                     // 0000000F3DF8: BFA6FFB3 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x22c8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000F3DFC: 8C7E047E
	v_dual_mov_b32 v22, v20 :: v_dual_mov_b32 v21, v19         // 0000000F3E00: CA100114 16140113
	v_dual_mov_b32 v23, v1 :: v_dual_mov_b32 v24, 0            // 0000000F3E08: CA100101 17180080
	v_mov_b32_e32 v25, v62                                     // 0000000F3E10: 7E32033E
	s_mov_b32 s9, 0                                            // 0000000F3E14: BE890080
	s_waitcnt lgkmcnt(0)                                       // 0000000F3E18: BF89FC07
	s_barrier                                                  // 0000000F3E1C: BFBD0000
	buffer_gl0_inv                                             // 0000000F3E20: E0AC0000 00000000
	s_nop 0                                                    // 0000000F3E28: BF800000
	s_nop 0                                                    // 0000000F3E2C: BF800000
	s_nop 0                                                    // 0000000F3E30: BF800000
	s_nop 0                                                    // 0000000F3E34: BF800000
	s_nop 0                                                    // 0000000F3E38: BF800000
	s_nop 0                                                    // 0000000F3E3C: BF800000
	global_load_b32 v26, v[21:22], off                         // 0000000F3E40: DC520000 1A7C0015
	ds_load_b32 v27, v24 offset:12288                          // 0000000F3E48: D8D83000 1B000018
	v_add_nc_u32_e32 v25, 0x80, v25                            // 0000000F3E50: 4A3232FF 00000080
	.long 0xd7000115                                           // 0000000F3E58: D7000115
	v_cndmask_b32_e32 v1, 0x6000, v21, vcc_lo                  // 0000000F3E5C: 02022AFF 00006000
	v_add_nc_u32_e32 v24, 4, v24                               // 0000000F3E64: 4A303084
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000F3E68: D5207C16 00062C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F3E70: BF890007
	v_mul_f32_e32 v26, v26, v27                                // 0000000F3E74: 1034371A
	.long 0xd4490004                                           // 0000000F3E78: D4490004
	v_cndmask_b32_e32 v1, 0x77f, v25, vcc_lo                   // 0000000F3E7C: 020232FF 0000077F
	ds_store_b32 v23, v26                                      // 0000000F3E84: D8340000 00001A17
	v_add_nc_u32_e32 v23, 0x204, v23                           // 0000000F3E8C: 4A2E2EFF 00000204
	s_or_b32 s9, s4, s9                                        // 0000000F3E94: 8C090904
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F3E98: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000F3E9C: 917E097E
	s_cbranch_execnz 65511                                     // 0000000F3EA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000F3EA4: 8C7E097E
	s_waitcnt lgkmcnt(0)                                       // 0000000F3EA8: BF89FC07
	s_barrier                                                  // 0000000F3EAC: BFBD0000
	buffer_gl0_inv                                             // 0000000F3EB0: E0AC0000 00000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000F3EB8: BE84206A
	s_cbranch_execz 63398                                      // 0000000F3EBC: BFA5F7A6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x358>
	v_add_nc_u32_e32 v35, 0x400, v47                           // 0000000F3EC0: 4A465EFF 00000400
	v_mov_b32_e32 v63, v0                                      // 0000000F3EC8: 7E7E0300
	s_mov_b32 s9, 0                                            // 0000000F3ECC: BE890080
	ds_load_2addr_b32 v[21:22], v47 offset0:240 offset1:245    // 0000000F3ED0: D8DCF5F0 1500002F
	ds_load_2addr_b32 v[23:24], v47 offset0:250 offset1:255    // 0000000F3ED8: D8DCFFFA 1700002F
	ds_load_2addr_b32 v[25:26], v35 offset0:4 offset1:9        // 0000000F3EE0: D8DC0904 19000023
	ds_load_2addr_b32 v[27:28], v35 offset0:14 offset1:19      // 0000000F3EE8: D8DC130E 1B000023
	ds_load_2addr_b32 v[29:30], v35 offset0:24 offset1:29      // 0000000F3EF0: D8DC1D18 1D000023
	ds_load_2addr_b32 v[31:32], v35 offset0:34 offset1:39      // 0000000F3EF8: D8DC2722 1F000023
	ds_load_2addr_b32 v[33:34], v35 offset0:44 offset1:49      // 0000000F3F00: D8DC312C 21000023
	ds_load_2addr_b32 v[35:36], v35 offset0:54 offset1:59      // 0000000F3F08: D8DC3B36 23000023
	v_lshrrev_b32_e32 v64, 2, v63                              // 0000000F3F10: 32807E82
	v_and_b32_e32 v71, -4, v63                                 // 0000000F3F14: 368E7EC4
	.long 0xd4490001                                           // 0000000F3F18: D4490001
	v_cndmask_b32_e32 v1, 0x17f, v63, vcc_lo                   // 0000000F3F1C: 02027EFF 0000017F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000F3F24: BF870003
	v_mad_u64_u32 v[64:65], null, v64, 20, v[2:3]              // 0000000F3F28: D6FE7C40 04092940
	ds_load_2addr_b32 v[65:66], v71 offset1:129                // 0000000F3F30: D8DC8100 41000047
	ds_load_b32 v72, v64                                       // 0000000F3F38: D8D80000 48000040
	s_or_b32 s9, s1, s9                                        // 0000000F3F40: 8C090901
	s_waitcnt lgkmcnt(0)                                       // 0000000F3F44: BF89FC07
	v_dual_fmac_f32 v72, v65, v21 :: v_dual_add_nc_u32 v67, 0x400, v71// 0000000F3F48: C8202B41 48428EFF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F3F54: BF8700C1
	v_fmac_f32_e32 v72, v66, v22                               // 0000000F3F58: 56902D42
	ds_load_2addr_b32 v[67:68], v67 offset0:2 offset1:131      // 0000000F3F5C: D8DC8302 43000043
	s_waitcnt lgkmcnt(0)                                       // 0000000F3F64: BF89FC07
	v_fmac_f32_e32 v72, v67, v23                               // 0000000F3F68: 56902F43
	v_dual_fmac_f32 v72, v68, v24 :: v_dual_add_nc_u32 v69, 0x800, v71// 0000000F3F6C: C8203144 48448EFF 00000800
	ds_load_2addr_b32 v[69:70], v69 offset0:4 offset1:133      // 0000000F3F78: D8DC8504 45000045
	s_waitcnt lgkmcnt(0)                                       // 0000000F3F80: BF89FC07
	v_dual_fmac_f32 v72, v69, v25 :: v_dual_add_nc_u32 v65, 0xc00, v71// 0000000F3F84: C8203345 48408EFF 00000C00
	ds_load_2addr_b32 v[65:66], v65 offset0:6 offset1:135      // 0000000F3F90: D8DC8706 41000041
	v_dual_fmac_f32 v72, v70, v26 :: v_dual_add_nc_u32 v67, 0x1000, v71// 0000000F3F98: C8203546 48428EFF 00001000
	ds_load_2addr_b32 v[67:68], v67 offset0:8 offset1:137      // 0000000F3FA4: D8DC8908 43000043
	s_waitcnt lgkmcnt(1)                                       // 0000000F3FAC: BF89FC17
	v_fmac_f32_e32 v72, v65, v27                               // 0000000F3FB0: 56903741
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F3FB4: BF870001
	v_dual_fmac_f32 v72, v66, v28 :: v_dual_add_nc_u32 v69, 0x1400, v71// 0000000F3FB8: C8203942 48448EFF 00001400
	ds_load_2addr_b32 v[69:70], v69 offset0:10 offset1:139     // 0000000F3FC4: D8DC8B0A 45000045
	s_waitcnt lgkmcnt(1)                                       // 0000000F3FCC: BF89FC17
	v_dual_fmac_f32 v72, v67, v29 :: v_dual_add_nc_u32 v65, 0x1800, v71// 0000000F3FD0: C8203B43 48408EFF 00001800
	v_add_nc_u32_e32 v67, 0x1c00, v71                          // 0000000F3FDC: 4A868EFF 00001C00
	ds_load_2addr_b32 v[65:66], v65 offset0:12 offset1:141     // 0000000F3FE4: D8DC8D0C 41000041
	v_fmac_f32_e32 v72, v68, v30                               // 0000000F3FEC: 56903D44
	ds_load_2addr_b32 v[67:68], v67 offset0:14 offset1:143     // 0000000F3FF0: D8DC8F0E 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000F3FF8: BF89FC27
	v_fmac_f32_e32 v72, v69, v31                               // 0000000F3FFC: 56903F45
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F4000: BF8700A1
	v_fmac_f32_e32 v72, v70, v32                               // 0000000F4004: 56904146
	s_waitcnt lgkmcnt(1)                                       // 0000000F4008: BF89FC17
	v_dual_fmac_f32 v72, v65, v33 :: v_dual_add_nc_u32 v65, 0x80, v63// 0000000F400C: C8204341 48407EFF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F4018: BF8700A1
	v_dual_fmac_f32 v72, v66, v34 :: v_dual_mov_b32 v63, v65   // 0000000F401C: C8104542 483E0141
	s_waitcnt lgkmcnt(0)                                       // 0000000F4024: BF89FC07
	v_fmac_f32_e32 v72, v67, v35                               // 0000000F4028: 56904743
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F402C: BF870001
	v_fmac_f32_e32 v72, v68, v36                               // 0000000F4030: 56904944
	ds_store_b32 v64, v72                                      // 0000000F4034: D8340000 00004840
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000F403C: 917E097E
	s_cbranch_execnz 65459                                     // 0000000F4040: BFA6FFB3 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2510>
	s_branch 63300                                             // 0000000F4044: BFA0F744 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x358>
	s_and_saveexec_b32 s0, vcc_lo                              // 0000000F4048: BE80206A
	s_cbranch_execz 48                                         // 0000000F404C: BFA50030 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2710>
	s_ashr_i32 s7, s6, 31                                      // 0000000F4050: 86079F06
	v_lshlrev_b32_e32 v0, 9, v38                               // 0000000F4054: 30004C89
	s_lshl_b64 s[0:1], s[22:23], 2                             // 0000000F4058: 84808216
	s_lshl_b64 s[2:3], s[6:7], 2                               // 0000000F405C: 84828206
	v_lshlrev_b32_e32 v1, 2, v39                               // 0000000F4060: 30024E82
	s_add_u32 s0, s2, s0                                       // 0000000F4064: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000F4068: 82010103
	.long 0xd7000000                                           // 0000000F406C: D7000000
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000F4070: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000F4074: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000000F4078: D5207C02 00010001
	s_mov_b32 s1, 0                                            // 0000000F4080: BE810080
	.long 0xd7006a00                                           // 0000000F4084: D7006A00
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000000F4088: 02020300
	v_add_co_ci_u32_e64 v3, null, 0, v2, vcc_lo                // 0000000F408C: D5207C03 01AA0480
	v_mad_u32_u24 v2, v38, 20, v1                              // 0000000F4094: D60B0002 04052926
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F409C: BF870093
	.long 0xd7006a00                                           // 0000000F40A0: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 0000000F40A4: 02020014
	v_add_co_ci_u32_e64 v1, null, s21, v3, vcc_lo              // 0000000F40A8: D5207C01 01AA0615
	s_nop 0                                                    // 0000000F40B0: BF800000
	s_nop 0                                                    // 0000000F40B4: BF800000
	s_nop 0                                                    // 0000000F40B8: BF800000
	s_nop 0                                                    // 0000000F40BC: BF800000
	ds_load_b32 v3, v2 offset:8256                             // 0000000F40C0: D8D82040 03000002
	v_add_nc_u32_e32 v37, 0x80, v37                            // 0000000F40C8: 4A4A4AFF 00000080
	v_add_nc_u32_e32 v2, 0x280, v2                             // 0000000F40D0: 4A0404FF 00000280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F40D8: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x17f, v37                        // 0000000F40DC: 7C924AFF 0000017F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000F40E4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000F40E8: BF89FC07
	global_store_b32 v[0:1], v3, off                           // 0000000F40EC: DC6A0000 007C0300
	.long 0xd7000000                                           // 0000000F40F4: D7000000
	v_cndmask_b32_e32 v1, 0x4000, v0, vcc_lo                   // 0000000F40F8: 020200FF 00004000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000F4100: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000F4108: 917E017E
	s_cbranch_execnz 65516                                     // 0000000F410C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26c0>
	s_endpgm                                                   // 0000000F4110: BFB00000
		...

