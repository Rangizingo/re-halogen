0000000000225e00 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_():
	s_load_b256 s[4:11], s[0:1], null                          // 000000225E00: F40C0100 F8000000
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 000000225E08: CA240100 040000FF 0000007F
	s_mov_b32 s12, s3                                          // 000000225E14: BE8C0003
	s_lshl_b32 s14, s2, 6                                      // 000000225E18: 840E8602
	s_ashr_i32 s13, s12, 31                                    // 000000225E1C: 860D9F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000225E20: BF8700A1
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000225E24: 30020282
	s_waitcnt lgkmcnt(0)                                       // 000000225E28: BF89FC07
	.long 0xd7000302                                           // 000000225E2C: D7000302
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 000000225E30: 02020206
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225E34: BF870001
	v_add_co_ci_u32_e64 v3, null, s7, 0, s3                    // 000000225E38: D5207C03 000D0007
	s_mov_b32 s3, 0                                            // 000000225E40: BE830080
	s_nop 0                                                    // 000000225E44: BF800000
	s_nop 0                                                    // 000000225E48: BF800000
	s_nop 0                                                    // 000000225E4C: BF800000
	s_nop 0                                                    // 000000225E50: BF800000
	s_nop 0                                                    // 000000225E54: BF800000
	s_nop 0                                                    // 000000225E58: BF800000
	s_nop 0                                                    // 000000225E5C: BF800000
	s_nop 0                                                    // 000000225E60: BF800000
	s_nop 0                                                    // 000000225E64: BF800000
	s_nop 0                                                    // 000000225E68: BF800000
	s_nop 0                                                    // 000000225E6C: BF800000
	s_nop 0                                                    // 000000225E70: BF800000
	s_nop 0                                                    // 000000225E74: BF800000
	s_nop 0                                                    // 000000225E78: BF800000
	s_nop 0                                                    // 000000225E7C: BF800000
	v_lshrrev_b32_e32 v7, 7, v4                                // 000000225E80: 320E0887
	v_add_nc_u32_e32 v9, 0x100, v4                             // 000000225E84: 4A1208FF 00000100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225E8C: BF870092
	v_or_b32_e32 v5, s14, v7                                   // 000000225E90: 380A0E0E
	v_mad_i64_i32 v[5:6], null, v5, 48, s[12:13]               // 000000225E94: D6FF7C05 00316105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225E9C: BF870091
	.long 0xd73c0005                                           // 000000225EA0: D73C0005
	v_cndmask_b32_e32 v1, 9, v5, vcc_lo                        // 000000225EA4: 02020A89
	.long 0xd7006a05                                           // 000000225EA8: D7006A05
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 000000225EAC: 02020B02
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225EB0: BF870001
	v_add_co_ci_u32_e64 v6, null, v3, v6, vcc_lo               // 000000225EB4: D5207C06 01AA0D03
	v_cmp_lt_u32_e32 vcc_lo, 0x1eff, v4                        // 000000225EBC: 7C9208FF 00001EFF
	v_mov_b32_e32 v4, v9                                       // 000000225EC4: 7E080309
	global_load_b32 v8, v[5:6], off                            // 000000225EC8: DC520000 087C0005
	v_mad_u64_u32 v[5:6], null, 0x204, v7, v[1:2]              // 000000225ED0: D6FE7C05 04060EFF 00000204
	s_or_b32 s3, vcc_lo, s3                                    // 000000225EDC: 8C03036A
	s_waitcnt vmcnt(0)                                         // 000000225EE0: BF8903F7
	ds_store_b32 v5, v8                                        // 000000225EE4: D8340000 00000805
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000225EEC: 917E037E
	s_cbranch_execnz 65507                                     // 000000225EF0: BFA6FFE3 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x80>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000225EF4: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000225EF8: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000225EFC: BE83007E
	v_cmpx_gt_u32_e32 64, v0                                   // 000000225F00: 7D9800C0
	s_cbranch_execz 17                                         // 000000225F04: BFA50011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x14c>
	v_or_b32_e32 v1, s14, v0                                   // 000000225F08: 3802000E
	s_lshl_b64 s[6:7], s[12:13], 2                             // 000000225F0C: 8486820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225F10: BF870091
	v_mad_i64_i32 v[1:2], null, 0xc0, v1, s[8:9]               // 000000225F14: D6FF7C01 002202FF 000000C0
	.long 0xd7006a01                                           // 000000225F20: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000225F24: 02000D01
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225F28: BF870001
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000225F2C: D5207C02 01AA0407
	global_load_b32 v1, v[1:2], off                            // 000000225F34: DC520000 017C0001
	v_lshlrev_b32_e32 v2, 2, v0                                // 000000225F3C: 30040082
	s_waitcnt vmcnt(0)                                         // 000000225F40: BF8903F7
	ds_store_b32 v2, v1 offset:33024                           // 000000225F44: D8348100 00000102
	s_or_b32 exec_lo, exec_lo, s3                              // 000000225F4C: 8C7E037E
	s_mov_b64 s[6:7], 0                                        // 000000225F50: BE860180
	s_cmp_eq_u64 s[10:11], 0                                   // 000000225F54: BF10800A
	s_mul_hi_i32 s8, s2, 48                                    // 000000225F58: 9708B002
	s_mul_i32 s9, s2, 48                                       // 000000225F5C: 9609B002
	s_mov_b64 s[2:3], 0                                        // 000000225F60: BE820180
	s_waitcnt lgkmcnt(0)                                       // 000000225F64: BF89FC07
	s_barrier                                                  // 000000225F68: BFBD0000
	buffer_gl0_inv                                             // 000000225F6C: E0AC0000 00000000
	s_cbranch_scc1 6                                           // 000000225F74: BFA20006 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x190>
	s_add_u32 s2, s9, s12                                      // 000000225F78: 80020C09
	s_addc_u32 s3, s8, s13                                     // 000000225F7C: 82030D08
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000225F80: BF870499
	s_lshl_b64 s[2:3], s[2:3], 14                              // 000000225F84: 84828E02
	s_add_u32 s2, s10, s2                                      // 000000225F88: 8002020A
	s_addc_u32 s3, s11, s3                                     // 000000225F8C: 8203030B
	s_load_b64 s[0:1], s[0:1], 0x28                            // 000000225F90: F4040000 F8000028
	s_waitcnt lgkmcnt(0)                                       // 000000225F98: BF89FC07
	s_cmp_eq_u64 s[0:1], 0                                     // 000000225F9C: BF108000
	s_cbranch_scc1 6                                           // 000000225FA0: BFA20006 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x1bc>
	s_add_u32 s6, s9, s12                                      // 000000225FA4: 80060C09
	s_addc_u32 s7, s8, s13                                     // 000000225FA8: 82070D08
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000225FAC: BF870499
	s_lshl_b64 s[6:7], s[6:7], 13                              // 000000225FB0: 84868D06
	s_add_u32 s6, s0, s6                                       // 000000225FB4: 80060600
	s_addc_u32 s7, s1, s7                                      // 000000225FB8: 82070701
	v_and_b32_e32 v4, 63, v0                                   // 000000225FBC: 360800BF
	v_lshrrev_b32_e32 v1, 6, v0                                // 000000225FC0: 32020086
	s_cmp_lg_u64 s[2:3], 0                                     // 000000225FC4: BF118002
	s_mov_b32 s10, 0                                           // 000000225FC8: BE8A0080
	s_cselect_b32 s8, -1, 0                                    // 000000225FCC: 980880C1
	s_cmp_lg_u64 s[6:7], 0                                     // 000000225FD0: BF118006
	v_add_nc_u32_e32 v7, s14, v1                               // 000000225FD4: 4A0E020E
	s_cselect_b32 s9, -1, 0                                    // 000000225FD8: 980980C1
	s_lshl_b64 s[0:1], s[12:13], 9                             // 000000225FDC: 8480890C
	v_mov_b32_e32 v1, 0                                        // 000000225FE0: 7E020280
	v_mul_u32_u24_e32 v5, 0x204, v4                            // 000000225FE4: 160A08FF 00000204
	v_lshl_or_b32 v6, v4, 2, 0x8100                            // 000000225FEC: D6560006 03FD0504 00008100
	s_add_u32 s0, s4, s0                                       // 000000225FF8: 80000004
	s_addc_u32 s1, s5, s1                                      // 000000225FFC: 82010105
	s_mov_b32 s11, 0x41800000                                  // 000000226000: BE8B00FF 41800000
	s_branch 10                                                // 000000226008: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x234>
	v_add_nc_u32_e32 v2, 0x100, v0                             // 00000022600C: 4A0400FF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xeff, v0                         // 000000226014: 7C9200FF 00000EFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000022601C: BF8704A2
	v_dual_mov_b32 v0, v2 :: v_dual_add_nc_u32 v7, 4, v7       // 000000226020: CA200102 00060E84
	s_or_b32 s10, vcc_lo, s10                                  // 000000226028: 8C0A0A6A
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000022602C: 917E0A7E
	s_cbranch_execz 141                                        // 000000226030: BFA5008D <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x468>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000226034: BF870131
	v_lshrrev_b32_e32 v9, 6, v0                                // 000000226038: 32120086
	v_mov_b32_e32 v2, 0                                        // 00000022603C: 7E040280
	s_mov_b32 s12, exec_lo                                     // 000000226040: BE8C007E
	.long 0xd4cb007e                                           // 000000226044: D4CB007E
	v_cndmask_b32_e32 v1, v4, v9, vcc_lo                       // 000000226048: 02021304
	s_cbranch_execz 107                                        // 00000022604C: BFA5006B <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x3fc>
	v_mad_i64_i32 v[2:3], null, 0x6000, v7, s[0:1]             // 000000226050: D6FF7C02 00020EFF 00006000
	v_mov_b32_e32 v8, 0                                        // 00000022605C: 7E100280
	v_mov_b32_e32 v10, v5                                      // 000000226060: 7E140305
	s_mov_b64 s[4:5], 0                                        // 000000226064: BE840180
	s_delay_alu instid0(VALU_DEP_3) | instid1(SALU_CYCLE_1)    // 000000226068: BF870483
	.long 0xd7006a17                                           // 00000022606C: D7006A17
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 000000226070: 02000902
	s_delay_alu instid0(VALU_DEP_1)                            // 000000226074: BF870001
	v_add_co_ci_u32_e64 v24, null, s5, v3, vcc_lo              // 000000226078: D5207C18 01AA0605
	ds_load_2addr_b32 v[27:28], v10 offset1:1                  // 000000226080: D8DC0100 1B00000A
	ds_load_2addr_b32 v[29:30], v10 offset0:2 offset1:3        // 000000226088: D8DC0302 1D00000A
	ds_load_2addr_b32 v[31:32], v10 offset0:4 offset1:5        // 000000226090: D8DC0504 1F00000A
	ds_load_2addr_b32 v[33:34], v10 offset0:6 offset1:7        // 000000226098: D8DC0706 2100000A
	s_add_u32 s4, s4, 64                                       // 0000002260A0: 8004C004
	s_addc_u32 s5, s5, 0                                       // 0000002260A4: 82058005
	s_clause 0x3                                               // 0000002260A8: BF850003
	global_load_b128 v[11:14], v[23:24], off                   // 0000002260AC: DC5E0000 0B7C0017
	global_load_b128 v[15:18], v[23:24], off offset:16         // 0000002260B4: DC5E0010 0F7C0017
	global_load_b128 v[19:22], v[23:24], off offset:32         // 0000002260BC: DC5E0020 137C0017
	global_load_b128 v[23:26], v[23:24], off offset:48         // 0000002260C4: DC5E0030 177C0017
	s_cmpk_eq_i32 s4, 0x200                                    // 0000002260CC: B1840200
	s_waitcnt vmcnt(3) lgkmcnt(3)                              // 0000002260D0: BF890C37
	v_fmac_f32_e32 v8, v11, v27                                // 0000002260D4: 5610370B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002260D8: BF8700C1
	v_fmac_f32_e32 v8, v12, v28                                // 0000002260DC: 5610390C
	ds_load_2addr_b32 v[11:12], v10 offset0:8 offset1:9        // 0000002260E0: D8DC0908 0B00000A
	s_waitcnt lgkmcnt(3)                                       // 0000002260E8: BF89FC37
	v_fmac_f32_e32 v8, v13, v29                                // 0000002260EC: 56103B0D
	v_fmac_f32_e32 v8, v14, v30                                // 0000002260F0: 56103D0E
	ds_load_2addr_b32 v[13:14], v10 offset0:10 offset1:11      // 0000002260F4: D8DC0B0A 0D00000A
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000002260FC: BF890837
	v_fmac_f32_e32 v8, v15, v31                                // 000000226100: 56103F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000226104: BF8700A1
	v_fmac_f32_e32 v8, v16, v32                                // 000000226108: 56104110
	s_waitcnt lgkmcnt(2)                                       // 00000022610C: BF89FC27
	v_fmac_f32_e32 v8, v17, v33                                // 000000226110: 56104311
	s_delay_alu instid0(VALU_DEP_1)                            // 000000226114: BF870001
	v_fmac_f32_e32 v8, v18, v34                                // 000000226118: 56104512
	ds_load_2addr_b32 v[15:16], v10 offset0:12 offset1:13      // 00000022611C: D8DC0D0C 0F00000A
	ds_load_2addr_b32 v[17:18], v10 offset0:14 offset1:15      // 000000226124: D8DC0F0E 1100000A
	v_add_nc_u32_e32 v10, 64, v10                              // 00000022612C: 4A1414C0
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 000000226130: BF890437
	v_fmac_f32_e32 v8, v19, v11                                // 000000226134: 56101713
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000226138: BF8700A1
	v_fmac_f32_e32 v8, v20, v12                                // 00000022613C: 56101914
	s_waitcnt lgkmcnt(2)                                       // 000000226140: BF89FC27
	v_fmac_f32_e32 v8, v21, v13                                // 000000226144: 56101B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000226148: BF8700A1
	v_fmac_f32_e32 v8, v22, v14                                // 00000022614C: 56101D16
	s_waitcnt vmcnt(0) lgkmcnt(1)                              // 000000226150: BF890017
	v_fmac_f32_e32 v8, v23, v15                                // 000000226154: 56101F17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000226158: BF8700A1
	v_fmac_f32_e32 v8, v24, v16                                // 00000022615C: 56102118
	s_waitcnt lgkmcnt(0)                                       // 000000226160: BF89FC07
	v_fmac_f32_e32 v8, v25, v17                                // 000000226164: 56102319
	s_delay_alu instid0(VALU_DEP_1)                            // 000000226168: BF870001
	v_fmac_f32_e32 v8, v26, v18                                // 00000022616C: 5610251A
	s_cbranch_scc0 65469                                       // 000000226170: BFA1FFBD <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x268>
	v_lshlrev_b32_e32 v2, 2, v9                                // 000000226174: 30041282
	ds_load_b32 v2, v2 offset:33024                            // 000000226178: D8D88100 02000002
	ds_load_b32 v3, v6                                         // 000000226180: D8D80000 03000006
	s_waitcnt lgkmcnt(0)                                       // 000000226188: BF89FC07
	v_sub_f32_e32 v2, v2, v3                                   // 00000022618C: 08040702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226190: BF870091
	v_mul_f32_e32 v3, 0x3fb8aa3b, v2                           // 000000226194: 100604FF 3FB8AA3B
	v_fma_f32 v9, 0x3fb8aa3b, v2, -v3                          // 00000022619C: D6130009 840E04FF 3FB8AA3B
	v_rndne_f32_e32 v10, v3                                    // 0000002261A8: 7E144703
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002261AC: BF870112
	v_fmac_f32_e32 v9, 0x32a5705f, v2                          // 0000002261B0: 561204FF 32A5705F
	v_sub_f32_e32 v3, v3, v10                                  // 0000002261B8: 08061503
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002261BC: BF8701B1
	v_add_f32_e32 v3, v3, v9                                   // 0000002261C0: 06061303
	v_cvt_i32_f32_e32 v9, v10                                  // 0000002261C4: 7E12110A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2                   // 0000002261C8: 7C3604FF C2CE8ED0
	v_exp_f32_e32 v3, v3                                       // 0000002261D0: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002261D4: BF870095
	.long 0xd71c0003                                           // 0000002261D8: D71C0003
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 0000002261DC: 02021303
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 0000002261E0: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2                   // 0000002261E4: 7C3C04FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002261EC: BF870092
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo               // 0000002261F0: 020406FF 7F800000
	v_mul_f32_e32 v2, v8, v2                                   // 0000002261F8: 10040508
	s_or_b32 exec_lo, exec_lo, s12                             // 0000002261FC: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000226200: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s8                         // 000000226204: 916A087E
	s_cbranch_vccnz 9                                          // 000000226208: BFA40009 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x430>
	.long 0xd73c0008                                           // 00000022620C: D73C0008
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000226210: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226214: BF870091
	.long 0xd7006a08                                           // 000000226218: D7006A08
	v_cndmask_b32_e32 v1, s2, v8, vcc_lo                       // 00000022621C: 02021002
	v_add_co_ci_u32_e64 v9, null, s3, v9, vcc_lo               // 000000226220: D5207C09 01AA1203
	global_store_b32 v[8:9], v2, off                           // 000000226228: DC6A0000 007C0208
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 000000226230: 916A097E
	s_cbranch_vccnz 65397                                      // 000000226234: BFA4FF75 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x20c>
	.long 0xd73c0008                                           // 000000226238: D73C0008
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 00000022623C: 02020081
	v_fma_mixlo_f16 v2, v2, s11, 0                             // 000000226240: CC210002 02001702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226248: BF870092
	.long 0xd7006a08                                           // 00000022624C: D7006A08
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 000000226250: 02021006
	v_add_co_ci_u32_e64 v9, null, s7, v9, vcc_lo               // 000000226254: D5207C09 01AA1207
	global_store_b16 v[8:9], v2, off                           // 00000022625C: DC660000 007C0208
	s_branch 65385                                             // 000000226264: BFA0FF69 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi64ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x20c>
	s_endpgm                                                   // 000000226268: BFB00000
		...

