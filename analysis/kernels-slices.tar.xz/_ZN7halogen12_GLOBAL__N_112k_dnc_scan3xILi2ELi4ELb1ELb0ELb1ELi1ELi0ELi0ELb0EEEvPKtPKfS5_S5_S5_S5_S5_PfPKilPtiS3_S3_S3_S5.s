00000000001b4b00 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE():
	s_load_b256 s[16:23], s[0:1], 0x38                         // 0000001B4B00: F40C0400 F8000038
	s_lshl_b32 s6, s3, 6                                       // 0000001B4B08: 84068603
	s_ashr_i32 s3, s2, 31                                      // 0000001B4B0C: 86039F02
	s_ashr_i32 s7, s6, 31                                      // 0000001B4B10: 86079F06
	v_and_b32_e32 v1, 63, v0                                   // 0000001B4B14: 360200BF
	v_mov_b32_e32 v5, v0                                       // 0000001B4B18: 7E0A0300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001B4B1C: BF8704D2
	v_lshlrev_b32_e32 v3, 2, v1                                // 0000001B4B20: 30060282
	v_mul_u32_u24_e32 v2, 0x210, v1                            // 0000001B4B24: 160402FF 00000210
	s_waitcnt lgkmcnt(0)                                       // 0000001B4B2C: BF89FC07
	s_load_b32 s4, s[18:19], null                              // 0000001B4B30: F4000109 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000001B4B38: 84928214
	s_add_u32 s5, s16, s18                                     // 0000001B4B3C: 80051210
	s_addc_u32 s8, s17, s19                                    // 0000001B4B40: 82081311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000001B4B44: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B4B48: BF870009
	s_add_u32 s5, s5, s20                                      // 0000001B4B4C: 80051405
	s_addc_u32 s8, s8, s21                                     // 0000001B4B50: 82081508
	s_waitcnt lgkmcnt(0)                                       // 0000001B4B54: BF89FC07
	s_mul_i32 s33, s4, 0x9000000                               // 0000001B4B58: 9621FF04 09000000
	s_mul_hi_i32 s15, s4, 0x9000000                            // 0000001B4B60: 970FFF04 09000000
	s_add_u32 s4, s5, s33                                      // 0000001B4B68: 80042105
	s_addc_u32 s5, s8, s15                                     // 0000001B4B6C: 82050F08
	s_lshl_b64 s[34:35], s[6:7], 2                             // 0000001B4B70: 84A28206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001B4B74: BF8700B9
	s_add_u32 s4, s4, s34                                      // 0000001B4B78: 80042204
	s_addc_u32 s5, s5, s35                                     // 0000001B4B7C: 82052305
	.long 0xd7000403                                           // 0000001B4B80: D7000403
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000001B4B84: 02020604
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 0000001B4B88: D5207C04 00110005
	s_mov_b32 s4, 0                                            // 0000001B4B90: BE840080
	s_nop 0                                                    // 0000001B4B94: BF800000
	s_nop 0                                                    // 0000001B4B98: BF800000
	s_nop 0                                                    // 0000001B4B9C: BF800000
	s_nop 0                                                    // 0000001B4BA0: BF800000
	s_nop 0                                                    // 0000001B4BA4: BF800000
	s_nop 0                                                    // 0000001B4BA8: BF800000
	s_nop 0                                                    // 0000001B4BAC: BF800000
	s_nop 0                                                    // 0000001B4BB0: BF800000
	s_nop 0                                                    // 0000001B4BB4: BF800000
	s_nop 0                                                    // 0000001B4BB8: BF800000
	s_nop 0                                                    // 0000001B4BBC: BF800000
	v_lshrrev_b32_e32 v8, 6, v5                                // 0000001B4BC0: 32100A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B4BC4: BF870121
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000001B4BC8: 300C1089
	v_lshl_add_u32 v8, v8, 2, v2                               // 0000001B4BCC: D6460008 04090508
	.long 0xd7006a06                                           // 0000001B4BD4: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000001B4BD8: 02020D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001B4BDC: BF8700D1
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000001B4BE0: D5207C07 01AA0880
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v5                        // 0000001B4BE8: 7C920AFF 00001F7F
	global_load_b32 v6, v[6:7], off                            // 0000001B4BF0: DC520000 067C0006
	v_add_nc_u32_e32 v7, 0x80, v5                              // 0000001B4BF8: 4A0E0AFF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 0000001B4C00: 8C04046A
	v_mov_b32_e32 v5, v7                                       // 0000001B4C04: 7E0A0307
	s_waitcnt vmcnt(0)                                         // 0000001B4C08: BF8903F7
	ds_store_b32 v8, v6                                        // 0000001B4C0C: D8340000 00000608
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001B4C14: 917E047E
	s_cbranch_execnz 65513                                     // 0000001B4C18: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001B4C1C: 8C7E047E
	s_load_b32 s58, s[0:1], 0x58                               // 0000001B4C20: F4000E80 F8000058
	v_or_b32_e32 v119, 0xffffff80, v0                          // 0000001B4C28: 38EE00FF FFFFFF80
	v_lshlrev_b32_e32 v5, 3, v0                                // 0000001B4C30: 300A0083
	v_lshlrev_b32_e32 v118, 2, v1                              // 0000001B4C34: 30EC0282
	v_mul_u32_u24_e32 v3, 0x210, v1                            // 0000001B4C38: 160602FF 00000210
	v_lshrrev_b32_e32 v4, 4, v0                                // 0000001B4C40: 32080084
	s_mov_b32 s4, 0                                            // 0000001B4C44: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000001B4C48: BF89FC07
	s_barrier                                                  // 0000001B4C4C: BFBD0000
	buffer_gl0_inv                                             // 0000001B4C50: E0AC0000 00000000
	s_cmp_gt_i32 s58, 0                                        // 0000001B4C58: BF02803A
	s_cbranch_scc1 14                                          // 0000001B4C5C: BFA2000E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	v_dual_mov_b32 v107, 0 :: v_dual_and_b32 v106, 0x200, v5   // 0000001B4C60: CA240080 6B6A0AFF 00000200
	v_mov_b32_e32 v1, s34                                      // 0000001B4C6C: 7E020222
	v_or_b32_e32 v6, 0xffffff80, v0                            // 0000001B4C70: 380C00FF FFFFFF80
	v_and_or_b32 v123, v4, 4, v3                               // 0000001B4C78: D657007B 040D0904
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B4C80: BF870004
	v_dual_mov_b32 v129, v107 :: v_dual_mov_b32 v2, s35        // 0000001B4C84: CA10016B 81020023
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 0000001B4C8C: 916A047E
	s_cbranch_vccz 1                                           // 0000001B4C90: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	s_branch 8093                                              // 0000001B4C94: BFA01F9D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x800c>
	s_clause 0x2                                               // 0000001B4C98: BF850002
	s_load_b256 s[24:31], s[0:1], 0x60                         // 0000001B4C9C: F40C0600 F8000060
	s_load_b64 s[56:57], s[0:1], null                          // 0000001B4CA4: F4040E00 F8000000
	s_load_b128 s[52:55], s[0:1], 0x18                         // 0000001B4CAC: F4080D00 F8000018
	s_lshl_b64 s[8:9], s[2:3], 2                               // 0000001B4CB4: 84888202
	s_mul_hi_i32 s10, s2, 0x55555556                           // 0000001B4CB8: 970AFF02 55555556
	v_dual_mov_b32 v107, 0 :: v_dual_lshlrev_b32 v2, 2, v0     // 0000001B4CC0: CA220080 6B020082
	v_lshlrev_b32_e32 v6, 1, v0                                // 0000001B4CC8: 300C0081
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000001B4CCC: 32020085
	v_bfe_u32 v7, v0, 4, 1                                     // 0000001B4CD0: D6100007 02050900
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B4CD8: BF870004
	v_or_b32_e32 v120, 0xf000, v2                              // 0000001B4CDC: 38F004FF 0000F000
	v_add_nc_u32_e32 v121, 0xf100, v2                          // 0000001B4CE4: 4AF204FF 0000F100
	v_mov_b32_e32 v129, v107                                   // 0000001B4CEC: 7F02036B
	v_mul_u32_u24_e32 v8, 0x2100, v1                           // 0000001B4CF0: 161002FF 00002100
	s_load_b256 s[44:51], s[0:1], 0x80                         // 0000001B4CF8: F40C0B00 F8000080
	s_mov_b32 s13, 0xcc00                                      // 0000001B4D00: BE8D00FF 0000CC00
	s_load_b64 s[0:1], s[0:1], 0xa0                            // 0000001B4D08: F4040000 F80000A0
	v_and_b32_e32 v106, 0x200, v5                              // 0000001B4D10: 36D40AFF 00000200
	.long 0xd44c0004                                           // 0000001B4D18: D44C0004
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 0000001B4D1C: 020200C0
	.long 0xd4490005                                           // 0000001B4D20: D4490005
	v_cndmask_b32_e32 v1, 63, v0, vcc_lo                       // 0000001B4D24: 020200BF
	v_and_or_b32 v123, v4, 4, v3                               // 0000001B4D28: D657007B 040D0904
	s_waitcnt lgkmcnt(0)                                       // 0000001B4D30: BF89FC07
	s_add_u32 s59, s30, s8                                     // 0000001B4D34: 803B081E
	s_addc_u32 s60, s31, s9                                    // 0000001B4D38: 823C091F
	s_lshr_b32 s9, s10, 31                                     // 0000001B4D3C: 85099F0A
	s_add_i32 s8, s58, 63                                      // 0000001B4D40: 8108BF3A
	s_add_i32 s10, s10, s9                                     // 0000001B4D44: 810A090A
	s_add_i32 s62, s58, -1                                     // 0000001B4D48: 813EC13A
	s_lshr_b32 s63, s8, 6                                      // 0000001B4D4C: 853F8608
	s_lshl_b32 s8, s10, 7                                      // 0000001B4D50: 8408870A
	s_mul_i32 s10, s62, 0x5000                                 // 0000001B4D54: 960AFF3E 00005000
	s_add_i32 s61, s2, 0xbd0                                   // 0000001B4D5C: 813DFF02 00000BD0
	s_mul_hi_u32 s11, s62, 0x5000                              // 0000001B4D64: 968BFF3E 00005000
	s_ashr_i32 s9, s8, 31                                      // 0000001B4D6C: 86099F08
	s_add_u32 s10, s56, s10                                    // 0000001B4D70: 800A0A38
	s_addc_u32 s11, s57, s11                                   // 0000001B4D74: 820B0B39
	s_lshl_b64 s[30:31], s[8:9], 1                             // 0000001B4D78: 849E8108
	s_mul_hi_u32 s8, s62, 0xc0                                 // 0000001B4D7C: 9688FF3E 000000C0
	s_add_u32 s9, s10, s30                                     // 0000001B4D84: 80091E0A
	s_addc_u32 s10, s11, s31                                   // 0000001B4D88: 820A1F0B
	.long 0xd7000902                                           // 0000001B4D8C: D7000902
	v_cndmask_b32_e32 v1, s9, v6, vcc_lo                       // 0000001B4D90: 02020C09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001B4D94: BF8700B1
	v_add_co_ci_u32_e64 v6, null, s10, 0, s9                   // 0000001B4D98: D5207C06 0025000A
	s_mul_i32 s9, s62, 0xc0                                    // 0000001B4DA0: 9609FF3E 000000C0
	.long 0xd7006a7a                                           // 0000001B4DA8: D7006A7A
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 0000001B4DAC: 020204FF 00001000
	v_add_co_ci_u32_e64 v124, null, 0, v6, vcc_lo              // 0000001B4DB4: D5207C7C 01AA0C80
	v_dual_mov_b32 v141, 0xf004 :: v_dual_lshlrev_b32 v2, 4, v1// 0000001B4DBC: CA2200FF 8D020284 0000F004
	v_dual_mov_b32 v143, 0xf014 :: v_dual_and_b32 v6, 15, v0   // 0000001B4DC8: CA2400FF 8F06008F 0000F014
	s_add_u32 s64, s59, s9                                     // 0000001B4DD4: 8040093B
	s_addc_u32 s65, s60, s8                                    // 0000001B4DD8: 8241083C
	s_add_u32 s11, s54, s34                                    // 0000001B4DDC: 800B2236
	s_addc_u32 s12, s55, s35                                   // 0000001B4DE0: 820C2337
	s_lshl_b32 s8, s2, 7                                       // 0000001B4DE4: 84088702
	v_or_b32_e32 v126, v2, v6                                  // 0000001B4DE8: 38FC0D02
	v_or_b32_e32 v130, v2, v7                                  // 0000001B4DEC: 39040F02
	v_mad_u32_u24 v2, 0x210, v6, v8                            // 0000001B4DF0: D60B0002 04220CFF 00000210
	s_ashr_i32 s9, s8, 31                                      // 0000001B4DFC: 86099F08
	v_dual_mov_b32 v145, 0xf024 :: v_dual_lshlrev_b32 v8, 2, v6// 0000001B4E00: CA2200FF 91080C82 0000F024
	s_lshl_b64 s[8:9], s[8:9], 1                               // 0000001B4E0C: 84888108
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001B4E10: BF870002
	v_lshl_or_b32 v133, v7, 2, v2                              // 0000001B4E14: D6560085 04090507
	s_add_u32 s8, s22, s8                                      // 0000001B4E1C: 80080816
	v_dual_mov_b32 v147, 0xf034 :: v_dual_lshlrev_b32 v2, 7, v126// 0000001B4E20: CA2200FF 9302FC87 0000F034
	s_addc_u32 s9, s23, s9                                     // 0000001B4E2C: 82090917
	s_lshl_b64 s[6:7], s[6:7], 1                               // 0000001B4E30: 84868106
	v_mad_u32_u24 v128, 0x90, v6, s13                          // 0000001B4E34: D60B0080 00360CFF 00000090
	s_add_u32 s8, s8, s6                                       // 0000001B4E40: 80080608
	.long 0xd7000686                                           // 0000001B4E44: D7000686
	v_cndmask_b32_e32 v1, s11, v8, vcc_lo                      // 0000001B4E48: 0202100B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4E4C: BF870001
	v_add_co_ci_u32_e64 v135, null, s12, 0, s6                 // 0000001B4E50: D5207C87 0019000C
	.long 0xd7000689                                           // 0000001B4E58: D7000689
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 0000001B4E5C: 0202041C
	v_dual_mov_b32 v149, 0xf044 :: v_dual_lshlrev_b32 v2, 1, v6// 0000001B4E60: CA2200FF 95020C81 0000F044
	s_addc_u32 s9, s9, s7                                      // 0000001B4E6C: 82090709
	v_mad_u32_u24 v131, 0x900, v1, v128                        // 0000001B4E70: D60B0083 060202FF 00000900
	v_add_co_ci_u32_e64 v138, null, s29, 0, s6                 // 0000001B4E7C: D5207C8A 0019001D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B4E84: BF870093
	.long 0xd700086c                                           // 0000001B4E88: D700086C
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000001B4E8C: 02020408
	v_add_co_ci_u32_e64 v109, null, s9, 0, s8                  // 0000001B4E90: D5207C6D 00210009
	s_add_u32 s8, s34, s20                                     // 0000001B4E98: 80081422
	.long 0xd44d0006                                           // 0000001B4E9C: D44D0006
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000001B4EA0: 02020280
	s_addc_u32 s9, s35, s21                                    // 0000001B4EA4: 82091523
	.long 0xd7000801                                           // 0000001B4EA8: D7000801
	v_cndmask_b32_e32 v1, s8, v106, vcc_lo                     // 0000001B4EAC: 0202D408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001B4EB0: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s9, 0, s8                    // 0000001B4EB4: D5207C02 00210009
	s_movk_i32 s10, 0x90                                       // 0000001B4EBC: B00A0090
	.long 0xd7006a01                                           // 0000001B4EC0: D7006A01
	v_cndmask_b32_e32 v1, v1, v118, vcc_lo                     // 0000001B4EC4: 0202ED01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000001B4EC8: D5207C02 01AA0480
	v_mad_u32_u24 v125, v0, s10, 0x8400                        // 0000001B4ED0: D60B007D 03FC1500 00008400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B4EDC: BF870093
	.long 0xd7006a6e                                           // 0000001B4EE0: D7006A6E
	v_cndmask_b32_e32 v1, s48, v1, vcc_lo                      // 0000001B4EE4: 02020230
	v_add_co_ci_u32_e64 v111, null, s49, v2, vcc_lo            // 0000001B4EE8: D5207C6F 01AA0431
	.long 0xd7006a70                                           // 0000001B4EF0: D7006A70
	v_cndmask_b32_e32 v1, s50, v1, vcc_lo                      // 0000001B4EF4: 02020232
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B4EF8: BF870001
	v_add_co_ci_u32_e64 v113, null, s51, v2, vcc_lo            // 0000001B4EFC: D5207C71 01AA0433
	.long 0xd7006a72                                           // 0000001B4F04: D7006A72
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 0000001B4F08: 02020200
	v_mul_u32_u24_e32 v127, 0x210, v6                          // 0000001B4F0C: 16FE0CFF 00000210
	v_mad_u32_u24 v132, v6, s10, 0x8400                        // 0000001B4F14: D60B0084 03FC1506 00008400
	v_lshl_add_u32 v136, v130, 1, v128                         // 0000001B4F20: D6460088 06010382
	.long 0xd4490007                                           // 0000001B4F28: D4490007
	v_cndmask_b32_e32 v1, 0x5f, v0, vcc_lo                     // 0000001B4F2C: 020200FF 0000005F
	v_lshl_or_b32 v139, v130, 2, 0xf100                        // 0000001B4F34: D656008B 03FD0582 0000F100
	v_add_co_ci_u32_e64 v115, null, s1, v2, vcc_lo             // 0000001B4F40: D5207C73 01AA0401
	v_dual_mov_b32 v151, 0xf054 :: v_dual_lshlrev_b32 v140, 1, v0// 0000001B4F48: CA2200FF 978C0081 0000F054
	v_mov_b32_e32 v142, 0xf00c                                 // 0000001B4F54: 7F1C02FF 0000F00C
	v_mov_b32_e32 v144, 0xf01c                                 // 0000001B4F5C: 7F2002FF 0000F01C
	v_mov_b32_e32 v146, 0xf02c                                 // 0000001B4F64: 7F2402FF 0000F02C
	v_mov_b32_e32 v148, 0xf03c                                 // 0000001B4F6C: 7F2802FF 0000F03C
	v_mov_b32_e32 v150, 0xf04c                                 // 0000001B4F74: 7F2C02FF 0000F04C
	v_mov_b32_e32 v152, 0xf05c                                 // 0000001B4F7C: 7F3002FF 0000F05C
	v_mov_b32_e32 v153, 0xf064                                 // 0000001B4F84: 7F3202FF 0000F064
	v_mov_b32_e32 v154, 0xf06c                                 // 0000001B4F8C: 7F3402FF 0000F06C
	v_mov_b32_e32 v155, 0xf074                                 // 0000001B4F94: 7F3602FF 0000F074
	v_mov_b32_e32 v156, 0xf07c                                 // 0000001B4F9C: 7F3802FF 0000F07C
	v_mov_b32_e32 v157, 0xf084                                 // 0000001B4FA4: 7F3A02FF 0000F084
	v_mov_b32_e32 v158, 0xf08c                                 // 0000001B4FAC: 7F3C02FF 0000F08C
	v_mov_b32_e32 v159, 0xf094                                 // 0000001B4FB4: 7F3E02FF 0000F094
	v_mov_b32_e32 v160, 0xf09c                                 // 0000001B4FBC: 7F4002FF 0000F09C
	v_mov_b32_e32 v161, 0xf0a4                                 // 0000001B4FC4: 7F4202FF 0000F0A4
	v_mov_b32_e32 v162, 0xf0ac                                 // 0000001B4FCC: 7F4402FF 0000F0AC
	v_mov_b32_e32 v163, 0xf0b4                                 // 0000001B4FD4: 7F4602FF 0000F0B4
	v_mov_b32_e32 v164, 0xf0bc                                 // 0000001B4FDC: 7F4802FF 0000F0BC
	v_mov_b32_e32 v165, 0xf0c4                                 // 0000001B4FE4: 7F4A02FF 0000F0C4
	v_mov_b32_e32 v166, 0xf0cc                                 // 0000001B4FEC: 7F4C02FF 0000F0CC
	v_mov_b32_e32 v167, 0xf0d4                                 // 0000001B4FF4: 7F4E02FF 0000F0D4
	v_mov_b32_e32 v168, 0xf0dc                                 // 0000001B4FFC: 7F5002FF 0000F0DC
	v_mov_b32_e32 v169, 0xf0e4                                 // 0000001B5004: 7F5202FF 0000F0E4
	v_mov_b32_e32 v170, 0xf0ec                                 // 0000001B500C: 7F5402FF 0000F0EC
	v_mov_b32_e32 v171, 0xf0f4                                 // 0000001B5014: 7F5602FF 0000F0F4
	s_mov_b32 s36, 0                                           // 0000001B501C: BEA40080
	s_mov_b32 s22, 0x41800000                                  // 0000001B5020: BE9600FF 41800000
	s_mov_b32 s37, s36                                         // 0000001B5028: BEA50024
	s_mov_b32 s38, s36                                         // 0000001B502C: BEA60024
	s_mov_b32 s39, s36                                         // 0000001B5030: BEA70024
	s_mov_b32 s40, s36                                         // 0000001B5034: BEA80024
	s_mov_b32 s41, s36                                         // 0000001B5038: BEA90024
	s_mov_b32 s42, s36                                         // 0000001B503C: BEAA0024
	s_mov_b32 s43, s36                                         // 0000001B5040: BEAB0024
	s_mov_b32 s23, s36                                         // 0000001B5044: BE970024
	s_branch 4                                                 // 0000001B5048: BFA00004 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x55c>
	s_add_i32 s23, s23, 1                                      // 0000001B504C: 81178117
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5050: BF870009
	s_cmp_eq_u32 s23, s63                                      // 0000001B5054: BF063F17
	s_cbranch_scc1 7849                                        // 0000001B5058: BFA21EA9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8000>
	s_mul_i32 s0, s23, 0xc00                                   // 0000001B505C: 9600FF17 00000C00
	s_lshl_b32 s29, s23, 6                                     // 0000001B5064: 841D8617
	s_add_i32 s0, s61, s0                                      // 0000001B5068: 8100003D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001B506C: BF870499
	s_ashr_i32 s1, s0, 31                                      // 0000001B5070: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000001B5074: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5078: BF870009
	s_add_u32 s0, s52, s0                                      // 0000001B507C: 80000034
	s_addc_u32 s1, s53, s1                                     // 0000001B5080: 82010135
	global_load_b32 v1, v107, s[0:1]                           // 0000001B5084: DC520000 0100006B
	s_waitcnt vmcnt(0)                                         // 0000001B508C: BF8903F7
	v_readfirstlane_b32 s28, v1                                // 0000001B5090: 7E380501
	s_and_saveexec_b32 s0, s4                                  // 0000001B5094: BE802004
	s_cbranch_execz 69                                         // 0000001B5098: BFA50045 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6b0>
	v_or_b32_e32 v1, s29, v0                                   // 0000001B509C: 3802001D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B50A0: BF870091
	v_mad_u64_u32 v[1:2], null, v1, 48, s[2:3]                 // 0000001B50A4: D6FE7C01 00096101
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000001B50AC: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B50B0: BF870091
	.long 0xd73c0001                                           // 0000001B50B4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000001B50B8: 02020282
	.long 0xd7006a01                                           // 0000001B50BC: D7006A01
	v_cndmask_b32_e32 v1, s52, v1, vcc_lo                      // 0000001B50C0: 02020234
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001B50C4: BF8700C1
	v_add_co_ci_u32_e64 v2, null, s53, v2, vcc_lo              // 0000001B50C8: D5207C02 01AA0435
	global_load_b32 v1, v[1:2], off                            // 0000001B50D0: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001B50D8: BF8903F7
	v_sub_f32_e32 v2, s28, v1                                  // 0000001B50DC: 0804021C
	v_dual_mul_f32 v4, 0x3fb8aa3b, v1 :: v_dual_mul_f32 v3, 0x3fb8aa3b, v2// 0000001B50E0: C8C602FF 040204FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B50EC: BF8701A1
	v_rndne_f32_e32 v8, v4                                     // 0000001B50F0: 7E104704
	v_fma_f32 v7, 0x3fb8aa3b, v1, -v4                          // 0000001B50F4: D6130007 841202FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v2, -v3                          // 0000001B5100: D6130005 840E04FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 0000001B510C: 7E0C4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B5110: BF870191
	v_dual_sub_f32 v4, v4, v8 :: v_dual_sub_f32 v3, v3, v6     // 0000001B5114: C94A1104 04020D03
	v_fmac_f32_e32 v5, 0x32a5705f, v2                          // 0000001B511C: 560A04FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2                   // 0000001B5124: 7C3604FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B512C: BF8701B2
	v_add_f32_e32 v3, v3, v5                                   // 0000001B5130: 06060B03
	v_cvt_i32_f32_e32 v5, v6                                   // 0000001B5134: 7E0A1106
	v_cvt_i32_f32_e32 v6, v8                                   // 0000001B5138: 7E0C1108
	v_exp_f32_e32 v3, v3                                       // 0000001B513C: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B5140: BF870095
	.long 0xd71c0003                                           // 0000001B5144: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000001B5148: 02020B03
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 0000001B514C: 02060680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 0000001B5150: 7C3602FF C2CE8ED0
	v_fmac_f32_e32 v7, 0x32a5705f, v1                          // 0000001B5158: 560E02FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B5160: BF870091
	v_add_f32_e32 v4, v4, v7                                   // 0000001B5164: 06080F04
	v_exp_f32_e32 v4, v4                                       // 0000001B5168: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B516C: BF870095
	.long 0xd71c0004                                           // 0000001B5170: D71C0004
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000001B5174: 02020D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 0000001B5178: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2                   // 0000001B517C: 7C3C04FF 42B17218
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo               // 0000001B5184: 020406FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 0000001B518C: 7C3C02FF 42B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B5194: BF870004
	v_cndmask_b32_e32 v1, 0x7f800000, v4, vcc_lo               // 0000001B5198: 020208FF 7F800000
	ds_store_b32 v120, v2                                      // 0000001B51A0: D8340000 00000278
	ds_store_b32 v121, v1                                      // 0000001B51A8: D8340000 00000179
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001B51B0: 8C7E007E
	s_mul_i32 s0, s23, 0x140000                                // 0000001B51B4: 9600FF17 00140000
	s_sub_i32 s14, s58, s29                                    // 0000001B51BC: 818E1D3A
	s_mul_hi_u32 s1, s23, 0x140000                             // 0000001B51C0: 9681FF17 00140000
	s_add_u32 s0, s56, s0                                      // 0000001B51C8: 80000038
	s_addc_u32 s1, s57, s1                                     // 0000001B51CC: 82010139
	s_add_u32 s0, s0, s30                                      // 0000001B51D0: 80001E00
	s_addc_u32 s1, s1, s31                                     // 0000001B51D4: 82011F01
	.long 0xd7000011                                           // 0000001B51D8: D7000011
	v_cndmask_b32_e32 v1, s0, v140, vcc_lo                     // 0000001B51DC: 02031800
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B51E0: BF870001
	v_add_co_ci_u32_e64 v64, null, s1, 0, s0                   // 0000001B51E4: D5207C40 00010001
	s_mul_i32 s0, s23, 0x3000                                  // 0000001B51EC: 9600FF17 00003000
	s_mul_hi_u32 s1, s23, 0x3000                               // 0000001B51F4: 9681FF17 00003000
	s_add_u32 s48, s59, s0                                     // 0000001B51FC: 8030003B
	s_addc_u32 s47, s60, s1                                    // 0000001B5200: 822F013C
	.long 0xd7006a01                                           // 0000001B5204: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v17, vcc_lo                  // 0000001B5208: 020222FF 00001000
	s_cmp_gt_i32 s14, 0                                        // 0000001B5210: BF02800E
	v_add_co_ci_u32_e64 v2, null, 0, v64, vcc_lo               // 0000001B5214: D5207C02 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B521C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5220: BF870009
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001B5224: 8B007E6A
	s_cselect_b32 s9, s47, s65                                 // 0000001B5228: 9809412F
	s_cselect_b32 s8, s48, s64                                 // 0000001B522C: 98084030
	s_add_u32 s0, s48, 0xc0                                    // 0000001B5230: 8000FF30 000000C0
	s_addc_u32 s1, s47, 0                                      // 0000001B5238: 8201802F
	v_dual_cndmask_b32 v2, v124, v2 :: v_dual_cndmask_b32 v1, v122, v1// 0000001B523C: CA52057C 0200037A
	.long 0xd7006a04                                           // 0000001B5244: D7006A04
	v_cndmask_b32_e32 v1, 0x6000, v17, vcc_lo                  // 0000001B5248: 020222FF 00006000
	s_cmp_gt_i32 s14, 1                                        // 0000001B5250: BF02810E
	v_add_co_ci_u32_e64 v3, null, 0, v64, vcc_lo               // 0000001B5254: D5207C03 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B525C: 986A80C1
	global_load_d16_b16 v1, v[1:2], off                        // 0000001B5260: DC820000 017C0001
	s_and_b32 s10, vcc_lo, exec_lo                             // 0000001B5268: 8B0A7E6A
	s_cselect_b32 s11, s1, s65                                 // 0000001B526C: 980B4101
	s_cselect_b32 s10, s0, s64                                 // 0000001B5270: 980A4000
	s_add_u32 s0, s48, 0x180                                   // 0000001B5274: 8000FF30 00000180
	s_addc_u32 s1, s47, 0                                      // 0000001B527C: 8201802F
	v_dual_cndmask_b32 v3, v124, v3 :: v_dual_cndmask_b32 v2, v122, v4// 0000001B5280: CA52077C 0302097A
	.long 0xd7006a05                                           // 0000001B5288: D7006A05
	v_cndmask_b32_e32 v1, 0xb000, v17, vcc_lo                  // 0000001B528C: 020222FF 0000B000
	s_cmp_gt_i32 s14, 2                                        // 0000001B5294: BF02820E
	v_add_co_ci_u32_e64 v4, null, 0, v64, vcc_lo               // 0000001B5298: D5207C04 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B52A0: 986A80C1
	global_load_d16_b16 v2, v[2:3], off                        // 0000001B52A4: DC820000 027C0002
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001B52AC: 8B0C7E6A
	s_cselect_b32 s13, s1, s65                                 // 0000001B52B0: 980D4101
	s_cselect_b32 s12, s0, s64                                 // 0000001B52B4: 980C4000
	s_add_u32 s0, s48, 0x240                                   // 0000001B52B8: 8000FF30 00000240
	s_addc_u32 s1, s47, 0                                      // 0000001B52C0: 8201802F
	v_dual_cndmask_b32 v4, v124, v4 :: v_dual_cndmask_b32 v3, v122, v5// 0000001B52C4: CA52097C 04020B7A
	.long 0xd7006a06                                           // 0000001B52CC: D7006A06
	v_cndmask_b32_e32 v1, 0x10000, v17, vcc_lo                 // 0000001B52D0: 020222FF 00010000
	s_cmp_gt_i32 s14, 3                                        // 0000001B52D8: BF02830E
	v_add_co_ci_u32_e64 v5, null, 0, v64, vcc_lo               // 0000001B52DC: D5207C05 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B52E4: 986A80C1
	global_load_d16_b16 v3, v[3:4], off                        // 0000001B52E8: DC820000 037C0003
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B52F0: 8B317E6A
	s_cselect_b32 s50, s0, s64                                 // 0000001B52F4: 98324000
	.long 0xd7000008                                           // 0000001B52F8: D7000008
	v_cndmask_b32_e32 v1, 0x15000, v17, vcc_lo                 // 0000001B52FC: 020222FF 00015000
	s_cselect_b32 s51, s1, s65                                 // 0000001B5304: 98334101
	s_add_u32 s1, s48, 0x300                                   // 0000001B5308: 8001FF30 00000300
	v_add_co_ci_u32_e64 v7, null, 0, v64, s0                   // 0000001B5310: D5207C07 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5318: 8200802F
	s_cmp_gt_i32 s14, 4                                        // 0000001B531C: BF02840E
	v_dual_cndmask_b32 v5, v124, v5 :: v_dual_cndmask_b32 v4, v122, v6// 0000001B5320: CA520B7C 05040D7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5328: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B532C: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5330: 8B317E6A
	s_cselect_b32 s55, s0, s65                                 // 0000001B5334: 98374100
	.long 0xd7000009                                           // 0000001B5338: D7000009
	v_cndmask_b32_e32 v1, 0x1a000, v17, vcc_lo                 // 0000001B533C: 020222FF 0001A000
	s_cselect_b32 s54, s1, s64                                 // 0000001B5344: 98364001
	s_add_u32 s1, s48, 0x3c0                                   // 0000001B5348: 8001FF30 000003C0
	v_add_co_ci_u32_e64 v10, null, 0, v64, s0                  // 0000001B5350: D5207C0A 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5358: 8200802F
	s_cmp_gt_i32 s14, 5                                        // 0000001B535C: BF02850E
	v_dual_cndmask_b32 v7, v124, v7 :: v_dual_cndmask_b32 v6, v122, v8// 0000001B5360: CA520F7C 0706117A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5368: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B536C: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5370: 8B317E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001B5374: 98434100
	.long 0xd7000008                                           // 0000001B5378: D7000008
	v_cndmask_b32_e32 v1, 0x1f000, v17, vcc_lo                 // 0000001B537C: 020222FF 0001F000
	s_cselect_b32 s66, s1, s64                                 // 0000001B5384: 98424001
	s_add_u32 s1, s48, 0x480                                   // 0000001B5388: 8001FF30 00000480
	v_add_co_ci_u32_e64 v11, null, 0, v64, s0                  // 0000001B5390: D5207C0B 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5398: 8200802F
	s_cmp_gt_i32 s14, 6                                        // 0000001B539C: BF02860E
	v_dual_cndmask_b32 v10, v124, v10 :: v_dual_cndmask_b32 v9, v122, v9// 0000001B53A0: CA52157C 0A08137A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B53A8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B53AC: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B53B0: 8B317E6A
	s_cselect_b32 s69, s0, s65                                 // 0000001B53B4: 98454100
	.long 0xd700000d                                           // 0000001B53B8: D700000D
	v_cndmask_b32_e32 v1, 0x24000, v17, vcc_lo                 // 0000001B53BC: 020222FF 00024000
	s_cselect_b32 s68, s1, s64                                 // 0000001B53C4: 98444001
	s_add_u32 s49, s48, 0x540                                  // 0000001B53C8: 8031FF30 00000540
	v_add_co_ci_u32_e64 v14, null, 0, v64, s0                  // 0000001B53D0: D5207C0E 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B53D8: 8200802F
	s_cmp_gt_i32 s14, 7                                        // 0000001B53DC: BF02870E
	v_dual_cndmask_b32 v12, v124, v11 :: v_dual_cndmask_b32 v11, v122, v8// 0000001B53E0: CA52177C 0C0A117A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B53E8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B53EC: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001B53F0: 8B017E6A
	s_cselect_b32 s1, s0, s65                                  // 0000001B53F4: 98014100
	s_cselect_b32 s0, s49, s64                                 // 0000001B53F8: 98004031
	s_add_u32 s49, s48, 0x600                                  // 0000001B53FC: 8031FF30 00000600
	v_dual_cndmask_b32 v14, v124, v14 :: v_dual_cndmask_b32 v13, v122, v13// 0000001B5404: CA521D7C 0E0C1B7A
	s_addc_u32 s70, s47, 0                                     // 0000001B540C: 8246802F
	global_load_d16_b16 v8, v[4:5], off                        // 0000001B5410: DC820000 087C0004
	global_load_d16_b16 v7, v[6:7], off                        // 0000001B5418: DC820000 077C0006
	global_load_d16_b16 v6, v[9:10], off                       // 0000001B5420: DC820000 067C0009
	global_load_d16_b16 v5, v[11:12], off                      // 0000001B5428: DC820000 057C000B
	global_load_d16_b16 v4, v[13:14], off                      // 0000001B5430: DC820000 047C000D
	s_cmp_gt_i32 s14, 8                                        // 0000001B5438: BF02880E
	.long 0xd7006a09                                           // 0000001B543C: D7006A09
	v_cndmask_b32_e32 v1, 0x29000, v17, vcc_lo                 // 0000001B5440: 020222FF 00029000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B5448: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v64, vcc_lo              // 0000001B544C: D5207C0A 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5454: 986A80C1
	s_clause 0x7                                               // 0000001B5458: BF850007
	global_load_b32 v73, v107, s[8:9]                          // 0000001B545C: DC520000 4908006B
	global_load_b32 v71, v107, s[10:11]                        // 0000001B5464: DC520000 470A006B
	global_load_b32 v72, v107, s[12:13]                        // 0000001B546C: DC520000 480C006B
	global_load_b32 v67, v107, s[50:51]                        // 0000001B5474: DC520000 4332006B
	global_load_b32 v68, v107, s[54:55]                        // 0000001B547C: DC520000 4436006B
	global_load_b32 v69, v107, s[66:67]                        // 0000001B5484: DC520000 4542006B
	global_load_b32 v70, v107, s[68:69]                        // 0000001B548C: DC520000 4644006B
	global_load_b32 v66, v107, s[0:1]                          // 0000001B5494: DC520000 4200006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001B549C: 8B007E6A
	s_cselect_b32 s9, s70, s65                                 // 0000001B54A0: 98094146
	s_cselect_b32 s8, s49, s64                                 // 0000001B54A4: 98084031
	s_add_u32 s0, s48, 0x6c0                                   // 0000001B54A8: 8000FF30 000006C0
	s_addc_u32 s1, s47, 0                                      // 0000001B54B0: 8201802F
	v_dual_cndmask_b32 v10, v124, v10 :: v_dual_cndmask_b32 v9, v122, v9// 0000001B54B4: CA52157C 0A08137A
	.long 0xd7006a0c                                           // 0000001B54BC: D7006A0C
	v_cndmask_b32_e32 v1, 0x2e000, v17, vcc_lo                 // 0000001B54C0: 020222FF 0002E000
	s_cmp_gt_i32 s14, 9                                        // 0000001B54C8: BF02890E
	v_add_co_ci_u32_e64 v11, null, 0, v64, vcc_lo              // 0000001B54CC: D5207C0B 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B54D4: 986A80C1
	global_load_d16_b16 v9, v[9:10], off                       // 0000001B54D8: DC820000 097C0009
	s_and_b32 s10, vcc_lo, exec_lo                             // 0000001B54E0: 8B0A7E6A
	s_cselect_b32 s11, s1, s65                                 // 0000001B54E4: 980B4101
	s_cselect_b32 s10, s0, s64                                 // 0000001B54E8: 980A4000
	s_add_u32 s0, s48, 0x780                                   // 0000001B54EC: 8000FF30 00000780
	s_addc_u32 s1, s47, 0                                      // 0000001B54F4: 8201802F
	v_dual_cndmask_b32 v11, v124, v11 :: v_dual_cndmask_b32 v10, v122, v12// 0000001B54F8: CA52177C 0B0A197A
	.long 0xd7006a0d                                           // 0000001B5500: D7006A0D
	v_cndmask_b32_e32 v1, 0x33000, v17, vcc_lo                 // 0000001B5504: 020222FF 00033000
	s_cmp_gt_i32 s14, 10                                       // 0000001B550C: BF028A0E
	v_add_co_ci_u32_e64 v12, null, 0, v64, vcc_lo              // 0000001B5510: D5207C0C 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5518: 986A80C1
	global_load_d16_b16 v10, v[10:11], off                     // 0000001B551C: DC820000 0A7C000A
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001B5524: 8B0C7E6A
	s_cselect_b32 s13, s1, s65                                 // 0000001B5528: 980D4101
	s_cselect_b32 s12, s0, s64                                 // 0000001B552C: 980C4000
	s_add_u32 s0, s48, 0x840                                   // 0000001B5530: 8000FF30 00000840
	s_addc_u32 s1, s47, 0                                      // 0000001B5538: 8201802F
	v_dual_cndmask_b32 v12, v124, v12 :: v_dual_cndmask_b32 v11, v122, v13// 0000001B553C: CA52197C 0C0A1B7A
	.long 0xd7006a0e                                           // 0000001B5544: D7006A0E
	v_cndmask_b32_e32 v1, 0x38000, v17, vcc_lo                 // 0000001B5548: 020222FF 00038000
	s_cmp_gt_i32 s14, 11                                       // 0000001B5550: BF028B0E
	v_add_co_ci_u32_e64 v13, null, 0, v64, vcc_lo              // 0000001B5554: D5207C0D 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B555C: 986A80C1
	global_load_d16_b16 v11, v[11:12], off                     // 0000001B5560: DC820000 0B7C000B
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5568: 8B317E6A
	s_cselect_b32 s50, s0, s64                                 // 0000001B556C: 98324000
	.long 0xd7000010                                           // 0000001B5570: D7000010
	v_cndmask_b32_e32 v1, 0x3d000, v17, vcc_lo                 // 0000001B5574: 020222FF 0003D000
	s_cselect_b32 s51, s1, s65                                 // 0000001B557C: 98334101
	s_add_u32 s1, s48, 0x900                                   // 0000001B5580: 8001FF30 00000900
	v_add_co_ci_u32_e64 v15, null, 0, v64, s0                  // 0000001B5588: D5207C0F 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5590: 8200802F
	s_cmp_gt_i32 s14, 12                                       // 0000001B5594: BF028C0E
	v_dual_cndmask_b32 v13, v124, v13 :: v_dual_cndmask_b32 v12, v122, v14// 0000001B5598: CA521B7C 0D0C1D7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B55A0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B55A4: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B55A8: 8B317E6A
	s_cselect_b32 s55, s0, s65                                 // 0000001B55AC: 98374100
	.long 0xd7000012                                           // 0000001B55B0: D7000012
	v_cndmask_b32_e32 v1, 0x42000, v17, vcc_lo                 // 0000001B55B4: 020222FF 00042000
	s_cselect_b32 s54, s1, s64                                 // 0000001B55BC: 98364001
	s_add_u32 s1, s48, 0x9c0                                   // 0000001B55C0: 8001FF30 000009C0
	v_add_co_ci_u32_e64 v19, null, 0, v64, s0                  // 0000001B55C8: D5207C13 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B55D0: 8200802F
	s_cmp_gt_i32 s14, 13                                       // 0000001B55D4: BF028D0E
	v_dual_cndmask_b32 v15, v124, v15 :: v_dual_cndmask_b32 v14, v122, v16// 0000001B55D8: CA521F7C 0F0E217A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B55E0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B55E4: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B55E8: 8B317E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001B55EC: 98434100
	.long 0xd7000010                                           // 0000001B55F0: D7000010
	v_cndmask_b32_e32 v1, 0x47000, v17, vcc_lo                 // 0000001B55F4: 020222FF 00047000
	s_cselect_b32 s66, s1, s64                                 // 0000001B55FC: 98424001
	s_add_u32 s1, s48, 0xa80                                   // 0000001B5600: 8001FF30 00000A80
	v_add_co_ci_u32_e64 v20, null, 0, v64, s0                  // 0000001B5608: D5207C14 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5610: 8200802F
	s_cmp_gt_i32 s14, 14                                       // 0000001B5614: BF028E0E
	v_dual_cndmask_b32 v19, v124, v19 :: v_dual_cndmask_b32 v18, v122, v18// 0000001B5618: CA52277C 1312257A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5620: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5624: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5628: 8B317E6A
	s_cselect_b32 s69, s0, s65                                 // 0000001B562C: 98454100
	.long 0xd7000016                                           // 0000001B5630: D7000016
	v_cndmask_b32_e32 v1, 0x4c000, v17, vcc_lo                 // 0000001B5634: 020222FF 0004C000
	s_cselect_b32 s68, s1, s64                                 // 0000001B563C: 98444001
	s_add_u32 s49, s48, 0xb40                                  // 0000001B5640: 8031FF30 00000B40
	v_add_co_ci_u32_e64 v23, null, 0, v64, s0                  // 0000001B5648: D5207C17 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5650: 8200802F
	s_cmp_gt_i32 s14, 15                                       // 0000001B5654: BF028F0E
	v_cndmask_b32_e32 v21, v124, v20, vcc_lo                   // 0000001B5658: 022A297C
	v_cndmask_b32_e32 v20, v122, v16, vcc_lo                   // 0000001B565C: 0228217A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5660: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5664: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001B5668: 8B017E6A
	s_cselect_b32 s1, s0, s65                                  // 0000001B566C: 98014100
	s_cselect_b32 s0, s49, s64                                 // 0000001B5670: 98004031
	s_add_u32 s49, s48, 0xc00                                  // 0000001B5674: 8031FF30 00000C00
	v_dual_cndmask_b32 v23, v124, v23 :: v_dual_cndmask_b32 v22, v122, v22// 0000001B567C: CA522F7C 17162D7A
	s_addc_u32 s70, s47, 0                                     // 0000001B5684: 8246802F
	global_load_d16_b16 v16, v[12:13], off                     // 0000001B5688: DC820000 107C000C
	global_load_d16_b16 v15, v[14:15], off                     // 0000001B5690: DC820000 0F7C000E
	global_load_d16_b16 v14, v[18:19], off                     // 0000001B5698: DC820000 0E7C0012
	global_load_d16_b16 v12, v[20:21], off                     // 0000001B56A0: DC820000 0C7C0014
	global_load_d16_b16 v13, v[22:23], off                     // 0000001B56A8: DC820000 0D7C0016
	s_cmp_gt_i32 s14, 16                                       // 0000001B56B0: BF02900E
	.long 0xd7006a12                                           // 0000001B56B4: D7006A12
	v_cndmask_b32_e32 v1, 0x51000, v17, vcc_lo                 // 0000001B56B8: 020222FF 00051000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B56C0: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v64, vcc_lo              // 0000001B56C4: D5207C13 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B56CC: 986A80C1
	s_clause 0x7                                               // 0000001B56D0: BF850007
	global_load_b32 v78, v107, s[8:9]                          // 0000001B56D4: DC520000 4E08006B
	global_load_b32 v79, v107, s[10:11]                        // 0000001B56DC: DC520000 4F0A006B
	global_load_b32 v80, v107, s[12:13]                        // 0000001B56E4: DC520000 500C006B
	global_load_b32 v81, v107, s[50:51]                        // 0000001B56EC: DC520000 5132006B
	global_load_b32 v77, v107, s[54:55]                        // 0000001B56F4: DC520000 4D36006B
	global_load_b32 v74, v107, s[66:67]                        // 0000001B56FC: DC520000 4A42006B
	global_load_b32 v75, v107, s[68:69]                        // 0000001B5704: DC520000 4B44006B
	global_load_b32 v76, v107, s[0:1]                          // 0000001B570C: DC520000 4C00006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001B5714: 8B007E6A
	s_cselect_b32 s9, s70, s65                                 // 0000001B5718: 98094146
	s_cselect_b32 s8, s49, s64                                 // 0000001B571C: 98084031
	s_add_u32 s0, s48, 0xcc0                                   // 0000001B5720: 8000FF30 00000CC0
	s_addc_u32 s1, s47, 0                                      // 0000001B5728: 8201802F
	v_dual_cndmask_b32 v19, v124, v19 :: v_dual_cndmask_b32 v18, v122, v18// 0000001B572C: CA52277C 1312257A
	.long 0xd7006a15                                           // 0000001B5734: D7006A15
	v_cndmask_b32_e32 v1, 0x56000, v17, vcc_lo                 // 0000001B5738: 020222FF 00056000
	s_cmp_gt_i32 s14, 17                                       // 0000001B5740: BF02910E
	v_add_co_ci_u32_e64 v20, null, 0, v64, vcc_lo              // 0000001B5744: D5207C14 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B574C: 986A80C1
	global_load_d16_b16 v18, v[18:19], off                     // 0000001B5750: DC820000 127C0012
	s_and_b32 s10, vcc_lo, exec_lo                             // 0000001B5758: 8B0A7E6A
	s_cselect_b32 s11, s1, s65                                 // 0000001B575C: 980B4101
	s_cselect_b32 s10, s0, s64                                 // 0000001B5760: 980A4000
	s_add_u32 s0, s48, 0xd80                                   // 0000001B5764: 8000FF30 00000D80
	s_addc_u32 s1, s47, 0                                      // 0000001B576C: 8201802F
	v_dual_cndmask_b32 v20, v124, v20 :: v_dual_cndmask_b32 v19, v122, v21// 0000001B5770: CA52297C 14122B7A
	.long 0xd7006a16                                           // 0000001B5778: D7006A16
	v_cndmask_b32_e32 v1, 0x5b000, v17, vcc_lo                 // 0000001B577C: 020222FF 0005B000
	s_cmp_gt_i32 s14, 18                                       // 0000001B5784: BF02920E
	v_add_co_ci_u32_e64 v21, null, 0, v64, vcc_lo              // 0000001B5788: D5207C15 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5790: 986A80C1
	global_load_d16_b16 v19, v[19:20], off                     // 0000001B5794: DC820000 137C0013
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001B579C: 8B0C7E6A
	s_cselect_b32 s13, s1, s65                                 // 0000001B57A0: 980D4101
	s_cselect_b32 s12, s0, s64                                 // 0000001B57A4: 980C4000
	s_add_u32 s0, s48, 0xe40                                   // 0000001B57A8: 8000FF30 00000E40
	s_addc_u32 s1, s47, 0                                      // 0000001B57B0: 8201802F
	v_dual_cndmask_b32 v21, v124, v21 :: v_dual_cndmask_b32 v20, v122, v22// 0000001B57B4: CA522B7C 15142D7A
	.long 0xd7006a17                                           // 0000001B57BC: D7006A17
	v_cndmask_b32_e32 v1, 0x60000, v17, vcc_lo                 // 0000001B57C0: 020222FF 00060000
	s_cmp_gt_i32 s14, 19                                       // 0000001B57C8: BF02930E
	v_add_co_ci_u32_e64 v22, null, 0, v64, vcc_lo              // 0000001B57CC: D5207C16 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B57D4: 986A80C1
	global_load_d16_b16 v20, v[20:21], off                     // 0000001B57D8: DC820000 147C0014
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B57E0: 8B317E6A
	s_cselect_b32 s50, s0, s64                                 // 0000001B57E4: 98324000
	.long 0xd7000019                                           // 0000001B57E8: D7000019
	v_cndmask_b32_e32 v1, 0x65000, v17, vcc_lo                 // 0000001B57EC: 020222FF 00065000
	s_cselect_b32 s51, s1, s65                                 // 0000001B57F4: 98334101
	s_add_u32 s1, s48, 0xf00                                   // 0000001B57F8: 8001FF30 00000F00
	v_add_co_ci_u32_e64 v24, null, 0, v64, s0                  // 0000001B5800: D5207C18 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5808: 8200802F
	s_cmp_gt_i32 s14, 20                                       // 0000001B580C: BF02940E
	v_dual_cndmask_b32 v22, v124, v22 :: v_dual_cndmask_b32 v21, v122, v23// 0000001B5810: CA522D7C 16142F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5818: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B581C: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5820: 8B317E6A
	s_cselect_b32 s55, s0, s65                                 // 0000001B5824: 98374100
	.long 0xd700001a                                           // 0000001B5828: D700001A
	v_cndmask_b32_e32 v1, 0x6a000, v17, vcc_lo                 // 0000001B582C: 020222FF 0006A000
	s_cselect_b32 s54, s1, s64                                 // 0000001B5834: 98364001
	s_add_u32 s1, s48, 0xfc0                                   // 0000001B5838: 8001FF30 00000FC0
	v_add_co_ci_u32_e64 v27, null, 0, v64, s0                  // 0000001B5840: D5207C1B 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5848: 8200802F
	s_cmp_gt_i32 s14, 21                                       // 0000001B584C: BF02950E
	v_dual_cndmask_b32 v24, v124, v24 :: v_dual_cndmask_b32 v23, v122, v25// 0000001B5850: CA52317C 1816337A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5858: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B585C: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5860: 8B317E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001B5864: 98434100
	.long 0xd7000019                                           // 0000001B5868: D7000019
	v_cndmask_b32_e32 v1, 0x6f000, v17, vcc_lo                 // 0000001B586C: 020222FF 0006F000
	s_cselect_b32 s66, s1, s64                                 // 0000001B5874: 98424001
	s_add_u32 s1, s48, 0x1080                                  // 0000001B5878: 8001FF30 00001080
	v_add_co_ci_u32_e64 v28, null, 0, v64, s0                  // 0000001B5880: D5207C1C 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5888: 8200802F
	s_cmp_gt_i32 s14, 22                                       // 0000001B588C: BF02960E
	v_dual_cndmask_b32 v27, v124, v27 :: v_dual_cndmask_b32 v26, v122, v26// 0000001B5890: CA52377C 1B1A357A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5898: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B589C: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B58A0: 8B317E6A
	s_cselect_b32 s69, s0, s65                                 // 0000001B58A4: 98454100
	.long 0xd700001e                                           // 0000001B58A8: D700001E
	v_cndmask_b32_e32 v1, 0x74000, v17, vcc_lo                 // 0000001B58AC: 020222FF 00074000
	s_cselect_b32 s68, s1, s64                                 // 0000001B58B4: 98444001
	s_add_u32 s49, s48, 0x1140                                 // 0000001B58B8: 8031FF30 00001140
	v_add_co_ci_u32_e64 v31, null, 0, v64, s0                  // 0000001B58C0: D5207C1F 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B58C8: 8200802F
	s_cmp_gt_i32 s14, 23                                       // 0000001B58CC: BF02970E
	v_dual_cndmask_b32 v29, v124, v28 :: v_dual_cndmask_b32 v28, v122, v25// 0000001B58D0: CA52397C 1D1C337A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B58D8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B58DC: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001B58E0: 8B017E6A
	s_cselect_b32 s1, s0, s65                                  // 0000001B58E4: 98014100
	s_cselect_b32 s0, s49, s64                                 // 0000001B58E8: 98004031
	s_add_u32 s49, s48, 0x1200                                 // 0000001B58EC: 8031FF30 00001200
	v_dual_cndmask_b32 v31, v124, v31 :: v_dual_cndmask_b32 v30, v122, v30// 0000001B58F4: CA523F7C 1F1E3D7A
	s_addc_u32 s70, s47, 0                                     // 0000001B58FC: 8246802F
	global_load_d16_b16 v25, v[21:22], off                     // 0000001B5900: DC820000 197C0015
	global_load_d16_b16 v24, v[23:24], off                     // 0000001B5908: DC820000 187C0017
	global_load_d16_b16 v23, v[26:27], off                     // 0000001B5910: DC820000 177C001A
	global_load_d16_b16 v22, v[28:29], off                     // 0000001B5918: DC820000 167C001C
	global_load_d16_b16 v21, v[30:31], off                     // 0000001B5920: DC820000 157C001E
	s_cmp_gt_i32 s14, 24                                       // 0000001B5928: BF02980E
	.long 0xd7006a1a                                           // 0000001B592C: D7006A1A
	v_cndmask_b32_e32 v1, 0x79000, v17, vcc_lo                 // 0000001B5930: 020222FF 00079000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B5938: BF870001
	v_add_co_ci_u32_e64 v27, null, 0, v64, vcc_lo              // 0000001B593C: D5207C1B 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5944: 986A80C1
	s_clause 0x7                                               // 0000001B5948: BF850007
	global_load_b32 v89, v107, s[8:9]                          // 0000001B594C: DC520000 5908006B
	global_load_b32 v88, v107, s[10:11]                        // 0000001B5954: DC520000 580A006B
	global_load_b32 v84, v107, s[12:13]                        // 0000001B595C: DC520000 540C006B
	global_load_b32 v85, v107, s[50:51]                        // 0000001B5964: DC520000 5532006B
	global_load_b32 v86, v107, s[54:55]                        // 0000001B596C: DC520000 5636006B
	global_load_b32 v87, v107, s[66:67]                        // 0000001B5974: DC520000 5742006B
	global_load_b32 v83, v107, s[68:69]                        // 0000001B597C: DC520000 5344006B
	global_load_b32 v82, v107, s[0:1]                          // 0000001B5984: DC520000 5200006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001B598C: 8B007E6A
	s_cselect_b32 s9, s70, s65                                 // 0000001B5990: 98094146
	s_cselect_b32 s8, s49, s64                                 // 0000001B5994: 98084031
	s_add_u32 s0, s48, 0x12c0                                  // 0000001B5998: 8000FF30 000012C0
	s_addc_u32 s1, s47, 0                                      // 0000001B59A0: 8201802F
	v_dual_cndmask_b32 v27, v124, v27 :: v_dual_cndmask_b32 v26, v122, v26// 0000001B59A4: CA52377C 1B1A357A
	.long 0xd7006a1d                                           // 0000001B59AC: D7006A1D
	v_cndmask_b32_e32 v1, 0x7e000, v17, vcc_lo                 // 0000001B59B0: 020222FF 0007E000
	s_cmp_gt_i32 s14, 25                                       // 0000001B59B8: BF02990E
	v_add_co_ci_u32_e64 v28, null, 0, v64, vcc_lo              // 0000001B59BC: D5207C1C 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B59C4: 986A80C1
	global_load_d16_b16 v26, v[26:27], off                     // 0000001B59C8: DC820000 1A7C001A
	s_and_b32 s10, vcc_lo, exec_lo                             // 0000001B59D0: 8B0A7E6A
	s_cselect_b32 s11, s1, s65                                 // 0000001B59D4: 980B4101
	s_cselect_b32 s10, s0, s64                                 // 0000001B59D8: 980A4000
	s_add_u32 s0, s48, 0x1380                                  // 0000001B59DC: 8000FF30 00001380
	s_addc_u32 s1, s47, 0                                      // 0000001B59E4: 8201802F
	v_dual_cndmask_b32 v28, v124, v28 :: v_dual_cndmask_b32 v27, v122, v29// 0000001B59E8: CA52397C 1C1A3B7A
	.long 0xd7006a1e                                           // 0000001B59F0: D7006A1E
	v_cndmask_b32_e32 v1, 0x83000, v17, vcc_lo                 // 0000001B59F4: 020222FF 00083000
	s_cmp_gt_i32 s14, 26                                       // 0000001B59FC: BF029A0E
	v_add_co_ci_u32_e64 v29, null, 0, v64, vcc_lo              // 0000001B5A00: D5207C1D 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5A08: 986A80C1
	global_load_d16_b16 v27, v[27:28], off                     // 0000001B5A0C: DC820000 1B7C001B
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001B5A14: 8B0C7E6A
	s_cselect_b32 s13, s1, s65                                 // 0000001B5A18: 980D4101
	s_cselect_b32 s12, s0, s64                                 // 0000001B5A1C: 980C4000
	s_add_u32 s0, s48, 0x1440                                  // 0000001B5A20: 8000FF30 00001440
	s_addc_u32 s1, s47, 0                                      // 0000001B5A28: 8201802F
	v_dual_cndmask_b32 v29, v124, v29 :: v_dual_cndmask_b32 v28, v122, v30// 0000001B5A2C: CA523B7C 1D1C3D7A
	.long 0xd7006a1f                                           // 0000001B5A34: D7006A1F
	v_cndmask_b32_e32 v1, 0x88000, v17, vcc_lo                 // 0000001B5A38: 020222FF 00088000
	s_cmp_gt_i32 s14, 27                                       // 0000001B5A40: BF029B0E
	v_add_co_ci_u32_e64 v30, null, 0, v64, vcc_lo              // 0000001B5A44: D5207C1E 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5A4C: 986A80C1
	global_load_d16_b16 v28, v[28:29], off                     // 0000001B5A50: DC820000 1C7C001C
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5A58: 8B317E6A
	s_cselect_b32 s50, s0, s64                                 // 0000001B5A5C: 98324000
	.long 0xd7000021                                           // 0000001B5A60: D7000021
	v_cndmask_b32_e32 v1, 0x8d000, v17, vcc_lo                 // 0000001B5A64: 020222FF 0008D000
	s_cselect_b32 s51, s1, s65                                 // 0000001B5A6C: 98334101
	s_add_u32 s1, s48, 0x1500                                  // 0000001B5A70: 8001FF30 00001500
	v_add_co_ci_u32_e64 v32, null, 0, v64, s0                  // 0000001B5A78: D5207C20 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5A80: 8200802F
	s_cmp_gt_i32 s14, 28                                       // 0000001B5A84: BF029C0E
	v_dual_cndmask_b32 v30, v124, v30 :: v_dual_cndmask_b32 v29, v122, v31// 0000001B5A88: CA523D7C 1E1C3F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5A90: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5A94: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5A98: 8B317E6A
	s_cselect_b32 s55, s0, s65                                 // 0000001B5A9C: 98374100
	.long 0xd7000022                                           // 0000001B5AA0: D7000022
	v_cndmask_b32_e32 v1, 0x92000, v17, vcc_lo                 // 0000001B5AA4: 020222FF 00092000
	s_cselect_b32 s54, s1, s64                                 // 0000001B5AAC: 98364001
	s_add_u32 s1, s48, 0x15c0                                  // 0000001B5AB0: 8001FF30 000015C0
	v_add_co_ci_u32_e64 v35, null, 0, v64, s0                  // 0000001B5AB8: D5207C23 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5AC0: 8200802F
	s_cmp_gt_i32 s14, 29                                       // 0000001B5AC4: BF029D0E
	v_dual_cndmask_b32 v32, v124, v32 :: v_dual_cndmask_b32 v31, v122, v33// 0000001B5AC8: CA52417C 201E437A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5AD0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5AD4: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5AD8: 8B317E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001B5ADC: 98434100
	.long 0xd7000021                                           // 0000001B5AE0: D7000021
	v_cndmask_b32_e32 v1, 0x97000, v17, vcc_lo                 // 0000001B5AE4: 020222FF 00097000
	s_cselect_b32 s66, s1, s64                                 // 0000001B5AEC: 98424001
	s_add_u32 s1, s48, 0x1680                                  // 0000001B5AF0: 8001FF30 00001680
	v_add_co_ci_u32_e64 v36, null, 0, v64, s0                  // 0000001B5AF8: D5207C24 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5B00: 8200802F
	s_cmp_gt_i32 s14, 30                                       // 0000001B5B04: BF029E0E
	v_dual_cndmask_b32 v35, v124, v35 :: v_dual_cndmask_b32 v34, v122, v34// 0000001B5B08: CA52477C 2322457A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5B10: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5B14: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5B18: 8B317E6A
	s_cselect_b32 s69, s0, s65                                 // 0000001B5B1C: 98454100
	.long 0xd7000026                                           // 0000001B5B20: D7000026
	v_cndmask_b32_e32 v1, 0x9c000, v17, vcc_lo                 // 0000001B5B24: 020222FF 0009C000
	s_cselect_b32 s68, s1, s64                                 // 0000001B5B2C: 98444001
	s_add_u32 s49, s48, 0x1740                                 // 0000001B5B30: 8031FF30 00001740
	v_add_co_ci_u32_e64 v39, null, 0, v64, s0                  // 0000001B5B38: D5207C27 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5B40: 8200802F
	s_cmp_gt_i32 s14, 31                                       // 0000001B5B44: BF029F0E
	v_dual_cndmask_b32 v37, v124, v36 :: v_dual_cndmask_b32 v36, v122, v33// 0000001B5B48: CA52497C 2524437A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5B50: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5B54: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001B5B58: 8B017E6A
	s_cselect_b32 s1, s0, s65                                  // 0000001B5B5C: 98014100
	s_cselect_b32 s0, s49, s64                                 // 0000001B5B60: 98004031
	s_add_u32 s49, s48, 0x1800                                 // 0000001B5B64: 8031FF30 00001800
	v_dual_cndmask_b32 v39, v124, v39 :: v_dual_cndmask_b32 v38, v122, v38// 0000001B5B6C: CA524F7C 27264D7A
	s_addc_u32 s70, s47, 0                                     // 0000001B5B74: 8246802F
	global_load_d16_b16 v33, v[29:30], off                     // 0000001B5B78: DC820000 217C001D
	global_load_d16_b16 v32, v[31:32], off                     // 0000001B5B80: DC820000 207C001F
	global_load_d16_b16 v31, v[34:35], off                     // 0000001B5B88: DC820000 1F7C0022
	global_load_d16_b16 v29, v[36:37], off                     // 0000001B5B90: DC820000 1D7C0024
	global_load_d16_b16 v30, v[38:39], off                     // 0000001B5B98: DC820000 1E7C0026
	s_cmp_gt_i32 s14, 32                                       // 0000001B5BA0: BF02A00E
	.long 0xd7006a22                                           // 0000001B5BA4: D7006A22
	v_cndmask_b32_e32 v1, 0xa1000, v17, vcc_lo                 // 0000001B5BA8: 020222FF 000A1000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B5BB0: BF870001
	v_add_co_ci_u32_e64 v35, null, 0, v64, vcc_lo              // 0000001B5BB4: D5207C23 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5BBC: 986A80C1
	s_clause 0x7                                               // 0000001B5BC0: BF850007
	global_load_b32 v95, v107, s[8:9]                          // 0000001B5BC4: DC520000 5F08006B
	global_load_b32 v96, v107, s[10:11]                        // 0000001B5BCC: DC520000 600A006B
	global_load_b32 v97, v107, s[12:13]                        // 0000001B5BD4: DC520000 610C006B
	global_load_b32 v94, v107, s[50:51]                        // 0000001B5BDC: DC520000 5E32006B
	global_load_b32 v90, v107, s[54:55]                        // 0000001B5BE4: DC520000 5A36006B
	global_load_b32 v91, v107, s[66:67]                        // 0000001B5BEC: DC520000 5B42006B
	global_load_b32 v92, v107, s[68:69]                        // 0000001B5BF4: DC520000 5C44006B
	global_load_b32 v93, v107, s[0:1]                          // 0000001B5BFC: DC520000 5D00006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001B5C04: 8B007E6A
	s_cselect_b32 s9, s70, s65                                 // 0000001B5C08: 98094146
	s_cselect_b32 s8, s49, s64                                 // 0000001B5C0C: 98084031
	s_add_u32 s0, s48, 0x18c0                                  // 0000001B5C10: 8000FF30 000018C0
	s_addc_u32 s1, s47, 0                                      // 0000001B5C18: 8201802F
	v_dual_cndmask_b32 v35, v124, v35 :: v_dual_cndmask_b32 v34, v122, v34// 0000001B5C1C: CA52477C 2322457A
	.long 0xd7006a25                                           // 0000001B5C24: D7006A25
	v_cndmask_b32_e32 v1, 0xa6000, v17, vcc_lo                 // 0000001B5C28: 020222FF 000A6000
	s_cmp_gt_i32 s14, 33                                       // 0000001B5C30: BF02A10E
	v_add_co_ci_u32_e64 v36, null, 0, v64, vcc_lo              // 0000001B5C34: D5207C24 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5C3C: 986A80C1
	global_load_d16_b16 v34, v[34:35], off                     // 0000001B5C40: DC820000 227C0022
	s_and_b32 s10, vcc_lo, exec_lo                             // 0000001B5C48: 8B0A7E6A
	s_cselect_b32 s11, s1, s65                                 // 0000001B5C4C: 980B4101
	s_cselect_b32 s10, s0, s64                                 // 0000001B5C50: 980A4000
	s_add_u32 s0, s48, 0x1980                                  // 0000001B5C54: 8000FF30 00001980
	s_addc_u32 s1, s47, 0                                      // 0000001B5C5C: 8201802F
	v_dual_cndmask_b32 v36, v124, v36 :: v_dual_cndmask_b32 v35, v122, v37// 0000001B5C60: CA52497C 24224B7A
	.long 0xd7006a26                                           // 0000001B5C68: D7006A26
	v_cndmask_b32_e32 v1, 0xab000, v17, vcc_lo                 // 0000001B5C6C: 020222FF 000AB000
	s_cmp_gt_i32 s14, 34                                       // 0000001B5C74: BF02A20E
	v_add_co_ci_u32_e64 v37, null, 0, v64, vcc_lo              // 0000001B5C78: D5207C25 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5C80: 986A80C1
	global_load_d16_b16 v35, v[35:36], off                     // 0000001B5C84: DC820000 237C0023
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001B5C8C: 8B0C7E6A
	s_cselect_b32 s13, s1, s65                                 // 0000001B5C90: 980D4101
	s_cselect_b32 s12, s0, s64                                 // 0000001B5C94: 980C4000
	s_add_u32 s0, s48, 0x1a40                                  // 0000001B5C98: 8000FF30 00001A40
	s_addc_u32 s1, s47, 0                                      // 0000001B5CA0: 8201802F
	v_dual_cndmask_b32 v37, v124, v37 :: v_dual_cndmask_b32 v36, v122, v38// 0000001B5CA4: CA524B7C 25244D7A
	.long 0xd7006a27                                           // 0000001B5CAC: D7006A27
	v_cndmask_b32_e32 v1, 0xb0000, v17, vcc_lo                 // 0000001B5CB0: 020222FF 000B0000
	s_cmp_gt_i32 s14, 35                                       // 0000001B5CB8: BF02A30E
	v_add_co_ci_u32_e64 v38, null, 0, v64, vcc_lo              // 0000001B5CBC: D5207C26 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5CC4: 986A80C1
	global_load_d16_b16 v36, v[36:37], off                     // 0000001B5CC8: DC820000 247C0024
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5CD0: 8B317E6A
	s_cselect_b32 s50, s0, s64                                 // 0000001B5CD4: 98324000
	.long 0xd7000029                                           // 0000001B5CD8: D7000029
	v_cndmask_b32_e32 v1, 0xb5000, v17, vcc_lo                 // 0000001B5CDC: 020222FF 000B5000
	s_cselect_b32 s51, s1, s65                                 // 0000001B5CE4: 98334101
	s_add_u32 s1, s48, 0x1b00                                  // 0000001B5CE8: 8001FF30 00001B00
	v_add_co_ci_u32_e64 v40, null, 0, v64, s0                  // 0000001B5CF0: D5207C28 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5CF8: 8200802F
	s_cmp_gt_i32 s14, 36                                       // 0000001B5CFC: BF02A40E
	v_dual_cndmask_b32 v38, v124, v38 :: v_dual_cndmask_b32 v37, v122, v39// 0000001B5D00: CA524D7C 26244F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5D08: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5D0C: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5D10: 8B317E6A
	s_cselect_b32 s55, s0, s65                                 // 0000001B5D14: 98374100
	.long 0xd700002a                                           // 0000001B5D18: D700002A
	v_cndmask_b32_e32 v1, 0xba000, v17, vcc_lo                 // 0000001B5D1C: 020222FF 000BA000
	s_cselect_b32 s54, s1, s64                                 // 0000001B5D24: 98364001
	s_add_u32 s1, s48, 0x1bc0                                  // 0000001B5D28: 8001FF30 00001BC0
	v_add_co_ci_u32_e64 v43, null, 0, v64, s0                  // 0000001B5D30: D5207C2B 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5D38: 8200802F
	s_cmp_gt_i32 s14, 37                                       // 0000001B5D3C: BF02A50E
	v_dual_cndmask_b32 v40, v124, v40 :: v_dual_cndmask_b32 v39, v122, v41// 0000001B5D40: CA52517C 2826537A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5D48: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5D4C: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5D50: 8B317E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001B5D54: 98434100
	.long 0xd7000029                                           // 0000001B5D58: D7000029
	v_cndmask_b32_e32 v1, 0xbf000, v17, vcc_lo                 // 0000001B5D5C: 020222FF 000BF000
	s_cselect_b32 s66, s1, s64                                 // 0000001B5D64: 98424001
	s_add_u32 s1, s48, 0x1c80                                  // 0000001B5D68: 8001FF30 00001C80
	v_add_co_ci_u32_e64 v44, null, 0, v64, s0                  // 0000001B5D70: D5207C2C 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5D78: 8200802F
	s_cmp_gt_i32 s14, 38                                       // 0000001B5D7C: BF02A60E
	v_dual_cndmask_b32 v43, v124, v43 :: v_dual_cndmask_b32 v42, v122, v42// 0000001B5D80: CA52577C 2B2A557A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5D88: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5D8C: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5D90: 8B317E6A
	s_cselect_b32 s69, s0, s65                                 // 0000001B5D94: 98454100
	.long 0xd700002e                                           // 0000001B5D98: D700002E
	v_cndmask_b32_e32 v1, 0xc4000, v17, vcc_lo                 // 0000001B5D9C: 020222FF 000C4000
	s_cselect_b32 s68, s1, s64                                 // 0000001B5DA4: 98444001
	s_add_u32 s49, s48, 0x1d40                                 // 0000001B5DA8: 8031FF30 00001D40
	v_add_co_ci_u32_e64 v47, null, 0, v64, s0                  // 0000001B5DB0: D5207C2F 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5DB8: 8200802F
	s_cmp_gt_i32 s14, 39                                       // 0000001B5DBC: BF02A70E
	v_dual_cndmask_b32 v45, v124, v44 :: v_dual_cndmask_b32 v44, v122, v41// 0000001B5DC0: CA52597C 2D2C537A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5DC8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5DCC: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001B5DD0: 8B017E6A
	s_cselect_b32 s1, s0, s65                                  // 0000001B5DD4: 98014100
	s_cselect_b32 s0, s49, s64                                 // 0000001B5DD8: 98004031
	s_add_u32 s49, s48, 0x1e00                                 // 0000001B5DDC: 8031FF30 00001E00
	v_dual_cndmask_b32 v47, v124, v47 :: v_dual_cndmask_b32 v46, v122, v46// 0000001B5DE4: CA525F7C 2F2E5D7A
	s_addc_u32 s70, s47, 0                                     // 0000001B5DEC: 8246802F
	global_load_d16_b16 v41, v[37:38], off                     // 0000001B5DF0: DC820000 297C0025
	global_load_d16_b16 v40, v[39:40], off                     // 0000001B5DF8: DC820000 287C0027
	global_load_d16_b16 v39, v[42:43], off                     // 0000001B5E00: DC820000 277C002A
	global_load_d16_b16 v37, v[44:45], off                     // 0000001B5E08: DC820000 257C002C
	global_load_d16_b16 v38, v[46:47], off                     // 0000001B5E10: DC820000 267C002E
	s_cmp_gt_i32 s14, 40                                       // 0000001B5E18: BF02A80E
	.long 0xd7006a2a                                           // 0000001B5E1C: D7006A2A
	v_cndmask_b32_e32 v1, 0xc9000, v17, vcc_lo                 // 0000001B5E20: 020222FF 000C9000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B5E28: BF870001
	v_add_co_ci_u32_e64 v43, null, 0, v64, vcc_lo              // 0000001B5E2C: D5207C2B 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5E34: 986A80C1
	s_clause 0x7                                               // 0000001B5E38: BF850007
	global_load_b32 v105, v107, s[8:9]                         // 0000001B5E3C: DC520000 6908006B
	global_load_b32 v101, v107, s[10:11]                       // 0000001B5E44: DC520000 650A006B
	global_load_b32 v102, v107, s[12:13]                       // 0000001B5E4C: DC520000 660C006B
	global_load_b32 v103, v107, s[50:51]                       // 0000001B5E54: DC520000 6732006B
	global_load_b32 v104, v107, s[54:55]                       // 0000001B5E5C: DC520000 6836006B
	global_load_b32 v100, v107, s[66:67]                       // 0000001B5E64: DC520000 6442006B
	global_load_b32 v98, v107, s[68:69]                        // 0000001B5E6C: DC520000 6244006B
	global_load_b32 v99, v107, s[0:1]                          // 0000001B5E74: DC520000 6300006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001B5E7C: 8B007E6A
	s_cselect_b32 s9, s70, s65                                 // 0000001B5E80: 98094146
	s_cselect_b32 s8, s49, s64                                 // 0000001B5E84: 98084031
	s_add_u32 s0, s48, 0x1ec0                                  // 0000001B5E88: 8000FF30 00001EC0
	s_addc_u32 s1, s47, 0                                      // 0000001B5E90: 8201802F
	v_dual_cndmask_b32 v43, v124, v43 :: v_dual_cndmask_b32 v42, v122, v42// 0000001B5E94: CA52577C 2B2A557A
	.long 0xd7006a2d                                           // 0000001B5E9C: D7006A2D
	v_cndmask_b32_e32 v1, 0xce000, v17, vcc_lo                 // 0000001B5EA0: 020222FF 000CE000
	s_cmp_gt_i32 s14, 41                                       // 0000001B5EA8: BF02A90E
	v_add_co_ci_u32_e64 v44, null, 0, v64, vcc_lo              // 0000001B5EAC: D5207C2C 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5EB4: 986A80C1
	global_load_d16_b16 v42, v[42:43], off                     // 0000001B5EB8: DC820000 2A7C002A
	s_and_b32 s10, vcc_lo, exec_lo                             // 0000001B5EC0: 8B0A7E6A
	s_cselect_b32 s11, s1, s65                                 // 0000001B5EC4: 980B4101
	s_cselect_b32 s10, s0, s64                                 // 0000001B5EC8: 980A4000
	s_add_u32 s0, s48, 0x1f80                                  // 0000001B5ECC: 8000FF30 00001F80
	s_addc_u32 s1, s47, 0                                      // 0000001B5ED4: 8201802F
	v_dual_cndmask_b32 v44, v124, v44 :: v_dual_cndmask_b32 v43, v122, v45// 0000001B5ED8: CA52597C 2C2A5B7A
	.long 0xd7006a2e                                           // 0000001B5EE0: D7006A2E
	v_cndmask_b32_e32 v1, 0xd3000, v17, vcc_lo                 // 0000001B5EE4: 020222FF 000D3000
	s_cmp_gt_i32 s14, 42                                       // 0000001B5EEC: BF02AA0E
	v_add_co_ci_u32_e64 v45, null, 0, v64, vcc_lo              // 0000001B5EF0: D5207C2D 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5EF8: 986A80C1
	global_load_d16_b16 v43, v[43:44], off                     // 0000001B5EFC: DC820000 2B7C002B
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001B5F04: 8B0C7E6A
	s_cselect_b32 s13, s1, s65                                 // 0000001B5F08: 980D4101
	s_cselect_b32 s12, s0, s64                                 // 0000001B5F0C: 980C4000
	s_add_u32 s0, s48, 0x2040                                  // 0000001B5F10: 8000FF30 00002040
	s_addc_u32 s1, s47, 0                                      // 0000001B5F18: 8201802F
	v_dual_cndmask_b32 v45, v124, v45 :: v_dual_cndmask_b32 v44, v122, v46// 0000001B5F1C: CA525B7C 2D2C5D7A
	.long 0xd7006a2f                                           // 0000001B5F24: D7006A2F
	v_cndmask_b32_e32 v1, 0xd8000, v17, vcc_lo                 // 0000001B5F28: 020222FF 000D8000
	s_cmp_gt_i32 s14, 43                                       // 0000001B5F30: BF02AB0E
	v_add_co_ci_u32_e64 v46, null, 0, v64, vcc_lo              // 0000001B5F34: D5207C2E 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5F3C: 986A80C1
	global_load_d16_b16 v44, v[44:45], off                     // 0000001B5F40: DC820000 2C7C002C
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5F48: 8B317E6A
	s_cselect_b32 s50, s0, s64                                 // 0000001B5F4C: 98324000
	.long 0xd7000031                                           // 0000001B5F50: D7000031
	v_cndmask_b32_e32 v1, 0xdd000, v17, vcc_lo                 // 0000001B5F54: 020222FF 000DD000
	s_cselect_b32 s51, s1, s65                                 // 0000001B5F5C: 98334101
	s_add_u32 s1, s48, 0x2100                                  // 0000001B5F60: 8001FF30 00002100
	v_add_co_ci_u32_e64 v48, null, 0, v64, s0                  // 0000001B5F68: D5207C30 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5F70: 8200802F
	s_cmp_gt_i32 s14, 44                                       // 0000001B5F74: BF02AC0E
	v_dual_cndmask_b32 v46, v124, v46 :: v_dual_cndmask_b32 v45, v122, v47// 0000001B5F78: CA525D7C 2E2C5F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5F80: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5F84: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5F88: 8B317E6A
	s_cselect_b32 s55, s0, s65                                 // 0000001B5F8C: 98374100
	.long 0xd7000032                                           // 0000001B5F90: D7000032
	v_cndmask_b32_e32 v1, 0xe2000, v17, vcc_lo                 // 0000001B5F94: 020222FF 000E2000
	s_cselect_b32 s54, s1, s64                                 // 0000001B5F9C: 98364001
	s_add_u32 s1, s48, 0x21c0                                  // 0000001B5FA0: 8001FF30 000021C0
	v_add_co_ci_u32_e64 v51, null, 0, v64, s0                  // 0000001B5FA8: D5207C33 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5FB0: 8200802F
	s_cmp_gt_i32 s14, 45                                       // 0000001B5FB4: BF02AD0E
	v_dual_cndmask_b32 v48, v124, v48 :: v_dual_cndmask_b32 v47, v122, v49// 0000001B5FB8: CA52617C 302E637A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B5FC0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B5FC4: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B5FC8: 8B317E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001B5FCC: 98434100
	.long 0xd7000031                                           // 0000001B5FD0: D7000031
	v_cndmask_b32_e32 v1, 0xe7000, v17, vcc_lo                 // 0000001B5FD4: 020222FF 000E7000
	s_cselect_b32 s66, s1, s64                                 // 0000001B5FDC: 98424001
	s_add_u32 s1, s48, 0x2280                                  // 0000001B5FE0: 8001FF30 00002280
	v_add_co_ci_u32_e64 v52, null, 0, v64, s0                  // 0000001B5FE8: D5207C34 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B5FF0: 8200802F
	s_cmp_gt_i32 s14, 46                                       // 0000001B5FF4: BF02AE0E
	v_dual_cndmask_b32 v51, v124, v51 :: v_dual_cndmask_b32 v50, v122, v50// 0000001B5FF8: CA52677C 3332657A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B6000: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B6004: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B6008: 8B317E6A
	s_cselect_b32 s69, s0, s65                                 // 0000001B600C: 98454100
	.long 0xd7000036                                           // 0000001B6010: D7000036
	v_cndmask_b32_e32 v1, 0xec000, v17, vcc_lo                 // 0000001B6014: 020222FF 000EC000
	s_cselect_b32 s68, s1, s64                                 // 0000001B601C: 98444001
	s_add_u32 s49, s48, 0x2340                                 // 0000001B6020: 8031FF30 00002340
	v_add_co_ci_u32_e64 v55, null, 0, v64, s0                  // 0000001B6028: D5207C37 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B6030: 8200802F
	s_cmp_gt_i32 s14, 47                                       // 0000001B6034: BF02AF0E
	v_dual_cndmask_b32 v53, v124, v52 :: v_dual_cndmask_b32 v52, v122, v49// 0000001B6038: CA52697C 3534637A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B6040: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B6044: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001B6048: 8B017E6A
	s_cselect_b32 s1, s0, s65                                  // 0000001B604C: 98014100
	s_cselect_b32 s0, s49, s64                                 // 0000001B6050: 98004031
	s_add_u32 s49, s48, 0x2400                                 // 0000001B6054: 8031FF30 00002400
	v_dual_cndmask_b32 v55, v124, v55 :: v_dual_cndmask_b32 v54, v122, v54// 0000001B605C: CA526F7C 37366D7A
	s_addc_u32 s70, s47, 0                                     // 0000001B6064: 8246802F
	global_load_d16_b16 v49, v[45:46], off                     // 0000001B6068: DC820000 317C002D
	global_load_d16_b16 v48, v[47:48], off                     // 0000001B6070: DC820000 307C002F
	global_load_d16_b16 v47, v[50:51], off                     // 0000001B6078: DC820000 2F7C0032
	global_load_d16_b16 v46, v[52:53], off                     // 0000001B6080: DC820000 2E7C0034
	global_load_d16_b16 v45, v[54:55], off                     // 0000001B6088: DC820000 2D7C0036
	s_cmp_gt_i32 s14, 48                                       // 0000001B6090: BF02B00E
	.long 0xd7006a32                                           // 0000001B6094: D7006A32
	v_cndmask_b32_e32 v1, 0xf1000, v17, vcc_lo                 // 0000001B6098: 020222FF 000F1000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B60A0: BF870001
	v_add_co_ci_u32_e64 v51, null, 0, v64, vcc_lo              // 0000001B60A4: D5207C33 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B60AC: 986A80C1
	s_clause 0x7                                               // 0000001B60B0: BF850007
	global_load_b32 v197, v107, s[8:9]                         // 0000001B60B4: DC520000 C508006B
	global_load_b32 v198, v107, s[10:11]                       // 0000001B60BC: DC520000 C60A006B
	global_load_b32 v196, v107, s[12:13]                       // 0000001B60C4: DC520000 C40C006B
	global_load_b32 v192, v107, s[50:51]                       // 0000001B60CC: DC520000 C032006B
	global_load_b32 v193, v107, s[54:55]                       // 0000001B60D4: DC520000 C136006B
	global_load_b32 v194, v107, s[66:67]                       // 0000001B60DC: DC520000 C242006B
	global_load_b32 v195, v107, s[68:69]                       // 0000001B60E4: DC520000 C344006B
	global_load_b32 v191, v107, s[0:1]                         // 0000001B60EC: DC520000 BF00006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001B60F4: 8B007E6A
	s_cselect_b32 s9, s70, s65                                 // 0000001B60F8: 98094146
	s_cselect_b32 s8, s49, s64                                 // 0000001B60FC: 98084031
	s_add_u32 s0, s48, 0x24c0                                  // 0000001B6100: 8000FF30 000024C0
	s_addc_u32 s1, s47, 0                                      // 0000001B6108: 8201802F
	v_dual_cndmask_b32 v51, v124, v51 :: v_dual_cndmask_b32 v50, v122, v50// 0000001B610C: CA52677C 3332657A
	.long 0xd7006a35                                           // 0000001B6114: D7006A35
	v_cndmask_b32_e32 v1, 0xf6000, v17, vcc_lo                 // 0000001B6118: 020222FF 000F6000
	s_cmp_gt_i32 s14, 49                                       // 0000001B6120: BF02B10E
	v_add_co_ci_u32_e64 v52, null, 0, v64, vcc_lo              // 0000001B6124: D5207C34 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B612C: 986A80C1
	global_load_d16_b16 v50, v[50:51], off                     // 0000001B6130: DC820000 327C0032
	s_and_b32 s10, vcc_lo, exec_lo                             // 0000001B6138: 8B0A7E6A
	s_cselect_b32 s11, s1, s65                                 // 0000001B613C: 980B4101
	s_cselect_b32 s10, s0, s64                                 // 0000001B6140: 980A4000
	s_add_u32 s0, s48, 0x2580                                  // 0000001B6144: 8000FF30 00002580
	s_addc_u32 s1, s47, 0                                      // 0000001B614C: 8201802F
	v_dual_cndmask_b32 v52, v124, v52 :: v_dual_cndmask_b32 v51, v122, v53// 0000001B6150: CA52697C 34326B7A
	.long 0xd7006a36                                           // 0000001B6158: D7006A36
	v_cndmask_b32_e32 v1, 0xfb000, v17, vcc_lo                 // 0000001B615C: 020222FF 000FB000
	s_cmp_gt_i32 s14, 50                                       // 0000001B6164: BF02B20E
	v_add_co_ci_u32_e64 v53, null, 0, v64, vcc_lo              // 0000001B6168: D5207C35 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B6170: 986A80C1
	global_load_d16_b16 v51, v[51:52], off                     // 0000001B6174: DC820000 337C0033
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001B617C: 8B0C7E6A
	s_cselect_b32 s13, s1, s65                                 // 0000001B6180: 980D4101
	s_cselect_b32 s12, s0, s64                                 // 0000001B6184: 980C4000
	s_add_u32 s0, s48, 0x2640                                  // 0000001B6188: 8000FF30 00002640
	s_addc_u32 s1, s47, 0                                      // 0000001B6190: 8201802F
	v_dual_cndmask_b32 v53, v124, v53 :: v_dual_cndmask_b32 v52, v122, v54// 0000001B6194: CA526B7C 35346D7A
	.long 0xd7006a37                                           // 0000001B619C: D7006A37
	v_cndmask_b32_e32 v1, 0x100000, v17, vcc_lo                // 0000001B61A0: 020222FF 00100000
	s_cmp_gt_i32 s14, 51                                       // 0000001B61A8: BF02B30E
	v_add_co_ci_u32_e64 v54, null, 0, v64, vcc_lo              // 0000001B61AC: D5207C36 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B61B4: 986A80C1
	global_load_d16_b16 v52, v[52:53], off                     // 0000001B61B8: DC820000 347C0034
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B61C0: 8B317E6A
	s_cselect_b32 s50, s0, s64                                 // 0000001B61C4: 98324000
	.long 0xd7000039                                           // 0000001B61C8: D7000039
	v_cndmask_b32_e32 v1, 0x105000, v17, vcc_lo                // 0000001B61CC: 020222FF 00105000
	s_cselect_b32 s51, s1, s65                                 // 0000001B61D4: 98334101
	s_add_u32 s1, s48, 0x2700                                  // 0000001B61D8: 8001FF30 00002700
	v_add_co_ci_u32_e64 v56, null, 0, v64, s0                  // 0000001B61E0: D5207C38 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B61E8: 8200802F
	s_cmp_gt_i32 s14, 52                                       // 0000001B61EC: BF02B40E
	v_dual_cndmask_b32 v54, v124, v54 :: v_dual_cndmask_b32 v53, v122, v55// 0000001B61F0: CA526D7C 36346F7A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B61F8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B61FC: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B6200: 8B317E6A
	s_cselect_b32 s55, s0, s65                                 // 0000001B6204: 98374100
	.long 0xd700003a                                           // 0000001B6208: D700003A
	v_cndmask_b32_e32 v1, 0x10a000, v17, vcc_lo                // 0000001B620C: 020222FF 0010A000
	s_cselect_b32 s54, s1, s64                                 // 0000001B6214: 98364001
	s_add_u32 s1, s48, 0x27c0                                  // 0000001B6218: 8001FF30 000027C0
	v_add_co_ci_u32_e64 v59, null, 0, v64, s0                  // 0000001B6220: D5207C3B 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B6228: 8200802F
	s_cmp_gt_i32 s14, 53                                       // 0000001B622C: BF02B50E
	v_dual_cndmask_b32 v56, v124, v56 :: v_dual_cndmask_b32 v55, v122, v57// 0000001B6230: CA52717C 3836737A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B6238: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B623C: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B6240: 8B317E6A
	s_cselect_b32 s67, s0, s65                                 // 0000001B6244: 98434100
	.long 0xd7000039                                           // 0000001B6248: D7000039
	v_cndmask_b32_e32 v1, 0x10f000, v17, vcc_lo                // 0000001B624C: 020222FF 0010F000
	s_cselect_b32 s66, s1, s64                                 // 0000001B6254: 98424001
	s_add_u32 s1, s48, 0x2880                                  // 0000001B6258: 8001FF30 00002880
	v_add_co_ci_u32_e64 v60, null, 0, v64, s0                  // 0000001B6260: D5207C3C 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B6268: 8200802F
	s_cmp_gt_i32 s14, 54                                       // 0000001B626C: BF02B60E
	v_dual_cndmask_b32 v59, v124, v59 :: v_dual_cndmask_b32 v58, v122, v58// 0000001B6270: CA52777C 3B3A757A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B6278: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B627C: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B6280: 8B317E6A
	s_cselect_b32 s69, s0, s65                                 // 0000001B6284: 98454100
	.long 0xd700003e                                           // 0000001B6288: D700003E
	v_cndmask_b32_e32 v1, 0x114000, v17, vcc_lo                // 0000001B628C: 020222FF 00114000
	s_cselect_b32 s68, s1, s64                                 // 0000001B6294: 98444001
	s_add_u32 s49, s48, 0x2940                                 // 0000001B6298: 8031FF30 00002940
	v_add_co_ci_u32_e64 v63, null, 0, v64, s0                  // 0000001B62A0: D5207C3F 00028080
	s_addc_u32 s0, s47, 0                                      // 0000001B62A8: 8200802F
	s_cmp_gt_i32 s14, 55                                       // 0000001B62AC: BF02B70E
	v_dual_cndmask_b32 v61, v124, v60 :: v_dual_cndmask_b32 v60, v122, v57// 0000001B62B0: CA52797C 3D3C737A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B62B8: 986A80C1
	v_dual_cndmask_b32 v63, v124, v63 :: v_dual_cndmask_b32 v62, v122, v62// 0000001B62BC: CA527F7C 3F3E7D7A
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001B62C4: 8B017E6A
	global_load_d16_b16 v57, v[53:54], off                     // 0000001B62C8: DC820000 397C0035
	global_load_d16_b16 v56, v[55:56], off                     // 0000001B62D0: DC820000 387C0037
	global_load_d16_b16 v55, v[58:59], off                     // 0000001B62D8: DC820000 377C003A
	global_load_d16_b16 v53, v[60:61], off                     // 0000001B62E0: DC820000 357C003C
	global_load_d16_b16 v54, v[62:63], off                     // 0000001B62E8: DC820000 367C003E
	s_cselect_b32 s1, s0, s65                                  // 0000001B62F0: 98014100
	s_cselect_b32 s0, s49, s64                                 // 0000001B62F4: 98004031
	s_add_u32 s49, s48, 0x2a00                                 // 0000001B62F8: 8031FF30 00002A00
	.long 0xd7006a3a                                           // 0000001B6300: D7006A3A
	v_cndmask_b32_e32 v1, 0x119000, v17, vcc_lo                // 0000001B6304: 020222FF 00119000
	s_addc_u32 s70, s47, 0                                     // 0000001B630C: 8246802F
	s_cmp_gt_i32 s14, 56                                       // 0000001B6310: BF02B80E
	v_add_co_ci_u32_e64 v59, null, 0, v64, vcc_lo              // 0000001B6314: D5207C3B 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B631C: 986A80C1
	s_clause 0x7                                               // 0000001B6320: BF850007
	global_load_b32 v203, v107, s[8:9]                         // 0000001B6324: DC520000 CB08006B
	global_load_b32 v204, v107, s[10:11]                       // 0000001B632C: DC520000 CC0A006B
	global_load_b32 v205, v107, s[12:13]                       // 0000001B6334: DC520000 CD0C006B
	global_load_b32 v206, v107, s[50:51]                       // 0000001B633C: DC520000 CE32006B
	global_load_b32 v202, v107, s[54:55]                       // 0000001B6344: DC520000 CA36006B
	global_load_b32 v199, v107, s[66:67]                       // 0000001B634C: DC520000 C742006B
	global_load_b32 v200, v107, s[68:69]                       // 0000001B6354: DC520000 C844006B
	global_load_b32 v201, v107, s[0:1]                         // 0000001B635C: DC520000 C900006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001B6364: 8B007E6A
	v_dual_cndmask_b32 v59, v124, v59 :: v_dual_cndmask_b32 v58, v122, v58// 0000001B6368: CA52777C 3B3A757A
	s_cselect_b32 s1, s70, s65                                 // 0000001B6370: 98014146
	s_cselect_b32 s0, s49, s64                                 // 0000001B6374: 98004031
	s_add_u32 s8, s48, 0x2ac0                                  // 0000001B6378: 8008FF30 00002AC0
	.long 0xd7006a3d                                           // 0000001B6380: D7006A3D
	v_cndmask_b32_e32 v1, 0x11e000, v17, vcc_lo                // 0000001B6384: 020222FF 0011E000
	s_addc_u32 s9, s47, 0                                      // 0000001B638C: 8209802F
	v_add_co_ci_u32_e64 v60, null, 0, v64, vcc_lo              // 0000001B6390: D5207C3C 01AA8080
	s_cmp_gt_i32 s14, 57                                       // 0000001B6398: BF02B90E
	global_load_d16_b16 v58, v[58:59], off                     // 0000001B639C: DC820000 3A7C003A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B63A4: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B63A8: BF870009
	s_and_b32 s10, vcc_lo, exec_lo                             // 0000001B63AC: 8B0A7E6A
	v_dual_cndmask_b32 v60, v124, v60 :: v_dual_cndmask_b32 v59, v122, v61// 0000001B63B0: CA52797C 3C3A7B7A
	s_cselect_b32 s9, s9, s65                                  // 0000001B63B8: 98094109
	s_cselect_b32 s8, s8, s64                                  // 0000001B63BC: 98084008
	s_add_u32 s10, s48, 0x2b80                                 // 0000001B63C0: 800AFF30 00002B80
	.long 0xd7006a3e                                           // 0000001B63C8: D7006A3E
	v_cndmask_b32_e32 v1, 0x123000, v17, vcc_lo                // 0000001B63CC: 020222FF 00123000
	s_addc_u32 s11, s47, 0                                     // 0000001B63D4: 820B802F
	v_add_co_ci_u32_e64 v61, null, 0, v64, vcc_lo              // 0000001B63D8: D5207C3D 01AA8080
	s_cmp_gt_i32 s14, 58                                       // 0000001B63E0: BF02BA0E
	global_load_d16_b16 v59, v[59:60], off                     // 0000001B63E4: DC820000 3B7C003B
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B63EC: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B63F0: BF870009
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001B63F4: 8B0C7E6A
	v_dual_cndmask_b32 v61, v124, v61 :: v_dual_cndmask_b32 v60, v122, v62// 0000001B63F8: CA527B7C 3D3C7D7A
	s_cselect_b32 s11, s11, s65                                // 0000001B6400: 980B410B
	s_cselect_b32 s10, s10, s64                                // 0000001B6404: 980A400A
	s_add_u32 s12, s48, 0x2c40                                 // 0000001B6408: 800CFF30 00002C40
	.long 0xd7006a3e                                           // 0000001B6410: D7006A3E
	v_cndmask_b32_e32 v1, 0x128000, v17, vcc_lo                // 0000001B6414: 020222FF 00128000
	s_addc_u32 s13, s47, 0                                     // 0000001B641C: 820D802F
	v_add_co_ci_u32_e64 v63, null, 0, v64, vcc_lo              // 0000001B6420: D5207C3F 01AA8080
	s_cmp_gt_i32 s14, 59                                       // 0000001B6428: BF02BB0E
	global_load_d16_b16 v61, v[60:61], off                     // 0000001B642C: DC820000 3D7C003C
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B6434: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B6438: BF870009
	s_and_b32 s49, vcc_lo, exec_lo                             // 0000001B643C: 8B317E6A
	v_dual_cndmask_b32 v63, v124, v63 :: v_dual_cndmask_b32 v62, v122, v62// 0000001B6440: CA527F7C 3F3E7D7A
	s_cselect_b32 s13, s13, s65                                // 0000001B6448: 980D410D
	s_cselect_b32 s12, s12, s64                                // 0000001B644C: 980C400C
	s_add_u32 s49, s48, 0x2d00                                 // 0000001B6450: 8031FF30 00002D00
	.long 0xd7006a41                                           // 0000001B6458: D7006A41
	v_cndmask_b32_e32 v1, 0x12d000, v17, vcc_lo                // 0000001B645C: 020222FF 0012D000
	s_addc_u32 s50, s47, 0                                     // 0000001B6464: 8232802F
	v_add_co_ci_u32_e64 v116, null, 0, v64, vcc_lo             // 0000001B6468: D5207C74 01AA8080
	s_cmp_gt_i32 s14, 60                                       // 0000001B6470: BF02BC0E
	global_load_d16_b16 v60, v[62:63], off                     // 0000001B6474: DC820000 3C7C003E
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B647C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B6480: BF870009
	s_and_b32 s51, vcc_lo, exec_lo                             // 0000001B6484: 8B337E6A
	v_dual_cndmask_b32 v63, v124, v116 :: v_dual_cndmask_b32 v62, v122, v65// 0000001B6488: CA52E97C 3F3E837A
	s_cselect_b32 s51, s50, s65                                // 0000001B6490: 98334132
	s_cselect_b32 s50, s49, s64                                // 0000001B6494: 98324031
	s_add_u32 s49, s48, 0x2dc0                                 // 0000001B6498: 8031FF30 00002DC0
	.long 0xd7006a41                                           // 0000001B64A0: D7006A41
	v_cndmask_b32_e32 v1, 0x132000, v17, vcc_lo                // 0000001B64A4: 020222FF 00132000
	s_addc_u32 s54, s47, 0                                     // 0000001B64AC: 8236802F
	v_add_co_ci_u32_e64 v116, null, 0, v64, vcc_lo             // 0000001B64B0: D5207C74 01AA8080
	s_cmp_gt_i32 s14, 61                                       // 0000001B64B8: BF02BD0E
	global_load_d16_b16 v62, v[62:63], off                     // 0000001B64BC: DC820000 3E7C003E
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B64C4: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B64C8: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001B64CC: 8B377E6A
	v_dual_cndmask_b32 v117, v124, v116 :: v_dual_cndmask_b32 v116, v122, v65// 0000001B64D0: CA52E97C 7574837A
	s_cselect_b32 s55, s54, s65                                // 0000001B64D8: 98374136
	s_cselect_b32 s54, s49, s64                                // 0000001B64DC: 98364031
	s_add_u32 s49, s48, 0x2e80                                 // 0000001B64E0: 8031FF30 00002E80
	.long 0xd7006a41                                           // 0000001B64E8: D7006A41
	v_cndmask_b32_e32 v1, 0x137000, v17, vcc_lo                // 0000001B64EC: 020222FF 00137000
	s_addc_u32 s66, s47, 0                                     // 0000001B64F4: 8242802F
	v_add_co_ci_u32_e64 v172, null, 0, v64, vcc_lo             // 0000001B64F8: D5207CAC 01AA8080
	s_cmp_gt_i32 s14, 62                                       // 0000001B6500: BF02BE0E
	global_load_d16_b16 v63, v[116:117], off                   // 0000001B6504: DC820000 3F7C0074
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B650C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B6510: BF870009
	s_and_b32 s67, vcc_lo, exec_lo                             // 0000001B6514: 8B437E6A
	v_dual_cndmask_b32 v117, v124, v172 :: v_dual_cndmask_b32 v116, v122, v65// 0000001B6518: CA53597C 7574837A
	s_cselect_b32 s67, s66, s65                                // 0000001B6520: 98434142
	s_cselect_b32 s66, s49, s64                                // 0000001B6524: 98424031
	s_add_u32 s48, s48, 0x2f40                                 // 0000001B6528: 8030FF30 00002F40
	.long 0xd7006a11                                           // 0000001B6530: D7006A11
	v_cndmask_b32_e32 v1, 0x13c000, v17, vcc_lo                // 0000001B6534: 020222FF 0013C000
	s_addc_u32 s47, s47, 0                                     // 0000001B653C: 822F802F
	v_add_co_ci_u32_e64 v65, null, 0, v64, vcc_lo              // 0000001B6540: D5207C41 01AA8080
	s_cmp_gt_i32 s14, 63                                       // 0000001B6548: BF02BF0E
	global_load_d16_b16 v64, v[116:117], off                   // 0000001B654C: DC820000 407C0074
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001B6554: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B6558: BF870009
	s_and_b32 s14, vcc_lo, exec_lo                             // 0000001B655C: 8B0E7E6A
	v_cndmask_b32_e32 v117, v124, v65, vcc_lo                  // 0000001B6560: 02EA837C
	v_cndmask_b32_e32 v116, v122, v17, vcc_lo                  // 0000001B6564: 02E8237A
	s_cselect_b32 s49, s47, s65                                // 0000001B6568: 9831412F
	s_cselect_b32 s48, s48, s64                                // 0000001B656C: 98304030
	s_clause 0x7                                               // 0000001B6570: BF850007
	global_load_b32 v214, v107, s[0:1]                         // 0000001B6574: DC520000 D600006B
	global_load_b32 v213, v107, s[8:9]                         // 0000001B657C: DC520000 D508006B
	global_load_b32 v212, v107, s[10:11]                       // 0000001B6584: DC520000 D40A006B
	global_load_b32 v209, v107, s[12:13]                       // 0000001B658C: DC520000 D10C006B
	global_load_b32 v210, v107, s[50:51]                       // 0000001B6594: DC520000 D232006B
	global_load_b32 v211, v107, s[54:55]                       // 0000001B659C: DC520000 D336006B
	global_load_b32 v208, v107, s[66:67]                       // 0000001B65A4: DC520000 D042006B
	global_load_b32 v207, v107, s[48:49]                       // 0000001B65AC: DC520000 CF30006B
	global_load_d16_b16 v65, v[116:117], off                   // 0000001B65B4: DC820000 417C0074
	.long 0x7e223880                                           // 0000001B65BC: 7E223880
	s_cmp_gt_i32 s58, s29                                      // 0000001B65C0: BF021D3A
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001B65C4: BF890007
	s_barrier                                                  // 0000001B65C8: BFBD0000
	buffer_gl0_inv                                             // 0000001B65CC: E0AC0000 00000000
	s_cbranch_scc0 10                                          // 0000001B65D4: BFA1000A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x1b00>
	ds_load_b32 v17, v107 offset:61440                         // 0000001B65D8: D8D8F000 1100006B
	v_lshlrev_b32_e32 v1, 16, v1                               // 0000001B65E0: 30020290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001B65E4: BF8700A1
	v_mul_f32_e32 v1, v73, v1                                  // 0000001B65E8: 10020349
	s_waitcnt lgkmcnt(0)                                       // 0000001B65EC: BF89FC07
	v_mul_f32_e32 v1, v1, v17                                  // 0000001B65F0: 10022301
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B65F4: BF870001
	v_fma_mixlo_f16 v17, v1, s22, 0                            // 0000001B65F8: CC210011 02002D01
	v_lshlrev_b32_e32 v5, 16, v5                               // 0000001B6600: 300A0A90
	v_lshlrev_b32_e32 v1, 16, v2                               // 0000001B6604: 30020490
	s_or_b32 s0, s29, 1                                        // 0000001B6608: 8C00811D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B660C: BF870119
	s_cmp_lt_i32 s0, s58                                       // 0000001B6610: BF043A00
	v_mul_f32_e32 v70, v70, v5                                 // 0000001B6614: 108C0B46
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B6618: BF8701B2
	v_dual_mul_f32 v71, v71, v1 :: v_dual_lshlrev_b32 v2, 16, v3// 0000001B661C: C8E20347 47020690
	v_lshlrev_b32_e32 v3, 16, v8                               // 0000001B6624: 30061090
	v_lshlrev_b32_e32 v5, 16, v13                              // 0000001B6628: 300A1A90
	v_dual_mul_f32 v72, v72, v2 :: v_dual_lshlrev_b32 v1, 16, v7// 0000001B662C: C8E20548 48000E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B6634: BF8701A3
	v_dual_mul_f32 v67, v67, v3 :: v_dual_lshlrev_b32 v2, 16, v6// 0000001B6638: C8E20743 43020C90
	v_lshlrev_b32_e32 v8, 16, v23                              // 0000001B6640: 30102E90
	v_dual_mul_f32 v68, v68, v1 :: v_dual_lshlrev_b32 v1, 16, v4// 0000001B6644: C8E20344 44000890
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B664C: BF8701A3
	v_dual_mul_f32 v69, v69, v2 :: v_dual_lshlrev_b32 v4, 16, v16// 0000001B6650: C8E20545 45042090
	v_lshlrev_b32_e32 v2, 16, v10                              // 0000001B6658: 30041490
	v_dual_mul_f32 v66, v66, v1 :: v_dual_lshlrev_b32 v7, 16, v24// 0000001B665C: C8E20342 42063090
	v_lshlrev_b32_e32 v3, 16, v11                              // 0000001B6664: 30061690
	v_dual_mul_f32 v182, v87, v8 :: v_dual_lshlrev_b32 v1, 16, v9// 0000001B6668: C8E21157 B6001290
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B6670: BF870214
	v_dual_mul_f32 v73, v79, v2 :: v_dual_lshlrev_b32 v2, 16, v12// 0000001B6674: C8E2054F 49021890
	v_mul_f32_e32 v185, v86, v7                                // 0000001B667C: 11720F56
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001B6680: BF8701C3
	v_dual_mul_f32 v16, v78, v1 :: v_dual_lshlrev_b32 v1, 16, v15// 0000001B6684: C8E2034E 10001E90
	v_lshlrev_b32_e32 v7, 16, v27                              // 0000001B668C: 300E3690
	v_lshlrev_b32_e32 v8, 16, v28                              // 0000001B6690: 30103890
	v_dual_mul_f32 v78, v80, v3 :: v_dual_mul_f32 v3, v75, v2  // 0000001B6694: C8C60750 4E02054B
	v_dual_mul_f32 v15, v77, v1 :: v_dual_mul_f32 v180, v96, v7// 0000001B669C: C8C6034D 0FB40F60
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001B66A4: BF870253
	v_dual_mul_f32 v2, v76, v5 :: v_dual_mul_f32 v177, v97, v8 // 0000001B66A8: C8C60B4C 02B01161
	v_lshlrev_b32_e32 v8, 16, v30                              // 0000001B66B0: 30103C90
	v_lshlrev_b32_e32 v5, 16, v19                              // 0000001B66B4: 300A2690
	v_lshlrev_b32_e32 v7, 16, v29                              // 0000001B66B8: 300E3A90
	v_dual_mul_f32 v79, v81, v4 :: v_dual_lshlrev_b32 v10, 16, v63// 0000001B66BC: C8E20951 4F0A7E90
	v_mul_f32_e32 v176, v93, v8                                // 0000001B66C4: 1160115D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B66C8: BF870214
	v_dual_mul_f32 v189, v88, v5 :: v_dual_lshlrev_b32 v6, 16, v18// 0000001B66CC: C8E20B58 BD062490
	v_dual_mul_f32 v178, v92, v7 :: v_dual_lshlrev_b32 v5, 16, v20// 0000001B66D4: C8E20F5C B2042890
	v_lshlrev_b32_e32 v8, 16, v40                              // 0000001B66DC: 30105090
	v_lshlrev_b32_e32 v7, 16, v41                              // 0000001B66E0: 300E5290
	.long 0x7e12392d                                           // 0000001B66E4: 7E12392D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B66E8: BF870214
	v_dual_mul_f32 v190, v84, v5 :: v_dual_lshlrev_b32 v5, 16, v22// 0000001B66EC: C8E20B54 BE042C90
	v_dual_mul_f32 v104, v104, v8 :: v_dual_lshlrev_b32 v1, 16, v14// 0000001B66F4: C8E21168 68001C90
	s_cselect_b32 s0, -1, 0                                    // 0000001B66FC: 980080C1
	s_or_b32 s1, s29, 2                                        // 0000001B6700: 8C01821D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000001B6704: BF8701D2
	v_mul_f32_e32 v186, v83, v5                                // 0000001B6708: 11740B53
	v_lshlrev_b32_e32 v5, 16, v21                              // 0000001B670C: 300A2A90
	v_dual_mul_f32 v4, v74, v1 :: v_dual_mul_f32 v1, v89, v6   // 0000001B6710: C8C6034A 04000D59
	v_lshlrev_b32_e32 v6, 16, v25                              // 0000001B6718: 300C3290
	s_cmp_lt_i32 s1, s58                                       // 0000001B671C: BF043A01
	v_dual_mul_f32 v188, v82, v5 :: v_dual_lshlrev_b32 v13, 16, v64// 0000001B6720: C8E20B52 BC0C8090
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001B6728: BF870132
	v_mul_f32_e32 v187, v85, v6                                // 0000001B672C: 11760D55
	v_lshlrev_b32_e32 v6, 16, v26                              // 0000001B6730: 300C3490
	v_mul_f32_e32 v26, v211, v10                               // 0000001B6734: 103415D3
	v_dual_mul_f32 v183, v95, v6 :: v_dual_lshlrev_b32 v6, 16, v31// 0000001B6738: C8E20D5F B7063E90
	v_lshlrev_b32_e32 v8, 16, v43                              // 0000001B6740: 30105690
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B6744: BF870092
	v_dual_mul_f32 v179, v91, v6 :: v_dual_lshlrev_b32 v6, 16, v36// 0000001B6748: C8E20D5B B3064890
	v_mul_f32_e32 v173, v102, v6                               // 0000001B6750: 115A0D66
	v_lshlrev_b32_e32 v6, 16, v38                              // 0000001B6754: 300C4C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001B6758: BF870131
	v_dual_mul_f32 v117, v99, v6 :: v_dual_lshlrev_b32 v6, 16, v48// 0000001B675C: C8E20D63 75066090
	v_lshlrev_b32_e32 v5, 16, v33                              // 0000001B6764: 300A4290
	v_mul_f32_e32 v99, v198, v8                                // 0000001B6768: 10C611C6
	v_mul_f32_e32 v181, v94, v5                                // 0000001B676C: 116A0B5E
	v_lshlrev_b32_e32 v5, 16, v32                              // 0000001B6770: 300A4090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B6774: BF870121
	v_dual_mul_f32 v184, v90, v5 :: v_dual_lshlrev_b32 v5, 16, v34// 0000001B6778: C8E20B5A B8044490
	v_lshlrev_b32_e32 v8, 16, v46                              // 0000001B6780: 30105C90
	v_mul_f32_e32 v175, v105, v5                               // 0000001B6784: 115E0B69
	v_lshlrev_b32_e32 v5, 16, v35                              // 0000001B6788: 300A4690
	v_mul_f32_e32 v105, v103, v7                               // 0000001B678C: 10D20F67
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B6790: BF870194
	v_dual_mul_f32 v42, v195, v8 :: v_dual_lshlrev_b32 v7, 16, v42// 0000001B6794: C8E211C3 2A065490
	v_dual_mul_f32 v174, v101, v5 :: v_dual_add_nc_u32 v195, s29, v126// 0000001B679C: C8E00B65 AEC2FC1D
	v_lshlrev_b32_e32 v5, 16, v39                              // 0000001B67A4: 300A4E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B67A8: BF8701A3
	v_mul_f32_e32 v102, v197, v7                               // 0000001B67AC: 10CC0FC5
	v_lshlrev_b32_e32 v8, 16, v57                              // 0000001B67B0: 30107290
	v_mul_f32_e32 v116, v100, v5                               // 0000001B67B4: 10E80B64
	v_dual_mul_f32 v100, v193, v6 :: v_dual_lshlrev_b32 v5, 16, v37// 0000001B67B8: C8E20DC1 64044A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B67C0: BF8701A3
	v_dual_mul_f32 v27, v206, v8 :: v_dual_lshlrev_b32 v6, 16, v51// 0000001B67C4: C8E211CE 1B066690
	v_lshlrev_b32_e32 v8, 16, v58                              // 0000001B67CC: 30107490
	v_dual_mul_f32 v172, v98, v5 :: v_dual_lshlrev_b32 v5, 16, v44// 0000001B67D0: C8E20B62 AC045890
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B67D8: BF870193
	v_dual_mul_f32 v43, v204, v6 :: v_dual_lshlrev_b32 v6, 16, v53// 0000001B67DC: C8E20DCC 2B066A90
	v_dual_mul_f32 v25, v214, v8 :: v_dual_lshlrev_b32 v8, 16, v61// 0000001B67E4: C8E211D6 19087A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B67EC: BF870223
	v_mul_f32_e32 v103, v196, v5                               // 0000001B67F0: 10CE0BC4
	v_lshlrev_b32_e32 v5, 16, v49                              // 0000001B67F4: 300A6290
	v_mul_f32_e32 v29, v200, v6                                // 0000001B67F8: 103A0DC8
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001B67FC: BF870132
	v_mul_f32_e32 v101, v192, v5                               // 0000001B6800: 10CA0BC0
	v_lshlrev_b32_e32 v5, 16, v9                               // 0000001B6804: 300A1290
	v_lshlrev_b32_e32 v9, 16, v62                              // 0000001B6808: 30127C90
	v_mul_f32_e32 v49, v191, v5                                // 0000001B680C: 10620BBF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001B6810: BF870002
	v_mul_f32_e32 v30, v210, v9                                // 0000001B6814: 103C13D2
	ds_load_2addr_b32 v[9:10], v143 offset1:1                  // 0000001B6818: D8DC0100 0900008F
	ds_load_2addr_b32 v[11:12], v144 offset1:1                 // 0000001B6820: D8DC0100 0B000090
	v_lshlrev_b32_e32 v5, 16, v50                              // 0000001B6828: 300A6490
	v_lshlrev_b32_e32 v7, 16, v47                              // 0000001B682C: 300E5E90
	v_mul_f32_e32 v47, v212, v8                                // 0000001B6830: 105E11D4
	v_mul_f32_e32 v50, v208, v13                               // 0000001B6834: 10641BD0
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B6838: BF870003
	v_dual_mul_f32 v48, v203, v5 :: v_dual_mul_f32 v45, v194, v7// 0000001B683C: C8C60BCB 302C0FC2
	v_lshlrev_b32_e32 v5, 16, v56                              // 0000001B6844: 300A7090
	v_lshlrev_b32_e32 v7, 16, v52                              // 0000001B6848: 300E6890
	ds_load_2addr_b32 v[191:192], v151 offset1:1               // 0000001B684C: D8DC0100 BF000097
	ds_load_2addr_b32 v[193:194], v152 offset1:1               // 0000001B6854: D8DC0100 C1000098
	v_lshlrev_b32_e32 v13, 16, v65                             // 0000001B685C: 301A8290
	v_dual_mul_f32 v32, v202, v5 :: v_dual_lshlrev_b32 v5, 16, v55// 0000001B6860: C8E20BCA 20046E90
	v_mul_f32_e32 v41, v205, v7                                // 0000001B6868: 10520FCD
	v_lshlrev_b32_e32 v7, 16, v54                              // 0000001B686C: 300E6C90
	ds_load_2addr_b32 v[53:54], v149 offset1:1                 // 0000001B6870: D8DC0100 35000095
	v_mul_f32_e32 v51, v207, v13                               // 0000001B6878: 10661BCF
	v_mul_f32_e32 v44, v199, v5                                // 0000001B687C: 10580BC7
	ds_load_2addr_b32 v[5:6], v141 offset1:1                   // 0000001B6880: D8DC0100 0500008D
	v_mul_f32_e32 v28, v201, v7                                // 0000001B6888: 10380FC9
	v_lshlrev_b32_e32 v7, 16, v59                              // 0000001B688C: 300E7690
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B6890: BF870001
	v_dual_mul_f32 v46, v213, v7 :: v_dual_lshlrev_b32 v7, 16, v60// 0000001B6894: C8E20FD5 2E067890
	ds_load_2addr_b32 v[55:56], v150 offset1:1                 // 0000001B689C: D8DC0100 37000096
	v_mul_f32_e32 v31, v209, v7                                // 0000001B68A4: 103E0FD1
	ds_load_2addr_b32 v[7:8], v142 offset1:1                   // 0000001B68A8: D8DC0100 0700008E
	s_waitcnt lgkmcnt(3)                                       // 0000001B68B0: BF89FC37
	v_dual_mul_f32 v53, v189, v53 :: v_dual_mul_f32 v54, v190, v54// 0000001B68B4: C8C66BBD 35366DBE
	s_waitcnt lgkmcnt(2)                                       // 0000001B68BC: BF89FC27
	v_dual_mul_f32 v5, v71, v5 :: v_dual_mul_f32 v6, v72, v6   // 0000001B68C0: C8C60B47 05060D48
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B68C8: BF870091
	v_fma_mixlo_f16 v5, v5, s22, 0                             // 0000001B68CC: CC210005 02002D05
	v_cndmask_b16 v17, 0, v5, s0                               // 0000001B68D4: D65D4011 00020A80
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B68DC: BF870003
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001B68E0: CC210005 02002D06
	s_cselect_b32 s0, -1, 0                                    // 0000001B68E8: 980080C1
	s_or_b32 s1, s29, 3                                        // 0000001B68EC: 8C01831D
	s_waitcnt lgkmcnt(0)                                       // 0000001B68F0: BF89FC07
	v_mul_f32_e32 v6, v67, v7                                  // 0000001B68F4: 100C0F43
	s_cmp_lt_i32 s1, s58                                       // 0000001B68F8: BF043A01
	v_mul_f32_e32 v7, v68, v8                                  // 0000001B68FC: 100E1144
	v_cndmask_b16 v18, 0, v5, s0                               // 0000001B6900: D65D0012 00020A80
	s_cselect_b32 s0, -1, 0                                    // 0000001B6908: 980080C1
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001B690C: CC210005 02002D06
	s_or_b32 s1, s29, 4                                        // 0000001B6914: 8C01841D
	v_mul_f32_e32 v6, v69, v9                                  // 0000001B6918: 100C1345
	s_cmp_lt_i32 s1, s58                                       // 0000001B691C: BF043A01
	v_fma_mixhi_f16 v5, v7, s22, 0                             // 0000001B6920: CC220005 02002D07
	s_cselect_b32 s1, -1, 0                                    // 0000001B6928: 980180C1
	v_cndmask_b16 v18, 0, v5, s0                               // 0000001B692C: D65D4012 00020A80
	s_or_b32 s0, s29, 5                                        // 0000001B6934: 8C00851D
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001B6938: CC210005 02002D06
	v_mul_f32_e32 v6, v70, v10                                 // 0000001B6940: 100C1546
	s_cmp_lt_i32 s0, s58                                       // 0000001B6944: BF043A00
	v_cndmask_b16 v19, 0, v5, s1                               // 0000001B6948: D65D1013 00060A80
	s_cselect_b32 s0, -1, 0                                    // 0000001B6950: 980080C1
	s_or_b32 s1, s29, 6                                        // 0000001B6954: 8C01861D
	v_cndmask_b16 v19, 0, v5, s0                               // 0000001B6958: D65D4013 00020A80
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001B6960: CC210005 02002D06
	v_dual_mul_f32 v10, v66, v11 :: v_dual_mul_f32 v11, v16, v12// 0000001B6968: C8C61742 0A0A1910
	s_cmp_lt_i32 s1, s58                                       // 0000001B6970: BF043A01
	ds_load_2addr_b32 v[6:7], v145 offset1:1                   // 0000001B6974: D8DC0100 06000091
	ds_load_2addr_b32 v[8:9], v146 offset1:1                   // 0000001B697C: D8DC0100 08000092
	s_cselect_b32 s0, -1, 0                                    // 0000001B6984: 980080C1
	v_fma_mixhi_f16 v5, v11, s22, 0                            // 0000001B6988: CC220005 02002D0B
	v_cndmask_b16 v20, 0, v5, s0                               // 0000001B6990: D65D0014 00020A80
	v_fma_mixlo_f16 v5, v10, s22, 0                            // 0000001B6998: CC210005 02002D0A
	ds_load_2addr_b32 v[10:11], v147 offset1:1                 // 0000001B69A0: D8DC0100 0A000093
	ds_load_2addr_b32 v[12:13], v148 offset1:1                 // 0000001B69A8: D8DC0100 0C000094
	s_or_b32 s1, s29, 7                                        // 0000001B69B0: 8C01871D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B69B4: BF870009
	s_cmp_lt_i32 s1, s58                                       // 0000001B69B8: BF043A01
	s_cselect_b32 s0, -1, 0                                    // 0000001B69BC: 980080C1
	s_or_b32 s1, s29, 8                                        // 0000001B69C0: 8C01881D
	v_cndmask_b16 v20, 0, v5, s0                               // 0000001B69C4: D65D4014 00020A80
	s_cmp_lt_i32 s1, s58                                       // 0000001B69CC: BF043A01
	s_cselect_b32 s0, -1, 0                                    // 0000001B69D0: 980080C1
	s_or_b32 s1, s29, 9                                        // 0000001B69D4: 8C01891D
	v_cndmask_b16 v21, 0, v5, s0                               // 0000001B69D8: D65D1015 00020A80
	s_cmp_lt_i32 s1, s58                                       // 0000001B69E0: BF043A01
	s_cselect_b32 s0, -1, 0                                    // 0000001B69E4: 980080C1
	s_or_b32 s1, s29, 10                                       // 0000001B69E8: 8C018A1D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B69EC: BF870009
	s_cmp_lt_i32 s1, s58                                       // 0000001B69F0: BF043A01
	s_waitcnt lgkmcnt(1)                                       // 0000001B69F4: BF89FC17
	v_mul_f32_e32 v4, v4, v10                                  // 0000001B69F8: 10081504
	s_waitcnt lgkmcnt(0)                                       // 0000001B69FC: BF89FC07
	v_mul_f32_e32 v52, v1, v13                                 // 0000001B6A00: 10681B01
	s_cselect_b32 s1, -1, 0                                    // 0000001B6A04: 980180C1
	s_or_b32 s8, s29, 11                                       // 0000001B6A08: 8C088B1D
	v_mul_f32_e32 v3, v3, v11                                  // 0000001B6A0C: 10061703
	s_cmp_lt_i32 s8, s58                                       // 0000001B6A10: BF043A08
	v_fma_mixlo_f16 v52, v52, s22, 0                           // 0000001B6A14: CC210034 02002D34
	v_fma_mixhi_f16 v52, v53, s22, 0                           // 0000001B6A1C: CC220034 02002D35
	v_fma_mixlo_f16 v53, v54, s22, 0                           // 0000001B6A24: CC210035 02002D36
	v_dual_mul_f32 v54, v187, v55 :: v_dual_mul_f32 v55, v185, v56// 0000001B6A2C: C8C66FBB 363671B9
	v_mul_f32_e32 v56, v186, v192                              // 0000001B6A34: 107181BA
	ds_load_2addr_b32 v[185:186], v153 offset1:1               // 0000001B6A38: D8DC0100 B9000099
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 0000001B6A40: CC210004 02002D04
	v_fma_mixhi_f16 v53, v54, s22, 0                           // 0000001B6A48: CC220035 02002D36
	v_fma_mixlo_f16 v54, v55, s22, 0                           // 0000001B6A50: CC210036 02002D37
	v_dual_mul_f32 v55, v182, v191 :: v_dual_mul_f32 v182, v188, v193// 0000001B6A58: C8C77FB6 37B783BC
	ds_load_2addr_b32 v[187:188], v154 offset1:1               // 0000001B6A60: D8DC0100 BB00009A
	v_dual_mul_f32 v5, v73, v6 :: v_dual_mul_f32 v6, v78, v7   // 0000001B6A68: C8C60D49 05060F4E
	v_fma_mixhi_f16 v54, v55, s22, 0                           // 0000001B6A70: CC220036 02002D37
	v_fma_mixlo_f16 v55, v56, s22, 0                           // 0000001B6A78: CC210037 02002D38
	v_fma_mixhi_f16 v55, v182, s22, 0                          // 0000001B6A80: CC220037 02002DB6
	v_mul_f32_e32 v56, v183, v194                              // 0000001B6A88: 107185B7
	ds_load_2addr_b32 v[182:183], v155 offset1:1               // 0000001B6A8C: D8DC0100 B600009B
	ds_load_2addr_b32 v[189:190], v156 offset1:1               // 0000001B6A94: D8DC0100 BD00009C
	v_fma_mixlo_f16 v5, v5, s22, 0                             // 0000001B6A9C: CC210005 02002D05
	v_mul_f32_e32 v7, v79, v8                                  // 0000001B6AA4: 100E114F
	v_fma_mixhi_f16 v5, v6, s22, 0                             // 0000001B6AA8: CC220005 02002D06
	v_mul_f32_e32 v6, v15, v9                                  // 0000001B6AB0: 100C130F
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 0000001B6AB4: CC210003 02002D03
	v_cndmask_b16 v21, 0, v5, s0                               // 0000001B6ABC: D65D4015 00020A80
	s_cselect_b32 s0, -1, 0                                    // 0000001B6AC4: 980080C1
	v_cndmask_b16 v22, 0, v5, s1                               // 0000001B6AC8: D65D1016 00060A80
	s_or_b32 s1, s29, 12                                       // 0000001B6AD0: 8C018C1D
	v_mul_f32_e32 v2, v2, v12                                  // 0000001B6AD4: 10041902
	s_cmp_lt_i32 s1, s58                                       // 0000001B6AD8: BF043A01
	v_fma_mixlo_f16 v56, v56, s22, 0                           // 0000001B6ADC: CC210038 02002D38
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001B6AE4: BF870002
	v_fma_mixhi_f16 v24, v2, s22, 0                            // 0000001B6AE8: CC220018 02002D02
	s_waitcnt lgkmcnt(1)                                       // 0000001B6AF0: BF89FC17
	v_mul_f32_e32 v178, v178, v183                             // 0000001B6AF4: 11656FB2
	s_waitcnt lgkmcnt(0)                                       // 0000001B6AF8: BF89FC07
	v_mul_f32_e32 v176, v176, v189                             // 0000001B6AFC: 11617BB0
	v_fma_mixlo_f16 v5, v7, s22, 0                             // 0000001B6B00: CC210005 02002D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B6B08: BF870112
	v_fma_mixlo_f16 v176, v176, s22, 0                         // 0000001B6B0C: CC2100B0 02002DB0
	v_cndmask_b16 v22, 0, v5, s0                               // 0000001B6B14: D65D4016 00020A80
	v_fma_mixlo_f16 v5, v6, s22, 0                             // 0000001B6B1C: CC210005 02002D06
	v_min_i32_e32 v6, s62, v195                                // 0000001B6B24: 220D863E
	s_cselect_b32 s0, -1, 0                                    // 0000001B6B28: 980080C1
	s_or_b32 s1, s29, 13                                       // 0000001B6B2C: 8C018D1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B6B30: BF870112
	v_cndmask_b16 v23, 0, v5, s0                               // 0000001B6B34: D65D0017 00020A80
	v_mad_i64_i32 v[5:6], null, v6, 48, s[2:3]                 // 0000001B6B3C: D6FF7C05 00096106
	s_cmp_lt_i32 s1, s58                                       // 0000001B6B44: BF043A01
	s_cselect_b32 s0, -1, 0                                    // 0000001B6B48: 980080C1
	s_or_b32 s1, s29, 14                                       // 0000001B6B4C: 8C018E1D
	v_cndmask_b16 v23, 0, v4, s0                               // 0000001B6B50: D65D4017 00020880
	s_cmp_lt_i32 s1, s58                                       // 0000001B6B58: BF043A01
	.long 0xd73c0061                                           // 0000001B6B5C: D73C0061
	v_cndmask_b32_e32 v1, 8, v5, vcc_lo                        // 0000001B6B60: 02020A88
	s_cselect_b32 s0, -1, 0                                    // 0000001B6B64: 980080C1
	s_or_b32 s1, s29, 15                                       // 0000001B6B68: 8C018F1D
	v_cndmask_b16 v24, 0, v3, s0                               // 0000001B6B6C: D65D0018 00020680
	s_cmp_lt_i32 s1, s58                                       // 0000001B6B74: BF043A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B6B78: BF870092
	.long 0xd7006a05                                           // 0000001B6B7C: D7006A05
	v_cndmask_b32_e32 v1, s26, v97, vcc_lo                     // 0000001B6B80: 0202C21A
	v_add_co_ci_u32_e64 v6, null, s27, v98, vcc_lo             // 0000001B6B84: D5207C06 01AAC41B
	s_clause 0xf                                               // 0000001B6B8C: BF85000F
	global_load_b128 v[89:92], v[5:6], off                     // 0000001B6B90: DC5E0000 597C0005
	global_load_b128 v[93:96], v[5:6], off offset:16           // 0000001B6B98: DC5E0010 5D7C0005
	global_load_b128 v[81:84], v[5:6], off offset:32           // 0000001B6BA0: DC5E0020 517C0005
	global_load_b128 v[85:88], v[5:6], off offset:48           // 0000001B6BA8: DC5E0030 557C0005
	global_load_b128 v[73:76], v[5:6], off offset:64           // 0000001B6BB0: DC5E0040 497C0005
	global_load_b128 v[77:80], v[5:6], off offset:80           // 0000001B6BB8: DC5E0050 4D7C0005
	global_load_b128 v[65:68], v[5:6], off offset:96           // 0000001B6BC0: DC5E0060 417C0005
	global_load_b128 v[69:72], v[5:6], off offset:112          // 0000001B6BC8: DC5E0070 457C0005
	global_load_b128 v[57:60], v[5:6], off offset:128          // 0000001B6BD0: DC5E0080 397C0005
	global_load_b128 v[61:64], v[5:6], off offset:144          // 0000001B6BD8: DC5E0090 3D7C0005
	global_load_b128 v[33:36], v[5:6], off offset:160          // 0000001B6BE0: DC5E00A0 217C0005
	global_load_b128 v[37:40], v[5:6], off offset:176          // 0000001B6BE8: DC5E00B0 257C0005
	global_load_b128 v[9:12], v[5:6], off offset:192           // 0000001B6BF0: DC5E00C0 097C0005
	global_load_b128 v[13:16], v[5:6], off offset:208          // 0000001B6BF8: DC5E00D0 0D7C0005
	global_load_b128 v[1:4], v[5:6], off offset:224            // 0000001B6C00: DC5E00E0 017C0005
	global_load_b128 v[5:8], v[5:6], off offset:240            // 0000001B6C08: DC5E00F0 057C0005
	s_cselect_b32 s0, -1, 0                                    // 0000001B6C10: 980080C1
	s_or_b32 s1, s29, 16                                       // 0000001B6C14: 8C01901D
	v_cndmask_b16 v24, 0, v24, s0                              // 0000001B6C18: D65D5018 00023080
	s_cmp_lt_i32 s1, s58                                       // 0000001B6C20: BF043A01
	ds_store_b128 v125, v[17:20]                               // 0000001B6C24: DB7C0000 0000117D
	ds_store_b128 v125, v[21:24] offset:16                     // 0000001B6C2C: DB7C0010 0000157D
	s_cselect_b32 s0, -1, 0                                    // 0000001B6C34: 980080C1
	ds_load_2addr_b32 v[19:20], v158 offset1:1                 // 0000001B6C38: D8DC0100 1300009E
	v_cndmask_b16 v52, 0, v52, s0                              // 0000001B6C40: D65D0034 00026880
	s_or_b32 s0, s29, 17                                       // 0000001B6C48: 8C00911D
	v_mul_f32_e32 v180, v180, v185                             // 0000001B6C4C: 116973B4
	s_cmp_lt_i32 s0, s58                                       // 0000001B6C50: BF043A00
	v_mul_f32_e32 v177, v177, v186                             // 0000001B6C54: 116375B1
	s_cselect_b32 s0, -1, 0                                    // 0000001B6C58: 980080C1
	s_or_b32 s1, s29, 18                                       // 0000001B6C5C: 8C01921D
	v_cndmask_b16 v52, 0, v52, s0                              // 0000001B6C60: D65D5034 00026880
	s_cmp_lt_i32 s1, s58                                       // 0000001B6C68: BF043A01
	v_fma_mixhi_f16 v56, v180, s22, 0                          // 0000001B6C6C: CC220038 02002DB4
	s_cselect_b32 s0, -1, 0                                    // 0000001B6C74: 980080C1
	s_or_b32 s1, s29, 19                                       // 0000001B6C78: 8C01931D
	v_cndmask_b16 v53, 0, v53, s0                              // 0000001B6C7C: D65D0035 00026A80
	s_cmp_lt_i32 s1, s58                                       // 0000001B6C84: BF043A01
	v_mul_f32_e32 v181, v181, v187                             // 0000001B6C88: 116B77B5
	s_cselect_b32 s0, -1, 0                                    // 0000001B6C8C: 980080C1
	s_or_b32 s1, s29, 20                                       // 0000001B6C90: 8C01941D
	v_cndmask_b16 v53, 0, v53, s0                              // 0000001B6C94: D65D5035 00026A80
	s_cmp_lt_i32 s1, s58                                       // 0000001B6C9C: BF043A01
	ds_load_2addr_b32 v[21:22], v159 offset1:1                 // 0000001B6CA0: D8DC0100 1500009F
	ds_load_2addr_b32 v[23:24], v160 offset1:1                 // 0000001B6CA8: D8DC0100 170000A0
	s_cselect_b32 s1, -1, 0                                    // 0000001B6CB0: 980180C1
	s_or_b32 s8, s29, 21                                       // 0000001B6CB4: 8C08951D
	v_cndmask_b16 v54, 0, v54, s1                              // 0000001B6CB8: D65D0036 00066C80
	s_cmp_lt_i32 s8, s58                                       // 0000001B6CC0: BF043A08
	v_mul_f32_e32 v17, v175, v190                              // 0000001B6CC4: 10237DAF
	s_cselect_b32 s0, -1, 0                                    // 0000001B6CC8: 980080C1
	s_or_b32 s8, s29, 22                                       // 0000001B6CCC: 8C08961D
	v_cndmask_b16 v54, 0, v54, s0                              // 0000001B6CD0: D65D5036 00026C80
	s_cmp_lt_i32 s8, s58                                       // 0000001B6CD8: BF043A08
	v_fma_mixlo_f16 v17, v17, s22, 0                           // 0000001B6CDC: CC210011 02002D11
	s_cselect_b32 s1, -1, 0                                    // 0000001B6CE4: 980180C1
	s_or_b32 s8, s29, 23                                       // 0000001B6CE8: 8C08971D
	v_cndmask_b16 v55, 0, v55, s1                              // 0000001B6CEC: D65D0037 00066E80
	s_cmp_lt_i32 s8, s58                                       // 0000001B6CF4: BF043A08
	s_waitcnt lgkmcnt(2)                                       // 0000001B6CF8: BF89FC27
	v_mul_f32_e32 v19, v105, v19                               // 0000001B6CFC: 10262769
	s_cselect_b32 s0, -1, 0                                    // 0000001B6D00: 980080C1
	s_or_b32 s8, s29, 24                                       // 0000001B6D04: 8C08981D
	v_cndmask_b16 v55, 0, v55, s0                              // 0000001B6D08: D65D5037 00026E80
	s_cmp_lt_i32 s8, s58                                       // 0000001B6D10: BF043A08
	v_mul_f32_e32 v20, v104, v20                               // 0000001B6D14: 10282968
	s_cselect_b32 s0, -1, 0                                    // 0000001B6D18: 980080C1
	s_or_b32 s1, s29, 25                                       // 0000001B6D1C: 8C01991D
	v_cndmask_b16 v180, 0, v56, s0                             // 0000001B6D20: D65D00B4 00027080
	s_cmp_lt_i32 s1, s58                                       // 0000001B6D28: BF043A01
	v_fma_mixlo_f16 v56, v177, s22, 0                          // 0000001B6D2C: CC210038 02002DB1
	s_cselect_b32 s1, -1, 0                                    // 0000001B6D34: 980180C1
	s_or_b32 s8, s29, 26                                       // 0000001B6D38: 8C089A1D
	v_mul_f32_e32 v177, v184, v188                             // 0000001B6D3C: 116379B8
	s_cmp_lt_i32 s8, s58                                       // 0000001B6D40: BF043A08
	v_cndmask_b16 v180, 0, v56, s1                             // 0000001B6D44: D65D50B4 00067080
	s_cselect_b32 s0, -1, 0                                    // 0000001B6D4C: 980080C1
	s_or_b32 s8, s29, 27                                       // 0000001B6D50: 8C089B1D
	v_fma_mixhi_f16 v56, v181, s22, 0                          // 0000001B6D54: CC220038 02002DB5
	s_cmp_lt_i32 s8, s58                                       // 0000001B6D5C: BF043A08
	v_cndmask_b16 v181, 0, v56, s0                             // 0000001B6D60: D65D00B5 00027080
	s_cselect_b32 s1, -1, 0                                    // 0000001B6D68: 980180C1
	s_or_b32 s8, s29, 28                                       // 0000001B6D6C: 8C089C1D
	v_fma_mixlo_f16 v56, v177, s22, 0                          // 0000001B6D70: CC210038 02002DB1
	v_mul_f32_e32 v177, v179, v182                             // 0000001B6D78: 11636DB3
	s_cmp_lt_i32 s8, s58                                       // 0000001B6D7C: BF043A08
	v_cndmask_b16 v181, 0, v56, s1                             // 0000001B6D80: D65D50B5 00067080
	s_cselect_b32 s0, -1, 0                                    // 0000001B6D88: 980080C1
	v_fma_mixhi_f16 v56, v178, s22, 0                          // 0000001B6D8C: CC220038 02002DB2
	v_cndmask_b16 v182, 0, v56, s0                             // 0000001B6D94: D65D00B6 00027080
	v_fma_mixlo_f16 v56, v177, s22, 0                          // 0000001B6D9C: CC210038 02002DB1
	ds_load_2addr_b32 v[177:178], v157 offset1:1               // 0000001B6DA4: D8DC0100 B100009D
	s_or_b32 s8, s29, 29                                       // 0000001B6DAC: 8C089D1D
	v_cmp_le_i32_e32 vcc_lo, s58, v195                         // 0000001B6DB0: 7C87863A
	s_cmp_lt_i32 s8, s58                                       // 0000001B6DB4: BF043A08
	s_cselect_b32 s0, -1, 0                                    // 0000001B6DB8: 980080C1
	s_or_b32 s1, s29, 30                                       // 0000001B6DBC: 8C019E1D
	v_cndmask_b16 v182, 0, v56, s0                             // 0000001B6DC0: D65D40B6 00027080
	s_cmp_lt_i32 s1, s58                                       // 0000001B6DC8: BF043A01
	s_cselect_b32 s1, -1, 0                                    // 0000001B6DCC: 980180C1
	s_or_b32 s8, s29, 31                                       // 0000001B6DD0: 8C089F1D
	v_cndmask_b16 v183, 0, v56, s1                             // 0000001B6DD4: D65D10B7 00067080
	s_cmp_lt_i32 s8, s58                                       // 0000001B6DDC: BF043A08
	s_cselect_b32 s0, -1, 0                                    // 0000001B6DE0: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B6DE4: BF870009
	v_cndmask_b16 v183, 0, v176, s0                            // 0000001B6DE8: D65D40B7 00036080
	s_or_b32 s0, s29, 32                                       // 0000001B6DF0: 8C00A01D
	ds_store_b128 v125, v[52:55] offset:32                     // 0000001B6DF4: DB7C0020 0000347D
	ds_store_b128 v125, v[180:183] offset:48                   // 0000001B6DFC: DB7C0030 0000B47D
	s_cmp_lt_i32 s0, s58                                       // 0000001B6E04: BF043A00
	s_waitcnt lgkmcnt(2)                                       // 0000001B6E08: BF89FC27
	v_mul_f32_e32 v18, v174, v177                              // 0000001B6E0C: 102563AE
	s_cselect_b32 s0, -1, 0                                    // 0000001B6E10: 980080C1
	v_mul_f32_e32 v52, v173, v178                              // 0000001B6E14: 106965AD
	v_cndmask_b16 v17, 0, v17, s0                              // 0000001B6E18: D65D0011 00022280
	s_or_b32 s0, s29, 33                                       // 0000001B6E20: 8C00A11D
	v_fma_mixhi_f16 v17, v18, s22, 0                           // 0000001B6E24: CC220011 02002D12
	s_cmp_lt_i32 s0, s58                                       // 0000001B6E2C: BF043A00
	v_fma_mixhi_f16 v18, v19, s22, 0                           // 0000001B6E30: CC220012 02002D13
	s_cselect_b32 s0, -1, 0                                    // 0000001B6E38: 980080C1
	s_or_b32 s1, s29, 34                                       // 0000001B6E3C: 8C01A21D
	v_fma_mixlo_f16 v19, v20, s22, 0                           // 0000001B6E40: CC210013 02002D14
	s_cmp_lt_i32 s1, s58                                       // 0000001B6E48: BF043A01
	v_mul_f32_e32 v20, v116, v21                               // 0000001B6E4C: 10282B74
	v_mul_f32_e32 v21, v172, v22                               // 0000001B6E50: 102A2DAC
	v_fma_mixlo_f16 v18, v52, s22, 0                           // 0000001B6E54: CC210012 02002D34
	v_cndmask_b16 v17, 0, v17, s0                              // 0000001B6E5C: D65D5011 00022280
	s_cselect_b32 s0, -1, 0                                    // 0000001B6E64: 980080C1
	s_or_b32 s1, s29, 35                                       // 0000001B6E68: 8C01A31D
	ds_load_2addr_b32 v[52:53], v161 offset1:1                 // 0000001B6E6C: D8DC0100 340000A1
	s_cmp_lt_i32 s1, s58                                       // 0000001B6E74: BF043A01
	v_fma_mixhi_f16 v19, v20, s22, 0                           // 0000001B6E78: CC220013 02002D14
	v_mul_f32_e32 v22, v117, v23                               // 0000001B6E80: 102C2F75
	v_fma_mixlo_f16 v20, v21, s22, 0                           // 0000001B6E84: CC210014 02002D15
	v_mul_f32_e32 v21, v102, v24                               // 0000001B6E8C: 102A3166
	ds_load_2addr_b32 v[23:24], v162 offset1:1                 // 0000001B6E90: D8DC0100 170000A2
	v_cndmask_b16 v18, 0, v18, s0                              // 0000001B6E98: D65D0012 00022480
	s_cselect_b32 s0, -1, 0                                    // 0000001B6EA0: 980080C1
	s_or_b32 s1, s29, 36                                       // 0000001B6EA4: 8C01A41D
	ds_load_2addr_b32 v[54:55], v163 offset1:1                 // 0000001B6EA8: D8DC0100 360000A3
	ds_load_2addr_b32 v[104:105], v164 offset1:1               // 0000001B6EB0: D8DC0100 680000A4
	s_cmp_lt_i32 s1, s58                                       // 0000001B6EB8: BF043A01
	v_cndmask_b16 v18, 0, v18, s0                              // 0000001B6EBC: D65D5012 00022480
	s_cselect_b32 s1, -1, 0                                    // 0000001B6EC4: 980180C1
	s_or_b32 s8, s29, 37                                       // 0000001B6EC8: 8C08A51D
	v_cndmask_b16 v19, 0, v19, s1                              // 0000001B6ECC: D65D0013 00062680
	s_cmp_lt_i32 s8, s58                                       // 0000001B6ED4: BF043A08
	v_fma_mixhi_f16 v20, v22, s22, 0                           // 0000001B6ED8: CC220014 02002D16
	s_cselect_b32 s0, -1, 0                                    // 0000001B6EE0: 980080C1
	s_or_b32 s8, s29, 38                                       // 0000001B6EE4: 8C08A61D
	v_cndmask_b16 v19, 0, v19, s0                              // 0000001B6EE8: D65D5013 00022680
	s_cmp_lt_i32 s8, s58                                       // 0000001B6EF0: BF043A08
	v_fma_mixlo_f16 v21, v21, s22, 0                           // 0000001B6EF4: CC210015 02002D15
	s_cselect_b32 s1, -1, 0                                    // 0000001B6EFC: 980180C1
	s_or_b32 s8, s29, 39                                       // 0000001B6F00: 8C08A71D
	v_cndmask_b16 v20, 0, v20, s1                              // 0000001B6F04: D65D0014 00062880
	s_cmp_lt_i32 s8, s58                                       // 0000001B6F0C: BF043A08
	s_waitcnt lgkmcnt(3)                                       // 0000001B6F10: BF89FC37
	v_mul_f32_e32 v22, v99, v52                                // 0000001B6F14: 102C6963
	s_cselect_b32 s0, -1, 0                                    // 0000001B6F18: 980080C1
	s_or_b32 s1, s29, 40                                       // 0000001B6F1C: 8C01A81D
	s_waitcnt lgkmcnt(2)                                       // 0000001B6F20: BF89FC27
	v_mul_f32_e32 v23, v101, v23                               // 0000001B6F24: 102E2F65
	s_cmp_lt_i32 s1, s58                                       // 0000001B6F28: BF043A01
	v_mul_f32_e32 v24, v100, v24                               // 0000001B6F2C: 10303164
	v_cndmask_b16 v20, 0, v20, s0                              // 0000001B6F30: D65D5014 00022880
	s_cselect_b32 s0, -1, 0                                    // 0000001B6F38: 980080C1
	v_mul_f32_e32 v52, v103, v53                               // 0000001B6F3C: 10686B67
	v_cndmask_b16 v21, 0, v21, s0                              // 0000001B6F40: D65D0015 00022A80
	s_or_b32 s0, s29, 41                                       // 0000001B6F48: 8C00A91D
	v_fma_mixhi_f16 v21, v22, s22, 0                           // 0000001B6F4C: CC220015 02002D16
	s_cmp_lt_i32 s0, s58                                       // 0000001B6F54: BF043A00
	v_fma_mixhi_f16 v22, v23, s22, 0                           // 0000001B6F58: CC220016 02002D17
	v_fma_mixlo_f16 v23, v24, s22, 0                           // 0000001B6F60: CC210017 02002D18
	s_waitcnt lgkmcnt(1)                                       // 0000001B6F68: BF89FC17
	v_mul_f32_e32 v24, v45, v54                                // 0000001B6F6C: 10306D2D
	v_mul_f32_e32 v42, v42, v55                                // 0000001B6F70: 10546F2A
	s_cselect_b32 s0, -1, 0                                    // 0000001B6F74: 980080C1
	s_or_b32 s1, s29, 42                                       // 0000001B6F78: 8C01AA1D
	v_fma_mixlo_f16 v22, v52, s22, 0                           // 0000001B6F7C: CC210016 02002D34
	s_cmp_lt_i32 s1, s58                                       // 0000001B6F84: BF043A01
	ds_load_2addr_b32 v[52:53], v165 offset1:1                 // 0000001B6F88: D8DC0100 340000A5
	v_fma_mixhi_f16 v23, v24, s22, 0                           // 0000001B6F90: CC220017 02002D18
	s_waitcnt lgkmcnt(1)                                       // 0000001B6F98: BF89FC17
	v_mul_f32_e32 v45, v49, v104                               // 0000001B6F9C: 105AD131
	v_fma_mixlo_f16 v24, v42, s22, 0                           // 0000001B6FA0: CC210018 02002D2A
	v_mul_f32_e32 v42, v48, v105                               // 0000001B6FA8: 1054D330
	ds_load_2addr_b32 v[48:49], v166 offset1:1                 // 0000001B6FAC: D8DC0100 300000A6
	v_cndmask_b16 v21, 0, v21, s0                              // 0000001B6FB4: D65D5015 00022A80
	s_cselect_b32 s0, -1, 0                                    // 0000001B6FBC: 980080C1
	s_or_b32 s1, s29, 43                                       // 0000001B6FC0: 8C01AB1D
	v_cndmask_b16 v22, 0, v22, s0                              // 0000001B6FC4: D65D0016 00022C80
	s_cmp_lt_i32 s1, s58                                       // 0000001B6FCC: BF043A01
	v_fma_mixhi_f16 v24, v45, s22, 0                           // 0000001B6FD0: CC220018 02002D2D
	s_cselect_b32 s0, -1, 0                                    // 0000001B6FD8: 980080C1
	s_or_b32 s1, s29, 44                                       // 0000001B6FDC: 8C01AC1D
	v_cndmask_b16 v22, 0, v22, s0                              // 0000001B6FE0: D65D5016 00022C80
	s_cmp_lt_i32 s1, s58                                       // 0000001B6FE8: BF043A01
	ds_load_2addr_b32 v[54:55], v167 offset1:1                 // 0000001B6FEC: D8DC0100 360000A7
	ds_load_2addr_b32 v[99:100], v168 offset1:1                // 0000001B6FF4: D8DC0100 630000A8
	s_cselect_b32 s1, -1, 0                                    // 0000001B6FFC: 980180C1
	s_or_b32 s8, s29, 45                                       // 0000001B7000: 8C08AD1D
	v_cndmask_b16 v23, 0, v23, s1                              // 0000001B7004: D65D0017 00062E80
	s_cmp_lt_i32 s8, s58                                       // 0000001B700C: BF043A08
	v_fma_mixlo_f16 v42, v42, s22, 0                           // 0000001B7010: CC21002A 02002D2A
	s_cselect_b32 s0, -1, 0                                    // 0000001B7018: 980080C1
	s_or_b32 s8, s29, 46                                       // 0000001B701C: 8C08AE1D
	v_cndmask_b16 v23, 0, v23, s0                              // 0000001B7020: D65D5017 00022E80
	s_cmp_lt_i32 s8, s58                                       // 0000001B7028: BF043A08
	s_waitcnt lgkmcnt(2)                                       // 0000001B702C: BF89FC27
	v_mul_f32_e32 v27, v27, v48                                // 0000001B7030: 1036611B
	s_cselect_b32 s1, -1, 0                                    // 0000001B7034: 980180C1
	s_or_b32 s8, s29, 47                                       // 0000001B7038: 8C08AF1D
	v_mul_f32_e32 v32, v32, v49                                // 0000001B703C: 10406320
	s_cmp_lt_i32 s8, s58                                       // 0000001B7040: BF043A08
	v_cndmask_b16 v24, 0, v24, s1                              // 0000001B7044: D65D0018 00063080
	s_cselect_b32 s0, -1, 0                                    // 0000001B704C: 980080C1
	s_or_b32 s1, s29, 48                                       // 0000001B7050: 8C01B01D
	v_cndmask_b16 v24, 0, v24, s0                              // 0000001B7054: D65D5018 00023080
	s_cmp_lt_i32 s1, s58                                       // 0000001B705C: BF043A01
	v_fma_mixlo_f16 v27, v27, s22, 0                           // 0000001B7060: CC21001B 02002D1B
	s_cselect_b32 s0, -1, 0                                    // 0000001B7068: 980080C1
	v_fma_mixhi_f16 v27, v32, s22, 0                           // 0000001B706C: CC22001B 02002D20
	ds_load_b32 v32, v107 offset:61692                         // 0000001B7074: D8D8F0FC 2000006B
	v_mul_f32_e32 v43, v43, v52                                // 0000001B707C: 1056692B
	v_cndmask_b16 v42, 0, v42, s0                              // 0000001B7080: D65D002A 00025480
	s_or_b32 s0, s29, 49                                       // 0000001B7088: 8C00B11D
	v_mul_f32_e32 v45, v41, v53                                // 0000001B708C: 105A6B29
	s_cmp_lt_i32 s0, s58                                       // 0000001B7090: BF043A00
	v_fma_mixlo_f16 v41, v43, s22, 0                           // 0000001B7094: CC210029 02002D2B
	s_cselect_b32 s0, -1, 0                                    // 0000001B709C: 980080C1
	s_or_b32 s1, s29, 50                                       // 0000001B70A0: 8C01B21D
	v_fma_mixhi_f16 v41, v45, s22, 0                           // 0000001B70A4: CC220029 02002D2D
	s_cmp_lt_i32 s1, s58                                       // 0000001B70AC: BF043A01
	v_cndmask_b16 v42, 0, v41, s0                              // 0000001B70B0: D65D402A 00025280
	s_cselect_b32 s0, -1, 0                                    // 0000001B70B8: 980080C1
	s_or_b32 s1, s29, 51                                       // 0000001B70BC: 8C01B31D
	v_cndmask_b16 v43, 0, v41, s0                              // 0000001B70C0: D65D102B 00025280
	s_cmp_lt_i32 s1, s58                                       // 0000001B70C8: BF043A01
	s_waitcnt lgkmcnt(2)                                       // 0000001B70CC: BF89FC27
	v_mul_f32_e32 v41, v44, v54                                // 0000001B70D0: 10526D2C
	s_cselect_b32 s0, -1, 0                                    // 0000001B70D4: 980080C1
	s_or_b32 s1, s29, 52                                       // 0000001B70D8: 8C01B41D
	ds_load_2addr_b32 v[48:49], v169 offset1:1                 // 0000001B70DC: D8DC0100 300000A9
	ds_load_2addr_b32 v[52:53], v170 offset1:1                 // 0000001B70E4: D8DC0100 340000AA
	s_cmp_lt_i32 s1, s58                                       // 0000001B70EC: BF043A01
	v_cndmask_b16 v43, 0, v27, s0                              // 0000001B70F0: D65D402B 00023680
	s_cselect_b32 s1, -1, 0                                    // 0000001B70F8: 980180C1
	s_or_b32 s8, s29, 53                                       // 0000001B70FC: 8C08B51D
	v_fma_mixlo_f16 v27, v41, s22, 0                           // 0000001B7100: CC21001B 02002D29
	s_cmp_lt_i32 s8, s58                                       // 0000001B7108: BF043A08
	v_mul_f32_e32 v29, v29, v55                                // 0000001B710C: 103A6F1D
	s_cselect_b32 s0, -1, 0                                    // 0000001B7110: 980080C1
	s_waitcnt lgkmcnt(3)                                       // 0000001B7114: BF89FC37
	v_mul_f32_e32 v28, v28, v99                                // 0000001B7118: 1038C71C
	v_cndmask_b16 v44, 0, v27, s0                              // 0000001B711C: D65D402C 00023680
	s_or_b32 s0, s29, 54                                       // 0000001B7124: 8C00B61D
	v_fma_mixlo_f16 v27, v29, s22, 0                           // 0000001B7128: CC21001B 02002D1D
	s_cmp_lt_i32 s0, s58                                       // 0000001B7130: BF043A00
	v_cndmask_b16 v44, 0, v27, s1                              // 0000001B7134: D65D102C 00063680
	s_cselect_b32 s0, -1, 0                                    // 0000001B713C: 980080C1
	s_or_b32 s1, s29, 55                                       // 0000001B7140: 8C01B71D
	v_fma_mixhi_f16 v27, v28, s22, 0                           // 0000001B7144: CC22001B 02002D1C
	s_cmp_lt_i32 s1, s58                                       // 0000001B714C: BF043A01
	v_cndmask_b16 v45, 0, v27, s0                              // 0000001B7150: D65D002D 00023680
	s_cselect_b32 s0, -1, 0                                    // 0000001B7158: 980080C1
	s_or_b32 s1, s29, 56                                       // 0000001B715C: 8C01B81D
	v_mul_f32_e32 v25, v25, v100                               // 0000001B7160: 1032C919
	s_cmp_lt_i32 s1, s58                                       // 0000001B7164: BF043A01
	v_cndmask_b16 v45, 0, v27, s0                              // 0000001B7168: D65D502D 00023680
	s_cselect_b32 s0, -1, 0                                    // 0000001B7170: 980080C1
	s_or_b32 s1, s29, 57                                       // 0000001B7174: 8C01B91D
	ds_load_2addr_b32 v[54:55], v171 offset1:1                 // 0000001B7178: D8DC0100 360000AB
	s_waitcnt lgkmcnt(2)                                       // 0000001B7180: BF89FC27
	v_dual_mul_f32 v27, v46, v48 :: v_dual_mul_f32 v28, v47, v49// 0000001B7184: C8C6612E 1B1C632F
	s_cmp_lt_i32 s1, s58                                       // 0000001B718C: BF043A01
	v_fma_mixlo_f16 v25, v25, s22, 0                           // 0000001B7190: CC210019 02002D19
	s_cselect_b32 s1, -1, 0                                    // 0000001B7198: 980180C1
	s_or_b32 s8, s29, 58                                       // 0000001B719C: 8C08BA1D
	v_fma_mixhi_f16 v25, v27, s22, 0                           // 0000001B71A0: CC220019 02002D1B
	v_fma_mixlo_f16 v28, v28, s22, 0                           // 0000001B71A8: CC21001C 02002D1C
	s_cmp_lt_i32 s8, s58                                       // 0000001B71B0: BF043A08
	v_cndmask_b16 v27, 0, v25, s0                              // 0000001B71B4: D65D001B 00023280
	s_cselect_b32 s0, -1, 0                                    // 0000001B71BC: 980080C1
	v_cndmask_b16 v27, 0, v25, s1                              // 0000001B71C0: D65D501B 00063280
	v_cndmask_b16 v28, 0, v28, s0                              // 0000001B71C8: D65D001C 00023880
	s_or_b32 s0, s29, 59                                       // 0000001B71D0: 8C00BB1D
	s_waitcnt lgkmcnt(1)                                       // 0000001B71D4: BF89FC17
	v_mul_f32_e32 v25, v31, v52                                // 0000001B71D8: 1032691F
	v_mul_f32_e32 v29, v30, v53                                // 0000001B71DC: 103A6B1E
	s_cmp_lt_i32 s0, s58                                       // 0000001B71E0: BF043A00
	v_mul_f32_e32 v30, v51, v32                                // 0000001B71E4: 103C4133
	s_cselect_b32 s0, -1, 0                                    // 0000001B71E8: 980080C1
	s_or_b32 s1, s29, 60                                       // 0000001B71EC: 8C01BC1D
	v_fma_mixlo_f16 v25, v25, s22, 0                           // 0000001B71F0: CC210019 02002D19
	v_fma_mixhi_f16 v25, v29, s22, 0                           // 0000001B71F8: CC220019 02002D1D
	s_cmp_lt_i32 s1, s58                                       // 0000001B7200: BF043A01
	s_cselect_b32 s1, -1, 0                                    // 0000001B7204: 980180C1
	s_or_b32 s8, s29, 61                                       // 0000001B7208: 8C08BD1D
	v_cndmask_b16 v28, 0, v25, s0                              // 0000001B720C: D65D401C 00023280
	s_cmp_lt_i32 s8, s58                                       // 0000001B7214: BF043A08
	v_cndmask_b16 v29, 0, v25, s1                              // 0000001B7218: D65D101D 00063280
	s_waitcnt lgkmcnt(0)                                       // 0000001B7220: BF89FC07
	v_mul_f32_e32 v25, v26, v54                                // 0000001B7224: 10326D1A
	s_cselect_b32 s0, -1, 0                                    // 0000001B7228: 980080C1
	s_or_b32 s1, s29, 62                                       // 0000001B722C: 8C01BE1D
	v_mul_f32_e32 v26, v50, v55                                // 0000001B7230: 10346F32
	s_cmp_lt_i32 s1, s58                                       // 0000001B7234: BF043A01
	v_fma_mixlo_f16 v25, v25, s22, 0                           // 0000001B7238: CC210019 02002D19
	s_cselect_b32 s1, -1, 0                                    // 0000001B7240: 980180C1
	s_or_b32 s8, s29, 63                                       // 0000001B7244: 8C08BF1D
	v_fma_mixhi_f16 v25, v26, s22, 0                           // 0000001B7248: CC220019 02002D1A
	v_fma_mixlo_f16 v26, v30, s22, 0                           // 0000001B7250: CC21001A 02002D1E
	s_cmp_lt_i32 s8, s58                                       // 0000001B7258: BF043A08
	v_cndmask_b16 v29, 0, v25, s0                              // 0000001B725C: D65D401D 00023280
	s_cselect_b32 s0, -1, 0                                    // 0000001B7264: 980080C1
	v_cndmask_b16 v30, 0, v25, s1                              // 0000001B7268: D65D101E 00063280
	v_cndmask_b16 v30, 0, v26, s0                              // 0000001B7270: D65D401E 00023480
	ds_store_b128 v125, v[17:20] offset:64                     // 0000001B7278: DB7C0040 0000117D
	ds_store_b128 v125, v[21:24] offset:80                     // 0000001B7280: DB7C0050 0000157D
	ds_store_b128 v125, v[42:45] offset:96                     // 0000001B7288: DB7C0060 00002A7D
	ds_store_b128 v125, v[27:30] offset:112                    // 0000001B7290: DB7C0070 00001B7D
	s_and_saveexec_b32 s0, vcc_lo                              // 0000001B7298: BE80206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B729C: BF870009
	s_xor_b32 s0, exec_lo, s0                                  // 0000001B72A0: 8D00007E
	s_cbranch_execz 67                                         // 0000001B72A4: BFA50043 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x28b4>
	s_waitcnt vmcnt(1)                                         // 0000001B72A8: BF8907F7
	v_mov_b32_e32 v1, 0                                        // 0000001B72AC: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B72B0: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000001B72B4: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000001B72B8: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000001B72BC: 7E080301
	s_waitcnt vmcnt(0)                                         // 0000001B72C0: BF8903F7
	v_mov_b32_e32 v5, v1                                       // 0000001B72C4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000001B72C8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000001B72CC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000001B72D0: 7E100301
	v_mov_b32_e32 v9, v1                                       // 0000001B72D4: 7E120301
	v_mov_b32_e32 v10, v1                                      // 0000001B72D8: 7E140301
	v_mov_b32_e32 v11, v1                                      // 0000001B72DC: 7E160301
	v_mov_b32_e32 v12, v1                                      // 0000001B72E0: 7E180301
	v_mov_b32_e32 v13, v1                                      // 0000001B72E4: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 0000001B72E8: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 0000001B72EC: 7E1E0301
	v_mov_b32_e32 v16, v1                                      // 0000001B72F0: 7E200301
	v_mov_b32_e32 v33, v1                                      // 0000001B72F4: 7E420301
	v_mov_b32_e32 v34, v1                                      // 0000001B72F8: 7E440301
	v_mov_b32_e32 v35, v1                                      // 0000001B72FC: 7E460301
	v_mov_b32_e32 v36, v1                                      // 0000001B7300: 7E480301
	v_mov_b32_e32 v37, v1                                      // 0000001B7304: 7E4A0301
	v_mov_b32_e32 v38, v1                                      // 0000001B7308: 7E4C0301
	v_mov_b32_e32 v39, v1                                      // 0000001B730C: 7E4E0301
	v_mov_b32_e32 v40, v1                                      // 0000001B7310: 7E500301
	v_mov_b32_e32 v57, v1                                      // 0000001B7314: 7E720301
	v_mov_b32_e32 v58, v1                                      // 0000001B7318: 7E740301
	v_mov_b32_e32 v59, v1                                      // 0000001B731C: 7E760301
	v_mov_b32_e32 v60, v1                                      // 0000001B7320: 7E780301
	v_mov_b32_e32 v61, v1                                      // 0000001B7324: 7E7A0301
	v_mov_b32_e32 v62, v1                                      // 0000001B7328: 7E7C0301
	v_mov_b32_e32 v63, v1                                      // 0000001B732C: 7E7E0301
	v_mov_b32_e32 v64, v1                                      // 0000001B7330: 7E800301
	v_mov_b32_e32 v65, v1                                      // 0000001B7334: 7E820301
	v_mov_b32_e32 v66, v1                                      // 0000001B7338: 7E840301
	v_mov_b32_e32 v67, v1                                      // 0000001B733C: 7E860301
	v_mov_b32_e32 v68, v1                                      // 0000001B7340: 7E880301
	v_mov_b32_e32 v69, v1                                      // 0000001B7344: 7E8A0301
	v_mov_b32_e32 v70, v1                                      // 0000001B7348: 7E8C0301
	v_mov_b32_e32 v71, v1                                      // 0000001B734C: 7E8E0301
	v_mov_b32_e32 v72, v1                                      // 0000001B7350: 7E900301
	v_mov_b32_e32 v73, v1                                      // 0000001B7354: 7E920301
	v_mov_b32_e32 v74, v1                                      // 0000001B7358: 7E940301
	v_mov_b32_e32 v75, v1                                      // 0000001B735C: 7E960301
	v_mov_b32_e32 v76, v1                                      // 0000001B7360: 7E980301
	v_mov_b32_e32 v77, v1                                      // 0000001B7364: 7E9A0301
	v_mov_b32_e32 v78, v1                                      // 0000001B7368: 7E9C0301
	v_mov_b32_e32 v79, v1                                      // 0000001B736C: 7E9E0301
	v_mov_b32_e32 v80, v1                                      // 0000001B7370: 7EA00301
	v_mov_b32_e32 v81, v1                                      // 0000001B7374: 7EA20301
	v_mov_b32_e32 v82, v1                                      // 0000001B7378: 7EA40301
	v_mov_b32_e32 v83, v1                                      // 0000001B737C: 7EA60301
	v_mov_b32_e32 v84, v1                                      // 0000001B7380: 7EA80301
	v_mov_b32_e32 v85, v1                                      // 0000001B7384: 7EAA0301
	v_mov_b32_e32 v86, v1                                      // 0000001B7388: 7EAC0301
	v_mov_b32_e32 v87, v1                                      // 0000001B738C: 7EAE0301
	v_mov_b32_e32 v88, v1                                      // 0000001B7390: 7EB00301
	v_mov_b32_e32 v89, v1                                      // 0000001B7394: 7EB20301
	v_mov_b32_e32 v90, v1                                      // 0000001B7398: 7EB40301
	v_mov_b32_e32 v91, v1                                      // 0000001B739C: 7EB60301
	v_mov_b32_e32 v92, v1                                      // 0000001B73A0: 7EB80301
	v_mov_b32_e32 v93, v1                                      // 0000001B73A4: 7EBA0301
	v_mov_b32_e32 v94, v1                                      // 0000001B73A8: 7EBC0301
	v_mov_b32_e32 v95, v1                                      // 0000001B73AC: 7EBE0301
	v_mov_b32_e32 v96, v1                                      // 0000001B73B0: 7EC00301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001B73B4: 8C7E007E
	ds_load_b128 v[17:20], v127                                // 0000001B73B8: DBFC0000 1100007F
	ds_load_b128 v[21:24], v127 offset:16                      // 0000001B73C0: DBFC0010 1500007F
	ds_load_b128 v[25:28], v127 offset:32                      // 0000001B73C8: DBFC0020 1900007F
	ds_load_b128 v[29:32], v127 offset:48                      // 0000001B73D0: DBFC0030 1D00007F
	ds_load_b128 v[41:44], v127 offset:8448                    // 0000001B73D8: DBFC2100 2900007F
	ds_load_b128 v[45:48], v127 offset:8464                    // 0000001B73E0: DBFC2110 2D00007F
	ds_load_b128 v[49:52], v127 offset:8480                    // 0000001B73E8: DBFC2120 3100007F
	ds_load_b128 v[53:56], v127 offset:8496                    // 0000001B73F0: DBFC2130 3500007F
	ds_load_b128 v[99:102], v127 offset:16896                  // 0000001B73F8: DBFC4200 6300007F
	ds_load_b128 v[180:183], v127 offset:16912                 // 0000001B7400: DBFC4210 B400007F
	v_dual_mov_b32 v179, s43 :: v_dual_mov_b32 v178, s42       // 0000001B7408: CA10002B B3B2002A
	v_dual_mov_b32 v177, s41 :: v_dual_mov_b32 v176, s40       // 0000001B7410: CA100029 B1B00028
	v_dual_mov_b32 v175, s39 :: v_dual_mov_b32 v174, s38       // 0000001B7418: CA100027 AFAE0026
	v_dual_mov_b32 v173, s37 :: v_dual_mov_b32 v172, s36       // 0000001B7420: CA100025 ADAC0024
	ds_load_b128 v[184:187], v127 offset:25344                 // 0000001B7428: DBFC6300 B800007F
	ds_load_b128 v[188:191], v127 offset:25360                 // 0000001B7430: DBFC6310 BC00007F
	s_waitcnt lgkmcnt(11)                                      // 0000001B7438: BF89FCB7
	v_fma_mixlo_f16 v17, v17, s22, 0                           // 0000001B743C: CC210011 02002D11
	v_fma_mixhi_f16 v17, v18, s22, 0                           // 0000001B7444: CC220011 02002D12
	v_fma_mixlo_f16 v18, v19, s22, 0                           // 0000001B744C: CC210012 02002D13
	v_fma_mixhi_f16 v18, v20, s22, 0                           // 0000001B7454: CC220012 02002D14
	s_waitcnt lgkmcnt(10)                                      // 0000001B745C: BF89FCA7
	v_fma_mixlo_f16 v19, v21, s22, 0                           // 0000001B7460: CC210013 02002D15
	v_fma_mixhi_f16 v19, v22, s22, 0                           // 0000001B7468: CC220013 02002D16
	v_fma_mixlo_f16 v20, v23, s22, 0                           // 0000001B7470: CC210014 02002D17
	v_fma_mixhi_f16 v20, v24, s22, 0                           // 0000001B7478: CC220014 02002D18
	s_waitcnt lgkmcnt(9)                                       // 0000001B7480: BF89FC97
	v_fma_mixlo_f16 v21, v25, s22, 0                           // 0000001B7484: CC210015 02002D19
	v_fma_mixhi_f16 v21, v26, s22, 0                           // 0000001B748C: CC220015 02002D1A
	v_fma_mixlo_f16 v22, v27, s22, 0                           // 0000001B7494: CC210016 02002D1B
	v_fma_mixhi_f16 v22, v28, s22, 0                           // 0000001B749C: CC220016 02002D1C
	s_waitcnt lgkmcnt(8)                                       // 0000001B74A4: BF89FC87
	v_fma_mixlo_f16 v23, v29, s22, 0                           // 0000001B74A8: CC210017 02002D1D
	v_fma_mixhi_f16 v23, v30, s22, 0                           // 0000001B74B0: CC220017 02002D1E
	v_fma_mixlo_f16 v24, v31, s22, 0                           // 0000001B74B8: CC210018 02002D1F
	v_fma_mixhi_f16 v24, v32, s22, 0                           // 0000001B74C0: CC220018 02002D20
	s_waitcnt lgkmcnt(7)                                       // 0000001B74C8: BF89FC77
	v_fma_mixlo_f16 v25, v41, s22, 0                           // 0000001B74CC: CC210019 02002D29
	v_fma_mixhi_f16 v25, v42, s22, 0                           // 0000001B74D4: CC220019 02002D2A
	v_fma_mixlo_f16 v26, v43, s22, 0                           // 0000001B74DC: CC21001A 02002D2B
	v_fma_mixhi_f16 v26, v44, s22, 0                           // 0000001B74E4: CC22001A 02002D2C
	s_waitcnt lgkmcnt(6)                                       // 0000001B74EC: BF89FC67
	v_fma_mixlo_f16 v27, v45, s22, 0                           // 0000001B74F0: CC21001B 02002D2D
	v_fma_mixhi_f16 v27, v46, s22, 0                           // 0000001B74F8: CC22001B 02002D2E
	v_fma_mixlo_f16 v28, v47, s22, 0                           // 0000001B7500: CC21001C 02002D2F
	v_fma_mixhi_f16 v28, v48, s22, 0                           // 0000001B7508: CC22001C 02002D30
	s_waitcnt lgkmcnt(5)                                       // 0000001B7510: BF89FC57
	v_fma_mixlo_f16 v29, v49, s22, 0                           // 0000001B7514: CC21001D 02002D31
	v_fma_mixhi_f16 v29, v50, s22, 0                           // 0000001B751C: CC22001D 02002D32
	v_fma_mixlo_f16 v30, v51, s22, 0                           // 0000001B7524: CC21001E 02002D33
	v_fma_mixhi_f16 v30, v52, s22, 0                           // 0000001B752C: CC22001E 02002D34
	s_waitcnt lgkmcnt(4)                                       // 0000001B7534: BF89FC47
	v_fma_mixlo_f16 v31, v53, s22, 0                           // 0000001B7538: CC21001F 02002D35
	v_fma_mixhi_f16 v31, v54, s22, 0                           // 0000001B7540: CC22001F 02002D36
	v_fma_mixlo_f16 v32, v55, s22, 0                           // 0000001B7548: CC210020 02002D37
	v_fma_mixhi_f16 v32, v56, s22, 0                           // 0000001B7550: CC220020 02002D38
	s_waitcnt vmcnt(14)                                        // 0000001B7558: BF893BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[17:24], v[172:179]// 0000001B755C: CC404029 1EB22359
	ds_load_b128 v[49:52], v127 offset:16928                   // 0000001B7564: DBFC4220 3100007F
	ds_load_b128 v[53:56], v127 offset:16944                   // 0000001B756C: DBFC4230 3500007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[25:32], v[172:179]// 0000001B7574: CC404011 1EB23359
	s_waitcnt lgkmcnt(5)                                       // 0000001B757C: BF89FC57
	v_fma_mixlo_f16 v25, v99, s22, 0                           // 0000001B7580: CC210019 02002D63
	v_fma_mixhi_f16 v25, v100, s22, 0                          // 0000001B7588: CC220019 02002D64
	v_fma_mixlo_f16 v26, v101, s22, 0                          // 0000001B7590: CC21001A 02002D65
	v_fma_mixhi_f16 v26, v102, s22, 0                          // 0000001B7598: CC22001A 02002D66
	ds_load_b128 v[99:102], v127 offset:25376                  // 0000001B75A0: DBFC6320 6300007F
	ds_load_b128 v[192:195], v127 offset:25392                 // 0000001B75A8: DBFC6330 C000007F
	s_waitcnt lgkmcnt(6)                                       // 0000001B75B0: BF89FC67
	v_fma_mixlo_f16 v27, v180, s22, 0                          // 0000001B75B4: CC21001B 02002DB4
	s_waitcnt lgkmcnt(5)                                       // 0000001B75BC: BF89FC57
	v_fma_mixlo_f16 v180, v184, s22, 0                         // 0000001B75C0: CC2100B4 02002DB8
	v_fma_mixhi_f16 v180, v185, s22, 0                         // 0000001B75C8: CC2200B4 02002DB9
	v_fma_mixhi_f16 v27, v181, s22, 0                          // 0000001B75D0: CC22001B 02002DB5
	v_fma_mixlo_f16 v28, v182, s22, 0                          // 0000001B75D8: CC21001C 02002DB6
	v_fma_mixhi_f16 v28, v183, s22, 0                          // 0000001B75E0: CC22001C 02002DB7
	v_fma_mixlo_f16 v181, v186, s22, 0                         // 0000001B75E8: CC2100B5 02002DBA
	v_fma_mixhi_f16 v181, v187, s22, 0                         // 0000001B75F0: CC2200B5 02002DBB
	s_waitcnt lgkmcnt(4)                                       // 0000001B75F8: BF89FC47
	v_fma_mixlo_f16 v182, v188, s22, 0                         // 0000001B75FC: CC2100B6 02002DBC
	v_fma_mixhi_f16 v182, v189, s22, 0                         // 0000001B7604: CC2200B6 02002DBD
	s_waitcnt lgkmcnt(3)                                       // 0000001B760C: BF89FC37
	v_fma_mixlo_f16 v29, v49, s22, 0                           // 0000001B7610: CC21001D 02002D31
	v_fma_mixhi_f16 v29, v50, s22, 0                           // 0000001B7618: CC22001D 02002D32
	v_fma_mixlo_f16 v30, v51, s22, 0                           // 0000001B7620: CC21001E 02002D33
	v_fma_mixhi_f16 v30, v52, s22, 0                           // 0000001B7628: CC22001E 02002D34
	s_waitcnt lgkmcnt(2)                                       // 0000001B7630: BF89FC27
	v_fma_mixlo_f16 v31, v53, s22, 0                           // 0000001B7634: CC21001F 02002D35
	v_fma_mixhi_f16 v31, v54, s22, 0                           // 0000001B763C: CC22001F 02002D36
	v_fma_mixlo_f16 v32, v55, s22, 0                           // 0000001B7644: CC210020 02002D37
	v_fma_mixhi_f16 v32, v56, s22, 0                           // 0000001B764C: CC220020 02002D38
	s_waitcnt lgkmcnt(1)                                       // 0000001B7654: BF89FC17
	v_fma_mixlo_f16 v184, v99, s22, 0                          // 0000001B7658: CC2100B8 02002D63
	v_fma_mixhi_f16 v184, v100, s22, 0                         // 0000001B7660: CC2200B8 02002D64
	v_fma_mixlo_f16 v185, v101, s22, 0                         // 0000001B7668: CC2100B9 02002D65
	v_fma_mixhi_f16 v185, v102, s22, 0                         // 0000001B7670: CC2200B9 02002D66
	ds_load_b128 v[99:102], v127 offset:96                     // 0000001B7678: DBFC0060 6300007F
	v_fma_mixlo_f16 v183, v190, s22, 0                         // 0000001B7680: CC2100B7 02002DBE
	v_fma_mixhi_f16 v183, v191, s22, 0                         // 0000001B7688: CC2200B7 02002DBF
	s_waitcnt lgkmcnt(1)                                       // 0000001B7690: BF89FC17
	v_fma_mixlo_f16 v186, v192, s22, 0                         // 0000001B7694: CC2100BA 02002DC0
	v_fma_mixhi_f16 v186, v193, s22, 0                         // 0000001B769C: CC2200BA 02002DC1
	v_fma_mixlo_f16 v187, v194, s22, 0                         // 0000001B76A4: CC2100BB 02002DC2
	v_fma_mixhi_f16 v187, v195, s22, 0                         // 0000001B76AC: CC2200BB 02002DC3
	ds_load_b128 v[196:199], v127 offset:64                    // 0000001B76B4: DBFC0040 C400007F
	ds_load_b128 v[188:191], v127 offset:80                    // 0000001B76BC: DBFC0050 BC00007F
	ds_load_b128 v[192:195], v127 offset:112                   // 0000001B76C4: DBFC0070 C000007F
	v_wmma_f32_16x16x16_f16 v[49:56], v[89:96], v[25:32], v[172:179]// 0000001B76CC: CC404031 1EB23359
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[180:187], v[172:179]// 0000001B76D4: CC404019 1EB36959
	ds_load_b128 v[172:175], v127 offset:8512                  // 0000001B76DC: DBFC2140 AC00007F
	ds_load_b128 v[176:179], v127 offset:8528                  // 0000001B76E4: DBFC2150 B000007F
	ds_load_b128 v[180:183], v127 offset:8544                  // 0000001B76EC: DBFC2160 B400007F
	ds_load_b128 v[184:187], v127 offset:16960                 // 0000001B76F4: DBFC4240 B800007F
	ds_load_b128 v[200:203], v127 offset:25424                 // 0000001B76FC: DBFC6350 C800007F
	ds_load_b128 v[204:207], v127 offset:25440                 // 0000001B7704: DBFC6360 CC00007F
	ds_load_b128 v[208:211], v127 offset:25456                 // 0000001B770C: DBFC6370 D000007F
	s_waitcnt lgkmcnt(10)                                      // 0000001B7714: BF89FCA7
	v_fma_mixlo_f16 v93, v99, s22, 0                           // 0000001B7718: CC21005D 02002D63
	v_fma_mixhi_f16 v93, v100, s22, 0                          // 0000001B7720: CC22005D 02002D64
	v_fma_mixlo_f16 v94, v101, s22, 0                          // 0000001B7728: CC21005E 02002D65
	v_fma_mixhi_f16 v94, v102, s22, 0                          // 0000001B7730: CC22005E 02002D66
	ds_load_b128 v[99:102], v127 offset:8560                   // 0000001B7738: DBFC2170 6300007F
	s_waitcnt lgkmcnt(10)                                      // 0000001B7740: BF89FCA7
	v_fma_mixlo_f16 v89, v196, s22, 0                          // 0000001B7744: CC210059 02002DC4
	s_waitcnt lgkmcnt(9)                                       // 0000001B774C: BF89FC97
	v_fma_mixlo_f16 v91, v188, s22, 0                          // 0000001B7750: CC21005B 02002DBC
	v_fma_mixhi_f16 v91, v189, s22, 0                          // 0000001B7758: CC22005B 02002DBD
	v_fma_mixlo_f16 v92, v190, s22, 0                          // 0000001B7760: CC21005C 02002DBE
	v_fma_mixhi_f16 v92, v191, s22, 0                          // 0000001B7768: CC22005C 02002DBF
	ds_load_b128 v[188:191], v127 offset:16976                 // 0000001B7770: DBFC4250 BC00007F
	v_fma_mixhi_f16 v89, v197, s22, 0                          // 0000001B7778: CC220059 02002DC5
	s_waitcnt lgkmcnt(8)                                       // 0000001B7780: BF89FC87
	v_fma_mixlo_f16 v172, v172, s22, 0                         // 0000001B7784: CC2100AC 02002DAC
	v_fma_mixhi_f16 v172, v173, s22, 0                         // 0000001B778C: CC2200AC 02002DAD
	v_fma_mixhi_f16 v173, v175, s22, 0                         // 0000001B7794: CC2200AD 02002DAF
	s_waitcnt lgkmcnt(7)                                       // 0000001B779C: BF89FC77
	v_fma_mixlo_f16 v175, v178, s22, 0                         // 0000001B77A0: CC2100AF 02002DB2
	v_fma_mixhi_f16 v175, v179, s22, 0                         // 0000001B77A8: CC2200AF 02002DB3
	v_fma_mixlo_f16 v90, v198, s22, 0                          // 0000001B77B0: CC21005A 02002DC6
	v_fma_mixhi_f16 v90, v199, s22, 0                          // 0000001B77B8: CC22005A 02002DC7
	v_fma_mixlo_f16 v95, v192, s22, 0                          // 0000001B77C0: CC21005F 02002DC0
	v_fma_mixhi_f16 v95, v193, s22, 0                          // 0000001B77C8: CC22005F 02002DC1
	v_fma_mixlo_f16 v96, v194, s22, 0                          // 0000001B77D0: CC210060 02002DC2
	v_fma_mixhi_f16 v96, v195, s22, 0                          // 0000001B77D8: CC220060 02002DC3
	s_waitcnt lgkmcnt(1)                                       // 0000001B77E0: BF89FC17
	v_fma_mixlo_f16 v178, v99, s22, 0                          // 0000001B77E4: CC2100B2 02002D63
	v_fma_mixhi_f16 v178, v100, s22, 0                         // 0000001B77EC: CC2200B2 02002D64
	v_fma_mixlo_f16 v179, v101, s22, 0                         // 0000001B77F4: CC2100B3 02002D65
	v_fma_mixhi_f16 v179, v102, s22, 0                         // 0000001B77FC: CC2200B3 02002D66
	ds_load_b128 v[99:102], v127 offset:25408                  // 0000001B7804: DBFC6340 6300007F
	ds_load_b128 v[192:195], v127 offset:16992                 // 0000001B780C: DBFC4260 C000007F
	ds_load_b128 v[196:199], v127 offset:17008                 // 0000001B7814: DBFC4270 C400007F
	v_fma_mixlo_f16 v173, v174, s22, 0                         // 0000001B781C: CC2100AD 02002DAE
	v_fma_mixhi_f16 v174, v177, s22, 0                         // 0000001B7824: CC2200AE 02002DB1
	v_fma_mixlo_f16 v177, v182, s22, 0                         // 0000001B782C: CC2100B1 02002DB6
	s_waitcnt lgkmcnt(3)                                       // 0000001B7834: BF89FC37
	v_fma_mixlo_f16 v182, v188, s22, 0                         // 0000001B7838: CC2100B6 02002DBC
	v_fma_mixhi_f16 v182, v189, s22, 0                         // 0000001B7840: CC2200B6 02002DBD
	v_fma_mixlo_f16 v174, v176, s22, 0                         // 0000001B7848: CC2100AE 02002DB0
	v_fma_mixlo_f16 v176, v180, s22, 0                         // 0000001B7850: CC2100B0 02002DB4
	v_fma_mixhi_f16 v176, v181, s22, 0                         // 0000001B7858: CC2200B0 02002DB5
	v_fma_mixhi_f16 v177, v183, s22, 0                         // 0000001B7860: CC2200B1 02002DB7
	v_fma_mixlo_f16 v180, v184, s22, 0                         // 0000001B7868: CC2100B4 02002DB8
	v_fma_mixhi_f16 v180, v185, s22, 0                         // 0000001B7870: CC2200B4 02002DB9
	v_fma_mixlo_f16 v181, v186, s22, 0                         // 0000001B7878: CC2100B5 02002DBA
	v_fma_mixhi_f16 v181, v187, s22, 0                         // 0000001B7880: CC2200B5 02002DBB
	v_fma_mixlo_f16 v183, v190, s22, 0                         // 0000001B7888: CC2100B7 02002DBE
	v_fma_mixhi_f16 v183, v191, s22, 0                         // 0000001B7890: CC2200B7 02002DBF
	v_fma_mixlo_f16 v190, v200, s22, 0                         // 0000001B7898: CC2100BE 02002DC8
	v_fma_mixhi_f16 v190, v201, s22, 0                         // 0000001B78A0: CC2200BE 02002DC9
	s_waitcnt lgkmcnt(2)                                       // 0000001B78A8: BF89FC27
	v_fma_mixlo_f16 v188, v99, s22, 0                          // 0000001B78AC: CC2100BC 02002D63
	v_fma_mixhi_f16 v188, v100, s22, 0                         // 0000001B78B4: CC2200BC 02002D64
	v_fma_mixlo_f16 v189, v101, s22, 0                         // 0000001B78BC: CC2100BD 02002D65
	v_fma_mixhi_f16 v189, v102, s22, 0                         // 0000001B78C4: CC2200BD 02002D66
	ds_load_b128 v[99:102], v127 offset:128                    // 0000001B78CC: DBFC0080 6300007F
	s_waitcnt lgkmcnt(2)                                       // 0000001B78D4: BF89FC27
	v_fma_mixlo_f16 v184, v192, s22, 0                         // 0000001B78D8: CC2100B8 02002DC0
	v_fma_mixhi_f16 v184, v193, s22, 0                         // 0000001B78E0: CC2200B8 02002DC1
	v_fma_mixlo_f16 v185, v194, s22, 0                         // 0000001B78E8: CC2100B9 02002DC2
	v_fma_mixhi_f16 v185, v195, s22, 0                         // 0000001B78F0: CC2200B9 02002DC3
	s_waitcnt lgkmcnt(1)                                       // 0000001B78F8: BF89FC17
	v_fma_mixlo_f16 v186, v196, s22, 0                         // 0000001B78FC: CC2100BA 02002DC4
	v_fma_mixhi_f16 v186, v197, s22, 0                         // 0000001B7904: CC2200BA 02002DC5
	v_fma_mixlo_f16 v187, v198, s22, 0                         // 0000001B790C: CC2100BB 02002DC6
	v_fma_mixhi_f16 v187, v199, s22, 0                         // 0000001B7914: CC2200BB 02002DC7
	v_fma_mixlo_f16 v191, v202, s22, 0                         // 0000001B791C: CC2100BF 02002DCA
	v_fma_mixhi_f16 v191, v203, s22, 0                         // 0000001B7924: CC2200BF 02002DCB
	v_fma_mixlo_f16 v192, v204, s22, 0                         // 0000001B792C: CC2100C0 02002DCC
	v_fma_mixhi_f16 v192, v205, s22, 0                         // 0000001B7934: CC2200C0 02002DCD
	v_fma_mixlo_f16 v193, v206, s22, 0                         // 0000001B793C: CC2100C1 02002DCE
	v_fma_mixhi_f16 v193, v207, s22, 0                         // 0000001B7944: CC2200C1 02002DCF
	v_fma_mixlo_f16 v194, v208, s22, 0                         // 0000001B794C: CC2100C2 02002DD0
	v_fma_mixhi_f16 v194, v209, s22, 0                         // 0000001B7954: CC2200C2 02002DD1
	v_fma_mixlo_f16 v195, v210, s22, 0                         // 0000001B795C: CC2100C3 02002DD2
	v_fma_mixhi_f16 v195, v211, s22, 0                         // 0000001B7964: CC2200C3 02002DD3
	ds_load_b128 v[196:199], v127 offset:144                   // 0000001B796C: DBFC0090 C400007F
	ds_load_b128 v[200:203], v127 offset:160                   // 0000001B7974: DBFC00A0 C800007F
	s_waitcnt vmcnt(12)                                        // 0000001B797C: BF8933F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[89:96], v[41:48]// 0000001B7980: CC404029 1CA6B351
	ds_load_b128 v[89:92], v127 offset:176                     // 0000001B7988: DBFC00B0 5900007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[172:179], v[17:24]// 0000001B7990: CC404011 1C475951
	v_wmma_f32_16x16x16_f16 v[49:56], v[81:88], v[180:187], v[49:56]// 0000001B7998: CC404031 1CC76951
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[188:195], v[25:32]// 0000001B79A0: CC404019 1C677951
	ds_load_b128 v[93:96], v127 offset:8576                    // 0000001B79A8: DBFC2180 5D00007F
	s_waitcnt lgkmcnt(4)                                       // 0000001B79B0: BF89FC47
	v_fma_mixlo_f16 v81, v99, s22, 0                           // 0000001B79B4: CC210051 02002D63
	v_fma_mixhi_f16 v81, v100, s22, 0                          // 0000001B79BC: CC220051 02002D64
	v_fma_mixlo_f16 v82, v101, s22, 0                          // 0000001B79C4: CC210052 02002D65
	v_fma_mixhi_f16 v82, v102, s22, 0                          // 0000001B79CC: CC220052 02002D66
	ds_load_b128 v[99:102], v127 offset:8592                   // 0000001B79D4: DBFC2190 6300007F
	ds_load_b128 v[172:175], v127 offset:8608                  // 0000001B79DC: DBFC21A0 AC00007F
	ds_load_b128 v[176:179], v127 offset:8624                  // 0000001B79E4: DBFC21B0 B000007F
	ds_load_b128 v[180:183], v127 offset:17024                 // 0000001B79EC: DBFC4280 B400007F
	ds_load_b128 v[184:187], v127 offset:17040                 // 0000001B79F4: DBFC4290 B800007F
	ds_load_b128 v[188:191], v127 offset:17072                 // 0000001B79FC: DBFC42B0 BC00007F
	ds_load_b128 v[192:195], v127 offset:25472                 // 0000001B7A04: DBFC6380 C000007F
	ds_load_b128 v[204:207], v127 offset:25520                 // 0000001B7A0C: DBFC63B0 CC00007F
	s_waitcnt lgkmcnt(11)                                      // 0000001B7A14: BF89FCB7
	v_fma_mixlo_f16 v83, v196, s22, 0                          // 0000001B7A18: CC210053 02002DC4
	v_fma_mixhi_f16 v83, v197, s22, 0                          // 0000001B7A20: CC220053 02002DC5
	v_fma_mixlo_f16 v84, v198, s22, 0                          // 0000001B7A28: CC210054 02002DC6
	s_waitcnt lgkmcnt(9)                                       // 0000001B7A30: BF89FC97
	v_fma_mixlo_f16 v88, v91, s22, 0                           // 0000001B7A34: CC210058 02002D5B
	v_fma_mixhi_f16 v88, v92, s22, 0                           // 0000001B7A3C: CC220058 02002D5C
	v_fma_mixhi_f16 v84, v199, s22, 0                          // 0000001B7A44: CC220054 02002DC7
	v_fma_mixlo_f16 v85, v200, s22, 0                          // 0000001B7A4C: CC210055 02002DC8
	v_fma_mixhi_f16 v85, v201, s22, 0                          // 0000001B7A54: CC220055 02002DC9
	v_fma_mixlo_f16 v86, v202, s22, 0                          // 0000001B7A5C: CC210056 02002DCA
	v_fma_mixhi_f16 v86, v203, s22, 0                          // 0000001B7A64: CC220056 02002DCB
	ds_load_b128 v[196:199], v127 offset:25488                 // 0000001B7A6C: DBFC6390 C400007F
	ds_load_b128 v[200:203], v127 offset:25504                 // 0000001B7A74: DBFC63A0 C800007F
	s_waitcnt lgkmcnt(9)                                       // 0000001B7A7C: BF89FC97
	v_fma_mixlo_f16 v91, v99, s22, 0                           // 0000001B7A80: CC21005B 02002D63
	v_fma_mixhi_f16 v91, v100, s22, 0                          // 0000001B7A88: CC22005B 02002D64
	v_fma_mixlo_f16 v92, v101, s22, 0                          // 0000001B7A90: CC21005C 02002D65
	v_fma_mixhi_f16 v92, v102, s22, 0                          // 0000001B7A98: CC22005C 02002D66
	ds_load_b128 v[99:102], v127 offset:17056                  // 0000001B7AA0: DBFC42A0 6300007F
	v_fma_mixhi_f16 v87, v90, s22, 0                           // 0000001B7AA8: CC220057 02002D5A
	v_fma_mixlo_f16 v90, v95, s22, 0                           // 0000001B7AB0: CC21005A 02002D5F
	s_waitcnt lgkmcnt(8)                                       // 0000001B7AB8: BF89FC87
	v_fma_mixlo_f16 v95, v176, s22, 0                          // 0000001B7ABC: CC21005F 02002DB0
	v_fma_mixhi_f16 v95, v177, s22, 0                          // 0000001B7AC4: CC22005F 02002DB1
	v_fma_mixlo_f16 v87, v89, s22, 0                           // 0000001B7ACC: CC210057 02002D59
	v_fma_mixlo_f16 v89, v93, s22, 0                           // 0000001B7AD4: CC210059 02002D5D
	v_fma_mixhi_f16 v89, v94, s22, 0                           // 0000001B7ADC: CC220059 02002D5E
	v_fma_mixhi_f16 v90, v96, s22, 0                           // 0000001B7AE4: CC22005A 02002D60
	v_fma_mixlo_f16 v93, v172, s22, 0                          // 0000001B7AEC: CC21005D 02002DAC
	v_fma_mixhi_f16 v93, v173, s22, 0                          // 0000001B7AF4: CC22005D 02002DAD
	v_fma_mixlo_f16 v94, v174, s22, 0                          // 0000001B7AFC: CC21005E 02002DAE
	v_fma_mixhi_f16 v94, v175, s22, 0                          // 0000001B7B04: CC22005E 02002DAF
	v_fma_mixlo_f16 v96, v178, s22, 0                          // 0000001B7B0C: CC210060 02002DB2
	v_fma_mixhi_f16 v96, v179, s22, 0                          // 0000001B7B14: CC220060 02002DB3
	s_waitcnt lgkmcnt(7)                                       // 0000001B7B1C: BF89FC77
	v_fma_mixlo_f16 v172, v180, s22, 0                         // 0000001B7B20: CC2100AC 02002DB4
	v_fma_mixhi_f16 v172, v181, s22, 0                         // 0000001B7B28: CC2200AC 02002DB5
	v_fma_mixlo_f16 v173, v182, s22, 0                         // 0000001B7B30: CC2100AD 02002DB6
	v_fma_mixhi_f16 v173, v183, s22, 0                         // 0000001B7B38: CC2200AD 02002DB7
	s_waitcnt lgkmcnt(6)                                       // 0000001B7B40: BF89FC67
	v_fma_mixlo_f16 v174, v184, s22, 0                         // 0000001B7B44: CC2100AE 02002DB8
	s_waitcnt lgkmcnt(0)                                       // 0000001B7B4C: BF89FC07
	v_fma_mixlo_f16 v176, v99, s22, 0                          // 0000001B7B50: CC2100B0 02002D63
	v_fma_mixhi_f16 v176, v100, s22, 0                         // 0000001B7B58: CC2200B0 02002D64
	v_fma_mixlo_f16 v177, v101, s22, 0                         // 0000001B7B60: CC2100B1 02002D65
	v_fma_mixhi_f16 v177, v102, s22, 0                         // 0000001B7B68: CC2200B1 02002D66
	ds_load_b128 v[99:102], v127 offset:192                    // 0000001B7B70: DBFC00C0 6300007F
	v_fma_mixhi_f16 v174, v185, s22, 0                         // 0000001B7B78: CC2200AE 02002DB9
	v_fma_mixlo_f16 v175, v186, s22, 0                         // 0000001B7B80: CC2100AF 02002DBA
	v_fma_mixhi_f16 v175, v187, s22, 0                         // 0000001B7B88: CC2200AF 02002DBB
	v_fma_mixlo_f16 v178, v188, s22, 0                         // 0000001B7B90: CC2100B2 02002DBC
	v_fma_mixhi_f16 v178, v189, s22, 0                         // 0000001B7B98: CC2200B2 02002DBD
	v_fma_mixlo_f16 v179, v190, s22, 0                         // 0000001B7BA0: CC2100B3 02002DBE
	v_fma_mixhi_f16 v179, v191, s22, 0                         // 0000001B7BA8: CC2200B3 02002DBF
	v_fma_mixlo_f16 v180, v192, s22, 0                         // 0000001B7BB0: CC2100B4 02002DC0
	v_fma_mixhi_f16 v180, v193, s22, 0                         // 0000001B7BB8: CC2200B4 02002DC1
	v_fma_mixlo_f16 v181, v194, s22, 0                         // 0000001B7BC0: CC2100B5 02002DC2
	v_fma_mixhi_f16 v181, v195, s22, 0                         // 0000001B7BC8: CC2200B5 02002DC3
	v_fma_mixlo_f16 v182, v196, s22, 0                         // 0000001B7BD0: CC2100B6 02002DC4
	v_fma_mixhi_f16 v182, v197, s22, 0                         // 0000001B7BD8: CC2200B6 02002DC5
	v_fma_mixlo_f16 v183, v198, s22, 0                         // 0000001B7BE0: CC2100B7 02002DC6
	v_fma_mixhi_f16 v183, v199, s22, 0                         // 0000001B7BE8: CC2200B7 02002DC7
	v_fma_mixlo_f16 v184, v200, s22, 0                         // 0000001B7BF0: CC2100B8 02002DC8
	v_fma_mixhi_f16 v184, v201, s22, 0                         // 0000001B7BF8: CC2200B8 02002DC9
	v_fma_mixlo_f16 v185, v202, s22, 0                         // 0000001B7C00: CC2100B9 02002DCA
	v_fma_mixhi_f16 v185, v203, s22, 0                         // 0000001B7C08: CC2200B9 02002DCB
	v_fma_mixlo_f16 v186, v204, s22, 0                         // 0000001B7C10: CC2100BA 02002DCC
	v_fma_mixhi_f16 v186, v205, s22, 0                         // 0000001B7C18: CC2200BA 02002DCD
	v_fma_mixlo_f16 v187, v206, s22, 0                         // 0000001B7C20: CC2100BB 02002DCE
	v_fma_mixhi_f16 v187, v207, s22, 0                         // 0000001B7C28: CC2200BB 02002DCF
	ds_load_b128 v[188:191], v127 offset:208                   // 0000001B7C30: DBFC00D0 BC00007F
	ds_load_b128 v[192:195], v127 offset:224                   // 0000001B7C38: DBFC00E0 C000007F
	s_waitcnt vmcnt(10)                                        // 0000001B7C40: BF892BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[73:80], v[81:88], v[41:48]// 0000001B7C44: CC404029 1CA6A349
	ds_load_b128 v[81:84], v127 offset:240                     // 0000001B7C4C: DBFC00F0 5100007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[89:96], v[17:24]// 0000001B7C54: CC404011 1C46B349
	v_wmma_f32_16x16x16_f16 v[49:56], v[73:80], v[172:179], v[49:56]// 0000001B7C5C: CC404031 1CC75949
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[180:187], v[25:32]// 0000001B7C64: CC404019 1C676949
	ds_load_b128 v[85:88], v127 offset:8640                    // 0000001B7C6C: DBFC21C0 5500007F
	ds_load_b128 v[89:92], v127 offset:8656                    // 0000001B7C74: DBFC21D0 5900007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B7C7C: BF89FC57
	v_fma_mixlo_f16 v73, v99, s22, 0                           // 0000001B7C80: CC210049 02002D63
	v_fma_mixhi_f16 v73, v100, s22, 0                          // 0000001B7C88: CC220049 02002D64
	v_fma_mixlo_f16 v74, v101, s22, 0                          // 0000001B7C90: CC21004A 02002D65
	v_fma_mixhi_f16 v74, v102, s22, 0                          // 0000001B7C98: CC22004A 02002D66
	ds_load_b128 v[93:96], v127 offset:8672                    // 0000001B7CA0: DBFC21E0 5D00007F
	ds_load_b128 v[99:102], v127 offset:8688                   // 0000001B7CA8: DBFC21F0 6300007F
	ds_load_b128 v[172:175], v127 offset:17088                 // 0000001B7CB0: DBFC42C0 AC00007F
	ds_load_b128 v[176:179], v127 offset:17104                 // 0000001B7CB8: DBFC42D0 B000007F
	ds_load_b128 v[180:183], v127 offset:17120                 // 0000001B7CC0: DBFC42E0 B400007F
	ds_load_b128 v[184:187], v127 offset:17136                 // 0000001B7CC8: DBFC42F0 B800007F
	s_waitcnt lgkmcnt(10)                                      // 0000001B7CD0: BF89FCA7
	v_fma_mixlo_f16 v75, v188, s22, 0                          // 0000001B7CD4: CC21004B 02002DBC
	v_fma_mixhi_f16 v75, v189, s22, 0                          // 0000001B7CDC: CC22004B 02002DBD
	v_fma_mixlo_f16 v76, v190, s22, 0                          // 0000001B7CE4: CC21004C 02002DBE
	s_waitcnt lgkmcnt(8)                                       // 0000001B7CEC: BF89FC87
	v_fma_mixhi_f16 v79, v82, s22, 0                           // 0000001B7CF0: CC22004F 02002D52
	v_fma_mixhi_f16 v76, v191, s22, 0                          // 0000001B7CF8: CC22004C 02002DBF
	v_fma_mixlo_f16 v77, v192, s22, 0                          // 0000001B7D00: CC21004D 02002DC0
	v_fma_mixhi_f16 v77, v193, s22, 0                          // 0000001B7D08: CC22004D 02002DC1
	s_waitcnt lgkmcnt(7)                                       // 0000001B7D10: BF89FC77
	v_fma_mixlo_f16 v82, v87, s22, 0                           // 0000001B7D14: CC210052 02002D57
	v_fma_mixhi_f16 v82, v88, s22, 0                           // 0000001B7D1C: CC220052 02002D58
	v_fma_mixlo_f16 v78, v194, s22, 0                          // 0000001B7D24: CC21004E 02002DC2
	v_fma_mixhi_f16 v78, v195, s22, 0                          // 0000001B7D2C: CC22004E 02002DC3
	v_fma_mixlo_f16 v79, v81, s22, 0                           // 0000001B7D34: CC21004F 02002D51
	v_fma_mixhi_f16 v80, v84, s22, 0                           // 0000001B7D3C: CC220050 02002D54
	v_fma_mixlo_f16 v81, v85, s22, 0                           // 0000001B7D44: CC210051 02002D55
	s_waitcnt lgkmcnt(4)                                       // 0000001B7D4C: BF89FC47
	v_fma_mixlo_f16 v87, v99, s22, 0                           // 0000001B7D50: CC210057 02002D63
	v_fma_mixhi_f16 v87, v100, s22, 0                          // 0000001B7D58: CC220057 02002D64
	v_fma_mixlo_f16 v88, v101, s22, 0                          // 0000001B7D60: CC210058 02002D65
	v_fma_mixhi_f16 v88, v102, s22, 0                          // 0000001B7D68: CC220058 02002D66
	ds_load_b128 v[99:102], v127 offset:25536                  // 0000001B7D70: DBFC63C0 6300007F
	ds_load_b128 v[188:191], v127 offset:25552                 // 0000001B7D78: DBFC63D0 BC00007F
	v_fma_mixhi_f16 v84, v92, s22, 0                           // 0000001B7D80: CC220054 02002D5C
	v_fma_mixlo_f16 v85, v93, s22, 0                           // 0000001B7D88: CC210055 02002D5D
	s_waitcnt lgkmcnt(4)                                       // 0000001B7D90: BF89FC47
	v_fma_mixlo_f16 v92, v178, s22, 0                          // 0000001B7D94: CC21005C 02002DB2
	ds_load_b128 v[192:195], v127 offset:25568                 // 0000001B7D9C: DBFC63E0 C000007F
	v_fma_mixhi_f16 v92, v179, s22, 0                          // 0000001B7DA4: CC22005C 02002DB3
	s_waitcnt lgkmcnt(4)                                       // 0000001B7DAC: BF89FC47
	v_fma_mixlo_f16 v93, v180, s22, 0                          // 0000001B7DB0: CC21005D 02002DB4
	v_fma_mixhi_f16 v93, v181, s22, 0                          // 0000001B7DB8: CC22005D 02002DB5
	ds_load_b128 v[178:181], v127 offset:25584                 // 0000001B7DC0: DBFC63F0 B200007F
	v_fma_mixlo_f16 v80, v83, s22, 0                           // 0000001B7DC8: CC210050 02002D53
	v_fma_mixlo_f16 v83, v89, s22, 0                           // 0000001B7DD0: CC210053 02002D59
	v_fma_mixlo_f16 v89, v172, s22, 0                          // 0000001B7DD8: CC210059 02002DAC
	v_fma_mixhi_f16 v89, v173, s22, 0                          // 0000001B7DE0: CC220059 02002DAD
	v_fma_mixhi_f16 v81, v86, s22, 0                           // 0000001B7DE8: CC220051 02002D56
	v_fma_mixhi_f16 v83, v90, s22, 0                           // 0000001B7DF0: CC220053 02002D5A
	v_fma_mixlo_f16 v84, v91, s22, 0                           // 0000001B7DF8: CC210054 02002D5B
	v_fma_mixhi_f16 v85, v94, s22, 0                           // 0000001B7E00: CC220055 02002D5E
	v_fma_mixlo_f16 v86, v95, s22, 0                           // 0000001B7E08: CC210056 02002D5F
	v_fma_mixhi_f16 v86, v96, s22, 0                           // 0000001B7E10: CC220056 02002D60
	s_waitcnt lgkmcnt(3)                                       // 0000001B7E18: BF89FC37
	v_fma_mixlo_f16 v172, v99, s22, 0                          // 0000001B7E1C: CC2100AC 02002D63
	v_fma_mixhi_f16 v172, v100, s22, 0                         // 0000001B7E24: CC2200AC 02002D64
	v_fma_mixlo_f16 v173, v101, s22, 0                         // 0000001B7E2C: CC2100AD 02002D65
	v_fma_mixhi_f16 v173, v102, s22, 0                         // 0000001B7E34: CC2200AD 02002D66
	ds_load_b128 v[99:102], v127 offset:256                    // 0000001B7E3C: DBFC0100 6300007F
	v_fma_mixlo_f16 v90, v174, s22, 0                          // 0000001B7E44: CC21005A 02002DAE
	v_fma_mixhi_f16 v90, v175, s22, 0                          // 0000001B7E4C: CC22005A 02002DAF
	v_fma_mixlo_f16 v91, v176, s22, 0                          // 0000001B7E54: CC21005B 02002DB0
	v_fma_mixhi_f16 v91, v177, s22, 0                          // 0000001B7E5C: CC22005B 02002DB1
	v_fma_mixlo_f16 v94, v182, s22, 0                          // 0000001B7E64: CC21005E 02002DB6
	v_fma_mixhi_f16 v94, v183, s22, 0                          // 0000001B7E6C: CC22005E 02002DB7
	v_fma_mixlo_f16 v95, v184, s22, 0                          // 0000001B7E74: CC21005F 02002DB8
	v_fma_mixhi_f16 v95, v185, s22, 0                          // 0000001B7E7C: CC22005F 02002DB9
	v_fma_mixlo_f16 v96, v186, s22, 0                          // 0000001B7E84: CC210060 02002DBA
	v_fma_mixhi_f16 v96, v187, s22, 0                          // 0000001B7E8C: CC220060 02002DBB
	s_waitcnt lgkmcnt(3)                                       // 0000001B7E94: BF89FC37
	v_fma_mixlo_f16 v174, v188, s22, 0                         // 0000001B7E98: CC2100AE 02002DBC
	v_fma_mixhi_f16 v174, v189, s22, 0                         // 0000001B7EA0: CC2200AE 02002DBD
	v_fma_mixlo_f16 v175, v190, s22, 0                         // 0000001B7EA8: CC2100AF 02002DBE
	v_fma_mixhi_f16 v175, v191, s22, 0                         // 0000001B7EB0: CC2200AF 02002DBF
	s_waitcnt lgkmcnt(2)                                       // 0000001B7EB8: BF89FC27
	v_fma_mixlo_f16 v176, v192, s22, 0                         // 0000001B7EBC: CC2100B0 02002DC0
	v_fma_mixhi_f16 v176, v193, s22, 0                         // 0000001B7EC4: CC2200B0 02002DC1
	v_fma_mixlo_f16 v177, v194, s22, 0                         // 0000001B7ECC: CC2100B1 02002DC2
	v_fma_mixhi_f16 v177, v195, s22, 0                         // 0000001B7ED4: CC2200B1 02002DC3
	s_waitcnt lgkmcnt(1)                                       // 0000001B7EDC: BF89FC17
	v_fma_mixlo_f16 v178, v178, s22, 0                         // 0000001B7EE0: CC2100B2 02002DB2
	v_fma_mixhi_f16 v178, v179, s22, 0                         // 0000001B7EE8: CC2200B2 02002DB3
	v_fma_mixlo_f16 v179, v180, s22, 0                         // 0000001B7EF0: CC2100B3 02002DB4
	v_fma_mixhi_f16 v179, v181, s22, 0                         // 0000001B7EF8: CC2200B3 02002DB5
	ds_load_b128 v[182:185], v127 offset:272                   // 0000001B7F00: DBFC0110 B600007F
	ds_load_b128 v[186:189], v127 offset:288                   // 0000001B7F08: DBFC0120 BA00007F
	s_waitcnt vmcnt(8)                                         // 0000001B7F10: BF8923F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[73:80], v[41:48]// 0000001B7F14: CC404029 1CA69341
	ds_load_b128 v[73:76], v127 offset:304                     // 0000001B7F1C: DBFC0130 4900007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[65:72], v[81:88], v[17:24]// 0000001B7F24: CC404011 1C46A341
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[89:96], v[49:56]// 0000001B7F2C: CC404031 1CC6B341
	v_wmma_f32_16x16x16_f16 v[25:32], v[65:72], v[172:179], v[25:32]// 0000001B7F34: CC404019 1C675941
	ds_load_b128 v[77:80], v127 offset:8704                    // 0000001B7F3C: DBFC2200 4D00007F
	ds_load_b128 v[81:84], v127 offset:8720                    // 0000001B7F44: DBFC2210 5100007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B7F4C: BF89FC57
	v_fma_mixlo_f16 v65, v99, s22, 0                           // 0000001B7F50: CC210041 02002D63
	v_fma_mixhi_f16 v65, v100, s22, 0                          // 0000001B7F58: CC220041 02002D64
	v_fma_mixlo_f16 v66, v101, s22, 0                          // 0000001B7F60: CC210042 02002D65
	v_fma_mixhi_f16 v66, v102, s22, 0                          // 0000001B7F68: CC220042 02002D66
	ds_load_b128 v[85:88], v127 offset:8736                    // 0000001B7F70: DBFC2220 5500007F
	ds_load_b128 v[89:92], v127 offset:8752                    // 0000001B7F78: DBFC2230 5900007F
	ds_load_b128 v[93:96], v127 offset:17152                   // 0000001B7F80: DBFC4300 5D00007F
	ds_load_b128 v[99:102], v127 offset:17168                  // 0000001B7F88: DBFC4310 6300007F
	ds_load_b128 v[172:175], v127 offset:17184                 // 0000001B7F90: DBFC4320 AC00007F
	ds_load_b128 v[176:179], v127 offset:17200                 // 0000001B7F98: DBFC4330 B000007F
	s_waitcnt lgkmcnt(10)                                      // 0000001B7FA0: BF89FCA7
	v_fma_mixlo_f16 v67, v182, s22, 0                          // 0000001B7FA4: CC210043 02002DB6
	v_fma_mixhi_f16 v67, v183, s22, 0                          // 0000001B7FAC: CC220043 02002DB7
	ds_load_b128 v[180:183], v127 offset:25616                 // 0000001B7FB4: DBFC6410 B400007F
	s_waitcnt lgkmcnt(9)                                       // 0000001B7FBC: BF89FC97
	v_fma_mixhi_f16 v71, v74, s22, 0                           // 0000001B7FC0: CC220047 02002D4A
	v_fma_mixlo_f16 v72, v75, s22, 0                           // 0000001B7FC8: CC210048 02002D4B
	v_fma_mixhi_f16 v72, v76, s22, 0                           // 0000001B7FD0: CC220048 02002D4C
	v_fma_mixlo_f16 v68, v184, s22, 0                          // 0000001B7FD8: CC210044 02002DB8
	s_waitcnt lgkmcnt(8)                                       // 0000001B7FE0: BF89FC87
	v_fma_mixlo_f16 v74, v79, s22, 0                           // 0000001B7FE4: CC21004A 02002D4F
	v_fma_mixhi_f16 v74, v80, s22, 0                           // 0000001B7FEC: CC22004A 02002D50
	s_waitcnt lgkmcnt(7)                                       // 0000001B7FF4: BF89FC77
	v_fma_mixlo_f16 v75, v81, s22, 0                           // 0000001B7FF8: CC21004B 02002D51
	v_fma_mixhi_f16 v75, v82, s22, 0                           // 0000001B8000: CC22004B 02002D52
	v_fma_mixlo_f16 v76, v83, s22, 0                           // 0000001B8008: CC21004C 02002D53
	v_fma_mixhi_f16 v76, v84, s22, 0                           // 0000001B8010: CC22004C 02002D54
	v_fma_mixhi_f16 v68, v185, s22, 0                          // 0000001B8018: CC220044 02002DB9
	s_waitcnt lgkmcnt(5)                                       // 0000001B8020: BF89FC57
	v_fma_mixlo_f16 v79, v89, s22, 0                           // 0000001B8024: CC21004F 02002D59
	v_fma_mixhi_f16 v79, v90, s22, 0                           // 0000001B802C: CC22004F 02002D5A
	v_fma_mixlo_f16 v80, v91, s22, 0                           // 0000001B8034: CC210050 02002D5B
	v_fma_mixhi_f16 v80, v92, s22, 0                           // 0000001B803C: CC220050 02002D5C
	ds_load_b128 v[89:92], v127 offset:25600                   // 0000001B8044: DBFC6400 5900007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B804C: BF89FC57
	v_fma_mixlo_f16 v81, v93, s22, 0                           // 0000001B8050: CC210051 02002D5D
	v_fma_mixhi_f16 v81, v94, s22, 0                           // 0000001B8058: CC220051 02002D5E
	v_fma_mixlo_f16 v82, v95, s22, 0                           // 0000001B8060: CC210052 02002D5F
	v_fma_mixhi_f16 v82, v96, s22, 0                           // 0000001B8068: CC220052 02002D60
	s_waitcnt lgkmcnt(4)                                       // 0000001B8070: BF89FC47
	v_fma_mixlo_f16 v83, v99, s22, 0                           // 0000001B8074: CC210053 02002D63
	v_fma_mixhi_f16 v83, v100, s22, 0                          // 0000001B807C: CC220053 02002D64
	v_fma_mixlo_f16 v84, v101, s22, 0                          // 0000001B8084: CC210054 02002D65
	ds_load_b128 v[93:96], v127 offset:25632                   // 0000001B808C: DBFC6420 5D00007F
	v_fma_mixhi_f16 v84, v102, s22, 0                          // 0000001B8094: CC220054 02002D66
	ds_load_b128 v[99:102], v127 offset:25648                  // 0000001B809C: DBFC6430 6300007F
	v_fma_mixlo_f16 v69, v186, s22, 0                          // 0000001B80A4: CC210045 02002DBA
	v_fma_mixhi_f16 v69, v187, s22, 0                          // 0000001B80AC: CC220045 02002DBB
	v_fma_mixlo_f16 v70, v188, s22, 0                          // 0000001B80B4: CC210046 02002DBC
	v_fma_mixhi_f16 v70, v189, s22, 0                          // 0000001B80BC: CC220046 02002DBD
	v_fma_mixlo_f16 v71, v73, s22, 0                           // 0000001B80C4: CC210047 02002D49
	v_fma_mixlo_f16 v73, v77, s22, 0                           // 0000001B80CC: CC210049 02002D4D
	v_fma_mixhi_f16 v73, v78, s22, 0                           // 0000001B80D4: CC220049 02002D4E
	v_fma_mixlo_f16 v77, v85, s22, 0                           // 0000001B80DC: CC21004D 02002D55
	v_fma_mixhi_f16 v77, v86, s22, 0                           // 0000001B80E4: CC22004D 02002D56
	v_fma_mixlo_f16 v78, v87, s22, 0                           // 0000001B80EC: CC21004E 02002D57
	v_fma_mixhi_f16 v78, v88, s22, 0                           // 0000001B80F4: CC22004E 02002D58
	s_waitcnt lgkmcnt(5)                                       // 0000001B80FC: BF89FC57
	v_fma_mixlo_f16 v85, v172, s22, 0                          // 0000001B8100: CC210055 02002DAC
	v_fma_mixhi_f16 v85, v173, s22, 0                          // 0000001B8108: CC220055 02002DAD
	v_fma_mixlo_f16 v86, v174, s22, 0                          // 0000001B8110: CC210056 02002DAE
	v_fma_mixhi_f16 v86, v175, s22, 0                          // 0000001B8118: CC220056 02002DAF
	s_waitcnt lgkmcnt(4)                                       // 0000001B8120: BF89FC47
	v_fma_mixlo_f16 v87, v176, s22, 0                          // 0000001B8124: CC210057 02002DB0
	v_fma_mixhi_f16 v87, v177, s22, 0                          // 0000001B812C: CC220057 02002DB1
	v_fma_mixlo_f16 v88, v178, s22, 0                          // 0000001B8134: CC210058 02002DB2
	v_fma_mixhi_f16 v88, v179, s22, 0                          // 0000001B813C: CC220058 02002DB3
	s_waitcnt lgkmcnt(2)                                       // 0000001B8144: BF89FC27
	v_fma_mixlo_f16 v89, v89, s22, 0                           // 0000001B8148: CC210059 02002D59
	v_fma_mixhi_f16 v89, v90, s22, 0                           // 0000001B8150: CC220059 02002D5A
	v_fma_mixlo_f16 v90, v91, s22, 0                           // 0000001B8158: CC21005A 02002D5B
	v_fma_mixhi_f16 v90, v92, s22, 0                           // 0000001B8160: CC22005A 02002D5C
	v_fma_mixlo_f16 v91, v180, s22, 0                          // 0000001B8168: CC21005B 02002DB4
	v_fma_mixhi_f16 v91, v181, s22, 0                          // 0000001B8170: CC22005B 02002DB5
	v_fma_mixlo_f16 v92, v182, s22, 0                          // 0000001B8178: CC21005C 02002DB6
	v_fma_mixhi_f16 v92, v183, s22, 0                          // 0000001B8180: CC22005C 02002DB7
	s_waitcnt lgkmcnt(1)                                       // 0000001B8188: BF89FC17
	v_fma_mixlo_f16 v93, v93, s22, 0                           // 0000001B818C: CC21005D 02002D5D
	v_fma_mixhi_f16 v93, v94, s22, 0                           // 0000001B8194: CC22005D 02002D5E
	v_fma_mixlo_f16 v94, v95, s22, 0                           // 0000001B819C: CC21005E 02002D5F
	v_fma_mixhi_f16 v94, v96, s22, 0                           // 0000001B81A4: CC22005E 02002D60
	s_waitcnt lgkmcnt(0)                                       // 0000001B81AC: BF89FC07
	v_fma_mixlo_f16 v95, v99, s22, 0                           // 0000001B81B0: CC21005F 02002D63
	v_fma_mixhi_f16 v95, v100, s22, 0                          // 0000001B81B8: CC22005F 02002D64
	v_fma_mixlo_f16 v96, v101, s22, 0                          // 0000001B81C0: CC210060 02002D65
	v_fma_mixhi_f16 v96, v102, s22, 0                          // 0000001B81C8: CC220060 02002D66
	ds_load_b128 v[172:175], v127 offset:320                   // 0000001B81D0: DBFC0140 AC00007F
	ds_load_b128 v[176:179], v127 offset:336                   // 0000001B81D8: DBFC0150 B000007F
	ds_load_b128 v[180:183], v127 offset:352                   // 0000001B81E0: DBFC0160 B400007F
	s_waitcnt vmcnt(6)                                         // 0000001B81E8: BF891BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[57:64], v[65:72], v[41:48]// 0000001B81EC: CC404029 1CA68339
	ds_load_b128 v[65:68], v127 offset:368                     // 0000001B81F4: DBFC0170 4100007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[73:80], v[17:24]// 0000001B81FC: CC404011 1C469339
	v_wmma_f32_16x16x16_f16 v[49:56], v[57:64], v[81:88], v[49:56]// 0000001B8204: CC404031 1CC6A339
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[89:96], v[25:32]// 0000001B820C: CC404019 1C66B339
	ds_load_b128 v[69:72], v127 offset:8768                    // 0000001B8214: DBFC2240 4500007F
	ds_load_b128 v[73:76], v127 offset:8784                    // 0000001B821C: DBFC2250 4900007F
	ds_load_b128 v[77:80], v127 offset:8800                    // 0000001B8224: DBFC2260 4D00007F
	ds_load_b128 v[81:84], v127 offset:8816                    // 0000001B822C: DBFC2270 5100007F
	ds_load_b128 v[85:88], v127 offset:17216                   // 0000001B8234: DBFC4340 5500007F
	ds_load_b128 v[89:92], v127 offset:17232                   // 0000001B823C: DBFC4350 5900007F
	ds_load_b128 v[93:96], v127 offset:17248                   // 0000001B8244: DBFC4360 5D00007F
	ds_load_b128 v[99:102], v127 offset:17264                  // 0000001B824C: DBFC4370 6300007F
	s_waitcnt lgkmcnt(11)                                      // 0000001B8254: BF89FCB7
	v_fma_mixlo_f16 v57, v172, s22, 0                          // 0000001B8258: CC210039 02002DAC
	v_fma_mixhi_f16 v57, v173, s22, 0                          // 0000001B8260: CC220039 02002DAD
	v_fma_mixlo_f16 v58, v174, s22, 0                          // 0000001B8268: CC21003A 02002DAE
	v_fma_mixhi_f16 v58, v175, s22, 0                          // 0000001B8270: CC22003A 02002DAF
	s_waitcnt lgkmcnt(8)                                       // 0000001B8278: BF89FC87
	v_fma_mixhi_f16 v63, v66, s22, 0                           // 0000001B827C: CC22003F 02002D42
	v_fma_mixlo_f16 v64, v67, s22, 0                           // 0000001B8284: CC210040 02002D43
	v_fma_mixhi_f16 v64, v68, s22, 0                           // 0000001B828C: CC220040 02002D44
	ds_load_b128 v[172:175], v127 offset:25680                 // 0000001B8294: DBFC6450 AC00007F
	s_waitcnt lgkmcnt(8)                                       // 0000001B829C: BF89FC87
	v_fma_mixlo_f16 v66, v71, s22, 0                           // 0000001B82A0: CC210042 02002D47
	v_fma_mixhi_f16 v66, v72, s22, 0                           // 0000001B82A8: CC220042 02002D48
	s_waitcnt lgkmcnt(7)                                       // 0000001B82B0: BF89FC77
	v_fma_mixlo_f16 v67, v73, s22, 0                           // 0000001B82B4: CC210043 02002D49
	v_fma_mixhi_f16 v67, v74, s22, 0                           // 0000001B82BC: CC220043 02002D4A
	v_fma_mixlo_f16 v68, v75, s22, 0                           // 0000001B82C4: CC210044 02002D4B
	v_fma_mixhi_f16 v68, v76, s22, 0                           // 0000001B82CC: CC220044 02002D4C
	s_waitcnt lgkmcnt(5)                                       // 0000001B82D4: BF89FC57
	v_fma_mixlo_f16 v71, v81, s22, 0                           // 0000001B82D8: CC210047 02002D51
	v_fma_mixhi_f16 v71, v82, s22, 0                           // 0000001B82E0: CC220047 02002D52
	v_fma_mixlo_f16 v72, v83, s22, 0                           // 0000001B82E8: CC210048 02002D53
	v_fma_mixhi_f16 v72, v84, s22, 0                           // 0000001B82F0: CC220048 02002D54
	ds_load_b128 v[81:84], v127 offset:25664                   // 0000001B82F8: DBFC6440 5100007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B8300: BF89FC57
	v_fma_mixlo_f16 v73, v85, s22, 0                           // 0000001B8304: CC210049 02002D55
	v_fma_mixhi_f16 v73, v86, s22, 0                           // 0000001B830C: CC220049 02002D56
	v_fma_mixlo_f16 v74, v87, s22, 0                           // 0000001B8314: CC21004A 02002D57
	v_fma_mixhi_f16 v74, v88, s22, 0                           // 0000001B831C: CC22004A 02002D58
	s_waitcnt lgkmcnt(4)                                       // 0000001B8324: BF89FC47
	v_fma_mixlo_f16 v75, v89, s22, 0                           // 0000001B8328: CC21004B 02002D59
	v_fma_mixhi_f16 v75, v90, s22, 0                           // 0000001B8330: CC22004B 02002D5A
	v_fma_mixlo_f16 v76, v91, s22, 0                           // 0000001B8338: CC21004C 02002D5B
	ds_load_b128 v[85:88], v127 offset:25696                   // 0000001B8340: DBFC6460 5500007F
	v_fma_mixhi_f16 v76, v92, s22, 0                           // 0000001B8348: CC22004C 02002D5C
	ds_load_b128 v[89:92], v127 offset:25712                   // 0000001B8350: DBFC6470 5900007F
	v_fma_mixlo_f16 v59, v176, s22, 0                          // 0000001B8358: CC21003B 02002DB0
	v_fma_mixhi_f16 v59, v177, s22, 0                          // 0000001B8360: CC22003B 02002DB1
	v_fma_mixlo_f16 v60, v178, s22, 0                          // 0000001B8368: CC21003C 02002DB2
	v_fma_mixhi_f16 v60, v179, s22, 0                          // 0000001B8370: CC22003C 02002DB3
	v_fma_mixlo_f16 v61, v180, s22, 0                          // 0000001B8378: CC21003D 02002DB4
	v_fma_mixhi_f16 v61, v181, s22, 0                          // 0000001B8380: CC22003D 02002DB5
	v_fma_mixlo_f16 v62, v182, s22, 0                          // 0000001B8388: CC21003E 02002DB6
	v_fma_mixhi_f16 v62, v183, s22, 0                          // 0000001B8390: CC22003E 02002DB7
	v_fma_mixlo_f16 v63, v65, s22, 0                           // 0000001B8398: CC21003F 02002D41
	v_fma_mixlo_f16 v65, v69, s22, 0                           // 0000001B83A0: CC210041 02002D45
	v_fma_mixhi_f16 v65, v70, s22, 0                           // 0000001B83A8: CC220041 02002D46
	v_fma_mixlo_f16 v69, v77, s22, 0                           // 0000001B83B0: CC210045 02002D4D
	v_fma_mixhi_f16 v69, v78, s22, 0                           // 0000001B83B8: CC220045 02002D4E
	v_fma_mixlo_f16 v70, v79, s22, 0                           // 0000001B83C0: CC210046 02002D4F
	v_fma_mixhi_f16 v70, v80, s22, 0                           // 0000001B83C8: CC220046 02002D50
	s_waitcnt lgkmcnt(5)                                       // 0000001B83D0: BF89FC57
	v_fma_mixlo_f16 v77, v93, s22, 0                           // 0000001B83D4: CC21004D 02002D5D
	v_fma_mixhi_f16 v77, v94, s22, 0                           // 0000001B83DC: CC22004D 02002D5E
	v_fma_mixlo_f16 v78, v95, s22, 0                           // 0000001B83E4: CC21004E 02002D5F
	v_fma_mixhi_f16 v78, v96, s22, 0                           // 0000001B83EC: CC22004E 02002D60
	s_waitcnt lgkmcnt(4)                                       // 0000001B83F4: BF89FC47
	v_fma_mixlo_f16 v79, v99, s22, 0                           // 0000001B83F8: CC21004F 02002D63
	v_fma_mixhi_f16 v79, v100, s22, 0                          // 0000001B8400: CC22004F 02002D64
	v_fma_mixlo_f16 v80, v101, s22, 0                          // 0000001B8408: CC210050 02002D65
	v_fma_mixhi_f16 v80, v102, s22, 0                          // 0000001B8410: CC220050 02002D66
	s_waitcnt lgkmcnt(2)                                       // 0000001B8418: BF89FC27
	v_fma_mixlo_f16 v81, v81, s22, 0                           // 0000001B841C: CC210051 02002D51
	v_fma_mixhi_f16 v81, v82, s22, 0                           // 0000001B8424: CC220051 02002D52
	v_fma_mixlo_f16 v82, v83, s22, 0                           // 0000001B842C: CC210052 02002D53
	v_fma_mixhi_f16 v82, v84, s22, 0                           // 0000001B8434: CC220052 02002D54
	v_fma_mixlo_f16 v83, v172, s22, 0                          // 0000001B843C: CC210053 02002DAC
	v_fma_mixhi_f16 v83, v173, s22, 0                          // 0000001B8444: CC220053 02002DAD
	v_fma_mixlo_f16 v84, v174, s22, 0                          // 0000001B844C: CC210054 02002DAE
	v_fma_mixhi_f16 v84, v175, s22, 0                          // 0000001B8454: CC220054 02002DAF
	s_waitcnt lgkmcnt(1)                                       // 0000001B845C: BF89FC17
	v_fma_mixlo_f16 v85, v85, s22, 0                           // 0000001B8460: CC210055 02002D55
	v_fma_mixhi_f16 v85, v86, s22, 0                           // 0000001B8468: CC220055 02002D56
	v_fma_mixlo_f16 v86, v87, s22, 0                           // 0000001B8470: CC210056 02002D57
	v_fma_mixhi_f16 v86, v88, s22, 0                           // 0000001B8478: CC220056 02002D58
	s_waitcnt lgkmcnt(0)                                       // 0000001B8480: BF89FC07
	v_fma_mixlo_f16 v87, v89, s22, 0                           // 0000001B8484: CC210057 02002D59
	v_fma_mixhi_f16 v87, v90, s22, 0                           // 0000001B848C: CC220057 02002D5A
	v_fma_mixlo_f16 v88, v91, s22, 0                           // 0000001B8494: CC210058 02002D5B
	v_fma_mixhi_f16 v88, v92, s22, 0                           // 0000001B849C: CC220058 02002D5C
	ds_load_b128 v[93:96], v127 offset:384                     // 0000001B84A4: DBFC0180 5D00007F
	ds_load_b128 v[99:102], v127 offset:400                    // 0000001B84AC: DBFC0190 6300007F
	ds_load_b128 v[172:175], v127 offset:416                   // 0000001B84B4: DBFC01A0 AC00007F
	s_waitcnt vmcnt(4)                                         // 0000001B84BC: BF8913F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[33:40], v[57:64], v[41:48]// 0000001B84C0: CC404029 1CA67321
	ds_load_b128 v[57:60], v127 offset:432                     // 0000001B84C8: DBFC01B0 3900007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[65:72], v[17:24]// 0000001B84D0: CC404011 1C468321
	v_wmma_f32_16x16x16_f16 v[49:56], v[33:40], v[73:80], v[49:56]// 0000001B84D8: CC404031 1CC69321
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[81:88], v[25:32]// 0000001B84E0: CC404019 1C66A321
	ds_load_b128 v[61:64], v127 offset:8832                    // 0000001B84E8: DBFC2280 3D00007F
	ds_load_b128 v[65:68], v127 offset:8848                    // 0000001B84F0: DBFC2290 4100007F
	ds_load_b128 v[69:72], v127 offset:8864                    // 0000001B84F8: DBFC22A0 4500007F
	ds_load_b128 v[73:76], v127 offset:8880                    // 0000001B8500: DBFC22B0 4900007F
	ds_load_b128 v[77:80], v127 offset:17280                   // 0000001B8508: DBFC4380 4D00007F
	ds_load_b128 v[81:84], v127 offset:17296                   // 0000001B8510: DBFC4390 5100007F
	ds_load_b128 v[85:88], v127 offset:17312                   // 0000001B8518: DBFC43A0 5500007F
	ds_load_b128 v[89:92], v127 offset:17328                   // 0000001B8520: DBFC43B0 5900007F
	s_waitcnt lgkmcnt(11)                                      // 0000001B8528: BF89FCB7
	v_fma_mixlo_f16 v33, v93, s22, 0                           // 0000001B852C: CC210021 02002D5D
	v_fma_mixhi_f16 v33, v94, s22, 0                           // 0000001B8534: CC220021 02002D5E
	v_fma_mixlo_f16 v34, v95, s22, 0                           // 0000001B853C: CC210022 02002D5F
	v_fma_mixhi_f16 v34, v96, s22, 0                           // 0000001B8544: CC220022 02002D60
	s_waitcnt lgkmcnt(8)                                       // 0000001B854C: BF89FC87
	v_fma_mixhi_f16 v39, v58, s22, 0                           // 0000001B8550: CC220027 02002D3A
	v_fma_mixlo_f16 v40, v59, s22, 0                           // 0000001B8558: CC210028 02002D3B
	v_fma_mixhi_f16 v40, v60, s22, 0                           // 0000001B8560: CC220028 02002D3C
	ds_load_b128 v[93:96], v127 offset:25744                   // 0000001B8568: DBFC6490 5D00007F
	s_waitcnt lgkmcnt(8)                                       // 0000001B8570: BF89FC87
	v_fma_mixlo_f16 v58, v63, s22, 0                           // 0000001B8574: CC21003A 02002D3F
	v_fma_mixhi_f16 v58, v64, s22, 0                           // 0000001B857C: CC22003A 02002D40
	s_waitcnt lgkmcnt(7)                                       // 0000001B8584: BF89FC77
	v_fma_mixlo_f16 v59, v65, s22, 0                           // 0000001B8588: CC21003B 02002D41
	v_fma_mixhi_f16 v59, v66, s22, 0                           // 0000001B8590: CC22003B 02002D42
	v_fma_mixlo_f16 v60, v67, s22, 0                           // 0000001B8598: CC21003C 02002D43
	v_fma_mixhi_f16 v60, v68, s22, 0                           // 0000001B85A0: CC22003C 02002D44
	s_waitcnt lgkmcnt(5)                                       // 0000001B85A8: BF89FC57
	v_fma_mixlo_f16 v63, v73, s22, 0                           // 0000001B85AC: CC21003F 02002D49
	v_fma_mixhi_f16 v63, v74, s22, 0                           // 0000001B85B4: CC22003F 02002D4A
	v_fma_mixlo_f16 v64, v75, s22, 0                           // 0000001B85BC: CC210040 02002D4B
	v_fma_mixhi_f16 v64, v76, s22, 0                           // 0000001B85C4: CC220040 02002D4C
	ds_load_b128 v[73:76], v127 offset:25728                   // 0000001B85CC: DBFC6480 4900007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B85D4: BF89FC57
	v_fma_mixlo_f16 v65, v77, s22, 0                           // 0000001B85D8: CC210041 02002D4D
	v_fma_mixhi_f16 v65, v78, s22, 0                           // 0000001B85E0: CC220041 02002D4E
	v_fma_mixlo_f16 v66, v79, s22, 0                           // 0000001B85E8: CC210042 02002D4F
	v_fma_mixhi_f16 v66, v80, s22, 0                           // 0000001B85F0: CC220042 02002D50
	s_waitcnt lgkmcnt(4)                                       // 0000001B85F8: BF89FC47
	v_fma_mixlo_f16 v67, v81, s22, 0                           // 0000001B85FC: CC210043 02002D51
	v_fma_mixhi_f16 v67, v82, s22, 0                           // 0000001B8604: CC220043 02002D52
	v_fma_mixlo_f16 v68, v83, s22, 0                           // 0000001B860C: CC210044 02002D53
	ds_load_b128 v[77:80], v127 offset:25760                   // 0000001B8614: DBFC64A0 4D00007F
	v_fma_mixhi_f16 v68, v84, s22, 0                           // 0000001B861C: CC220044 02002D54
	ds_load_b128 v[81:84], v127 offset:25776                   // 0000001B8624: DBFC64B0 5100007F
	v_fma_mixlo_f16 v35, v99, s22, 0                           // 0000001B862C: CC210023 02002D63
	v_fma_mixhi_f16 v35, v100, s22, 0                          // 0000001B8634: CC220023 02002D64
	v_fma_mixlo_f16 v36, v101, s22, 0                          // 0000001B863C: CC210024 02002D65
	v_fma_mixhi_f16 v36, v102, s22, 0                          // 0000001B8644: CC220024 02002D66
	v_fma_mixlo_f16 v37, v172, s22, 0                          // 0000001B864C: CC210025 02002DAC
	v_fma_mixhi_f16 v37, v173, s22, 0                          // 0000001B8654: CC220025 02002DAD
	v_fma_mixlo_f16 v38, v174, s22, 0                          // 0000001B865C: CC210026 02002DAE
	v_fma_mixhi_f16 v38, v175, s22, 0                          // 0000001B8664: CC220026 02002DAF
	v_fma_mixlo_f16 v39, v57, s22, 0                           // 0000001B866C: CC210027 02002D39
	v_fma_mixlo_f16 v57, v61, s22, 0                           // 0000001B8674: CC210039 02002D3D
	v_fma_mixhi_f16 v57, v62, s22, 0                           // 0000001B867C: CC220039 02002D3E
	v_fma_mixlo_f16 v61, v69, s22, 0                           // 0000001B8684: CC21003D 02002D45
	v_fma_mixhi_f16 v61, v70, s22, 0                           // 0000001B868C: CC22003D 02002D46
	v_fma_mixlo_f16 v62, v71, s22, 0                           // 0000001B8694: CC21003E 02002D47
	v_fma_mixhi_f16 v62, v72, s22, 0                           // 0000001B869C: CC22003E 02002D48
	s_waitcnt lgkmcnt(5)                                       // 0000001B86A4: BF89FC57
	v_fma_mixlo_f16 v69, v85, s22, 0                           // 0000001B86A8: CC210045 02002D55
	v_fma_mixhi_f16 v69, v86, s22, 0                           // 0000001B86B0: CC220045 02002D56
	v_fma_mixlo_f16 v70, v87, s22, 0                           // 0000001B86B8: CC210046 02002D57
	v_fma_mixhi_f16 v70, v88, s22, 0                           // 0000001B86C0: CC220046 02002D58
	s_waitcnt lgkmcnt(4)                                       // 0000001B86C8: BF89FC47
	v_fma_mixlo_f16 v71, v89, s22, 0                           // 0000001B86CC: CC210047 02002D59
	v_fma_mixhi_f16 v71, v90, s22, 0                           // 0000001B86D4: CC220047 02002D5A
	v_fma_mixlo_f16 v72, v91, s22, 0                           // 0000001B86DC: CC210048 02002D5B
	v_fma_mixhi_f16 v72, v92, s22, 0                           // 0000001B86E4: CC220048 02002D5C
	s_waitcnt lgkmcnt(2)                                       // 0000001B86EC: BF89FC27
	v_fma_mixlo_f16 v73, v73, s22, 0                           // 0000001B86F0: CC210049 02002D49
	v_fma_mixhi_f16 v73, v74, s22, 0                           // 0000001B86F8: CC220049 02002D4A
	v_fma_mixlo_f16 v74, v75, s22, 0                           // 0000001B8700: CC21004A 02002D4B
	v_fma_mixhi_f16 v74, v76, s22, 0                           // 0000001B8708: CC22004A 02002D4C
	v_fma_mixlo_f16 v75, v93, s22, 0                           // 0000001B8710: CC21004B 02002D5D
	v_fma_mixhi_f16 v75, v94, s22, 0                           // 0000001B8718: CC22004B 02002D5E
	v_fma_mixlo_f16 v76, v95, s22, 0                           // 0000001B8720: CC21004C 02002D5F
	v_fma_mixhi_f16 v76, v96, s22, 0                           // 0000001B8728: CC22004C 02002D60
	s_waitcnt lgkmcnt(1)                                       // 0000001B8730: BF89FC17
	v_fma_mixlo_f16 v77, v77, s22, 0                           // 0000001B8734: CC21004D 02002D4D
	v_fma_mixhi_f16 v77, v78, s22, 0                           // 0000001B873C: CC22004D 02002D4E
	v_fma_mixlo_f16 v78, v79, s22, 0                           // 0000001B8744: CC21004E 02002D4F
	v_fma_mixhi_f16 v78, v80, s22, 0                           // 0000001B874C: CC22004E 02002D50
	s_waitcnt lgkmcnt(0)                                       // 0000001B8754: BF89FC07
	v_fma_mixlo_f16 v79, v81, s22, 0                           // 0000001B8758: CC21004F 02002D51
	v_fma_mixhi_f16 v79, v82, s22, 0                           // 0000001B8760: CC22004F 02002D52
	v_fma_mixlo_f16 v80, v83, s22, 0                           // 0000001B8768: CC210050 02002D53
	v_fma_mixhi_f16 v80, v84, s22, 0                           // 0000001B8770: CC220050 02002D54
	ds_load_b128 v[85:88], v127 offset:448                     // 0000001B8778: DBFC01C0 5500007F
	ds_load_b128 v[89:92], v127 offset:464                     // 0000001B8780: DBFC01D0 5900007F
	ds_load_b128 v[93:96], v127 offset:480                     // 0000001B8788: DBFC01E0 5D00007F
	s_waitcnt vmcnt(2)                                         // 0000001B8790: BF890BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[9:16], v[33:40], v[41:48]// 0000001B8794: CC404029 1CA64309
	ds_load_b128 v[33:36], v127 offset:496                     // 0000001B879C: DBFC01F0 2100007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[9:16], v[57:64], v[17:24]// 0000001B87A4: CC404011 1C467309
	v_wmma_f32_16x16x16_f16 v[49:56], v[9:16], v[65:72], v[49:56]// 0000001B87AC: CC404031 1CC68309
	v_wmma_f32_16x16x16_f16 v[25:32], v[9:16], v[73:80], v[25:32]// 0000001B87B4: CC404019 1C669309
	ds_load_b128 v[37:40], v127 offset:8896                    // 0000001B87BC: DBFC22C0 2500007F
	ds_load_b128 v[57:60], v127 offset:8912                    // 0000001B87C4: DBFC22D0 3900007F
	ds_load_b128 v[61:64], v127 offset:8928                    // 0000001B87CC: DBFC22E0 3D00007F
	ds_load_b128 v[65:68], v127 offset:8944                    // 0000001B87D4: DBFC22F0 4100007F
	ds_load_b128 v[69:72], v127 offset:17344                   // 0000001B87DC: DBFC43C0 4500007F
	ds_load_b128 v[73:76], v127 offset:17360                   // 0000001B87E4: DBFC43D0 4900007F
	ds_load_b128 v[77:80], v127 offset:17376                   // 0000001B87EC: DBFC43E0 4D00007F
	ds_load_b128 v[81:84], v127 offset:17392                   // 0000001B87F4: DBFC43F0 5100007F
	s_waitcnt lgkmcnt(11)                                      // 0000001B87FC: BF89FCB7
	v_fma_mixlo_f16 v9, v85, s22, 0                            // 0000001B8800: CC210009 02002D55
	v_fma_mixhi_f16 v9, v86, s22, 0                            // 0000001B8808: CC220009 02002D56
	v_fma_mixlo_f16 v10, v87, s22, 0                           // 0000001B8810: CC21000A 02002D57
	v_fma_mixhi_f16 v10, v88, s22, 0                           // 0000001B8818: CC22000A 02002D58
	s_waitcnt lgkmcnt(8)                                       // 0000001B8820: BF89FC87
	v_fma_mixhi_f16 v15, v34, s22, 0                           // 0000001B8824: CC22000F 02002D22
	v_fma_mixlo_f16 v16, v35, s22, 0                           // 0000001B882C: CC210010 02002D23
	v_fma_mixhi_f16 v16, v36, s22, 0                           // 0000001B8834: CC220010 02002D24
	ds_load_b128 v[85:88], v127 offset:25808                   // 0000001B883C: DBFC64D0 5500007F
	s_waitcnt lgkmcnt(8)                                       // 0000001B8844: BF89FC87
	v_fma_mixlo_f16 v34, v39, s22, 0                           // 0000001B8848: CC210022 02002D27
	v_fma_mixhi_f16 v34, v40, s22, 0                           // 0000001B8850: CC220022 02002D28
	s_waitcnt lgkmcnt(7)                                       // 0000001B8858: BF89FC77
	v_fma_mixlo_f16 v35, v57, s22, 0                           // 0000001B885C: CC210023 02002D39
	v_fma_mixhi_f16 v35, v58, s22, 0                           // 0000001B8864: CC220023 02002D3A
	v_fma_mixlo_f16 v36, v59, s22, 0                           // 0000001B886C: CC210024 02002D3B
	v_fma_mixhi_f16 v36, v60, s22, 0                           // 0000001B8874: CC220024 02002D3C
	s_waitcnt lgkmcnt(5)                                       // 0000001B887C: BF89FC57
	v_fma_mixlo_f16 v39, v65, s22, 0                           // 0000001B8880: CC210027 02002D41
	v_fma_mixhi_f16 v39, v66, s22, 0                           // 0000001B8888: CC220027 02002D42
	v_fma_mixlo_f16 v40, v67, s22, 0                           // 0000001B8890: CC210028 02002D43
	v_fma_mixhi_f16 v40, v68, s22, 0                           // 0000001B8898: CC220028 02002D44
	ds_load_b128 v[65:68], v127 offset:25792                   // 0000001B88A0: DBFC64C0 4100007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B88A8: BF89FC57
	v_fma_mixlo_f16 v57, v69, s22, 0                           // 0000001B88AC: CC210039 02002D45
	v_fma_mixhi_f16 v57, v70, s22, 0                           // 0000001B88B4: CC220039 02002D46
	v_fma_mixlo_f16 v58, v71, s22, 0                           // 0000001B88BC: CC21003A 02002D47
	v_fma_mixhi_f16 v58, v72, s22, 0                           // 0000001B88C4: CC22003A 02002D48
	s_waitcnt lgkmcnt(4)                                       // 0000001B88CC: BF89FC47
	v_fma_mixlo_f16 v59, v73, s22, 0                           // 0000001B88D0: CC21003B 02002D49
	v_fma_mixhi_f16 v59, v74, s22, 0                           // 0000001B88D8: CC22003B 02002D4A
	ds_load_b128 v[69:72], v127 offset:25824                   // 0000001B88E0: DBFC64E0 4500007F
	v_fma_mixlo_f16 v60, v75, s22, 0                           // 0000001B88E8: CC21003C 02002D4B
	v_fma_mixhi_f16 v60, v76, s22, 0                           // 0000001B88F0: CC22003C 02002D4C
	ds_load_b128 v[73:76], v127 offset:25840                   // 0000001B88F8: DBFC64F0 4900007F
	v_fma_mixlo_f16 v11, v89, s22, 0                           // 0000001B8900: CC21000B 02002D59
	v_fma_mixhi_f16 v11, v90, s22, 0                           // 0000001B8908: CC22000B 02002D5A
	v_fma_mixlo_f16 v12, v91, s22, 0                           // 0000001B8910: CC21000C 02002D5B
	v_fma_mixhi_f16 v12, v92, s22, 0                           // 0000001B8918: CC22000C 02002D5C
	v_fma_mixlo_f16 v13, v93, s22, 0                           // 0000001B8920: CC21000D 02002D5D
	v_fma_mixhi_f16 v13, v94, s22, 0                           // 0000001B8928: CC22000D 02002D5E
	v_fma_mixlo_f16 v14, v95, s22, 0                           // 0000001B8930: CC21000E 02002D5F
	v_fma_mixhi_f16 v14, v96, s22, 0                           // 0000001B8938: CC22000E 02002D60
	v_fma_mixlo_f16 v15, v33, s22, 0                           // 0000001B8940: CC21000F 02002D21
	v_fma_mixlo_f16 v33, v37, s22, 0                           // 0000001B8948: CC210021 02002D25
	v_fma_mixhi_f16 v33, v38, s22, 0                           // 0000001B8950: CC220021 02002D26
	v_fma_mixlo_f16 v37, v61, s22, 0                           // 0000001B8958: CC210025 02002D3D
	v_fma_mixhi_f16 v37, v62, s22, 0                           // 0000001B8960: CC220025 02002D3E
	v_fma_mixlo_f16 v38, v63, s22, 0                           // 0000001B8968: CC210026 02002D3F
	v_fma_mixhi_f16 v38, v64, s22, 0                           // 0000001B8970: CC220026 02002D40
	s_waitcnt lgkmcnt(5)                                       // 0000001B8978: BF89FC57
	v_fma_mixlo_f16 v61, v77, s22, 0                           // 0000001B897C: CC21003D 02002D4D
	v_fma_mixhi_f16 v61, v78, s22, 0                           // 0000001B8984: CC22003D 02002D4E
	v_fma_mixlo_f16 v62, v79, s22, 0                           // 0000001B898C: CC21003E 02002D4F
	v_fma_mixhi_f16 v62, v80, s22, 0                           // 0000001B8994: CC22003E 02002D50
	s_waitcnt lgkmcnt(4)                                       // 0000001B899C: BF89FC47
	v_fma_mixlo_f16 v63, v81, s22, 0                           // 0000001B89A0: CC21003F 02002D51
	v_fma_mixhi_f16 v63, v82, s22, 0                           // 0000001B89A8: CC22003F 02002D52
	v_fma_mixlo_f16 v64, v83, s22, 0                           // 0000001B89B0: CC210040 02002D53
	v_fma_mixhi_f16 v64, v84, s22, 0                           // 0000001B89B8: CC220040 02002D54
	s_waitcnt lgkmcnt(2)                                       // 0000001B89C0: BF89FC27
	v_fma_mixlo_f16 v65, v65, s22, 0                           // 0000001B89C4: CC210041 02002D41
	v_fma_mixhi_f16 v65, v66, s22, 0                           // 0000001B89CC: CC220041 02002D42
	v_fma_mixlo_f16 v66, v67, s22, 0                           // 0000001B89D4: CC210042 02002D43
	v_fma_mixhi_f16 v66, v68, s22, 0                           // 0000001B89DC: CC220042 02002D44
	v_fma_mixlo_f16 v67, v85, s22, 0                           // 0000001B89E4: CC210043 02002D55
	v_fma_mixhi_f16 v67, v86, s22, 0                           // 0000001B89EC: CC220043 02002D56
	v_fma_mixlo_f16 v68, v87, s22, 0                           // 0000001B89F4: CC210044 02002D57
	v_fma_mixhi_f16 v68, v88, s22, 0                           // 0000001B89FC: CC220044 02002D58
	s_waitcnt lgkmcnt(1)                                       // 0000001B8A04: BF89FC17
	v_fma_mixlo_f16 v69, v69, s22, 0                           // 0000001B8A08: CC210045 02002D45
	v_fma_mixhi_f16 v69, v70, s22, 0                           // 0000001B8A10: CC220045 02002D46
	v_fma_mixlo_f16 v70, v71, s22, 0                           // 0000001B8A18: CC210046 02002D47
	v_fma_mixhi_f16 v70, v72, s22, 0                           // 0000001B8A20: CC220046 02002D48
	s_waitcnt lgkmcnt(0)                                       // 0000001B8A28: BF89FC07
	v_fma_mixlo_f16 v71, v73, s22, 0                           // 0000001B8A2C: CC210047 02002D49
	v_fma_mixhi_f16 v71, v74, s22, 0                           // 0000001B8A34: CC220047 02002D4A
	v_fma_mixlo_f16 v72, v75, s22, 0                           // 0000001B8A3C: CC210048 02002D4B
	v_fma_mixhi_f16 v72, v76, s22, 0                           // 0000001B8A44: CC220048 02002D4C
	s_waitcnt vmcnt(0)                                         // 0000001B8A4C: BF8903F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[1:8], v[9:16], v[41:48]// 0000001B8A50: CC404029 1CA61301
	v_wmma_f32_16x16x16_f16 v[17:24], v[1:8], v[33:40], v[17:24]// 0000001B8A58: CC404011 1C464301
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[57:64], v[49:56]// 0000001B8A60: CC404031 1CC67301
	v_wmma_f32_16x16x16_f16 v[25:32], v[1:8], v[65:72], v[25:32]// 0000001B8A68: CC404019 1C668301
	v_add_nc_u32_e32 v172, s29, v130                           // 0000001B8A70: 4B59041D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B8A74: BF870001
	v_or_b32_e32 v1, 2, v172                                   // 0000001B8A78: 38035882
	v_or_b32_e32 v2, 4, v172                                   // 0000001B8A7C: 38055884
	v_or_b32_e32 v5, 6, v172                                   // 0000001B8A80: 380B5886
	v_or_b32_e32 v7, 8, v172                                   // 0000001B8A84: 380F5888
	v_or_b32_e32 v8, 10, v172                                  // 0000001B8A88: 3811588A
	v_min_i32_e32 v1, s62, v1                                  // 0000001B8A8C: 2202023E
	v_min_i32_e32 v6, s62, v2                                  // 0000001B8A90: 220C043E
	v_min_i32_e32 v10, s62, v5                                 // 0000001B8A94: 22140A3E
	v_or_b32_e32 v9, 12, v172                                  // 0000001B8A98: 3813588C
	v_min_i32_e32 v11, s62, v7                                 // 0000001B8A9C: 22160E3E
	v_mad_i64_i32 v[1:2], null, v1, 48, s[2:3]                 // 0000001B8AA0: D6FF7C01 00096101
	v_mad_i64_i32 v[5:6], null, v6, 48, s[2:3]                 // 0000001B8AA8: D6FF7C05 00096106
	v_min_i32_e32 v13, s62, v8                                 // 0000001B8AB0: 221A103E
	v_mad_i64_i32 v[7:8], null, v10, 48, s[2:3]                // 0000001B8AB4: D6FF7C07 0009610A
	v_min_i32_e32 v14, s62, v9                                 // 0000001B8ABC: 221C123E
	v_mad_i64_i32 v[9:10], null, v11, 48, s[2:3]               // 0000001B8AC0: D6FF7C09 0009610B
	v_or_b32_e32 v15, 14, v172                                 // 0000001B8AC8: 381F588E
	v_min_i32_e32 v3, s62, v172                                // 0000001B8ACC: 2207583E
	.long 0xd73c0001                                           // 0000001B8AD0: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001B8AD4: 02020289
	.long 0xd73c0005                                           // 0000001B8AD8: D73C0005
	v_cndmask_b32_e32 v1, 9, v5, vcc_lo                        // 0000001B8ADC: 02020A89
	.long 0xd444000a                                           // 0000001B8AE0: D444000A
	v_cndmask_b32_e32 v1, s58, v172, vcc_lo                    // 0000001B8AE4: 0203583A
	v_min_i32_e32 v15, s62, v15                                // 0000001B8AE8: 221E1E3E
	v_mad_i64_i32 v[3:4], null, v3, 48, s[2:3]                 // 0000001B8AEC: D6FF7C03 00096103
	.long 0xd73c0009                                           // 0000001B8AF4: D73C0009
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 0000001B8AF8: 02021289
	.long 0xd700000b                                           // 0000001B8AFC: D700000B
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001B8B00: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001B8B04: BF8700D1
	v_add_co_ci_u32_e64 v12, null, v135, v2, s0                // 0000001B8B08: D5207C0C 00020587
	.long 0xd73c0001                                           // 0000001B8B10: D73C0001
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 0000001B8B14: 02020E89
	v_mad_i64_i32 v[7:8], null, v13, 48, s[2:3]                // 0000001B8B18: D6FF7C07 0009610D
	v_mad_i64_i32 v[13:14], null, v14, 48, s[2:3]              // 0000001B8B20: D6FF7C0D 0009610E
	.long 0xd7000005                                           // 0000001B8B28: D7000005
	v_cndmask_b32_e32 v1, v134, v5, vcc_lo                     // 0000001B8B2C: 02020B86
	v_add_co_ci_u32_e64 v6, null, v135, v6, s0                 // 0000001B8B30: D5207C06 00020D87
	.long 0xd7000024                                           // 0000001B8B38: D7000024
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001B8B3C: 02020386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001B8B40: BF8700B1
	v_add_co_ci_u32_e64 v37, null, v135, v2, s0                // 0000001B8B44: D5207C25 00020587
	.long 0xd73c0001                                           // 0000001B8B4C: D73C0001
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 0000001B8B50: 02020E89
	.long 0xd7000007                                           // 0000001B8B54: D7000007
	v_cndmask_b32_e32 v1, v134, v9, vcc_lo                     // 0000001B8B58: 02021386
	v_add_co_ci_u32_e64 v8, null, v135, v10, s0                // 0000001B8B5C: D5207C08 00021587
	.long 0xd73c0009                                           // 0000001B8B64: D73C0009
	v_cndmask_b32_e32 v1, 9, v13, vcc_lo                       // 0000001B8B68: 02021A89
	v_mad_i64_i32 v[13:14], null, v15, 48, s[2:3]              // 0000001B8B6C: D6FF7C0D 0009610F
	.long 0xd7000026                                           // 0000001B8B74: D7000026
	v_cndmask_b32_e32 v1, v134, v1, vcc_lo                     // 0000001B8B78: 02020386
	.long 0xd73c0003                                           // 0000001B8B7C: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001B8B80: 02020689
	v_add_co_ci_u32_e64 v39, null, v135, v2, s0                // 0000001B8B84: D5207C27 00020587
	.long 0xd7000043                                           // 0000001B8B8C: D7000043
	v_cndmask_b32_e32 v1, v134, v9, vcc_lo                     // 0000001B8B90: 02021386
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001B8B94: BF8700B1
	v_add_co_ci_u32_e64 v68, null, v135, v10, s0               // 0000001B8B98: D5207C44 00021587
	.long 0xd73c0009                                           // 0000001B8BA0: D73C0009
	v_cndmask_b32_e32 v1, 9, v13, vcc_lo                       // 0000001B8BA4: 02021A89
	.long 0xd7000002                                           // 0000001B8BA8: D7000002
	v_cndmask_b32_e32 v1, v134, v3, vcc_lo                     // 0000001B8BAC: 02020786
	v_add_co_ci_u32_e64 v3, null, v135, v4, s0                 // 0000001B8BB0: D5207C03 00020987
	.long 0x7e023880                                           // 0000001B8BB8: 7E023880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B8BBC: BF870094
	.long 0xd7000045                                           // 0000001B8BC0: D7000045
	v_cndmask_b32_e32 v1, v134, v9, vcc_lo                     // 0000001B8BC4: 02021386
	v_add_co_ci_u32_e64 v70, null, v135, v10, s0               // 0000001B8BC8: D5207C46 00021587
	s_clause 0x1e                                              // 0000001B8BD0: BF85001E
	global_load_b32 v63, v[11:12], off                         // 0000001B8BD4: DC520000 3F7C000B
	global_load_b32 v60, v[5:6], off                           // 0000001B8BDC: DC520000 3C7C0005
	global_load_b32 v40, v[2:3], off offset:64                 // 0000001B8BE4: DC520040 287C0002
	global_load_b32 v57, v[11:12], off offset:64               // 0000001B8BEC: DC520040 397C000B
	global_load_b32 v35, v[2:3], off offset:128                // 0000001B8BF4: DC520080 237C0002
	global_load_b32 v15, v[11:12], off offset:128              // 0000001B8BFC: DC520080 0F7C000B
	global_load_b32 v9, v[11:12], off offset:192               // 0000001B8C04: DC5200C0 097C000B
	global_load_b32 v10, v[2:3], off offset:192                // 0000001B8C0C: DC5200C0 0A7C0002
	global_load_b32 v66, v[36:37], off                         // 0000001B8C14: DC520000 427C0024
	global_load_b32 v65, v[7:8], off                           // 0000001B8C1C: DC520000 417C0007
	global_load_b32 v59, v[5:6], off offset:64                 // 0000001B8C24: DC520040 3B7C0005
	global_load_b32 v58, v[36:37], off offset:64               // 0000001B8C2C: DC520040 3A7C0024
	global_load_b32 v34, v[5:6], off offset:128                // 0000001B8C34: DC520080 227C0005
	global_load_b32 v12, v[36:37], off offset:128              // 0000001B8C3C: DC520080 0C7C0024
	global_load_b32 v4, v[36:37], off offset:192               // 0000001B8C44: DC5200C0 047C0024
	global_load_b32 v11, v[5:6], off offset:192                // 0000001B8C4C: DC5200C0 0B7C0005
	global_load_b32 v64, v[38:39], off                         // 0000001B8C54: DC520000 407C0026
	global_load_b32 v61, v[67:68], off                         // 0000001B8C5C: DC520000 3D7C0043
	global_load_b32 v36, v[7:8], off offset:64                 // 0000001B8C64: DC520040 247C0007
	global_load_b32 v37, v[38:39], off offset:64               // 0000001B8C6C: DC520040 257C0026
	global_load_b32 v16, v[7:8], off offset:128                // 0000001B8C74: DC520080 107C0007
	global_load_b32 v33, v[38:39], off offset:128              // 0000001B8C7C: DC520080 217C0026
	global_load_b32 v5, v[38:39], off offset:192               // 0000001B8C84: DC5200C0 057C0026
	global_load_b32 v6, v[7:8], off offset:192                 // 0000001B8C8C: DC5200C0 067C0007
	global_load_b32 v62, v[69:70], off                         // 0000001B8C94: DC520000 3E7C0045
	global_load_b32 v38, v[67:68], off offset:64               // 0000001B8C9C: DC520040 267C0043
	global_load_b32 v39, v[69:70], off offset:64               // 0000001B8CA4: DC520040 277C0045
	global_load_b32 v13, v[67:68], off offset:128              // 0000001B8CAC: DC520080 0D7C0043
	global_load_b32 v14, v[69:70], off offset:128              // 0000001B8CB4: DC520080 0E7C0045
	global_load_b32 v7, v[69:70], off offset:192               // 0000001B8CBC: DC5200C0 077C0045
	global_load_b32 v8, v[67:68], off offset:192               // 0000001B8CC4: DC5200C0 087C0043
	s_and_saveexec_b32 s0, s10                                 // 0000001B8CCC: BE80200A
	s_cbranch_execz 8                                          // 0000001B8CD0: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x41f4>
	global_load_b32 v1, v[2:3], off                            // 0000001B8CD4: DC520000 017C0002
	s_waitcnt vmcnt(0)                                         // 0000001B8CDC: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v41                         // 0000001B8CE0: 560252FF BB800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B8CE8: BF870001
	v_fma_mixlo_f16 v1, v1, s22, 0                             // 0000001B8CEC: CC210001 02002D01
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001B8CF4: 8C7E007E
	s_waitcnt vmcnt(29)                                        // 0000001B8CF8: BF8977F7
	v_dual_fmac_f32 v60, 0xbb800000, v43 :: v_dual_add_nc_u32 v179, 2, v172// 0000001B8CFC: C82056FF 3CB35882 BB800000
	v_dual_fmac_f32 v63, 0xbb800000, v42 :: v_dual_add_nc_u32 v178, 4, v172// 0000001B8D08: C82054FF 3FB35884 BB800000
	s_waitcnt vmcnt(14)                                        // 0000001B8D14: BF893BF7
	v_dual_fmac_f32 v64, 0xbb800000, v46 :: v_dual_add_nc_u32 v177, 6, v172// 0000001B8D18: C8205CFF 40B15886 BB800000
	v_dual_fmac_f32 v66, 0xbb800000, v44 :: v_dual_fmac_f32 v65, 0xbb800000, v45// 0000001B8D24: C80058FF 42405AFF BB800000
	s_waitcnt vmcnt(13)                                        // 0000001B8D30: BF8937F7
	v_dual_fmac_f32 v61, 0xbb800000, v47 :: v_dual_add_nc_u32 v176, 8, v172// 0000001B8D34: C8205EFF 3DB15888 BB800000
	v_dual_fmac_f32 v40, 0xbb800000, v17 :: v_dual_add_nc_u32 v175, 10, v172// 0000001B8D40: C82022FF 28AF588A BB800000
	v_dual_fmac_f32 v57, 0xbb800000, v18 :: v_dual_add_nc_u32 v174, 12, v172// 0000001B8D4C: C82024FF 39AF588C BB800000
	s_waitcnt vmcnt(12)                                        // 0000001B8D58: BF8933F7
	v_dual_fmac_f32 v36, 0xbb800000, v21 :: v_dual_add_nc_u32 v173, 14, v172// 0000001B8D5C: C8202AFF 24AD588E BB800000
	s_waitcnt vmcnt(6)                                         // 0000001B8D68: BF891BF7
	v_dual_fmac_f32 v62, 0xbb800000, v48 :: v_dual_fmac_f32 v59, 0xbb800000, v19// 0000001B8D6C: C80060FF 3E3A26FF BB800000
	.long 0xd444000d                                           // 0000001B8D78: D444000D
	v_cndmask_b32_e32 v1, s58, v179, vcc_lo                    // 0000001B8D7C: 0203663A
	v_fma_mixhi_f16 v1, v63, s22, 0                            // 0000001B8D80: CC220001 02002D3F
	.long 0xd444000c                                           // 0000001B8D88: D444000C
	v_cndmask_b32_e32 v1, s58, v178, vcc_lo                    // 0000001B8D8C: 0203643A
	v_fma_mixlo_f16 v2, v60, s22, 0                            // 0000001B8D90: CC210002 02002D3C
	.long 0xd444000b                                           // 0000001B8D98: D444000B
	v_cndmask_b32_e32 v1, s58, v177, vcc_lo                    // 0000001B8D9C: 0203623A
	v_fma_mixhi_f16 v2, v66, s22, 0                            // 0000001B8DA0: CC220002 02002D42
	.long 0xd4440009                                           // 0000001B8DA8: D4440009
	v_cndmask_b32_e32 v1, s58, v176, vcc_lo                    // 0000001B8DAC: 0203603A
	v_fma_mixlo_f16 v3, v65, s22, 0                            // 0000001B8DB0: CC210003 02002D41
	.long 0xd4440001                                           // 0000001B8DB8: D4440001
	v_cndmask_b32_e32 v1, s58, v175, vcc_lo                    // 0000001B8DBC: 02035E3A
	v_fma_mixhi_f16 v3, v64, s22, 0                            // 0000001B8DC0: CC220003 02002D40
	.long 0xd4440008                                           // 0000001B8DC8: D4440008
	v_cndmask_b32_e32 v1, s58, v174, vcc_lo                    // 0000001B8DCC: 02035C3A
	v_fma_mixlo_f16 v41, v61, s22, 0                           // 0000001B8DD0: CC210029 02002D3D
	.long 0xd4440000                                           // 0000001B8DD8: D4440000
	v_cndmask_b32_e32 v1, s58, v173, vcc_lo                    // 0000001B8DDC: 02035A3A
	v_fma_mixhi_f16 v41, v62, s22, 0                           // 0000001B8DE0: CC220029 02002D3E
	v_dual_fmac_f32 v58, 0xbb800000, v20 :: v_dual_fmac_f32 v37, 0xbb800000, v22// 0000001B8DE8: C80028FF 3A242CFF BB800000
	v_cndmask_b16 v1, 0, v1, s13                               // 0000001B8DF4: D65D5001 00360280
	v_cndmask_b16 v2, 0, v2, s12                               // 0000001B8DFC: D65D0002 00320480
	v_fma_mixlo_f16 v18, v40, s22, 0                           // 0000001B8E04: CC210012 02002D28
	s_waitcnt vmcnt(4)                                         // 0000001B8E0C: BF8913F7
	v_dual_fmac_f32 v38, 0xbb800000, v23 :: v_dual_fmac_f32 v39, 0xbb800000, v24// 0000001B8E10: C8002EFF 262630FF BB800000
	v_cndmask_b16 v2, 0, v2, s11                               // 0000001B8E1C: D65D5002 002E0480
	v_fma_mixhi_f16 v18, v57, s22, 0                           // 0000001B8E24: CC220012 02002D39
	v_cndmask_b16 v3, 0, v3, s9                                // 0000001B8E2C: D65D0003 00260680
	v_fma_mixlo_f16 v19, v59, s22, 0                           // 0000001B8E34: CC210013 02002D3B
	v_cndmask_b16 v3, 0, v3, s1                                // 0000001B8E3C: D65D5003 00060680
	v_cndmask_b16 v17, 0, v41, s8                              // 0000001B8E44: D65D0011 00225280
	v_cndmask_b16 v17, 0, v41, s0                              // 0000001B8E4C: D65D5011 00025280
	ds_store_b16 v136, v1                                      // 0000001B8E54: D87C0000 00000188
	ds_store_b16_d16_hi v136, v1 offset:4                      // 0000001B8E5C: DA840004 00000188
	ds_store_b16 v136, v2 offset:8                             // 0000001B8E64: D87C0008 00000288
	ds_store_b16_d16_hi v136, v2 offset:12                     // 0000001B8E6C: DA84000C 00000288
	ds_store_b16 v136, v3 offset:16                            // 0000001B8E74: D87C0010 00000388
	ds_store_b16_d16_hi v136, v3 offset:20                     // 0000001B8E7C: DA840014 00000388
	ds_store_b16 v136, v17 offset:24                           // 0000001B8E84: D87C0018 00001188
	ds_store_b16_d16_hi v136, v17 offset:28                    // 0000001B8E8C: DA84001C 00001188
	v_fma_mixhi_f16 v2, v58, s22, 0                            // 0000001B8E94: CC220002 02002D3A
	v_fma_mixlo_f16 v3, v36, s22, 0                            // 0000001B8E9C: CC210003 02002D24
	v_dual_fmac_f32 v35, 0xbb800000, v49 :: v_dual_fmac_f32 v34, 0xbb800000, v51// 0000001B8EA4: C80062FF 232266FF BB800000
	v_cndmask_b16 v1, 0, v18, s10                              // 0000001B8EB0: D65D0001 002A2480
	v_fma_mixhi_f16 v3, v37, s22, 0                            // 0000001B8EB8: CC220003 02002D25
	v_fma_mixlo_f16 v17, v38, s22, 0                           // 0000001B8EC0: CC210011 02002D26
	v_fma_mixhi_f16 v17, v39, s22, 0                           // 0000001B8EC8: CC220011 02002D27
	v_dual_fmac_f32 v15, 0xbb800000, v50 :: v_dual_fmac_f32 v12, 0xbb800000, v52// 0000001B8ED0: C80064FF 0F0C68FF BB800000
	v_cndmask_b16 v1, 0, v18, s13                              // 0000001B8EDC: D65D5001 00362480
	v_cndmask_b16 v2, 0, v19, s12                              // 0000001B8EE4: D65D0002 00322680
	v_cndmask_b16 v2, 0, v2, s11                               // 0000001B8EEC: D65D5002 002E0480
	v_dual_fmac_f32 v16, 0xbb800000, v53 :: v_dual_fmac_f32 v33, 0xbb800000, v54// 0000001B8EF4: C8006AFF 10206CFF BB800000
	v_cndmask_b16 v3, 0, v3, s9                                // 0000001B8F00: D65D0003 00260680
	v_fma_mixlo_f16 v18, v35, s22, 0                           // 0000001B8F08: CC210012 02002D23
	s_waitcnt vmcnt(2)                                         // 0000001B8F10: BF890BF7
	v_dual_fmac_f32 v13, 0xbb800000, v55 :: v_dual_fmac_f32 v14, 0xbb800000, v56// 0000001B8F14: C8006EFF 0D0E70FF BB800000
	v_cndmask_b16 v3, 0, v3, s1                                // 0000001B8F20: D65D5003 00060680
	v_cndmask_b16 v17, 0, v17, s8                              // 0000001B8F28: D65D0011 00222280
	v_cndmask_b16 v17, 0, v17, s0                              // 0000001B8F30: D65D5011 00022280
	ds_store_b16 v136, v1 offset:2304                          // 0000001B8F38: D87C0900 00000188
	ds_store_b16_d16_hi v136, v1 offset:2308                   // 0000001B8F40: DA840904 00000188
	ds_store_b16 v136, v2 offset:2312                          // 0000001B8F48: D87C0908 00000288
	ds_store_b16_d16_hi v136, v2 offset:2316                   // 0000001B8F50: DA84090C 00000288
	ds_store_b16 v136, v3 offset:2320                          // 0000001B8F58: D87C0910 00000388
	ds_store_b16_d16_hi v136, v3 offset:2324                   // 0000001B8F60: DA840914 00000388
	ds_store_b16 v136, v17 offset:2328                         // 0000001B8F68: D87C0918 00001188
	ds_store_b16_d16_hi v136, v17 offset:2332                  // 0000001B8F70: DA84091C 00001188
	v_fma_mixhi_f16 v1, v15, s22, 0                            // 0000001B8F78: CC220001 02002D0F
	v_fma_mixlo_f16 v2, v34, s22, 0                            // 0000001B8F80: CC210002 02002D22
	v_dual_fmac_f32 v10, 0xbb800000, v25 :: v_dual_fmac_f32 v9, 0xbb800000, v26// 0000001B8F88: C80032FF 0A0834FF BB800000
	v_fma_mixhi_f16 v2, v12, s22, 0                            // 0000001B8F94: CC220002 02002D0C
	v_fma_mixlo_f16 v3, v16, s22, 0                            // 0000001B8F9C: CC210003 02002D10
	v_dual_fmac_f32 v11, 0xbb800000, v27 :: v_dual_fmac_f32 v4, 0xbb800000, v28// 0000001B8FA4: C80036FF 0B0438FF BB800000
	v_cndmask_b16 v1, 0, v18, s10                              // 0000001B8FB0: D65D0001 002A2480
	v_fma_mixhi_f16 v3, v33, s22, 0                            // 0000001B8FB8: CC220003 02002D21
	v_fma_mixlo_f16 v12, v13, s22, 0                           // 0000001B8FC0: CC21000C 02002D0D
	v_fma_mixhi_f16 v12, v14, s22, 0                           // 0000001B8FC8: CC22000C 02002D0E
	v_cndmask_b16 v1, 0, v1, s13                               // 0000001B8FD0: D65D5001 00360280
	v_dual_fmac_f32 v6, 0xbb800000, v29 :: v_dual_fmac_f32 v5, 0xbb800000, v30// 0000001B8FD8: C8003AFF 06043CFF BB800000
	v_cndmask_b16 v2, 0, v2, s12                               // 0000001B8FE4: D65D0002 00320480
	v_fma_mixlo_f16 v10, v10, s22, 0                           // 0000001B8FEC: CC21000A 02002D0A
	s_waitcnt vmcnt(0)                                         // 0000001B8FF4: BF8903F7
	v_dual_fmac_f32 v8, 0xbb800000, v31 :: v_dual_fmac_f32 v7, 0xbb800000, v32// 0000001B8FF8: C8003EFF 080640FF BB800000
	v_cndmask_b16 v2, 0, v2, s11                               // 0000001B9004: D65D5002 002E0480
	v_fma_mixlo_f16 v9, v9, s22, 0                             // 0000001B900C: CC210009 02002D09
	v_cndmask_b16 v3, 0, v3, s9                                // 0000001B9014: D65D0003 00260680
	v_fma_mixhi_f16 v9, v11, s22, 0                            // 0000001B901C: CC220009 02002D0B
	v_cndmask_b16 v3, 0, v3, s1                                // 0000001B9024: D65D5003 00060680
	v_cndmask_b16 v12, 0, v12, s8                              // 0000001B902C: D65D000C 00221880
	v_cndmask_b16 v12, 0, v12, s0                              // 0000001B9034: D65D500C 00021880
	ds_store_b16 v136, v1 offset:4608                          // 0000001B903C: D87C1200 00000188
	ds_store_b16_d16_hi v136, v1 offset:4612                   // 0000001B9044: DA841204 00000188
	ds_store_b16 v136, v2 offset:4616                          // 0000001B904C: D87C1208 00000288
	ds_store_b16_d16_hi v136, v2 offset:4620                   // 0000001B9054: DA84120C 00000288
	ds_store_b16 v136, v3 offset:4624                          // 0000001B905C: D87C1210 00000388
	ds_store_b16_d16_hi v136, v3 offset:4628                   // 0000001B9064: DA841214 00000388
	ds_store_b16 v136, v12 offset:4632                         // 0000001B906C: D87C1218 00000C88
	ds_store_b16_d16_hi v136, v12 offset:4636                  // 0000001B9074: DA84121C 00000C88
	v_fma_mixhi_f16 v2, v4, s22, 0                             // 0000001B907C: CC220002 02002D04
	v_fma_mixlo_f16 v3, v6, s22, 0                             // 0000001B9084: CC210003 02002D06
	v_cndmask_b16 v1, 0, v10, s10                              // 0000001B908C: D65D0001 002A1480
	v_fma_mixhi_f16 v3, v5, s22, 0                             // 0000001B9094: CC220003 02002D05
	v_fma_mixlo_f16 v4, v8, s22, 0                             // 0000001B909C: CC210004 02002D08
	v_fma_mixhi_f16 v4, v7, s22, 0                             // 0000001B90A4: CC220004 02002D07
	v_cndmask_b16 v1, 0, v9, s13                               // 0000001B90AC: D65D4001 00361280
	v_cndmask_b16 v2, 0, v9, s12                               // 0000001B90B4: D65D1002 00321280
	v_cndmask_b16 v2, 0, v2, s11                               // 0000001B90BC: D65D5002 002E0480
	v_cndmask_b16 v3, 0, v3, s9                                // 0000001B90C4: D65D0003 00260680
	v_cndmask_b16 v3, 0, v3, s1                                // 0000001B90CC: D65D5003 00060680
	v_cndmask_b16 v4, 0, v4, s8                                // 0000001B90D4: D65D0004 00220880
	v_cndmask_b16 v4, 0, v4, s0                                // 0000001B90DC: D65D5004 00020880
	ds_store_b16 v136, v1 offset:6912                          // 0000001B90E4: D87C1B00 00000188
	ds_store_b16_d16_hi v136, v1 offset:6916                   // 0000001B90EC: DA841B04 00000188
	ds_store_b16 v136, v2 offset:6920                          // 0000001B90F4: D87C1B08 00000288
	ds_store_b16_d16_hi v136, v2 offset:6924                   // 0000001B90FC: DA841B0C 00000288
	ds_store_b16 v136, v3 offset:6928                          // 0000001B9104: D87C1B10 00000388
	ds_store_b16_d16_hi v136, v3 offset:6932                   // 0000001B910C: DA841B14 00000388
	ds_store_b16 v136, v4 offset:6936                          // 0000001B9114: D87C1B18 00000488
	ds_store_b16_d16_hi v136, v4 offset:6940                   // 0000001B911C: DA841B1C 00000488
	.long 0xd7000e01                                           // 0000001B9124: D7000E01
	v_cndmask_b32_e32 v1, s24, v97, vcc_lo                     // 0000001B9128: 0202C218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B912C: BF870001
	v_add_co_ci_u32_e64 v2, null, s25, v98, s14                // 0000001B9130: D5207C02 003AC419
	s_waitcnt lgkmcnt(0)                                       // 0000001B9138: BF89FC07
	s_barrier                                                  // 0000001B913C: BFBD0000
	buffer_gl0_inv                                             // 0000001B9140: E0AC0000 00000000
	s_clause 0xf                                               // 0000001B9148: BF85000F
	global_load_b128 v[97:100], v[1:2], off                    // 0000001B914C: DC5E0000 617C0001
	global_load_b128 v[101:104], v[1:2], off offset:16         // 0000001B9154: DC5E0010 657C0001
	global_load_b128 v[89:92], v[1:2], off offset:32           // 0000001B915C: DC5E0020 597C0001
	global_load_b128 v[93:96], v[1:2], off offset:48           // 0000001B9164: DC5E0030 5D7C0001
	global_load_b128 v[81:84], v[1:2], off offset:64           // 0000001B916C: DC5E0040 517C0001
	global_load_b128 v[85:88], v[1:2], off offset:80           // 0000001B9174: DC5E0050 557C0001
	global_load_b128 v[73:76], v[1:2], off offset:96           // 0000001B917C: DC5E0060 497C0001
	global_load_b128 v[77:80], v[1:2], off offset:112          // 0000001B9184: DC5E0070 4D7C0001
	global_load_b128 v[57:60], v[1:2], off offset:128          // 0000001B918C: DC5E0080 397C0001
	global_load_b128 v[61:64], v[1:2], off offset:144          // 0000001B9194: DC5E0090 3D7C0001
	global_load_b128 v[49:52], v[1:2], off offset:160          // 0000001B919C: DC5E00A0 317C0001
	global_load_b128 v[53:56], v[1:2], off offset:176          // 0000001B91A4: DC5E00B0 357C0001
	global_load_b128 v[41:44], v[1:2], off offset:192          // 0000001B91AC: DC5E00C0 297C0001
	global_load_b128 v[45:48], v[1:2], off offset:208          // 0000001B91B4: DC5E00D0 2D7C0001
	global_load_b128 v[33:36], v[1:2], off offset:224          // 0000001B91BC: DC5E00E0 217C0001
	global_load_b128 v[37:40], v[1:2], off offset:240          // 0000001B91C4: DC5E00F0 257C0001
	s_and_saveexec_b32 s14, vcc_lo                             // 0000001B91CC: BE8E206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B91D0: BF870009
	s_xor_b32 s14, exec_lo, s14                                // 0000001B91D4: 8D0E0E7E
	s_cbranch_execz 81                                         // 0000001B91D8: BFA50051 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4820>
	s_waitcnt vmcnt(15)                                        // 0000001B91DC: BF893FF7
	v_mov_b32_e32 v97, 0                                       // 0000001B91E0: 7EC20280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B91E4: BF870001
	v_mov_b32_e32 v98, v97                                     // 0000001B91E8: 7EC40361
	v_mov_b32_e32 v99, v97                                     // 0000001B91EC: 7EC60361
	v_mov_b32_e32 v100, v97                                    // 0000001B91F0: 7EC80361
	s_waitcnt vmcnt(14)                                        // 0000001B91F4: BF893BF7
	v_mov_b32_e32 v101, v97                                    // 0000001B91F8: 7ECA0361
	v_mov_b32_e32 v102, v97                                    // 0000001B91FC: 7ECC0361
	v_mov_b32_e32 v103, v97                                    // 0000001B9200: 7ECE0361
	v_mov_b32_e32 v104, v97                                    // 0000001B9204: 7ED00361
	s_waitcnt vmcnt(13)                                        // 0000001B9208: BF8937F7
	v_mov_b32_e32 v89, v97                                     // 0000001B920C: 7EB20361
	v_mov_b32_e32 v90, v97                                     // 0000001B9210: 7EB40361
	v_mov_b32_e32 v91, v97                                     // 0000001B9214: 7EB60361
	v_mov_b32_e32 v92, v97                                     // 0000001B9218: 7EB80361
	s_waitcnt vmcnt(12)                                        // 0000001B921C: BF8933F7
	v_mov_b32_e32 v93, v97                                     // 0000001B9220: 7EBA0361
	v_mov_b32_e32 v94, v97                                     // 0000001B9224: 7EBC0361
	v_mov_b32_e32 v95, v97                                     // 0000001B9228: 7EBE0361
	v_mov_b32_e32 v96, v97                                     // 0000001B922C: 7EC00361
	s_waitcnt vmcnt(11)                                        // 0000001B9230: BF892FF7
	v_mov_b32_e32 v81, v97                                     // 0000001B9234: 7EA20361
	v_mov_b32_e32 v82, v97                                     // 0000001B9238: 7EA40361
	v_mov_b32_e32 v83, v97                                     // 0000001B923C: 7EA60361
	v_mov_b32_e32 v84, v97                                     // 0000001B9240: 7EA80361
	s_waitcnt vmcnt(10)                                        // 0000001B9244: BF892BF7
	v_mov_b32_e32 v85, v97                                     // 0000001B9248: 7EAA0361
	v_mov_b32_e32 v86, v97                                     // 0000001B924C: 7EAC0361
	v_mov_b32_e32 v87, v97                                     // 0000001B9250: 7EAE0361
	v_mov_b32_e32 v88, v97                                     // 0000001B9254: 7EB00361
	s_waitcnt vmcnt(9)                                         // 0000001B9258: BF8927F7
	v_mov_b32_e32 v73, v97                                     // 0000001B925C: 7E920361
	v_mov_b32_e32 v74, v97                                     // 0000001B9260: 7E940361
	v_mov_b32_e32 v75, v97                                     // 0000001B9264: 7E960361
	v_mov_b32_e32 v76, v97                                     // 0000001B9268: 7E980361
	s_waitcnt vmcnt(8)                                         // 0000001B926C: BF8923F7
	v_mov_b32_e32 v77, v97                                     // 0000001B9270: 7E9A0361
	v_mov_b32_e32 v78, v97                                     // 0000001B9274: 7E9C0361
	v_mov_b32_e32 v79, v97                                     // 0000001B9278: 7E9E0361
	v_mov_b32_e32 v80, v97                                     // 0000001B927C: 7EA00361
	s_waitcnt vmcnt(7)                                         // 0000001B9280: BF891FF7
	v_mov_b32_e32 v57, v97                                     // 0000001B9284: 7E720361
	v_mov_b32_e32 v58, v97                                     // 0000001B9288: 7E740361
	v_mov_b32_e32 v59, v97                                     // 0000001B928C: 7E760361
	v_mov_b32_e32 v60, v97                                     // 0000001B9290: 7E780361
	s_waitcnt vmcnt(6)                                         // 0000001B9294: BF891BF7
	v_mov_b32_e32 v61, v97                                     // 0000001B9298: 7E7A0361
	v_mov_b32_e32 v62, v97                                     // 0000001B929C: 7E7C0361
	v_mov_b32_e32 v63, v97                                     // 0000001B92A0: 7E7E0361
	v_mov_b32_e32 v64, v97                                     // 0000001B92A4: 7E800361
	s_waitcnt vmcnt(5)                                         // 0000001B92A8: BF8917F7
	v_mov_b32_e32 v49, v97                                     // 0000001B92AC: 7E620361
	v_mov_b32_e32 v50, v97                                     // 0000001B92B0: 7E640361
	v_mov_b32_e32 v51, v97                                     // 0000001B92B4: 7E660361
	v_mov_b32_e32 v52, v97                                     // 0000001B92B8: 7E680361
	s_waitcnt vmcnt(4)                                         // 0000001B92BC: BF8913F7
	v_mov_b32_e32 v53, v97                                     // 0000001B92C0: 7E6A0361
	v_mov_b32_e32 v54, v97                                     // 0000001B92C4: 7E6C0361
	v_mov_b32_e32 v55, v97                                     // 0000001B92C8: 7E6E0361
	v_mov_b32_e32 v56, v97                                     // 0000001B92CC: 7E700361
	s_waitcnt vmcnt(3)                                         // 0000001B92D0: BF890FF7
	v_mov_b32_e32 v41, v97                                     // 0000001B92D4: 7E520361
	v_mov_b32_e32 v42, v97                                     // 0000001B92D8: 7E540361
	v_mov_b32_e32 v43, v97                                     // 0000001B92DC: 7E560361
	v_mov_b32_e32 v44, v97                                     // 0000001B92E0: 7E580361
	s_waitcnt vmcnt(2)                                         // 0000001B92E4: BF890BF7
	v_mov_b32_e32 v45, v97                                     // 0000001B92E8: 7E5A0361
	v_mov_b32_e32 v46, v97                                     // 0000001B92EC: 7E5C0361
	v_mov_b32_e32 v47, v97                                     // 0000001B92F0: 7E5E0361
	v_mov_b32_e32 v48, v97                                     // 0000001B92F4: 7E600361
	s_waitcnt vmcnt(1)                                         // 0000001B92F8: BF8907F7
	v_mov_b32_e32 v33, v97                                     // 0000001B92FC: 7E420361
	v_mov_b32_e32 v34, v97                                     // 0000001B9300: 7E440361
	v_mov_b32_e32 v35, v97                                     // 0000001B9304: 7E460361
	v_mov_b32_e32 v36, v97                                     // 0000001B9308: 7E480361
	s_waitcnt vmcnt(0)                                         // 0000001B930C: BF8903F7
	v_mov_b32_e32 v37, v97                                     // 0000001B9310: 7E4A0361
	v_mov_b32_e32 v38, v97                                     // 0000001B9314: 7E4C0361
	v_mov_b32_e32 v39, v97                                     // 0000001B9318: 7E4E0361
	v_mov_b32_e32 v40, v97                                     // 0000001B931C: 7E500361
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001B9320: 8C7E0E7E
	ds_load_b128 v[1:4], v127                                  // 0000001B9324: DBFC0000 0100007F
	ds_load_b128 v[5:8], v127 offset:16                        // 0000001B932C: DBFC0010 0500007F
	ds_load_b128 v[9:12], v127 offset:32                       // 0000001B9334: DBFC0020 0900007F
	ds_load_b128 v[13:16], v127 offset:48                      // 0000001B933C: DBFC0030 0D00007F
	ds_load_b128 v[17:20], v127 offset:8448                    // 0000001B9344: DBFC2100 1100007F
	ds_load_b128 v[21:24], v127 offset:8464                    // 0000001B934C: DBFC2110 1500007F
	ds_load_b128 v[25:28], v127 offset:8480                    // 0000001B9354: DBFC2120 1900007F
	ds_load_b128 v[29:32], v127 offset:8496                    // 0000001B935C: DBFC2130 1D00007F
	ds_load_b128 v[180:183], v127 offset:16896                 // 0000001B9364: DBFC4200 B400007F
	ds_load_b128 v[184:187], v127 offset:16912                 // 0000001B936C: DBFC4210 B800007F
	ds_load_b128 v[188:191], v127 offset:16928                 // 0000001B9374: DBFC4220 BC00007F
	ds_load_b128 v[192:195], v127 offset:16944                 // 0000001B937C: DBFC4230 C000007F
	ds_load_b128 v[196:199], v127 offset:25376                 // 0000001B9384: DBFC6320 C400007F
	v_dual_mov_b32 v72, s43 :: v_dual_mov_b32 v71, s42         // 0000001B938C: CA10002B 4846002A
	v_dual_mov_b32 v70, s41 :: v_dual_mov_b32 v69, s40         // 0000001B9394: CA100029 46440028
	v_dual_mov_b32 v68, s39 :: v_dual_mov_b32 v67, s38         // 0000001B939C: CA100027 44420026
	v_dual_mov_b32 v66, s37 :: v_dual_mov_b32 v65, s36         // 0000001B93A4: CA100025 42400024
	s_waitcnt lgkmcnt(12)                                      // 0000001B93AC: BF89FCC7
	v_fma_mixlo_f16 v1, v1, s22, 0                             // 0000001B93B0: CC210001 02002D01
	v_fma_mixhi_f16 v1, v2, s22, 0                             // 0000001B93B8: CC220001 02002D02
	v_fma_mixlo_f16 v2, v3, s22, 0                             // 0000001B93C0: CC210002 02002D03
	v_fma_mixhi_f16 v2, v4, s22, 0                             // 0000001B93C8: CC220002 02002D04
	s_waitcnt lgkmcnt(11)                                      // 0000001B93D0: BF89FCB7
	v_fma_mixlo_f16 v3, v5, s22, 0                             // 0000001B93D4: CC210003 02002D05
	v_fma_mixhi_f16 v3, v6, s22, 0                             // 0000001B93DC: CC220003 02002D06
	v_fma_mixlo_f16 v4, v7, s22, 0                             // 0000001B93E4: CC210004 02002D07
	v_fma_mixhi_f16 v4, v8, s22, 0                             // 0000001B93EC: CC220004 02002D08
	s_waitcnt lgkmcnt(10)                                      // 0000001B93F4: BF89FCA7
	v_fma_mixlo_f16 v5, v9, s22, 0                             // 0000001B93F8: CC210005 02002D09
	v_fma_mixhi_f16 v5, v10, s22, 0                            // 0000001B9400: CC220005 02002D0A
	v_fma_mixlo_f16 v6, v11, s22, 0                            // 0000001B9408: CC210006 02002D0B
	v_fma_mixhi_f16 v6, v12, s22, 0                            // 0000001B9410: CC220006 02002D0C
	s_waitcnt lgkmcnt(9)                                       // 0000001B9418: BF89FC97
	v_fma_mixlo_f16 v7, v13, s22, 0                            // 0000001B941C: CC210007 02002D0D
	v_fma_mixhi_f16 v7, v14, s22, 0                            // 0000001B9424: CC220007 02002D0E
	v_fma_mixlo_f16 v8, v15, s22, 0                            // 0000001B942C: CC210008 02002D0F
	v_fma_mixhi_f16 v8, v16, s22, 0                            // 0000001B9434: CC220008 02002D10
	s_waitcnt lgkmcnt(8)                                       // 0000001B943C: BF89FC87
	v_fma_mixlo_f16 v17, v17, s22, 0                           // 0000001B9440: CC210011 02002D11
	v_fma_mixhi_f16 v17, v18, s22, 0                           // 0000001B9448: CC220011 02002D12
	v_fma_mixlo_f16 v18, v19, s22, 0                           // 0000001B9450: CC210012 02002D13
	v_fma_mixhi_f16 v18, v20, s22, 0                           // 0000001B9458: CC220012 02002D14
	s_waitcnt lgkmcnt(7)                                       // 0000001B9460: BF89FC77
	v_fma_mixlo_f16 v19, v21, s22, 0                           // 0000001B9464: CC210013 02002D15
	v_fma_mixhi_f16 v19, v22, s22, 0                           // 0000001B946C: CC220013 02002D16
	v_fma_mixlo_f16 v20, v23, s22, 0                           // 0000001B9474: CC210014 02002D17
	v_fma_mixhi_f16 v20, v24, s22, 0                           // 0000001B947C: CC220014 02002D18
	s_waitcnt lgkmcnt(6)                                       // 0000001B9484: BF89FC67
	v_fma_mixlo_f16 v21, v25, s22, 0                           // 0000001B9488: CC210015 02002D19
	v_fma_mixhi_f16 v21, v26, s22, 0                           // 0000001B9490: CC220015 02002D1A
	v_fma_mixlo_f16 v22, v27, s22, 0                           // 0000001B9498: CC210016 02002D1B
	v_fma_mixhi_f16 v22, v28, s22, 0                           // 0000001B94A0: CC220016 02002D1C
	s_waitcnt lgkmcnt(5)                                       // 0000001B94A8: BF89FC57
	v_fma_mixlo_f16 v23, v29, s22, 0                           // 0000001B94AC: CC210017 02002D1D
	v_fma_mixhi_f16 v23, v30, s22, 0                           // 0000001B94B4: CC220017 02002D1E
	v_fma_mixlo_f16 v24, v31, s22, 0                           // 0000001B94BC: CC210018 02002D1F
	v_fma_mixhi_f16 v24, v32, s22, 0                           // 0000001B94C4: CC220018 02002D20
	s_waitcnt vmcnt(14)                                        // 0000001B94CC: BF893BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[97:104], v[1:8], v[65:72]// 0000001B94D0: CC404019 1D060361
	s_waitcnt lgkmcnt(3)                                       // 0000001B94D8: BF89FC37
	v_fma_mixlo_f16 v4, v186, s22, 0                           // 0000001B94DC: CC210004 02002DBA
	v_fma_mixhi_f16 v4, v187, s22, 0                           // 0000001B94E4: CC220004 02002DBB
	v_wmma_f32_16x16x16_f16 v[9:16], v[97:104], v[17:24], v[65:72]// 0000001B94EC: CC404009 1D062361
	ds_load_b128 v[17:20], v127 offset:25344                   // 0000001B94F4: DBFC6300 1100007F
	ds_load_b128 v[21:24], v127 offset:25360                   // 0000001B94FC: DBFC6310 1500007F
	s_waitcnt lgkmcnt(4)                                       // 0000001B9504: BF89FC47
	v_fma_mixlo_f16 v5, v188, s22, 0                           // 0000001B9508: CC210005 02002DBC
	v_fma_mixhi_f16 v5, v189, s22, 0                           // 0000001B9510: CC220005 02002DBD
	ds_load_b128 v[186:189], v127 offset:25392                 // 0000001B9518: DBFC6330 BA00007F
	v_fma_mixlo_f16 v3, v184, s22, 0                           // 0000001B9520: CC210003 02002DB8
	v_fma_mixlo_f16 v6, v190, s22, 0                           // 0000001B9528: CC210006 02002DBE
	v_fma_mixhi_f16 v6, v191, s22, 0                           // 0000001B9530: CC220006 02002DBF
	s_waitcnt lgkmcnt(4)                                       // 0000001B9538: BF89FC47
	v_fma_mixlo_f16 v7, v192, s22, 0                           // 0000001B953C: CC210007 02002DC0
	v_fma_mixhi_f16 v7, v193, s22, 0                           // 0000001B9544: CC220007 02002DC1
	v_fma_mixlo_f16 v8, v194, s22, 0                           // 0000001B954C: CC210008 02002DC2
	v_fma_mixhi_f16 v8, v195, s22, 0                           // 0000001B9554: CC220008 02002DC3
	ds_load_b128 v[190:193], v127 offset:64                    // 0000001B955C: DBFC0040 BE00007F
	ds_load_b128 v[200:203], v127 offset:80                    // 0000001B9564: DBFC0050 C800007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B956C: BF89FC57
	v_fma_mixlo_f16 v184, v196, s22, 0                         // 0000001B9570: CC2100B8 02002DC4
	v_fma_mixhi_f16 v184, v197, s22, 0                         // 0000001B9578: CC2200B8 02002DC5
	ds_load_b128 v[194:197], v127 offset:96                    // 0000001B9580: DBFC0060 C200007F
	ds_load_b128 v[204:207], v127 offset:112                   // 0000001B9588: DBFC0070 CC00007F
	v_fma_mixlo_f16 v1, v180, s22, 0                           // 0000001B9590: CC210001 02002DB4
	v_fma_mixhi_f16 v1, v181, s22, 0                           // 0000001B9598: CC220001 02002DB5
	v_fma_mixlo_f16 v2, v182, s22, 0                           // 0000001B95A0: CC210002 02002DB6
	v_fma_mixhi_f16 v2, v183, s22, 0                           // 0000001B95A8: CC220002 02002DB7
	v_fma_mixhi_f16 v3, v185, s22, 0                           // 0000001B95B0: CC220003 02002DB9
	s_waitcnt lgkmcnt(6)                                       // 0000001B95B8: BF89FC67
	v_fma_mixlo_f16 v180, v17, s22, 0                          // 0000001B95BC: CC2100B4 02002D11
	v_fma_mixhi_f16 v180, v18, s22, 0                          // 0000001B95C4: CC2200B4 02002D12
	v_fma_mixlo_f16 v181, v19, s22, 0                          // 0000001B95CC: CC2100B5 02002D13
	v_fma_mixhi_f16 v181, v20, s22, 0                          // 0000001B95D4: CC2200B5 02002D14
	s_waitcnt lgkmcnt(5)                                       // 0000001B95DC: BF89FC57
	v_fma_mixlo_f16 v182, v21, s22, 0                          // 0000001B95E0: CC2100B6 02002D15
	v_fma_mixhi_f16 v182, v22, s22, 0                          // 0000001B95E8: CC2200B6 02002D16
	v_fma_mixlo_f16 v183, v23, s22, 0                          // 0000001B95F0: CC2100B7 02002D17
	v_fma_mixhi_f16 v183, v24, s22, 0                          // 0000001B95F8: CC2200B7 02002D18
	v_fma_mixlo_f16 v185, v198, s22, 0                         // 0000001B9600: CC2100B9 02002DC6
	v_fma_mixhi_f16 v185, v199, s22, 0                         // 0000001B9608: CC2200B9 02002DC7
	s_waitcnt lgkmcnt(4)                                       // 0000001B9610: BF89FC47
	v_fma_mixlo_f16 v186, v186, s22, 0                         // 0000001B9614: CC2100BA 02002DBA
	v_fma_mixhi_f16 v186, v187, s22, 0                         // 0000001B961C: CC2200BA 02002DBB
	v_fma_mixlo_f16 v187, v188, s22, 0                         // 0000001B9624: CC2100BB 02002DBC
	v_fma_mixhi_f16 v187, v189, s22, 0                         // 0000001B962C: CC2200BB 02002DBD
	v_wmma_f32_16x16x16_f16 v[17:24], v[97:104], v[1:8], v[65:72]// 0000001B9634: CC404011 1D060361
	ds_load_b128 v[208:211], v127 offset:17008                 // 0000001B963C: DBFC4270 D000007F
	ds_load_b128 v[212:215], v127 offset:25408                 // 0000001B9644: DBFC6340 D400007F
	ds_load_b128 v[216:219], v127 offset:25424                 // 0000001B964C: DBFC6350 D800007F
	v_wmma_f32_16x16x16_f16 v[1:8], v[97:104], v[180:187], v[65:72]// 0000001B9654: CC404001 1D076961
	ds_load_b128 v[180:183], v127 offset:8512                  // 0000001B965C: DBFC2140 B400007F
	ds_load_b128 v[184:187], v127 offset:8528                  // 0000001B9664: DBFC2150 B800007F
	s_waitcnt lgkmcnt(8)                                       // 0000001B966C: BF89FC87
	v_fma_mixlo_f16 v97, v190, s22, 0                          // 0000001B9670: CC210061 02002DBE
	v_fma_mixhi_f16 v97, v191, s22, 0                          // 0000001B9678: CC220061 02002DBF
	v_fma_mixlo_f16 v98, v192, s22, 0                          // 0000001B9680: CC210062 02002DC0
	v_fma_mixhi_f16 v98, v193, s22, 0                          // 0000001B9688: CC220062 02002DC1
	s_waitcnt lgkmcnt(7)                                       // 0000001B9690: BF89FC77
	v_fma_mixlo_f16 v99, v200, s22, 0                          // 0000001B9694: CC210063 02002DC8
	v_fma_mixhi_f16 v99, v201, s22, 0                          // 0000001B969C: CC220063 02002DC9
	v_fma_mixlo_f16 v100, v202, s22, 0                         // 0000001B96A4: CC210064 02002DCA
	v_fma_mixhi_f16 v100, v203, s22, 0                         // 0000001B96AC: CC220064 02002DCB
	ds_load_b128 v[188:191], v127 offset:8544                  // 0000001B96B4: DBFC2160 BC00007F
	s_waitcnt lgkmcnt(7)                                       // 0000001B96BC: BF89FC77
	v_fma_mixlo_f16 v101, v194, s22, 0                         // 0000001B96C0: CC210065 02002DC2
	v_fma_mixhi_f16 v101, v195, s22, 0                         // 0000001B96C8: CC220065 02002DC3
	v_fma_mixlo_f16 v102, v196, s22, 0                         // 0000001B96D0: CC210066 02002DC4
	v_fma_mixhi_f16 v102, v197, s22, 0                         // 0000001B96D8: CC220066 02002DC5
	ds_load_b128 v[192:195], v127 offset:8560                  // 0000001B96E0: DBFC2170 C000007F
	s_waitcnt lgkmcnt(7)                                       // 0000001B96E8: BF89FC77
	v_fma_mixlo_f16 v103, v204, s22, 0                         // 0000001B96EC: CC210067 02002DCC
	v_fma_mixhi_f16 v103, v205, s22, 0                         // 0000001B96F4: CC220067 02002DCD
	v_fma_mixlo_f16 v104, v206, s22, 0                         // 0000001B96FC: CC210068 02002DCE
	v_fma_mixhi_f16 v104, v207, s22, 0                         // 0000001B9704: CC220068 02002DCF
	ds_load_b128 v[196:199], v127 offset:16960                 // 0000001B970C: DBFC4240 C400007F
	ds_load_b128 v[200:203], v127 offset:16976                 // 0000001B9714: DBFC4250 C800007F
	ds_load_b128 v[204:207], v127 offset:16992                 // 0000001B971C: DBFC4260 CC00007F
	s_waitcnt lgkmcnt(6)                                       // 0000001B9724: BF89FC67
	v_fma_mixlo_f16 v180, v180, s22, 0                         // 0000001B9728: CC2100B4 02002DB4
	v_fma_mixhi_f16 v180, v181, s22, 0                         // 0000001B9730: CC2200B4 02002DB5
	v_fma_mixlo_f16 v181, v182, s22, 0                         // 0000001B9738: CC2100B5 02002DB6
	v_fma_mixhi_f16 v181, v183, s22, 0                         // 0000001B9740: CC2200B5 02002DB7
	s_waitcnt lgkmcnt(5)                                       // 0000001B9748: BF89FC57
	v_fma_mixhi_f16 v182, v185, s22, 0                         // 0000001B974C: CC2200B6 02002DB9
	v_fma_mixlo_f16 v183, v186, s22, 0                         // 0000001B9754: CC2100B7 02002DBA
	ds_load_b128 v[220:223], v127 offset:25440                 // 0000001B975C: DBFC6360 DC00007F
	s_waitcnt lgkmcnt(5)                                       // 0000001B9764: BF89FC57
	v_fma_mixhi_f16 v185, v191, s22, 0                         // 0000001B9768: CC2200B9 02002DBF
	v_fma_mixlo_f16 v182, v184, s22, 0                         // 0000001B9770: CC2100B6 02002DB8
	v_fma_mixhi_f16 v183, v187, s22, 0                         // 0000001B9778: CC2200B7 02002DBB
	v_fma_mixlo_f16 v184, v188, s22, 0                         // 0000001B9780: CC2100B8 02002DBC
	v_fma_mixhi_f16 v184, v189, s22, 0                         // 0000001B9788: CC2200B8 02002DBD
	s_waitcnt lgkmcnt(4)                                       // 0000001B9790: BF89FC47
	v_fma_mixlo_f16 v186, v192, s22, 0                         // 0000001B9794: CC2100BA 02002DC0
	v_fma_mixlo_f16 v185, v190, s22, 0                         // 0000001B979C: CC2100B9 02002DBE
	v_fma_mixhi_f16 v186, v193, s22, 0                         // 0000001B97A4: CC2200BA 02002DC1
	v_fma_mixlo_f16 v187, v194, s22, 0                         // 0000001B97AC: CC2100BB 02002DC2
	v_fma_mixhi_f16 v187, v195, s22, 0                         // 0000001B97B4: CC2200BB 02002DC3
	s_waitcnt lgkmcnt(3)                                       // 0000001B97BC: BF89FC37
	v_fma_mixlo_f16 v188, v196, s22, 0                         // 0000001B97C0: CC2100BC 02002DC4
	s_waitcnt lgkmcnt(2)                                       // 0000001B97C8: BF89FC27
	v_fma_mixlo_f16 v191, v202, s22, 0                         // 0000001B97CC: CC2100BF 02002DCA
	v_fma_mixhi_f16 v191, v203, s22, 0                         // 0000001B97D4: CC2200BF 02002DCB
	s_waitcnt lgkmcnt(1)                                       // 0000001B97DC: BF89FC17
	v_fma_mixlo_f16 v192, v204, s22, 0                         // 0000001B97E0: CC2100C0 02002DCC
	v_fma_mixhi_f16 v192, v205, s22, 0                         // 0000001B97E8: CC2200C0 02002DCD
	ds_load_b128 v[202:205], v127 offset:25456                 // 0000001B97F0: DBFC6370 CA00007F
	v_fma_mixhi_f16 v188, v197, s22, 0                         // 0000001B97F8: CC2200BC 02002DC5
	v_fma_mixlo_f16 v189, v198, s22, 0                         // 0000001B9800: CC2100BD 02002DC6
	v_fma_mixhi_f16 v189, v199, s22, 0                         // 0000001B9808: CC2200BD 02002DC7
	v_fma_mixlo_f16 v190, v200, s22, 0                         // 0000001B9810: CC2100BE 02002DC8
	v_fma_mixhi_f16 v190, v201, s22, 0                         // 0000001B9818: CC2200BE 02002DC9
	v_fma_mixlo_f16 v193, v206, s22, 0                         // 0000001B9820: CC2100C1 02002DCE
	v_fma_mixhi_f16 v193, v207, s22, 0                         // 0000001B9828: CC2200C1 02002DCF
	v_fma_mixlo_f16 v194, v208, s22, 0                         // 0000001B9830: CC2100C2 02002DD0
	v_fma_mixhi_f16 v194, v209, s22, 0                         // 0000001B9838: CC2200C2 02002DD1
	v_fma_mixlo_f16 v195, v210, s22, 0                         // 0000001B9840: CC2100C3 02002DD2
	v_fma_mixhi_f16 v195, v211, s22, 0                         // 0000001B9848: CC2200C3 02002DD3
	v_fma_mixlo_f16 v196, v212, s22, 0                         // 0000001B9850: CC2100C4 02002DD4
	v_fma_mixhi_f16 v196, v213, s22, 0                         // 0000001B9858: CC2200C4 02002DD5
	v_fma_mixlo_f16 v197, v214, s22, 0                         // 0000001B9860: CC2100C5 02002DD6
	v_fma_mixhi_f16 v197, v215, s22, 0                         // 0000001B9868: CC2200C5 02002DD7
	v_fma_mixlo_f16 v198, v216, s22, 0                         // 0000001B9870: CC2100C6 02002DD8
	v_fma_mixhi_f16 v198, v217, s22, 0                         // 0000001B9878: CC2200C6 02002DD9
	v_fma_mixlo_f16 v199, v218, s22, 0                         // 0000001B9880: CC2100C7 02002DDA
	v_fma_mixhi_f16 v199, v219, s22, 0                         // 0000001B9888: CC2200C7 02002DDB
	s_waitcnt lgkmcnt(1)                                       // 0000001B9890: BF89FC17
	v_fma_mixlo_f16 v200, v220, s22, 0                         // 0000001B9894: CC2100C8 02002DDC
	v_fma_mixhi_f16 v200, v221, s22, 0                         // 0000001B989C: CC2200C8 02002DDD
	v_fma_mixlo_f16 v201, v222, s22, 0                         // 0000001B98A4: CC2100C9 02002DDE
	v_fma_mixhi_f16 v201, v223, s22, 0                         // 0000001B98AC: CC2200C9 02002DDF
	s_waitcnt lgkmcnt(0)                                       // 0000001B98B4: BF89FC07
	v_fma_mixlo_f16 v202, v202, s22, 0                         // 0000001B98B8: CC2100CA 02002DCA
	v_fma_mixhi_f16 v202, v203, s22, 0                         // 0000001B98C0: CC2200CA 02002DCB
	v_fma_mixlo_f16 v203, v204, s22, 0                         // 0000001B98C8: CC2100CB 02002DCC
	v_fma_mixhi_f16 v203, v205, s22, 0                         // 0000001B98D0: CC2200CB 02002DCD
	ds_load_b128 v[206:209], v127 offset:128                   // 0000001B98D8: DBFC0080 CE00007F
	ds_load_b128 v[210:213], v127 offset:144                   // 0000001B98E0: DBFC0090 D200007F
	ds_load_b128 v[214:217], v127 offset:160                   // 0000001B98E8: DBFC00A0 D600007F
	s_waitcnt vmcnt(12)                                        // 0000001B98F0: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[97:104], v[25:32]// 0000001B98F4: CC404019 1C66C359
	ds_load_b128 v[97:100], v127 offset:176                    // 0000001B98FC: DBFC00B0 6100007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[89:96], v[180:187], v[9:16]// 0000001B9904: CC404009 1C276959
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[188:195], v[17:24]// 0000001B990C: CC404011 1C477959
	v_wmma_f32_16x16x16_f16 v[1:8], v[89:96], v[196:203], v[1:8]// 0000001B9914: CC404001 1C078959
	ds_load_b128 v[101:104], v127 offset:8576                  // 0000001B991C: DBFC2180 6500007F
	ds_load_b128 v[180:183], v127 offset:8592                  // 0000001B9924: DBFC2190 B400007F
	ds_load_b128 v[184:187], v127 offset:8608                  // 0000001B992C: DBFC21A0 B800007F
	ds_load_b128 v[188:191], v127 offset:8624                  // 0000001B9934: DBFC21B0 BC00007F
	ds_load_b128 v[192:195], v127 offset:17024                 // 0000001B993C: DBFC4280 C000007F
	ds_load_b128 v[196:199], v127 offset:17040                 // 0000001B9944: DBFC4290 C400007F
	ds_load_b128 v[200:203], v127 offset:17056                 // 0000001B994C: DBFC42A0 C800007F
	s_mul_i32 s14, s23, 48                                     // 0000001B9954: 960EB017
	s_mul_hi_u32 s47, s23, 48                                  // 0000001B9958: 96AFB017
	s_add_u32 s48, s14, s2                                     // 0000001B995C: 8030020E
	s_addc_u32 s49, s47, s3                                    // 0000001B9960: 8231032F
	ds_load_b128 v[220:223], v127 offset:25648                 // 0000001B9964: DBFC6430 DC00007F
	s_waitcnt lgkmcnt(11)                                      // 0000001B996C: BF89FCB7
	v_fma_mixlo_f16 v89, v206, s22, 0                          // 0000001B9970: CC210059 02002DCE
	v_fma_mixhi_f16 v89, v207, s22, 0                          // 0000001B9978: CC220059 02002DCF
	v_fma_mixlo_f16 v90, v208, s22, 0                          // 0000001B9980: CC21005A 02002DD0
	v_fma_mixhi_f16 v90, v209, s22, 0                          // 0000001B9988: CC22005A 02002DD1
	s_waitcnt lgkmcnt(10)                                      // 0000001B9990: BF89FCA7
	v_fma_mixlo_f16 v91, v210, s22, 0                          // 0000001B9994: CC21005B 02002DD2
	v_fma_mixhi_f16 v91, v211, s22, 0                          // 0000001B999C: CC22005B 02002DD3
	s_waitcnt lgkmcnt(8)                                       // 0000001B99A4: BF89FC87
	v_fma_mixhi_f16 v95, v98, s22, 0                           // 0000001B99A8: CC22005F 02002D62
	v_fma_mixlo_f16 v96, v99, s22, 0                           // 0000001B99B0: CC210060 02002D63
	v_fma_mixhi_f16 v96, v100, s22, 0                          // 0000001B99B8: CC220060 02002D64
	s_waitcnt lgkmcnt(7)                                       // 0000001B99C0: BF89FC77
	v_fma_mixlo_f16 v98, v103, s22, 0                          // 0000001B99C4: CC210062 02002D67
	v_fma_mixhi_f16 v98, v104, s22, 0                          // 0000001B99CC: CC220062 02002D68
	s_waitcnt lgkmcnt(6)                                       // 0000001B99D4: BF89FC67
	v_fma_mixlo_f16 v99, v180, s22, 0                          // 0000001B99D8: CC210063 02002DB4
	v_fma_mixhi_f16 v99, v181, s22, 0                          // 0000001B99E0: CC220063 02002DB5
	v_fma_mixlo_f16 v100, v182, s22, 0                         // 0000001B99E8: CC210064 02002DB6
	v_fma_mixhi_f16 v100, v183, s22, 0                         // 0000001B99F0: CC220064 02002DB7
	s_waitcnt lgkmcnt(4)                                       // 0000001B99F8: BF89FC47
	v_fma_mixlo_f16 v103, v188, s22, 0                         // 0000001B99FC: CC210067 02002DBC
	ds_load_b128 v[204:207], v127 offset:17072                 // 0000001B9A04: DBFC42B0 CC00007F
	v_fma_mixhi_f16 v103, v189, s22, 0                         // 0000001B9A0C: CC220067 02002DBD
	v_fma_mixlo_f16 v104, v190, s22, 0                         // 0000001B9A14: CC210068 02002DBE
	v_fma_mixhi_f16 v104, v191, s22, 0                         // 0000001B9A1C: CC220068 02002DBF
	ds_load_b128 v[188:191], v127 offset:25472                 // 0000001B9A24: DBFC6380 BC00007F
	ds_load_b128 v[208:211], v127 offset:25488                 // 0000001B9A2C: DBFC6390 D000007F
	s_waitcnt lgkmcnt(6)                                       // 0000001B9A34: BF89FC67
	v_fma_mixlo_f16 v180, v192, s22, 0                         // 0000001B9A38: CC2100B4 02002DC0
	v_fma_mixhi_f16 v180, v193, s22, 0                         // 0000001B9A40: CC2200B4 02002DC1
	v_fma_mixlo_f16 v181, v194, s22, 0                         // 0000001B9A48: CC2100B5 02002DC2
	v_fma_mixhi_f16 v181, v195, s22, 0                         // 0000001B9A50: CC2200B5 02002DC3
	s_waitcnt lgkmcnt(5)                                       // 0000001B9A58: BF89FC57
	v_fma_mixlo_f16 v182, v196, s22, 0                         // 0000001B9A5C: CC2100B6 02002DC4
	v_fma_mixhi_f16 v182, v197, s22, 0                         // 0000001B9A64: CC2200B6 02002DC5
	v_fma_mixlo_f16 v183, v198, s22, 0                         // 0000001B9A6C: CC2100B7 02002DC6
	ds_load_b128 v[192:195], v127 offset:25504                 // 0000001B9A74: DBFC63A0 C000007F
	v_fma_mixhi_f16 v183, v199, s22, 0                         // 0000001B9A7C: CC2200B7 02002DC7
	ds_load_b128 v[196:199], v127 offset:25520                 // 0000001B9A84: DBFC63B0 C400007F
	v_fma_mixlo_f16 v92, v212, s22, 0                          // 0000001B9A8C: CC21005C 02002DD4
	v_fma_mixhi_f16 v92, v213, s22, 0                          // 0000001B9A94: CC22005C 02002DD5
	v_fma_mixlo_f16 v93, v214, s22, 0                          // 0000001B9A9C: CC21005D 02002DD6
	v_fma_mixhi_f16 v93, v215, s22, 0                          // 0000001B9AA4: CC22005D 02002DD7
	v_fma_mixlo_f16 v94, v216, s22, 0                          // 0000001B9AAC: CC21005E 02002DD8
	v_fma_mixhi_f16 v94, v217, s22, 0                          // 0000001B9AB4: CC22005E 02002DD9
	v_fma_mixlo_f16 v95, v97, s22, 0                           // 0000001B9ABC: CC21005F 02002D61
	v_fma_mixlo_f16 v97, v101, s22, 0                          // 0000001B9AC4: CC210061 02002D65
	v_fma_mixhi_f16 v97, v102, s22, 0                          // 0000001B9ACC: CC220061 02002D66
	v_fma_mixlo_f16 v101, v184, s22, 0                         // 0000001B9AD4: CC210065 02002DB8
	v_fma_mixhi_f16 v101, v185, s22, 0                         // 0000001B9ADC: CC220065 02002DB9
	v_fma_mixlo_f16 v102, v186, s22, 0                         // 0000001B9AE4: CC210066 02002DBA
	v_fma_mixhi_f16 v102, v187, s22, 0                         // 0000001B9AEC: CC220066 02002DBB
	s_waitcnt lgkmcnt(6)                                       // 0000001B9AF4: BF89FC67
	v_fma_mixlo_f16 v184, v200, s22, 0                         // 0000001B9AF8: CC2100B8 02002DC8
	v_fma_mixhi_f16 v184, v201, s22, 0                         // 0000001B9B00: CC2200B8 02002DC9
	v_fma_mixlo_f16 v185, v202, s22, 0                         // 0000001B9B08: CC2100B9 02002DCA
	v_fma_mixhi_f16 v185, v203, s22, 0                         // 0000001B9B10: CC2200B9 02002DCB
	s_waitcnt lgkmcnt(4)                                       // 0000001B9B18: BF89FC47
	v_fma_mixlo_f16 v186, v204, s22, 0                         // 0000001B9B1C: CC2100BA 02002DCC
	v_fma_mixhi_f16 v186, v205, s22, 0                         // 0000001B9B24: CC2200BA 02002DCD
	v_fma_mixlo_f16 v187, v206, s22, 0                         // 0000001B9B2C: CC2100BB 02002DCE
	v_fma_mixhi_f16 v187, v207, s22, 0                         // 0000001B9B34: CC2200BB 02002DCF
	s_waitcnt lgkmcnt(3)                                       // 0000001B9B3C: BF89FC37
	v_fma_mixlo_f16 v188, v188, s22, 0                         // 0000001B9B40: CC2100BC 02002DBC
	v_fma_mixhi_f16 v188, v189, s22, 0                         // 0000001B9B48: CC2200BC 02002DBD
	v_fma_mixlo_f16 v189, v190, s22, 0                         // 0000001B9B50: CC2100BD 02002DBE
	v_fma_mixhi_f16 v189, v191, s22, 0                         // 0000001B9B58: CC2200BD 02002DBF
	s_waitcnt lgkmcnt(2)                                       // 0000001B9B60: BF89FC27
	v_fma_mixlo_f16 v190, v208, s22, 0                         // 0000001B9B64: CC2100BE 02002DD0
	v_fma_mixhi_f16 v190, v209, s22, 0                         // 0000001B9B6C: CC2200BE 02002DD1
	v_fma_mixlo_f16 v191, v210, s22, 0                         // 0000001B9B74: CC2100BF 02002DD2
	v_fma_mixhi_f16 v191, v211, s22, 0                         // 0000001B9B7C: CC2200BF 02002DD3
	s_waitcnt lgkmcnt(1)                                       // 0000001B9B84: BF89FC17
	v_fma_mixlo_f16 v192, v192, s22, 0                         // 0000001B9B88: CC2100C0 02002DC0
	v_fma_mixhi_f16 v192, v193, s22, 0                         // 0000001B9B90: CC2200C0 02002DC1
	v_fma_mixlo_f16 v193, v194, s22, 0                         // 0000001B9B98: CC2100C1 02002DC2
	v_fma_mixhi_f16 v193, v195, s22, 0                         // 0000001B9BA0: CC2200C1 02002DC3
	s_waitcnt lgkmcnt(0)                                       // 0000001B9BA8: BF89FC07
	v_fma_mixlo_f16 v194, v196, s22, 0                         // 0000001B9BAC: CC2100C2 02002DC4
	v_fma_mixhi_f16 v194, v197, s22, 0                         // 0000001B9BB4: CC2200C2 02002DC5
	v_fma_mixlo_f16 v195, v198, s22, 0                         // 0000001B9BBC: CC2100C3 02002DC6
	v_fma_mixhi_f16 v195, v199, s22, 0                         // 0000001B9BC4: CC2200C3 02002DC7
	ds_load_b128 v[200:203], v127 offset:192                   // 0000001B9BCC: DBFC00C0 C800007F
	ds_load_b128 v[204:207], v127 offset:208                   // 0000001B9BD4: DBFC00D0 CC00007F
	ds_load_b128 v[208:211], v127 offset:224                   // 0000001B9BDC: DBFC00E0 D000007F
	s_waitcnt vmcnt(10)                                        // 0000001B9BE4: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 0000001B9BE8: CC404019 1C66B351
	ds_load_b128 v[89:92], v127 offset:240                     // 0000001B9BF0: DBFC00F0 5900007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[97:104], v[9:16]// 0000001B9BF8: CC404009 1C26C351
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[180:187], v[17:24]// 0000001B9C00: CC404011 1C476951
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[188:195], v[1:8]// 0000001B9C08: CC404001 1C077951
	ds_load_b128 v[93:96], v127 offset:8640                    // 0000001B9C10: DBFC21C0 5D00007F
	ds_load_b128 v[97:100], v127 offset:8656                   // 0000001B9C18: DBFC21D0 6100007F
	ds_load_b128 v[101:104], v127 offset:8672                  // 0000001B9C20: DBFC21E0 6500007F
	ds_load_b128 v[180:183], v127 offset:8688                  // 0000001B9C28: DBFC21F0 B400007F
	ds_load_b128 v[184:187], v127 offset:17088                 // 0000001B9C30: DBFC42C0 B800007F
	ds_load_b128 v[188:191], v127 offset:17104                 // 0000001B9C38: DBFC42D0 BC00007F
	ds_load_b128 v[192:195], v127 offset:17120                 // 0000001B9C40: DBFC42E0 C000007F
	ds_load_b128 v[196:199], v127 offset:17136                 // 0000001B9C48: DBFC42F0 C400007F
	s_lshl_b64 s[48:49], s[48:49], 13                          // 0000001B9C50: 84B08D30
	ds_load_b128 v[212:215], v127 offset:25616                 // 0000001B9C54: DBFC6410 D400007F
	.long 0xd7006a74                                           // 0000001B9C5C: D7006A74
	v_cndmask_b32_e32 v0, v137, v48, vcc_lo                    // 0000001B9C60: 02006189
	s_waitcnt lgkmcnt(12)                                      // 0000001B9C64: BF89FCC7
	v_fma_mixlo_f16 v81, v200, s22, 0                          // 0000001B9C68: CC210051 02002DC8
	v_fma_mixhi_f16 v81, v201, s22, 0                          // 0000001B9C70: CC220051 02002DC9
	v_fma_mixlo_f16 v82, v202, s22, 0                          // 0000001B9C78: CC210052 02002DCA
	v_fma_mixhi_f16 v82, v203, s22, 0                          // 0000001B9C80: CC220052 02002DCB
	s_waitcnt lgkmcnt(9)                                       // 0000001B9C88: BF89FC97
	v_fma_mixhi_f16 v87, v90, s22, 0                           // 0000001B9C8C: CC220057 02002D5A
	v_fma_mixlo_f16 v88, v91, s22, 0                           // 0000001B9C94: CC210058 02002D5B
	v_fma_mixhi_f16 v88, v92, s22, 0                           // 0000001B9C9C: CC220058 02002D5C
	ds_load_b128 v[200:203], v127 offset:25552                 // 0000001B9CA4: DBFC63D0 C800007F
	s_waitcnt lgkmcnt(9)                                       // 0000001B9CAC: BF89FC97
	v_fma_mixlo_f16 v90, v95, s22, 0                           // 0000001B9CB0: CC21005A 02002D5F
	v_fma_mixhi_f16 v90, v96, s22, 0                           // 0000001B9CB8: CC22005A 02002D60
	s_waitcnt lgkmcnt(8)                                       // 0000001B9CC0: BF89FC87
	v_fma_mixlo_f16 v91, v97, s22, 0                           // 0000001B9CC4: CC21005B 02002D61
	v_fma_mixhi_f16 v91, v98, s22, 0                           // 0000001B9CCC: CC22005B 02002D62
	v_fma_mixlo_f16 v92, v99, s22, 0                           // 0000001B9CD4: CC21005C 02002D63
	v_fma_mixhi_f16 v92, v100, s22, 0                          // 0000001B9CDC: CC22005C 02002D64
	s_waitcnt lgkmcnt(6)                                       // 0000001B9CE4: BF89FC67
	v_fma_mixlo_f16 v95, v180, s22, 0                          // 0000001B9CE8: CC21005F 02002DB4
	v_fma_mixhi_f16 v95, v181, s22, 0                          // 0000001B9CF0: CC22005F 02002DB5
	v_fma_mixlo_f16 v96, v182, s22, 0                          // 0000001B9CF8: CC210060 02002DB6
	v_fma_mixhi_f16 v96, v183, s22, 0                          // 0000001B9D00: CC220060 02002DB7
	ds_load_b128 v[180:183], v127 offset:25536                 // 0000001B9D08: DBFC63C0 B400007F
	s_waitcnt lgkmcnt(6)                                       // 0000001B9D10: BF89FC67
	v_fma_mixlo_f16 v97, v184, s22, 0                          // 0000001B9D14: CC210061 02002DB8
	v_fma_mixhi_f16 v97, v185, s22, 0                          // 0000001B9D1C: CC220061 02002DB9
	v_fma_mixlo_f16 v98, v186, s22, 0                          // 0000001B9D24: CC210062 02002DBA
	v_fma_mixhi_f16 v98, v187, s22, 0                          // 0000001B9D2C: CC220062 02002DBB
	s_waitcnt lgkmcnt(5)                                       // 0000001B9D34: BF89FC57
	v_fma_mixlo_f16 v99, v188, s22, 0                          // 0000001B9D38: CC210063 02002DBC
	v_fma_mixhi_f16 v99, v189, s22, 0                          // 0000001B9D40: CC220063 02002DBD
	v_fma_mixlo_f16 v100, v190, s22, 0                         // 0000001B9D48: CC210064 02002DBE
	v_fma_mixhi_f16 v100, v191, s22, 0                         // 0000001B9D50: CC220064 02002DBF
	ds_load_b128 v[184:187], v127 offset:25568                 // 0000001B9D58: DBFC63E0 B800007F
	ds_load_b128 v[188:191], v127 offset:25584                 // 0000001B9D60: DBFC63F0 BC00007F
	v_fma_mixlo_f16 v83, v204, s22, 0                          // 0000001B9D68: CC210053 02002DCC
	v_fma_mixhi_f16 v83, v205, s22, 0                          // 0000001B9D70: CC220053 02002DCD
	v_fma_mixlo_f16 v84, v206, s22, 0                          // 0000001B9D78: CC210054 02002DCE
	v_fma_mixhi_f16 v84, v207, s22, 0                          // 0000001B9D80: CC220054 02002DCF
	v_fma_mixlo_f16 v85, v208, s22, 0                          // 0000001B9D88: CC210055 02002DD0
	v_fma_mixhi_f16 v85, v209, s22, 0                          // 0000001B9D90: CC220055 02002DD1
	v_fma_mixlo_f16 v86, v210, s22, 0                          // 0000001B9D98: CC210056 02002DD2
	v_fma_mixhi_f16 v86, v211, s22, 0                          // 0000001B9DA0: CC220056 02002DD3
	v_fma_mixlo_f16 v87, v89, s22, 0                           // 0000001B9DA8: CC210057 02002D59
	v_fma_mixlo_f16 v89, v93, s22, 0                           // 0000001B9DB0: CC210059 02002D5D
	v_fma_mixhi_f16 v89, v94, s22, 0                           // 0000001B9DB8: CC220059 02002D5E
	v_fma_mixlo_f16 v93, v101, s22, 0                          // 0000001B9DC0: CC21005D 02002D65
	v_fma_mixhi_f16 v93, v102, s22, 0                          // 0000001B9DC8: CC22005D 02002D66
	v_fma_mixlo_f16 v94, v103, s22, 0                          // 0000001B9DD0: CC21005E 02002D67
	v_fma_mixhi_f16 v94, v104, s22, 0                          // 0000001B9DD8: CC22005E 02002D68
	s_waitcnt lgkmcnt(6)                                       // 0000001B9DE0: BF89FC67
	v_fma_mixlo_f16 v101, v192, s22, 0                         // 0000001B9DE4: CC210065 02002DC0
	v_fma_mixhi_f16 v101, v193, s22, 0                         // 0000001B9DEC: CC220065 02002DC1
	v_fma_mixlo_f16 v102, v194, s22, 0                         // 0000001B9DF4: CC210066 02002DC2
	v_fma_mixhi_f16 v102, v195, s22, 0                         // 0000001B9DFC: CC220066 02002DC3
	s_waitcnt lgkmcnt(5)                                       // 0000001B9E04: BF89FC57
	v_fma_mixlo_f16 v103, v196, s22, 0                         // 0000001B9E08: CC210067 02002DC4
	v_fma_mixhi_f16 v103, v197, s22, 0                         // 0000001B9E10: CC220067 02002DC5
	v_fma_mixlo_f16 v104, v198, s22, 0                         // 0000001B9E18: CC210068 02002DC6
	v_fma_mixhi_f16 v104, v199, s22, 0                         // 0000001B9E20: CC220068 02002DC7
	s_waitcnt vmcnt(8)                                         // 0000001B9E28: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[81:88], v[25:32]// 0000001B9E2C: CC404019 1C66A349
	ds_load_b128 v[81:84], v127 offset:8704                    // 0000001B9E34: DBFC2200 5100007F
	ds_load_b128 v[85:88], v127 offset:8720                    // 0000001B9E3C: DBFC2210 5500007F
	s_waitcnt lgkmcnt(4)                                       // 0000001B9E44: BF89FC47
	v_fma_mixlo_f16 v180, v180, s22, 0                         // 0000001B9E48: CC2100B4 02002DB4
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[97:104], v[17:24]// 0000001B9E50: CC404011 1C46C349
	ds_load_b128 v[102:105], v127 offset:8736                  // 0000001B9E58: DBFC2220 6600007F
	v_fma_mixhi_f16 v180, v181, s22, 0                         // 0000001B9E60: CC2200B4 02002DB5
	v_fma_mixlo_f16 v181, v182, s22, 0                         // 0000001B9E68: CC2100B5 02002DB6
	v_fma_mixhi_f16 v181, v183, s22, 0                         // 0000001B9E70: CC2200B5 02002DB7
	v_fma_mixlo_f16 v182, v200, s22, 0                         // 0000001B9E78: CC2100B6 02002DC8
	v_fma_mixhi_f16 v182, v201, s22, 0                         // 0000001B9E80: CC2200B6 02002DC9
	v_fma_mixlo_f16 v183, v202, s22, 0                         // 0000001B9E88: CC2100B7 02002DCA
	v_fma_mixhi_f16 v183, v203, s22, 0                         // 0000001B9E90: CC2200B7 02002DCB
	s_waitcnt lgkmcnt(4)                                       // 0000001B9E98: BF89FC47
	v_fma_mixlo_f16 v184, v184, s22, 0                         // 0000001B9E9C: CC2100B8 02002DB8
	v_fma_mixhi_f16 v184, v185, s22, 0                         // 0000001B9EA4: CC2200B8 02002DB9
	v_fma_mixlo_f16 v185, v186, s22, 0                         // 0000001B9EAC: CC2100B9 02002DBA
	v_fma_mixhi_f16 v185, v187, s22, 0                         // 0000001B9EB4: CC2200B9 02002DBB
	s_waitcnt lgkmcnt(3)                                       // 0000001B9EBC: BF89FC37
	v_fma_mixlo_f16 v186, v188, s22, 0                         // 0000001B9EC0: CC2100BA 02002DBC
	v_fma_mixhi_f16 v186, v189, s22, 0                         // 0000001B9EC8: CC2200BA 02002DBD
	v_fma_mixlo_f16 v187, v190, s22, 0                         // 0000001B9ED0: CC2100BB 02002DBE
	v_fma_mixhi_f16 v187, v191, s22, 0                         // 0000001B9ED8: CC2200BB 02002DBF
	v_add_co_ci_u32_e64 v117, null, s49, v138, vcc_lo          // 0000001B9EE0: D5207C75 01AB1431
	v_wmma_f32_16x16x16_f16 v[9:16], v[73:80], v[89:96], v[9:16]// 0000001B9EE8: CC404009 1C26B349
	s_waitcnt lgkmcnt(2)                                       // 0000001B9EF0: BF89FC27
	v_fma_mixlo_f16 v81, v81, s22, 0                           // 0000001B9EF4: CC210051 02002D51
	v_wmma_f32_16x16x16_f16 v[1:8], v[73:80], v[180:187], v[1:8]// 0000001B9EFC: CC404001 1C076949
	s_clause 0x1                                               // 0000001B9F04: BF850001
	global_load_b128 v[184:187], v[116:117], off offset:16     // 0000001B9F08: DC5E0010 B87C0074
	global_load_b128 v[180:183], v[116:117], off               // 0000001B9F10: DC5E0000 B47C0074
	v_fma_mixhi_f16 v81, v82, s22, 0                           // 0000001B9F18: CC220051 02002D52
	v_fma_mixlo_f16 v82, v83, s22, 0                           // 0000001B9F20: CC210052 02002D53
	ds_load_b128 v[188:191], v127 offset:8752                  // 0000001B9F28: DBFC2230 BC00007F
	s_waitcnt lgkmcnt(2)                                       // 0000001B9F30: BF89FC27
	v_fma_mixlo_f16 v83, v85, s22, 0                           // 0000001B9F34: CC210053 02002D55
	v_fma_mixhi_f16 v83, v86, s22, 0                           // 0000001B9F3C: CC220053 02002D56
	s_waitcnt lgkmcnt(1)                                       // 0000001B9F44: BF89FC17
	v_fma_mixlo_f16 v85, v102, s22, 0                          // 0000001B9F48: CC210055 02002D66
	v_fma_mixhi_f16 v85, v103, s22, 0                          // 0000001B9F50: CC220055 02002D67
	v_fma_mixlo_f16 v86, v104, s22, 0                          // 0000001B9F58: CC210056 02002D68
	s_clause 0x3                                               // 0000001B9F60: BF850003
	global_load_b128 v[101:104], v[116:117], off offset:80     // 0000001B9F64: DC5E0050 657C0074
	global_load_b128 v[97:100], v[116:117], off offset:64      // 0000001B9F6C: DC5E0040 617C0074
	global_load_b128 v[93:96], v[116:117], off offset:112      // 0000001B9F74: DC5E0070 5D7C0074
	global_load_b128 v[89:92], v[116:117], off offset:96       // 0000001B9F7C: DC5E0060 597C0074
	ds_load_b128 v[192:195], v127 offset:256                   // 0000001B9F84: DBFC0100 C000007F
	ds_load_b128 v[196:199], v127 offset:272                   // 0000001B9F8C: DBFC0110 C400007F
	ds_load_b128 v[200:203], v127 offset:288                   // 0000001B9F94: DBFC0120 C800007F
	ds_load_b128 v[204:207], v127 offset:304                   // 0000001B9F9C: DBFC0130 CC00007F
	ds_load_b128 v[208:211], v127 offset:25600                 // 0000001B9FA4: DBFC6400 D000007F
	ds_load_b128 v[216:219], v127 offset:25632                 // 0000001B9FAC: DBFC6420 D800007F
	v_fma_mixhi_f16 v82, v84, s22, 0                           // 0000001B9FB4: CC220052 02002D54
	v_fma_mixlo_f16 v84, v87, s22, 0                           // 0000001B9FBC: CC210054 02002D57
	v_fma_mixhi_f16 v84, v88, s22, 0                           // 0000001B9FC4: CC220054 02002D58
	v_fma_mixhi_f16 v86, v105, s22, 0                          // 0000001B9FCC: CC220056 02002D69
	s_waitcnt lgkmcnt(6)                                       // 0000001B9FD4: BF89FC67
	v_fma_mixlo_f16 v87, v188, s22, 0                          // 0000001B9FD8: CC210057 02002DBC
	v_fma_mixhi_f16 v87, v189, s22, 0                          // 0000001B9FE0: CC220057 02002DBD
	v_fma_mixlo_f16 v88, v190, s22, 0                          // 0000001B9FE8: CC210058 02002DBE
	v_fma_mixhi_f16 v88, v191, s22, 0                          // 0000001B9FF0: CC220058 02002DBF
	s_waitcnt lgkmcnt(5)                                       // 0000001B9FF8: BF89FC57
	v_fma_mixlo_f16 v73, v192, s22, 0                          // 0000001B9FFC: CC210049 02002DC0
	v_fma_mixhi_f16 v73, v193, s22, 0                          // 0000001BA004: CC220049 02002DC1
	v_fma_mixlo_f16 v74, v194, s22, 0                          // 0000001BA00C: CC21004A 02002DC2
	v_fma_mixhi_f16 v74, v195, s22, 0                          // 0000001BA014: CC22004A 02002DC3
	s_waitcnt lgkmcnt(4)                                       // 0000001BA01C: BF89FC47
	v_fma_mixlo_f16 v75, v196, s22, 0                          // 0000001BA020: CC21004B 02002DC4
	v_fma_mixhi_f16 v75, v197, s22, 0                          // 0000001BA028: CC22004B 02002DC5
	v_fma_mixlo_f16 v76, v198, s22, 0                          // 0000001BA030: CC21004C 02002DC6
	v_fma_mixhi_f16 v76, v199, s22, 0                          // 0000001BA038: CC22004C 02002DC7
	s_waitcnt lgkmcnt(3)                                       // 0000001BA040: BF89FC37
	v_fma_mixlo_f16 v77, v200, s22, 0                          // 0000001BA044: CC21004D 02002DC8
	v_fma_mixhi_f16 v77, v201, s22, 0                          // 0000001BA04C: CC22004D 02002DC9
	v_fma_mixlo_f16 v78, v202, s22, 0                          // 0000001BA054: CC21004E 02002DCA
	v_fma_mixhi_f16 v78, v203, s22, 0                          // 0000001BA05C: CC22004E 02002DCB
	s_waitcnt lgkmcnt(2)                                       // 0000001BA064: BF89FC27
	v_fma_mixlo_f16 v79, v204, s22, 0                          // 0000001BA068: CC21004F 02002DCC
	v_fma_mixhi_f16 v79, v205, s22, 0                          // 0000001BA070: CC22004F 02002DCD
	v_fma_mixlo_f16 v80, v206, s22, 0                          // 0000001BA078: CC210050 02002DCE
	v_fma_mixhi_f16 v80, v207, s22, 0                          // 0000001BA080: CC220050 02002DCF
	ds_load_b128 v[192:195], v127 offset:17152                 // 0000001BA088: DBFC4300 C000007F
	ds_load_b128 v[196:199], v127 offset:17168                 // 0000001BA090: DBFC4310 C400007F
	ds_load_b128 v[200:203], v127 offset:17184                 // 0000001BA098: DBFC4320 C800007F
	ds_load_b128 v[204:207], v127 offset:17200                 // 0000001BA0A0: DBFC4330 CC00007F
	s_waitcnt vmcnt(12)                                        // 0000001BA0A8: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[73:80], v[25:32]// 0000001BA0AC: CC404019 1C669339
	ds_load_b128 v[73:76], v127 offset:368                     // 0000001BA0B4: DBFC0170 4900007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[57:64], v[81:88], v[9:16]// 0000001BA0BC: CC404009 1C26A339
	ds_load_b128 v[77:80], v127 offset:8768                    // 0000001BA0C4: DBFC2240 4D00007F
	ds_load_b128 v[81:84], v127 offset:8784                    // 0000001BA0CC: DBFC2250 5100007F
	ds_load_b128 v[85:88], v127 offset:8800                    // 0000001BA0D4: DBFC2260 5500007F
	s_waitcnt lgkmcnt(7)                                       // 0000001BA0DC: BF89FC77
	v_fma_mixlo_f16 v188, v192, s22, 0                         // 0000001BA0E0: CC2100BC 02002DC0
	v_fma_mixhi_f16 v188, v193, s22, 0                         // 0000001BA0E8: CC2200BC 02002DC1
	v_fma_mixlo_f16 v189, v194, s22, 0                         // 0000001BA0F0: CC2100BD 02002DC2
	v_fma_mixhi_f16 v189, v195, s22, 0                         // 0000001BA0F8: CC2200BD 02002DC3
	s_waitcnt lgkmcnt(6)                                       // 0000001BA100: BF89FC67
	v_fma_mixlo_f16 v190, v196, s22, 0                         // 0000001BA104: CC2100BE 02002DC4
	v_fma_mixhi_f16 v190, v197, s22, 0                         // 0000001BA10C: CC2200BE 02002DC5
	v_fma_mixlo_f16 v191, v198, s22, 0                         // 0000001BA114: CC2100BF 02002DC6
	v_fma_mixhi_f16 v191, v199, s22, 0                         // 0000001BA11C: CC2200BF 02002DC7
	s_waitcnt lgkmcnt(5)                                       // 0000001BA124: BF89FC57
	v_fma_mixlo_f16 v192, v200, s22, 0                         // 0000001BA128: CC2100C0 02002DC8
	v_fma_mixhi_f16 v192, v201, s22, 0                         // 0000001BA130: CC2200C0 02002DC9
	v_fma_mixlo_f16 v193, v202, s22, 0                         // 0000001BA138: CC2100C1 02002DCA
	v_fma_mixhi_f16 v193, v203, s22, 0                         // 0000001BA140: CC2200C1 02002DCB
	s_waitcnt lgkmcnt(4)                                       // 0000001BA148: BF89FC47
	v_fma_mixlo_f16 v194, v204, s22, 0                         // 0000001BA14C: CC2100C2 02002DCC
	v_fma_mixhi_f16 v194, v205, s22, 0                         // 0000001BA154: CC2200C2 02002DCD
	v_fma_mixlo_f16 v195, v206, s22, 0                         // 0000001BA15C: CC2100C3 02002DCE
	v_fma_mixhi_f16 v195, v207, s22, 0                         // 0000001BA164: CC2200C3 02002DCF
	v_fma_mixlo_f16 v196, v208, s22, 0                         // 0000001BA16C: CC2100C4 02002DD0
	v_fma_mixhi_f16 v196, v209, s22, 0                         // 0000001BA174: CC2200C4 02002DD1
	v_fma_mixlo_f16 v197, v210, s22, 0                         // 0000001BA17C: CC2100C5 02002DD2
	v_fma_mixhi_f16 v197, v211, s22, 0                         // 0000001BA184: CC2200C5 02002DD3
	v_fma_mixlo_f16 v198, v212, s22, 0                         // 0000001BA18C: CC2100C6 02002DD4
	v_fma_mixhi_f16 v198, v213, s22, 0                         // 0000001BA194: CC2200C6 02002DD5
	v_fma_mixlo_f16 v199, v214, s22, 0                         // 0000001BA19C: CC2100C7 02002DD6
	v_fma_mixhi_f16 v199, v215, s22, 0                         // 0000001BA1A4: CC2200C7 02002DD7
	v_fma_mixlo_f16 v200, v216, s22, 0                         // 0000001BA1AC: CC2100C8 02002DD8
	v_fma_mixhi_f16 v200, v217, s22, 0                         // 0000001BA1B4: CC2200C8 02002DD9
	v_fma_mixlo_f16 v201, v218, s22, 0                         // 0000001BA1BC: CC2100C9 02002DDA
	v_fma_mixhi_f16 v201, v219, s22, 0                         // 0000001BA1C4: CC2200C9 02002DDB
	v_fma_mixlo_f16 v202, v220, s22, 0                         // 0000001BA1CC: CC2100CA 02002DDC
	v_fma_mixhi_f16 v202, v221, s22, 0                         // 0000001BA1D4: CC2200CA 02002DDD
	v_fma_mixlo_f16 v203, v222, s22, 0                         // 0000001BA1DC: CC2100CB 02002DDE
	v_fma_mixhi_f16 v203, v223, s22, 0                         // 0000001BA1E4: CC2200CB 02002DDF
	ds_load_b128 v[204:207], v127 offset:320                   // 0000001BA1EC: DBFC0140 CC00007F
	ds_load_b128 v[208:211], v127 offset:336                   // 0000001BA1F4: DBFC0150 D000007F
	ds_load_b128 v[212:215], v127 offset:352                   // 0000001BA1FC: DBFC0160 D400007F
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[188:195], v[17:24]// 0000001BA204: CC404011 1C477939
	v_wmma_f32_16x16x16_f16 v[1:8], v[57:64], v[196:203], v[1:8]// 0000001BA20C: CC404001 1C078939
	ds_load_b128 v[188:191], v127 offset:8816                  // 0000001BA214: DBFC2270 BC00007F
	ds_load_b128 v[192:195], v127 offset:17216                 // 0000001BA21C: DBFC4340 C000007F
	ds_load_b128 v[196:199], v127 offset:17232                 // 0000001BA224: DBFC4350 C400007F
	s_waitcnt lgkmcnt(9)                                       // 0000001BA22C: BF89FC97
	v_fma_mixhi_f16 v63, v74, s22, 0                           // 0000001BA230: CC22003F 02002D4A
	v_fma_mixlo_f16 v64, v75, s22, 0                           // 0000001BA238: CC210040 02002D4B
	v_fma_mixhi_f16 v64, v76, s22, 0                           // 0000001BA240: CC220040 02002D4C
	s_waitcnt lgkmcnt(8)                                       // 0000001BA248: BF89FC87
	v_fma_mixlo_f16 v74, v79, s22, 0                           // 0000001BA24C: CC21004A 02002D4F
	v_fma_mixhi_f16 v74, v80, s22, 0                           // 0000001BA254: CC22004A 02002D50
	s_waitcnt lgkmcnt(7)                                       // 0000001BA25C: BF89FC77
	v_fma_mixlo_f16 v75, v81, s22, 0                           // 0000001BA260: CC21004B 02002D51
	v_fma_mixhi_f16 v75, v82, s22, 0                           // 0000001BA268: CC22004B 02002D52
	v_fma_mixlo_f16 v76, v83, s22, 0                           // 0000001BA270: CC21004C 02002D53
	v_fma_mixhi_f16 v76, v84, s22, 0                           // 0000001BA278: CC22004C 02002D54
	ds_load_b128 v[200:203], v127 offset:17248                 // 0000001BA280: DBFC4360 C800007F
	v_fma_mixlo_f16 v63, v73, s22, 0                           // 0000001BA288: CC21003F 02002D49
	v_fma_mixlo_f16 v73, v77, s22, 0                           // 0000001BA290: CC210049 02002D4D
	s_waitcnt lgkmcnt(6)                                       // 0000001BA298: BF89FC67
	v_fma_mixlo_f16 v57, v204, s22, 0                          // 0000001BA29C: CC210039 02002DCC
	v_fma_mixhi_f16 v57, v205, s22, 0                          // 0000001BA2A4: CC220039 02002DCD
	v_fma_mixlo_f16 v58, v206, s22, 0                          // 0000001BA2AC: CC21003A 02002DCE
	v_fma_mixhi_f16 v58, v207, s22, 0                          // 0000001BA2B4: CC22003A 02002DCF
	s_waitcnt lgkmcnt(5)                                       // 0000001BA2BC: BF89FC57
	v_fma_mixlo_f16 v59, v208, s22, 0                          // 0000001BA2C0: CC21003B 02002DD0
	v_fma_mixhi_f16 v59, v209, s22, 0                          // 0000001BA2C8: CC22003B 02002DD1
	v_fma_mixlo_f16 v60, v210, s22, 0                          // 0000001BA2D0: CC21003C 02002DD2
	v_fma_mixhi_f16 v60, v211, s22, 0                          // 0000001BA2D8: CC22003C 02002DD3
	s_waitcnt lgkmcnt(3)                                       // 0000001BA2E0: BF89FC37
	v_fma_mixlo_f16 v79, v188, s22, 0                          // 0000001BA2E4: CC21004F 02002DBC
	ds_load_b128 v[204:207], v127 offset:17264                 // 0000001BA2EC: DBFC4370 CC00007F
	v_fma_mixhi_f16 v79, v189, s22, 0                          // 0000001BA2F4: CC22004F 02002DBD
	v_fma_mixlo_f16 v80, v190, s22, 0                          // 0000001BA2FC: CC210050 02002DBE
	v_fma_mixhi_f16 v80, v191, s22, 0                          // 0000001BA304: CC220050 02002DBF
	ds_load_b128 v[188:191], v127 offset:25664                 // 0000001BA30C: DBFC6440 BC00007F
	ds_load_b128 v[208:211], v127 offset:25680                 // 0000001BA314: DBFC6450 D000007F
	s_waitcnt lgkmcnt(5)                                       // 0000001BA31C: BF89FC57
	v_fma_mixlo_f16 v81, v192, s22, 0                          // 0000001BA320: CC210051 02002DC0
	v_fma_mixhi_f16 v81, v193, s22, 0                          // 0000001BA328: CC220051 02002DC1
	v_fma_mixlo_f16 v82, v194, s22, 0                          // 0000001BA330: CC210052 02002DC2
	v_fma_mixhi_f16 v82, v195, s22, 0                          // 0000001BA338: CC220052 02002DC3
	s_waitcnt lgkmcnt(4)                                       // 0000001BA340: BF89FC47
	v_fma_mixlo_f16 v83, v196, s22, 0                          // 0000001BA344: CC210053 02002DC4
	v_fma_mixhi_f16 v83, v197, s22, 0                          // 0000001BA34C: CC220053 02002DC5
	v_fma_mixlo_f16 v84, v198, s22, 0                          // 0000001BA354: CC210054 02002DC6
	ds_load_b128 v[192:195], v127 offset:25696                 // 0000001BA35C: DBFC6460 C000007F
	v_fma_mixhi_f16 v84, v199, s22, 0                          // 0000001BA364: CC220054 02002DC7
	ds_load_b128 v[196:199], v127 offset:25712                 // 0000001BA36C: DBFC6470 C400007F
	v_fma_mixlo_f16 v61, v212, s22, 0                          // 0000001BA374: CC21003D 02002DD4
	v_fma_mixhi_f16 v61, v213, s22, 0                          // 0000001BA37C: CC22003D 02002DD5
	v_fma_mixlo_f16 v62, v214, s22, 0                          // 0000001BA384: CC21003E 02002DD6
	v_fma_mixhi_f16 v62, v215, s22, 0                          // 0000001BA38C: CC22003E 02002DD7
	v_fma_mixhi_f16 v73, v78, s22, 0                           // 0000001BA394: CC220049 02002D4E
	v_fma_mixlo_f16 v77, v85, s22, 0                           // 0000001BA39C: CC21004D 02002D55
	v_fma_mixhi_f16 v77, v86, s22, 0                           // 0000001BA3A4: CC22004D 02002D56
	v_fma_mixlo_f16 v78, v87, s22, 0                           // 0000001BA3AC: CC21004E 02002D57
	v_fma_mixhi_f16 v78, v88, s22, 0                           // 0000001BA3B4: CC22004E 02002D58
	s_waitcnt lgkmcnt(5)                                       // 0000001BA3BC: BF89FC57
	v_fma_mixlo_f16 v85, v200, s22, 0                          // 0000001BA3C0: CC210055 02002DC8
	v_fma_mixhi_f16 v85, v201, s22, 0                          // 0000001BA3C8: CC220055 02002DC9
	v_fma_mixlo_f16 v86, v202, s22, 0                          // 0000001BA3D0: CC210056 02002DCA
	v_fma_mixhi_f16 v86, v203, s22, 0                          // 0000001BA3D8: CC220056 02002DCB
	s_waitcnt lgkmcnt(4)                                       // 0000001BA3E0: BF89FC47
	v_fma_mixlo_f16 v87, v204, s22, 0                          // 0000001BA3E4: CC210057 02002DCC
	v_fma_mixhi_f16 v87, v205, s22, 0                          // 0000001BA3EC: CC220057 02002DCD
	v_fma_mixlo_f16 v88, v206, s22, 0                          // 0000001BA3F4: CC210058 02002DCE
	v_fma_mixhi_f16 v88, v207, s22, 0                          // 0000001BA3FC: CC220058 02002DCF
	s_waitcnt lgkmcnt(3)                                       // 0000001BA404: BF89FC37
	v_fma_mixlo_f16 v188, v188, s22, 0                         // 0000001BA408: CC2100BC 02002DBC
	v_fma_mixhi_f16 v188, v189, s22, 0                         // 0000001BA410: CC2200BC 02002DBD
	v_fma_mixlo_f16 v189, v190, s22, 0                         // 0000001BA418: CC2100BD 02002DBE
	v_fma_mixhi_f16 v189, v191, s22, 0                         // 0000001BA420: CC2200BD 02002DBF
	s_waitcnt lgkmcnt(2)                                       // 0000001BA428: BF89FC27
	v_fma_mixlo_f16 v190, v208, s22, 0                         // 0000001BA42C: CC2100BE 02002DD0
	v_fma_mixhi_f16 v190, v209, s22, 0                         // 0000001BA434: CC2200BE 02002DD1
	v_fma_mixlo_f16 v191, v210, s22, 0                         // 0000001BA43C: CC2100BF 02002DD2
	v_fma_mixhi_f16 v191, v211, s22, 0                         // 0000001BA444: CC2200BF 02002DD3
	s_waitcnt lgkmcnt(1)                                       // 0000001BA44C: BF89FC17
	v_fma_mixlo_f16 v192, v192, s22, 0                         // 0000001BA450: CC2100C0 02002DC0
	v_fma_mixhi_f16 v192, v193, s22, 0                         // 0000001BA458: CC2200C0 02002DC1
	v_fma_mixlo_f16 v193, v194, s22, 0                         // 0000001BA460: CC2100C1 02002DC2
	v_fma_mixhi_f16 v193, v195, s22, 0                         // 0000001BA468: CC2200C1 02002DC3
	s_waitcnt lgkmcnt(0)                                       // 0000001BA470: BF89FC07
	v_fma_mixlo_f16 v194, v196, s22, 0                         // 0000001BA474: CC2100C2 02002DC4
	v_fma_mixhi_f16 v194, v197, s22, 0                         // 0000001BA47C: CC2200C2 02002DC5
	v_fma_mixlo_f16 v195, v198, s22, 0                         // 0000001BA484: CC2100C3 02002DC6
	v_fma_mixhi_f16 v195, v199, s22, 0                         // 0000001BA48C: CC2200C3 02002DC7
	ds_load_b128 v[200:203], v127 offset:384                   // 0000001BA494: DBFC0180 C800007F
	ds_load_b128 v[204:207], v127 offset:400                   // 0000001BA49C: DBFC0190 CC00007F
	ds_load_b128 v[208:211], v127 offset:416                   // 0000001BA4A4: DBFC01A0 D000007F
	s_waitcnt vmcnt(10)                                        // 0000001BA4AC: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[57:64], v[25:32]// 0000001BA4B0: CC404019 1C667331
	ds_load_b128 v[57:60], v127 offset:432                     // 0000001BA4B8: DBFC01B0 3900007F
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[73:80], v[9:16]// 0000001BA4C0: CC404009 1C269331
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[81:88], v[17:24]// 0000001BA4C8: CC404011 1C46A331
	v_wmma_f32_16x16x16_f16 v[1:8], v[49:56], v[188:195], v[1:8]// 0000001BA4D0: CC404001 1C077931
	ds_load_b128 v[61:64], v127 offset:8832                    // 0000001BA4D8: DBFC2280 3D00007F
	ds_load_b128 v[73:76], v127 offset:8848                    // 0000001BA4E0: DBFC2290 4900007F
	ds_load_b128 v[77:80], v127 offset:8864                    // 0000001BA4E8: DBFC22A0 4D00007F
	ds_load_b128 v[81:84], v127 offset:8880                    // 0000001BA4F0: DBFC22B0 5100007F
	ds_load_b128 v[85:88], v127 offset:17280                   // 0000001BA4F8: DBFC4380 5500007F
	ds_load_b128 v[188:191], v127 offset:17296                 // 0000001BA500: DBFC4390 BC00007F
	ds_load_b128 v[192:195], v127 offset:17312                 // 0000001BA508: DBFC43A0 C000007F
	ds_load_b128 v[196:199], v127 offset:17328                 // 0000001BA510: DBFC43B0 C400007F
	ds_load_b128 v[215:218], v127 offset:25840                 // 0000001BA518: DBFC64F0 D700007F
	s_waitcnt lgkmcnt(12)                                      // 0000001BA520: BF89FCC7
	v_fma_mixlo_f16 v49, v200, s22, 0                          // 0000001BA524: CC210031 02002DC8
	v_fma_mixhi_f16 v49, v201, s22, 0                          // 0000001BA52C: CC220031 02002DC9
	v_fma_mixlo_f16 v50, v202, s22, 0                          // 0000001BA534: CC210032 02002DCA
	v_fma_mixhi_f16 v50, v203, s22, 0                          // 0000001BA53C: CC220032 02002DCB
	s_waitcnt lgkmcnt(9)                                       // 0000001BA544: BF89FC97
	v_fma_mixhi_f16 v55, v58, s22, 0                           // 0000001BA548: CC220037 02002D3A
	v_fma_mixlo_f16 v56, v59, s22, 0                           // 0000001BA550: CC210038 02002D3B
	v_fma_mixhi_f16 v56, v60, s22, 0                           // 0000001BA558: CC220038 02002D3C
	ds_load_b128 v[200:203], v127 offset:25744                 // 0000001BA560: DBFC6490 C800007F
	s_waitcnt lgkmcnt(9)                                       // 0000001BA568: BF89FC97
	v_fma_mixlo_f16 v58, v63, s22, 0                           // 0000001BA56C: CC21003A 02002D3F
	v_fma_mixhi_f16 v58, v64, s22, 0                           // 0000001BA574: CC22003A 02002D40
	s_waitcnt lgkmcnt(8)                                       // 0000001BA57C: BF89FC87
	v_fma_mixlo_f16 v59, v73, s22, 0                           // 0000001BA580: CC21003B 02002D49
	v_fma_mixhi_f16 v59, v74, s22, 0                           // 0000001BA588: CC22003B 02002D4A
	v_fma_mixlo_f16 v60, v75, s22, 0                           // 0000001BA590: CC21003C 02002D4B
	v_fma_mixhi_f16 v60, v76, s22, 0                           // 0000001BA598: CC22003C 02002D4C
	s_waitcnt lgkmcnt(6)                                       // 0000001BA5A0: BF89FC67
	v_fma_mixlo_f16 v63, v81, s22, 0                           // 0000001BA5A4: CC21003F 02002D51
	v_fma_mixhi_f16 v63, v82, s22, 0                           // 0000001BA5AC: CC22003F 02002D52
	v_fma_mixlo_f16 v64, v83, s22, 0                           // 0000001BA5B4: CC210040 02002D53
	v_fma_mixhi_f16 v64, v84, s22, 0                           // 0000001BA5BC: CC220040 02002D54
	ds_load_b128 v[81:84], v127 offset:25728                   // 0000001BA5C4: DBFC6480 5100007F
	s_waitcnt lgkmcnt(6)                                       // 0000001BA5CC: BF89FC67
	v_fma_mixlo_f16 v73, v85, s22, 0                           // 0000001BA5D0: CC210049 02002D55
	v_fma_mixhi_f16 v73, v86, s22, 0                           // 0000001BA5D8: CC220049 02002D56
	v_fma_mixlo_f16 v74, v87, s22, 0                           // 0000001BA5E0: CC21004A 02002D57
	v_fma_mixhi_f16 v74, v88, s22, 0                           // 0000001BA5E8: CC22004A 02002D58
	s_waitcnt lgkmcnt(5)                                       // 0000001BA5F0: BF89FC57
	v_fma_mixlo_f16 v75, v188, s22, 0                          // 0000001BA5F4: CC21004B 02002DBC
	v_fma_mixhi_f16 v75, v189, s22, 0                          // 0000001BA5FC: CC22004B 02002DBD
	v_fma_mixlo_f16 v76, v190, s22, 0                          // 0000001BA604: CC21004C 02002DBE
	ds_load_b128 v[85:88], v127 offset:25760                   // 0000001BA60C: DBFC64A0 5500007F
	v_fma_mixhi_f16 v76, v191, s22, 0                          // 0000001BA614: CC22004C 02002DBF
	ds_load_b128 v[188:191], v127 offset:25776                 // 0000001BA61C: DBFC64B0 BC00007F
	v_fma_mixlo_f16 v55, v57, s22, 0                           // 0000001BA624: CC210037 02002D39
	v_fma_mixlo_f16 v57, v61, s22, 0                           // 0000001BA62C: CC210039 02002D3D
	v_fma_mixlo_f16 v61, v77, s22, 0                           // 0000001BA634: CC21003D 02002D4D
	v_fma_mixhi_f16 v61, v78, s22, 0                           // 0000001BA63C: CC22003D 02002D4E
	s_waitcnt lgkmcnt(6)                                       // 0000001BA644: BF89FC67
	v_fma_mixlo_f16 v77, v192, s22, 0                          // 0000001BA648: CC21004D 02002DC0
	v_fma_mixhi_f16 v77, v193, s22, 0                          // 0000001BA650: CC22004D 02002DC1
	v_fma_mixlo_f16 v78, v194, s22, 0                          // 0000001BA658: CC21004E 02002DC2
	v_fma_mixhi_f16 v78, v195, s22, 0                          // 0000001BA660: CC22004E 02002DC3
	ds_load_b128 v[192:195], v127 offset:448                   // 0000001BA668: DBFC01C0 C000007F
	s_waitcnt lgkmcnt(3)                                       // 0000001BA670: BF89FC37
	v_fma_mixlo_f16 v81, v81, s22, 0                           // 0000001BA674: CC210051 02002D51
	v_fma_mixhi_f16 v81, v82, s22, 0                           // 0000001BA67C: CC220051 02002D52
	v_fma_mixlo_f16 v82, v83, s22, 0                           // 0000001BA684: CC210052 02002D53
	v_fma_mixhi_f16 v82, v84, s22, 0                           // 0000001BA68C: CC220052 02002D54
	v_fma_mixlo_f16 v83, v200, s22, 0                          // 0000001BA694: CC210053 02002DC8
	v_fma_mixhi_f16 v83, v201, s22, 0                          // 0000001BA69C: CC220053 02002DC9
	v_fma_mixlo_f16 v84, v202, s22, 0                          // 0000001BA6A4: CC210054 02002DCA
	v_fma_mixhi_f16 v84, v203, s22, 0                          // 0000001BA6AC: CC220054 02002DCB
	s_waitcnt lgkmcnt(2)                                       // 0000001BA6B4: BF89FC27
	v_fma_mixlo_f16 v85, v85, s22, 0                           // 0000001BA6B8: CC210055 02002D55
	v_fma_mixhi_f16 v85, v86, s22, 0                           // 0000001BA6C0: CC220055 02002D56
	v_fma_mixlo_f16 v86, v87, s22, 0                           // 0000001BA6C8: CC210056 02002D57
	v_fma_mixhi_f16 v86, v88, s22, 0                           // 0000001BA6D0: CC220056 02002D58
	s_waitcnt lgkmcnt(1)                                       // 0000001BA6D8: BF89FC17
	v_fma_mixlo_f16 v87, v188, s22, 0                          // 0000001BA6DC: CC210057 02002DBC
	ds_load_b128 v[200:203], v127 offset:480                   // 0000001BA6E4: DBFC01E0 C800007F
	v_fma_mixhi_f16 v87, v189, s22, 0                          // 0000001BA6EC: CC220057 02002DBD
	v_fma_mixlo_f16 v88, v190, s22, 0                          // 0000001BA6F4: CC210058 02002DBE
	v_fma_mixhi_f16 v88, v191, s22, 0                          // 0000001BA6FC: CC220058 02002DBF
	ds_load_b128 v[188:191], v127 offset:496                   // 0000001BA704: DBFC01F0 BC00007F
	v_fma_mixlo_f16 v51, v204, s22, 0                          // 0000001BA70C: CC210033 02002DCC
	v_fma_mixhi_f16 v51, v205, s22, 0                          // 0000001BA714: CC220033 02002DCD
	v_fma_mixlo_f16 v52, v206, s22, 0                          // 0000001BA71C: CC210034 02002DCE
	v_fma_mixhi_f16 v52, v207, s22, 0                          // 0000001BA724: CC220034 02002DCF
	v_fma_mixlo_f16 v53, v208, s22, 0                          // 0000001BA72C: CC210035 02002DD0
	v_fma_mixhi_f16 v53, v209, s22, 0                          // 0000001BA734: CC220035 02002DD1
	v_fma_mixlo_f16 v54, v210, s22, 0                          // 0000001BA73C: CC210036 02002DD2
	v_fma_mixhi_f16 v54, v211, s22, 0                          // 0000001BA744: CC220036 02002DD3
	v_fma_mixhi_f16 v57, v62, s22, 0                           // 0000001BA74C: CC220039 02002D3E
	v_fma_mixlo_f16 v62, v79, s22, 0                           // 0000001BA754: CC21003E 02002D4F
	v_fma_mixhi_f16 v62, v80, s22, 0                           // 0000001BA75C: CC22003E 02002D50
	v_fma_mixlo_f16 v79, v196, s22, 0                          // 0000001BA764: CC21004F 02002DC4
	v_fma_mixhi_f16 v79, v197, s22, 0                          // 0000001BA76C: CC22004F 02002DC5
	v_fma_mixlo_f16 v80, v198, s22, 0                          // 0000001BA774: CC210050 02002DC6
	v_fma_mixhi_f16 v80, v199, s22, 0                          // 0000001BA77C: CC220050 02002DC7
	ds_load_b128 v[196:199], v127 offset:464                   // 0000001BA784: DBFC01D0 C400007F
	s_waitcnt vmcnt(8)                                         // 0000001BA78C: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[49:56], v[25:32]// 0000001BA790: CC404019 1C666329
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[57:64], v[9:16]// 0000001BA798: CC404009 1C267329
	v_wmma_f32_16x16x16_f16 v[1:8], v[41:48], v[81:88], v[1:8] // 0000001BA7A0: CC404001 1C06A329
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[73:80], v[17:24]// 0000001BA7A8: CC404011 1C469329
	ds_load_b128 v[49:52], v127 offset:8896                    // 0000001BA7B0: DBFC22C0 3100007F
	ds_load_b128 v[53:56], v127 offset:8912                    // 0000001BA7B8: DBFC22D0 3500007F
	s_waitcnt lgkmcnt(5)                                       // 0000001BA7C0: BF89FC57
	v_fma_mixlo_f16 v41, v192, s22, 0                          // 0000001BA7C4: CC210029 02002DC0
	v_fma_mixhi_f16 v41, v193, s22, 0                          // 0000001BA7CC: CC220029 02002DC1
	v_fma_mixlo_f16 v42, v194, s22, 0                          // 0000001BA7D4: CC21002A 02002DC2
	v_fma_mixhi_f16 v42, v195, s22, 0                          // 0000001BA7DC: CC22002A 02002DC3
	ds_load_b128 v[57:60], v127 offset:8928                    // 0000001BA7E4: DBFC22E0 3900007F
	ds_load_b128 v[61:64], v127 offset:8944                    // 0000001BA7EC: DBFC22F0 3D00007F
	s_waitcnt lgkmcnt(5)                                       // 0000001BA7F4: BF89FC57
	v_fma_mixlo_f16 v47, v188, s22, 0                          // 0000001BA7F8: CC21002F 02002DBC
	v_fma_mixhi_f16 v47, v189, s22, 0                          // 0000001BA800: CC22002F 02002DBD
	v_fma_mixlo_f16 v48, v190, s22, 0                          // 0000001BA808: CC210030 02002DBE
	v_fma_mixhi_f16 v48, v191, s22, 0                          // 0000001BA810: CC220030 02002DBF
	ds_load_b128 v[73:76], v127 offset:17344                   // 0000001BA818: DBFC43C0 4900007F
	ds_load_b128 v[77:80], v127 offset:17360                   // 0000001BA820: DBFC43D0 4D00007F
	ds_load_b128 v[81:84], v127 offset:17376                   // 0000001BA828: DBFC43E0 5100007F
	ds_load_b128 v[85:88], v127 offset:17392                   // 0000001BA830: DBFC43F0 5500007F
	ds_load_b128 v[188:191], v127 offset:25792                 // 0000001BA838: DBFC64C0 BC00007F
	ds_load_b128 v[192:195], v127 offset:25808                 // 0000001BA840: DBFC64D0 C000007F
	ds_load_b128 v[211:214], v127 offset:25824                 // 0000001BA848: DBFC64E0 D300007F
	s_waitcnt lgkmcnt(11)                                      // 0000001BA850: BF89FCB7
	v_fma_mixlo_f16 v43, v196, s22, 0                          // 0000001BA854: CC21002B 02002DC4
	v_fma_mixhi_f16 v43, v197, s22, 0                          // 0000001BA85C: CC22002B 02002DC5
	v_fma_mixlo_f16 v44, v198, s22, 0                          // 0000001BA864: CC21002C 02002DC6
	v_fma_mixhi_f16 v44, v199, s22, 0                          // 0000001BA86C: CC22002C 02002DC7
	v_fma_mixlo_f16 v45, v200, s22, 0                          // 0000001BA874: CC21002D 02002DC8
	v_fma_mixhi_f16 v45, v201, s22, 0                          // 0000001BA87C: CC22002D 02002DC9
	v_fma_mixlo_f16 v46, v202, s22, 0                          // 0000001BA884: CC21002E 02002DCA
	v_fma_mixhi_f16 v46, v203, s22, 0                          // 0000001BA88C: CC22002E 02002DCB
	s_waitcnt lgkmcnt(10)                                      // 0000001BA894: BF89FCA7
	v_fma_mixlo_f16 v49, v49, s22, 0                           // 0000001BA898: CC210031 02002D31
	v_fma_mixhi_f16 v49, v50, s22, 0                           // 0000001BA8A0: CC220031 02002D32
	v_fma_mixlo_f16 v50, v51, s22, 0                           // 0000001BA8A8: CC210032 02002D33
	v_fma_mixhi_f16 v50, v52, s22, 0                           // 0000001BA8B0: CC220032 02002D34
	s_waitcnt lgkmcnt(9)                                       // 0000001BA8B8: BF89FC97
	v_fma_mixlo_f16 v51, v53, s22, 0                           // 0000001BA8BC: CC210033 02002D35
	v_fma_mixhi_f16 v51, v54, s22, 0                           // 0000001BA8C4: CC220033 02002D36
	v_fma_mixlo_f16 v52, v55, s22, 0                           // 0000001BA8CC: CC210034 02002D37
	v_fma_mixhi_f16 v52, v56, s22, 0                           // 0000001BA8D4: CC220034 02002D38
	s_waitcnt lgkmcnt(8)                                       // 0000001BA8DC: BF89FC87
	v_fma_mixlo_f16 v53, v57, s22, 0                           // 0000001BA8E0: CC210035 02002D39
	v_fma_mixhi_f16 v53, v58, s22, 0                           // 0000001BA8E8: CC220035 02002D3A
	v_fma_mixlo_f16 v54, v59, s22, 0                           // 0000001BA8F0: CC210036 02002D3B
	s_waitcnt lgkmcnt(7)                                       // 0000001BA8F8: BF89FC77
	v_fma_mixlo_f16 v55, v61, s22, 0                           // 0000001BA8FC: CC210037 02002D3D
	v_fma_mixhi_f16 v55, v62, s22, 0                           // 0000001BA904: CC220037 02002D3E
	v_fma_mixlo_f16 v56, v63, s22, 0                           // 0000001BA90C: CC210038 02002D3F
	v_fma_mixhi_f16 v56, v64, s22, 0                           // 0000001BA914: CC220038 02002D40
	s_waitcnt lgkmcnt(6)                                       // 0000001BA91C: BF89FC67
	v_fma_mixlo_f16 v57, v73, s22, 0                           // 0000001BA920: CC210039 02002D49
	v_fma_mixhi_f16 v57, v74, s22, 0                           // 0000001BA928: CC220039 02002D4A
	v_fma_mixlo_f16 v58, v75, s22, 0                           // 0000001BA930: CC21003A 02002D4B
	v_fma_mixhi_f16 v58, v76, s22, 0                           // 0000001BA938: CC22003A 02002D4C
	s_waitcnt lgkmcnt(5)                                       // 0000001BA940: BF89FC57
	v_fma_mixlo_f16 v59, v77, s22, 0                           // 0000001BA944: CC21003B 02002D4D
	s_waitcnt lgkmcnt(4)                                       // 0000001BA94C: BF89FC47
	v_fma_mixlo_f16 v61, v81, s22, 0                           // 0000001BA950: CC21003D 02002D51
	v_fma_mixhi_f16 v61, v82, s22, 0                           // 0000001BA958: CC22003D 02002D52
	v_fma_mixlo_f16 v62, v83, s22, 0                           // 0000001BA960: CC21003E 02002D53
	v_fma_mixhi_f16 v62, v84, s22, 0                           // 0000001BA968: CC22003E 02002D54
	s_waitcnt lgkmcnt(3)                                       // 0000001BA970: BF89FC37
	v_fma_mixlo_f16 v63, v85, s22, 0                           // 0000001BA974: CC21003F 02002D55
	v_fma_mixhi_f16 v63, v86, s22, 0                           // 0000001BA97C: CC22003F 02002D56
	v_fma_mixlo_f16 v64, v87, s22, 0                           // 0000001BA984: CC210040 02002D57
	v_fma_mixhi_f16 v64, v88, s22, 0                           // 0000001BA98C: CC220040 02002D58
	s_waitcnt lgkmcnt(2)                                       // 0000001BA994: BF89FC27
	v_fma_mixlo_f16 v73, v188, s22, 0                          // 0000001BA998: CC210049 02002DBC
	v_fma_mixhi_f16 v73, v189, s22, 0                          // 0000001BA9A0: CC220049 02002DBD
	v_fma_mixlo_f16 v74, v190, s22, 0                          // 0000001BA9A8: CC21004A 02002DBE
	v_fma_mixhi_f16 v74, v191, s22, 0                          // 0000001BA9B0: CC22004A 02002DBF
	s_waitcnt lgkmcnt(1)                                       // 0000001BA9B8: BF89FC17
	v_fma_mixlo_f16 v75, v192, s22, 0                          // 0000001BA9BC: CC21004B 02002DC0
	v_fma_mixhi_f16 v75, v193, s22, 0                          // 0000001BA9C4: CC22004B 02002DC1
	v_fma_mixlo_f16 v76, v194, s22, 0                          // 0000001BA9CC: CC21004C 02002DC2
	v_fma_mixhi_f16 v76, v195, s22, 0                          // 0000001BA9D4: CC22004C 02002DC3
	s_waitcnt lgkmcnt(0)                                       // 0000001BA9DC: BF89FC07
	v_fma_mixlo_f16 v77, v211, s22, 0                          // 0000001BA9E0: CC21004D 02002DD3
	ds_load_b128 v[81:84], v128                                // 0000001BA9E8: DBFC0000 51000080
	ds_load_b128 v[85:88], v128 offset:16                      // 0000001BA9F0: DBFC0010 55000080
	ds_load_b128 v[192:195], v128 offset:2320                  // 0000001BA9F8: DBFC0910 C0000080
	ds_load_b128 v[188:191], v128 offset:2304                  // 0000001BAA00: DBFC0900 BC000080
	ds_load_b128 v[200:203], v128 offset:4624                  // 0000001BAA08: DBFC1210 C8000080
	ds_load_b128 v[196:199], v128 offset:4608                  // 0000001BAA10: DBFC1200 C4000080
	ds_load_b128 v[208:211], v128 offset:6928                  // 0000001BAA18: DBFC1B10 D0000080
	ds_load_b128 v[204:207], v128 offset:6912                  // 0000001BAA20: DBFC1B00 CC000080
	v_fma_mixhi_f16 v54, v60, s22, 0                           // 0000001BAA28: CC220036 02002D3C
	v_fma_mixhi_f16 v59, v78, s22, 0                           // 0000001BAA30: CC22003B 02002D4E
	v_fma_mixlo_f16 v60, v79, s22, 0                           // 0000001BAA38: CC21003C 02002D4F
	v_fma_mixhi_f16 v60, v80, s22, 0                           // 0000001BAA40: CC22003C 02002D50
	v_fma_mixhi_f16 v77, v212, s22, 0                          // 0000001BAA48: CC22004D 02002DD4
	v_fma_mixlo_f16 v78, v213, s22, 0                          // 0000001BAA50: CC21004E 02002DD5
	v_fma_mixhi_f16 v78, v214, s22, 0                          // 0000001BAA58: CC22004E 02002DD6
	v_fma_mixlo_f16 v79, v215, s22, 0                          // 0000001BAA60: CC21004F 02002DD7
	v_fma_mixhi_f16 v79, v216, s22, 0                          // 0000001BAA68: CC22004F 02002DD8
	v_fma_mixlo_f16 v80, v217, s22, 0                          // 0000001BAA70: CC210050 02002DD9
	v_fma_mixhi_f16 v80, v218, s22, 0                          // 0000001BAA78: CC220050 02002DDA
	s_waitcnt vmcnt(6)                                         // 0000001BAA80: BF891BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[41:48], v[25:32]// 0000001BAA84: CC404019 1C665321
	v_wmma_f32_16x16x16_f16 v[9:16], v[33:40], v[49:56], v[9:16]// 0000001BAA8C: CC404009 1C266321
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 0000001BAA94: CC404011 1C467321
	s_waitcnt vmcnt(4) lgkmcnt(6)                              // 0000001BAA9C: BF891067
	v_wmma_f32_16x16x16_f16 v[57:64], v[180:187], v[81:88], v[65:72]// 0000001BAAA0: CC404039 1D06A3B4
	v_wmma_f32_16x16x16_f16 v[1:8], v[33:40], v[73:80], v[1:8] // 0000001BAAA8: CC404001 1C069321
	s_waitcnt lgkmcnt(4)                                       // 0000001BAAB0: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[180:187], v[188:195], v[65:72]// 0000001BAAB4: CC404031 1D0779B4
	s_waitcnt lgkmcnt(2)                                       // 0000001BAABC: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[180:187], v[196:203], v[65:72]// 0000001BAAC0: CC404029 1D0789B4
	s_waitcnt lgkmcnt(0)                                       // 0000001BAAC8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[180:187], v[204:211], v[65:72]// 0000001BAACC: CC404021 1D0799B4
	s_and_saveexec_b32 s14, s6                                 // 0000001BAAD4: BE8E2006
	s_cbranch_execnz 1209                                      // 0000001BAAD8: BFA604B9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x72c0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BAADC: 8C7E0E7E
	s_and_saveexec_b32 s14, s5                                 // 0000001BAAE0: BE8E2005
	s_cbranch_execnz 1242                                      // 0000001BAAE4: BFA604DA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7350>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BAAE8: 8C7E0E7E
	s_and_saveexec_b32 s14, s7                                 // 0000001BAAEC: BE8E2007
	s_cbranch_execz 30                                         // 0000001BAAF0: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x606c>
	ds_load_b128 v[65:68], v128 offset:96                      // 0000001BAAF4: DBFC0060 41000080
	ds_load_b128 v[69:72], v128 offset:112                     // 0000001BAAFC: DBFC0070 45000080
	ds_load_b128 v[77:80], v128 offset:2416                    // 0000001BAB04: DBFC0970 4D000080
	ds_load_b128 v[73:76], v128 offset:2400                    // 0000001BAB0C: DBFC0960 49000080
	ds_load_b128 v[85:88], v128 offset:4720                    // 0000001BAB14: DBFC1270 55000080
	ds_load_b128 v[81:84], v128 offset:4704                    // 0000001BAB1C: DBFC1260 51000080
	s_waitcnt vmcnt(3)                                         // 0000001BAB24: BF890FF7
	ds_load_b128 v[101:104], v128 offset:7024                  // 0000001BAB28: DBFC1B70 65000080
	s_waitcnt vmcnt(2)                                         // 0000001BAB30: BF890BF7
	ds_load_b128 v[97:100], v128 offset:7008                   // 0000001BAB34: DBFC1B60 61000080
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001BAB3C: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[89:96], v[65:72], v[57:64]// 0000001BAB40: CC404039 1CE68359
	s_waitcnt lgkmcnt(4)                                       // 0000001BAB48: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[89:96], v[73:80], v[49:56]// 0000001BAB4C: CC404031 1CC69359
	s_waitcnt lgkmcnt(2)                                       // 0000001BAB54: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[81:88], v[41:48]// 0000001BAB58: CC404029 1CA6A359
	s_waitcnt lgkmcnt(0)                                       // 0000001BAB60: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[89:96], v[97:104], v[33:40]// 0000001BAB64: CC404021 1C86C359
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BAB6C: 8C7E0E7E
	s_add_i32 s29, s29, 64                                     // 0000001BAB70: 811DC01D
	s_mov_b32 s14, -1                                          // 0000001BAB74: BE8E00C1
	s_cmp_le_i32 s29, s58                                      // 0000001BAB78: BF053A1D
	s_cbranch_scc0 392                                         // 0000001BAB7C: BFA10188 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66a0>
	ds_load_2addr_b32 v[65:66], v139 offset1:2                 // 0000001BAB80: D8DC0200 4100008B
	ds_load_2addr_b32 v[67:68], v139 offset0:4 offset1:6       // 0000001BAB88: D8DC0604 4300008B
	ds_load_2addr_b32 v[69:70], v139 offset0:8 offset1:10      // 0000001BAB90: D8DC0A08 4500008B
	ds_load_2addr_b32 v[71:72], v139 offset0:12 offset1:14     // 0000001BAB98: D8DC0E0C 4700008B
	v_mad_u64_u32 v[73:74], null, 0x3000, v172, v[108:109]     // 0000001BABA0: D6FE7C49 05B358FF 00003000
	v_mad_u64_u32 v[75:76], null, 0x3000, v179, v[108:109]     // 0000001BABAC: D6FE7C4B 05B366FF 00003000
	v_mad_u64_u32 v[77:78], null, 0x3000, v178, v[108:109]     // 0000001BABB8: D6FE7C4D 05B364FF 00003000
	v_mad_u64_u32 v[79:80], null, 0x3000, v177, v[108:109]     // 0000001BABC4: D6FE7C4F 05B362FF 00003000
	s_mov_b32 s14, 0                                           // 0000001BABD0: BE8E0080
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000001BABD4: BF890437
	v_fma_f32 v96, v9, v65, v49                                // 0000001BABD8: D6130060 04C68309
	v_fma_f32 v97, v10, v66, v50                               // 0000001BABE0: D6130061 04CA850A
	s_waitcnt lgkmcnt(2)                                       // 0000001BABE8: BF89FC27
	v_fma_f32 v98, v11, v67, v51                               // 0000001BABEC: D6130062 04CE870B
	v_fma_f32 v100, v12, v68, v52                              // 0000001BABF4: D6130064 04D2890C
	s_waitcnt lgkmcnt(1)                                       // 0000001BABFC: BF89FC17
	v_fma_f32 v104, v13, v69, v53                              // 0000001BAC00: D6130068 04D68B0D
	v_dual_mul_f32 v96, 0x3b800000, v96 :: v_dual_mul_f32 v97, 0x3b800000, v97// 0000001BAC08: C8C6C0FF 6060C2FF 3B800000
	v_mul_f32_e32 v98, 0x3b800000, v98                         // 0000001BAC14: 10C4C4FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 0000001BAC1C: BF89FC07
	v_fma_f32 v105, v16, v72, v56                              // 0000001BAC20: D6130069 04E29110
	v_mul_f32_e32 v100, 0x3b800000, v100                       // 0000001BAC28: 10C8C8FF 3B800000
	v_bfe_u32 v101, v96, 16, 1                                 // 0000001BAC30: D6100065 02052160
	v_bfe_u32 v102, v97, 16, 1                                 // 0000001BAC38: D6100066 02052161
	v_bfe_u32 v103, v98, 16, 1                                 // 0000001BAC40: D6100067 02052162
	v_mul_f32_e32 v105, 0x3b800000, v105                       // 0000001BAC48: 10D2D2FF 3B800000
	v_fma_f32 v181, v18, v66, v42                              // 0000001BAC50: D61300B5 04AA8512
	v_add3_u32 v96, v96, v101, 0x7fff                          // 0000001BAC58: D6550060 03FECB60 00007FFF
	v_add3_u32 v97, v97, v102, 0x7fff                          // 0000001BAC64: D6550061 03FECD61 00007FFF
	v_add3_u32 v98, v98, v103, 0x7fff                          // 0000001BAC70: D6550062 03FECF62 00007FFF
	v_bfe_u32 v101, v100, 16, 1                                // 0000001BAC7C: D6100065 02052164
	v_mul_f32_e32 v102, 0x3b800000, v104                       // 0000001BAC84: 10CCD0FF 3B800000
	v_fma_f32 v103, v14, v70, v54                              // 0000001BAC8C: D6130067 04DA8D0E
	v_fma_f32 v104, v15, v71, v55                              // 0000001BAC94: D6130068 04DE8F0F
	v_fma_f32 v116, v17, v65, v41                              // 0000001BAC9C: D6130074 04A68311
	v_add3_u32 v100, v100, v101, 0x7fff                        // 0000001BACA4: D6550064 03FECB64 00007FFF
	v_bfe_u32 v101, v102, 16, 1                                // 0000001BACB0: D6100065 02052166
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001BACB8: BF870234
	v_dual_mul_f32 v103, 0x3b800000, v103 :: v_dual_mul_f32 v104, 0x3b800000, v104// 0000001BACBC: C8C6CEFF 6768D0FF 3B800000
	v_bfe_u32 v180, v105, 16, 1                                // 0000001BACC8: D61000B4 02052169
	v_fma_f32 v183, v22, v70, v46                              // 0000001BACD0: D61300B7 04BA8D16
	v_add3_u32 v101, v102, v101, 0x7fff                        // 0000001BACD8: D6550065 03FECB66 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BACE4: BF870224
	v_bfe_u32 v102, v103, 16, 1                                // 0000001BACE8: D6100066 02052167
	v_bfe_u32 v117, v104, 16, 1                                // 0000001BACF0: D6100075 02052168
	v_dual_mul_f32 v116, 0x3b800000, v116 :: v_dual_mul_f32 v183, 0x3b800000, v183// 0000001BACF8: C8C6E8FF 74B76EFF 3B800000
	v_fma_f32 v182, v21, v69, v45                              // 0000001BAD04: D61300B6 04B68B15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BAD0C: BF870214
	v_add3_u32 v102, v103, v102, 0x7fff                        // 0000001BAD10: D6550066 03FECD67 00007FFF
	v_add3_u32 v103, v104, v117, 0x7fff                        // 0000001BAD1C: D6550067 03FEEB68 00007FFF
	v_add3_u32 v104, v105, v180, 0x7fff                        // 0000001BAD28: D6550068 03FF6969 00007FFF
	v_bfe_u32 v105, v116, 16, 1                                // 0000001BAD34: D6100069 02052174
	v_mul_f32_e32 v117, 0x3b800000, v181                       // 0000001BAD3C: 10EB6AFF 3B800000
	v_fma_f32 v180, v19, v67, v43                              // 0000001BAD44: D61300B4 04AE8713
	v_fma_f32 v181, v20, v68, v44                              // 0000001BAD4C: D61300B5 04B28914
	v_fma_f32 v81, v25, v65, v57                               // 0000001BAD54: D6130051 04E68319
	v_add3_u32 v105, v116, v105, 0x7fff                        // 0000001BAD5C: D6550069 03FED374 00007FFF
	v_bfe_u32 v116, v117, 16, 1                                // 0000001BAD68: D6100074 02052175
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001BAD70: BF870234
	v_dual_mul_f32 v180, 0x3b800000, v180 :: v_dual_mul_f32 v181, 0x3b800000, v181// 0000001BAD74: C8C768FF B4B56AFF 3B800000
	v_fma_f32 v65, v1, v65, v33                                // 0000001BAD80: D6130041 04868301
	v_mul_f32_e32 v182, 0x3b800000, v182                       // 0000001BAD88: 116D6CFF 3B800000
	v_add3_u32 v116, v117, v116, 0x7fff                        // 0000001BAD90: D6550074 03FEE975 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BAD9C: BF870004
	v_bfe_u32 v117, v180, 16, 1                                // 0000001BADA0: D6100075 020521B4
	v_bfe_u32 v184, v181, 16, 1                                // 0000001BADA8: D61000B8 020521B5
	v_fma_f32 v186, v23, v71, v47                              // 0000001BADB0: D61300BA 04BE8F17
	v_mul_f32_e32 v65, 0x3b800000, v65                         // 0000001BADB8: 108282FF 3B800000
	v_bfe_u32 v185, v182, 16, 1                                // 0000001BADC0: D61000B9 020521B6
	v_fma_f32 v83, v27, v67, v59                               // 0000001BADC8: D6130053 04EE871B
	v_add3_u32 v117, v180, v117, 0x7fff                        // 0000001BADD0: D6550075 03FEEBB4 00007FFF
	v_add3_u32 v180, v181, v184, 0x7fff                        // 0000001BADDC: D65500B4 03FF71B5 00007FFF
	v_fma_f32 v67, v3, v67, v35                                // 0000001BADE8: D6130043 048E8703
	v_add3_u32 v181, v182, v185, 0x7fff                        // 0000001BADF0: D65500B5 03FF73B6 00007FFF
	v_bfe_u32 v182, v183, 16, 1                                // 0000001BADFC: D61000B6 020521B7
	v_mul_f32_e32 v184, 0x3b800000, v186                       // 0000001BAE04: 117174FF 3B800000
	v_fma_f32 v185, v24, v72, v48                              // 0000001BAE0C: D61300B9 04C29118
	v_fma_f32 v82, v26, v66, v58                               // 0000001BAE14: D6130052 04EA851A
	v_fma_f32 v66, v2, v66, v34                                // 0000001BAE1C: D6130042 048A8502
	v_mul_f32_e32 v81, 0x3b800000, v81                         // 0000001BAE24: 10A2A2FF 3B800000
	v_add3_u32 v182, v183, v182, 0x7fff                        // 0000001BAE2C: D65500B6 03FF6DB7 00007FFF
	v_mul_f32_e32 v185, 0x3b800000, v185                       // 0000001BAE38: 117372FF 3B800000
	v_mul_f32_e32 v67, 0x3b800000, v67                         // 0000001BAE40: 108686FF 3B800000
	v_bfe_u32 v183, v184, 16, 1                                // 0000001BAE48: D61000B7 020521B8
	v_mul_f32_e32 v82, 0x3b800000, v82                         // 0000001BAE50: 10A4A4FF 3B800000
	v_fma_f32 v85, v29, v69, v61                               // 0000001BAE58: D6130055 04F68B1D
	v_fma_f32 v69, v5, v69, v37                                // 0000001BAE60: D6130045 04968B05
	v_mul_f32_e32 v66, 0x3b800000, v66                         // 0000001BAE68: 108484FF 3B800000
	v_fma_f32 v84, v28, v68, v60                               // 0000001BAE70: D6130054 04F2891C
	v_fma_f32 v87, v31, v71, v63                               // 0000001BAE78: D6130057 04FE8F1F
	s_waitcnt vmcnt(0)                                         // 0000001BAE80: BF8903F7
	v_bfe_u32 v89, v81, 16, 1                                  // 0000001BAE84: D6100059 02052151
	v_add3_u32 v183, v184, v183, 0x7fff                        // 0000001BAE8C: D65500B7 03FF6FB8 00007FFF
	v_bfe_u32 v184, v185, 16, 1                                // 0000001BAE98: D61000B8 020521B9
	v_fma_f32 v68, v4, v68, v36                                // 0000001BAEA0: D6130044 04928904
	v_fma_f32 v86, v30, v70, v62                               // 0000001BAEA8: D6130056 04FA8D1E
	v_bfe_u32 v90, v82, 16, 1                                  // 0000001BAEB0: D610005A 02052152
	v_bfe_u32 v186, v65, 16, 1                                 // 0000001BAEB8: D61000BA 02052141
	v_bfe_u32 v187, v66, 16, 1                                 // 0000001BAEC0: D61000BB 02052142
	v_fma_f32 v88, v32, v72, v64                               // 0000001BAEC8: D6130058 05029120
	v_dual_mul_f32 v83, 0x3b800000, v83 :: v_dual_mul_f32 v84, 0x3b800000, v84// 0000001BAED0: C8C6A6FF 5354A8FF 3B800000
	v_mul_f32_e32 v87, 0x3b800000, v87                         // 0000001BAEDC: 10AEAEFF 3B800000
	v_add3_u32 v89, v81, v89, 0x7fff                           // 0000001BAEE4: D6550059 03FEB351 00007FFF
	v_add3_u32 v184, v185, v184, 0x7fff                        // 0000001BAEF0: D65500B8 03FF71B9 00007FFF
	v_bfe_u32 v185, v67, 16, 1                                 // 0000001BAEFC: D61000B9 02052143
	v_fma_f32 v70, v6, v70, v38                                // 0000001BAF04: D6130046 049A8D06
	v_dual_mul_f32 v68, 0x3b800000, v68 :: v_dual_mul_f32 v85, 0x3b800000, v85// 0000001BAF0C: C8C688FF 4454AAFF 3B800000
	v_mul_f32_e32 v86, 0x3b800000, v86                         // 0000001BAF18: 10ACACFF 3B800000
	v_add3_u32 v90, v82, v90, 0x7fff                           // 0000001BAF20: D655005A 03FEB552 00007FFF
	v_add3_u32 v65, v65, v186, 0x7fff                          // 0000001BAF2C: D6550041 03FF7541 00007FFF
	v_add3_u32 v66, v66, v187, 0x7fff                          // 0000001BAF38: D6550042 03FF7742 00007FFF
	v_mul_f32_e32 v88, 0x3b800000, v88                         // 0000001BAF44: 10B0B0FF 3B800000
	v_bfe_u32 v91, v83, 16, 1                                  // 0000001BAF4C: D610005B 02052153
	v_bfe_u32 v95, v87, 16, 1                                  // 0000001BAF54: D610005F 02052157
	s_clause 0x7                                               // 0000001BAF5C: BF850007
	global_store_d16_hi_b16 v[73:74], v89, off                 // 0000001BAF60: DC960000 007C5949
	global_store_d16_hi_b16 v[73:74], v96, off offset:32       // 0000001BAF68: DC960020 007C6049
	global_store_d16_hi_b16 v[73:74], v105, off offset:64      // 0000001BAF70: DC960040 007C6949
	global_store_d16_hi_b16 v[75:76], v90, off                 // 0000001BAF78: DC960000 007C5A4B
	global_store_d16_hi_b16 v[75:76], v97, off offset:32       // 0000001BAF80: DC960020 007C614B
	global_store_d16_hi_b16 v[75:76], v116, off offset:64      // 0000001BAF88: DC960040 007C744B
	global_store_d16_hi_b16 v[73:74], v65, off offset:96       // 0000001BAF90: DC960060 007C4149
	global_store_d16_hi_b16 v[75:76], v66, off offset:96       // 0000001BAF98: DC960060 007C424B
	v_add3_u32 v65, v67, v185, 0x7fff                          // 0000001BAFA0: D6550041 03FF7343 00007FFF
	v_mul_f32_e32 v67, 0x3b800000, v69                         // 0000001BAFAC: 10868AFF 3B800000
	v_mul_f32_e32 v69, 0x3b800000, v70                         // 0000001BAFB4: 108A8CFF 3B800000
	v_bfe_u32 v66, v68, 16, 1                                  // 0000001BAFBC: D6100042 02052144
	v_fma_f32 v70, v7, v71, v39                                // 0000001BAFC4: D6130046 049E8F07
	v_fma_f32 v71, v8, v72, v40                                // 0000001BAFCC: D6130047 04A29108
	v_bfe_u32 v93, v85, 16, 1                                  // 0000001BAFD4: D610005D 02052155
	v_bfe_u32 v94, v86, 16, 1                                  // 0000001BAFDC: D610005E 02052156
	v_bfe_u32 v92, v84, 16, 1                                  // 0000001BAFE4: D610005C 02052154
	v_add3_u32 v91, v83, v91, 0x7fff                           // 0000001BAFEC: D655005B 03FEB753 00007FFF
	v_add3_u32 v95, v87, v95, 0x7fff                           // 0000001BAFF8: D655005F 03FEBF57 00007FFF
	v_bfe_u32 v87, v88, 16, 1                                  // 0000001BB004: D6100057 02052158
	v_add3_u32 v66, v68, v66, 0x7fff                           // 0000001BB00C: D6550042 03FE8544 00007FFF
	v_bfe_u32 v68, v67, 16, 1                                  // 0000001BB018: D6100044 02052143
	v_dual_mul_f32 v70, 0x3b800000, v70 :: v_dual_mul_f32 v71, 0x3b800000, v71// 0000001BB020: C8C68CFF 46468EFF 3B800000
	v_add3_u32 v93, v85, v93, 0x7fff                           // 0000001BB02C: D655005D 03FEBB55 00007FFF
	v_mad_u64_u32 v[81:82], null, 0x3000, v176, v[108:109]     // 0000001BB038: D6FE7C51 05B360FF 00003000
	v_add3_u32 v94, v86, v94, 0x7fff                           // 0000001BB044: D655005E 03FEBD56 00007FFF
	v_mad_u64_u32 v[85:86], null, 0x3000, v174, v[108:109]     // 0000001BB050: D6FE7C55 05B35CFF 00003000
	v_add3_u32 v92, v84, v92, 0x7fff                           // 0000001BB05C: D655005C 03FEB954 00007FFF
	v_bfe_u32 v72, v69, 16, 1                                  // 0000001BB068: D6100048 02052145
	v_mad_u64_u32 v[83:84], null, 0x3000, v175, v[108:109]     // 0000001BB070: D6FE7C53 05B35EFF 00003000
	v_add3_u32 v99, v88, v87, 0x7fff                           // 0000001BB07C: D6550063 03FEAF58 00007FFF
	v_mad_u64_u32 v[87:88], null, 0x3000, v173, v[108:109]     // 0000001BB088: D6FE7C57 05B35AFF 00003000
	s_clause 0x7                                               // 0000001BB094: BF850007
	global_store_d16_hi_b16 v[77:78], v91, off                 // 0000001BB098: DC960000 007C5B4D
	global_store_d16_hi_b16 v[77:78], v98, off offset:32       // 0000001BB0A0: DC960020 007C624D
	global_store_d16_hi_b16 v[77:78], v117, off offset:64      // 0000001BB0A8: DC960040 007C754D
	global_store_d16_hi_b16 v[79:80], v92, off                 // 0000001BB0B0: DC960000 007C5C4F
	global_store_d16_hi_b16 v[79:80], v100, off offset:32      // 0000001BB0B8: DC960020 007C644F
	global_store_d16_hi_b16 v[79:80], v180, off offset:64      // 0000001BB0C0: DC960040 007CB44F
	global_store_d16_hi_b16 v[77:78], v65, off offset:96       // 0000001BB0C8: DC960060 007C414D
	global_store_d16_hi_b16 v[79:80], v66, off offset:96       // 0000001BB0D0: DC960060 007C424F
	v_add3_u32 v65, v67, v68, 0x7fff                           // 0000001BB0D8: D6550041 03FE8943 00007FFF
	v_bfe_u32 v67, v70, 16, 1                                  // 0000001BB0E4: D6100043 02052146
	v_bfe_u32 v68, v71, 16, 1                                  // 0000001BB0EC: D6100044 02052147
	v_add3_u32 v66, v69, v72, 0x7fff                           // 0000001BB0F4: D6550042 03FE9145 00007FFF
	s_clause 0x7                                               // 0000001BB100: BF850007
	global_store_d16_hi_b16 v[81:82], v93, off                 // 0000001BB104: DC960000 007C5D51
	global_store_d16_hi_b16 v[81:82], v101, off offset:32      // 0000001BB10C: DC960020 007C6551
	global_store_d16_hi_b16 v[81:82], v181, off offset:64      // 0000001BB114: DC960040 007CB551
	global_store_d16_hi_b16 v[83:84], v94, off                 // 0000001BB11C: DC960000 007C5E53
	global_store_d16_hi_b16 v[83:84], v102, off offset:32      // 0000001BB124: DC960020 007C6653
	global_store_d16_hi_b16 v[83:84], v182, off offset:64      // 0000001BB12C: DC960040 007CB653
	global_store_d16_hi_b16 v[81:82], v65, off offset:96       // 0000001BB134: DC960060 007C4151
	global_store_d16_hi_b16 v[83:84], v66, off offset:96       // 0000001BB13C: DC960060 007C4253
	v_add3_u32 v65, v70, v67, 0x7fff                           // 0000001BB144: D6550041 03FE8746 00007FFF
	v_add3_u32 v66, v71, v68, 0x7fff                           // 0000001BB150: D6550042 03FE8947 00007FFF
	s_clause 0x7                                               // 0000001BB15C: BF850007
	global_store_d16_hi_b16 v[85:86], v95, off                 // 0000001BB160: DC960000 007C5F55
	global_store_d16_hi_b16 v[85:86], v103, off offset:32      // 0000001BB168: DC960020 007C6755
	global_store_d16_hi_b16 v[85:86], v183, off offset:64      // 0000001BB170: DC960040 007CB755
	global_store_d16_hi_b16 v[87:88], v99, off                 // 0000001BB178: DC960000 007C6357
	global_store_d16_hi_b16 v[87:88], v104, off offset:32      // 0000001BB180: DC960020 007C6857
	global_store_d16_hi_b16 v[87:88], v184, off offset:64      // 0000001BB188: DC960040 007CB857
	global_store_d16_hi_b16 v[85:86], v65, off offset:96       // 0000001BB190: DC960060 007C4155
	global_store_d16_hi_b16 v[87:88], v66, off offset:96       // 0000001BB198: DC960060 007C4257
	s_and_not1_b32 vcc_lo, exec_lo, s14                        // 0000001BB1A0: 916A0E7E
	s_cbranch_vccnz 114                                        // 0000001BB1A4: BFA40072 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6870>
	s_and_saveexec_b32 s14, s10                                // 0000001BB1A8: BE8E200A
	s_cbranch_execnz 937                                       // 0000001BB1AC: BFA603A9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7554>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB1B0: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001BB1B4: BE8E200D
	s_cbranch_execnz 956                                       // 0000001BB1B8: BFA603BC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x75ac>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB1BC: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001BB1C0: BE8E200C
	s_cbranch_execnz 975                                       // 0000001BB1C4: BFA603CF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7604>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB1C8: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001BB1CC: BE8E200B
	s_cbranch_execnz 994                                       // 0000001BB1D0: BFA603E2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x765c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB1D4: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001BB1D8: BE8E2009
	s_cbranch_execnz 1013                                      // 0000001BB1DC: BFA603F5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x76b4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB1E0: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001BB1E4: BE8E2001
	s_cbranch_execnz 1032                                      // 0000001BB1E8: BFA60408 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x770c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB1EC: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001BB1F0: BE8E2008
	s_cbranch_execnz 1051                                      // 0000001BB1F4: BFA6041B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7764>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB1F8: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001BB1FC: BE8E2000
	s_cbranch_execnz 1070                                      // 0000001BB200: BFA6042E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x77bc>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB204: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001BB208: BE8E200A
	s_cbranch_execnz 1089                                      // 0000001BB20C: BFA60441 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7814>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB210: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001BB214: BE8E200D
	s_cbranch_execnz 1108                                      // 0000001BB218: BFA60454 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x786c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB21C: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001BB220: BE8E200C
	s_cbranch_execnz 1127                                      // 0000001BB224: BFA60467 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x78c4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB228: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001BB22C: BE8E200B
	s_cbranch_execnz 1146                                      // 0000001BB230: BFA6047A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x791c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB234: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001BB238: BE8E2009
	s_cbranch_execnz 1165                                      // 0000001BB23C: BFA6048D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7974>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB240: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001BB244: BE8E2001
	s_cbranch_execnz 1184                                      // 0000001BB248: BFA604A0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x79cc>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB24C: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001BB250: BE8E2008
	s_cbranch_execnz 1203                                      // 0000001BB254: BFA604B3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7a24>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB258: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001BB25C: BE8E2000
	s_cbranch_execnz 1222                                      // 0000001BB260: BFA604C6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7a7c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB264: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001BB268: BE8E200A
	s_cbranch_execnz 1241                                      // 0000001BB26C: BFA604D9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7ad4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB270: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001BB274: BE8E200D
	s_cbranch_execnz 1260                                      // 0000001BB278: BFA604EC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7b2c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB27C: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001BB280: BE8E200C
	s_cbranch_execnz 1279                                      // 0000001BB284: BFA604FF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7b84>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB288: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001BB28C: BE8E200B
	s_cbranch_execnz 1298                                      // 0000001BB290: BFA60512 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7bdc>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB294: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001BB298: BE8E2009
	s_cbranch_execnz 1317                                      // 0000001BB29C: BFA60525 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7c34>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB2A0: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001BB2A4: BE8E2001
	s_cbranch_execnz 1336                                      // 0000001BB2A8: BFA60538 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7c8c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB2AC: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001BB2B0: BE8E2008
	s_cbranch_execnz 1355                                      // 0000001BB2B4: BFA6054B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7ce4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB2B8: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001BB2BC: BE8E2000
	s_cbranch_execnz 1374                                      // 0000001BB2C0: BFA6055E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7d3c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB2C4: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001BB2C8: BE8E200A
	s_cbranch_execnz 1393                                      // 0000001BB2CC: BFA60571 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7d94>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BB2D0: 8C7E0E7E
	s_and_saveexec_b32 s10, s13                                // 0000001BB2D4: BE8A200D
	s_cbranch_execnz 1412                                      // 0000001BB2D8: BFA60584 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7dec>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001BB2DC: 8C7E0A7E
	s_and_saveexec_b32 s10, s12                                // 0000001BB2E0: BE8A200C
	s_cbranch_execnz 1431                                      // 0000001BB2E4: BFA60597 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7e44>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001BB2E8: 8C7E0A7E
	s_and_saveexec_b32 s10, s11                                // 0000001BB2EC: BE8A200B
	s_cbranch_execnz 1450                                      // 0000001BB2F0: BFA605AA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7e9c>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001BB2F4: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 0000001BB2F8: BE8A2009
	s_cbranch_execnz 1469                                      // 0000001BB2FC: BFA605BD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7ef4>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001BB300: 8C7E0A7E
	s_and_saveexec_b32 s9, s1                                  // 0000001BB304: BE892001
	s_cbranch_execnz 1488                                      // 0000001BB308: BFA605D0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7f4c>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000001BB30C: 8C7E097E
	s_and_saveexec_b32 s1, s8                                  // 0000001BB310: BE812008
	s_cbranch_execnz 1507                                      // 0000001BB314: BFA605E3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7fa4>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001BB318: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000001BB31C: BE812000
	s_cbranch_execz 18                                         // 0000001BB320: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x686c>
	ds_load_b32 v1, v139 offset:56                             // 0000001BB324: D8D80038 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BB32C: BF89FC07
	v_fmac_f32_e32 v40, v8, v1                                 // 0000001BB330: 56500308
	v_mad_u64_u32 v[1:2], null, 0x3000, v173, v[108:109]       // 0000001BB334: D6FE7C01 05B35AFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BB340: BF870092
	v_mul_f32_e32 v3, 0x3b800000, v40                          // 0000001BB344: 100650FF 3B800000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001BB34C: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BB354: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001BB358: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001BB364: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001BB36C: 8C7E017E
	s_waitcnt vmcnt(0)                                         // 0000001BB370: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 0000001BB374: BC7C0000
	s_barrier                                                  // 0000001BB378: BFBD0000
	buffer_gl0_inv                                             // 0000001BB37C: E0AC0000 00000000
	ds_load_b128 v[1:4], v131                                  // 0000001BB384: DBFC0000 01000083
	ds_load_b128 v[5:8], v131 offset:16                        // 0000001BB38C: DBFC0010 05000083
	ds_load_b128 v[25:28], v132                                // 0000001BB394: DBFC0000 19000084
	ds_load_b128 v[29:32], v132 offset:16                      // 0000001BB39C: DBFC0010 1D000084
	ds_load_b128 v[9:12], v131 offset:32                       // 0000001BB3A4: DBFC0020 09000083
	ds_load_b128 v[13:16], v131 offset:48                      // 0000001BB3AC: DBFC0030 0D000083
	ds_load_b128 v[33:36], v132 offset:2304                    // 0000001BB3B4: DBFC0900 21000084
	ds_load_b128 v[37:40], v132 offset:2320                    // 0000001BB3BC: DBFC0910 25000084
	ds_load_b128 v[41:44], v132 offset:4608                    // 0000001BB3C4: DBFC1200 29000084
	ds_load_b128 v[45:48], v132 offset:4624                    // 0000001BB3CC: DBFC1210 2D000084
	ds_load_b128 v[49:52], v132 offset:6912                    // 0000001BB3D4: DBFC1B00 31000084
	ds_load_b128 v[53:56], v132 offset:6928                    // 0000001BB3DC: DBFC1B10 35000084
	ds_load_b128 v[57:60], v132 offset:9216                    // 0000001BB3E4: DBFC2400 39000084
	ds_load_b128 v[61:64], v132 offset:9232                    // 0000001BB3EC: DBFC2410 3D000084
	ds_load_b128 v[65:68], v132 offset:11520                   // 0000001BB3F4: DBFC2D00 41000084
	ds_load_b128 v[69:72], v132 offset:11536                   // 0000001BB3FC: DBFC2D10 45000084
	ds_load_b128 v[73:76], v132 offset:13824                   // 0000001BB404: DBFC3600 49000084
	ds_load_b128 v[77:80], v132 offset:13840                   // 0000001BB40C: DBFC3610 4D000084
	ds_load_b128 v[81:84], v132 offset:16128                   // 0000001BB414: DBFC3F00 51000084
	ds_load_b128 v[85:88], v132 offset:16144                   // 0000001BB41C: DBFC3F10 55000084
	ds_load_b128 v[89:92], v132 offset:32                      // 0000001BB424: DBFC0020 59000084
	ds_load_b128 v[93:96], v132 offset:48                      // 0000001BB42C: DBFC0030 5D000084
	v_dual_mov_b32 v17, s36 :: v_dual_mov_b32 v18, s37         // 0000001BB434: CA100024 11120025
	v_dual_mov_b32 v19, s38 :: v_dual_mov_b32 v20, s39         // 0000001BB43C: CA100026 13140027
	v_dual_mov_b32 v21, s40 :: v_dual_mov_b32 v22, s41         // 0000001BB444: CA100028 15160029
	v_dual_mov_b32 v23, s42 :: v_dual_mov_b32 v24, s43         // 0000001BB44C: CA10002A 1718002B
	s_mul_f32 s0, s28, 0x3fb8aa3b                              // 0000001BB454: A200FF1C 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000001BB45C: BF87000B
	s_xor_b32 s1, s0, 0x80000000                               // 0000001BB460: 8D01FF00 80000000
	s_rndne_f32 s8, s0                                         // 0000001BB468: BE886300
	s_waitcnt lgkmcnt(14)                                      // 0000001BB46C: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[172:179], v[33:40], v[1:8], v[17:24]// 0000001BB470: CC4040AC 1C460321
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[1:8], v[17:24]// 0000001BB478: CC404061 1C460319
	ds_load_b128 v[25:28], v132 offset:2336                    // 0000001BB480: DBFC0920 19000084
	ds_load_b128 v[29:32], v132 offset:2352                    // 0000001BB488: DBFC0930 1D000084
	s_waitcnt lgkmcnt(14)                                      // 0000001BB490: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[1:8], v[17:24]// 0000001BB494: CC404021 1C460329
	s_waitcnt lgkmcnt(12)                                      // 0000001BB49C: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[41:48], v[49:56], v[1:8], v[17:24]// 0000001BB4A0: CC404029 1C460331
	s_waitcnt lgkmcnt(10)                                      // 0000001BB4A8: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[49:56], v[57:64], v[1:8], v[17:24]// 0000001BB4AC: CC404031 1C460339
	s_waitcnt lgkmcnt(8)                                       // 0000001BB4B4: BF89FC87
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[1:8], v[17:24]// 0000001BB4B8: CC404039 1C460341
	s_waitcnt lgkmcnt(6)                                       // 0000001BB4C0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[73:80], v[1:8], v[17:24]// 0000001BB4C4: CC404041 1C460349
	s_waitcnt lgkmcnt(4)                                       // 0000001BB4CC: BF89FC47
	v_wmma_f32_16x16x16_f16 v[73:80], v[81:88], v[1:8], v[17:24]// 0000001BB4D0: CC404049 1C460351
	ds_load_b128 v[1:4], v132 offset:4640                      // 0000001BB4D8: DBFC1220 01000084
	ds_load_b128 v[5:8], v132 offset:4656                      // 0000001BB4E0: DBFC1230 05000084
	ds_load_b128 v[17:20], v132 offset:6944                    // 0000001BB4E8: DBFC1B20 11000084
	ds_load_b128 v[21:24], v132 offset:6960                    // 0000001BB4F0: DBFC1B30 15000084
	ds_load_b128 v[81:84], v132 offset:9248                    // 0000001BB4F8: DBFC2420 51000084
	ds_load_b128 v[85:88], v132 offset:9264                    // 0000001BB500: DBFC2430 55000084
	s_waitcnt lgkmcnt(8)                                       // 0000001BB508: BF89FC87
	v_wmma_f32_16x16x16_f16 v[97:104], v[89:96], v[9:16], v[97:104]// 0000001BB50C: CC404061 1D861359
	s_fmamk_f32 s1, s28, 0x3fb8aa3b, s1                        // 0000001BB514: A301011C 3FB8AA3B
	s_sub_f32 s0, s0, s8                                       // 0000001BB51C: A0800800
	s_cmp_nlt_f32 s28, 0xc2ce8ed0                              // 0000001BB520: BF4EFF1C C2CE8ED0
	s_waitcnt lgkmcnt(6)                                       // 0000001BB528: BF89FC67
	v_wmma_f32_16x16x16_f16 v[172:179], v[25:32], v[9:16], v[172:179]// 0000001BB52C: CC4040AC 1EB21319
	ds_load_b128 v[25:28], v132 offset:11552                   // 0000001BB534: DBFC2D20 19000084
	ds_load_b128 v[29:32], v132 offset:11568                   // 0000001BB53C: DBFC2D30 1D000084
	s_fmamk_f32 s1, s28, 0x32a5705f, s1                        // 0000001BB544: A301011C 32A5705F
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001BB54C: 986A80C1
	s_cmp_ngt_f32 s28, 0x42b17218                              // 0000001BB550: BF4BFF1C 42B17218
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000001BB558: BF870599
	s_add_f32 s0, s0, s1                                       // 0000001BB55C: A0000100
	v_exp_f32_e32 v91, s0                                      // 0000001BB560: 7EB64A00
	s_waitcnt lgkmcnt(6)                                       // 0000001BB564: BF89FC67
	v_wmma_f32_16x16x16_f16 v[33:40], v[1:8], v[9:16], v[33:40]// 0000001BB568: CC404021 1C861301
	ds_load_b128 v[1:4], v132 offset:13856                     // 0000001BB570: DBFC3620 01000084
	ds_load_b128 v[5:8], v132 offset:13872                     // 0000001BB578: DBFC3630 05000084
	s_waitcnt lgkmcnt(6)                                       // 0000001BB580: BF89FC67
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[9:16], v[41:48]// 0000001BB584: CC404029 1CA61311
	ds_load_b128 v[17:20], v132 offset:16160                   // 0000001BB58C: DBFC3F20 11000084
	ds_load_b128 v[21:24], v132 offset:16176                   // 0000001BB594: DBFC3F30 15000084
	s_waitcnt lgkmcnt(6)                                       // 0000001BB59C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[49:56], v[81:88], v[9:16], v[49:56]// 0000001BB5A0: CC404031 1CC61351
	ds_load_b128 v[85:88], v131 offset:80                      // 0000001BB5A8: DBFC0050 55000083
	ds_load_b128 v[81:84], v131 offset:64                      // 0000001BB5B0: DBFC0040 51000083
	s_cvt_i32_f32 s0, s8                                       // 0000001BB5B8: BE806608
	s_waitcnt lgkmcnt(6)                                       // 0000001BB5BC: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[25:32], v[9:16], v[57:64]// 0000001BB5C0: CC404039 1CE61319
	ds_load_b128 v[29:32], v132 offset:80                      // 0000001BB5C8: DBFC0050 1D000084
	ds_load_b128 v[25:28], v132 offset:64                      // 0000001BB5D0: DBFC0040 19000084
	.long 0xd71c005b                                           // 0000001BB5D8: D71C005B
	v_cndmask_b32_e32 v0, v91, v0, vcc_lo                      // 0000001BB5DC: 0200015B
	s_waitcnt lgkmcnt(6)                                       // 0000001BB5E0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[1:8], v[9:16], v[65:72]// 0000001BB5E4: CC404041 1D061301
	ds_load_b128 v[5:8], v132 offset:2384                      // 0000001BB5EC: DBFC0950 05000084
	ds_load_b128 v[1:4], v132 offset:2368                      // 0000001BB5F4: DBFC0940 01000084
	s_waitcnt lgkmcnt(6)                                       // 0000001BB5FC: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[9:16], v[73:80]// 0000001BB600: CC404049 1D261311
	ds_load_b128 v[13:16], v132 offset:4688                    // 0000001BB608: DBFC1250 0D000084
	ds_load_b128 v[9:12], v132 offset:4672                     // 0000001BB610: DBFC1240 09000084
	ds_load_b128 v[21:24], v132 offset:6992                    // 0000001BB618: DBFC1B50 15000084
	ds_load_b128 v[17:20], v132 offset:6976                    // 0000001BB620: DBFC1B40 11000084
	s_waitcnt lgkmcnt(6)                                       // 0000001BB628: BF89FC67
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[81:88], v[97:104]// 0000001BB62C: CC404061 1D86A319
	ds_load_b128 v[29:32], v132 offset:9296                    // 0000001BB634: DBFC2450 1D000084
	ds_load_b128 v[25:28], v132 offset:9280                    // 0000001BB63C: DBFC2440 19000084
	s_waitcnt lgkmcnt(6)                                       // 0000001BB644: BF89FC67
	v_wmma_f32_16x16x16_f16 v[172:179], v[1:8], v[81:88], v[172:179]// 0000001BB648: CC4040AC 1EB2A301
	ds_load_b128 v[5:8], v132 offset:11600                     // 0000001BB650: DBFC2D50 05000084
	ds_load_b128 v[1:4], v132 offset:11584                     // 0000001BB658: DBFC2D40 01000084
	s_waitcnt lgkmcnt(6)                                       // 0000001BB660: BF89FC67
	v_wmma_f32_16x16x16_f16 v[33:40], v[9:16], v[81:88], v[33:40]// 0000001BB664: CC404021 1C86A309
	ds_load_b128 v[13:16], v132 offset:13904                   // 0000001BB66C: DBFC3650 0D000084
	ds_load_b128 v[9:12], v132 offset:13888                    // 0000001BB674: DBFC3640 09000084
	s_waitcnt lgkmcnt(6)                                       // 0000001BB67C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[81:88], v[41:48]// 0000001BB680: CC404029 1CA6A311
	ds_load_b128 v[21:24], v132 offset:16208                   // 0000001BB688: DBFC3F50 15000084
	ds_load_b128 v[17:20], v132 offset:16192                   // 0000001BB690: DBFC3F40 11000084
	s_waitcnt lgkmcnt(6)                                       // 0000001BB698: BF89FC67
	v_wmma_f32_16x16x16_f16 v[49:56], v[25:32], v[81:88], v[49:56]// 0000001BB69C: CC404031 1CC6A319
	ds_load_b128 v[29:32], v131 offset:112                     // 0000001BB6A4: DBFC0070 1D000083
	ds_load_b128 v[25:28], v131 offset:96                      // 0000001BB6AC: DBFC0060 19000083
	s_waitcnt lgkmcnt(6)                                       // 0000001BB6B4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[1:8], v[81:88], v[57:64]// 0000001BB6B8: CC404039 1CE6A301
	ds_load_b128 v[5:8], v132 offset:112                       // 0000001BB6C0: DBFC0070 05000084
	ds_load_b128 v[1:4], v132 offset:96                        // 0000001BB6C8: DBFC0060 01000084
	s_waitcnt lgkmcnt(6)                                       // 0000001BB6D0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[9:16], v[81:88], v[65:72]// 0000001BB6D4: CC404041 1D06A309
	ds_load_b128 v[13:16], v132 offset:2416                    // 0000001BB6DC: DBFC0970 0D000084
	ds_load_b128 v[9:12], v132 offset:2400                     // 0000001BB6E4: DBFC0960 09000084
	s_waitcnt lgkmcnt(6)                                       // 0000001BB6EC: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[81:88], v[73:80]// 0000001BB6F0: CC404049 1D26A311
	ds_load_b128 v[21:24], v132 offset:4720                    // 0000001BB6F8: DBFC1270 15000084
	ds_load_b128 v[17:20], v132 offset:4704                    // 0000001BB700: DBFC1260 11000084
	ds_load_b128 v[85:88], v132 offset:7024                    // 0000001BB708: DBFC1B70 55000084
	ds_load_b128 v[81:84], v132 offset:7008                    // 0000001BB710: DBFC1B60 51000084
	s_waitcnt lgkmcnt(6)                                       // 0000001BB718: BF89FC67
	v_wmma_f32_16x16x16_f16 v[97:104], v[1:8], v[25:32], v[97:104]// 0000001BB71C: CC404061 1D863301
	ds_load_b128 v[5:8], v132 offset:9328                      // 0000001BB724: DBFC2470 05000084
	ds_load_b128 v[1:4], v132 offset:9312                      // 0000001BB72C: DBFC2460 01000084
	s_waitcnt lgkmcnt(4)                                       // 0000001BB734: BF89FC47
	v_wmma_f32_16x16x16_f16 v[33:40], v[17:24], v[25:32], v[33:40]// 0000001BB738: CC404021 1C863311
	ds_load_b128 v[21:24], v132 offset:13936                   // 0000001BB740: DBFC3670 15000084
	ds_load_b128 v[17:20], v132 offset:13920                   // 0000001BB748: DBFC3660 11000084
	s_waitcnt lgkmcnt(4)                                       // 0000001BB750: BF89FC47
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[25:32], v[41:48]// 0000001BB754: CC404029 1CA63351
	ds_load_b128 v[85:88], v132 offset:16240                   // 0000001BB75C: DBFC3F70 55000084
	ds_load_b128 v[81:84], v132 offset:16224                   // 0000001BB764: DBFC3F60 51000084
	v_wmma_f32_16x16x16_f16 v[172:179], v[9:16], v[25:32], v[172:179]// 0000001BB76C: CC4040AC 1EB23309
	ds_load_b128 v[13:16], v132 offset:11632                   // 0000001BB774: DBFC2D70 0D000084
	ds_load_b128 v[9:12], v132 offset:11616                    // 0000001BB77C: DBFC2D60 09000084
	ds_load_2addr_b32 v[89:90], v133 offset1:2                 // 0000001BB784: D8DC0200 59000085
	s_waitcnt lgkmcnt(7)                                       // 0000001BB78C: BF89FC77
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[25:32], v[49:56]// 0000001BB790: CC404031 1CC63301
	ds_load_2addr_b32 v[1:2], v133 offset0:4 offset1:6         // 0000001BB798: D8DC0604 01000085
	ds_load_2addr_b32 v[3:4], v133 offset0:8 offset1:10        // 0000001BB7A0: D8DC0A08 03000085
	ds_load_2addr_b32 v[5:6], v133 offset0:12 offset1:14       // 0000001BB7A8: D8DC0E0C 05000085
	s_waitcnt lgkmcnt(8)                                       // 0000001BB7B0: BF89FC87
	v_wmma_f32_16x16x16_f16 v[65:72], v[17:24], v[25:32], v[65:72]// 0000001BB7B4: CC404041 1D063311
	ds_load_2addr_b32 v[7:8], v133 offset0:16 offset1:18       // 0000001BB7BC: D8DC1210 07000085
	s_waitcnt lgkmcnt(7)                                       // 0000001BB7C4: BF89FC77
	v_wmma_f32_16x16x16_f16 v[73:80], v[81:88], v[25:32], v[73:80]// 0000001BB7C8: CC404049 1D263351
	s_waitcnt lgkmcnt(5)                                       // 0000001BB7D0: BF89FC57
	v_wmma_f32_16x16x16_f16 v[57:64], v[9:16], v[25:32], v[57:64]// 0000001BB7D4: CC404039 1CE63309
	v_cndmask_b32_e32 v31, 0, v91, vcc_lo                      // 0000001BB7DC: 023EB680
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001BB7E0: 986A80C1
	ds_load_2addr_b32 v[9:10], v133 offset0:20 offset1:22      // 0000001BB7E4: D8DC1614 09000085
	ds_load_2addr_b32 v[11:12], v133 offset0:24 offset1:26     // 0000001BB7EC: D8DC1A18 0B000085
	ds_load_2addr_b32 v[13:14], v133 offset0:28 offset1:30     // 0000001BB7F4: D8DC1E1C 0D000085
	ds_load_2addr_b32 v[15:16], v133 offset0:32 offset1:34     // 0000001BB7FC: D8DC2220 0F000085
	ds_load_2addr_b32 v[17:18], v133 offset0:36 offset1:38     // 0000001BB804: D8DC2624 11000085
	v_cndmask_b32_e32 v91, 0x7f800000, v31, vcc_lo             // 0000001BB80C: 02B63EFF 7F800000
	ds_load_2addr_b32 v[19:20], v133 offset0:40 offset1:42     // 0000001BB814: D8DC2A28 13000085
	ds_load_2addr_b32 v[21:22], v133 offset0:44 offset1:46     // 0000001BB81C: D8DC2E2C 15000085
	ds_load_2addr_b32 v[23:24], v133 offset0:48 offset1:50     // 0000001BB824: D8DC3230 17000085
	ds_load_2addr_b32 v[25:26], v133 offset0:52 offset1:54     // 0000001BB82C: D8DC3634 19000085
	ds_load_2addr_b32 v[27:28], v133 offset0:56 offset1:58     // 0000001BB834: D8DC3A38 1B000085
	ds_load_2addr_b32 v[29:30], v133 offset0:60 offset1:62     // 0000001BB83C: D8DC3E3C 1D000085
	s_waitcnt lgkmcnt(15)                                      // 0000001BB844: BF89FCF7
	v_mul_f32_e32 v90, v91, v90                                // 0000001BB848: 10B4B55B
	v_mul_f32_e32 v89, v91, v89                                // 0000001BB84C: 10B2B35B
	ds_load_2addr_b32 v[31:32], v133 offset0:64 offset1:66     // 0000001BB850: D8DC4240 1F000085
	ds_load_2addr_b32 v[81:82], v133 offset0:68 offset1:70     // 0000001BB858: D8DC4644 51000085
	ds_load_2addr_b32 v[83:84], v133 offset0:72 offset1:74     // 0000001BB860: D8DC4A48 53000085
	ds_load_2addr_b32 v[85:86], v133 offset0:76 offset1:78     // 0000001BB868: D8DC4E4C 55000085
	s_waitcnt lgkmcnt(18)                                      // 0000001BB870: BF89FD27
	v_mul_f32_e32 v93, v91, v2                                 // 0000001BB874: 10BA055B
	v_mul_f32_e32 v92, v91, v1                                 // 0000001BB878: 10B8035B
	v_fmac_f32_e32 v90, 0x3b800000, v98                        // 0000001BB87C: 56B4C4FF 3B800000
	s_waitcnt lgkmcnt(17)                                      // 0000001BB884: BF89FD17
	v_dual_mul_f32 v94, v91, v3 :: v_dual_fmac_f32 v89, 0x3b800000, v97// 0000001BB888: C8C0075B 5E58C2FF 3B800000
	v_mul_f32_e32 v95, v91, v4                                 // 0000001BB894: 10BE095B
	v_dual_fmac_f32 v93, 0x3b800000, v100 :: v_dual_fmac_f32 v92, 0x3b800000, v99// 0000001BB898: C800C8FF 5D5CC6FF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BB8A4: BF8701A3
	v_fmac_f32_e32 v94, 0x3b800000, v101                       // 0000001BB8A8: 56BCCAFF 3B800000
	s_waitcnt lgkmcnt(16)                                      // 0000001BB8B0: BF89FD07
	v_dual_mul_f32 v96, v91, v5 :: v_dual_fmac_f32 v95, 0x3b800000, v102// 0000001BB8B4: C8C00B5B 605ECCFF 3B800000
	v_mul_f32_e32 v105, v91, v6                                // 0000001BB8C0: 10D20D5B
	s_waitcnt lgkmcnt(14)                                      // 0000001BB8C4: BF89FCE7
	v_mul_f32_e32 v100, v91, v10                               // 0000001BB8C8: 10C8155B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001BB8CC: BF8701B3
	v_dual_mul_f32 v99, v91, v9 :: v_dual_fmac_f32 v96, 0x3b800000, v103// 0000001BB8D0: C8C0135B 6360CEFF 3B800000
	s_waitcnt lgkmcnt(11)                                      // 0000001BB8DC: BF89FCB7
	v_dual_mul_f32 v116, v91, v15 :: v_dual_fmac_f32 v105, 0x3b800000, v104// 0000001BB8E0: C8C01F5B 7468D0FF 3B800000
	v_fmac_f32_e32 v100, 0x3b800000, v175                      // 0000001BB8EC: 56C95EFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BB8F4: BF870223
	v_dual_mul_f32 v98, v91, v8 :: v_dual_fmac_f32 v99, 0x3b800000, v174// 0000001BB8F8: C8C0115B 62635CFF 3B800000
	v_mul_f32_e32 v97, v91, v7                                 // 0000001BB904: 10C20F5B
	v_dual_mul_f32 v117, v91, v16 :: v_dual_fmac_f32 v116, 0x3b800000, v33// 0000001BB908: C8C0215B 757442FF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BB914: BF870193
	v_fmac_f32_e32 v98, 0x3b800000, v173                       // 0000001BB918: 56C55AFF 3B800000
	v_dual_mul_f32 v104, v91, v14 :: v_dual_fmac_f32 v97, 0x3b800000, v172// 0000001BB920: C8C01D5B 686158FF 3B800000
	v_mul_f32_e32 v103, v91, v13                               // 0000001BB92C: 10CE1B5B
	s_waitcnt lgkmcnt(10)                                      // 0000001BB930: BF89FCA7
	v_dual_mul_f32 v172, v91, v17 :: v_dual_fmac_f32 v117, 0x3b800000, v34// 0000001BB934: C8C0235B AC7444FF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BB940: BF870193
	v_fmac_f32_e32 v104, 0x3b800000, v179                      // 0000001BB944: 56D166FF 3B800000
	v_dual_mul_f32 v102, v91, v12 :: v_dual_fmac_f32 v103, 0x3b800000, v178// 0000001BB94C: C8C0195B 666764FF 3B800000
	v_mul_f32_e32 v101, v91, v11                               // 0000001BB958: 10CA175B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BB95C: BF870194
	v_dual_mul_f32 v173, v91, v18 :: v_dual_fmac_f32 v172, 0x3b800000, v35// 0000001BB960: C8C0255B ADAC46FF 3B800000
	v_fmac_f32_e32 v102, 0x3b800000, v177                      // 0000001BB96C: 56CD62FF 3B800000
	s_waitcnt lgkmcnt(9)                                       // 0000001BB974: BF89FC97
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BB978: BF870193
	v_dual_mul_f32 v174, v91, v19 :: v_dual_fmac_f32 v101, 0x3b800000, v176// 0000001BB97C: C8C0275B AE6560FF 3B800000
	v_fmac_f32_e32 v173, 0x3b800000, v36                       // 0000001BB988: 575A48FF 3B800000
	v_mul_f32_e32 v175, v91, v20                               // 0000001BB990: 115E295B
	ds_load_2addr_b32 v[1:2], v133 offset0:80 offset1:82       // 0000001BB994: D8DC5250 01000085
	ds_load_2addr_b32 v[3:4], v133 offset0:84 offset1:86       // 0000001BB99C: D8DC5654 03000085
	ds_load_2addr_b32 v[5:6], v133 offset0:88 offset1:90       // 0000001BB9A4: D8DC5A58 05000085
	ds_load_2addr_b32 v[87:88], v133 offset0:92 offset1:94     // 0000001BB9AC: D8DC5E5C 57000085
	ds_load_2addr_b32 v[7:8], v133 offset0:96 offset1:98       // 0000001BB9B4: D8DC6260 07000085
	ds_load_2addr_b32 v[9:10], v133 offset0:100 offset1:102    // 0000001BB9BC: D8DC6664 09000085
	ds_load_2addr_b32 v[11:12], v133 offset0:104 offset1:106   // 0000001BB9C4: D8DC6A68 0B000085
	ds_load_2addr_b32 v[13:14], v133 offset0:108 offset1:110   // 0000001BB9CC: D8DC6E6C 0D000085
	v_fmac_f32_e32 v174, 0x3b800000, v37                       // 0000001BB9D4: 575C4AFF 3B800000
	s_waitcnt lgkmcnt(16)                                      // 0000001BB9DC: BF89FD07
	v_dual_mul_f32 v176, v91, v21 :: v_dual_fmac_f32 v175, 0x3b800000, v38// 0000001BB9E0: C8C02B5B B0AE4CFF 3B800000
	v_mul_f32_e32 v177, v91, v22                               // 0000001BB9EC: 11622D5B
	ds_load_2addr_b32 v[15:16], v133 offset0:112 offset1:114   // 0000001BB9F0: D8DC7270 0F000085
	ds_load_2addr_b32 v[17:18], v133 offset0:116 offset1:118   // 0000001BB9F8: D8DC7674 11000085
	ds_load_2addr_b32 v[19:20], v133 offset0:120 offset1:122   // 0000001BBA00: D8DC7A78 13000085
	ds_load_2addr_b32 v[21:22], v133 offset0:124 offset1:126   // 0000001BBA08: D8DC7E7C 15000085
	s_waitcnt lgkmcnt(18)                                      // 0000001BBA10: BF89FD27
	v_mul_f32_e32 v26, v91, v26                                // 0000001BBA14: 1034355B
	v_dual_fmac_f32 v176, 0x3b800000, v39 :: v_dual_mul_f32 v25, v91, v25// 0000001BBA18: C8064EFF B018335B 3B800000
	v_fmac_f32_e32 v177, 0x3b800000, v40                       // 0000001BBA24: 576250FF 3B800000
	v_mul_f32_e32 v24, v91, v24                                // 0000001BBA2C: 1030315B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000001BBA30: BF8701D4
	v_fmac_f32_e32 v26, 0x3b800000, v44                        // 0000001BBA34: 563458FF 3B800000
	s_waitcnt lgkmcnt(17)                                      // 0000001BBA3C: BF89FD17
	v_dual_mul_f32 v28, v91, v28 :: v_dual_fmac_f32 v25, 0x3b800000, v43// 0000001BBA40: C8C0395B 1C1856FF 3B800000
	v_mul_f32_e32 v27, v91, v27                                // 0000001BBA4C: 1036375B
	v_dual_mul_f32 v23, v91, v23 :: v_dual_fmac_f32 v24, 0x3b800000, v42// 0000001BBA50: C8C02F5B 171854FF 3B800000
	v_fmac_f32_e32 v28, 0x3b800000, v46                        // 0000001BBA5C: 56385CFF 3B800000
	s_waitcnt lgkmcnt(16)                                      // 0000001BBA64: BF89FD07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001BBA68: BF870133
	v_dual_mul_f32 v30, v91, v30 :: v_dual_fmac_f32 v27, 0x3b800000, v45// 0000001BBA6C: C8C03D5B 1E1A5AFF 3B800000
	v_mul_f32_e32 v29, v91, v29                                // 0000001BBA78: 103A3B5B
	s_cmp_lg_u32 s23, s44                                      // 0000001BBA7C: BF072C17
	v_dual_fmac_f32 v23, 0x3b800000, v41 :: v_dual_fmac_f32 v30, 0x3b800000, v48// 0000001BBA80: C80052FF 171E60FF 3B800000
	s_waitcnt lgkmcnt(15)                                      // 0000001BBA8C: BF89FCF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBA90: BF870092
	v_dual_mul_f32 v32, v91, v32 :: v_dual_fmac_f32 v29, 0x3b800000, v47// 0000001BBA94: C8C0415B 201C5EFF 3B800000
	v_dual_mul_f32 v31, v91, v31 :: v_dual_fmac_f32 v32, 0x3b800000, v50// 0000001BBAA0: C8C03F5B 1F2064FF 3B800000
	s_waitcnt lgkmcnt(14)                                      // 0000001BBAAC: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBAB0: BF870091
	v_dual_mul_f32 v34, v91, v82 :: v_dual_fmac_f32 v31, 0x3b800000, v49// 0000001BBAB4: C8C0A55B 221E62FF 3B800000
	v_dual_mul_f32 v33, v91, v81 :: v_dual_fmac_f32 v34, 0x3b800000, v52// 0000001BBAC0: C8C0A35B 212268FF 3B800000
	s_waitcnt lgkmcnt(13)                                      // 0000001BBACC: BF89FCD7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBAD0: BF870091
	v_dual_mul_f32 v36, v91, v84 :: v_dual_fmac_f32 v33, 0x3b800000, v51// 0000001BBAD4: C8C0A95B 242066FF 3B800000
	v_dual_mul_f32 v35, v91, v83 :: v_dual_fmac_f32 v36, 0x3b800000, v54// 0000001BBAE0: C8C0A75B 23246CFF 3B800000
	s_waitcnt lgkmcnt(12)                                      // 0000001BBAEC: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBAF0: BF870091
	v_dual_mul_f32 v38, v91, v86 :: v_dual_fmac_f32 v35, 0x3b800000, v53// 0000001BBAF4: C8C0AD5B 26226AFF 3B800000
	v_dual_mul_f32 v37, v91, v85 :: v_dual_fmac_f32 v38, 0x3b800000, v56// 0000001BBB00: C8C0AB5B 252670FF 3B800000
	s_waitcnt lgkmcnt(11)                                      // 0000001BBB0C: BF89FCB7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBB10: BF870091
	v_dual_mul_f32 v2, v91, v2 :: v_dual_fmac_f32 v37, 0x3b800000, v55// 0000001BBB14: C8C0055B 02246EFF 3B800000
	v_dual_mul_f32 v1, v91, v1 :: v_dual_fmac_f32 v2, 0x3b800000, v58// 0000001BBB20: C8C0035B 010274FF 3B800000
	s_waitcnt lgkmcnt(10)                                      // 0000001BBB2C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBB30: BF870091
	v_dual_mul_f32 v4, v91, v4 :: v_dual_fmac_f32 v1, 0x3b800000, v57// 0000001BBB34: C8C0095B 040072FF 3B800000
	v_dual_mul_f32 v3, v91, v3 :: v_dual_fmac_f32 v4, 0x3b800000, v60// 0000001BBB40: C8C0075B 030478FF 3B800000
	s_waitcnt lgkmcnt(9)                                       // 0000001BBB4C: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBB50: BF870091
	v_dual_mul_f32 v6, v91, v6 :: v_dual_fmac_f32 v3, 0x3b800000, v59// 0000001BBB54: C8C00D5B 060276FF 3B800000
	v_dual_mul_f32 v5, v91, v5 :: v_dual_fmac_f32 v6, 0x3b800000, v62// 0000001BBB60: C8C00B5B 05067CFF 3B800000
	s_waitcnt lgkmcnt(8)                                       // 0000001BBB6C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBB70: BF870091
	v_dual_mul_f32 v40, v91, v88 :: v_dual_fmac_f32 v5, 0x3b800000, v61// 0000001BBB74: C8C0B15B 28047AFF 3B800000
	v_dual_mul_f32 v39, v91, v87 :: v_dual_fmac_f32 v40, 0x3b800000, v64// 0000001BBB80: C8C0AF5B 272880FF 3B800000
	s_waitcnt lgkmcnt(7)                                       // 0000001BBB8C: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBB90: BF870091
	v_dual_mul_f32 v8, v91, v8 :: v_dual_fmac_f32 v39, 0x3b800000, v63// 0000001BBB94: C8C0115B 08267EFF 3B800000
	v_dual_mul_f32 v7, v91, v7 :: v_dual_fmac_f32 v8, 0x3b800000, v66// 0000001BBBA0: C8C00F5B 070884FF 3B800000
	s_waitcnt lgkmcnt(6)                                       // 0000001BBBAC: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBBB0: BF870091
	v_dual_mul_f32 v10, v91, v10 :: v_dual_fmac_f32 v7, 0x3b800000, v65// 0000001BBBB4: C8C0155B 0A0682FF 3B800000
	v_dual_mul_f32 v9, v91, v9 :: v_dual_fmac_f32 v10, 0x3b800000, v68// 0000001BBBC0: C8C0135B 090A88FF 3B800000
	s_waitcnt lgkmcnt(5)                                       // 0000001BBBCC: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBBD0: BF870091
	v_dual_mul_f32 v12, v91, v12 :: v_dual_fmac_f32 v9, 0x3b800000, v67// 0000001BBBD4: C8C0195B 0C0886FF 3B800000
	v_dual_mul_f32 v11, v91, v11 :: v_dual_fmac_f32 v12, 0x3b800000, v70// 0000001BBBE0: C8C0175B 0B0C8CFF 3B800000
	s_waitcnt lgkmcnt(4)                                       // 0000001BBBEC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBBF0: BF870091
	v_dual_mul_f32 v14, v91, v14 :: v_dual_fmac_f32 v11, 0x3b800000, v69// 0000001BBBF4: C8C01D5B 0E0A8AFF 3B800000
	v_dual_mul_f32 v13, v91, v13 :: v_dual_fmac_f32 v14, 0x3b800000, v72// 0000001BBC00: C8C01B5B 0D0E90FF 3B800000
	s_waitcnt lgkmcnt(3)                                       // 0000001BBC0C: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBC10: BF870091
	v_dual_mul_f32 v16, v91, v16 :: v_dual_fmac_f32 v13, 0x3b800000, v71// 0000001BBC14: C8C0215B 100C8EFF 3B800000
	v_dual_mul_f32 v15, v91, v15 :: v_dual_fmac_f32 v16, 0x3b800000, v74// 0000001BBC20: C8C01F5B 0F1094FF 3B800000
	s_waitcnt lgkmcnt(2)                                       // 0000001BBC2C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBC30: BF870091
	v_dual_mul_f32 v18, v91, v18 :: v_dual_fmac_f32 v15, 0x3b800000, v73// 0000001BBC34: C8C0255B 120E92FF 3B800000
	v_dual_mul_f32 v17, v91, v17 :: v_dual_fmac_f32 v18, 0x3b800000, v76// 0000001BBC40: C8C0235B 111298FF 3B800000
	s_waitcnt lgkmcnt(1)                                       // 0000001BBC4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBC50: BF870091
	v_dual_mul_f32 v20, v91, v20 :: v_dual_fmac_f32 v17, 0x3b800000, v75// 0000001BBC54: C8C0295B 141096FF 3B800000
	v_dual_mul_f32 v19, v91, v19 :: v_dual_fmac_f32 v20, 0x3b800000, v78// 0000001BBC60: C8C0275B 13149CFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 0000001BBC6C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BBC70: BF870091
	v_dual_mul_f32 v22, v91, v22 :: v_dual_fmac_f32 v19, 0x3b800000, v77// 0000001BBC74: C8C02D5B 16129AFF 3B800000
	v_dual_mul_f32 v21, v91, v21 :: v_dual_fmac_f32 v22, 0x3b800000, v80// 0000001BBC80: C8C02B5B 1516A0FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BBC8C: BF870001
	v_fmac_f32_e32 v21, 0x3b800000, v79                        // 0000001BBC90: 562A9EFF 3B800000
	ds_store_2addr_b32 v133, v89, v90 offset1:2                // 0000001BBC98: D8380200 005A5985
	ds_store_2addr_b32 v133, v92, v93 offset0:4 offset1:6      // 0000001BBCA0: D8380604 005D5C85
	ds_store_2addr_b32 v133, v94, v95 offset0:8 offset1:10     // 0000001BBCA8: D8380A08 005F5E85
	ds_store_2addr_b32 v133, v96, v105 offset0:12 offset1:14   // 0000001BBCB0: D8380E0C 00696085
	ds_store_2addr_b32 v133, v97, v98 offset0:16 offset1:18    // 0000001BBCB8: D8381210 00626185
	ds_store_2addr_b32 v133, v99, v100 offset0:20 offset1:22   // 0000001BBCC0: D8381614 00646385
	ds_store_2addr_b32 v133, v101, v102 offset0:24 offset1:26  // 0000001BBCC8: D8381A18 00666585
	ds_store_2addr_b32 v133, v103, v104 offset0:28 offset1:30  // 0000001BBCD0: D8381E1C 00686785
	ds_store_2addr_b32 v133, v116, v117 offset0:32 offset1:34  // 0000001BBCD8: D8382220 00757485
	ds_store_2addr_b32 v133, v172, v173 offset0:36 offset1:38  // 0000001BBCE0: D8382624 00ADAC85
	ds_store_2addr_b32 v133, v174, v175 offset0:40 offset1:42  // 0000001BBCE8: D8382A28 00AFAE85
	ds_store_2addr_b32 v133, v176, v177 offset0:44 offset1:46  // 0000001BBCF0: D8382E2C 00B1B085
	ds_store_2addr_b32 v133, v23, v24 offset0:48 offset1:50    // 0000001BBCF8: D8383230 00181785
	ds_store_2addr_b32 v133, v25, v26 offset0:52 offset1:54    // 0000001BBD00: D8383634 001A1985
	ds_store_2addr_b32 v133, v27, v28 offset0:56 offset1:58    // 0000001BBD08: D8383A38 001C1B85
	ds_store_2addr_b32 v133, v29, v30 offset0:60 offset1:62    // 0000001BBD10: D8383E3C 001E1D85
	ds_store_2addr_b32 v133, v31, v32 offset0:64 offset1:66    // 0000001BBD18: D8384240 00201F85
	ds_store_2addr_b32 v133, v33, v34 offset0:68 offset1:70    // 0000001BBD20: D8384644 00222185
	ds_store_2addr_b32 v133, v35, v36 offset0:72 offset1:74    // 0000001BBD28: D8384A48 00242385
	ds_store_2addr_b32 v133, v37, v38 offset0:76 offset1:78    // 0000001BBD30: D8384E4C 00262585
	ds_store_2addr_b32 v133, v1, v2 offset0:80 offset1:82      // 0000001BBD38: D8385250 00020185
	ds_store_2addr_b32 v133, v3, v4 offset0:84 offset1:86      // 0000001BBD40: D8385654 00040385
	ds_store_2addr_b32 v133, v5, v6 offset0:88 offset1:90      // 0000001BBD48: D8385A58 00060585
	ds_store_2addr_b32 v133, v39, v40 offset0:92 offset1:94    // 0000001BBD50: D8385E5C 00282785
	ds_store_2addr_b32 v133, v7, v8 offset0:96 offset1:98      // 0000001BBD58: D8386260 00080785
	ds_store_2addr_b32 v133, v9, v10 offset0:100 offset1:102   // 0000001BBD60: D8386664 000A0985
	ds_store_2addr_b32 v133, v11, v12 offset0:104 offset1:106  // 0000001BBD68: D8386A68 000C0B85
	ds_store_2addr_b32 v133, v13, v14 offset0:108 offset1:110  // 0000001BBD70: D8386E6C 000E0D85
	ds_store_2addr_b32 v133, v15, v16 offset0:112 offset1:114  // 0000001BBD78: D8387270 00100F85
	ds_store_2addr_b32 v133, v17, v18 offset0:116 offset1:118  // 0000001BBD80: D8387674 00121185
	ds_store_2addr_b32 v133, v19, v20 offset0:120 offset1:122  // 0000001BBD88: D8387A78 00141385
	ds_store_2addr_b32 v133, v21, v22 offset0:124 offset1:126  // 0000001BBD90: D8387E7C 00161585
	s_waitcnt lgkmcnt(0)                                       // 0000001BBD98: BF89FC07
	s_barrier                                                  // 0000001BBD9C: BFBD0000
	buffer_gl0_inv                                             // 0000001BBDA0: E0AC0000 00000000
	s_cbranch_scc0 73                                          // 0000001BBDA8: BFA10049 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x73d0>
	s_cmp_lg_u32 s23, s45                                      // 0000001BBDAC: BF072D17
	s_cbranch_scc0 105                                         // 0000001BBDB0: BFA10069 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7458>
	s_cmp_lg_u32 s23, s46                                      // 0000001BBDB4: BF072E17
	s_cbranch_scc1 58532                                       // 0000001BBDB8: BFA2E4A4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x54c>
	s_branch 134                                               // 0000001BBDBC: BFA00086 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x74d8>
	s_clause 0x1                                               // 0000001BBDC0: BF850001
	global_load_b128 v[69:72], v[116:117], off offset:48       // 0000001BBDC4: DC5E0030 457C0074
	global_load_b128 v[65:68], v[116:117], off offset:32       // 0000001BBDCC: DC5E0020 417C0074
	ds_load_b128 v[73:76], v128 offset:32                      // 0000001BBDD4: DBFC0020 49000080
	ds_load_b128 v[77:80], v128 offset:48                      // 0000001BBDDC: DBFC0030 4D000080
	ds_load_b128 v[85:88], v128 offset:2352                    // 0000001BBDE4: DBFC0930 55000080
	ds_load_b128 v[81:84], v128 offset:2336                    // 0000001BBDEC: DBFC0920 51000080
	ds_load_b128 v[184:187], v128 offset:4656                  // 0000001BBDF4: DBFC1230 B8000080
	ds_load_b128 v[180:183], v128 offset:4640                  // 0000001BBDFC: DBFC1220 B4000080
	ds_load_b128 v[192:195], v128 offset:6960                  // 0000001BBE04: DBFC1B30 C0000080
	ds_load_b128 v[188:191], v128 offset:6944                  // 0000001BBE0C: DBFC1B20 BC000080
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001BBE14: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[73:80], v[57:64]// 0000001BBE18: CC404039 1CE69341
	s_waitcnt lgkmcnt(4)                                       // 0000001BBE20: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[81:88], v[49:56]// 0000001BBE24: CC404031 1CC6A341
	s_waitcnt lgkmcnt(2)                                       // 0000001BBE2C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[180:187], v[41:48]// 0000001BBE30: CC404029 1CA76941
	s_waitcnt lgkmcnt(0)                                       // 0000001BBE38: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[65:72], v[188:195], v[33:40]// 0000001BBE3C: CC404021 1C877941
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BBE44: 8C7E0E7E
	s_and_saveexec_b32 s14, s5                                 // 0000001BBE48: BE8E2005
	s_cbranch_execz 64294                                      // 0000001BBE4C: BFA5FB26 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5fe8>
	ds_load_b128 v[65:68], v128 offset:64                      // 0000001BBE50: DBFC0040 41000080
	ds_load_b128 v[69:72], v128 offset:80                      // 0000001BBE58: DBFC0050 45000080
	ds_load_b128 v[77:80], v128 offset:2384                    // 0000001BBE60: DBFC0950 4D000080
	ds_load_b128 v[73:76], v128 offset:2368                    // 0000001BBE68: DBFC0940 49000080
	ds_load_b128 v[85:88], v128 offset:4688                    // 0000001BBE70: DBFC1250 55000080
	ds_load_b128 v[81:84], v128 offset:4672                    // 0000001BBE78: DBFC1240 51000080
	ds_load_b128 v[184:187], v128 offset:6992                  // 0000001BBE80: DBFC1B50 B8000080
	ds_load_b128 v[180:183], v128 offset:6976                  // 0000001BBE88: DBFC1B40 B4000080
	s_waitcnt vmcnt(2) lgkmcnt(6)                              // 0000001BBE90: BF890867
	v_wmma_f32_16x16x16_f16 v[57:64], v[97:104], v[65:72], v[57:64]// 0000001BBE94: CC404039 1CE68361
	s_waitcnt lgkmcnt(4)                                       // 0000001BBE9C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[97:104], v[73:80], v[49:56]// 0000001BBEA0: CC404031 1CC69361
	s_waitcnt lgkmcnt(2)                                       // 0000001BBEA8: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[97:104], v[81:88], v[41:48]// 0000001BBEAC: CC404029 1CA6A361
	s_waitcnt lgkmcnt(0)                                       // 0000001BBEB4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[97:104], v[180:187], v[33:40]// 0000001BBEB8: CC404021 1C876961
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BBEC0: 8C7E0E7E
	s_and_saveexec_b32 s14, s7                                 // 0000001BBEC4: BE8E2007
	s_cbranch_execnz 64266                                     // 0000001BBEC8: BFA6FB0A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5ff4>
	s_branch 64295                                             // 0000001BBECC: BFA0FB27 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x606c>
	v_mov_b32_e32 v3, v123                                     // 0000001BBED0: 7E06037B
	v_dual_mov_b32 v1, v110 :: v_dual_mov_b32 v2, v111         // 0000001BBED4: CA10016E 0102016F
	v_mov_b32_e32 v4, v119                                     // 0000001BBEDC: 7E080377
	s_mov_b32 s1, 0                                            // 0000001BBEE0: BE810080
	s_nop 0                                                    // 0000001BBEE4: BF800000
	s_nop 0                                                    // 0000001BBEE8: BF800000
	s_nop 0                                                    // 0000001BBEEC: BF800000
	s_nop 0                                                    // 0000001BBEF0: BF800000
	s_nop 0                                                    // 0000001BBEF4: BF800000
	s_nop 0                                                    // 0000001BBEF8: BF800000
	s_nop 0                                                    // 0000001BBEFC: BF800000
	ds_load_b32 v5, v3                                         // 0000001BBF00: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001BBF08: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001BBF10: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001BBF14: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001BBF18: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001BBF20: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001BBF24: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001BBF28: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001BBF30: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001BBF34: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001BBF3C: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001BBF44: 917E017E
	s_cbranch_execnz 65517                                     // 0000001BBF48: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7400>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001BBF4C: 8C7E017E
	s_cmp_lg_u32 s23, s45                                      // 0000001BBF50: BF072D17
	s_cbranch_scc1 65431                                       // 0000001BBF54: BFA2FF97 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x72b4>
	v_dual_mov_b32 v1, v112 :: v_dual_mov_b32 v4, v119         // 0000001BBF58: CA100170 01040177
	v_dual_mov_b32 v3, v123 :: v_dual_mov_b32 v2, v113         // 0000001BBF60: CA10017B 03020171
	s_mov_b32 s1, 0                                            // 0000001BBF68: BE810080
	s_nop 0                                                    // 0000001BBF6C: BF800000
	s_nop 0                                                    // 0000001BBF70: BF800000
	s_nop 0                                                    // 0000001BBF74: BF800000
	s_nop 0                                                    // 0000001BBF78: BF800000
	s_nop 0                                                    // 0000001BBF7C: BF800000
	ds_load_b32 v5, v3                                         // 0000001BBF80: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001BBF88: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001BBF90: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001BBF94: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001BBF98: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001BBFA0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001BBFA4: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001BBFA8: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001BBFB0: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001BBFB4: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001BBFBC: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001BBFC4: 917E017E
	s_cbranch_execnz 65517                                     // 0000001BBFC8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7480>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001BBFCC: 8C7E017E
	s_cmp_lg_u32 s23, s46                                      // 0000001BBFD0: BF072E17
	s_cbranch_scc1 58397                                       // 0000001BBFD4: BFA2E41D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x54c>
	v_mov_b32_e32 v3, v123                                     // 0000001BBFD8: 7E06037B
	v_dual_mov_b32 v1, v114 :: v_dual_mov_b32 v2, v115         // 0000001BBFDC: CA100172 01020173
	v_mov_b32_e32 v4, v119                                     // 0000001BBFE4: 7E080377
	s_mov_b32 s1, 0                                            // 0000001BBFE8: BE810080
	s_nop 0                                                    // 0000001BBFEC: BF800000
	s_nop 0                                                    // 0000001BBFF0: BF800000
	s_nop 0                                                    // 0000001BBFF4: BF800000
	s_nop 0                                                    // 0000001BBFF8: BF800000
	s_nop 0                                                    // 0000001BBFFC: BF800000
	ds_load_b32 v5, v3                                         // 0000001BC000: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001BC008: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001BC010: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001BC014: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001BC018: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001BC020: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001BC024: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001BC028: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001BC030: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001BC034: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001BC03C: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001BC044: 917E017E
	s_cbranch_execnz 65517                                     // 0000001BC048: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7500>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001BC04C: 8C7E017E
	s_branch 58366                                             // 0000001BC050: BFA0E3FE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x54c>
	ds_load_b32 v65, v139                                      // 0000001BC054: D8D80000 4100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC05C: BF89FC07
	v_fma_f32 v25, v25, v65, v57                               // 0000001BC060: D6130019 04E68319
	v_mad_u64_u32 v[65:66], null, 0x3000, v172, v[108:109]     // 0000001BC068: D6FE7C41 05B358FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC074: BF870092
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 0000001BC078: 103232FF 3B800000
	v_bfe_u32 v57, v25, 16, 1                                  // 0000001BC080: D6100039 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC088: BF870001
	v_add3_u32 v25, v25, v57, 0x7fff                           // 0000001BC08C: D6550019 03FE7319 00007FFF
	global_store_d16_hi_b16 v[65:66], v25, off                 // 0000001BC098: DC960000 007C1941
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC0A0: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001BC0A4: BE8E200D
	s_cbranch_execz 64580                                      // 0000001BC0A8: BFA5FC44 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66bc>
	ds_load_b32 v25, v139 offset:8                             // 0000001BC0AC: D8D80008 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC0B4: BF89FC07
	v_fma_f32 v25, v26, v25, v58                               // 0000001BC0B8: D6130019 04EA331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC0C0: BF870121
	v_mul_f32_e32 v57, 0x3b800000, v25                         // 0000001BC0C4: 107232FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v179, v[108:109]     // 0000001BC0CC: D6FE7C19 05B366FF 00003000
	v_bfe_u32 v58, v57, 16, 1                                  // 0000001BC0D8: D610003A 02052139
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC0E0: BF870001
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000001BC0E4: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[25:26], v57, off                 // 0000001BC0F0: DC960000 007C3919
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC0F8: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001BC0FC: BE8E200C
	s_cbranch_execz 64561                                      // 0000001BC100: BFA5FC31 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66c8>
	ds_load_b32 v25, v139 offset:16                            // 0000001BC104: D8D80010 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC10C: BF89FC07
	v_fma_f32 v25, v27, v25, v59                               // 0000001BC110: D6130019 04EE331B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC118: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001BC11C: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v178, v[108:109]     // 0000001BC124: D6FE7C19 05B364FF 00003000
	v_bfe_u32 v57, v27, 16, 1                                  // 0000001BC130: D6100039 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC138: BF870001
	v_add3_u32 v27, v27, v57, 0x7fff                           // 0000001BC13C: D655001B 03FE731B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001BC148: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC150: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001BC154: BE8E200B
	s_cbranch_execz 64542                                      // 0000001BC158: BFA5FC1E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66d4>
	ds_load_b32 v25, v139 offset:24                            // 0000001BC15C: D8D80018 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC164: BF89FC07
	v_fma_f32 v25, v28, v25, v60                               // 0000001BC168: D6130019 04F2331C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC170: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001BC174: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v177, v[108:109]     // 0000001BC17C: D6FE7C19 05B362FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001BC188: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC190: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001BC194: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001BC1A0: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC1A8: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001BC1AC: BE8E2009
	s_cbranch_execz 64523                                      // 0000001BC1B0: BFA5FC0B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66e0>
	ds_load_b32 v25, v139 offset:32                            // 0000001BC1B4: D8D80020 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC1BC: BF89FC07
	v_fma_f32 v25, v29, v25, v61                               // 0000001BC1C0: D6130019 04F6331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC1C8: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001BC1CC: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v176, v[108:109]     // 0000001BC1D4: D6FE7C19 05B360FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001BC1E0: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC1E8: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001BC1EC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001BC1F8: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC200: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001BC204: BE8E2001
	s_cbranch_execz 64504                                      // 0000001BC208: BFA5FBF8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66ec>
	ds_load_b32 v25, v139 offset:40                            // 0000001BC20C: D8D80028 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC214: BF89FC07
	v_fma_f32 v25, v30, v25, v62                               // 0000001BC218: D6130019 04FA331E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC220: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001BC224: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v175, v[108:109]     // 0000001BC22C: D6FE7C19 05B35EFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001BC238: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC240: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001BC244: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001BC250: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC258: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001BC25C: BE8E2008
	s_cbranch_execz 64485                                      // 0000001BC260: BFA5FBE5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66f8>
	ds_load_b32 v25, v139 offset:48                            // 0000001BC264: D8D80030 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC26C: BF89FC07
	v_fma_f32 v25, v31, v25, v63                               // 0000001BC270: D6130019 04FE331F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC278: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001BC27C: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v174, v[108:109]     // 0000001BC284: D6FE7C19 05B35CFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001BC290: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC298: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001BC29C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001BC2A8: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC2B0: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001BC2B4: BE8E2000
	s_cbranch_execz 64466                                      // 0000001BC2B8: BFA5FBD2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6704>
	ds_load_b32 v25, v139 offset:56                            // 0000001BC2BC: D8D80038 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC2C4: BF89FC07
	v_fma_f32 v25, v32, v25, v64                               // 0000001BC2C8: D6130019 05023320
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC2D0: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001BC2D4: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v173, v[108:109]     // 0000001BC2DC: D6FE7C19 05B35AFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001BC2E8: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC2F0: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001BC2F4: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001BC300: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC308: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001BC30C: BE8E200A
	s_cbranch_execz 64447                                      // 0000001BC310: BFA5FBBF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6710>
	ds_load_b32 v25, v139                                      // 0000001BC314: D8D80000 1900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC31C: BF89FC07
	v_fma_f32 v9, v9, v25, v49                                 // 0000001BC320: D6130009 04C63309
	v_mad_u64_u32 v[25:26], null, 0x3000, v172, v[108:109]     // 0000001BC328: D6FE7C19 05B358FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC334: BF870092
	v_mul_f32_e32 v9, 0x3b800000, v9                           // 0000001BC338: 101212FF 3B800000
	v_bfe_u32 v27, v9, 16, 1                                   // 0000001BC340: D610001B 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC348: BF870001
	v_add3_u32 v9, v9, v27, 0x7fff                             // 0000001BC34C: D6550009 03FE3709 00007FFF
	global_store_d16_hi_b16 v[25:26], v9, off offset:32        // 0000001BC358: DC960020 007C0919
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC360: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001BC364: BE8E200D
	s_cbranch_execz 64428                                      // 0000001BC368: BFA5FBAC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x671c>
	ds_load_b32 v9, v139 offset:8                              // 0000001BC36C: D8D80008 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC374: BF89FC07
	v_fma_f32 v9, v10, v9, v50                                 // 0000001BC378: D6130009 04CA130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC380: BF870121
	v_mul_f32_e32 v25, 0x3b800000, v9                          // 0000001BC384: 103212FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v179, v[108:109]      // 0000001BC38C: D6FE7C09 05B366FF 00003000
	v_bfe_u32 v26, v25, 16, 1                                  // 0000001BC398: D610001A 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC3A0: BF870001
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000001BC3A4: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[9:10], v25, off offset:32        // 0000001BC3B0: DC960020 007C1909
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC3B8: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001BC3BC: BE8E200C
	s_cbranch_execz 64409                                      // 0000001BC3C0: BFA5FB99 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6728>
	ds_load_b32 v9, v139 offset:16                             // 0000001BC3C4: D8D80010 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC3CC: BF89FC07
	v_fma_f32 v9, v11, v9, v51                                 // 0000001BC3D0: D6130009 04CE130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC3D8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001BC3DC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v178, v[108:109]      // 0000001BC3E4: D6FE7C09 05B364FF 00003000
	v_bfe_u32 v25, v11, 16, 1                                  // 0000001BC3F0: D6100019 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC3F8: BF870001
	v_add3_u32 v11, v11, v25, 0x7fff                           // 0000001BC3FC: D655000B 03FE330B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001BC408: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC410: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001BC414: BE8E200B
	s_cbranch_execz 64390                                      // 0000001BC418: BFA5FB86 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6734>
	ds_load_b32 v9, v139 offset:24                             // 0000001BC41C: D8D80018 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC424: BF89FC07
	v_fma_f32 v9, v12, v9, v52                                 // 0000001BC428: D6130009 04D2130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC430: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001BC434: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v177, v[108:109]      // 0000001BC43C: D6FE7C09 05B362FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001BC448: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC450: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001BC454: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001BC460: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC468: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001BC46C: BE8E2009
	s_cbranch_execz 64371                                      // 0000001BC470: BFA5FB73 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6740>
	ds_load_b32 v9, v139 offset:32                             // 0000001BC474: D8D80020 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC47C: BF89FC07
	v_fma_f32 v9, v13, v9, v53                                 // 0000001BC480: D6130009 04D6130D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC488: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001BC48C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v176, v[108:109]      // 0000001BC494: D6FE7C09 05B360FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001BC4A0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC4A8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001BC4AC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001BC4B8: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC4C0: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001BC4C4: BE8E2001
	s_cbranch_execz 64352                                      // 0000001BC4C8: BFA5FB60 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x674c>
	ds_load_b32 v9, v139 offset:40                             // 0000001BC4CC: D8D80028 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC4D4: BF89FC07
	v_fma_f32 v9, v14, v9, v54                                 // 0000001BC4D8: D6130009 04DA130E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC4E0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001BC4E4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v175, v[108:109]      // 0000001BC4EC: D6FE7C09 05B35EFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001BC4F8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC500: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001BC504: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001BC510: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC518: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001BC51C: BE8E2008
	s_cbranch_execz 64333                                      // 0000001BC520: BFA5FB4D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6758>
	ds_load_b32 v9, v139 offset:48                             // 0000001BC524: D8D80030 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC52C: BF89FC07
	v_fma_f32 v9, v15, v9, v55                                 // 0000001BC530: D6130009 04DE130F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC538: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001BC53C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v174, v[108:109]      // 0000001BC544: D6FE7C09 05B35CFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001BC550: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC558: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001BC55C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001BC568: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC570: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001BC574: BE8E2000
	s_cbranch_execz 64314                                      // 0000001BC578: BFA5FB3A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6764>
	ds_load_b32 v9, v139 offset:56                             // 0000001BC57C: D8D80038 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC584: BF89FC07
	v_fma_f32 v9, v16, v9, v56                                 // 0000001BC588: D6130009 04E21310
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC590: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001BC594: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v173, v[108:109]      // 0000001BC59C: D6FE7C09 05B35AFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001BC5A8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC5B0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001BC5B4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001BC5C0: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC5C8: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001BC5CC: BE8E200A
	s_cbranch_execz 64295                                      // 0000001BC5D0: BFA5FB27 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6770>
	ds_load_b32 v9, v139                                       // 0000001BC5D4: D8D80000 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC5DC: BF89FC07
	v_fma_f32 v9, v17, v9, v41                                 // 0000001BC5E0: D6130009 04A61311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC5E8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001BC5EC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v172, v[108:109]      // 0000001BC5F4: D6FE7C09 05B358FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001BC600: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC608: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001BC60C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001BC618: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC620: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 0000001BC624: BE8E200D
	s_cbranch_execz 64276                                      // 0000001BC628: BFA5FB14 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x677c>
	ds_load_b32 v9, v139 offset:8                              // 0000001BC62C: D8D80008 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC634: BF89FC07
	v_fma_f32 v9, v18, v9, v42                                 // 0000001BC638: D6130009 04AA1312
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC640: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001BC644: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v179, v[108:109]      // 0000001BC64C: D6FE7C09 05B366FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001BC658: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC660: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001BC664: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001BC670: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC678: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 0000001BC67C: BE8E200C
	s_cbranch_execz 64257                                      // 0000001BC680: BFA5FB01 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6788>
	ds_load_b32 v9, v139 offset:16                             // 0000001BC684: D8D80010 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC68C: BF89FC07
	v_fma_f32 v9, v19, v9, v43                                 // 0000001BC690: D6130009 04AE1313
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC698: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001BC69C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v178, v[108:109]      // 0000001BC6A4: D6FE7C09 05B364FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001BC6B0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC6B8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001BC6BC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001BC6C8: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC6D0: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 0000001BC6D4: BE8E200B
	s_cbranch_execz 64238                                      // 0000001BC6D8: BFA5FAEE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6794>
	ds_load_b32 v9, v139 offset:24                             // 0000001BC6DC: D8D80018 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC6E4: BF89FC07
	v_fma_f32 v9, v20, v9, v44                                 // 0000001BC6E8: D6130009 04B21314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC6F0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001BC6F4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v177, v[108:109]      // 0000001BC6FC: D6FE7C09 05B362FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001BC708: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC710: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001BC714: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001BC720: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC728: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 0000001BC72C: BE8E2009
	s_cbranch_execz 64219                                      // 0000001BC730: BFA5FADB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67a0>
	ds_load_b32 v9, v139 offset:32                             // 0000001BC734: D8D80020 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC73C: BF89FC07
	v_fma_f32 v9, v21, v9, v45                                 // 0000001BC740: D6130009 04B61315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC748: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001BC74C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v176, v[108:109]      // 0000001BC754: D6FE7C09 05B360FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001BC760: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC768: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001BC76C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001BC778: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC780: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 0000001BC784: BE8E2001
	s_cbranch_execz 64200                                      // 0000001BC788: BFA5FAC8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67ac>
	ds_load_b32 v9, v139 offset:40                             // 0000001BC78C: D8D80028 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC794: BF89FC07
	v_fma_f32 v9, v22, v9, v46                                 // 0000001BC798: D6130009 04BA1316
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC7A0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001BC7A4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v175, v[108:109]      // 0000001BC7AC: D6FE7C09 05B35EFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001BC7B8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC7C0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001BC7C4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001BC7D0: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC7D8: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 0000001BC7DC: BE8E2008
	s_cbranch_execz 64181                                      // 0000001BC7E0: BFA5FAB5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67b8>
	ds_load_b32 v9, v139 offset:48                             // 0000001BC7E4: D8D80030 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC7EC: BF89FC07
	v_fma_f32 v9, v23, v9, v47                                 // 0000001BC7F0: D6130009 04BE1317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC7F8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001BC7FC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v174, v[108:109]      // 0000001BC804: D6FE7C09 05B35CFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001BC810: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC818: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001BC81C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001BC828: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC830: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 0000001BC834: BE8E2000
	s_cbranch_execz 64162                                      // 0000001BC838: BFA5FAA2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67c4>
	ds_load_b32 v9, v139 offset:56                             // 0000001BC83C: D8D80038 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC844: BF89FC07
	v_fma_f32 v9, v24, v9, v48                                 // 0000001BC848: D6130009 04C21318
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC850: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001BC854: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v173, v[108:109]      // 0000001BC85C: D6FE7C09 05B35AFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001BC868: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC870: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001BC874: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001BC880: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC888: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 0000001BC88C: BE8E200A
	s_cbranch_execz 64143                                      // 0000001BC890: BFA5FA8F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67d0>
	ds_load_b32 v9, v139                                       // 0000001BC894: D8D80000 0900008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC89C: BF89FC07
	v_fma_f32 v1, v1, v9, v33                                  // 0000001BC8A0: D6130001 04861301
	v_mad_u64_u32 v[9:10], null, 0x3000, v172, v[108:109]      // 0000001BC8A8: D6FE7C09 05B358FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC8B4: BF870092
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 0000001BC8B8: 100202FF 3B800000
	v_bfe_u32 v11, v1, 16, 1                                   // 0000001BC8C0: D610000B 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC8C8: BF870001
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001BC8CC: D6550001 03FE1701 00007FFF
	global_store_d16_hi_b16 v[9:10], v1, off offset:96         // 0000001BC8D8: DC960060 007C0109
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001BC8E0: 8C7E0E7E
	s_and_saveexec_b32 s10, s13                                // 0000001BC8E4: BE8A200D
	s_cbranch_execz 64124                                      // 0000001BC8E8: BFA5FA7C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67dc>
	ds_load_b32 v1, v139 offset:8                              // 0000001BC8EC: D8D80008 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC8F4: BF89FC07
	v_fma_f32 v1, v2, v1, v34                                  // 0000001BC8F8: D6130001 048A0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC900: BF870121
	v_mul_f32_e32 v9, 0x3b800000, v1                           // 0000001BC904: 101202FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v179, v[108:109]       // 0000001BC90C: D6FE7C01 05B366FF 00003000
	v_bfe_u32 v10, v9, 16, 1                                   // 0000001BC918: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC920: BF870001
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000001BC924: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[1:2], v9, off offset:96          // 0000001BC930: DC960060 007C0901
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001BC938: 8C7E0A7E
	s_and_saveexec_b32 s10, s12                                // 0000001BC93C: BE8A200C
	s_cbranch_execz 64105                                      // 0000001BC940: BFA5FA69 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67e8>
	ds_load_b32 v1, v139 offset:16                             // 0000001BC944: D8D80010 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC94C: BF89FC07
	v_fma_f32 v1, v3, v1, v35                                  // 0000001BC950: D6130001 048E0303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC958: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001BC95C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v178, v[108:109]       // 0000001BC964: D6FE7C01 05B364FF 00003000
	v_bfe_u32 v9, v3, 16, 1                                    // 0000001BC970: D6100009 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC978: BF870001
	v_add3_u32 v3, v3, v9, 0x7fff                              // 0000001BC97C: D6550003 03FE1303 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001BC988: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001BC990: 8C7E0A7E
	s_and_saveexec_b32 s10, s11                                // 0000001BC994: BE8A200B
	s_cbranch_execz 64086                                      // 0000001BC998: BFA5FA56 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67f4>
	ds_load_b32 v1, v139 offset:24                             // 0000001BC99C: D8D80018 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC9A4: BF89FC07
	v_fma_f32 v1, v4, v1, v36                                  // 0000001BC9A8: D6130001 04920304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC9B0: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001BC9B4: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v177, v[108:109]       // 0000001BC9BC: D6FE7C01 05B362FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001BC9C8: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC9D0: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001BC9D4: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001BC9E0: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001BC9E8: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 0000001BC9EC: BE8A2009
	s_cbranch_execz 64067                                      // 0000001BC9F0: BFA5FA43 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6800>
	ds_load_b32 v1, v139 offset:32                             // 0000001BC9F4: D8D80020 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BC9FC: BF89FC07
	v_fma_f32 v1, v5, v1, v37                                  // 0000001BCA00: D6130001 04960305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCA08: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001BCA0C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v176, v[108:109]       // 0000001BCA14: D6FE7C01 05B360FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001BCA20: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BCA28: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001BCA2C: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001BCA38: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001BCA40: 8C7E0A7E
	s_and_saveexec_b32 s9, s1                                  // 0000001BCA44: BE892001
	s_cbranch_execz 64048                                      // 0000001BCA48: BFA5FA30 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x680c>
	ds_load_b32 v1, v139 offset:40                             // 0000001BCA4C: D8D80028 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BCA54: BF89FC07
	v_fma_f32 v1, v6, v1, v38                                  // 0000001BCA58: D6130001 049A0306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCA60: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001BCA64: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v175, v[108:109]       // 0000001BCA6C: D6FE7C01 05B35EFF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001BCA78: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BCA80: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001BCA84: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001BCA90: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s9                              // 0000001BCA98: 8C7E097E
	s_and_saveexec_b32 s1, s8                                  // 0000001BCA9C: BE812008
	s_cbranch_execz 64029                                      // 0000001BCAA0: BFA5FA1D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6818>
	ds_load_b32 v1, v139 offset:48                             // 0000001BCAA4: D8D80030 0100008B
	s_waitcnt lgkmcnt(0)                                       // 0000001BCAAC: BF89FC07
	v_fma_f32 v1, v7, v1, v39                                  // 0000001BCAB0: D6130001 049E0307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCAB8: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001BCABC: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v174, v[108:109]       // 0000001BCAC4: D6FE7C01 05B35CFF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001BCAD0: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BCAD8: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001BCADC: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001BCAE8: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001BCAF0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000001BCAF4: BE812000
	s_cbranch_execnz 64010                                     // 0000001BCAF8: BFA6FA0A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6824>
	s_branch 64027                                             // 0000001BCAFC: BFA0FA1B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x686c>
	v_dual_mov_b32 v1, s34 :: v_dual_mov_b32 v2, s35           // 0000001BCB00: CA100022 01020023
	v_mov_b32_e32 v6, v119                                     // 0000001BCB08: 7E0C0377
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCB0C: BF870092
	.long 0xd7006a00                                           // 0000001BCB10: D7006A00
	v_cndmask_b32_e32 v0, v1, v18, vcc_lo                      // 0000001BCB14: 02002501
	v_add_co_ci_u32_e64 v1, null, s19, v2, vcc_lo              // 0000001BCB18: D5207C01 01AA0413
	s_add_u32 s0, s33, s20                                     // 0000001BCB20: 80001421
	s_addc_u32 s1, s15, s21                                    // 0000001BCB24: 8201150F
	.long 0xd7006a00                                           // 0000001BCB28: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000001BCB2C: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001BCB30: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000001BCB34: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000001BCB3C: BE810080
	.long 0xd7006a00                                           // 0000001BCB40: D7006A00
	v_cndmask_b32_e32 v1, v0, v106, vcc_lo                     // 0000001BCB44: 0202D500
	v_add_co_ci_u32_e64 v1, null, v1, v107, vcc_lo             // 0000001BCB48: D5207C01 01AAD701
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCB50: BF870092
	.long 0xd7006a00                                           // 0000001BCB54: D7006A00
	v_cndmask_b32_e32 v1, v0, v118, vcc_lo                     // 0000001BCB58: 0202ED00
	v_add_co_ci_u32_e64 v1, null, v1, v129, vcc_lo             // 0000001BCB5C: D5207C01 01AB0301
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCB64: BF870092
	.long 0xd7006a00                                           // 0000001BCB68: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000001BCB6C: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000001BCB70: D5207C01 01AA0211
	s_nop 0                                                    // 0000001BCB78: BF800000
	s_nop 0                                                    // 0000001BCB7C: BF800000
	ds_load_b32 v2, v123                                       // 0000001BCB80: D8D80000 0200007B
	v_add_nc_u32_e32 v6, 0x80, v6                              // 0000001BCB88: 4A0C0CFF 00000080
	v_add_nc_u32_e32 v123, 8, v123                             // 0000001BCB90: 4AF6F688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001BCB94: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v6                        // 0000001BCB98: 7C920CFF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001BCBA0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001BCBA4: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000001BCBA8: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000001BCBB0: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 0000001BCBB4: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000001BCBBC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001BCBC4: 917E017E
	s_cbranch_execnz 65517                                     // 0000001BCBC8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8080>
	s_nop 0                                                    // 0000001BCBCC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001BCBD0: BFB60003
	s_endpgm                                                   // 0000001BCBD4: BFB00000
		...

