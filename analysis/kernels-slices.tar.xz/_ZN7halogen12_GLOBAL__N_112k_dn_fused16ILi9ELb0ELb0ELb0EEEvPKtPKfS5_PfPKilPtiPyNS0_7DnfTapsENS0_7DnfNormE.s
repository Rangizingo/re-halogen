0000000000051100 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE>:
; _ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE():
	s_clause 0x1                                               // 000000051100: BF850001
	s_load_b256 s[20:27], s[0:1], 0x20                         // 000000051104: F40C0500 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 00000005110C: F40C0200 F8000000
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 5, v0       // 000000051114: CA220080 02020085
	s_ashr_i32 s3, s2, 31                                      // 00000005111C: 86039F02
	s_mov_b32 s28, 0                                           // 000000051120: BE9C0080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000051124: BF870001
	v_and_b32_e32 v3, 0x200, v3                                // 000000051128: 360606FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 000000051130: BF89FC07
	s_load_b32 s16, s[20:21], null                             // 000000051134: F400040A F8000000
	v_readfirstlane_b32 s20, v0                                // 00000005113C: 7E280500
	s_lshl_b64 s[4:5], s[22:23], 2                             // 000000051140: 84848216
	s_lshr_b32 s21, s20, 5                                     // 000000051144: 85158514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000051148: BF8704D9
	s_lshl_b32 s33, s21, 4                                     // 00000005114C: 84218415
	s_add_u32 s4, s14, s4                                      // 000000051150: 8004040E
	v_and_or_b32 v1, v0, 15, s33                               // 000000051154: D6570001 00851F00
	s_addc_u32 s5, s15, s5                                     // 00000005115C: 8205050F
	s_lshl_b64 s[6:7], s[2:3], 16                              // 000000051160: 84869002
	s_add_u32 s4, s4, s6                                       // 000000051164: 80040604
	s_delay_alu instid0(VALU_DEP_1)                            // 000000051168: BF870001
	.long 0xd73c0001                                           // 00000005116C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000051170: 02020282
	s_addc_u32 s5, s5, s7                                      // 000000051174: 82050705
	s_waitcnt lgkmcnt(0)                                       // 000000051178: BF89FC07
	s_mul_i32 s14, s16, 0x9000000                              // 00000005117C: 960EFF10 09000000
	s_mul_hi_i32 s15, s16, 0x9000000                           // 000000051184: 970FFF10 09000000
	s_add_u32 s4, s4, s14                                      // 00000005118C: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000051190: 82050F05
	.long 0xd7006a01                                           // 000000051194: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000051198: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000005119C: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000000511A0: D5207C02 01AA0405
	s_or_b32 s5, s21, s2                                       // 0000000511A8: 8C050215
	.long 0xd7006abb                                           // 0000000511AC: D7006ABB
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000000511B0: 02020701
	v_add_co_ci_u32_e64 v188, null, 0, v2, vcc_lo              // 0000000511B4: D5207CBC 01AA0480
	s_cselect_b32 s38, 0, -1                                   // 0000000511BC: 9826C180
	.long 0xd7006a09                                           // 0000000511C0: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v187, vcc_lo                 // 0000000511C4: 020376FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000511CC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v188, vcc_lo             // 0000000511D0: D5207C0A 01AB7880
	.long 0xd7006a34                                           // 0000000511D8: D7006A34
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000511DC: 0201FFBB
	.long 0x00002000                                           // 0000000511E0: 00002000
	v_add_co_ci_u32_e64 v53, null, 0, v188, vcc_lo             // 0000000511E4: D5207C35 01AB7880
	.long 0xd7006a0d                                           // 0000000511EC: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v187, vcc_lo                 // 0000000511F0: 020376FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000511F8: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v188, vcc_lo             // 0000000511FC: D5207C0E 01AB7880
	.long 0xd7006a0f                                           // 000000051204: D7006A0F
	v_cndmask_b32_e32 v1, 0x3000, v187, vcc_lo                 // 000000051208: 020376FF 00003000
	v_add_co_ci_u32_e64 v16, null, 0, v188, vcc_lo             // 000000051210: D5207C10 01AB7880
	.long 0xd7006a3c                                           // 000000051218: D7006A3C
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000005121C: 0201FFBB
	.long 0x00004000                                           // 000000051220: 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000051224: BF870001
	v_add_co_ci_u32_e64 v61, null, 0, v188, vcc_lo             // 000000051228: D5207C3D 01AB7880
	.long 0xd7006a11                                           // 000000051230: D7006A11
	v_cndmask_b32_e32 v1, 0x4000, v187, vcc_lo                 // 000000051234: 020376FF 00004000
	s_clause 0x7                                               // 00000005123C: BF850007
	global_load_b32 v5, v[187:188], off                        // 000000051240: DC520000 057C00BB
	global_load_b32 v6, v[187:188], off offset:1024            // 000000051248: DC520400 067C00BB
	global_load_b32 v7, v[187:188], off offset:2048            // 000000051250: DC520800 077C00BB
	global_load_b32 v8, v[187:188], off offset:3072            // 000000051258: DC520C00 087C00BB
	global_load_b32 v2, v[9:10], off offset:1024               // 000000051260: DC520400 027C0009
	global_load_b32 v3, v[9:10], off offset:2048               // 000000051268: DC520800 037C0009
	global_load_b32 v4, v[9:10], off offset:3072               // 000000051270: DC520C00 047C0009
	global_load_b32 v1, v[13:14], off offset:1024              // 000000051278: DC520400 017C000D
	v_add_co_ci_u32_e64 v18, null, 0, v188, vcc_lo             // 000000051280: D5207C12 01AB7880
	s_clause 0x7                                               // 000000051288: BF850007
	global_load_b32 v12, v[13:14], off offset:2048             // 00000005128C: DC520800 0C7C000D
	global_load_b32 v13, v[13:14], off offset:3072             // 000000051294: DC520C00 0D7C000D
	global_load_b32 v9, v[15:16], off offset:1024              // 00000005129C: DC520400 097C000F
	global_load_b32 v10, v[15:16], off offset:2048             // 0000000512A4: DC520800 0A7C000F
	global_load_b32 v11, v[15:16], off offset:3072             // 0000000512AC: DC520C00 0B7C000F
	global_load_b32 v14, v[17:18], off offset:1024             // 0000000512B4: DC520400 0E7C0011
	global_load_b32 v15, v[17:18], off offset:2048             // 0000000512BC: DC520800 0F7C0011
	global_load_b32 v16, v[17:18], off offset:3072             // 0000000512C4: DC520C00 107C0011
	.long 0xd7006a11                                           // 0000000512CC: D7006A11
	v_cndmask_b32_e32 v1, 0x5000, v187, vcc_lo                 // 0000000512D0: 020376FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000512D8: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v188, vcc_lo             // 0000000512DC: D5207C12 01AB7880
	.long 0xd7006a41                                           // 0000000512E4: D7006A41
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000512E8: 0201FFBB
	.long 0x00006000                                           // 0000000512EC: 00006000
	v_add_co_ci_u32_e64 v66, null, 0, v188, vcc_lo             // 0000000512F0: D5207C42 01AB7880
	.long 0xd7006a17                                           // 0000000512F8: D7006A17
	v_cndmask_b32_e32 v1, 0x6000, v187, vcc_lo                 // 0000000512FC: 020376FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000051304: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v188, vcc_lo             // 000000051308: D5207C18 01AB7880
	.long 0xd7006a19                                           // 000000051310: D7006A19
	v_cndmask_b32_e32 v1, 0x7000, v187, vcc_lo                 // 000000051314: 020376FF 00007000
	v_add_co_ci_u32_e64 v26, null, 0, v188, vcc_lo             // 00000005131C: D5207C1A 01AB7880
	.long 0xd7006a29                                           // 000000051324: D7006A29
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000051328: 0201FFBB
	.long 0x00008000                                           // 00000005132C: 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000051330: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v188, vcc_lo             // 000000051334: D5207C2A 01AB7880
	.long 0xd7006a20                                           // 00000005133C: D7006A20
	v_cndmask_b32_e32 v1, 0x8000, v187, vcc_lo                 // 000000051340: 020376FF 00008000
	v_add_co_ci_u32_e64 v33, null, 0, v188, vcc_lo             // 000000051348: D5207C21 01AB7880
	.long 0xd7006a22                                           // 000000051350: D7006A22
	v_cndmask_b32_e32 v1, 0x9000, v187, vcc_lo                 // 000000051354: 020376FF 00009000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005135C: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v188, vcc_lo             // 000000051360: D5207C23 01AB7880
	.long 0xd7006a2b                                           // 000000051368: D7006A2B
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000005136C: 0201FFBB
	.long 0x0000a000                                           // 000000051370: 0000A000
	v_add_co_ci_u32_e64 v44, null, 0, v188, vcc_lo             // 000000051374: D5207C2C 01AB7880
	.long 0xd7006a25                                           // 00000005137C: D7006A25
	v_cndmask_b32_e32 v1, 0xa000, v187, vcc_lo                 // 000000051380: 020376FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000051388: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v188, vcc_lo             // 00000005138C: D5207C26 01AB7880
	.long 0xd7006a27                                           // 000000051394: D7006A27
	v_cndmask_b32_e32 v1, 0xb000, v187, vcc_lo                 // 000000051398: 020376FF 0000B000
	v_add_co_ci_u32_e64 v40, null, 0, v188, vcc_lo             // 0000000513A0: D5207C28 01AB7880
	.long 0xd7006a2d                                           // 0000000513A8: D7006A2D
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000513AC: 0201FFBB
	.long 0x0000c000                                           // 0000000513B0: 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000513B4: BF8700A1
	v_add_co_ci_u32_e64 v46, null, 0, v188, vcc_lo             // 0000000513B8: D5207C2E 01AB7880
	.long 0xd7006a2f                                           // 0000000513C0: D7006A2F
	v_cndmask_b32_e32 v1, 0xc000, v187, vcc_lo                 // 0000000513C4: 020376FF 0000C000
	v_add_co_ci_u32_e64 v48, null, 0, v188, vcc_lo             // 0000000513CC: D5207C30 01AB7880
	.long 0xd7006a36                                           // 0000000513D4: D7006A36
	v_cndmask_b32_e32 v1, 0xd000, v187, vcc_lo                 // 0000000513D8: 020376FF 0000D000
	s_clause 0x17                                              // 0000000513E0: BF850017
	global_load_b32 v20, v[17:18], off offset:1024             // 0000000513E4: DC520400 147C0011
	global_load_b32 v21, v[17:18], off offset:2048             // 0000000513EC: DC520800 157C0011
	global_load_b32 v22, v[17:18], off offset:3072             // 0000000513F4: DC520C00 167C0011
	global_load_b32 v17, v[23:24], off offset:1024             // 0000000513FC: DC520400 117C0017
	global_load_b32 v18, v[23:24], off offset:2048             // 000000051404: DC520800 127C0017
	global_load_b32 v19, v[23:24], off offset:3072             // 00000005140C: DC520C00 137C0017
	global_load_b32 v23, v[25:26], off offset:1024             // 000000051414: DC520400 177C0019
	global_load_b32 v24, v[25:26], off offset:2048             // 00000005141C: DC520800 187C0019
	global_load_b32 v31, v[25:26], off offset:3072             // 000000051424: DC520C00 1F7C0019
	global_load_b32 v28, v[32:33], off offset:1024             // 00000005142C: DC520400 1C7C0020
	global_load_b32 v29, v[32:33], off offset:2048             // 000000051434: DC520800 1D7C0020
	global_load_b32 v30, v[32:33], off offset:3072             // 00000005143C: DC520C00 1E7C0020
	global_load_b32 v25, v[34:35], off offset:1024             // 000000051444: DC520400 197C0022
	global_load_b32 v26, v[34:35], off offset:2048             // 00000005144C: DC520800 1A7C0022
	global_load_b32 v27, v[34:35], off offset:3072             // 000000051454: DC520C00 1B7C0022
	global_load_b32 v32, v[37:38], off offset:1024             // 00000005145C: DC520400 207C0025
	global_load_b32 v36, v[37:38], off offset:2048             // 000000051464: DC520800 247C0025
	global_load_b32 v37, v[37:38], off offset:3072             // 00000005146C: DC520C00 257C0025
	global_load_b32 v33, v[39:40], off offset:1024             // 000000051474: DC520400 217C0027
	global_load_b32 v34, v[39:40], off offset:2048             // 00000005147C: DC520800 227C0027
	global_load_b32 v35, v[39:40], off offset:3072             // 000000051484: DC520C00 237C0027
	global_load_b32 v38, v[47:48], off offset:1024             // 00000005148C: DC520400 267C002F
	global_load_b32 v39, v[47:48], off offset:2048             // 000000051494: DC520800 277C002F
	global_load_b32 v40, v[47:48], off offset:3072             // 00000005149C: DC520C00 287C002F
	v_add_co_ci_u32_e64 v55, null, 0, v188, vcc_lo             // 0000000514A4: D5207C37 01AB7880
	.long 0xd7006a2f                                           // 0000000514AC: D7006A2F
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000514B0: 0201FFBB
	.long 0x0000e000                                           // 0000000514B4: 0000E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000514B8: BF8700A1
	v_add_co_ci_u32_e64 v48, null, 0, v188, vcc_lo             // 0000000514BC: D5207C30 01AB7880
	.long 0xd7006a3e                                           // 0000000514C4: D7006A3E
	v_cndmask_b32_e32 v1, 0xe000, v187, vcc_lo                 // 0000000514C8: 020376FF 0000E000
	v_add_co_ci_u32_e64 v63, null, 0, v188, vcc_lo             // 0000000514D0: D5207C3F 01AB7880
	.long 0xd7006a43                                           // 0000000514D8: D7006A43
	v_cndmask_b32_e32 v1, 0xf000, v187, vcc_lo                 // 0000000514DC: 020376FF 0000F000
	s_clause 0x7                                               // 0000000514E4: BF850007
	global_load_b32 v51, v[41:42], off offset:-4096            // 0000000514E8: DC521000 337C0029
	global_load_b32 v58, v[41:42], off                         // 0000000514F0: DC520000 3A7C0029
	global_load_b32 v50, v[43:44], off offset:-4096            // 0000000514F8: DC521000 327C002B
	global_load_b32 v56, v[43:44], off                         // 000000051500: DC520000 387C002B
	global_load_b32 v44, v[45:46], off offset:-4096            // 000000051508: DC521000 2C7C002D
	global_load_b32 v43, v[45:46], off                         // 000000051510: DC520000 2B7C002D
	global_load_b32 v42, v[47:48], off offset:-4096            // 000000051518: DC521000 2A7C002F
	global_load_b32 v41, v[47:48], off                         // 000000051520: DC520000 297C002F
	v_add_co_ci_u32_e64 v68, null, 0, v188, vcc_lo             // 000000051528: D5207C44 01AB7880
	s_clause 0xf                                               // 000000051530: BF85000F
	global_load_b32 v48, v[54:55], off offset:1024             // 000000051534: DC520400 307C0036
	global_load_b32 v49, v[54:55], off offset:2048             // 00000005153C: DC520800 317C0036
	global_load_b32 v55, v[54:55], off offset:3072             // 000000051544: DC520C00 377C0036
	global_load_b32 v45, v[62:63], off offset:1024             // 00000005154C: DC520400 2D7C003E
	global_load_b32 v46, v[62:63], off offset:2048             // 000000051554: DC520800 2E7C003E
	global_load_b32 v47, v[62:63], off offset:3072             // 00000005155C: DC520C00 2F7C003E
	global_load_b32 v57, v[67:68], off                         // 000000051564: DC520000 397C0043
	global_load_b32 v59, v[67:68], off offset:1024             // 00000005156C: DC520400 3B7C0043
	global_load_b32 v54, v[52:53], off offset:-4096            // 000000051574: DC521000 367C0034
	global_load_b32 v64, v[52:53], off                         // 00000005157C: DC520000 407C0034
	global_load_b32 v53, v[60:61], off offset:-4096            // 000000051584: DC521000 357C003C
	global_load_b32 v63, v[60:61], off                         // 00000005158C: DC520000 3F7C003C
	global_load_b32 v52, v[65:66], off offset:-4096            // 000000051594: DC521000 347C0041
	global_load_b32 v62, v[65:66], off                         // 00000005159C: DC520000 3E7C0041
	global_load_b32 v60, v[67:68], off offset:2048             // 0000000515A4: DC520800 3C7C0043
	global_load_b32 v61, v[67:68], off offset:3072             // 0000000515AC: DC520C00 3D7C0043
	v_lshlrev_b32_e32 v65, 3, v0                               // 0000000515B4: 30820083
	s_cbranch_scc1 1                                           // 0000000515B8: BFA20001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4c0>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 0000000515BC: BE9C4D83
	s_load_b32 s39, s[0:1], 0x38                               // 0000000515C0: F40009C0 F8000038
	v_lshrrev_b32_e32 v69, 4, v0                               // 0000000515C8: 328A0084
	s_mul_hi_i32 s4, s2, 0x55555556                            // 0000000515CC: 9704FF02 55555556
	v_and_b32_e32 v67, 0x78, v65                               // 0000000515D4: 368682FF 00000078
	s_lshr_b32 s14, s4, 31                                     // 0000000515DC: 850E9F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000515E0: BF870499
	s_add_i32 s4, s4, s14                                      // 0000000515E4: 81040E04
	s_lshl_b32 s14, s4, 7                                      // 0000000515E8: 840E8704
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000515EC: BF870001
	v_lshlrev_b32_e32 v67, 1, v67                              // 0000000515F0: 30868681
	s_ashr_i32 s15, s14, 31                                    // 0000000515F4: 860F9F0E
	s_mov_b32 s4, exec_lo                                      // 0000000515F8: BE84007E
	s_lshl_b64 s[14:15], s[14:15], 1                           // 0000000515FC: 848E810E
	s_waitcnt lgkmcnt(0)                                       // 000000051600: BF89FC07
	s_add_i32 s40, s39, -1                                     // 000000051604: 8128C127
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051608: BF870099
	v_min_i32_e32 v66, s40, v69                                // 00000005160C: 22848A28
	v_mad_i64_i32 v[65:66], null, 0x5000, v66, s[8:9]          // 000000051610: D6FF7C41 002284FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005161C: BF870091
	.long 0xd7006a41                                           // 000000051620: D7006A41
	v_cndmask_b32_e32 v0, v65, v14, vcc_lo                     // 000000051624: 02001D41
	v_add_co_ci_u32_e64 v66, null, s15, v66, vcc_lo            // 000000051628: D5207C42 01AA840F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051630: BF870092
	.long 0xd7006a41                                           // 000000051634: D7006A41
	v_cndmask_b32_e32 v1, v65, v67, vcc_lo                     // 000000051638: 02028741
	v_add_co_ci_u32_e64 v66, null, 0, v66, vcc_lo              // 00000005163C: D5207C42 01AA8480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051644: BF870092
	.long 0xd7006a43                                           // 000000051648: D7006A43
	v_cndmask_b32_e32 v1, 0x1000, v65, vcc_lo                  // 00000005164C: 020282FF 00001000
	v_add_co_ci_u32_e64 v68, null, 0, v66, vcc_lo              // 000000051654: D5207C44 01AA8480
	s_clause 0x1                                               // 00000005165C: BF850001
	global_load_b128 v[74:77], v[65:66], off                   // 000000051660: DC5E0000 4A7C0041
	global_load_b128 v[78:81], v[67:68], off                   // 000000051668: DC5E0000 4E7C0043
	.long 0xd4c3007e                                           // 000000051670: D4C3007E
	v_cndmask_b32_e32 v1, s39, v69, vcc_lo                     // 000000051674: 02028A27
	s_cbranch_execz 11                                         // 000000051678: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5a8>
	s_waitcnt vmcnt(1)                                         // 00000005167C: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 000000051680: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000051684: BF870001
	v_mov_b32_e32 v75, v76                                     // 000000051688: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 00000005168C: 7E94034C
	s_waitcnt vmcnt(0)                                         // 000000051690: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 000000051694: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 000000051698: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 00000005169C: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 0000000516A0: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 0000000516A4: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000516A8: 8C7E047E
	v_cmp_gt_u32_e32 vcc_lo, 16, v0                            // 0000000516AC: 7C980090
	.long 0xd4440004                                           // 0000000516B0: D4440004
	v_cndmask_b32_e32 v1, s39, v0, vcc_lo                      // 0000000516B4: 02020027
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v140, 0            // 0000000516B8: CA100080 418C0080
	s_and_b32 s16, vcc_lo, s4                                  // 0000000516C0: 8B10046A
	scratch_store_b32 off, v65, off                            // 0000000516C4: DC690000 007C4100
	s_and_saveexec_b32 s4, s16                                 // 0000000516CC: BE842010
	s_cbranch_execz 30                                         // 0000000516D0: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x64c>
	v_mul_u32_u24_e32 v65, 0xc0, v0                            // 0000000516D4: 168200FF 000000C0
	s_lshl_b64 s[16:17], s[2:3], 2                             // 0000000516DC: 84908202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000516E0: BF870091
	.long 0xd7001242                                           // 0000000516E4: D7001242
	v_cndmask_b32_e32 v1, s10, v65, vcc_lo                     // 0000000516E8: 0202820A
	v_add_co_ci_u32_e64 v67, null, s11, 0, s18                 // 0000000516EC: D5207C43 0049000B
	.long 0xd7001244                                           // 0000000516F4: D7001244
	v_cndmask_b32_e32 v1, s12, v65, vcc_lo                     // 0000000516F8: 0202820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000516FC: BF870211
	v_add_co_ci_u32_e64 v69, null, s13, 0, s18                 // 000000051700: D5207C45 0049000D
	.long 0xd7006a41                                           // 000000051708: D7006A41
	v_cndmask_b32_e32 v0, v66, v16, vcc_lo                     // 00000005170C: 02002142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000051710: BF870211
	v_add_co_ci_u32_e64 v66, null, s17, v67, vcc_lo            // 000000051714: D5207C42 01AA8611
	.long 0xd7006a43                                           // 00000005171C: D7006A43
	v_cndmask_b32_e32 v0, v68, v16, vcc_lo                     // 000000051720: 02002144
	s_delay_alu instid0(VALU_DEP_1)                            // 000000051724: BF870001
	v_add_co_ci_u32_e64 v68, null, s17, v69, vcc_lo            // 000000051728: D5207C44 01AA8A11
	global_load_b32 v140, v[65:66], off                        // 000000051730: DC520000 8C7C0041
	global_load_b32 v65, v[67:68], off                         // 000000051738: DC520000 417C0043
	s_waitcnt vmcnt(0)                                         // 000000051740: BF8903F7
	scratch_store_b32 off, v65, off                            // 000000051744: DC690000 007C4100
	s_or_b32 exec_lo, exec_lo, s4                              // 00000005174C: 8C7E047E
	s_waitcnt vmcnt(62)                                        // 000000051750: BF89FBF7
	v_dual_mul_f32 v139, 0x43800000, v5 :: v_dual_mul_f32 v138, 0x43800000, v6// 000000051754: C8C60AFF 8B8A0CFF 43800000
	v_dual_mul_f32 v137, 0x43800000, v7 :: v_dual_mul_f32 v136, 0x43800000, v8// 000000051760: C8C60EFF 898810FF 43800000
	s_waitcnt vmcnt(9)                                         // 00000005176C: BF8927F7
	v_dual_mul_f32 v135, 0x43800000, v54 :: v_dual_mul_f32 v54, 0x43800000, v4// 000000051770: C8C66CFF 873608FF 43800000
	v_dual_mul_f32 v134, 0x43800000, v2 :: v_dual_mul_f32 v133, 0x43800000, v3// 00000005177C: C8C604FF 868406FF 43800000
	s_waitcnt vmcnt(8)                                         // 000000051788: BF8923F7
	v_dual_mul_f32 v132, 0x43800000, v64 :: v_dual_mul_f32 v131, 0x43800000, v1// 00000005178C: C8C680FF 848202FF 43800000
	v_dual_mul_f32 v130, 0x43800000, v12 :: v_dual_mul_f32 v129, 0x43800000, v13// 000000051798: C8C618FF 82801AFF 43800000
	s_waitcnt vmcnt(7)                                         // 0000000517A4: BF891FF7
	v_dual_mul_f32 v128, 0x43800000, v53 :: v_dual_mul_f32 v53, 0x43800000, v11// 0000000517A8: C8C66AFF 803416FF 43800000
	v_dual_mul_f32 v127, 0x43800000, v9 :: v_dual_mul_f32 v126, 0x43800000, v10// 0000000517B4: C8C612FF 7F7E14FF 43800000
	s_waitcnt vmcnt(6)                                         // 0000000517C0: BF891BF7
	v_dual_mul_f32 v125, 0x43800000, v63 :: v_dual_mul_f32 v124, 0x43800000, v14// 0000000517C4: C8C67EFF 7D7C1CFF 43800000
	v_dual_mul_f32 v123, 0x43800000, v15 :: v_dual_mul_f32 v122, 0x43800000, v16// 0000000517D0: C8C61EFF 7B7A20FF 43800000
	s_waitcnt vmcnt(5)                                         // 0000000517DC: BF8917F7
	v_dual_mul_f32 v121, 0x43800000, v52 :: v_dual_mul_f32 v52, 0x43800000, v22// 0000000517E0: C8C668FF 79342CFF 43800000
	v_dual_mul_f32 v120, 0x43800000, v20 :: v_dual_mul_f32 v119, 0x43800000, v21// 0000000517EC: C8C628FF 78762AFF 43800000
	s_waitcnt vmcnt(4)                                         // 0000000517F8: BF8913F7
	v_dual_mul_f32 v118, 0x43800000, v62 :: v_dual_mul_f32 v117, 0x43800000, v17// 0000000517FC: C8C67CFF 767422FF 43800000
	v_dual_mul_f32 v116, 0x43800000, v18 :: v_dual_mul_f32 v115, 0x43800000, v19// 000000051808: C8C624FF 747226FF 43800000
	v_dual_mul_f32 v114, 0x43800000, v51 :: v_dual_mul_f32 v111, 0x43800000, v58// 000000051814: C8C666FF 726E74FF 43800000
	v_dual_mul_f32 v113, 0x43800000, v23 :: v_dual_mul_f32 v112, 0x43800000, v24// 000000051820: C8C62EFF 717030FF 43800000
	v_dual_mul_f32 v51, 0x43800000, v31 :: v_dual_mul_f32 v110, 0x43800000, v28// 00000005182C: C8C63EFF 336E38FF 43800000
	v_dual_mul_f32 v109, 0x43800000, v29 :: v_dual_mul_f32 v108, 0x43800000, v30// 000000051838: C8C63AFF 6D6C3CFF 43800000
	v_dual_mul_f32 v107, 0x43800000, v50 :: v_dual_mul_f32 v106, 0x43800000, v25// 000000051844: C8C664FF 6B6A32FF 43800000
	v_dual_mul_f32 v105, 0x43800000, v26 :: v_dual_mul_f32 v50, 0x43800000, v27// 000000051850: C8C634FF 693236FF 43800000
	v_dual_mul_f32 v104, 0x43800000, v56 :: v_dual_mul_f32 v101, 0x43800000, v37// 00000005185C: C8C670FF 68644AFF 43800000
	v_dual_mul_f32 v103, 0x43800000, v32 :: v_dual_mul_f32 v98, 0x43800000, v34// 000000051868: C8C640FF 676244FF 43800000
	v_dual_mul_f32 v102, 0x43800000, v36 :: v_dual_mul_f32 v99, 0x43800000, v33// 000000051874: C8C648FF 666242FF 43800000
	v_dual_mul_f32 v100, 0x43800000, v44 :: v_dual_mul_f32 v97, 0x43800000, v43// 000000051880: C8C658FF 646056FF 43800000
	v_dual_mul_f32 v58, 0x43800000, v35 :: v_dual_mul_f32 v93, 0x43800000, v42// 00000005188C: C8C646FF 3A5C54FF 43800000
	v_dual_mul_f32 v96, 0x43800000, v38 :: v_dual_mul_f32 v95, 0x43800000, v39// 000000051898: C8C64CFF 605E4EFF 43800000
	v_dual_mul_f32 v94, 0x43800000, v40 :: v_dual_mul_f32 v91, 0x43800000, v49// 0000000518A4: C8C650FF 5E5A62FF 43800000
	v_dual_mul_f32 v92, 0x43800000, v48 :: v_dual_mul_f32 v141, 0x43800000, v45// 0000000518B0: C8C660FF 5C8C5AFF 43800000
	v_dual_mul_f32 v152, 0x43800000, v55 :: v_dual_mul_f32 v191, 0x43800000, v57// 0000000518BC: C8C66EFF 98BE72FF 43800000
	v_dual_mul_f32 v90, 0x43800000, v41 :: v_dual_mul_f32 v189, 0x43800000, v59// 0000000518C8: C8C652FF 5ABC76FF 43800000
	s_waitcnt vmcnt(2)                                         // 0000000518D4: BF890BF7
	v_dual_mul_f32 v150, 0x43800000, v46 :: v_dual_mul_f32 v151, 0x43800000, v61// 0000000518D8: C8C65CFF 96967AFF 43800000
	v_mul_f32_e32 v142, 0x43800000, v47                        // 0000000518E4: 111C5EFF 43800000
	v_mul_f32_e32 v190, 0x43800000, v60                        // 0000000518EC: 117C78FF 43800000
	s_cmp_lt_i32 s39, 1                                        // 0000000518F4: BF048127
	s_cbranch_scc1 4711                                        // 0000000518F8: BFA21267 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5198>
	s_add_u32 s30, s8, s14                                     // 0000000518FC: 801E0E08
	s_addc_u32 s31, s9, s15                                    // 000000051900: 821F0F09
	s_lshl_b64 s[14:15], s[2:3], 2                             // 000000051904: 848E8202
	s_load_b64 s[26:27], s[0:1], 0x68                          // 000000051908: F4040680 F8000068
	s_add_u32 s10, s10, s14                                    // 000000051910: 800A0E0A
	s_addc_u32 s11, s11, s15                                   // 000000051914: 820B0F0B
	s_add_u32 s34, s12, s14                                    // 000000051918: 80220E0C
	s_addc_u32 s35, s13, s15                                   // 00000005191C: 82230F0D
	s_add_i32 s3, s39, 15                                      // 000000051920: 81038F27
	s_load_b256 s[12:19], s[0:1], 0x48                         // 000000051924: F40C0300 F8000048
	s_ashr_i32 s4, s3, 31                                      // 00000005192C: 86049F03
	.long 0xd71f008f                                           // 000000051930: D71F008F
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000051934: 020100C1
	s_lshr_b32 s4, s4, 28                                      // 000000051938: 85049C04
	v_mov_b32_e32 v1, 0                                        // 00000005193C: 7E020280
	s_add_i32 s3, s3, s4                                       // 000000051940: 81030403
	v_mov_b32_e32 v149, 0x1000504                              // 000000051944: 7F2A02FF 01000504
	s_waitcnt lgkmcnt(0)                                       // 00000005194C: BF89FC07
	s_ashr_i32 s15, s3, 4                                      // 000000051950: 860F8403
	s_cmp_lg_u32 s21, 0                                        // 000000051954: BF078015
	s_movk_i32 s3, 0x5f40                                      // 000000051958: B0035F40
	s_cselect_b32 s41, -1, 0                                   // 00000005195C: 982980C1
	s_lshl_b32 s22, s2, 7                                      // 000000051960: 84168702
	v_and_b32_e32 v2, 16, v143                                 // 000000051964: 36051E90
	s_ashr_i32 s23, s22, 31                                    // 000000051968: 86179F16
	s_cmp_gt_u32 s20, 63                                       // 00000005196C: BF08BF14
	v_xor_b32_e32 v146, 2, v143                                // 000000051970: 3B251E82
	s_cselect_b32 s42, -1, 0                                   // 000000051974: 982A80C1
	s_cmp_eq_u32 s21, 0                                        // 000000051978: BF068015
	v_add_nc_u32_e32 v144, 16, v2                              // 00000005197C: 4B200490
	s_cselect_b32 s2, -1, 0                                    // 000000051980: 980280C1
	v_xor_b32_e32 v147, 4, v143                                // 000000051984: 3B271E84
	s_and_b32 s4, s2, exec_lo                                  // 000000051988: 8B047E02
	s_cselect_b32 s43, s3, 0x5f80                              // 00000005198C: 982BFF03 00005F80
	s_lshl_b64 s[36:37], s[22:23], 1                           // 000000051994: 84A48116
	v_xor_b32_e32 v148, 8, v143                                // 000000051998: 3B291E88
	s_add_u32 s44, s24, s36                                    // 00000005199C: 802C2418
	s_addc_u32 s45, s25, s37                                   // 0000000519A0: 822D2519
	s_max_i32 s46, s15, 1                                      // 0000000519A4: 8A2E810F
	s_add_u32 s16, s16, s6                                     // 0000000519A8: 80100610
	s_addc_u32 s17, s17, s7                                    // 0000000519AC: 82110711
	s_add_u32 s18, s18, s6                                     // 0000000519B0: 80120612
	s_mov_b32 s20, 0                                           // 0000000519B4: BE940080
	s_addc_u32 s19, s19, s7                                    // 0000000519B8: 82130713
	s_add_u32 s47, s26, s6                                     // 0000000519BC: 802F061A
	s_addc_u32 s7, s27, s7                                     // 0000000519C0: 8207071B
	s_mov_b32 s48, 0x41800000                                  // 0000000519C4: BEB000FF 41800000
	s_movk_i32 s49, 0x1800                                     // 0000000519CC: B0311800
	s_movk_i32 s50, 0x2900                                     // 0000000519D0: B0322900
	s_mov_b32 s21, s20                                         // 0000000519D4: BE950014
	s_mov_b32 s22, s20                                         // 0000000519D8: BE960014
	s_mov_b32 s23, s20                                         // 0000000519DC: BE970014
	s_mov_b32 s24, s20                                         // 0000000519E0: BE980014
	s_mov_b32 s25, s20                                         // 0000000519E4: BE990014
	s_mov_b32 s26, s20                                         // 0000000519E8: BE9A0014
	s_mov_b32 s27, s20                                         // 0000000519EC: BE9B0014
	s_mov_b32 s51, 0x3d800000                                  // 0000000519F0: BEB300FF 3D800000
	s_mov_b32 s52, 0x76543210                                  // 0000000519F8: BEB400FF 76543210
	s_mov_b32 s53, s20                                         // 000000051A00: BEB50014
	s_mov_b32 s6, s20                                          // 000000051A04: BE860014
	s_branch 10                                                // 000000051A08: BFA0000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x934>
	v_mov_b32_e32 v151, v65                                    // 000000051A0C: 7F2E0341
	v_mov_b32_e32 v152, v57                                    // 000000051A10: 7F300339
	v_mov_b32_e32 v58, v49                                     // 000000051A14: 7E740331
	v_mov_b32_e32 v50, v9                                      // 000000051A18: 7E640309
	v_mov_b32_e32 v51, v17                                     // 000000051A1C: 7E660311
	v_mov_b32_e32 v52, v25                                     // 000000051A20: 7E680319
	v_mov_b32_e32 v53, v33                                     // 000000051A24: 7E6A0321
	v_mov_b32_e32 v54, v41                                     // 000000051A28: 7E6C0329
	s_cmp_eq_u32 s53, s46                                      // 000000051A2C: BF062E35
	s_cbranch_scc1 4623                                        // 000000051A30: BFA2120F <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5170>
	v_mov_b32_e32 v44, v0                                      // 000000051A34: 7E580300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000051A38: BF8701B1
	v_ashrrev_i32_e32 v2, 4, v44                               // 000000051A3C: 34045884
	v_and_b32_e32 v55, 15, v44                                 // 000000051A40: 366E588F
	.long 0xd4440003                                           // 000000051A44: D4440003
	v_cndmask_b32_e32 v1, 16, v44, vcc_lo                      // 000000051A48: 02025890
	.long 0xd72c0003                                           // 000000051A4C: D72C0003
	v_cndmask_b32_e32 v1, 0x110, v2, vcc_lo                    // 000000051A50: 020204FF 00000110
	s_delay_alu instid0(VALU_DEP_1)                            // 000000051A58: BF870001
	v_lshl_add_u32 v3, v55, 4, v3                              // 000000051A5C: D6460003 040D0937
	s_waitcnt vmcnt(1)                                         // 000000051A64: BF8907F7
	ds_store_b128 v3, v[74:77] offset:10496                    // 000000051A68: DB7C2900 00004A03
	s_waitcnt vmcnt(0)                                         // 000000051A70: BF8903F7
	ds_store_b128 v3, v[78:81] offset:6144                     // 000000051A74: DB7C1800 00004E03
	s_and_saveexec_b32 s4, s3                                  // 000000051A7C: BE842003
	s_cbranch_execz 6                                          // 000000051A80: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x99c>
	scratch_load_b32 v4, off, off                              // 000000051A84: DC510000 047C0000
	v_lshlrev_b32_e32 v3, 2, v44                               // 000000051A8C: 30065882
	s_waitcnt vmcnt(0)                                         // 000000051A90: BF8903F7
	ds_store_b32 v3, v4 offset:24064                           // 000000051A94: D8345E00 00000403
	s_or_b32 exec_lo, exec_lo, s4                              // 000000051A9C: 8C7E047E
	v_and_b32_e32 v34, 1, v44                                  // 000000051AA0: 36445881
	s_lshl_b32 s54, s53, 4                                     // 000000051AA4: 84368435
	v_or_b32_e32 v153, s33, v55                                // 000000051AA8: 39326E21
	s_mov_b32 s29, exec_lo                                     // 000000051AAC: BE9D007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000051AB0: BF870112
	v_or_b32_e32 v15, s54, v34                                 // 000000051AB4: 381E4436
	v_and_b32_e32 v6, 0x7ffffffe, v153                         // 000000051AB8: 360D32FF 7FFFFFFE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000051AC0: BF870232
	v_min_i32_e32 v3, s40, v15                                 // 000000051AC4: 22061E28
	v_or_b32_e32 v5, 2, v15                                    // 000000051AC8: 380A1E82
	v_or_b32_e32 v7, 4, v15                                    // 000000051ACC: 380E1E84
	v_lshlrev_b32_e32 v19, 1, v6                               // 000000051AD0: 30260C81
	v_or_b32_e32 v8, 6, v15                                    // 000000051AD4: 38101E86
	v_mad_i64_i32 v[3:4], null, 0x5000, v3, s[8:9]             // 000000051AD8: D6FF7C03 002206FF 00005000
	v_min_i32_e32 v5, s40, v5                                  // 000000051AE4: 220A0A28
	v_min_i32_e32 v7, s40, v7                                  // 000000051AE8: 220E0E28
	v_or_b32_e32 v17, 12, v15                                  // 000000051AEC: 38221E8C
	v_min_i32_e32 v8, s40, v8                                  // 000000051AF0: 22101028
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000051AF4: BF8700A4
	v_mad_i64_i32 v[5:6], null, 0x5000, v5, s[8:9]             // 000000051AF8: D6FF7C05 00220AFF 00005000
	.long 0xd7006a09                                           // 000000051B04: D7006A09
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000051B08: 02004903
	v_add_co_ci_u32_e64 v10, null, s37, v4, vcc_lo             // 000000051B0C: D5207C0A 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v7, s[8:9]             // 000000051B14: D6FF7C03 00220EFF 00005000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051B20: BF870093
	.long 0xd7006a07                                           // 000000051B24: D7006A07
	v_cndmask_b32_e32 v1, v9, v19, vcc_lo                      // 000000051B28: 02022709
	v_add_co_ci_u32_e64 v9, null, 0, v10, vcc_lo               // 000000051B2C: D5207C09 01AA1480
	.long 0xd7006a0a                                           // 000000051B34: D7006A0A
	v_cndmask_b32_e32 v0, v5, v36, vcc_lo                      // 000000051B38: 02004905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000051B3C: BF870211
	v_add_co_ci_u32_e64 v11, null, s37, v6, vcc_lo             // 000000051B40: D5207C0B 01AA0C25
	.long 0xd7006a05                                           // 000000051B48: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 000000051B4C: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000051B54: BF870211
	v_add_co_ci_u32_e64 v6, null, 0, v9, vcc_lo                // 000000051B58: D5207C06 01AA1280
	.long 0xd7006a07                                           // 000000051B60: D7006A07
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 000000051B64: 0202270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000051B68: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v11, vcc_lo               // 000000051B6C: D5207C09 01AA1680
	.long 0xd7006a0a                                           // 000000051B74: D7006A0A
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000051B78: 02004903
	v_add_co_ci_u32_e64 v11, null, s37, v4, vcc_lo             // 000000051B7C: D5207C0B 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v8, s[8:9]             // 000000051B84: D6FF7C03 002210FF 00005000
	.long 0xd7006a07                                           // 000000051B90: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 000000051B94: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000051B9C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v9, vcc_lo                // 000000051BA0: D5207C08 01AA1280
	.long 0xd7006a09                                           // 000000051BA8: D7006A09
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 000000051BAC: 0202270A
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo              // 000000051BB0: D5207C0A 01AA1680
	v_or_b32_e32 v11, 8, v15                                   // 000000051BB8: 38161E88
	.long 0xd7006a03                                           // 000000051BBC: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000051BC0: 02004903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000051BC4: BF870191
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 000000051BC8: D5207C04 01AA0825
	v_min_i32_e32 v11, s40, v11                                // 000000051BD0: 22161628
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051BD4: BF870093
	.long 0xd7006a0c                                           // 000000051BD8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000051BDC: 02022703
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 000000051BE0: D5207C0D 01AA0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000051BE8: BF8700A3
	v_mad_i64_i32 v[3:4], null, 0x5000, v11, s[8:9]            // 000000051BEC: D6FF7C03 002216FF 00005000
	.long 0xd7006a09                                           // 000000051BF8: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v9, vcc_lo                   // 000000051BFC: 020212FF 00002000
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 000000051C04: D5207C0A 01AA1480
	.long 0xd7006a0b                                           // 000000051C0C: D7006A0B
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 000000051C10: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000051C18: BF8700B1
	v_add_co_ci_u32_e64 v12, null, 0, v13, vcc_lo              // 000000051C1C: D5207C0C 01AA1A80
	v_or_b32_e32 v13, 10, v15                                  // 000000051C24: 381A1E8A
	.long 0xd7006a03                                           // 000000051C28: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000051C2C: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 000000051C30: D5207C04 01AA0825
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000051C38: BF870193
	v_min_i32_e32 v13, s40, v13                                // 000000051C3C: 221A1A28
	.long 0xd7006a0e                                           // 000000051C40: D7006A0E
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000051C44: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000051C48: BF870191
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 000000051C4C: D5207C10 01AA0880
	v_mad_i64_i32 v[3:4], null, 0x5000, v13, s[8:9]            // 000000051C54: D6FF7C03 00221AFF 00005000
	v_or_b32_e32 v15, 14, v15                                  // 000000051C60: 381E1E8E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051C64: BF870094
	.long 0xd7006a0d                                           // 000000051C68: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v14, vcc_lo                  // 000000051C6C: 02021CFF 00002000
	v_add_co_ci_u32_e64 v14, null, 0, v16, vcc_lo              // 000000051C74: D5207C0E 01AA2080
	v_min_i32_e32 v16, s40, v17                                // 000000051C7C: 22202228
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000051C80: BF8700A4
	v_min_i32_e32 v15, s40, v15                                // 000000051C84: 221E1E28
	.long 0xd7006a11                                           // 000000051C88: D7006A11
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000051C8C: 02004903
	v_add_co_ci_u32_e64 v18, null, s37, v4, vcc_lo             // 000000051C90: D5207C12 01AA0825
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000051C98: BF870194
	v_mad_i64_i32 v[3:4], null, 0x5000, v16, s[8:9]            // 000000051C9C: D6FF7C03 002220FF 00005000
	.long 0xd7006a11                                           // 000000051CA8: D7006A11
	v_cndmask_b32_e32 v1, v17, v19, vcc_lo                     // 000000051CAC: 02022711
	v_mad_i64_i32 v[15:16], null, 0x5000, v15, s[8:9]          // 000000051CB0: D6FF7C0F 00221EFF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000051CBC: BF870194
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 000000051CC0: D5207C12 01AA2480
	.long 0xd7006a11                                           // 000000051CC8: D7006A11
	v_cndmask_b32_e32 v1, 0x2000, v17, vcc_lo                  // 000000051CCC: 020222FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000051CD4: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 000000051CD8: D5207C12 01AA2480
	.long 0xd7006a03                                           // 000000051CE0: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000051CE4: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 000000051CE8: D5207C04 01AA0825
	.long 0xd7006a0f                                           // 000000051CF0: D7006A0F
	v_cndmask_b32_e32 v0, v15, v36, vcc_lo                     // 000000051CF4: 0200490F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000051CF8: BF870211
	v_add_co_ci_u32_e64 v16, null, s37, v16, vcc_lo            // 000000051CFC: D5207C10 01AA2025
	.long 0xd7006a03                                           // 000000051D04: D7006A03
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000051D08: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000051D0C: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000051D10: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 000000051D18: D7006A0F
	v_cndmask_b32_e32 v1, v15, v19, vcc_lo                     // 000000051D1C: 0202270F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000051D20: BF870211
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000051D24: D5207C10 01AA2080
	.long 0xd7006a03                                           // 000000051D2C: D7006A03
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 000000051D30: 020206FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000051D38: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000051D3C: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 000000051D44: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v15, vcc_lo                  // 000000051D48: 02021EFF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000051D50: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000051D54: D5207C10 01AA2080
	s_clause 0x7                                               // 000000051D5C: BF850007
	global_load_b32 v42, v[5:6], off                           // 000000051D60: DC520000 2A7C0005
	global_load_b32 v41, v[7:8], off                           // 000000051D68: DC520000 297C0007
	global_load_b32 v40, v[9:10], off                          // 000000051D70: DC520000 287C0009
	global_load_b32 v39, v[11:12], off                         // 000000051D78: DC520000 277C000B
	global_load_b32 v38, v[13:14], off                         // 000000051D80: DC520000 267C000D
	global_load_b32 v37, v[17:18], off                         // 000000051D88: DC520000 257C0011
	global_load_b32 v35, v[3:4], off                           // 000000051D90: DC520000 237C0003
	global_load_b32 v36, v[15:16], off                         // 000000051D98: DC520000 247C000F
	v_lshlrev_b32_e32 v5, 16, v78                              // 000000051DA0: 300A9C90
	v_and_b32_e32 v4, 0xffff0000, v74                          // 000000051DA4: 360894FF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v75                          // 000000051DAC: 361096FF FFFF0000
	v_lshlrev_b32_e32 v3, 16, v74                              // 000000051DB4: 30069490
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000051DB8: BF8701A4
	v_dual_mul_f32 v5, v5, v5 :: v_dual_lshlrev_b32 v12, 16, v80// 000000051DBC: C8E20B05 050CA090
	v_lshlrev_b32_e32 v7, 16, v75                              // 000000051DC4: 300E9690
	v_dual_mul_f32 v3, v3, v3 :: v_dual_and_b32 v6, 0xffff0000, v78// 000000051DC8: C8E40703 03069CFF FFFF0000
	v_mul_f32_e32 v4, v4, v4                                   // 000000051DD4: 10080904
	v_and_b32_e32 v13, 0xffff0000, v80                         // 000000051DD8: 361AA0FF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v76                         // 000000051DE0: 361498FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000051DE8: BF8701B4
	v_dual_mul_f32 v6, v6, v6 :: v_dual_and_b32 v11, 0xffff0000, v77// 000000051DEC: C8E40D06 060A9AFF FFFF0000
	v_mul_f32_e32 v12, v12, v12                                // 000000051DF8: 1018190C
	v_add_f32_e32 v3, v3, v4                                   // 000000051DFC: 06060903
	v_dual_add_f32 v4, v5, v6 :: v_dual_lshlrev_b32 v9, 16, v76// 000000051E00: C9220D05 04089890
	v_dual_mul_f32 v5, v7, v7 :: v_dual_mul_f32 v6, v8, v8     // 000000051E08: C8C60F07 05061108
	v_lshlrev_b32_e32 v7, 16, v79                              // 000000051E10: 300E9E90
	v_dual_mul_f32 v13, v13, v13 :: v_dual_and_b32 v8, 0xffff0000, v79// 000000051E14: C8E41B0D 0D089EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000051E20: BF870113
	v_dual_add_f32 v5, v5, v6 :: v_dual_and_b32 v14, 0xffff0000, v81// 000000051E24: C9240D05 050EA2FF FFFF0000
	v_dual_mul_f32 v6, v7, v7 :: v_dual_mul_f32 v7, v8, v8     // 000000051E30: C8C60F07 06061108
	v_dual_mul_f32 v8, v9, v9 :: v_dual_mul_f32 v9, v10, v10   // 000000051E38: C8C61309 0808150A
	v_lshlrev_b32_e32 v10, 16, v77                             // 000000051E40: 30149A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000051E44: BF870113
	v_dual_add_f32 v6, v6, v7 :: v_dual_add_f32 v7, v12, v13   // 000000051E48: C9080F06 06061B0C
	v_dual_add_f32 v8, v8, v9 :: v_dual_mul_f32 v9, v10, v10   // 000000051E50: C9061308 0808150A
	v_dual_mul_f32 v10, v11, v11 :: v_dual_lshlrev_b32 v11, 16, v81// 000000051E58: C8E2170B 0A0AA290
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000051E60: BF870113
	v_add_f32_e32 v4, v4, v6                                   // 000000051E64: 06080D04
	v_dual_add_f32 v9, v9, v10 :: v_dual_mul_f32 v10, v11, v11 // 000000051E68: C9061509 090A170B
	v_mul_f32_e32 v11, v14, v14                                // 000000051E70: 10161D0E
	v_add_f32_e32 v3, v3, v5                                   // 000000051E74: 06060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000051E78: BF870123
	v_add_f32_e32 v5, v8, v9                                   // 000000051E7C: 060A1308
	v_xor_b32_e32 v9, 1, v143                                  // 000000051E80: 3A131E81
	v_dual_add_f32 v8, v10, v11 :: v_dual_add_f32 v3, v3, v5   // 000000051E84: C908170A 08020B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000051E8C: BF8701A2
	v_cmp_lt_u32_e32 vcc_lo, v9, v144                          // 000000051E90: 7C932109
	v_cndmask_b32_e32 v9, v143, v9, vcc_lo                     // 000000051E94: 0212138F
	v_add_f32_e32 v5, v7, v8                                   // 000000051E98: 060A1107
	v_cmp_lt_u32_e32 vcc_lo, v146, v144                        // 000000051E9C: 7C932192
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000051EA0: BF870193
	v_lshlrev_b32_e32 v6, 2, v9                                // 000000051EA4: 300C1282
	v_dual_add_f32 v4, v4, v5 :: v_dual_cndmask_b32 v7, v143, v146// 000000051EA8: C9120B04 0407258F
	v_cmp_lt_u32_e32 vcc_lo, v147, v144                        // 000000051EB0: 7C932193
	ds_bpermute_b32 v5, v6, v3                                 // 000000051EB4: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 000000051EBC: DACC0000 06000406
	s_waitcnt lgkmcnt(0)                                       // 000000051EC4: BF89FC07
	v_dual_add_f32 v4, v4, v6 :: v_dual_add_f32 v3, v3, v5     // 000000051EC8: C9080D04 04020B03
	v_lshlrev_b32_e32 v5, 2, v7                                // 000000051ED0: 300A0E82
	ds_bpermute_b32 v6, v5, v3                                 // 000000051ED4: DACC0000 06000305
	ds_bpermute_b32 v5, v5, v4                                 // 000000051EDC: DACC0000 05000405
	v_cndmask_b32_e32 v7, v143, v147, vcc_lo                   // 000000051EE4: 020F278F
	v_cmp_lt_u32_e32 vcc_lo, v148, v144                        // 000000051EE8: 7C932194
	s_waitcnt lgkmcnt(0)                                       // 000000051EEC: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v5     // 000000051EF0: C9080D03 03040B04
	s_delay_alu instid0(VALU_DEP_3)                            // 000000051EF8: BF870003
	v_dual_cndmask_b32 v7, v143, v148 :: v_dual_lshlrev_b32 v6, 2, v7// 000000051EFC: CA63298F 07060E82
	ds_bpermute_b32 v5, v6, v3                                 // 000000051F04: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 000000051F0C: DACC0000 06000406
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000051F14: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 000000051F18: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 000000051F1C: C9080B03 03040D04
	ds_bpermute_b32 v5, v7, v3                                 // 000000051F24: DACC0000 05000307
	ds_bpermute_b32 v6, v7, v4                                 // 000000051F2C: DACC0000 06000407
	v_cmpx_eq_u32_e32 0, v55                                   // 000000051F34: 7D946E80
	s_cbranch_execz 41                                         // 000000051F38: BFA50029 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xee0>
	s_waitcnt lgkmcnt(0)                                       // 000000051F3C: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 000000051F40: C9080B03 03040D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051F48: BF870091
	v_dual_add_f32 v3, 0x358637bd, v3 :: v_dual_add_f32 v4, 0x358637bd, v4// 000000051F4C: C90806FF 030408FF 358637BD
	v_dual_mul_f32 v5, 0x4b800000, v3 :: v_dual_mul_f32 v6, 0x4b800000, v4// 000000051F58: C8C606FF 050608FF 4B800000
	.long 0xd4140004                                           // 000000051F64: D4140004
	v_cndmask_b32_e32 v1, 0x800000, v4, vcc_lo                 // 000000051F68: 020208FF 00800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v3                      // 000000051F70: 7C2806FF 00800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051F78: BF870092
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 000000051F7C: D5010004 00120D04
	v_rsq_f32_e32 v4, v4                                       // 000000051F84: 7E085D04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051F88: BF870095
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_mul_f32 v6, 0x45800000, v4// 000000051F8C: CA460B03 030608FF 45800000
	v_rsq_f32_e32 v3, v3                                       // 000000051F98: 7E065D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000051F9C: BF870321
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 000000051FA0: D5010004 00120D04
	v_rsq_f32_e32 v6, 0x43000000                               // 000000051FA8: 7E0C5CFF 43000000
	v_mul_f32_e32 v5, 0x45800000, v3                           // 000000051FB0: 100A06FF 45800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000051FB8: BF870001
	v_cndmask_b32_e32 v3, v3, v5, vcc_lo                       // 000000051FBC: 02060B03
	v_lshlrev_b32_e32 v5, 2, v2                                // 000000051FC0: 300A0482
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 000000051FC4: BF870105
	v_mul_f32_e32 v3, v6, v3                                   // 000000051FC8: 10060706
	s_delay_alu instid0(VALU_DEP_2)                            // 000000051FCC: BF870002
	v_add_nc_u32_e32 v5, 0x5c00, v5                            // 000000051FD0: 4A0A0AFF 00005C00
	ds_store_2addr_b32 v5, v4, v3 offset0:208 offset1:224      // 000000051FD8: D838E0D0 00030405
	s_or_b32 exec_lo, exec_lo, s29                             // 000000051FE0: 8C7E1D7E
	v_and_b32_e32 v43, 31, v44                                 // 000000051FE4: 3656589F
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 000000051FE8: 916A027E
	s_cbranch_vccnz 119                                        // 000000051FEC: BFA40077 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10cc>
	.long 0xd7600045                                           // 000000051FF0: D7600045
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                   // 000000051FF4: 0201018C
	.long 0xd7600044                                           // 000000051FF8: D7600044
	v_cndmask_b32_e32 v0, v140, v129, vcc_lo                   // 000000051FFC: 0201038C
	.long 0xd7600043                                           // 000000052000: D7600043
	v_cndmask_b32_e32 v0, v140, v130, vcc_lo                   // 000000052004: 0201058C
	.long 0xd7600042                                           // 000000052008: D7600042
	v_cndmask_b32_e32 v0, v140, v131, vcc_lo                   // 00000005200C: 0201078C
	.long 0xd7600041                                           // 000000052010: D7600041
	v_cndmask_b32_e32 v0, v140, v132, vcc_lo                   // 000000052014: 0201098C
	.long 0xd7600040                                           // 000000052018: D7600040
	v_cndmask_b32_e32 v0, v140, v133, vcc_lo                   // 00000005201C: 02010B8C
	.long 0xd760003f                                           // 000000052020: D760003F
	v_cndmask_b32_e32 v0, v140, v134, vcc_lo                   // 000000052024: 02010D8C
	.long 0xd760003e                                           // 000000052028: D760003E
	v_cndmask_b32_e32 v0, v140, v135, vcc_lo                   // 00000005202C: 02010F8C
	.long 0xd760003d                                           // 000000052030: D760003D
	v_cndmask_b32_e32 v0, v140, v136, vcc_lo                   // 000000052034: 0201118C
	.long 0xd760003c                                           // 000000052038: D760003C
	v_cndmask_b32_e32 v0, v140, v137, vcc_lo                   // 00000005203C: 0201138C
	.long 0xd760003b                                           // 000000052040: D760003B
	v_cndmask_b32_e32 v0, v140, v138, vcc_lo                   // 000000052044: 0201158C
	.long 0xd760003a                                           // 000000052048: D760003A
	v_cndmask_b32_e32 v0, v140, v139, vcc_lo                   // 00000005204C: 0201178C
	.long 0xd7600039                                           // 000000052050: D7600039
	v_cndmask_b32_e32 v0, v140, v140, vcc_lo                   // 000000052054: 0201198C
	.long 0xd7600038                                           // 000000052058: D7600038
	v_cndmask_b32_e32 v0, v140, v141, vcc_lo                   // 00000005205C: 02011B8C
	.long 0xd7600037                                           // 000000052060: D7600037
	v_cndmask_b32_e32 v0, v140, v142, vcc_lo                   // 000000052064: 02011D8C
	.long 0xd760001d                                           // 000000052068: D760001D
	v_cndmask_b32_e32 v0, v140, v143, vcc_lo                   // 00000005206C: 02011F8C
	s_mov_b32 s4, exec_lo                                      // 000000052070: BE84007E
	v_cmpx_gt_u32_e32 16, v43                                  // 000000052074: 7D985690
	s_cbranch_execz 83                                         // 000000052078: BFA50053 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10c8>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000005207C: 7C945680
	s_add_f32 s69, s69, 0                                      // 000000052080: A0458045
	v_lshlrev_b32_e32 v4, 2, v43                               // 000000052084: 30085682
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000052088: BF8704BA
	s_add_f32 s68, s69, s68                                    // 00000005208C: A0444445
	v_cndmask_b32_e64 v3, 0, s69, vcc_lo                       // 000000052090: D5010003 01A88A80
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 000000052098: 7C945681
	s_add_f32 s67, s68, s67                                    // 00000005209C: A0434344
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000520A0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s68, vcc_lo                      // 0000000520A4: D5010003 01A88903
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 0000000520AC: 7C945682
	s_add_f32 s66, s67, s66                                    // 0000000520B0: A0424243
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000520B4: BF8704A2
	v_cndmask_b32_e64 v3, v3, s67, vcc_lo                      // 0000000520B8: D5010003 01A88703
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 0000000520C0: 7C945683
	s_add_f32 s65, s66, s65                                    // 0000000520C4: A0414142
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000520C8: BF8704A2
	v_cndmask_b32_e64 v3, v3, s66, vcc_lo                      // 0000000520CC: D5010003 01A88503
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 0000000520D4: 7C945684
	s_add_f32 s64, s65, s64                                    // 0000000520D8: A0404041
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000520DC: BF8704A2
	v_cndmask_b32_e64 v3, v3, s65, vcc_lo                      // 0000000520E0: D5010003 01A88303
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 0000000520E8: 7C945685
	s_add_f32 s63, s64, s63                                    // 0000000520EC: A03F3F40
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000520F0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s64, vcc_lo                      // 0000000520F4: D5010003 01A88103
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 0000000520FC: 7C945686
	s_add_f32 s62, s63, s62                                    // 000000052100: A03E3E3F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000052104: BF8704A2
	v_cndmask_b32_e64 v3, v3, s63, vcc_lo                      // 000000052108: D5010003 01A87F03
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 000000052110: 7C945687
	s_add_f32 s61, s62, s61                                    // 000000052114: A03D3D3E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000052118: BF8704A2
	v_cndmask_b32_e64 v3, v3, s62, vcc_lo                      // 00000005211C: D5010003 01A87D03
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 000000052124: 7C945688
	s_add_f32 s60, s61, s60                                    // 000000052128: A03C3C3D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005212C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s61, vcc_lo                      // 000000052130: D5010003 01A87B03
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 000000052138: 7C945689
	s_add_f32 s59, s60, s59                                    // 00000005213C: A03B3B3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000052140: BF8704A2
	v_cndmask_b32_e64 v3, v3, s60, vcc_lo                      // 000000052144: D5010003 01A87903
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000005214C: 7C94568A
	s_add_f32 s58, s59, s58                                    // 000000052150: A03A3A3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000052154: BF8704A2
	v_cndmask_b32_e64 v3, v3, s59, vcc_lo                      // 000000052158: D5010003 01A87703
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 000000052160: 7C94568B
	s_add_f32 s57, s58, s57                                    // 000000052164: A039393A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000052168: BF8704A2
	v_cndmask_b32_e64 v3, v3, s58, vcc_lo                      // 00000005216C: D5010003 01A87503
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 000000052174: 7C94568C
	s_add_f32 s56, s57, s56                                    // 000000052178: A0383839
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005217C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s57, vcc_lo                      // 000000052180: D5010003 01A87303
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 000000052188: 7C94568D
	s_add_f32 s55, s56, s55                                    // 00000005218C: A0373738
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000052190: BF8704A2
	v_cndmask_b32_e64 v3, v3, s56, vcc_lo                      // 000000052194: D5010003 01A87103
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 00000005219C: 7C94568E
	s_add_f32 s29, s55, s29                                    // 0000000521A0: A01D1D37
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000521A4: BF870002
	v_cndmask_b32_e64 v3, v3, s55, vcc_lo                      // 0000000521A8: D5010003 01A86F03
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 0000000521B0: 7C94568F
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000000521B4: BF870482
	v_cndmask_b32_e64 v3, v3, s29, vcc_lo                      // 0000000521B8: D5010003 01A83B03
	ds_store_b32 v4, v3 offset:24128                           // 0000000521C0: D8345E40 00000304
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000521C8: 8C7E047E
	s_add_i32 s53, s53, 1                                      // 0000000521CC: 81358135
	s_waitcnt lgkmcnt(0)                                       // 0000000521D0: BF89FC07
	s_barrier                                                  // 0000000521D4: BFBD0000
	s_cmp_ge_i32 s53, s15                                      // 0000000521D8: BF030F35
	s_cbranch_scc1 71                                          // 0000000521DC: BFA20047 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11fc>
	s_lshl_b32 s4, s53, 4                                      // 0000000521E0: 84048435
	v_lshlrev_b32_e32 v4, 4, v44                               // 0000000521E4: 30085884
	s_waitcnt lgkmcnt(0)                                       // 0000000521E8: BF89FC07
	v_add_nc_u32_e32 v6, s4, v2                                // 0000000521EC: 4A0C0404
	s_mov_b32 s29, exec_lo                                     // 0000000521F0: BE9D007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000521F4: BF870112
	v_and_b32_e32 v4, 0xf0, v4                                 // 0000000521F8: 360808FF 000000F0
	v_min_i32_e32 v2, s40, v6                                  // 000000052200: 22040C28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052204: BF870091
	v_mad_i64_i32 v[2:3], null, 0x5000, v2, s[30:31]           // 000000052208: D6FF7C02 007A04FF 00005000
	.long 0xd7006a02                                           // 000000052214: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000052218: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005221C: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000052220: D5207C03 01AA0680
	.long 0xd7006a04                                           // 000000052228: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000005222C: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000052234: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000052238: D5207C05 01AA0680
	s_clause 0x1                                               // 000000052240: BF850001
	global_load_b128 v[74:77], v[2:3], off                     // 000000052244: DC5E0000 4A7C0002
	global_load_b128 v[78:81], v[4:5], off                     // 00000005224C: DC5E0000 4E7C0004
	.long 0xd4c3007e                                           // 000000052254: D4C3007E
	v_cndmask_b32_e32 v1, s39, v6, vcc_lo                      // 000000052258: 02020C27
	s_cbranch_execz 11                                         // 00000005225C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x118c>
	s_waitcnt vmcnt(1)                                         // 000000052260: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 000000052264: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000052268: BF870001
	v_mov_b32_e32 v75, v76                                     // 00000005226C: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 000000052270: 7E94034C
	s_waitcnt vmcnt(0)                                         // 000000052274: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 000000052278: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 00000005227C: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 000000052280: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 000000052284: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 000000052288: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s29                             // 00000005228C: 8C7E1D7E
	s_and_saveexec_b32 s29, s3                                 // 000000052290: BE9D2003
	s_cbranch_execz 23                                         // 000000052294: BFA50017 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11f4>
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, s4, v44      // 000000052298: CA200080 03025804
	v_mov_b32_e32 v140, 0                                      // 0000000522A0: 7F180280
	s_mov_b32 s3, exec_lo                                      // 0000000522A4: BE83007E
	scratch_store_b32 off, v3, off                             // 0000000522A8: DC690000 007C0300
	.long 0xd4c4007e                                           // 0000000522B0: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 0000000522B4: 02020427
	s_cbranch_execz 13                                         // 0000000522B8: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11f0>
	v_mad_i64_i32 v[3:4], null, 0xc0, v2, s[10:11]             // 0000000522BC: D6FF7C03 002A04FF 000000C0
	v_mad_i64_i32 v[5:6], null, 0xc0, v2, s[34:35]             // 0000000522C8: D6FF7C05 008A04FF 000000C0
	global_load_b32 v140, v[3:4], off                          // 0000000522D4: DC520000 8C7C0003
	global_load_b32 v2, v[5:6], off                            // 0000000522DC: DC520000 027C0005
	s_waitcnt vmcnt(0)                                         // 0000000522E4: BF8903F7
	scratch_store_b32 off, v2, off                             // 0000000522E8: DC690000 007C0200
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000522F0: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000522F4: BF870009
	s_or_b32 exec_lo, exec_lo, s29                             // 0000000522F8: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000522FC: BF870009
	s_and_b32 vcc_lo, exec_lo, s42                             // 000000052300: 8B6A2A7E
	s_mov_b32 s3, -1                                           // 000000052304: BE8300C1
	s_cbranch_vccz 81                                          // 000000052308: BFA30051 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1350>
	v_and_b32_e32 v2, -16, v44                                 // 00000005230C: 360458D0
	s_mov_b32 s3, exec_lo                                      // 000000052310: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000052314: BF870001
	v_cmpx_eq_u32_e32 64, v2                                   // 000000052318: 7D9404C0
	s_cbranch_execz 74                                         // 00000005231C: BFA5004A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1348>
	v_lshlrev_b32_e32 v4, 2, v44                               // 000000052320: 30085882
	s_waitcnt lgkmcnt(1)                                       // 000000052324: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000052328: BF870001
	v_add_nc_u32_e32 v5, 0x5c00, v4                            // 00000005232C: 4A0A08FF 00005C00
	ds_load_2addr_b32 v[2:3], v5 offset0:64 offset1:80         // 000000052334: D8DC5040 02000005
	s_waitcnt lgkmcnt(1)                                       // 00000005233C: BF89FC17
	ds_load_b32 v6, v1 offset:24188                            // 000000052340: D8D85E7C 06000001
	s_waitcnt lgkmcnt(1)                                       // 000000052348: BF89FC17
	v_mul_f32_e32 v7, 0x3fb8aa3b, v3                           // 00000005234C: 100E06FF 3FB8AA3B
	ds_load_b32 v8, v4 offset:24128                            // 000000052354: D8D85E40 08000004
	s_waitcnt lgkmcnt(1)                                       // 00000005235C: BF89FC17
	v_sub_f32_e32 v6, v6, v3                                   // 000000052360: 080C0706
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000052364: 7C3606FF C2CE8ED0
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v7                          // 00000005236C: D6130009 841E06FF 3FB8AA3B
	v_rndne_f32_e32 v10, v7                                    // 000000052378: 7E144707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005237C: BF870114
	v_mul_f32_e32 v11, 0x3fb8aa3b, v6                          // 000000052380: 10160CFF 3FB8AA3B
	v_sub_f32_e32 v7, v7, v10                                  // 000000052388: 080E1507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000005238C: BF8701C2
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v11                        // 000000052390: D613000C 842E0CFF 3FB8AA3B
	v_fmac_f32_e32 v9, 0x32a5705f, v3                          // 00000005239C: 561206FF 32A5705F
	v_cvt_i32_f32_e32 v10, v10                                 // 0000000523A4: 7E14110A
	v_rndne_f32_e32 v13, v11                                   // 0000000523A8: 7E1A470B
	v_dual_fmac_f32 v12, 0x32a5705f, v6 :: v_dual_add_f32 v7, v7, v9// 0000000523AC: C8080CFF 0C061307 32A5705F
	s_waitcnt lgkmcnt(0)                                       // 0000000523B8: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000523BC: BF870112
	v_dual_sub_f32 v9, v11, v13 :: v_dual_mul_f32 v2, v8, v2   // 0000000523C0: C9461B0B 09020508
	v_exp_f32_e32 v7, v7                                       // 0000000523C8: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000523CC: BF870125
	.long 0xd71c0007                                           // 0000000523D0: D71C0007
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 0000000523D4: 02021507
	v_cvt_i32_f32_e32 v10, v13                                 // 0000000523D8: 7E14110D
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 0000000523DC: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 0000000523E0: 7C3C06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000523E8: BF8701B2
	v_cndmask_b32_e32 v3, 0x7f800000, v7, vcc_lo               // 0000000523EC: 02060EFF 7F800000
	v_add_f32_e32 v9, v9, v12                                  // 0000000523F4: 06121909
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 0000000523F8: 7C360CFF C2CE8ED0
	v_mul_f32_e32 v2, v3, v2                                   // 000000052400: 10040503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052404: BF870093
	v_exp_f32_e32 v9, v9                                       // 000000052408: 7E124B09
	v_mul_f32_e32 v2, 0x41800000, v2                           // 00000005240C: 100404FF 41800000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052414: BF870095
	.long 0xd71c0009                                           // 000000052418: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000005241C: 02021509
	v_cndmask_b32_e32 v7, 0, v9, vcc_lo                        // 000000052420: 020E1280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 000000052424: 7C3C0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000005242C: BF870002
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 000000052430: 020C0EFF 7F800000
	ds_store_b32 v4, v3 offset:24064                           // 000000052438: D8345E00 00000304
	ds_store_2addr_b32 v5, v6, v2 offset0:96 offset1:112       // 000000052440: D8387060 00020605
	s_or_b32 exec_lo, exec_lo, s3                              // 000000052448: 8C7E037E
	s_mov_b32 s3, 0                                            // 00000005244C: BE830080
	v_lshrrev_b32_e32 v154, 4, v43                             // 000000052450: 33345684
	v_mul_u32_u24_e32 v57, 0x110, v55                          // 000000052454: 16726EFF 00000110
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 00000005245C: 916A037E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000052460: BF870002
	v_lshlrev_b32_e32 v56, 2, v154                             // 000000052464: 30713482
	s_cbranch_vccnz 872                                        // 000000052468: BFA40368 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x210c>
	v_mad_u32_u24 v2, 0x110, v55, s49                          // 00000005246C: D60B0002 00C66EFF 00000110
	s_and_b32 s3, s2, exec_lo                                  // 000000052478: 8B037E02
	s_cselect_b32 s3, 0, 0x1100                                // 00000005247C: 9803FF80 00001100
	v_mad_u32_u24 v3, 0x110, v55, s50                          // 000000052484: D60B0003 00CA6EFF 00000110
	ds_load_b128 v[10:13], v57 offset:6144                     // 000000052490: DBFC1800 0A000039
	ds_load_b128 v[14:17], v57 offset:6160                     // 000000052498: DBFC1810 0E000039
	v_add_nc_u32_e32 v4, s3, v2                                // 0000000524A0: 4A080403
	v_mov_b32_e32 v8, v1                                       // 0000000524A4: 7E100301
	s_waitcnt lgkmcnt(3)                                       // 0000000524A8: BF89FC37
	v_mov_b32_e32 v5, v1                                       // 0000000524AC: 7E0A0301
	v_cndmask_b32_e64 v45, v3, v2, s2                          // 0000000524B0: D501002D 000A0503
	v_mov_b32_e32 v3, v1                                       // 0000000524B8: 7E060301
	ds_load_b128 v[18:21], v4                                  // 0000000524BC: DBFC0000 12000004
	ds_load_b128 v[22:25], v4 offset:16                        // 0000000524C4: DBFC0010 16000004
	ds_load_b128 v[26:29], v57 offset:6176                     // 0000000524CC: DBFC1820 1A000039
	ds_load_b128 v[30:33], v57 offset:6192                     // 0000000524D4: DBFC1830 1E000039
	ds_load_b128 v[59:62], v45 offset:32                       // 0000000524DC: DBFC0020 3B00002D
	ds_load_b128 v[63:66], v45 offset:48                       // 0000000524E4: DBFC0030 3F00002D
	ds_load_b128 v[155:158], v45 offset:64                     // 0000000524EC: DBFC0040 9B00002D
	ds_load_b128 v[159:162], v45 offset:80                     // 0000000524F4: DBFC0050 9F00002D
	ds_load_b128 v[167:170], v57 offset:6224                   // 0000000524FC: DBFC1850 A7000039
	ds_load_b128 v[163:166], v57 offset:6208                   // 000000052504: DBFC1840 A3000039
	v_mov_b32_e32 v2, v1                                       // 00000005250C: 7E040301
	v_mov_b32_e32 v4, v1                                       // 000000052510: 7E080301
	s_waitcnt lgkmcnt(12)                                      // 000000052514: BF89FCC7
	v_mov_b32_e32 v6, v1                                       // 000000052518: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000005251C: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 000000052520: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000052524: BF870212
	v_mov_b32_e32 v8, v7                                       // 000000052528: 7E100307
	v_mov_b32_e32 v7, v6                                       // 00000005252C: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 000000052530: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000052534: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000052538: 7E080303
	v_mov_b32_e32 v3, v2                                       // 00000005253C: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000052540: 7E040301
	ds_load_b128 v[175:178], v57 offset:6256                   // 000000052544: DBFC1870 AF000039
	ds_load_b128 v[171:174], v57 offset:6240                   // 00000005254C: DBFC1860 AB000039
	ds_load_b128 v[183:186], v45 offset:112                    // 000000052554: DBFC0070 B700002D
	ds_load_b128 v[179:182], v45 offset:96                     // 00000005255C: DBFC0060 B300002D
	v_or_b32_e32 v49, 6, v154                                  // 000000052564: 38633486
	v_or_b32_e32 v48, 8, v154                                  // 000000052568: 38613488
	v_or_b32_e32 v47, 10, v154                                 // 00000005256C: 385F348A
	s_waitcnt lgkmcnt(12)                                      // 000000052570: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 000000052574: CC414002 1C0A1512
	ds_load_b128 v[14:17], v57 offset:6288                     // 00000005257C: DBFC1890 0E000039
	ds_load_b128 v[10:13], v57 offset:6272                     // 000000052584: DBFC1880 0A000039
	ds_load_b128 v[22:25], v45 offset:144                      // 00000005258C: DBFC0090 1600002D
	ds_load_b128 v[18:21], v45 offset:128                      // 000000052594: DBFC0080 1200002D
	s_and_not1_b32 vcc_lo, exec_lo, s41                        // 00000005259C: 916A297E
	s_mov_b32 s3, -1                                           // 0000000525A0: BE8300C1
	s_waitcnt lgkmcnt(12)                                      // 0000000525A4: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[59:66], v[26:33], v[2:9]// 0000000525A8: CC414002 1C0A353B
	ds_load_b128 v[30:33], v57 offset:6320                     // 0000000525B0: DBFC18B0 1E000039
	ds_load_b128 v[26:29], v57 offset:6304                     // 0000000525B8: DBFC18A0 1A000039
	ds_load_b128 v[65:68], v45 offset:176                      // 0000000525C0: DBFC00B0 4100002D
	ds_load_b128 v[61:64], v45 offset:160                      // 0000000525C8: DBFC00A0 3D00002D
	v_lshlrev_b32_e32 v60, 2, v55                              // 0000000525D0: 30786E82
	v_or_b32_e32 v59, 4, v154                                  // 0000000525D4: 38773484
	s_waitcnt lgkmcnt(12)                                      // 0000000525D8: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[155:162], v[163:170], v[2:9]// 0000000525DC: CC414002 1C0B479B
	ds_load_b128 v[159:162], v57 offset:6352                   // 0000000525E4: DBFC18D0 9F000039
	ds_load_b128 v[155:158], v57 offset:6336                   // 0000000525EC: DBFC18C0 9B000039
	v_add_nc_u32_e32 v46, 64, v60                              // 0000000525F4: 4A5C78C0
	ds_load_b128 v[167:170], v57 offset:6384                   // 0000000525F8: DBFC18F0 A7000039
	ds_load_b128 v[163:166], v57 offset:6368                   // 000000052600: DBFC18E0 A3000039
	s_waitcnt lgkmcnt(12)                                      // 000000052608: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[179:186], v[171:178], v[2:9]// 00000005260C: CC414002 1C0B57B3
	ds_load_b128 v[175:178], v45 offset:208                    // 000000052614: DBFC00D0 AF00002D
	ds_load_b128 v[171:174], v45 offset:192                    // 00000005261C: DBFC00C0 AB00002D
	s_waitcnt lgkmcnt(10)                                      // 000000052624: BF89FCA7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 000000052628: CC414002 1C0A1512
	v_add_nc_u32_e32 v10, 0x5c00, v56                          // 000000052630: 4A1470FF 00005C00
	v_add_nc_u32_e32 v11, s43, v56                             // 000000052638: 4A16702B
	ds_load_b128 v[183:186], v45 offset:240                    // 00000005263C: DBFC00F0 B700002D
	ds_load_b128 v[179:182], v45 offset:224                    // 000000052644: DBFC00E0 B300002D
	ds_load_2addr_stride64_b32 v[12:13], v46 offset0:94 offset1:95// 00000005264C: D8E05F5E 0C00002E
	v_or_b32_e32 v46, 12, v154                                 // 000000052654: 385D348C
	s_waitcnt lgkmcnt(9)                                       // 000000052658: BF89FC97
	v_wmma_f32_16x16x16_bf16 v[2:9], v[61:68], v[26:33], v[2:9]// 00000005265C: CC414002 1C0A353D
	ds_load_2addr_b32 v[28:29], v10 offset0:144 offset1:146    // 000000052664: D8DC9290 1C00000A
	ds_load_2addr_b32 v[24:25], v10 offset0:148 offset1:150    // 00000005266C: D8DC9694 1800000A
	ds_load_2addr_b32 v[20:21], v10 offset0:152 offset1:154    // 000000052674: D8DC9A98 1400000A
	ds_load_2addr_b32 v[16:17], v10 offset0:156 offset1:158    // 00000005267C: D8DC9E9C 1000000A
	ds_load_2addr_b32 v[26:27], v11 offset1:2                  // 000000052684: D8DC0200 1A00000B
	ds_load_2addr_b32 v[22:23], v11 offset0:4 offset1:6        // 00000005268C: D8DC0604 1600000B
	ds_load_2addr_b32 v[18:19], v11 offset0:8 offset1:10       // 000000052694: D8DC0A08 1200000B
	ds_load_2addr_b32 v[14:15], v11 offset0:12 offset1:14      // 00000005269C: D8DC0E0C 0E00000B
	v_or_b32_e32 v61, 2, v154                                  // 0000000526A4: 387B3482
	v_or_b32_e32 v45, 14, v154                                 // 0000000526A8: 385B348E
	s_waitcnt lgkmcnt(11)                                      // 0000000526AC: BF89FCB7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[171:178], v[155:162], v[2:9]// 0000000526B0: CC414002 1C0B37AB
	s_waitcnt lgkmcnt(9)                                       // 0000000526B8: BF89FC97
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000526BC: BF870001
	v_wmma_f32_16x16x16_bf16 v[2:9], v[179:186], v[163:170], v[2:9]// 0000000526C0: CC414002 1C0B47B3
	s_cbranch_vccnz 353                                        // 0000000526C8: BFA40161 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b50>
	.long 0x7e143880                                           // 0000000526CC: 7E143880
	s_mov_b32 s3, exec_lo                                      // 0000000526D0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000526D4: BF870001
	.long 0x7f14390a                                           // 0000000526D8: 7F14390A
	.long 0xd4cb007e                                           // 0000000526DC: D4CB007E
	v_cndmask_b32_e32 v1, v55, v154, vcc_lo                    // 0000000526E0: 02033537
	s_cbranch_execz 34                                         // 0000000526E4: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1670>
	s_waitcnt lgkmcnt(7)                                       // 0000000526E8: BF89FC77
	v_sub_f32_e32 v11, v28, v12                                // 0000000526EC: 0816191C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000526F0: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v11                         // 0000000526F4: 103C16FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v11, -v30                       // 0000000526FC: D613001F 847A16FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 000000052708: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005270C: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v11 :: v_dual_sub_f32 v30, v30, v32// 000000052710: C80A16FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 00000005271C: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 000000052720: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000052724: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005272C: BF870293
	v_exp_f32_e32 v30, v30                                     // 000000052730: 7E3C4B1E
	.long 0xd71c001e                                           // 000000052734: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 000000052738: 02023F1E
	s_waitcnt lgkmcnt(3)                                       // 00000005273C: BF89FC37
	v_mul_f32_e32 v31, v2, v26                                 // 000000052740: 103E3502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052744: BF870122
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 000000052748: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000005274C: 7C3C16FF 42B17218
	v_dual_cndmask_b32 v11, 0x7f800000, v30 :: v_dual_mul_f32 v30, v13, v31// 000000052754: CA463CFF 0B1E3F0D 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052760: BF870091
	v_mul_f32_e32 v11, v11, v30                                // 000000052764: 10163D0B
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 000000052768: CC22000A 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000052770: 8C7E037E
	v_mul_u32_u24_e32 v11, 48, v154                            // 000000052774: 161734B0
	s_mov_b32 s3, exec_lo                                      // 000000052778: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005277C: BF870001
	v_lshl_add_u32 v11, v55, 1, v11                            // 000000052780: D646000B 042D0337
	ds_store_b16_d16_hi v11, v10 offset:23296                  // 000000052788: DA845B00 00000A0B
	.long 0xd4cb007e                                           // 000000052790: D4CB007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 000000052794: 02027B37
	s_cbranch_execz 34                                         // 000000052798: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1724>
	s_waitcnt lgkmcnt(8)                                       // 00000005279C: BF89FC87
	v_sub_f32_e32 v10, v29, v12                                // 0000000527A0: 0814191D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000527A4: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v10                         // 0000000527A8: 103C14FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v30                       // 0000000527B0: D613001F 847A14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 0000000527BC: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000527C0: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v10 :: v_dual_sub_f32 v30, v30, v32// 0000000527C4: C80A14FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 0000000527D0: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 0000000527D4: 7E3E1120
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000527D8: BF870292
	v_exp_f32_e32 v30, v30                                     // 0000000527DC: 7E3C4B1E
	.long 0xd71c001e                                           // 0000000527E0: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 0000000527E4: 02023F1E
	s_waitcnt lgkmcnt(4)                                       // 0000000527E8: BF89FC47
	v_mul_f32_e32 v31, v3, v27                                 // 0000000527EC: 103E3703
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 0000000527F0: 7C3614FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000527F8: BF870123
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 0000000527FC: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000052800: 7C3C14FF 42B17218
	v_cndmask_b32_e32 v10, 0x7f800000, v30, vcc_lo             // 000000052808: 02143CFF 7F800000
	v_mul_f32_e32 v30, v13, v31                                // 000000052810: 103C3F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052814: BF870091
	v_mul_f32_e32 v10, v10, v30                                // 000000052818: 10143D0A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 00000005281C: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000052824: 8C7E037E
	.long 0x7f143880                                           // 000000052828: 7F143880
	v_or_b32_e32 v30, 0x5b00, v11                              // 00000005282C: 383C16FF 00005B00
	s_mov_b32 s3, exec_lo                                      // 000000052834: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000052838: BF870002
	.long 0x7e16398a                                           // 00000005283C: 7E16398A
	ds_store_b16 v30, v10 offset:96                            // 000000052840: D87C0060 00000A1E
	.long 0xd4cb007e                                           // 000000052848: D4CB007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 00000005284C: 02027737
	s_cbranch_execz 35                                         // 000000052850: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x17e0>
	s_waitcnt lgkmcnt(8)                                       // 000000052854: BF89FC87
	v_sub_f32_e32 v11, v24, v12                                // 000000052858: 08161918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005285C: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000052860: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000052868: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000052870: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000005287C: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052880: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000052884: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000052890: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000052894: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000052898: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000005289C: 7E3E4B1F
	.long 0xd71c001f                                           // 0000000528A0: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000000528A4: 0202411F
	s_waitcnt lgkmcnt(4)                                       // 0000000528A8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000528AC: BF870121
	v_dual_mul_f32 v32, v4, v22 :: v_dual_cndmask_b32 v31, 0, v31// 0000000528B0: C8D22D04 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 0000000528B8: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 0000000528C0: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000528C8: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 0000000528CC: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 0000000528D0: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000528D4: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 0000000528D8: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000528E0: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000528E4: BF870009
	s_mov_b32 s3, exec_lo                                      // 0000000528E8: BE83007E
	ds_store_b16 v30, v11 offset:192                           // 0000000528EC: D87C00C0 00000B1E
	.long 0xd4cb007e                                           // 0000000528F4: D4CB007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 0000000528F8: 02026337
	s_cbranch_execz 35                                         // 0000000528FC: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x188c>
	s_waitcnt lgkmcnt(9)                                       // 000000052900: BF89FC97
	v_sub_f32_e32 v10, v25, v12                                // 000000052904: 08141919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052908: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000005290C: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000052914: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000052920: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000052924: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000052928: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000052930: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000052934: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000052938: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000005293C: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000052940: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000052948: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000005294C: BF870135
	.long 0xd71c000b                                           // 000000052950: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000052954: 02023F0B
	s_waitcnt lgkmcnt(5)                                       // 000000052958: BF89FC57
	v_mul_f32_e32 v31, v5, v23                                 // 00000005295C: 103E2F05
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000052960: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000052964: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005296C: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000052970: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000052978: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005297C: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000052980: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 000000052984: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005298C: 8C7E037E
	.long 0x7e143880                                           // 000000052990: 7E143880
	s_mov_b32 s3, exec_lo                                      // 000000052994: BE83007E
	ds_store_b16_d16_hi v30, v10 offset:288                    // 000000052998: DA840120 00000A1E
	.long 0x7e16390a                                           // 0000000529A0: 7E16390A
	.long 0xd4cb007e                                           // 0000000529A4: D4CB007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 0000000529A8: 02026137
	s_cbranch_execz 34                                         // 0000000529AC: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1938>
	s_waitcnt lgkmcnt(9)                                       // 0000000529B0: BF89FC97
	v_sub_f32_e32 v11, v20, v12                                // 0000000529B4: 08161914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000529B8: BF870091
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 0000000529BC: 103E16FF 3FB8AA3B
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 0000000529C4: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 0000000529D0: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000529D4: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 0000000529D8: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 0000000529E4: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 0000000529E8: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000529EC: BF870292
	v_exp_f32_e32 v31, v31                                     // 0000000529F0: 7E3E4B1F
	.long 0xd71c001f                                           // 0000000529F4: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000000529F8: 0202411F
	s_waitcnt lgkmcnt(5)                                       // 0000000529FC: BF89FC57
	v_mul_f32_e32 v32, v6, v18                                 // 000000052A00: 10402506
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000052A04: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052A0C: BF870123
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 000000052A10: 023E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000052A14: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000052A1C: 02163EFF 7F800000
	v_mul_f32_e32 v31, v13, v32                                // 000000052A24: 103E410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052A28: BF870091
	v_mul_f32_e32 v11, v11, v31                                // 000000052A2C: 10163F0B
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 000000052A30: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000052A38: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000052A3C: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000052A40: BE83007E
	ds_store_b16 v30, v11 offset:384                           // 000000052A44: D87C0180 00000B1E
	.long 0xd4cb007e                                           // 000000052A4C: D4CB007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 000000052A50: 02025F37
	s_cbranch_execz 35                                         // 000000052A54: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x19e4>
	s_waitcnt lgkmcnt(10)                                      // 000000052A58: BF89FCA7
	v_sub_f32_e32 v10, v21, v12                                // 000000052A5C: 08141915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052A60: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000052A64: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000052A6C: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000052A78: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000052A7C: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000052A80: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000052A88: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000052A8C: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000052A90: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 000000052A94: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000052A98: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000052AA0: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000052AA4: BF870135
	.long 0xd71c000b                                           // 000000052AA8: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000052AAC: 02023F0B
	s_waitcnt lgkmcnt(6)                                       // 000000052AB0: BF89FC67
	v_mul_f32_e32 v31, v7, v19                                 // 000000052AB4: 103E2707
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000052AB8: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000052ABC: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000052AC4: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000052AC8: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000052AD0: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052AD4: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000052AD8: 1014170A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 000000052ADC: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000052AE4: 8C7E037E
	.long 0x7f143880                                           // 000000052AE8: 7F143880
	s_mov_b32 s3, exec_lo                                      // 000000052AEC: BE83007E
	ds_store_b16 v30, v10 offset:480                           // 000000052AF0: D87C01E0 00000A1E
	.long 0x7e16398a                                           // 000000052AF8: 7E16398A
	.long 0xd4cb007e                                           // 000000052AFC: D4CB007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 000000052B00: 02025D37
	s_cbranch_execz 35                                         // 000000052B04: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1a94>
	s_waitcnt lgkmcnt(10)                                      // 000000052B08: BF89FCA7
	v_sub_f32_e32 v11, v16, v12                                // 000000052B0C: 08161910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052B10: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000052B14: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000052B1C: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000052B24: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 000000052B30: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052B34: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000052B38: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000052B44: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000052B48: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000052B4C: BF870292
	v_exp_f32_e32 v31, v31                                     // 000000052B50: 7E3E4B1F
	.long 0xd71c001f                                           // 000000052B54: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000052B58: 0202411F
	s_waitcnt lgkmcnt(6)                                       // 000000052B5C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052B60: BF870121
	v_dual_mul_f32 v32, v8, v14 :: v_dual_cndmask_b32 v31, 0, v31// 000000052B64: C8D21D08 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000052B6C: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000052B74: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052B7C: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 000000052B80: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 000000052B84: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000052B88: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 000000052B8C: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000052B94: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000052B98: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000052B9C: BE83007E
	ds_store_b16 v30, v11 offset:576                           // 000000052BA0: D87C0240 00000B1E
	.long 0xd4cb007e                                           // 000000052BA8: D4CB007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 000000052BAC: 02025B37
	s_cbranch_execz 35                                         // 000000052BB0: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b40>
	s_waitcnt lgkmcnt(11)                                      // 000000052BB4: BF89FCB7
	v_sub_f32_e32 v10, v17, v12                                // 000000052BB8: 08141911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052BBC: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000052BC0: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000052BC8: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000052BD4: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000052BD8: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000052BDC: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000052BE4: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000052BE8: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000052BEC: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 000000052BF0: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000052BF4: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000052BFC: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000052C00: BF870135
	.long 0xd71c000b                                           // 000000052C04: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000052C08: 02023F0B
	s_waitcnt lgkmcnt(7)                                       // 000000052C0C: BF89FC77
	v_mul_f32_e32 v31, v9, v15                                 // 000000052C10: 103E1F09
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000052C14: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000052C18: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000052C20: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000052C24: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000052C2C: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052C30: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000052C34: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 000000052C38: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000052C40: 8C7E037E
	s_mov_b32 s3, 0                                            // 000000052C44: BE830080
	ds_store_b16_d16_hi v30, v10 offset:672                    // 000000052C48: DA8402A0 00000A1E
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000052C50: 8B6A037E
	s_cbranch_vccz 365                                         // 000000052C54: BFA3016D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x210c>
	v_or_b32_e32 v10, 0x5e40, v56                              // 000000052C58: 381470FF 00005E40
	v_mov_b32_e32 v63, 0                                       // 000000052C60: 7E7E0280
	v_mov_b32_e32 v65, 0                                       // 000000052C64: 7E820280
	s_mov_b32 s3, exec_lo                                      // 000000052C68: BE83007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000052C6C: BF870003
	v_subrev_nc_u32_e32 v64, 64, v10                           // 000000052C70: 4E8014C0
	ds_load_2addr_b32 v[32:33], v64 offset0:2 offset1:4        // 000000052C74: D8DC0402 20000040
	ds_load_2addr_b32 v[30:31], v64 offset0:6 offset1:8        // 000000052C7C: D8DC0806 1E000040
	ds_load_2addr_b32 v[10:11], v64 offset0:10 offset1:12      // 000000052C84: D8DC0C0A 0A000040
	ds_load_b32 v62, v64 offset:56                             // 000000052C8C: D8D80038 3E000040
	.long 0xd4c9007e                                           // 000000052C94: D4C9007E
	v_cndmask_b32_e32 v1, v55, v154, vcc_lo                    // 000000052C98: 02033537
	s_cbranch_execz 37                                         // 000000052C9C: BFA50025 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1c34>
	s_waitcnt lgkmcnt(11)                                      // 000000052CA0: BF89FCB7
	v_sub_f32_e32 v28, v28, v12                                // 000000052CA4: 0838191C
	ds_load_b32 v64, v64                                       // 000000052CA8: D8D80000 40000040
	s_waitcnt lgkmcnt(8)                                       // 000000052CB0: BF89FC87
	v_dual_mul_f32 v2, v2, v26 :: v_dual_mul_f32 v65, 0x3fb8aa3b, v28// 000000052CB4: C8C63502 024038FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000052CC0: BF870111
	v_mul_f32_e32 v2, v13, v2                                  // 000000052CC4: 1004050D
	v_fma_f32 v66, 0x3fb8aa3b, v28, -v65                       // 000000052CC8: D6130042 850638FF 3FB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 000000052CD4: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000052CD8: BF8701C1
	v_dual_sub_f32 v65, v65, v67 :: v_dual_fmac_f32 v66, 0x32a5705f, v28// 000000052CDC: C9408741 414238FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v28                  // 000000052CE8: 7C3638FF C2CE8ED0
	s_waitcnt lgkmcnt(0)                                       // 000000052CF0: BF89FC07
	v_mul_f32_e32 v2, v64, v2                                  // 000000052CF4: 10040540
	v_add_f32_e32 v65, v65, v66                                // 000000052CF8: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000052CFC: 7E841143
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000052D00: BF870292
	v_exp_f32_e32 v65, v65                                     // 000000052D04: 7E824B41
	.long 0xd71c0041                                           // 000000052D08: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000052D0C: 02028541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052D10: BF870121
	v_cndmask_b32_e32 v26, 0, v65, vcc_lo                      // 000000052D14: 02348280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v28                  // 000000052D18: 7C3C38FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 000000052D20: 023434FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000052D28: BF870001
	.long 0xd5080041                                           // 000000052D2C: D5080041
	v_sub_co_ci_u32_e32 v1, vcc_lo, v2, v26, vcc_lo            // 000000052D30: 42023502
	s_or_b32 exec_lo, exec_lo, s3                              // 000000052D34: 8C7E037E
	v_or_b32_e32 v2, 0x5e40, v60                               // 000000052D38: 380478FF 00005E40
	s_waitcnt lgkmcnt(7)                                       // 000000052D40: BF89FC77
	v_lshlrev_b32_e32 v26, 6, v154                             // 000000052D44: 30353486
	s_mov_b32 s3, exec_lo                                      // 000000052D48: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000052D4C: BF870001
	v_add3_u32 v2, v2, v26, 0xfffff8c0                         // 000000052D50: D6550002 03FE3502 FFFFF8C0
	ds_store_b32 v2, v65                                       // 000000052D5C: D8340000 00004102
	.long 0xd4c9007e                                           // 000000052D64: D4C9007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 000000052D68: 02027B37
	s_cbranch_execz 33                                         // 000000052D6C: BFA50021 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1cf4>
	v_dual_sub_f32 v26, v29, v12 :: v_dual_mul_f32 v3, v3, v27 // 000000052D70: C946191D 1A023703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052D78: BF870121
	v_dual_mul_f32 v28, 0x3fb8aa3b, v26 :: v_dual_mul_f32 v3, v13, v3// 000000052D7C: C8C634FF 1C02070D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v26                  // 000000052D88: 7C3634FF C2CE8ED0
	v_fma_f32 v29, 0x3fb8aa3b, v26, -v28                       // 000000052D90: D613001D 847234FF 3FB8AA3B
	v_rndne_f32_e32 v60, v28                                   // 000000052D9C: 7E78471C
	s_waitcnt lgkmcnt(4)                                       // 000000052DA0: BF89FC47
	v_mul_f32_e32 v3, v32, v3                                  // 000000052DA4: 10060720
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052DA8: BF870092
	v_dual_fmac_f32 v29, 0x32a5705f, v26 :: v_dual_sub_f32 v28, v28, v60// 000000052DAC: C80A34FF 1D1C791C 32A5705F
	v_add_f32_e32 v28, v28, v29                                // 000000052DB8: 06383B1C
	v_cvt_i32_f32_e32 v29, v60                                 // 000000052DBC: 7E3A113C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000052DC0: BF870292
	v_exp_f32_e32 v28, v28                                     // 000000052DC4: 7E384B1C
	.long 0xd71c001c                                           // 000000052DC8: D71C001C
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                     // 000000052DCC: 02023B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052DD0: BF870121
	v_cndmask_b32_e32 v27, 0, v28, vcc_lo                      // 000000052DD4: 02363880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v26                  // 000000052DD8: 7C3C34FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v27, vcc_lo             // 000000052DE0: 023436FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000052DE8: BF870001
	.long 0xd508003f                                           // 000000052DEC: D508003F
	v_sub_co_ci_u32_e32 v1, vcc_lo, v3, v26, vcc_lo            // 000000052DF0: 42023503
	s_or_b32 exec_lo, exec_lo, s3                              // 000000052DF4: 8C7E037E
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v26, 0              // 000000052DF8: CA100080 031A0080
	s_mov_b32 s3, exec_lo                                      // 000000052E00: BE83007E
	ds_store_b32 v2, v63 offset:128                            // 000000052E04: D8340080 00003F02
	.long 0xd4c9007e                                           // 000000052E0C: D4C9007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 000000052E10: 02027737
	s_cbranch_execz 35                                         // 000000052E14: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1da4>
	v_sub_f32_e32 v24, v24, v12                                // 000000052E18: 08301918
	s_waitcnt lgkmcnt(8)                                       // 000000052E1C: BF89FC87
	v_mul_f32_e32 v4, v4, v22                                  // 000000052E20: 10082D04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000052E24: BF8701A2
	v_mul_f32_e32 v26, 0x3fb8aa3b, v24                         // 000000052E28: 103430FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v24                  // 000000052E30: 7C3630FF C2CE8ED0
	v_mul_f32_e32 v4, v13, v4                                  // 000000052E38: 1008090D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000052E3C: BF8701B3
	v_fma_f32 v27, 0x3fb8aa3b, v24, -v26                       // 000000052E40: D613001B 846A30FF 3FB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000052E4C: 7E38471A
	s_waitcnt lgkmcnt(5)                                       // 000000052E50: BF89FC57
	v_mul_f32_e32 v4, v33, v4                                  // 000000052E54: 10080921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000052E58: BF870193
	v_fmac_f32_e32 v27, 0x32a5705f, v24                        // 000000052E5C: 563630FF 32A5705F
	v_sub_f32_e32 v26, v26, v28                                // 000000052E64: 0834391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052E68: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000052E6C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000052E70: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000052E74: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052E78: BF870095
	.long 0xd71c001a                                           // 000000052E7C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000052E80: 0202371A
	v_cndmask_b32_e32 v22, 0, v26, vcc_lo                      // 000000052E84: 022C3480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v24                  // 000000052E88: 7C3C30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052E90: BF870092
	v_cndmask_b32_e32 v22, 0x7f800000, v22, vcc_lo             // 000000052E94: 022C2CFF 7F800000
	.long 0xd508001a                                           // 000000052E9C: D508001A
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v22, vcc_lo            // 000000052EA0: 42022D04
	s_or_b32 exec_lo, exec_lo, s3                              // 000000052EA4: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000052EA8: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000052EAC: BE83007E
	ds_store_b32 v2, v26 offset:256                            // 000000052EB0: D8340100 00001A02
	.long 0xd4c9007e                                           // 000000052EB8: D4C9007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 000000052EBC: 02026337
	s_cbranch_execz 34                                         // 000000052EC0: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1e4c>
	v_sub_f32_e32 v3, v25, v12                                 // 000000052EC4: 08061919
	s_waitcnt lgkmcnt(9)                                       // 000000052EC8: BF89FC97
	v_mul_f32_e32 v5, v5, v23                                  // 000000052ECC: 100A2F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052ED0: BF870091
	v_dual_mul_f32 v4, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, v13, v5// 000000052ED4: C8C606FF 04040B0D 3FB8AA3B
	v_fma_f32 v22, 0x3fb8aa3b, v3, -v4                         // 000000052EE0: D6130016 841206FF 3FB8AA3B
	v_rndne_f32_e32 v24, v4                                    // 000000052EEC: 7E304704
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000052EF0: BF870112
	v_fmac_f32_e32 v22, 0x32a5705f, v3                         // 000000052EF4: 562C06FF 32A5705F
	v_sub_f32_e32 v4, v4, v24                                  // 000000052EFC: 08083104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000052F00: BF8701B1
	v_add_f32_e32 v4, v4, v22                                  // 000000052F04: 06082D04
	v_cvt_i32_f32_e32 v22, v24                                 // 000000052F08: 7E2C1118
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000052F0C: 7C3606FF C2CE8ED0
	v_exp_f32_e32 v4, v4                                       // 000000052F14: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052F18: BF870095
	.long 0xd71c0004                                           // 000000052F1C: D71C0004
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 000000052F20: 02022D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 000000052F24: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000052F28: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(5)                                       // 000000052F30: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052F34: BF870092
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v30, v5// 000000052F38: CA4608FF 03040B1E 7F800000
	.long 0xd5080003                                           // 000000052F44: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 000000052F48: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 000000052F4C: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 000000052F50: CA100080 04040080
	s_mov_b32 s3, exec_lo                                      // 000000052F58: BE83007E
	ds_store_b32 v2, v3 offset:384                             // 000000052F5C: D8340180 00000302
	.long 0xd4c9007e                                           // 000000052F64: D4C9007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 000000052F68: 02026137
	s_cbranch_execz 34                                         // 000000052F6C: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1ef8>
	s_waitcnt lgkmcnt(9)                                       // 000000052F70: BF89FC97
	v_dual_sub_f32 v3, v20, v12 :: v_dual_mul_f32 v6, v6, v18  // 000000052F74: C9461914 03062506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052F7C: BF870121
	v_dual_mul_f32 v5, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v6, v13, v6// 000000052F80: C8C606FF 05060D0D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000052F8C: 7C3606FF C2CE8ED0
	v_fma_f32 v20, 0x3fb8aa3b, v3, -v5                         // 000000052F94: D6130014 841606FF 3FB8AA3B
	v_rndne_f32_e32 v22, v5                                    // 000000052FA0: 7E2C4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052FA4: BF870091
	v_dual_fmac_f32 v20, 0x32a5705f, v3 :: v_dual_sub_f32 v5, v5, v22// 000000052FA8: C80A06FF 14042D05 32A5705F
	v_add_f32_e32 v5, v5, v20                                  // 000000052FB4: 060A2905
	v_cvt_i32_f32_e32 v20, v22                                 // 000000052FB8: 7E281116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000052FBC: BF870292
	v_exp_f32_e32 v5, v5                                       // 000000052FC0: 7E0A4B05
	.long 0xd71c0005                                           // 000000052FC4: D71C0005
	v_cndmask_b32_e32 v1, v5, v20, vcc_lo                      // 000000052FC8: 02022905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052FCC: BF870121
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 000000052FD0: 020A0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000052FD4: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v3, 0x7f800000, v5, vcc_lo               // 000000052FDC: 02060AFF 7F800000
	s_waitcnt lgkmcnt(6)                                       // 000000052FE4: BF89FC67
	v_mul_f32_e32 v5, v31, v6                                  // 000000052FE8: 100A0D1F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000052FEC: BF870001
	.long 0xd5080005                                           // 000000052FF0: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v3, vcc_lo             // 000000052FF4: 42020705
	s_or_b32 exec_lo, exec_lo, s3                              // 000000052FF8: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000052FFC: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000053000: BE83007E
	ds_store_b32 v2, v5 offset:512                             // 000000053004: D8340200 00000502
	.long 0xd4c9007e                                           // 00000005300C: D4C9007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 000000053010: 02025F37
	s_cbranch_execz 35                                         // 000000053014: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1fa4>
	v_sub_f32_e32 v3, v21, v12                                 // 000000053018: 08061915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005301C: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 000000053020: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 000000053028: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 000000053034: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000053038: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000005303C: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000053040: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 000000053048: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053050: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 000000053054: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 000000053058: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000005305C: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000053060: BF8700A5
	.long 0xd71c0004                                           // 000000053064: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 000000053068: 02020B04
	s_waitcnt lgkmcnt(10)                                      // 00000005306C: BF89FCA7
	v_dual_mul_f32 v5, v7, v19 :: v_dual_cndmask_b32 v4, 0, v4 // 000000053070: C8D22707 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000053078: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000005307C: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000053080: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(6)                                       // 000000053088: BF89FC67
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v10, v5// 00000005308C: CA4608FF 03040B0A 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000053098: BF870001
	.long 0xd5080004                                           // 00000005309C: D5080004
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 0000000530A0: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000530A4: 8C7E037E
	v_mov_b32_e32 v3, 0                                        // 0000000530A8: 7E060280
	v_mov_b32_e32 v5, 0                                        // 0000000530AC: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 0000000530B0: BE83007E
	ds_store_b32 v2, v4 offset:640                             // 0000000530B4: D8340280 00000402
	.long 0xd4c9007e                                           // 0000000530BC: D4C9007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 0000000530C0: 02025D37
	s_cbranch_execz 35                                         // 0000000530C4: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2054>
	v_sub_f32_e32 v4, v16, v12                                 // 0000000530C8: 08081910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000530CC: BF870091
	v_mul_f32_e32 v5, 0x3fb8aa3b, v4                           // 0000000530D0: 100A08FF 3FB8AA3B
	v_fma_f32 v6, 0x3fb8aa3b, v4, -v5                          // 0000000530D8: D6130006 841608FF 3FB8AA3B
	v_rndne_f32_e32 v7, v5                                     // 0000000530E4: 7E0E4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000530E8: BF870221
	v_sub_f32_e32 v5, v5, v7                                   // 0000000530EC: 080A0F05
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 0000000530F0: 7C3608FF C2CE8ED0
	v_fmac_f32_e32 v6, 0x32a5705f, v4                          // 0000000530F8: 560C08FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053100: BF870121
	v_add_f32_e32 v5, v5, v6                                   // 000000053104: 060A0D05
	v_cvt_i32_f32_e32 v6, v7                                   // 000000053108: 7E0C1107
	v_exp_f32_e32 v5, v5                                       // 00000005310C: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000053110: BF8700A5
	.long 0xd71c0005                                           // 000000053114: D71C0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 000000053118: 02020D05
	s_waitcnt lgkmcnt(10)                                      // 00000005311C: BF89FCA7
	v_dual_mul_f32 v6, v8, v14 :: v_dual_cndmask_b32 v5, 0, v5 // 000000053120: C8D21D08 06040A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000053128: BF870131
	v_mul_f32_e32 v6, v13, v6                                  // 00000005312C: 100C0D0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 000000053130: 7C3C08FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 000000053138: BF89FC77
	v_dual_cndmask_b32 v4, 0x7f800000, v5 :: v_dual_mul_f32 v5, v11, v6// 00000005313C: CA460AFF 04040D0B 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000053148: BF870001
	.long 0xd5080005                                           // 00000005314C: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v4, vcc_lo             // 000000053150: 42020905
	s_or_b32 exec_lo, exec_lo, s3                              // 000000053154: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000053158: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000005315C: BE83007E
	ds_store_b32 v2, v5 offset:768                             // 000000053160: D8340300 00000502
	.long 0xd4c9007e                                           // 000000053168: D4C9007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 00000005316C: 02025B37
	s_cbranch_execz 35                                         // 000000053170: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2100>
	v_sub_f32_e32 v3, v17, v12                                 // 000000053174: 08061911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053178: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000005317C: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 000000053184: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 000000053190: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000053194: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 000000053198: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000005319C: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 0000000531A4: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000531AC: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 0000000531B0: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 0000000531B4: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 0000000531B8: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000531BC: BF8700A5
	.long 0xd71c0004                                           // 0000000531C0: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 0000000531C4: 02020B04
	s_waitcnt lgkmcnt(11)                                      // 0000000531C8: BF89FCB7
	v_dual_mul_f32 v5, v9, v15 :: v_dual_cndmask_b32 v4, 0, v4 // 0000000531CC: C8D21F09 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000531D4: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 0000000531D8: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 0000000531DC: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 0000000531E4: BF89FC77
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v62, v5// 0000000531E8: CA4608FF 03040B3E 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000531F4: BF870001
	.long 0xd5080003                                           // 0000000531F8: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 0000000531FC: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 000000053200: 8C7E037E
	ds_store_b32 v2, v3 offset:896                             // 000000053204: D8340380 00000302
	s_waitcnt lgkmcnt(0)                                       // 00000005320C: BF89FC07
	s_barrier                                                  // 000000053210: BFBD0000
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 000000053214: 916A267E
	s_cbranch_vccz 6                                           // 000000053218: BFA30006 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2134>
	s_and_b32 vcc_lo, exec_lo, s41                             // 00000005321C: 8B6A297E
	s_mov_b32 s3, -1                                           // 000000053220: BE8300C1
	s_cbranch_vccnz 7                                          // 000000053224: BFA40007 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2144>
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 000000053228: 916A037E
	s_cbranch_vccz 180                                         // 00000005322C: BFA300B4 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2400>
	s_branch 712                                               // 000000053230: BFA002C8 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c54>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 000000053234: BE9C4D83
	s_and_b32 vcc_lo, exec_lo, s41                             // 000000053238: 8B6A297E
	s_mov_b32 s3, -1                                           // 00000005323C: BE8300C1
	s_cbranch_vccz 65529                                       // 000000053240: BFA3FFF9 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2128>
	s_mov_b32 s3, exec_lo                                      // 000000053244: BE83007E
	v_cmpx_gt_i32_e32 0x120, v44                               // 000000053248: 7D8858FF 00000120
	s_cbranch_execz 169                                        // 000000053250: BFA500A9 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x23f8>
	v_add_nc_u32_e32 v2, 0xffffff00, v44                       // 000000053254: 4A0458FF FFFFFF00
	s_mov_b32 s4, 0                                            // 00000005325C: BE840080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000053260: BF870001
	v_mov_b32_e32 v3, v2                                       // 000000053264: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000053268: BF8700A1
	v_add_nc_u32_e32 v3, 0xe0, v3                              // 00000005326C: 4A0606FF 000000E0
	s_waitcnt lgkmcnt(0)                                       // 000000053274: BF89FC07
	v_ashrrev_i32_e32 v16, 7, v3                               // 000000053278: 34200687
	v_and_b32_e32 v12, 0x7f, v3                                // 00000005327C: 361806FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053284: BF870092
	.long 0xd72c0004                                           // 000000053288: D72C0004
	v_cndmask_b32_e32 v1, 0x880, v16, vcc_lo                   // 00000005328C: 020220FF 00000880
	v_lshl_add_u32 v4, v12, 1, v4                              // 000000053294: D6460004 0411030C
	ds_load_u16 v20, v4 offset:7776                            // 00000005329C: D8F01E60 14000004
	ds_load_u16 v21, v4 offset:7232                            // 0000000532A4: D8F01C40 15000004
	ds_load_u16 v22, v4 offset:6688                            // 0000000532AC: D8F01A20 16000004
	ds_load_u16 v23, v4 offset:6144                            // 0000000532B4: D8F01800 17000004
	ds_load_u16 v24, v4 offset:6416                            // 0000000532BC: D8F01910 18000004
	s_waitcnt lgkmcnt(3)                                       // 0000000532C4: BF89FC37
	v_lshlrev_b32_e32 v21, 16, v21                             // 0000000532C8: 302A2A90
	s_waitcnt lgkmcnt(1)                                       // 0000000532CC: BF89FC17
	v_lshlrev_b32_e32 v23, 16, v23                             // 0000000532D0: 302E2E90
	v_lshlrev_b32_e32 v17, 5, v16                              // 0000000532D4: 30222085
	ds_load_u16 v25, v4 offset:6960                            // 0000000532D8: D8F01B30 19000004
	ds_load_u16 v26, v4 offset:7504                            // 0000000532E0: D8F01D50 1A000004
	ds_load_u16 v27, v4 offset:8048                            // 0000000532E8: D8F01F70 1B000004
	ds_load_b128 v[4:7], v17 offset:24384                      // 0000000532F0: DBFC5F40 04000011
	ds_load_b128 v[8:11], v17 offset:24400                     // 0000000532F8: DBFC5F50 08000011
	v_lshlrev_b32_e32 v20, 16, v20                             // 000000053300: 30282890
	s_waitcnt lgkmcnt(0)                                       // 000000053304: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053308: BF870091
	v_dual_mul_f32 v10, v10, v20 :: v_dual_lshlrev_b32 v25, 16, v25// 00000005330C: C8E2290A 0A183290
	v_dual_mul_f32 v7, v7, v25 :: v_dual_lshlrev_b32 v24, 16, v24// 000000053314: C8E23307 07183090
	v_mul_f32_e32 v8, v8, v21                                  // 00000005331C: 10102B08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000053320: BF870002
	v_dual_mul_f32 v4, v4, v23 :: v_dual_mul_f32 v5, v5, v24   // 000000053324: C8C62F04 04043105
	v_mul_u32_u24_e32 v18, 48, v12                             // 00000005332C: 162418B0
	ds_load_b128 v[12:15], v17 offset:24192                    // 000000053330: DBFC5E80 0C000011
	v_lshlrev_b32_e32 v26, 16, v26                             // 000000053338: 30343490
	v_lshlrev_b32_e32 v27, 16, v27                             // 00000005333C: 30363690
	v_lshl_add_u32 v28, v16, 4, v18                            // 000000053340: D646001C 04490910
	ds_load_b128 v[16:19], v17 offset:24208                    // 000000053348: DBFC5E90 10000011
	s_waitcnt lgkmcnt(1)                                       // 000000053350: BF89FC17
	v_mul_f32_e32 v12, v12, v4                                 // 000000053354: 1018090C
	v_mul_f32_e32 v4, v13, v5                                  // 000000053358: 10080B0D
	v_dual_mul_f32 v11, v11, v27 :: v_dual_lshlrev_b32 v22, 16, v22// 00000005335C: C8E2370B 0B162C90
	v_mul_f32_e32 v5, v15, v7                                  // 000000053364: 100A0F0F
	v_mul_f32_e32 v9, v9, v26                                  // 000000053368: 10123509
	s_waitcnt lgkmcnt(0)                                       // 00000005336C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000053370: BF870243
	v_dual_mul_f32 v7, v16, v8 :: v_dual_mul_f32 v6, v6, v22   // 000000053374: C8C61110 07062D06
	v_cmp_lt_i32_e32 vcc_lo, 31, v3                            // 00000005337C: 7C82069F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 000000053380: CC220004 02006104
	v_dual_mul_f32 v8, v17, v9 :: v_dual_mul_f32 v9, v18, v10  // 000000053388: C8C61311 08081512
	v_mul_f32_e32 v6, v14, v6                                  // 000000053390: 100C0D0E
	v_mul_f32_e32 v10, v19, v11                                // 000000053394: 10141713
	v_fma_mixlo_f16 v4, v12, s48, 0                            // 000000053398: CC210004 0200610C
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 0000000533A0: CC220005 02006105
	s_or_b32 s4, vcc_lo, s4                                    // 0000000533A8: 8C04046A
	v_fma_mixlo_f16 v5, v6, s48, 0                             // 0000000533AC: CC210005 02006106
	v_fma_mixhi_f16 v6, v8, s48, 0                             // 0000000533B4: CC220006 02006108
	v_fma_mixlo_f16 v6, v7, s48, 0                             // 0000000533BC: CC210006 02006107
	v_fma_mixhi_f16 v7, v10, s48, 0                            // 0000000533C4: CC220007 0200610A
	v_fma_mixlo_f16 v7, v9, s48, 0                             // 0000000533CC: CC210007 02006109
	ds_store_b128 v28, v[4:7]                                  // 0000000533D4: DB7C0000 0000041C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000533DC: 917E047E
	s_cbranch_execnz 65441                                     // 0000000533E0: BFA6FFA1 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2168>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000533E4: 8C7E047E
	v_lshl_add_u32 v3, v44, 3, 0xffffff00                      // 0000000533E8: D6460003 03FD072C FFFFFF00
	s_mov_b32 s4, 0                                            // 0000000533F4: BE840080
	v_add_nc_u32_e32 v2, 0xe0, v2                              // 0000000533F8: 4A0404FF 000000E0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000053400: BF8701A2
	v_and_b32_e32 v4, 0x78, v3                                 // 000000053404: 360806FF 00000078
	v_add_nc_u32_e32 v3, 0x700, v3                             // 00000005340C: 4A0606FF 00000700
	v_ashrrev_i32_e32 v5, 4, v2                                // 000000053414: 340A0484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053418: BF870121
	.long 0xd72c0006                                           // 00000005341C: D72C0006
	v_cndmask_b32_e32 v1, 0x110, v5, vcc_lo                    // 000000053420: 02020AFF 00000110
	v_lshlrev_b32_e32 v8, 2, v5                                // 000000053428: 30100A82
	v_lshl_add_u32 v9, v4, 1, v6                               // 00000005342C: D6460009 04190304
	ds_load_b128 v[4:7], v9 offset:10496                       // 000000053434: DBFC2900 04000009
	ds_load_b32 v8, v8 offset:24448                            // 00000005343C: D8D85F80 08000008
	s_waitcnt lgkmcnt(1)                                       // 000000053444: BF89FC17
	v_and_b32_e32 v12, 0xffff0000, v6                          // 000000053448: 36180CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000053450: 300C0C90
	v_and_b32_e32 v13, 0xffff0000, v7                          // 000000053454: 361A0EFF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v4                          // 00000005345C: 361408FF FFFF0000
	v_lshlrev_b32_e32 v4, 16, v4                               // 000000053464: 30080890
	v_and_b32_e32 v11, 0xffff0000, v5                          // 000000053468: 36160AFF FFFF0000
	v_lshlrev_b32_e32 v5, 16, v5                               // 000000053470: 300A0A90
	s_waitcnt lgkmcnt(0)                                       // 000000053474: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000053478: BF8701A3
	v_dual_mul_f32 v14, v8, v4 :: v_dual_lshlrev_b32 v7, 16, v7// 00000005347C: C8E20908 0E060E90
	v_mul_f32_e32 v4, v8, v10                                  // 000000053484: 10081508
	v_mul_f32_e32 v10, v8, v5                                  // 000000053488: 10140B08
	v_mul_f32_e32 v5, v8, v11                                  // 00000005348C: 100A1708
	v_mul_f32_e32 v11, v8, v6                                  // 000000053490: 10160D08
	v_mul_f32_e32 v6, v8, v12                                  // 000000053494: 100C1908
	v_mul_f32_e32 v12, v8, v7                                  // 000000053498: 10180F08
	v_mul_f32_e32 v7, v8, v13                                  // 00000005349C: 100E1B08
	v_cmp_lt_i32_e32 vcc_lo, 31, v2                            // 0000000534A0: 7C82049F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 0000000534A4: CC220004 02006104
	v_fma_mixlo_f16 v4, v14, s48, 0                            // 0000000534AC: CC210004 0200610E
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 0000000534B4: CC220005 02006105
	v_fma_mixlo_f16 v5, v10, s48, 0                            // 0000000534BC: CC210005 0200610A
	v_fma_mixhi_f16 v6, v6, s48, 0                             // 0000000534C4: CC220006 02006106
	v_fma_mixlo_f16 v6, v11, s48, 0                            // 0000000534CC: CC210006 0200610B
	v_fma_mixhi_f16 v7, v7, s48, 0                             // 0000000534D4: CC220007 02006107
	v_fma_mixlo_f16 v7, v12, s48, 0                            // 0000000534DC: CC210007 0200610C
	s_or_b32 s4, vcc_lo, s4                                    // 0000000534E4: 8C04046A
	ds_store_b128 v9, v[4:7] offset:10496                      // 0000000534E8: DB7C2900 00000409
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000534F0: 917E047E
	s_cbranch_execnz 65472                                     // 0000000534F4: BFA6FFC0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x22f8>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000534F8: 8C7E037E
	s_cbranch_execnz 533                                       // 0000000534FC: BFA60215 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c54>
	s_mov_b32 s3, exec_lo                                      // 000000053500: BE83007E
	v_cmpx_gt_u32_e32 16, v43                                  // 000000053504: 7D985690
	s_cbranch_execz 529                                        // 000000053508: BFA50211 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c50>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000005350C: 7C945680
	s_waitcnt lgkmcnt(0)                                       // 000000053510: BF89FC07
	ds_load_b96 v[14:16], v1 offset:23280                      // 000000053514: DBF85AF0 0E000001
	ds_load_b128 v[59:62], v1 offset:23248                     // 00000005351C: DBFC5AD0 3B000001
	ds_load_b128 v[63:66], v1 offset:23264                     // 000000053524: DBFC5AE0 3F000001
	ds_load_b128 v[10:13], v1 offset:23168                     // 00000005352C: DBFC5A80 0A000001
	ds_load_b128 v[6:9], v1 offset:23184                       // 000000053534: DBFC5A90 06000001
	ds_load_b128 v[2:5], v1 offset:23200                       // 00000005353C: DBFC5AA0 02000001
	ds_load_b64 v[17:18], v1 offset:23216                      // 000000053544: D9D85AB0 11000001
	v_cndmask_b32_e64 v44, 0, 1.0, vcc_lo                      // 00000005354C: D501002C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 000000053554: 7C945681
	ds_load_b128 v[45:48], v1 offset:23232                     // 000000053558: DBFC5AC0 2D000001
	v_cndmask_b32_e64 v33, 0, 1.0, vcc_lo                      // 000000053560: D5010021 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 000000053568: 7C945682
	v_cndmask_b32_e64 v32, 0, 1.0, vcc_lo                      // 00000005356C: D5010020 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 000000053574: 7C945683
	v_cndmask_b32_e64 v31, 0, 1.0, vcc_lo                      // 000000053578: D501001F 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 000000053580: 7C945684
	v_cndmask_b32_e64 v29, 0, 1.0, vcc_lo                      // 000000053584: D501001D 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 00000005358C: 7C945685
	v_cndmask_b32_e64 v30, 0, 1.0, vcc_lo                      // 000000053590: D501001E 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 000000053598: 7C945686
	v_cndmask_b32_e64 v28, 0, 1.0, vcc_lo                      // 00000005359C: D501001C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 0000000535A4: 7C945687
	v_cndmask_b32_e64 v27, 0, 1.0, vcc_lo                      // 0000000535A8: D501001B 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 0000000535B0: 7C945688
	v_cndmask_b32_e64 v25, 0, 1.0, vcc_lo                      // 0000000535B4: D5010019 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 0000000535BC: 7C945689
	v_cndmask_b32_e64 v23, 0, 1.0, vcc_lo                      // 0000000535C0: D5010017 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 0000000535C8: 7C94568A
	v_cndmask_b32_e64 v26, 0, 1.0, vcc_lo                      // 0000000535CC: D501001A 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 0000000535D4: 7C94568B
	v_cndmask_b32_e64 v24, 0, 1.0, vcc_lo                      // 0000000535D8: D5010018 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 0000000535E0: 7C94568C
	v_cndmask_b32_e64 v20, 0, 1.0, vcc_lo                      // 0000000535E4: D5010014 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 0000000535EC: 7C94568D
	v_cndmask_b32_e64 v22, 0, 1.0, vcc_lo                      // 0000000535F0: D5010016 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 0000000535F8: 7C94568E
	v_cndmask_b32_e64 v21, 0, 1.0, vcc_lo                      // 0000000535FC: D5010015 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 000000053604: 7C94568F
	v_cndmask_b32_e64 v19, 0, 1.0, vcc_lo                      // 000000053608: D5010013 01A9E480
	s_waitcnt lgkmcnt(7)                                       // 000000053610: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000053614: BF8700B1
	v_fmac_f32_e32 v22, v19, v15                               // 000000053618: 562C1F13
	v_fmac_f32_e32 v21, v19, v16                               // 00000005361C: 562A2113
	s_waitcnt lgkmcnt(1)                                       // 000000053620: BF89FC17
	v_dual_fmac_f32 v23, v19, v64 :: v_dual_fmac_f32 v22, v21, v18// 000000053624: C8008113 17162515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000005362C: BF8700D1
	v_dual_fmac_f32 v26, v19, v65 :: v_dual_fmac_f32 v23, v21, v3// 000000053630: C8008313 1A160715
	v_fmac_f32_e32 v25, v19, v63                               // 000000053638: 56327F13
	ds_load_b32 v18, v1 offset:22880                           // 00000005363C: D8D85960 12000001
	v_fmac_f32_e32 v26, v21, v4                                // 000000053644: 56340915
	v_dual_fmac_f32 v28, v19, v61 :: v_dual_fmac_f32 v25, v21, v2// 000000053648: C8007B13 1C180515
	v_dual_fmac_f32 v29, v19, v59 :: v_dual_fmac_f32 v28, v21, v8// 000000053650: C8007713 1D1C1115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053658: BF870091
	v_dual_fmac_f32 v30, v19, v60 :: v_dual_fmac_f32 v29, v21, v6// 00000005365C: C8007913 1E1C0D15
	v_dual_fmac_f32 v27, v19, v62 :: v_dual_fmac_f32 v30, v21, v7// 000000053664: C8007D13 1B1E0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005366C: BF870091
	v_dual_fmac_f32 v24, v19, v66 :: v_dual_fmac_f32 v27, v21, v9// 000000053670: C8008513 181A1315
	v_fmac_f32_e32 v24, v21, v5                                // 000000053678: 56300B15
	ds_load_b128 v[2:5], v1 offset:23072                       // 00000005367C: DBFC5A20 02000001
	s_waitcnt lgkmcnt(2)                                       // 000000053684: BF89FC27
	v_fmac_f32_e32 v31, v19, v48                               // 000000053688: 563E6113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005368C: BF870091
	v_dual_fmac_f32 v32, v19, v47 :: v_dual_fmac_f32 v31, v21, v13// 000000053690: C8005F13 201E1B15
	v_dual_fmac_f32 v33, v19, v46 :: v_dual_fmac_f32 v32, v21, v12// 000000053698: C8005D13 21201915
	v_fmac_f32_e32 v44, v19, v45                               // 0000000536A0: 56585B13
	ds_load_b128 v[45:48], v1 offset:24064                     // 0000000536A4: DBFC5E00 2D000001
	v_dual_fmac_f32 v33, v21, v11 :: v_dual_fmac_f32 v20, v19, v14// 0000000536AC: C8001715 21141D13
	ds_load_b128 v[59:62], v1 offset:23104                     // 0000000536B4: DBFC5A40 3B000001
	ds_load_b128 v[63:66], v1 offset:23136                     // 0000000536BC: DBFC5A60 3F000001
	ds_load_b128 v[67:70], v1 offset:23120                     // 0000000536C4: DBFC5A50 43000001
	ds_load_b32 v14, v1 offset:23152                           // 0000000536CC: D8D85A70 0E000001
	v_fmac_f32_e32 v44, v21, v10                               // 0000000536D4: 56581515
	ds_load_b128 v[6:9], v1 offset:23056                       // 0000000536D8: DBFC5A10 06000001
	ds_load_b128 v[10:13], v1 offset:23040                     // 0000000536E0: DBFC5A00 0A000001
	s_waitcnt lgkmcnt(5)                                       // 0000000536E8: BF89FC57
	v_fmac_f32_e32 v44, v22, v59                               // 0000000536EC: 56587716
	v_dual_fmac_f32 v33, v22, v60 :: v_dual_fmac_f32 v20, v21, v17// 0000000536F0: C8007916 21142315
	s_waitcnt lgkmcnt(3)                                       // 0000000536F8: BF89FC37
	v_fmac_f32_e32 v29, v22, v67                               // 0000000536FC: 563A8716
	v_fmac_f32_e32 v31, v22, v62                               // 000000053700: 563E7D16
	s_waitcnt lgkmcnt(2)                                       // 000000053704: BF89FC27
	v_fmac_f32_e32 v20, v22, v14                               // 000000053708: 56281D16
	ds_load_b128 v[14:17], v1 offset:22976                     // 00000005370C: DBFC59C0 0E000001
	v_fmac_f32_e32 v24, v22, v66                               // 000000053714: 56308516
	v_fmac_f32_e32 v32, v22, v61                               // 000000053718: 56407B16
	ds_load_b64 v[66:67], v1 offset:22944                      // 00000005371C: D9D859A0 42000001
	s_waitcnt lgkmcnt(2)                                       // 000000053724: BF89FC27
	v_fmac_f32_e32 v33, v20, v11                               // 000000053728: 56421714
	v_fmac_f32_e32 v24, v20, v5                                // 00000005372C: 56300B14
	s_waitcnt lgkmcnt(1)                                       // 000000053730: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000053734: BF8701B1
	v_dual_fmac_f32 v33, v24, v15 :: v_dual_fmac_f32 v30, v22, v68// 000000053738: C8001F18 211E8916
	v_fmac_f32_e32 v29, v20, v6                                // 000000053740: 563A0D14
	v_dual_fmac_f32 v25, v22, v63 :: v_dual_fmac_f32 v44, v20, v10// 000000053744: C8007F16 192C1514
	v_dual_fmac_f32 v23, v22, v64 :: v_dual_fmac_f32 v30, v20, v7// 00000005374C: C8008116 171E0F14
	v_fmac_f32_e32 v26, v22, v65                               // 000000053754: 56348316
	ds_load_b128 v[59:62], v1 offset:22992                     // 000000053758: DBFC59D0 3B000001
	ds_load_b96 v[63:65], v1 offset:23008                      // 000000053760: DBF859E0 3F000001
	v_dual_fmac_f32 v28, v22, v69 :: v_dual_fmac_f32 v25, v20, v2// 000000053768: C8008B16 1C180514
	v_dual_fmac_f32 v27, v22, v70 :: v_dual_fmac_f32 v32, v20, v12// 000000053770: C8008D16 1B201914
	v_fmac_f32_e32 v23, v20, v3                                // 000000053778: 562E0714
	v_fmac_f32_e32 v26, v20, v4                                // 00000005377C: 56340914
	v_fmac_f32_e32 v31, v20, v13                               // 000000053780: 563E1B14
	s_delay_alu instid0(VALU_DEP_4)                            // 000000053784: BF870004
	v_fmac_f32_e32 v27, v20, v9                                // 000000053788: 56361314
	ds_load_b128 v[2:5], v1 offset:22848                       // 00000005378C: DBFC5940 02000001
	s_waitcnt lgkmcnt(1)                                       // 000000053794: BF89FC17
	v_fmac_f32_e32 v26, v24, v65                               // 000000053798: 56348318
	v_fmac_f32_e32 v28, v20, v8                                // 00000005379C: 56381114
	ds_load_b128 v[6:9], v1 offset:22928                       // 0000000537A0: DBFC5990 06000001
	ds_load_b128 v[10:13], v1 offset:22912                     // 0000000537A8: DBFC5980 0A000001
	v_fmac_f32_e32 v29, v24, v59                               // 0000000537B0: 563A7718
	s_waitcnt lgkmcnt(1)                                       // 0000000537B4: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000537B8: BF870001
	v_fmac_f32_e32 v29, v26, v6                                // 0000000537BC: 563A0D1A
	v_fmac_f32_e32 v31, v24, v17                               // 0000000537C0: 563E2318
	v_fmac_f32_e32 v44, v24, v14                               // 0000000537C4: 56581D18
	v_fmac_f32_e32 v23, v24, v64                               // 0000000537C8: 562E8118
	v_fmac_f32_e32 v32, v24, v16                               // 0000000537CC: 56402118
	ds_load_b128 v[14:17], v1 offset:22864                     // 0000000537D0: DBFC5950 0E000001
	v_fmac_f32_e32 v23, v26, v67                               // 0000000537D8: 562E871A
	s_waitcnt lgkmcnt(0)                                       // 0000000537DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000537E0: BF870001
	v_fmac_f32_e32 v29, v23, v14                               // 0000000537E4: 563A1D17
	v_fmac_f32_e32 v27, v24, v62                               // 0000000537E8: 56367D18
	v_fmac_f32_e32 v30, v24, v60                               // 0000000537EC: 563C7918
	v_fmac_f32_e32 v25, v24, v63                               // 0000000537F0: 56327F18
	v_dual_fmac_f32 v33, v26, v11 :: v_dual_fmac_f32 v28, v24, v61// 0000000537F4: C800171A 211C7B18
	ds_load_b128 v[59:62], v1 offset:22800                     // 0000000537FC: DBFC5910 3B000001
	v_fmac_f32_e32 v32, v26, v12                               // 000000053804: 5640191A
	v_fmac_f32_e32 v31, v26, v13                               // 000000053808: 563E1B1A
	v_fmac_f32_e32 v44, v26, v10                               // 00000005380C: 5658151A
	ds_load_b128 v[10:13], v1 offset:22784                     // 000000053810: DBFC5900 0A000001
	ds_load_b96 v[63:65], v1 offset:22736                      // 000000053818: DBF858D0 3F000001
	v_fmac_f32_e32 v27, v26, v9                                // 000000053820: 5636131A
	v_fmac_f32_e32 v30, v26, v7                                // 000000053824: 563C0F1A
	v_fmac_f32_e32 v25, v26, v66                               // 000000053828: 5632851A
	v_fmac_f32_e32 v28, v26, v8                                // 00000005382C: 5638111A
	ds_load_b128 v[6:9], v1 offset:22720                       // 000000053830: DBFC58C0 06000001
	ds_load_b64 v[66:67], v1 offset:22672                      // 000000053838: D9D85890 42000001
	v_fmac_f32_e32 v33, v23, v3                                // 000000053840: 56420717
	v_fmac_f32_e32 v25, v23, v18                               // 000000053844: 56322517
	v_fmac_f32_e32 v28, v23, v16                               // 000000053848: 56382117
	v_fmac_f32_e32 v27, v23, v17                               // 00000005384C: 56362317
	v_fmac_f32_e32 v30, v23, v15                               // 000000053850: 563C1F17
	ds_load_b128 v[14:17], v1 offset:22528                     // 000000053854: DBFC5800 0E000001
	s_waitcnt lgkmcnt(5)                                       // 00000005385C: BF89FC57
	v_fmac_f32_e32 v27, v25, v62                               // 000000053860: 56367D19
	v_fmac_f32_e32 v28, v25, v61                               // 000000053864: 56387B19
	v_fmac_f32_e32 v30, v25, v60                               // 000000053868: 563C7919
	s_waitcnt lgkmcnt(3)                                       // 00000005386C: BF89FC37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000053870: BF870112
	v_fmac_f32_e32 v28, v27, v65                               // 000000053874: 5638831B
	v_fmac_f32_e32 v30, v27, v64                               // 000000053878: 563C811B
	s_waitcnt lgkmcnt(1)                                       // 00000005387C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000053880: BF870001
	v_fmac_f32_e32 v30, v28, v67                               // 000000053884: 563C871C
	v_dual_fmac_f32 v44, v23, v2 :: v_dual_fmac_f32 v33, v25, v11// 000000053888: C8000517 2C201719
	v_fmac_f32_e32 v31, v23, v5                                // 000000053890: 563E0B17
	v_fmac_f32_e32 v32, v23, v4                                // 000000053894: 56400917
	ds_load_b128 v[2:5], v1 offset:22656                       // 000000053898: DBFC5880 02000001
	v_fmac_f32_e32 v44, v25, v10                               // 0000000538A0: 56581519
	v_fmac_f32_e32 v29, v25, v59                               // 0000000538A4: 563A7719
	v_fmac_f32_e32 v31, v25, v13                               // 0000000538A8: 563E1B19
	v_fmac_f32_e32 v32, v25, v12                               // 0000000538AC: 56401919
	ds_load_b128 v[10:13], v1 offset:22592                     // 0000000538B0: DBFC5840 0A000001
	ds_load_b32 v18, v1 offset:22608                           // 0000000538B8: D8D85850 12000001
	v_fmac_f32_e32 v33, v27, v7                                // 0000000538C0: 56420F1B
	v_fmac_f32_e32 v29, v27, v63                               // 0000000538C4: 563A7F1B
	ds_load_b64 v[59:60], v1 offset:22400                      // 0000000538C8: D9D85780 3B000001
	v_dual_fmac_f32 v32, v27, v8 :: v_dual_fmac_f32 v29, v28, v66// 0000000538D0: C800111B 201C851C
	ds_load_b128 v[63:66], v1 offset:24304                     // 0000000538D8: DBFC5EF0 3F000001
	s_waitcnt lgkmcnt(2)                                       // 0000000538E0: BF89FC27
	v_fmac_f32_e32 v29, v30, v18                               // 0000000538E4: 563A251E
	v_dual_fmac_f32 v44, v27, v6 :: v_dual_fmac_f32 v33, v28, v3// 0000000538E8: C8000D1B 2C20071C
	v_fmac_f32_e32 v31, v27, v9                                // 0000000538F0: 563E131B
	ds_load_b96 v[6:8], v1 offset:22464                        // 0000000538F4: DBF857C0 06000001
	ds_load_b32 v9, v1 offset:22336                            // 0000000538FC: D8D85740 09000001
	v_fmac_f32_e32 v44, v28, v2                                // 000000053904: 5658051C
	v_fmac_f32_e32 v32, v28, v4                                // 000000053908: 5640091C
	v_fmac_f32_e32 v31, v28, v5                                // 00000005390C: 563E0B1C
	v_fmac_f32_e32 v33, v30, v11                               // 000000053910: 5642171E
	ds_load_b128 v[2:5], v1 offset:24256                       // 000000053914: DBFC5EC0 02000001
	v_fmac_f32_e32 v44, v30, v10                               // 00000005391C: 5658151E
	v_fmac_f32_e32 v32, v30, v12                               // 000000053920: 5640191E
	v_fmac_f32_e32 v31, v30, v13                               // 000000053924: 563E1B1E
	v_fmac_f32_e32 v33, v29, v15                               // 000000053928: 56421F1D
	s_waitcnt lgkmcnt(3)                                       // 00000005392C: BF89FC37
	v_mul_f32_e32 v72, v65, v21                                // 000000053930: 10902B41
	v_fmac_f32_e32 v44, v29, v14                               // 000000053934: 56581D1D
	v_fmac_f32_e32 v32, v29, v16                               // 000000053938: 5640211D
	v_fmac_f32_e32 v31, v29, v17                               // 00000005393C: 563E231D
	s_waitcnt lgkmcnt(2)                                       // 000000053940: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000053944: BF8700A1
	v_fmac_f32_e32 v32, v31, v8                                // 000000053948: 5640111F
	v_fmac_f32_e32 v33, v31, v7                                // 00000005394C: 56420F1F
	v_dual_fmac_f32 v44, v31, v6 :: v_dual_fmac_f32 v33, v32, v60// 000000053950: C8000D1F 2C207920
	s_delay_alu instid0(VALU_DEP_1)                            // 000000053958: BF870001
	v_fmac_f32_e32 v44, v32, v59                               // 00000005395C: 56587720
	ds_load_b128 v[59:62], v1 offset:24288                     // 000000053960: DBFC5EE0 3B000001
	s_waitcnt lgkmcnt(1)                                       // 000000053968: BF89FC17
	v_fma_mixlo_f16 v49, v5, v31, 0                            // 00000005396C: CC210031 02023F05
	v_mul_f32_e32 v15, v3, v33                                 // 000000053974: 101E4303
	v_fmac_f32_e32 v44, v33, v9                                // 000000053978: 56581321
	ds_load_b128 v[6:9], v1 offset:24272                       // 00000005397C: DBFC5ED0 06000001
	ds_load_b128 v[10:13], v1 offset:24112                     // 000000053984: DBFC5E30 0A000001
	v_fma_mixlo_f16 v18, v3, v33, 0                            // 00000005398C: CC210012 02024303
	v_mul_f32_e32 v14, v2, v44                                 // 000000053994: 101C5902
	v_fma_mixlo_f16 v2, v2, v44, 0                             // 000000053998: CC210002 02025902
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000539A0: BF870113
	v_fma_mix_f32 v15, v18, -1.0, v15 op_sel_hi:[1,1,0]        // 0000000539A4: CC20000F 1C3DE712
	v_fma_mix_f32 v3, v2, -1.0, v14 op_sel_hi:[1,1,0]          // 0000000539AC: CC200003 1C39E702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000000539B4: BF870232
	.long 0x7f1c150f                                           // 0000000539B8: 7F1C150F
	v_mul_f32_e32 v15, v4, v32                                 // 0000000539BC: 101E4104
	.long 0x7f043912                                           // 0000000539C0: 7F043912
	v_cvt_f16_f32_e32 v14, v3                                  // 0000000539C4: 7E1C1503
	v_fma_mixlo_f16 v3, v4, v32, 0                             // 0000000539C8: CC210003 02024104
	v_mul_f32_e32 v4, v5, v31                                  // 0000000539D0: 10083F05
	s_waitcnt lgkmcnt(2)                                       // 0000000539D4: BF89FC27
	v_fma_mixlo_f16 v69, v60, v23, 0                           // 0000000539D8: CC210045 02022F3C
	s_waitcnt lgkmcnt(1)                                       // 0000000539E0: BF89FC17
	v_mul_f32_e32 v16, v7, v30                                 // 0000000539E4: 10203D07
	v_fma_mixlo_f16 v67, v7, v30, 0                            // 0000000539E8: CC210043 02023D07
	v_fma_mix_f32 v7, v3, -1.0, v15 op_sel_hi:[1,1,0]          // 0000000539F0: CC200007 1C3DE703
	v_mul_f32_e32 v5, v6, v29                                  // 0000000539F8: 100A3B06
	v_fma_mixlo_f16 v68, v9, v27, 0                            // 0000000539FC: CC210044 02023709
	.long 0x7f063931                                           // 000000053A04: 7F063931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000053A08: BF8701D4
	v_cvt_f16_f32_e32 v15, v7                                  // 000000053A0C: 7E1E1507
	v_mul_f32_e32 v7, v8, v28                                  // 000000053A10: 100E3908
	v_fma_mix_f32 v17, v49, -1.0, v4 op_sel_hi:[1,1,0]         // 000000053A14: CC200011 1C11E731
	v_fma_mixlo_f16 v4, v6, v29, 0                             // 000000053A1C: CC210004 02023B06
	v_fma_mix_f32 v6, v67, -1.0, v16 op_sel_hi:[1,1,0]         // 000000053A24: CC200006 1C41E743
	.long 0x7f1e1511                                           // 000000053A2C: 7F1E1511
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000053A30: BF870193
	v_fma_mix_f32 v5, v4, -1.0, v5 op_sel_hi:[1,1,0]           // 000000053A34: CC200005 1C15E704
	.long 0x7f201506                                           // 000000053A3C: 7F201506
	v_fma_mixlo_f16 v6, v59, v25, 0                            // 000000053A40: CC210006 0202333B
	.long 0x7f083943                                           // 000000053A48: 7F083943
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000053A4C: BF8701C4
	v_cvt_f16_f32_e32 v16, v5                                  // 000000053A50: 7E201505
	v_fma_mixlo_f16 v5, v8, v28, 0                             // 000000053A54: CC210005 02023908
	v_dual_mul_f32 v8, v9, v27 :: v_dual_mul_f32 v9, v59, v25  // 000000053A5C: C8C63709 0808333B
	v_dual_mul_f32 v59, v60, v23 :: v_dual_mul_f32 v60, v61, v26// 000000053A64: C8C62F3C 3B3C353D
	v_fma_mix_f32 v7, v5, -1.0, v7 op_sel_hi:[1,1,0]           // 000000053A6C: CC200007 1C1DE705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000053A74: BF870213
	v_fma_mix_f32 v8, v68, -1.0, v8 op_sel_hi:[1,1,0]          // 000000053A78: CC200008 1C21E744
	v_fma_mix_f32 v9, v6, -1.0, v9 op_sel_hi:[1,1,0]           // 000000053A80: CC200009 1C25E706
	s_delay_alu instid0(VALU_DEP_4)                            // 000000053A88: BF870004
	v_fma_mix_f32 v70, v69, -1.0, v59 op_sel_hi:[1,1,0]        // 000000053A8C: CC200046 1CEDE745
	.long 0x7f0c3945                                           // 000000053A94: 7F0C3945
	v_cvt_f16_f32_e32 v17, v7                                  // 000000053A98: 7E221507
	v_fma_mixlo_f16 v7, v61, v26, 0                            // 000000053A9C: CC210007 0202353D
	.long 0x7f221508                                           // 000000053AA4: 7F221508
	v_cvt_f16_f32_e32 v59, v9                                  // 000000053AA8: 7E761509
	.long 0x7f761546                                           // 000000053AAC: 7F761546
	v_mul_f32_e32 v9, v62, v24                                 // 000000053AB0: 1012313E
	v_fma_mix_f32 v8, v7, -1.0, v60 op_sel_hi:[1,1,0]          // 000000053AB4: CC200008 1CF1E707
	v_fma_mixlo_f16 v70, v62, v24, 0                           // 000000053ABC: CC210046 0202313E
	v_dual_mul_f32 v61, v63, v20 :: v_dual_mul_f32 v62, v64, v22// 000000053AC4: C8C6293F 3D3E2D40
	v_fma_mixlo_f16 v64, v64, v22, 0                           // 000000053ACC: CC210040 02022D40
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000053AD4: BF870214
	v_cvt_f16_f32_e32 v60, v8                                  // 000000053AD8: 7E781508
	v_fma_mix_f32 v71, v70, -1.0, v9 op_sel_hi:[1,1,0]         // 000000053ADC: CC200047 1C25E746
	v_fma_mixlo_f16 v8, v63, v20, 0                            // 000000053AE4: CC210008 0202293F
	v_fma_mixlo_f16 v9, v65, v21, 0                            // 000000053AEC: CC210009 02022B41
	v_fma_mix_f32 v62, v64, -1.0, v62 op_sel_hi:[1,1,0]        // 000000053AF4: CC20003E 1CF9E740
	v_mul_f32_e32 v65, v66, v19                                // 000000053AFC: 10822742
	v_fma_mixlo_f16 v66, v66, v19, 0                           // 000000053B00: CC210042 02022742
	v_fma_mix_f32 v61, v8, -1.0, v61 op_sel_hi:[1,1,0]         // 000000053B08: CC20003D 1CF5E708
	v_fma_mix_f32 v63, v9, -1.0, v72 op_sel_hi:[1,1,0]         // 000000053B10: CC20003F 1D21E709
	.long 0x7f781547                                           // 000000053B18: 7F781547
	.long 0x7f103940                                           // 000000053B1C: 7F103940
	v_fma_mix_f32 v71, v66, -1.0, v65 op_sel_hi:[1,1,0]        // 000000053B20: CC200047 1D05E742
	v_cvt_f16_f32_e32 v61, v61                                 // 000000053B28: 7E7A153D
	.long 0x7f7a153e                                           // 000000053B2C: 7F7A153E
	v_cvt_f16_f32_e32 v62, v63                                 // 000000053B30: 7E7C153F
	.long 0x7f123942                                           // 000000053B34: 7F123942
	ds_load_b128 v[63:66], v1 offset:24080                     // 000000053B38: DBFC5E10 3F000001
	v_mul_u32_u24_e32 v72, 48, v43                             // 000000053B40: 169056B0
	.long 0x7f0e3946                                           // 000000053B44: 7F0E3946
	.long 0x7f0a3944                                           // 000000053B48: 7F0A3944
	v_mul_f32_e32 v18, v45, v44                                // 000000053B4C: 1024592D
	v_fma_mixlo_f16 v43, v45, v44, 0                           // 000000053B50: CC21002B 0202592D
	v_mul_f32_e32 v44, v46, v33                                // 000000053B58: 1058432E
	v_fma_mixlo_f16 v33, v46, v33, 0                           // 000000053B5C: CC210021 0202432E
	ds_store_b128 v72, v[6:9] offset:19216                     // 000000053B64: DB7C4B10 00000648
	ds_store_b128 v72, v[2:5] offset:19200                     // 000000053B6C: DB7C4B00 00000248
	ds_load_b128 v[2:5], v1 offset:24096                       // 000000053B74: DBFC5E20 02000001
	v_dual_mul_f32 v7, v47, v32 :: v_dual_mul_f32 v8, v48, v31 // 000000053B7C: C8C6412F 07083F30
	v_fma_mix_f32 v44, v33, -1.0, v44 op_sel_hi:[1,1,0]        // 000000053B84: CC20002C 1CB1E721
	.long 0x7f7c1547                                           // 000000053B8C: 7F7C1547
	s_delay_alu instid0(VALU_DEP_2)                            // 000000053B90: BF870002
	.long 0x7f0c152c                                           // 000000053B94: 7F0C152C
	v_fma_mixlo_f16 v44, v47, v32, 0                           // 000000053B98: CC21002C 0202412F
	s_waitcnt lgkmcnt(3)                                       // 000000053BA0: BF89FC37
	v_mul_f32_e32 v9, v63, v29                                 // 000000053BA4: 10123B3F
	v_fma_mix_f32 v18, v43, -1.0, v18 op_sel_hi:[1,1,0]        // 000000053BA8: CC200012 1C49E72B
	v_fma_mixlo_f16 v45, v63, v29, 0                           // 000000053BB0: CC21002D 02023B3F
	v_fma_mix_f32 v7, v44, -1.0, v7 op_sel_hi:[1,1,0]          // 000000053BB8: CC200007 1C1DE72C
	v_fma_mixlo_f16 v46, v65, v28, 0                           // 000000053BC0: CC21002E 02023941
	.long 0x7f563921                                           // 000000053BC8: 7F563921
	v_cvt_f16_f32_e32 v6, v18                                  // 000000053BCC: 7E0C1512
	v_fma_mixlo_f16 v18, v48, v31, 0                           // 000000053BD0: CC210012 02023F30
	v_mul_f32_e32 v31, v64, v30                                // 000000053BD8: 103E3D40
	v_fma_mixlo_f16 v30, v64, v30, 0                           // 000000053BDC: CC21001E 02023D40
	v_fma_mix_f32 v9, v45, -1.0, v9 op_sel_hi:[1,1,0]          // 000000053BE4: CC200009 1C25E72D
	v_cvt_f16_f32_e32 v7, v7                                   // 000000053BEC: 7E0E1507
	.long 0x7f583912                                           // 000000053BF0: 7F583912
	s_delay_alu instid0(VALU_DEP_4)                            // 000000053BF4: BF870004
	v_fma_mix_f32 v29, v30, -1.0, v31 op_sel_hi:[1,1,0]        // 000000053BF8: CC20001D 1C7DE71E
	v_mul_f32_e32 v31, v65, v28                                // 000000053C00: 103E3941
	v_fma_mix_f32 v8, v18, -1.0, v8 op_sel_hi:[1,1,0]          // 000000053C04: CC200008 1C21E712
	v_mul_f32_e32 v28, v66, v27                                // 000000053C0C: 10383742
	v_fma_mixlo_f16 v27, v66, v27, 0                           // 000000053C10: CC21001B 02023742
	.long 0x7f5a391e                                           // 000000053C18: 7F5A391E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000053C1C: BF870004
	.long 0x7f0e1508                                           // 000000053C20: 7F0E1508
	v_cvt_f16_f32_e32 v8, v9                                   // 000000053C24: 7E101509
	.long 0x7f10151d                                           // 000000053C28: 7F10151D
	v_fma_mix_f32 v9, v46, -1.0, v31 op_sel_hi:[1,1,0]         // 000000053C2C: CC200009 1C7DE72E
	s_waitcnt lgkmcnt(0)                                       // 000000053C34: BF89FC07
	v_mul_f32_e32 v29, v2, v25                                 // 000000053C38: 103A3302
	v_fma_mixlo_f16 v2, v2, v25, 0                             // 000000053C3C: CC210002 02023302
	v_mul_f32_e32 v25, v3, v23                                 // 000000053C44: 10322F03
	v_fma_mixlo_f16 v31, v3, v23, 0                            // 000000053C48: CC21001F 02022F03
	v_fma_mix_f32 v3, v27, -1.0, v28 op_sel_hi:[1,1,0]         // 000000053C50: CC200003 1C71E71B
	v_cvt_f16_f32_e32 v9, v9                                   // 000000053C58: 7E121509
	v_mul_f32_e32 v23, v4, v26                                 // 000000053C5C: 102E3504
	.long 0x7f5c391b                                           // 000000053C60: 7F5C391B
	v_fma_mix_f32 v25, v31, -1.0, v25 op_sel_hi:[1,1,0]        // 000000053C64: CC200019 1C65E71F
	.long 0x7f121503                                           // 000000053C6C: 7F121503
	v_fma_mixlo_f16 v3, v4, v26, 0                             // 000000053C70: CC210003 02023504
	v_mul_f32_e32 v26, v11, v22                                // 000000053C78: 10342D0B
	v_fma_mix_f32 v28, v2, -1.0, v29 op_sel_hi:[1,1,0]         // 000000053C7C: CC20001C 1C75E702
	v_fma_mixlo_f16 v11, v11, v22, 0                           // 000000053C84: CC21000B 02022D0B
	.long 0x7f04391f                                           // 000000053C8C: 7F04391F
	v_fma_mix_f32 v4, v3, -1.0, v23 op_sel_hi:[1,1,0]          // 000000053C90: CC200004 1C5DE703
	.long 0x7f2e1519                                           // 000000053C98: 7F2E1519
	v_cvt_f16_f32_e32 v23, v28                                 // 000000053C9C: 7E2E151C
	v_mul_f32_e32 v25, v5, v24                                 // 000000053CA0: 10323105
	v_fma_mixlo_f16 v28, v5, v24, 0                            // 000000053CA4: CC21001C 02023105
	v_cvt_f16_f32_e32 v24, v4                                  // 000000053CAC: 7E301504
	v_mul_f32_e32 v5, v10, v20                                 // 000000053CB0: 100A290A
	v_fma_mixlo_f16 v4, v10, v20, 0                            // 000000053CB4: CC210004 0202290A
	v_fma_mix_f32 v20, v11, -1.0, v26 op_sel_hi:[1,1,0]        // 000000053CBC: CC200014 1C69E70B
	v_fma_mix_f32 v22, v28, -1.0, v25 op_sel_hi:[1,1,0]        // 000000053CC4: CC200016 1C65E71C
	v_mul_f32_e32 v25, v12, v21                                // 000000053CCC: 10322B0C
	.long 0x7f06391c                                           // 000000053CD0: 7F06391C
	v_fma_mix_f32 v10, v4, -1.0, v5 op_sel_hi:[1,1,0]          // 000000053CD4: CC20000A 1C15E704
	v_fma_mixlo_f16 v5, v12, v21, 0                            // 000000053CDC: CC210005 02022B0C
	v_mul_f32_e32 v21, v13, v19                                // 000000053CE4: 102A270D
	v_fma_mixlo_f16 v13, v13, v19, 0                           // 000000053CE8: CC21000D 0202270D
	.long 0x7f08390b                                           // 000000053CF0: 7F08390B
	.long 0x7f301516                                           // 000000053CF4: 7F301516
	v_fma_mix_f32 v12, v5, -1.0, v25 op_sel_hi:[1,1,0]         // 000000053CF8: CC20000C 1C65E705
	v_cvt_f16_f32_e32 v25, v10                                 // 000000053D00: 7E32150A
	v_fma_mix_f32 v10, v13, -1.0, v21 op_sel_hi:[1,1,0]        // 000000053D04: CC20000A 1C55E70D
	.long 0x7f0a390d                                           // 000000053D0C: 7F0A390D
	.long 0x7f321514                                           // 000000053D10: 7F321514
	v_cvt_f16_f32_e32 v26, v12                                 // 000000053D14: 7E34150C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000053D18: BF870004
	.long 0x7f34150a                                           // 000000053D1C: 7F34150A
	ds_store_b128 v72, v[59:62] offset:19984                   // 000000053D20: DB7C4E10 00003B48
	ds_store_b128 v72, v[14:17] offset:19968                   // 000000053D28: DB7C4E00 00000E48
	ds_store_b128 v72, v[2:5] offset:20752                     // 000000053D30: DB7C5110 00000248
	ds_store_b128 v72, v[43:46] offset:20736                   // 000000053D38: DB7C5100 00002B48
	ds_store_b128 v72, v[23:26] offset:21520                   // 000000053D40: DB7C5410 00001748
	ds_store_b128 v72, v[6:9] offset:21504                     // 000000053D48: DB7C5400 00000648
	s_or_b32 exec_lo, exec_lo, s3                              // 000000053D50: 8C7E037E
	s_waitcnt lgkmcnt(0)                                       // 000000053D54: BF89FC07
	s_barrier                                                  // 000000053D58: BFBD0000
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 000000053D5C: 916A267E
	s_cbranch_vccnz 5                                          // 000000053D60: BFA40005 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c78>
	s_sendmsg_rtn_b64 s[56:57], sendmsg(MSG_RTN_GET_REALTIME)  // 000000053D64: BEB84D83
	s_waitcnt lgkmcnt(0)                                       // 000000053D68: BF89FC07
	s_sub_i32 s3, s6, s28                                      // 000000053D6C: 81831C06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000053D70: BF870009
	s_add_i32 s6, s3, s56                                      // 000000053D74: 81063803
	v_lshlrev_b32_e32 v59, 1, v153                             // 000000053D78: 30773281
	v_cmp_eq_u32_e32 vcc_lo, 0, v34                            // 000000053D7C: 7C944480
	v_mul_u32_u24_e32 v60, 48, v55                             // 000000053D80: 16786EB0
	s_cmp_lt_i32 s54, s39                                      // 000000053D84: BF042736
	ds_load_u16 v2, v59 offset:6416                            // 000000053D88: D8F01910 0200003B
	ds_load_u16 v3, v59 offset:7776                            // 000000053D90: D8F01E60 0300003B
	ds_load_u16 v4, v59 offset:7232                            // 000000053D98: D8F01C40 0400003B
	s_waitcnt lgkmcnt(0)                                       // 000000053DA0: BF89FC07
	ds_load_u16 v5, v59 offset:6688                            // 000000053DA4: D8F01A20 0500003B
	ds_load_u16 v6, v59 offset:6144                            // 000000053DAC: D8F01800 0600003B
	ds_load_b128 v[22:25], v60 offset:19984                    // 000000053DB4: DBFC4E10 1600003C
	ds_load_b128 v[18:21], v60 offset:19968                    // 000000053DBC: DBFC4E00 1200003C
	ds_load_b128 v[26:29], v60 offset:19200                    // 000000053DC4: DBFC4B00 1A00003C
	ds_load_b128 v[30:33], v60 offset:19216                    // 000000053DCC: DBFC4B10 1E00003C
	s_cselect_b32 s3, -1, 0                                    // 000000053DD4: 980380C1
	s_or_b32 s4, s54, 1                                        // 000000053DD8: 8C048136
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000053DDC: BF870159
	s_cmp_lt_i32 s4, s39                                       // 000000053DE0: BF042704
	s_cselect_b32 s4, -1, 0                                    // 000000053DE4: 980480C1
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000053DE8: 30040490
	s_waitcnt lgkmcnt(4)                                       // 000000053DEC: BF89FC47
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000053DF0: 300C0C90
	.long 0x7f141502                                           // 000000053DF4: 7F141502
	ds_load_u16 v2, v59 offset:6960                            // 000000053DF8: D8F01B30 0200003B
	v_cvt_f16_f32_e32 v10, v6                                  // 000000053E00: 7E141506
	s_waitcnt lgkmcnt(0)                                       // 000000053E04: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000053E08: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000053E0C: BF8700A1
	.long 0x7f161502                                           // 000000053E10: 7F161502
	v_lshlrev_b32_e32 v2, 16, v5                               // 000000053E14: 30040A90
	v_cvt_f16_f32_e32 v11, v2                                  // 000000053E18: 7E161502
	ds_load_u16 v2, v59 offset:7504                            // 000000053E1C: D8F01D50 0200003B
	s_waitcnt lgkmcnt(0)                                       // 000000053E24: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000053E28: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000053E2C: BF8700A1
	.long 0x7f181502                                           // 000000053E30: 7F181502
	v_lshlrev_b32_e32 v2, 16, v4                               // 000000053E34: 30040890
	v_cvt_f16_f32_e32 v12, v2                                  // 000000053E38: 7E181502
	ds_load_u16 v2, v59 offset:8048                            // 000000053E3C: D8F01F70 0200003B
	s_waitcnt lgkmcnt(0)                                       // 000000053E44: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000053E48: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000053E4C: BF8700A1
	.long 0x7f1a1502                                           // 000000053E50: 7F1A1502
	v_lshlrev_b32_e32 v2, 16, v3                               // 000000053E54: 30040690
	v_cvt_f16_f32_e32 v13, v2                                  // 000000053E58: 7E1A1502
	ds_load_u16 v2, v59 offset:8592                            // 000000053E5C: D8F02190 0200003B
	ds_load_u16 v3, v59 offset:9952                            // 000000053E64: D8F026E0 0300003B
	ds_load_u16 v4, v59 offset:9408                            // 000000053E6C: D8F024C0 0400003B
	ds_load_u16 v5, v59 offset:8864                            // 000000053E74: D8F022A0 0500003B
	ds_load_u16 v6, v59 offset:8320                            // 000000053E7C: D8F02080 0600003B
	s_waitcnt lgkmcnt(4)                                       // 000000053E84: BF89FC47
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000053E88: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000053E8C: BF8700B1
	.long 0x7f1c1502                                           // 000000053E90: 7F1C1502
	s_waitcnt lgkmcnt(0)                                       // 000000053E94: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v6                               // 000000053E98: 30040C90
	v_cvt_f16_f32_e32 v14, v2                                  // 000000053E9C: 7E1C1502
	ds_load_u16 v2, v59 offset:9136                            // 000000053EA0: D8F023B0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 000000053EA8: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000053EAC: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000053EB0: BF8700A1
	.long 0x7f1e1502                                           // 000000053EB4: 7F1E1502
	v_lshlrev_b32_e32 v2, 16, v5                               // 000000053EB8: 30040A90
	v_cvt_f16_f32_e32 v15, v2                                  // 000000053EBC: 7E1E1502
	ds_load_u16 v2, v59 offset:9680                            // 000000053EC0: D8F025D0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 000000053EC8: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000053ECC: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000053ED0: BF8700A1
	.long 0x7f201502                                           // 000000053ED4: 7F201502
	v_lshlrev_b32_e32 v2, 16, v4                               // 000000053ED8: 30040890
	v_cvt_f16_f32_e32 v16, v2                                  // 000000053EDC: 7E201502
	ds_load_u16 v2, v59 offset:10224                           // 000000053EE0: D8F027F0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 000000053EE8: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000053EEC: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000053EF0: BF8700A1
	.long 0x7f221502                                           // 000000053EF4: 7F221502
	v_lshlrev_b32_e32 v2, 16, v3                               // 000000053EF8: 30040690
	v_cvt_f16_f32_e32 v17, v2                                  // 000000053EFC: 7E221502
	v_dual_mov_b32 v2, s20 :: v_dual_mov_b32 v3, s21           // 000000053F00: CA100014 02020015
	v_dual_mov_b32 v4, s22 :: v_dual_mov_b32 v5, s23           // 000000053F08: CA100016 04040017
	v_dual_mov_b32 v6, s24 :: v_dual_mov_b32 v7, s25           // 000000053F10: CA100018 06060019
	v_dual_mov_b32 v8, s26 :: v_dual_mov_b32 v9, s27           // 000000053F18: CA10001A 0808001B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053F20: BF870121
	v_wmma_f32_16x16x16_f16 v[61:68], v[18:25], v[10:17], v[2:9]// 000000053F24: CC40403D 1C0A1512
	v_mov_b32_e32 v18, 0                                       // 000000053F2C: 7E240280
	v_wmma_f32_16x16x16_f16 v[61:68], v[26:33], v[10:17], v[61:68]// 000000053F30: CC40403D 1CF6151A
	v_dual_mov_b32 v10, 0 :: v_dual_cndmask_b32 v11, 0x7060302, v149// 000000053F38: CA120080 0A0B2AFF 07060302
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 000000053F44: CA100080 0C0C0080
	v_mov_b32_e32 v14, 0                                       // 000000053F4C: 7E1C0280
	s_waitcnt vmcnt(7)                                         // 000000053F50: BF891FF7
	s_delay_alu instid0(VALU_DEP_3)                            // 000000053F54: BF870003
	v_mov_b32_dpp v10, v42 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000053F58: 7E1402FA FF00B12A
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 000000053F60: CA100080 0F100080
	v_mov_b32_e32 v17, 0                                       // 000000053F68: 7E220280
	s_waitcnt vmcnt(6)                                         // 000000053F6C: BF891BF7
	v_mov_b32_dpp v12, v41 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000053F70: 7E1802FA FF00B129
	v_perm_b32 v10, v42, v10, v11                              // 000000053F78: D644000A 042E152A
	s_waitcnt vmcnt(5)                                         // 000000053F80: BF8917F7
	v_mov_b32_dpp v13, v40 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000053F84: 7E1A02FA FF00B128
	s_waitcnt vmcnt(4)                                         // 000000053F8C: BF8913F7
	v_mov_b32_dpp v14, v39 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000053F90: 7E1C02FA FF00B127
	s_waitcnt vmcnt(3)                                         // 000000053F98: BF890FF7
	v_mov_b32_dpp v15, v38 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000053F9C: 7E1E02FA FF00B126
	s_waitcnt vmcnt(2)                                         // 000000053FA4: BF890BF7
	v_mov_b32_dpp v16, v37 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000053FA8: 7E2002FA FF00B125
	s_waitcnt vmcnt(1)                                         // 000000053FB0: BF8907F7
	v_mov_b32_dpp v17, v35 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000053FB4: 7E2202FA FF00B123
	s_waitcnt vmcnt(0)                                         // 000000053FBC: BF8903F7
	v_mov_b32_dpp v18, v36 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000053FC0: 7E2402FA FF00B124
	v_perm_b32 v12, v41, v12, v11                              // 000000053FC8: D644000C 042E1929
	v_perm_b32 v13, v40, v13, v11                              // 000000053FD0: D644000D 042E1B28
	v_perm_b32 v14, v39, v14, v11                              // 000000053FD8: D644000E 042E1D27
	v_perm_b32 v15, v38, v15, v11                              // 000000053FE0: D644000F 042E1F26
	v_perm_b32 v16, v37, v16, v11                              // 000000053FE8: D6440010 042E2125
	v_perm_b32 v17, v35, v17, v11                              // 000000053FF0: D6440011 042E2323
	v_perm_b32 v11, v36, v18, v11                              // 000000053FF8: D644000B 042E2524
	v_lshlrev_b32_e32 v18, 16, v10                             // 000000054000: 30241490
	v_and_b32_e32 v19, 0xffff0000, v10                         // 000000054004: 362614FF FFFF0000
	ds_load_b128 v[30:33], v60 offset:21520                    // 00000005400C: DBFC5410 1E00003C
	ds_load_b128 v[26:29], v60 offset:21504                    // 000000054014: DBFC5400 1A00003C
	ds_load_b128 v[38:41], v60 offset:20752                    // 00000005401C: DBFC5110 2600003C
	ds_load_b128 v[34:37], v60 offset:20736                    // 000000054024: DBFC5100 2200003C
	v_cmp_eq_u32_e32 vcc_lo, 0, v154                           // 00000005402C: 7C953480
	v_cvt_f16_f32_e32 v10, v18                                 // 000000054030: 7E141512
	.long 0x7f141513                                           // 000000054034: 7F141513
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000054038: BF870112
	v_cndmask_b16 v18, 0, v10, s3                              // 00000005403C: D65D0012 000E1480
	v_cndmask_b16 v18, 0, v10, s4                              // 000000054044: D65D5012 00121480
	v_lshlrev_b32_e32 v10, 16, v12                             // 00000005404C: 30141890
	s_or_b32 s3, s54, 2                                        // 000000054050: 8C038236
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054054: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000054058: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000005405C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000054060: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000054064: BF870481
	v_cndmask_b16 v19, 0, v10, s3                              // 000000054068: D65D0013 000E1480
	v_and_b32_e32 v10, 0xffff0000, v12                         // 000000054070: 361418FF FFFF0000
	s_or_b32 s3, s54, 3                                        // 000000054078: 8C038336
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005407C: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000054080: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000054084: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000054088: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000005408C: BF870481
	v_cndmask_b16 v19, 0, v10, s3                              // 000000054090: D65D4013 000E1480
	v_lshlrev_b32_e32 v10, 16, v13                             // 000000054098: 30141A90
	s_or_b32 s3, s54, 4                                        // 00000005409C: 8C038436
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000540A0: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000540A4: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000540A8: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000540AC: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000540B0: BF870481
	v_cndmask_b16 v20, 0, v10, s3                              // 0000000540B4: D65D0014 000E1480
	v_and_b32_e32 v10, 0xffff0000, v13                         // 0000000540BC: 36141AFF FFFF0000
	s_or_b32 s3, s54, 5                                        // 0000000540C4: 8C038536
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000540C8: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000540CC: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000540D0: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000540D4: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000540D8: BF870481
	v_cndmask_b16 v20, 0, v10, s3                              // 0000000540DC: D65D4014 000E1480
	v_lshlrev_b32_e32 v10, 16, v14                             // 0000000540E4: 30141C90
	s_or_b32 s3, s54, 6                                        // 0000000540E8: 8C038636
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000540EC: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000540F0: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000540F4: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000540F8: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000540FC: BF870481
	v_cndmask_b16 v21, 0, v10, s3                              // 000000054100: D65D0015 000E1480
	v_and_b32_e32 v10, 0xffff0000, v14                         // 000000054108: 36141CFF FFFF0000
	s_or_b32 s3, s54, 7                                        // 000000054110: 8C038736
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054114: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000054118: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000005411C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000054120: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000054124: BF870481
	v_cndmask_b16 v21, 0, v10, s3                              // 000000054128: D65D4015 000E1480
	v_lshlrev_b32_e32 v10, 16, v15                             // 000000054130: 30141E90
	s_or_b32 s3, s54, 8                                        // 000000054134: 8C038836
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054138: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000005413C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000054140: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000054144: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000054148: BF870481
	v_cndmask_b16 v22, 0, v10, s3                              // 00000005414C: D65D0016 000E1480
	v_and_b32_e32 v10, 0xffff0000, v15                         // 000000054154: 36141EFF FFFF0000
	s_or_b32 s3, s54, 9                                        // 00000005415C: 8C038936
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054160: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000054164: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000054168: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000005416C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000054170: BF870481
	v_cndmask_b16 v22, 0, v10, s3                              // 000000054174: D65D4016 000E1480
	v_lshlrev_b32_e32 v10, 16, v16                             // 00000005417C: 30142090
	s_or_b32 s3, s54, 10                                       // 000000054180: 8C038A36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054184: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000054188: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000005418C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000054190: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000054194: BF870481
	v_cndmask_b16 v23, 0, v10, s3                              // 000000054198: D65D0017 000E1480
	v_and_b32_e32 v10, 0xffff0000, v16                         // 0000000541A0: 361420FF FFFF0000
	s_or_b32 s3, s54, 11                                       // 0000000541A8: 8C038B36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000541AC: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000541B0: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000541B4: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000541B8: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000541BC: BF870481
	v_cndmask_b16 v23, 0, v10, s3                              // 0000000541C0: D65D4017 000E1480
	v_lshlrev_b32_e32 v10, 16, v17                             // 0000000541C8: 30142290
	s_or_b32 s3, s54, 12                                       // 0000000541CC: 8C038C36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000541D0: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000541D4: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000541D8: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 0000000541DC: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000541E0: BF870481
	v_cndmask_b16 v24, 0, v10, s3                              // 0000000541E4: D65D0018 000E1480
	v_and_b32_e32 v10, 0xffff0000, v17                         // 0000000541EC: 361422FF FFFF0000
	s_or_b32 s3, s54, 13                                       // 0000000541F4: 8C038D36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000541F8: BF870099
	s_cmp_lt_i32 s3, s39                                       // 0000000541FC: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000054200: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000054204: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000054208: BF870481
	v_cndmask_b16 v24, 0, v10, s3                              // 00000005420C: D65D4018 000E1480
	v_lshlrev_b32_e32 v10, 16, v11                             // 000000054214: 30141690
	s_or_b32 s3, s54, 14                                       // 000000054218: 8C038E36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005421C: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000054220: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000054224: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000054228: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000005422C: BF870481
	v_cndmask_b16 v25, 0, v10, s3                              // 000000054230: D65D0019 000E1480
	v_and_b32_e32 v10, 0xffff0000, v11                         // 000000054238: 361416FF FFFF0000
	s_or_b32 s3, s54, 15                                       // 000000054240: 8C038F36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054244: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000054248: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000005424C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000054250: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000054254: BF870481
	v_cndmask_b16 v25, 0, v10, s3                              // 000000054258: D65D4019 000E1480
	s_waitcnt lgkmcnt(2)                                       // 000000054260: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000054264: BF8700A1
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[18:25], v[2:9]// 000000054268: CC40400A 1C0A251A
	s_waitcnt lgkmcnt(0)                                       // 000000054270: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[34:41], v[18:25], v[10:17]// 000000054274: CC40400A 1C2A2522
	v_cvt_f16_f32_e32 v18, v61                                 // 00000005427C: 7E24153D
	v_mad_u32_u24 v22, 0x110, v154, v59                        // 000000054280: D60B0016 04EF34FF 00000110
	.long 0x7f24153e                                           // 00000005428C: 7F24153E
	v_cvt_f16_f32_e32 v19, v63                                 // 000000054290: 7E26153F
	.long 0x7f261540                                           // 000000054294: 7F261540
	v_cvt_f16_f32_e32 v20, v65                                 // 000000054298: 7E281541
	.long 0x7f281542                                           // 00000005429C: 7F281542
	v_cvt_f16_f32_e32 v21, v67                                 // 0000000542A0: 7E2A1543
	.long 0x7f2a1544                                           // 0000000542A4: 7F2A1544
	ds_store_b16 v22, v18 offset:14848                         // 0000000542A8: D87C3A00 00001216
	ds_store_b16_d16_hi v22, v18 offset:15392                  // 0000000542B0: DA843C20 00001216
	ds_store_b16 v22, v19 offset:15936                         // 0000000542B8: D87C3E40 00001316
	ds_store_b16_d16_hi v22, v19 offset:16480                  // 0000000542C0: DA844060 00001316
	ds_store_b16 v22, v20 offset:17024                         // 0000000542C8: D87C4280 00001416
	ds_store_b16_d16_hi v22, v20 offset:17568                  // 0000000542D0: DA8444A0 00001416
	ds_store_b16 v22, v21 offset:18112                         // 0000000542D8: D87C46C0 00001516
	ds_store_b16_d16_hi v22, v21 offset:18656                  // 0000000542E0: DA8448E0 00001516
	v_fma_mixlo_f16 v18, v139, s51, 0                          // 0000000542E8: CC210012 0200678B
	v_fma_mixhi_f16 v18, v138, s51, 0                          // 0000000542F0: CC220012 0200678A
	v_mov_b32_e32 v20, 0x3020706                               // 0000000542F8: 7E2802FF 03020706
	v_cndmask_b32_e32 v61, 0x5040100, v149, vcc_lo             // 000000054300: 027B2AFF 05040100
	s_waitcnt lgkmcnt(0)                                       // 000000054308: BF89FC07
	s_barrier                                                  // 00000005430C: BFBD0000
	ds_load_b128 v[46:49], v57 offset:14864                    // 000000054310: DBFC3A10 2E000039
	ds_load_b128 v[42:45], v57 offset:14848                    // 000000054318: DBFC3A00 2A000039
	ds_load_b128 v[67:70], v57 offset:14896                    // 000000054320: DBFC3A30 43000039
	ds_load_b128 v[63:66], v57 offset:14880                    // 000000054328: DBFC3A20 3F000039
	v_dual_mov_b32 v19, v18 :: v_dual_cndmask_b32 v62, 0x7060302, v20// 000000054330: CA120112 133E28FF 07060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005433C: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000054340: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v26, v18, v19, v61                              // 00000005434C: D644001A 04F62712
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000054354: BF8700B3
	v_perm_b32 v27, v18, v19, v62                              // 000000054358: D644001B 04FA2712
	v_fma_mixlo_f16 v18, v137, s51, 0                          // 000000054360: CC210012 02006789
	v_fma_mixhi_f16 v18, v136, s51, 0                          // 000000054368: CC220012 02006788
	v_mov_b32_e32 v19, v18                                     // 000000054370: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054374: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000054378: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v28, v18, v19, v61                              // 000000054384: D644001C 04F62712
	v_perm_b32 v29, v18, v19, v62                              // 00000005438C: D644001D 04FA2712
	v_fma_mixlo_f16 v18, v135, s51, 0                          // 000000054394: CC210012 02006787
	v_fma_mixhi_f16 v18, v134, s51, 0                          // 00000005439C: CC220012 02006786
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000543A4: BF870091
	v_mov_b32_e32 v19, v18                                     // 0000000543A8: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 0000000543AC: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000543B8: BF8700C1
	v_perm_b32 v30, v18, v19, v61                              // 0000000543BC: D644001E 04F62712
	v_perm_b32 v31, v18, v19, v62                              // 0000000543C4: D644001F 04FA2712
	v_fma_mixlo_f16 v18, v133, s51, 0                          // 0000000543CC: CC210012 02006785
	v_fma_mixhi_f16 v18, v54, s51, 0                           // 0000000543D4: CC220012 02006736
	v_mov_b32_e32 v19, v18                                     // 0000000543DC: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000543E0: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 0000000543E4: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v32, v18, v19, v61                              // 0000000543F0: D6440020 04F62712
	v_perm_b32 v33, v18, v19, v62                              // 0000000543F8: D6440021 04FA2712
	v_fma_mixlo_f16 v18, v132, s51, 0                          // 000000054400: CC210012 02006784
	v_fma_mixhi_f16 v18, v131, s51, 0                          // 000000054408: CC220012 02006783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054410: BF870091
	v_mov_b32_e32 v19, v18                                     // 000000054414: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000054418: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000054424: BF8700C1
	v_perm_b32 v34, v18, v19, v61                              // 000000054428: D6440022 04F62712
	v_perm_b32 v35, v18, v19, v62                              // 000000054430: D6440023 04FA2712
	v_fma_mixlo_f16 v18, v130, s51, 0                          // 000000054438: CC210012 02006782
	v_fma_mixhi_f16 v18, v129, s51, 0                          // 000000054440: CC220012 02006781
	v_mov_b32_e32 v19, v18                                     // 000000054448: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005444C: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000054450: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v36, v18, v19, v61                              // 00000005445C: D6440024 04F62712
	v_perm_b32 v37, v18, v19, v62                              // 000000054464: D6440025 04FA2712
	v_fma_mixlo_f16 v18, v128, s51, 0                          // 00000005446C: CC210012 02006780
	v_fma_mixhi_f16 v18, v127, s51, 0                          // 000000054474: CC220012 0200677F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005447C: BF870091
	v_mov_b32_e32 v19, v18                                     // 000000054480: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000054484: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000054490: BF8700C1
	v_perm_b32 v38, v18, v19, v61                              // 000000054494: D6440026 04F62712
	v_perm_b32 v39, v18, v19, v62                              // 00000005449C: D6440027 04FA2712
	v_fma_mixlo_f16 v18, v126, s51, 0                          // 0000000544A4: CC210012 0200677E
	v_fma_mixhi_f16 v18, v53, s51, 0                           // 0000000544AC: CC220012 02006735
	v_mov_b32_e32 v19, v18                                     // 0000000544B4: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000544B8: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 0000000544BC: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v40, v18, v19, v61                              // 0000000544C8: D6440028 04F62712
	v_perm_b32 v41, v18, v19, v62                              // 0000000544D0: D6440029 04FA2712
	s_waitcnt lgkmcnt(2)                                       // 0000000544D8: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[26:33], v[2:9]// 0000000544DC: CC404012 1C0A352A
	s_waitcnt lgkmcnt(0)                                       // 0000000544E4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000544E8: BF870001
	v_wmma_f32_16x16x16_f16 v[18:25], v[63:70], v[34:41], v[18:25]// 0000000544EC: CC404012 1C4A453F
	ds_load_b128 v[63:66], v57 offset:10496                    // 0000000544F4: DBFC2900 3F000039
	ds_load_b128 v[67:70], v57 offset:10512                    // 0000000544FC: DBFC2910 43000039
	s_waitcnt lgkmcnt(0)                                       // 000000054504: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[63:70], v[26:33], v[2:9]// 000000054508: CC40402A 1C0A353F
	ds_load_b128 v[26:29], v57 offset:10528                    // 000000054510: DBFC2920 1A000039
	ds_load_b128 v[30:33], v57 offset:10544                    // 000000054518: DBFC2930 1E000039
	s_waitcnt lgkmcnt(0)                                       // 000000054520: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[26:33], v[34:41], v[42:49]// 000000054524: CC40402A 1CAA451A
	v_fma_mixlo_f16 v27, v125, s51, 0                          // 00000005452C: CC21001B 0200677D
	v_fma_mixhi_f16 v27, v124, s51, 0                          // 000000054534: CC22001B 0200677C
	v_fma_mixlo_f16 v29, v123, s51, 0                          // 00000005453C: CC21001D 0200677B
	v_fma_mixhi_f16 v29, v122, s51, 0                          // 000000054544: CC22001D 0200677A
	v_fma_mixlo_f16 v31, v121, s51, 0                          // 00000005454C: CC21001F 02006779
	v_fma_mixhi_f16 v31, v120, s51, 0                          // 000000054554: CC22001F 02006778
	v_fma_mixlo_f16 v33, v119, s51, 0                          // 00000005455C: CC210021 02006777
	v_fma_mixhi_f16 v33, v52, s51, 0                           // 000000054564: CC220021 02006734
	v_mov_b32_e32 v28, v27                                     // 00000005456C: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000054570: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000054574: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000054578: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000005457C: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000054580: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005458C: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000054590: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000005459C: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000545A8: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000545AC: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000545B8: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000545C0: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000545C8: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 0000000545D0: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 0000000545D8: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 0000000545E0: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 0000000545E8: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 0000000545F0: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14928                    // 0000000545F8: DBFC3A50 26000039
	ds_load_b128 v[34:37], v57 offset:14912                    // 000000054600: DBFC3A40 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000054608: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000005460C: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10576                    // 000000054614: DBFC2950 26000039
	ds_load_b128 v[34:37], v57 offset:10560                    // 00000005461C: DBFC2940 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000054624: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000054628: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v118, s51, 0                          // 000000054630: CC21001B 02006776
	v_fma_mixhi_f16 v27, v117, s51, 0                          // 000000054638: CC22001B 02006775
	v_fma_mixlo_f16 v29, v116, s51, 0                          // 000000054640: CC21001D 02006774
	v_fma_mixhi_f16 v29, v115, s51, 0                          // 000000054648: CC22001D 02006773
	v_fma_mixlo_f16 v31, v114, s51, 0                          // 000000054650: CC21001F 02006772
	v_fma_mixhi_f16 v31, v113, s51, 0                          // 000000054658: CC22001F 02006771
	v_fma_mixlo_f16 v33, v112, s51, 0                          // 000000054660: CC210021 02006770
	v_fma_mixhi_f16 v33, v51, s51, 0                           // 000000054668: CC220021 02006733
	v_mov_b32_e32 v28, v27                                     // 000000054670: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000054674: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000054678: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005467C: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000054680: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000054684: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000054690: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000054694: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 0000000546A0: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000546AC: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000546B0: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000546BC: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000546C4: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000546CC: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 0000000546D4: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 0000000546DC: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 0000000546E4: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 0000000546EC: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 0000000546F4: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14960                    // 0000000546FC: DBFC3A70 26000039
	ds_load_b128 v[34:37], v57 offset:14944                    // 000000054704: DBFC3A60 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000005470C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000054710: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10608                    // 000000054718: DBFC2970 26000039
	ds_load_b128 v[34:37], v57 offset:10592                    // 000000054720: DBFC2960 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000054728: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000005472C: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v111, s51, 0                          // 000000054734: CC21001B 0200676F
	v_fma_mixhi_f16 v27, v110, s51, 0                          // 00000005473C: CC22001B 0200676E
	v_fma_mixlo_f16 v29, v109, s51, 0                          // 000000054744: CC21001D 0200676D
	v_fma_mixhi_f16 v29, v108, s51, 0                          // 00000005474C: CC22001D 0200676C
	v_fma_mixlo_f16 v31, v107, s51, 0                          // 000000054754: CC21001F 0200676B
	v_fma_mixhi_f16 v31, v106, s51, 0                          // 00000005475C: CC22001F 0200676A
	v_fma_mixlo_f16 v33, v105, s51, 0                          // 000000054764: CC210021 02006769
	v_fma_mixhi_f16 v33, v50, s51, 0                           // 00000005476C: CC220021 02006732
	v_mov_b32_e32 v28, v27                                     // 000000054774: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000054778: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000005477C: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000054780: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000054784: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000054788: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000054794: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000054798: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 0000000547A4: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000547B0: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000547B4: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000547C0: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000547C8: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000547D0: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 0000000547D8: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 0000000547E0: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 0000000547E8: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 0000000547F0: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 0000000547F8: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14992                    // 000000054800: DBFC3A90 26000039
	ds_load_b128 v[34:37], v57 offset:14976                    // 000000054808: DBFC3A80 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000054810: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000054814: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10640                    // 00000005481C: DBFC2990 26000039
	ds_load_b128 v[34:37], v57 offset:10624                    // 000000054824: DBFC2980 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000005482C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000054830: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v104, s51, 0                          // 000000054838: CC21001B 02006768
	v_fma_mixhi_f16 v27, v103, s51, 0                          // 000000054840: CC22001B 02006767
	v_fma_mixlo_f16 v29, v102, s51, 0                          // 000000054848: CC21001D 02006766
	v_fma_mixhi_f16 v29, v101, s51, 0                          // 000000054850: CC22001D 02006765
	v_fma_mixlo_f16 v31, v100, s51, 0                          // 000000054858: CC21001F 02006764
	v_fma_mixhi_f16 v31, v99, s51, 0                           // 000000054860: CC22001F 02006763
	v_fma_mixlo_f16 v33, v98, s51, 0                           // 000000054868: CC210021 02006762
	v_fma_mixhi_f16 v33, v58, s51, 0                           // 000000054870: CC220021 0200673A
	v_mov_b32_e32 v28, v27                                     // 000000054878: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000005487C: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000054880: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000054884: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000054888: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000005488C: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000054898: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000005489C: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 0000000548A8: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000548B4: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000548B8: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000548C4: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000548CC: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000548D4: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 0000000548DC: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 0000000548E4: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 0000000548EC: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 0000000548F4: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 0000000548FC: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15024                    // 000000054904: DBFC3AB0 26000039
	ds_load_b128 v[34:37], v57 offset:15008                    // 00000005490C: DBFC3AA0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000054914: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000054918: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10672                    // 000000054920: DBFC29B0 26000039
	ds_load_b128 v[34:37], v57 offset:10656                    // 000000054928: DBFC29A0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000054930: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000054934: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v97, s51, 0                           // 00000005493C: CC21001B 02006761
	v_fma_mixhi_f16 v27, v96, s51, 0                           // 000000054944: CC22001B 02006760
	v_fma_mixlo_f16 v29, v95, s51, 0                           // 00000005494C: CC21001D 0200675F
	v_fma_mixhi_f16 v29, v94, s51, 0                           // 000000054954: CC22001D 0200675E
	v_fma_mixlo_f16 v31, v93, s51, 0                           // 00000005495C: CC21001F 0200675D
	v_fma_mixhi_f16 v31, v92, s51, 0                           // 000000054964: CC22001F 0200675C
	v_fma_mixlo_f16 v33, v91, s51, 0                           // 00000005496C: CC210021 0200675B
	v_fma_mixhi_f16 v33, v152, s51, 0                          // 000000054974: CC220021 02006798
	v_mov_b32_e32 v28, v27                                     // 00000005497C: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000054980: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000054984: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000054988: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000005498C: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000054990: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005499C: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 0000000549A0: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 0000000549AC: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000549B8: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000549BC: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000549C8: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000549D0: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000549D8: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 0000000549E0: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 0000000549E8: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 0000000549F0: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 0000000549F8: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000054A00: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15056                    // 000000054A08: DBFC3AD0 26000039
	ds_load_b128 v[34:37], v57 offset:15040                    // 000000054A10: DBFC3AC0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000054A18: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000054A1C: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10704                    // 000000054A24: DBFC29D0 26000039
	ds_load_b128 v[34:37], v57 offset:10688                    // 000000054A2C: DBFC29C0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000054A34: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000054A38: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v90, s51, 0                           // 000000054A40: CC21001B 0200675A
	v_fma_mixhi_f16 v27, v141, s51, 0                          // 000000054A48: CC22001B 0200678D
	v_fma_mixlo_f16 v29, v150, s51, 0                          // 000000054A50: CC21001D 02006796
	v_fma_mixhi_f16 v29, v142, s51, 0                          // 000000054A58: CC22001D 0200678E
	v_fma_mixlo_f16 v31, v191, s51, 0                          // 000000054A60: CC21001F 020067BF
	v_fma_mixhi_f16 v31, v189, s51, 0                          // 000000054A68: CC22001F 020067BD
	v_fma_mixlo_f16 v33, v190, s51, 0                          // 000000054A70: CC210021 020067BE
	v_fma_mixhi_f16 v33, v151, s51, 0                          // 000000054A78: CC220021 02006797
	v_mov_b32_e32 v28, v27                                     // 000000054A80: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000054A84: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000054A88: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000054A8C: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000054A90: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000054A94: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000054AA0: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000054AA4: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000054AB0: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000054ABC: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000054AC0: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 000000054ACC: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 000000054AD4: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000054ADC: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000054AE4: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000054AEC: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000054AF4: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000054AFC: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000054B04: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15088                    // 000000054B0C: DBFC3AF0 26000039
	ds_load_b128 v[34:37], v57 offset:15072                    // 000000054B14: DBFC3AE0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000054B1C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000054B20: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10736                    // 000000054B28: DBFC29F0 26000039
	ds_load_b128 v[34:37], v57 offset:10720                    // 000000054B30: DBFC29E0 22000039
	v_dual_mul_f32 v18, 0x3b800000, v18 :: v_dual_mul_f32 v19, 0x3b800000, v19// 000000054B38: C8C624FF 121226FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v20 :: v_dual_mul_f32 v21, 0x3b800000, v21// 000000054B44: C8C628FF 14142AFF 3B800000
	v_mul_f32_e32 v22, 0x3b800000, v22                         // 000000054B50: 102C2CFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000054B58: BF870223
	v_sub_f32_e32 v10, v10, v18                                // 000000054B5C: 0814250A
	v_or_b32_e32 v18, s54, v154                                // 000000054B60: 38253436
	v_dual_sub_f32 v11, v11, v19 :: v_dual_sub_f32 v12, v12, v20// 000000054B64: C94A270B 0B0C290C
	v_sub_f32_e32 v13, v13, v21                                // 000000054B6C: 081A2B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000054B70: BF870214
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 000000054B74: CC21000A 0200610A
	v_or_b32_e32 v19, 2, v18                                   // 000000054B7C: 38262482
	.long 0xd4440003                                           // 000000054B80: D4440003
	v_cndmask_b32_e32 v1, s39, v18, vcc_lo                     // 000000054B84: 02022427
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 000000054B88: CC22000A 0200610B
	v_dual_mul_f32 v23, 0x3b800000, v23 :: v_dual_sub_f32 v14, v14, v22// 000000054B90: C8CA2EFF 170E2D0E 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000054B9C: BF870214
	v_cmp_gt_i32_e32 vcc_lo, s39, v19                          // 000000054BA0: 7C882627
	v_cndmask_b16 v10, 0, v10, s3                              // 000000054BA4: D65D000A 000E1480
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000054BAC: BF8701D3
	v_dual_mul_f32 v24, 0x3b800000, v24 :: v_dual_sub_f32 v15, v15, v23// 000000054BB0: C8CA30FF 180E2F0F 3B800000
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 000000054BBC: 103232FF 3B800000
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000054BC4: D65D500A 01AA1480
	s_waitcnt lgkmcnt(0)                                       // 000000054BCC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000054BD0: CC40402A 1CAA3522
	v_dual_sub_f32 v16, v16, v24 :: v_dual_sub_f32 v17, v17, v25// 000000054BD8: C94A3110 10103311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000054BE0: BF8700C3
	v_mov_b32_e32 v11, v10                                     // 000000054BE4: 7E16030A
	ds_load_b128 v[19:22], v60 offset:23296                    // 000000054BE8: DBFC5B00 1300003C
	ds_load_b128 v[23:26], v60 offset:23312                    // 000000054BF0: DBFC5B10 1700003C
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000054BF8: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v66, v10, v11, v61                              // 000000054C04: D6440042 04F6170A
	v_perm_b32 v67, v10, v11, v62                              // 000000054C0C: D6440043 04FA170A
	v_or_b32_e32 v10, 4, v18                                   // 000000054C14: 38142484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000054C18: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 000000054C1C: 7C881427
	v_or_b32_e32 v10, 6, v18                                   // 000000054C20: 38142486
	.long 0xd4440004                                           // 000000054C24: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 000000054C28: 02021427
	v_fma_mixlo_f16 v10, v12, s48, 0                           // 000000054C2C: CC21000A 0200610C
	v_fma_mixhi_f16 v10, v13, s48, 0                           // 000000054C34: CC22000A 0200610D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000054C3C: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000054C40: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s4                              // 000000054C48: D65D500A 00121480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054C50: BF870091
	v_mov_b32_e32 v11, v10                                     // 000000054C54: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000054C58: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000054C64: BF8700B1
	v_perm_b32 v68, v10, v11, v61                              // 000000054C68: D6440044 04F6170A
	v_perm_b32 v69, v10, v11, v62                              // 000000054C70: D6440045 04FA170A
	v_or_b32_e32 v10, 8, v18                                   // 000000054C78: 38142488
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 000000054C7C: 7C881427
	v_or_b32_e32 v10, 10, v18                                  // 000000054C80: 3814248A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000054C84: BF870131
	.long 0xd4440004                                           // 000000054C88: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 000000054C8C: 02021427
	v_fma_mixlo_f16 v10, v14, s48, 0                           // 000000054C90: CC21000A 0200610E
	v_fma_mixhi_f16 v10, v15, s48, 0                           // 000000054C98: CC22000A 0200610F
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000054CA0: D65D000A 01AA1480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054CA8: BF870092
	v_cndmask_b16 v10, 0, v10, s4                              // 000000054CAC: D65D500A 00121480
	v_mov_b32_e32 v11, v10                                     // 000000054CB4: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054CB8: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000054CBC: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v70, v10, v11, v61                              // 000000054CC8: D6440046 04F6170A
	v_perm_b32 v71, v10, v11, v62                              // 000000054CD0: D6440047 04FA170A
	v_or_b32_e32 v10, 12, v18                                  // 000000054CD8: 3814248C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000054CDC: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 000000054CE0: 7C881427
	v_or_b32_e32 v10, 14, v18                                  // 000000054CE4: 3814248E
	.long 0xd4440004                                           // 000000054CE8: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 000000054CEC: 02021427
	v_fma_mixlo_f16 v10, v16, s48, 0                           // 000000054CF0: CC21000A 02006110
	v_fma_mixhi_f16 v10, v17, s48, 0                           // 000000054CF8: CC22000A 02006111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000054D00: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000054D04: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s4                              // 000000054D0C: D65D500A 00121480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054D14: BF870091
	v_mov_b32_e32 v11, v10                                     // 000000054D18: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000054D1C: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000054D28: BF8700B1
	v_perm_b32 v72, v10, v11, v61                              // 000000054D2C: D6440048 04F6170A
	v_perm_b32 v73, v10, v11, v62                              // 000000054D34: D6440049 04FA170A
	s_waitcnt lgkmcnt(0)                                       // 000000054D3C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[19:26], v[66:73], v[2:9]// 000000054D40: CC40400A 1C0A8513
	.long 0xd7000402                                           // 000000054D48: D7000402
	v_cndmask_b32_e32 v1, s44, v59, vcc_lo                     // 000000054D4C: 0202762C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000054D50: BF870001
	v_add_co_ci_u32_e64 v3, null, s45, 0, s4                   // 000000054D54: D5207C03 0011002D
	s_and_saveexec_b32 s4, s3                                  // 000000054D5C: BE842003
	s_cbranch_execz 19                                         // 000000054D60: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3cb0>
	ds_load_b32 v4, v56 offset:24320                           // 000000054D64: D8D85F00 04000038
	s_waitcnt lgkmcnt(0)                                       // 000000054D6C: BF89FC07
	v_mul_f32_e32 v4, v42, v4                                  // 000000054D70: 1008092A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054D74: BF870091
	v_add_f32_e32 v4, v10, v4                                  // 000000054D78: 0608090A
	v_mul_f32_e32 v6, 0x3b800000, v4                           // 000000054D7C: 100C08FF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v18, v[2:3]            // 000000054D84: D6FE7C04 040A24FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054D90: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000054D94: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000054D9C: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000054DA8: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s4                              // 000000054DB0: 8C7E047E
	v_or3_b32 v4, v154, s54, 2                                 // 000000054DB4: D6580004 02086D9A
	s_mov_b32 s3, exec_lo                                      // 000000054DBC: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000054DC0: BF870001
	.long 0xd4c4007e                                           // 000000054DC4: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000054DC8: 02020827
	s_cbranch_execz 19                                         // 000000054DCC: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d1c>
	ds_load_b32 v5, v56 offset:24328                           // 000000054DD0: D8D85F08 05000038
	s_waitcnt lgkmcnt(0)                                       // 000000054DD8: BF89FC07
	v_mul_f32_e32 v5, v43, v5                                  // 000000054DDC: 100A0B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054DE0: BF870091
	v_add_f32_e32 v5, v11, v5                                  // 000000054DE4: 060A0B0B
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000054DE8: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000054DF0: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054DFC: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000054E00: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000054E08: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000054E14: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000054E1C: 8C7E037E
	v_or3_b32 v4, v154, s54, 4                                 // 000000054E20: D6580004 02106D9A
	s_mov_b32 s3, exec_lo                                      // 000000054E28: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000054E2C: BF870001
	.long 0xd4c4007e                                           // 000000054E30: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000054E34: 02020827
	s_cbranch_execz 19                                         // 000000054E38: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d88>
	ds_load_b32 v5, v56 offset:24336                           // 000000054E3C: D8D85F10 05000038
	s_waitcnt lgkmcnt(0)                                       // 000000054E44: BF89FC07
	v_mul_f32_e32 v5, v44, v5                                  // 000000054E48: 100A0B2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054E4C: BF870091
	v_add_f32_e32 v5, v12, v5                                  // 000000054E50: 060A0B0C
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000054E54: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000054E5C: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054E68: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000054E6C: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000054E74: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000054E80: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000054E88: 8C7E037E
	v_or3_b32 v4, v154, s54, 6                                 // 000000054E8C: D6580004 02186D9A
	s_mov_b32 s3, exec_lo                                      // 000000054E94: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000054E98: BF870001
	.long 0xd4c4007e                                           // 000000054E9C: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000054EA0: 02020827
	s_cbranch_execz 19                                         // 000000054EA4: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3df4>
	ds_load_b32 v5, v56 offset:24344                           // 000000054EA8: D8D85F18 05000038
	s_waitcnt lgkmcnt(0)                                       // 000000054EB0: BF89FC07
	v_mul_f32_e32 v5, v45, v5                                  // 000000054EB4: 100A0B2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054EB8: BF870091
	v_add_f32_e32 v5, v13, v5                                  // 000000054EBC: 060A0B0D
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000054EC0: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000054EC8: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054ED4: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000054ED8: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000054EE0: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000054EEC: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000054EF4: 8C7E037E
	v_or3_b32 v4, v154, s54, 8                                 // 000000054EF8: D6580004 02206D9A
	s_mov_b32 s3, exec_lo                                      // 000000054F00: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000054F04: BF870001
	.long 0xd4c4007e                                           // 000000054F08: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000054F0C: 02020827
	s_cbranch_execz 19                                         // 000000054F10: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3e60>
	ds_load_b32 v5, v56 offset:24352                           // 000000054F14: D8D85F20 05000038
	s_waitcnt lgkmcnt(0)                                       // 000000054F1C: BF89FC07
	v_mul_f32_e32 v5, v46, v5                                  // 000000054F20: 100A0B2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054F24: BF870091
	v_add_f32_e32 v5, v14, v5                                  // 000000054F28: 060A0B0E
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000054F2C: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000054F34: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054F40: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000054F44: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000054F4C: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000054F58: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000054F60: 8C7E037E
	v_or3_b32 v4, v154, s54, 10                                // 000000054F64: D6580004 02286D9A
	s_mov_b32 s3, exec_lo                                      // 000000054F6C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000054F70: BF870001
	.long 0xd4c4007e                                           // 000000054F74: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000054F78: 02020827
	s_cbranch_execz 19                                         // 000000054F7C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3ecc>
	ds_load_b32 v5, v56 offset:24360                           // 000000054F80: D8D85F28 05000038
	s_waitcnt lgkmcnt(0)                                       // 000000054F88: BF89FC07
	v_mul_f32_e32 v5, v47, v5                                  // 000000054F8C: 100A0B2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054F90: BF870091
	v_add_f32_e32 v5, v15, v5                                  // 000000054F94: 060A0B0F
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000054F98: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000054FA0: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054FAC: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000054FB0: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000054FB8: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000054FC4: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000054FCC: 8C7E037E
	v_or3_b32 v4, v154, s54, 12                                // 000000054FD0: D6580004 02306D9A
	s_mov_b32 s3, exec_lo                                      // 000000054FD8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000054FDC: BF870001
	.long 0xd4c4007e                                           // 000000054FE0: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000054FE4: 02020827
	s_cbranch_execz 19                                         // 000000054FE8: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3f38>
	ds_load_b32 v5, v56 offset:24368                           // 000000054FEC: D8D85F30 05000038
	s_waitcnt lgkmcnt(0)                                       // 000000054FF4: BF89FC07
	v_mul_f32_e32 v5, v48, v5                                  // 000000054FF8: 100A0B30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054FFC: BF870091
	v_add_f32_e32 v5, v16, v5                                  // 000000055000: 060A0B10
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000055004: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000005500C: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055018: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000005501C: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000055024: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000055030: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000055038: 8C7E037E
	v_or3_b32 v4, v154, s54, 14                                // 00000005503C: D6580004 02386D9A
	s_mov_b32 s3, exec_lo                                      // 000000055044: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000055048: BF870001
	.long 0xd4c4007e                                           // 00000005504C: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000055050: 02020827
	s_cbranch_execz 19                                         // 000000055054: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3fa4>
	ds_load_b32 v5, v56 offset:24376                           // 000000055058: D8D85F38 05000038
	v_mad_u64_u32 v[2:3], null, 0x3000, v4, v[2:3]             // 000000055060: D6FE7C02 040A08FF 00003000
	s_waitcnt lgkmcnt(0)                                       // 00000005506C: BF89FC07
	v_mul_f32_e32 v5, v49, v5                                  // 000000055070: 100A0B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055074: BF870091
	v_add_f32_e32 v5, v17, v5                                  // 000000055078: 060A0B11
	v_mul_f32_e32 v5, 0x3b800000, v5                           // 00000005507C: 100A0AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055084: BF870091
	v_bfe_u32 v6, v5, 16, 1                                    // 000000055088: D6100006 02052105
	v_add3_u32 v4, v5, v6, 0x7fff                              // 000000055090: D6550004 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000005509C: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000550A4: 8C7E037E
	ds_load_b32 v56, v1 offset:24188                           // 0000000550A8: D8D85E7C 38000001
	v_mad_u32_u24 v2, v55, 48, 0x4b00                          // 0000000550B0: D60B0002 03FD6137 00004B00
	s_add_i32 s54, s54, 16                                     // 0000000550BC: 81369036
	v_mov_b32_e32 v178, s27                                    // 0000000550C0: 7F64021B
	v_dual_mov_b32 v176, s25 :: v_dual_mov_b32 v173, s22       // 0000000550C4: CA100019 B0AC0016
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000550CC: BF870003
	v_dual_mov_b32 v174, s23 :: v_dual_add_nc_u32 v55, 0xffffb500, v2// 0000000550D0: CA200017 AE3604FF FFFFB500
	v_dual_mov_b32 v171, s20 :: v_dual_mov_b32 v172, s21       // 0000000550DC: CA100014 ABAC0015
	ds_load_b128 v[159:162], v55 offset:2320                   // 0000000550E4: DBFC0910 9F000037
	ds_load_b128 v[155:158], v55 offset:2304                   // 0000000550EC: DBFC0900 9B000037
	ds_load_b128 v[167:170], v55 offset:3088                   // 0000000550F4: DBFC0C10 A7000037
	ds_load_b128 v[163:166], v55 offset:3072                   // 0000000550FC: DBFC0C00 A3000037
	ds_load_b128 v[2:5], v55                                   // 000000055104: DBFC0000 02000037
	ds_load_b128 v[6:9], v55 offset:16                         // 00000005510C: DBFC0010 06000037
	ds_load_b128 v[82:85], v55 offset:4608                     // 000000055114: DBFC1200 52000037
	ds_load_b128 v[183:186], v55 offset:3856                   // 00000005511C: DBFC0F10 B7000037
	ds_load_b128 v[179:182], v55 offset:3840                   // 000000055124: DBFC0F00 B3000037
	ds_load_b128 v[86:89], v55 offset:4624                     // 00000005512C: DBFC1210 56000037
	v_mov_b32_e32 v177, s26                                    // 000000055134: 7F62021A
	v_mov_b32_e32 v175, s24                                    // 000000055138: 7F5E0218
	s_waitcnt lgkmcnt(10)                                      // 00000005513C: BF89FCA7
	v_readfirstlane_b32 s3, v56                                // 000000055140: 7E060538
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v56                  // 000000055144: 7C3670FF C2CE8ED0
	s_mul_f32 s3, s3, 0x3fb8aa3b                               // 00000005514C: A203FF03 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 000000055154: BF87000B
	s_xor_b32 s4, s3, 0x80000000                               // 000000055158: 8D04FF03 80000000
	s_cmp_lg_u32 s12, s54                                      // 000000055160: BF07360C
	v_fma_f32 v10, 0x3fb8aa3b, v56, s4                         // 000000055164: D613000A 001270FF 3FB8AA3B
	s_rndne_f32 s4, s3                                         // 000000055170: BE846303
	s_waitcnt lgkmcnt(4)                                       // 000000055174: BF89FC47
	v_wmma_f32_16x16x16_f16 v[34:41], v[2:9], v[66:73], v[171:178]// 000000055178: CC404022 1EAE8502
	s_delay_alu instid0(VALU_DEP_2)                            // 000000055180: BF870002
	v_fmac_f32_e32 v10, 0x32a5705f, v56                        // 000000055184: 561470FF 32A5705F
	s_sub_f32 s3, s3, s4                                       // 00000005518C: A0830403
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_3)    // 000000055190: BF870581
	v_add_f32_e32 v18, s3, v10                                 // 000000055194: 06241403
	s_cvt_i32_f32 s3, s4                                       // 000000055198: BE836604
	ds_load_b128 v[14:17], v55 offset:784                      // 00000005519C: DBFC0310 0E000037
	ds_load_b128 v[10:13], v55 offset:768                      // 0000000551A4: DBFC0300 0A000037
	ds_load_b128 v[46:49], v55 offset:1552                     // 0000000551AC: DBFC0610 2E000037
	ds_load_b128 v[42:45], v55 offset:1536                     // 0000000551B4: DBFC0600 2A000037
	v_exp_f32_e32 v18, v18                                     // 0000000551BC: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000551C0: BF870095
	.long 0xd71c0012                                           // 0000000551C4: D71C0012
	v_cndmask_b32_e32 v0, v18, v3, vcc_lo                      // 0000000551C8: 02000712
	v_cndmask_b32_e32 v2, 0, v18, vcc_lo                       // 0000000551CC: 02042480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v56                  // 0000000551D0: 7C3C70FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000551D8: BF870092
	v_cndmask_b32_e32 v145, 0x7f800000, v2, vcc_lo             // 0000000551DC: 032204FF 7F800000
	v_fmac_f32_e32 v41, v54, v145                              // 0000000551E4: 56532336
	s_waitcnt lgkmcnt(2)                                       // 0000000551E8: BF89FC27
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[66:73], v[171:178]// 0000000551EC: CC40401A 1EAE850A
	v_wmma_f32_16x16x16_f16 v[10:17], v[155:162], v[66:73], v[171:178]// 0000000551F4: CC40400A 1EAE859B
	ds_load_b128 v[159:162], v55 offset:5392                   // 0000000551FC: DBFC1510 9F000037
	ds_load_b128 v[155:158], v55 offset:5376                   // 000000055204: DBFC1500 9B000037
	s_waitcnt lgkmcnt(2)                                       // 00000005520C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[66:73], v[171:178]// 000000055210: CC404012 1EAE852A
	v_wmma_f32_16x16x16_f16 v[2:9], v[163:170], v[66:73], v[171:178]// 000000055218: CC404002 1EAE85A3
	v_wmma_f32_16x16x16_f16 v[42:49], v[179:186], v[66:73], v[171:178]// 000000055220: CC40402A 1EAE85B3
	v_fma_f32 v138, v138, v145, v35                            // 000000055228: D613008A 048F238A
	v_fma_f32 v136, v136, v145, v37                            // 000000055230: D6130088 04972388
	v_fma_f32 v135, v135, v145, v38                            // 000000055238: D6130087 049B2387
	v_fma_f32 v131, v131, v145, v27                            // 000000055240: D6130083 046F2383
	v_fmac_f32_e32 v33, v53, v145                              // 000000055248: 56432335
	v_fmac_f32_e32 v25, v52, v145                              // 00000005524C: 56332334
	v_fmac_f32_e32 v17, v51, v145                              // 000000055250: 56232333
	v_fmac_f32_e32 v9, v50, v145                               // 000000055254: 56132332
	v_wmma_f32_16x16x16_f16 v[50:57], v[82:89], v[66:73], v[171:178]// 000000055258: CC404032 1EAE8552
	v_fmac_f32_e32 v49, v58, v145                              // 000000055260: 5663233A
	v_fma_f32 v139, v139, v145, v34                            // 000000055264: D613008B 048B238B
	v_fma_f32 v137, v137, v145, v36                            // 00000005526C: D6130089 04932389
	s_waitcnt lgkmcnt(0)                                       // 000000055274: BF89FC07
	v_wmma_f32_16x16x16_f16 v[58:65], v[155:162], v[66:73], v[171:178]// 000000055278: CC40403A 1EAE859B
	v_fma_f32 v134, v134, v145, v39                            // 000000055280: D6130086 049F2386
	v_fma_f32 v133, v133, v145, v40                            // 000000055288: D6130085 04A32385
	v_fma_f32 v132, v132, v145, v26                            // 000000055290: D6130084 046B2384
	v_fma_f32 v130, v130, v145, v28                            // 000000055298: D6130082 04732382
	v_fma_f32 v129, v129, v145, v29                            // 0000000552A0: D6130081 04772381
	v_fma_f32 v128, v128, v145, v30                            // 0000000552A8: D6130080 047B2380
	v_fma_f32 v127, v127, v145, v31                            // 0000000552B0: D613007F 047F237F
	v_fma_f32 v126, v126, v145, v32                            // 0000000552B8: D613007E 0483237E
	v_fma_f32 v125, v125, v145, v18                            // 0000000552C0: D613007D 044B237D
	v_fma_f32 v124, v124, v145, v19                            // 0000000552C8: D613007C 044F237C
	v_fma_f32 v123, v123, v145, v20                            // 0000000552D0: D613007B 0453237B
	v_fma_f32 v122, v122, v145, v21                            // 0000000552D8: D613007A 0457237A
	v_fma_f32 v121, v121, v145, v22                            // 0000000552E0: D6130079 045B2379
	v_fma_f32 v120, v120, v145, v23                            // 0000000552E8: D6130078 045F2378
	v_fma_f32 v119, v119, v145, v24                            // 0000000552F0: D6130077 04632377
	v_fma_f32 v118, v118, v145, v10                            // 0000000552F8: D6130076 042B2376
	v_fma_f32 v117, v117, v145, v11                            // 000000055300: D6130075 042F2375
	v_fma_f32 v116, v116, v145, v12                            // 000000055308: D6130074 04332374
	v_fma_f32 v115, v115, v145, v13                            // 000000055310: D6130073 04372373
	v_fma_f32 v114, v114, v145, v14                            // 000000055318: D6130072 043B2372
	v_fma_f32 v113, v113, v145, v15                            // 000000055320: D6130071 043F2371
	v_fma_f32 v112, v112, v145, v16                            // 000000055328: D6130070 04432370
	v_fma_f32 v111, v111, v145, v2                             // 000000055330: D613006F 040B236F
	v_fma_f32 v110, v110, v145, v3                             // 000000055338: D613006E 040F236E
	v_fma_f32 v109, v109, v145, v4                             // 000000055340: D613006D 0413236D
	v_fma_f32 v108, v108, v145, v5                             // 000000055348: D613006C 0417236C
	v_fma_f32 v107, v107, v145, v6                             // 000000055350: D613006B 041B236B
	v_fma_f32 v106, v106, v145, v7                             // 000000055358: D613006A 041F236A
	v_fma_f32 v105, v105, v145, v8                             // 000000055360: D6130069 04232369
	v_fma_f32 v104, v104, v145, v42                            // 000000055368: D6130068 04AB2368
	v_fma_f32 v103, v103, v145, v43                            // 000000055370: D6130067 04AF2367
	v_fma_f32 v102, v102, v145, v44                            // 000000055378: D6130066 04B32366
	v_fma_f32 v101, v101, v145, v45                            // 000000055380: D6130065 04B72365
	v_fma_f32 v100, v100, v145, v46                            // 000000055388: D6130064 04BB2364
	v_fma_f32 v99, v99, v145, v47                              // 000000055390: D6130063 04BF2363
	v_fma_f32 v98, v98, v145, v48                              // 000000055398: D6130062 04C32362
	v_fma_f32 v97, v97, v145, v50                              // 0000000553A0: D6130061 04CB2361
	v_fma_f32 v96, v96, v145, v51                              // 0000000553A8: D6130060 04CF2360
	v_fma_f32 v95, v95, v145, v52                              // 0000000553B0: D613005F 04D3235F
	v_fma_f32 v94, v94, v145, v53                              // 0000000553B8: D613005E 04D7235E
	v_fma_f32 v93, v93, v145, v54                              // 0000000553C0: D613005D 04DB235D
	v_fma_f32 v92, v92, v145, v55                              // 0000000553C8: D613005C 04DF235C
	v_fma_f32 v91, v91, v145, v56                              // 0000000553D0: D613005B 04E3235B
	v_fmac_f32_e32 v57, v152, v145                             // 0000000553D8: 56732398
	v_fma_f32 v90, v90, v145, v58                              // 0000000553DC: D613005A 04EB235A
	v_fma_f32 v141, v141, v145, v59                            // 0000000553E4: D613008D 04EF238D
	v_fma_f32 v150, v150, v145, v60                            // 0000000553EC: D6130096 04F32396
	v_fma_f32 v142, v142, v145, v61                            // 0000000553F4: D613008E 04F7238E
	v_fma_f32 v191, v191, v145, v62                            // 0000000553FC: D61300BF 04FB23BF
	v_fma_f32 v189, v189, v145, v63                            // 000000055404: D61300BD 04FF23BD
	v_fma_f32 v190, v190, v145, v64                            // 00000005540C: D61300BE 050323BE
	v_dual_fmac_f32 v65, v151, v145 :: v_dual_mul_f32 v6, 0x3b800000, v128// 000000055414: C8072397 410700FF 3B800000
	v_lshl_add_u32 v2, v154, 7, v153                           // 000000055420: D6460002 06650F9A
	v_dual_mul_f32 v69, 0x3b800000, v139 :: v_dual_mul_f32 v152, 0x3b800000, v41// 000000055428: C8C716FF 459852FF 3B800000
	v_dual_mul_f32 v70, 0x3b800000, v138 :: v_dual_mul_f32 v71, 0x3b800000, v137// 000000055434: C8C714FF 464712FF 3B800000
	v_mul_f32_e32 v64, 0x3b800000, v127                        // 000000055440: 1080FEFF 3B800000
	v_mul_f32_e32 v72, 0x3b800000, v136                        // 000000055448: 109110FF 3B800000
	v_dual_mul_f32 v4, 0x3b800000, v135 :: v_dual_mul_f32 v73, 0x3b800000, v134// 000000055450: C8C70EFF 04490CFF 3B800000
	v_dual_mul_f32 v60, 0x3b800000, v123 :: v_dual_mul_f32 v151, 0x3b800000, v133// 00000005545C: C8C6F6FF 3C970AFF 3B800000
	v_dual_mul_f32 v66, 0x3b800000, v126 :: v_dual_mul_f32 v5, 0x3b800000, v132// 000000055468: C8C6FCFF 420508FF 3B800000
	v_mul_f32_e32 v8, 0x3b800000, v121                         // 000000055474: 1010F2FF 3B800000
	v_mul_f32_e32 v68, 0x3b800000, v131                        // 00000005547C: 108906FF 3B800000
	v_dual_mul_f32 v62, 0x3b800000, v130 :: v_dual_mul_f32 v63, 0x3b800000, v129// 000000055484: C8C704FF 3E3F02FF 3B800000
	v_dual_mul_f32 v52, 0x3b800000, v120 :: v_dual_mul_f32 v67, 0x3b800000, v33// 000000055490: C8C6F0FF 344242FF 3B800000
	v_dual_mul_f32 v10, 0x3b800000, v118 :: v_dual_mul_f32 v7, 0x3b800000, v125// 00000005549C: C8C6ECFF 0A06FAFF 3B800000
	v_mul_f32_e32 v56, 0x3b800000, v116                        // 0000000554A8: 1070E8FF 3B800000
	v_dual_mul_f32 v59, 0x3b800000, v124 :: v_dual_mul_f32 v54, 0x3b800000, v25// 0000000554B0: C8C6F8FF 3B3632FF 3B800000
	v_dual_mul_f32 v61, 0x3b800000, v122 :: v_dual_mul_f32 v58, 0x3b800000, v115// 0000000554BC: C8C6F4FF 3D3AE6FF 3B800000
	v_dual_mul_f32 v53, 0x3b800000, v119 :: v_dual_mul_f32 v50, 0x3b800000, v113// 0000000554C8: C8C6EEFF 3532E2FF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v117 :: v_dual_mul_f32 v12, 0x3b800000, v111// 0000000554D4: C8C6EAFF 370CDEFF 3B800000
	v_dual_mul_f32 v11, 0x3b800000, v114 :: v_dual_mul_f32 v40, 0x3b800000, v17// 0000000554E0: C8C6E4FF 0B2822FF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v112 :: v_dual_mul_f32 v44, 0x3b800000, v109// 0000000554EC: C8C6E0FF 332CDAFF 3B800000
	v_dual_mul_f32 v43, 0x3b800000, v110 :: v_dual_mul_f32 v14, 0x3b800000, v107// 0000000554F8: C8C6DCFF 2B0ED6FF 3B800000
	v_dual_mul_f32 v45, 0x3b800000, v108 :: v_dual_mul_f32 v46, 0x3b800000, v106// 000000055504: C8C6D8FF 2D2ED4FF 3B800000
	v_dual_mul_f32 v47, 0x3b800000, v105 :: v_dual_mul_f32 v42, 0x3b800000, v103// 000000055510: C8C6D2FF 2F2ACEFF 3B800000
	v_dual_mul_f32 v48, 0x3b800000, v9 :: v_dual_mul_f32 v15, 0x3b800000, v104// 00000005551C: C8C612FF 300ED0FF 3B800000
	v_dual_mul_f32 v35, 0x3b800000, v102 :: v_dual_mul_f32 v36, 0x3b800000, v101// 000000055528: C8C6CCFF 2324CAFF 3B800000
	v_dual_mul_f32 v27, 0x3b800000, v100 :: v_dual_mul_f32 v38, 0x3b800000, v98// 000000055534: C8C6C8FF 1B26C4FF 3B800000
	v_dual_mul_f32 v37, 0x3b800000, v99 :: v_dual_mul_f32 v28, 0x3b800000, v97// 000000055540: C8C6C6FF 251CC2FF 3B800000
	v_dual_mul_f32 v39, 0x3b800000, v49 :: v_dual_mul_f32 v32, 0x3b800000, v95// 00000005554C: C8C662FF 2720BEFF 3B800000
	v_dual_mul_f32 v31, 0x3b800000, v96 :: v_dual_mul_f32 v34, 0x3b800000, v94// 000000055558: C8C6C0FF 1F22BCFF 3B800000
	v_dual_mul_f32 v29, 0x3b800000, v93 :: v_dual_mul_f32 v20, 0x3b800000, v92// 000000055564: C8C6BAFF 1D14B8FF 3B800000
	v_dual_mul_f32 v21, 0x3b800000, v91 :: v_dual_mul_f32 v22, 0x3b800000, v57// 000000055570: C8C6B6FF 151672FF 3B800000
	v_dual_mul_f32 v30, 0x3b800000, v90 :: v_dual_mul_f32 v23, 0x3b800000, v141// 00000005557C: C8C6B4FF 1E171AFF 3B800000
	v_dual_mul_f32 v24, 0x3b800000, v150 :: v_dual_mul_f32 v13, 0x3b800000, v65// 000000055588: C8C72CFF 180C82FF 3B800000
	v_mul_f32_e32 v26, 0x3b800000, v142                        // 000000055594: 10351CFF 3B800000
	v_dual_mul_f32 v16, 0x3b800000, v191 :: v_dual_mul_f32 v19, 0x3b800000, v190// 00000005559C: C8C77EFF 10137CFF 3B800000
	v_mul_f32_e32 v18, 0x3b800000, v189                        // 0000000555A8: 10257AFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 0000000555B0: BF89FC07
	s_barrier                                                  // 0000000555B4: BFBD0000
	s_cbranch_scc0 5                                           // 0000000555B8: BFA10005 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44d0>
	s_cmp_lg_u32 s13, s54                                      // 0000000555BC: BF07360D
	s_cbranch_scc0 273                                         // 0000000555C0: BFA10111 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4908>
	s_cmp_lg_u32 s14, s54                                      // 0000000555C4: BF07360E
	s_cbranch_scc1 61712                                       // 0000000555C8: BFA2F110 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	s_branch 540                                               // 0000000555CC: BFA0021C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4d40>
	v_mov_b32_e32 v82, v2                                      // 0000000555D0: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000555D4: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 0000000555D8: 34A6A49F
	.long 0xd73c0052                                           // 0000000555DC: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 0000000555E0: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000555E4: BF870091
	.long 0xd7006a52                                           // 0000000555E8: D7006A52
	v_cndmask_b32_e32 v1, s16, v82, vcc_lo                     // 0000000555EC: 0202A410
	v_add_co_ci_u32_e64 v83, null, s17, v83, vcc_lo            // 0000000555F0: D5207C53 01AAA611
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000555F8: BF870092
	.long 0xd7006a54                                           // 0000000555FC: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 000000055600: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000055608: D5207C55 01AAA680
	.long 0xd7006a56                                           // 000000055610: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000055614: 0201FF52
	.long 0x00002000                                           // 000000055618: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005561C: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 000000055620: D5207C57 01AAA680
	.long 0xd7006a58                                           // 000000055628: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 00000005562C: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 000000055634: D5207C59 01AAA680
	s_clause 0x7                                               // 00000005563C: BF850007
	global_store_b32 v[82:83], v69, off                        // 000000055640: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 000000055648: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 000000055650: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 000000055658: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 000000055660: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 000000055668: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 000000055670: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 000000055678: DC6A0400 007C4458
	.long 0xd7006a54                                           // 000000055680: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 000000055684: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005568C: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000055690: D5207C55 01AAA680
	.long 0xd7006a99                                           // 000000055698: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005569C: 0201FF52
	.long 0x00004000                                           // 0000000556A0: 00004000
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 0000000556A4: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 0000000556AC: D7006A9B
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 0000000556B0: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000556B8: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 0000000556BC: D5207C9C 01AAA680
	s_clause 0x7                                               // 0000000556C4: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 0000000556C8: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 0000000556D0: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 0000000556D8: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 0000000556E0: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 0000000556E8: DC6A0C00 007C4354
	global_store_b32 v[155:156], v59, off offset:1024          // 0000000556F0: DC6A0400 007C3B9B
	global_store_b32 v[155:156], v60, off offset:2048          // 0000000556F8: DC6A0800 007C3C9B
	global_store_b32 v[155:156], v61, off offset:3072          // 000000055700: DC6A0C00 007C3D9B
	.long 0xd7006a54                                           // 000000055708: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 00000005570C: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055714: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000055718: D5207C55 01AAA680
	.long 0xd7006a58                                           // 000000055720: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000055724: 0201FF52
	.long 0x00006000                                           // 000000055728: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000005572C: D5207C59 01AAA680
	.long 0xd7006a9b                                           // 000000055734: D7006A9B
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 000000055738: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055740: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000055744: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000005574C: D7006A9D
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 000000055750: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 000000055758: D5207C9E 01AAA680
	.long 0xd7006a9f                                           // 000000055760: D7006A9F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000055764: 0201FF52
	.long 0x00008000                                           // 000000055768: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005576C: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v83, vcc_lo             // 000000055770: D5207CA0 01AAA680
	s_clause 0x7                                               // 000000055778: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 00000005577C: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 000000055784: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 00000005578C: DC6A0C00 007C3654
	global_store_b32 v[155:156], v55, off offset:1024          // 000000055794: DC6A0400 007C379B
	global_store_b32 v[155:156], v56, off offset:2048          // 00000005579C: DC6A0800 007C389B
	global_store_b32 v[155:156], v58, off offset:3072          // 0000000557A4: DC6A0C00 007C3A9B
	global_store_b32 v[157:158], v50, off offset:1024          // 0000000557AC: DC6A0400 007C329D
	global_store_b32 v[157:158], v51, off offset:2048          // 0000000557B4: DC6A0800 007C339D
	.long 0xd7006a54                                           // 0000000557BC: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 0000000557C0: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000557C8: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000557CC: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 0000000557D4: D7006A9B
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 0000000557D8: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 0000000557E0: D5207C9C 01AAA680
	.long 0xd7006aa1                                           // 0000000557E8: D7006AA1
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000557EC: 0201FF52
	.long 0x0000a000                                           // 0000000557F0: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000557F4: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v83, vcc_lo             // 0000000557F8: D5207CA2 01AAA680
	.long 0xd7006aa3                                           // 000000055800: D7006AA3
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 000000055804: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000005580C: D5207CA4 01AAA680
	s_clause 0x7                                               // 000000055814: BF850007
	global_store_b32 v[157:158], v40, off offset:3072          // 000000055818: DC6A0C00 007C289D
	global_store_b32 v[84:85], v43, off offset:1024            // 000000055820: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 000000055828: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 000000055830: DC6A0C00 007C2D54
	global_store_b32 v[155:156], v46, off offset:1024          // 000000055838: DC6A0400 007C2E9B
	global_store_b32 v[155:156], v47, off offset:2048          // 000000055840: DC6A0800 007C2F9B
	global_store_b32 v[155:156], v48, off offset:3072          // 000000055848: DC6A0C00 007C309B
	global_store_b32 v[163:164], v42, off offset:1024          // 000000055850: DC6A0400 007C2AA3
	.long 0xd7006a54                                           // 000000055858: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 00000005585C: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055864: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000055868: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 000000055870: D7006A9B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000055874: 0201FF52
	.long 0x0000c000                                           // 000000055878: 0000C000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000005587C: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 000000055884: D7006A9D
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 000000055888: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000055890: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 000000055894: D5207C9E 01AAA680
	s_clause 0x7                                               // 00000005589C: BF850007
	global_store_b32 v[163:164], v35, off offset:2048          // 0000000558A0: DC6A0800 007C23A3
	global_store_b32 v[163:164], v36, off offset:3072          // 0000000558A8: DC6A0C00 007C24A3
	global_store_b32 v[84:85], v37, off offset:1024            // 0000000558B0: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 0000000558B8: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 0000000558C0: DC6A0C00 007C2754
	global_store_b32 v[157:158], v31, off offset:1024          // 0000000558C8: DC6A0400 007C1F9D
	global_store_b32 v[157:158], v32, off offset:2048          // 0000000558D0: DC6A0800 007C209D
	global_store_b32 v[157:158], v34, off offset:3072          // 0000000558D8: DC6A0C00 007C229D
	.long 0xd7006a54                                           // 0000000558E0: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 0000000558E4: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000558EC: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000558F0: D5207C55 01AAA680
	.long 0xd7006a9d                                           // 0000000558F8: D7006A9D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000558FC: 0201FF52
	.long 0x0000e000                                           // 000000055900: 0000E000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 000000055904: D5207C9E 01AAA680
	.long 0xd7006aa3                                           // 00000005590C: D7006AA3
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 000000055910: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000055918: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000005591C: D5207CA4 01AAA680
	.long 0xd7006a52                                           // 000000055924: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 000000055928: 0202A4FF 0000F000
	s_clause 0x7                                               // 000000055930: BF850007
	global_store_b32 v[159:160], v11, off offset:-4096         // 000000055934: DC6A1000 007C0B9F
	global_store_b32 v[159:160], v12, off                      // 00000005593C: DC6A0000 007C0C9F
	global_store_b32 v[161:162], v14, off offset:-4096         // 000000055944: DC6A1000 007C0EA1
	global_store_b32 v[161:162], v15, off                      // 00000005594C: DC6A0000 007C0FA1
	global_store_b32 v[155:156], v27, off offset:-4096         // 000000055954: DC6A1000 007C1B9B
	global_store_b32 v[155:156], v28, off                      // 00000005595C: DC6A0000 007C1C9B
	global_store_b32 v[157:158], v29, off offset:-4096         // 000000055964: DC6A1000 007C1D9D
	global_store_b32 v[157:158], v30, off                      // 00000005596C: DC6A0000 007C1E9D
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 000000055974: D5207C53 01AAA680
	s_clause 0xf                                               // 00000005597C: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 000000055980: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 000000055988: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 000000055990: DC6A0C00 007C1654
	global_store_b32 v[163:164], v23, off offset:1024          // 000000055998: DC6A0400 007C17A3
	global_store_b32 v[163:164], v24, off offset:2048          // 0000000559A0: DC6A0800 007C18A3
	global_store_b32 v[163:164], v26, off offset:3072          // 0000000559A8: DC6A0C00 007C1AA3
	global_store_b32 v[82:83], v16, off                        // 0000000559B0: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 0000000559B8: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 0000000559C0: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 0000000559C8: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 0000000559D0: DC6A0000 007C0556
	global_store_b32 v[153:154], v6, off offset:-4096          // 0000000559D8: DC6A1000 007C0699
	global_store_b32 v[153:154], v7, off                       // 0000000559E0: DC6A0000 007C0799
	global_store_b32 v[88:89], v8, off offset:-4096            // 0000000559E8: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 0000000559F0: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 0000000559F8: DC6A0C00 007C0D52
	s_cmp_lg_u32 s13, s54                                      // 000000055A00: BF07360D
	s_cbranch_scc1 65263                                       // 000000055A04: BFA2FEEF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44c4>
	v_mov_b32_e32 v82, v2                                      // 000000055A08: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055A0C: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 000000055A10: 34A6A49F
	.long 0xd73c0052                                           // 000000055A14: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 000000055A18: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055A1C: BF870091
	.long 0xd7006a52                                           // 000000055A20: D7006A52
	v_cndmask_b32_e32 v1, s18, v82, vcc_lo                     // 000000055A24: 0202A412
	v_add_co_ci_u32_e64 v83, null, s19, v83, vcc_lo            // 000000055A28: D5207C53 01AAA613
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055A30: BF870092
	.long 0xd7006a54                                           // 000000055A34: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 000000055A38: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000055A40: D5207C55 01AAA680
	.long 0xd7006a56                                           // 000000055A48: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000055A4C: 0201FF52
	.long 0x00002000                                           // 000000055A50: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055A54: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 000000055A58: D5207C57 01AAA680
	.long 0xd7006a58                                           // 000000055A60: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 000000055A64: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 000000055A6C: D5207C59 01AAA680
	s_clause 0x7                                               // 000000055A74: BF850007
	global_store_b32 v[82:83], v69, off                        // 000000055A78: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 000000055A80: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 000000055A88: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 000000055A90: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 000000055A98: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 000000055AA0: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 000000055AA8: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 000000055AB0: DC6A0400 007C4458
	.long 0xd7006a54                                           // 000000055AB8: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 000000055ABC: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055AC4: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000055AC8: D5207C55 01AAA680
	.long 0xd7006a99                                           // 000000055AD0: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000055AD4: 0201FF52
	.long 0x00004000                                           // 000000055AD8: 00004000
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 000000055ADC: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 000000055AE4: D7006A9B
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 000000055AE8: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000055AF0: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000055AF4: D5207C9C 01AAA680
	s_clause 0x7                                               // 000000055AFC: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 000000055B00: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 000000055B08: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 000000055B10: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 000000055B18: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 000000055B20: DC6A0C00 007C4354
	global_store_b32 v[155:156], v59, off offset:1024          // 000000055B28: DC6A0400 007C3B9B
	global_store_b32 v[155:156], v60, off offset:2048          // 000000055B30: DC6A0800 007C3C9B
	global_store_b32 v[155:156], v61, off offset:3072          // 000000055B38: DC6A0C00 007C3D9B
	.long 0xd7006a54                                           // 000000055B40: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 000000055B44: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055B4C: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000055B50: D5207C55 01AAA680
	.long 0xd7006a58                                           // 000000055B58: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000055B5C: 0201FF52
	.long 0x00006000                                           // 000000055B60: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 000000055B64: D5207C59 01AAA680
	.long 0xd7006a9b                                           // 000000055B6C: D7006A9B
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 000000055B70: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055B78: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000055B7C: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 000000055B84: D7006A9D
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 000000055B88: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 000000055B90: D5207C9E 01AAA680
	.long 0xd7006a9f                                           // 000000055B98: D7006A9F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000055B9C: 0201FF52
	.long 0x00008000                                           // 000000055BA0: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000055BA4: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v83, vcc_lo             // 000000055BA8: D5207CA0 01AAA680
	s_clause 0x7                                               // 000000055BB0: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 000000055BB4: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 000000055BBC: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 000000055BC4: DC6A0C00 007C3654
	global_store_b32 v[155:156], v55, off offset:1024          // 000000055BCC: DC6A0400 007C379B
	global_store_b32 v[155:156], v56, off offset:2048          // 000000055BD4: DC6A0800 007C389B
	global_store_b32 v[155:156], v58, off offset:3072          // 000000055BDC: DC6A0C00 007C3A9B
	global_store_b32 v[157:158], v50, off offset:1024          // 000000055BE4: DC6A0400 007C329D
	global_store_b32 v[157:158], v51, off offset:2048          // 000000055BEC: DC6A0800 007C339D
	.long 0xd7006a54                                           // 000000055BF4: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 000000055BF8: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055C00: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000055C04: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 000000055C0C: D7006A9B
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 000000055C10: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000055C18: D5207C9C 01AAA680
	.long 0xd7006aa1                                           // 000000055C20: D7006AA1
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000055C24: 0201FF52
	.long 0x0000a000                                           // 000000055C28: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055C2C: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v83, vcc_lo             // 000000055C30: D5207CA2 01AAA680
	.long 0xd7006aa3                                           // 000000055C38: D7006AA3
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 000000055C3C: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 000000055C44: D5207CA4 01AAA680
	s_clause 0x7                                               // 000000055C4C: BF850007
	global_store_b32 v[157:158], v40, off offset:3072          // 000000055C50: DC6A0C00 007C289D
	global_store_b32 v[84:85], v43, off offset:1024            // 000000055C58: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 000000055C60: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 000000055C68: DC6A0C00 007C2D54
	global_store_b32 v[155:156], v46, off offset:1024          // 000000055C70: DC6A0400 007C2E9B
	global_store_b32 v[155:156], v47, off offset:2048          // 000000055C78: DC6A0800 007C2F9B
	global_store_b32 v[155:156], v48, off offset:3072          // 000000055C80: DC6A0C00 007C309B
	global_store_b32 v[163:164], v42, off offset:1024          // 000000055C88: DC6A0400 007C2AA3
	.long 0xd7006a54                                           // 000000055C90: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 000000055C94: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055C9C: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000055CA0: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 000000055CA8: D7006A9B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000055CAC: 0201FF52
	.long 0x0000c000                                           // 000000055CB0: 0000C000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000055CB4: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 000000055CBC: D7006A9D
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 000000055CC0: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000055CC8: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 000000055CCC: D5207C9E 01AAA680
	s_clause 0x7                                               // 000000055CD4: BF850007
	global_store_b32 v[163:164], v35, off offset:2048          // 000000055CD8: DC6A0800 007C23A3
	global_store_b32 v[163:164], v36, off offset:3072          // 000000055CE0: DC6A0C00 007C24A3
	global_store_b32 v[84:85], v37, off offset:1024            // 000000055CE8: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 000000055CF0: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 000000055CF8: DC6A0C00 007C2754
	global_store_b32 v[157:158], v31, off offset:1024          // 000000055D00: DC6A0400 007C1F9D
	global_store_b32 v[157:158], v32, off offset:2048          // 000000055D08: DC6A0800 007C209D
	global_store_b32 v[157:158], v34, off offset:3072          // 000000055D10: DC6A0C00 007C229D
	.long 0xd7006a54                                           // 000000055D18: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 000000055D1C: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055D24: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000055D28: D5207C55 01AAA680
	.long 0xd7006a9d                                           // 000000055D30: D7006A9D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000055D34: 0201FF52
	.long 0x0000e000                                           // 000000055D38: 0000E000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 000000055D3C: D5207C9E 01AAA680
	.long 0xd7006aa3                                           // 000000055D44: D7006AA3
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 000000055D48: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000055D50: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 000000055D54: D5207CA4 01AAA680
	.long 0xd7006a52                                           // 000000055D5C: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 000000055D60: 0202A4FF 0000F000
	s_clause 0x7                                               // 000000055D68: BF850007
	global_store_b32 v[159:160], v11, off offset:-4096         // 000000055D6C: DC6A1000 007C0B9F
	global_store_b32 v[159:160], v12, off                      // 000000055D74: DC6A0000 007C0C9F
	global_store_b32 v[161:162], v14, off offset:-4096         // 000000055D7C: DC6A1000 007C0EA1
	global_store_b32 v[161:162], v15, off                      // 000000055D84: DC6A0000 007C0FA1
	global_store_b32 v[155:156], v27, off offset:-4096         // 000000055D8C: DC6A1000 007C1B9B
	global_store_b32 v[155:156], v28, off                      // 000000055D94: DC6A0000 007C1C9B
	global_store_b32 v[157:158], v29, off offset:-4096         // 000000055D9C: DC6A1000 007C1D9D
	global_store_b32 v[157:158], v30, off                      // 000000055DA4: DC6A0000 007C1E9D
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 000000055DAC: D5207C53 01AAA680
	s_clause 0xf                                               // 000000055DB4: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 000000055DB8: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 000000055DC0: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 000000055DC8: DC6A0C00 007C1654
	global_store_b32 v[163:164], v23, off offset:1024          // 000000055DD0: DC6A0400 007C17A3
	global_store_b32 v[163:164], v24, off offset:2048          // 000000055DD8: DC6A0800 007C18A3
	global_store_b32 v[163:164], v26, off offset:3072          // 000000055DE0: DC6A0C00 007C1AA3
	global_store_b32 v[82:83], v16, off                        // 000000055DE8: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 000000055DF0: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 000000055DF8: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 000000055E00: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 000000055E08: DC6A0000 007C0556
	global_store_b32 v[153:154], v6, off offset:-4096          // 000000055E10: DC6A1000 007C0699
	global_store_b32 v[153:154], v7, off                       // 000000055E18: DC6A0000 007C0799
	global_store_b32 v[88:89], v8, off offset:-4096            // 000000055E20: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 000000055E28: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 000000055E30: DC6A0C00 007C0D52
	s_cmp_lg_u32 s14, s54                                      // 000000055E38: BF07360E
	s_cbranch_scc1 61171                                       // 000000055E3C: BFA2EEF3 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000055E40: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055E44: BF870091
	.long 0xd73c0002                                           // 000000055E48: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000055E4C: 02020482
	.long 0xd7006a02                                           // 000000055E50: D7006A02
	v_cndmask_b32_e32 v1, s47, v2, vcc_lo                      // 000000055E54: 0202042F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000055E58: BF870111
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 000000055E5C: D5207C03 01AA0607
	.long 0xd7006a52                                           // 000000055E64: D7006A52
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 000000055E68: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055E70: BF8700A1
	v_add_co_ci_u32_e64 v83, null, 0, v3, vcc_lo               // 000000055E74: D5207C53 01AA0680
	.long 0xd7006a54                                           // 000000055E7C: D7006A54
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000055E80: 0201FF02
	.long 0x00002000                                           // 000000055E84: 00002000
	v_add_co_ci_u32_e64 v85, null, 0, v3, vcc_lo               // 000000055E88: D5207C55 01AA0680
	.long 0xd7006a56                                           // 000000055E90: D7006A56
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 000000055E94: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000055E9C: BF870001
	v_add_co_ci_u32_e64 v87, null, 0, v3, vcc_lo               // 000000055EA0: D5207C57 01AA0680
	s_clause 0x7                                               // 000000055EA8: BF850007
	global_store_b32 v[2:3], v69, off                          // 000000055EAC: DC6A0000 007C4502
	global_store_b32 v[2:3], v70, off offset:1024              // 000000055EB4: DC6A0400 007C4602
	global_store_b32 v[2:3], v71, off offset:2048              // 000000055EBC: DC6A0800 007C4702
	global_store_b32 v[2:3], v72, off offset:3072              // 000000055EC4: DC6A0C00 007C4802
	global_store_b32 v[82:83], v73, off offset:1024            // 000000055ECC: DC6A0400 007C4952
	global_store_b32 v[82:83], v151, off offset:2048           // 000000055ED4: DC6A0800 007C9752
	global_store_b32 v[82:83], v152, off offset:3072           // 000000055EDC: DC6A0C00 007C9852
	global_store_b32 v[86:87], v68, off offset:1024            // 000000055EE4: DC6A0400 007C4456
	.long 0xd7006a44                                           // 000000055EEC: D7006A44
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 000000055EF0: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055EF8: BF8700A1
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 000000055EFC: D5207C45 01AA0680
	.long 0xd7006a46                                           // 000000055F04: D7006A46
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000055F08: 0201FF02
	.long 0x00004000                                           // 000000055F0C: 00004000
	v_add_co_ci_u32_e64 v71, null, 0, v3, vcc_lo               // 000000055F10: D5207C47 01AA0680
	.long 0xd7006a48                                           // 000000055F18: D7006A48
	v_cndmask_b32_e32 v1, 0x4000, v2, vcc_lo                   // 000000055F1C: 020204FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000055F24: BF870001
	v_add_co_ci_u32_e64 v73, null, 0, v3, vcc_lo               // 000000055F28: D5207C49 01AA0680
	s_clause 0x7                                               // 000000055F30: BF850007
	global_store_b32 v[86:87], v62, off offset:2048            // 000000055F34: DC6A0800 007C3E56
	global_store_b32 v[86:87], v63, off offset:3072            // 000000055F3C: DC6A0C00 007C3F56
	global_store_b32 v[68:69], v64, off offset:1024            // 000000055F44: DC6A0400 007C4044
	global_store_b32 v[68:69], v66, off offset:2048            // 000000055F4C: DC6A0800 007C4244
	global_store_b32 v[68:69], v67, off offset:3072            // 000000055F54: DC6A0C00 007C4344
	global_store_b32 v[72:73], v59, off offset:1024            // 000000055F5C: DC6A0400 007C3B48
	global_store_b32 v[72:73], v60, off offset:2048            // 000000055F64: DC6A0800 007C3C48
	global_store_b32 v[72:73], v61, off offset:3072            // 000000055F6C: DC6A0C00 007C3D48
	.long 0xd7006a3b                                           // 000000055F74: D7006A3B
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 000000055F78: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055F80: BF8700A1
	v_add_co_ci_u32_e64 v60, null, 0, v3, vcc_lo               // 000000055F84: D5207C3C 01AA0680
	.long 0xd7006a3d                                           // 000000055F8C: D7006A3D
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000055F90: 0201FF02
	.long 0x00006000                                           // 000000055F94: 00006000
	v_add_co_ci_u32_e64 v62, null, 0, v3, vcc_lo               // 000000055F98: D5207C3E 01AA0680
	.long 0xd7006a3f                                           // 000000055FA0: D7006A3F
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 000000055FA4: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000055FAC: BF8700A1
	v_add_co_ci_u32_e64 v64, null, 0, v3, vcc_lo               // 000000055FB0: D5207C40 01AA0680
	.long 0xd7006a42                                           // 000000055FB8: D7006A42
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 000000055FBC: 020204FF 00007000
	v_add_co_ci_u32_e64 v67, null, 0, v3, vcc_lo               // 000000055FC4: D5207C43 01AA0680
	.long 0xd7006a44                                           // 000000055FCC: D7006A44
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000055FD0: 0201FF02
	.long 0x00008000                                           // 000000055FD4: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000055FD8: BF870001
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 000000055FDC: D5207C45 01AA0680
	s_clause 0x7                                               // 000000055FE4: BF850007
	global_store_b32 v[59:60], v52, off offset:1024            // 000000055FE8: DC6A0400 007C343B
	global_store_b32 v[59:60], v53, off offset:2048            // 000000055FF0: DC6A0800 007C353B
	global_store_b32 v[59:60], v54, off offset:3072            // 000000055FF8: DC6A0C00 007C363B
	global_store_b32 v[63:64], v55, off offset:1024            // 000000056000: DC6A0400 007C373F
	global_store_b32 v[63:64], v56, off offset:2048            // 000000056008: DC6A0800 007C383F
	global_store_b32 v[63:64], v58, off offset:3072            // 000000056010: DC6A0C00 007C3A3F
	global_store_b32 v[66:67], v50, off offset:1024            // 000000056018: DC6A0400 007C3242
	global_store_b32 v[66:67], v51, off offset:2048            // 000000056020: DC6A0800 007C3342
	.long 0xd7006a32                                           // 000000056028: D7006A32
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 00000005602C: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056034: BF8700A1
	v_add_co_ci_u32_e64 v51, null, 0, v3, vcc_lo               // 000000056038: D5207C33 01AA0680
	.long 0xd7006a34                                           // 000000056040: D7006A34
	v_cndmask_b32_e32 v1, 0x9000, v2, vcc_lo                   // 000000056044: 020204FF 00009000
	v_add_co_ci_u32_e64 v53, null, 0, v3, vcc_lo               // 00000005604C: D5207C35 01AA0680
	.long 0xd7006a36                                           // 000000056054: D7006A36
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000056058: 0201FF02
	.long 0x0000a000                                           // 00000005605C: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056060: BF8700A1
	v_add_co_ci_u32_e64 v55, null, 0, v3, vcc_lo               // 000000056064: D5207C37 01AA0680
	.long 0xd7006a3a                                           // 00000005606C: D7006A3A
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 000000056070: 020204FF 0000A000
	v_add_co_ci_u32_e64 v59, null, 0, v3, vcc_lo               // 000000056078: D5207C3B 01AA0680
	s_clause 0x7                                               // 000000056080: BF850007
	global_store_b32 v[66:67], v40, off offset:3072            // 000000056084: DC6A0C00 007C2842
	global_store_b32 v[50:51], v43, off offset:1024            // 00000005608C: DC6A0400 007C2B32
	global_store_b32 v[50:51], v44, off offset:2048            // 000000056094: DC6A0800 007C2C32
	global_store_b32 v[50:51], v45, off offset:3072            // 00000005609C: DC6A0C00 007C2D32
	global_store_b32 v[52:53], v46, off offset:1024            // 0000000560A4: DC6A0400 007C2E34
	global_store_b32 v[52:53], v47, off offset:2048            // 0000000560AC: DC6A0800 007C2F34
	global_store_b32 v[52:53], v48, off offset:3072            // 0000000560B4: DC6A0C00 007C3034
	global_store_b32 v[58:59], v42, off offset:1024            // 0000000560BC: DC6A0400 007C2A3A
	.long 0xd7006a2a                                           // 0000000560C4: D7006A2A
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 0000000560C8: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000560D0: BF8700A1
	v_add_co_ci_u32_e64 v43, null, 0, v3, vcc_lo               // 0000000560D4: D5207C2B 01AA0680
	.long 0xd7006a2c                                           // 0000000560DC: D7006A2C
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 0000000560E0: 0201FF02
	.long 0x0000c000                                           // 0000000560E4: 0000C000
	v_add_co_ci_u32_e64 v45, null, 0, v3, vcc_lo               // 0000000560E8: D5207C2D 01AA0680
	.long 0xd7006a2e                                           // 0000000560F0: D7006A2E
	v_cndmask_b32_e32 v1, 0xc000, v2, vcc_lo                   // 0000000560F4: 020204FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000560FC: BF870001
	v_add_co_ci_u32_e64 v47, null, 0, v3, vcc_lo               // 000000056100: D5207C2F 01AA0680
	s_clause 0x7                                               // 000000056108: BF850007
	global_store_b32 v[58:59], v35, off offset:2048            // 00000005610C: DC6A0800 007C233A
	global_store_b32 v[58:59], v36, off offset:3072            // 000000056114: DC6A0C00 007C243A
	global_store_b32 v[42:43], v37, off offset:1024            // 00000005611C: DC6A0400 007C252A
	global_store_b32 v[42:43], v38, off offset:2048            // 000000056124: DC6A0800 007C262A
	global_store_b32 v[42:43], v39, off offset:3072            // 00000005612C: DC6A0C00 007C272A
	global_store_b32 v[46:47], v31, off offset:1024            // 000000056134: DC6A0400 007C1F2E
	global_store_b32 v[46:47], v32, off offset:2048            // 00000005613C: DC6A0800 007C202E
	global_store_b32 v[46:47], v34, off offset:3072            // 000000056144: DC6A0C00 007C222E
	.long 0xd7006a1f                                           // 00000005614C: D7006A1F
	v_cndmask_b32_e32 v1, 0xd000, v2, vcc_lo                   // 000000056150: 020204FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056158: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v3, vcc_lo               // 00000005615C: D5207C20 01AA0680
	.long 0xd7006a22                                           // 000000056164: D7006A22
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000056168: 0201FF02
	.long 0x0000e000                                           // 00000005616C: 0000E000
	v_add_co_ci_u32_e64 v35, null, 0, v3, vcc_lo               // 000000056170: D5207C23 01AA0680
	.long 0xd7006a24                                           // 000000056178: D7006A24
	v_cndmask_b32_e32 v1, 0xe000, v2, vcc_lo                   // 00000005617C: 020204FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056184: BF870001
	v_add_co_ci_u32_e64 v37, null, 0, v3, vcc_lo               // 000000056188: D5207C25 01AA0680
	.long 0xd7006a02                                           // 000000056190: D7006A02
	v_cndmask_b32_e32 v1, 0xf000, v2, vcc_lo                   // 000000056194: 020204FF 0000F000
	s_clause 0x7                                               // 00000005619C: BF850007
	global_store_b32 v[68:69], v11, off offset:-4096           // 0000000561A0: DC6A1000 007C0B44
	global_store_b32 v[68:69], v12, off                        // 0000000561A8: DC6A0000 007C0C44
	global_store_b32 v[54:55], v14, off offset:-4096           // 0000000561B0: DC6A1000 007C0E36
	global_store_b32 v[54:55], v15, off                        // 0000000561B8: DC6A0000 007C0F36
	global_store_b32 v[44:45], v27, off offset:-4096           // 0000000561C0: DC6A1000 007C1B2C
	global_store_b32 v[44:45], v28, off                        // 0000000561C8: DC6A0000 007C1C2C
	global_store_b32 v[34:35], v29, off offset:-4096           // 0000000561D0: DC6A1000 007C1D22
	global_store_b32 v[34:35], v30, off                        // 0000000561D8: DC6A0000 007C1E22
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000000561E0: D5207C03 01AA0680
	s_clause 0xf                                               // 0000000561E8: BF85000F
	global_store_b32 v[31:32], v20, off offset:1024            // 0000000561EC: DC6A0400 007C141F
	global_store_b32 v[31:32], v21, off offset:2048            // 0000000561F4: DC6A0800 007C151F
	global_store_b32 v[31:32], v22, off offset:3072            // 0000000561FC: DC6A0C00 007C161F
	global_store_b32 v[36:37], v23, off offset:1024            // 000000056204: DC6A0400 007C1724
	global_store_b32 v[36:37], v24, off offset:2048            // 00000005620C: DC6A0800 007C1824
	global_store_b32 v[36:37], v26, off offset:3072            // 000000056214: DC6A0C00 007C1A24
	global_store_b32 v[2:3], v16, off                          // 00000005621C: DC6A0000 007C1002
	global_store_b32 v[2:3], v18, off offset:1024              // 000000056224: DC6A0400 007C1202
	global_store_b32 v[2:3], v19, off offset:2048              // 00000005622C: DC6A0800 007C1302
	global_store_b32 v[84:85], v4, off offset:-4096            // 000000056234: DC6A1000 007C0454
	global_store_b32 v[84:85], v5, off                         // 00000005623C: DC6A0000 007C0554
	global_store_b32 v[70:71], v6, off offset:-4096            // 000000056244: DC6A1000 007C0646
	global_store_b32 v[70:71], v7, off                         // 00000005624C: DC6A0000 007C0746
	global_store_b32 v[61:62], v8, off offset:-4096            // 000000056254: DC6A1000 007C083D
	global_store_b32 v[61:62], v10, off                        // 00000005625C: DC6A0000 007C0A3D
	global_store_b32 v[2:3], v13, off offset:3072              // 000000056264: DC6A0C00 007C0D02
	s_branch 60903                                             // 00000005626C: BFA0EDE7 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	v_mov_b32_e32 v54, v41                                     // 000000056270: 7E6C0329
	v_mov_b32_e32 v53, v33                                     // 000000056274: 7E6A0321
	v_mov_b32_e32 v52, v25                                     // 000000056278: 7E680319
	v_mov_b32_e32 v51, v17                                     // 00000005627C: 7E660311
	v_mov_b32_e32 v50, v9                                      // 000000056280: 7E640309
	v_mov_b32_e32 v58, v49                                     // 000000056284: 7E740331
	v_mov_b32_e32 v152, v57                                    // 000000056288: 7F300339
	v_mov_b32_e32 v151, v65                                    // 00000005628C: 7F2E0341
	s_mov_b32 s7, 0                                            // 000000056290: BE870080
	s_branch 1                                                 // 000000056294: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x519c>
	s_mov_b64 s[6:7], 0                                        // 000000056298: BE860180
	v_dual_mul_f32 v3, 0x3b800000, v139 :: v_dual_mul_f32 v4, 0x3b800000, v138// 00000005629C: C8C716FF 030514FF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v137 :: v_dual_mul_f32 v6, 0x3b800000, v136// 0000000562A8: C8C712FF 050710FF 3B800000
	.long 0xd7006a01                                           // 0000000562B4: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000562B8: 0201FFBB
	.long 0x00002000                                           // 0000000562BC: 00002000
	v_dual_mul_f32 v7, 0x3b800000, v135 :: v_dual_mul_f32 v8, 0x3b800000, v134// 0000000562C0: C8C70EFF 07090CFF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 0000000562CC: D5207C02 01AB7880
	v_dual_mul_f32 v9, 0x3b800000, v133 :: v_dual_mul_f32 v10, 0x3b800000, v54// 0000000562D4: C8C70AFF 090A6CFF 3B800000
	s_clause 0x7                                               // 0000000562E0: BF850007
	global_store_b32 v[187:188], v3, off                       // 0000000562E4: DC6A0000 007C03BB
	global_store_b32 v[187:188], v4, off offset:1024           // 0000000562EC: DC6A0400 007C04BB
	global_store_b32 v[187:188], v5, off offset:2048           // 0000000562F4: DC6A0800 007C05BB
	global_store_b32 v[187:188], v6, off offset:3072           // 0000000562FC: DC6A0C00 007C06BB
	global_store_b32 v[1:2], v7, off offset:-4096              // 000000056304: DC6A1000 007C0701
	global_store_b32 v[1:2], v8, off offset:-3072              // 00000005630C: DC6A1400 007C0801
	global_store_b32 v[1:2], v9, off offset:-2048              // 000000056314: DC6A1800 007C0901
	global_store_b32 v[1:2], v10, off offset:-1024             // 00000005631C: DC6A1C00 007C0A01
	v_dual_mul_f32 v5, 0x3b800000, v132 :: v_dual_mul_f32 v6, 0x3b800000, v131// 000000056324: C8C708FF 050706FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v130 :: v_dual_mul_f32 v8, 0x3b800000, v129// 000000056330: C8C704FF 070902FF 3B800000
	.long 0xd7006a03                                           // 00000005633C: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000056340: 0201FFBB
	.long 0x00004000                                           // 000000056344: 00004000
	v_dual_mul_f32 v9, 0x3b800000, v128 :: v_dual_mul_f32 v10, 0x3b800000, v127// 000000056348: C8C700FF 090AFEFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000056354: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v126 :: v_dual_mul_f32 v12, 0x3b800000, v53// 00000005635C: C8C6FCFF 0B0C6AFF 3B800000
	s_clause 0x7                                               // 000000056368: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000005636C: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000056374: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 00000005637C: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 000000056384: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 00000005638C: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 000000056394: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 00000005639C: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 0000000563A4: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v125 :: v_dual_mul_f32 v6, 0x3b800000, v124// 0000000563AC: C8C6FAFF 0506F8FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v123 :: v_dual_mul_f32 v8, 0x3b800000, v122// 0000000563B8: C8C6F6FF 0708F4FF 3B800000
	.long 0xd7006a01                                           // 0000000563C4: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000563C8: 0201FFBB
	.long 0x00006000                                           // 0000000563CC: 00006000
	v_dual_mul_f32 v9, 0x3b800000, v121 :: v_dual_mul_f32 v10, 0x3b800000, v120// 0000000563D0: C8C6F2FF 090AF0FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 0000000563DC: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v119 :: v_dual_mul_f32 v12, 0x3b800000, v52// 0000000563E4: C8C6EEFF 0B0C68FF 3B800000
	s_clause 0x7                                               // 0000000563F0: BF850007
	global_store_b32 v[3:4], v5, off                           // 0000000563F4: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 0000000563FC: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000056404: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 00000005640C: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000056414: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 00000005641C: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000056424: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 00000005642C: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v118 :: v_dual_mul_f32 v6, 0x3b800000, v117// 000000056434: C8C6ECFF 0506EAFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v116 :: v_dual_mul_f32 v8, 0x3b800000, v115// 000000056440: C8C6E8FF 0708E6FF 3B800000
	.long 0xd7006a03                                           // 00000005644C: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000056450: 0201FFBB
	.long 0x00008000                                           // 000000056454: 00008000
	v_dual_mul_f32 v9, 0x3b800000, v114 :: v_dual_mul_f32 v10, 0x3b800000, v113// 000000056458: C8C6E4FF 090AE2FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000056464: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v112 :: v_dual_mul_f32 v12, 0x3b800000, v51// 00000005646C: C8C6E0FF 0B0C66FF 3B800000
	s_clause 0x7                                               // 000000056478: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000005647C: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000056484: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 00000005648C: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 000000056494: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 00000005649C: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 0000000564A4: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 0000000564AC: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 0000000564B4: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v111 :: v_dual_mul_f32 v6, 0x3b800000, v110// 0000000564BC: C8C6DEFF 0506DCFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v109 :: v_dual_mul_f32 v8, 0x3b800000, v108// 0000000564C8: C8C6DAFF 0708D8FF 3B800000
	.long 0xd7006a01                                           // 0000000564D4: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000564D8: 0201FFBB
	.long 0x0000a000                                           // 0000000564DC: 0000A000
	v_dual_mul_f32 v9, 0x3b800000, v107 :: v_dual_mul_f32 v10, 0x3b800000, v106// 0000000564E0: C8C6D6FF 090AD4FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 0000000564EC: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v105 :: v_dual_mul_f32 v12, 0x3b800000, v50// 0000000564F4: C8C6D2FF 0B0C64FF 3B800000
	s_clause 0x7                                               // 000000056500: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000056504: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 00000005650C: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000056514: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 00000005651C: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000056524: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 00000005652C: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000056534: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 00000005653C: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v104 :: v_dual_mul_f32 v6, 0x3b800000, v103// 000000056544: C8C6D0FF 0506CEFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v102 :: v_dual_mul_f32 v8, 0x3b800000, v101// 000000056550: C8C6CCFF 0708CAFF 3B800000
	.long 0xd7006a03                                           // 00000005655C: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000056560: 0201FFBB
	.long 0x0000c000                                           // 000000056564: 0000C000
	v_dual_mul_f32 v9, 0x3b800000, v100 :: v_dual_mul_f32 v10, 0x3b800000, v99// 000000056568: C8C6C8FF 090AC6FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000056574: D5207C04 01AB7880
	v_mul_f32_e32 v11, 0x3b800000, v98                         // 00000005657C: 1016C4FF 3B800000
	v_mul_f32_e32 v12, 0x3b800000, v58                         // 000000056584: 101874FF 3B800000
	s_clause 0x7                                               // 00000005658C: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000056590: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000056598: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 0000000565A0: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 0000000565A8: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 0000000565B0: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 0000000565B8: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 0000000565C0: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 0000000565C8: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v97 :: v_dual_mul_f32 v6, 0x3b800000, v96// 0000000565D0: C8C6C2FF 0506C0FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v95 :: v_dual_mul_f32 v8, 0x3b800000, v94// 0000000565DC: C8C6BEFF 0708BCFF 3B800000
	.long 0xd7006a01                                           // 0000000565E8: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000565EC: 0201FFBB
	.long 0x0000e000                                           // 0000000565F0: 0000E000
	v_dual_mul_f32 v9, 0x3b800000, v93 :: v_dual_mul_f32 v10, 0x3b800000, v92// 0000000565F4: C8C6BAFF 090AB8FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 000000056600: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v91 :: v_dual_mul_f32 v12, 0x3b800000, v152// 000000056608: C8C6B6FF 0B0D30FF 3B800000
	s_clause 0x7                                               // 000000056614: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000056618: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 000000056620: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000056628: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 000000056630: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000056638: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000056640: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000056648: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000056650: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v90 :: v_dual_mul_f32 v6, 0x3b800000, v141// 000000056658: C8C6B4FF 05071AFF 3B800000
	v_and_or_b32 v0, v0, 31, s5                                // 000000056664: D6570000 00153F00
	v_dual_mul_f32 v7, 0x3b800000, v150 :: v_dual_mul_f32 v10, 0x3b800000, v189// 00000005666C: C8C72CFF 070B7AFF 3B800000
	.long 0xd7006a03                                           // 000000056678: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000005667C: 0201FFBB
	.long 0x0000fc00                                           // 000000056680: 0000FC00
	v_dual_mul_f32 v8, 0x3b800000, v142 :: v_dual_mul_f32 v9, 0x3b800000, v191// 000000056684: C8C71CFF 08097EFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000056690: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v190 :: v_dual_mul_f32 v12, 0x3b800000, v151// 000000056698: C8C77CFF 0B0D2EFF 3B800000
	s_clause 0x7                                               // 0000000566A4: BF850007
	global_store_b32 v[1:2], v5, off                           // 0000000566A8: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 0000000566B0: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 0000000566B8: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 0000000566C0: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-3072              // 0000000566C8: DC6A1400 007C0903
	global_store_b32 v[3:4], v10, off offset:-2048             // 0000000566D0: DC6A1800 007C0A03
	global_store_b32 v[3:4], v11, off offset:-1024             // 0000000566D8: DC6A1C00 007C0B03
	global_store_b32 v[3:4], v12, off                          // 0000000566E0: DC6A0000 007C0C03
	s_mov_b32 s2, exec_lo                                      // 0000000566E8: BE82007E
	v_cmpx_eq_u32_e32 0, v0                                    // 0000000566EC: 7D940080
	s_cbranch_execz 8                                          // 0000000566F0: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi9ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5614>
	s_load_b64 s[0:1], s[0:1], 0x40                            // 0000000566F4: F4040000 F8000040
	v_mov_b32_e32 v0, s6                                       // 0000000566FC: 7E000206
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, s7              // 000000056700: CA100080 02000007
	s_waitcnt lgkmcnt(0)                                       // 000000056708: BF89FC07
	global_store_b64 v2, v[0:1], s[0:1] offset:64              // 00000005670C: DC6E0040 00000002
	s_endpgm                                                   // 000000056714: BFB00000
		...

