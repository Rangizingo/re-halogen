00000000000cd400 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000CD400: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000CD404: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000CD40C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000CD414: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000CD418: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000CD41C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000CD420: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000CD428: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000CD42C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000CD430: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000CD434: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000CD43C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000CD440: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000CD444: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000CD448: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000CD44C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000CD450: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000CD454: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000CD458: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000CD45C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000CD464: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000CD46C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000CD470: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000CD474: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000CD478: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000CD47C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000CD480: 821E191E
	.long 0xd7001f02                                           // 0000000CD484: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000CD488: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000CD48C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000CD494: BE9E0080
	s_nop 0                                                    // 0000000CD498: BF800000
	s_nop 0                                                    // 0000000CD49C: BF800000
	s_nop 0                                                    // 0000000CD4A0: BF800000
	s_nop 0                                                    // 0000000CD4A4: BF800000
	s_nop 0                                                    // 0000000CD4A8: BF800000
	s_nop 0                                                    // 0000000CD4AC: BF800000
	s_nop 0                                                    // 0000000CD4B0: BF800000
	s_nop 0                                                    // 0000000CD4B4: BF800000
	s_nop 0                                                    // 0000000CD4B8: BF800000
	s_nop 0                                                    // 0000000CD4BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000CD4C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000CD4C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD4CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000CD4D0: 300C1089
	.long 0xd7006a06                                           // 0000000CD4D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000CD4D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CD4DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000CD4E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000CD4E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000CD4F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000CD4F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000CD4FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000CD508: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000CD50C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000CD510: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000CD518: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000CD51C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000CD520: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000CD524: F4000780 F8000058
	v_or_b32_e32 v36, 0xffffff80, v0                           // 0000000CD52C: 384800FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000CD534: 32040084
	s_mov_b32 s0, 0                                            // 0000000CD538: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000CD53C: BF89FC07
	s_barrier                                                  // 0000000CD540: BFBD0000
	buffer_gl0_inv                                             // 0000000CD544: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000CD54C: BF02801E
	s_cbranch_scc1 12                                          // 0000000CD550: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000CD554: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000CD55C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000CD564: BF870002
	v_lshl_add_u32 v35, v5, 2, v3                              // 0000000CD568: D6460023 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000CD570: 7E060280
	v_lshlrev_b32_e32 v37, 2, v5                               // 0000000CD574: 304A0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000CD578: 916A007E
	s_cbranch_vccz 2                                           // 0000000CD57C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 3113                                              // 0000000CD580: BFA00C29 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3228>
	v_lshlrev_b32_e32 v37, 2, v5                               // 0000000CD584: 304A0A82
	s_add_i32 s0, s30, 63                                      // 0000000CD588: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000CD58C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000CD594: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000CD598: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000CD59C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000CD5A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v38, 2, v0      // 0000000CD5A4: CA220080 03260082
	s_ashr_i32 s1, s0, 31                                      // 0000000CD5AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000CD5B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000CD5B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000CD5B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000CD5BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000CD5C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000CD5C4: 848A811A
	v_mad_u32_u24 v35, 0x44, v2, v37                           // 0000000CD5C8: D60B0023 049604FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000CD5D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000CD5D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000CD5DC: B00A0204
	.long 0xd7000b2a                                           // 0000000CD5E0: D7000B2A
	v_cndmask_b32_e32 v1, s34, v37, vcc_lo                     // 0000000CD5E4: 02024A22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000CD5E8: BF8704B1
	v_add_co_ci_u32_e64 v43, null, s35, 0, s11                 // 0000000CD5EC: D5207C2B 002D0023
	v_mad_u32_u24 v44, v2, s10, 0x3300                         // 0000000CD5F4: D60B002C 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000CD600: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v39, 0x4320, v38// 0000000CD604: CA20000B 0C264CFF 00004320
	v_or_b32_e32 v11, s10, v38                                 // 0000000CD610: 38164C0A
	.long 0xd7000a05                                           // 0000000CD614: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000CD618: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CD61C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000CD620: D5207C06 00290001
	.long 0xd7000107                                           // 0000000CD628: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000CD62C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CD630: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000CD634: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000CD63C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000CD640: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000CD644: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000CD64C: 84848E02
	.long 0xd700010b                                           // 0000000CD650: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000CD654: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000CD658: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000CD65C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000CD664: 8205050F
	.long 0xd700010d                                           // 0000000CD668: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000CD66C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CD670: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000CD674: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000CD67C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000CD680: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000CD688: D5207C10 00061880
	.long 0xd7000111                                           // 0000000CD690: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000CD694: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CD69C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000CD6A0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000CD6A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000CD6AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000CD6B4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000CD6BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000CD6C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CD6C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000CD6CC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000CD6D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000CD6D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000CD6E0: D5207C18 00061880
	.long 0xd7000119                                           // 0000000CD6E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000CD6EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CD6F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000CD6F8: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000CD700: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000CD704: 020216FF 00150000
	v_add_nc_u32_e32 v40, 0x4420, v38                          // 0000000CD70C: 4A504CFF 00004420
	.long 0xd44c0000                                           // 0000000CD714: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000CD718: 020200FF 00000080
	v_add_nc_u32_e32 v41, 1, v2                                // 0000000CD720: 4A520481
	v_add_nc_u32_e32 v4, 0x2200, v35                           // 0000000CD724: 4A0846FF 00002200
	v_or_b32_e32 v45, 0x2200, v1                               // 0000000CD72C: 385A02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000CD734: D5207C1C 00061880
	v_add_nc_u32_e32 v46, 0x400, v1                            // 0000000CD73C: 4A5C02FF 00000400
	v_add_nc_u32_e32 v47, 0x600, v1                            // 0000000CD744: 4A5E02FF 00000600
	v_add_nc_u32_e32 v48, 0x800, v1                            // 0000000CD74C: 4A6002FF 00000800
	v_add_nc_u32_e32 v49, 0xc00, v1                            // 0000000CD754: 4A6202FF 00000C00
	v_add_nc_u32_e32 v50, 0xe00, v1                            // 0000000CD75C: 4A6402FF 00000E00
	v_add_nc_u32_e32 v51, 0x1000, v1                           // 0000000CD764: 4A6602FF 00001000
	v_add_nc_u32_e32 v52, 0x1400, v1                           // 0000000CD76C: 4A6802FF 00001400
	v_add_nc_u32_e32 v53, 0x1600, v1                           // 0000000CD774: 4A6A02FF 00001600
	v_add_nc_u32_e32 v54, 0x1800, v1                           // 0000000CD77C: 4A6C02FF 00001800
	v_add_nc_u32_e32 v55, 0x1c00, v1                           // 0000000CD784: 4A6E02FF 00001C00
	v_add_nc_u32_e32 v56, 0x1e00, v1                           // 0000000CD78C: 4A7002FF 00001E00
	v_add_nc_u32_e32 v57, 0x2000, v1                           // 0000000CD794: 4A7202FF 00002000
	s_mov_b32 s5, 0                                            // 0000000CD79C: BE850080
	s_mov_b32 s6, 0x43800000                                   // 0000000CD7A0: BE8600FF 43800000
	s_mov_b32 s7, 0x3b800000                                   // 0000000CD7A8: BE8700FF 3B800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000CD7B0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000CD7B4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000CD7BC: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000CD7C0: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000CD7C4: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000CD7C8: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000CD7CC: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000CD7D0: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000CD7D4: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000CD7D8: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000CD7DC: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000CD7E4: BE84206A
	s_cbranch_execz 77                                         // 0000000CD7E8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x520>
	v_or_b32_e32 v29, s11, v0                                  // 0000000CD7EC: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD7F0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000CD7F4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000CD7FC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CD800: BF870091
	.long 0xd73c001d                                           // 0000000CD804: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000CD808: 02023A82
	.long 0xd700011d                                           // 0000000CD80C: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000CD810: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000CD814: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000CD818: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000CD820: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CD828: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000CD82C: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000CD830: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000CD83C: BF8701A1
	v_fma_f32 v58, 0x3fb8aa3b, v29, -v32                       // 0000000CD840: D613003A 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v59, v32                                   // 0000000CD84C: 7E764720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000CD850: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000CD85C: 7E44471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CD860: BF870191
	v_dual_fmac_f32 v58, 0x32a5705f, v29 :: v_dual_sub_f32 v31, v31, v34// 0000000CD864: C80A3AFF 3A1E451F 32A5705F
	v_dual_fmac_f32 v33, 0x32a5705f, v30 :: v_dual_sub_f32 v32, v32, v59// 0000000CD870: C80A3CFF 21207720 32A5705F
	.long 0xd41b0001                                           // 0000000CD87C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000CD880: 02023CFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000CD888: BF8701B2
	v_dual_add_f32 v31, v31, v33 :: v_dual_add_f32 v32, v32, v58// 0000000CD88C: C908431F 1F207520
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000CD894: 7E421122
	v_cvt_i32_f32_e32 v34, v59                                 // 0000000CD898: 7E44113B
	v_exp_f32_e32 v31, v31                                     // 0000000CD89C: 7E3E4B1F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000000CD8A0: BF870313
	v_exp_f32_e32 v32, v32                                     // 0000000CD8A4: 7E404B20
	.long 0xd71c001f                                           // 0000000CD8A8: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000CD8AC: 0202431F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000CD8B0: BF870115
	.long 0xd71c0020                                           // 0000000CD8B4: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000CD8B8: 02024520
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000CD8BC: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000CD8C4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000CD8C8: 02023AFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CD8D0: BF8700A1
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000CD8D4: D5010020 00064080
	.long 0xd41e0001                                           // 0000000CD8DC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000CD8E0: 02023CFF 42B17218
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000CD8E8: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000CD8F4: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000CD8F8: 02023AFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CD900: BF870001
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000CD904: D501001D 000640FF 7F800000
	ds_store_b32 v39, v30                                      // 0000000CD910: D8340000 00001E27
	ds_store_b32 v40, v29                                      // 0000000CD918: D8340000 00001D28
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CD920: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000CD924: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000CD92C: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CD930: BF89FC07
	s_barrier                                                  // 0000000CD934: BFBD0000
	buffer_gl0_inv                                             // 0000000CD938: E0AC0000 00000000
	s_branch 15                                                // 0000000CD940: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CD944: 8C7E047E
	.long 0xd700011d                                           // 0000000CD948: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000CD94C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CD954: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CD958: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000CD960: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000CD964: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000CD968: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000CD96C: BF89FC07
	s_barrier                                                  // 0000000CD970: BFBD0000
	buffer_gl0_inv                                             // 0000000CD974: E0AC0000 00000000
	s_cbranch_scc1 702                                         // 0000000CD97C: BFA202BE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000CD980: CA10011E 201E011D
	v_dual_mov_b32 v33, v38 :: v_dual_mov_b32 v34, v36         // 0000000CD988: CA100126 21220124
	s_mov_b32 s13, 0                                           // 0000000CD990: BE8D0080
	s_nop 0                                                    // 0000000CD994: BF800000
	s_nop 0                                                    // 0000000CD998: BF800000
	s_nop 0                                                    // 0000000CD99C: BF800000
	s_nop 0                                                    // 0000000CD9A0: BF800000
	s_nop 0                                                    // 0000000CD9A4: BF800000
	s_nop 0                                                    // 0000000CD9A8: BF800000
	s_nop 0                                                    // 0000000CD9AC: BF800000
	s_nop 0                                                    // 0000000CD9B0: BF800000
	s_nop 0                                                    // 0000000CD9B4: BF800000
	s_nop 0                                                    // 0000000CD9B8: BF800000
	s_nop 0                                                    // 0000000CD9BC: BF800000
	global_load_b32 v58, v[31:32], off                         // 0000000CD9C0: DC520000 3A7C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000CD9C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000CD9D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000CD9D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CD9DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000CD9E0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000CD9E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000CD9EC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000CD9F4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000CD9F8: BF8903F7
	ds_store_b32 v33, v58 offset:13056                         // 0000000CD9FC: D8343300 00003A21
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000CDA04: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000CDA0C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000CDA10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000CDA14: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000CDA18: BF89FC07
	s_barrier                                                  // 0000000CDA1C: BFBD0000
	buffer_gl0_inv                                             // 0000000CDA20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000CDA28: BE842000
	s_cbranch_execz 65477                                      // 0000000CDA2C: BFA5FFC5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	ds_load_2addr_b32 v[31:32], v44 offset1:1                  // 0000000CDA30: D8DC0100 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:2 offset1:3        // 0000000CDA38: D8DC0302 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:4 offset1:5        // 0000000CDA40: D8DC0504 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:6 offset1:7        // 0000000CDA48: D8DC0706 3C00002C
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000CDA50: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 0000000CDA58: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 0000000CDA60: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 0000000CDA68: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v44 offset0:14 offset1:15      // 0000000CDA70: D8DC0F0E 4800002C
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 0000000CDA78: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 0000000CDA80: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 0000000CDA88: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 0000000CDA90: D8DCFFEE 50000001
	v_or3_b32 v70, s12, s11, v2                                // 0000000CDA98: D6580046 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDAA0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 0000000CDAA4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 0000000CDAAC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 0000000CDAB0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDAB4: BF870091
	.long 0xd7000146                                           // 0000000CDAB8: D7000146
	v_cndmask_b32_e32 v1, v42, v70, vcc_lo                     // 0000000CDABC: 02028D2A
	v_add_co_ci_u32_e64 v71, null, v43, v71, s1                // 0000000CDAC0: D5207C47 00068F2B
	global_load_b32 v70, v[70:71], off                         // 0000000CDAC8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 0000000CDAD0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 0000000CDAD4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CDADC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 0000000CDAE0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 0000000CDAE8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 0000000CDAEC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v44 offset0:8 offset1:9        // 0000000CDAF4: D8DC0908 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:10 offset1:11      // 0000000CDAFC: D8DC0B0A 3E00002C
	ds_load_2addr_b32 v[70:71], v44 offset0:12 offset1:13      // 0000000CDB04: D8DC0D0C 4600002C
	v_fma_f32 v33, -v34, v65, v33                              // 0000000CDB0C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 0000000CDB14: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDB18: BF870091
	v_fma_f32 v33, -v58, v66, v33                              // 0000000CDB1C: D6130021 2486853A
	v_fma_f32 v33, -v59, v67, v33                              // 0000000CDB24: D6130021 2486873B
	s_waitcnt lgkmcnt(8)                                       // 0000000CDB2C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDB30: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 0000000CDB34: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 0000000CDB3C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 0000000CDB44: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDB48: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 0000000CDB4C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 0000000CDB54: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 0000000CDB5C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CDB60: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000CDB64: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v44 offset0:16 offset1:17      // 0000000CDB6C: D8DC1110 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:18 offset1:19      // 0000000CDB74: D8DC1312 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:20 offset1:21      // 0000000CDB7C: D8DC1514 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:22 offset1:23      // 0000000CDB84: D8DC1716 3C00002C
	ds_load_2addr_b32 v[64:65], v46 offset0:16 offset1:33      // 0000000CDB8C: D8DC2110 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:50 offset1:67      // 0000000CDB94: D8DC4332 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:101     // 0000000CDB9C: D8DC6554 4400002E
	ds_load_2addr_b32 v[74:75], v46 offset0:118 offset1:135    // 0000000CDBA4: D8DC8776 4A00002E
	v_fma_f32 v62, -v63, v77, v62                              // 0000000CDBAC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 0000000CDBB4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDBB8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 0000000CDBBC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 0000000CDBC4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDBCC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 0000000CDBD0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 0000000CDBD8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 0000000CDBE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDBE4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 0000000CDBE8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 0000000CDBF0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 0000000CDBF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CDBFC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 0000000CDC00: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v44 offset0:24 offset1:25      // 0000000CDC08: D8DC1918 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:26 offset1:27      // 0000000CDC10: D8DC1B1A 3E00002C
	ds_load_2addr_b32 v[64:65], v44 offset0:28 offset1:29      // 0000000CDC18: D8DC1D1C 4000002C
	ds_load_2addr_b32 v[70:71], v44 offset0:30 offset1:31      // 0000000CDC20: D8DC1F1E 4600002C
	ds_load_2addr_b32 v[72:73], v46 offset0:152 offset1:169    // 0000000CDC28: D8DCA998 4800002E
	ds_load_2addr_b32 v[76:77], v46 offset0:186 offset1:203    // 0000000CDC30: D8DCCBBA 4C00002E
	ds_load_2addr_b32 v[78:79], v46 offset0:220 offset1:237    // 0000000CDC38: D8DCEDDC 4E00002E
	ds_load_2addr_b32 v[80:81], v47 offset0:126 offset1:143    // 0000000CDC40: D8DC8F7E 5000002F
	v_fma_f32 v33, -v34, v67, v33                              // 0000000CDC48: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 0000000CDC50: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDC54: BF870091
	v_fma_f32 v33, -v58, v68, v33                              // 0000000CDC58: D6130021 2486893A
	v_fma_f32 v33, -v59, v69, v33                              // 0000000CDC60: D6130021 24868B3B
	s_waitcnt lgkmcnt(8)                                       // 0000000CDC68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDC6C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000CDC70: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000CDC78: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000CDC80: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDC84: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 0000000CDC88: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 0000000CDC90: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 0000000CDC98: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CDC9C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000CDCA0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v44 offset0:32 offset1:33      // 0000000CDCA8: D8DC2120 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:34 offset1:35      // 0000000CDCB0: D8DC2322 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:36 offset1:37      // 0000000CDCB8: D8DC2524 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:38 offset1:39      // 0000000CDCC0: D8DC2726 3C00002C
	ds_load_2addr_b32 v[66:67], v48 offset0:32 offset1:49      // 0000000CDCC8: D8DC3120 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:66 offset1:83      // 0000000CDCD0: D8DC5342 44000030
	ds_load_2addr_b32 v[72:73], v48 offset0:100 offset1:117    // 0000000CDCD8: D8DC7564 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:134 offset1:151    // 0000000CDCE0: D8DC9786 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 0000000CDCE8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000CDCF0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDCF4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000CDCF8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000CDD00: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000CDD08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDD0C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 0000000CDD10: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 0000000CDD18: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 0000000CDD20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDD24: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 0000000CDD28: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 0000000CDD30: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 0000000CDD38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CDD3C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 0000000CDD40: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v44 offset0:40 offset1:41      // 0000000CDD48: D8DC2928 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:42 offset1:43      // 0000000CDD50: D8DC2B2A 3E00002C
	ds_load_2addr_b32 v[64:65], v44 offset0:44 offset1:45      // 0000000CDD58: D8DC2D2C 4000002C
	ds_load_2addr_b32 v[66:67], v44 offset0:46 offset1:47      // 0000000CDD60: D8DC2F2E 4200002C
	ds_load_2addr_b32 v[70:71], v48 offset0:168 offset1:185    // 0000000CDD68: D8DCB9A8 46000030
	ds_load_2addr_b32 v[76:77], v48 offset0:202 offset1:219    // 0000000CDD70: D8DCDBCA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:236 offset1:253    // 0000000CDD78: D8DCFDEC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:14 offset1:31      // 0000000CDD80: D8DC1F0E 50000031
	v_fma_f32 v33, -v34, v69, v33                              // 0000000CDD88: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 0000000CDD90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDD94: BF870091
	v_fma_f32 v33, -v58, v72, v33                              // 0000000CDD98: D6130021 2486913A
	v_fma_f32 v33, -v59, v73, v33                              // 0000000CDDA0: D6130021 2486933B
	s_waitcnt lgkmcnt(8)                                       // 0000000CDDA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDDAC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000CDDB0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000CDDB8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000CDDC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDDC4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 0000000CDDC8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 0000000CDDD0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 0000000CDDD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CDDDC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000CDDE0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v44 offset0:48 offset1:49      // 0000000CDDE8: D8DC3130 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:50 offset1:51      // 0000000CDDF0: D8DC3332 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:52 offset1:53      // 0000000CDDF8: D8DC3534 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:54 offset1:55      // 0000000CDE00: D8DC3736 3C00002C
	ds_load_2addr_b32 v[68:69], v49 offset0:48 offset1:65      // 0000000CDE08: D8DC4130 44000031
	ds_load_2addr_b32 v[70:71], v49 offset0:82 offset1:99      // 0000000CDE10: D8DC6352 46000031
	ds_load_2addr_b32 v[72:73], v49 offset0:116 offset1:133    // 0000000CDE18: D8DC8574 48000031
	ds_load_2addr_b32 v[74:75], v49 offset0:150 offset1:167    // 0000000CDE20: D8DCA796 4A000031
	v_fma_f32 v62, -v63, v77, v62                              // 0000000CDE28: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000CDE30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDE34: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000CDE38: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000CDE40: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000CDE48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDE4C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000CDE50: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000CDE58: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000CDE60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDE64: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000CDE68: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CDE70: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CDE78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CDE7C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000CDE80: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v44 offset0:56 offset1:57      // 0000000CDE88: D8DC3938 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:58 offset1:59      // 0000000CDE90: D8DC3B3A 3E00002C
	ds_load_2addr_b32 v[64:65], v44 offset0:60 offset1:61      // 0000000CDE98: D8DC3D3C 4000002C
	ds_load_2addr_b32 v[66:67], v44 offset0:62 offset1:63      // 0000000CDEA0: D8DC3F3E 4200002C
	ds_load_2addr_b32 v[68:69], v49 offset0:184 offset1:201    // 0000000CDEA8: D8DCC9B8 44000031
	ds_load_2addr_b32 v[76:77], v49 offset0:218 offset1:235    // 0000000CDEB0: D8DCEBDA 4C000031
	ds_load_2addr_b32 v[78:79], v50 offset0:124 offset1:141    // 0000000CDEB8: D8DC8D7C 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:30 offset1:47      // 0000000CDEC0: D8DC2F1E 50000033
	v_fma_f32 v33, -v34, v71, v33                              // 0000000CDEC8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000CDED0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDED4: BF870091
	v_fma_f32 v33, -v58, v72, v33                              // 0000000CDED8: D6130021 2486913A
	v_fma_f32 v33, -v59, v73, v33                              // 0000000CDEE0: D6130021 2486933B
	s_waitcnt lgkmcnt(8)                                       // 0000000CDEE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDEEC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000CDEF0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000CDEF8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000CDF00: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDF04: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000CDF08: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CDF10: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CDF18: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CDF1C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000CDF20: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v44 offset0:64 offset1:65      // 0000000CDF28: D8DC4140 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:66 offset1:67      // 0000000CDF30: D8DC4342 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:68 offset1:69      // 0000000CDF38: D8DC4544 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:70 offset1:71      // 0000000CDF40: D8DC4746 3C00002C
	ds_load_2addr_b32 v[68:69], v51 offset0:64 offset1:81      // 0000000CDF48: D8DC5140 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:98 offset1:115     // 0000000CDF50: D8DC7362 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:132 offset1:149    // 0000000CDF58: D8DC9584 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:166 offset1:183    // 0000000CDF60: D8DCB7A6 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 0000000CDF68: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000CDF70: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDF74: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000CDF78: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000CDF80: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000CDF88: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDF8C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000CDF90: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000CDF98: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000CDFA0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CDFA4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000CDFA8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CDFB0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CDFB8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CDFBC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000CDFC0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v44 offset0:72 offset1:73      // 0000000CDFC8: D8DC4948 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:74 offset1:75      // 0000000CDFD0: D8DC4B4A 3E00002C
	ds_load_2addr_b32 v[64:65], v44 offset0:76 offset1:77      // 0000000CDFD8: D8DC4D4C 4000002C
	ds_load_2addr_b32 v[66:67], v44 offset0:78 offset1:79      // 0000000CDFE0: D8DC4F4E 4200002C
	ds_load_2addr_b32 v[68:69], v51 offset0:200 offset1:217    // 0000000CDFE8: D8DCD9C8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:234 offset1:251    // 0000000CDFF0: D8DCFBEA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:12 offset1:29      // 0000000CDFF8: D8DC1D0C 4E000034
	ds_load_2addr_b32 v[80:81], v52 offset0:46 offset1:63      // 0000000CE000: D8DC3F2E 50000034
	v_fma_f32 v33, -v34, v71, v33                              // 0000000CE008: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000CE010: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE014: BF870091
	v_fma_f32 v33, -v58, v72, v33                              // 0000000CE018: D6130021 2486913A
	v_fma_f32 v33, -v59, v73, v33                              // 0000000CE020: D6130021 2486933B
	s_waitcnt lgkmcnt(8)                                       // 0000000CE028: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE02C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000CE030: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000CE038: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000CE040: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE044: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000CE048: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CE050: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CE058: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE05C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000CE060: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v44 offset0:80 offset1:81      // 0000000CE068: D8DC5150 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:82 offset1:83      // 0000000CE070: D8DC5352 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:84 offset1:85      // 0000000CE078: D8DC5554 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:86 offset1:87      // 0000000CE080: D8DC5756 3C00002C
	ds_load_2addr_b32 v[68:69], v52 offset0:80 offset1:97      // 0000000CE088: D8DC6150 44000034
	ds_load_2addr_b32 v[70:71], v52 offset0:114 offset1:131    // 0000000CE090: D8DC8372 46000034
	ds_load_2addr_b32 v[72:73], v52 offset0:148 offset1:165    // 0000000CE098: D8DCA594 48000034
	ds_load_2addr_b32 v[74:75], v52 offset0:182 offset1:199    // 0000000CE0A0: D8DCC7B6 4A000034
	v_fma_f32 v62, -v63, v77, v62                              // 0000000CE0A8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000CE0B0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE0B4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000CE0B8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000CE0C0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000CE0C8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE0CC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000CE0D0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000CE0D8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000CE0E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE0E4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000CE0E8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CE0F0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CE0F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE0FC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000CE100: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v44 offset0:88 offset1:89      // 0000000CE108: D8DC5958 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:90 offset1:91      // 0000000CE110: D8DC5B5A 3E00002C
	ds_load_2addr_b32 v[64:65], v44 offset0:92 offset1:93      // 0000000CE118: D8DC5D5C 4000002C
	ds_load_2addr_b32 v[66:67], v44 offset0:94 offset1:95      // 0000000CE120: D8DC5F5E 4200002C
	ds_load_2addr_b32 v[68:69], v52 offset0:216 offset1:233    // 0000000CE128: D8DCE9D8 44000034
	ds_load_2addr_b32 v[76:77], v53 offset0:122 offset1:139    // 0000000CE130: D8DC8B7A 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:28 offset1:45      // 0000000CE138: D8DC2D1C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:62 offset1:79      // 0000000CE140: D8DC4F3E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 0000000CE148: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000CE150: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE154: BF870091
	v_fma_f32 v33, -v58, v72, v33                              // 0000000CE158: D6130021 2486913A
	v_fma_f32 v33, -v59, v73, v33                              // 0000000CE160: D6130021 2486933B
	s_waitcnt lgkmcnt(8)                                       // 0000000CE168: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE16C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000CE170: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000CE178: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000CE180: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE184: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000CE188: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CE190: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CE198: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE19C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000CE1A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v44 offset0:96 offset1:97      // 0000000CE1A8: D8DC6160 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:98 offset1:99      // 0000000CE1B0: D8DC6362 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:100 offset1:101    // 0000000CE1B8: D8DC6564 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:102 offset1:103    // 0000000CE1C0: D8DC6766 3C00002C
	ds_load_2addr_b32 v[68:69], v54 offset0:96 offset1:113     // 0000000CE1C8: D8DC7160 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:130 offset1:147    // 0000000CE1D0: D8DC9382 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:164 offset1:181    // 0000000CE1D8: D8DCB5A4 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:198 offset1:215    // 0000000CE1E0: D8DCD7C6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 0000000CE1E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000CE1F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE1F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000CE1F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000CE200: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000CE208: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE20C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000CE210: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000CE218: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000CE220: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE224: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000CE228: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CE230: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CE238: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE23C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000CE240: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v44 offset0:104 offset1:105    // 0000000CE248: D8DC6968 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:106 offset1:107    // 0000000CE250: D8DC6B6A 3E00002C
	ds_load_2addr_b32 v[64:65], v44 offset0:108 offset1:109    // 0000000CE258: D8DC6D6C 4000002C
	ds_load_2addr_b32 v[66:67], v44 offset0:110 offset1:111    // 0000000CE260: D8DC6F6E 4200002C
	ds_load_2addr_b32 v[68:69], v54 offset0:232 offset1:249    // 0000000CE268: D8DCF9E8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:10 offset1:27      // 0000000CE270: D8DC1B0A 4C000037
	ds_load_2addr_b32 v[78:79], v55 offset0:44 offset1:61      // 0000000CE278: D8DC3D2C 4E000037
	ds_load_2addr_b32 v[80:81], v55 offset0:78 offset1:95      // 0000000CE280: D8DC5F4E 50000037
	v_fma_f32 v33, -v34, v71, v33                              // 0000000CE288: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000CE290: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE294: BF870091
	v_fma_f32 v33, -v58, v72, v33                              // 0000000CE298: D6130021 2486913A
	v_fma_f32 v33, -v59, v73, v33                              // 0000000CE2A0: D6130021 2486933B
	s_waitcnt lgkmcnt(8)                                       // 0000000CE2A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE2AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000CE2B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000CE2B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000CE2C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE2C4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000CE2C8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CE2D0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CE2D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE2DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000CE2E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v44 offset0:112 offset1:113    // 0000000CE2E8: D8DC7170 1F00002C
	ds_load_2addr_b32 v[33:34], v44 offset0:114 offset1:115    // 0000000CE2F0: D8DC7372 2100002C
	ds_load_2addr_b32 v[58:59], v44 offset0:116 offset1:117    // 0000000CE2F8: D8DC7574 3A00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:118 offset1:119    // 0000000CE300: D8DC7776 3C00002C
	ds_load_2addr_b32 v[68:69], v55 offset0:112 offset1:129    // 0000000CE308: D8DC8170 44000037
	ds_load_2addr_b32 v[70:71], v55 offset0:146 offset1:163    // 0000000CE310: D8DCA392 46000037
	ds_load_2addr_b32 v[72:73], v55 offset0:180 offset1:197    // 0000000CE318: D8DCC5B4 48000037
	ds_load_2addr_b32 v[74:75], v55 offset0:214 offset1:231    // 0000000CE320: D8DCE7D6 4A000037
	v_fma_f32 v62, -v63, v77, v62                              // 0000000CE328: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000CE330: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE334: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000CE338: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000CE340: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000CE348: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE34C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000CE350: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000CE358: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000CE360: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE364: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000CE368: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CE370: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CE378: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE37C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000CE380: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v44 offset0:120 offset1:121    // 0000000CE388: D8DC7978 1F00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:122 offset1:123    // 0000000CE390: D8DC7B7A 3E00002C
	ds_load_2addr_b32 v[64:65], v44 offset0:124 offset1:125    // 0000000CE398: D8DC7D7C 4000002C
	ds_load_2addr_b32 v[66:67], v44 offset0:126 offset1:127    // 0000000CE3A0: D8DC7F7E 4200002C
	ds_load_2addr_b32 v[68:69], v56 offset0:120 offset1:137    // 0000000CE3A8: D8DC8978 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:26 offset1:43      // 0000000CE3B0: D8DC2B1A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:60 offset1:77      // 0000000CE3B8: D8DC4D3C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:94 offset1:111     // 0000000CE3C0: D8DC6F5E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 0000000CE3C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000CE3D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE3D4: BF870091
	v_fma_f32 v33, -v58, v72, v33                              // 0000000CE3D8: D6130021 2486913A
	v_fma_f32 v33, -v59, v73, v33                              // 0000000CE3E0: D6130021 2486933B
	s_waitcnt lgkmcnt(8)                                       // 0000000CE3E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE3EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000CE3F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000CE3F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000CE400: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE404: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000CE408: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000CE410: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000CE418: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE41C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 0000000CE420: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 0000000CE428: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 0000000CE430: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE434: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 0000000CE438: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 0000000CE440: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 0000000CE448: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CE44C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 0000000CE450: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s12, v[4:5]            // 0000000CE458: D6FE7C1F 041018FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 0000000CE464: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 0000000CE46C: D8340000 0000201F
	s_branch 64819                                             // 0000000CE474: BFA0FD33 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	v_mov_b32_e32 v30, v14                                     // 0000000CE478: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000CE47C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000CE484: 7E3E0309
	v_mov_b32_e32 v58, v41                                     // 0000000CE488: 7E740329
	s_mov_b32 s12, 0                                           // 0000000CE48C: BE8C0080
	s_branch 21                                                // 0000000CE490: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000CE494: 8C7E0D7E
	.long 0xd700011f                                           // 0000000CE498: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000CE49C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE4A4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000CE4A8: D5207C20 00064080
	.long 0xd700011d                                           // 0000000CE4B0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000CE4B4: 02023AFF 00000800
	v_add_nc_u32_e32 v58, 8, v58                               // 0000000CE4BC: 4A747488
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CE4C0: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000CE4C8: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000CE4CC: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000CE4D0: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000CE4D4: BC7C0000
	s_barrier                                                  // 0000000CE4D8: BFBD0000
	buffer_gl0_inv                                             // 0000000CE4DC: E0AC0000 00000000
	s_cbranch_scc1 598                                         // 0000000CE4E4: BFA20256 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000CE4E8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000CE4EC: CA100120 2220011F
	v_dual_mov_b32 v59, v38 :: v_dual_mov_b32 v60, v36         // 0000000CE4F4: CA100126 3B3C0124
	s_mov_b32 s13, 0                                           // 0000000CE4FC: BE8D0080
	global_load_b32 v61, v[33:34], off                         // 0000000CE500: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000CE508: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000CE510: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000CE514: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CE51C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000CE520: D5207C22 00064480
	.long 0xd4490004                                           // 0000000CE528: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000CE52C: 020278FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000CE534: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000CE538: BF8903F7
	ds_store_b32 v59, v61 offset:13056                         // 0000000CE53C: D8343300 00003D3B
	v_add_nc_u32_e32 v59, 0x204, v59                           // 0000000CE544: 4A7676FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000CE54C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000CE550: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000CE554: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000CE558: BF89FC07
	s_barrier                                                  // 0000000CE55C: BFBD0000
	buffer_gl0_inv                                             // 0000000CE560: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000CE568: BE8D2000
	s_cbranch_execz 65481                                      // 0000000CE56C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s12, v2                                  // 0000000CE570: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CE574: BF870091
	v_or_b32_e32 v59, s11, v33                                 // 0000000CE578: 3876420B
	.long 0xd4440001                                           // 0000000CE57C: D4440001
	v_cndmask_b32_e32 v1, s30, v59, vcc_lo                     // 0000000CE580: 0202761E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000CE584: 8B7E017E
	s_cbranch_execz 65474                                      // 0000000CE588: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	ds_load_2addr_b32 v[60:61], v44 offset1:1                  // 0000000CE58C: D8DC0100 3C00002C
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000CE594: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v44 offset0:2 offset1:3        // 0000000CE59C: D8DC0302 4000002C
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 0000000CE5A4: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v44 offset0:4 offset1:5        // 0000000CE5AC: D8DC0504 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:6 offset1:7        // 0000000CE5B4: D8DC0706 4600002C
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 0000000CE5BC: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 0000000CE5C4: D8DC7766 4A000001
	s_mov_b32 s14, 0                                           // 0000000CE5CC: BE8E0080
	s_waitcnt lgkmcnt(6)                                       // 0000000CE5D0: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 0000000CE5D4: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE5DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CE5E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CE5E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CE5E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE5EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CE5F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CE5F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CE5F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE5FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CE600: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CE604: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CE608: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE60C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CE610: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:8 offset1:9        // 0000000CE614: D8DC0908 3C00002C
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 0000000CE61C: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v44 offset0:10 offset1:11      // 0000000CE624: D8DC0B0A 4000002C
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 0000000CE62C: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v44 offset0:12 offset1:13      // 0000000CE634: D8DC0D0C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:14 offset1:15      // 0000000CE63C: D8DC0F0E 4600002C
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 0000000CE644: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 0000000CE64C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 0000000CE654: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CE658: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE65C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CE660: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CE664: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CE668: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE66C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CE670: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CE674: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CE678: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE67C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CE680: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CE684: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CE688: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE68C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CE690: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:16 offset1:17      // 0000000CE694: D8DC1110 3C00002C
	ds_load_2addr_b32 v[62:63], v46 offset0:16 offset1:33      // 0000000CE69C: D8DC2110 3E00002E
	ds_load_2addr_b32 v[64:65], v44 offset0:18 offset1:19      // 0000000CE6A4: D8DC1312 4000002C
	ds_load_2addr_b32 v[66:67], v46 offset0:50 offset1:67      // 0000000CE6AC: D8DC4332 4200002E
	ds_load_2addr_b32 v[68:69], v44 offset0:20 offset1:21      // 0000000CE6B4: D8DC1514 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:22 offset1:23      // 0000000CE6BC: D8DC1716 4600002C
	ds_load_2addr_b32 v[72:73], v46 offset0:84 offset1:101     // 0000000CE6C4: D8DC6554 4800002E
	ds_load_2addr_b32 v[74:75], v46 offset0:118 offset1:135    // 0000000CE6CC: D8DC8776 4A00002E
	s_waitcnt lgkmcnt(6)                                       // 0000000CE6D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CE6D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE6DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CE6E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CE6E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CE6E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE6EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CE6F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CE6F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CE6F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE6FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CE700: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CE704: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CE708: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE70C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CE710: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:24 offset1:25      // 0000000CE714: D8DC1918 3C00002C
	ds_load_2addr_b32 v[62:63], v46 offset0:152 offset1:169    // 0000000CE71C: D8DCA998 3E00002E
	ds_load_2addr_b32 v[64:65], v44 offset0:26 offset1:27      // 0000000CE724: D8DC1B1A 4000002C
	ds_load_2addr_b32 v[66:67], v46 offset0:186 offset1:203    // 0000000CE72C: D8DCCBBA 4200002E
	ds_load_2addr_b32 v[68:69], v44 offset0:28 offset1:29      // 0000000CE734: D8DC1D1C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:30 offset1:31      // 0000000CE73C: D8DC1F1E 4600002C
	ds_load_2addr_b32 v[72:73], v46 offset0:220 offset1:237    // 0000000CE744: D8DCEDDC 4800002E
	ds_load_2addr_b32 v[74:75], v47 offset0:126 offset1:143    // 0000000CE74C: D8DC8F7E 4A00002F
	s_waitcnt lgkmcnt(6)                                       // 0000000CE754: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CE758: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE75C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CE760: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CE764: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CE768: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE76C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CE770: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CE774: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CE778: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE77C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CE780: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CE784: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CE788: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE78C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CE790: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:32 offset1:33      // 0000000CE794: D8DC2120 3C00002C
	ds_load_2addr_b32 v[62:63], v48 offset0:32 offset1:49      // 0000000CE79C: D8DC3120 3E000030
	ds_load_2addr_b32 v[64:65], v44 offset0:34 offset1:35      // 0000000CE7A4: D8DC2322 4000002C
	ds_load_2addr_b32 v[66:67], v48 offset0:66 offset1:83      // 0000000CE7AC: D8DC5342 42000030
	ds_load_2addr_b32 v[68:69], v44 offset0:36 offset1:37      // 0000000CE7B4: D8DC2524 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:38 offset1:39      // 0000000CE7BC: D8DC2726 4600002C
	ds_load_2addr_b32 v[72:73], v48 offset0:100 offset1:117    // 0000000CE7C4: D8DC7564 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:134 offset1:151    // 0000000CE7CC: D8DC9786 4A000030
	s_waitcnt lgkmcnt(6)                                       // 0000000CE7D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CE7D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE7DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CE7E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CE7E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CE7E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE7EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CE7F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CE7F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CE7F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE7FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CE800: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CE804: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CE808: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE80C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CE810: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:40 offset1:41      // 0000000CE814: D8DC2928 3C00002C
	ds_load_2addr_b32 v[62:63], v48 offset0:168 offset1:185    // 0000000CE81C: D8DCB9A8 3E000030
	ds_load_2addr_b32 v[64:65], v44 offset0:42 offset1:43      // 0000000CE824: D8DC2B2A 4000002C
	ds_load_2addr_b32 v[66:67], v48 offset0:202 offset1:219    // 0000000CE82C: D8DCDBCA 42000030
	ds_load_2addr_b32 v[68:69], v44 offset0:44 offset1:45      // 0000000CE834: D8DC2D2C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:46 offset1:47      // 0000000CE83C: D8DC2F2E 4600002C
	ds_load_2addr_b32 v[72:73], v48 offset0:236 offset1:253    // 0000000CE844: D8DCFDEC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:14 offset1:31      // 0000000CE84C: D8DC1F0E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 0000000CE854: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CE858: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE85C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CE860: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CE864: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CE868: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE86C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CE870: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CE874: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CE878: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE87C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CE880: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CE884: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CE888: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE88C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CE890: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:48 offset1:49      // 0000000CE894: D8DC3130 3C00002C
	ds_load_2addr_b32 v[62:63], v49 offset0:48 offset1:65      // 0000000CE89C: D8DC4130 3E000031
	ds_load_2addr_b32 v[64:65], v44 offset0:50 offset1:51      // 0000000CE8A4: D8DC3332 4000002C
	ds_load_2addr_b32 v[66:67], v49 offset0:82 offset1:99      // 0000000CE8AC: D8DC6352 42000031
	ds_load_2addr_b32 v[68:69], v44 offset0:52 offset1:53      // 0000000CE8B4: D8DC3534 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:54 offset1:55      // 0000000CE8BC: D8DC3736 4600002C
	ds_load_2addr_b32 v[72:73], v49 offset0:116 offset1:133    // 0000000CE8C4: D8DC8574 48000031
	ds_load_2addr_b32 v[74:75], v49 offset0:150 offset1:167    // 0000000CE8CC: D8DCA796 4A000031
	s_waitcnt lgkmcnt(6)                                       // 0000000CE8D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CE8D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE8DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CE8E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CE8E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CE8E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE8EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CE8F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CE8F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CE8F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE8FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CE900: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CE904: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CE908: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE90C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CE910: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:56 offset1:57      // 0000000CE914: D8DC3938 3C00002C
	ds_load_2addr_b32 v[62:63], v49 offset0:184 offset1:201    // 0000000CE91C: D8DCC9B8 3E000031
	ds_load_2addr_b32 v[64:65], v44 offset0:58 offset1:59      // 0000000CE924: D8DC3B3A 4000002C
	ds_load_2addr_b32 v[66:67], v49 offset0:218 offset1:235    // 0000000CE92C: D8DCEBDA 42000031
	ds_load_2addr_b32 v[68:69], v44 offset0:60 offset1:61      // 0000000CE934: D8DC3D3C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:62 offset1:63      // 0000000CE93C: D8DC3F3E 4600002C
	ds_load_2addr_b32 v[72:73], v50 offset0:124 offset1:141    // 0000000CE944: D8DC8D7C 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:30 offset1:47      // 0000000CE94C: D8DC2F1E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000CE954: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CE958: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE95C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CE960: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CE964: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CE968: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE96C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CE970: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CE974: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CE978: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE97C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CE980: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CE984: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CE988: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CE98C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CE990: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:64 offset1:65      // 0000000CE994: D8DC4140 3C00002C
	ds_load_2addr_b32 v[62:63], v51 offset0:64 offset1:81      // 0000000CE99C: D8DC5140 3E000033
	ds_load_2addr_b32 v[64:65], v44 offset0:66 offset1:67      // 0000000CE9A4: D8DC4342 4000002C
	ds_load_2addr_b32 v[66:67], v51 offset0:98 offset1:115     // 0000000CE9AC: D8DC7362 42000033
	ds_load_2addr_b32 v[68:69], v44 offset0:68 offset1:69      // 0000000CE9B4: D8DC4544 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:70 offset1:71      // 0000000CE9BC: D8DC4746 4600002C
	ds_load_2addr_b32 v[72:73], v51 offset0:132 offset1:149    // 0000000CE9C4: D8DC9584 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:166 offset1:183    // 0000000CE9CC: D8DCB7A6 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000CE9D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CE9D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE9DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CE9E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CE9E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CE9E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE9EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CE9F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CE9F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CE9F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CE9FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CEA00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CEA04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CEA08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CEA0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CEA10: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:72 offset1:73      // 0000000CEA14: D8DC4948 3C00002C
	ds_load_2addr_b32 v[62:63], v51 offset0:200 offset1:217    // 0000000CEA1C: D8DCD9C8 3E000033
	ds_load_2addr_b32 v[64:65], v44 offset0:74 offset1:75      // 0000000CEA24: D8DC4B4A 4000002C
	ds_load_2addr_b32 v[66:67], v51 offset0:234 offset1:251    // 0000000CEA2C: D8DCFBEA 42000033
	ds_load_2addr_b32 v[68:69], v44 offset0:76 offset1:77      // 0000000CEA34: D8DC4D4C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:78 offset1:79      // 0000000CEA3C: D8DC4F4E 4600002C
	ds_load_2addr_b32 v[72:73], v52 offset0:12 offset1:29      // 0000000CEA44: D8DC1D0C 48000034
	ds_load_2addr_b32 v[74:75], v52 offset0:46 offset1:63      // 0000000CEA4C: D8DC3F2E 4A000034
	s_waitcnt lgkmcnt(6)                                       // 0000000CEA54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CEA58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEA5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CEA60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CEA64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CEA68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEA6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CEA70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CEA74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CEA78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEA7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CEA80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CEA84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CEA88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CEA8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CEA90: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:80 offset1:81      // 0000000CEA94: D8DC5150 3C00002C
	ds_load_2addr_b32 v[62:63], v52 offset0:80 offset1:97      // 0000000CEA9C: D8DC6150 3E000034
	ds_load_2addr_b32 v[64:65], v44 offset0:82 offset1:83      // 0000000CEAA4: D8DC5352 4000002C
	ds_load_2addr_b32 v[66:67], v52 offset0:114 offset1:131    // 0000000CEAAC: D8DC8372 42000034
	ds_load_2addr_b32 v[68:69], v44 offset0:84 offset1:85      // 0000000CEAB4: D8DC5554 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:86 offset1:87      // 0000000CEABC: D8DC5756 4600002C
	ds_load_2addr_b32 v[72:73], v52 offset0:148 offset1:165    // 0000000CEAC4: D8DCA594 48000034
	ds_load_2addr_b32 v[74:75], v52 offset0:182 offset1:199    // 0000000CEACC: D8DCC7B6 4A000034
	s_waitcnt lgkmcnt(6)                                       // 0000000CEAD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CEAD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEADC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CEAE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CEAE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CEAE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEAEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CEAF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CEAF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CEAF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEAFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CEB00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CEB04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CEB08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CEB0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CEB10: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:88 offset1:89      // 0000000CEB14: D8DC5958 3C00002C
	ds_load_2addr_b32 v[62:63], v52 offset0:216 offset1:233    // 0000000CEB1C: D8DCE9D8 3E000034
	ds_load_2addr_b32 v[64:65], v44 offset0:90 offset1:91      // 0000000CEB24: D8DC5B5A 4000002C
	ds_load_2addr_b32 v[66:67], v53 offset0:122 offset1:139    // 0000000CEB2C: D8DC8B7A 42000035
	ds_load_2addr_b32 v[68:69], v44 offset0:92 offset1:93      // 0000000CEB34: D8DC5D5C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:94 offset1:95      // 0000000CEB3C: D8DC5F5E 4600002C
	ds_load_2addr_b32 v[72:73], v54 offset0:28 offset1:45      // 0000000CEB44: D8DC2D1C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:62 offset1:79      // 0000000CEB4C: D8DC4F3E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000CEB54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CEB58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEB5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CEB60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CEB64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CEB68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEB6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CEB70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CEB74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CEB78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEB7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CEB80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CEB84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CEB88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CEB8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CEB90: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:96 offset1:97      // 0000000CEB94: D8DC6160 3C00002C
	ds_load_2addr_b32 v[62:63], v54 offset0:96 offset1:113     // 0000000CEB9C: D8DC7160 3E000036
	ds_load_2addr_b32 v[64:65], v44 offset0:98 offset1:99      // 0000000CEBA4: D8DC6362 4000002C
	ds_load_2addr_b32 v[66:67], v54 offset0:130 offset1:147    // 0000000CEBAC: D8DC9382 42000036
	ds_load_2addr_b32 v[68:69], v44 offset0:100 offset1:101    // 0000000CEBB4: D8DC6564 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:102 offset1:103    // 0000000CEBBC: D8DC6766 4600002C
	ds_load_2addr_b32 v[72:73], v54 offset0:164 offset1:181    // 0000000CEBC4: D8DCB5A4 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:198 offset1:215    // 0000000CEBCC: D8DCD7C6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000CEBD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CEBD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEBDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CEBE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CEBE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CEBE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEBEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CEBF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CEBF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CEBF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEBFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CEC00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CEC04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CEC08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CEC0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CEC10: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:104 offset1:105    // 0000000CEC14: D8DC6968 3C00002C
	ds_load_2addr_b32 v[62:63], v54 offset0:232 offset1:249    // 0000000CEC1C: D8DCF9E8 3E000036
	ds_load_2addr_b32 v[64:65], v44 offset0:106 offset1:107    // 0000000CEC24: D8DC6B6A 4000002C
	ds_load_2addr_b32 v[66:67], v55 offset0:10 offset1:27      // 0000000CEC2C: D8DC1B0A 42000037
	ds_load_2addr_b32 v[68:69], v44 offset0:108 offset1:109    // 0000000CEC34: D8DC6D6C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:110 offset1:111    // 0000000CEC3C: D8DC6F6E 4600002C
	ds_load_2addr_b32 v[72:73], v55 offset0:44 offset1:61      // 0000000CEC44: D8DC3D2C 48000037
	ds_load_2addr_b32 v[74:75], v55 offset0:78 offset1:95      // 0000000CEC4C: D8DC5F4E 4A000037
	s_waitcnt lgkmcnt(6)                                       // 0000000CEC54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CEC58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEC5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CEC60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CEC64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CEC68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEC6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CEC70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CEC74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CEC78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CEC7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CEC80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CEC84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CEC88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CEC8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CEC90: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:112 offset1:113    // 0000000CEC94: D8DC7170 3C00002C
	ds_load_2addr_b32 v[62:63], v55 offset0:112 offset1:129    // 0000000CEC9C: D8DC8170 3E000037
	ds_load_2addr_b32 v[64:65], v44 offset0:114 offset1:115    // 0000000CECA4: D8DC7372 4000002C
	ds_load_2addr_b32 v[66:67], v55 offset0:146 offset1:163    // 0000000CECAC: D8DCA392 42000037
	ds_load_2addr_b32 v[68:69], v44 offset0:116 offset1:117    // 0000000CECB4: D8DC7574 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:118 offset1:119    // 0000000CECBC: D8DC7776 4600002C
	ds_load_2addr_b32 v[72:73], v55 offset0:180 offset1:197    // 0000000CECC4: D8DCC5B4 48000037
	ds_load_2addr_b32 v[74:75], v55 offset0:214 offset1:231    // 0000000CECCC: D8DCE7D6 4A000037
	s_waitcnt lgkmcnt(6)                                       // 0000000CECD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CECD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CECDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CECE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000CECE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CECE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CECEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CECF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000CECF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CECF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CECFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CED00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000CED04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CED08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CED0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CED10: 56989747
	ds_load_2addr_b32 v[60:61], v44 offset0:120 offset1:121    // 0000000CED14: D8DC7978 3C00002C
	ds_load_2addr_b32 v[62:63], v56 offset0:120 offset1:137    // 0000000CED1C: D8DC8978 3E000038
	ds_load_2addr_b32 v[64:65], v44 offset0:122 offset1:123    // 0000000CED24: D8DC7B7A 4000002C
	ds_load_2addr_b32 v[66:67], v57 offset0:26 offset1:43      // 0000000CED2C: D8DC2B1A 42000039
	ds_load_2addr_b32 v[68:69], v44 offset0:124 offset1:125    // 0000000CED34: D8DC7D7C 4400002C
	ds_load_2addr_b32 v[70:71], v44 offset0:126 offset1:127    // 0000000CED3C: D8DC7F7E 4600002C
	ds_load_2addr_b32 v[72:73], v57 offset0:60 offset1:77      // 0000000CED44: D8DC4D3C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:94 offset1:111     // 0000000CED4C: D8DC6F5E 4A000039
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000CED54: 30424282
	s_waitcnt lgkmcnt(6)                                       // 0000000CED58: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000CED5C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 0000000CED60: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000CED68: CA10011E 2220011D
	v_mov_b32_e32 v62, v58                                     // 0000000CED70: 7E7C033A
	v_fmac_f32_e32 v76, v61, v63                               // 0000000CED74: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 0000000CED78: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 0000000CED7C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CED80: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 0000000CED84: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 0000000CED88: 56988741
	s_waitcnt lgkmcnt(2)                                       // 0000000CED8C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CED90: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 0000000CED94: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 0000000CED98: 56989345
	s_waitcnt lgkmcnt(1)                                       // 0000000CED9C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CEDA0: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 0000000CEDA4: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 0000000CEDA8: 56989747
	s_waitcnt lgkmcnt(0)                                       // 0000000CEDAC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CEDB0: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 0000000CEDB4: 1078794C
	s_nop 0                                                    // 0000000CEDB8: BF800000
	s_nop 0                                                    // 0000000CEDBC: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000CEDC0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000CEDC8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000CEDD0: 4A7C7CC1
	.long 0xd7000121                                           // 0000000CEDD4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000CEDD8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CEDDC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000CEDE0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000CEDE8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000CEDEC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000CEDF0: 4A7A7AFF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000CEDF8: 8C0E0E04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CEDFC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 0000000CEE00: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000CEE04: 917E0E7E
	s_cbranch_execnz 65517                                     // 0000000CEE08: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000CEE0C: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CEE10: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 0000000CEE14: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v59, v[5:6]          // 0000000CEE1C: D6FE7C21 041676FF 00003000
	v_add3_u32 v59, v60, v61, 0x7fff                           // 0000000CEE28: D655003B 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v59, off                 // 0000000CEE34: DC960000 007C3B21
	s_branch 64917                                             // 0000000CEE3C: BFA0FD95 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000CEE40: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v36                                     // 0000000CEE48: 7E3E0324
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000CEE4C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000CEE50: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000CEE58: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000CEE5C: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000CEE64: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000CEE6C: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000CEE70: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000CEE74: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000CEE7C: A0010401
	s_mov_b32 s4, 0                                            // 0000000CEE80: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000CEE84: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000CEE88: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000CEE8C: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000CEE90: BF870585
	.long 0xd71c001d                                           // 0000000CEE94: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000CEE98: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000CEE9C: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000CEEA0: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000CEEA8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000CEEAC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000CEEB4: 980180C1
	v_mov_b32_e32 v29, v35                                     // 0000000CEEB8: 7E3A0323
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000CEEBC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000CEEC8: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000CEED0: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CEED8: BF870001
	.long 0xd4490001                                           // 0000000CEEDC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000CEEE0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000CEEE8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000CEEEC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000CEEF0: 1040411E
	ds_store_b32 v29, v32                                      // 0000000CEEF4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000CEEFC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CEF04: 917E047E
	s_cbranch_execnz 65519                                     // 0000000CEF08: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ac8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CEF0C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000CEF10: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v38           // 0000000CEF18: CA100080 1F200126
	v_mov_b32_e32 v33, v36                                     // 0000000CEF20: 7E420324
	s_mov_b32 s10, 0                                           // 0000000CEF24: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CEF28: BF89FC07
	s_barrier                                                  // 0000000CEF2C: BFBD0000
	buffer_gl0_inv                                             // 0000000CEF30: E0AC0000 00000000
	s_nop 0                                                    // 0000000CEF38: BF800000
	s_nop 0                                                    // 0000000CEF3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CEF40: DC520000 227C001D
	ds_load_b32 v58, v31 offset:17184                          // 0000000CEF48: D8D84320 3A00001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CEF50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CEF58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CEF5C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000CEF64: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CEF68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CEF70: BF870004
	.long 0xd4490004                                           // 0000000CEF74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CEF78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CEF80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CEF84: BF890007
	v_mul_f32_e32 v34, v34, v58                                // 0000000CEF88: 10447522
	ds_store_b32 v32, v34 offset:13056                         // 0000000CEF8C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000CEF94: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CEF9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CEFA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CEFA4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000CEFA8: BF89FC07
	s_barrier                                                  // 0000000CEFAC: BFBD0000
	buffer_gl0_inv                                             // 0000000CEFB0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v45 offset1:17                 // 0000000CEFB8: D8DC1100 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:34 offset1:51      // 0000000CEFC0: D8DC3322 1F00002D
	ds_load_2addr_b32 v[33:34], v45 offset0:68 offset1:85      // 0000000CEFC8: D8DC5544 2100002D
	ds_load_2addr_b32 v[58:59], v45 offset0:102 offset1:119    // 0000000CEFD0: D8DC7766 3A00002D
	v_mov_b32_e32 v60, v0                                      // 0000000CEFD8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000CEFDC: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000CEFE0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000CEFE4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000CEFEC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000CEFF4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000CEFF8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000CF000: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000CF008: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000CF00C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000CF014: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000CF01C: BF89FC07
	v_fma_mixlo_f16 v58, v58, s6, 0                            // 0000000CF020: CC21003A 02000D3A
	v_fma_mixlo_f16 v59, v59, s6, 0                            // 0000000CF028: CC21003B 02000D3B
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF030: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF038: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF040: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF048: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF050: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF058: CC200022 8A000F22
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF060: CC20003A 8A000F3A
	v_fma_mix_f32 v59, v59, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF068: CC20003B 8A000F3B
	v_lshrrev_b32_e32 v63, 4, v60                              // 0000000CF070: 327E7884
	.long 0xd4490001                                           // 0000000CF074: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000CF078: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000CF080: BF870002
	v_lshlrev_b32_e32 v68, 2, v63                              // 0000000CF084: 30887E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 0000000CF088: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CF094: 8C040401
	v_add_nc_u32_e32 v61, 0x3200, v68                          // 0000000CF098: 4A7A88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000CF0A0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000CF0A8: 4A8488FF 00003A00
	v_add_nc_u32_e32 v68, 0x3e00, v68                          // 0000000CF0B0: 4A8888FF 00003E00
	ds_load_b32 v69, v63                                       // 0000000CF0B8: D8D80000 4500003F
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000CF0C0: D8DCC342 40000040
	ds_load_2addr_b32 v[61:62], v61 offset0:64 offset1:193     // 0000000CF0C8: D8DCC140 3D00003D
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000CF0D0: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000CF0D8: BF89FC27
	v_fma_mixlo_f16 v64, v64, s6, 0                            // 0000000CF0DC: CC210040 02000D40
	s_waitcnt lgkmcnt(1)                                       // 0000000CF0E4: BF89FC17
	v_fma_mixlo_f16 v61, v61, s6, 0                            // 0000000CF0E8: CC21003D 02000D3D
	v_fma_mixlo_f16 v70, v62, s6, 0                            // 0000000CF0F0: CC210046 02000D3E
	v_fma_mixlo_f16 v65, v65, s6, 0                            // 0000000CF0F8: CC210041 02000D41
	s_waitcnt lgkmcnt(0)                                       // 0000000CF100: BF89FC07
	v_fma_mixlo_f16 v66, v66, s6, 0                            // 0000000CF104: CC210042 02000D42
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF10C: CC200040 8A000F40
	v_fma_mix_f32 v71, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF114: CC200047 8A000F3D
	ds_load_2addr_b32 v[61:62], v68 offset0:70 offset1:199     // 0000000CF11C: D8DCC746 3D000044
	v_fma_mix_f32 v68, v70, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF124: CC200044 8A000F46
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF12C: CC200041 8A000F41
	v_fma_mix_f32 v66, v66, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF134: CC200042 8A000F42
	v_fmac_f32_e32 v69, v71, v29                               // 0000000CF13C: 568A3B47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF140: BF870091
	v_fmac_f32_e32 v69, v68, v30                               // 0000000CF144: 568A3D44
	v_fmac_f32_e32 v69, v64, v31                               // 0000000CF148: 568A3F40
	v_fma_mixlo_f16 v64, v67, s6, 0                            // 0000000CF14C: CC210040 02000D43
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000CF154: BF8701B2
	v_fmac_f32_e32 v69, v65, v32                               // 0000000CF158: 568A4141
	s_waitcnt lgkmcnt(0)                                       // 0000000CF15C: BF89FC07
	v_fma_mixlo_f16 v61, v61, s6, 0                            // 0000000CF160: CC21003D 02000D3D
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF168: CC200040 8A000F40
	v_fma_mixlo_f16 v62, v62, s6, 0                            // 0000000CF170: CC21003E 02000D3E
	v_fmac_f32_e32 v69, v66, v33                               // 0000000CF178: 568A4342
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CF17C: BF870194
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF180: CC20003D 8A000F3D
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF188: CC20003E 8A000F3E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF190: BF870093
	v_fmac_f32_e32 v69, v64, v34                               // 0000000CF194: 568A4540
	v_fmac_f32_e32 v69, v61, v58                               // 0000000CF198: 568A753D
	v_add_nc_u32_e32 v61, 0x80, v60                            // 0000000CF19C: 4A7A78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CF1A4: BF870001
	v_dual_fmac_f32 v69, v62, v59 :: v_dual_mov_b32 v60, v61   // 0000000CF1A8: C810773E 453C013D
	ds_store_b32 v63, v69                                      // 0000000CF1B0: D8340000 0000453F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CF1B8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000CF1BC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c70>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CF1C0: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v31, v38         // 0000000CF1C4: CA100110 1E1E0126
	v_dual_mov_b32 v29, v15 :: v_dual_mov_b32 v32, 0           // 0000000CF1CC: CA10010F 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000CF1D4: 7E420324
	s_mov_b32 s10, 0                                           // 0000000CF1D8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CF1DC: BF89FC07
	s_barrier                                                  // 0000000CF1E0: BFBD0000
	buffer_gl0_inv                                             // 0000000CF1E4: E0AC0000 00000000
	s_nop 0                                                    // 0000000CF1EC: BF800000
	s_nop 0                                                    // 0000000CF1F0: BF800000
	s_nop 0                                                    // 0000000CF1F4: BF800000
	s_nop 0                                                    // 0000000CF1F8: BF800000
	s_nop 0                                                    // 0000000CF1FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CF200: DC520000 227C001D
	ds_load_b32 v58, v32 offset:17216                          // 0000000CF208: D8D84340 3A000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CF210: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CF218: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CF21C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000CF224: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CF228: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CF230: BF870004
	.long 0xd4490004                                           // 0000000CF234: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CF238: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CF240: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CF244: BF890007
	v_mul_f32_e32 v34, v34, v58                                // 0000000CF248: 10447522
	ds_store_b32 v31, v34 offset:13056                         // 0000000CF24C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000CF254: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CF25C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CF260: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CF264: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000CF268: BF89FC07
	s_barrier                                                  // 0000000CF26C: BFBD0000
	buffer_gl0_inv                                             // 0000000CF270: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v45 offset0:136 offset1:153    // 0000000CF278: D8DC9988 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:170 offset1:187    // 0000000CF280: D8DCBBAA 1F00002D
	ds_load_2addr_b32 v[33:34], v45 offset0:204 offset1:221    // 0000000CF288: D8DCDDCC 2100002D
	ds_load_2addr_b32 v[58:59], v45 offset0:238 offset1:255    // 0000000CF290: D8DCFFEE 3A00002D
	v_mov_b32_e32 v60, v0                                      // 0000000CF298: 7E780300
	s_mov_b32 s4, 0                                            // 0000000CF29C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000CF2A0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000CF2A4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000CF2AC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000CF2B4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000CF2B8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000CF2C0: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000CF2C8: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000CF2CC: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000CF2D4: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000CF2DC: BF89FC07
	v_fma_mixlo_f16 v58, v58, s6, 0                            // 0000000CF2E0: CC21003A 02000D3A
	v_fma_mixlo_f16 v59, v59, s6, 0                            // 0000000CF2E8: CC21003B 02000D3B
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF2F0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF2F8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF300: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF308: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF310: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF318: CC200022 8A000F22
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF320: CC20003A 8A000F3A
	v_fma_mix_f32 v59, v59, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF328: CC20003B 8A000F3B
	v_lshrrev_b32_e32 v63, 4, v60                              // 0000000CF330: 327E7884
	.long 0xd4490001                                           // 0000000CF334: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000CF338: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000CF340: BF870002
	v_lshlrev_b32_e32 v68, 2, v63                              // 0000000CF344: 30887E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 0000000CF348: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CF354: 8C040401
	v_add_nc_u32_e32 v61, 0x3200, v68                          // 0000000CF358: 4A7A88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000CF360: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000CF368: 4A8488FF 00003A00
	v_add_nc_u32_e32 v68, 0x3e00, v68                          // 0000000CF370: 4A8888FF 00003E00
	ds_load_b32 v69, v63                                       // 0000000CF378: D8D80000 4500003F
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000CF380: D8DCC342 40000040
	ds_load_2addr_b32 v[61:62], v61 offset0:64 offset1:193     // 0000000CF388: D8DCC140 3D00003D
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000CF390: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000CF398: BF89FC27
	v_fma_mixlo_f16 v64, v64, s6, 0                            // 0000000CF39C: CC210040 02000D40
	s_waitcnt lgkmcnt(1)                                       // 0000000CF3A4: BF89FC17
	v_fma_mixlo_f16 v61, v61, s6, 0                            // 0000000CF3A8: CC21003D 02000D3D
	v_fma_mixlo_f16 v70, v62, s6, 0                            // 0000000CF3B0: CC210046 02000D3E
	v_fma_mixlo_f16 v65, v65, s6, 0                            // 0000000CF3B8: CC210041 02000D41
	s_waitcnt lgkmcnt(0)                                       // 0000000CF3C0: BF89FC07
	v_fma_mixlo_f16 v66, v66, s6, 0                            // 0000000CF3C4: CC210042 02000D42
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF3CC: CC200040 8A000F40
	v_fma_mix_f32 v71, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF3D4: CC200047 8A000F3D
	ds_load_2addr_b32 v[61:62], v68 offset0:70 offset1:199     // 0000000CF3DC: D8DCC746 3D000044
	v_fma_mix_f32 v68, v70, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF3E4: CC200044 8A000F46
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF3EC: CC200041 8A000F41
	v_fma_mix_f32 v66, v66, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF3F4: CC200042 8A000F42
	v_fmac_f32_e32 v69, v71, v29                               // 0000000CF3FC: 568A3B47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF400: BF870091
	v_fmac_f32_e32 v69, v68, v30                               // 0000000CF404: 568A3D44
	v_fmac_f32_e32 v69, v64, v31                               // 0000000CF408: 568A3F40
	v_fma_mixlo_f16 v64, v67, s6, 0                            // 0000000CF40C: CC210040 02000D43
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000CF414: BF8701B2
	v_fmac_f32_e32 v69, v65, v32                               // 0000000CF418: 568A4141
	s_waitcnt lgkmcnt(0)                                       // 0000000CF41C: BF89FC07
	v_fma_mixlo_f16 v61, v61, s6, 0                            // 0000000CF420: CC21003D 02000D3D
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF428: CC200040 8A000F40
	v_fma_mixlo_f16 v62, v62, s6, 0                            // 0000000CF430: CC21003E 02000D3E
	v_fmac_f32_e32 v69, v66, v33                               // 0000000CF438: 568A4342
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CF43C: BF870194
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF440: CC20003D 8A000F3D
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF448: CC20003E 8A000F3E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF450: BF870093
	v_fmac_f32_e32 v69, v64, v34                               // 0000000CF454: 568A4540
	v_fmac_f32_e32 v69, v61, v58                               // 0000000CF458: 568A753D
	v_add_nc_u32_e32 v61, 0x80, v60                            // 0000000CF45C: 4A7A78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CF464: BF870001
	v_dual_fmac_f32 v69, v62, v59 :: v_dual_mov_b32 v60, v61   // 0000000CF468: C810773E 453C013D
	ds_store_b32 v63, v69                                      // 0000000CF470: D8340000 0000453F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CF478: 917E047E
	s_cbranch_execnz 65452                                     // 0000000CF47C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f30>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CF480: 8C7E047E
	v_mov_b32_e32 v30, v18                                     // 0000000CF484: 7E3C0312
	v_mov_b32_e32 v31, v38                                     // 0000000CF488: 7E3E0326
	v_dual_mov_b32 v29, v17 :: v_dual_mov_b32 v32, 0           // 0000000CF48C: CA100111 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000CF494: 7E420324
	s_mov_b32 s10, 0                                           // 0000000CF498: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CF49C: BF89FC07
	s_barrier                                                  // 0000000CF4A0: BFBD0000
	buffer_gl0_inv                                             // 0000000CF4A4: E0AC0000 00000000
	s_nop 0                                                    // 0000000CF4AC: BF800000
	s_nop 0                                                    // 0000000CF4B0: BF800000
	s_nop 0                                                    // 0000000CF4B4: BF800000
	s_nop 0                                                    // 0000000CF4B8: BF800000
	s_nop 0                                                    // 0000000CF4BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CF4C0: DC520000 227C001D
	ds_load_b32 v58, v32 offset:17248                          // 0000000CF4C8: D8D84360 3A000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CF4D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CF4D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CF4DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000CF4E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CF4E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CF4F0: BF870004
	.long 0xd4490004                                           // 0000000CF4F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CF4F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CF500: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CF504: BF890007
	v_mul_f32_e32 v34, v34, v58                                // 0000000CF508: 10447522
	ds_store_b32 v31, v34 offset:13056                         // 0000000CF50C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000CF514: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CF51C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CF520: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x20c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CF524: 8C7E0A7E
	v_add_nc_u32_e32 v31, 0x400, v45                           // 0000000CF528: 4A3E5AFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000CF530: BF89FC07
	s_barrier                                                  // 0000000CF534: BFBD0000
	buffer_gl0_inv                                             // 0000000CF538: E0AC0000 00000000
	s_mov_b32 s4, 0                                            // 0000000CF540: BE840080
	ds_load_2addr_b32 v[29:30], v31 offset0:16 offset1:33      // 0000000CF544: D8DC2110 1D00001F
	ds_load_2addr_b32 v[32:33], v31 offset0:50 offset1:67      // 0000000CF54C: D8DC4332 2000001F
	ds_load_2addr_b32 v[58:59], v31 offset0:84 offset1:101     // 0000000CF554: D8DC6554 3A00001F
	ds_load_2addr_b32 v[60:61], v31 offset0:118 offset1:135    // 0000000CF55C: D8DC8776 3C00001F
	s_waitcnt lgkmcnt(3)                                       // 0000000CF564: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000CF568: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000CF570: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000CF578: BF89FC27
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000CF57C: CC210020 02000D20
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000CF584: CC210021 02000D21
	s_waitcnt lgkmcnt(1)                                       // 0000000CF58C: BF89FC17
	v_fma_mixlo_f16 v34, v58, s6, 0                            // 0000000CF590: CC210022 02000D3A
	v_fma_mixlo_f16 v58, v59, s6, 0                            // 0000000CF598: CC21003A 02000D3B
	s_waitcnt lgkmcnt(0)                                       // 0000000CF5A0: BF89FC07
	v_fma_mixlo_f16 v59, v60, s6, 0                            // 0000000CF5A4: CC21003B 02000D3C
	v_fma_mixlo_f16 v60, v61, s6, 0                            // 0000000CF5AC: CC21003C 02000D3D
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF5B4: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF5BC: CC20001E 8A000F1E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF5C4: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF5CC: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF5D4: CC200022 8A000F22
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF5DC: CC20003A 8A000F3A
	v_fma_mix_f32 v59, v59, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF5E4: CC20003B 8A000F3B
	v_fma_mix_f32 v60, v60, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF5EC: CC20003C 8A000F3C
	v_mov_b32_e32 v61, v0                                      // 0000000CF5F4: 7E7A0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CF5F8: BF870121
	v_lshrrev_b32_e32 v64, 4, v61                              // 0000000CF5FC: 32807A84
	.long 0xd4490001                                           // 0000000CF600: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000CF604: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v64                              // 0000000CF60C: 308A8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 0000000CF610: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CF61C: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v69                          // 0000000CF620: 4A7C8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000CF628: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000CF630: 4A868AFF 00003A00
	v_add_nc_u32_e32 v69, 0x3e00, v69                          // 0000000CF638: 4A8A8AFF 00003E00
	ds_load_b32 v70, v64                                       // 0000000CF640: D8D80000 46000040
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000CF648: D8DCC342 41000041
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000CF650: D8DCC140 3E00003E
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000CF658: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000CF660: BF89FC27
	v_fma_mixlo_f16 v65, v65, s6, 0                            // 0000000CF664: CC210041 02000D41
	s_waitcnt lgkmcnt(1)                                       // 0000000CF66C: BF89FC17
	v_fma_mixlo_f16 v62, v62, s6, 0                            // 0000000CF670: CC21003E 02000D3E
	v_fma_mixlo_f16 v71, v63, s6, 0                            // 0000000CF678: CC210047 02000D3F
	v_fma_mixlo_f16 v66, v66, s6, 0                            // 0000000CF680: CC210042 02000D42
	s_waitcnt lgkmcnt(0)                                       // 0000000CF688: BF89FC07
	v_fma_mixlo_f16 v67, v67, s6, 0                            // 0000000CF68C: CC210043 02000D43
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF694: CC200041 8A000F41
	v_fma_mix_f32 v72, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF69C: CC200048 8A000F3E
	ds_load_2addr_b32 v[62:63], v69 offset0:70 offset1:199     // 0000000CF6A4: D8DCC746 3E000045
	v_fma_mix_f32 v69, v71, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF6AC: CC200045 8A000F47
	v_fma_mix_f32 v66, v66, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF6B4: CC200042 8A000F42
	v_fma_mix_f32 v67, v67, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF6BC: CC200043 8A000F43
	v_fmac_f32_e32 v70, v72, v29                               // 0000000CF6C4: 568C3B48
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF6C8: BF870091
	v_fmac_f32_e32 v70, v69, v30                               // 0000000CF6CC: 568C3D45
	v_fmac_f32_e32 v70, v65, v32                               // 0000000CF6D0: 568C4141
	v_fma_mixlo_f16 v65, v68, s6, 0                            // 0000000CF6D4: CC210041 02000D44
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000CF6DC: BF8701B2
	v_fmac_f32_e32 v70, v66, v33                               // 0000000CF6E0: 568C4342
	s_waitcnt lgkmcnt(0)                                       // 0000000CF6E4: BF89FC07
	v_fma_mixlo_f16 v62, v62, s6, 0                            // 0000000CF6E8: CC21003E 02000D3E
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF6F0: CC200041 8A000F41
	v_fma_mixlo_f16 v63, v63, s6, 0                            // 0000000CF6F8: CC21003F 02000D3F
	v_fmac_f32_e32 v70, v67, v34                               // 0000000CF700: 568C4543
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CF704: BF870194
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF708: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF710: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF718: BF870093
	v_fmac_f32_e32 v70, v65, v58                               // 0000000CF71C: 568C7541
	v_fmac_f32_e32 v70, v62, v59                               // 0000000CF720: 568C773E
	v_add_nc_u32_e32 v62, 0x80, v61                            // 0000000CF724: 4A7C7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CF72C: BF870001
	v_dual_fmac_f32 v70, v63, v60 :: v_dual_mov_b32 v61, v62   // 0000000CF730: C810793F 463C013E
	ds_store_b32 v64, v70                                      // 0000000CF738: D8340000 00004640
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CF740: 917E047E
	s_cbranch_execnz 65452                                     // 0000000CF744: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x21f8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CF748: 8C7E047E
	v_mov_b32_e32 v30, v20                                     // 0000000CF74C: 7E3C0314
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v29, v19         // 0000000CF750: CA100126 201C0113
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 0000000CF758: CA100080 21220124
	s_mov_b32 s10, 0                                           // 0000000CF760: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CF764: BF89FC07
	s_barrier                                                  // 0000000CF768: BFBD0000
	buffer_gl0_inv                                             // 0000000CF76C: E0AC0000 00000000
	s_nop 0                                                    // 0000000CF774: BF800000
	s_nop 0                                                    // 0000000CF778: BF800000
	s_nop 0                                                    // 0000000CF77C: BF800000
	global_load_b32 v58, v[29:30], off                         // 0000000CF780: DC520000 3A7C001D
	ds_load_b32 v59, v33 offset:17280                          // 0000000CF788: D8D84380 3B000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000CF790: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000CF798: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CF79C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000CF7A4: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CF7A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CF7B0: BF870004
	.long 0xd4490004                                           // 0000000CF7B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000CF7B8: 020244FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CF7C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CF7C4: BF890007
	v_mul_f32_e32 v58, v58, v59                                // 0000000CF7C8: 1074773A
	ds_store_b32 v32, v58 offset:13056                         // 0000000CF7CC: D8343300 00003A20
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000CF7D4: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CF7DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CF7E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2380>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CF7E4: 8C7E0A7E
	v_add_nc_u32_e32 v34, 0x600, v45                           // 0000000CF7E8: 4A445AFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000CF7F0: BF89FC07
	s_barrier                                                  // 0000000CF7F4: BFBD0000
	buffer_gl0_inv                                             // 0000000CF7F8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:152 offset1:169    // 0000000CF800: D8DCA998 1D00001F
	ds_load_2addr_b32 v[32:33], v31 offset0:186 offset1:203    // 0000000CF808: D8DCCBBA 2000001F
	ds_load_2addr_b32 v[58:59], v31 offset0:220 offset1:237    // 0000000CF810: D8DCEDDC 3A00001F
	ds_load_2addr_b32 v[60:61], v34 offset0:126 offset1:143    // 0000000CF818: D8DC8F7E 3C000022
	s_mov_b32 s4, 0                                            // 0000000CF820: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000CF824: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000CF828: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000CF830: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000CF838: BF89FC27
	v_fma_mixlo_f16 v31, v32, s6, 0                            // 0000000CF83C: CC21001F 02000D20
	v_fma_mixlo_f16 v32, v33, s6, 0                            // 0000000CF844: CC210020 02000D21
	s_waitcnt lgkmcnt(1)                                       // 0000000CF84C: BF89FC17
	v_fma_mixlo_f16 v33, v58, s6, 0                            // 0000000CF850: CC210021 02000D3A
	v_fma_mixlo_f16 v34, v59, s6, 0                            // 0000000CF858: CC210022 02000D3B
	s_waitcnt lgkmcnt(0)                                       // 0000000CF860: BF89FC07
	v_fma_mixlo_f16 v58, v60, s6, 0                            // 0000000CF864: CC21003A 02000D3C
	v_fma_mixlo_f16 v59, v61, s6, 0                            // 0000000CF86C: CC21003B 02000D3D
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF874: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF87C: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF884: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF88C: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF894: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF89C: CC200022 8A000F22
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF8A4: CC20003A 8A000F3A
	v_fma_mix_f32 v59, v59, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF8AC: CC20003B 8A000F3B
	v_mov_b32_e32 v60, v0                                      // 0000000CF8B4: 7E780300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CF8B8: BF870121
	v_lshrrev_b32_e32 v63, 4, v60                              // 0000000CF8BC: 327E7884
	.long 0xd4490001                                           // 0000000CF8C0: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000CF8C4: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v63                              // 0000000CF8CC: 30887E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 0000000CF8D0: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CF8DC: 8C040401
	v_add_nc_u32_e32 v61, 0x3200, v68                          // 0000000CF8E0: 4A7A88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000CF8E8: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000CF8F0: 4A8488FF 00003A00
	v_add_nc_u32_e32 v68, 0x3e00, v68                          // 0000000CF8F8: 4A8888FF 00003E00
	ds_load_b32 v69, v63                                       // 0000000CF900: D8D80000 4500003F
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000CF908: D8DCC342 40000040
	ds_load_2addr_b32 v[61:62], v61 offset0:64 offset1:193     // 0000000CF910: D8DCC140 3D00003D
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000CF918: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000CF920: BF89FC27
	v_fma_mixlo_f16 v64, v64, s6, 0                            // 0000000CF924: CC210040 02000D40
	s_waitcnt lgkmcnt(1)                                       // 0000000CF92C: BF89FC17
	v_fma_mixlo_f16 v61, v61, s6, 0                            // 0000000CF930: CC21003D 02000D3D
	v_fma_mixlo_f16 v70, v62, s6, 0                            // 0000000CF938: CC210046 02000D3E
	v_fma_mixlo_f16 v65, v65, s6, 0                            // 0000000CF940: CC210041 02000D41
	s_waitcnt lgkmcnt(0)                                       // 0000000CF948: BF89FC07
	v_fma_mixlo_f16 v66, v66, s6, 0                            // 0000000CF94C: CC210042 02000D42
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF954: CC200040 8A000F40
	v_fma_mix_f32 v71, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF95C: CC200047 8A000F3D
	ds_load_2addr_b32 v[61:62], v68 offset0:70 offset1:199     // 0000000CF964: D8DCC746 3D000044
	v_fma_mix_f32 v68, v70, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF96C: CC200044 8A000F46
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF974: CC200041 8A000F41
	v_fma_mix_f32 v66, v66, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF97C: CC200042 8A000F42
	v_fmac_f32_e32 v69, v71, v29                               // 0000000CF984: 568A3B47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF988: BF870091
	v_fmac_f32_e32 v69, v68, v30                               // 0000000CF98C: 568A3D44
	v_fmac_f32_e32 v69, v64, v31                               // 0000000CF990: 568A3F40
	v_fma_mixlo_f16 v64, v67, s6, 0                            // 0000000CF994: CC210040 02000D43
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000CF99C: BF8701B2
	v_fmac_f32_e32 v69, v65, v32                               // 0000000CF9A0: 568A4141
	s_waitcnt lgkmcnt(0)                                       // 0000000CF9A4: BF89FC07
	v_fma_mixlo_f16 v61, v61, s6, 0                            // 0000000CF9A8: CC21003D 02000D3D
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF9B0: CC200040 8A000F40
	v_fma_mixlo_f16 v62, v62, s6, 0                            // 0000000CF9B8: CC21003E 02000D3E
	v_fmac_f32_e32 v69, v66, v33                               // 0000000CF9C0: 568A4342
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CF9C4: BF870194
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF9C8: CC20003D 8A000F3D
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CF9D0: CC20003E 8A000F3E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CF9D8: BF870093
	v_fmac_f32_e32 v69, v64, v34                               // 0000000CF9DC: 568A4540
	v_fmac_f32_e32 v69, v61, v58                               // 0000000CF9E0: 568A753D
	v_add_nc_u32_e32 v61, 0x80, v60                            // 0000000CF9E4: 4A7A78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CF9EC: BF870001
	v_dual_fmac_f32 v69, v62, v59 :: v_dual_mov_b32 v60, v61   // 0000000CF9F0: C810773E 453C013D
	ds_store_b32 v63, v69                                      // 0000000CF9F8: D8340000 0000453F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CFA00: 917E047E
	s_cbranch_execnz 65452                                     // 0000000CFA04: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x24b8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CFA08: 8C7E047E
	v_mov_b32_e32 v30, v22                                     // 0000000CFA0C: 7E3C0316
	v_mov_b32_e32 v31, v38                                     // 0000000CFA10: 7E3E0326
	v_dual_mov_b32 v29, v21 :: v_dual_mov_b32 v32, 0           // 0000000CFA14: CA100115 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000CFA1C: 7E420324
	s_mov_b32 s10, 0                                           // 0000000CFA20: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CFA24: BF89FC07
	s_barrier                                                  // 0000000CFA28: BFBD0000
	buffer_gl0_inv                                             // 0000000CFA2C: E0AC0000 00000000
	s_nop 0                                                    // 0000000CFA34: BF800000
	s_nop 0                                                    // 0000000CFA38: BF800000
	s_nop 0                                                    // 0000000CFA3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CFA40: DC520000 227C001D
	ds_load_b32 v58, v32 offset:17312                          // 0000000CFA48: D8D843A0 3A000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CFA50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CFA58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CFA5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000CFA64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CFA68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CFA70: BF870004
	.long 0xd4490004                                           // 0000000CFA74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CFA78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CFA80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CFA84: BF890007
	v_mul_f32_e32 v34, v34, v58                                // 0000000CFA88: 10447522
	ds_store_b32 v31, v34 offset:13056                         // 0000000CFA8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000CFA94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CFA9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CFAA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2640>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CFAA4: 8C7E0A7E
	v_add_nc_u32_e32 v32, 0x800, v45                           // 0000000CFAA8: 4A405AFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000CFAB0: BF89FC07
	s_barrier                                                  // 0000000CFAB4: BFBD0000
	buffer_gl0_inv                                             // 0000000CFAB8: E0AC0000 00000000
	s_mov_b32 s4, 0                                            // 0000000CFAC0: BE840080
	ds_load_2addr_b32 v[29:30], v32 offset0:32 offset1:49      // 0000000CFAC4: D8DC3120 1D000020
	ds_load_2addr_b32 v[33:34], v32 offset0:66 offset1:83      // 0000000CFACC: D8DC5342 21000020
	ds_load_2addr_b32 v[58:59], v32 offset0:100 offset1:117    // 0000000CFAD4: D8DC7564 3A000020
	ds_load_2addr_b32 v[60:61], v32 offset0:134 offset1:151    // 0000000CFADC: D8DC9786 3C000020
	s_waitcnt lgkmcnt(3)                                       // 0000000CFAE4: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000CFAE8: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000CFAF0: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000CFAF8: BF89FC27
	v_fma_mixlo_f16 v31, v33, s6, 0                            // 0000000CFAFC: CC21001F 02000D21
	v_fma_mixlo_f16 v33, v34, s6, 0                            // 0000000CFB04: CC210021 02000D22
	s_waitcnt lgkmcnt(1)                                       // 0000000CFB0C: BF89FC17
	v_fma_mixlo_f16 v34, v58, s6, 0                            // 0000000CFB10: CC210022 02000D3A
	v_fma_mixlo_f16 v58, v59, s6, 0                            // 0000000CFB18: CC21003A 02000D3B
	s_waitcnt lgkmcnt(0)                                       // 0000000CFB20: BF89FC07
	v_fma_mixlo_f16 v59, v60, s6, 0                            // 0000000CFB24: CC21003B 02000D3C
	v_fma_mixlo_f16 v60, v61, s6, 0                            // 0000000CFB2C: CC21003C 02000D3D
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFB34: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFB3C: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFB44: CC20001F 8A000F1F
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFB4C: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFB54: CC200022 8A000F22
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFB5C: CC20003A 8A000F3A
	v_fma_mix_f32 v59, v59, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFB64: CC20003B 8A000F3B
	v_fma_mix_f32 v60, v60, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFB6C: CC20003C 8A000F3C
	v_mov_b32_e32 v61, v0                                      // 0000000CFB74: 7E7A0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CFB78: BF870121
	v_lshrrev_b32_e32 v64, 4, v61                              // 0000000CFB7C: 32807A84
	.long 0xd4490001                                           // 0000000CFB80: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000CFB84: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v64                              // 0000000CFB8C: 308A8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 0000000CFB90: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CFB9C: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v69                          // 0000000CFBA0: 4A7C8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000CFBA8: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000CFBB0: 4A868AFF 00003A00
	v_add_nc_u32_e32 v69, 0x3e00, v69                          // 0000000CFBB8: 4A8A8AFF 00003E00
	ds_load_b32 v70, v64                                       // 0000000CFBC0: D8D80000 46000040
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000CFBC8: D8DCC342 41000041
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000CFBD0: D8DCC140 3E00003E
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000CFBD8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000CFBE0: BF89FC27
	v_fma_mixlo_f16 v65, v65, s6, 0                            // 0000000CFBE4: CC210041 02000D41
	s_waitcnt lgkmcnt(1)                                       // 0000000CFBEC: BF89FC17
	v_fma_mixlo_f16 v62, v62, s6, 0                            // 0000000CFBF0: CC21003E 02000D3E
	v_fma_mixlo_f16 v71, v63, s6, 0                            // 0000000CFBF8: CC210047 02000D3F
	v_fma_mixlo_f16 v66, v66, s6, 0                            // 0000000CFC00: CC210042 02000D42
	s_waitcnt lgkmcnt(0)                                       // 0000000CFC08: BF89FC07
	v_fma_mixlo_f16 v67, v67, s6, 0                            // 0000000CFC0C: CC210043 02000D43
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFC14: CC200041 8A000F41
	v_fma_mix_f32 v72, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFC1C: CC200048 8A000F3E
	ds_load_2addr_b32 v[62:63], v69 offset0:70 offset1:199     // 0000000CFC24: D8DCC746 3E000045
	v_fma_mix_f32 v69, v71, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFC2C: CC200045 8A000F47
	v_fma_mix_f32 v66, v66, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFC34: CC200042 8A000F42
	v_fma_mix_f32 v67, v67, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFC3C: CC200043 8A000F43
	v_fmac_f32_e32 v70, v72, v29                               // 0000000CFC44: 568C3B48
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFC48: BF870091
	v_fmac_f32_e32 v70, v69, v30                               // 0000000CFC4C: 568C3D45
	v_fmac_f32_e32 v70, v65, v31                               // 0000000CFC50: 568C3F41
	v_fma_mixlo_f16 v65, v68, s6, 0                            // 0000000CFC54: CC210041 02000D44
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000CFC5C: BF8701B2
	v_fmac_f32_e32 v70, v66, v33                               // 0000000CFC60: 568C4342
	s_waitcnt lgkmcnt(0)                                       // 0000000CFC64: BF89FC07
	v_fma_mixlo_f16 v62, v62, s6, 0                            // 0000000CFC68: CC21003E 02000D3E
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFC70: CC200041 8A000F41
	v_fma_mixlo_f16 v63, v63, s6, 0                            // 0000000CFC78: CC21003F 02000D3F
	v_fmac_f32_e32 v70, v67, v34                               // 0000000CFC80: 568C4543
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CFC84: BF870194
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFC88: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFC90: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFC98: BF870093
	v_fmac_f32_e32 v70, v65, v58                               // 0000000CFC9C: 568C7541
	v_fmac_f32_e32 v70, v62, v59                               // 0000000CFCA0: 568C773E
	v_add_nc_u32_e32 v62, 0x80, v61                            // 0000000CFCA4: 4A7C7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CFCAC: BF870001
	v_dual_fmac_f32 v70, v63, v60 :: v_dual_mov_b32 v61, v62   // 0000000CFCB0: C810793F 463C013E
	ds_store_b32 v64, v70                                      // 0000000CFCB8: D8340000 00004640
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CFCC0: 917E047E
	s_cbranch_execnz 65452                                     // 0000000CFCC4: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2778>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CFCC8: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v31, v38         // 0000000CFCCC: CA100118 1E1E0126
	v_mov_b32_e32 v29, v23                                     // 0000000CFCD4: 7E3A0317
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 0000000CFCD8: CA100080 21220124
	s_mov_b32 s10, 0                                           // 0000000CFCE0: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CFCE4: BF89FC07
	s_barrier                                                  // 0000000CFCE8: BFBD0000
	buffer_gl0_inv                                             // 0000000CFCEC: E0AC0000 00000000
	s_nop 0                                                    // 0000000CFCF4: BF800000
	s_nop 0                                                    // 0000000CFCF8: BF800000
	s_nop 0                                                    // 0000000CFCFC: BF800000
	global_load_b32 v58, v[29:30], off                         // 0000000CFD00: DC520000 3A7C001D
	ds_load_b32 v59, v33 offset:17344                          // 0000000CFD08: D8D843C0 3B000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000CFD10: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000CFD18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CFD1C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000CFD24: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CFD28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CFD30: BF870004
	.long 0xd4490004                                           // 0000000CFD34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000CFD38: 020244FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CFD40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CFD44: BF890007
	v_mul_f32_e32 v58, v58, v59                                // 0000000CFD48: 1074773A
	ds_store_b32 v31, v58 offset:13056                         // 0000000CFD4C: D8343300 00003A1F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000CFD54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CFD5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CFD60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2900>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CFD64: 8C7E0A7E
	v_add_nc_u32_e32 v31, 0xc00, v45                           // 0000000CFD68: 4A3E5AFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000CFD70: BF89FC07
	s_barrier                                                  // 0000000CFD74: BFBD0000
	buffer_gl0_inv                                             // 0000000CFD78: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v32 offset0:168 offset1:185    // 0000000CFD80: D8DCB9A8 1D000020
	ds_load_2addr_b32 v[33:34], v32 offset0:202 offset1:219    // 0000000CFD88: D8DCDBCA 21000020
	ds_load_2addr_b32 v[58:59], v32 offset0:236 offset1:253    // 0000000CFD90: D8DCFDEC 3A000020
	ds_load_2addr_b32 v[60:61], v31 offset0:14 offset1:31      // 0000000CFD98: D8DC1F0E 3C00001F
	s_mov_b32 s4, 0                                            // 0000000CFDA0: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000CFDA4: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000CFDA8: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000CFDB0: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000CFDB8: BF89FC27
	v_fma_mixlo_f16 v32, v33, s6, 0                            // 0000000CFDBC: CC210020 02000D21
	v_fma_mixlo_f16 v33, v34, s6, 0                            // 0000000CFDC4: CC210021 02000D22
	s_waitcnt lgkmcnt(1)                                       // 0000000CFDCC: BF89FC17
	v_fma_mixlo_f16 v34, v58, s6, 0                            // 0000000CFDD0: CC210022 02000D3A
	v_fma_mixlo_f16 v58, v59, s6, 0                            // 0000000CFDD8: CC21003A 02000D3B
	s_waitcnt lgkmcnt(0)                                       // 0000000CFDE0: BF89FC07
	v_fma_mixlo_f16 v59, v60, s6, 0                            // 0000000CFDE4: CC21003B 02000D3C
	v_fma_mixlo_f16 v60, v61, s6, 0                            // 0000000CFDEC: CC21003C 02000D3D
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFDF4: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFDFC: CC20001E 8A000F1E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFE04: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFE0C: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFE14: CC200022 8A000F22
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFE1C: CC20003A 8A000F3A
	v_fma_mix_f32 v59, v59, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFE24: CC20003B 8A000F3B
	v_fma_mix_f32 v60, v60, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFE2C: CC20003C 8A000F3C
	v_mov_b32_e32 v61, v0                                      // 0000000CFE34: 7E7A0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CFE38: BF870121
	v_lshrrev_b32_e32 v64, 4, v61                              // 0000000CFE3C: 32807A84
	.long 0xd4490001                                           // 0000000CFE40: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000CFE44: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v64                              // 0000000CFE4C: 308A8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 0000000CFE50: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CFE5C: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v69                          // 0000000CFE60: 4A7C8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000CFE68: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000CFE70: 4A868AFF 00003A00
	v_add_nc_u32_e32 v69, 0x3e00, v69                          // 0000000CFE78: 4A8A8AFF 00003E00
	ds_load_b32 v70, v64                                       // 0000000CFE80: D8D80000 46000040
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000CFE88: D8DCC342 41000041
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000CFE90: D8DCC140 3E00003E
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000CFE98: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000CFEA0: BF89FC27
	v_fma_mixlo_f16 v65, v65, s6, 0                            // 0000000CFEA4: CC210041 02000D41
	s_waitcnt lgkmcnt(1)                                       // 0000000CFEAC: BF89FC17
	v_fma_mixlo_f16 v62, v62, s6, 0                            // 0000000CFEB0: CC21003E 02000D3E
	v_fma_mixlo_f16 v71, v63, s6, 0                            // 0000000CFEB8: CC210047 02000D3F
	v_fma_mixlo_f16 v66, v66, s6, 0                            // 0000000CFEC0: CC210042 02000D42
	s_waitcnt lgkmcnt(0)                                       // 0000000CFEC8: BF89FC07
	v_fma_mixlo_f16 v67, v67, s6, 0                            // 0000000CFECC: CC210043 02000D43
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFED4: CC200041 8A000F41
	v_fma_mix_f32 v72, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFEDC: CC200048 8A000F3E
	ds_load_2addr_b32 v[62:63], v69 offset0:70 offset1:199     // 0000000CFEE4: D8DCC746 3E000045
	v_fma_mix_f32 v69, v71, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFEEC: CC200045 8A000F47
	v_fma_mix_f32 v66, v66, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFEF4: CC200042 8A000F42
	v_fma_mix_f32 v67, v67, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFEFC: CC200043 8A000F43
	v_fmac_f32_e32 v70, v72, v29                               // 0000000CFF04: 568C3B48
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFF08: BF870091
	v_fmac_f32_e32 v70, v69, v30                               // 0000000CFF0C: 568C3D45
	v_fmac_f32_e32 v70, v65, v32                               // 0000000CFF10: 568C4141
	v_fma_mixlo_f16 v65, v68, s6, 0                            // 0000000CFF14: CC210041 02000D44
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000CFF1C: BF8701B2
	v_fmac_f32_e32 v70, v66, v33                               // 0000000CFF20: 568C4342
	s_waitcnt lgkmcnt(0)                                       // 0000000CFF24: BF89FC07
	v_fma_mixlo_f16 v62, v62, s6, 0                            // 0000000CFF28: CC21003E 02000D3E
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFF30: CC200041 8A000F41
	v_fma_mixlo_f16 v63, v63, s6, 0                            // 0000000CFF38: CC21003F 02000D3F
	v_fmac_f32_e32 v70, v67, v34                               // 0000000CFF40: 568C4543
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000CFF44: BF870194
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFF48: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000CFF50: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CFF58: BF870093
	v_fmac_f32_e32 v70, v65, v58                               // 0000000CFF5C: 568C7541
	v_fmac_f32_e32 v70, v62, v59                               // 0000000CFF60: 568C773E
	v_add_nc_u32_e32 v62, 0x80, v61                            // 0000000CFF64: 4A7C7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CFF6C: BF870001
	v_dual_fmac_f32 v70, v63, v60 :: v_dual_mov_b32 v61, v62   // 0000000CFF70: C810793F 463C013E
	ds_store_b32 v64, v70                                      // 0000000CFF78: D8340000 00004640
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CFF80: 917E047E
	s_cbranch_execnz 65452                                     // 0000000CFF84: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a38>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CFF88: 8C7E047E
	v_mov_b32_e32 v30, v26                                     // 0000000CFF8C: 7E3C031A
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v29, v25         // 0000000CFF90: CA100126 201C0119
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 0000000CFF98: CA100080 21220124
	s_mov_b32 s10, 0                                           // 0000000CFFA0: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CFFA4: BF89FC07
	s_barrier                                                  // 0000000CFFA8: BFBD0000
	buffer_gl0_inv                                             // 0000000CFFAC: E0AC0000 00000000
	s_nop 0                                                    // 0000000CFFB4: BF800000
	s_nop 0                                                    // 0000000CFFB8: BF800000
	s_nop 0                                                    // 0000000CFFBC: BF800000
	global_load_b32 v58, v[29:30], off                         // 0000000CFFC0: DC520000 3A7C001D
	ds_load_b32 v59, v33 offset:17376                          // 0000000CFFC8: D8D843E0 3B000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000CFFD0: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000CFFD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CFFDC: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000CFFE4: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CFFE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CFFF0: BF870004
	.long 0xd4490004                                           // 0000000CFFF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000CFFF8: 020244FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D0000: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D0004: BF890007
	v_mul_f32_e32 v58, v58, v59                                // 0000000D0008: 1074773A
	ds_store_b32 v32, v58 offset:13056                         // 0000000D000C: D8343300 00003A20
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000D0014: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D001C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D0020: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2bc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D0024: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D0028: BF89FC07
	s_barrier                                                  // 0000000D002C: BFBD0000
	buffer_gl0_inv                                             // 0000000D0030: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:48 offset1:65      // 0000000D0038: D8DC4130 1D00001F
	ds_load_2addr_b32 v[32:33], v31 offset0:82 offset1:99      // 0000000D0040: D8DC6352 2000001F
	ds_load_2addr_b32 v[58:59], v31 offset0:116 offset1:133    // 0000000D0048: D8DC8574 3A00001F
	ds_load_2addr_b32 v[60:61], v31 offset0:150 offset1:167    // 0000000D0050: D8DCA796 3C00001F
	s_mov_b32 s4, 0                                            // 0000000D0058: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000D005C: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000D0060: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000D0068: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000D0070: BF89FC27
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000D0074: CC210020 02000D20
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000D007C: CC210021 02000D21
	s_waitcnt lgkmcnt(1)                                       // 0000000D0084: BF89FC17
	v_fma_mixlo_f16 v34, v58, s6, 0                            // 0000000D0088: CC210022 02000D3A
	v_fma_mixlo_f16 v58, v59, s6, 0                            // 0000000D0090: CC21003A 02000D3B
	s_waitcnt lgkmcnt(0)                                       // 0000000D0098: BF89FC07
	v_fma_mixlo_f16 v59, v60, s6, 0                            // 0000000D009C: CC21003B 02000D3C
	v_fma_mixlo_f16 v60, v61, s6, 0                            // 0000000D00A4: CC21003C 02000D3D
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D00AC: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D00B4: CC20001E 8A000F1E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D00BC: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D00C4: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D00CC: CC200022 8A000F22
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D00D4: CC20003A 8A000F3A
	v_fma_mix_f32 v59, v59, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D00DC: CC20003B 8A000F3B
	v_fma_mix_f32 v60, v60, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D00E4: CC20003C 8A000F3C
	v_mov_b32_e32 v61, v0                                      // 0000000D00EC: 7E7A0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D00F0: BF870121
	v_lshrrev_b32_e32 v64, 4, v61                              // 0000000D00F4: 32807A84
	.long 0xd4490001                                           // 0000000D00F8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000D00FC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v64                              // 0000000D0104: 308A8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 0000000D0108: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D0114: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v69                          // 0000000D0118: 4A7C8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000D0120: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000D0128: 4A868AFF 00003A00
	v_add_nc_u32_e32 v69, 0x3e00, v69                          // 0000000D0130: 4A8A8AFF 00003E00
	ds_load_b32 v70, v64                                       // 0000000D0138: D8D80000 46000040
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000D0140: D8DCC342 41000041
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000D0148: D8DCC140 3E00003E
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000D0150: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000D0158: BF89FC27
	v_fma_mixlo_f16 v65, v65, s6, 0                            // 0000000D015C: CC210041 02000D41
	s_waitcnt lgkmcnt(1)                                       // 0000000D0164: BF89FC17
	v_fma_mixlo_f16 v62, v62, s6, 0                            // 0000000D0168: CC21003E 02000D3E
	v_fma_mixlo_f16 v71, v63, s6, 0                            // 0000000D0170: CC210047 02000D3F
	v_fma_mixlo_f16 v66, v66, s6, 0                            // 0000000D0178: CC210042 02000D42
	s_waitcnt lgkmcnt(0)                                       // 0000000D0180: BF89FC07
	v_fma_mixlo_f16 v67, v67, s6, 0                            // 0000000D0184: CC210043 02000D43
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D018C: CC200041 8A000F41
	v_fma_mix_f32 v72, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0194: CC200048 8A000F3E
	ds_load_2addr_b32 v[62:63], v69 offset0:70 offset1:199     // 0000000D019C: D8DCC746 3E000045
	v_fma_mix_f32 v69, v71, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D01A4: CC200045 8A000F47
	v_fma_mix_f32 v66, v66, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D01AC: CC200042 8A000F42
	v_fma_mix_f32 v67, v67, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D01B4: CC200043 8A000F43
	v_fmac_f32_e32 v70, v72, v29                               // 0000000D01BC: 568C3B48
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D01C0: BF870091
	v_fmac_f32_e32 v70, v69, v30                               // 0000000D01C4: 568C3D45
	v_fmac_f32_e32 v70, v65, v32                               // 0000000D01C8: 568C4141
	v_fma_mixlo_f16 v65, v68, s6, 0                            // 0000000D01CC: CC210041 02000D44
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000D01D4: BF8701B2
	v_fmac_f32_e32 v70, v66, v33                               // 0000000D01D8: 568C4342
	s_waitcnt lgkmcnt(0)                                       // 0000000D01DC: BF89FC07
	v_fma_mixlo_f16 v62, v62, s6, 0                            // 0000000D01E0: CC21003E 02000D3E
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D01E8: CC200041 8A000F41
	v_fma_mixlo_f16 v63, v63, s6, 0                            // 0000000D01F0: CC21003F 02000D3F
	v_fmac_f32_e32 v70, v67, v34                               // 0000000D01F8: 568C4543
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D01FC: BF870194
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0200: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0208: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0210: BF870093
	v_fmac_f32_e32 v70, v65, v58                               // 0000000D0214: 568C7541
	v_fmac_f32_e32 v70, v62, v59                               // 0000000D0218: 568C773E
	v_add_nc_u32_e32 v62, 0x80, v61                            // 0000000D021C: 4A7C7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D0224: BF870001
	v_dual_fmac_f32 v70, v63, v60 :: v_dual_mov_b32 v61, v62   // 0000000D0228: C810793F 463C013E
	ds_store_b32 v64, v70                                      // 0000000D0230: D8340000 00004640
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D0238: 917E047E
	s_cbranch_execnz 65452                                     // 0000000D023C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2cf0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D0240: 8C7E047E
	v_mov_b32_e32 v30, v28                                     // 0000000D0244: 7E3C031C
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v29, v27         // 0000000D0248: CA100126 201C011B
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 0000000D0250: CA100080 21220124
	s_mov_b32 s10, 0                                           // 0000000D0258: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D025C: BF89FC07
	s_barrier                                                  // 0000000D0260: BFBD0000
	buffer_gl0_inv                                             // 0000000D0264: E0AC0000 00000000
	s_nop 0                                                    // 0000000D026C: BF800000
	s_nop 0                                                    // 0000000D0270: BF800000
	s_nop 0                                                    // 0000000D0274: BF800000
	s_nop 0                                                    // 0000000D0278: BF800000
	s_nop 0                                                    // 0000000D027C: BF800000
	global_load_b32 v58, v[29:30], off                         // 0000000D0280: DC520000 3A7C001D
	ds_load_b32 v59, v33 offset:17408                          // 0000000D0288: D8D84400 3B000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000D0290: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000D0298: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D029C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000D02A4: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D02A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D02B0: BF870004
	.long 0xd4490004                                           // 0000000D02B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000D02B8: 020244FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D02C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D02C4: BF890007
	v_mul_f32_e32 v58, v58, v59                                // 0000000D02C8: 1074773A
	ds_store_b32 v32, v58 offset:13056                         // 0000000D02CC: D8343300 00003A20
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000D02D4: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D02DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D02E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D02E4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v45                           // 0000000D02E8: 4A425AFF 00000E00
	v_add_nc_u32_e32 v58, 0x1000, v45                          // 0000000D02F0: 4A745AFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000D02F8: BF89FC07
	s_barrier                                                  // 0000000D02FC: BFBD0000
	buffer_gl0_inv                                             // 0000000D0300: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:184 offset1:201    // 0000000D0308: D8DCC9B8 1D00001F
	ds_load_2addr_b32 v[31:32], v31 offset0:218 offset1:235    // 0000000D0310: D8DCEBDA 1F00001F
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000D0318: D8DC8D7C 21000021
	ds_load_2addr_b32 v[58:59], v58 offset0:30 offset1:47      // 0000000D0320: D8DC2F1E 3A00003A
	v_mov_b32_e32 v60, v0                                      // 0000000D0328: 7E780300
	s_mov_b32 s4, 0                                            // 0000000D032C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000D0330: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000D0334: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000D033C: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000D0344: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000D0348: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000D0350: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000D0358: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000D035C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000D0364: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000D036C: BF89FC07
	v_fma_mixlo_f16 v58, v58, s6, 0                            // 0000000D0370: CC21003A 02000D3A
	v_fma_mixlo_f16 v59, v59, s6, 0                            // 0000000D0378: CC21003B 02000D3B
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0380: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0388: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0390: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0398: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D03A0: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D03A8: CC200022 8A000F22
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D03B0: CC20003A 8A000F3A
	v_fma_mix_f32 v59, v59, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D03B8: CC20003B 8A000F3B
	v_lshrrev_b32_e32 v63, 4, v60                              // 0000000D03C0: 327E7884
	.long 0xd4490001                                           // 0000000D03C4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000D03C8: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D03D0: BF870002
	v_lshlrev_b32_e32 v68, 2, v63                              // 0000000D03D4: 30887E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 0000000D03D8: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D03E4: 8C040401
	v_add_nc_u32_e32 v61, 0x3200, v68                          // 0000000D03E8: 4A7A88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000D03F0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000D03F8: 4A8488FF 00003A00
	v_add_nc_u32_e32 v68, 0x3e00, v68                          // 0000000D0400: 4A8888FF 00003E00
	ds_load_b32 v69, v63                                       // 0000000D0408: D8D80000 4500003F
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000D0410: D8DCC342 40000040
	ds_load_2addr_b32 v[61:62], v61 offset0:64 offset1:193     // 0000000D0418: D8DCC140 3D00003D
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000D0420: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000D0428: BF89FC27
	v_fma_mixlo_f16 v64, v64, s6, 0                            // 0000000D042C: CC210040 02000D40
	s_waitcnt lgkmcnt(1)                                       // 0000000D0434: BF89FC17
	v_fma_mixlo_f16 v61, v61, s6, 0                            // 0000000D0438: CC21003D 02000D3D
	v_fma_mixlo_f16 v70, v62, s6, 0                            // 0000000D0440: CC210046 02000D3E
	v_fma_mixlo_f16 v65, v65, s6, 0                            // 0000000D0448: CC210041 02000D41
	s_waitcnt lgkmcnt(0)                                       // 0000000D0450: BF89FC07
	v_fma_mixlo_f16 v66, v66, s6, 0                            // 0000000D0454: CC210042 02000D42
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D045C: CC200040 8A000F40
	v_fma_mix_f32 v71, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0464: CC200047 8A000F3D
	ds_load_2addr_b32 v[61:62], v68 offset0:70 offset1:199     // 0000000D046C: D8DCC746 3D000044
	v_fma_mix_f32 v68, v70, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0474: CC200044 8A000F46
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D047C: CC200041 8A000F41
	v_fma_mix_f32 v66, v66, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D0484: CC200042 8A000F42
	v_fmac_f32_e32 v69, v71, v29                               // 0000000D048C: 568A3B47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0490: BF870091
	v_fmac_f32_e32 v69, v68, v30                               // 0000000D0494: 568A3D44
	v_fmac_f32_e32 v69, v64, v31                               // 0000000D0498: 568A3F40
	v_fma_mixlo_f16 v64, v67, s6, 0                            // 0000000D049C: CC210040 02000D43
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000D04A4: BF8701B2
	v_fmac_f32_e32 v69, v65, v32                               // 0000000D04A8: 568A4141
	s_waitcnt lgkmcnt(0)                                       // 0000000D04AC: BF89FC07
	v_fma_mixlo_f16 v61, v61, s6, 0                            // 0000000D04B0: CC21003D 02000D3D
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D04B8: CC200040 8A000F40
	v_fma_mixlo_f16 v62, v62, s6, 0                            // 0000000D04C0: CC21003E 02000D3E
	v_fmac_f32_e32 v69, v66, v33                               // 0000000D04C8: 568A4342
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D04CC: BF870194
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D04D0: CC20003D 8A000F3D
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D04D8: CC20003E 8A000F3E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D04E0: BF870093
	v_fmac_f32_e32 v69, v64, v34                               // 0000000D04E4: 568A4540
	v_fmac_f32_e32 v69, v61, v58                               // 0000000D04E8: 568A753D
	v_add_nc_u32_e32 v61, 0x80, v60                            // 0000000D04EC: 4A7A78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D04F4: BF870001
	v_dual_fmac_f32 v69, v62, v59 :: v_dual_mov_b32 v60, v61   // 0000000D04F8: C810773E 453C013D
	ds_store_b32 v63, v69                                      // 0000000D0500: D8340000 0000453F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D0508: 917E047E
	s_cbranch_execnz 65452                                     // 0000000D050C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2fc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D0510: 8C7E047E
	.long 0xd7000107                                           // 0000000D0514: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000D0518: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D0520: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000D0524: D5207C08 00061080
	.long 0xd7000109                                           // 0000000D052C: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000D0530: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000D0538: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000D0540: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000D0544: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D054C: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000D0550: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000D0558: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000D055C: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000D0564: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000D056C: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000D0570: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D0578: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000D057C: D5207C10 00062080
	.long 0xd7000111                                           // 0000000D0584: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000D0588: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000D0590: D5207C12 00062480
	.long 0xd7000113                                           // 0000000D0598: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000D059C: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D05A4: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000D05A8: D5207C14 00062880
	.long 0xd7000115                                           // 0000000D05B0: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000D05B4: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000D05BC: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000D05C4: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000D05C8: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D05D0: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000D05D4: D5207C18 00063080
	.long 0xd7000119                                           // 0000000D05DC: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000D05E0: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000D05E8: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000D05F0: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000D05F4: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D05FC: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000D0600: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000D0608: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000D060C: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000D0610: BF062105
	s_barrier                                                  // 0000000D0614: BFBD0000
	buffer_gl0_inv                                             // 0000000D0618: E0AC0000 00000000
	s_cbranch_scc0 62564                                       // 0000000D0620: BFA1F464 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b4>
	v_mov_b32_e32 v4, v36                                      // 0000000D0624: 7E080324
	s_add_u32 s0, s28, s20                                     // 0000000D0628: 8000141C
	.long 0xd73c0000                                           // 0000000D062C: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000D0630: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000D0634: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000D0638: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000D063C: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000D0640: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000D0644: 82010103
	.long 0xd7006a00                                           // 0000000D0648: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000D064C: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000D0650: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000D0654: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000D065C: BE810080
	.long 0xd7006a00                                           // 0000000D0660: D7006A00
	v_cndmask_b32_e32 v1, v0, v37, vcc_lo                      // 0000000D0664: 02024B00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000D0668: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D0670: BF870092
	.long 0xd7006a00                                           // 0000000D0674: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000D0678: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000D067C: D5207C01 01AA0211
	s_nop 0                                                    // 0000000D0684: BF800000
	s_nop 0                                                    // 0000000D0688: BF800000
	s_nop 0                                                    // 0000000D068C: BF800000
	s_nop 0                                                    // 0000000D0690: BF800000
	s_nop 0                                                    // 0000000D0694: BF800000
	s_nop 0                                                    // 0000000D0698: BF800000
	s_nop 0                                                    // 0000000D069C: BF800000
	s_nop 0                                                    // 0000000D06A0: BF800000
	s_nop 0                                                    // 0000000D06A4: BF800000
	s_nop 0                                                    // 0000000D06A8: BF800000
	s_nop 0                                                    // 0000000D06AC: BF800000
	s_nop 0                                                    // 0000000D06B0: BF800000
	s_nop 0                                                    // 0000000D06B4: BF800000
	s_nop 0                                                    // 0000000D06B8: BF800000
	s_nop 0                                                    // 0000000D06BC: BF800000
	ds_load_b32 v2, v35                                        // 0000000D06C0: D8D80000 02000023
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000D06C8: 4A0808FF 00000080
	v_add_nc_u32_e32 v35, 0x220, v35                           // 0000000D06D0: 4A4646FF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000D06D8: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000D06DC: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000D06E4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000D06E8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000D06EC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000D06F4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000D06F8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000D0700: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000D0708: 917E017E
	s_cbranch_execnz 65516                                     // 0000000D070C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x32c0>
	s_endpgm                                                   // 0000000D0710: BFB00000
		...

