0000000000166200 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000166200: BF850001
	s_load_b512 s[12:27], s[0:1], 0x8                          // 000000166204: F4100300 F8000008
	s_load_b128 s[4:7], s[0:1], 0x48                           // 00000016620C: F4080100 F8000048
	s_lshl_b32 s8, s3, 6                                       // 000000166214: 84088603
	s_ashr_i32 s3, s2, 31                                      // 000000166218: 86039F02
	s_ashr_i32 s9, s8, 31                                      // 00000016621C: 86099F08
	v_and_b32_e32 v88, 63, v0                                  // 000000166220: 36B000BF
	s_movk_i32 s11, 0x210                                      // 000000166224: B00B0210
	v_mov_b32_e32 v4, v0                                       // 000000166228: 7E080300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000016622C: BF8704D2
	v_lshlrev_b32_e32 v2, 2, v88                               // 000000166230: 3004B082
	v_mad_u32_u24 v1, v88, s11, 0x3200                         // 000000166234: D60B0001 03FC1758 00003200
	s_waitcnt lgkmcnt(0)                                       // 000000166240: BF89FC07
	s_load_b32 s10, s[26:27], null                             // 000000166244: F400028D F8000000
	s_lshl_b64 s[26:27], s[4:5], 2                             // 00000016624C: 849A8204
	s_add_u32 s4, s24, s26                                     // 000000166250: 80041A18
	s_addc_u32 s5, s25, s27                                    // 000000166254: 82051B19
	s_lshl_b64 s[28:29], s[2:3], 16                            // 000000166258: 849C9002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000016625C: BF870009
	s_add_u32 s4, s4, s28                                      // 000000166260: 80041C04
	s_addc_u32 s5, s5, s29                                     // 000000166264: 82051D05
	s_waitcnt lgkmcnt(0)                                       // 000000166268: BF89FC07
	s_mul_i32 s33, s10, 0x9000000                              // 00000016626C: 9621FF0A 09000000
	s_mul_hi_i32 s34, s10, 0x9000000                           // 000000166274: 9722FF0A 09000000
	s_add_u32 s4, s4, s33                                      // 00000016627C: 80042104
	s_addc_u32 s5, s5, s34                                     // 000000166280: 82052205
	s_lshl_b64 s[30:31], s[8:9], 2                             // 000000166284: 849E8208
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000166288: BF8700B9
	s_add_u32 s4, s4, s30                                      // 00000016628C: 80041E04
	s_addc_u32 s5, s5, s31                                     // 000000166290: 82051F05
	.long 0xd7000402                                           // 000000166294: D7000402
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 000000166298: 02020404
	v_add_co_ci_u32_e64 v3, null, s5, 0, s4                    // 00000016629C: D5207C03 00110005
	s_mov_b32 s4, 0                                            // 0000001662A4: BE840080
	s_nop 0                                                    // 0000001662A8: BF800000
	s_nop 0                                                    // 0000001662AC: BF800000
	s_nop 0                                                    // 0000001662B0: BF800000
	s_nop 0                                                    // 0000001662B4: BF800000
	s_nop 0                                                    // 0000001662B8: BF800000
	s_nop 0                                                    // 0000001662BC: BF800000
	v_lshrrev_b32_e32 v7, 6, v4                                // 0000001662C0: 320E0886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001662C4: BF870121
	v_lshlrev_b32_e32 v5, 9, v7                                // 0000001662C8: 300A0E89
	v_lshl_add_u32 v7, v7, 2, v1                               // 0000001662CC: D6460007 04050507
	.long 0xd7006a05                                           // 0000001662D4: D7006A05
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 0000001662D8: 02020B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001662DC: BF8700D1
	v_add_co_ci_u32_e64 v6, null, 0, v3, vcc_lo                // 0000001662E0: D5207C06 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001662E8: 7C9208FF 00001F7F
	global_load_b32 v5, v[5:6], off                            // 0000001662F0: DC520000 057C0005
	v_add_nc_u32_e32 v6, 0x80, v4                              // 0000001662F8: 4A0C08FF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 000000166300: 8C04046A
	v_mov_b32_e32 v4, v6                                       // 000000166304: 7E080306
	s_waitcnt vmcnt(0)                                         // 000000166308: BF8903F7
	ds_store_b32 v7, v5                                        // 00000016630C: D8340000 00000507
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000166314: 917E047E
	s_cbranch_execnz 65513                                     // 000000166318: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000016631C: 8C7E047E
	s_load_b32 s35, s[0:1], 0x58                               // 000000166320: F40008C0 F8000058
	v_or_b32_e32 v89, 0xffffff80, v0                           // 000000166328: 38B200FF FFFFFF80
	v_lshrrev_b32_e32 v1, 6, v0                                // 000000166330: 32020086
	s_mov_b32 s0, 0                                            // 000000166334: BE800080
	s_waitcnt lgkmcnt(0)                                       // 000000166338: BF89FC07
	s_barrier                                                  // 00000016633C: BFBD0000
	buffer_gl0_inv                                             // 000000166340: E0AC0000 00000000
	s_cmp_gt_i32 s35, 0                                        // 000000166348: BF028023
	s_cbranch_scc1 9                                           // 00000016634C: BFA20009 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x174>
	v_lshrrev_b32_e32 v82, 6, v0                               // 000000166350: 32A40086
	v_or_b32_e32 v2, 0xffffff80, v0                            // 000000166354: 380400FF FFFFFF80
	v_mov_b32_e32 v83, 0                                       // 00000016635C: 7EA60280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000166360: BF870003
	v_mov_b32_e32 v3, v82                                      // 000000166364: 7E060352
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000166368: 916A007E
	s_cbranch_vccz 1                                           // 00000016636C: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x174>
	s_branch 5276                                              // 000000166370: BFA0149C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x53e4>
	s_add_i32 s0, s35, 63                                      // 000000166374: 8100BF23
	s_add_i32 s45, s2, 0xbd0                                   // 000000166378: 812DFF02 00000BD0
	s_lshr_b32 s44, s0, 6                                      // 000000166380: 852C8600
	s_add_u32 s4, s18, s30                                     // 000000166384: 80041E12
	s_addc_u32 s5, s19, s31                                    // 000000166388: 82051F13
	s_mov_b32 s19, 0                                           // 00000016638C: BE930080
	v_lshrrev_b32_e32 v90, 5, v0                               // 000000166390: 32B40085
	s_mov_b32 s36, s19                                         // 000000166394: BEA40013
	s_mov_b32 s37, s19                                         // 000000166398: BEA50013
	s_mov_b32 s38, s19                                         // 00000016639C: BEA60013
	s_mov_b32 s39, s19                                         // 0000001663A0: BEA70013
	s_mov_b32 s40, s19                                         // 0000001663A4: BEA80013
	s_mov_b32 s41, s19                                         // 0000001663A8: BEA90013
	s_mov_b32 s42, s19                                         // 0000001663AC: BEAA0013
	s_mov_b32 s43, s19                                         // 0000001663B0: BEAB0013
	v_lshlrev_b32_e32 v2, 2, v0                                // 0000001663B4: 30040082
	v_mul_u32_u24_e32 v7, 0xa00, v90                           // 0000001663B8: 160EB4FF 00000A00
	v_dual_mov_b32 v10, s36 :: v_dual_mov_b32 v11, s37         // 0000001663C0: CA100024 0A0A0025
	v_lshlrev_b32_e32 v3, 4, v90                               // 0000001663C8: 3006B484
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000001663CC: BF8701D4
	v_or_b32_e32 v91, 0xb600, v2                               // 0000001663D0: 38B604FF 0000B600
	v_dual_mov_b32 v13, s39 :: v_dual_add_nc_u32 v92, 0xb700, v2// 0000001663D8: CA200027 0D5C04FF 0000B700
	v_dual_mov_b32 v15, s41 :: v_dual_lshlrev_b32 v2, 8, v0    // 0000001663E4: CA220029 0F020088
	v_and_b32_e32 v4, 15, v0                                   // 0000001663EC: 3608008F
	v_bfe_u32 v5, v0, 4, 1                                     // 0000001663F0: D6100005 02050900
	v_dual_mov_b32 v17, s43 :: v_dual_and_b32 v2, 0xf00, v2    // 0000001663F8: CA24002B 110204FF 00000F00
	s_movk_i32 s0, 0x210                                       // 000000166404: B0000210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000166408: BF870193
	v_or_b32_e32 v93, v3, v4                                   // 00000016640C: 38BA0903
	v_or_b32_e32 v95, v3, v5                                   // 000000166410: 38BE0B03
	v_lshl_or_b32 v105, v88, 2, 0xb600                         // 000000166414: D6560069 03FD0558 0000B600
	v_lshl_or_b32 v3, v90, 12, v2                              // 000000166420: D6560003 0409195A
	v_mov_b32_e32 v2, 0                                        // 000000166428: 7E040280
	v_mov_b32_e32 v12, s38                                     // 00000016642C: 7E180226
	v_lshl_or_b32 v104, v95, 2, 0xb700                         // 000000166430: D6560068 03FD055F 0000B700
	v_mov_b32_e32 v14, s40                                     // 00000016643C: 7E1C0228
	.long 0xd7000a60                                           // 000000166440: D7000A60
	v_cndmask_b32_e32 v1, s22, v3, vcc_lo                      // 000000166444: 02020616
	v_mov_b32_e32 v83, v2                                      // 000000166448: 7EA60302
	v_mad_u32_u24 v94, v4, s0, 0x3200                          // 00000016644C: D60B005E 03FC0104 00003200
	s_lshl_b32 s0, s2, 7                                       // 000000166458: 84008702
	v_lshlrev_b32_e32 v6, 2, v4                                // 00000016645C: 300C0882
	s_ashr_i32 s1, s0, 31                                      // 000000166460: 86019F00
	v_mul_u32_u24_e32 v98, 0xa0, v4                            // 000000166464: 16C408FF 000000A0
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000016646C: 84808100
	v_mad_u32_u24 v3, 0x2100, v90, v94                         // 000000166470: D60B0003 057AB4FF 00002100
	s_add_u32 s6, s6, s0                                       // 00000016647C: 80060006
	s_addc_u32 s7, s7, s1                                      // 000000166480: 82070107
	s_lshl_b64 s[0:1], s[8:9], 1                               // 000000166484: 84808108
	v_mov_b32_e32 v82, v1                                      // 000000166488: 7EA40301
	s_add_u32 s6, s6, s0                                       // 00000016648C: 80060006
	s_movk_i32 s0, 0x2800                                      // 000000166490: B0002800
	s_addc_u32 s7, s7, s1                                      // 000000166494: 82070107
	v_mad_u32_u24 v99, 0xa0, v4, s0                            // 000000166498: D60B0063 000208FF 000000A0
	.long 0xd7000065                                           // 0000001664A4: D7000065
	v_cndmask_b32_e32 v1, s4, v6, vcc_lo                       // 0000001664A8: 02020C04
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001664AC: BF870001
	v_add_co_ci_u32_e64 v102, null, s5, 0, s0                  // 0000001664B0: D5207C66 00010005
	s_lshl_b64 s[0:1], s[2:3], 9                               // 0000001664B8: 84808902
	v_lshl_or_b32 v100, v5, 2, v3                              // 0000001664BC: D6560064 040D0505
	v_lshlrev_b32_e32 v5, 1, v4                                // 0000001664C4: 300A0881
	v_mad_u64_u32 v[3:4], null, 0x6000, v88, s[0:1]            // 0000001664C8: D6FE7C03 0002B0FF 00006000
	v_mul_u32_u24_e32 v6, 0xa0, v1                             // 0000001664D4: 160C02FF 000000A0
	v_add_co_ci_u32_e64 v97, null, s23, 0, s10                 // 0000001664DC: D5207C61 00290017
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001664E4: BF870094
	.long 0xd7000054                                           // 0000001664E8: D7000054
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000001664EC: 02020A06
	v_add_co_ci_u32_e64 v85, null, s7, 0, s0                   // 0000001664F0: D5207C55 00010007
	v_lshl_or_b32 v3, v1, 2, v3                                // 0000001664F8: D6560003 040D0501
	v_lshl_add_u32 v103, v95, 1, v98                           // 000000166500: D6460067 0589035F
	v_lshl_add_u32 v106, v88, 1, v6                            // 000000166508: D646006A 04190358
	v_dual_mov_b32 v16, s42 :: v_dual_add_nc_u32 v107, v98, v7 // 000000166510: CA20002A 106A0F62
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000166518: BF870094
	.long 0xd7000056                                           // 00000016651C: D7000056
	v_cndmask_b32_e32 v1, s14, v3, vcc_lo                      // 000000166520: 0202060E
	v_add_co_ci_u32_e64 v87, null, s15, v4, s0                 // 000000166524: D5207C57 0002080F
	s_mov_b32 s22, 0x41800000                                  // 00000016652C: BE9600FF 41800000
	s_mov_b32 s23, 0                                           // 000000166534: BE970080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 000000166538: 7C9800C0
	s_branch 13                                                // 00000016653C: BFA0000D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x374>
	.long 0xd7000056                                           // 000000166540: D7000056
	v_cndmask_b32_e32 v1, 0x180000, v86, vcc_lo                // 000000166544: 0202ACFF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016654C: BF870001
	v_add_co_ci_u32_e64 v87, null, 0, v87, s0                  // 000000166550: D5207C57 0002AE80
	s_add_i32 s23, s23, 1                                      // 000000166558: 81178117
	s_waitcnt lgkmcnt(0)                                       // 00000016655C: BF89FC07
	s_cmp_eq_u32 s23, s44                                      // 000000166560: BF062C17
	s_barrier                                                  // 000000166564: BFBD0000
	buffer_gl0_inv                                             // 000000166568: E0AC0000 00000000
	s_cbranch_scc1 5146                                        // 000000166570: BFA2141A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x53dc>
	s_mul_i32 s0, s23, 0xc00                                   // 000000166574: 9600FF17 00000C00
	s_lshl_b32 s46, s23, 6                                     // 00000016657C: 842E8617
	s_add_i32 s0, s45, s0                                      // 000000166580: 8100002D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000166584: BF870499
	s_ashr_i32 s1, s0, 31                                      // 000000166588: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000016658C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000166590: BF870009
	s_add_u32 s0, s16, s0                                      // 000000166594: 80000010
	s_addc_u32 s1, s17, s1                                     // 000000166598: 82010111
	global_load_b32 v3, v2, s[0:1]                             // 00000016659C: DC520000 03000002
	s_waitcnt vmcnt(0)                                         // 0000001665A4: BF8903F7
	v_readfirstlane_b32 s47, v3                                // 0000001665A8: 7E5E0503
	s_and_saveexec_b32 s1, vcc_lo                              // 0000001665AC: BE81206A
	s_cbranch_execz 77                                         // 0000001665B0: BFA5004D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4e8>
	v_or_b32_e32 v3, s46, v0                                   // 0000001665B4: 3806002E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001665B8: BF870091
	v_mad_u64_u32 v[3:4], null, v3, 48, s[2:3]                 // 0000001665BC: D6FE7C03 00096103
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000001665C4: 3408069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001665C8: BF870091
	.long 0xd73c0003                                           // 0000001665CC: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 0000001665D0: 02020682
	.long 0xd7000003                                           // 0000001665D4: D7000003
	v_cndmask_b32_e32 v1, s16, v3, vcc_lo                      // 0000001665D8: 02020610
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001665DC: BF8700C1
	v_add_co_ci_u32_e64 v4, null, s17, v4, s0                  // 0000001665E0: D5207C04 00020811
	global_load_b32 v3, v[3:4], off                            // 0000001665E8: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000001665F0: BF8903F7
	v_sub_f32_e32 v4, s47, v3                                  // 0000001665F4: 0808062F
	v_dual_mul_f32 v6, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, 0x3fb8aa3b, v4// 0000001665F8: C8C606FF 060408FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000166604: BF8701A1
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v6                          // 000000166608: D6130009 841A06FF 3FB8AA3B
	v_rndne_f32_e32 v18, v6                                    // 000000166614: 7E244706
	v_fma_f32 v7, 0x3fb8aa3b, v4, -v5                          // 000000166618: D6130007 841608FF 3FB8AA3B
	v_rndne_f32_e32 v8, v5                                     // 000000166624: 7E104705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000166628: BF870113
	v_dual_fmac_f32 v9, 0x32a5705f, v3 :: v_dual_sub_f32 v6, v6, v18// 00000016662C: C80A06FF 09062506 32A5705F
	v_sub_f32_e32 v5, v5, v8                                   // 000000166638: 080A1105
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016663C: BF870124
	v_fmac_f32_e32 v7, 0x32a5705f, v4                          // 000000166640: 560E08FF 32A5705F
	.long 0xd41b0000                                           // 000000166648: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v4, vcc_lo               // 00000016664C: 020208FF C2CE8ED0
	v_dual_add_f32 v6, v6, v9 :: v_dual_add_f32 v5, v5, v7     // 000000166654: C9081306 06040F05
	v_cvt_i32_f32_e32 v7, v8                                   // 00000016665C: 7E0E1108
	v_cvt_i32_f32_e32 v8, v18                                  // 000000166660: 7E101112
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000166664: BF870193
	v_exp_f32_e32 v6, v6                                       // 000000166668: 7E0C4B06
	v_exp_f32_e32 v5, v5                                       // 00000016666C: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000166670: BF870296
	.long 0xd71c0006                                           // 000000166674: D71C0006
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 000000166678: 02021106
	.long 0xd71c0005                                           // 00000016667C: D71C0005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000166680: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000166684: BF8700A1
	v_cndmask_b32_e64 v5, 0, v5, s0                            // 000000166688: D5010005 00020A80
	.long 0xd41b0000                                           // 000000166690: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v3, vcc_lo               // 000000166694: 020206FF C2CE8ED0
	v_cndmask_b32_e64 v6, 0, v6, s0                            // 00000016669C: D5010006 00020C80
	.long 0xd41e0000                                           // 0000001666A4: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v4, vcc_lo               // 0000001666A8: 020208FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001666B0: BF8700A1
	v_cndmask_b32_e64 v4, 0x7f800000, v5, s0                   // 0000001666B4: D5010004 00020AFF 7F800000
	.long 0xd41e0000                                           // 0000001666C0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v3, vcc_lo               // 0000001666C4: 020206FF 42B17218
	v_cndmask_b32_e64 v3, 0x7f800000, v6, s0                   // 0000001666CC: D5010003 00020CFF 7F800000
	ds_store_b32 v91, v4                                       // 0000001666D8: D8340000 0000045B
	ds_store_b32 v92, v3                                       // 0000001666E0: D8340000 0000035C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001666E8: 8C7E017E
	v_add_nc_u32_e32 v7, s46, v93                              // 0000001666EC: 4A0EBA2E
	.long 0x7f7a3880                                           // 0000001666F0: 7F7A3880
	s_waitcnt lgkmcnt(0)                                       // 0000001666F4: BF89FC07
	s_barrier                                                  // 0000001666F8: BFBD0000
	buffer_gl0_inv                                             // 0000001666FC: E0AC0000 00000000
	v_mad_u64_u32 v[3:4], null, v7, 48, s[2:3]                 // 000000166704: D6FE7C03 00096107
	.long 0xd4440000                                           // 00000016670C: D4440000
	v_cndmask_b32_e32 v1, s35, v7, vcc_lo                      // 000000166710: 02020E23
	.long 0x7f7639bd                                           // 000000166714: 7F7639BD
	.long 0x7e7639bd                                           // 000000166718: 7E7639BD
	.long 0x7f7439bd                                           // 00000016671C: 7F7439BD
	.long 0x7e7439bd                                           // 000000166720: 7E7439BD
	.long 0xd73c0005                                           // 000000166724: D73C0005
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000166728: 02020689
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016672C: BF870091
	.long 0xd7000103                                           // 000000166730: D7000103
	v_cndmask_b32_e32 v1, s20, v5, vcc_lo                      // 000000166734: 02020A14
	v_add_co_ci_u32_e64 v4, null, s21, v6, s1                  // 000000166738: D5207C04 00060C15
	s_and_saveexec_b32 s1, s0                                  // 000000166740: BE812000
	s_cbranch_execz 11                                         // 000000166744: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x574>
	global_load_b128 v[18:21], v[3:4], off                     // 000000166748: DC5E0000 127C0003
	s_waitcnt vmcnt(0)                                         // 000000166750: BF8903F7
	v_fma_mixlo_f16 v58, v18, s22, 0                           // 000000166754: CC21003A 02002D12
	v_fma_mixhi_f16 v58, v19, s22, 0                           // 00000016675C: CC22003A 02002D13
	v_fma_mixlo_f16 v59, v20, s22, 0                           // 000000166764: CC21003B 02002D14
	v_fma_mixhi_f16 v59, v21, s22, 0                           // 00000016676C: CC22003B 02002D15
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166774: 8C7E017E
	.long 0x7e7a39bd                                           // 000000166778: 7E7A39BD
	.long 0x7f7839bd                                           // 00000016677C: 7F7839BD
	.long 0x7e7839bd                                           // 000000166780: 7E7839BD
	s_and_saveexec_b32 s1, s0                                  // 000000166784: BE812000
	s_cbranch_execz 11                                         // 000000166788: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5b8>
	global_load_b128 v[18:21], v[3:4], off offset:16           // 00000016678C: DC5E0010 127C0003
	s_waitcnt vmcnt(0)                                         // 000000166794: BF8903F7
	v_fma_mixlo_f16 v60, v18, s22, 0                           // 000000166798: CC21003C 02002D12
	v_fma_mixhi_f16 v60, v19, s22, 0                           // 0000001667A0: CC22003C 02002D13
	v_fma_mixlo_f16 v61, v20, s22, 0                           // 0000001667A8: CC21003D 02002D14
	v_fma_mixhi_f16 v61, v21, s22, 0                           // 0000001667B0: CC22003D 02002D15
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001667B8: 8C7E017E
	.long 0x7f823880                                           // 0000001667BC: 7F823880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001667C0: BF870001
	.long 0x7f7e39c1                                           // 0000001667C4: 7F7E39C1
	.long 0x7e7e39c1                                           // 0000001667C8: 7E7E39C1
	.long 0x7f7c39c1                                           // 0000001667CC: 7F7C39C1
	.long 0x7e7c39c1                                           // 0000001667D0: 7E7C39C1
	s_and_saveexec_b32 s1, s0                                  // 0000001667D4: BE812000
	s_cbranch_execz 11                                         // 0000001667D8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x608>
	global_load_b128 v[18:21], v[3:4], off offset:32           // 0000001667DC: DC5E0020 127C0003
	s_waitcnt vmcnt(0)                                         // 0000001667E4: BF8903F7
	v_fma_mixlo_f16 v62, v18, s22, 0                           // 0000001667E8: CC21003E 02002D12
	v_fma_mixhi_f16 v62, v19, s22, 0                           // 0000001667F0: CC22003E 02002D13
	v_fma_mixlo_f16 v63, v20, s22, 0                           // 0000001667F8: CC21003F 02002D14
	v_fma_mixhi_f16 v63, v21, s22, 0                           // 000000166800: CC22003F 02002D15
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166808: 8C7E017E
	.long 0x7e8239c1                                           // 00000016680C: 7E8239C1
	.long 0x7f8039c1                                           // 000000166810: 7F8039C1
	.long 0x7e8039c1                                           // 000000166814: 7E8039C1
	s_and_saveexec_b32 s1, s0                                  // 000000166818: BE812000
	s_cbranch_execz 11                                         // 00000016681C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x64c>
	global_load_b128 v[18:21], v[3:4], off offset:48           // 000000166820: DC5E0030 127C0003
	s_waitcnt vmcnt(0)                                         // 000000166828: BF8903F7
	v_fma_mixlo_f16 v64, v18, s22, 0                           // 00000016682C: CC210040 02002D12
	v_fma_mixhi_f16 v64, v19, s22, 0                           // 000000166834: CC220040 02002D13
	v_fma_mixlo_f16 v65, v20, s22, 0                           // 00000016683C: CC210041 02002D14
	v_fma_mixhi_f16 v65, v21, s22, 0                           // 000000166844: CC220041 02002D15
	s_or_b32 exec_lo, exec_lo, s1                              // 00000016684C: 8C7E017E
	ds_load_b128 v[18:21], v94                                 // 000000166850: DBFC0000 1200005E
	ds_load_b128 v[22:25], v94 offset:16                       // 000000166858: DBFC0010 1600005E
	ds_load_b128 v[26:29], v94 offset:8448                     // 000000166860: DBFC2100 1A00005E
	ds_load_b128 v[30:33], v94 offset:8464                     // 000000166868: DBFC2110 1E00005E
	ds_load_b128 v[50:53], v94 offset:16896                    // 000000166870: DBFC4200 3200005E
	ds_load_b128 v[54:57], v94 offset:16912                    // 000000166878: DBFC4210 3600005E
	ds_load_b128 v[66:69], v94 offset:25344                    // 000000166880: DBFC6300 4200005E
	ds_load_b128 v[70:73], v94 offset:25360                    // 000000166888: DBFC6310 4600005E
	s_waitcnt lgkmcnt(7)                                       // 000000166890: BF89FC77
	v_fma_mixlo_f16 v18, v18, s22, 0                           // 000000166894: CC210012 02002D12
	v_fma_mixhi_f16 v18, v19, s22, 0                           // 00000016689C: CC220012 02002D13
	v_fma_mixlo_f16 v19, v20, s22, 0                           // 0000001668A4: CC210013 02002D14
	v_fma_mixhi_f16 v19, v21, s22, 0                           // 0000001668AC: CC220013 02002D15
	s_waitcnt lgkmcnt(6)                                       // 0000001668B4: BF89FC67
	v_fma_mixlo_f16 v20, v22, s22, 0                           // 0000001668B8: CC210014 02002D16
	v_fma_mixhi_f16 v20, v23, s22, 0                           // 0000001668C0: CC220014 02002D17
	v_fma_mixlo_f16 v21, v24, s22, 0                           // 0000001668C8: CC210015 02002D18
	v_fma_mixhi_f16 v21, v25, s22, 0                           // 0000001668D0: CC220015 02002D19
	v_dual_mov_b32 v22, v18 :: v_dual_mov_b32 v23, v19         // 0000001668D8: CA100112 16160113
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001668E0: BF870004
	v_mov_b32_e32 v24, v20                                     // 0000001668E4: 7E300314
	s_waitcnt lgkmcnt(5)                                       // 0000001668E8: BF89FC57
	v_fma_mixlo_f16 v26, v26, s22, 0                           // 0000001668EC: CC21001A 02002D1A
	v_mov_b32_e32 v25, v21                                     // 0000001668F4: 7E320315
	v_fma_mixhi_f16 v26, v27, s22, 0                           // 0000001668F8: CC22001A 02002D1B
	v_fma_mixlo_f16 v27, v28, s22, 0                           // 000000166900: CC21001B 02002D1C
	v_fma_mixhi_f16 v27, v29, s22, 0                           // 000000166908: CC22001B 02002D1D
	s_waitcnt lgkmcnt(4)                                       // 000000166910: BF89FC47
	v_fma_mixlo_f16 v28, v30, s22, 0                           // 000000166914: CC21001C 02002D1E
	v_fma_mixhi_f16 v28, v31, s22, 0                           // 00000016691C: CC22001C 02002D1F
	v_fma_mixlo_f16 v29, v32, s22, 0                           // 000000166924: CC21001D 02002D20
	v_fma_mixhi_f16 v29, v33, s22, 0                           // 00000016692C: CC22001D 02002D21
	v_wmma_f32_16x16x16_f16 v[42:49], v[58:65], v[18:25], v[10:17]// 000000166934: CC40402A 1C2A253A
	s_waitcnt lgkmcnt(3)                                       // 00000016693C: BF89FC37
	v_fma_mixlo_f16 v18, v50, s22, 0                           // 000000166940: CC210012 02002D32
	v_fma_mixhi_f16 v18, v51, s22, 0                           // 000000166948: CC220012 02002D33
	v_fma_mixlo_f16 v19, v52, s22, 0                           // 000000166950: CC210013 02002D34
	v_fma_mixhi_f16 v19, v53, s22, 0                           // 000000166958: CC220013 02002D35
	s_waitcnt lgkmcnt(2)                                       // 000000166960: BF89FC27
	v_fma_mixlo_f16 v20, v54, s22, 0                           // 000000166964: CC210014 02002D36
	v_fma_mixhi_f16 v20, v55, s22, 0                           // 00000016696C: CC220014 02002D37
	v_fma_mixlo_f16 v21, v56, s22, 0                           // 000000166974: CC210015 02002D38
	v_fma_mixhi_f16 v21, v57, s22, 0                           // 00000016697C: CC220015 02002D39
	s_waitcnt lgkmcnt(1)                                       // 000000166984: BF89FC17
	v_fma_mixlo_f16 v66, v66, s22, 0                           // 000000166988: CC210042 02002D42
	v_fma_mixhi_f16 v66, v67, s22, 0                           // 000000166990: CC220042 02002D43
	v_fma_mixlo_f16 v67, v68, s22, 0                           // 000000166998: CC210043 02002D44
	v_fma_mixhi_f16 v67, v69, s22, 0                           // 0000001669A0: CC220043 02002D45
	s_waitcnt lgkmcnt(0)                                       // 0000001669A8: BF89FC07
	v_fma_mixlo_f16 v68, v70, s22, 0                           // 0000001669AC: CC210044 02002D46
	v_fma_mixhi_f16 v68, v71, s22, 0                           // 0000001669B4: CC220044 02002D47
	v_fma_mixlo_f16 v69, v72, s22, 0                           // 0000001669BC: CC210045 02002D48
	v_fma_mixhi_f16 v69, v73, s22, 0                           // 0000001669C4: CC220045 02002D49
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v31, v27         // 0000001669CC: CA10011A 1E1E011B
	v_dual_mov_b32 v32, v28 :: v_dual_mov_b32 v33, v29         // 0000001669D4: CA10011C 2020011D
	v_dual_mov_b32 v22, v18 :: v_dual_mov_b32 v23, v19         // 0000001669DC: CA100112 16160113
	v_dual_mov_b32 v24, v20 :: v_dual_mov_b32 v25, v21         // 0000001669E4: CA100114 18180115
	v_dual_mov_b32 v70, v66 :: v_dual_mov_b32 v71, v67         // 0000001669EC: CA100142 46460143
	v_dual_mov_b32 v72, v68 :: v_dual_mov_b32 v73, v69         // 0000001669F4: CA100144 48480145
	.long 0x7f723880                                           // 0000001669FC: 7F723880
	v_wmma_f32_16x16x16_f16 v[34:41], v[58:65], v[26:33], v[10:17]// 000000166A00: CC404022 1C2A353A
	v_wmma_f32_16x16x16_f16 v[26:33], v[58:65], v[18:25], v[10:17]// 000000166A08: CC40401A 1C2A253A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000166A10: BF870214
	v_wmma_f32_16x16x16_f16 v[18:25], v[58:65], v[66:73], v[10:17]// 000000166A14: CC404012 1C2A853A
	.long 0x7f6e39b9                                           // 000000166A1C: 7F6E39B9
	.long 0x7e6e39b9                                           // 000000166A20: 7E6E39B9
	.long 0x7f6c39b9                                           // 000000166A24: 7F6C39B9
	.long 0x7e6c39b9                                           // 000000166A28: 7E6C39B9
	s_and_saveexec_b32 s1, s0                                  // 000000166A2C: BE812000
	s_cbranch_execz 11                                         // 000000166A30: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x860>
	global_load_b128 v[50:53], v[3:4], off offset:64           // 000000166A34: DC5E0040 327C0003
	s_waitcnt vmcnt(0)                                         // 000000166A3C: BF8903F7
	v_fma_mixlo_f16 v54, v50, s22, 0                           // 000000166A40: CC210036 02002D32
	v_fma_mixhi_f16 v54, v51, s22, 0                           // 000000166A48: CC220036 02002D33
	v_fma_mixlo_f16 v55, v52, s22, 0                           // 000000166A50: CC210037 02002D34
	v_fma_mixhi_f16 v55, v53, s22, 0                           // 000000166A58: CC220037 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166A60: 8C7E017E
	.long 0x7e7239b9                                           // 000000166A64: 7E7239B9
	.long 0x7f7039b9                                           // 000000166A68: 7F7039B9
	.long 0x7e7039b9                                           // 000000166A6C: 7E7039B9
	s_and_saveexec_b32 s1, s0                                  // 000000166A70: BE812000
	s_cbranch_execz 11                                         // 000000166A74: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8a4>
	global_load_b128 v[50:53], v[3:4], off offset:80           // 000000166A78: DC5E0050 327C0003
	s_waitcnt vmcnt(0)                                         // 000000166A80: BF8903F7
	v_fma_mixlo_f16 v56, v50, s22, 0                           // 000000166A84: CC210038 02002D32
	v_fma_mixhi_f16 v56, v51, s22, 0                           // 000000166A8C: CC220038 02002D33
	v_fma_mixlo_f16 v57, v52, s22, 0                           // 000000166A94: CC210039 02002D34
	v_fma_mixhi_f16 v57, v53, s22, 0                           // 000000166A9C: CC220039 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166AA4: 8C7E017E
	.long 0x7f7a3880                                           // 000000166AA8: 7F7A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000166AAC: BF870001
	.long 0x7f7639bd                                           // 000000166AB0: 7F7639BD
	.long 0x7e7639bd                                           // 000000166AB4: 7E7639BD
	.long 0x7f7439bd                                           // 000000166AB8: 7F7439BD
	.long 0x7e7439bd                                           // 000000166ABC: 7E7439BD
	s_and_saveexec_b32 s1, s0                                  // 000000166AC0: BE812000
	s_cbranch_execz 11                                         // 000000166AC4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8f4>
	global_load_b128 v[50:53], v[3:4], off offset:96           // 000000166AC8: DC5E0060 327C0003
	s_waitcnt vmcnt(0)                                         // 000000166AD0: BF8903F7
	v_fma_mixlo_f16 v58, v50, s22, 0                           // 000000166AD4: CC21003A 02002D32
	v_fma_mixhi_f16 v58, v51, s22, 0                           // 000000166ADC: CC22003A 02002D33
	v_fma_mixlo_f16 v59, v52, s22, 0                           // 000000166AE4: CC21003B 02002D34
	v_fma_mixhi_f16 v59, v53, s22, 0                           // 000000166AEC: CC22003B 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166AF4: 8C7E017E
	.long 0x7e7a39bd                                           // 000000166AF8: 7E7A39BD
	.long 0x7f7839bd                                           // 000000166AFC: 7F7839BD
	.long 0x7e7839bd                                           // 000000166B00: 7E7839BD
	s_and_saveexec_b32 s1, s0                                  // 000000166B04: BE812000
	s_cbranch_execz 11                                         // 000000166B08: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x938>
	global_load_b128 v[50:53], v[3:4], off offset:112          // 000000166B0C: DC5E0070 327C0003
	s_waitcnt vmcnt(0)                                         // 000000166B14: BF8903F7
	v_fma_mixlo_f16 v60, v50, s22, 0                           // 000000166B18: CC21003C 02002D32
	v_fma_mixhi_f16 v60, v51, s22, 0                           // 000000166B20: CC22003C 02002D33
	v_fma_mixlo_f16 v61, v52, s22, 0                           // 000000166B28: CC21003D 02002D34
	v_fma_mixhi_f16 v61, v53, s22, 0                           // 000000166B30: CC22003D 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166B38: 8C7E017E
	ds_load_b128 v[50:53], v94 offset:64                       // 000000166B3C: DBFC0040 3200005E
	ds_load_b128 v[64:67], v94 offset:80                       // 000000166B44: DBFC0050 4000005E
	ds_load_b128 v[70:73], v94 offset:8512                     // 000000166B4C: DBFC2140 4600005E
	ds_load_b128 v[74:77], v94 offset:8528                     // 000000166B54: DBFC2150 4A00005E
	ds_load_b128 v[78:81], v94 offset:16960                    // 000000166B5C: DBFC4240 4E00005E
	ds_load_b128 v[110:113], v94 offset:16976                  // 000000166B64: DBFC4250 6E00005E
	ds_load_b128 v[116:119], v94 offset:25408                  // 000000166B6C: DBFC6340 7400005E
	s_waitcnt lgkmcnt(6)                                       // 000000166B74: BF89FC67
	v_fma_mixlo_f16 v62, v50, s22, 0                           // 000000166B78: CC21003E 02002D32
	v_fma_mixhi_f16 v62, v51, s22, 0                           // 000000166B80: CC22003E 02002D33
	v_fma_mixlo_f16 v63, v52, s22, 0                           // 000000166B88: CC21003F 02002D34
	v_fma_mixhi_f16 v63, v53, s22, 0                           // 000000166B90: CC22003F 02002D35
	ds_load_b128 v[50:53], v94 offset:25424                    // 000000166B98: DBFC6350 3200005E
	s_waitcnt lgkmcnt(6)                                       // 000000166BA0: BF89FC67
	v_fma_mixlo_f16 v64, v64, s22, 0                           // 000000166BA4: CC210040 02002D40
	v_fma_mixhi_f16 v64, v65, s22, 0                           // 000000166BAC: CC220040 02002D41
	v_fma_mixlo_f16 v65, v66, s22, 0                           // 000000166BB4: CC210041 02002D42
	v_fma_mixhi_f16 v65, v67, s22, 0                           // 000000166BBC: CC220041 02002D43
	s_waitcnt lgkmcnt(5)                                       // 000000166BC4: BF89FC57
	v_fma_mixlo_f16 v70, v70, s22, 0                           // 000000166BC8: CC210046 02002D46
	v_fma_mixhi_f16 v70, v71, s22, 0                           // 000000166BD0: CC220046 02002D47
	v_fma_mixlo_f16 v71, v72, s22, 0                           // 000000166BD8: CC210047 02002D48
	v_fma_mixhi_f16 v71, v73, s22, 0                           // 000000166BE0: CC220047 02002D49
	s_waitcnt lgkmcnt(4)                                       // 000000166BE8: BF89FC47
	v_fma_mixlo_f16 v72, v74, s22, 0                           // 000000166BEC: CC210048 02002D4A
	v_fma_mixhi_f16 v72, v75, s22, 0                           // 000000166BF4: CC220048 02002D4B
	v_fma_mixlo_f16 v73, v76, s22, 0                           // 000000166BFC: CC210049 02002D4C
	v_fma_mixhi_f16 v73, v77, s22, 0                           // 000000166C04: CC220049 02002D4D
	s_waitcnt lgkmcnt(3)                                       // 000000166C0C: BF89FC37
	v_fma_mixlo_f16 v108, v78, s22, 0                          // 000000166C10: CC21006C 02002D4E
	v_fma_mixhi_f16 v108, v79, s22, 0                          // 000000166C18: CC22006C 02002D4F
	v_fma_mixlo_f16 v109, v80, s22, 0                          // 000000166C20: CC21006D 02002D50
	v_fma_mixhi_f16 v109, v81, s22, 0                          // 000000166C28: CC22006D 02002D51
	s_waitcnt lgkmcnt(2)                                       // 000000166C30: BF89FC27
	v_fma_mixlo_f16 v110, v110, s22, 0                         // 000000166C34: CC21006E 02002D6E
	v_fma_mixhi_f16 v110, v111, s22, 0                         // 000000166C3C: CC22006E 02002D6F
	v_fma_mixlo_f16 v111, v112, s22, 0                         // 000000166C44: CC21006F 02002D70
	v_fma_mixhi_f16 v111, v113, s22, 0                         // 000000166C4C: CC22006F 02002D71
	s_waitcnt lgkmcnt(1)                                       // 000000166C54: BF89FC17
	v_fma_mixlo_f16 v116, v116, s22, 0                         // 000000166C58: CC210074 02002D74
	v_fma_mixhi_f16 v116, v117, s22, 0                         // 000000166C60: CC220074 02002D75
	v_fma_mixlo_f16 v117, v118, s22, 0                         // 000000166C68: CC210075 02002D76
	v_fma_mixhi_f16 v117, v119, s22, 0                         // 000000166C70: CC220075 02002D77
	s_waitcnt lgkmcnt(0)                                       // 000000166C78: BF89FC07
	v_fma_mixlo_f16 v118, v50, s22, 0                          // 000000166C7C: CC210076 02002D32
	v_fma_mixhi_f16 v118, v51, s22, 0                          // 000000166C84: CC220076 02002D33
	v_fma_mixlo_f16 v119, v52, s22, 0                          // 000000166C8C: CC210077 02002D34
	v_fma_mixhi_f16 v119, v53, s22, 0                          // 000000166C94: CC220077 02002D35
	v_dual_mov_b32 v66, v62 :: v_dual_mov_b32 v67, v63         // 000000166C9C: CA10013E 4242013F
	v_dual_mov_b32 v68, v64 :: v_dual_mov_b32 v69, v65         // 000000166CA4: CA100140 44440141
	v_dual_mov_b32 v74, v70 :: v_dual_mov_b32 v75, v71         // 000000166CAC: CA100146 4A4A0147
	v_dual_mov_b32 v76, v72 :: v_dual_mov_b32 v77, v73         // 000000166CB4: CA100148 4C4C0149
	v_dual_mov_b32 v112, v108 :: v_dual_mov_b32 v113, v109     // 000000166CBC: CA10016C 7070016D
	v_dual_mov_b32 v114, v110 :: v_dual_mov_b32 v115, v111     // 000000166CC4: CA10016E 7272016F
	v_dual_mov_b32 v120, v116 :: v_dual_mov_b32 v121, v117     // 000000166CCC: CA100174 78780175
	v_dual_mov_b32 v122, v118 :: v_dual_mov_b32 v123, v119     // 000000166CD4: CA100176 7A7A0177
	.long 0x7f6a3880                                           // 000000166CDC: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[54:61], v[62:69], v[42:49]// 000000166CE0: CC40402A 1CAA7D36
	v_wmma_f32_16x16x16_f16 v[34:41], v[54:61], v[70:77], v[34:41]// 000000166CE8: CC404022 1C8A8D36
	v_wmma_f32_16x16x16_f16 v[26:33], v[54:61], v[108:115], v[26:33]// 000000166CF0: CC40401A 1C6AD936
	v_wmma_f32_16x16x16_f16 v[18:25], v[54:61], v[116:123], v[18:25]// 000000166CF8: CC404012 1C4AE936
	.long 0x7f6639b5                                           // 000000166D00: 7F6639B5
	.long 0x7e6639b5                                           // 000000166D04: 7E6639B5
	.long 0x7f6439b5                                           // 000000166D08: 7F6439B5
	.long 0x7e6439b5                                           // 000000166D0C: 7E6439B5
	s_and_saveexec_b32 s1, s0                                  // 000000166D10: BE812000
	s_cbranch_execz 11                                         // 000000166D14: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb44>
	global_load_b128 v[54:57], v[3:4], off offset:128          // 000000166D18: DC5E0080 367C0003
	s_waitcnt vmcnt(0)                                         // 000000166D20: BF8903F7
	v_fma_mixlo_f16 v50, v54, s22, 0                           // 000000166D24: CC210032 02002D36
	v_fma_mixhi_f16 v50, v55, s22, 0                           // 000000166D2C: CC220032 02002D37
	v_fma_mixlo_f16 v51, v56, s22, 0                           // 000000166D34: CC210033 02002D38
	v_fma_mixhi_f16 v51, v57, s22, 0                           // 000000166D3C: CC220033 02002D39
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166D44: 8C7E017E
	.long 0x7e6a39b5                                           // 000000166D48: 7E6A39B5
	.long 0x7f6839b5                                           // 000000166D4C: 7F6839B5
	.long 0x7e6839b5                                           // 000000166D50: 7E6839B5
	s_and_saveexec_b32 s1, s0                                  // 000000166D54: BE812000
	s_cbranch_execz 11                                         // 000000166D58: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb88>
	global_load_b128 v[52:55], v[3:4], off offset:144          // 000000166D5C: DC5E0090 347C0003
	s_waitcnt vmcnt(0)                                         // 000000166D64: BF8903F7
	v_fma_mixlo_f16 v52, v52, s22, 0                           // 000000166D68: CC210034 02002D34
	v_fma_mixhi_f16 v52, v53, s22, 0                           // 000000166D70: CC220034 02002D35
	v_fma_mixlo_f16 v53, v54, s22, 0                           // 000000166D78: CC210035 02002D36
	v_fma_mixhi_f16 v53, v55, s22, 0                           // 000000166D80: CC220035 02002D37
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166D88: 8C7E017E
	.long 0x7f723880                                           // 000000166D8C: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000166D90: BF870001
	.long 0x7f6e39b9                                           // 000000166D94: 7F6E39B9
	.long 0x7e6e39b9                                           // 000000166D98: 7E6E39B9
	.long 0x7f6c39b9                                           // 000000166D9C: 7F6C39B9
	.long 0x7e6c39b9                                           // 000000166DA0: 7E6C39B9
	s_and_saveexec_b32 s1, s0                                  // 000000166DA4: BE812000
	s_cbranch_execz 11                                         // 000000166DA8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xbd8>
	global_load_b128 v[58:61], v[3:4], off offset:160          // 000000166DAC: DC5E00A0 3A7C0003
	s_waitcnt vmcnt(0)                                         // 000000166DB4: BF8903F7
	v_fma_mixlo_f16 v54, v58, s22, 0                           // 000000166DB8: CC210036 02002D3A
	v_fma_mixhi_f16 v54, v59, s22, 0                           // 000000166DC0: CC220036 02002D3B
	v_fma_mixlo_f16 v55, v60, s22, 0                           // 000000166DC8: CC210037 02002D3C
	v_fma_mixhi_f16 v55, v61, s22, 0                           // 000000166DD0: CC220037 02002D3D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166DD8: 8C7E017E
	.long 0x7e7239b9                                           // 000000166DDC: 7E7239B9
	.long 0x7f7039b9                                           // 000000166DE0: 7F7039B9
	.long 0x7e7039b9                                           // 000000166DE4: 7E7039B9
	s_and_saveexec_b32 s1, s0                                  // 000000166DE8: BE812000
	s_cbranch_execz 11                                         // 000000166DEC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc1c>
	global_load_b128 v[56:59], v[3:4], off offset:176          // 000000166DF0: DC5E00B0 387C0003
	s_waitcnt vmcnt(0)                                         // 000000166DF8: BF8903F7
	v_fma_mixlo_f16 v56, v56, s22, 0                           // 000000166DFC: CC210038 02002D38
	v_fma_mixhi_f16 v56, v57, s22, 0                           // 000000166E04: CC220038 02002D39
	v_fma_mixlo_f16 v57, v58, s22, 0                           // 000000166E0C: CC210039 02002D3A
	v_fma_mixhi_f16 v57, v59, s22, 0                           // 000000166E14: CC220039 02002D3B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000166E1C: 8C7E017E
	ds_load_b128 v[59:62], v94 offset:128                      // 000000166E20: DBFC0080 3B00005E
	ds_load_b128 v[63:66], v94 offset:144                      // 000000166E28: DBFC0090 3F00005E
	ds_load_b128 v[67:70], v94 offset:8576                     // 000000166E30: DBFC2180 4300005E
	ds_load_b128 v[71:74], v94 offset:8592                     // 000000166E38: DBFC2190 4700005E
	ds_load_b128 v[75:78], v94 offset:17024                    // 000000166E40: DBFC4280 4B00005E
	ds_load_b128 v[110:113], v94 offset:17040                  // 000000166E48: DBFC4290 6E00005E
	ds_load_b128 v[116:119], v94 offset:25472                  // 000000166E50: DBFC6380 7400005E
	ds_load_b128 v[120:123], v94 offset:25488                  // 000000166E58: DBFC6390 7800005E
	.long 0x7f743880                                           // 000000166E60: 7F743880
	s_waitcnt lgkmcnt(7)                                       // 000000166E64: BF89FC77
	v_fma_mixlo_f16 v59, v59, s22, 0                           // 000000166E68: CC21003B 02002D3B
	v_fma_mixhi_f16 v59, v60, s22, 0                           // 000000166E70: CC22003B 02002D3C
	v_fma_mixlo_f16 v60, v61, s22, 0                           // 000000166E78: CC21003C 02002D3D
	v_fma_mixhi_f16 v60, v62, s22, 0                           // 000000166E80: CC22003C 02002D3E
	s_waitcnt lgkmcnt(6)                                       // 000000166E88: BF89FC67
	v_fma_mixlo_f16 v61, v63, s22, 0                           // 000000166E8C: CC21003D 02002D3F
	v_fma_mixhi_f16 v61, v64, s22, 0                           // 000000166E94: CC22003D 02002D40
	v_fma_mixlo_f16 v62, v65, s22, 0                           // 000000166E9C: CC21003E 02002D41
	v_fma_mixhi_f16 v62, v66, s22, 0                           // 000000166EA4: CC22003E 02002D42
	s_waitcnt lgkmcnt(5)                                       // 000000166EAC: BF89FC57
	v_fma_mixlo_f16 v67, v67, s22, 0                           // 000000166EB0: CC210043 02002D43
	v_fma_mixhi_f16 v67, v68, s22, 0                           // 000000166EB8: CC220043 02002D44
	v_fma_mixlo_f16 v68, v69, s22, 0                           // 000000166EC0: CC210044 02002D45
	v_fma_mixhi_f16 v68, v70, s22, 0                           // 000000166EC8: CC220044 02002D46
	s_waitcnt lgkmcnt(4)                                       // 000000166ED0: BF89FC47
	v_fma_mixlo_f16 v69, v71, s22, 0                           // 000000166ED4: CC210045 02002D47
	v_fma_mixhi_f16 v69, v72, s22, 0                           // 000000166EDC: CC220045 02002D48
	v_fma_mixlo_f16 v70, v73, s22, 0                           // 000000166EE4: CC210046 02002D49
	v_fma_mixhi_f16 v70, v74, s22, 0                           // 000000166EEC: CC220046 02002D4A
	s_waitcnt lgkmcnt(3)                                       // 000000166EF4: BF89FC37
	v_fma_mixlo_f16 v108, v75, s22, 0                          // 000000166EF8: CC21006C 02002D4B
	v_fma_mixhi_f16 v108, v76, s22, 0                          // 000000166F00: CC22006C 02002D4C
	v_fma_mixlo_f16 v109, v77, s22, 0                          // 000000166F08: CC21006D 02002D4D
	v_fma_mixhi_f16 v109, v78, s22, 0                          // 000000166F10: CC22006D 02002D4E
	s_waitcnt lgkmcnt(2)                                       // 000000166F18: BF89FC27
	v_fma_mixlo_f16 v110, v110, s22, 0                         // 000000166F1C: CC21006E 02002D6E
	v_fma_mixhi_f16 v110, v111, s22, 0                         // 000000166F24: CC22006E 02002D6F
	v_fma_mixlo_f16 v111, v112, s22, 0                         // 000000166F2C: CC21006F 02002D70
	v_fma_mixhi_f16 v111, v113, s22, 0                         // 000000166F34: CC22006F 02002D71
	s_waitcnt lgkmcnt(1)                                       // 000000166F3C: BF89FC17
	v_fma_mixlo_f16 v116, v116, s22, 0                         // 000000166F40: CC210074 02002D74
	v_fma_mixhi_f16 v116, v117, s22, 0                         // 000000166F48: CC220074 02002D75
	v_fma_mixlo_f16 v117, v118, s22, 0                         // 000000166F50: CC210075 02002D76
	v_fma_mixhi_f16 v117, v119, s22, 0                         // 000000166F58: CC220075 02002D77
	s_waitcnt lgkmcnt(0)                                       // 000000166F60: BF89FC07
	v_fma_mixlo_f16 v118, v120, s22, 0                         // 000000166F64: CC210076 02002D78
	v_fma_mixhi_f16 v118, v121, s22, 0                         // 000000166F6C: CC220076 02002D79
	v_fma_mixlo_f16 v119, v122, s22, 0                         // 000000166F74: CC210077 02002D7A
	v_fma_mixhi_f16 v119, v123, s22, 0                         // 000000166F7C: CC220077 02002D7B
	v_dual_mov_b32 v63, v59 :: v_dual_mov_b32 v64, v60         // 000000166F84: CA10013B 3F40013C
	v_dual_mov_b32 v65, v61 :: v_dual_mov_b32 v66, v62         // 000000166F8C: CA10013D 4142013E
	v_dual_mov_b32 v71, v67 :: v_dual_mov_b32 v72, v68         // 000000166F94: CA100143 47480144
	v_dual_mov_b32 v73, v69 :: v_dual_mov_b32 v74, v70         // 000000166F9C: CA100145 494A0146
	v_dual_mov_b32 v112, v108 :: v_dual_mov_b32 v113, v109     // 000000166FA4: CA10016C 7070016D
	v_dual_mov_b32 v114, v110 :: v_dual_mov_b32 v115, v111     // 000000166FAC: CA10016E 7272016F
	v_dual_mov_b32 v120, v116 :: v_dual_mov_b32 v121, v117     // 000000166FB4: CA100174 78780175
	v_dual_mov_b32 v122, v118 :: v_dual_mov_b32 v123, v119     // 000000166FBC: CA100176 7A7A0177
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[59:66], v[42:49]// 000000166FC4: CC40402A 1CAA7732
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[67:74], v[34:41]// 000000166FCC: CC404022 1C8A8732
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[108:115], v[26:33]// 000000166FD4: CC40401A 1C6AD932
	s_delay_alu instid0(VALU_DEP_4)                            // 000000166FDC: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[116:123], v[18:25]// 000000166FE0: CC404012 1C4AE932
	.long 0x7f7039ba                                           // 000000166FE8: 7F7039BA
	.long 0x7e7039ba                                           // 000000166FEC: 7E7039BA
	.long 0x7f6e39ba                                           // 000000166FF0: 7F6E39BA
	.long 0x7e6e39ba                                           // 000000166FF4: 7E6E39BA
	s_and_saveexec_b32 s1, s0                                  // 000000166FF8: BE812000
	s_cbranch_execz 11                                         // 000000166FFC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe2c>
	global_load_b128 v[50:53], v[3:4], off offset:192          // 000000167000: DC5E00C0 327C0003
	s_waitcnt vmcnt(0)                                         // 000000167008: BF8903F7
	v_fma_mixlo_f16 v55, v50, s22, 0                           // 00000016700C: CC210037 02002D32
	v_fma_mixhi_f16 v55, v51, s22, 0                           // 000000167014: CC220037 02002D33
	v_fma_mixlo_f16 v56, v52, s22, 0                           // 00000016701C: CC210038 02002D34
	v_fma_mixhi_f16 v56, v53, s22, 0                           // 000000167024: CC220038 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 00000016702C: 8C7E017E
	.long 0x7e7439ba                                           // 000000167030: 7E7439BA
	.long 0x7f7239ba                                           // 000000167034: 7F7239BA
	.long 0x7e7239ba                                           // 000000167038: 7E7239BA
	s_and_saveexec_b32 s1, s0                                  // 00000016703C: BE812000
	s_cbranch_execz 11                                         // 000000167040: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe70>
	global_load_b128 v[50:53], v[3:4], off offset:208          // 000000167044: DC5E00D0 327C0003
	s_waitcnt vmcnt(0)                                         // 00000016704C: BF8903F7
	v_fma_mixlo_f16 v57, v50, s22, 0                           // 000000167050: CC210039 02002D32
	v_fma_mixhi_f16 v57, v51, s22, 0                           // 000000167058: CC220039 02002D33
	v_fma_mixlo_f16 v58, v52, s22, 0                           // 000000167060: CC21003A 02002D34
	v_fma_mixhi_f16 v58, v53, s22, 0                           // 000000167068: CC22003A 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 000000167070: 8C7E017E
	.long 0x7f7c3880                                           // 000000167074: 7F7C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000167078: BF870001
	.long 0x7f7839be                                           // 00000016707C: 7F7839BE
	.long 0x7e7839be                                           // 000000167080: 7E7839BE
	.long 0x7f7639be                                           // 000000167084: 7F7639BE
	.long 0x7e7639be                                           // 000000167088: 7E7639BE
	s_and_saveexec_b32 s1, s0                                  // 00000016708C: BE812000
	s_cbranch_execz 11                                         // 000000167090: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xec0>
	global_load_b128 v[50:53], v[3:4], off offset:224          // 000000167094: DC5E00E0 327C0003
	s_waitcnt vmcnt(0)                                         // 00000016709C: BF8903F7
	v_fma_mixlo_f16 v59, v50, s22, 0                           // 0000001670A0: CC21003B 02002D32
	v_fma_mixhi_f16 v59, v51, s22, 0                           // 0000001670A8: CC22003B 02002D33
	v_fma_mixlo_f16 v60, v52, s22, 0                           // 0000001670B0: CC21003C 02002D34
	v_fma_mixhi_f16 v60, v53, s22, 0                           // 0000001670B8: CC22003C 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001670C0: 8C7E017E
	.long 0x7e7c39be                                           // 0000001670C4: 7E7C39BE
	.long 0x7f7a39be                                           // 0000001670C8: 7F7A39BE
	.long 0x7e7a39be                                           // 0000001670CC: 7E7A39BE
	s_and_saveexec_b32 s1, s0                                  // 0000001670D0: BE812000
	s_cbranch_execz 11                                         // 0000001670D4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xf04>
	global_load_b128 v[50:53], v[3:4], off offset:240          // 0000001670D8: DC5E00F0 327C0003
	s_waitcnt vmcnt(0)                                         // 0000001670E0: BF8903F7
	v_fma_mixlo_f16 v61, v50, s22, 0                           // 0000001670E4: CC21003D 02002D32
	v_fma_mixhi_f16 v61, v51, s22, 0                           // 0000001670EC: CC22003D 02002D33
	v_fma_mixlo_f16 v62, v52, s22, 0                           // 0000001670F4: CC21003E 02002D34
	v_fma_mixhi_f16 v62, v53, s22, 0                           // 0000001670FC: CC22003E 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 000000167104: 8C7E017E
	ds_load_b128 v[50:53], v94 offset:192                      // 000000167108: DBFC00C0 3200005E
	ds_load_b128 v[65:68], v94 offset:208                      // 000000167110: DBFC00D0 4100005E
	ds_load_b128 v[71:74], v94 offset:8640                     // 000000167118: DBFC21C0 4700005E
	ds_load_b128 v[75:78], v94 offset:8656                     // 000000167120: DBFC21D0 4B00005E
	ds_load_b128 v[108:111], v94 offset:17088                  // 000000167128: DBFC42C0 6C00005E
	ds_load_b128 v[112:115], v94 offset:17104                  // 000000167130: DBFC42D0 7000005E
	ds_load_b128 v[116:119], v94 offset:25536                  // 000000167138: DBFC63C0 7400005E
	s_waitcnt lgkmcnt(6)                                       // 000000167140: BF89FC67
	v_fma_mixlo_f16 v63, v50, s22, 0                           // 000000167144: CC21003F 02002D32
	v_fma_mixhi_f16 v63, v51, s22, 0                           // 00000016714C: CC22003F 02002D33
	v_fma_mixlo_f16 v64, v52, s22, 0                           // 000000167154: CC210040 02002D34
	v_fma_mixhi_f16 v64, v53, s22, 0                           // 00000016715C: CC220040 02002D35
	ds_load_b128 v[50:53], v94 offset:25552                    // 000000167164: DBFC63D0 3200005E
	s_waitcnt lgkmcnt(6)                                       // 00000016716C: BF89FC67
	v_fma_mixlo_f16 v65, v65, s22, 0                           // 000000167170: CC210041 02002D41
	v_fma_mixhi_f16 v65, v66, s22, 0                           // 000000167178: CC220041 02002D42
	v_fma_mixlo_f16 v66, v67, s22, 0                           // 000000167180: CC210042 02002D43
	v_fma_mixhi_f16 v66, v68, s22, 0                           // 000000167188: CC220042 02002D44
	s_waitcnt lgkmcnt(5)                                       // 000000167190: BF89FC57
	v_fma_mixlo_f16 v71, v71, s22, 0                           // 000000167194: CC210047 02002D47
	v_fma_mixhi_f16 v71, v72, s22, 0                           // 00000016719C: CC220047 02002D48
	v_fma_mixlo_f16 v72, v73, s22, 0                           // 0000001671A4: CC210048 02002D49
	v_fma_mixhi_f16 v72, v74, s22, 0                           // 0000001671AC: CC220048 02002D4A
	s_waitcnt lgkmcnt(4)                                       // 0000001671B4: BF89FC47
	v_fma_mixlo_f16 v73, v75, s22, 0                           // 0000001671B8: CC210049 02002D4B
	v_fma_mixhi_f16 v73, v76, s22, 0                           // 0000001671C0: CC220049 02002D4C
	v_fma_mixlo_f16 v74, v77, s22, 0                           // 0000001671C8: CC21004A 02002D4D
	v_fma_mixhi_f16 v74, v78, s22, 0                           // 0000001671D0: CC22004A 02002D4E
	s_waitcnt lgkmcnt(3)                                       // 0000001671D8: BF89FC37
	v_fma_mixlo_f16 v108, v108, s22, 0                         // 0000001671DC: CC21006C 02002D6C
	v_fma_mixhi_f16 v108, v109, s22, 0                         // 0000001671E4: CC22006C 02002D6D
	v_fma_mixlo_f16 v109, v110, s22, 0                         // 0000001671EC: CC21006D 02002D6E
	v_fma_mixhi_f16 v109, v111, s22, 0                         // 0000001671F4: CC22006D 02002D6F
	s_waitcnt lgkmcnt(2)                                       // 0000001671FC: BF89FC27
	v_fma_mixlo_f16 v110, v112, s22, 0                         // 000000167200: CC21006E 02002D70
	v_fma_mixhi_f16 v110, v113, s22, 0                         // 000000167208: CC22006E 02002D71
	v_fma_mixlo_f16 v111, v114, s22, 0                         // 000000167210: CC21006F 02002D72
	v_fma_mixhi_f16 v111, v115, s22, 0                         // 000000167218: CC22006F 02002D73
	s_waitcnt lgkmcnt(1)                                       // 000000167220: BF89FC17
	v_fma_mixlo_f16 v116, v116, s22, 0                         // 000000167224: CC210074 02002D74
	v_fma_mixhi_f16 v116, v117, s22, 0                         // 00000016722C: CC220074 02002D75
	v_fma_mixlo_f16 v117, v118, s22, 0                         // 000000167234: CC210075 02002D76
	v_fma_mixhi_f16 v117, v119, s22, 0                         // 00000016723C: CC220075 02002D77
	s_waitcnt lgkmcnt(0)                                       // 000000167244: BF89FC07
	v_fma_mixlo_f16 v118, v50, s22, 0                          // 000000167248: CC210076 02002D32
	v_fma_mixhi_f16 v118, v51, s22, 0                          // 000000167250: CC220076 02002D33
	v_fma_mixlo_f16 v119, v52, s22, 0                          // 000000167258: CC210077 02002D34
	v_fma_mixhi_f16 v119, v53, s22, 0                          // 000000167260: CC220077 02002D35
	v_dual_mov_b32 v67, v63 :: v_dual_mov_b32 v68, v64         // 000000167268: CA10013F 43440140
	v_dual_mov_b32 v69, v65 :: v_dual_mov_b32 v70, v66         // 000000167270: CA100141 45460142
	v_dual_mov_b32 v75, v71 :: v_dual_mov_b32 v76, v72         // 000000167278: CA100147 4B4C0148
	v_dual_mov_b32 v77, v73 :: v_dual_mov_b32 v78, v74         // 000000167280: CA100149 4D4E014A
	v_dual_mov_b32 v112, v108 :: v_dual_mov_b32 v113, v109     // 000000167288: CA10016C 7070016D
	v_dual_mov_b32 v114, v110 :: v_dual_mov_b32 v115, v111     // 000000167290: CA10016E 7272016F
	v_dual_mov_b32 v120, v116 :: v_dual_mov_b32 v121, v117     // 000000167298: CA100174 78780175
	v_dual_mov_b32 v122, v118 :: v_dual_mov_b32 v123, v119     // 0000001672A0: CA100176 7A7A0177
	.long 0x7f6a3880                                           // 0000001672A8: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[55:62], v[63:70], v[42:49]// 0000001672AC: CC40402A 1CAA7F37
	v_wmma_f32_16x16x16_f16 v[34:41], v[55:62], v[71:78], v[34:41]// 0000001672B4: CC404022 1C8A8F37
	v_wmma_f32_16x16x16_f16 v[26:33], v[55:62], v[108:115], v[26:33]// 0000001672BC: CC40401A 1C6AD937
	v_wmma_f32_16x16x16_f16 v[18:25], v[55:62], v[116:123], v[18:25]// 0000001672C4: CC404012 1C4AE937
	.long 0x7f6639b5                                           // 0000001672CC: 7F6639B5
	.long 0x7e6639b5                                           // 0000001672D0: 7E6639B5
	.long 0x7f6439b5                                           // 0000001672D4: 7F6439B5
	.long 0x7e6439b5                                           // 0000001672D8: 7E6439B5
	s_and_saveexec_b32 s1, s0                                  // 0000001672DC: BE812000
	s_cbranch_execz 11                                         // 0000001672E0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1110>
	global_load_b128 v[54:57], v[3:4], off offset:256          // 0000001672E4: DC5E0100 367C0003
	s_waitcnt vmcnt(0)                                         // 0000001672EC: BF8903F7
	v_fma_mixlo_f16 v50, v54, s22, 0                           // 0000001672F0: CC210032 02002D36
	v_fma_mixhi_f16 v50, v55, s22, 0                           // 0000001672F8: CC220032 02002D37
	v_fma_mixlo_f16 v51, v56, s22, 0                           // 000000167300: CC210033 02002D38
	v_fma_mixhi_f16 v51, v57, s22, 0                           // 000000167308: CC220033 02002D39
	s_or_b32 exec_lo, exec_lo, s1                              // 000000167310: 8C7E017E
	.long 0x7e6a39b5                                           // 000000167314: 7E6A39B5
	.long 0x7f6839b5                                           // 000000167318: 7F6839B5
	.long 0x7e6839b5                                           // 00000016731C: 7E6839B5
	s_and_saveexec_b32 s1, s0                                  // 000000167320: BE812000
	s_cbranch_execz 11                                         // 000000167324: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1154>
	global_load_b128 v[52:55], v[3:4], off offset:272          // 000000167328: DC5E0110 347C0003
	s_waitcnt vmcnt(0)                                         // 000000167330: BF8903F7
	v_fma_mixlo_f16 v52, v52, s22, 0                           // 000000167334: CC210034 02002D34
	v_fma_mixhi_f16 v52, v53, s22, 0                           // 00000016733C: CC220034 02002D35
	v_fma_mixlo_f16 v53, v54, s22, 0                           // 000000167344: CC210035 02002D36
	v_fma_mixhi_f16 v53, v55, s22, 0                           // 00000016734C: CC220035 02002D37
	s_or_b32 exec_lo, exec_lo, s1                              // 000000167354: 8C7E017E
	.long 0x7f723880                                           // 000000167358: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016735C: BF870001
	.long 0x7f6e39b9                                           // 000000167360: 7F6E39B9
	.long 0x7e6e39b9                                           // 000000167364: 7E6E39B9
	.long 0x7f6c39b9                                           // 000000167368: 7F6C39B9
	.long 0x7e6c39b9                                           // 00000016736C: 7E6C39B9
	s_and_saveexec_b32 s1, s0                                  // 000000167370: BE812000
	s_cbranch_execz 11                                         // 000000167374: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11a4>
	global_load_b128 v[58:61], v[3:4], off offset:288          // 000000167378: DC5E0120 3A7C0003
	s_waitcnt vmcnt(0)                                         // 000000167380: BF8903F7
	v_fma_mixlo_f16 v54, v58, s22, 0                           // 000000167384: CC210036 02002D3A
	v_fma_mixhi_f16 v54, v59, s22, 0                           // 00000016738C: CC220036 02002D3B
	v_fma_mixlo_f16 v55, v60, s22, 0                           // 000000167394: CC210037 02002D3C
	v_fma_mixhi_f16 v55, v61, s22, 0                           // 00000016739C: CC220037 02002D3D
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001673A4: 8C7E017E
	.long 0x7e7239b9                                           // 0000001673A8: 7E7239B9
	.long 0x7f7039b9                                           // 0000001673AC: 7F7039B9
	.long 0x7e7039b9                                           // 0000001673B0: 7E7039B9
	s_and_saveexec_b32 s1, s0                                  // 0000001673B4: BE812000
	s_cbranch_execz 11                                         // 0000001673B8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11e8>
	global_load_b128 v[56:59], v[3:4], off offset:304          // 0000001673BC: DC5E0130 387C0003
	s_waitcnt vmcnt(0)                                         // 0000001673C4: BF8903F7
	v_fma_mixlo_f16 v56, v56, s22, 0                           // 0000001673C8: CC210038 02002D38
	v_fma_mixhi_f16 v56, v57, s22, 0                           // 0000001673D0: CC220038 02002D39
	v_fma_mixlo_f16 v57, v58, s22, 0                           // 0000001673D8: CC210039 02002D3A
	v_fma_mixhi_f16 v57, v59, s22, 0                           // 0000001673E0: CC220039 02002D3B
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001673E8: 8C7E017E
	ds_load_b128 v[59:62], v94 offset:256                      // 0000001673EC: DBFC0100 3B00005E
	ds_load_b128 v[63:66], v94 offset:272                      // 0000001673F4: DBFC0110 3F00005E
	ds_load_b128 v[67:70], v94 offset:8704                     // 0000001673FC: DBFC2200 4300005E
	ds_load_b128 v[71:74], v94 offset:8720                     // 000000167404: DBFC2210 4700005E
	ds_load_b128 v[75:78], v94 offset:17152                    // 00000016740C: DBFC4300 4B00005E
	ds_load_b128 v[110:113], v94 offset:17168                  // 000000167414: DBFC4310 6E00005E
	ds_load_b128 v[116:119], v94 offset:25600                  // 00000016741C: DBFC6400 7400005E
	ds_load_b128 v[120:123], v94 offset:25616                  // 000000167424: DBFC6410 7800005E
	.long 0x7f743880                                           // 00000016742C: 7F743880
	s_waitcnt lgkmcnt(7)                                       // 000000167430: BF89FC77
	v_fma_mixlo_f16 v59, v59, s22, 0                           // 000000167434: CC21003B 02002D3B
	v_fma_mixhi_f16 v59, v60, s22, 0                           // 00000016743C: CC22003B 02002D3C
	v_fma_mixlo_f16 v60, v61, s22, 0                           // 000000167444: CC21003C 02002D3D
	v_fma_mixhi_f16 v60, v62, s22, 0                           // 00000016744C: CC22003C 02002D3E
	s_waitcnt lgkmcnt(6)                                       // 000000167454: BF89FC67
	v_fma_mixlo_f16 v61, v63, s22, 0                           // 000000167458: CC21003D 02002D3F
	v_fma_mixhi_f16 v61, v64, s22, 0                           // 000000167460: CC22003D 02002D40
	v_fma_mixlo_f16 v62, v65, s22, 0                           // 000000167468: CC21003E 02002D41
	v_fma_mixhi_f16 v62, v66, s22, 0                           // 000000167470: CC22003E 02002D42
	s_waitcnt lgkmcnt(5)                                       // 000000167478: BF89FC57
	v_fma_mixlo_f16 v67, v67, s22, 0                           // 00000016747C: CC210043 02002D43
	v_fma_mixhi_f16 v67, v68, s22, 0                           // 000000167484: CC220043 02002D44
	v_fma_mixlo_f16 v68, v69, s22, 0                           // 00000016748C: CC210044 02002D45
	v_fma_mixhi_f16 v68, v70, s22, 0                           // 000000167494: CC220044 02002D46
	s_waitcnt lgkmcnt(4)                                       // 00000016749C: BF89FC47
	v_fma_mixlo_f16 v69, v71, s22, 0                           // 0000001674A0: CC210045 02002D47
	v_fma_mixhi_f16 v69, v72, s22, 0                           // 0000001674A8: CC220045 02002D48
	v_fma_mixlo_f16 v70, v73, s22, 0                           // 0000001674B0: CC210046 02002D49
	v_fma_mixhi_f16 v70, v74, s22, 0                           // 0000001674B8: CC220046 02002D4A
	s_waitcnt lgkmcnt(3)                                       // 0000001674C0: BF89FC37
	v_fma_mixlo_f16 v108, v75, s22, 0                          // 0000001674C4: CC21006C 02002D4B
	v_fma_mixhi_f16 v108, v76, s22, 0                          // 0000001674CC: CC22006C 02002D4C
	v_fma_mixlo_f16 v109, v77, s22, 0                          // 0000001674D4: CC21006D 02002D4D
	v_fma_mixhi_f16 v109, v78, s22, 0                          // 0000001674DC: CC22006D 02002D4E
	s_waitcnt lgkmcnt(2)                                       // 0000001674E4: BF89FC27
	v_fma_mixlo_f16 v110, v110, s22, 0                         // 0000001674E8: CC21006E 02002D6E
	v_fma_mixhi_f16 v110, v111, s22, 0                         // 0000001674F0: CC22006E 02002D6F
	v_fma_mixlo_f16 v111, v112, s22, 0                         // 0000001674F8: CC21006F 02002D70
	v_fma_mixhi_f16 v111, v113, s22, 0                         // 000000167500: CC22006F 02002D71
	s_waitcnt lgkmcnt(1)                                       // 000000167508: BF89FC17
	v_fma_mixlo_f16 v116, v116, s22, 0                         // 00000016750C: CC210074 02002D74
	v_fma_mixhi_f16 v116, v117, s22, 0                         // 000000167514: CC220074 02002D75
	v_fma_mixlo_f16 v117, v118, s22, 0                         // 00000016751C: CC210075 02002D76
	v_fma_mixhi_f16 v117, v119, s22, 0                         // 000000167524: CC220075 02002D77
	s_waitcnt lgkmcnt(0)                                       // 00000016752C: BF89FC07
	v_fma_mixlo_f16 v118, v120, s22, 0                         // 000000167530: CC210076 02002D78
	v_fma_mixhi_f16 v118, v121, s22, 0                         // 000000167538: CC220076 02002D79
	v_fma_mixlo_f16 v119, v122, s22, 0                         // 000000167540: CC210077 02002D7A
	v_fma_mixhi_f16 v119, v123, s22, 0                         // 000000167548: CC220077 02002D7B
	v_dual_mov_b32 v63, v59 :: v_dual_mov_b32 v64, v60         // 000000167550: CA10013B 3F40013C
	v_dual_mov_b32 v65, v61 :: v_dual_mov_b32 v66, v62         // 000000167558: CA10013D 4142013E
	v_dual_mov_b32 v71, v67 :: v_dual_mov_b32 v72, v68         // 000000167560: CA100143 47480144
	v_dual_mov_b32 v73, v69 :: v_dual_mov_b32 v74, v70         // 000000167568: CA100145 494A0146
	v_dual_mov_b32 v112, v108 :: v_dual_mov_b32 v113, v109     // 000000167570: CA10016C 7070016D
	v_dual_mov_b32 v114, v110 :: v_dual_mov_b32 v115, v111     // 000000167578: CA10016E 7272016F
	v_dual_mov_b32 v120, v116 :: v_dual_mov_b32 v121, v117     // 000000167580: CA100174 78780175
	v_dual_mov_b32 v122, v118 :: v_dual_mov_b32 v123, v119     // 000000167588: CA100176 7A7A0177
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[59:66], v[42:49]// 000000167590: CC40402A 1CAA7732
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[67:74], v[34:41]// 000000167598: CC404022 1C8A8732
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[108:115], v[26:33]// 0000001675A0: CC40401A 1C6AD932
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001675A8: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[116:123], v[18:25]// 0000001675AC: CC404012 1C4AE932
	.long 0x7f7039ba                                           // 0000001675B4: 7F7039BA
	.long 0x7e7039ba                                           // 0000001675B8: 7E7039BA
	.long 0x7f6e39ba                                           // 0000001675BC: 7F6E39BA
	.long 0x7e6e39ba                                           // 0000001675C0: 7E6E39BA
	s_and_saveexec_b32 s1, s0                                  // 0000001675C4: BE812000
	s_cbranch_execz 11                                         // 0000001675C8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13f8>
	global_load_b128 v[50:53], v[3:4], off offset:320          // 0000001675CC: DC5E0140 327C0003
	s_waitcnt vmcnt(0)                                         // 0000001675D4: BF8903F7
	v_fma_mixlo_f16 v55, v50, s22, 0                           // 0000001675D8: CC210037 02002D32
	v_fma_mixhi_f16 v55, v51, s22, 0                           // 0000001675E0: CC220037 02002D33
	v_fma_mixlo_f16 v56, v52, s22, 0                           // 0000001675E8: CC210038 02002D34
	v_fma_mixhi_f16 v56, v53, s22, 0                           // 0000001675F0: CC220038 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001675F8: 8C7E017E
	.long 0x7e7439ba                                           // 0000001675FC: 7E7439BA
	.long 0x7f7239ba                                           // 000000167600: 7F7239BA
	.long 0x7e7239ba                                           // 000000167604: 7E7239BA
	s_and_saveexec_b32 s1, s0                                  // 000000167608: BE812000
	s_cbranch_execz 11                                         // 00000016760C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x143c>
	global_load_b128 v[50:53], v[3:4], off offset:336          // 000000167610: DC5E0150 327C0003
	s_waitcnt vmcnt(0)                                         // 000000167618: BF8903F7
	v_fma_mixlo_f16 v57, v50, s22, 0                           // 00000016761C: CC210039 02002D32
	v_fma_mixhi_f16 v57, v51, s22, 0                           // 000000167624: CC220039 02002D33
	v_fma_mixlo_f16 v58, v52, s22, 0                           // 00000016762C: CC21003A 02002D34
	v_fma_mixhi_f16 v58, v53, s22, 0                           // 000000167634: CC22003A 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 00000016763C: 8C7E017E
	.long 0x7f7c3880                                           // 000000167640: 7F7C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000167644: BF870001
	.long 0x7f7839be                                           // 000000167648: 7F7839BE
	.long 0x7e7839be                                           // 00000016764C: 7E7839BE
	.long 0x7f7639be                                           // 000000167650: 7F7639BE
	.long 0x7e7639be                                           // 000000167654: 7E7639BE
	s_and_saveexec_b32 s1, s0                                  // 000000167658: BE812000
	s_cbranch_execz 11                                         // 00000016765C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x148c>
	global_load_b128 v[50:53], v[3:4], off offset:352          // 000000167660: DC5E0160 327C0003
	s_waitcnt vmcnt(0)                                         // 000000167668: BF8903F7
	v_fma_mixlo_f16 v59, v50, s22, 0                           // 00000016766C: CC21003B 02002D32
	v_fma_mixhi_f16 v59, v51, s22, 0                           // 000000167674: CC22003B 02002D33
	v_fma_mixlo_f16 v60, v52, s22, 0                           // 00000016767C: CC21003C 02002D34
	v_fma_mixhi_f16 v60, v53, s22, 0                           // 000000167684: CC22003C 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 00000016768C: 8C7E017E
	.long 0x7e7c39be                                           // 000000167690: 7E7C39BE
	.long 0x7f7a39be                                           // 000000167694: 7F7A39BE
	.long 0x7e7a39be                                           // 000000167698: 7E7A39BE
	s_and_saveexec_b32 s1, s0                                  // 00000016769C: BE812000
	s_cbranch_execz 11                                         // 0000001676A0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14d0>
	global_load_b128 v[50:53], v[3:4], off offset:368          // 0000001676A4: DC5E0170 327C0003
	s_waitcnt vmcnt(0)                                         // 0000001676AC: BF8903F7
	v_fma_mixlo_f16 v61, v50, s22, 0                           // 0000001676B0: CC21003D 02002D32
	v_fma_mixhi_f16 v61, v51, s22, 0                           // 0000001676B8: CC22003D 02002D33
	v_fma_mixlo_f16 v62, v52, s22, 0                           // 0000001676C0: CC21003E 02002D34
	v_fma_mixhi_f16 v62, v53, s22, 0                           // 0000001676C8: CC22003E 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001676D0: 8C7E017E
	ds_load_b128 v[50:53], v94 offset:320                      // 0000001676D4: DBFC0140 3200005E
	ds_load_b128 v[66:69], v94 offset:336                      // 0000001676DC: DBFC0150 4200005E
	ds_load_b128 v[72:75], v94 offset:8768                     // 0000001676E4: DBFC2240 4800005E
	ds_load_b128 v[76:79], v94 offset:8784                     // 0000001676EC: DBFC2250 4C00005E
	ds_load_b128 v[108:111], v94 offset:17216                  // 0000001676F4: DBFC4340 6C00005E
	ds_load_b128 v[112:115], v94 offset:17232                  // 0000001676FC: DBFC4350 7000005E
	ds_load_b128 v[116:119], v94 offset:25664                  // 000000167704: DBFC6440 7400005E
	.long 0x7f7e3880                                           // 00000016770C: 7F7E3880
	s_waitcnt lgkmcnt(6)                                       // 000000167710: BF89FC67
	v_fma_mixlo_f16 v64, v50, s22, 0                           // 000000167714: CC210040 02002D32
	v_fma_mixhi_f16 v64, v51, s22, 0                           // 00000016771C: CC220040 02002D33
	v_fma_mixlo_f16 v65, v52, s22, 0                           // 000000167724: CC210041 02002D34
	v_fma_mixhi_f16 v65, v53, s22, 0                           // 00000016772C: CC220041 02002D35
	ds_load_b128 v[50:53], v94 offset:25680                    // 000000167734: DBFC6450 3200005E
	s_waitcnt lgkmcnt(6)                                       // 00000016773C: BF89FC67
	v_fma_mixlo_f16 v66, v66, s22, 0                           // 000000167740: CC210042 02002D42
	v_fma_mixhi_f16 v66, v67, s22, 0                           // 000000167748: CC220042 02002D43
	v_fma_mixlo_f16 v67, v68, s22, 0                           // 000000167750: CC210043 02002D44
	v_fma_mixhi_f16 v67, v69, s22, 0                           // 000000167758: CC220043 02002D45
	s_waitcnt lgkmcnt(5)                                       // 000000167760: BF89FC57
	v_fma_mixlo_f16 v72, v72, s22, 0                           // 000000167764: CC210048 02002D48
	v_fma_mixhi_f16 v72, v73, s22, 0                           // 00000016776C: CC220048 02002D49
	v_fma_mixlo_f16 v73, v74, s22, 0                           // 000000167774: CC210049 02002D4A
	v_fma_mixhi_f16 v73, v75, s22, 0                           // 00000016777C: CC220049 02002D4B
	s_waitcnt lgkmcnt(4)                                       // 000000167784: BF89FC47
	v_fma_mixlo_f16 v74, v76, s22, 0                           // 000000167788: CC21004A 02002D4C
	v_fma_mixhi_f16 v74, v77, s22, 0                           // 000000167790: CC22004A 02002D4D
	v_fma_mixlo_f16 v75, v78, s22, 0                           // 000000167798: CC21004B 02002D4E
	v_fma_mixhi_f16 v75, v79, s22, 0                           // 0000001677A0: CC22004B 02002D4F
	s_waitcnt lgkmcnt(3)                                       // 0000001677A8: BF89FC37
	v_fma_mixlo_f16 v108, v108, s22, 0                         // 0000001677AC: CC21006C 02002D6C
	v_fma_mixhi_f16 v108, v109, s22, 0                         // 0000001677B4: CC22006C 02002D6D
	v_fma_mixlo_f16 v109, v110, s22, 0                         // 0000001677BC: CC21006D 02002D6E
	v_fma_mixhi_f16 v109, v111, s22, 0                         // 0000001677C4: CC22006D 02002D6F
	s_waitcnt lgkmcnt(2)                                       // 0000001677CC: BF89FC27
	v_fma_mixlo_f16 v110, v112, s22, 0                         // 0000001677D0: CC21006E 02002D70
	v_fma_mixhi_f16 v110, v113, s22, 0                         // 0000001677D8: CC22006E 02002D71
	v_fma_mixlo_f16 v111, v114, s22, 0                         // 0000001677E0: CC21006F 02002D72
	v_fma_mixhi_f16 v111, v115, s22, 0                         // 0000001677E8: CC22006F 02002D73
	s_waitcnt lgkmcnt(1)                                       // 0000001677F0: BF89FC17
	v_fma_mixlo_f16 v116, v116, s22, 0                         // 0000001677F4: CC210074 02002D74
	v_fma_mixhi_f16 v116, v117, s22, 0                         // 0000001677FC: CC220074 02002D75
	v_fma_mixlo_f16 v117, v118, s22, 0                         // 000000167804: CC210075 02002D76
	v_fma_mixhi_f16 v117, v119, s22, 0                         // 00000016780C: CC220075 02002D77
	s_waitcnt lgkmcnt(0)                                       // 000000167814: BF89FC07
	v_fma_mixlo_f16 v118, v50, s22, 0                          // 000000167818: CC210076 02002D32
	v_fma_mixhi_f16 v118, v51, s22, 0                          // 000000167820: CC220076 02002D33
	v_fma_mixlo_f16 v119, v52, s22, 0                          // 000000167828: CC210077 02002D34
	v_fma_mixhi_f16 v119, v53, s22, 0                          // 000000167830: CC220077 02002D35
	v_dual_mov_b32 v68, v64 :: v_dual_mov_b32 v69, v65         // 000000167838: CA100140 44440141
	v_dual_mov_b32 v70, v66 :: v_dual_mov_b32 v71, v67         // 000000167840: CA100142 46460143
	v_dual_mov_b32 v76, v72 :: v_dual_mov_b32 v77, v73         // 000000167848: CA100148 4C4C0149
	v_dual_mov_b32 v78, v74 :: v_dual_mov_b32 v79, v75         // 000000167850: CA10014A 4E4E014B
	v_dual_mov_b32 v112, v108 :: v_dual_mov_b32 v113, v109     // 000000167858: CA10016C 7070016D
	v_dual_mov_b32 v114, v110 :: v_dual_mov_b32 v115, v111     // 000000167860: CA10016E 7272016F
	v_dual_mov_b32 v120, v116 :: v_dual_mov_b32 v121, v117     // 000000167868: CA100174 78780175
	v_dual_mov_b32 v122, v118 :: v_dual_mov_b32 v123, v119     // 000000167870: CA100176 7A7A0177
	v_wmma_f32_16x16x16_f16 v[42:49], v[55:62], v[64:71], v[42:49]// 000000167878: CC40402A 1CAA8137
	v_wmma_f32_16x16x16_f16 v[34:41], v[55:62], v[72:79], v[34:41]// 000000167880: CC404022 1C8A9137
	v_wmma_f32_16x16x16_f16 v[26:33], v[55:62], v[108:115], v[26:33]// 000000167888: CC40401A 1C6AD937
	s_delay_alu instid0(VALU_DEP_4)                            // 000000167890: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[55:62], v[116:123], v[18:25]// 000000167894: CC404012 1C4AE937
	.long 0x7f7a39bf                                           // 00000016789C: 7F7A39BF
	.long 0x7e7a39bf                                           // 0000001678A0: 7E7A39BF
	.long 0x7f7839bf                                           // 0000001678A4: 7F7839BF
	.long 0x7e7839bf                                           // 0000001678A8: 7E7839BF
	s_and_saveexec_b32 s1, s0                                  // 0000001678AC: BE812000
	s_cbranch_execz 11                                         // 0000001678B0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16e0>
	global_load_b128 v[50:53], v[3:4], off offset:384          // 0000001678B4: DC5E0180 327C0003
	s_waitcnt vmcnt(0)                                         // 0000001678BC: BF8903F7
	v_fma_mixlo_f16 v60, v50, s22, 0                           // 0000001678C0: CC21003C 02002D32
	v_fma_mixhi_f16 v60, v51, s22, 0                           // 0000001678C8: CC22003C 02002D33
	v_fma_mixlo_f16 v61, v52, s22, 0                           // 0000001678D0: CC21003D 02002D34
	v_fma_mixhi_f16 v61, v53, s22, 0                           // 0000001678D8: CC22003D 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001678E0: 8C7E017E
	.long 0x7e7e39bf                                           // 0000001678E4: 7E7E39BF
	.long 0x7f7c39bf                                           // 0000001678E8: 7F7C39BF
	.long 0x7e7c39bf                                           // 0000001678EC: 7E7C39BF
	s_and_saveexec_b32 s1, s0                                  // 0000001678F0: BE812000
	s_cbranch_execz 11                                         // 0000001678F4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1724>
	global_load_b128 v[50:53], v[3:4], off offset:400          // 0000001678F8: DC5E0190 327C0003
	s_waitcnt vmcnt(0)                                         // 000000167900: BF8903F7
	v_fma_mixlo_f16 v62, v50, s22, 0                           // 000000167904: CC21003E 02002D32
	v_fma_mixhi_f16 v62, v51, s22, 0                           // 00000016790C: CC22003E 02002D33
	v_fma_mixlo_f16 v63, v52, s22, 0                           // 000000167914: CC21003F 02002D34
	v_fma_mixhi_f16 v63, v53, s22, 0                           // 00000016791C: CC22003F 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 000000167924: 8C7E017E
	.long 0x7f863880                                           // 000000167928: 7F863880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016792C: BF870001
	.long 0x7f8239c3                                           // 000000167930: 7F8239C3
	.long 0x7e8239c3                                           // 000000167934: 7E8239C3
	.long 0x7f8039c3                                           // 000000167938: 7F8039C3
	.long 0x7e8039c3                                           // 00000016793C: 7E8039C3
	s_and_saveexec_b32 s1, s0                                  // 000000167940: BE812000
	s_cbranch_execz 11                                         // 000000167944: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1774>
	global_load_b128 v[50:53], v[3:4], off offset:416          // 000000167948: DC5E01A0 327C0003
	s_waitcnt vmcnt(0)                                         // 000000167950: BF8903F7
	v_fma_mixlo_f16 v64, v50, s22, 0                           // 000000167954: CC210040 02002D32
	v_fma_mixhi_f16 v64, v51, s22, 0                           // 00000016795C: CC220040 02002D33
	v_fma_mixlo_f16 v65, v52, s22, 0                           // 000000167964: CC210041 02002D34
	v_fma_mixhi_f16 v65, v53, s22, 0                           // 00000016796C: CC220041 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 000000167974: 8C7E017E
	.long 0x7e8639c3                                           // 000000167978: 7E8639C3
	.long 0x7f8439c3                                           // 00000016797C: 7F8439C3
	.long 0x7e8439c3                                           // 000000167980: 7E8439C3
	s_and_saveexec_b32 s1, s0                                  // 000000167984: BE812000
	s_cbranch_execz 11                                         // 000000167988: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17b8>
	global_load_b128 v[50:53], v[3:4], off offset:432          // 00000016798C: DC5E01B0 327C0003
	s_waitcnt vmcnt(0)                                         // 000000167994: BF8903F7
	v_fma_mixlo_f16 v66, v50, s22, 0                           // 000000167998: CC210042 02002D32
	v_fma_mixhi_f16 v66, v51, s22, 0                           // 0000001679A0: CC220042 02002D33
	v_fma_mixlo_f16 v67, v52, s22, 0                           // 0000001679A8: CC210043 02002D34
	v_fma_mixhi_f16 v67, v53, s22, 0                           // 0000001679B0: CC220043 02002D35
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001679B8: 8C7E017E
	ds_load_b128 v[50:53], v94 offset:384                      // 0000001679BC: DBFC0180 3200005E
	ds_load_b128 v[54:57], v94 offset:400                      // 0000001679C4: DBFC0190 3600005E
	ds_load_b128 v[72:75], v94 offset:8832                     // 0000001679CC: DBFC2280 4800005E
	ds_load_b128 v[76:79], v94 offset:8848                     // 0000001679D4: DBFC2290 4C00005E
	ds_load_b128 v[116:119], v94 offset:17280                  // 0000001679DC: DBFC4380 7400005E
	ds_load_b128 v[120:123], v94 offset:17296                  // 0000001679E4: DBFC4390 7800005E
	ds_load_b128 v[124:127], v94 offset:25728                  // 0000001679EC: DBFC6480 7C00005E
	s_waitcnt lgkmcnt(6)                                       // 0000001679F4: BF89FC67
	v_fma_mixlo_f16 v68, v50, s22, 0                           // 0000001679F8: CC210044 02002D32
	v_fma_mixhi_f16 v68, v51, s22, 0                           // 000000167A00: CC220044 02002D33
	v_fma_mixlo_f16 v69, v52, s22, 0                           // 000000167A08: CC210045 02002D34
	v_fma_mixhi_f16 v69, v53, s22, 0                           // 000000167A10: CC220045 02002D35
	ds_load_b128 v[50:53], v94 offset:25744                    // 000000167A18: DBFC6490 3200005E
	s_waitcnt lgkmcnt(6)                                       // 000000167A20: BF89FC67
	v_fma_mixlo_f16 v70, v54, s22, 0                           // 000000167A24: CC210046 02002D36
	v_fma_mixhi_f16 v70, v55, s22, 0                           // 000000167A2C: CC220046 02002D37
	v_fma_mixlo_f16 v71, v56, s22, 0                           // 000000167A34: CC210047 02002D38
	v_fma_mixhi_f16 v71, v57, s22, 0                           // 000000167A3C: CC220047 02002D39
	s_waitcnt lgkmcnt(5)                                       // 000000167A44: BF89FC57
	v_fma_mixlo_f16 v108, v72, s22, 0                          // 000000167A48: CC21006C 02002D48
	v_fma_mixhi_f16 v108, v73, s22, 0                          // 000000167A50: CC22006C 02002D49
	v_fma_mixlo_f16 v109, v74, s22, 0                          // 000000167A58: CC21006D 02002D4A
	v_fma_mixhi_f16 v109, v75, s22, 0                          // 000000167A60: CC22006D 02002D4B
	s_waitcnt lgkmcnt(4)                                       // 000000167A68: BF89FC47
	v_fma_mixlo_f16 v110, v76, s22, 0                          // 000000167A6C: CC21006E 02002D4C
	v_fma_mixhi_f16 v110, v77, s22, 0                          // 000000167A74: CC22006E 02002D4D
	v_fma_mixlo_f16 v111, v78, s22, 0                          // 000000167A7C: CC21006F 02002D4E
	v_fma_mixhi_f16 v111, v79, s22, 0                          // 000000167A84: CC22006F 02002D4F
	s_waitcnt lgkmcnt(3)                                       // 000000167A8C: BF89FC37
	v_fma_mixlo_f16 v116, v116, s22, 0                         // 000000167A90: CC210074 02002D74
	v_fma_mixhi_f16 v116, v117, s22, 0                         // 000000167A98: CC220074 02002D75
	v_fma_mixlo_f16 v117, v118, s22, 0                         // 000000167AA0: CC210075 02002D76
	v_fma_mixhi_f16 v117, v119, s22, 0                         // 000000167AA8: CC220075 02002D77
	s_waitcnt lgkmcnt(2)                                       // 000000167AB0: BF89FC27
	v_fma_mixlo_f16 v118, v120, s22, 0                         // 000000167AB4: CC210076 02002D78
	v_fma_mixhi_f16 v118, v121, s22, 0                         // 000000167ABC: CC220076 02002D79
	v_fma_mixlo_f16 v119, v122, s22, 0                         // 000000167AC4: CC210077 02002D7A
	v_fma_mixhi_f16 v119, v123, s22, 0                         // 000000167ACC: CC220077 02002D7B
	s_waitcnt lgkmcnt(1)                                       // 000000167AD4: BF89FC17
	v_fma_mixlo_f16 v124, v124, s22, 0                         // 000000167AD8: CC21007C 02002D7C
	v_fma_mixhi_f16 v124, v125, s22, 0                         // 000000167AE0: CC22007C 02002D7D
	v_fma_mixlo_f16 v125, v126, s22, 0                         // 000000167AE8: CC21007D 02002D7E
	v_fma_mixhi_f16 v125, v127, s22, 0                         // 000000167AF0: CC22007D 02002D7F
	s_waitcnt lgkmcnt(0)                                       // 000000167AF8: BF89FC07
	v_fma_mixlo_f16 v126, v50, s22, 0                          // 000000167AFC: CC21007E 02002D32
	v_fma_mixhi_f16 v126, v51, s22, 0                          // 000000167B04: CC22007E 02002D33
	v_fma_mixlo_f16 v127, v52, s22, 0                          // 000000167B0C: CC21007F 02002D34
	v_fma_mixhi_f16 v127, v53, s22, 0                          // 000000167B14: CC22007F 02002D35
	v_dual_mov_b32 v72, v68 :: v_dual_mov_b32 v73, v69         // 000000167B1C: CA100144 48480145
	v_dual_mov_b32 v74, v70 :: v_dual_mov_b32 v75, v71         // 000000167B24: CA100146 4A4A0147
	v_dual_mov_b32 v112, v108 :: v_dual_mov_b32 v113, v109     // 000000167B2C: CA10016C 7070016D
	v_dual_mov_b32 v114, v110 :: v_dual_mov_b32 v115, v111     // 000000167B34: CA10016E 7272016F
	v_dual_mov_b32 v120, v116 :: v_dual_mov_b32 v121, v117     // 000000167B3C: CA100174 78780175
	v_dual_mov_b32 v122, v118 :: v_dual_mov_b32 v123, v119     // 000000167B44: CA100176 7A7A0177
	v_dual_mov_b32 v128, v124 :: v_dual_mov_b32 v129, v125     // 000000167B4C: CA10017C 8080017D
	v_dual_mov_b32 v130, v126 :: v_dual_mov_b32 v131, v127     // 000000167B54: CA10017E 8282017F
	.long 0x7f6a3880                                           // 000000167B5C: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[60:67], v[68:75], v[42:49]// 000000167B60: CC40402A 1CAA893C
	v_wmma_f32_16x16x16_f16 v[34:41], v[60:67], v[108:115], v[34:41]// 000000167B68: CC404022 1C8AD93C
	v_wmma_f32_16x16x16_f16 v[26:33], v[60:67], v[116:123], v[26:33]// 000000167B70: CC40401A 1C6AE93C
	v_wmma_f32_16x16x16_f16 v[18:25], v[60:67], v[124:131], v[18:25]// 000000167B78: CC404012 1C4AF93C
	.long 0x7f6639b5                                           // 000000167B80: 7F6639B5
	.long 0x7e6639b5                                           // 000000167B84: 7E6639B5
	.long 0x7f6439b5                                           // 000000167B88: 7F6439B5
	.long 0x7e6439b5                                           // 000000167B8C: 7E6439B5
	s_and_saveexec_b32 s1, s0                                  // 000000167B90: BE812000
	s_cbranch_execz 11                                         // 000000167B94: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c4>
	global_load_b128 v[54:57], v[3:4], off offset:448          // 000000167B98: DC5E01C0 367C0003
	s_waitcnt vmcnt(0)                                         // 000000167BA0: BF8903F7
	v_fma_mixlo_f16 v50, v54, s22, 0                           // 000000167BA4: CC210032 02002D36
	v_fma_mixhi_f16 v50, v55, s22, 0                           // 000000167BAC: CC220032 02002D37
	v_fma_mixlo_f16 v51, v56, s22, 0                           // 000000167BB4: CC210033 02002D38
	v_fma_mixhi_f16 v51, v57, s22, 0                           // 000000167BBC: CC220033 02002D39
	s_or_b32 exec_lo, exec_lo, s1                              // 000000167BC4: 8C7E017E
	.long 0x7e6a39b5                                           // 000000167BC8: 7E6A39B5
	.long 0x7f6839b5                                           // 000000167BCC: 7F6839B5
	.long 0x7e6839b5                                           // 000000167BD0: 7E6839B5
	s_and_saveexec_b32 s1, s0                                  // 000000167BD4: BE812000
	s_cbranch_execz 11                                         // 000000167BD8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a08>
	global_load_b128 v[52:55], v[3:4], off offset:464          // 000000167BDC: DC5E01D0 347C0003
	s_waitcnt vmcnt(0)                                         // 000000167BE4: BF8903F7
	v_fma_mixlo_f16 v52, v52, s22, 0                           // 000000167BE8: CC210034 02002D34
	v_fma_mixhi_f16 v52, v53, s22, 0                           // 000000167BF0: CC220034 02002D35
	v_fma_mixlo_f16 v53, v54, s22, 0                           // 000000167BF8: CC210035 02002D36
	v_fma_mixhi_f16 v53, v55, s22, 0                           // 000000167C00: CC220035 02002D37
	s_or_b32 exec_lo, exec_lo, s1                              // 000000167C08: 8C7E017E
	.long 0x7f723880                                           // 000000167C0C: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000167C10: BF870001
	.long 0x7f6e39b9                                           // 000000167C14: 7F6E39B9
	.long 0x7e6e39b9                                           // 000000167C18: 7E6E39B9
	.long 0x7f6c39b9                                           // 000000167C1C: 7F6C39B9
	.long 0x7e6c39b9                                           // 000000167C20: 7E6C39B9
	s_and_saveexec_b32 s1, s0                                  // 000000167C24: BE812000
	s_cbranch_execz 11                                         // 000000167C28: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a58>
	global_load_b128 v[58:61], v[3:4], off offset:480          // 000000167C2C: DC5E01E0 3A7C0003
	s_waitcnt vmcnt(0)                                         // 000000167C34: BF8903F7
	v_fma_mixlo_f16 v54, v58, s22, 0                           // 000000167C38: CC210036 02002D3A
	v_fma_mixhi_f16 v54, v59, s22, 0                           // 000000167C40: CC220036 02002D3B
	v_fma_mixlo_f16 v55, v60, s22, 0                           // 000000167C48: CC210037 02002D3C
	v_fma_mixhi_f16 v55, v61, s22, 0                           // 000000167C50: CC220037 02002D3D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000167C58: 8C7E017E
	.long 0x7e7239b9                                           // 000000167C5C: 7E7239B9
	.long 0x7f7039b9                                           // 000000167C60: 7F7039B9
	.long 0x7e7039b9                                           // 000000167C64: 7E7039B9
	s_and_saveexec_b32 s1, s0                                  // 000000167C68: BE812000
	s_cbranch_execz 11                                         // 000000167C6C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a9c>
	global_load_b128 v[56:59], v[3:4], off offset:496          // 000000167C70: DC5E01F0 387C0003
	s_waitcnt vmcnt(0)                                         // 000000167C78: BF8903F7
	v_fma_mixlo_f16 v56, v56, s22, 0                           // 000000167C7C: CC210038 02002D38
	v_fma_mixhi_f16 v56, v57, s22, 0                           // 000000167C84: CC220038 02002D39
	v_fma_mixlo_f16 v57, v58, s22, 0                           // 000000167C8C: CC210039 02002D3A
	v_fma_mixhi_f16 v57, v59, s22, 0                           // 000000167C94: CC220039 02002D3B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000167C9C: 8C7E017E
	ds_load_b128 v[58:61], v94 offset:448                      // 000000167CA0: DBFC01C0 3A00005E
	ds_load_b128 v[62:65], v94 offset:464                      // 000000167CA8: DBFC01D0 3E00005E
	ds_load_b128 v[66:69], v94 offset:8896                     // 000000167CB0: DBFC22C0 4200005E
	ds_load_b128 v[70:73], v94 offset:8912                     // 000000167CB8: DBFC22D0 4600005E
	ds_load_b128 v[74:77], v94 offset:17344                    // 000000167CC0: DBFC43C0 4A00005E
	ds_load_b128 v[78:81], v94 offset:17360                    // 000000167CC8: DBFC43D0 4E00005E
	ds_load_b128 v[108:111], v94 offset:25792                  // 000000167CD0: DBFC64C0 6C00005E
	ds_load_b128 v[112:115], v94 offset:25808                  // 000000167CD8: DBFC64D0 7000005E
	v_add_nc_u32_e32 v7, s46, v95                              // 000000167CE0: 4A0EBE2E
	.long 0x7e063880                                           // 000000167CE4: 7E063880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000167CE8: BF870112
	.long 0xd4440001                                           // 000000167CEC: D4440001
	v_cndmask_b32_e32 v1, s35, v7, vcc_lo                      // 000000167CF0: 02020E23
	.long 0x7f063903                                           // 000000167CF4: 7F063903
	s_waitcnt lgkmcnt(7)                                       // 000000167CF8: BF89FC77
	v_fma_mixlo_f16 v58, v58, s22, 0                           // 000000167CFC: CC21003A 02002D3A
	v_fma_mixhi_f16 v58, v59, s22, 0                           // 000000167D04: CC22003A 02002D3B
	v_fma_mixlo_f16 v59, v60, s22, 0                           // 000000167D0C: CC21003B 02002D3C
	v_fma_mixhi_f16 v59, v61, s22, 0                           // 000000167D14: CC22003B 02002D3D
	s_waitcnt lgkmcnt(6)                                       // 000000167D1C: BF89FC67
	v_fma_mixlo_f16 v60, v62, s22, 0                           // 000000167D20: CC21003C 02002D3E
	v_fma_mixhi_f16 v60, v63, s22, 0                           // 000000167D28: CC22003C 02002D3F
	v_fma_mixlo_f16 v61, v64, s22, 0                           // 000000167D30: CC21003D 02002D40
	v_fma_mixhi_f16 v61, v65, s22, 0                           // 000000167D38: CC22003D 02002D41
	v_dual_mov_b32 v62, v58 :: v_dual_mov_b32 v63, v59         // 000000167D40: CA10013A 3E3E013B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000167D48: BF870004
	v_mov_b32_e32 v64, v60                                     // 000000167D4C: 7E80033C
	s_waitcnt lgkmcnt(5)                                       // 000000167D50: BF89FC57
	v_fma_mixlo_f16 v66, v66, s22, 0                           // 000000167D54: CC210042 02002D42
	v_mov_b32_e32 v65, v61                                     // 000000167D5C: 7E82033D
	v_fma_mixhi_f16 v66, v67, s22, 0                           // 000000167D60: CC220042 02002D43
	v_fma_mixlo_f16 v67, v68, s22, 0                           // 000000167D68: CC210043 02002D44
	v_fma_mixhi_f16 v67, v69, s22, 0                           // 000000167D70: CC220043 02002D45
	s_waitcnt lgkmcnt(4)                                       // 000000167D78: BF89FC47
	v_fma_mixlo_f16 v68, v70, s22, 0                           // 000000167D7C: CC210044 02002D46
	v_fma_mixhi_f16 v68, v71, s22, 0                           // 000000167D84: CC220044 02002D47
	v_fma_mixlo_f16 v69, v72, s22, 0                           // 000000167D8C: CC210045 02002D48
	v_fma_mixhi_f16 v69, v73, s22, 0                           // 000000167D94: CC220045 02002D49
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[58:65], v[42:49]// 000000167D9C: CC40402A 1CAA7532
	s_waitcnt lgkmcnt(3)                                       // 000000167DA4: BF89FC37
	v_fma_mixlo_f16 v58, v74, s22, 0                           // 000000167DA8: CC21003A 02002D4A
	v_fma_mixhi_f16 v58, v75, s22, 0                           // 000000167DB0: CC22003A 02002D4B
	v_fma_mixlo_f16 v59, v76, s22, 0                           // 000000167DB8: CC21003B 02002D4C
	v_fma_mixhi_f16 v59, v77, s22, 0                           // 000000167DC0: CC22003B 02002D4D
	s_waitcnt lgkmcnt(2)                                       // 000000167DC8: BF89FC27
	v_fma_mixlo_f16 v60, v78, s22, 0                           // 000000167DCC: CC21003C 02002D4E
	v_fma_mixhi_f16 v60, v79, s22, 0                           // 000000167DD4: CC22003C 02002D4F
	v_fma_mixlo_f16 v61, v80, s22, 0                           // 000000167DDC: CC21003D 02002D50
	v_fma_mixhi_f16 v61, v81, s22, 0                           // 000000167DE4: CC22003D 02002D51
	s_waitcnt lgkmcnt(1)                                       // 000000167DEC: BF89FC17
	v_fma_mixlo_f16 v74, v108, s22, 0                          // 000000167DF0: CC21004A 02002D6C
	v_fma_mixhi_f16 v74, v109, s22, 0                          // 000000167DF8: CC22004A 02002D6D
	v_fma_mixlo_f16 v75, v110, s22, 0                          // 000000167E00: CC21004B 02002D6E
	v_fma_mixhi_f16 v75, v111, s22, 0                          // 000000167E08: CC22004B 02002D6F
	s_waitcnt lgkmcnt(0)                                       // 000000167E10: BF89FC07
	v_fma_mixlo_f16 v76, v112, s22, 0                          // 000000167E14: CC21004C 02002D70
	v_fma_mixhi_f16 v76, v113, s22, 0                          // 000000167E1C: CC22004C 02002D71
	v_fma_mixlo_f16 v77, v114, s22, 0                          // 000000167E24: CC21004D 02002D72
	v_fma_mixhi_f16 v77, v115, s22, 0                          // 000000167E2C: CC22004D 02002D73
	v_dual_mov_b32 v70, v66 :: v_dual_mov_b32 v71, v67         // 000000167E34: CA100142 46460143
	v_dual_mov_b32 v72, v68 :: v_dual_mov_b32 v73, v69         // 000000167E3C: CA100144 48480145
	v_dual_mov_b32 v62, v58 :: v_dual_mov_b32 v63, v59         // 000000167E44: CA10013A 3E3E013B
	v_dual_mov_b32 v64, v60 :: v_dual_mov_b32 v65, v61         // 000000167E4C: CA10013C 4040013D
	v_dual_mov_b32 v78, v74 :: v_dual_mov_b32 v79, v75         // 000000167E54: CA10014A 4E4E014B
	v_dual_mov_b32 v80, v76 :: v_dual_mov_b32 v81, v77         // 000000167E5C: CA10014C 5050014D
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[66:73], v[34:41]// 000000167E64: CC404022 1C8A8532
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000167E6C: BF870194
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[58:65], v[26:33]// 000000167E70: CC40401A 1C6A7532
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[74:81], v[18:25]// 000000167E78: CC404012 1C4A9532
	s_and_saveexec_b32 s5, s1                                  // 000000167E80: BE852001
	s_cbranch_execz 17                                         // 000000167E84: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ccc>
	v_mad_u64_u32 v[8:9], null, v7, 48, s[2:3]                 // 000000167E88: D6FE7C08 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167E90: BF870091
	.long 0xd73c0008                                           // 000000167E94: D73C0008
	v_cndmask_b32_e32 v1, 9, v8, vcc_lo                        // 000000167E98: 02021089
	.long 0xd7000408                                           // 000000167E9C: D7000408
	v_cndmask_b32_e32 v1, v101, v8, vcc_lo                     // 000000167EA0: 02021165
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000167EA4: BF8700C1
	v_add_co_ci_u32_e64 v9, null, v102, v9, s4                 // 000000167EA8: D5207C09 00121366
	global_load_b32 v4, v[8:9], off                            // 000000167EB0: DC520000 047C0008
	s_waitcnt vmcnt(0)                                         // 000000167EB8: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v42                         // 000000167EBC: 560854FF BB800000
	v_fma_mixhi_f16 v3, v4, s22, 0                             // 000000167EC4: CC220003 02002D04
	s_or_b32 exec_lo, exec_lo, s5                              // 000000167ECC: 8C7E057E
	v_add_nc_u32_e32 v8, 2, v7                                 // 000000167ED0: 4A100E82
	ds_store_b16_d16_hi v103, v3                               // 000000167ED4: DA840000 00000367
	.long 0xd4440004                                           // 000000167EDC: D4440004
	v_cndmask_b32_e32 v1, s35, v8, vcc_lo                      // 000000167EE0: 02021023
	s_and_saveexec_b32 s6, s4                                  // 000000167EE4: BE862004
	s_cbranch_execz 17                                         // 000000167EE8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d30>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 000000167EEC: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167EF4: BF870091
	.long 0xd73c0003                                           // 000000167EF8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000167EFC: 02020689
	.long 0xd7000503                                           // 000000167F00: D7000503
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000167F04: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000167F08: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s5                 // 000000167F0C: D5207C04 00160966
	global_load_b32 v3, v[3:4], off                            // 000000167F14: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000167F1C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v43                         // 000000167F20: 560656FF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 000000167F28: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s6                              // 000000167F30: 8C7E067E
	v_add_nc_u32_e32 v9, 4, v7                                 // 000000167F34: 4A120E84
	.long 0x7f063880                                           // 000000167F38: 7F063880
	ds_store_b16 v103, v3 offset:4                             // 000000167F3C: D87C0004 00000367
	.long 0xd4440005                                           // 000000167F44: D4440005
	v_cndmask_b32_e32 v1, s35, v9, vcc_lo                      // 000000167F48: 02021223
	.long 0x7e083983                                           // 000000167F4C: 7E083983
	s_and_saveexec_b32 s7, s5                                  // 000000167F50: BE872005
	s_cbranch_execz 17                                         // 000000167F54: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d9c>
	v_mad_u64_u32 v[42:43], null, v9, 48, s[2:3]               // 000000167F58: D6FE7C2A 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167F60: BF870091
	.long 0xd73c002a                                           // 000000167F64: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000167F68: 02025489
	.long 0xd700062a                                           // 000000167F6C: D700062A
	v_cndmask_b32_e32 v1, v101, v42, vcc_lo                    // 000000167F70: 02025565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000167F74: BF8700C1
	v_add_co_ci_u32_e64 v43, null, v102, v43, s6               // 000000167F78: D5207C2B 001A5766
	global_load_b32 v4, v[42:43], off                          // 000000167F80: DC520000 047C002A
	s_waitcnt vmcnt(0)                                         // 000000167F88: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v44                         // 000000167F8C: 560858FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000167F94: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s7                              // 000000167F9C: 8C7E077E
	v_add_nc_u32_e32 v108, 6, v7                               // 000000167FA0: 4AD80E86
	ds_store_b16 v103, v4 offset:8                             // 000000167FA4: D87C0008 00000467
	.long 0xd4440006                                           // 000000167FAC: D4440006
	v_cndmask_b32_e32 v1, s35, v108, vcc_lo                    // 000000167FB0: 0202D823
	s_and_saveexec_b32 s8, s6                                  // 000000167FB4: BE882006
	s_cbranch_execz 17                                         // 000000167FB8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e00>
	v_mad_u64_u32 v[3:4], null, v108, 48, s[2:3]               // 000000167FBC: D6FE7C03 0009616C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000167FC4: BF870091
	.long 0xd73c0003                                           // 000000167FC8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000167FCC: 02020689
	.long 0xd7000703                                           // 000000167FD0: D7000703
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000167FD4: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000167FD8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s7                 // 000000167FDC: D5207C04 001E0966
	global_load_b32 v3, v[3:4], off                            // 000000167FE4: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000167FEC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v45                         // 000000167FF0: 56065AFF BB800000
	v_fma_mixhi_f16 v3, v3, s22, 0                             // 000000167FF8: CC220003 02002D03
	s_or_b32 exec_lo, exec_lo, s8                              // 000000168000: 8C7E087E
	v_add_nc_u32_e32 v109, 8, v7                               // 000000168004: 4ADA0E88
	.long 0x7e083880                                           // 000000168008: 7E083880
	ds_store_b16_d16_hi v103, v3 offset:12                     // 00000016800C: DA84000C 00000367
	.long 0xd4440007                                           // 000000168014: D4440007
	v_cndmask_b32_e32 v1, s35, v109, vcc_lo                    // 000000168018: 0202DA23
	.long 0x7e063904                                           // 00000016801C: 7E063904
	s_and_saveexec_b32 s9, s7                                  // 000000168020: BE892007
	s_cbranch_execz 17                                         // 000000168024: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e6c>
	v_mad_u64_u32 v[42:43], null, v109, 48, s[2:3]             // 000000168028: D6FE7C2A 0009616D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168030: BF870091
	.long 0xd73c002a                                           // 000000168034: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000168038: 02025489
	.long 0xd700082a                                           // 00000016803C: D700082A
	v_cndmask_b32_e32 v1, v101, v42, vcc_lo                    // 000000168040: 02025565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168044: BF8700C1
	v_add_co_ci_u32_e64 v43, null, v102, v43, s8               // 000000168048: D5207C2B 00225766
	global_load_b32 v3, v[42:43], off                          // 000000168050: DC520000 037C002A
	s_waitcnt vmcnt(0)                                         // 000000168058: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v46                         // 00000016805C: 56065CFF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 000000168064: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s9                              // 00000016806C: 8C7E097E
	v_add_nc_u32_e32 v110, 10, v7                              // 000000168070: 4ADC0E8A
	ds_store_b16 v103, v3 offset:16                            // 000000168074: D87C0010 00000367
	.long 0xd4440008                                           // 00000016807C: D4440008
	v_cndmask_b32_e32 v1, s35, v110, vcc_lo                    // 000000168080: 0202DC23
	s_and_saveexec_b32 s10, s8                                 // 000000168084: BE8A2008
	s_cbranch_execz 17                                         // 000000168088: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ed0>
	v_mad_u64_u32 v[3:4], null, v110, 48, s[2:3]               // 00000016808C: D6FE7C03 0009616E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168094: BF870091
	.long 0xd73c0003                                           // 000000168098: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016809C: 02020689
	.long 0xd7000903                                           // 0000001680A0: D7000903
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 0000001680A4: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001680A8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s9                 // 0000001680AC: D5207C04 00260966
	global_load_b32 v3, v[3:4], off                            // 0000001680B4: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000001680BC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v47                         // 0000001680C0: 56065EFF BB800000
	v_fma_mixlo_f16 v4, v3, s22, 0                             // 0000001680C8: CC210004 02002D03
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001680D0: 8C7E0A7E
	v_add_nc_u32_e32 v111, 12, v7                              // 0000001680D4: 4ADE0E8C
	.long 0x7e063880                                           // 0000001680D8: 7E063880
	ds_store_b16 v103, v4 offset:20                            // 0000001680DC: D87C0014 00000467
	.long 0xd4440009                                           // 0000001680E4: D4440009
	v_cndmask_b32_e32 v1, s35, v111, vcc_lo                    // 0000001680E8: 0202DE23
	.long 0x7f063903                                           // 0000001680EC: 7F063903
	s_and_saveexec_b32 s11, s9                                 // 0000001680F0: BE8B2009
	s_cbranch_execz 17                                         // 0000001680F4: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f3c>
	v_mad_u64_u32 v[42:43], null, v111, 48, s[2:3]             // 0000001680F8: D6FE7C2A 0009616F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168100: BF870091
	.long 0xd73c002a                                           // 000000168104: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000168108: 02025489
	.long 0xd7000a2a                                           // 00000016810C: D7000A2A
	v_cndmask_b32_e32 v1, v101, v42, vcc_lo                    // 000000168110: 02025565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168114: BF8700C1
	v_add_co_ci_u32_e64 v43, null, v102, v43, s10              // 000000168118: D5207C2B 002A5766
	global_load_b32 v4, v[42:43], off                          // 000000168120: DC520000 047C002A
	s_waitcnt vmcnt(0)                                         // 000000168128: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v48                         // 00000016812C: 560860FF BB800000
	v_fma_mixhi_f16 v3, v4, s22, 0                             // 000000168134: CC220003 02002D04
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016813C: 8C7E0B7E
	v_add_nc_u32_e32 v112, 14, v7                              // 000000168140: 4AE00E8E
	ds_store_b16_d16_hi v103, v3 offset:24                     // 000000168144: DA840018 00000367
	.long 0xd444000a                                           // 00000016814C: D444000A
	v_cndmask_b32_e32 v1, s35, v112, vcc_lo                    // 000000168150: 0202E023
	s_and_saveexec_b32 s14, s10                                // 000000168154: BE8E200A
	s_cbranch_execz 17                                         // 000000168158: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fa0>
	v_mad_u64_u32 v[3:4], null, v112, 48, s[2:3]               // 00000016815C: D6FE7C03 00096170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168164: BF870091
	.long 0xd73c0003                                           // 000000168168: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016816C: 02020689
	.long 0xd7000b03                                           // 000000168170: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000168174: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168178: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 00000016817C: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off                            // 000000168184: DC520000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016818C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v49                         // 000000168190: 560662FF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 000000168198: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001681A0: 8C7E0E7E
	.long 0x7f063880                                           // 0000001681A4: 7F063880
	ds_store_b16 v103, v3 offset:28                            // 0000001681A8: D87C001C 00000367
	.long 0x7e083983                                           // 0000001681B0: 7E083983
	s_and_saveexec_b32 s14, s1                                 // 0000001681B4: BE8E2001
	s_cbranch_execz 17                                         // 0000001681B8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2000>
	v_mad_u64_u32 v[42:43], null, v7, 48, s[2:3]               // 0000001681BC: D6FE7C2A 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001681C4: BF870091
	.long 0xd73c002a                                           // 0000001681C8: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 0000001681CC: 02025489
	.long 0xd7000b2a                                           // 0000001681D0: D7000B2A
	v_cndmask_b32_e32 v1, v101, v42, vcc_lo                    // 0000001681D4: 02025565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001681D8: BF8700C1
	v_add_co_ci_u32_e64 v43, null, v102, v43, s11              // 0000001681DC: D5207C2B 002E5766
	global_load_b32 v4, v[42:43], off offset:64                // 0000001681E4: DC520040 047C002A
	s_waitcnt vmcnt(0)                                         // 0000001681EC: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v34                         // 0000001681F0: 560844FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 0000001681F8: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168200: 8C7E0E7E
	ds_store_b16 v103, v4 offset:2560                          // 000000168204: D87C0A00 00000467
	s_and_saveexec_b32 s14, s4                                 // 00000016820C: BE8E2004
	s_cbranch_execz 17                                         // 000000168210: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2058>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 000000168214: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016821C: BF870091
	.long 0xd73c0003                                           // 000000168220: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000168224: 02020689
	.long 0xd7000b03                                           // 000000168228: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 00000016822C: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168230: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000168234: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:64                  // 00000016823C: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 000000168244: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v35                         // 000000168248: 560646FF BB800000
	v_fma_mixhi_f16 v3, v3, s22, 0                             // 000000168250: CC220003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168258: 8C7E0E7E
	.long 0x7e063880                                           // 00000016825C: 7E063880
	ds_store_b16_d16_hi v103, v3 offset:2564                   // 000000168260: DA840A04 00000367
	.long 0x7e083903                                           // 000000168268: 7E083903
	s_and_saveexec_b32 s14, s5                                 // 00000016826C: BE8E2005
	s_cbranch_execz 17                                         // 000000168270: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x20b8>
	v_mad_u64_u32 v[34:35], null, v9, 48, s[2:3]               // 000000168274: D6FE7C22 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016827C: BF870091
	.long 0xd73c0022                                           // 000000168280: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 000000168284: 02024489
	.long 0xd7000b22                                           // 000000168288: D7000B22
	v_cndmask_b32_e32 v1, v101, v34, vcc_lo                    // 00000016828C: 02024565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168290: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v102, v35, s11              // 000000168294: D5207C23 002E4766
	global_load_b32 v4, v[34:35], off offset:64                // 00000016829C: DC520040 047C0022
	s_waitcnt vmcnt(0)                                         // 0000001682A4: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v36                         // 0000001682A8: 560848FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 0000001682B0: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001682B8: 8C7E0E7E
	ds_store_b16 v103, v4 offset:2568                          // 0000001682BC: D87C0A08 00000467
	s_and_saveexec_b32 s14, s6                                 // 0000001682C4: BE8E2006
	s_cbranch_execz 17                                         // 0000001682C8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2110>
	v_mad_u64_u32 v[3:4], null, v108, 48, s[2:3]               // 0000001682CC: D6FE7C03 0009616C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001682D4: BF870091
	.long 0xd73c0003                                           // 0000001682D8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001682DC: 02020689
	.long 0xd7000b03                                           // 0000001682E0: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 0000001682E4: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001682E8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 0000001682EC: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:64                  // 0000001682F4: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 0000001682FC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v37                         // 000000168300: 56064AFF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 000000168308: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168310: 8C7E0E7E
	.long 0x7f063880                                           // 000000168314: 7F063880
	ds_store_b16 v103, v3 offset:2572                          // 000000168318: D87C0A0C 00000367
	.long 0x7e083983                                           // 000000168320: 7E083983
	s_and_saveexec_b32 s14, s7                                 // 000000168324: BE8E2007
	s_cbranch_execz 17                                         // 000000168328: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2170>
	v_mad_u64_u32 v[34:35], null, v109, 48, s[2:3]             // 00000016832C: D6FE7C22 0009616D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168334: BF870091
	.long 0xd73c0022                                           // 000000168338: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 00000016833C: 02024489
	.long 0xd7000b22                                           // 000000168340: D7000B22
	v_cndmask_b32_e32 v1, v101, v34, vcc_lo                    // 000000168344: 02024565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168348: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v102, v35, s11              // 00000016834C: D5207C23 002E4766
	global_load_b32 v4, v[34:35], off offset:64                // 000000168354: DC520040 047C0022
	s_waitcnt vmcnt(0)                                         // 00000016835C: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v38                         // 000000168360: 56084CFF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000168368: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168370: 8C7E0E7E
	ds_store_b16 v103, v4 offset:2576                          // 000000168374: D87C0A10 00000467
	s_and_saveexec_b32 s14, s8                                 // 00000016837C: BE8E2008
	s_cbranch_execz 17                                         // 000000168380: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x21c8>
	v_mad_u64_u32 v[3:4], null, v110, 48, s[2:3]               // 000000168384: D6FE7C03 0009616E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016838C: BF870091
	.long 0xd73c0003                                           // 000000168390: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000168394: 02020689
	.long 0xd7000b03                                           // 000000168398: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 00000016839C: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001683A0: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 0000001683A4: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:64                  // 0000001683AC: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 0000001683B4: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v39                         // 0000001683B8: 56064EFF BB800000
	v_fma_mixhi_f16 v3, v3, s22, 0                             // 0000001683C0: CC220003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001683C8: 8C7E0E7E
	.long 0x7e063880                                           // 0000001683CC: 7E063880
	ds_store_b16_d16_hi v103, v3 offset:2580                   // 0000001683D0: DA840A14 00000367
	.long 0x7e083903                                           // 0000001683D8: 7E083903
	s_and_saveexec_b32 s14, s9                                 // 0000001683DC: BE8E2009
	s_cbranch_execz 17                                         // 0000001683E0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2228>
	v_mad_u64_u32 v[34:35], null, v111, 48, s[2:3]             // 0000001683E4: D6FE7C22 0009616F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001683EC: BF870091
	.long 0xd73c0022                                           // 0000001683F0: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 0000001683F4: 02024489
	.long 0xd7000b22                                           // 0000001683F8: D7000B22
	v_cndmask_b32_e32 v1, v101, v34, vcc_lo                    // 0000001683FC: 02024565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168400: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v102, v35, s11              // 000000168404: D5207C23 002E4766
	global_load_b32 v4, v[34:35], off offset:64                // 00000016840C: DC520040 047C0022
	s_waitcnt vmcnt(0)                                         // 000000168414: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v40                         // 000000168418: 560850FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000168420: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168428: 8C7E0E7E
	ds_store_b16 v103, v4 offset:2584                          // 00000016842C: D87C0A18 00000467
	s_and_saveexec_b32 s14, s10                                // 000000168434: BE8E200A
	s_cbranch_execz 17                                         // 000000168438: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2280>
	v_mad_u64_u32 v[3:4], null, v112, 48, s[2:3]               // 00000016843C: D6FE7C03 00096170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168444: BF870091
	.long 0xd73c0003                                           // 000000168448: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016844C: 02020689
	.long 0xd7000b03                                           // 000000168450: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000168454: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168458: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 00000016845C: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:64                  // 000000168464: DC520040 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016846C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v41                         // 000000168470: 560652FF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 000000168478: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168480: 8C7E0E7E
	.long 0x7f063880                                           // 000000168484: 7F063880
	ds_store_b16 v103, v3 offset:2588                          // 000000168488: D87C0A1C 00000367
	.long 0x7e083983                                           // 000000168490: 7E083983
	s_and_saveexec_b32 s14, s1                                 // 000000168494: BE8E2001
	s_cbranch_execz 17                                         // 000000168498: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x22e0>
	v_mad_u64_u32 v[34:35], null, v7, 48, s[2:3]               // 00000016849C: D6FE7C22 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001684A4: BF870091
	.long 0xd73c0022                                           // 0000001684A8: D73C0022
	v_cndmask_b32_e32 v1, 9, v34, vcc_lo                       // 0000001684AC: 02024489
	.long 0xd7000b22                                           // 0000001684B0: D7000B22
	v_cndmask_b32_e32 v1, v101, v34, vcc_lo                    // 0000001684B4: 02024565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001684B8: BF8700C1
	v_add_co_ci_u32_e64 v35, null, v102, v35, s11              // 0000001684BC: D5207C23 002E4766
	global_load_b32 v4, v[34:35], off offset:128               // 0000001684C4: DC520080 047C0022
	s_waitcnt vmcnt(0)                                         // 0000001684CC: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v26                         // 0000001684D0: 560834FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 0000001684D8: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001684E0: 8C7E0E7E
	ds_store_b16 v103, v4 offset:5120                          // 0000001684E4: D87C1400 00000467
	s_and_saveexec_b32 s14, s4                                 // 0000001684EC: BE8E2004
	s_cbranch_execz 17                                         // 0000001684F0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2338>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 0000001684F4: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001684FC: BF870091
	.long 0xd73c0003                                           // 000000168500: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000168504: 02020689
	.long 0xd7000b03                                           // 000000168508: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 00000016850C: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168510: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000168514: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:128                 // 00000016851C: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 000000168524: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v27                         // 000000168528: 560636FF BB800000
	v_fma_mixhi_f16 v3, v3, s22, 0                             // 000000168530: CC220003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168538: 8C7E0E7E
	.long 0x7e063880                                           // 00000016853C: 7E063880
	ds_store_b16_d16_hi v103, v3 offset:5124                   // 000000168540: DA841404 00000367
	.long 0x7e083903                                           // 000000168548: 7E083903
	s_and_saveexec_b32 s14, s5                                 // 00000016854C: BE8E2005
	s_cbranch_execz 17                                         // 000000168550: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2398>
	v_mad_u64_u32 v[26:27], null, v9, 48, s[2:3]               // 000000168554: D6FE7C1A 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016855C: BF870091
	.long 0xd73c001a                                           // 000000168560: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 000000168564: 02023489
	.long 0xd7000b1a                                           // 000000168568: D7000B1A
	v_cndmask_b32_e32 v1, v101, v26, vcc_lo                    // 00000016856C: 02023565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168570: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v102, v27, s11              // 000000168574: D5207C1B 002E3766
	global_load_b32 v4, v[26:27], off offset:128               // 00000016857C: DC520080 047C001A
	s_waitcnt vmcnt(0)                                         // 000000168584: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v28                         // 000000168588: 560838FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000168590: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168598: 8C7E0E7E
	ds_store_b16 v103, v4 offset:5128                          // 00000016859C: D87C1408 00000467
	s_and_saveexec_b32 s14, s6                                 // 0000001685A4: BE8E2006
	s_cbranch_execz 17                                         // 0000001685A8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23f0>
	v_mad_u64_u32 v[3:4], null, v108, 48, s[2:3]               // 0000001685AC: D6FE7C03 0009616C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001685B4: BF870091
	.long 0xd73c0003                                           // 0000001685B8: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001685BC: 02020689
	.long 0xd7000b03                                           // 0000001685C0: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 0000001685C4: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001685C8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 0000001685CC: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:128                 // 0000001685D4: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 0000001685DC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v29                         // 0000001685E0: 56063AFF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 0000001685E8: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001685F0: 8C7E0E7E
	.long 0x7f063880                                           // 0000001685F4: 7F063880
	ds_store_b16 v103, v3 offset:5132                          // 0000001685F8: D87C140C 00000367
	.long 0x7e083983                                           // 000000168600: 7E083983
	s_and_saveexec_b32 s14, s7                                 // 000000168604: BE8E2007
	s_cbranch_execz 17                                         // 000000168608: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2450>
	v_mad_u64_u32 v[26:27], null, v109, 48, s[2:3]             // 00000016860C: D6FE7C1A 0009616D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168614: BF870091
	.long 0xd73c001a                                           // 000000168618: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000016861C: 02023489
	.long 0xd7000b1a                                           // 000000168620: D7000B1A
	v_cndmask_b32_e32 v1, v101, v26, vcc_lo                    // 000000168624: 02023565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168628: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v102, v27, s11              // 00000016862C: D5207C1B 002E3766
	global_load_b32 v4, v[26:27], off offset:128               // 000000168634: DC520080 047C001A
	s_waitcnt vmcnt(0)                                         // 00000016863C: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v30                         // 000000168640: 56083CFF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000168648: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168650: 8C7E0E7E
	ds_store_b16 v103, v4 offset:5136                          // 000000168654: D87C1410 00000467
	s_and_saveexec_b32 s14, s8                                 // 00000016865C: BE8E2008
	s_cbranch_execz 17                                         // 000000168660: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x24a8>
	v_mad_u64_u32 v[3:4], null, v110, 48, s[2:3]               // 000000168664: D6FE7C03 0009616E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016866C: BF870091
	.long 0xd73c0003                                           // 000000168670: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000168674: 02020689
	.long 0xd7000b03                                           // 000000168678: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 00000016867C: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168680: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000168684: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:128                 // 00000016868C: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 000000168694: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v31                         // 000000168698: 56063EFF BB800000
	v_fma_mixhi_f16 v3, v3, s22, 0                             // 0000001686A0: CC220003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001686A8: 8C7E0E7E
	.long 0x7e063880                                           // 0000001686AC: 7E063880
	ds_store_b16_d16_hi v103, v3 offset:5140                   // 0000001686B0: DA841414 00000367
	.long 0x7e083903                                           // 0000001686B8: 7E083903
	s_and_saveexec_b32 s14, s9                                 // 0000001686BC: BE8E2009
	s_cbranch_execz 17                                         // 0000001686C0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2508>
	v_mad_u64_u32 v[26:27], null, v111, 48, s[2:3]             // 0000001686C4: D6FE7C1A 0009616F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001686CC: BF870091
	.long 0xd73c001a                                           // 0000001686D0: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 0000001686D4: 02023489
	.long 0xd7000b1a                                           // 0000001686D8: D7000B1A
	v_cndmask_b32_e32 v1, v101, v26, vcc_lo                    // 0000001686DC: 02023565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001686E0: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v102, v27, s11              // 0000001686E4: D5207C1B 002E3766
	global_load_b32 v4, v[26:27], off offset:128               // 0000001686EC: DC520080 047C001A
	s_waitcnt vmcnt(0)                                         // 0000001686F4: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v32                         // 0000001686F8: 560840FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000168700: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168708: 8C7E0E7E
	ds_store_b16 v103, v4 offset:5144                          // 00000016870C: D87C1418 00000467
	s_and_saveexec_b32 s14, s10                                // 000000168714: BE8E200A
	s_cbranch_execz 17                                         // 000000168718: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2560>
	v_mad_u64_u32 v[3:4], null, v112, 48, s[2:3]               // 00000016871C: D6FE7C03 00096170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168724: BF870091
	.long 0xd73c0003                                           // 000000168728: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016872C: 02020689
	.long 0xd7000b03                                           // 000000168730: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000168734: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168738: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 00000016873C: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:128                 // 000000168744: DC520080 037C0003
	s_waitcnt vmcnt(0)                                         // 00000016874C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v33                         // 000000168750: 560642FF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 000000168758: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168760: 8C7E0E7E
	.long 0x7f063880                                           // 000000168764: 7F063880
	ds_store_b16 v103, v3 offset:5148                          // 000000168768: D87C141C 00000367
	.long 0x7e083983                                           // 000000168770: 7E083983
	s_and_saveexec_b32 s14, s1                                 // 000000168774: BE8E2001
	s_cbranch_execz 17                                         // 000000168778: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25c0>
	v_mad_u64_u32 v[26:27], null, v7, 48, s[2:3]               // 00000016877C: D6FE7C1A 00096107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168784: BF870091
	.long 0xd73c001a                                           // 000000168788: D73C001A
	v_cndmask_b32_e32 v1, 9, v26, vcc_lo                       // 00000016878C: 02023489
	.long 0xd7000b1a                                           // 000000168790: D7000B1A
	v_cndmask_b32_e32 v1, v101, v26, vcc_lo                    // 000000168794: 02023565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168798: BF8700C1
	v_add_co_ci_u32_e64 v27, null, v102, v27, s11              // 00000016879C: D5207C1B 002E3766
	global_load_b32 v4, v[26:27], off offset:192               // 0000001687A4: DC5200C0 047C001A
	s_waitcnt vmcnt(0)                                         // 0000001687AC: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v18                         // 0000001687B0: 560824FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 0000001687B8: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001687C0: 8C7E0E7E
	ds_store_b16 v103, v4 offset:7680                          // 0000001687C4: D87C1E00 00000467
	s_and_saveexec_b32 s14, s4                                 // 0000001687CC: BE8E2004
	s_cbranch_execz 17                                         // 0000001687D0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2618>
	v_mad_u64_u32 v[3:4], null, v8, 48, s[2:3]                 // 0000001687D4: D6FE7C03 00096108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001687DC: BF870091
	.long 0xd73c0003                                           // 0000001687E0: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001687E4: 02020689
	.long 0xd7000b03                                           // 0000001687E8: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 0000001687EC: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001687F0: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 0000001687F4: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:192                 // 0000001687FC: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 000000168804: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v19                         // 000000168808: 560626FF BB800000
	v_fma_mixhi_f16 v3, v3, s22, 0                             // 000000168810: CC220003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168818: 8C7E0E7E
	.long 0x7e063880                                           // 00000016881C: 7E063880
	ds_store_b16_d16_hi v103, v3 offset:7684                   // 000000168820: DA841E04 00000367
	.long 0x7e083903                                           // 000000168828: 7E083903
	s_and_saveexec_b32 s14, s5                                 // 00000016882C: BE8E2005
	s_cbranch_execz 17                                         // 000000168830: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2678>
	v_mad_u64_u32 v[18:19], null, v9, 48, s[2:3]               // 000000168834: D6FE7C12 00096109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016883C: BF870091
	.long 0xd73c0012                                           // 000000168840: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 000000168844: 02022489
	.long 0xd7000b12                                           // 000000168848: D7000B12
	v_cndmask_b32_e32 v1, v101, v18, vcc_lo                    // 00000016884C: 02022565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168850: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v102, v19, s11              // 000000168854: D5207C13 002E2766
	global_load_b32 v4, v[18:19], off offset:192               // 00000016885C: DC5200C0 047C0012
	s_waitcnt vmcnt(0)                                         // 000000168864: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v20                         // 000000168868: 560828FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000168870: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168878: 8C7E0E7E
	ds_store_b16 v103, v4 offset:7688                          // 00000016887C: D87C1E08 00000467
	s_and_saveexec_b32 s14, s6                                 // 000000168884: BE8E2006
	s_cbranch_execz 17                                         // 000000168888: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26d0>
	v_mad_u64_u32 v[3:4], null, v108, 48, s[2:3]               // 00000016888C: D6FE7C03 0009616C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168894: BF870091
	.long 0xd73c0003                                           // 000000168898: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 00000016889C: 02020689
	.long 0xd7000b03                                           // 0000001688A0: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 0000001688A4: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001688A8: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 0000001688AC: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:192                 // 0000001688B4: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 0000001688BC: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v21                         // 0000001688C0: 56062AFF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 0000001688C8: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001688D0: 8C7E0E7E
	.long 0x7f063880                                           // 0000001688D4: 7F063880
	ds_store_b16 v103, v3 offset:7692                          // 0000001688D8: D87C1E0C 00000367
	.long 0x7e083983                                           // 0000001688E0: 7E083983
	s_and_saveexec_b32 s14, s7                                 // 0000001688E4: BE8E2007
	s_cbranch_execz 17                                         // 0000001688E8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2730>
	v_mad_u64_u32 v[18:19], null, v109, 48, s[2:3]             // 0000001688EC: D6FE7C12 0009616D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001688F4: BF870091
	.long 0xd73c0012                                           // 0000001688F8: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 0000001688FC: 02022489
	.long 0xd7000b12                                           // 000000168900: D7000B12
	v_cndmask_b32_e32 v1, v101, v18, vcc_lo                    // 000000168904: 02022565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168908: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v102, v19, s11              // 00000016890C: D5207C13 002E2766
	global_load_b32 v4, v[18:19], off offset:192               // 000000168914: DC5200C0 047C0012
	s_waitcnt vmcnt(0)                                         // 00000016891C: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v22                         // 000000168920: 56082CFF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 000000168928: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168930: 8C7E0E7E
	ds_store_b16 v103, v4 offset:7696                          // 000000168934: D87C1E10 00000467
	s_and_saveexec_b32 s14, s8                                 // 00000016893C: BE8E2008
	s_cbranch_execz 17                                         // 000000168940: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2788>
	v_mad_u64_u32 v[3:4], null, v110, 48, s[2:3]               // 000000168944: D6FE7C03 0009616E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016894C: BF870091
	.long 0xd73c0003                                           // 000000168950: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000168954: 02020689
	.long 0xd7000b03                                           // 000000168958: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 00000016895C: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168960: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000168964: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:192                 // 00000016896C: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 000000168974: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v23                         // 000000168978: 56062EFF BB800000
	v_fma_mixhi_f16 v3, v3, s22, 0                             // 000000168980: CC220003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168988: 8C7E0E7E
	.long 0x7e063880                                           // 00000016898C: 7E063880
	ds_store_b16_d16_hi v103, v3 offset:7700                   // 000000168990: DA841E14 00000367
	.long 0x7e083903                                           // 000000168998: 7E083903
	s_and_saveexec_b32 s14, s9                                 // 00000016899C: BE8E2009
	s_cbranch_execz 17                                         // 0000001689A0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27e8>
	v_mad_u64_u32 v[18:19], null, v111, 48, s[2:3]             // 0000001689A4: D6FE7C12 0009616F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001689AC: BF870091
	.long 0xd73c0012                                           // 0000001689B0: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 0000001689B4: 02022489
	.long 0xd7000b12                                           // 0000001689B8: D7000B12
	v_cndmask_b32_e32 v1, v101, v18, vcc_lo                    // 0000001689BC: 02022565
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001689C0: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v102, v19, s11              // 0000001689C4: D5207C13 002E2766
	global_load_b32 v4, v[18:19], off offset:192               // 0000001689CC: DC5200C0 047C0012
	s_waitcnt vmcnt(0)                                         // 0000001689D4: BF8903F7
	v_fmac_f32_e32 v4, 0xbb800000, v24                         // 0000001689D8: 560830FF BB800000
	v_fma_mixlo_f16 v4, v4, s22, 0                             // 0000001689E0: CC210004 02002D04
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001689E8: 8C7E0E7E
	ds_store_b16 v103, v4 offset:7704                          // 0000001689EC: D87C1E18 00000467
	s_and_saveexec_b32 s14, s10                                // 0000001689F4: BE8E200A
	s_cbranch_execz 17                                         // 0000001689F8: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2840>
	v_mad_u64_u32 v[3:4], null, v112, 48, s[2:3]               // 0000001689FC: D6FE7C03 00096170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000168A04: BF870091
	.long 0xd73c0003                                           // 000000168A08: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 000000168A0C: 02020689
	.long 0xd7000b03                                           // 000000168A10: D7000B03
	v_cndmask_b32_e32 v1, v101, v3, vcc_lo                     // 000000168A14: 02020765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000168A18: BF8700C1
	v_add_co_ci_u32_e64 v4, null, v102, v4, s11                // 000000168A1C: D5207C04 002E0966
	global_load_b32 v3, v[3:4], off offset:192                 // 000000168A24: DC5200C0 037C0003
	s_waitcnt vmcnt(0)                                         // 000000168A2C: BF8903F7
	v_fmac_f32_e32 v3, 0xbb800000, v25                         // 000000168A30: 560632FF BB800000
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 000000168A38: CC210003 02002D03
	s_or_b32 exec_lo, exec_lo, s14                             // 000000168A40: 8C7E0E7E
	.long 0x7f7a3880                                           // 000000168A44: 7F7A3880
	.long 0xd7000b04                                           // 000000168A48: D7000B04
	v_cndmask_b32_e32 v1, s12, v5, vcc_lo                      // 000000168A4C: 02020A0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000168A50: BF870191
	v_add_co_ci_u32_e64 v5, null, s13, v6, s11                 // 000000168A54: D5207C05 002E0C0D
	.long 0x7f7639bd                                           // 000000168A5C: 7F7639BD
	.long 0x7e7639bd                                           // 000000168A60: 7E7639BD
	.long 0x7f7439bd                                           // 000000168A64: 7F7439BD
	.long 0x7e7439bd                                           // 000000168A68: 7E7439BD
	ds_store_b16 v103, v3 offset:7708                          // 000000168A6C: D87C1E1C 00000367
	s_waitcnt lgkmcnt(0)                                       // 000000168A74: BF89FC07
	s_barrier                                                  // 000000168A78: BFBD0000
	buffer_gl0_inv                                             // 000000168A7C: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 000000168A84: BE8B2000
	s_cbranch_execz 11                                         // 000000168A88: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x28b8>
	global_load_b128 v[18:21], v[4:5], off                     // 000000168A8C: DC5E0000 127C0004
	s_waitcnt vmcnt(0)                                         // 000000168A94: BF8903F7
	v_fma_mixlo_f16 v58, v18, s22, 0                           // 000000168A98: CC21003A 02002D12
	v_fma_mixhi_f16 v58, v19, s22, 0                           // 000000168AA0: CC22003A 02002D13
	v_fma_mixlo_f16 v59, v20, s22, 0                           // 000000168AA8: CC21003B 02002D14
	v_fma_mixhi_f16 v59, v21, s22, 0                           // 000000168AB0: CC22003B 02002D15
	s_or_b32 exec_lo, exec_lo, s11                             // 000000168AB8: 8C7E0B7E
	.long 0x7e7a39bd                                           // 000000168ABC: 7E7A39BD
	.long 0x7f7839bd                                           // 000000168AC0: 7F7839BD
	.long 0x7e7839bd                                           // 000000168AC4: 7E7839BD
	s_and_saveexec_b32 s11, s0                                 // 000000168AC8: BE8B2000
	s_cbranch_execz 11                                         // 000000168ACC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x28fc>
	global_load_b128 v[18:21], v[4:5], off offset:16           // 000000168AD0: DC5E0010 127C0004
	s_waitcnt vmcnt(0)                                         // 000000168AD8: BF8903F7
	v_fma_mixlo_f16 v60, v18, s22, 0                           // 000000168ADC: CC21003C 02002D12
	v_fma_mixhi_f16 v60, v19, s22, 0                           // 000000168AE4: CC22003C 02002D13
	v_fma_mixlo_f16 v61, v20, s22, 0                           // 000000168AEC: CC21003D 02002D14
	v_fma_mixhi_f16 v61, v21, s22, 0                           // 000000168AF4: CC22003D 02002D15
	s_or_b32 exec_lo, exec_lo, s11                             // 000000168AFC: 8C7E0B7E
	.long 0x7f823880                                           // 000000168B00: 7F823880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000168B04: BF870001
	.long 0x7f7e39c1                                           // 000000168B08: 7F7E39C1
	.long 0x7e7e39c1                                           // 000000168B0C: 7E7E39C1
	.long 0x7f7c39c1                                           // 000000168B10: 7F7C39C1
	.long 0x7e7c39c1                                           // 000000168B14: 7E7C39C1
	s_and_saveexec_b32 s11, s0                                 // 000000168B18: BE8B2000
	s_cbranch_execz 11                                         // 000000168B1C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x294c>
	global_load_b128 v[18:21], v[4:5], off offset:32           // 000000168B20: DC5E0020 127C0004
	s_waitcnt vmcnt(0)                                         // 000000168B28: BF8903F7
	v_fma_mixlo_f16 v62, v18, s22, 0                           // 000000168B2C: CC21003E 02002D12
	v_fma_mixhi_f16 v62, v19, s22, 0                           // 000000168B34: CC22003E 02002D13
	v_fma_mixlo_f16 v63, v20, s22, 0                           // 000000168B3C: CC21003F 02002D14
	v_fma_mixhi_f16 v63, v21, s22, 0                           // 000000168B44: CC22003F 02002D15
	s_or_b32 exec_lo, exec_lo, s11                             // 000000168B4C: 8C7E0B7E
	.long 0x7e8239c1                                           // 000000168B50: 7E8239C1
	.long 0x7f8039c1                                           // 000000168B54: 7F8039C1
	.long 0x7e8039c1                                           // 000000168B58: 7E8039C1
	s_and_saveexec_b32 s11, s0                                 // 000000168B5C: BE8B2000
	s_cbranch_execz 11                                         // 000000168B60: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2990>
	global_load_b128 v[18:21], v[4:5], off offset:48           // 000000168B64: DC5E0030 127C0004
	s_waitcnt vmcnt(0)                                         // 000000168B6C: BF8903F7
	v_fma_mixlo_f16 v64, v18, s22, 0                           // 000000168B70: CC210040 02002D12
	v_fma_mixhi_f16 v64, v19, s22, 0                           // 000000168B78: CC220040 02002D13
	v_fma_mixlo_f16 v65, v20, s22, 0                           // 000000168B80: CC210041 02002D14
	v_fma_mixhi_f16 v65, v21, s22, 0                           // 000000168B88: CC220041 02002D15
	s_or_b32 exec_lo, exec_lo, s11                             // 000000168B90: 8C7E0B7E
	ds_load_b128 v[18:21], v94                                 // 000000168B94: DBFC0000 1200005E
	ds_load_b128 v[22:25], v94 offset:16                       // 000000168B9C: DBFC0010 1600005E
	ds_load_b128 v[26:29], v94 offset:8448                     // 000000168BA4: DBFC2100 1A00005E
	ds_load_b128 v[30:33], v94 offset:8464                     // 000000168BAC: DBFC2110 1E00005E
	ds_load_b128 v[50:53], v94 offset:16896                    // 000000168BB4: DBFC4200 3200005E
	ds_load_b128 v[54:57], v94 offset:16912                    // 000000168BBC: DBFC4210 3600005E
	ds_load_b128 v[74:77], v94 offset:25344                    // 000000168BC4: DBFC6300 4A00005E
	ds_load_b128 v[78:81], v94 offset:25360                    // 000000168BCC: DBFC6310 4E00005E
	v_dual_mov_b32 v73, s43 :: v_dual_mov_b32 v72, s42         // 000000168BD4: CA10002B 4948002A
	v_dual_mov_b32 v71, s41 :: v_dual_mov_b32 v70, s40         // 000000168BDC: CA100029 47460028
	v_dual_mov_b32 v69, s39 :: v_dual_mov_b32 v68, s38         // 000000168BE4: CA100027 45440026
	v_dual_mov_b32 v67, s37 :: v_dual_mov_b32 v66, s36         // 000000168BEC: CA100025 43420024
	s_waitcnt lgkmcnt(7)                                       // 000000168BF4: BF89FC77
	v_fma_mixlo_f16 v18, v18, s22, 0                           // 000000168BF8: CC210012 02002D12
	v_fma_mixhi_f16 v18, v19, s22, 0                           // 000000168C00: CC220012 02002D13
	v_fma_mixlo_f16 v19, v20, s22, 0                           // 000000168C08: CC210013 02002D14
	v_fma_mixhi_f16 v19, v21, s22, 0                           // 000000168C10: CC220013 02002D15
	s_waitcnt lgkmcnt(6)                                       // 000000168C18: BF89FC67
	v_fma_mixlo_f16 v20, v22, s22, 0                           // 000000168C1C: CC210014 02002D16
	v_fma_mixhi_f16 v20, v23, s22, 0                           // 000000168C24: CC220014 02002D17
	v_fma_mixlo_f16 v21, v24, s22, 0                           // 000000168C2C: CC210015 02002D18
	v_fma_mixhi_f16 v21, v25, s22, 0                           // 000000168C34: CC220015 02002D19
	v_dual_mov_b32 v22, v18 :: v_dual_mov_b32 v23, v19         // 000000168C3C: CA100112 16160113
	s_delay_alu instid0(VALU_DEP_4)                            // 000000168C44: BF870004
	v_mov_b32_e32 v24, v20                                     // 000000168C48: 7E300314
	s_waitcnt lgkmcnt(5)                                       // 000000168C4C: BF89FC57
	v_fma_mixlo_f16 v26, v26, s22, 0                           // 000000168C50: CC21001A 02002D1A
	v_mov_b32_e32 v25, v21                                     // 000000168C58: 7E320315
	v_fma_mixhi_f16 v26, v27, s22, 0                           // 000000168C5C: CC22001A 02002D1B
	v_fma_mixlo_f16 v27, v28, s22, 0                           // 000000168C64: CC21001B 02002D1C
	v_fma_mixhi_f16 v27, v29, s22, 0                           // 000000168C6C: CC22001B 02002D1D
	s_waitcnt lgkmcnt(4)                                       // 000000168C74: BF89FC47
	v_fma_mixlo_f16 v28, v30, s22, 0                           // 000000168C78: CC21001C 02002D1E
	v_fma_mixhi_f16 v28, v31, s22, 0                           // 000000168C80: CC22001C 02002D1F
	v_fma_mixlo_f16 v29, v32, s22, 0                           // 000000168C88: CC21001D 02002D20
	v_fma_mixhi_f16 v29, v33, s22, 0                           // 000000168C90: CC22001D 02002D21
	v_wmma_f32_16x16x16_f16 v[42:49], v[58:65], v[18:25], v[66:73]// 000000168C98: CC40402A 1D0A253A
	s_waitcnt lgkmcnt(3)                                       // 000000168CA0: BF89FC37
	v_fma_mixlo_f16 v18, v50, s22, 0                           // 000000168CA4: CC210012 02002D32
	v_fma_mixhi_f16 v18, v51, s22, 0                           // 000000168CAC: CC220012 02002D33
	v_fma_mixlo_f16 v19, v52, s22, 0                           // 000000168CB4: CC210013 02002D34
	v_fma_mixhi_f16 v19, v53, s22, 0                           // 000000168CBC: CC220013 02002D35
	s_waitcnt lgkmcnt(2)                                       // 000000168CC4: BF89FC27
	v_fma_mixlo_f16 v20, v54, s22, 0                           // 000000168CC8: CC210014 02002D36
	v_fma_mixhi_f16 v20, v55, s22, 0                           // 000000168CD0: CC220014 02002D37
	v_fma_mixlo_f16 v21, v56, s22, 0                           // 000000168CD8: CC210015 02002D38
	v_fma_mixhi_f16 v21, v57, s22, 0                           // 000000168CE0: CC220015 02002D39
	s_waitcnt lgkmcnt(1)                                       // 000000168CE8: BF89FC17
	v_fma_mixlo_f16 v74, v74, s22, 0                           // 000000168CEC: CC21004A 02002D4A
	v_fma_mixhi_f16 v74, v75, s22, 0                           // 000000168CF4: CC22004A 02002D4B
	v_fma_mixlo_f16 v75, v76, s22, 0                           // 000000168CFC: CC21004B 02002D4C
	v_fma_mixhi_f16 v75, v77, s22, 0                           // 000000168D04: CC22004B 02002D4D
	s_waitcnt lgkmcnt(0)                                       // 000000168D0C: BF89FC07
	v_fma_mixlo_f16 v76, v78, s22, 0                           // 000000168D10: CC21004C 02002D4E
	v_fma_mixhi_f16 v76, v79, s22, 0                           // 000000168D18: CC22004C 02002D4F
	v_fma_mixlo_f16 v77, v80, s22, 0                           // 000000168D20: CC21004D 02002D50
	v_fma_mixhi_f16 v77, v81, s22, 0                           // 000000168D28: CC22004D 02002D51
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v31, v27         // 000000168D30: CA10011A 1E1E011B
	v_dual_mov_b32 v32, v28 :: v_dual_mov_b32 v33, v29         // 000000168D38: CA10011C 2020011D
	v_dual_mov_b32 v22, v18 :: v_dual_mov_b32 v23, v19         // 000000168D40: CA100112 16160113
	v_dual_mov_b32 v24, v20 :: v_dual_mov_b32 v25, v21         // 000000168D48: CA100114 18180115
	v_dual_mov_b32 v78, v74 :: v_dual_mov_b32 v79, v75         // 000000168D50: CA10014A 4E4E014B
	v_dual_mov_b32 v80, v76 :: v_dual_mov_b32 v81, v77         // 000000168D58: CA10014C 5050014D
	.long 0x7f723880                                           // 000000168D60: 7F723880
	v_wmma_f32_16x16x16_f16 v[34:41], v[58:65], v[26:33], v[66:73]// 000000168D64: CC404022 1D0A353A
	v_wmma_f32_16x16x16_f16 v[26:33], v[58:65], v[18:25], v[66:73]// 000000168D6C: CC40401A 1D0A253A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000168D74: BF870214
	v_wmma_f32_16x16x16_f16 v[18:25], v[58:65], v[74:81], v[66:73]// 000000168D78: CC404012 1D0A953A
	.long 0x7f6e39b9                                           // 000000168D80: 7F6E39B9
	.long 0x7e6e39b9                                           // 000000168D84: 7E6E39B9
	.long 0x7f6c39b9                                           // 000000168D88: 7F6C39B9
	.long 0x7e6c39b9                                           // 000000168D8C: 7E6C39B9
	s_and_saveexec_b32 s11, s0                                 // 000000168D90: BE8B2000
	s_cbranch_execz 11                                         // 000000168D94: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2bc4>
	global_load_b128 v[50:53], v[4:5], off offset:64           // 000000168D98: DC5E0040 327C0004
	s_waitcnt vmcnt(0)                                         // 000000168DA0: BF8903F7
	v_fma_mixlo_f16 v54, v50, s22, 0                           // 000000168DA4: CC210036 02002D32
	v_fma_mixhi_f16 v54, v51, s22, 0                           // 000000168DAC: CC220036 02002D33
	v_fma_mixlo_f16 v55, v52, s22, 0                           // 000000168DB4: CC210037 02002D34
	v_fma_mixhi_f16 v55, v53, s22, 0                           // 000000168DBC: CC220037 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 000000168DC4: 8C7E0B7E
	.long 0x7e7239b9                                           // 000000168DC8: 7E7239B9
	.long 0x7f7039b9                                           // 000000168DCC: 7F7039B9
	.long 0x7e7039b9                                           // 000000168DD0: 7E7039B9
	s_and_saveexec_b32 s11, s0                                 // 000000168DD4: BE8B2000
	s_cbranch_execz 11                                         // 000000168DD8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c08>
	global_load_b128 v[50:53], v[4:5], off offset:80           // 000000168DDC: DC5E0050 327C0004
	s_waitcnt vmcnt(0)                                         // 000000168DE4: BF8903F7
	v_fma_mixlo_f16 v56, v50, s22, 0                           // 000000168DE8: CC210038 02002D32
	v_fma_mixhi_f16 v56, v51, s22, 0                           // 000000168DF0: CC220038 02002D33
	v_fma_mixlo_f16 v57, v52, s22, 0                           // 000000168DF8: CC210039 02002D34
	v_fma_mixhi_f16 v57, v53, s22, 0                           // 000000168E00: CC220039 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 000000168E08: 8C7E0B7E
	.long 0x7f7a3880                                           // 000000168E0C: 7F7A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000168E10: BF870001
	.long 0x7f7639bd                                           // 000000168E14: 7F7639BD
	.long 0x7e7639bd                                           // 000000168E18: 7E7639BD
	.long 0x7f7439bd                                           // 000000168E1C: 7F7439BD
	.long 0x7e7439bd                                           // 000000168E20: 7E7439BD
	s_and_saveexec_b32 s11, s0                                 // 000000168E24: BE8B2000
	s_cbranch_execz 11                                         // 000000168E28: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c58>
	global_load_b128 v[50:53], v[4:5], off offset:96           // 000000168E2C: DC5E0060 327C0004
	s_waitcnt vmcnt(0)                                         // 000000168E34: BF8903F7
	v_fma_mixlo_f16 v58, v50, s22, 0                           // 000000168E38: CC21003A 02002D32
	v_fma_mixhi_f16 v58, v51, s22, 0                           // 000000168E40: CC22003A 02002D33
	v_fma_mixlo_f16 v59, v52, s22, 0                           // 000000168E48: CC21003B 02002D34
	v_fma_mixhi_f16 v59, v53, s22, 0                           // 000000168E50: CC22003B 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 000000168E58: 8C7E0B7E
	.long 0x7e7a39bd                                           // 000000168E5C: 7E7A39BD
	.long 0x7f7839bd                                           // 000000168E60: 7F7839BD
	.long 0x7e7839bd                                           // 000000168E64: 7E7839BD
	s_and_saveexec_b32 s11, s0                                 // 000000168E68: BE8B2000
	s_cbranch_execz 11                                         // 000000168E6C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c9c>
	global_load_b128 v[50:53], v[4:5], off offset:112          // 000000168E70: DC5E0070 327C0004
	s_waitcnt vmcnt(0)                                         // 000000168E78: BF8903F7
	v_fma_mixlo_f16 v60, v50, s22, 0                           // 000000168E7C: CC21003C 02002D32
	v_fma_mixhi_f16 v60, v51, s22, 0                           // 000000168E84: CC22003C 02002D33
	v_fma_mixlo_f16 v61, v52, s22, 0                           // 000000168E8C: CC21003D 02002D34
	v_fma_mixhi_f16 v61, v53, s22, 0                           // 000000168E94: CC22003D 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 000000168E9C: 8C7E0B7E
	ds_load_b128 v[50:53], v94 offset:64                       // 000000168EA0: DBFC0040 3200005E
	ds_load_b128 v[64:67], v94 offset:80                       // 000000168EA8: DBFC0050 4000005E
	ds_load_b128 v[70:73], v94 offset:8512                     // 000000168EB0: DBFC2140 4600005E
	ds_load_b128 v[74:77], v94 offset:8528                     // 000000168EB8: DBFC2150 4A00005E
	ds_load_b128 v[78:81], v94 offset:16960                    // 000000168EC0: DBFC4240 4E00005E
	ds_load_b128 v[115:118], v94 offset:16976                  // 000000168EC8: DBFC4250 7300005E
	ds_load_b128 v[121:124], v94 offset:25408                  // 000000168ED0: DBFC6340 7900005E
	s_waitcnt lgkmcnt(6)                                       // 000000168ED8: BF89FC67
	v_fma_mixlo_f16 v62, v50, s22, 0                           // 000000168EDC: CC21003E 02002D32
	v_fma_mixhi_f16 v62, v51, s22, 0                           // 000000168EE4: CC22003E 02002D33
	v_fma_mixlo_f16 v63, v52, s22, 0                           // 000000168EEC: CC21003F 02002D34
	v_fma_mixhi_f16 v63, v53, s22, 0                           // 000000168EF4: CC22003F 02002D35
	ds_load_b128 v[50:53], v94 offset:25424                    // 000000168EFC: DBFC6350 3200005E
	s_waitcnt lgkmcnt(6)                                       // 000000168F04: BF89FC67
	v_fma_mixlo_f16 v64, v64, s22, 0                           // 000000168F08: CC210040 02002D40
	v_fma_mixhi_f16 v64, v65, s22, 0                           // 000000168F10: CC220040 02002D41
	v_fma_mixlo_f16 v65, v66, s22, 0                           // 000000168F18: CC210041 02002D42
	v_fma_mixhi_f16 v65, v67, s22, 0                           // 000000168F20: CC220041 02002D43
	s_waitcnt lgkmcnt(5)                                       // 000000168F28: BF89FC57
	v_fma_mixlo_f16 v70, v70, s22, 0                           // 000000168F2C: CC210046 02002D46
	v_fma_mixhi_f16 v70, v71, s22, 0                           // 000000168F34: CC220046 02002D47
	v_fma_mixlo_f16 v71, v72, s22, 0                           // 000000168F3C: CC210047 02002D48
	v_fma_mixhi_f16 v71, v73, s22, 0                           // 000000168F44: CC220047 02002D49
	s_waitcnt lgkmcnt(4)                                       // 000000168F4C: BF89FC47
	v_fma_mixlo_f16 v72, v74, s22, 0                           // 000000168F50: CC210048 02002D4A
	v_fma_mixhi_f16 v72, v75, s22, 0                           // 000000168F58: CC220048 02002D4B
	v_fma_mixlo_f16 v73, v76, s22, 0                           // 000000168F60: CC210049 02002D4C
	v_fma_mixhi_f16 v73, v77, s22, 0                           // 000000168F68: CC220049 02002D4D
	s_waitcnt lgkmcnt(3)                                       // 000000168F70: BF89FC37
	v_fma_mixlo_f16 v113, v78, s22, 0                          // 000000168F74: CC210071 02002D4E
	v_fma_mixhi_f16 v113, v79, s22, 0                          // 000000168F7C: CC220071 02002D4F
	v_fma_mixlo_f16 v114, v80, s22, 0                          // 000000168F84: CC210072 02002D50
	v_fma_mixhi_f16 v114, v81, s22, 0                          // 000000168F8C: CC220072 02002D51
	s_waitcnt lgkmcnt(2)                                       // 000000168F94: BF89FC27
	v_fma_mixlo_f16 v115, v115, s22, 0                         // 000000168F98: CC210073 02002D73
	v_fma_mixhi_f16 v115, v116, s22, 0                         // 000000168FA0: CC220073 02002D74
	v_fma_mixlo_f16 v116, v117, s22, 0                         // 000000168FA8: CC210074 02002D75
	v_fma_mixhi_f16 v116, v118, s22, 0                         // 000000168FB0: CC220074 02002D76
	s_waitcnt lgkmcnt(1)                                       // 000000168FB8: BF89FC17
	v_fma_mixlo_f16 v121, v121, s22, 0                         // 000000168FBC: CC210079 02002D79
	v_fma_mixhi_f16 v121, v122, s22, 0                         // 000000168FC4: CC220079 02002D7A
	v_fma_mixlo_f16 v122, v123, s22, 0                         // 000000168FCC: CC21007A 02002D7B
	v_fma_mixhi_f16 v122, v124, s22, 0                         // 000000168FD4: CC22007A 02002D7C
	s_waitcnt lgkmcnt(0)                                       // 000000168FDC: BF89FC07
	v_fma_mixlo_f16 v123, v50, s22, 0                          // 000000168FE0: CC21007B 02002D32
	v_fma_mixhi_f16 v123, v51, s22, 0                          // 000000168FE8: CC22007B 02002D33
	v_fma_mixlo_f16 v124, v52, s22, 0                          // 000000168FF0: CC21007C 02002D34
	v_fma_mixhi_f16 v124, v53, s22, 0                          // 000000168FF8: CC22007C 02002D35
	v_dual_mov_b32 v66, v62 :: v_dual_mov_b32 v67, v63         // 000000169000: CA10013E 4242013F
	v_dual_mov_b32 v68, v64 :: v_dual_mov_b32 v69, v65         // 000000169008: CA100140 44440141
	v_dual_mov_b32 v74, v70 :: v_dual_mov_b32 v75, v71         // 000000169010: CA100146 4A4A0147
	v_dual_mov_b32 v76, v72 :: v_dual_mov_b32 v77, v73         // 000000169018: CA100148 4C4C0149
	v_dual_mov_b32 v117, v113 :: v_dual_mov_b32 v118, v114     // 000000169020: CA100171 75760172
	v_dual_mov_b32 v119, v115 :: v_dual_mov_b32 v120, v116     // 000000169028: CA100173 77780174
	v_dual_mov_b32 v125, v121 :: v_dual_mov_b32 v126, v122     // 000000169030: CA100179 7D7E017A
	v_dual_mov_b32 v127, v123 :: v_dual_mov_b32 v128, v124     // 000000169038: CA10017B 7F80017C
	.long 0x7f6a3880                                           // 000000169040: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[54:61], v[62:69], v[42:49]// 000000169044: CC40402A 1CAA7D36
	v_wmma_f32_16x16x16_f16 v[34:41], v[54:61], v[70:77], v[34:41]// 00000016904C: CC404022 1C8A8D36
	v_wmma_f32_16x16x16_f16 v[26:33], v[54:61], v[113:120], v[26:33]// 000000169054: CC40401A 1C6AE336
	v_wmma_f32_16x16x16_f16 v[18:25], v[54:61], v[121:128], v[18:25]// 00000016905C: CC404012 1C4AF336
	.long 0x7f6639b5                                           // 000000169064: 7F6639B5
	.long 0x7e6639b5                                           // 000000169068: 7E6639B5
	.long 0x7f6439b5                                           // 00000016906C: 7F6439B5
	.long 0x7e6439b5                                           // 000000169070: 7E6439B5
	s_and_saveexec_b32 s11, s0                                 // 000000169074: BE8B2000
	s_cbranch_execz 11                                         // 000000169078: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ea8>
	global_load_b128 v[54:57], v[4:5], off offset:128          // 00000016907C: DC5E0080 367C0004
	s_waitcnt vmcnt(0)                                         // 000000169084: BF8903F7
	v_fma_mixlo_f16 v50, v54, s22, 0                           // 000000169088: CC210032 02002D36
	v_fma_mixhi_f16 v50, v55, s22, 0                           // 000000169090: CC220032 02002D37
	v_fma_mixlo_f16 v51, v56, s22, 0                           // 000000169098: CC210033 02002D38
	v_fma_mixhi_f16 v51, v57, s22, 0                           // 0000001690A0: CC220033 02002D39
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001690A8: 8C7E0B7E
	.long 0x7e6a39b5                                           // 0000001690AC: 7E6A39B5
	.long 0x7f6839b5                                           // 0000001690B0: 7F6839B5
	.long 0x7e6839b5                                           // 0000001690B4: 7E6839B5
	s_and_saveexec_b32 s11, s0                                 // 0000001690B8: BE8B2000
	s_cbranch_execz 11                                         // 0000001690BC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2eec>
	global_load_b128 v[52:55], v[4:5], off offset:144          // 0000001690C0: DC5E0090 347C0004
	s_waitcnt vmcnt(0)                                         // 0000001690C8: BF8903F7
	v_fma_mixlo_f16 v52, v52, s22, 0                           // 0000001690CC: CC210034 02002D34
	v_fma_mixhi_f16 v52, v53, s22, 0                           // 0000001690D4: CC220034 02002D35
	v_fma_mixlo_f16 v53, v54, s22, 0                           // 0000001690DC: CC210035 02002D36
	v_fma_mixhi_f16 v53, v55, s22, 0                           // 0000001690E4: CC220035 02002D37
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001690EC: 8C7E0B7E
	.long 0x7f723880                                           // 0000001690F0: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001690F4: BF870001
	.long 0x7f6e39b9                                           // 0000001690F8: 7F6E39B9
	.long 0x7e6e39b9                                           // 0000001690FC: 7E6E39B9
	.long 0x7f6c39b9                                           // 000000169100: 7F6C39B9
	.long 0x7e6c39b9                                           // 000000169104: 7E6C39B9
	s_and_saveexec_b32 s11, s0                                 // 000000169108: BE8B2000
	s_cbranch_execz 11                                         // 00000016910C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2f3c>
	global_load_b128 v[58:61], v[4:5], off offset:160          // 000000169110: DC5E00A0 3A7C0004
	s_waitcnt vmcnt(0)                                         // 000000169118: BF8903F7
	v_fma_mixlo_f16 v54, v58, s22, 0                           // 00000016911C: CC210036 02002D3A
	v_fma_mixhi_f16 v54, v59, s22, 0                           // 000000169124: CC220036 02002D3B
	v_fma_mixlo_f16 v55, v60, s22, 0                           // 00000016912C: CC210037 02002D3C
	v_fma_mixhi_f16 v55, v61, s22, 0                           // 000000169134: CC220037 02002D3D
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016913C: 8C7E0B7E
	.long 0x7e7239b9                                           // 000000169140: 7E7239B9
	.long 0x7f7039b9                                           // 000000169144: 7F7039B9
	.long 0x7e7039b9                                           // 000000169148: 7E7039B9
	s_and_saveexec_b32 s11, s0                                 // 00000016914C: BE8B2000
	s_cbranch_execz 11                                         // 000000169150: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2f80>
	global_load_b128 v[56:59], v[4:5], off offset:176          // 000000169154: DC5E00B0 387C0004
	s_waitcnt vmcnt(0)                                         // 00000016915C: BF8903F7
	v_fma_mixlo_f16 v56, v56, s22, 0                           // 000000169160: CC210038 02002D38
	v_fma_mixhi_f16 v56, v57, s22, 0                           // 000000169168: CC220038 02002D39
	v_fma_mixlo_f16 v57, v58, s22, 0                           // 000000169170: CC210039 02002D3A
	v_fma_mixhi_f16 v57, v59, s22, 0                           // 000000169178: CC220039 02002D3B
	s_or_b32 exec_lo, exec_lo, s11                             // 000000169180: 8C7E0B7E
	ds_load_b128 v[59:62], v94 offset:128                      // 000000169184: DBFC0080 3B00005E
	ds_load_b128 v[63:66], v94 offset:144                      // 00000016918C: DBFC0090 3F00005E
	ds_load_b128 v[67:70], v94 offset:8576                     // 000000169194: DBFC2180 4300005E
	ds_load_b128 v[71:74], v94 offset:8592                     // 00000016919C: DBFC2190 4700005E
	ds_load_b128 v[75:78], v94 offset:17024                    // 0000001691A4: DBFC4280 4B00005E
	ds_load_b128 v[115:118], v94 offset:17040                  // 0000001691AC: DBFC4290 7300005E
	ds_load_b128 v[121:124], v94 offset:25472                  // 0000001691B4: DBFC6380 7900005E
	ds_load_b128 v[125:128], v94 offset:25488                  // 0000001691BC: DBFC6390 7D00005E
	.long 0x7f743880                                           // 0000001691C4: 7F743880
	s_waitcnt lgkmcnt(7)                                       // 0000001691C8: BF89FC77
	v_fma_mixlo_f16 v59, v59, s22, 0                           // 0000001691CC: CC21003B 02002D3B
	v_fma_mixhi_f16 v59, v60, s22, 0                           // 0000001691D4: CC22003B 02002D3C
	v_fma_mixlo_f16 v60, v61, s22, 0                           // 0000001691DC: CC21003C 02002D3D
	v_fma_mixhi_f16 v60, v62, s22, 0                           // 0000001691E4: CC22003C 02002D3E
	s_waitcnt lgkmcnt(6)                                       // 0000001691EC: BF89FC67
	v_fma_mixlo_f16 v61, v63, s22, 0                           // 0000001691F0: CC21003D 02002D3F
	v_fma_mixhi_f16 v61, v64, s22, 0                           // 0000001691F8: CC22003D 02002D40
	v_fma_mixlo_f16 v62, v65, s22, 0                           // 000000169200: CC21003E 02002D41
	v_fma_mixhi_f16 v62, v66, s22, 0                           // 000000169208: CC22003E 02002D42
	s_waitcnt lgkmcnt(5)                                       // 000000169210: BF89FC57
	v_fma_mixlo_f16 v67, v67, s22, 0                           // 000000169214: CC210043 02002D43
	v_fma_mixhi_f16 v67, v68, s22, 0                           // 00000016921C: CC220043 02002D44
	v_fma_mixlo_f16 v68, v69, s22, 0                           // 000000169224: CC210044 02002D45
	v_fma_mixhi_f16 v68, v70, s22, 0                           // 00000016922C: CC220044 02002D46
	s_waitcnt lgkmcnt(4)                                       // 000000169234: BF89FC47
	v_fma_mixlo_f16 v69, v71, s22, 0                           // 000000169238: CC210045 02002D47
	v_fma_mixhi_f16 v69, v72, s22, 0                           // 000000169240: CC220045 02002D48
	v_fma_mixlo_f16 v70, v73, s22, 0                           // 000000169248: CC210046 02002D49
	v_fma_mixhi_f16 v70, v74, s22, 0                           // 000000169250: CC220046 02002D4A
	s_waitcnt lgkmcnt(3)                                       // 000000169258: BF89FC37
	v_fma_mixlo_f16 v113, v75, s22, 0                          // 00000016925C: CC210071 02002D4B
	v_fma_mixhi_f16 v113, v76, s22, 0                          // 000000169264: CC220071 02002D4C
	v_fma_mixlo_f16 v114, v77, s22, 0                          // 00000016926C: CC210072 02002D4D
	v_fma_mixhi_f16 v114, v78, s22, 0                          // 000000169274: CC220072 02002D4E
	s_waitcnt lgkmcnt(2)                                       // 00000016927C: BF89FC27
	v_fma_mixlo_f16 v115, v115, s22, 0                         // 000000169280: CC210073 02002D73
	v_fma_mixhi_f16 v115, v116, s22, 0                         // 000000169288: CC220073 02002D74
	v_fma_mixlo_f16 v116, v117, s22, 0                         // 000000169290: CC210074 02002D75
	v_fma_mixhi_f16 v116, v118, s22, 0                         // 000000169298: CC220074 02002D76
	s_waitcnt lgkmcnt(1)                                       // 0000001692A0: BF89FC17
	v_fma_mixlo_f16 v121, v121, s22, 0                         // 0000001692A4: CC210079 02002D79
	v_fma_mixhi_f16 v121, v122, s22, 0                         // 0000001692AC: CC220079 02002D7A
	v_fma_mixlo_f16 v122, v123, s22, 0                         // 0000001692B4: CC21007A 02002D7B
	v_fma_mixhi_f16 v122, v124, s22, 0                         // 0000001692BC: CC22007A 02002D7C
	s_waitcnt lgkmcnt(0)                                       // 0000001692C4: BF89FC07
	v_fma_mixlo_f16 v123, v125, s22, 0                         // 0000001692C8: CC21007B 02002D7D
	v_fma_mixhi_f16 v123, v126, s22, 0                         // 0000001692D0: CC22007B 02002D7E
	v_fma_mixlo_f16 v124, v127, s22, 0                         // 0000001692D8: CC21007C 02002D7F
	v_fma_mixhi_f16 v124, v128, s22, 0                         // 0000001692E0: CC22007C 02002D80
	v_dual_mov_b32 v63, v59 :: v_dual_mov_b32 v64, v60         // 0000001692E8: CA10013B 3F40013C
	v_dual_mov_b32 v65, v61 :: v_dual_mov_b32 v66, v62         // 0000001692F0: CA10013D 4142013E
	v_dual_mov_b32 v71, v67 :: v_dual_mov_b32 v72, v68         // 0000001692F8: CA100143 47480144
	v_dual_mov_b32 v73, v69 :: v_dual_mov_b32 v74, v70         // 000000169300: CA100145 494A0146
	v_dual_mov_b32 v117, v113 :: v_dual_mov_b32 v118, v114     // 000000169308: CA100171 75760172
	v_dual_mov_b32 v119, v115 :: v_dual_mov_b32 v120, v116     // 000000169310: CA100173 77780174
	v_dual_mov_b32 v125, v121 :: v_dual_mov_b32 v126, v122     // 000000169318: CA100179 7D7E017A
	v_dual_mov_b32 v127, v123 :: v_dual_mov_b32 v128, v124     // 000000169320: CA10017B 7F80017C
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[59:66], v[42:49]// 000000169328: CC40402A 1CAA7732
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[67:74], v[34:41]// 000000169330: CC404022 1C8A8732
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[113:120], v[26:33]// 000000169338: CC40401A 1C6AE332
	s_delay_alu instid0(VALU_DEP_4)                            // 000000169340: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[121:128], v[18:25]// 000000169344: CC404012 1C4AF332
	.long 0x7f7039ba                                           // 00000016934C: 7F7039BA
	.long 0x7e7039ba                                           // 000000169350: 7E7039BA
	.long 0x7f6e39ba                                           // 000000169354: 7F6E39BA
	.long 0x7e6e39ba                                           // 000000169358: 7E6E39BA
	s_and_saveexec_b32 s11, s0                                 // 00000016935C: BE8B2000
	s_cbranch_execz 11                                         // 000000169360: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3190>
	global_load_b128 v[50:53], v[4:5], off offset:192          // 000000169364: DC5E00C0 327C0004
	s_waitcnt vmcnt(0)                                         // 00000016936C: BF8903F7
	v_fma_mixlo_f16 v55, v50, s22, 0                           // 000000169370: CC210037 02002D32
	v_fma_mixhi_f16 v55, v51, s22, 0                           // 000000169378: CC220037 02002D33
	v_fma_mixlo_f16 v56, v52, s22, 0                           // 000000169380: CC210038 02002D34
	v_fma_mixhi_f16 v56, v53, s22, 0                           // 000000169388: CC220038 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 000000169390: 8C7E0B7E
	.long 0x7e7439ba                                           // 000000169394: 7E7439BA
	.long 0x7f7239ba                                           // 000000169398: 7F7239BA
	.long 0x7e7239ba                                           // 00000016939C: 7E7239BA
	s_and_saveexec_b32 s11, s0                                 // 0000001693A0: BE8B2000
	s_cbranch_execz 11                                         // 0000001693A4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x31d4>
	global_load_b128 v[50:53], v[4:5], off offset:208          // 0000001693A8: DC5E00D0 327C0004
	s_waitcnt vmcnt(0)                                         // 0000001693B0: BF8903F7
	v_fma_mixlo_f16 v57, v50, s22, 0                           // 0000001693B4: CC210039 02002D32
	v_fma_mixhi_f16 v57, v51, s22, 0                           // 0000001693BC: CC220039 02002D33
	v_fma_mixlo_f16 v58, v52, s22, 0                           // 0000001693C4: CC21003A 02002D34
	v_fma_mixhi_f16 v58, v53, s22, 0                           // 0000001693CC: CC22003A 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001693D4: 8C7E0B7E
	.long 0x7f7c3880                                           // 0000001693D8: 7F7C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001693DC: BF870001
	.long 0x7f7839be                                           // 0000001693E0: 7F7839BE
	.long 0x7e7839be                                           // 0000001693E4: 7E7839BE
	.long 0x7f7639be                                           // 0000001693E8: 7F7639BE
	.long 0x7e7639be                                           // 0000001693EC: 7E7639BE
	s_and_saveexec_b32 s11, s0                                 // 0000001693F0: BE8B2000
	s_cbranch_execz 11                                         // 0000001693F4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3224>
	global_load_b128 v[50:53], v[4:5], off offset:224          // 0000001693F8: DC5E00E0 327C0004
	s_waitcnt vmcnt(0)                                         // 000000169400: BF8903F7
	v_fma_mixlo_f16 v59, v50, s22, 0                           // 000000169404: CC21003B 02002D32
	v_fma_mixhi_f16 v59, v51, s22, 0                           // 00000016940C: CC22003B 02002D33
	v_fma_mixlo_f16 v60, v52, s22, 0                           // 000000169414: CC21003C 02002D34
	v_fma_mixhi_f16 v60, v53, s22, 0                           // 00000016941C: CC22003C 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 000000169424: 8C7E0B7E
	.long 0x7e7c39be                                           // 000000169428: 7E7C39BE
	.long 0x7f7a39be                                           // 00000016942C: 7F7A39BE
	.long 0x7e7a39be                                           // 000000169430: 7E7A39BE
	s_and_saveexec_b32 s11, s0                                 // 000000169434: BE8B2000
	s_cbranch_execz 11                                         // 000000169438: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3268>
	global_load_b128 v[50:53], v[4:5], off offset:240          // 00000016943C: DC5E00F0 327C0004
	s_waitcnt vmcnt(0)                                         // 000000169444: BF8903F7
	v_fma_mixlo_f16 v61, v50, s22, 0                           // 000000169448: CC21003D 02002D32
	v_fma_mixhi_f16 v61, v51, s22, 0                           // 000000169450: CC22003D 02002D33
	v_fma_mixlo_f16 v62, v52, s22, 0                           // 000000169458: CC21003E 02002D34
	v_fma_mixhi_f16 v62, v53, s22, 0                           // 000000169460: CC22003E 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 000000169468: 8C7E0B7E
	ds_load_b128 v[50:53], v94 offset:192                      // 00000016946C: DBFC00C0 3200005E
	ds_load_b128 v[65:68], v94 offset:208                      // 000000169474: DBFC00D0 4100005E
	ds_load_b128 v[71:74], v94 offset:8640                     // 00000016947C: DBFC21C0 4700005E
	ds_load_b128 v[75:78], v94 offset:8656                     // 000000169484: DBFC21D0 4B00005E
	ds_load_b128 v[113:116], v94 offset:17088                  // 00000016948C: DBFC42C0 7100005E
	ds_load_b128 v[117:120], v94 offset:17104                  // 000000169494: DBFC42D0 7500005E
	ds_load_b128 v[121:124], v94 offset:25536                  // 00000016949C: DBFC63C0 7900005E
	s_waitcnt lgkmcnt(6)                                       // 0000001694A4: BF89FC67
	v_fma_mixlo_f16 v63, v50, s22, 0                           // 0000001694A8: CC21003F 02002D32
	v_fma_mixhi_f16 v63, v51, s22, 0                           // 0000001694B0: CC22003F 02002D33
	v_fma_mixlo_f16 v64, v52, s22, 0                           // 0000001694B8: CC210040 02002D34
	v_fma_mixhi_f16 v64, v53, s22, 0                           // 0000001694C0: CC220040 02002D35
	ds_load_b128 v[50:53], v94 offset:25552                    // 0000001694C8: DBFC63D0 3200005E
	s_waitcnt lgkmcnt(6)                                       // 0000001694D0: BF89FC67
	v_fma_mixlo_f16 v65, v65, s22, 0                           // 0000001694D4: CC210041 02002D41
	v_fma_mixhi_f16 v65, v66, s22, 0                           // 0000001694DC: CC220041 02002D42
	v_fma_mixlo_f16 v66, v67, s22, 0                           // 0000001694E4: CC210042 02002D43
	v_fma_mixhi_f16 v66, v68, s22, 0                           // 0000001694EC: CC220042 02002D44
	s_waitcnt lgkmcnt(5)                                       // 0000001694F4: BF89FC57
	v_fma_mixlo_f16 v71, v71, s22, 0                           // 0000001694F8: CC210047 02002D47
	v_fma_mixhi_f16 v71, v72, s22, 0                           // 000000169500: CC220047 02002D48
	v_fma_mixlo_f16 v72, v73, s22, 0                           // 000000169508: CC210048 02002D49
	v_fma_mixhi_f16 v72, v74, s22, 0                           // 000000169510: CC220048 02002D4A
	s_waitcnt lgkmcnt(4)                                       // 000000169518: BF89FC47
	v_fma_mixlo_f16 v73, v75, s22, 0                           // 00000016951C: CC210049 02002D4B
	v_fma_mixhi_f16 v73, v76, s22, 0                           // 000000169524: CC220049 02002D4C
	v_fma_mixlo_f16 v74, v77, s22, 0                           // 00000016952C: CC21004A 02002D4D
	v_fma_mixhi_f16 v74, v78, s22, 0                           // 000000169534: CC22004A 02002D4E
	s_waitcnt lgkmcnt(3)                                       // 00000016953C: BF89FC37
	v_fma_mixlo_f16 v113, v113, s22, 0                         // 000000169540: CC210071 02002D71
	v_fma_mixhi_f16 v113, v114, s22, 0                         // 000000169548: CC220071 02002D72
	v_fma_mixlo_f16 v114, v115, s22, 0                         // 000000169550: CC210072 02002D73
	v_fma_mixhi_f16 v114, v116, s22, 0                         // 000000169558: CC220072 02002D74
	s_waitcnt lgkmcnt(2)                                       // 000000169560: BF89FC27
	v_fma_mixlo_f16 v115, v117, s22, 0                         // 000000169564: CC210073 02002D75
	v_fma_mixhi_f16 v115, v118, s22, 0                         // 00000016956C: CC220073 02002D76
	v_fma_mixlo_f16 v116, v119, s22, 0                         // 000000169574: CC210074 02002D77
	v_fma_mixhi_f16 v116, v120, s22, 0                         // 00000016957C: CC220074 02002D78
	s_waitcnt lgkmcnt(1)                                       // 000000169584: BF89FC17
	v_fma_mixlo_f16 v121, v121, s22, 0                         // 000000169588: CC210079 02002D79
	v_fma_mixhi_f16 v121, v122, s22, 0                         // 000000169590: CC220079 02002D7A
	v_fma_mixlo_f16 v122, v123, s22, 0                         // 000000169598: CC21007A 02002D7B
	v_fma_mixhi_f16 v122, v124, s22, 0                         // 0000001695A0: CC22007A 02002D7C
	s_waitcnt lgkmcnt(0)                                       // 0000001695A8: BF89FC07
	v_fma_mixlo_f16 v123, v50, s22, 0                          // 0000001695AC: CC21007B 02002D32
	v_fma_mixhi_f16 v123, v51, s22, 0                          // 0000001695B4: CC22007B 02002D33
	v_fma_mixlo_f16 v124, v52, s22, 0                          // 0000001695BC: CC21007C 02002D34
	v_fma_mixhi_f16 v124, v53, s22, 0                          // 0000001695C4: CC22007C 02002D35
	v_dual_mov_b32 v67, v63 :: v_dual_mov_b32 v68, v64         // 0000001695CC: CA10013F 43440140
	v_dual_mov_b32 v69, v65 :: v_dual_mov_b32 v70, v66         // 0000001695D4: CA100141 45460142
	v_dual_mov_b32 v75, v71 :: v_dual_mov_b32 v76, v72         // 0000001695DC: CA100147 4B4C0148
	v_dual_mov_b32 v77, v73 :: v_dual_mov_b32 v78, v74         // 0000001695E4: CA100149 4D4E014A
	v_dual_mov_b32 v117, v113 :: v_dual_mov_b32 v118, v114     // 0000001695EC: CA100171 75760172
	v_dual_mov_b32 v119, v115 :: v_dual_mov_b32 v120, v116     // 0000001695F4: CA100173 77780174
	v_dual_mov_b32 v125, v121 :: v_dual_mov_b32 v126, v122     // 0000001695FC: CA100179 7D7E017A
	v_dual_mov_b32 v127, v123 :: v_dual_mov_b32 v128, v124     // 000000169604: CA10017B 7F80017C
	.long 0x7f6a3880                                           // 00000016960C: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[55:62], v[63:70], v[42:49]// 000000169610: CC40402A 1CAA7F37
	v_wmma_f32_16x16x16_f16 v[34:41], v[55:62], v[71:78], v[34:41]// 000000169618: CC404022 1C8A8F37
	v_wmma_f32_16x16x16_f16 v[26:33], v[55:62], v[113:120], v[26:33]// 000000169620: CC40401A 1C6AE337
	v_wmma_f32_16x16x16_f16 v[18:25], v[55:62], v[121:128], v[18:25]// 000000169628: CC404012 1C4AF337
	.long 0x7f6639b5                                           // 000000169630: 7F6639B5
	.long 0x7e6639b5                                           // 000000169634: 7E6639B5
	.long 0x7f6439b5                                           // 000000169638: 7F6439B5
	.long 0x7e6439b5                                           // 00000016963C: 7E6439B5
	s_and_saveexec_b32 s11, s0                                 // 000000169640: BE8B2000
	s_cbranch_execz 11                                         // 000000169644: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3474>
	global_load_b128 v[54:57], v[4:5], off offset:256          // 000000169648: DC5E0100 367C0004
	s_waitcnt vmcnt(0)                                         // 000000169650: BF8903F7
	v_fma_mixlo_f16 v50, v54, s22, 0                           // 000000169654: CC210032 02002D36
	v_fma_mixhi_f16 v50, v55, s22, 0                           // 00000016965C: CC220032 02002D37
	v_fma_mixlo_f16 v51, v56, s22, 0                           // 000000169664: CC210033 02002D38
	v_fma_mixhi_f16 v51, v57, s22, 0                           // 00000016966C: CC220033 02002D39
	s_or_b32 exec_lo, exec_lo, s11                             // 000000169674: 8C7E0B7E
	.long 0x7e6a39b5                                           // 000000169678: 7E6A39B5
	.long 0x7f6839b5                                           // 00000016967C: 7F6839B5
	.long 0x7e6839b5                                           // 000000169680: 7E6839B5
	s_and_saveexec_b32 s11, s0                                 // 000000169684: BE8B2000
	s_cbranch_execz 11                                         // 000000169688: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x34b8>
	global_load_b128 v[52:55], v[4:5], off offset:272          // 00000016968C: DC5E0110 347C0004
	s_waitcnt vmcnt(0)                                         // 000000169694: BF8903F7
	v_fma_mixlo_f16 v52, v52, s22, 0                           // 000000169698: CC210034 02002D34
	v_fma_mixhi_f16 v52, v53, s22, 0                           // 0000001696A0: CC220034 02002D35
	v_fma_mixlo_f16 v53, v54, s22, 0                           // 0000001696A8: CC210035 02002D36
	v_fma_mixhi_f16 v53, v55, s22, 0                           // 0000001696B0: CC220035 02002D37
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001696B8: 8C7E0B7E
	.long 0x7f723880                                           // 0000001696BC: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001696C0: BF870001
	.long 0x7f6e39b9                                           // 0000001696C4: 7F6E39B9
	.long 0x7e6e39b9                                           // 0000001696C8: 7E6E39B9
	.long 0x7f6c39b9                                           // 0000001696CC: 7F6C39B9
	.long 0x7e6c39b9                                           // 0000001696D0: 7E6C39B9
	s_and_saveexec_b32 s11, s0                                 // 0000001696D4: BE8B2000
	s_cbranch_execz 11                                         // 0000001696D8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3508>
	global_load_b128 v[58:61], v[4:5], off offset:288          // 0000001696DC: DC5E0120 3A7C0004
	s_waitcnt vmcnt(0)                                         // 0000001696E4: BF8903F7
	v_fma_mixlo_f16 v54, v58, s22, 0                           // 0000001696E8: CC210036 02002D3A
	v_fma_mixhi_f16 v54, v59, s22, 0                           // 0000001696F0: CC220036 02002D3B
	v_fma_mixlo_f16 v55, v60, s22, 0                           // 0000001696F8: CC210037 02002D3C
	v_fma_mixhi_f16 v55, v61, s22, 0                           // 000000169700: CC220037 02002D3D
	s_or_b32 exec_lo, exec_lo, s11                             // 000000169708: 8C7E0B7E
	.long 0x7e7239b9                                           // 00000016970C: 7E7239B9
	.long 0x7f7039b9                                           // 000000169710: 7F7039B9
	.long 0x7e7039b9                                           // 000000169714: 7E7039B9
	s_and_saveexec_b32 s11, s0                                 // 000000169718: BE8B2000
	s_cbranch_execz 11                                         // 00000016971C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x354c>
	global_load_b128 v[56:59], v[4:5], off offset:304          // 000000169720: DC5E0130 387C0004
	s_waitcnt vmcnt(0)                                         // 000000169728: BF8903F7
	v_fma_mixlo_f16 v56, v56, s22, 0                           // 00000016972C: CC210038 02002D38
	v_fma_mixhi_f16 v56, v57, s22, 0                           // 000000169734: CC220038 02002D39
	v_fma_mixlo_f16 v57, v58, s22, 0                           // 00000016973C: CC210039 02002D3A
	v_fma_mixhi_f16 v57, v59, s22, 0                           // 000000169744: CC220039 02002D3B
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016974C: 8C7E0B7E
	ds_load_b128 v[59:62], v94 offset:256                      // 000000169750: DBFC0100 3B00005E
	ds_load_b128 v[63:66], v94 offset:272                      // 000000169758: DBFC0110 3F00005E
	ds_load_b128 v[67:70], v94 offset:8704                     // 000000169760: DBFC2200 4300005E
	ds_load_b128 v[71:74], v94 offset:8720                     // 000000169768: DBFC2210 4700005E
	ds_load_b128 v[75:78], v94 offset:17152                    // 000000169770: DBFC4300 4B00005E
	ds_load_b128 v[115:118], v94 offset:17168                  // 000000169778: DBFC4310 7300005E
	ds_load_b128 v[121:124], v94 offset:25600                  // 000000169780: DBFC6400 7900005E
	ds_load_b128 v[125:128], v94 offset:25616                  // 000000169788: DBFC6410 7D00005E
	.long 0x7f743880                                           // 000000169790: 7F743880
	s_waitcnt lgkmcnt(7)                                       // 000000169794: BF89FC77
	v_fma_mixlo_f16 v59, v59, s22, 0                           // 000000169798: CC21003B 02002D3B
	v_fma_mixhi_f16 v59, v60, s22, 0                           // 0000001697A0: CC22003B 02002D3C
	v_fma_mixlo_f16 v60, v61, s22, 0                           // 0000001697A8: CC21003C 02002D3D
	v_fma_mixhi_f16 v60, v62, s22, 0                           // 0000001697B0: CC22003C 02002D3E
	s_waitcnt lgkmcnt(6)                                       // 0000001697B8: BF89FC67
	v_fma_mixlo_f16 v61, v63, s22, 0                           // 0000001697BC: CC21003D 02002D3F
	v_fma_mixhi_f16 v61, v64, s22, 0                           // 0000001697C4: CC22003D 02002D40
	v_fma_mixlo_f16 v62, v65, s22, 0                           // 0000001697CC: CC21003E 02002D41
	v_fma_mixhi_f16 v62, v66, s22, 0                           // 0000001697D4: CC22003E 02002D42
	s_waitcnt lgkmcnt(5)                                       // 0000001697DC: BF89FC57
	v_fma_mixlo_f16 v67, v67, s22, 0                           // 0000001697E0: CC210043 02002D43
	v_fma_mixhi_f16 v67, v68, s22, 0                           // 0000001697E8: CC220043 02002D44
	v_fma_mixlo_f16 v68, v69, s22, 0                           // 0000001697F0: CC210044 02002D45
	v_fma_mixhi_f16 v68, v70, s22, 0                           // 0000001697F8: CC220044 02002D46
	s_waitcnt lgkmcnt(4)                                       // 000000169800: BF89FC47
	v_fma_mixlo_f16 v69, v71, s22, 0                           // 000000169804: CC210045 02002D47
	v_fma_mixhi_f16 v69, v72, s22, 0                           // 00000016980C: CC220045 02002D48
	v_fma_mixlo_f16 v70, v73, s22, 0                           // 000000169814: CC210046 02002D49
	v_fma_mixhi_f16 v70, v74, s22, 0                           // 00000016981C: CC220046 02002D4A
	s_waitcnt lgkmcnt(3)                                       // 000000169824: BF89FC37
	v_fma_mixlo_f16 v113, v75, s22, 0                          // 000000169828: CC210071 02002D4B
	v_fma_mixhi_f16 v113, v76, s22, 0                          // 000000169830: CC220071 02002D4C
	v_fma_mixlo_f16 v114, v77, s22, 0                          // 000000169838: CC210072 02002D4D
	v_fma_mixhi_f16 v114, v78, s22, 0                          // 000000169840: CC220072 02002D4E
	s_waitcnt lgkmcnt(2)                                       // 000000169848: BF89FC27
	v_fma_mixlo_f16 v115, v115, s22, 0                         // 00000016984C: CC210073 02002D73
	v_fma_mixhi_f16 v115, v116, s22, 0                         // 000000169854: CC220073 02002D74
	v_fma_mixlo_f16 v116, v117, s22, 0                         // 00000016985C: CC210074 02002D75
	v_fma_mixhi_f16 v116, v118, s22, 0                         // 000000169864: CC220074 02002D76
	s_waitcnt lgkmcnt(1)                                       // 00000016986C: BF89FC17
	v_fma_mixlo_f16 v121, v121, s22, 0                         // 000000169870: CC210079 02002D79
	v_fma_mixhi_f16 v121, v122, s22, 0                         // 000000169878: CC220079 02002D7A
	v_fma_mixlo_f16 v122, v123, s22, 0                         // 000000169880: CC21007A 02002D7B
	v_fma_mixhi_f16 v122, v124, s22, 0                         // 000000169888: CC22007A 02002D7C
	s_waitcnt lgkmcnt(0)                                       // 000000169890: BF89FC07
	v_fma_mixlo_f16 v123, v125, s22, 0                         // 000000169894: CC21007B 02002D7D
	v_fma_mixhi_f16 v123, v126, s22, 0                         // 00000016989C: CC22007B 02002D7E
	v_fma_mixlo_f16 v124, v127, s22, 0                         // 0000001698A4: CC21007C 02002D7F
	v_fma_mixhi_f16 v124, v128, s22, 0                         // 0000001698AC: CC22007C 02002D80
	v_dual_mov_b32 v63, v59 :: v_dual_mov_b32 v64, v60         // 0000001698B4: CA10013B 3F40013C
	v_dual_mov_b32 v65, v61 :: v_dual_mov_b32 v66, v62         // 0000001698BC: CA10013D 4142013E
	v_dual_mov_b32 v71, v67 :: v_dual_mov_b32 v72, v68         // 0000001698C4: CA100143 47480144
	v_dual_mov_b32 v73, v69 :: v_dual_mov_b32 v74, v70         // 0000001698CC: CA100145 494A0146
	v_dual_mov_b32 v117, v113 :: v_dual_mov_b32 v118, v114     // 0000001698D4: CA100171 75760172
	v_dual_mov_b32 v119, v115 :: v_dual_mov_b32 v120, v116     // 0000001698DC: CA100173 77780174
	v_dual_mov_b32 v125, v121 :: v_dual_mov_b32 v126, v122     // 0000001698E4: CA100179 7D7E017A
	v_dual_mov_b32 v127, v123 :: v_dual_mov_b32 v128, v124     // 0000001698EC: CA10017B 7F80017C
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[59:66], v[42:49]// 0000001698F4: CC40402A 1CAA7732
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[67:74], v[34:41]// 0000001698FC: CC404022 1C8A8732
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[113:120], v[26:33]// 000000169904: CC40401A 1C6AE332
	s_delay_alu instid0(VALU_DEP_4)                            // 00000016990C: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[121:128], v[18:25]// 000000169910: CC404012 1C4AF332
	.long 0x7f7039ba                                           // 000000169918: 7F7039BA
	.long 0x7e7039ba                                           // 00000016991C: 7E7039BA
	.long 0x7f6e39ba                                           // 000000169920: 7F6E39BA
	.long 0x7e6e39ba                                           // 000000169924: 7E6E39BA
	s_and_saveexec_b32 s11, s0                                 // 000000169928: BE8B2000
	s_cbranch_execz 11                                         // 00000016992C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x375c>
	global_load_b128 v[50:53], v[4:5], off offset:320          // 000000169930: DC5E0140 327C0004
	s_waitcnt vmcnt(0)                                         // 000000169938: BF8903F7
	v_fma_mixlo_f16 v55, v50, s22, 0                           // 00000016993C: CC210037 02002D32
	v_fma_mixhi_f16 v55, v51, s22, 0                           // 000000169944: CC220037 02002D33
	v_fma_mixlo_f16 v56, v52, s22, 0                           // 00000016994C: CC210038 02002D34
	v_fma_mixhi_f16 v56, v53, s22, 0                           // 000000169954: CC220038 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016995C: 8C7E0B7E
	.long 0x7e7439ba                                           // 000000169960: 7E7439BA
	.long 0x7f7239ba                                           // 000000169964: 7F7239BA
	.long 0x7e7239ba                                           // 000000169968: 7E7239BA
	s_and_saveexec_b32 s11, s0                                 // 00000016996C: BE8B2000
	s_cbranch_execz 11                                         // 000000169970: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x37a0>
	global_load_b128 v[50:53], v[4:5], off offset:336          // 000000169974: DC5E0150 327C0004
	s_waitcnt vmcnt(0)                                         // 00000016997C: BF8903F7
	v_fma_mixlo_f16 v57, v50, s22, 0                           // 000000169980: CC210039 02002D32
	v_fma_mixhi_f16 v57, v51, s22, 0                           // 000000169988: CC220039 02002D33
	v_fma_mixlo_f16 v58, v52, s22, 0                           // 000000169990: CC21003A 02002D34
	v_fma_mixhi_f16 v58, v53, s22, 0                           // 000000169998: CC22003A 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001699A0: 8C7E0B7E
	.long 0x7f7c3880                                           // 0000001699A4: 7F7C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001699A8: BF870001
	.long 0x7f7839be                                           // 0000001699AC: 7F7839BE
	.long 0x7e7839be                                           // 0000001699B0: 7E7839BE
	.long 0x7f7639be                                           // 0000001699B4: 7F7639BE
	.long 0x7e7639be                                           // 0000001699B8: 7E7639BE
	s_and_saveexec_b32 s11, s0                                 // 0000001699BC: BE8B2000
	s_cbranch_execz 11                                         // 0000001699C0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x37f0>
	global_load_b128 v[50:53], v[4:5], off offset:352          // 0000001699C4: DC5E0160 327C0004
	s_waitcnt vmcnt(0)                                         // 0000001699CC: BF8903F7
	v_fma_mixlo_f16 v59, v50, s22, 0                           // 0000001699D0: CC21003B 02002D32
	v_fma_mixhi_f16 v59, v51, s22, 0                           // 0000001699D8: CC22003B 02002D33
	v_fma_mixlo_f16 v60, v52, s22, 0                           // 0000001699E0: CC21003C 02002D34
	v_fma_mixhi_f16 v60, v53, s22, 0                           // 0000001699E8: CC22003C 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001699F0: 8C7E0B7E
	.long 0x7e7c39be                                           // 0000001699F4: 7E7C39BE
	.long 0x7f7a39be                                           // 0000001699F8: 7F7A39BE
	.long 0x7e7a39be                                           // 0000001699FC: 7E7A39BE
	s_and_saveexec_b32 s11, s0                                 // 000000169A00: BE8B2000
	s_cbranch_execz 11                                         // 000000169A04: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3834>
	global_load_b128 v[50:53], v[4:5], off offset:368          // 000000169A08: DC5E0170 327C0004
	s_waitcnt vmcnt(0)                                         // 000000169A10: BF8903F7
	v_fma_mixlo_f16 v61, v50, s22, 0                           // 000000169A14: CC21003D 02002D32
	v_fma_mixhi_f16 v61, v51, s22, 0                           // 000000169A1C: CC22003D 02002D33
	v_fma_mixlo_f16 v62, v52, s22, 0                           // 000000169A24: CC21003E 02002D34
	v_fma_mixhi_f16 v62, v53, s22, 0                           // 000000169A2C: CC22003E 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 000000169A34: 8C7E0B7E
	ds_load_b128 v[50:53], v94 offset:320                      // 000000169A38: DBFC0140 3200005E
	ds_load_b128 v[66:69], v94 offset:336                      // 000000169A40: DBFC0150 4200005E
	ds_load_b128 v[72:75], v94 offset:8768                     // 000000169A48: DBFC2240 4800005E
	ds_load_b128 v[76:79], v94 offset:8784                     // 000000169A50: DBFC2250 4C00005E
	ds_load_b128 v[113:116], v94 offset:17216                  // 000000169A58: DBFC4340 7100005E
	ds_load_b128 v[117:120], v94 offset:17232                  // 000000169A60: DBFC4350 7500005E
	ds_load_b128 v[121:124], v94 offset:25664                  // 000000169A68: DBFC6440 7900005E
	.long 0x7f7e3880                                           // 000000169A70: 7F7E3880
	s_waitcnt lgkmcnt(6)                                       // 000000169A74: BF89FC67
	v_fma_mixlo_f16 v64, v50, s22, 0                           // 000000169A78: CC210040 02002D32
	v_fma_mixhi_f16 v64, v51, s22, 0                           // 000000169A80: CC220040 02002D33
	v_fma_mixlo_f16 v65, v52, s22, 0                           // 000000169A88: CC210041 02002D34
	v_fma_mixhi_f16 v65, v53, s22, 0                           // 000000169A90: CC220041 02002D35
	ds_load_b128 v[50:53], v94 offset:25680                    // 000000169A98: DBFC6450 3200005E
	s_waitcnt lgkmcnt(6)                                       // 000000169AA0: BF89FC67
	v_fma_mixlo_f16 v66, v66, s22, 0                           // 000000169AA4: CC210042 02002D42
	v_fma_mixhi_f16 v66, v67, s22, 0                           // 000000169AAC: CC220042 02002D43
	v_fma_mixlo_f16 v67, v68, s22, 0                           // 000000169AB4: CC210043 02002D44
	v_fma_mixhi_f16 v67, v69, s22, 0                           // 000000169ABC: CC220043 02002D45
	s_waitcnt lgkmcnt(5)                                       // 000000169AC4: BF89FC57
	v_fma_mixlo_f16 v72, v72, s22, 0                           // 000000169AC8: CC210048 02002D48
	v_fma_mixhi_f16 v72, v73, s22, 0                           // 000000169AD0: CC220048 02002D49
	v_fma_mixlo_f16 v73, v74, s22, 0                           // 000000169AD8: CC210049 02002D4A
	v_fma_mixhi_f16 v73, v75, s22, 0                           // 000000169AE0: CC220049 02002D4B
	s_waitcnt lgkmcnt(4)                                       // 000000169AE8: BF89FC47
	v_fma_mixlo_f16 v74, v76, s22, 0                           // 000000169AEC: CC21004A 02002D4C
	v_fma_mixhi_f16 v74, v77, s22, 0                           // 000000169AF4: CC22004A 02002D4D
	v_fma_mixlo_f16 v75, v78, s22, 0                           // 000000169AFC: CC21004B 02002D4E
	v_fma_mixhi_f16 v75, v79, s22, 0                           // 000000169B04: CC22004B 02002D4F
	s_waitcnt lgkmcnt(3)                                       // 000000169B0C: BF89FC37
	v_fma_mixlo_f16 v113, v113, s22, 0                         // 000000169B10: CC210071 02002D71
	v_fma_mixhi_f16 v113, v114, s22, 0                         // 000000169B18: CC220071 02002D72
	v_fma_mixlo_f16 v114, v115, s22, 0                         // 000000169B20: CC210072 02002D73
	v_fma_mixhi_f16 v114, v116, s22, 0                         // 000000169B28: CC220072 02002D74
	s_waitcnt lgkmcnt(2)                                       // 000000169B30: BF89FC27
	v_fma_mixlo_f16 v115, v117, s22, 0                         // 000000169B34: CC210073 02002D75
	v_fma_mixhi_f16 v115, v118, s22, 0                         // 000000169B3C: CC220073 02002D76
	v_fma_mixlo_f16 v116, v119, s22, 0                         // 000000169B44: CC210074 02002D77
	v_fma_mixhi_f16 v116, v120, s22, 0                         // 000000169B4C: CC220074 02002D78
	s_waitcnt lgkmcnt(1)                                       // 000000169B54: BF89FC17
	v_fma_mixlo_f16 v121, v121, s22, 0                         // 000000169B58: CC210079 02002D79
	v_fma_mixhi_f16 v121, v122, s22, 0                         // 000000169B60: CC220079 02002D7A
	v_fma_mixlo_f16 v122, v123, s22, 0                         // 000000169B68: CC21007A 02002D7B
	v_fma_mixhi_f16 v122, v124, s22, 0                         // 000000169B70: CC22007A 02002D7C
	s_waitcnt lgkmcnt(0)                                       // 000000169B78: BF89FC07
	v_fma_mixlo_f16 v123, v50, s22, 0                          // 000000169B7C: CC21007B 02002D32
	v_fma_mixhi_f16 v123, v51, s22, 0                          // 000000169B84: CC22007B 02002D33
	v_fma_mixlo_f16 v124, v52, s22, 0                          // 000000169B8C: CC21007C 02002D34
	v_fma_mixhi_f16 v124, v53, s22, 0                          // 000000169B94: CC22007C 02002D35
	v_dual_mov_b32 v68, v64 :: v_dual_mov_b32 v69, v65         // 000000169B9C: CA100140 44440141
	v_dual_mov_b32 v70, v66 :: v_dual_mov_b32 v71, v67         // 000000169BA4: CA100142 46460143
	v_dual_mov_b32 v76, v72 :: v_dual_mov_b32 v77, v73         // 000000169BAC: CA100148 4C4C0149
	v_dual_mov_b32 v78, v74 :: v_dual_mov_b32 v79, v75         // 000000169BB4: CA10014A 4E4E014B
	v_dual_mov_b32 v117, v113 :: v_dual_mov_b32 v118, v114     // 000000169BBC: CA100171 75760172
	v_dual_mov_b32 v119, v115 :: v_dual_mov_b32 v120, v116     // 000000169BC4: CA100173 77780174
	v_dual_mov_b32 v125, v121 :: v_dual_mov_b32 v126, v122     // 000000169BCC: CA100179 7D7E017A
	v_dual_mov_b32 v127, v123 :: v_dual_mov_b32 v128, v124     // 000000169BD4: CA10017B 7F80017C
	v_wmma_f32_16x16x16_f16 v[42:49], v[55:62], v[64:71], v[42:49]// 000000169BDC: CC40402A 1CAA8137
	v_wmma_f32_16x16x16_f16 v[34:41], v[55:62], v[72:79], v[34:41]// 000000169BE4: CC404022 1C8A9137
	v_wmma_f32_16x16x16_f16 v[26:33], v[55:62], v[113:120], v[26:33]// 000000169BEC: CC40401A 1C6AE337
	s_delay_alu instid0(VALU_DEP_4)                            // 000000169BF4: BF870004
	v_wmma_f32_16x16x16_f16 v[18:25], v[55:62], v[121:128], v[18:25]// 000000169BF8: CC404012 1C4AF337
	.long 0x7f7a39bf                                           // 000000169C00: 7F7A39BF
	.long 0x7e7a39bf                                           // 000000169C04: 7E7A39BF
	.long 0x7f7839bf                                           // 000000169C08: 7F7839BF
	.long 0x7e7839bf                                           // 000000169C0C: 7E7839BF
	s_and_saveexec_b32 s11, s0                                 // 000000169C10: BE8B2000
	s_cbranch_execz 11                                         // 000000169C14: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a44>
	global_load_b128 v[50:53], v[4:5], off offset:384          // 000000169C18: DC5E0180 327C0004
	s_waitcnt vmcnt(0)                                         // 000000169C20: BF8903F7
	v_fma_mixlo_f16 v60, v50, s22, 0                           // 000000169C24: CC21003C 02002D32
	v_fma_mixhi_f16 v60, v51, s22, 0                           // 000000169C2C: CC22003C 02002D33
	v_fma_mixlo_f16 v61, v52, s22, 0                           // 000000169C34: CC21003D 02002D34
	v_fma_mixhi_f16 v61, v53, s22, 0                           // 000000169C3C: CC22003D 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 000000169C44: 8C7E0B7E
	.long 0x7e7e39bf                                           // 000000169C48: 7E7E39BF
	.long 0x7f7c39bf                                           // 000000169C4C: 7F7C39BF
	.long 0x7e7c39bf                                           // 000000169C50: 7E7C39BF
	s_and_saveexec_b32 s11, s0                                 // 000000169C54: BE8B2000
	s_cbranch_execz 11                                         // 000000169C58: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a88>
	global_load_b128 v[50:53], v[4:5], off offset:400          // 000000169C5C: DC5E0190 327C0004
	s_waitcnt vmcnt(0)                                         // 000000169C64: BF8903F7
	v_fma_mixlo_f16 v62, v50, s22, 0                           // 000000169C68: CC21003E 02002D32
	v_fma_mixhi_f16 v62, v51, s22, 0                           // 000000169C70: CC22003E 02002D33
	v_fma_mixlo_f16 v63, v52, s22, 0                           // 000000169C78: CC21003F 02002D34
	v_fma_mixhi_f16 v63, v53, s22, 0                           // 000000169C80: CC22003F 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 000000169C88: 8C7E0B7E
	.long 0x7f863880                                           // 000000169C8C: 7F863880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000169C90: BF870001
	.long 0x7f8239c3                                           // 000000169C94: 7F8239C3
	.long 0x7e8239c3                                           // 000000169C98: 7E8239C3
	.long 0x7f8039c3                                           // 000000169C9C: 7F8039C3
	.long 0x7e8039c3                                           // 000000169CA0: 7E8039C3
	s_and_saveexec_b32 s11, s0                                 // 000000169CA4: BE8B2000
	s_cbranch_execz 11                                         // 000000169CA8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ad8>
	global_load_b128 v[50:53], v[4:5], off offset:416          // 000000169CAC: DC5E01A0 327C0004
	s_waitcnt vmcnt(0)                                         // 000000169CB4: BF8903F7
	v_fma_mixlo_f16 v64, v50, s22, 0                           // 000000169CB8: CC210040 02002D32
	v_fma_mixhi_f16 v64, v51, s22, 0                           // 000000169CC0: CC220040 02002D33
	v_fma_mixlo_f16 v65, v52, s22, 0                           // 000000169CC8: CC210041 02002D34
	v_fma_mixhi_f16 v65, v53, s22, 0                           // 000000169CD0: CC220041 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 000000169CD8: 8C7E0B7E
	.long 0x7e8639c3                                           // 000000169CDC: 7E8639C3
	.long 0x7f8439c3                                           // 000000169CE0: 7F8439C3
	.long 0x7e8439c3                                           // 000000169CE4: 7E8439C3
	s_and_saveexec_b32 s11, s0                                 // 000000169CE8: BE8B2000
	s_cbranch_execz 11                                         // 000000169CEC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b1c>
	global_load_b128 v[50:53], v[4:5], off offset:432          // 000000169CF0: DC5E01B0 327C0004
	s_waitcnt vmcnt(0)                                         // 000000169CF8: BF8903F7
	v_fma_mixlo_f16 v66, v50, s22, 0                           // 000000169CFC: CC210042 02002D32
	v_fma_mixhi_f16 v66, v51, s22, 0                           // 000000169D04: CC220042 02002D33
	v_fma_mixlo_f16 v67, v52, s22, 0                           // 000000169D0C: CC210043 02002D34
	v_fma_mixhi_f16 v67, v53, s22, 0                           // 000000169D14: CC220043 02002D35
	s_or_b32 exec_lo, exec_lo, s11                             // 000000169D1C: 8C7E0B7E
	ds_load_b128 v[50:53], v94 offset:384                      // 000000169D20: DBFC0180 3200005E
	ds_load_b128 v[54:57], v94 offset:400                      // 000000169D28: DBFC0190 3600005E
	ds_load_b128 v[72:75], v94 offset:8832                     // 000000169D30: DBFC2280 4800005E
	ds_load_b128 v[76:79], v94 offset:8848                     // 000000169D38: DBFC2290 4C00005E
	ds_load_b128 v[121:124], v94 offset:17280                  // 000000169D40: DBFC4380 7900005E
	ds_load_b128 v[125:128], v94 offset:17296                  // 000000169D48: DBFC4390 7D00005E
	ds_load_b128 v[129:132], v94 offset:25728                  // 000000169D50: DBFC6480 8100005E
	s_waitcnt lgkmcnt(6)                                       // 000000169D58: BF89FC67
	v_fma_mixlo_f16 v68, v50, s22, 0                           // 000000169D5C: CC210044 02002D32
	v_fma_mixhi_f16 v68, v51, s22, 0                           // 000000169D64: CC220044 02002D33
	v_fma_mixlo_f16 v69, v52, s22, 0                           // 000000169D6C: CC210045 02002D34
	v_fma_mixhi_f16 v69, v53, s22, 0                           // 000000169D74: CC220045 02002D35
	ds_load_b128 v[50:53], v94 offset:25744                    // 000000169D7C: DBFC6490 3200005E
	s_waitcnt lgkmcnt(6)                                       // 000000169D84: BF89FC67
	v_fma_mixlo_f16 v70, v54, s22, 0                           // 000000169D88: CC210046 02002D36
	v_fma_mixhi_f16 v70, v55, s22, 0                           // 000000169D90: CC220046 02002D37
	v_fma_mixlo_f16 v71, v56, s22, 0                           // 000000169D98: CC210047 02002D38
	v_fma_mixhi_f16 v71, v57, s22, 0                           // 000000169DA0: CC220047 02002D39
	s_waitcnt lgkmcnt(5)                                       // 000000169DA8: BF89FC57
	v_fma_mixlo_f16 v113, v72, s22, 0                          // 000000169DAC: CC210071 02002D48
	v_fma_mixhi_f16 v113, v73, s22, 0                          // 000000169DB4: CC220071 02002D49
	v_fma_mixlo_f16 v114, v74, s22, 0                          // 000000169DBC: CC210072 02002D4A
	v_fma_mixhi_f16 v114, v75, s22, 0                          // 000000169DC4: CC220072 02002D4B
	s_waitcnt lgkmcnt(4)                                       // 000000169DCC: BF89FC47
	v_fma_mixlo_f16 v115, v76, s22, 0                          // 000000169DD0: CC210073 02002D4C
	v_fma_mixhi_f16 v115, v77, s22, 0                          // 000000169DD8: CC220073 02002D4D
	v_fma_mixlo_f16 v116, v78, s22, 0                          // 000000169DE0: CC210074 02002D4E
	v_fma_mixhi_f16 v116, v79, s22, 0                          // 000000169DE8: CC220074 02002D4F
	s_waitcnt lgkmcnt(3)                                       // 000000169DF0: BF89FC37
	v_fma_mixlo_f16 v121, v121, s22, 0                         // 000000169DF4: CC210079 02002D79
	v_fma_mixhi_f16 v121, v122, s22, 0                         // 000000169DFC: CC220079 02002D7A
	v_fma_mixlo_f16 v122, v123, s22, 0                         // 000000169E04: CC21007A 02002D7B
	v_fma_mixhi_f16 v122, v124, s22, 0                         // 000000169E0C: CC22007A 02002D7C
	s_waitcnt lgkmcnt(2)                                       // 000000169E14: BF89FC27
	v_fma_mixlo_f16 v123, v125, s22, 0                         // 000000169E18: CC21007B 02002D7D
	v_fma_mixhi_f16 v123, v126, s22, 0                         // 000000169E20: CC22007B 02002D7E
	v_fma_mixlo_f16 v124, v127, s22, 0                         // 000000169E28: CC21007C 02002D7F
	v_fma_mixhi_f16 v124, v128, s22, 0                         // 000000169E30: CC22007C 02002D80
	s_waitcnt lgkmcnt(1)                                       // 000000169E38: BF89FC17
	v_fma_mixlo_f16 v129, v129, s22, 0                         // 000000169E3C: CC210081 02002D81
	v_fma_mixhi_f16 v129, v130, s22, 0                         // 000000169E44: CC220081 02002D82
	v_fma_mixlo_f16 v130, v131, s22, 0                         // 000000169E4C: CC210082 02002D83
	v_fma_mixhi_f16 v130, v132, s22, 0                         // 000000169E54: CC220082 02002D84
	s_waitcnt lgkmcnt(0)                                       // 000000169E5C: BF89FC07
	v_fma_mixlo_f16 v131, v50, s22, 0                          // 000000169E60: CC210083 02002D32
	v_fma_mixhi_f16 v131, v51, s22, 0                          // 000000169E68: CC220083 02002D33
	v_fma_mixlo_f16 v132, v52, s22, 0                          // 000000169E70: CC210084 02002D34
	v_fma_mixhi_f16 v132, v53, s22, 0                          // 000000169E78: CC220084 02002D35
	v_dual_mov_b32 v72, v68 :: v_dual_mov_b32 v73, v69         // 000000169E80: CA100144 48480145
	v_dual_mov_b32 v74, v70 :: v_dual_mov_b32 v75, v71         // 000000169E88: CA100146 4A4A0147
	v_dual_mov_b32 v117, v113 :: v_dual_mov_b32 v118, v114     // 000000169E90: CA100171 75760172
	v_dual_mov_b32 v119, v115 :: v_dual_mov_b32 v120, v116     // 000000169E98: CA100173 77780174
	v_dual_mov_b32 v125, v121 :: v_dual_mov_b32 v126, v122     // 000000169EA0: CA100179 7D7E017A
	v_dual_mov_b32 v127, v123 :: v_dual_mov_b32 v128, v124     // 000000169EA8: CA10017B 7F80017C
	v_dual_mov_b32 v133, v129 :: v_dual_mov_b32 v134, v130     // 000000169EB0: CA100181 85860182
	v_dual_mov_b32 v135, v131 :: v_dual_mov_b32 v136, v132     // 000000169EB8: CA100183 87880184
	.long 0x7f6a3880                                           // 000000169EC0: 7F6A3880
	v_wmma_f32_16x16x16_f16 v[42:49], v[60:67], v[68:75], v[42:49]// 000000169EC4: CC40402A 1CAA893C
	v_wmma_f32_16x16x16_f16 v[34:41], v[60:67], v[113:120], v[34:41]// 000000169ECC: CC404022 1C8AE33C
	v_wmma_f32_16x16x16_f16 v[26:33], v[60:67], v[121:128], v[26:33]// 000000169ED4: CC40401A 1C6AF33C
	v_wmma_f32_16x16x16_f16 v[18:25], v[60:67], v[129:136], v[18:25]// 000000169EDC: CC404012 1C4B033C
	.long 0x7f6639b5                                           // 000000169EE4: 7F6639B5
	.long 0x7e6639b5                                           // 000000169EE8: 7E6639B5
	.long 0x7f6439b5                                           // 000000169EEC: 7F6439B5
	.long 0x7e6439b5                                           // 000000169EF0: 7E6439B5
	s_and_saveexec_b32 s11, s0                                 // 000000169EF4: BE8B2000
	s_cbranch_execz 11                                         // 000000169EF8: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d28>
	global_load_b128 v[54:57], v[4:5], off offset:448          // 000000169EFC: DC5E01C0 367C0004
	s_waitcnt vmcnt(0)                                         // 000000169F04: BF8903F7
	v_fma_mixlo_f16 v50, v54, s22, 0                           // 000000169F08: CC210032 02002D36
	v_fma_mixhi_f16 v50, v55, s22, 0                           // 000000169F10: CC220032 02002D37
	v_fma_mixlo_f16 v51, v56, s22, 0                           // 000000169F18: CC210033 02002D38
	v_fma_mixhi_f16 v51, v57, s22, 0                           // 000000169F20: CC220033 02002D39
	s_or_b32 exec_lo, exec_lo, s11                             // 000000169F28: 8C7E0B7E
	.long 0x7e6a39b5                                           // 000000169F2C: 7E6A39B5
	.long 0x7f6839b5                                           // 000000169F30: 7F6839B5
	.long 0x7e6839b5                                           // 000000169F34: 7E6839B5
	s_and_saveexec_b32 s11, s0                                 // 000000169F38: BE8B2000
	s_cbranch_execz 11                                         // 000000169F3C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d6c>
	global_load_b128 v[52:55], v[4:5], off offset:464          // 000000169F40: DC5E01D0 347C0004
	s_waitcnt vmcnt(0)                                         // 000000169F48: BF8903F7
	v_fma_mixlo_f16 v52, v52, s22, 0                           // 000000169F4C: CC210034 02002D34
	v_fma_mixhi_f16 v52, v53, s22, 0                           // 000000169F54: CC220034 02002D35
	v_fma_mixlo_f16 v53, v54, s22, 0                           // 000000169F5C: CC210035 02002D36
	v_fma_mixhi_f16 v53, v55, s22, 0                           // 000000169F64: CC220035 02002D37
	s_or_b32 exec_lo, exec_lo, s11                             // 000000169F6C: 8C7E0B7E
	.long 0x7f723880                                           // 000000169F70: 7F723880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000169F74: BF870001
	.long 0x7f6e39b9                                           // 000000169F78: 7F6E39B9
	.long 0x7e6e39b9                                           // 000000169F7C: 7E6E39B9
	.long 0x7f6c39b9                                           // 000000169F80: 7F6C39B9
	.long 0x7e6c39b9                                           // 000000169F84: 7E6C39B9
	s_and_saveexec_b32 s11, s0                                 // 000000169F88: BE8B2000
	s_cbranch_execz 11                                         // 000000169F8C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3dbc>
	global_load_b128 v[58:61], v[4:5], off offset:480          // 000000169F90: DC5E01E0 3A7C0004
	s_waitcnt vmcnt(0)                                         // 000000169F98: BF8903F7
	v_fma_mixlo_f16 v54, v58, s22, 0                           // 000000169F9C: CC210036 02002D3A
	v_fma_mixhi_f16 v54, v59, s22, 0                           // 000000169FA4: CC220036 02002D3B
	v_fma_mixlo_f16 v55, v60, s22, 0                           // 000000169FAC: CC210037 02002D3C
	v_fma_mixhi_f16 v55, v61, s22, 0                           // 000000169FB4: CC220037 02002D3D
	s_or_b32 exec_lo, exec_lo, s11                             // 000000169FBC: 8C7E0B7E
	.long 0x7e7239b9                                           // 000000169FC0: 7E7239B9
	.long 0x7f7039b9                                           // 000000169FC4: 7F7039B9
	.long 0x7e7039b9                                           // 000000169FC8: 7E7039B9
	s_and_saveexec_b32 s11, s0                                 // 000000169FCC: BE8B2000
	s_cbranch_execz 11                                         // 000000169FD0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3e00>
	global_load_b128 v[3:6], v[4:5], off offset:496            // 000000169FD4: DC5E01F0 037C0004
	s_waitcnt vmcnt(0)                                         // 000000169FDC: BF8903F7
	v_fma_mixlo_f16 v56, v3, s22, 0                            // 000000169FE0: CC210038 02002D03
	v_fma_mixhi_f16 v56, v4, s22, 0                            // 000000169FE8: CC220038 02002D04
	v_fma_mixlo_f16 v57, v5, s22, 0                            // 000000169FF0: CC210039 02002D05
	v_fma_mixhi_f16 v57, v6, s22, 0                            // 000000169FF8: CC220039 02002D06
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016A000: 8C7E0B7E
	ds_load_b128 v[3:6], v94 offset:448                        // 00000016A004: DBFC01C0 0300005E
	ds_load_b128 v[60:63], v94 offset:464                      // 00000016A00C: DBFC01D0 3C00005E
	ds_load_b128 v[66:69], v94 offset:8896                     // 00000016A014: DBFC22C0 4200005E
	ds_load_b128 v[70:73], v94 offset:8912                     // 00000016A01C: DBFC22D0 4600005E
	ds_load_b128 v[74:77], v94 offset:17344                    // 00000016A024: DBFC43C0 4A00005E
	ds_load_b128 v[78:81], v94 offset:17360                    // 00000016A02C: DBFC43D0 4E00005E
	s_mul_i32 s11, s23, 48                                     // 00000016A034: 960BB017
	s_mul_hi_u32 s0, s23, 48                                   // 00000016A038: 9680B017
	s_add_u32 s14, s11, s2                                     // 00000016A03C: 800E020B
	s_addc_u32 s15, s0, s3                                     // 00000016A040: 820F0300
	s_mov_b32 s11, 0                                           // 00000016A044: BE8B0080
	s_lshl_b64 s[14:15], s[14:15], 14                          // 00000016A048: 848E8E0E
	ds_load_b128 v[115:118], v94 offset:25808                  // 00000016A04C: DBFC64D0 7300005E
	s_waitcnt lgkmcnt(6)                                       // 00000016A054: BF89FC67
	v_fma_mixlo_f16 v58, v3, s22, 0                            // 00000016A058: CC21003A 02002D03
	v_fma_mixhi_f16 v58, v4, s22, 0                            // 00000016A060: CC22003A 02002D04
	v_fma_mixlo_f16 v59, v5, s22, 0                            // 00000016A068: CC21003B 02002D05
	v_fma_mixhi_f16 v59, v6, s22, 0                            // 00000016A070: CC22003B 02002D06
	ds_load_b128 v[3:6], v94 offset:25792                      // 00000016A078: DBFC64C0 0300005E
	s_waitcnt lgkmcnt(3)                                       // 00000016A080: BF89FC37
	v_fma_mixlo_f16 v74, v74, s22, 0                           // 00000016A084: CC21004A 02002D4A
	v_fma_mixhi_f16 v74, v75, s22, 0                           // 00000016A08C: CC22004A 02002D4B
	v_fma_mixlo_f16 v75, v76, s22, 0                           // 00000016A094: CC21004B 02002D4C
	v_fma_mixhi_f16 v75, v77, s22, 0                           // 00000016A09C: CC22004B 02002D4D
	s_waitcnt lgkmcnt(2)                                       // 00000016A0A4: BF89FC27
	v_fma_mixlo_f16 v76, v78, s22, 0                           // 00000016A0A8: CC21004C 02002D4E
	v_fma_mixhi_f16 v76, v79, s22, 0                           // 00000016A0B0: CC22004C 02002D4F
	v_fma_mixlo_f16 v77, v80, s22, 0                           // 00000016A0B8: CC21004D 02002D50
	v_fma_mixhi_f16 v77, v81, s22, 0                           // 00000016A0C0: CC22004D 02002D51
	v_fma_mixlo_f16 v60, v60, s22, 0                           // 00000016A0C8: CC21003C 02002D3C
	v_fma_mixhi_f16 v60, v61, s22, 0                           // 00000016A0D0: CC22003C 02002D3D
	v_fma_mixlo_f16 v61, v62, s22, 0                           // 00000016A0D8: CC21003D 02002D3E
	v_fma_mixhi_f16 v61, v63, s22, 0                           // 00000016A0E0: CC22003D 02002D3F
	v_fma_mixlo_f16 v66, v66, s22, 0                           // 00000016A0E8: CC210042 02002D42
	v_fma_mixhi_f16 v66, v67, s22, 0                           // 00000016A0F0: CC220042 02002D43
	v_fma_mixlo_f16 v67, v68, s22, 0                           // 00000016A0F8: CC210043 02002D44
	v_fma_mixhi_f16 v67, v69, s22, 0                           // 00000016A100: CC220043 02002D45
	v_fma_mixlo_f16 v68, v70, s22, 0                           // 00000016A108: CC210044 02002D46
	v_fma_mixhi_f16 v68, v71, s22, 0                           // 00000016A110: CC220044 02002D47
	v_fma_mixlo_f16 v69, v72, s22, 0                           // 00000016A118: CC210045 02002D48
	v_fma_mixhi_f16 v69, v73, s22, 0                           // 00000016A120: CC220045 02002D49
	v_dual_mov_b32 v78, v74 :: v_dual_mov_b32 v79, v75         // 00000016A128: CA10014A 4E4E014B
	v_dual_mov_b32 v80, v76 :: v_dual_mov_b32 v81, v77         // 00000016A130: CA10014C 5050014D
	s_waitcnt lgkmcnt(0)                                       // 00000016A138: BF89FC07
	v_fma_mixlo_f16 v113, v3, s22, 0                           // 00000016A13C: CC210071 02002D03
	v_fma_mixhi_f16 v113, v4, s22, 0                           // 00000016A144: CC220071 02002D04
	v_fma_mixlo_f16 v114, v5, s22, 0                           // 00000016A14C: CC210072 02002D05
	v_fma_mixhi_f16 v114, v6, s22, 0                           // 00000016A154: CC220072 02002D06
	v_fma_mixlo_f16 v115, v115, s22, 0                         // 00000016A15C: CC210073 02002D73
	v_fma_mixhi_f16 v115, v116, s22, 0                         // 00000016A164: CC220073 02002D74
	v_fma_mixlo_f16 v116, v117, s22, 0                         // 00000016A16C: CC210074 02002D75
	v_fma_mixhi_f16 v116, v118, s22, 0                         // 00000016A174: CC220074 02002D76
	v_dual_mov_b32 v62, v58 :: v_dual_mov_b32 v63, v59         // 00000016A17C: CA10013A 3E3E013B
	v_dual_mov_b32 v64, v60 :: v_dual_mov_b32 v65, v61         // 00000016A184: CA10013C 4040013D
	v_dual_mov_b32 v70, v66 :: v_dual_mov_b32 v71, v67         // 00000016A18C: CA100142 46460143
	v_dual_mov_b32 v72, v68 :: v_dual_mov_b32 v73, v69         // 00000016A194: CA100144 48480145
	v_dual_mov_b32 v117, v113 :: v_dual_mov_b32 v118, v114     // 00000016A19C: CA100171 75760172
	v_dual_mov_b32 v119, v115 :: v_dual_mov_b32 v120, v116     // 00000016A1A4: CA100173 77780174
	v_wmma_f32_16x16x16_f16 v[26:33], v[50:57], v[74:81], v[26:33]// 00000016A1AC: CC40401A 1C6A9532
	v_mov_b32_e32 v74, 0                                       // 00000016A1B4: 7E940280
	.long 0xd7000003                                           // 00000016A1B8: D7000003
	v_cndmask_b32_e32 v0, v96, v14, vcc_lo                     // 00000016A1BC: 02001D60
	v_wmma_f32_16x16x16_f16 v[42:49], v[50:57], v[58:65], v[42:49]// 00000016A1C0: CC40402A 1CAA7532
	v_wmma_f32_16x16x16_f16 v[34:41], v[50:57], v[66:73], v[34:41]// 00000016A1C8: CC404022 1C8A8532
	v_wmma_f32_16x16x16_f16 v[18:25], v[50:57], v[113:120], v[18:25]// 00000016A1D0: CC404012 1C4AE332
	v_add_co_ci_u32_e64 v4, null, s15, v97, s0                 // 00000016A1D8: D5207C04 0002C20F
	v_mov_b32_e32 v75, v74                                     // 00000016A1E0: 7E96034A
	v_mov_b32_e32 v76, v74                                     // 00000016A1E4: 7E98034A
	v_mov_b32_e32 v77, v74                                     // 00000016A1E8: 7E9A034A
	v_mov_b32_e32 v78, v74                                     // 00000016A1EC: 7E9C034A
	v_mov_b32_e32 v79, v74                                     // 00000016A1F0: 7E9E034A
	v_mov_b32_e32 v80, v74                                     // 00000016A1F4: 7EA0034A
	v_mov_b32_e32 v81, v74                                     // 00000016A1F8: 7EA2034A
	v_mov_b32_e32 v66, v74                                     // 00000016A1FC: 7E84034A
	v_mov_b32_e32 v67, v74                                     // 00000016A200: 7E86034A
	v_mov_b32_e32 v68, v74                                     // 00000016A204: 7E88034A
	v_mov_b32_e32 v69, v74                                     // 00000016A208: 7E8A034A
	v_mov_b32_e32 v70, v74                                     // 00000016A20C: 7E8C034A
	v_mov_b32_e32 v71, v74                                     // 00000016A210: 7E8E034A
	v_mov_b32_e32 v72, v74                                     // 00000016A214: 7E90034A
	v_mov_b32_e32 v73, v74                                     // 00000016A218: 7E92034A
	v_mov_b32_e32 v58, v74                                     // 00000016A21C: 7E74034A
	v_mov_b32_e32 v59, v74                                     // 00000016A220: 7E76034A
	v_mov_b32_e32 v60, v74                                     // 00000016A224: 7E78034A
	v_mov_b32_e32 v61, v74                                     // 00000016A228: 7E7A034A
	v_mov_b32_e32 v62, v74                                     // 00000016A22C: 7E7C034A
	v_mov_b32_e32 v63, v74                                     // 00000016A230: 7E7E034A
	v_mov_b32_e32 v64, v74                                     // 00000016A234: 7E80034A
	v_mov_b32_e32 v65, v74                                     // 00000016A238: 7E82034A
	v_mov_b32_e32 v50, v74                                     // 00000016A23C: 7E64034A
	v_mov_b32_e32 v51, v74                                     // 00000016A240: 7E66034A
	v_mov_b32_e32 v52, v74                                     // 00000016A244: 7E68034A
	v_mov_b32_e32 v53, v74                                     // 00000016A248: 7E6A034A
	v_mov_b32_e32 v54, v74                                     // 00000016A24C: 7E6C034A
	v_mov_b32_e32 v55, v74                                     // 00000016A250: 7E6E034A
	v_mov_b32_e32 v56, v74                                     // 00000016A254: 7E70034A
	v_mov_b32_e32 v57, v74                                     // 00000016A258: 7E72034A
	s_mov_b32 s14, 0                                           // 00000016A25C: BE8E0080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000016A260: BF870499
	s_lshl_b32 s18, s14, 4                                     // 00000016A264: 8412840E
	s_lshl_b64 s[48:49], s[18:19], 2                           // 00000016A268: 84B08212
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A26C: BF870099
	.long 0xd7000005                                           // 00000016A270: D7000005
	v_cndmask_b32_e32 v0, v3, v48, vcc_lo                      // 00000016A274: 02006103
	v_add_co_ci_u32_e64 v6, null, s49, v4, s0                  // 00000016A278: D5207C06 00020831
	.long 0xd44a0000                                           // 00000016A280: D44A0000
	v_cndmask_b32_e32 v1, s14, v90, vcc_lo                     // 00000016A284: 0202B40E
	s_clause 0x3                                               // 00000016A288: BF850003
	global_load_b128 v[145:148], v[5:6], off                   // 00000016A28C: DC5E0000 917C0005
	global_load_b128 v[149:152], v[5:6], off offset:16         // 00000016A294: DC5E0010 957C0005
	global_load_b128 v[153:156], v[5:6], off offset:32         // 00000016A29C: DC5E0020 997C0005
	global_load_b128 v[157:160], v[5:6], off offset:48         // 00000016A2A4: DC5E0030 9D7C0005
	v_lshl_add_u32 v5, s14, 5, v98                             // 00000016A2AC: D6460005 05890A0E
	s_add_i32 s14, s14, 1                                      // 00000016A2B4: 810E810E
	s_or_b32 s11, s0, s11                                      // 00000016A2B8: 8C0B0B00
	ds_load_b128 v[113:116], v5                                // 00000016A2BC: DBFC0000 71000005
	ds_load_b128 v[117:120], v5 offset:16                      // 00000016A2C4: DBFC0010 75000005
	ds_load_b128 v[125:128], v5 offset:2576                    // 00000016A2CC: DBFC0A10 7D000005
	ds_load_b128 v[121:124], v5 offset:2560                    // 00000016A2D4: DBFC0A00 79000005
	ds_load_b128 v[133:136], v5 offset:5136                    // 00000016A2DC: DBFC1410 85000005
	ds_load_b128 v[129:132], v5 offset:5120                    // 00000016A2E4: DBFC1400 81000005
	ds_load_b128 v[141:144], v5 offset:7696                    // 00000016A2EC: DBFC1E10 8D000005
	ds_load_b128 v[137:140], v5 offset:7680                    // 00000016A2F4: DBFC1E00 89000005
	s_waitcnt vmcnt(3)                                         // 00000016A2FC: BF890FF7
	v_fma_mixlo_f16 v145, v145, s22, 0                         // 00000016A300: CC210091 02002D91
	v_fma_mixhi_f16 v145, v146, s22, 0                         // 00000016A308: CC220091 02002D92
	v_fma_mixlo_f16 v146, v147, s22, 0                         // 00000016A310: CC210092 02002D93
	v_fma_mixhi_f16 v146, v148, s22, 0                         // 00000016A318: CC220092 02002D94
	s_waitcnt vmcnt(2)                                         // 00000016A320: BF890BF7
	v_fma_mixlo_f16 v147, v149, s22, 0                         // 00000016A324: CC210093 02002D95
	v_fma_mixhi_f16 v147, v150, s22, 0                         // 00000016A32C: CC220093 02002D96
	v_fma_mixlo_f16 v148, v151, s22, 0                         // 00000016A334: CC210094 02002D97
	v_fma_mixhi_f16 v148, v152, s22, 0                         // 00000016A33C: CC220094 02002D98
	s_waitcnt vmcnt(1)                                         // 00000016A344: BF8907F7
	v_fma_mixlo_f16 v149, v153, s22, 0                         // 00000016A348: CC210095 02002D99
	v_fma_mixhi_f16 v149, v154, s22, 0                         // 00000016A350: CC220095 02002D9A
	v_fma_mixlo_f16 v150, v155, s22, 0                         // 00000016A358: CC210096 02002D9B
	v_fma_mixhi_f16 v150, v156, s22, 0                         // 00000016A360: CC220096 02002D9C
	s_waitcnt vmcnt(0)                                         // 00000016A368: BF8903F7
	v_fma_mixlo_f16 v151, v157, s22, 0                         // 00000016A36C: CC210097 02002D9D
	v_fma_mixhi_f16 v151, v158, s22, 0                         // 00000016A374: CC220097 02002D9E
	v_fma_mixlo_f16 v152, v159, s22, 0                         // 00000016A37C: CC210098 02002D9F
	v_fma_mixhi_f16 v152, v160, s22, 0                         // 00000016A384: CC220098 02002DA0
	s_waitcnt lgkmcnt(6)                                       // 00000016A38C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016A390: BF870001
	v_wmma_f32_16x16x16_f16 v[74:81], v[145:152], v[113:120], v[74:81]// 00000016A394: CC40404A 1D2AE391
	s_waitcnt lgkmcnt(4)                                       // 00000016A39C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[66:73], v[145:152], v[121:128], v[66:73]// 00000016A3A0: CC404042 1D0AF391
	s_waitcnt lgkmcnt(2)                                       // 00000016A3A8: BF89FC27
	v_wmma_f32_16x16x16_f16 v[58:65], v[145:152], v[129:136], v[58:65]// 00000016A3AC: CC40403A 1CEB0391
	s_waitcnt lgkmcnt(0)                                       // 00000016A3B4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[50:57], v[145:152], v[137:144], v[50:57]// 00000016A3B8: CC404032 1CCB1391
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000016A3C0: 917E0B7E
	s_cbranch_execnz 65446                                     // 00000016A3C4: BFA6FFA6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4060>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000016A3C8: 8C7E0B7E
	s_and_saveexec_b32 s0, s1                                  // 00000016A3CC: BE802001
	s_cbranch_execnz 474                                       // 00000016A3D0: BFA601DA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x493c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A3D4: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000016A3D8: BE802004
	s_cbranch_execnz 493                                       // 00000016A3DC: BFA601ED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4994>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A3E0: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000016A3E4: BE802005
	s_cbranch_execnz 512                                       // 00000016A3E8: BFA60200 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x49ec>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A3EC: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000016A3F0: BE802006
	s_cbranch_execnz 531                                       // 00000016A3F4: BFA60213 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4a44>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A3F8: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000016A3FC: BE802007
	s_cbranch_execnz 550                                       // 00000016A400: BFA60226 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4a9c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A404: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000016A408: BE802008
	s_cbranch_execnz 569                                       // 00000016A40C: BFA60239 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4af4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A410: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000016A414: BE802009
	s_cbranch_execnz 588                                       // 00000016A418: BFA6024C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4b4c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A41C: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000016A420: BE80200A
	s_cbranch_execnz 607                                       // 00000016A424: BFA6025F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4ba4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A428: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000016A42C: BE802001
	s_cbranch_execnz 625                                       // 00000016A430: BFA60271 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4bf8>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A434: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000016A438: BE802004
	s_cbranch_execnz 644                                       // 00000016A43C: BFA60284 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4c50>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A440: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000016A444: BE802005
	s_cbranch_execnz 663                                       // 00000016A448: BFA60297 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4ca8>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A44C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000016A450: BE802006
	s_cbranch_execnz 682                                       // 00000016A454: BFA602AA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4d00>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A458: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000016A45C: BE802007
	s_cbranch_execnz 701                                       // 00000016A460: BFA602BD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4d58>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A464: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000016A468: BE802008
	s_cbranch_execnz 720                                       // 00000016A46C: BFA602D0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4db0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A470: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000016A474: BE802009
	s_cbranch_execnz 739                                       // 00000016A478: BFA602E3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4e08>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A47C: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000016A480: BE80200A
	s_cbranch_execnz 758                                       // 00000016A484: BFA602F6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4e60>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A488: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000016A48C: BE802001
	s_cbranch_execnz 776                                       // 00000016A490: BFA60308 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4eb4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A494: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000016A498: BE802004
	s_cbranch_execnz 795                                       // 00000016A49C: BFA6031B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f0c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A4A0: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000016A4A4: BE802005
	s_cbranch_execnz 814                                       // 00000016A4A8: BFA6032E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f64>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A4AC: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000016A4B0: BE802006
	s_cbranch_execnz 833                                       // 00000016A4B4: BFA60341 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4fbc>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A4B8: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000016A4BC: BE802007
	s_cbranch_execnz 852                                       // 00000016A4C0: BFA60354 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5014>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A4C4: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000016A4C8: BE802008
	s_cbranch_execnz 871                                       // 00000016A4CC: BFA60367 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x506c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A4D0: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000016A4D4: BE802009
	s_cbranch_execnz 890                                       // 00000016A4D8: BFA6037A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x50c4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A4DC: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000016A4E0: BE80200A
	s_cbranch_execnz 909                                       // 00000016A4E4: BFA6038D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x511c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A4E8: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000016A4EC: BE802001
	s_cbranch_execnz 927                                       // 00000016A4F0: BFA6039F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5170>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A4F4: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000016A4F8: BE802004
	s_cbranch_execnz 946                                       // 00000016A4FC: BFA603B2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51c8>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A500: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000016A504: BE802005
	s_cbranch_execnz 965                                       // 00000016A508: BFA603C5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5220>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A50C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000016A510: BE802006
	s_cbranch_execnz 984                                       // 00000016A514: BFA603D8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5278>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A518: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000016A51C: BE802007
	s_cbranch_execnz 1003                                      // 00000016A520: BFA603EB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x52d0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A524: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000016A528: BE802008
	s_cbranch_execnz 1022                                      // 00000016A52C: BFA603FE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5328>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A530: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000016A534: BE802009
	s_cbranch_execnz 1041                                      // 00000016A538: BFA60411 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5380>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A53C: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000016A540: BE80200A
	s_cbranch_execz 18                                         // 00000016A544: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4390>
	ds_load_b32 v3, v104 offset:56                             // 00000016A548: D8D80038 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016A550: BF89FC07
	v_fmac_f32_e32 v57, v25, v3                                // 00000016A554: 56720719
	v_mad_u64_u32 v[3:4], null, 0x3000, v112, v[84:85]         // 00000016A558: D6FE7C03 0552E0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016A564: BF870092
	v_mul_f32_e32 v5, 0x3b800000, v57                          // 00000016A568: 100A72FF 3B800000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016A570: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016A578: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016A57C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000016A588: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016A590: 8C7E007E
	s_mul_f32 s0, s47, 0x3fb8aa3b                              // 00000016A594: A200FF2F 3FB8AA3B
	v_or_b32_e32 v4, s46, v88                                  // 00000016A59C: 3808B02E
	v_dual_mov_b32 v18, v86 :: v_dual_mov_b32 v19, v87         // 00000016A5A0: CA100156 12120157
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000016A5A8: BF870009
	s_xor_b32 s1, s0, 0x80000000                               // 00000016A5AC: 8D01FF00 80000000
	s_rndne_f32 s4, s0                                         // 00000016A5B4: BE846300
	s_fmamk_f32 s1, s47, 0x3fb8aa3b, s1                        // 00000016A5B8: A301012F 3FB8AA3B
	s_cmp_nlt_f32 s47, 0xc2ce8ed0                              // 00000016A5C0: BF4EFF2F C2CE8ED0
	s_mov_b32 s5, 0                                            // 00000016A5C8: BE850080
	s_sub_f32 s0, s0, s4                                       // 00000016A5CC: A0800400
	s_fmamk_f32 s1, s47, 0x32a5705f, s1                        // 00000016A5D0: A301012F 32A5705F
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000016A5D8: BF87059B
	s_add_f32 s0, s0, s1                                       // 00000016A5DC: A0000100
	v_exp_f32_e32 v3, s0                                       // 00000016A5E0: 7E064A00
	s_cvt_i32_f32 s0, s4                                       // 00000016A5E4: BE806604
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000016A5E8: BF870585
	.long 0xd71c0003                                           // 00000016A5EC: D71C0003
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 00000016A5F0: 02000103
	s_cselect_b32 s0, -1, 0                                    // 00000016A5F4: 980080C1
	s_cmp_ngt_f32 s47, 0x42b17218                              // 00000016A5F8: BF4BFF2F 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000016A600: BF870131
	v_cndmask_b32_e64 v3, 0, v3, s0                            // 00000016A604: D5010003 00020680
	s_cselect_b32 s1, -1, 0                                    // 00000016A60C: 980180C1
	.long 0xd4440000                                           // 00000016A610: D4440000
	v_cndmask_b32_e32 v1, s35, v4, vcc_lo                      // 00000016A614: 02020823
	v_cndmask_b32_e64 v20, 0x7f800000, v3, s1                  // 00000016A618: D5010014 000606FF 7F800000
	s_branch 120                                               // 00000016A624: BFA00078 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4608>
	s_set_inst_prefetch_distance 0x2                           // 00000016A628: BF840002
	s_or_b32 exec_lo, exec_lo, s6                              // 00000016A62C: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000016A630: BF89FC07
	s_barrier                                                  // 00000016A634: BFBD0000
	buffer_gl0_inv                                             // 00000016A638: E0AC0000 00000000
	ds_load_b128 v[22:25], v99                                 // 00000016A640: DBFC0000 16000063
	ds_load_b128 v[26:29], v99 offset:16                       // 00000016A648: DBFC0010 1A000063
	ds_load_b128 v[30:33], v107                                // 00000016A650: DBFC0000 1E00006B
	ds_load_b128 v[34:37], v107 offset:16                      // 00000016A658: DBFC0010 2200006B
	ds_load_b128 v[38:41], v99 offset:32                       // 00000016A660: DBFC0020 26000063
	ds_load_b128 v[42:45], v99 offset:48                       // 00000016A668: DBFC0030 2A000063
	ds_load_b128 v[46:49], v107 offset:32                      // 00000016A670: DBFC0020 2E00006B
	ds_load_b128 v[50:53], v107 offset:48                      // 00000016A678: DBFC0030 3200006B
	v_mov_b32_e32 v9, v2                                       // 00000016A680: 7E120302
	v_mov_b32_e32 v3, v2                                       // 00000016A684: 7E060302
	v_mov_b32_e32 v4, v2                                       // 00000016A688: 7E080302
	v_mov_b32_e32 v5, v2                                       // 00000016A68C: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 00000016A690: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 00000016A694: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 00000016A698: 7E100302
	v_mov_b32_e32 v61, v9                                      // 00000016A69C: 7E7A0309
	v_dual_mov_b32 v57, v5 :: v_dual_mov_b32 v56, v4           // 00000016A6A0: CA100105 39380104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000016A6A8: BF870214
	v_dual_mov_b32 v59, v7 :: v_dual_mov_b32 v58, v6           // 00000016A6AC: CA100107 3B3A0106
	v_dual_mov_b32 v60, v8 :: v_dual_mov_b32 v55, v3           // 00000016A6B4: CA100108 3C360103
	v_mov_b32_e32 v54, v2                                      // 00000016A6BC: 7E6C0302
	ds_load_b128 v[66:69], v99 offset:80                       // 00000016A6C0: DBFC0050 42000063
	ds_load_b128 v[62:65], v99 offset:64                       // 00000016A6C8: DBFC0040 3E000063
	ds_load_b128 v[74:77], v107 offset:80                      // 00000016A6D0: DBFC0050 4A00006B
	ds_load_b128 v[70:73], v107 offset:64                      // 00000016A6D8: DBFC0040 4600006B
	ds_load_b128 v[112:115], v99 offset:112                    // 00000016A6E0: DBFC0070 70000063
	ds_load_b128 v[108:111], v99 offset:96                     // 00000016A6E8: DBFC0060 6C000063
	ds_load_2addr_b32 v[3:4], v21 offset0:16 offset1:18        // 00000016A6F0: D8DC1210 03000015
	ds_load_b128 v[120:123], v107 offset:112                   // 00000016A6F8: DBFC0070 7800006B
	ds_load_b128 v[116:119], v107 offset:96                    // 00000016A700: DBFC0060 7400006B
	ds_load_2addr_b32 v[5:6], v21 offset0:20 offset1:22        // 00000016A708: D8DC1614 05000015
	ds_load_2addr_b32 v[7:8], v21 offset0:24 offset1:26        // 00000016A710: D8DC1A18 07000015
	.long 0xd7000112                                           // 00000016A718: D7000112
	v_cndmask_b32_e32 v1, 0x80, v18, vcc_lo                    // 00000016A71C: 020224FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016A724: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 00000016A728: D5207C13 00062680
	s_waitcnt lgkmcnt(15)                                      // 00000016A730: BF89FCF7
	v_wmma_f32_16x16x16_f16 v[54:61], v[22:29], v[30:37], v[54:61]// 00000016A734: CC404036 1CDA3D16
	ds_load_2addr_b32 v[22:23], v21 offset0:28 offset1:30      // 00000016A73C: D8DC1E1C 16000015
	s_add_i32 s1, s5, 32                                       // 00000016A744: 8101A005
	s_cmpk_gt_u32 s5, 0x5f                                     // 00000016A748: B585005F
	s_mov_b32 s5, s1                                           // 00000016A74C: BE850001
	s_waitcnt lgkmcnt(12)                                      // 00000016A750: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[54:61], v[38:45], v[46:53], v[54:61]// 00000016A754: CC404036 1CDA5D26
	s_waitcnt lgkmcnt(8)                                       // 00000016A75C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016A760: BF870001
	v_wmma_f32_16x16x16_f16 v[54:61], v[62:69], v[70:77], v[54:61]// 00000016A764: CC404036 1CDA8D3E
	s_waitcnt lgkmcnt(5)                                       // 00000016A76C: BF89FC57
	v_mul_f32_e32 v3, v20, v3                                  // 00000016A770: 10060714
	v_mul_f32_e32 v4, v20, v4                                  // 00000016A774: 10080914
	s_waitcnt lgkmcnt(2)                                       // 00000016A778: BF89FC27
	v_mul_f32_e32 v5, v20, v5                                  // 00000016A77C: 100A0B14
	v_wmma_f32_16x16x16_f16 v[54:61], v[108:115], v[116:123], v[54:61]// 00000016A780: CC404036 1CDAE96C
	s_waitcnt lgkmcnt(1)                                       // 00000016A788: BF89FC17
	v_mul_f32_e32 v7, v20, v7                                  // 00000016A78C: 100E0F14
	v_mul_f32_e32 v6, v20, v6                                  // 00000016A790: 100C0D14
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000016A794: BF870193
	v_dual_mul_f32 v8, v20, v8 :: v_dual_fmac_f32 v3, 0x3b800000, v54// 00000016A798: C8C01114 08026CFF 3B800000
	v_fmac_f32_e32 v7, 0x3b800000, v58                         // 00000016A7A4: 560E74FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 00000016A7AC: BF89FC07
	v_mul_f32_e32 v9, v20, v22                                 // 00000016A7B0: 10122D14
	v_mul_f32_e32 v22, v20, v23                                // 00000016A7B4: 102C2F14
	v_dual_fmac_f32 v4, 0x3b800000, v55 :: v_dual_fmac_f32 v5, 0x3b800000, v56// 00000016A7B8: C8006EFF 040470FF 3B800000
	v_fmac_f32_e32 v8, 0x3b800000, v59                         // 00000016A7C4: 561076FF 3B800000
	v_fmac_f32_e32 v6, 0x3b800000, v57                         // 00000016A7CC: 560C72FF 3B800000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000016A7D4: BF870004
	v_dual_fmac_f32 v22, 0x3b800000, v61 :: v_dual_fmac_f32 v9, 0x3b800000, v60// 00000016A7D8: C8007AFF 160878FF 3B800000
	ds_store_2addr_b32 v21, v3, v4 offset0:16 offset1:18       // 00000016A7E4: D8381210 00040315
	ds_store_2addr_b32 v21, v5, v6 offset0:20 offset1:22       // 00000016A7EC: D8381614 00060515
	ds_store_2addr_b32 v21, v7, v8 offset0:24 offset1:26       // 00000016A7F4: D8381A18 00080715
	ds_store_2addr_b32 v21, v9, v22 offset0:28 offset1:30      // 00000016A7FC: D8381E1C 00160915
	s_cbranch_scc1 61262                                       // 00000016A804: BFA2EF4E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x340>
	v_dual_mov_b32 v4, v18 :: v_dual_mov_b32 v5, v19           // 00000016A808: CA100112 04040113
	v_dual_mov_b32 v6, v106 :: v_dual_mov_b32 v7, v89          // 00000016A810: CA10016A 06060159
	s_mov_b32 s6, 0                                            // 00000016A818: BE860080
	s_waitcnt_vscnt null, 0x0                                  // 00000016A81C: BC7C0000
	s_barrier                                                  // 00000016A820: BFBD0000
	buffer_gl0_inv                                             // 00000016A824: E0AC0000 00000000
	s_set_inst_prefetch_distance 0x1                           // 00000016A82C: BF840001
	s_branch 21                                                // 00000016A830: BFA00015 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4688>
	s_nop 0                                                    // 00000016A834: BF800000
	s_nop 0                                                    // 00000016A838: BF800000
	s_nop 0                                                    // 00000016A83C: BF800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000016A840: 8C7E017E
	v_add_nc_u32_e32 v7, 0x80, v7                              // 00000016A844: 4A0E0EFF 00000080
	.long 0xd7000404                                           // 00000016A84C: D7000404
	v_cndmask_b32_e32 v0, v4, v136, vcc_lo                     // 00000016A850: 02011104
	ds_store_b16 v6, v3 offset:10240                           // 00000016A854: D87C2800 00000306
	v_add_nc_u32_e32 v6, 0x140, v6                             // 00000016A85C: 4A0C0CFF 00000140
	.long 0xd4490001                                           // 00000016A864: D4490001
	v_cndmask_b32_e32 v1, 0x37f, v7, vcc_lo                    // 00000016A868: 02020EFF 0000037F
	v_add_co_ci_u32_e64 v5, null, 0, v5, s4                    // 00000016A870: D5207C05 00120A80
	s_or_b32 s6, s1, s6                                        // 00000016A878: 8C060601
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000016A87C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000016A880: 917E067E
	s_cbranch_execz 13                                         // 00000016A884: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x46bc>
	.long 0x7e063880                                           // 00000016A888: 7E063880
	s_and_saveexec_b32 s1, s0                                  // 00000016A88C: BE812000
	s_cbranch_execz 65515                                      // 00000016A890: BFA5FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4640>
	global_load_b32 v3, v[4:5], off                            // 00000016A894: DC520000 037C0004
	ds_load_b32 v8, v105                                       // 00000016A89C: D8D80000 08000069
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000016A8A4: BF890007
	v_mul_f32_e32 v3, v3, v8                                   // 00000016A8A8: 10061103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016A8AC: BF870001
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 00000016A8B0: CC210003 02002D03
	s_branch 65505                                             // 00000016A8B8: BFA0FFE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4640>
	s_set_inst_prefetch_distance 0x2                           // 00000016A8BC: BF840002
	s_or_b32 exec_lo, exec_lo, s6                              // 00000016A8C0: 8C7E067E
	v_lshl_add_u32 v21, s5, 2, v100                            // 00000016A8C4: D6460015 05910405
	s_waitcnt lgkmcnt(0)                                       // 00000016A8CC: BF89FC07
	s_barrier                                                  // 00000016A8D0: BFBD0000
	buffer_gl0_inv                                             // 00000016A8D4: E0AC0000 00000000
	ds_load_b128 v[22:25], v99                                 // 00000016A8DC: DBFC0000 16000063
	ds_load_b128 v[26:29], v99 offset:16                       // 00000016A8E4: DBFC0010 1A000063
	ds_load_b128 v[30:33], v99 offset:32                       // 00000016A8EC: DBFC0020 1E000063
	ds_load_b128 v[34:37], v99 offset:48                       // 00000016A8F4: DBFC0030 22000063
	ds_load_b128 v[38:41], v107                                // 00000016A8FC: DBFC0000 2600006B
	ds_load_b128 v[42:45], v107 offset:16                      // 00000016A904: DBFC0010 2A00006B
	ds_load_b128 v[46:49], v107 offset:32                      // 00000016A90C: DBFC0020 2E00006B
	ds_load_b128 v[50:53], v107 offset:48                      // 00000016A914: DBFC0030 3200006B
	ds_load_b128 v[58:61], v99 offset:80                       // 00000016A91C: DBFC0050 3A000063
	ds_load_b128 v[54:57], v99 offset:64                       // 00000016A924: DBFC0040 36000063
	ds_load_b128 v[66:69], v107 offset:80                      // 00000016A92C: DBFC0050 4200006B
	ds_load_b128 v[62:65], v107 offset:64                      // 00000016A934: DBFC0040 3E00006B
	ds_load_b128 v[74:77], v99 offset:112                      // 00000016A93C: DBFC0070 4A000063
	ds_load_b128 v[70:73], v99 offset:96                       // 00000016A944: DBFC0060 46000063
	ds_load_b128 v[112:115], v107 offset:112                   // 00000016A94C: DBFC0070 7000006B
	ds_load_b128 v[108:111], v107 offset:96                    // 00000016A954: DBFC0060 6C00006B
	ds_load_2addr_b32 v[78:79], v21 offset1:2                  // 00000016A95C: D8DC0200 4E000015
	ds_load_2addr_b32 v[80:81], v21 offset0:4 offset1:6        // 00000016A964: D8DC0604 50000015
	ds_load_2addr_b32 v[124:125], v21 offset0:8 offset1:10     // 00000016A96C: D8DC0A08 7C000015
	ds_load_2addr_b32 v[126:127], v21 offset0:12 offset1:14    // 00000016A974: D8DC0E0C 7E000015
	v_mov_b32_e32 v9, v2                                       // 00000016A97C: 7E120302
	v_mov_b32_e32 v3, v2                                       // 00000016A980: 7E060302
	v_mov_b32_e32 v4, v2                                       // 00000016A984: 7E080302
	v_mov_b32_e32 v5, v2                                       // 00000016A988: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 00000016A98C: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 00000016A990: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 00000016A994: 7E100302
	v_mov_b32_e32 v123, v9                                     // 00000016A998: 7EF60309
	v_dual_mov_b32 v119, v5 :: v_dual_mov_b32 v118, v4         // 00000016A99C: CA100105 77760104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000016A9A4: BF870214
	v_dual_mov_b32 v121, v7 :: v_dual_mov_b32 v120, v6         // 00000016A9A8: CA100107 79780106
	v_dual_mov_b32 v122, v8 :: v_dual_mov_b32 v117, v3         // 00000016A9B0: CA100108 7A740103
	v_mov_b32_e32 v116, v2                                     // 00000016A9B8: 7EE80302
	s_waitcnt lgkmcnt(3)                                       // 00000016A9BC: BF89FC37
	v_dual_mov_b32 v4, v18 :: v_dual_mul_f32 v3, v20, v78      // 00000016A9C0: CA060112 04029D14
	v_mul_f32_e32 v8, v20, v79                                 // 00000016A9C8: 10109F14
	s_waitcnt lgkmcnt(2)                                       // 00000016A9CC: BF89FC27
	v_mul_f32_e32 v9, v20, v80                                 // 00000016A9D0: 1012A114
	v_wmma_f32_16x16x16_f16 v[116:123], v[22:29], v[38:45], v[116:123]// 00000016A9D4: CC404074 1DD24D16
	v_mul_f32_e32 v22, v20, v81                                // 00000016A9DC: 102CA314
	s_waitcnt lgkmcnt(1)                                       // 00000016A9E0: BF89FC17
	v_mul_f32_e32 v23, v20, v124                               // 00000016A9E4: 102EF914
	v_mul_f32_e32 v24, v20, v125                               // 00000016A9E8: 1030FB14
	s_waitcnt lgkmcnt(0)                                       // 00000016A9EC: BF89FC07
	v_dual_mov_b32 v6, v106 :: v_dual_mul_f32 v25, v20, v126   // 00000016A9F0: CA06016A 0618FD14
	v_wmma_f32_16x16x16_f16 v[116:123], v[30:37], v[46:53], v[116:123]// 00000016A9F8: CC404074 1DD25D1E
	v_dual_mul_f32 v26, v20, v127 :: v_dual_mov_b32 v5, v19    // 00000016AA00: C8D0FF14 1A040113
	v_mov_b32_e32 v7, v89                                      // 00000016AA08: 7E0E0359
	s_mov_b32 s6, 0                                            // 00000016AA0C: BE860080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016AA10: BF870093
	v_wmma_f32_16x16x16_f16 v[116:123], v[54:61], v[62:69], v[116:123]// 00000016AA14: CC404074 1DD27D36
	v_wmma_f32_16x16x16_f16 v[116:123], v[70:77], v[108:115], v[116:123]// 00000016AA1C: CC404074 1DD2D946
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000016AA24: BF870111
	v_dual_fmac_f32 v3, 0x3b800000, v116 :: v_dual_fmac_f32 v8, 0x3b800000, v117// 00000016AA28: C800E8FF 0308EAFF 3B800000
	v_dual_fmac_f32 v9, 0x3b800000, v118 :: v_dual_fmac_f32 v22, 0x3b800000, v119// 00000016AA34: C800ECFF 0916EEFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000016AA40: BF870213
	v_dual_fmac_f32 v23, 0x3b800000, v120 :: v_dual_fmac_f32 v24, 0x3b800000, v121// 00000016AA44: C800F0FF 1718F2FF 3B800000
	v_dual_fmac_f32 v25, 0x3b800000, v122 :: v_dual_fmac_f32 v26, 0x3b800000, v123// 00000016AA50: C800F4FF 191AF6FF 3B800000
	ds_store_2addr_b32 v21, v3, v8 offset1:2                   // 00000016AA5C: D8380200 00080315
	ds_store_2addr_b32 v21, v9, v22 offset0:4 offset1:6        // 00000016AA64: D8380604 00160915
	ds_store_2addr_b32 v21, v23, v24 offset0:8 offset1:10      // 00000016AA6C: D8380A08 00181715
	ds_store_2addr_b32 v21, v25, v26 offset0:12 offset1:14     // 00000016AA74: D8380E0C 001A1915
	s_waitcnt lgkmcnt(0)                                       // 00000016AA7C: BF89FC07
	s_barrier                                                  // 00000016AA80: BFBD0000
	buffer_gl0_inv                                             // 00000016AA84: E0AC0000 00000000
	s_set_inst_prefetch_distance 0x1                           // 00000016AA8C: BF840001
	s_branch 29                                                // 00000016AA90: BFA0001D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4908>
	s_nop 0                                                    // 00000016AA94: BF800000
	s_nop 0                                                    // 00000016AA98: BF800000
	s_nop 0                                                    // 00000016AA9C: BF800000
	s_nop 0                                                    // 00000016AAA0: BF800000
	s_nop 0                                                    // 00000016AAA4: BF800000
	s_nop 0                                                    // 00000016AAA8: BF800000
	s_nop 0                                                    // 00000016AAAC: BF800000
	s_nop 0                                                    // 00000016AAB0: BF800000
	s_nop 0                                                    // 00000016AAB4: BF800000
	s_nop 0                                                    // 00000016AAB8: BF800000
	s_nop 0                                                    // 00000016AABC: BF800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000016AAC0: 8C7E017E
	v_add_nc_u32_e32 v7, 0x80, v7                              // 00000016AAC4: 4A0E0EFF 00000080
	.long 0xd7000404                                           // 00000016AACC: D7000404
	v_cndmask_b32_e32 v0, v4, v136, vcc_lo                     // 00000016AAD0: 02011104
	ds_store_b16 v6, v3 offset:10240                           // 00000016AAD4: D87C2800 00000306
	v_add_nc_u32_e32 v6, 0x140, v6                             // 00000016AADC: 4A0C0CFF 00000140
	.long 0xd4490001                                           // 00000016AAE4: D4490001
	v_cndmask_b32_e32 v1, 0x37f, v7, vcc_lo                    // 00000016AAE8: 02020EFF 0000037F
	v_add_co_ci_u32_e64 v5, null, 0, v5, s4                    // 00000016AAF0: D5207C05 00120A80
	s_or_b32 s6, s1, s6                                        // 00000016AAF8: 8C060601
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000016AAFC: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000016AB00: 917E067E
	s_cbranch_execz 65224                                      // 00000016AB04: BFA5FEC8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4428>
	.long 0x7e063880                                           // 00000016AB08: 7E063880
	s_and_saveexec_b32 s1, s0                                  // 00000016AB0C: BE812000
	s_cbranch_execz 65515                                      // 00000016AB10: BFA5FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x48c0>
	global_load_b32 v3, v[4:5], off offset:64                  // 00000016AB14: DC520040 037C0004
	ds_load_b32 v8, v105                                       // 00000016AB1C: D8D80000 08000069
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000016AB24: BF890007
	v_mul_f32_e32 v3, v3, v8                                   // 00000016AB28: 10061103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016AB2C: BF870001
	v_fma_mixlo_f16 v3, v3, s22, 0                             // 00000016AB30: CC210003 02002D03
	s_branch 65505                                             // 00000016AB38: BFA0FFE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x48c0>
	ds_load_b32 v3, v104                                       // 00000016AB3C: D8D80000 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016AB44: BF89FC07
	v_fma_f32 v3, v42, v3, v74                                 // 00000016AB48: D6130003 052A072A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AB50: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016AB54: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[84:85]           // 00000016AB5C: D6FE7C03 05520EFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016AB68: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016AB70: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016AB74: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000016AB80: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016AB88: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000016AB8C: BE802004
	s_cbranch_execz 65043                                      // 00000016AB90: BFA5FE13 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41e0>
	ds_load_b32 v3, v104 offset:8                              // 00000016AB94: D8D80008 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016AB9C: BF89FC07
	v_fma_f32 v3, v43, v3, v75                                 // 00000016ABA0: D6130003 052E072B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016ABA8: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016ABAC: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[84:85]           // 00000016ABB4: D6FE7C03 055210FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016ABC0: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016ABC8: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016ABCC: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000016ABD8: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016ABE0: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000016ABE4: BE802005
	s_cbranch_execz 65024                                      // 00000016ABE8: BFA5FE00 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41ec>
	ds_load_b32 v3, v104 offset:16                             // 00000016ABEC: D8D80010 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016ABF4: BF89FC07
	v_fma_f32 v3, v44, v3, v76                                 // 00000016ABF8: D6130003 0532072C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AC00: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016AC04: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[84:85]           // 00000016AC0C: D6FE7C03 055212FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016AC18: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016AC20: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016AC24: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000016AC30: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016AC38: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000016AC3C: BE802006
	s_cbranch_execz 65005                                      // 00000016AC40: BFA5FDED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41f8>
	ds_load_b32 v3, v104 offset:24                             // 00000016AC44: D8D80018 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016AC4C: BF89FC07
	v_fma_f32 v3, v45, v3, v77                                 // 00000016AC50: D6130003 0536072D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AC58: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016AC5C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v108, v[84:85]         // 00000016AC64: D6FE7C03 0552D8FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016AC70: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016AC78: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016AC7C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000016AC88: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016AC90: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000016AC94: BE802007
	s_cbranch_execz 64986                                      // 00000016AC98: BFA5FDDA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4204>
	ds_load_b32 v3, v104 offset:32                             // 00000016AC9C: D8D80020 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016ACA4: BF89FC07
	v_fma_f32 v3, v46, v3, v78                                 // 00000016ACA8: D6130003 053A072E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016ACB0: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016ACB4: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v109, v[84:85]         // 00000016ACBC: D6FE7C03 0552DAFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016ACC8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016ACD0: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016ACD4: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000016ACE0: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016ACE8: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000016ACEC: BE802008
	s_cbranch_execz 64967                                      // 00000016ACF0: BFA5FDC7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4210>
	ds_load_b32 v3, v104 offset:40                             // 00000016ACF4: D8D80028 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016ACFC: BF89FC07
	v_fma_f32 v3, v47, v3, v79                                 // 00000016AD00: D6130003 053E072F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AD08: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016AD0C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v110, v[84:85]         // 00000016AD14: D6FE7C03 0552DCFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016AD20: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016AD28: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016AD2C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000016AD38: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016AD40: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000016AD44: BE802009
	s_cbranch_execz 64948                                      // 00000016AD48: BFA5FDB4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x421c>
	ds_load_b32 v3, v104 offset:48                             // 00000016AD4C: D8D80030 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016AD54: BF89FC07
	v_fma_f32 v3, v48, v3, v80                                 // 00000016AD58: D6130003 05420730
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AD60: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016AD64: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v111, v[84:85]         // 00000016AD6C: D6FE7C03 0552DEFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016AD78: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016AD80: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016AD84: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000016AD90: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016AD98: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000016AD9C: BE80200A
	s_cbranch_execz 64929                                      // 00000016ADA0: BFA5FDA1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4228>
	ds_load_b32 v3, v104 offset:56                             // 00000016ADA4: D8D80038 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016ADAC: BF89FC07
	v_fmac_f32_e32 v81, v49, v3                                // 00000016ADB0: 56A20731
	v_mad_u64_u32 v[3:4], null, 0x3000, v112, v[84:85]         // 00000016ADB4: D6FE7C03 0552E0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016ADC0: BF870092
	v_mul_f32_e32 v5, 0x3b800000, v81                          // 00000016ADC4: 100AA2FF 3B800000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016ADCC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016ADD4: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016ADD8: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 00000016ADE4: DC960000 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016ADEC: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000016ADF0: BE802001
	s_cbranch_execz 64911                                      // 00000016ADF4: BFA5FD8F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4234>
	ds_load_b32 v3, v104                                       // 00000016ADF8: D8D80000 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016AE00: BF89FC07
	v_fma_f32 v3, v34, v3, v66                                 // 00000016AE04: D6130003 050A0722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AE0C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016AE10: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[84:85]           // 00000016AE18: D6FE7C03 05520EFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016AE24: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016AE2C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016AE30: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000016AE3C: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016AE44: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000016AE48: BE802004
	s_cbranch_execz 64892                                      // 00000016AE4C: BFA5FD7C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4240>
	ds_load_b32 v3, v104 offset:8                              // 00000016AE50: D8D80008 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016AE58: BF89FC07
	v_fma_f32 v3, v35, v3, v67                                 // 00000016AE5C: D6130003 050E0723
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AE64: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016AE68: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[84:85]           // 00000016AE70: D6FE7C03 055210FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016AE7C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016AE84: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016AE88: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000016AE94: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016AE9C: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000016AEA0: BE802005
	s_cbranch_execz 64873                                      // 00000016AEA4: BFA5FD69 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x424c>
	ds_load_b32 v3, v104 offset:16                             // 00000016AEA8: D8D80010 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016AEB0: BF89FC07
	v_fma_f32 v3, v36, v3, v68                                 // 00000016AEB4: D6130003 05120724
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AEBC: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016AEC0: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[84:85]           // 00000016AEC8: D6FE7C03 055212FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016AED4: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016AEDC: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016AEE0: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000016AEEC: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016AEF4: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000016AEF8: BE802006
	s_cbranch_execz 64854                                      // 00000016AEFC: BFA5FD56 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4258>
	ds_load_b32 v3, v104 offset:24                             // 00000016AF00: D8D80018 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016AF08: BF89FC07
	v_fma_f32 v3, v37, v3, v69                                 // 00000016AF0C: D6130003 05160725
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AF14: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016AF18: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v108, v[84:85]         // 00000016AF20: D6FE7C03 0552D8FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016AF2C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016AF34: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016AF38: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000016AF44: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016AF4C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000016AF50: BE802007
	s_cbranch_execz 64835                                      // 00000016AF54: BFA5FD43 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4264>
	ds_load_b32 v3, v104 offset:32                             // 00000016AF58: D8D80020 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016AF60: BF89FC07
	v_fma_f32 v3, v38, v3, v70                                 // 00000016AF64: D6130003 051A0726
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AF6C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016AF70: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v109, v[84:85]         // 00000016AF78: D6FE7C03 0552DAFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016AF84: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016AF8C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016AF90: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000016AF9C: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016AFA4: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000016AFA8: BE802008
	s_cbranch_execz 64816                                      // 00000016AFAC: BFA5FD30 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4270>
	ds_load_b32 v3, v104 offset:40                             // 00000016AFB0: D8D80028 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016AFB8: BF89FC07
	v_fma_f32 v3, v39, v3, v71                                 // 00000016AFBC: D6130003 051E0727
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016AFC4: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016AFC8: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v110, v[84:85]         // 00000016AFD0: D6FE7C03 0552DCFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016AFDC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016AFE4: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016AFE8: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000016AFF4: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016AFFC: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000016B000: BE802009
	s_cbranch_execz 64797                                      // 00000016B004: BFA5FD1D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x427c>
	ds_load_b32 v3, v104 offset:48                             // 00000016B008: D8D80030 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B010: BF89FC07
	v_fma_f32 v3, v40, v3, v72                                 // 00000016B014: D6130003 05220728
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B01C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B020: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v111, v[84:85]         // 00000016B028: D6FE7C03 0552DEFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B034: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B03C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B040: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000016B04C: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B054: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000016B058: BE80200A
	s_cbranch_execz 64778                                      // 00000016B05C: BFA5FD0A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4288>
	ds_load_b32 v3, v104 offset:56                             // 00000016B060: D8D80038 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B068: BF89FC07
	v_fmac_f32_e32 v73, v41, v3                                // 00000016B06C: 56920729
	v_mad_u64_u32 v[3:4], null, 0x3000, v112, v[84:85]         // 00000016B070: D6FE7C03 0552E0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B07C: BF870092
	v_mul_f32_e32 v5, 0x3b800000, v73                          // 00000016B080: 100A92FF 3B800000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B088: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B090: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B094: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:32          // 00000016B0A0: DC960020 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B0A8: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000016B0AC: BE802001
	s_cbranch_execz 64760                                      // 00000016B0B0: BFA5FCF8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4294>
	ds_load_b32 v3, v104                                       // 00000016B0B4: D8D80000 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B0BC: BF89FC07
	v_fma_f32 v3, v26, v3, v58                                 // 00000016B0C0: D6130003 04EA071A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B0C8: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B0CC: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[84:85]           // 00000016B0D4: D6FE7C03 05520EFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B0E0: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B0E8: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B0EC: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000016B0F8: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B100: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000016B104: BE802004
	s_cbranch_execz 64741                                      // 00000016B108: BFA5FCE5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42a0>
	ds_load_b32 v3, v104 offset:8                              // 00000016B10C: D8D80008 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B114: BF89FC07
	v_fma_f32 v3, v27, v3, v59                                 // 00000016B118: D6130003 04EE071B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B120: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B124: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[84:85]           // 00000016B12C: D6FE7C03 055210FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B138: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B140: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B144: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000016B150: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B158: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000016B15C: BE802005
	s_cbranch_execz 64722                                      // 00000016B160: BFA5FCD2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42ac>
	ds_load_b32 v3, v104 offset:16                             // 00000016B164: D8D80010 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B16C: BF89FC07
	v_fma_f32 v3, v28, v3, v60                                 // 00000016B170: D6130003 04F2071C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B178: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B17C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[84:85]           // 00000016B184: D6FE7C03 055212FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B190: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B198: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B19C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000016B1A8: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B1B0: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000016B1B4: BE802006
	s_cbranch_execz 64703                                      // 00000016B1B8: BFA5FCBF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42b8>
	ds_load_b32 v3, v104 offset:24                             // 00000016B1BC: D8D80018 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B1C4: BF89FC07
	v_fma_f32 v3, v29, v3, v61                                 // 00000016B1C8: D6130003 04F6071D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B1D0: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B1D4: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v108, v[84:85]         // 00000016B1DC: D6FE7C03 0552D8FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B1E8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B1F0: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B1F4: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000016B200: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B208: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000016B20C: BE802007
	s_cbranch_execz 64684                                      // 00000016B210: BFA5FCAC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42c4>
	ds_load_b32 v3, v104 offset:32                             // 00000016B214: D8D80020 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B21C: BF89FC07
	v_fma_f32 v3, v30, v3, v62                                 // 00000016B220: D6130003 04FA071E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B228: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B22C: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v109, v[84:85]         // 00000016B234: D6FE7C03 0552DAFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B240: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B248: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B24C: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000016B258: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B260: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000016B264: BE802008
	s_cbranch_execz 64665                                      // 00000016B268: BFA5FC99 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42d0>
	ds_load_b32 v3, v104 offset:40                             // 00000016B26C: D8D80028 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B274: BF89FC07
	v_fma_f32 v3, v31, v3, v63                                 // 00000016B278: D6130003 04FE071F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B280: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B284: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v110, v[84:85]         // 00000016B28C: D6FE7C03 0552DCFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B298: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B2A0: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B2A4: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000016B2B0: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B2B8: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000016B2BC: BE802009
	s_cbranch_execz 64646                                      // 00000016B2C0: BFA5FC86 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42dc>
	ds_load_b32 v3, v104 offset:48                             // 00000016B2C4: D8D80030 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B2CC: BF89FC07
	v_fma_f32 v3, v32, v3, v64                                 // 00000016B2D0: D6130003 05020720
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B2D8: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B2DC: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v111, v[84:85]         // 00000016B2E4: D6FE7C03 0552DEFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B2F0: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B2F8: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B2FC: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000016B308: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B310: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000016B314: BE80200A
	s_cbranch_execz 64627                                      // 00000016B318: BFA5FC73 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42e8>
	ds_load_b32 v3, v104 offset:56                             // 00000016B31C: D8D80038 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B324: BF89FC07
	v_fmac_f32_e32 v65, v33, v3                                // 00000016B328: 56820721
	v_mad_u64_u32 v[3:4], null, 0x3000, v112, v[84:85]         // 00000016B32C: D6FE7C03 0552E0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B338: BF870092
	v_mul_f32_e32 v5, 0x3b800000, v65                          // 00000016B33C: 100A82FF 3B800000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B344: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B34C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B350: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:64          // 00000016B35C: DC960040 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B364: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 00000016B368: BE802001
	s_cbranch_execz 64609                                      // 00000016B36C: BFA5FC61 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42f4>
	ds_load_b32 v3, v104                                       // 00000016B370: D8D80000 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B378: BF89FC07
	v_fma_f32 v3, v18, v3, v50                                 // 00000016B37C: D6130003 04CA0712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B384: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B388: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v7, v[84:85]           // 00000016B390: D6FE7C03 05520EFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B39C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B3A4: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B3A8: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000016B3B4: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B3BC: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000016B3C0: BE802004
	s_cbranch_execz 64590                                      // 00000016B3C4: BFA5FC4E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4300>
	ds_load_b32 v3, v104 offset:8                              // 00000016B3C8: D8D80008 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B3D0: BF89FC07
	v_fma_f32 v3, v19, v3, v51                                 // 00000016B3D4: D6130003 04CE0713
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B3DC: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B3E0: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v8, v[84:85]           // 00000016B3E8: D6FE7C03 055210FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B3F4: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B3FC: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B400: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000016B40C: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B414: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000016B418: BE802005
	s_cbranch_execz 64571                                      // 00000016B41C: BFA5FC3B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x430c>
	ds_load_b32 v3, v104 offset:16                             // 00000016B420: D8D80010 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B428: BF89FC07
	v_fma_f32 v3, v20, v3, v52                                 // 00000016B42C: D6130003 04D20714
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B434: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B438: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v9, v[84:85]           // 00000016B440: D6FE7C03 055212FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B44C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B454: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B458: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000016B464: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B46C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000016B470: BE802006
	s_cbranch_execz 64552                                      // 00000016B474: BFA5FC28 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4318>
	ds_load_b32 v3, v104 offset:24                             // 00000016B478: D8D80018 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B480: BF89FC07
	v_fma_f32 v3, v21, v3, v53                                 // 00000016B484: D6130003 04D60715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B48C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B490: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v108, v[84:85]         // 00000016B498: D6FE7C03 0552D8FF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B4A4: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B4AC: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B4B0: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000016B4BC: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B4C4: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000016B4C8: BE802007
	s_cbranch_execz 64533                                      // 00000016B4CC: BFA5FC15 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4324>
	ds_load_b32 v3, v104 offset:32                             // 00000016B4D0: D8D80020 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B4D8: BF89FC07
	v_fma_f32 v3, v22, v3, v54                                 // 00000016B4DC: D6130003 04DA0716
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B4E4: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B4E8: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v109, v[84:85]         // 00000016B4F0: D6FE7C03 0552DAFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B4FC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B504: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B508: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000016B514: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B51C: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000016B520: BE802008
	s_cbranch_execz 64514                                      // 00000016B524: BFA5FC02 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4330>
	ds_load_b32 v3, v104 offset:40                             // 00000016B528: D8D80028 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B530: BF89FC07
	v_fma_f32 v3, v23, v3, v55                                 // 00000016B534: D6130003 04DE0717
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B53C: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B540: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v110, v[84:85]         // 00000016B548: D6FE7C03 0552DCFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B554: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B55C: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B560: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000016B56C: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B574: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000016B578: BE802009
	s_cbranch_execz 64495                                      // 00000016B57C: BFA5FBEF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x433c>
	ds_load_b32 v3, v104 offset:48                             // 00000016B580: D8D80030 03000068
	s_waitcnt lgkmcnt(0)                                       // 00000016B588: BF89FC07
	v_fma_f32 v3, v24, v3, v56                                 // 00000016B58C: D6130003 04E20718
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000016B594: BF870121
	v_mul_f32_e32 v5, 0x3b800000, v3                           // 00000016B598: 100A06FF 3B800000
	v_mad_u64_u32 v[3:4], null, 0x3000, v111, v[84:85]         // 00000016B5A0: D6FE7C03 0552DEFF 00003000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000016B5AC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000016B5B4: BF870001
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000016B5B8: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off offset:96          // 00000016B5C4: DC960060 007C0503
	s_or_b32 exec_lo, exec_lo, s0                              // 00000016B5CC: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000016B5D0: BE80200A
	s_cbranch_execnz 64476                                     // 00000016B5D4: BFA6FBDC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4348>
	s_branch 64493                                             // 00000016B5D8: BFA0FBED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4390>
	v_mov_b32_e32 v2, v89                                      // 00000016B5DC: 7E040359
	v_mov_b32_e32 v3, v1                                       // 00000016B5E0: 7E060301
	s_add_u32 s0, s33, s28                                     // 00000016B5E4: 80001C21
	.long 0xd73c0000                                           // 00000016B5E8: D73C0000
	v_cndmask_b32_e32 v1, 9, v82, vcc_lo                       // 00000016B5EC: 0202A489
	s_addc_u32 s1, s34, s29                                    // 00000016B5F0: 82011D22
	s_add_u32 s2, s30, s26                                     // 00000016B5F4: 80021A1E
	s_addc_u32 s3, s31, s27                                    // 00000016B5F8: 82031B1F
	s_add_u32 s0, s2, s0                                       // 00000016B5FC: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000016B600: 82010103
	v_lshlrev_b32_e32 v4, 2, v88                               // 00000016B604: 3008B082
	.long 0xd7006a00                                           // 00000016B608: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000016B60C: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000016B610: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000016B614: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000016B61C: BE810080
	.long 0xd7006a00                                           // 00000016B620: D7006A00
	v_cndmask_b32_e32 v1, v0, v4, vcc_lo                       // 00000016B624: 02020900
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000016B628: D5207C01 01AA0280
	v_mul_u32_u24_e32 v4, 0x210, v88                           // 00000016B630: 1608B0FF 00000210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000016B638: BF870093
	.long 0xd7006a00                                           // 00000016B63C: D7006A00
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 00000016B640: 02020018
	v_add_co_ci_u32_e64 v1, null, s25, v1, vcc_lo              // 00000016B644: D5207C01 01AA0219
	s_delay_alu instid0(VALU_DEP_3)                            // 00000016B64C: BF870003
	v_lshl_add_u32 v3, v3, 2, v4                               // 00000016B650: D6460003 04110503
	s_nop 0                                                    // 00000016B658: BF800000
	s_nop 0                                                    // 00000016B65C: BF800000
	s_nop 0                                                    // 00000016B660: BF800000
	s_nop 0                                                    // 00000016B664: BF800000
	s_nop 0                                                    // 00000016B668: BF800000
	s_nop 0                                                    // 00000016B66C: BF800000
	s_nop 0                                                    // 00000016B670: BF800000
	s_nop 0                                                    // 00000016B674: BF800000
	s_nop 0                                                    // 00000016B678: BF800000
	s_nop 0                                                    // 00000016B67C: BF800000
	ds_load_b32 v4, v3 offset:12800                            // 00000016B680: D8D83200 04000003
	v_add_nc_u32_e32 v2, 0x80, v2                              // 00000016B688: 4A0404FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 00000016B690: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000016B694: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v2                        // 00000016B698: 7C9204FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 00000016B6A0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000016B6A4: BF89FC07
	global_store_b32 v[0:1], v4, off                           // 00000016B6A8: DC6A0000 007C0400
	.long 0xd7000000                                           // 00000016B6B0: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 00000016B6B4: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000016B6BC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000016B6C4: 917E017E
	s_cbranch_execnz 65517                                     // 00000016B6C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi2ELi4ELb1ELb0ELi7EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5480>
	s_nop 0                                                    // 00000016B6CC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000016B6D0: BFB60003
	s_endpgm                                                   // 00000016B6D4: BFB00000
		...

