000000000018e800 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi8EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi8EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 00000018E800: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 00000018E804: F4080300 F8000020
	s_load_b128 s[24:27], s[0:1], 0x38                         // 00000018E80C: F4080600 F8000038
	s_mov_b32 s20, s3                                          // 00000018E814: BE940003
	s_ashr_i32 s3, s2, 31                                      // 00000018E818: 86039F02
	s_waitcnt lgkmcnt(0)                                       // 00000018E81C: BF89FC07
	s_load_b32 s6, s[14:15], null                              // 00000018E820: F4000187 F8000000
	s_load_b32 s30, s[0:1], 0x48                               // 00000018E828: F4000780 F8000048
	s_lshl_b64 s[4:5], s[2:3], 2                               // 00000018E830: 84848202
	s_waitcnt lgkmcnt(0)                                       // 00000018E834: BF89FC07
	s_add_i32 s3, s6, s2                                       // 00000018E838: 81030206
	s_add_u32 s14, s26, s4                                     // 00000018E83C: 800E041A
	s_addc_u32 s15, s27, s5                                    // 00000018E840: 820F051B
	s_load_b256 s[4:11], s[0:1], null                          // 00000018E844: F40C0100 F8000000
	s_load_b32 s1, s[14:15], null                              // 00000018E84C: F4000047 F8000000
	s_add_i32 s16, s3, 1                                       // 00000018E854: 81108103
	s_mul_hi_i32 s15, s30, s2                                  // 00000018E858: 970F021E
	s_ashr_i32 s0, s16, 31                                     // 00000018E85C: 86009F10
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000018E860: BF870499
	s_lshr_b32 s0, s0, 30                                      // 00000018E864: 85009E00
	s_add_i32 s0, s16, s0                                      // 00000018E868: 81000010
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000018E86C: BF870499
	s_and_b32 s14, s0, -4                                      // 00000018E870: 8B0EC400
	s_sub_i32 s16, s3, s14                                     // 00000018E874: 81900E03
	s_ashr_i32 s3, s0, 2                                       // 00000018E878: 86038200
	s_cmp_gt_i32 s16, -1                                       // 00000018E87C: BF02C110
	s_mul_i32 s14, s30, s2                                     // 00000018E880: 960E021E
	s_cselect_b32 s17, -1, 0                                   // 00000018E884: 981180C1
	s_lshl_b64 s[14:15], s[14:15], 2                           // 00000018E888: 848E820E
	s_mov_b32 s26, s3                                          // 00000018E88C: BE9A0003
	s_add_u32 s14, s24, s14                                    // 00000018E890: 800E0E18
	s_addc_u32 s15, s25, s15                                   // 00000018E894: 820F0F19
	s_and_b32 vcc_lo, exec_lo, s17                             // 00000018E898: 8B6A117E
	s_cbranch_vccnz 11                                         // 00000018E89C: BFA4000B <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi8EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xcc>
	s_waitcnt lgkmcnt(0)                                       // 00000018E8A0: BF89FC07
	s_max_i32 s18, s1, 1                                       // 00000018E8A4: 8A128101
	s_mov_b32 s19, 0                                           // 00000018E8A8: BE930080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000018E8AC: BF870499
	s_lshl_b64 s[18:19], s[18:19], 2                           // 00000018E8B0: 84928212
	s_add_u32 s0, s14, s18                                     // 00000018E8B4: 8000120E
	s_addc_u32 s19, s15, s19                                   // 00000018E8B8: 8213130F
	s_add_u32 s18, s0, -4                                      // 00000018E8BC: 8012C400
	s_addc_u32 s19, s19, -1                                    // 00000018E8C0: 8213C113
	s_load_b32 s26, s[18:19], null                             // 00000018E8C4: F4000689 F8000000
	s_mov_b32 s18, exec_lo                                     // 00000018E8CC: BE92007E
	v_cmpx_gt_u32_e32 0x180, v0                                // 00000018E8D0: 7D9800FF 00000180
	s_cbranch_execz 64                                         // 00000018E8D8: BFA50040 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi8EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1dc>
	v_and_b32_e32 v1, 31, v0                                   // 00000018E8DC: 3602009F
	s_mul_i32 s22, s20, 0xc00                                  // 00000018E8E0: 9616FF14 00000C00
	v_lshlrev_b32_e32 v2, 4, v0                                // 00000018E8E8: 30040084
	s_ashr_i32 s23, s22, 31                                    // 00000018E8EC: 86179F16
	s_mul_i32 s19, s2, 0x3000                                  // 00000018E8F0: 9613FF02 00003000
	s_lshl_b64 s[22:23], s[22:23], 1                           // 00000018E8F8: 84968116
	v_lshlrev_b32_e32 v1, 4, v1                                // 00000018E8FC: 30020284
	s_waitcnt lgkmcnt(0)                                       // 00000018E900: BF89FC07
	s_add_u32 s4, s4, s22                                      // 00000018E904: 80041604
	s_addc_u32 s5, s5, s23                                     // 00000018E908: 82051705
	s_mul_hi_i32 s0, s2, 0x3000                                // 00000018E90C: 9700FF02 00003000
	s_add_u32 s4, s4, s19                                      // 00000018E914: 80041304
	v_and_or_b32 v4, 0x200, v2, v1                             // 00000018E918: D6570004 040604FF 00000200
	s_addc_u32 s0, s5, s0                                      // 00000018E924: 82000005
	.long 0xd7000401                                           // 00000018E928: D7000401
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000018E92C: 02020404
	v_lshl_or_b32 v3, v0, 3, 0xfffffe00                        // 00000018E930: D6560003 03FD0700 FFFFFE00
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 00000018E93C: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 00000018E944: BE840080
	s_nop 0                                                    // 00000018E948: BF800000
	s_nop 0                                                    // 00000018E94C: BF800000
	s_nop 0                                                    // 00000018E950: BF800000
	s_nop 0                                                    // 00000018E954: BF800000
	s_nop 0                                                    // 00000018E958: BF800000
	s_nop 0                                                    // 00000018E95C: BF800000
	s_nop 0                                                    // 00000018E960: BF800000
	s_nop 0                                                    // 00000018E964: BF800000
	s_nop 0                                                    // 00000018E968: BF800000
	s_nop 0                                                    // 00000018E96C: BF800000
	s_nop 0                                                    // 00000018E970: BF800000
	s_nop 0                                                    // 00000018E974: BF800000
	s_nop 0                                                    // 00000018E978: BF800000
	s_nop 0                                                    // 00000018E97C: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 00000018E980: DC5E0000 057C0001
	v_add_nc_u32_e32 v9, 0x400, v4                             // 00000018E988: 4A1208FF 00000400
	v_add_nc_u32_e32 v3, 0x200, v3                             // 00000018E990: 4A0606FF 00000200
	.long 0xd7006a01                                           // 00000018E998: D7006A01
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 00000018E99C: 020202FF 00000400
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018E9A4: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000018E9A8: D5207C02 01AA0480
	s_waitcnt vmcnt(0)                                         // 00000018E9B0: BF8903F7
	ds_store_b128 v4, v[5:8] offset:1024                       // 00000018E9B4: DB7C0400 00000504
	v_mov_b32_e32 v4, v9                                       // 00000018E9BC: 7E080309
	.long 0xd4490000                                           // 00000018E9C0: D4490000
	v_cndmask_b32_e32 v1, 0x9ff, v3, vcc_lo                    // 00000018E9C4: 020206FF 000009FF
	s_or_b32 s4, s0, s4                                        // 00000018E9CC: 8C040400
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000018E9D0: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000018E9D4: 917E047E
	s_cbranch_execnz 65513                                     // 00000018E9D8: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi8EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x180>
	s_or_b32 exec_lo, exec_lo, s18                             // 00000018E9DC: 8C7E127E
	v_cndmask_b32_e64 v1, 0, 1, s17                            // 00000018E9E0: D5010001 00450280
	v_lshrrev_b32_e32 v7, 5, v0                                // 00000018E9E8: 320E0085
	s_waitcnt lgkmcnt(0)                                       // 00000018E9EC: BF89FC07
	s_barrier                                                  // 00000018E9F0: BFBD0000
	buffer_gl0_inv                                             // 00000018E9F4: E0AC0000 00000000
	v_readfirstlane_b32 s0, v1                                 // 00000018E9FC: 7E000501
	v_lshlrev_b32_e32 v174, 7, v7                              // 00000018EA00: 315C0E87
	s_add_i32 s27, s1, s0                                      // 00000018EA04: 811B0001
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000018EA08: BF870499
	s_add_i32 s0, s27, 3                                       // 00000018EA0C: 8100831B
	s_ashr_i32 s28, s0, 2                                      // 00000018EA10: 861C8200
	s_mov_b32 s0, 0                                            // 00000018EA14: BE800080
	s_cmp_gt_i32 s28, 0                                        // 00000018EA18: BF02801C
	s_cbranch_scc1 2                                           // 00000018EA1C: BFA20002 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi8EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x228>
	v_lshlrev_b32_e32 v8, 7, v7                                // 00000018EA20: 30100E87
	s_branch 1                                                 // 00000018EA24: BFA00001 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi8EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x22c>
	s_mov_b32 s0, -1                                           // 00000018EA28: BE8000C1
	v_mov_b32_e32 v38, 0                                       // 00000018EA2C: 7E4C0280
	v_and_b32_e32 v172, 15, v0                                 // 00000018EA30: 3758008F
	v_bfe_u32 v173, v0, 4, 1                                   // 00000018EA34: D61000AD 02050900
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000018EA3C: 916A007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000018EA40: BF870003
	v_mov_b32_e32 v37, v38                                     // 00000018EA44: 7E4A0326
	v_mov_b32_e32 v36, v38                                     // 00000018EA48: 7E480326
	v_mov_b32_e32 v35, v38                                     // 00000018EA4C: 7E460326
	v_mov_b32_e32 v34, v38                                     // 00000018EA50: 7E440326
	v_mov_b32_e32 v33, v38                                     // 00000018EA54: 7E420326
	v_mov_b32_e32 v46, v38                                     // 00000018EA58: 7E5C0326
	v_mov_b32_e32 v45, v38                                     // 00000018EA5C: 7E5A0326
	v_mov_b32_e32 v44, v38                                     // 00000018EA60: 7E580326
	v_mov_b32_e32 v43, v38                                     // 00000018EA64: 7E560326
	v_mov_b32_e32 v42, v38                                     // 00000018EA68: 7E540326
	v_mov_b32_e32 v41, v38                                     // 00000018EA6C: 7E520326
	v_mov_b32_e32 v54, v38                                     // 00000018EA70: 7E6C0326
	v_mov_b32_e32 v53, v38                                     // 00000018EA74: 7E6A0326
	v_mov_b32_e32 v52, v38                                     // 00000018EA78: 7E680326
	v_mov_b32_e32 v51, v38                                     // 00000018EA7C: 7E660326
	v_mov_b32_e32 v50, v38                                     // 00000018EA80: 7E640326
	v_mov_b32_e32 v49, v38                                     // 00000018EA84: 7E620326
	v_mov_b32_e32 v62, v38                                     // 00000018EA88: 7E7C0326
	v_mov_b32_e32 v61, v38                                     // 00000018EA8C: 7E7A0326
	v_mov_b32_e32 v60, v38                                     // 00000018EA90: 7E780326
	v_mov_b32_e32 v59, v38                                     // 00000018EA94: 7E760326
	v_mov_b32_e32 v58, v38                                     // 00000018EA98: 7E740326
	v_mov_b32_e32 v57, v38                                     // 00000018EA9C: 7E720326
	v_mov_b32_e32 v30, v38                                     // 00000018EAA0: 7E3C0326
	v_mov_b32_e32 v29, v38                                     // 00000018EAA4: 7E3A0326
	v_mov_b32_e32 v28, v38                                     // 00000018EAA8: 7E380326
	v_mov_b32_e32 v27, v38                                     // 00000018EAAC: 7E360326
	v_mov_b32_e32 v26, v38                                     // 00000018EAB0: 7E340326
	v_mov_b32_e32 v25, v38                                     // 00000018EAB4: 7E320326
	v_mov_b32_e32 v22, v38                                     // 00000018EAB8: 7E2C0326
	v_mov_b32_e32 v21, v38                                     // 00000018EABC: 7E2A0326
	v_mov_b32_e32 v20, v38                                     // 00000018EAC0: 7E280326
	v_mov_b32_e32 v19, v38                                     // 00000018EAC4: 7E260326
	v_mov_b32_e32 v18, v38                                     // 00000018EAC8: 7E240326
	v_mov_b32_e32 v17, v38                                     // 00000018EACC: 7E220326
	v_mov_b32_e32 v14, v38                                     // 00000018EAD0: 7E1C0326
	v_mov_b32_e32 v13, v38                                     // 00000018EAD4: 7E1A0326
	v_mov_b32_e32 v12, v38                                     // 00000018EAD8: 7E180326
	v_mov_b32_e32 v11, v38                                     // 00000018EADC: 7E160326
	v_mov_b32_e32 v10, v38                                     // 00000018EAE0: 7E140326
	v_mov_b32_e32 v9, v38                                      // 00000018EAE4: 7E120326
	v_mov_b32_e32 v6, v38                                      // 00000018EAE8: 7E0C0326
	v_mov_b32_e32 v5, v38                                      // 00000018EAEC: 7E0A0326
	v_mov_b32_e32 v4, v38                                      // 00000018EAF0: 7E080326
	v_mov_b32_e32 v3, v38                                      // 00000018EAF4: 7E060326
	v_mov_b32_e32 v2, v38                                      // 00000018EAF8: 7E040326
	v_mov_b32_e32 v1, v38                                      // 00000018EAFC: 7E020326
	v_mov_b32_e32 v91, v38                                     // 00000018EB00: 7EB60326
	v_mov_b32_e32 v170, v38                                    // 00000018EB04: 7F540326
	v_mov_b32_e32 v90, v38                                     // 00000018EB08: 7EB40326
	v_mov_b32_e32 v171, v38                                    // 00000018EB0C: 7F560326
	v_mov_b32_e32 v89, v38                                     // 00000018EB10: 7EB20326
	v_mov_b32_e32 v169, v38                                    // 00000018EB14: 7F520326
	s_cbranch_vccnz 1254                                       // 00000018EB18: BFA404E6 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi8EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x16b4>
	v_lshlrev_b32_e32 v1, 6, v173                              // 00000018EB1C: 30035A86
	v_dual_mov_b32 v169, 0 :: v_dual_lshlrev_b32 v2, 2, v172   // 00000018EB20: CA220080 A9035882
	v_cmp_gt_u32_e32 vcc_lo, 12, v172                          // 00000018EB28: 7C99588C
	s_ashr_i32 s21, s20, 31                                    // 00000018EB2C: 86159F14
	s_lshl2_add_u32 s0, s1, s16                                // 00000018EB30: 87801001
	s_delay_alu instid0(VALU_DEP_2)                            // 00000018EB34: BF870002
	v_or3_b32 v1, v1, v2, 0x1c00                               // 00000018EB38: D6580001 03FE0501 00001C00
	v_dual_mov_b32 v65, 0 :: v_dual_lshlrev_b32 v0, 5, v0      // 00000018EB44: CA220080 41000085
	v_dual_cndmask_b32 v3, 0, v172 :: v_dual_lshlrev_b32 v2, 10, v7// 00000018EB4C: CA635880 03020E8A
	s_lshl_b64 s[4:5], s[20:21], 11                            // 00000018EB54: 84848B14
	s_add_i32 s29, s0, 1                                       // 00000018EB58: 811D8100
	s_load_b128 s[16:19], s[14:15], null                       // 00000018EB5C: F4080407 F8000000
	s_add_i32 s30, s30, -4                                     // 00000018EB64: 811EC41E
	s_add_u32 s0, s6, s4                                       // 00000018EB68: 80000406
	s_addc_u32 s4, s7, s5                                      // 00000018EB6C: 82040507
	v_dual_mov_b32 v69, v65 :: v_dual_and_b32 v0, 0x60, v0     // 00000018EB70: CA240141 450000FF 00000060
	.long 0xd7000005                                           // 00000018EB7C: D7000005
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 00000018EB80: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000018EB84: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s4, 0, s0                    // 00000018EB88: D5207C06 00010004
	v_dual_mov_b32 v67, v65 :: v_dual_lshlrev_b32 v4, 9, v7    // 00000018EB90: CA220141 43040E89
	.long 0xd7000000                                           // 00000018EB98: D7000000
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 00000018EB9C: 02020105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018EBA0: BF870001
	v_add_co_ci_u32_e64 v176, null, 0, v6, s0                  // 00000018EBA4: D5207CB0 00020C80
	v_xor_b32_e32 v5, 1, v7                                    // 00000018EBAC: 3A0A0E81
	v_dual_mov_b32 v71, v65 :: v_dual_lshlrev_b32 v6, 5, v173  // 00000018EBB0: CA220141 47075A85
	v_dual_mov_b32 v185, 0xf149f2ca :: v_dual_lshlrev_b32 v8, 1, v172// 00000018EBB8: CA2200FF B9095881 F149F2CA
	v_lshl_add_u32 v3, v3, 9, 0x400                            // 00000018EBC4: D6460003 03FD1303 00000400
	v_dual_mov_b32 v184, 0xf149f2ca :: v_dual_lshlrev_b32 v7, 8, v7// 00000018EBD0: CA2200FF B8060E88 F149F2CA
	s_lshl_b64 s[4:5], s[20:21], 8                             // 00000018EBDC: 84848814
	v_lshrrev_b32_e32 v175, 2, v172                            // 00000018EBE0: 335F5882
	v_dual_mov_b32 v186, 0xf149f2ca :: v_dual_add_nc_u32 v177, v1, v2// 00000018EBE4: CA2000FF BAB00501 F149F2CA
	v_lshl_add_u32 v178, v5, 10, v1                            // 00000018EBF0: D64600B2 04051505
	v_or3_b32 v179, v4, v6, v8                                 // 00000018EBF8: D65800B3 04220D04
	v_lshl_or_b32 v180, v172, 5, v4                            // 00000018EC00: D65600B4 04110BAC
	v_or3_b32 v181, s4, v172, v174                             // 00000018EC08: D65800B5 06BB5804
	v_dual_mov_b32 v182, s5 :: v_dual_add_nc_u32 v183, v3, v7  // 00000018EC10: CA200005 B6B60F03
	v_mov_b32_e32 v66, v65                                     // 00000018EC18: 7E840341
	v_dual_mov_b32 v68, v65 :: v_dual_mov_b32 v187, 0xf149f2ca // 00000018EC1C: CA100141 44BA00FF F149F2CA
	v_dual_mov_b32 v70, v65 :: v_dual_mov_b32 v189, 0xf149f2ca // 00000018EC28: CA100141 46BC00FF F149F2CA
	v_dual_mov_b32 v72, v65 :: v_dual_mov_b32 v89, 0           // 00000018EC34: CA100141 48580080
	v_dual_mov_b32 v188, 0xf149f2ca :: v_dual_mov_b32 v171, 0  // 00000018EC3C: CA1000FF BCAA0080 F149F2CA
	v_dual_mov_b32 v190, 0xf149f2ca :: v_dual_mov_b32 v91, 0   // 00000018EC48: CA1000FF BE5A0080 F149F2CA
	v_dual_mov_b32 v192, 0xf149f2ca :: v_dual_mov_b32 v191, 0  // 00000018EC54: CA1000FF C0BE0080 F149F2CA
	v_dual_mov_b32 v90, 0 :: v_dual_mov_b32 v193, 0            // 00000018EC60: CA100080 5AC00080
	v_dual_mov_b32 v170, 0 :: v_dual_mov_b32 v1, 0             // 00000018EC68: CA100080 AA000080
	v_dual_mov_b32 v2, v169 :: v_dual_mov_b32 v9, 0            // 00000018EC70: CA1001A9 02080080
	v_mov_b32_e32 v3, v169                                     // 00000018EC78: 7E0603A9
	v_dual_mov_b32 v4, v169 :: v_dual_mov_b32 v17, 0           // 00000018EC7C: CA1001A9 04100080
	v_mov_b32_e32 v5, v169                                     // 00000018EC84: 7E0A03A9
	v_dual_mov_b32 v6, v169 :: v_dual_mov_b32 v25, 0           // 00000018EC88: CA1001A9 06180080
	v_mov_b32_e32 v7, v169                                     // 00000018EC90: 7E0E03A9
	v_dual_mov_b32 v8, v169 :: v_dual_mov_b32 v57, 0           // 00000018EC94: CA1001A9 08380080
	v_dual_mov_b32 v10, v169 :: v_dual_mov_b32 v49, 0          // 00000018EC9C: CA1001A9 0A300080
	v_mov_b32_e32 v11, v169                                    // 00000018ECA4: 7E1603A9
	v_dual_mov_b32 v12, v169 :: v_dual_mov_b32 v41, 0          // 00000018ECA8: CA1001A9 0C280080
	v_mov_b32_e32 v13, v169                                    // 00000018ECB0: 7E1A03A9
	v_dual_mov_b32 v14, v169 :: v_dual_mov_b32 v33, 0          // 00000018ECB4: CA1001A9 0E200080
	v_mov_b32_e32 v15, v169                                    // 00000018ECBC: 7E1E03A9
	v_mov_b32_e32 v16, v169                                    // 00000018ECC0: 7E2003A9
	v_mov_b32_e32 v18, v169                                    // 00000018ECC4: 7E2403A9
	v_mov_b32_e32 v19, v169                                    // 00000018ECC8: 7E2603A9
	v_mov_b32_e32 v20, v169                                    // 00000018ECCC: 7E2803A9
	v_mov_b32_e32 v21, v169                                    // 00000018ECD0: 7E2A03A9
	v_mov_b32_e32 v22, v169                                    // 00000018ECD4: 7E2C03A9
	v_mov_b32_e32 v23, v169                                    // 00000018ECD8: 7E2E03A9
	v_mov_b32_e32 v24, v169                                    // 00000018ECDC: 7E3003A9
	v_mov_b32_e32 v26, v169                                    // 00000018ECE0: 7E3403A9
	v_mov_b32_e32 v27, v169                                    // 00000018ECE4: 7E3603A9
	v_mov_b32_e32 v28, v169                                    // 00000018ECE8: 7E3803A9
	v_mov_b32_e32 v29, v169                                    // 00000018ECEC: 7E3A03A9
	v_mov_b32_e32 v30, v169                                    // 00000018ECF0: 7E3C03A9
	v_mov_b32_e32 v31, v169                                    // 00000018ECF4: 7E3E03A9
	v_mov_b32_e32 v32, v169                                    // 00000018ECF8: 7E4003A9
	v_mov_b32_e32 v58, v169                                    // 00000018ECFC: 7E7403A9
	v_mov_b32_e32 v59, v169                                    // 00000018ED00: 7E7603A9
	v_mov_b32_e32 v60, v169                                    // 00000018ED04: 7E7803A9
	v_mov_b32_e32 v61, v169                                    // 00000018ED08: 7E7A03A9
	v_mov_b32_e32 v62, v169                                    // 00000018ED0C: 7E7C03A9
	v_mov_b32_e32 v63, v169                                    // 00000018ED10: 7E7E03A9
	v_mov_b32_e32 v64, v169                                    // 00000018ED14: 7E8003A9
	v_mov_b32_e32 v50, v169                                    // 00000018ED18: 7E6403A9
	v_mov_b32_e32 v51, v169                                    // 00000018ED1C: 7E6603A9
	v_mov_b32_e32 v52, v169                                    // 00000018ED20: 7E6803A9
	v_mov_b32_e32 v53, v169                                    // 00000018ED24: 7E6A03A9
	v_mov_b32_e32 v54, v169                                    // 00000018ED28: 7E6C03A9
	v_mov_b32_e32 v55, v169                                    // 00000018ED2C: 7E6E03A9
	v_mov_b32_e32 v56, v169                                    // 00000018ED30: 7E7003A9
	v_mov_b32_e32 v42, v169                                    // 00000018ED34: 7E5403A9
	v_mov_b32_e32 v43, v169                                    // 00000018ED38: 7E5603A9
	v_mov_b32_e32 v44, v169                                    // 00000018ED3C: 7E5803A9
	v_mov_b32_e32 v45, v169                                    // 00000018ED40: 7E5A03A9
	v_mov_b32_e32 v46, v169                                    // 00000018ED44: 7E5C03A9
	v_mov_b32_e32 v47, v169                                    // 00000018ED48: 7E5E03A9
	v_mov_b32_e32 v48, v169                                    // 00000018ED4C: 7E6003A9
	v_mov_b32_e32 v34, v169                                    // 00000018ED50: 7E4403A9
	v_mov_b32_e32 v35, v169                                    // 00000018ED54: 7E4603A9
	v_mov_b32_e32 v36, v169                                    // 00000018ED58: 7E4803A9
	v_mov_b32_e32 v37, v169                                    // 00000018ED5C: 7E4A03A9
	v_mov_b32_e32 v38, v169                                    // 00000018ED60: 7E4C03A9
	v_mov_b32_e32 v39, v169                                    // 00000018ED64: 7E4E03A9
	v_mov_b32_e32 v40, v169                                    // 00000018ED68: 7E5003A9
	s_mov_b32 s21, 0                                           // 00000018ED6C: BE950080
	v_cmp_eq_u32_e32 vcc_lo, 2, v175                           // 00000018ED70: 7C955E82
	s_branch 1051                                              // 00000018ED74: BFA0041B <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi8EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x15e4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000018ED78: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018ED7C: BF870099
	s_or_b32 exec_lo, exec_lo, s17                             // 00000018ED80: 8C7E117E
	v_ashrrev_i32_e32 v74, 31, v73                             // 00000018ED84: 3494929F
	s_ashr_i32 s17, s16, 31                                    // 00000018ED88: 86119F10
	s_ashr_i32 s23, s22, 31                                    // 00000018ED8C: 86179F16
	s_lshl_b64 s[16:17], s[16:17], 9                           // 00000018ED90: 84908910
	s_ashr_i32 s19, s18, 31                                    // 00000018ED94: 86139F12
	.long 0xd73c0049                                           // 00000018ED98: D73C0049
	v_cndmask_b32_e32 v1, 12, v73, vcc_lo                      // 00000018ED9C: 0202928C
	s_lshl_b64 s[22:23], s[22:23], 9                           // 00000018EDA0: 84968916
	s_ashr_i32 s25, s24, 31                                    // 00000018EDA4: 86199F18
	s_lshl_b64 s[18:19], s[18:19], 9                           // 00000018EDA8: 84928912
	s_lshl_b64 s[24:25], s[24:25], 9                           // 00000018EDAC: 84988918
	s_add_i32 s28, s28, -1                                     // 00000018EDB0: 811CC11C
	.long 0xd70000d5                                           // 00000018EDB4: D70000D5
	v_cndmask_b32_e32 v1, v0, v73, vcc_lo                      // 00000018EDB8: 02029300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018EDBC: BF870001
	v_add_co_ci_u32_e64 v214, null, v176, v74, s0              // 00000018EDC0: D5207CD6 000295B0
	ds_load_b128 v[145:148], v183                              // 00000018EDC8: DBFC0000 910000B7
	ds_load_b128 v[149:152], v183 offset:16                    // 00000018EDD0: DBFC0010 950000B7
	ds_load_b128 v[197:200], v183 offset:32                    // 00000018EDD8: DBFC0020 C50000B7
	ds_load_b128 v[201:204], v183 offset:48                    // 00000018EDE0: DBFC0030 C90000B7
	ds_load_b128 v[77:80], v183 offset:80                      // 00000018EDE8: DBFC0050 4D0000B7
	ds_load_b128 v[73:76], v183 offset:64                      // 00000018EDF0: DBFC0040 490000B7
	ds_load_b128 v[85:88], v183 offset:112                     // 00000018EDF8: DBFC0070 550000B7
	ds_load_b128 v[81:84], v183 offset:96                      // 00000018EE00: DBFC0060 510000B7
	ds_load_b128 v[93:96], v183 offset:144                     // 00000018EE08: DBFC0090 5D0000B7
	ds_load_b128 v[89:92], v183 offset:128                     // 00000018EE10: DBFC0080 590000B7
	ds_load_b128 v[101:104], v183 offset:176                   // 00000018EE18: DBFC00B0 650000B7
	ds_load_b128 v[97:100], v183 offset:160                    // 00000018EE20: DBFC00A0 610000B7
	ds_load_b128 v[117:120], v183 offset:208                   // 00000018EE28: DBFC00D0 750000B7
	ds_load_b128 v[113:116], v183 offset:192                   // 00000018EE30: DBFC00C0 710000B7
	ds_load_b128 v[125:128], v183 offset:240                   // 00000018EE38: DBFC00F0 7D0000B7
	ds_load_b128 v[121:124], v183 offset:224                   // 00000018EE40: DBFC00E0 790000B7
	s_clause 0x9                                               // 00000018EE48: BF850009
	global_load_b128 v[133:136], v[213:214], off offset:16     // 00000018EE4C: DC5E0010 857C00D5
	global_load_b128 v[129:132], v[213:214], off               // 00000018EE54: DC5E0000 817C00D5
	global_load_b128 v[141:144], v[213:214], off offset:144    // 00000018EE5C: DC5E0090 8D7C00D5
	global_load_b128 v[137:140], v[213:214], off offset:128    // 00000018EE64: DC5E0080 897C00D5
	global_load_b128 v[209:212], v[213:214], off offset:272    // 00000018EE6C: DC5E0110 D17C00D5
	global_load_b128 v[205:208], v[213:214], off offset:256    // 00000018EE74: DC5E0100 CD7C00D5
	global_load_b128 v[165:168], v[213:214], off offset:400    // 00000018EE7C: DC5E0190 A57C00D5
	global_load_b128 v[161:164], v[213:214], off offset:384    // 00000018EE84: DC5E0180 A17C00D5
	global_load_b128 v[157:160], v[213:214], off offset:528    // 00000018EE8C: DC5E0210 9D7C00D5
	global_load_b128 v[153:156], v[213:214], off offset:512    // 00000018EE94: DC5E0200 997C00D5
	s_waitcnt vmcnt(8) lgkmcnt(0)                              // 00000018EE9C: BF892007
	v_wmma_f32_16x16x16_bf16 v[105:112], v[145:152], v[129:136], v[65:72]// 00000018EEA0: CC414069 1D070391
	s_clause 0x3                                               // 00000018EEA8: BF850003
	global_load_b128 v[149:152], v[213:214], off offset:656    // 00000018EEAC: DC5E0290 957C00D5
	global_load_b128 v[145:148], v[213:214], off offset:640    // 00000018EEB4: DC5E0280 917C00D5
	global_load_b128 v[133:136], v[213:214], off offset:784    // 00000018EEBC: DC5E0310 857C00D5
	global_load_b128 v[129:132], v[213:214], off offset:768    // 00000018EEC4: DC5E0300 817C00D5
	s_waitcnt vmcnt(10)                                        // 00000018EECC: BF892BF7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[197:204], v[137:144], v[105:112]// 00000018EED0: CC414069 1DA713C5
	s_clause 0x1                                               // 00000018EED8: BF850001
	global_load_b128 v[141:144], v[213:214], off offset:912    // 00000018EEDC: DC5E0390 8D7C00D5
	global_load_b128 v[137:140], v[213:214], off offset:896    // 00000018EEE4: DC5E0380 897C00D5
	.long 0xd59c40c5                                           // 00000018EEEC: D59C40C5
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 00000018EEF0: 02010080
	s_waitcnt vmcnt(10)                                        // 00000018EEF4: BF892BF7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[73:80], v[205:212], v[105:112]// 00000018EEF8: CC414069 1DA79B49
	.long 0xd7000049                                           // 00000018EF00: D7000049
	v_cndmask_b32_e32 v1, s16, v181, vcc_lo                    // 00000018EF04: 02036A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000018EF08: BF8701A1
	v_add_co_ci_u32_e64 v74, null, s17, v182, s0               // 00000018EF0C: D5207C4A 00036C11
	s_waitcnt vmcnt(8)                                         // 00000018EF14: BF8923F7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[81:88], v[161:168], v[105:112]// 00000018EF18: CC414069 1DA74351
	.long 0xd700004b                                           // 00000018EF20: D700004B
	v_cndmask_b32_e32 v1, s22, v181, vcc_lo                    // 00000018EF24: 02036A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000018EF28: BF8701A1
	v_add_co_ci_u32_e64 v76, null, s23, v182, s0               // 00000018EF2C: D5207C4C 00036C17
	s_waitcnt vmcnt(6)                                         // 00000018EF34: BF891BF7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[89:96], v[153:160], v[105:112]// 00000018EF38: CC414069 1DA73359
	.long 0xd700004d                                           // 00000018EF40: D700004D
	v_cndmask_b32_e32 v1, s18, v181, vcc_lo                    // 00000018EF44: 02036A12
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018EF48: BF870001
	v_add_co_ci_u32_e64 v78, null, s19, v182, s0               // 00000018EF4C: D5207C4E 00036C13
	.long 0xd700004f                                           // 00000018EF54: D700004F
	v_cndmask_b32_e32 v1, s24, v181, vcc_lo                    // 00000018EF58: 02036A18
	.long 0xd73c0049                                           // 00000018EF5C: D73C0049
	v_cndmask_b32_e32 v1, 3, v73, vcc_lo                       // 00000018EF60: 02029283
	v_add_co_ci_u32_e64 v80, null, s25, v182, s0               // 00000018EF64: D5207C50 00036C19
	.long 0xd73c004b                                           // 00000018EF6C: D73C004B
	v_cndmask_b32_e32 v1, 3, v75, vcc_lo                       // 00000018EF70: 02029683
	.long 0xd73c004d                                           // 00000018EF74: D73C004D
	v_cndmask_b32_e32 v1, 3, v77, vcc_lo                       // 00000018EF78: 02029A83
	.long 0xd59c485e                                           // 00000018EF7C: D59C485E
	v_cndmask_b32_e32 v0, v197, v128, vcc_lo                   // 00000018EF80: 020101C5
	s_delay_alu instid0(VALU_DEP_4)                            // 00000018EF84: BF870004
	.long 0xd73c004f                                           // 00000018EF88: D73C004F
	v_cndmask_b32_e32 v1, 3, v79, vcc_lo                       // 00000018EF8C: 02029E83
	.long 0xd59c485d                                           // 00000018EF90: D59C485D
	v_cndmask_b32_e32 v0, v197, v128, vcc_lo                   // 00000018EF94: 020101C5
	.long 0xd59c485f                                           // 00000018EF98: D59C485F
	v_cndmask_b32_e32 v0, v197, v128, vcc_lo                   // 00000018EF9C: 020101C5
	.long 0xd59c4860                                           // 00000018EFA0: D59C4860
	v_cndmask_b32_e32 v0, v197, v128, vcc_lo                   // 00000018EFA4: 020101C5
	s_mov_b32 s19, s7                                          // 00000018EFA8: BE930007
	s_mov_b32 s18, s6                                          // 00000018EFAC: BE920006
	s_mov_b32 s17, s5                                          // 00000018EFB0: BE910005
	s_mov_b32 s16, s4                                          // 00000018EFB4: BE900004
	s_waitcnt vmcnt(4)                                         // 00000018EFB8: BF8913F7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[97:104], v[145:152], v[105:112]// 00000018EFBC: CC414069 1DA72361
	s_waitcnt vmcnt(2)                                         // 00000018EFC4: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000018EFC8: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[105:112], v[113:120], v[129:136], v[105:112]// 00000018EFCC: CC414069 1DA70371
	.long 0xd7000077                                           // 00000018EFD4: D7000077
	v_cndmask_b32_e32 v1, s8, v73, vcc_lo                      // 00000018EFD8: 02029208
	v_add_co_ci_u32_e64 v120, null, s9, v74, s0                // 00000018EFDC: D5207C78 00029409
	s_waitcnt vmcnt(0)                                         // 00000018EFE4: BF8903F7
	s_delay_alu instid0(VALU_DEP_3)                            // 00000018EFE8: BF870003
	v_wmma_f32_16x16x16_bf16 v[105:112], v[121:128], v[137:144], v[105:112]// 00000018EFEC: CC414069 1DA71379
	.long 0xd7000079                                           // 00000018EFF4: D7000079
	v_cndmask_b32_e32 v1, s8, v75, vcc_lo                      // 00000018EFF8: 02029608
	ds_store_2addr_b32 v177, v105, v106 offset1:32             // 00000018EFFC: D8382000 006A69B1
	ds_store_2addr_b32 v177, v107, v108 offset0:64 offset1:96  // 00000018F004: D8386040 006C6BB1
	ds_store_2addr_b32 v177, v109, v110 offset0:128 offset1:160// 00000018F00C: D838A080 006E6DB1
	ds_store_2addr_b32 v177, v111, v112 offset0:192 offset1:224// 00000018F014: D838E0C0 00706FB1
	v_add_co_ci_u32_e64 v122, null, s9, v76, s0                // 00000018F01C: D5207C7A 00029809
	.long 0xd700007b                                           // 00000018F024: D700007B
	v_cndmask_b32_e32 v1, s8, v77, vcc_lo                      // 00000018F028: 02029A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000018F02C: BF8700A1
	v_add_co_ci_u32_e64 v124, null, s9, v78, s0                // 00000018F030: D5207C7C 00029C09
	.long 0xd7000093                                           // 00000018F038: D7000093
	v_cndmask_b32_e32 v1, s8, v79, vcc_lo                      // 00000018F03C: 02029E08
	v_add_co_ci_u32_e64 v148, null, s9, v80, s0                // 00000018F040: D5207C94 0002A009
	.long 0xd4440000                                           // 00000018F048: D4440000
	v_cndmask_b32_e32 v1, s29, v172, vcc_lo                    // 00000018F04C: 0203581D
	s_add_i32 s29, s29, -16                                    // 00000018F050: 811DD01D
	s_cmp_lg_u32 s28, 0                                        // 00000018F054: BF07801C
	s_waitcnt lgkmcnt(0)                                       // 00000018F058: BF89FC07
	s_barrier                                                  // 00000018F05C: BFBD0000
	buffer_gl0_inv                                             // 00000018F060: E0AC0000 00000000
	ds_load_2addr_b32 v[81:82], v178 offset1:32                // 00000018F068: D8DC2000 510000B2
	ds_load_2addr_b32 v[83:84], v178 offset0:64 offset1:96     // 00000018F070: D8DC6040 530000B2
	ds_load_2addr_b32 v[85:86], v178 offset0:128 offset1:160   // 00000018F078: D8DCA080 550000B2
	ds_load_2addr_b32 v[87:88], v178 offset0:192 offset1:224   // 00000018F080: D8DCE0C0 570000B2
	s_waitcnt lgkmcnt(3)                                       // 00000018F088: BF89FC37
	v_dual_add_f32 v73, v106, v82 :: v_dual_add_f32 v74, v105, v81// 00000018F08C: C908A56A 494AA369
	s_waitcnt lgkmcnt(2)                                       // 00000018F094: BF89FC27
	v_dual_add_f32 v75, v108, v84 :: v_dual_add_f32 v76, v107, v83// 00000018F098: C908A96C 4B4CA76B
	s_waitcnt lgkmcnt(1)                                       // 00000018F0A0: BF89FC17
	v_dual_add_f32 v77, v110, v86 :: v_dual_add_f32 v78, v109, v85// 00000018F0A4: C908AD6E 4D4EAB6D
	v_dual_mul_f32 v73, 0x3d800000, v73 :: v_dual_mul_f32 v74, 0x3d800000, v74// 00000018F0AC: C8C692FF 494A94FF 3D800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000018F0B8: BF8701B3
	v_dual_mul_f32 v75, 0x3d800000, v75 :: v_dual_mul_f32 v76, 0x3d800000, v76// 00000018F0BC: C8C696FF 4B4C98FF 3D800000
	s_waitcnt lgkmcnt(0)                                       // 00000018F0C8: BF89FC07
	v_dual_add_f32 v79, v112, v88 :: v_dual_add_f32 v80, v111, v87// 00000018F0CC: C908B170 4F50AF6F
	v_cndmask_b32_e64 v73, 0xf149f2ca, v73, s0                 // 00000018F0D4: D5010049 000292FF F149F2CA
	v_cndmask_b32_e64 v74, 0xf149f2ca, v74, s0                 // 00000018F0E0: D501004A 000294FF F149F2CA
	v_dual_mul_f32 v77, 0x3d800000, v77 :: v_dual_mul_f32 v78, 0x3d800000, v78// 00000018F0EC: C8C69AFF 4D4E9CFF 3D800000
	v_cndmask_b32_e64 v75, 0xf149f2ca, v75, s0                 // 00000018F0F8: D501004B 000296FF F149F2CA
	v_cndmask_b32_e64 v76, 0xf149f2ca, v76, s0                 // 00000018F104: D501004C 000298FF F149F2CA
	s_delay_alu instid0(VALU_DEP_4)                            // 00000018F110: BF870004
	v_mov_b32_dpp v81, v74 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F114: 7EA202FA FF09614A
	v_mov_b32_dpp v82, v73 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F11C: 7EA402FA FF096149
	v_dual_mul_f32 v79, 0x3d800000, v79 :: v_dual_mul_f32 v80, 0x3d800000, v80// 00000018F124: C8C69EFF 4F50A0FF 3D800000
	v_cndmask_b32_e64 v77, 0xf149f2ca, v77, s0                 // 00000018F130: D501004D 00029AFF F149F2CA
	v_cndmask_b32_e64 v78, 0xf149f2ca, v78, s0                 // 00000018F13C: D501004E 00029CFF F149F2CA
	v_mov_b32_dpp v83, v76 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F148: 7EA602FA FF09614C
	v_mov_b32_dpp v84, v75 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F150: 7EA802FA FF09614B
	v_dual_max_f32 v81, v81, v81 :: v_dual_max_f32 v82, v82, v82// 00000018F158: CA94A351 5152A552
	v_cndmask_b32_e64 v79, 0xf149f2ca, v79, s0                 // 00000018F160: D501004F 00029EFF F149F2CA
	v_cndmask_b32_e64 v80, 0xf149f2ca, v80, s0                 // 00000018F16C: D5010050 0002A0FF F149F2CA
	v_mov_b32_dpp v85, v78 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F178: 7EAA02FA FF09614E
	v_mov_b32_dpp v86, v77 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F180: 7EAC02FA FF09614D
	v_dual_max_f32 v83, v83, v83 :: v_dual_max_f32 v84, v84, v84// 00000018F188: CA94A753 5354A954
	v_dual_max_f32 v81, v74, v81 :: v_dual_max_f32 v82, v73, v82// 00000018F190: CA94A34A 5152A549
	v_mov_b32_dpp v87, v80 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F198: 7EAE02FA FF096150
	v_mov_b32_dpp v88, v79 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F1A0: 7EB002FA FF09614F
	v_dual_max_f32 v85, v85, v85 :: v_dual_max_f32 v86, v86, v86// 00000018F1A8: CA94AB55 5556AD56
	v_dual_max_f32 v83, v76, v83 :: v_dual_max_f32 v84, v75, v84// 00000018F1B0: CA94A74C 5354A94B
	v_mov_b32_dpp v89, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F1B8: 7EB202FA FF096251
	v_mov_b32_dpp v90, v82 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F1C0: 7EB402FA FF096252
	v_dual_max_f32 v87, v87, v87 :: v_dual_max_f32 v88, v88, v88// 00000018F1C8: CA94AF57 5758B158
	v_dual_max_f32 v85, v78, v85 :: v_dual_max_f32 v86, v77, v86// 00000018F1D0: CA94AB4E 5556AD4D
	v_mov_b32_dpp v91, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F1D8: 7EB602FA FF096253
	v_mov_b32_dpp v92, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F1E0: 7EB802FA FF096254
	v_dual_max_f32 v89, v89, v89 :: v_dual_max_f32 v90, v90, v90// 00000018F1E8: CA94B359 595AB55A
	v_dual_max_f32 v87, v80, v87 :: v_dual_max_f32 v88, v79, v88// 00000018F1F0: CA94AF50 5758B14F
	v_mov_b32_dpp v97, v85 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F1F8: 7EC202FA FF096255
	v_mov_b32_dpp v98, v86 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F200: 7EC402FA FF096256
	v_dual_max_f32 v91, v91, v91 :: v_dual_max_f32 v92, v92, v92// 00000018F208: CA94B75B 5B5CB95C
	v_dual_max_f32 v81, v81, v89 :: v_dual_max_f32 v82, v82, v90// 00000018F210: CA94B351 5152B552
	v_mov_b32_dpp v99, v87 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F218: 7EC602FA FF096257
	v_mov_b32_dpp v100, v88 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F220: 7EC802FA FF096258
	v_dual_max_f32 v97, v97, v97 :: v_dual_max_f32 v98, v98, v98// 00000018F228: CA94C361 6162C562
	v_dual_max_f32 v83, v83, v91 :: v_dual_max_f32 v84, v84, v92// 00000018F230: CA94B753 5354B954
	v_mov_b32_dpp v89, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F238: 7EB202FA FF096451
	v_mov_b32_dpp v90, v82 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F240: 7EB402FA FF096452
	v_dual_max_f32 v99, v99, v99 :: v_dual_max_f32 v100, v100, v100// 00000018F248: CA94C763 6364C964
	v_dual_max_f32 v85, v85, v97 :: v_dual_max_f32 v86, v86, v98// 00000018F250: CA94C355 5556C556
	v_mov_b32_dpp v91, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F258: 7EB602FA FF096453
	v_mov_b32_dpp v92, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F260: 7EB802FA FF096454
	v_dual_max_f32 v89, v89, v89 :: v_dual_max_f32 v90, v90, v90// 00000018F268: CA94B359 595AB55A
	v_dual_max_f32 v87, v87, v99 :: v_dual_max_f32 v88, v88, v100// 00000018F270: CA94C757 5758C958
	v_mov_b32_dpp v97, v85 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F278: 7EC202FA FF096455
	v_mov_b32_dpp v98, v86 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F280: 7EC402FA FF096456
	v_dual_max_f32 v91, v91, v91 :: v_dual_max_f32 v92, v92, v92// 00000018F288: CA94B75B 5B5CB95C
	v_dual_max_f32 v81, v81, v89 :: v_dual_max_f32 v82, v82, v90// 00000018F290: CA94B351 5152B552
	v_mov_b32_dpp v99, v87 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F298: 7EC602FA FF096457
	v_mov_b32_dpp v100, v88 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F2A0: 7EC802FA FF096458
	v_dual_max_f32 v97, v97, v97 :: v_dual_max_f32 v98, v98, v98// 00000018F2A8: CA94C361 6162C562
	v_dual_max_f32 v83, v83, v91 :: v_dual_max_f32 v84, v84, v92// 00000018F2B0: CA94B753 5354B954
	v_mov_b32_dpp v89, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F2B8: 7EB202FA FF096851
	v_mov_b32_dpp v90, v82 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F2C0: 7EB402FA FF096852
	v_dual_max_f32 v99, v99, v99 :: v_dual_max_f32 v100, v100, v100// 00000018F2C8: CA94C763 6364C964
	v_dual_max_f32 v85, v85, v97 :: v_dual_max_f32 v86, v86, v98// 00000018F2D0: CA94C355 5556C556
	v_mov_b32_dpp v91, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F2D8: 7EB602FA FF096853
	v_mov_b32_dpp v92, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F2E0: 7EB802FA FF096854
	v_max3_f32 v149, v184, v81, v89                            // 00000018F2E8: D61C0095 0566A3B8
	v_max3_f32 v150, v185, v82, v90                            // 00000018F2F0: D61C0096 056AA5B9
	v_dual_max_f32 v87, v87, v99 :: v_dual_max_f32 v88, v88, v100// 00000018F2F8: CA94C757 5758C958
	v_mov_b32_dpp v97, v85 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F300: 7EC202FA FF096855
	v_mov_b32_dpp v98, v86 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F308: 7EC402FA FF096856
	v_max3_f32 v151, v186, v83, v91                            // 00000018F310: D61C0097 056EA7BA
	v_max3_f32 v152, v187, v84, v92                            // 00000018F318: D61C0098 0572A9BB
	v_dual_sub_f32 v74, v74, v149 :: v_dual_sub_f32 v73, v73, v150// 00000018F320: C94B2B4A 4A492D49
	v_mov_b32_dpp v99, v87 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F328: 7EC602FA FF096857
	v_mov_b32_dpp v100, v88 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018F330: 7EC802FA FF096858
	v_max3_f32 v153, v188, v85, v97                            // 00000018F338: D61C0099 0586ABBC
	v_max3_f32 v154, v189, v86, v98                            // 00000018F340: D61C009A 058AADBD
	v_dual_sub_f32 v76, v76, v151 :: v_dual_sub_f32 v75, v75, v152// 00000018F348: C94B2F4C 4C4B314B
	v_dual_mul_f32 v81, 0x3fb8aa3b, v73 :: v_dual_mul_f32 v82, 0x3fb8aa3b, v74// 00000018F350: C8C692FF 515294FF 3FB8AA3B
	v_max3_f32 v155, v190, v87, v99                            // 00000018F35C: D61C009B 058EAFBE
	v_max3_f32 v156, v192, v88, v100                           // 00000018F364: D61C009C 0592B1C0
	v_dual_sub_f32 v78, v78, v153 :: v_dual_sub_f32 v77, v77, v154// 00000018F36C: C94B334E 4E4D354D
	v_dual_mul_f32 v83, 0x3fb8aa3b, v75 :: v_dual_mul_f32 v84, 0x3fb8aa3b, v76// 00000018F374: C8C696FF 535498FF 3FB8AA3B
	v_fma_f32 v89, 0x3fb8aa3b, v73, -v81                       // 00000018F380: D6130059 854692FF 3FB8AA3B
	v_rndne_f32_e32 v90, v81                                   // 00000018F38C: 7EB44751
	v_dual_sub_f32 v80, v80, v155 :: v_dual_sub_f32 v79, v79, v156// 00000018F390: C94B3750 504F394F
	v_dual_mul_f32 v85, 0x3fb8aa3b, v77 :: v_dual_mul_f32 v86, 0x3fb8aa3b, v78// 00000018F398: C8C69AFF 55569CFF 3FB8AA3B
	v_fma_f32 v91, 0x3fb8aa3b, v74, -v82                       // 00000018F3A4: D613005B 854A94FF 3FB8AA3B
	v_rndne_f32_e32 v92, v82                                   // 00000018F3B0: 7EB84752
	v_rndne_f32_e32 v100, v84                                  // 00000018F3B4: 7EC84754
	v_fmac_f32_e32 v89, 0x32a5705f, v73                        // 00000018F3B8: 56B292FF 32A5705F
	v_sub_f32_e32 v81, v81, v90                                // 00000018F3C0: 08A2B551
	v_dual_mul_f32 v87, 0x3fb8aa3b, v79 :: v_dual_mul_f32 v88, 0x3fb8aa3b, v80// 00000018F3C4: C8C69EFF 5758A0FF 3FB8AA3B
	v_fma_f32 v97, 0x3fb8aa3b, v75, -v83                       // 00000018F3D0: D6130061 854E96FF 3FB8AA3B
	v_rndne_f32_e32 v98, v83                                   // 00000018F3DC: 7EC44753
	v_fma_f32 v99, 0x3fb8aa3b, v76, -v84                       // 00000018F3E0: D6130063 855298FF 3FB8AA3B
	v_rndne_f32_e32 v104, v86                                  // 00000018F3EC: 7ED04756
	v_dual_fmac_f32 v91, 0x32a5705f, v74 :: v_dual_sub_f32 v82, v82, v92// 00000018F3F0: C80A94FF 5B52B952 32A5705F
	v_dual_sub_f32 v84, v84, v100 :: v_dual_add_f32 v81, v81, v89// 00000018F3FC: C948C954 5450B351
	v_sub_f32_e32 v164, v187, v152                             // 00000018F404: 094931BB
	v_fma_f32 v103, 0x3fb8aa3b, v78, -v86                      // 00000018F408: D6130067 855A9CFF 3FB8AA3B
	v_rndne_f32_e32 v108, v88                                  // 00000018F414: 7ED84758
	v_dual_fmac_f32 v97, 0x32a5705f, v75 :: v_dual_sub_f32 v86, v86, v104// 00000018F418: C80A96FF 6156D156 32A5705F
	v_dual_sub_f32 v83, v83, v98 :: v_dual_add_f32 v82, v82, v91// 00000018F424: C948C553 5352B752
	v_exp_f32_e32 v81, v81                                     // 00000018F42C: 7EA24B51
	v_fma_f32 v101, 0x3fb8aa3b, v77, -v85                      // 00000018F430: D6130065 85569AFF 3FB8AA3B
	v_rndne_f32_e32 v102, v85                                  // 00000018F43C: 7ECC4755
	v_fma_f32 v107, 0x3fb8aa3b, v80, -v88                      // 00000018F440: D613006B 8562A0FF 3FB8AA3B
	v_cvt_i32_f32_e32 v90, v90                                 // 00000018F44C: 7EB4115A
	v_fmac_f32_e32 v103, 0x32a5705f, v78                       // 00000018F450: 56CE9CFF 32A5705F
	v_fmac_f32_e32 v99, 0x32a5705f, v76                        // 00000018F458: 56C698FF 32A5705F
	v_dual_sub_f32 v88, v88, v108 :: v_dual_add_f32 v83, v83, v97// 00000018F460: C948D958 5852C353
	v_sub_f32_e32 v162, v185, v150                             // 00000018F468: 09452DB9
	v_exp_f32_e32 v82, v82                                     // 00000018F46C: 7EA44B52
	v_cvt_i32_f32_e32 v92, v92                                 // 00000018F470: 7EB8115C
	v_fmac_f32_e32 v107, 0x32a5705f, v80                       // 00000018F474: 56D6A0FF 32A5705F
	v_dual_sub_f32 v85, v85, v102 :: v_dual_add_f32 v86, v86, v103// 00000018F47C: C948CD55 5556CF56
	v_dual_fmac_f32 v101, 0x32a5705f, v77 :: v_dual_add_f32 v84, v84, v99// 00000018F484: C8089AFF 6554C754 32A5705F
	v_exp_f32_e32 v83, v83                                     // 00000018F490: 7EA64B53
	.long 0xd71c0051                                           // 00000018F494: D71C0051
	v_cndmask_b32_e32 v1, v81, v90, vcc_lo                     // 00000018F498: 0202B551
	.long 0xd41b0000                                           // 00000018F49C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v73, vcc_lo              // 00000018F4A0: 020292FF C2CE8ED0
	v_fma_f32 v105, 0x3fb8aa3b, v79, -v87                      // 00000018F4A8: D6130069 855E9EFF 3FB8AA3B
	v_rndne_f32_e32 v106, v87                                  // 00000018F4B4: 7ED44757
	v_cvt_i32_f32_e32 v98, v98                                 // 00000018F4B8: 7EC41162
	v_dual_add_f32 v88, v88, v107 :: v_dual_add_f32 v85, v85, v101// 00000018F4BC: C908D758 5854CB55
	v_sub_f32_e32 v168, v192, v156                             // 00000018F4C4: 095139C0
	v_exp_f32_e32 v84, v84                                     // 00000018F4C8: 7EA84B54
	.long 0xd71c0052                                           // 00000018F4CC: D71C0052
	v_cndmask_b32_e32 v1, v82, v92, vcc_lo                     // 00000018F4D0: 0202B952
	v_cndmask_b32_e64 v81, 0, v81, s0                          // 00000018F4D4: D5010051 0002A280
	.long 0xd41b0000                                           // 00000018F4DC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v74, vcc_lo              // 00000018F4E0: 020294FF C2CE8ED0
	v_cvt_i32_f32_e32 v100, v100                               // 00000018F4E8: 7EC81164
	v_fmac_f32_e32 v105, 0x32a5705f, v79                       // 00000018F4EC: 56D29EFF 32A5705F
	v_sub_f32_e32 v87, v87, v106                               // 00000018F4F4: 08AED557
	v_exp_f32_e32 v85, v85                                     // 00000018F4F8: 7EAA4B55
	.long 0xd71c0053                                           // 00000018F4FC: D71C0053
	v_cndmask_b32_e32 v1, v83, v98, vcc_lo                     // 00000018F500: 0202C553
	v_cndmask_b32_e64 v82, 0, v82, s0                          // 00000018F504: D5010052 0002A480
	.long 0xd41b0000                                           // 00000018F50C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v75, vcc_lo              // 00000018F510: 020296FF C2CE8ED0
	v_cvt_i32_f32_e32 v102, v102                               // 00000018F518: 7ECC1166
	v_dual_add_f32 v87, v87, v105 :: v_dual_sub_f32 v166, v189, v154// 00000018F51C: C90AD357 57A735BD
	v_exp_f32_e32 v86, v86                                     // 00000018F524: 7EAC4B56
	.long 0xd71c0054                                           // 00000018F528: D71C0054
	v_cndmask_b32_e32 v1, v84, v100, vcc_lo                    // 00000018F52C: 0202C954
	v_cndmask_b32_e64 v83, 0, v83, s0                          // 00000018F530: D5010053 0002A680
	.long 0xd41b0000                                           // 00000018F538: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v76, vcc_lo              // 00000018F53C: 020298FF C2CE8ED0
	v_cvt_i32_f32_e32 v104, v104                               // 00000018F544: 7ED01168
	v_exp_f32_e32 v87, v87                                     // 00000018F548: 7EAE4B57
	.long 0xd71c0055                                           // 00000018F54C: D71C0055
	v_cndmask_b32_e32 v1, v85, v102, vcc_lo                    // 00000018F550: 0202CD55
	v_exp_f32_e32 v88, v88                                     // 00000018F554: 7EB04B58
	v_cndmask_b32_e64 v84, 0, v84, s0                          // 00000018F558: D5010054 0002A880
	.long 0xd41b0000                                           // 00000018F560: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v77, vcc_lo              // 00000018F564: 02029AFF C2CE8ED0
	v_cvt_i32_f32_e32 v89, v106                                // 00000018F56C: 7EB2116A
	.long 0xd71c0056                                           // 00000018F570: D71C0056
	v_cndmask_b32_e32 v1, v86, v104, vcc_lo                    // 00000018F574: 0202D156
	v_cvt_i32_f32_e32 v91, v108                                // 00000018F578: 7EB6116C
	v_dual_sub_f32 v163, v186, v151 :: v_dual_mov_b32 v192, v156// 00000018F57C: C9512FBA A3C0019C
	v_cndmask_b32_e64 v85, 0, v85, s0                          // 00000018F584: D5010055 0002AA80
	.long 0xd41b0000                                           // 00000018F58C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v78, vcc_lo              // 00000018F590: 02029CFF C2CE8ED0
	.long 0xd71c0057                                           // 00000018F598: D71C0057
	v_cndmask_b32_e32 v1, v87, v89, vcc_lo                     // 00000018F59C: 0202B357
	.long 0xd71c0058                                           // 00000018F5A0: D71C0058
	v_cndmask_b32_e32 v1, v88, v91, vcc_lo                     // 00000018F5A4: 0202B758
	v_dual_mov_b32 v186, v151 :: v_dual_sub_f32 v161, v184, v149// 00000018F5A8: CA0A0197 BAA12BB8
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000018F5B0: BF8701C4
	v_cndmask_b32_e64 v86, 0, v86, s0                          // 00000018F5B4: D5010056 0002AC80
	.long 0xd41b0000                                           // 00000018F5BC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v79, vcc_lo              // 00000018F5C0: 02029EFF C2CE8ED0
	v_dual_mov_b32 v184, v149 :: v_dual_sub_f32 v165, v188, v153// 00000018F5C8: CA0A0195 B8A533BC
	v_dual_sub_f32 v167, v190, v155 :: v_dual_mov_b32 v188, v153// 00000018F5D0: C95137BE A7BC0199
	v_cndmask_b32_e64 v87, 0, v87, s0                          // 00000018F5D8: D5010057 0002AE80
	.long 0xd41b0000                                           // 00000018F5E0: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v80, vcc_lo              // 00000018F5E4: 0202A0FF C2CE8ED0
	v_dual_mov_b32 v190, v155 :: v_dual_mov_b32 v185, v150     // 00000018F5EC: CA10019B BEB80196
	v_mul_f32_e32 v156, 0x3fb8aa3b, v168                       // 00000018F5F4: 113950FF 3FB8AA3B
	v_mul_f32_e32 v150, 0x3fb8aa3b, v162                       // 00000018F5FC: 112D44FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000018F604: BF870224
	v_cndmask_b32_e64 v88, 0, v88, s0                          // 00000018F608: D5010058 0002B080
	.long 0xd41e0000                                           // 00000018F610: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v73, vcc_lo              // 00000018F614: 020292FF 42B17218
	v_fma_f32 v211, 0x3fb8aa3b, v168, -v156                    // 00000018F61C: D61300D3 867350FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000018F628: BF870224
	v_rndne_f32_e32 v200, v150                                 // 00000018F62C: 7F904796
	v_mov_b32_e32 v187, v152                                   // 00000018F630: 7F760398
	v_cndmask_b32_e64 v89, 0x7f800000, v81, s0                 // 00000018F634: D5010059 0002A2FF 7F800000
	.long 0xd41e0000                                           // 00000018F640: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v74, vcc_lo              // 00000018F644: 020294FF 42B17218
	v_mul_f32_e32 v152, 0x3fb8aa3b, v164                       // 00000018F64C: 113148FF 3FB8AA3B
	v_fma_f32 v199, 0x3fb8aa3b, v162, -v150                    // 00000018F654: D61300C7 865B44FF 3FB8AA3B
	v_rndne_f32_e32 v212, v156                                 // 00000018F660: 7FA8479C
	.long 0xd59c08c5                                           // 00000018F664: D59C08C5
	v_cndmask_b32_e32 v0, v89, v128, vcc_lo                    // 00000018F668: 02010159
	v_cndmask_b32_e64 v157, 0x7f800000, v82, s0                // 00000018F66C: D501009D 0002A4FF 7F800000
	.long 0xd41e0000                                           // 00000018F678: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v75, vcc_lo              // 00000018F67C: 020296FF 42B17218
	v_rndne_f32_e32 v204, v152                                 // 00000018F684: 7F984798
	v_mov_b32_e32 v189, v154                                   // 00000018F688: 7F7A039A
	v_and_b32_e32 v73, 1, v197                                 // 00000018F68C: 36938A81
	.long 0xd59c085d                                           // 00000018F690: D59C085D
	v_cndmask_b32_e32 v0, v157, v128, vcc_lo                   // 00000018F694: 0201019D
	v_cndmask_b32_e64 v90, 0x7f800000, v83, s0                 // 00000018F698: D501005A 0002A6FF 7F800000
	.long 0xd41e0000                                           // 00000018F6A4: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v76, vcc_lo              // 00000018F6A8: 020298FF 42B17218
	v_mul_f32_e32 v154, 0x3fb8aa3b, v166                       // 00000018F6B0: 11354CFF 3FB8AA3B
	v_add3_u32 v73, v89, v73, 0x7fff                           // 00000018F6B8: D6550049 03FE9359 00007FFF
	v_and_b32_e32 v75, 1, v93                                  // 00000018F6C4: 3696BA81
	.long 0xd59c08c5                                           // 00000018F6C8: D59C08C5
	v_cndmask_b32_e32 v0, v90, v128, vcc_lo                    // 00000018F6CC: 0201015A
	v_cndmask_b32_e64 v158, 0x7f800000, v84, s0                // 00000018F6D0: D501009E 0002A8FF 7F800000
	.long 0xd41e0000                                           // 00000018F6DC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v77, vcc_lo              // 00000018F6E0: 02029AFF 42B17218
	v_rndne_f32_e32 v208, v154                                 // 00000018F6E8: 7FA0479A
	v_add3_u32 v75, v157, v75, 0x7fff                          // 00000018F6EC: D655004B 03FE979D 00007FFF
	v_and_b32_e32 v74, 1, v197                                 // 00000018F6F8: 36958A81
	.long 0xd59c085e                                           // 00000018F6FC: D59C085E
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                   // 00000018F700: 0201019E
	v_cndmask_b32_e64 v91, 0x7f800000, v85, s0                 // 00000018F704: D501005B 0002AAFF 7F800000
	.long 0xd41e0000                                           // 00000018F710: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v78, vcc_lo              // 00000018F714: 02029CFF 42B17218
	v_mul_f32_e32 v149, 0x3fb8aa3b, v161                       // 00000018F71C: 112B42FF 3FB8AA3B
	v_add3_u32 v74, v90, v74, 0x7fff                           // 00000018F724: D655004A 03FE955A 00007FFF
	v_and_b32_e32 v76, 1, v94                                  // 00000018F730: 3698BC81
	.long 0xd59c08c5                                           // 00000018F734: D59C08C5
	v_cndmask_b32_e32 v0, v91, v128, vcc_lo                    // 00000018F738: 0201015B
	v_cndmask_b32_e64 v159, 0x7f800000, v86, s0                // 00000018F73C: D501009F 0002ACFF 7F800000
	.long 0xd41e0000                                           // 00000018F748: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v79, vcc_lo              // 00000018F74C: 02029EFF 42B17218
	v_fma_f32 v203, 0x3fb8aa3b, v164, -v152                    // 00000018F754: D61300CB 866348FF 3FB8AA3B
	v_add3_u32 v76, v158, v76, 0x7fff                          // 00000018F760: D655004C 03FE999E 00007FFF
	v_and_b32_e32 v78, 1, v197                                 // 00000018F76C: 369D8A81
	.long 0xd59c085f                                           // 00000018F770: D59C085F
	v_cndmask_b32_e32 v0, v159, v128, vcc_lo                   // 00000018F774: 0201019F
	v_cndmask_b32_e64 v92, 0x7f800000, v87, s0                 // 00000018F778: D501005C 0002AEFF 7F800000
	.long 0xd41e0000                                           // 00000018F784: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v80, vcc_lo              // 00000018F788: 0202A0FF 42B17218
	v_fma_f32 v207, 0x3fb8aa3b, v166, -v154                    // 00000018F790: D61300CF 866B4CFF 3FB8AA3B
	v_add3_u32 v78, v91, v78, 0x7fff                           // 00000018F79C: D655004E 03FE9D5B 00007FFF
	v_and_b32_e32 v77, 1, v95                                  // 00000018F7A8: 369ABE81
	.long 0xd59c08c5                                           // 00000018F7AC: D59C08C5
	v_cndmask_b32_e32 v0, v92, v128, vcc_lo                    // 00000018F7B0: 0201015C
	v_cndmask_b32_e64 v160, 0x7f800000, v88, s0                // 00000018F7B4: D50100A0 0002B0FF 7F800000
	v_sub_f32_e32 v154, v154, v208                             // 00000018F7C0: 0935A19A
	v_rndne_f32_e32 v198, v149                                 // 00000018F7C4: 7F8C4795
	v_add3_u32 v77, v159, v77, 0x7fff                          // 00000018F7C8: D655004D 03FE9B9F 00007FFF
	v_and_b32_e32 v80, 1, v197                                 // 00000018F7D4: 36A18A81
	.long 0xd59c0860                                           // 00000018F7D8: D59C0860
	v_cndmask_b32_e32 v0, v160, v128, vcc_lo                   // 00000018F7DC: 020101A0
	v_fma_f32 v197, 0x3fb8aa3b, v161, -v149                    // 00000018F7E0: D61300C5 865742FF 3FB8AA3B
	v_dual_mul_f32 v151, 0x3fb8aa3b, v163 :: v_dual_sub_f32 v156, v156, v212// 00000018F7EC: C8CB46FF 979DA99C 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000018F7F8: BF870214
	v_add3_u32 v80, v92, v80, 0x7fff                           // 00000018F7FC: D6550050 03FEA15C 00007FFF
	v_and_b32_e32 v79, 1, v96                                  // 00000018F808: 369EC081
	v_fmac_f32_e32 v203, 0x32a5705f, v164                      // 00000018F80C: 579748FF 32A5705F
	v_dual_sub_f32 v152, v152, v204 :: v_dual_fmac_f32 v197, 0x32a5705f, v161// 00000018F814: C9419998 98C542FF 32A5705F
	v_fmac_f32_e32 v207, 0x32a5705f, v166                      // 00000018F820: 579F4CFF 32A5705F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000018F828: BF870004
	v_add3_u32 v79, v160, v79, 0x7fff                          // 00000018F82C: D655004F 03FE9FA0 00007FFF
	ds_store_b16_d16_hi v179, v75                              // 00000018F838: DA840000 00004BB3
	ds_store_b16_d16_hi v179, v73 offset:64                    // 00000018F840: DA840040 000049B3
	ds_store_b16_d16_hi v179, v76 offset:128                   // 00000018F848: DA840080 00004CB3
	ds_store_b16_d16_hi v179, v74 offset:192                   // 00000018F850: DA8400C0 00004AB3
	ds_store_b16_d16_hi v179, v77 offset:256                   // 00000018F858: DA840100 00004DB3
	ds_store_b16_d16_hi v179, v78 offset:320                   // 00000018F860: DA840140 00004EB3
	ds_store_b16_d16_hi v179, v79 offset:384                   // 00000018F868: DA840180 00004FB3
	ds_store_b16_d16_hi v179, v80 offset:448                   // 00000018F870: DA8401C0 000050B3
	ds_load_b128 v[73:76], v180                                // 00000018F878: DBFC0000 490000B4
	ds_load_b128 v[77:80], v180 offset:16                      // 00000018F880: DBFC0010 4D0000B4
	s_clause 0x1f                                              // 00000018F888: BF85001F
	global_load_b64 v[81:82], v[119:120], off                  // 00000018F88C: DC560000 517C0077
	global_load_b64 v[93:94], v[119:120], off offset:128       // 00000018F894: DC560080 5D7C0077
	global_load_b64 v[101:102], v[119:120], off offset:256     // 00000018F89C: DC560100 657C0077
	global_load_b64 v[109:110], v[119:120], off offset:384     // 00000018F8A4: DC560180 6D7C0077
	global_load_b64 v[83:84], v[121:122], off                  // 00000018F8AC: DC560000 537C0079
	global_load_b64 v[95:96], v[121:122], off offset:128       // 00000018F8B4: DC560080 5F7C0079
	global_load_b64 v[103:104], v[121:122], off offset:256     // 00000018F8BC: DC560100 677C0079
	global_load_b64 v[111:112], v[121:122], off offset:384     // 00000018F8C4: DC560180 6F7C0079
	global_load_b64 v[85:86], v[123:124], off                  // 00000018F8CC: DC560000 557C007B
	global_load_b64 v[97:98], v[123:124], off offset:128       // 00000018F8D4: DC560080 617C007B
	global_load_b64 v[105:106], v[123:124], off offset:256     // 00000018F8DC: DC560100 697C007B
	global_load_b64 v[113:114], v[123:124], off offset:384     // 00000018F8E4: DC560180 717C007B
	global_load_b64 v[87:88], v[147:148], off                  // 00000018F8EC: DC560000 577C0093
	global_load_b64 v[99:100], v[147:148], off offset:128      // 00000018F8F4: DC560080 637C0093
	global_load_b64 v[107:108], v[147:148], off offset:256     // 00000018F8FC: DC560100 6B7C0093
	global_load_b64 v[115:116], v[147:148], off offset:384     // 00000018F904: DC560180 737C0093
	global_load_b64 v[117:118], v[119:120], off offset:512     // 00000018F90C: DC560200 757C0077
	global_load_b64 v[125:126], v[119:120], off offset:640     // 00000018F914: DC560280 7D7C0077
	global_load_b64 v[133:134], v[119:120], off offset:768     // 00000018F91C: DC560300 857C0077
	global_load_b64 v[141:142], v[119:120], off offset:896     // 00000018F924: DC560380 8D7C0077
	global_load_b64 v[119:120], v[121:122], off offset:512     // 00000018F92C: DC560200 777C0079
	global_load_b64 v[127:128], v[121:122], off offset:640     // 00000018F934: DC560280 7F7C0079
	global_load_b64 v[135:136], v[121:122], off offset:768     // 00000018F93C: DC560300 877C0079
	global_load_b64 v[143:144], v[121:122], off offset:896     // 00000018F944: DC560380 8F7C0079
	global_load_b64 v[121:122], v[123:124], off offset:512     // 00000018F94C: DC560200 797C007B
	global_load_b64 v[129:130], v[123:124], off offset:640     // 00000018F954: DC560280 817C007B
	global_load_b64 v[137:138], v[123:124], off offset:768     // 00000018F95C: DC560300 897C007B
	global_load_b64 v[145:146], v[123:124], off offset:896     // 00000018F964: DC560380 917C007B
	global_load_b64 v[123:124], v[147:148], off offset:512     // 00000018F96C: DC560200 7B7C0093
	global_load_b64 v[131:132], v[147:148], off offset:640     // 00000018F974: DC560280 837C0093
	global_load_b64 v[139:140], v[147:148], off offset:768     // 00000018F97C: DC560300 8B7C0093
	global_load_b64 v[147:148], v[147:148], off offset:896     // 00000018F984: DC560380 937C0093
	v_dual_sub_f32 v149, v149, v198 :: v_dual_add_f32 v154, v154, v207// 00000018F98C: C9498D95 959B9F9A
	v_fma_f32 v201, 0x3fb8aa3b, v163, -v151                    // 00000018F994: D61300C9 865F46FF 3FB8AA3B
	v_rndne_f32_e32 v202, v151                                 // 00000018F9A0: 7F944797
	v_sub_f32_e32 v150, v150, v200                             // 00000018F9A4: 092D9196
	v_fmac_f32_e32 v211, 0x32a5705f, v168                      // 00000018F9A8: 57A750FF 32A5705F
	v_dual_fmac_f32 v199, 0x32a5705f, v162 :: v_dual_add_f32 v152, v152, v203// 00000018F9B0: C80944FF C7999798 32A5705F
	v_add_f32_e32 v149, v149, v197                             // 00000018F9BC: 072B8B95
	v_fmac_f32_e32 v201, 0x32a5705f, v163                      // 00000018F9C0: 579346FF 32A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000018F9C8: BF870214
	v_dual_sub_f32 v151, v151, v202 :: v_dual_add_f32 v156, v156, v211// 00000018F9CC: C9499597 979DA79C
	v_dual_mul_f32 v153, 0x3fb8aa3b, v165 :: v_dual_add_f32 v150, v150, v199// 00000018F9D4: C8C94AFF 99978F96 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000018F9E0: BF8701A4
	v_exp_f32_e32 v149, v149                                   // 00000018F9E4: 7F2A4B95
	v_cvt_i32_f32_e32 v198, v198                               // 00000018F9E8: 7F8C11C6
	v_add_f32_e32 v151, v151, v201                             // 00000018F9EC: 072F9397
	s_delay_alu instid0(VALU_DEP_3)                            // 00000018F9F0: BF870003
	v_fma_f32 v205, 0x3fb8aa3b, v165, -v153                    // 00000018F9F4: D61300CD 86674AFF 3FB8AA3B
	v_rndne_f32_e32 v206, v153                                 // 00000018FA00: 7F9C4799
	v_exp_f32_e32 v150, v150                                   // 00000018FA04: 7F2C4B96
	v_mul_f32_e32 v155, 0x3fb8aa3b, v167                       // 00000018FA08: 11374EFF 3FB8AA3B
	v_cvt_i32_f32_e32 v200, v200                               // 00000018FA10: 7F9011C8
	v_fmac_f32_e32 v205, 0x32a5705f, v165                      // 00000018FA14: 579B4AFF 32A5705F
	v_sub_f32_e32 v153, v153, v206                             // 00000018FA1C: 09339D99
	v_exp_f32_e32 v151, v151                                   // 00000018FA20: 7F2E4B97
	.long 0xd71c0095                                           // 00000018FA24: D71C0095
	v_cndmask_b32_e32 v1, v149, v198, vcc_lo                   // 00000018FA28: 02038D95
	.long 0xd41b0000                                           // 00000018FA2C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v161, vcc_lo             // 00000018FA30: 020342FF C2CE8ED0
	v_fma_f32 v209, 0x3fb8aa3b, v167, -v155                    // 00000018FA38: D61300D1 866F4EFF 3FB8AA3B
	v_rndne_f32_e32 v210, v155                                 // 00000018FA44: 7FA4479B
	v_cvt_i32_f32_e32 v202, v202                               // 00000018FA48: 7F9411CA
	v_add_f32_e32 v153, v153, v205                             // 00000018FA4C: 07339B99
	v_exp_f32_e32 v152, v152                                   // 00000018FA50: 7F304B98
	.long 0xd71c0096                                           // 00000018FA54: D71C0096
	v_cndmask_b32_e32 v1, v150, v200, vcc_lo                   // 00000018FA58: 02039196
	v_cndmask_b32_e64 v149, 0, v149, s0                        // 00000018FA5C: D5010095 00032A80
	.long 0xd41b0000                                           // 00000018FA64: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v162, vcc_lo             // 00000018FA68: 020344FF C2CE8ED0
	v_cvt_i32_f32_e32 v204, v204                               // 00000018FA70: 7F9811CC
	v_fmac_f32_e32 v209, 0x32a5705f, v167                      // 00000018FA74: 57A34EFF 32A5705F
	v_sub_f32_e32 v155, v155, v210                             // 00000018FA7C: 0937A59B
	v_exp_f32_e32 v153, v153                                   // 00000018FA80: 7F324B99
	.long 0xd71c0097                                           // 00000018FA84: D71C0097
	v_cndmask_b32_e32 v1, v151, v202, vcc_lo                   // 00000018FA88: 02039597
	v_cndmask_b32_e64 v150, 0, v150, s0                        // 00000018FA8C: D5010096 00032C80
	.long 0xd41b0000                                           // 00000018FA94: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v163, vcc_lo             // 00000018FA98: 020346FF C2CE8ED0
	v_cvt_i32_f32_e32 v206, v206                               // 00000018FAA0: 7F9C11CE
	v_add_f32_e32 v155, v155, v209                             // 00000018FAA4: 0737A39B
	v_exp_f32_e32 v154, v154                                   // 00000018FAA8: 7F344B9A
	.long 0xd71c0098                                           // 00000018FAAC: D71C0098
	v_cndmask_b32_e32 v1, v152, v204, vcc_lo                   // 00000018FAB0: 02039998
	v_cndmask_b32_e64 v151, 0, v151, s0                        // 00000018FAB4: D5010097 00032E80
	.long 0xd41b0000                                           // 00000018FABC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v164, vcc_lo             // 00000018FAC0: 020348FF C2CE8ED0
	v_cvt_i32_f32_e32 v208, v208                               // 00000018FAC8: 7FA011D0
	v_exp_f32_e32 v155, v155                                   // 00000018FACC: 7F364B9B
	.long 0xd71c0099                                           // 00000018FAD0: D71C0099
	v_cndmask_b32_e32 v1, v153, v206, vcc_lo                   // 00000018FAD4: 02039D99
	v_exp_f32_e32 v156, v156                                   // 00000018FAD8: 7F384B9C
	v_cndmask_b32_e64 v152, 0, v152, s0                        // 00000018FADC: D5010098 00033080
	.long 0xd41b0000                                           // 00000018FAE4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v165, vcc_lo             // 00000018FAE8: 02034AFF C2CE8ED0
	v_cvt_i32_f32_e32 v197, v210                               // 00000018FAF0: 7F8A11D2
	.long 0xd71c009a                                           // 00000018FAF4: D71C009A
	v_cndmask_b32_e32 v1, v154, v208, vcc_lo                   // 00000018FAF8: 0203A19A
	v_cvt_i32_f32_e32 v199, v212                               // 00000018FAFC: 7F8E11D4
	s_delay_alu instid0(VALU_DEP_4)                            // 00000018FB00: BF870004
	v_cndmask_b32_e64 v153, 0, v153, s0                        // 00000018FB04: D5010099 00033280
	.long 0xd41b0000                                           // 00000018FB0C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v166, vcc_lo             // 00000018FB10: 02034CFF C2CE8ED0
	.long 0xd71c009b                                           // 00000018FB18: D71C009B
	v_cndmask_b32_e32 v1, v155, v197, vcc_lo                   // 00000018FB1C: 02038B9B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 00000018FB20: BF870205
	.long 0xd71c009c                                           // 00000018FB24: D71C009C
	v_cndmask_b32_e32 v1, v156, v199, vcc_lo                   // 00000018FB28: 02038F9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000018FB2C: BF8700A3
	v_cndmask_b32_e64 v154, 0, v154, s0                        // 00000018FB30: D501009A 00033480
	.long 0xd41b0000                                           // 00000018FB38: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v167, vcc_lo             // 00000018FB3C: 02034EFF C2CE8ED0
	v_cndmask_b32_e64 v155, 0, v155, s0                        // 00000018FB44: D501009B 00033680
	.long 0xd41b0000                                           // 00000018FB4C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v168, vcc_lo             // 00000018FB50: 020350FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000018FB58: BF8700A1
	v_cndmask_b32_e64 v156, 0, v156, s0                        // 00000018FB5C: D501009C 00033880
	.long 0xd41e0000                                           // 00000018FB64: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v161, vcc_lo             // 00000018FB68: 020342FF 42B17218
	v_cndmask_b32_e64 v149, 0x7f800000, v149, s0               // 00000018FB70: D5010095 00032AFF 7F800000
	.long 0xd41e0000                                           // 00000018FB7C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v162, vcc_lo             // 00000018FB80: 020344FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000018FB88: BF870112
	v_mul_f32_e32 v9, v9, v149                                 // 00000018FB8C: 10132B09
	v_cndmask_b32_e64 v150, 0x7f800000, v150, s0               // 00000018FB90: D5010096 00032CFF 7F800000
	.long 0xd41e0000                                           // 00000018FB9C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v163, vcc_lo             // 00000018FBA0: 020346FF 42B17218
	v_mul_f32_e32 v1, v1, v149                                 // 00000018FBA8: 10032B01
	v_fma_f32 v169, v169, v149, v157                           // 00000018FBAC: D61300A9 06772BA9
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000018FBB4: BF870214
	v_mul_f32_e32 v58, v58, v150                               // 00000018FBB8: 10752D3A
	v_cndmask_b32_e64 v151, 0x7f800000, v151, s0               // 00000018FBBC: D5010097 00032EFF 7F800000
	.long 0xd41e0000                                           // 00000018FBC8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v164, vcc_lo             // 00000018FBCC: 020348FF 42B17218
	v_mul_f32_e32 v50, v50, v150                               // 00000018FBD4: 10652D32
	v_mul_f32_e32 v42, v42, v150                               // 00000018FBD8: 10552D2A
	v_mul_f32_e32 v34, v34, v150                               // 00000018FBDC: 10452D22
	v_mul_f32_e32 v26, v26, v150                               // 00000018FBE0: 10352D1A
	v_cndmask_b32_e64 v152, 0x7f800000, v152, s0               // 00000018FBE4: D5010098 000330FF 7F800000
	.long 0xd41e0000                                           // 00000018FBF0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v165, vcc_lo             // 00000018FBF4: 02034AFF 42B17218
	v_dual_mul_f32 v17, v17, v149 :: v_dual_mul_f32 v18, v18, v150// 00000018FBFC: C8C72B11 11132D12
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000018FC04: BF870193
	v_dual_mul_f32 v19, v19, v151 :: v_dual_mul_f32 v60, v60, v152// 00000018FC08: C8C72F13 133D313C
	v_cndmask_b32_e64 v153, 0x7f800000, v153, s0               // 00000018FC10: D5010099 000332FF 7F800000
	.long 0xd41e0000                                           // 00000018FC1C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v166, vcc_lo             // 00000018FC20: 02034CFF 42B17218
	v_mul_f32_e32 v52, v52, v152                               // 00000018FC28: 10693134
	v_mul_f32_e32 v44, v44, v152                               // 00000018FC2C: 1059312C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000018FC30: BF870214
	v_dual_mul_f32 v36, v36, v152 :: v_dual_mul_f32 v61, v61, v153// 00000018FC34: C8C73124 243D333D
	v_cndmask_b32_e64 v154, 0x7f800000, v154, s0               // 00000018FC3C: D501009A 000334FF 7F800000
	.long 0xd41e0000                                           // 00000018FC48: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v167, vcc_lo             // 00000018FC4C: 02034EFF 42B17218
	v_mul_f32_e32 v57, v57, v149                               // 00000018FC54: 10732B39
	v_mul_f32_e32 v49, v49, v149                               // 00000018FC58: 10632B31
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000018FC5C: BF870214
	v_dual_mul_f32 v53, v53, v153 :: v_dual_mul_f32 v62, v62, v154// 00000018FC60: C8C73335 353F353E
	v_cndmask_b32_e64 v155, 0x7f800000, v155, s0               // 00000018FC68: D501009B 000336FF 7F800000
	.long 0xd41e0000                                           // 00000018FC74: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v168, vcc_lo             // 00000018FC78: 020350FF 42B17218
	v_dual_mul_f32 v54, v54, v154 :: v_dual_mul_f32 v41, v41, v149// 00000018FC80: C8C73536 36292B29
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000018FC88: BF870223
	v_dual_mul_f32 v22, v22, v154 :: v_dual_mul_f32 v63, v63, v155// 00000018FC8C: C8C73516 163F373F
	v_mul_f32_e32 v28, v28, v152                               // 00000018FC94: 1039311C
	v_cndmask_b32_e64 v156, 0x7f800000, v156, s0               // 00000018FC98: D501009C 000338FF 7F800000
	v_mul_f32_e32 v59, v59, v151                               // 00000018FCA4: 10772F3B
	v_mul_f32_e32 v51, v51, v151                               // 00000018FCA8: 10672F33
	v_dual_mul_f32 v55, v55, v155 :: v_dual_mul_f32 v20, v20, v152// 00000018FCAC: C8C73737 37153114
	s_delay_alu instid0(VALU_DEP_4)                            // 00000018FCB4: BF870004
	v_mul_f32_e32 v64, v64, v156                               // 00000018FCB8: 10813940
	v_dual_mul_f32 v56, v56, v156 :: v_dual_mul_f32 v43, v43, v151// 00000018FCBC: C8C73938 382B2F2B
	v_dual_mul_f32 v24, v24, v156 :: v_dual_mul_f32 v45, v45, v153// 00000018FCC4: C8C73918 182D332D
	v_mul_f32_e32 v10, v10, v150                               // 00000018FCCC: 10152D0A
	v_dual_mul_f32 v46, v46, v154 :: v_dual_mul_f32 v47, v47, v155// 00000018FCD0: C8C7352E 2E2F372F
	v_mul_f32_e32 v12, v12, v152                               // 00000018FCD8: 1019310C
	v_dual_mul_f32 v48, v48, v156 :: v_dual_mul_f32 v33, v33, v149// 00000018FCDC: C8C73930 30212B21
	v_dual_mul_f32 v14, v14, v154 :: v_dual_mul_f32 v35, v35, v151// 00000018FCE4: C8C7350E 0E232F23
	v_dual_mul_f32 v16, v16, v156 :: v_dual_mul_f32 v37, v37, v153// 00000018FCEC: C8C73910 10253325
	v_mul_f32_e32 v2, v2, v150                                 // 00000018FCF4: 10052D02
	v_dual_mul_f32 v38, v38, v154 :: v_dual_mul_f32 v39, v39, v155// 00000018FCF8: C8C73526 26273727
	v_mul_f32_e32 v4, v4, v152                                 // 00000018FD00: 10093104
	v_dual_mul_f32 v40, v40, v156 :: v_dual_mul_f32 v25, v25, v149// 00000018FD04: C8C73928 28192B19
	v_dual_mul_f32 v6, v6, v154 :: v_dual_mul_f32 v27, v27, v151// 00000018FD0C: C8C73506 061B2F1B
	v_fmac_f32_e32 v92, v193, v156                             // 00000018FD14: 56B939C1
	v_dual_mul_f32 v29, v29, v153 :: v_dual_mul_f32 v8, v8, v156// 00000018FD18: C8C7331D 1D093908
	v_dual_mul_f32 v30, v30, v154 :: v_dual_mul_f32 v31, v31, v155// 00000018FD20: C8C7351E 1E1F371F
	v_dual_mul_f32 v32, v32, v156 :: v_dual_mul_f32 v21, v21, v153// 00000018FD28: C8C73920 20153315
	v_mul_f32_e32 v23, v23, v155                               // 00000018FD30: 102F3717
	v_mul_f32_e32 v11, v11, v151                               // 00000018FD34: 10172F0B
	v_mul_f32_e32 v13, v13, v153                               // 00000018FD38: 101B330D
	v_mul_f32_e32 v15, v15, v155                               // 00000018FD3C: 101F370F
	v_mul_f32_e32 v3, v3, v151                                 // 00000018FD40: 10072F03
	v_mul_f32_e32 v5, v5, v153                                 // 00000018FD44: 100B3305
	v_mul_f32_e32 v7, v7, v155                                 // 00000018FD48: 100F3707
	v_fma_f32 v171, v171, v151, v158                           // 00000018FD4C: D61300AB 067B2FAB
	v_fma_f32 v170, v170, v153, v159                           // 00000018FD54: D61300AA 067F33AA
	v_fma_f32 v191, v191, v155, v160                           // 00000018FD5C: D61300BF 068337BF
	v_dual_fmac_f32 v89, v196, v150 :: v_dual_fmac_f32 v90, v195, v152// 00000018FD64: C8012DC4 595B31C3
	v_fmac_f32_e32 v91, v194, v154                             // 00000018FD6C: 56B735C2
	v_mov_b32_e32 v193, v92                                    // 00000018FD70: 7F82035C
	s_waitcnt vmcnt(19) lgkmcnt(0)                             // 00000018FD74: BF894C07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[73:80], v[81:88], v[57:64]// 00000018FD78: CC414039 1CE6A349
	s_waitcnt vmcnt(18)                                        // 00000018FD80: BF894BF7
	v_wmma_f32_16x16x16_bf16 v[49:56], v[73:80], v[93:100], v[49:56]// 00000018FD84: CC414031 1CC6BB49
	s_waitcnt vmcnt(17)                                        // 00000018FD8C: BF8947F7
	v_wmma_f32_16x16x16_bf16 v[41:48], v[73:80], v[101:108], v[41:48]// 00000018FD90: CC414029 1CA6CB49
	s_waitcnt vmcnt(16)                                        // 00000018FD98: BF8943F7
	v_wmma_f32_16x16x16_bf16 v[33:40], v[73:80], v[109:116], v[33:40]// 00000018FD9C: CC414021 1C86DB49
	s_waitcnt vmcnt(3)                                         // 00000018FDA4: BF890FF7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[73:80], v[117:124], v[25:32]// 00000018FDA8: CC414019 1C66EB49
	s_waitcnt vmcnt(2)                                         // 00000018FDB0: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[17:24], v[73:80], v[125:132], v[17:24]// 00000018FDB4: CC414011 1C46FB49
	s_waitcnt vmcnt(1)                                         // 00000018FDBC: BF8907F7
	v_wmma_f32_16x16x16_bf16 v[9:16], v[73:80], v[133:140], v[9:16]// 00000018FDC0: CC414009 1C270B49
	s_waitcnt vmcnt(0)                                         // 00000018FDC8: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[1:8], v[73:80], v[141:148], v[1:8]// 00000018FDCC: CC414001 1C071B49
	s_barrier                                                  // 00000018FDD4: BFBD0000
	buffer_gl0_inv                                             // 00000018FDD8: E0AC0000 00000000
	s_cbranch_scc0 51                                          // 00000018FDE0: BFA10033 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi8EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x16b0>
	s_mov_b32 s0, s21                                          // 00000018FDE4: BE800015
	s_add_i32 s21, s21, 4                                      // 00000018FDE8: 81158415
	v_dual_mov_b32 v194, v91 :: v_dual_mov_b32 v195, v90       // 00000018FDEC: CA10015B C2C2015A
	s_min_i32 s4, s21, s30                                     // 00000018FDF4: 89041E15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000018FDF8: BF870499
	s_ashr_i32 s5, s4, 31                                      // 00000018FDFC: 86059F04
	s_lshl_b64 s[4:5], s[4:5], 2                               // 00000018FE00: 84848204
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000018FE04: BF870009
	s_add_u32 s4, s14, s4                                      // 00000018FE08: 8004040E
	s_addc_u32 s5, s15, s5                                     // 00000018FE0C: 8205050F
	s_cmp_lt_i32 s0, s27                                       // 00000018FE10: BF041B00
	s_cselect_b32 s6, s3, s26                                  // 00000018FE14: 98061A03
	s_cmp_lt_i32 s0, s1                                        // 00000018FE18: BF040100
	s_waitcnt lgkmcnt(0)                                       // 00000018FE1C: BF89FC07
	s_cselect_b32 s16, s16, s6                                 // 00000018FE20: 98100610
	s_add_i32 s22, s0, 1                                       // 00000018FE24: 81168100
	s_load_b128 s[4:7], s[4:5], null                           // 00000018FE28: F4080102 F8000000
	s_cmp_lt_i32 s22, s27                                      // 00000018FE30: BF041B16
	v_dual_mov_b32 v196, v89 :: v_dual_mov_b32 v73, s16        // 00000018FE34: CA100159 C4480010
	s_cselect_b32 s23, s3, s26                                 // 00000018FE3C: 98171A03
	s_cmp_lt_i32 s22, s1                                       // 00000018FE40: BF040116
	s_cselect_b32 s22, s17, s23                                // 00000018FE44: 98161711
	s_add_i32 s17, s0, 2                                       // 00000018FE48: 81118200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000018FE4C: BF8704D9
	s_cmp_lt_i32 s17, s27                                      // 00000018FE50: BF041B11
	s_cselect_b32 s23, s3, s26                                 // 00000018FE54: 98171A03
	s_cmp_lt_i32 s17, s1                                       // 00000018FE58: BF040111
	s_cselect_b32 s18, s18, s23                                // 00000018FE5C: 98121712
	s_add_i32 s17, s0, 3                                       // 00000018FE60: 81118300
	s_cmp_lt_i32 s17, s27                                      // 00000018FE64: BF041B11
	s_cselect_b32 s23, s3, s26                                 // 00000018FE68: 98171A03
	s_cmp_lt_i32 s17, s1                                       // 00000018FE6C: BF040111
	s_mov_b32 s17, exec_lo                                     // 00000018FE70: BE91007E
	s_cselect_b32 s24, s19, s23                                // 00000018FE74: 98181713
	v_cmpx_lt_i32_e32 0, v175                                  // 00000018FE78: 7D835E80
	s_cbranch_execz 64447                                      // 00000018FE7C: BFA5FBBF <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi8EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x57c>
	.long 0xd44d0000                                           // 00000018FE80: D44D0000
	v_cndmask_b32_e32 v1, 1, v175, vcc_lo                      // 00000018FE84: 02035E81
	s_and_saveexec_b32 s19, s0                                 // 00000018FE88: BE932000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000018FE8C: BF870009
	s_xor_b32 s0, exec_lo, s19                                 // 00000018FE90: 8D00137E
	v_mov_b32_e32 v73, s18                                     // 00000018FE94: 7E920212
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018FE98: BF870001
	v_cndmask_b32_e32 v73, s24, v73, vcc_lo                    // 00000018FE9C: 02929218
	s_and_not1_saveexec_b32 s0, s0                             // 00000018FEA0: BE803000
	s_cbranch_execz 64436                                      // 00000018FEA4: BFA5FBB4 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi8EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x578>
	v_mov_b32_e32 v73, s22                                     // 00000018FEA8: 7E920216
	s_branch 64434                                             // 00000018FEAC: BFA0FBB2 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi8EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x578>
	v_mov_b32_e32 v8, v174                                     // 00000018FEB0: 7E1003AE
	s_mul_i32 s0, s20, 12                                      // 00000018FEB4: 96008C14
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018FEB8: BF870001
	v_or_b32_e32 v7, v8, v172                                  // 00000018FEBC: 380F5908
	v_or_b32_e32 v0, s0, v173                                  // 00000018FEC0: 38015A00
	v_mov_b32_dpp v78, v91 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018FEC4: 7E9C02FA FF09615B
	v_mov_b32_dpp v75, v90 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018FECC: 7E9602FA FF09615A
	v_mov_b32_dpp v74, v171 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018FED4: 7E9402FA FF0961AB
	v_mov_b32_dpp v76, v170 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018FEDC: 7E9802FA FF0961AA
	v_lshlrev_b32_e32 v0, 8, v0                                // 00000018FEE4: 30000088
	v_mov_b32_e32 v8, 0                                        // 00000018FEE8: 7E100280
	v_dual_add_f32 v78, v91, v78 :: v_dual_add_f32 v81, v90, v75// 00000018FEEC: C9089D5B 4E50975A
	v_add_f32_e32 v83, v171, v74                               // 00000018FEF4: 06A695AB
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000018FEF8: BF870214
	v_add_nc_u32_e32 v23, 0x400, v0                            // 00000018FEFC: 4A2E00FF 00000400
	v_mad_i64_i32 v[7:8], null, 0x1800, s2, v[7:8]             // 00000018FF04: D6FF7C07 041C04FF 00001800
	v_ashrrev_i32_e32 v16, 31, v0                              // 00000018FF10: 3420009F
	v_add_nc_u32_e32 v31, 0x600, v0                            // 00000018FF14: 4A3E00FF 00000600
	v_add_nc_u32_e32 v39, 0x800, v0                            // 00000018FF1C: 4A4E00FF 00000800
	v_ashrrev_i32_e32 v24, 31, v23                             // 00000018FF24: 34302E9F
	v_or_b32_e32 v65, 0x200, v0                                // 00000018FF28: 388200FF 00000200
	v_add_f32_dpp v81, v81, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018FF30: 06A2A2FA FF096251
	v_ashrrev_i32_e32 v32, 31, v31                             // 00000018FF38: 34403E9F
	.long 0xd7006a0f                                           // 00000018FF3C: D7006A0F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 00000018FF40: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000018FF44: BF8700A1
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 00000018FF48: D5207C10 01AA2108
	.long 0xd7006a17                                           // 00000018FF50: D7006A17
	v_cndmask_b32_e32 v1, v7, v23, vcc_lo                      // 00000018FF54: 02022F07
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 00000018FF58: D5207C18 01AA3108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000018FF60: BF870233
	.long 0xd73c000f                                           // 00000018FF64: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 00000018FF68: 02021E81
	v_add_nc_u32_e32 v0, 0xa00, v0                             // 00000018FF6C: 4A0000FF 00000A00
	v_ashrrev_i32_e32 v40, 31, v39                             // 00000018FF74: 34504E9F
	.long 0xd73c0017                                           // 00000018FF78: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 00000018FF7C: 02022E81
	v_ashrrev_i32_e32 v66, 31, v65                             // 00000018FF80: 3484829F
	v_add_f32_dpp v78, v78, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018FF84: 069C9CFA FF09624E
	.long 0xd7006a45                                           // 00000018FF8C: D7006A45
	v_cndmask_b32_e32 v1, s10, v15, vcc_lo                     // 00000018FF90: 02021E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000018FF94: BF8700A1
	v_add_co_ci_u32_e64 v70, null, s11, v16, vcc_lo            // 00000018FF98: D5207C46 01AA200B
	.long 0xd7006a1f                                           // 00000018FFA0: D7006A1F
	v_cndmask_b32_e32 v1, v7, v31, vcc_lo                      // 00000018FFA4: 02023F07
	v_add_co_ci_u32_e64 v32, null, v8, v32, vcc_lo             // 00000018FFA8: D5207C20 01AA4108
	.long 0xd7006a37                                           // 00000018FFB0: D7006A37
	v_cndmask_b32_e32 v1, s10, v23, vcc_lo                     // 00000018FFB4: 02022E0A
	v_ashrrev_i32_e32 v48, 31, v0                              // 00000018FFB8: 3460009F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000018FFBC: BF8700B3
	.long 0xd73c001f                                           // 00000018FFC0: D73C001F
	v_cndmask_b32_e32 v1, 1, v31, vcc_lo                       // 00000018FFC4: 02023E81
	v_add_co_ci_u32_e64 v56, null, s11, v24, vcc_lo            // 00000018FFC8: D5207C38 01AA300B
	.long 0xd7006a27                                           // 00000018FFD0: D7006A27
	v_cndmask_b32_e32 v1, v7, v39, vcc_lo                      // 00000018FFD4: 02024F07
	v_add_co_ci_u32_e64 v40, null, v8, v40, vcc_lo             // 00000018FFD8: D5207C28 01AA5108
	.long 0xd7006a2f                                           // 00000018FFE0: D7006A2F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 00000018FFE4: 02020107
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018FFE8: BF870001
	v_add_co_ci_u32_e64 v48, null, v8, v48, vcc_lo             // 00000018FFEC: D5207C30 01AA6108
	.long 0xd7006a3f                                           // 00000018FFF4: D7006A3F
	v_cndmask_b32_e32 v1, s10, v31, vcc_lo                     // 00000018FFF8: 02023E0A
	global_load_u16 v73, v[69:70], off offset:1024             // 00000018FFFC: DC4A0400 497C0045
	v_add_co_ci_u32_e64 v64, null, s11, v32, vcc_lo            // 000000190004: D5207C40 01AA400B
	.long 0xd7006a07                                           // 00000019000C: D7006A07
	v_cndmask_b32_e32 v1, v7, v65, vcc_lo                      // 000000190010: 02028307
	s_clause 0x2                                               // 000000190014: BF850002
	global_load_u16 v80, v[69:70], off                         // 000000190018: DC4A0000 507C0045
	global_load_u16 v82, v[69:70], off offset:32               // 000000190020: DC4A0020 527C0045
	global_load_u16 v103, v[69:70], off offset:64              // 000000190028: DC4A0040 677C0045
	v_add_co_ci_u32_e64 v8, null, v8, v66, vcc_lo              // 000000190030: D5207C08 01AA8508
	.long 0xd73c0027                                           // 000000190038: D73C0027
	v_cndmask_b32_e32 v1, 1, v39, vcc_lo                       // 00000019003C: 02024E81
	.long 0xd73c002f                                           // 000000190040: D73C002F
	v_cndmask_b32_e32 v1, 1, v47, vcc_lo                       // 000000190044: 02025E81
	v_add_f32_dpp v83, v83, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000190048: 06A6A6FA FF096253
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000190050: BF8700C4
	.long 0xd73c0056                                           // 000000190054: D73C0056
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 000000190058: 02020E81
	v_mov_b32_dpp v8, v89 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019005C: 7E1002FA FF096159
	v_mov_b32_dpp v7, v169 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000190064: 7E0E02FA FF0961A9
	.long 0xd7006a43                                           // 00000019006C: D7006A43
	v_cndmask_b32_e32 v1, s10, v39, vcc_lo                     // 000000190070: 02024E0A
	v_add_co_ci_u32_e64 v68, null, s11, v40, vcc_lo            // 000000190074: D5207C44 01AA500B
	.long 0xd7006a41                                           // 00000019007C: D7006A41
	v_cndmask_b32_e32 v1, s10, v47, vcc_lo                     // 000000190080: 02025E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000190084: BF8700A1
	v_add_co_ci_u32_e64 v66, null, s11, v48, vcc_lo            // 000000190088: D5207C42 01AA600B
	.long 0xd7006a47                                           // 000000190090: D7006A47
	v_cndmask_b32_e32 v1, s10, v86, vcc_lo                     // 000000190094: 0202AC0A
	v_add_co_ci_u32_e64 v72, null, s11, v87, vcc_lo            // 000000190098: D5207C48 01AAAE0B
	s_clause 0x9                                               // 0000001900A0: BF850009
	global_load_u16 v99, v[63:64], off                         // 0000001900A4: DC4A0000 637C003F
	global_load_u16 v98, v[55:56], off                         // 0000001900AC: DC4A0000 627C0037
	global_load_u16 v101, v[65:66], off                        // 0000001900B4: DC4A0000 657C0041
	global_load_u16 v100, v[67:68], off                        // 0000001900BC: DC4A0000 647C0043
	global_load_u16 v102, v[71:72], off offset:32              // 0000001900C4: DC4A0020 667C0047
	global_load_u16 v94, v[63:64], off offset:32               // 0000001900CC: DC4A0020 5E7C003F
	global_load_u16 v93, v[55:56], off offset:32               // 0000001900D4: DC4A0020 5D7C0037
	global_load_u16 v96, v[65:66], off offset:32               // 0000001900DC: DC4A0020 607C0041
	global_load_u16 v95, v[67:68], off offset:32               // 0000001900E4: DC4A0020 5F7C0043
	global_load_u16 v97, v[71:72], off offset:64               // 0000001900EC: DC4A0040 617C0047
	v_add_f32_e32 v8, v89, v8                                  // 0000001900F4: 06101159
	v_add_f32_e32 v7, v169, v7                                 // 0000001900F8: 060E0FA9
	v_add_f32_dpp v83, v83, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001900FC: 06A6A6FA FF096453
	v_add_f32_dpp v81, v81, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000190104: 06A2A2FA FF096451
	v_add_f32_dpp v78, v78, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019010C: 069C9CFA FF09644E
	v_add_f32_dpp v8, v8, v8 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000190114: 061010FA FF096208
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019011C: 060E0EFA FF096207
	v_add_f32_dpp v89, v83, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000190124: 06B2A6FA FF096853
	v_add_f32_dpp v88, v81, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019012C: 06B0A2FA FF096851
	v_add_f32_dpp v81, v78, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000190134: 06A29CFA FF09684E
	v_add_f32_dpp v8, v8, v8 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019013C: 061010FA FF096408
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000190144: 060E0EFA FF096407
	v_div_scale_f32 v109, null, v89, v89, 1.0                  // 00000019014C: D6FC7C6D 03CAB359
	v_div_scale_f32 v110, null, v88, v88, 1.0                  // 000000190154: D6FC7C6E 03CAB158
	v_div_scale_f32 v115, null, v81, v81, 1.0                  // 00000019015C: D6FC7C73 03CAA351
	v_add_f32_dpp v107, v8, v8 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000190164: 06D610FA FF096808
	v_add_f32_dpp v108, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019016C: 06D80EFA FF096807
	.long 0xd7000507                                           // 000000190174: D7000507
	v_cndmask_b32_e32 v1, s12, v15, vcc_lo                     // 000000190178: 02021E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000019017C: BF8700B1
	v_add_co_ci_u32_e64 v8, null, s13, v16, s5                 // 000000190180: D5207C08 0016200D
	v_rcp_f32_e32 v91, v109                                    // 000000190188: 7EB6556D
	.long 0xd700050f                                           // 00000019018C: D700050F
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 000000190190: 02022E0C
	v_add_co_ci_u32_e64 v16, null, s13, v24, s5                // 000000190194: D5207C10 0016300D
	.long 0xd7000517                                           // 00000019019C: D7000517
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 0000001901A0: 02023E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001901A4: BF8700A1
	v_add_co_ci_u32_e64 v24, null, s13, v32, s5                // 0000001901A8: D5207C18 0016400D
	.long 0xd700051f                                           // 0000001901B0: D700051F
	v_cndmask_b32_e32 v1, s12, v39, vcc_lo                     // 0000001901B4: 02024E0C
	v_add_co_ci_u32_e64 v32, null, s13, v40, s5                // 0000001901B8: D5207C20 0016500D
	.long 0xd7000527                                           // 0000001901C0: D7000527
	v_cndmask_b32_e32 v1, s12, v47, vcc_lo                     // 0000001901C4: 02025E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001901C8: BF8700A1
	v_add_co_ci_u32_e64 v40, null, s13, v48, s5                // 0000001901CC: D5207C28 0016600D
	.long 0xd700052f                                           // 0000001901D4: D700052F
	v_cndmask_b32_e32 v1, s12, v86, vcc_lo                     // 0000001901D8: 0202AC0C
	v_add_co_ci_u32_e64 v48, null, s13, v87, s5                // 0000001901DC: D5207C30 0016AE0D
	s_clause 0x1f                                              // 0000001901E4: BF85001F
	global_load_u16 v78, v[69:70], off offset:96               // 0000001901E8: DC4A0060 4E7C0045
	global_load_u16 v86, v[69:70], off offset:128              // 0000001901F0: DC4A0080 567C0045
	global_load_u16 v87, v[69:70], off offset:160              // 0000001901F8: DC4A00A0 577C0045
	global_load_u16 v92, v[69:70], off offset:192              // 000000190200: DC4A00C0 5C7C0045
	global_load_u16 v69, v[69:70], off offset:224              // 000000190208: DC4A00E0 457C0045
	global_load_u16 v138, v[55:56], off offset:64              // 000000190210: DC4A0040 8A7C0037
	global_load_u16 v133, v[55:56], off offset:96              // 000000190218: DC4A0060 857C0037
	global_load_u16 v128, v[55:56], off offset:128             // 000000190220: DC4A0080 807C0037
	global_load_u16 v124, v[55:56], off offset:160             // 000000190228: DC4A00A0 7C7C0037
	global_load_u16 v104, v[55:56], off offset:192             // 000000190230: DC4A00C0 687C0037
	global_load_u16 v137, v[63:64], off offset:64              // 000000190238: DC4A0040 897C003F
	global_load_u16 v132, v[63:64], off offset:96              // 000000190240: DC4A0060 847C003F
	global_load_u16 v127, v[63:64], off offset:128             // 000000190248: DC4A0080 7F7C003F
	global_load_u16 v123, v[63:64], off offset:160             // 000000190250: DC4A00A0 7B7C003F
	global_load_u16 v70, v[63:64], off offset:192              // 000000190258: DC4A00C0 467C003F
	global_load_u16 v56, v[55:56], off offset:224              // 000000190260: DC4A00E0 387C0037
	global_load_u16 v140, v[67:68], off offset:64              // 000000190268: DC4A0040 8C7C0043
	global_load_u16 v135, v[67:68], off offset:96              // 000000190270: DC4A0060 877C0043
	global_load_u16 v130, v[67:68], off offset:128             // 000000190278: DC4A0080 827C0043
	global_load_u16 v126, v[67:68], off offset:160             // 000000190280: DC4A00A0 7E7C0043
	global_load_u16 v106, v[67:68], off offset:192             // 000000190288: DC4A00C0 6A7C0043
	global_load_u16 v55, v[63:64], off offset:224              // 000000190290: DC4A00E0 377C003F
	global_load_u16 v139, v[65:66], off offset:64              // 000000190298: DC4A0040 8B7C0041
	global_load_u16 v134, v[65:66], off offset:96              // 0000001902A0: DC4A0060 867C0041
	global_load_u16 v129, v[65:66], off offset:128             // 0000001902A8: DC4A0080 817C0041
	global_load_u16 v125, v[65:66], off offset:160             // 0000001902B0: DC4A00A0 7D7C0041
	global_load_u16 v105, v[65:66], off offset:192             // 0000001902B8: DC4A00C0 697C0041
	global_load_u16 v63, v[67:68], off offset:224              // 0000001902C0: DC4A00E0 3F7C0043
	global_load_u16 v141, v[71:72], off offset:96              // 0000001902C8: DC4A0060 8D7C0047
	global_load_u16 v136, v[71:72], off offset:128             // 0000001902D0: DC4A0080 887C0047
	global_load_u16 v131, v[71:72], off offset:160             // 0000001902D8: DC4A00A0 837C0047
	global_load_u16 v68, v[71:72], off offset:192              // 0000001902E0: DC4A00C0 447C0047
	s_clause 0x1                                               // 0000001902E8: BF850001
	global_load_u16 v67, v[71:72], off offset:224              // 0000001902EC: DC4A00E0 437C0047
	global_load_u16 v64, v[65:66], off offset:224              // 0000001902F4: DC4A00E0 407C0041
	v_fma_f32 v71, -v109, v91, 1.0                             // 0000001902FC: D6130047 23CAB76D
	v_add_f32_e32 v84, v170, v76                               // 000000190304: 06A899AA
	v_div_scale_f32 v117, null, v108, v108, 1.0                // 000000190308: D6FC7C75 03CAD96C
	v_div_scale_f32 v118, null, v107, v107, 1.0                // 000000190310: D6FC7C76 03CAD76B
	v_rcp_f32_e32 v90, v110                                    // 000000190318: 7EB4556E
	v_fmac_f32_e32 v91, v71, v91                               // 00000019031C: 56B6B747
	v_add_f32_dpp v84, v84, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000190320: 06A8A8FA FF096254
	v_rcp_f32_e32 v122, v117                                   // 000000190328: 7EF45575
	v_rcp_f32_e32 v121, v118                                   // 00000019032C: 7EF25576
	v_div_scale_f32 v119, vcc_lo, 1.0, v108, 1.0               // 000000190330: D6FC6A77 03CAD8F2
	v_div_scale_f32 v120, s4, 1.0, v107, 1.0                   // 000000190338: D6FC0478 03CAD6F2
	v_add_f32_dpp v84, v84, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000190340: 06A8A8FA FF096454
	v_div_scale_f32 v112, s2, 1.0, v89, 1.0                    // 000000190348: D6FC0270 03CAB2F2
	v_div_scale_f32 v116, s1, 1.0, v81, 1.0                    // 000000190350: D6FC0174 03CAA2F2
	v_fma_f32 v72, -v110, v90, 1.0                             // 000000190358: D6130048 23CAB56E
	v_div_scale_f32 v113, s3, 1.0, v88, 1.0                    // 000000190360: D6FC0371 03CAB0F2
	v_add_f32_dpp v83, v84, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000190368: 06A6A8FA FF096854
	v_fma_f32 v65, -v117, v122, 1.0                            // 000000190370: D6130041 23CAF575
	v_fma_f32 v66, -v118, v121, 1.0                            // 000000190378: D6130042 23CAF376
	v_fmac_f32_e32 v90, v72, v90                               // 000000190380: 56B4B548
	v_rcp_f32_e32 v84, v115                                    // 000000190384: 7EA85573
	v_div_scale_f32 v111, null, v83, v83, 1.0                  // 000000190388: D6FC7C6F 03CAA753
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000190390: BF870233
	v_dual_fmac_f32 v122, v65, v122 :: v_dual_fmac_f32 v121, v66, v121// 000000190394: C800F541 7A78F342
	v_div_scale_f32 v114, s0, 1.0, v83, 1.0                    // 00000019039C: D6FC0072 03CAA6F2
	v_dual_mul_f32 v71, v112, v91 :: v_dual_mul_f32 v72, v113, v90// 0000001903A4: C8C6B770 4748B571
	v_rcp_f32_e32 v85, v111                                    // 0000001903AC: 7EAA556F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001903B0: BF870313
	v_dual_mul_f32 v65, v119, v122 :: v_dual_mul_f32 v66, v120, v121// 0000001903B4: C8C6F577 4142F378
	v_fma_f32 v143, -v115, v84, 1.0                            // 0000001903BC: D613008F 23CAA973
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001903C4: BF870223
	v_fma_f32 v146, -v109, v71, v112                           // 0000001903C8: D6130092 25C28F6D
	v_fma_f32 v147, -v110, v72, v113                           // 0000001903D0: D6130093 25C6916E
	v_fma_f32 v144, -v117, v65, v119                           // 0000001903D8: D6130090 25DE8375
	v_fma_f32 v145, -v118, v66, v120                           // 0000001903E0: D6130091 25E28576
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001903E8: BF870214
	v_dual_fmac_f32 v84, v143, v84 :: v_dual_fmac_f32 v71, v146, v91// 0000001903EC: C800A98F 5446B792
	v_fmac_f32_e32 v72, v147, v90                              // 0000001903F4: 5690B593
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001903F8: BF870215
	v_fma_f32 v142, -v111, v85, 1.0                            // 0000001903FC: D613008E 23CAAB6F
	v_dual_fmac_f32 v65, v144, v122 :: v_dual_fmac_f32 v66, v145, v121// 000000190404: C800F590 4142F391
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019040C: BF870224
	v_mul_f32_e32 v143, v116, v84                              // 000000190410: 111EA974
	v_fma_f32 v109, -v109, v71, v112                           // 000000190414: D613006D 25C28F6D
	v_fmac_f32_e32 v85, v142, v85                              // 00000019041C: 56AAAB8E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000190420: BF870004
	v_fma_f32 v117, -v117, v65, v119                           // 000000190424: D6130075 25DE8375
	v_fma_f32 v118, -v118, v66, v120                           // 00000019042C: D6130076 25E28576
	v_fma_f32 v144, -v115, v143, v116                          // 000000190434: D6130090 25D31F73
	.long 0x7f003880                                           // 00000019043C: 7F003880
	v_mul_f32_e32 v142, v114, v85                              // 000000190440: 111CAB72
	v_div_fmas_f32 v65, v117, v122, v65                        // 000000190444: D6370041 0506F575
	s_mov_b32 vcc_lo, s4                                       // 00000019044C: BEEA0004
	v_div_fmas_f32 v117, v118, v121, v66                       // 000000190450: D6370075 050AF376
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000190458: BF870193
	v_fma_f32 v148, -v111, v142, v114                          // 00000019045C: D6130094 25CB1D6F
	v_div_fixup_f32 v66, v65, v108, 1.0                        // 000000190464: D6270042 03CAD941
	v_fma_f32 v108, -v110, v72, v113                           // 00000019046C: D613006C 25C6916E
	.long 0x7f9e3980                                           // 000000190474: 7F9E3980
	v_div_fixup_f32 v65, v117, v107, 1.0                       // 000000190478: D6270041 03CAD775
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000190480: BF870234
	v_dual_fmac_f32 v142, v148, v85 :: v_dual_mul_f32 v57, v57, v66// 000000190484: C806AB94 8E388539
	v_fmac_f32_e32 v143, v144, v84                             // 00000019048C: 571EA990
	.long 0x7f983980                                           // 000000190490: 7F983980
	v_mul_f32_e32 v58, v58, v65                                // 000000190494: 1074833A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000190498: BF870004
	v_fma_f32 v107, -v111, v142, v114                          // 00000019049C: D613006B 25CB1D6F
	v_mul_f32_e32 v111, v49, v66                               // 0000001904A4: 10DE8531
	v_fma_f32 v110, -v115, v143, v116                          // 0000001904A8: D613006E 25D31F73
	.long 0x7f9a3980                                           // 0000001904B0: 7F9A3980
	.long 0x7f963980                                           // 0000001904B4: 7F963980
	.long 0x7f943980                                           // 0000001904B8: 7F943980
	v_dual_mul_f32 v33, v33, v66 :: v_dual_mul_f32 v26, v26, v65// 0000001904BC: C8C68521 211A831A
	v_mul_f32_e32 v25, v25, v66                                // 0000001904C4: 10328519
	v_mul_f32_e32 v17, v17, v66                                // 0000001904C8: 10228511
	v_mul_f32_e32 v9, v9, v66                                  // 0000001904CC: 10128509
	v_dual_mul_f32 v1, v1, v66 :: v_dual_mul_f32 v18, v18, v65 // 0000001904D0: C8C68501 01128312
	v_mul_f32_e32 v42, v42, v65                                // 0000001904D8: 1054832A
	v_mul_f32_e32 v34, v34, v65                                // 0000001904DC: 10448322
	v_mul_f32_e32 v10, v10, v65                                // 0000001904E0: 1014830A
	v_mul_f32_e32 v2, v2, v65                                  // 0000001904E4: 10048302
	s_waitcnt vmcnt(47)                                        // 0000001904E8: BF89BFF7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000001904EC: 30929290
	s_waitcnt vmcnt(46)                                        // 0000001904F0: BF89BBF7
	v_dual_mul_f32 v80, v50, v65 :: v_dual_lshlrev_b32 v49, 16, v80// 0000001904F4: C8E28332 5030A090
	s_waitcnt vmcnt(45)                                        // 0000001904FC: BF89B7F7
	v_lshlrev_b32_e32 v50, 16, v82                             // 000000190500: 3064A490
	s_waitcnt vmcnt(44)                                        // 000000190504: BF89B3F7
	v_lshlrev_b32_e32 v82, 16, v103                            // 000000190508: 30A4CE90
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019050C: BF870001
	v_mul_f32_e32 v114, 0xbfb8aa3b, v82                        // 000000190510: 10E4A4FF BFB8AA3B
	v_mul_f32_e32 v112, 0xbfb8aa3b, v73                        // 000000190518: 10E092FF BFB8AA3B
	v_mul_f32_e32 v103, 0xbfb8aa3b, v49                        // 000000190520: 10CE62FF BFB8AA3B
	v_mul_f32_e32 v113, 0xbfb8aa3b, v50                        // 000000190528: 10E264FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000190530: 7C3C62FF 42CE8ED0
	v_rndne_f32_e32 v152, v114                                 // 000000190538: 7F304772
	v_fma_f32 v117, 0xbfb8aa3b, v73, -v112                     // 00000019053C: D6130075 85C292FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v49, -v103                     // 000000190548: D6130073 859E62FF BFB8AA3B
	v_rndne_f32_e32 v116, v103                                 // 000000190554: 7EE84767
	s_waitcnt vmcnt(40)                                        // 000000190558: BF89A3F7
	v_lshlrev_b32_e32 v100, 16, v100                           // 00000019055C: 30C8C890
	v_lshlrev_b32_e32 v98, 16, v98                             // 000000190560: 30C4C490
	v_rndne_f32_e32 v118, v112                                 // 000000190564: 7EEC4770
	v_lshlrev_b32_e32 v101, 16, v101                           // 000000190568: 30CACA90
	v_lshlrev_b32_e32 v99, 16, v99                             // 00000019056C: 30C6C690
	s_waitcnt vmcnt(37)                                        // 000000190570: BF8997F7
	v_lshlrev_b32_e32 v93, 16, v93                             // 000000190574: 30BABA90
	v_dual_mul_f32 v121, 0xbfb8aa3b, v100 :: v_dual_lshlrev_b32 v102, 16, v102// 000000190578: C8E2C8FF 7966CC90 BFB8AA3B
	v_mul_f32_e32 v119, 0xbfb8aa3b, v98                        // 000000190584: 10EEC4FF BFB8AA3B
	v_fma_f32 v151, 0xbfb8aa3b, v82, -v114                     // 00000019058C: D6130097 85CAA4FF BFB8AA3B
	v_dual_fmac_f32 v115, 0xb2a5705f, v49 :: v_dual_sub_f32 v112, v112, v118// 000000190598: C80A62FF 7370ED70 B2A5705F
	v_dual_fmac_f32 v117, 0xb2a5705f, v73 :: v_dual_sub_f32 v114, v114, v152// 0000001905A4: C80A92FF 75733172 B2A5705F
	v_dual_sub_f32 v103, v103, v116 :: v_dual_mul_f32 v122, 0xbfb8aa3b, v101// 0000001905B0: C946E967 677ACAFF BFB8AA3B
	v_mul_f32_e32 v120, 0xbfb8aa3b, v99                        // 0000001905BC: 10F0C6FF BFB8AA3B
	v_fma_f32 v145, 0xbfb8aa3b, v50, -v113                     // 0000001905C4: D6130091 85C664FF BFB8AA3B
	v_rndne_f32_e32 v146, v113                                 // 0000001905D0: 7F244771
	v_dual_mul_f32 v147, 0xbfb8aa3b, v93 :: v_dual_mul_f32 v144, 0xbfb8aa3b, v102// 0000001905D4: C8C6BAFF 9390CCFF BFB8AA3B
	v_fma_f32 v154, 0xbfb8aa3b, v98, -v119                     // 0000001905E0: D613009A 85DEC4FF BFB8AA3B
	v_dual_add_f32 v112, v112, v117 :: v_dual_add_f32 v103, v103, v115// 0000001905EC: C908EB70 7066E767
	v_fma_f32 v156, 0xbfb8aa3b, v99, -v120                     // 0000001905F4: D613009C 85E2C6FF BFB8AA3B
	v_fma_f32 v158, 0xbfb8aa3b, v100, -v121                    // 000000190600: D613009E 85E6C8FF BFB8AA3B
	v_rndne_f32_e32 v163, v144                                 // 00000019060C: 7F464790
	v_fmac_f32_e32 v145, 0xb2a5705f, v50                       // 000000190610: 572264FF B2A5705F
	v_sub_f32_e32 v113, v113, v146                             // 000000190618: 08E32571
	v_fmac_f32_e32 v154, 0xb2a5705f, v98                       // 00000019061C: 5734C4FF B2A5705F
	v_exp_f32_e32 v103, v103                                   // 000000190624: 7ECE4B67
	s_waitcnt vmcnt(35)                                        // 000000190628: BF898FF7
	v_lshlrev_b32_e32 v95, 16, v95                             // 00000019062C: 30BEBE90
	s_waitcnt vmcnt(34)                                        // 000000190630: BF898BF7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000190634: 30C2C290
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000190638: 30C0C090
	v_cvt_i32_f32_e32 v116, v116                               // 00000019063C: 7EE81174
	v_rndne_f32_e32 v155, v119                                 // 000000190640: 7F364777
	v_fma_f32 v160, 0xbfb8aa3b, v101, -v122                    // 000000190644: D61300A0 85EACAFF BFB8AA3B
	v_rndne_f32_e32 v161, v122                                 // 000000190650: 7F42477A
	v_fma_f32 v162, 0xbfb8aa3b, v102, -v144                    // 000000190654: D61300A2 8642CCFF BFB8AA3B
	v_fmac_f32_e32 v156, 0xb2a5705f, v99                       // 000000190660: 5738C6FF B2A5705F
	v_fmac_f32_e32 v158, 0xb2a5705f, v100                      // 000000190668: 573CC8FF B2A5705F
	v_dual_sub_f32 v144, v144, v163 :: v_dual_add_f32 v113, v113, v145// 000000190670: C9494790 90712371
	v_exp_f32_e32 v112, v112                                   // 000000190678: 7EE04B70
	v_dual_mul_f32 v149, 0xbfb8aa3b, v95 :: v_dual_lshlrev_b32 v94, 16, v94// 00000019067C: C8E2BEFF 955EBC90 BFB8AA3B
	v_dual_mul_f32 v153, 0xbfb8aa3b, v97 :: v_dual_mul_f32 v150, 0xbfb8aa3b, v96// 000000190688: C8C6C2FF 9996C0FF BFB8AA3B
	v_cvt_i32_f32_e32 v118, v118                               // 000000190694: 7EEC1176
	v_rndne_f32_e32 v157, v120                                 // 000000190698: 7F3A4778
	v_dual_fmac_f32 v151, 0xb2a5705f, v82 :: v_dual_fmac_f32 v160, 0xb2a5705f, v101// 00000019069C: C800A4FF 97A0CAFF B2A5705F
	v_dual_sub_f32 v115, v119, v155 :: v_dual_sub_f32 v122, v122, v161// 0000001906A8: C94B3777 737B437A
	v_exp_f32_e32 v113, v113                                   // 0000001906B0: 7EE24B71
	.long 0xd71c0067                                           // 0000001906B4: D71C0067
	v_cndmask_b32_e32 v1, v103, v116, vcc_lo                   // 0000001906B8: 0202E967
	v_mul_f32_e32 v148, 0xbfb8aa3b, v94                        // 0000001906BC: 1128BCFF BFB8AA3B
	v_rndne_f32_e32 v159, v121                                 // 0000001906C4: 7F3E4779
	v_cvt_i32_f32_e32 v146, v146                               // 0000001906C8: 7F241192
	v_fma_f32 v164, 0xbfb8aa3b, v93, -v147                     // 0000001906CC: D61300A4 864EBAFF BFB8AA3B
	v_fma_f32 v168, 0xbfb8aa3b, v95, -v149                     // 0000001906D8: D61300A8 8656BEFF BFB8AA3B
	v_fma_f32 v170, 0xbfb8aa3b, v96, -v150                     // 0000001906E4: D61300AA 865AC0FF BFB8AA3B
	v_rndne_f32_e32 v171, v150                                 // 0000001906F0: 7F564796
	v_dual_sub_f32 v119, v120, v157 :: v_dual_fmac_f32 v162, 0xb2a5705f, v102// 0000001906F4: C9413B78 77A2CCFF B2A5705F
	v_dual_add_f32 v122, v122, v160 :: v_dual_cndmask_b32 v103, 0, v103// 000000190700: C913417A 7A66CE80
	.long 0xd71c0070                                           // 000000190708: D71C0070
	v_cndmask_b32_e32 v1, v112, v118, vcc_lo                   // 00000019070C: 0202ED70
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000190710: 7C3C92FF 42CE8ED0
	v_rndne_f32_e32 v165, v147                                 // 000000190718: 7F4A4793
	v_fma_f32 v166, 0xbfb8aa3b, v94, -v148                     // 00000019071C: D61300A6 8652BCFF BFB8AA3B
	v_dual_sub_f32 v121, v121, v159 :: v_dual_fmac_f32 v164, 0xb2a5705f, v93// 000000190728: C9413F79 79A4BAFF B2A5705F
	v_dual_fmac_f32 v168, 0xb2a5705f, v95 :: v_dual_add_f32 v115, v115, v154// 000000190734: C808BEFF A8733573 B2A5705F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000190740: BF870002
	v_dual_fmac_f32 v170, 0xb2a5705f, v96 :: v_dual_add_f32 v121, v121, v158// 000000190744: C808C0FF AA793D79 B2A5705F
	v_dual_sub_f32 v150, v150, v171 :: v_dual_add_f32 v119, v119, v156// 000000190750: C9495796 96773977
	.long 0xd71c0071                                           // 000000190758: D71C0071
	v_cndmask_b32_e32 v1, v113, v146, vcc_lo                   // 00000019075C: 02032571
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 000000190760: 02E0E080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v50                  // 000000190764: 7C3C64FF 42CE8ED0
	v_dual_sub_f32 v145, v147, v165 :: v_dual_fmac_f32 v166, 0xb2a5705f, v94// 00000019076C: C9414B93 91A6BCFF B2A5705F
	v_add_f32_e32 v144, v144, v162                             // 000000190778: 07214590
	v_dual_add_f32 v150, v150, v170 :: v_dual_cndmask_b32 v113, 0, v113// 00000019077C: C9135596 9670E280
	v_exp_f32_e32 v115, v115                                   // 000000190784: 7EE64B73
	v_exp_f32_e32 v119, v119                                   // 000000190788: 7EEE4B77
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000019078C: 7C3662FF C2B17218
	v_cvt_i32_f32_e32 v117, v155                               // 000000190794: 7EEA119B
	v_cvt_i32_f32_e32 v120, v157                               // 000000190798: 7EF0119D
	v_add_f32_e32 v145, v145, v164                             // 00000019079C: 07234991
	v_exp_f32_e32 v144, v144                                   // 0000001907A0: 7F204B90
	v_cndmask_b32_e32 v49, 0x7f800000, v103, vcc_lo            // 0000001907A4: 0262CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000001907AC: 7C3692FF C2B17218
	v_cvt_i32_f32_e32 v155, v159                               // 0000001907B4: 7F36119F
	v_cvt_i32_f32_e32 v159, v163                               // 0000001907B8: 7F3E11A3
	v_exp_f32_e32 v121, v121                                   // 0000001907BC: 7EF24B79
	.long 0xd71c0073                                           // 0000001907C0: D71C0073
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                   // 0000001907C4: 0202EB73
	.long 0xd71c0075                                           // 0000001907C8: D71C0075
	v_cndmask_b32_e32 v1, v119, v120, vcc_lo                   // 0000001907CC: 0202F177
	v_cndmask_b32_e32 v73, 0x7f800000, v112, vcc_lo            // 0000001907D0: 0292E0FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v98                  // 0000001907D8: 7C3CC4FF 42CE8ED0
	v_exp_f32_e32 v122, v122                                   // 0000001907E0: 7EF44B7A
	.long 0xd71c0078                                           // 0000001907E4: D71C0078
	v_cndmask_b32_e32 v1, v144, v159, vcc_lo                   // 0000001907E8: 02033F90
	v_rndne_f32_e32 v167, v148                                 // 0000001907EC: 7F4E4794
	v_cvt_i32_f32_e32 v157, v161                               // 0000001907F0: 7F3A11A1
	v_cndmask_b32_e32 v103, 0, v115, vcc_lo                    // 0000001907F4: 02CEE680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v99                  // 0000001907F8: 7C3CC6FF 42CE8ED0
	.long 0xd71c0076                                           // 000000190800: D71C0076
	v_cndmask_b32_e32 v1, v121, v155, vcc_lo                   // 000000190804: 02033779
	v_rndne_f32_e32 v169, v149                                 // 000000190808: 7F524795
	v_sub_f32_e32 v148, v148, v167                             // 00000019080C: 09294F94
	v_exp_f32_e32 v145, v145                                   // 000000190810: 7F224B91
	v_cndmask_b32_e32 v112, 0, v117, vcc_lo                    // 000000190814: 02E0EA80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 000000190818: 7C3CC8FF 42CE8ED0
	.long 0xd71c0077                                           // 000000190820: D71C0077
	v_cndmask_b32_e32 v1, v122, v157, vcc_lo                   // 000000190824: 02033B7A
	v_dual_sub_f32 v149, v149, v169 :: v_dual_add_f32 v148, v148, v166// 000000190828: C9495395 95954D94
	v_cvt_i32_f32_e32 v147, v165                               // 000000190830: 7F2611A5
	v_cndmask_b32_e32 v115, 0, v118, vcc_lo                    // 000000190834: 02E6EC80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v101                 // 000000190838: 7C3CCAFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000190840: BF870004
	v_add_f32_e32 v149, v149, v168                             // 000000190844: 072B5195
	v_exp_f32_e32 v148, v148                                   // 000000190848: 7F284B94
	v_exp_f32_e32 v116, v150                                   // 00000019084C: 7EE84B96
	v_cvt_i32_f32_e32 v161, v167                               // 000000190850: 7F4211A7
	v_cndmask_b32_e32 v117, 0, v119, vcc_lo                    // 000000190854: 02EAEE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 000000190858: 7C3CCCFF 42CE8ED0
	v_cvt_i32_f32_e32 v165, v171                               // 000000190860: 7F4A11AB
	v_exp_f32_e32 v149, v149                                   // 000000190864: 7F2A4B95
	.long 0xd71c0079                                           // 000000190868: D71C0079
	v_cndmask_b32_e32 v1, v145, v147, vcc_lo                   // 00000019086C: 02032791
	v_cvt_i32_f32_e32 v163, v169                               // 000000190870: 7F4611A9
	v_cndmask_b32_e32 v118, 0, v120, vcc_lo                    // 000000190874: 02ECF080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v50                  // 000000190878: 7C3664FF C2B17218
	.long 0xd71c007a                                           // 000000190880: D71C007A
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 000000190884: 02034394
	.long 0xd71c0074                                           // 000000190888: D71C0074
	v_cndmask_b32_e32 v1, v116, v165, vcc_lo                   // 00000019088C: 02034B74
	v_add_f32_e32 v120, 1.0, v49                               // 000000190890: 06F062F2
	.long 0xd41b0005                                           // 000000190894: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v94, vcc_lo              // 000000190898: 0202BCFF C2B17218
	v_cndmask_b32_e32 v50, 0x7f800000, v113, vcc_lo            // 0000001908A0: 0264E2FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v93                  // 0000001908A8: 7C3CBAFF 42CE8ED0
	.long 0xd71c0090                                           // 0000001908B0: D71C0090
	v_cndmask_b32_e32 v1, v149, v163, vcc_lo                   // 0000001908B4: 02034795
	v_cndmask_b32_e32 v113, 0, v121, vcc_lo                    // 0000001908B8: 02E2F280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v94                  // 0000001908BC: 7C3CBCFF 42CE8ED0
	v_div_scale_f32 v121, null, v120, v120, v57                // 0000001908C4: D6FC7C79 04E6F178
	v_cndmask_b32_e32 v119, 0, v122, vcc_lo                    // 0000001908CC: 02EEF480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v95                  // 0000001908D0: 7C3CBEFF 42CE8ED0
	v_cndmask_b32_e32 v49, 0, v144, vcc_lo                     // 0000001908D8: 02632080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000001908DC: 7C3CC0FF 42CE8ED0
	v_cndmask_b32_e32 v116, 0, v116, vcc_lo                    // 0000001908E4: 02E8E880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v98                  // 0000001908E8: 7C36C4FF C2B17218
	v_cndmask_b32_e32 v98, 0x7f800000, v103, vcc_lo            // 0000001908F0: 02C4CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v99                  // 0000001908F8: 7C36C6FF C2B17218
	v_rcp_f32_e32 v103, v121                                   // 000000190900: 7ECE5579
	v_cndmask_b32_e64 v94, 0x7f800000, v119, s5                // 000000190904: D501005E 0016EEFF 7F800000
	.long 0xd41b0005                                           // 000000190910: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v95, vcc_lo              // 000000190914: 0202BEFF C2B17218
	v_dual_add_f32 v98, 1.0, v98 :: v_dual_cndmask_b32 v99, 0x7f800000, v112// 00000019091C: C912C4F2 6262E0FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 000000190928: 7C36C8FF C2B17218
	v_dual_add_f32 v73, 1.0, v73 :: v_dual_cndmask_b32 v100, 0x7f800000, v115// 000000190930: C91292F2 4964E6FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019093C: BF870121
	v_div_scale_f32 v122, null, v73, v73, v58                  // 000000190940: D6FC7C7A 04EA9349
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v101                 // 000000190948: 7C36CAFF C2B17218
	v_rcp_f32_e32 v112, v122                                   // 000000190950: 7EE0557A
	v_cndmask_b32_e32 v101, 0x7f800000, v117, vcc_lo           // 000000190954: 02CAEAFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 00000019095C: 7C36CCFF C2B17218
	v_cndmask_b32_e32 v102, 0x7f800000, v118, vcc_lo           // 000000190964: 02CCECFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v93                  // 00000019096C: 7C36BAFF C2B17218
	v_div_scale_f32 v118, s4, v58, v73, v58                    // 000000190974: D6FC0476 04EA933A
	v_cndmask_b32_e64 v95, 0x7f800000, v49, s5                 // 00000019097C: D501005F 001662FF 7F800000
	.long 0xd41b0005                                           // 000000190988: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v96, vcc_lo              // 00000019098C: 0202C0FF C2B17218
	v_dual_add_f32 v102, 1.0, v102 :: v_dual_cndmask_b32 v93, 0x7f800000, v113// 000000190994: C912CCF2 665CE2FF 7F800000
	v_div_scale_f32 v117, vcc_lo, v57, v120, v57               // 0000001909A0: D6FC6A75 04E6F139
	v_add_f32_e32 v115, 1.0, v50                               // 0000001909A8: 06E664F2
	v_fma_f32 v50, -v121, v103, 1.0                            // 0000001909AC: D6130032 23CACF79
	v_fma_f32 v113, -v122, v112, 1.0                           // 0000001909B4: D6130071 23CAE17A
	v_div_scale_f32 v119, null, v102, v102, v80                // 0000001909BC: D6FC7C77 0542CD66
	v_cndmask_b32_e64 v96, 0x7f800000, v116, s5                // 0000001909C4: D5010060 0016E8FF 7F800000
	v_dual_add_f32 v94, 1.0, v94 :: v_dual_add_f32 v95, 1.0, v95// 0000001909D0: C908BCF2 5E5EBEF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001909D8: BF870214
	v_dual_fmac_f32 v103, v50, v103 :: v_dual_fmac_f32 v112, v113, v112// 0000001909DC: C800CF32 6770E171
	v_rcp_f32_e32 v146, v119                                   // 0000001909E4: 7F245577
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001909E8: BF870111
	v_mul_f32_e32 v50, v117, v103                              // 0000001909EC: 1064CF75
	v_mul_f32_e32 v144, v118, v112                             // 0000001909F0: 1120E176
	v_div_scale_f32 v113, null, v115, v115, v111               // 0000001909F4: D6FC7C71 05BEE773
	v_div_scale_f32 v116, s5, v111, v115, v111                 // 0000001909FC: D6FC0574 05BEE76F
	v_add_f32_e32 v93, 1.0, v93                                // 000000190A04: 06BABAF2
	v_fma_f32 v49, -v121, v50, v117                            // 000000190A08: D6130031 25D66579
	v_fma_f32 v147, -v122, v144, v118                          // 000000190A10: D6130093 25DB217A
	v_rcp_f32_e32 v145, v113                                   // 000000190A18: 7F225571
	v_add_f32_e32 v99, 1.0, v99                                // 000000190A1C: 06C6C6F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000190A20: BF870193
	v_fmac_f32_e32 v50, v49, v103                              // 000000190A24: 5664CF31
	v_fmac_f32_e32 v144, v147, v112                            // 000000190A28: 5720E193
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000190A2C: BF870112
	v_fma_f32 v117, -v121, v50, v117                           // 000000190A30: D6130075 25D66579
	v_fma_f32 v118, -v122, v144, v118                          // 000000190A38: D6130076 25DB217A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000190A40: BF870225
	v_fma_f32 v49, -v113, v145, 1.0                            // 000000190A44: D6130031 23CB2371
	v_fma_f32 v121, -v119, v146, 1.0                           // 000000190A4C: D6130079 23CB2577
	v_div_fmas_f32 v103, v117, v103, v50                       // 000000190A54: D6370067 04CACF75
	s_mov_b32 vcc_lo, s4                                       // 000000190A5C: BEEA0004
	s_delay_alu instid0(VALU_DEP_3)                            // 000000190A60: BF870003
	v_fmac_f32_e32 v145, v49, v145                             // 000000190A64: 57232331
	v_div_fmas_f32 v112, v118, v112, v144                      // 000000190A68: D6370070 0642E176
	s_mov_b32 vcc_lo, s2                                       // 000000190A70: BEEA0002
	v_fmac_f32_e32 v146, v121, v146                            // 000000190A74: 57252579
	v_div_fmas_f32 v50, v109, v91, v71                         // 000000190A78: D6370032 051EB76D
	s_mov_b32 vcc_lo, s3                                       // 000000190A80: BEEA0003
	v_div_fixup_f32 v57, v103, v120, v57                       // 000000190A84: D6270039 04E6F167
	v_div_fmas_f32 v71, v108, v90, v72                         // 000000190A8C: D6370047 0522B56C
	v_div_scale_f32 v72, s2, v80, v102, v80                    // 000000190A94: D6FC0248 0542CD50
	v_div_fixup_f32 v50, v50, v89, 1.0                         // 000000190A9C: D6270032 03CAB332
	v_add_f32_e32 v90, 1.0, v100                               // 000000190AA4: 06B4C8F2
	v_add_f32_e32 v96, 1.0, v96                                // 000000190AA8: 06C0C0F2
	v_div_fixup_f32 v49, v71, v88, 1.0                         // 000000190AAC: D6270031 03CAB147
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000190AB4: BF870244
	v_dual_mul_f32 v88, v116, v145 :: v_dual_mul_f32 v59, v59, v50// 000000190AB8: C8C72374 583A653B
	v_add_f32_e32 v71, 1.0, v101                               // 000000190AC0: 068ECAF2
	v_mul_f32_e32 v103, v51, v50                               // 000000190AC4: 10CE6533
	.long 0x7e9e39b9                                           // 000000190AC8: 7E9E39B9
	v_fma_f32 v91, -v113, v88, v116                            // 000000190ACC: D613005B 25D2B171
	v_mul_f32_e32 v89, v72, v146                               // 000000190AD4: 10B32548
	v_div_scale_f32 v100, null, v98, v98, v59                  // 000000190AD8: D6FC7C64 04EEC562
	v_div_fixup_f32 v58, v112, v73, v58                        // 000000190AE0: D627003A 04EA9370
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000190AE8: BF870214
	v_dual_fmac_f32 v88, v91, v145 :: v_dual_and_b32 v79, 1, v79// 000000190AEC: C825235B 584E9E81
	v_fma_f32 v101, -v119, v89, v72                            // 000000190AF4: D6130065 2522B377
	v_mul_f32_e32 v60, v60, v49                                // 000000190AFC: 1078633C
	v_rcp_f32_e32 v91, v100                                    // 000000190B00: 7EB65564
	.long 0x7e0039ba                                           // 000000190B04: 7E0039BA
	v_fma_f32 v109, -v113, v88, v116                           // 000000190B08: D613006D 25D2B171
	v_fmac_f32_e32 v89, v101, v146                             // 000000190B10: 56B32565
	v_div_scale_f32 v108, null, v99, v99, v60                  // 000000190B14: D6FC7C6C 04F2C763
	v_mul_f32_e32 v113, v52, v49                               // 000000190B1C: 10E26334
	v_div_scale_f32 v116, vcc_lo, v59, v98, v59                // 000000190B20: D6FC6A74 04EEC53B
	v_div_scale_f32 v122, s4, v103, v93, v103                  // 000000190B28: D6FC047A 059EBB67
	v_div_scale_f32 v117, null, v93, v93, v103                 // 000000190B30: D6FC7C75 059EBB5D
	v_rcp_f32_e32 v101, v108                                   // 000000190B38: 7ECA556C
	v_fma_f32 v51, -v100, v91, 1.0                             // 000000190B3C: D6130033 23CAB764
	v_fma_f32 v72, -v119, v89, v72                             // 000000190B44: D6130048 2522B377
	v_add3_u32 v57, v57, v79, 0x7fff                           // 000000190B4C: D6550039 03FE9F39 00007FFF
	v_rcp_f32_e32 v112, v117                                   // 000000190B58: 7EE05575
	v_dual_mul_f32 v43, v43, v50 :: v_dual_mul_f32 v44, v44, v49// 000000190B5C: C8C6652B 2B2C632C
	v_dual_mul_f32 v36, v36, v49 :: v_dual_mul_f32 v35, v35, v50// 000000190B64: C8C66324 24226523
	v_mul_f32_e32 v28, v28, v49                                // 000000190B6C: 1038631C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000190B70: BF870246
	v_fma_f32 v52, -v108, v101, 1.0                            // 000000190B74: D6130034 23CACB6C
	v_dual_mul_f32 v20, v20, v49 :: v_dual_mul_f32 v27, v27, v50// 000000190B7C: C8C66314 141A651B
	v_dual_mul_f32 v12, v12, v49 :: v_dual_mul_f32 v19, v19, v50// 000000190B84: C8C6630C 0C126513
	v_mul_f32_e32 v4, v4, v49                                  // 000000190B8C: 10086304
	v_fmac_f32_e32 v101, v52, v101                             // 000000190B90: 56CACB34
	v_fmac_f32_e32 v91, v51, v91                               // 000000190B94: 56B6B733
	v_div_scale_f32 v51, s3, v60, v99, v60                     // 000000190B98: D6FC0333 04F2C73C
	v_mul_f32_e32 v11, v11, v50                                // 000000190BA0: 1016650B
	v_mul_f32_e32 v3, v3, v50                                  // 000000190BA4: 10066503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000190BA8: BF870093
	v_mul_f32_e32 v118, v51, v101                              // 000000190BAC: 10ECCB33
	v_fma_f32 v121, -v108, v118, v51                           // 000000190BB0: D6130079 24CEED6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000190BB8: BF870121
	v_fmac_f32_e32 v118, v121, v101                            // 000000190BBC: 56ECCB79
	v_mul_f32_e32 v52, v116, v91                               // 000000190BC0: 1068B774
	v_fma_f32 v51, -v108, v118, v51                            // 000000190BC4: D6130033 24CEED6C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000190BCC: BF870092
	v_fma_f32 v120, -v100, v52, v116                           // 000000190BD0: D6130078 25D26964
	v_fmac_f32_e32 v52, v120, v91                              // 000000190BD8: 5668B778
	v_fma_f32 v120, -v117, v112, 1.0                           // 000000190BDC: D6130078 23CAE175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000190BE4: BF870092
	v_fma_f32 v100, -v100, v52, v116                           // 000000190BE8: D6130064 25D26964
	v_div_fmas_f32 v91, v100, v91, v52                         // 000000190BF0: D637005B 04D2B764
	s_mov_b32 vcc_lo, s3                                       // 000000190BF8: BEEA0003
	v_div_fmas_f32 v100, v51, v101, v118                       // 000000190BFC: D6370064 05DACB33
	s_mov_b32 vcc_lo, s0                                       // 000000190C04: BEEA0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000190C08: BF870002
	v_div_fixup_f32 v59, v91, v98, v59                         // 000000190C0C: D627003B 04EEC55B
	v_div_fmas_f32 v51, v107, v85, v142                        // 000000190C14: D6370033 063AAB6B
	s_mov_b32 vcc_lo, s1                                       // 000000190C1C: BEEA0001
	v_div_fixup_f32 v60, v100, v99, v60                        // 000000190C20: D627003C 04F2C764
	v_div_fmas_f32 v84, v110, v84, v143                        // 000000190C28: D6370054 063EA96E
	v_and_b32_e32 v85, 1, v0                                   // 000000190C30: 36AA0081
	v_div_fixup_f32 v52, v51, v83, 1.0                         // 000000190C34: D6270034 03CAA733
	.long 0x7e9a39bb                                           // 000000190C3C: 7E9A39BB
	.long 0x7e0039bc                                           // 000000190C40: 7E0039BC
	v_div_fixup_f32 v51, v84, v81, 1.0                         // 000000190C44: D6270033 03CAA354
	v_add3_u32 v58, v58, v85, 0x7fff                           // 000000190C4C: D655003A 03FEAB3A 00007FFF
	v_mul_f32_e32 v61, v61, v52                                // 000000190C58: 107A693D
	s_clause 0x1                                               // 000000190C5C: BF850001
	global_store_d16_hi_b16 v[7:8], v57, off                   // 000000190C60: DC960000 007C3907
	global_store_d16_hi_b16 v[7:8], v58, off offset:1024       // 000000190C68: DC960400 007C3A07
	v_mul_f32_e32 v62, v62, v51                                // 000000190C70: 107C673E
	v_div_scale_f32 v73, null, v94, v94, v113                  // 000000190C74: D6FC7C49 05C6BD5E
	v_div_scale_f32 v121, s6, v113, v94, v113                  // 000000190C7C: D6FC0679 05C6BD71
	v_mul_f32_e32 v54, v54, v51                                // 000000190C84: 106C6736
	v_div_scale_f32 v85, null, v90, v90, v61                   // 000000190C88: D6FC7C55 04F6B55A
	v_mul_f32_e32 v53, v53, v52                                // 000000190C90: 106A6935
	v_rcp_f32_e32 v119, v73                                    // 000000190C94: 7EEE5549
	v_div_scale_f32 v99, vcc_lo, v61, v90, v61                 // 000000190C98: D6FC6A63 04F6B53D
	v_div_scale_f32 v116, null, v96, v96, v54                  // 000000190CA0: D6FC7C74 04DAC160
	v_mul_f32_e32 v37, v37, v52                                // 000000190CA8: 104A6925
	v_div_scale_f32 v100, null, v95, v95, v53                  // 000000190CAC: D6FC7C64 04D6BF5F
	v_div_scale_f32 v110, s1, v53, v95, v53                    // 000000190CB4: D6FC016E 04D6BF35
	v_dual_mul_f32 v22, v22, v51 :: v_dual_mul_f32 v29, v29, v52// 000000190CBC: C8C66716 161C691D
	v_mul_f32_e32 v14, v14, v51                                // 000000190CC4: 101C670E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000190CC8: BF870314
	v_rcp_f32_e32 v107, v100                                   // 000000190CCC: 7ED65564
	v_fma_f32 v144, -v73, v119, 1.0                            // 000000190CD0: D6130090 23CAEF49
	v_mul_f32_e32 v21, v21, v52                                // 000000190CD8: 102A6915
	v_mul_f32_e32 v13, v13, v52                                // 000000190CDC: 101A690D
	v_dual_mul_f32 v5, v5, v52 :: v_dual_mul_f32 v6, v6, v51   // 000000190CE0: C8C66905 05066706
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000190CE8: BF870094
	v_fmac_f32_e32 v119, v144, v119                            // 000000190CEC: 56EEEF90
	v_dual_fmac_f32 v112, v120, v112 :: v_dual_mul_f32 v81, v121, v119// 000000190CF0: C806E178 7050EF79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000190CF8: BF870111
	v_mul_f32_e32 v83, v122, v112                              // 000000190CFC: 10A6E17A
	v_fma_f32 v84, -v73, v81, v121                             // 000000190D00: D6130054 25E6A349
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000190D08: BF870092
	v_fma_f32 v79, -v117, v83, v122                            // 000000190D0C: D613004F 25EAA775
	v_fmac_f32_e32 v83, v79, v112                              // 000000190D14: 56A6E14F
	v_div_scale_f32 v79, null, v71, v71, v62                   // 000000190D18: D6FC7C4F 04FA8F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000190D20: BF870291
	v_rcp_f32_e32 v91, v79                                     // 000000190D24: 7EB6554F
	v_fma_f32 v98, -v79, v91, 1.0                              // 000000190D28: D6130062 23CAB74F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000190D30: BF870131
	v_dual_fmac_f32 v91, v98, v91 :: v_dual_and_b32 v98, 1, v0 // 000000190D34: C824B762 5B620081
	v_fmac_f32_e32 v81, v84, v119                              // 000000190D3C: 56A2EF54
	v_rcp_f32_e32 v84, v85                                     // 000000190D40: 7EA85555
	v_add3_u32 v60, v60, v98, 0x7fff                           // 000000190D44: D655003C 03FEC53C 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000190D50: BF870292
	v_fma_f32 v58, -v73, v81, v121                             // 000000190D54: D613003A 25E6A349
	v_fma_f32 v73, -v85, v84, 1.0                              // 000000190D5C: D6130049 23CAA955
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000190D64: BF8700A1
	v_fmac_f32_e32 v84, v73, v84                               // 000000190D68: 56A8A949
	v_div_scale_f32 v73, s0, v62, v71, v62                     // 000000190D6C: D6FC0049 04FA8F3E
	v_dual_mul_f32 v101, v99, v84 :: v_dual_mul_f32 v108, v73, v91// 000000190D74: C8C6A963 656CB749
	v_fma_f32 v57, -v117, v83, v122                            // 000000190D7C: D6130039 25EAA775
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000190D84: BF870092
	v_fma_f32 v117, -v79, v108, v73                            // 000000190D88: D6130075 2526D94F
	v_dual_fmac_f32 v108, v117, v91 :: v_dual_and_b32 v77, 1, v77// 000000190D90: C824B775 6C4C9A81
	s_delay_alu instid0(VALU_DEP_1)                            // 000000190D98: BF870001
	v_add3_u32 v59, v59, v77, 0x7fff                           // 000000190D9C: D655003B 03FE9B3B 00007FFF
	v_fma_f32 v77, -v85, v101, v99                             // 000000190DA8: D613004D 258ECB55
	global_store_d16_hi_b16 v[15:16], v59, off                 // 000000190DB0: DC960000 007C3B0F
	v_fma_f32 v59, -v100, v107, 1.0                            // 000000190DB8: D613003B 23CAD764
	global_store_d16_hi_b16 v[23:24], v60, off                 // 000000190DC0: DC960000 007C3C17
	v_fmac_f32_e32 v107, v59, v107                             // 000000190DC8: 56D6D73B
	v_fmac_f32_e32 v101, v77, v84                              // 000000190DCC: 56CAA94D
	v_fma_f32 v59, -v79, v108, v73                             // 000000190DD0: D613003B 2526D94F
	v_rcp_f32_e32 v77, v116                                    // 000000190DD8: 7E9A5574
	s_waitcnt vmcnt(23)                                        // 000000190DDC: BF895FF7
	v_lshlrev_b32_e32 v79, 16, v137                            // 000000190DE0: 309F1290
	v_mul_f32_e32 v41, v41, v66                                // 000000190DE4: 10528529
	v_fma_f32 v60, -v85, v101, v99                             // 000000190DE8: D613003C 258ECB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000190DF0: BF870141
	v_div_fmas_f32 v60, v60, v84, v101                         // 000000190DF4: D637003C 0596A93C
	s_mov_b32 vcc_lo, s0                                       // 000000190DFC: BEEA0000
	v_div_fmas_f32 v59, v59, v91, v108                         // 000000190E00: D637003B 05B2B73B
	s_mov_b32 vcc_lo, s2                                       // 000000190E08: BEEA0002
	v_div_fixup_f32 v60, v60, v90, v61                         // 000000190E0C: D627003C 04F6B53C
	v_div_fmas_f32 v72, v72, v146, v89                         // 000000190E14: D6370048 05672548
	s_mov_b32 vcc_lo, s5                                       // 000000190E1C: BEEA0005
	v_div_fixup_f32 v59, v59, v71, v62                         // 000000190E20: D627003B 04FA8F3B
	v_div_fmas_f32 v61, v109, v145, v88                        // 000000190E28: D637003D 0563236D
	.long 0x7e9839bc                                           // 000000190E30: 7E9839BC
	v_div_fixup_f32 v62, v72, v102, v80                        // 000000190E34: D627003E 0542CD48
	s_mov_b32 vcc_lo, s4                                       // 000000190E3C: BEEA0004
	.long 0x7e0039bb                                           // 000000190E40: 7E0039BB
	v_div_fixup_f32 v61, v61, v115, v111                       // 000000190E44: D627003D 05BEE73D
	v_and_b32_e32 v72, 1, v76                                  // 000000190E4C: 36909881
	.long 0x7e9639be                                           // 000000190E50: 7E9639BE
	v_div_fmas_f32 v57, v57, v112, v83                         // 000000190E54: D6370039 054EE139
	v_and_b32_e32 v71, 1, v0                                   // 000000190E5C: 368E0081
	.long 0x7e0039bd                                           // 000000190E60: 7E0039BD
	v_add3_u32 v60, v60, v72, 0x7fff                           // 000000190E64: D655003C 03FE913C 00007FFF
	v_fma_f32 v72, 0xbfb8aa3b, v97, -v153                      // 000000190E70: D6130048 8666C2FF BFB8AA3B
	s_mov_b32 vcc_lo, s6                                       // 000000190E7C: BEEA0006
	v_add3_u32 v59, v59, v71, 0x7fff                           // 000000190E80: D655003B 03FE8F3B 00007FFF
	v_div_fmas_f32 v58, v58, v119, v81                         // 000000190E8C: D637003A 0546EF3A
	v_div_fixup_f32 v57, v57, v93, v103                        // 000000190E94: D6270039 059EBB39
	v_dual_fmac_f32 v72, 0xb2a5705f, v97 :: v_dual_and_b32 v73, 1, v75// 000000190E9C: C824C2FF 48489681 B2A5705F
	v_and_b32_e32 v75, 1, v0                                   // 000000190EA8: 36960081
	s_delay_alu instid0(VALU_DEP_4)                            // 000000190EAC: BF870004
	v_div_fixup_f32 v58, v58, v94, v113                        // 000000190EB0: D627003A 05C6BD3A
	s_clause 0x1                                               // 000000190EB8: BF850001
	global_store_d16_hi_b16 v[31:32], v60, off                 // 000000190EBC: DC960000 007C3C1F
	global_store_d16_hi_b16 v[39:40], v59, off                 // 000000190EC4: DC960000 007C3B27
	v_fma_f32 v60, -v116, v77, 1.0                             // 000000190ECC: D613003C 23CA9B74
	v_add3_u32 v62, v62, v73, 0x7fff                           // 000000190ED4: D655003E 03FE933E 00007FFF
	v_add3_u32 v61, v61, v75, 0x7fff                           // 000000190EE0: D655003D 03FE973D 00007FFF
	s_clause 0x1                                               // 000000190EEC: BF850001
	global_store_d16_hi_b16 v[7:8], v61, off offset:32         // 000000190EF0: DC960020 007C3D07
	global_store_d16_hi_b16 v[47:48], v62, off offset:32       // 000000190EF8: DC960020 007C3E2F
	v_add_f32_e32 v61, v114, v151                              // 000000190F00: 067B2F72
	.long 0x7e0039ba                                           // 000000190F04: 7E0039BA
	.long 0x7e9439b9                                           // 000000190F08: 7E9439B9
	v_rndne_f32_e32 v73, v153                                  // 000000190F0C: 7E924799
	v_fmac_f32_e32 v77, v60, v77                               // 000000190F10: 569A9B3C
	v_exp_f32_e32 v60, v61                                     // 000000190F14: 7E784B3D
	v_div_scale_f32 v61, s0, v54, v96, v54                     // 000000190F18: D6FC003D 04DAC136
	v_and_b32_e32 v59, 1, v0                                   // 000000190F20: 36760081
	v_dual_sub_f32 v74, v153, v73 :: v_dual_and_b32 v71, 1, v74// 000000190F24: C9649399 4A469481
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v82                  // 000000190F2C: 7C3CA4FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000190F34: BF870004
	v_mul_f32_e32 v76, v61, v77                                // 000000190F38: 10989B3D
	v_mul_f32_e32 v62, v110, v107                              // 000000190F3C: 107CD76E
	v_add3_u32 v58, v58, v59, 0x7fff                           // 000000190F40: D655003A 03FE773A 00007FFF
	v_cvt_i32_f32_e32 v59, v152                                // 000000190F4C: 7E761198
	v_add_f32_e32 v72, v74, v72                                // 000000190F50: 0690914A
	v_add3_u32 v57, v57, v71, 0x7fff                           // 000000190F54: D6550039 03FE8F39 00007FFF
	v_fma_f32 v75, -v100, v62, v110                            // 000000190F60: D613004B 25BA7D64
	v_mul_f32_e32 v80, 0xbfb8aa3b, v79                         // 000000190F68: 10A09EFF BFB8AA3B
	.long 0xd71c003b                                           // 000000190F70: D71C003B
	v_cndmask_b32_e32 v1, v60, v59, vcc_lo                     // 000000190F74: 0202773C
	v_fma_f32 v60, -v116, v76, v61                             // 000000190F78: D613003C 24F69974
	v_exp_f32_e32 v71, v72                                     // 000000190F80: 7E8E4B48
	v_fmac_f32_e32 v62, v75, v107                              // 000000190F84: 567CD74B
	global_store_d16_hi_b16 v[15:16], v57, off offset:32       // 000000190F88: DC960020 007C390F
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 000000190F90: 02767680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v82                  // 000000190F94: 7C36A4FF C2B17218
	v_fmac_f32_e32 v76, v60, v77                               // 000000190F9C: 56989B3C
	v_fma_f32 v72, -v100, v62, v110                            // 000000190FA0: D6130048 25BA7D64
	v_cvt_i32_f32_e32 v60, v73                                 // 000000190FA8: 7E781149
	global_store_d16_hi_b16 v[23:24], v58, off offset:32       // 000000190FAC: DC960020 007C3A17
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 000000190FB4: 027676FF 7F800000
	s_mov_b32 vcc_lo, s1                                       // 000000190FBC: BEEA0001
	v_fma_f32 v61, -v116, v76, v61                             // 000000190FC0: D613003D 24F69974
	v_div_fmas_f32 v62, v72, v107, v62                         // 000000190FC8: D637003E 04FAD748
	.long 0xd71c003c                                           // 000000190FD0: D71C003C
	v_cndmask_b32_e32 v1, v71, v60, vcc_lo                     // 000000190FD4: 02027947
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000190FD8: 7C3CC2FF 42CE8ED0
	.long 0x7f903980                                           // 000000190FE0: 7F903980
	v_fma_f32 v82, 0xbfb8aa3b, v79, -v80                       // 000000190FE4: D6130052 85429EFF BFB8AA3B
	v_div_fixup_f32 v53, v62, v95, v53                         // 000000190FF0: D6270035 04D6BF3E
	v_rndne_f32_e32 v83, v80                                   // 000000190FF8: 7EA64750
	v_cndmask_b32_e32 v60, 0, v60, vcc_lo                      // 000000190FFC: 02787880
	s_mov_b32 vcc_lo, s0                                       // 000000191000: BEEA0000
	v_div_fmas_f32 v61, v61, v77, v76                          // 000000191004: D637003D 05329B3D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000019100C: 7C36C2FF C2B17218
	.long 0x7e9039b5                                           // 000000191014: 7E9039B5
	v_sub_f32_e32 v80, v80, v83                                // 000000191018: 08A0A750
	v_fmac_f32_e32 v82, 0xb2a5705f, v79                        // 00000019101C: 56A49EFF B2A5705F
	v_div_fixup_f32 v54, v61, v96, v54                         // 000000191024: D6270036 04DAC13D
	v_dual_cndmask_b32 v60, 0x7f800000, v60 :: v_dual_lshlrev_b32 v61, 16, v138// 00000019102C: CA6278FF 3C3D1490 7F800000
	v_and_b32_e32 v72, 1, v72                                  // 000000191038: 36909081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019103C: BF870214
	v_add_f32_e32 v80, v80, v82                                // 000000191040: 06A0A550
	.long 0x7e0039b6                                           // 000000191044: 7E0039B6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000191048: BF870234
	v_add_f32_e32 v60, 1.0, v60                                // 00000019104C: 067878F2
	v_mul_f32_e32 v62, 0xbfb8aa3b, v61                         // 000000191050: 107C7AFF BFB8AA3B
	v_add3_u32 v53, v53, v72, 0x7fff                           // 000000191058: D6550035 03FE9135 00007FFF
	v_and_b32_e32 v77, 1, v0                                   // 000000191064: 369A0081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000191068: BF870214
	v_div_scale_f32 v58, null, v60, v60, v42                   // 00000019106C: D6FC7C3A 04AA793C
	v_fma_f32 v75, 0xbfb8aa3b, v61, -v62                       // 000000191074: D613004B 84FA7AFF BFB8AA3B
	v_rndne_f32_e32 v76, v62                                   // 000000191080: 7E98473E
	global_store_d16_hi_b16 v[31:32], v53, off offset:32       // 000000191084: DC960020 007C351F
	v_add3_u32 v54, v54, v77, 0x7fff                           // 00000019108C: D6550036 03FE9B36 00007FFF
	v_rcp_f32_e32 v74, v58                                     // 000000191098: 7E94553A
	v_sub_f32_e32 v62, v62, v76                                // 00000019109C: 087C993E
	v_cvt_i32_f32_e32 v76, v76                                 // 0000001910A0: 7E98114C
	global_store_d16_hi_b16 v[39:40], v54, off offset:32       // 0000001910A4: DC960020 007C3627
	v_fma_f32 v81, -v58, v74, 1.0                              // 0000001910AC: D6130051 23CA953A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001910B4: BF870091
	v_dual_add_f32 v59, 1.0, v59 :: v_dual_fmac_f32 v74, v81, v74// 0000001910B8: C90076F2 3B4A9551
	v_div_scale_f32 v71, null, v59, v59, v41                   // 0000001910C0: D6FC7C47 04A6773B
	v_div_scale_f32 v81, s0, v42, v60, v42                     // 0000001910C8: D6FC0051 04AA792A
	v_fmac_f32_e32 v75, 0xb2a5705f, v61                        // 0000001910D0: 56967AFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001910D8: BF870113
	v_rcp_f32_e32 v57, v71                                     // 0000001910DC: 7E725547
	v_mul_f32_e32 v84, v81, v74                                // 0000001910E0: 10A89551
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001910E4: BF8701A2
	v_add_f32_e32 v62, v62, v75                                // 0000001910E8: 067C973E
	.long 0xd41e0001                                           // 0000001910EC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v61, vcc_lo              // 0000001910F0: 02027AFF 42CE8ED0
	v_fma_f32 v72, -v58, v84, v81                              // 0000001910F8: D6130048 2546A93A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000191100: BF870313
	v_exp_f32_e32 v62, v62                                     // 000000191104: 7E7C4B3E
	v_fma_f32 v73, -v71, v57, 1.0                              // 000000191108: D6130049 23CA7347
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000191110: BF8701A2
	v_fmac_f32_e32 v84, v72, v74                               // 000000191114: 56A89548
	v_cvt_i32_f32_e32 v72, v83                                 // 000000191118: 7E901153
	v_fmac_f32_e32 v57, v73, v57                               // 00000019111C: 56727349
	v_div_scale_f32 v73, vcc_lo, v41, v59, v41                 // 000000191120: D6FC6A49 04A67729
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000191128: BF8701B5
	.long 0xd71c003e                                           // 00000019112C: D71C003E
	v_cndmask_b32_e32 v1, v62, v76, vcc_lo                     // 000000191130: 0202993E
	v_exp_f32_e32 v76, v80                                     // 000000191134: 7E984B50
	v_fma_f32 v58, -v58, v84, v81                              // 000000191138: D613003A 2546A93A
	v_mul_f32_e32 v75, v73, v57                                // 000000191140: 10967349
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000191144: BF8701A3
	v_cndmask_b32_e64 v62, 0, v62, s1                          // 000000191148: D501003E 00067C80
	.long 0xd41b0001                                           // 000000191150: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v61, vcc_lo              // 000000191154: 02027AFF C2B17218
	v_fma_f32 v77, -v71, v75, v73                              // 00000019115C: D613004D 25269747
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000191164: BF870292
	v_cndmask_b32_e64 v61, 0x7f800000, v62, s1                 // 000000191168: D501003D 00067CFF 7F800000
	.long 0xd71c003e                                           // 000000191174: D71C003E
	v_cndmask_b32_e32 v1, v76, v72, vcc_lo                     // 000000191178: 0202914C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019117C: BF870093
	v_fmac_f32_e32 v75, v77, v57                               // 000000191180: 5696734D
	v_fma_f32 v71, -v71, v75, v73                              // 000000191184: D6130047 25269747
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019118C: BF870121
	v_div_fmas_f32 v57, v71, v57, v75                          // 000000191190: D6370039 052E7347
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v79                  // 000000191198: 7C3C9EFF 42CE8ED0
	v_div_fixup_f32 v41, v57, v59, v41                         // 0000001911A0: D6270029 04A67739
	v_cndmask_b32_e32 v62, 0, v62, vcc_lo                      // 0000001911A8: 027C7C80
	s_mov_b32 vcc_lo, s0                                       // 0000001911AC: BEEA0000
	.long 0x7f763980                                           // 0000001911B0: 7F763980
	v_div_fmas_f32 v58, v58, v74, v84                          // 0000001911B4: D637003A 0552953A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v79                  // 0000001911BC: 7C369EFF C2B17218
	v_add_f32_e32 v61, 1.0, v61                                // 0000001911C4: 067A7AF2
	.long 0x7e7639a9                                           // 0000001911C8: 7E7639A9
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001911CC: BF870224
	v_div_fixup_f32 v42, v58, v60, v42                         // 0000001911D0: D627002A 04AA793A
	v_cndmask_b32_e32 v62, 0x7f800000, v62, vcc_lo             // 0000001911D8: 027C7CFF 7F800000
	v_div_scale_f32 v71, null, v61, v61, v43                   // 0000001911E0: D6FC7C47 04AE7B3D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001911E8: BF870113
	.long 0x7e0039aa                                           // 0000001911EC: 7E0039AA
	v_rcp_f32_e32 v53, v71                                     // 0000001911F0: 7E6A5547
	s_waitcnt vmcnt(17)                                        // 0000001911F4: BF8947F7
	v_lshlrev_b32_e32 v60, 16, v140                            // 0000001911F8: 30791890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001911FC: BF870092
	v_dual_add_f32 v58, 1.0, v62 :: v_dual_and_b32 v75, 1, v0  // 000000191200: C9247CF2 3A4A0081
	v_add3_u32 v42, v42, v75, 0x7fff                           // 000000191208: D655002A 03FE972A 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000191214: BF870095
	v_fma_f32 v62, -v71, v53, 1.0                              // 000000191218: D613003E 23CA6B47
	v_fmac_f32_e32 v53, v62, v53                               // 000000191220: 566A6B3E
	v_mul_f32_e32 v57, 0xbfb8aa3b, v60                         // 000000191224: 107278FF BFB8AA3B
	v_div_scale_f32 v54, null, v58, v58, v44                   // 00000019122C: D6FC7C36 04B2753A
	v_div_scale_f32 v62, vcc_lo, v43, v61, v43                 // 000000191234: D6FC6A3E 04AE7B2B
	.long 0xd41e0001                                           // 00000019123C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v60, vcc_lo              // 000000191240: 020278FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000191248: BF870214
	v_fma_f32 v73, 0xbfb8aa3b, v60, -v57                       // 00000019124C: D6130049 84E678FF BFB8AA3B
	v_rcp_f32_e32 v72, v54                                     // 000000191258: 7E905536
	v_rndne_f32_e32 v74, v57                                   // 00000019125C: 7E944739
	s_waitcnt vmcnt(11)                                        // 000000191260: BF892FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000191264: BF870092
	v_dual_fmac_f32 v73, 0xb2a5705f, v60 :: v_dual_lshlrev_b32 v76, 16, v139// 000000191268: C82278FF 494D1690 B2A5705F
	v_mul_f32_e32 v77, 0xbfb8aa3b, v76                         // 000000191274: 109A98FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019127C: BF8701A5
	v_fma_f32 v79, -v54, v72, 1.0                              // 000000191280: D613004F 23CA9136
	v_sub_f32_e32 v57, v57, v74                                // 000000191288: 08729539
	v_fma_f32 v80, 0xbfb8aa3b, v76, -v77                       // 00000019128C: D6130050 853698FF BFB8AA3B
	v_and_b32_e32 v59, 1, v59                                  // 000000191298: 36767681
	v_rndne_f32_e32 v81, v77                                   // 00000019129C: 7EA2474D
	v_fmac_f32_e32 v72, v79, v72                               // 0000001912A0: 5690914F
	v_div_scale_f32 v79, s0, v44, v58, v44                     // 0000001912A4: D6FC004F 04B2752C
	v_dual_add_f32 v57, v57, v73 :: v_dual_fmac_f32 v80, 0xb2a5705f, v76// 0000001912AC: C9009339 395098FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001912B8: BF870224
	v_sub_f32_e32 v77, v77, v81                                // 0000001912BC: 089AA34D
	v_add3_u32 v41, v41, v59, 0x7fff                           // 0000001912C0: D6550029 03FE7729 00007FFF
	v_mul_f32_e32 v82, v79, v72                                // 0000001912CC: 10A4914F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001912D0: BF870004
	v_exp_f32_e32 v57, v57                                     // 0000001912D4: 7E724B39
	v_cvt_i32_f32_e32 v74, v74                                 // 0000001912D8: 7E94114A
	v_add_f32_e32 v77, v77, v80                                // 0000001912DC: 069AA14D
	global_store_d16_hi_b16 v[7:8], v41, off offset:64         // 0000001912E0: DC960040 007C2907
	v_fma_f32 v59, -v54, v82, v79                              // 0000001912E8: D613003B 253EA536
	v_mul_f32_e32 v73, v62, v53                                // 0000001912F0: 10926B3E
	global_store_d16_hi_b16 v[47:48], v42, off offset:64       // 0000001912F4: DC960040 007C2A2F
	v_fmac_f32_e32 v82, v59, v72                               // 0000001912FC: 56A4913B
	v_fma_f32 v75, -v71, v73, v62                              // 000000191300: D613004B 24FA9347
	.long 0xd71c0039                                           // 000000191308: D71C0039
	v_cndmask_b32_e32 v1, v57, v74, vcc_lo                     // 00000019130C: 02029539
	v_exp_f32_e32 v74, v77                                     // 000000191310: 7E944B4D
	v_cvt_i32_f32_e32 v59, v81                                 // 000000191314: 7E761151
	v_fma_f32 v54, -v54, v82, v79                              // 000000191318: D6130036 253EA536
	v_fmac_f32_e32 v73, v75, v53                               // 000000191320: 56926B4B
	v_cndmask_b32_e64 v57, 0, v57, s1                          // 000000191324: D5010039 00067280
	.long 0xd41b0001                                           // 00000019132C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v60, vcc_lo              // 000000191330: 020278FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000191338: BF870293
	v_fma_f32 v62, -v71, v73, v62                              // 00000019133C: D613003E 24FA9347
	.long 0xd71c003b                                           // 000000191344: D71C003B
	v_cndmask_b32_e32 v1, v74, v59, vcc_lo                     // 000000191348: 0202774A
	s_waitcnt vmcnt(5)                                         // 00000019134C: BF8917F7
	v_lshlrev_b32_e32 v74, 16, v141                            // 000000191350: 30951A90
	v_cndmask_b32_e64 v57, 0x7f800000, v57, s1                 // 000000191354: D5010039 000672FF 7F800000
	v_div_fmas_f32 v53, v62, v53, v73                          // 000000191360: D6370035 05266B3E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v76                  // 000000191368: 7C3C98FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000191370: BF870194
	v_mul_f32_e32 v75, 0xbfb8aa3b, v74                         // 000000191374: 109694FF BFB8AA3B
	v_div_fixup_f32 v43, v53, v61, v43                         // 00000019137C: D627002B 04AE7B35
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 000000191384: 02767680
	s_mov_b32 vcc_lo, s0                                       // 000000191388: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000019138C: BF8701B3
	v_fma_f32 v77, 0xbfb8aa3b, v74, -v75                       // 000000191390: D613004D 852E94FF BFB8AA3B
	v_div_fmas_f32 v54, v54, v72, v82                          // 00000019139C: D6370036 054A9136
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v76                  // 0000001913A4: 7C3698FF C2B17218
	v_fmac_f32_e32 v77, 0xb2a5705f, v74                        // 0000001913AC: 569A94FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001913B4: BF870003
	v_div_fixup_f32 v41, v54, v58, v44                         // 0000001913B8: D6270029 04B27536
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 0000001913C0: 027676FF 7F800000
	v_mul_f32_e32 v44, v46, v51                                // 0000001913C8: 1058672E
	v_lshlrev_b32_e32 v58, 16, v78                             // 0000001913CC: 30749C90
	v_rndne_f32_e32 v78, v75                                   // 0000001913D0: 7E9C474B
	.long 0x7e0039a9                                           // 0000001913D4: 7E0039A9
	v_add_f32_e32 v54, 1.0, v59                                // 0000001913D8: 066C76F2
	.long 0x7e7639ab                                           // 0000001913DC: 7E7639AB
	v_mul_f32_e32 v53, 0xbfb8aa3b, v58                         // 0000001913E0: 106A74FF BFB8AA3B
	.long 0x7f763980                                           // 0000001913E8: 7F763980
	v_sub_f32_e32 v75, v75, v78                                // 0000001913EC: 08969D4B
	v_div_scale_f32 v42, null, v54, v54, v44                   // 0000001913F0: D6FC7C2A 04B26D36
	.long 0xd41e0001                                           // 0000001913F8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v58, vcc_lo              // 0000001913FC: 020274FF 42CE8ED0
	v_fma_f32 v71, 0xbfb8aa3b, v58, -v53                       // 000000191404: D6130047 84D674FF BFB8AA3B
	v_rndne_f32_e32 v72, v53                                   // 000000191410: 7E904735
	v_and_b32_e32 v59, 1, v59                                  // 000000191414: 36767681
	v_rcp_f32_e32 v62, v42                                     // 000000191418: 7E7C552A
	v_add_f32_e32 v75, v75, v77                                // 00000019141C: 06969B4B
	v_fmac_f32_e32 v71, 0xb2a5705f, v58                        // 000000191420: 568E74FF B2A5705F
	v_sub_f32_e32 v53, v53, v72                                // 000000191428: 086A9135
	v_cvt_i32_f32_e32 v72, v72                                 // 00000019142C: 7E901148
	v_add3_u32 v43, v43, v59, 0x7fff                           // 000000191430: D655002B 03FE772B 00007FFF
	v_and_b32_e32 v73, 1, v0                                   // 00000019143C: 36920081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000191440: BF870294
	v_add_f32_e32 v53, v53, v71                                // 000000191444: 066A8F35
	v_fma_f32 v76, -v42, v62, 1.0                              // 000000191448: D613004C 23CA7D2A
	v_mul_f32_e32 v45, v45, v52                                // 000000191450: 105A692D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000191454: BF870214
	v_add3_u32 v41, v41, v73, 0x7fff                           // 000000191458: D6550029 03FE9329 00007FFF
	v_exp_f32_e32 v53, v53                                     // 000000191464: 7E6A4B35
	global_store_d16_hi_b16 v[15:16], v43, off offset:64       // 000000191468: DC960040 007C2B0F
	v_fmac_f32_e32 v62, v76, v62                               // 000000191470: 567C7D4C
	v_div_scale_f32 v76, s0, v44, v54, v44                     // 000000191474: D6FC004C 04B26D2C
	global_store_d16_hi_b16 v[23:24], v41, off offset:64       // 00000019147C: DC960040 007C2917
	v_mul_f32_e32 v79, v76, v62                                // 000000191484: 109E7D4C
	.long 0xd71c0035                                           // 000000191488: D71C0035
	v_cndmask_b32_e32 v1, v53, v72, vcc_lo                     // 00000019148C: 02029135
	v_exp_f32_e32 v72, v75                                     // 000000191490: 7E904B4B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000191494: BF870112
	v_fma_f32 v59, -v42, v79, v76                              // 000000191498: D613003B 25329F2A
	v_cndmask_b32_e64 v53, 0, v53, s1                          // 0000001914A0: D5010035 00066A80
	.long 0xd41b0001                                           // 0000001914A8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v58, vcc_lo              // 0000001914AC: 020274FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001914B4: BF8701A3
	v_fmac_f32_e32 v79, v59, v62                               // 0000001914B8: 569E7D3B
	v_cvt_i32_f32_e32 v59, v78                                 // 0000001914BC: 7E76114E
	v_cndmask_b32_e64 v53, 0x7f800000, v53, s1                 // 0000001914C0: D5010035 00066AFF 7F800000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001914CC: BF870003
	v_fma_f32 v42, -v42, v79, v76                              // 0000001914D0: D613002A 25329F2A
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001914D8: BF870185
	.long 0xd71c003a                                           // 0000001914DC: D71C003A
	v_cndmask_b32_e32 v1, v72, v59, vcc_lo                     // 0000001914E0: 02027748
	v_dual_add_f32 v57, 1.0, v57 :: v_dual_lshlrev_b32 v72, 16, v132// 0000001914E4: C92272F2 39490890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001914EC: BF870091
	v_div_scale_f32 v60, null, v57, v57, v45                   // 0000001914F0: D6FC7C3C 04B67339
	v_rcp_f32_e32 v46, v60                                     // 0000001914F8: 7E5C553C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001914FC: BF870095
	v_fma_f32 v61, -v60, v46, 1.0                              // 000000191500: D613003D 23CA5D3C
	v_fmac_f32_e32 v46, v61, v46                               // 000000191508: 565C5D3D
	v_div_scale_f32 v61, vcc_lo, v45, v57, v45                 // 00000019150C: D6FC6A3D 04B6732D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000191514: BF870091
	v_mul_f32_e32 v71, v61, v46                                // 000000191518: 108E5D3D
	v_fma_f32 v73, -v60, v71, v61                              // 00000019151C: D6130049 24F68F3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000191524: BF870121
	v_fmac_f32_e32 v71, v73, v46                               // 000000191528: 568E5D49
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000019152C: 109290FF BFB8AA3B
	v_fma_f32 v60, -v60, v71, v61                              // 000000191534: D613003C 24F68F3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019153C: BF8701A2
	v_fma_f32 v75, 0xbfb8aa3b, v72, -v73                       // 000000191540: D613004B 852690FF BFB8AA3B
	v_rndne_f32_e32 v76, v73                                   // 00000019154C: 7E984749
	v_div_fmas_f32 v46, v60, v46, v71                          // 000000191550: D637002E 051E5D3C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v74                  // 000000191558: 7C3C94FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000191560: BF870214
	v_fmac_f32_e32 v75, 0xb2a5705f, v72                        // 000000191564: 569690FF B2A5705F
	v_dual_sub_f32 v73, v73, v76 :: v_dual_cndmask_b32 v58, 0, v58// 00000019156C: C9529949 493A7480
	s_mov_b32 vcc_lo, s0                                       // 000000191574: BEEA0000
	v_div_fixup_f32 v45, v46, v57, v45                         // 000000191578: D627002D 04B6732E
	v_div_fmas_f32 v42, v42, v62, v79                          // 000000191580: D637002A 053E7D2A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v74                  // 000000191588: 7C3694FF C2B17218
	.long 0x7f723980                                           // 000000191590: 7F723980
	v_add_f32_e32 v73, v73, v75                                // 000000191594: 06929749
	.long 0x7e7239ad                                           // 000000191598: 7E7239AD
	v_div_fixup_f32 v42, v42, v54, v44                         // 00000019159C: D627002A 04B26D2A
	v_cndmask_b32_e32 v58, 0x7f800000, v58, vcc_lo             // 0000001915A4: 027474FF 7F800000
	v_lshlrev_b32_e32 v54, 16, v133                            // 0000001915AC: 306D0A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001915B0: BF870214
	v_and_b32_e32 v57, 1, v57                                  // 0000001915B4: 36727281
	.long 0x7e0039aa                                           // 0000001915B8: 7E0039AA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001915BC: BF870214
	v_add_f32_e32 v44, 1.0, v58                                // 0000001915C0: 065874F2
	v_mul_f32_e32 v46, 0xbfb8aa3b, v54                         // 0000001915C4: 105C6CFF BFB8AA3B
	.long 0xd41e0001                                           // 0000001915CC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v54, vcc_lo              // 0000001915D0: 02026CFF 42CE8ED0
	v_add3_u32 v45, v45, v57, 0x7fff                           // 0000001915D8: D655002D 03FE732D 00007FFF
	v_and_b32_e32 v71, 1, v0                                   // 0000001915E4: 368E0081
	v_div_scale_f32 v41, null, v44, v44, v34                   // 0000001915E8: D6FC7C29 048A592C
	v_fma_f32 v61, 0xbfb8aa3b, v54, -v46                       // 0000001915F0: D613003D 84BA6CFF BFB8AA3B
	v_rndne_f32_e32 v62, v46                                   // 0000001915FC: 7E7C472E
	global_store_d16_hi_b16 v[31:32], v45, off offset:64       // 000000191600: DC960040 007C2D1F
	v_add3_u32 v42, v42, v71, 0x7fff                           // 000000191608: D655002A 03FE8F2A 00007FFF
	v_rcp_f32_e32 v60, v41                                     // 000000191614: 7E785529
	v_fmac_f32_e32 v61, 0xb2a5705f, v54                        // 000000191618: 567A6CFF B2A5705F
	v_sub_f32_e32 v46, v46, v62                                // 000000191620: 085C7D2E
	v_cvt_i32_f32_e32 v62, v62                                 // 000000191624: 7E7C113E
	v_lshlrev_b32_e32 v45, 16, v135                            // 000000191628: 305B0E90
	global_store_d16_hi_b16 v[39:40], v42, off offset:64       // 00000019162C: DC960040 007C2A27
	v_add_f32_e32 v46, v46, v61                                // 000000191634: 065C7B2E
	v_fma_f32 v74, -v41, v60, 1.0                              // 000000191638: D613004A 23CA7929
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000191640: BF870092
	v_exp_f32_e32 v46, v46                                     // 000000191644: 7E5C4B2E
	v_fmac_f32_e32 v60, v74, v60                               // 000000191648: 5678794A
	v_div_scale_f32 v74, s0, v34, v44, v34                     // 00000019164C: D6FC004A 048A5922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000191654: BF870291
	v_mul_f32_e32 v77, v74, v60                                // 000000191658: 109A794A
	.long 0xd71c002e                                           // 00000019165C: D71C002E
	v_cndmask_b32_e32 v1, v46, v62, vcc_lo                     // 000000191660: 02027D2E
	v_exp_f32_e32 v62, v73                                     // 000000191664: 7E7C4B49
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000191668: BF870112
	v_fma_f32 v57, -v41, v77, v74                              // 00000019166C: D6130039 252A9B29
	v_cndmask_b32_e64 v46, 0, v46, s1                          // 000000191674: D501002E 00065C80
	.long 0xd41b0001                                           // 00000019167C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v54, vcc_lo              // 000000191680: 02026CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000191688: BF8701A3
	v_fmac_f32_e32 v77, v57, v60                               // 00000019168C: 569A7939
	v_cvt_i32_f32_e32 v57, v76                                 // 000000191690: 7E72114C
	v_cndmask_b32_e64 v46, 0x7f800000, v46, s1                 // 000000191694: D501002E 00065CFF 7F800000
	.long 0xd41e0001                                           // 0000001916A0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v45, vcc_lo              // 0000001916A4: 02025AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001916AC: BF870004
	v_fma_f32 v41, -v41, v77, v74                              // 0000001916B0: D6130029 252A9B29
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 0000001916B8: BF870205
	.long 0xd71c0036                                           // 0000001916BC: D71C0036
	v_cndmask_b32_e32 v1, v62, v57, vcc_lo                     // 0000001916C0: 0202733E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001916C4: BF870124
	v_dual_add_f32 v53, 1.0, v53 :: v_dual_add_f32 v46, 1.0, v46// 0000001916C8: C9086AF2 352E5CF2
	v_lshlrev_b32_e32 v62, 16, v134                            // 0000001916D0: 307D0C90
	v_div_scale_f32 v59, null, v53, v53, v33                   // 0000001916D4: D6FC7C3B 04866B35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001916DC: BF870113
	v_div_scale_f32 v57, null, v46, v46, v35                   // 0000001916E0: D6FC7C39 048E5D2E
	v_rcp_f32_e32 v43, v59                                     // 0000001916E8: 7E56553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001916EC: BF870095
	v_fma_f32 v58, -v59, v43, 1.0                              // 0000001916F0: D613003A 23CA573B
	v_fmac_f32_e32 v43, v58, v43                               // 0000001916F8: 5656573A
	v_div_scale_f32 v58, vcc_lo, v33, v53, v33                 // 0000001916FC: D6FC6A3A 04866B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000191704: BF870091
	v_mul_f32_e32 v61, v58, v43                                // 000000191708: 107A573A
	v_fma_f32 v71, -v59, v61, v58                              // 00000019170C: D6130047 24EA7B3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000191714: BF870121
	v_fmac_f32_e32 v61, v71, v43                               // 000000191718: 567A5747
	v_mul_f32_e32 v71, 0xbfb8aa3b, v62                         // 00000019171C: 108E7CFF BFB8AA3B
	v_fma_f32 v58, -v59, v61, v58                              // 000000191724: D613003A 24EA7B3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019172C: BF8701A2
	v_fma_f32 v73, 0xbfb8aa3b, v62, -v71                       // 000000191730: D6130049 851E7CFF BFB8AA3B
	v_rndne_f32_e32 v74, v71                                   // 00000019173C: 7E944747
	v_div_fmas_f32 v43, v58, v43, v61                          // 000000191740: D637002B 04F6573A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 000000191748: 7C3C90FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000191750: BF870214
	v_fmac_f32_e32 v73, 0xb2a5705f, v62                        // 000000191754: 56927CFF B2A5705F
	v_sub_f32_e32 v71, v71, v74                                // 00000019175C: 088E9547
	v_cndmask_b32_e32 v54, 0, v54, vcc_lo                      // 000000191760: 026C6C80
	s_mov_b32 vcc_lo, s0                                       // 000000191764: BEEA0000
	v_div_fixup_f32 v33, v43, v53, v33                         // 000000191768: D6270021 04866B2B
	v_div_fmas_f32 v41, v41, v60, v77                          // 000000191770: D6370029 05367929
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 000000191778: 7C3690FF C2B17218
	v_mul_f32_e32 v43, 0xbfb8aa3b, v45                         // 000000191780: 10565AFF BFB8AA3B
	.long 0x7f6a3980                                           // 000000191788: 7F6A3980
	.long 0x7e6a39a1                                           // 00000019178C: 7E6A39A1
	v_div_fixup_f32 v34, v41, v44, v34                         // 000000191790: D6270022 048A5929
	v_cndmask_b32_e32 v54, 0x7f800000, v54, vcc_lo             // 000000191798: 026C6CFF 7F800000
	v_rcp_f32_e32 v41, v57                                     // 0000001917A0: 7E525539
	v_fma_f32 v59, 0xbfb8aa3b, v45, -v43                       // 0000001917A4: D613003B 84AE5AFF BFB8AA3B
	v_rndne_f32_e32 v60, v43                                   // 0000001917B0: 7E78472B
	.long 0x7e0039a2                                           // 0000001917B4: 7E0039A2
	v_dual_add_f32 v44, 1.0, v54 :: v_dual_and_b32 v53, 1, v53 // 0000001917B8: C9246CF2 2C346A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001917C0: BF870214
	v_fmac_f32_e32 v59, 0xb2a5705f, v45                        // 0000001917C4: 56765AFF B2A5705F
	v_sub_f32_e32 v43, v43, v60                                // 0000001917CC: 0856792B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001917D0: BF870214
	v_and_b32_e32 v61, 1, v0                                   // 0000001917D4: 367A0081
	v_div_scale_f32 v42, null, v44, v44, v36                   // 0000001917D8: D6FC7C2A 0492592C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001917E0: BF870005
	v_fma_f32 v54, -v57, v41, 1.0                              // 0000001917E4: D6130036 23CA5339
	v_cvt_i32_f32_e32 v60, v60                                 // 0000001917EC: 7E78113C
	v_add_f32_e32 v43, v43, v59                                // 0000001917F0: 0656772B
	v_add3_u32 v34, v34, v61, 0x7fff                           // 0000001917F4: D6550022 03FE7B22 00007FFF
	v_rcp_f32_e32 v58, v42                                     // 000000191800: 7E74552A
	v_fmac_f32_e32 v41, v54, v41                               // 000000191804: 56525336
	v_div_scale_f32 v54, vcc_lo, v35, v46, v35                 // 000000191808: D6FC6A36 048E5D23
	v_exp_f32_e32 v43, v43                                     // 000000191810: 7E564B2B
	v_add_f32_e32 v71, v71, v73                                // 000000191814: 068E9347
	v_add3_u32 v33, v33, v53, 0x7fff                           // 000000191818: D6550021 03FE6B21 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000191824: BF870313
	v_mul_f32_e32 v59, v54, v41                                // 000000191828: 10765336
	v_fma_f32 v72, -v42, v58, 1.0                              // 00000019182C: D6130048 23CA752A
	global_store_d16_hi_b16 v[7:8], v33, off offset:96         // 000000191834: DC960060 007C2107
	v_fma_f32 v61, -v57, v59, v54                              // 00000019183C: D613003D 24DA7739
	.long 0xd71c002b                                           // 000000191844: D71C002B
	v_cndmask_b32_e32 v1, v43, v60, vcc_lo                     // 000000191848: 0202792B
	v_exp_f32_e32 v60, v71                                     // 00000019184C: 7E784B47
	v_fmac_f32_e32 v58, v72, v58                               // 000000191850: 56747548
	v_div_scale_f32 v72, s0, v36, v44, v36                     // 000000191854: D6FC0048 04925924
	v_fmac_f32_e32 v59, v61, v41                               // 00000019185C: 5676533D
	v_cndmask_b32_e64 v43, 0, v43, s1                          // 000000191860: D501002B 00065680
	.long 0xd41b0001                                           // 000000191868: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v45, vcc_lo              // 00000019186C: 02025AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v34, off offset:96       // 000000191874: DC960060 007C222F
	v_mul_f32_e32 v75, v72, v58                                // 00000019187C: 10967548
	v_fma_f32 v54, -v57, v59, v54                              // 000000191880: D6130036 24DA7739
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 000000191888: D501002B 000656FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000191894: BF870193
	v_fma_f32 v53, -v42, v75, v72                              // 000000191898: D6130035 2522972A
	v_div_fmas_f32 v41, v54, v41, v59                          // 0000001918A0: D6370029 04EE5336
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v62                  // 0000001918A8: 7C3C7CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001918B0: BF870214
	v_add_f32_e32 v43, 1.0, v43                                // 0000001918B4: 065656F2
	v_fmac_f32_e32 v75, v53, v58                               // 0000001918B8: 56967535
	v_cvt_i32_f32_e32 v53, v74                                 // 0000001918BC: 7E6A114A
	v_div_fixup_f32 v35, v41, v46, v35                         // 0000001918C0: D6270023 048E5D29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001918C8: BF870193
	v_fma_f32 v42, -v42, v75, v72                              // 0000001918CC: D613002A 2522972A
	.long 0xd71c002d                                           // 0000001918D4: D71C002D
	v_cndmask_b32_e32 v1, v60, v53, vcc_lo                     // 0000001918D8: 02026B3C
	v_div_scale_f32 v53, null, v43, v43, v37                   // 0000001918DC: D6FC7C35 0496572B
	s_waitcnt vmcnt(4)                                         // 0000001918E4: BF8913F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001918E8: BF8700A2
	v_dual_cndmask_b32 v45, 0, v45 :: v_dual_lshlrev_b32 v60, 16, v136// 0000001918EC: CA625A80 2D3D1090
	s_mov_b32 vcc_lo, s0                                       // 0000001918F4: BEEA0000
	v_mul_f32_e32 v61, 0xbfb8aa3b, v60                         // 0000001918F8: 107A78FF BFB8AA3B
	v_div_fmas_f32 v42, v42, v58, v75                          // 000000191900: D637002A 052E752A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v62                  // 000000191908: 7C367CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000191910: BF870193
	v_fma_f32 v71, 0xbfb8aa3b, v60, -v61                       // 000000191914: D6130047 84F678FF BFB8AA3B
	v_div_fixup_f32 v33, v42, v44, v36                         // 000000191920: D6270021 0492592A
	v_dual_cndmask_b32 v45, 0x7f800000, v45 :: v_dual_mul_f32 v36, v38, v51// 000000191928: CA465AFF 2D246726 7F800000
	v_lshlrev_b32_e32 v44, 16, v86                             // 000000191934: 3058AC90
	v_rcp_f32_e32 v38, v53                                     // 000000191938: 7E4C5535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019193C: BF870193
	.long 0x7e0039a1                                           // 000000191940: 7E0039A1
	v_add_f32_e32 v42, 1.0, v45                                // 000000191944: 06545AF2
	v_rndne_f32_e32 v72, v61                                   // 000000191948: 7E90473D
	v_mul_f32_e32 v41, 0xbfb8aa3b, v44                         // 00000019194C: 105258FF BFB8AA3B
	.long 0x7e5a39a3                                           // 000000191954: 7E5A39A3
	.long 0x7f5a3980                                           // 000000191958: 7F5A3980
	v_div_scale_f32 v34, null, v42, v42, v36                   // 00000019195C: D6FC7C22 0492552A
	v_and_b32_e32 v59, 1, v0                                   // 000000191964: 36760081
	v_fma_f32 v57, 0xbfb8aa3b, v44, -v41                       // 000000191968: D6130039 84A658FF BFB8AA3B
	v_rndne_f32_e32 v58, v41                                   // 000000191974: 7E744729
	v_fma_f32 v46, -v53, v38, 1.0                              // 000000191978: D613002E 23CA4D35
	v_rcp_f32_e32 v54, v34                                     // 000000191980: 7E6C5522
	v_fmac_f32_e32 v71, 0xb2a5705f, v60                        // 000000191984: 568E78FF B2A5705F
	v_fmac_f32_e32 v57, 0xb2a5705f, v44                        // 00000019198C: 567258FF B2A5705F
	v_sub_f32_e32 v41, v41, v58                                // 000000191994: 08527529
	v_fmac_f32_e32 v38, v46, v38                               // 000000191998: 564C4D2E
	v_div_scale_f32 v46, vcc_lo, v37, v43, v37                 // 00000019199C: D6FC6A2E 04965725
	v_sub_f32_e32 v61, v61, v72                                // 0000001919A4: 087A913D
	v_and_b32_e32 v45, 1, v45                                  // 0000001919A8: 365A5A81
	v_add_f32_e32 v41, v41, v57                                // 0000001919AC: 06527329
	v_add3_u32 v33, v33, v59, 0x7fff                           // 0000001919B0: D6550021 03FE7721 00007FFF
	v_fma_f32 v62, -v34, v54, 1.0                              // 0000001919BC: D613003E 23CA6D22
	v_mul_f32_e32 v57, v46, v38                                // 0000001919C4: 10724D2E
	v_cvt_i32_f32_e32 v58, v58                                 // 0000001919C8: 7E74113A
	v_exp_f32_e32 v41, v41                                     // 0000001919CC: 7E524B29
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001919D0: BF870253
	v_dual_add_f32 v61, v61, v71 :: v_dual_fmac_f32 v54, v62, v54// 0000001919D4: C9008F3D 3D366D3E
	v_div_scale_f32 v62, s0, v36, v42, v36                     // 0000001919DC: D6FC003E 04925524
	v_fma_f32 v59, -v53, v57, v46                              // 0000001919E4: D613003B 24BA7335
	v_add3_u32 v35, v35, v45, 0x7fff                           // 0000001919EC: D6550023 03FE5B23 00007FFF
	.long 0xd41e0001                                           // 0000001919F8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v44, vcc_lo              // 0000001919FC: 020258FF 42CE8ED0
	v_mul_f32_e32 v73, v62, v54                                // 000000191A04: 10926D3E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000191A08: BF870294
	v_fmac_f32_e32 v57, v59, v38                               // 000000191A0C: 56724D3B
	.long 0xd71c0029                                           // 000000191A10: D71C0029
	v_cndmask_b32_e32 v1, v41, v58, vcc_lo                     // 000000191A14: 02027529
	v_exp_f32_e32 v58, v61                                     // 000000191A18: 7E744B3D
	global_store_d16_hi_b16 v[15:16], v35, off offset:96       // 000000191A1C: DC960060 007C230F
	v_fma_f32 v45, -v34, v73, v62                              // 000000191A24: D613002D 24FA9322
	v_fma_f32 v46, -v53, v57, v46                              // 000000191A2C: D613002E 24BA7335
	v_cndmask_b32_e64 v41, 0, v41, s1                          // 000000191A34: D5010029 00065280
	.long 0xd41b0001                                           // 000000191A3C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v44, vcc_lo              // 000000191A40: 020258FF C2B17218
	global_store_d16_hi_b16 v[23:24], v33, off offset:96       // 000000191A48: DC960060 007C2117
	v_fmac_f32_e32 v73, v45, v54                               // 000000191A50: 56926D2D
	v_cvt_i32_f32_e32 v45, v72                                 // 000000191A54: 7E5A1148
	v_div_fmas_f32 v38, v46, v38, v57                          // 000000191A58: D6370026 04E64D2E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v60                  // 000000191A60: 7C3C78FF 42CE8ED0
	v_cndmask_b32_e64 v41, 0x7f800000, v41, s1                 // 000000191A68: D5010029 000652FF 7F800000
	v_fma_f32 v34, -v34, v73, v62                              // 000000191A74: D6130022 24FA9322
	.long 0xd71c002c                                           // 000000191A7C: D71C002C
	v_cndmask_b32_e32 v1, v58, v45, vcc_lo                     // 000000191A80: 02025B3A
	v_div_fixup_f32 v37, v38, v43, v37                         // 000000191A84: D6270025 04965726
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000191A8C: BF870224
	v_dual_add_f32 v41, 1.0, v41 :: v_dual_lshlrev_b32 v58, 16, v127// 000000191A90: C92252F2 293AFE90
	.long 0x7f563980                                           // 000000191A98: 7F563980
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 000000191A9C: 02585880
	s_mov_b32 vcc_lo, s0                                       // 000000191AA0: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000191AA4: BF870003
	v_mul_f32_e32 v59, 0xbfb8aa3b, v58                         // 000000191AA8: 107674FF BFB8AA3B
	v_div_fmas_f32 v34, v34, v54, v73                          // 000000191AB0: D6370022 05266D22
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v60                  // 000000191AB8: 7C3678FF C2B17218
	v_div_scale_f32 v45, null, v41, v41, v25                   // 000000191AC0: D6FC7C2D 04665329
	.long 0x7e5639a5                                           // 000000191AC8: 7E5639A5
	v_fma_f32 v61, 0xbfb8aa3b, v58, -v59                       // 000000191ACC: D613003D 84EE74FF BFB8AA3B
	v_div_fixup_f32 v34, v34, v42, v36                         // 000000191AD8: D6270022 04925522
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo             // 000000191AE0: 025858FF 7F800000
	v_lshlrev_b32_e32 v42, 16, v128                            // 000000191AE8: 30550090
	v_rcp_f32_e32 v35, v45                                     // 000000191AEC: 7E46552D
	v_rndne_f32_e32 v62, v59                                   // 000000191AF0: 7E7C473B
	.long 0x7e0039a2                                           // 000000191AF4: 7E0039A2
	v_add_f32_e32 v36, 1.0, v44                                // 000000191AF8: 064858F2
	v_mul_f32_e32 v38, 0xbfb8aa3b, v42                         // 000000191AFC: 104C54FF BFB8AA3B
	v_fmac_f32_e32 v61, 0xb2a5705f, v58                        // 000000191B04: 567A74FF B2A5705F
	v_sub_f32_e32 v59, v59, v62                                // 000000191B0C: 08767D3B
	v_and_b32_e32 v57, 1, v0                                   // 000000191B10: 36720081
	v_div_scale_f32 v33, null, v36, v36, v26                   // 000000191B14: D6FC7C21 046A4924
	v_fma_f32 v53, 0xbfb8aa3b, v42, -v38                       // 000000191B1C: D6130035 849A54FF BFB8AA3B
	v_rndne_f32_e32 v54, v38                                   // 000000191B28: 7E6C4726
	v_fma_f32 v44, -v45, v35, 1.0                              // 000000191B2C: D613002C 23CA472D
	v_and_b32_e32 v43, 1, v43                                  // 000000191B34: 36565681
	v_rcp_f32_e32 v46, v33                                     // 000000191B38: 7E5C5521
	v_fmac_f32_e32 v53, 0xb2a5705f, v42                        // 000000191B3C: 566A54FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000191B44: BF870243
	v_dual_sub_f32 v38, v38, v54 :: v_dual_fmac_f32 v35, v44, v35// 000000191B48: C9406D26 2622472C
	v_div_scale_f32 v44, vcc_lo, v25, v41, v25                 // 000000191B50: D6FC6A2C 04665319
	v_add3_u32 v34, v34, v57, 0x7fff                           // 000000191B58: D6550022 03FE7322 00007FFF
	v_cvt_i32_f32_e32 v54, v54                                 // 000000191B64: 7E6C1136
	v_add_f32_e32 v38, v38, v53                                // 000000191B68: 064C6B26
	v_add_f32_e32 v59, v59, v61                                // 000000191B6C: 06767B3B
	v_mul_f32_e32 v53, v44, v35                                // 000000191B70: 106A472C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000191B74: BF870005
	v_fma_f32 v60, -v33, v46, 1.0                              // 000000191B78: D613003C 23CA5D21
	v_add3_u32 v37, v37, v43, 0x7fff                           // 000000191B80: D6550025 03FE5725 00007FFF
	v_exp_f32_e32 v38, v38                                     // 000000191B8C: 7E4C4B26
	.long 0xd41e0001                                           // 000000191B90: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v42, vcc_lo              // 000000191B94: 020254FF 42CE8ED0
	v_fma_f32 v57, -v45, v53, v44                              // 000000191B9C: D6130039 24B26B2D
	v_fmac_f32_e32 v46, v60, v46                               // 000000191BA4: 565C5D3C
	v_div_scale_f32 v60, s0, v26, v36, v26                     // 000000191BA8: D6FC003C 046A491A
	global_store_d16_hi_b16 v[31:32], v37, off offset:96       // 000000191BB0: DC960060 007C251F
	v_lshlrev_b32_e32 v37, 16, v130                            // 000000191BB8: 304B0490
	v_fmac_f32_e32 v53, v57, v35                               // 000000191BBC: 566A4739
	global_store_d16_hi_b16 v[39:40], v34, off offset:96       // 000000191BC0: DC960060 007C2227
	v_mul_f32_e32 v71, v60, v46                                // 000000191BC8: 108E5D3C
	.long 0xd71c0026                                           // 000000191BCC: D71C0026
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 000000191BD0: 02026D26
	v_exp_f32_e32 v54, v59                                     // 000000191BD4: 7E6C4B3B
	v_fma_f32 v44, -v45, v53, v44                              // 000000191BD8: D613002C 24B26B2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000191BE0: BF870193
	v_fma_f32 v43, -v33, v71, v60                              // 000000191BE4: D613002B 24F28F21
	v_cndmask_b32_e64 v38, 0, v38, s1                          // 000000191BEC: D5010026 00064C80
	.long 0xd41b0001                                           // 000000191BF4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v42, vcc_lo              // 000000191BF8: 020254FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 000000191C00: BF870004
	v_div_fmas_f32 v35, v44, v35, v53                          // 000000191C04: D6370023 04D6472C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v58                  // 000000191C0C: 7C3C74FF 42CE8ED0
	v_fmac_f32_e32 v71, v43, v46                               // 000000191C14: 568E5D2B
	v_cvt_i32_f32_e32 v43, v62                                 // 000000191C18: 7E56113E
	v_cndmask_b32_e64 v38, 0x7f800000, v38, s1                 // 000000191C1C: D5010026 00064CFF 7F800000
	v_div_fixup_f32 v25, v35, v41, v25                         // 000000191C28: D6270019 04665323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v37                         // 000000191C30: 10464AFF BFB8AA3B
	v_fma_f32 v33, -v33, v71, v60                              // 000000191C38: D6130021 24F28F21
	.long 0xd71c002a                                           // 000000191C40: D71C002A
	v_cndmask_b32_e32 v1, v54, v43, vcc_lo                     // 000000191C44: 02025736
	v_add_f32_e32 v38, 1.0, v38                                // 000000191C48: 064C4CF2
	v_lshlrev_b32_e32 v54, 16, v129                            // 000000191C4C: 306D0290
	v_fma_f32 v45, 0xbfb8aa3b, v37, -v35                       // 000000191C50: D613002D 848E4AFF BFB8AA3B
	.long 0x7e523999                                           // 000000191C5C: 7E523999
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000191C60: 02545480
	s_mov_b32 vcc_lo, s0                                       // 000000191C64: BEEA0000
	v_div_scale_f32 v43, null, v38, v38, v27                   // 000000191C68: D6FC7C2B 046E4D26
	v_div_fmas_f32 v33, v33, v46, v71                          // 000000191C70: D6370021 051E5D21
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v58                  // 000000191C78: 7C3674FF C2B17218
	v_rndne_f32_e32 v46, v35                                   // 000000191C80: 7E5C4723
	v_fmac_f32_e32 v45, 0xb2a5705f, v37                        // 000000191C84: 565A4AFF B2A5705F
	v_mul_f32_e32 v57, 0xbfb8aa3b, v54                         // 000000191C8C: 10726CFF BFB8AA3B
	v_div_fixup_f32 v26, v33, v36, v26                         // 000000191C94: D627001A 046A4921
	v_cndmask_b32_e32 v42, 0x7f800000, v42, vcc_lo             // 000000191C9C: 025454FF 7F800000
	v_rcp_f32_e32 v33, v43                                     // 000000191CA4: 7E42552B
	v_sub_f32_e32 v35, v35, v46                                // 000000191CA8: 08465D23
	v_fma_f32 v59, 0xbfb8aa3b, v54, -v57                       // 000000191CAC: D613003B 84E66CFF BFB8AA3B
	.long 0x7e00399a                                           // 000000191CB8: 7E00399A
	v_add_f32_e32 v36, 1.0, v42                                // 000000191CBC: 064854F2
	v_rndne_f32_e32 v60, v57                                   // 000000191CC0: 7E784739
	v_add_f32_e32 v35, v35, v45                                // 000000191CC4: 06465B23
	.long 0x7f523980                                           // 000000191CC8: 7F523980
	v_and_b32_e32 v53, 1, v0                                   // 000000191CCC: 366A0081
	v_div_scale_f32 v34, null, v36, v36, v28                   // 000000191CD0: D6FC7C22 04724924
	v_fma_f32 v42, -v43, v33, 1.0                              // 000000191CD8: D613002A 23CA432B
	v_exp_f32_e32 v35, v35                                     // 000000191CE0: 7E464B23
	v_fmac_f32_e32 v59, 0xb2a5705f, v54                        // 000000191CE4: 56766CFF B2A5705F
	v_sub_f32_e32 v57, v57, v60                                // 000000191CEC: 08727939
	v_rcp_f32_e32 v44, v34                                     // 000000191CF0: 7E585522
	v_fmac_f32_e32 v33, v42, v33                               // 000000191CF4: 5642432A
	v_div_scale_f32 v42, vcc_lo, v27, v38, v27                 // 000000191CF8: D6FC6A2A 046E4D1B
	v_and_b32_e32 v41, 1, v41                                  // 000000191D00: 36525281
	v_add3_u32 v26, v26, v53, 0x7fff                           // 000000191D04: D655001A 03FE6B1A 00007FFF
	v_cvt_i32_f32_e32 v46, v46                                 // 000000191D10: 7E5C112E
	v_add_f32_e32 v57, v57, v59                                // 000000191D14: 06727739
	v_mul_f32_e32 v45, v42, v33                                // 000000191D18: 105A432A
	v_add3_u32 v25, v25, v41, 0x7fff                           // 000000191D1C: D6550019 03FE5319 00007FFF
	.long 0xd41e0001                                           // 000000191D28: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v37, vcc_lo              // 000000191D2C: 02024AFF 42CE8ED0
	v_fma_f32 v58, -v34, v44, 1.0                              // 000000191D34: D613003A 23CA5922
	.long 0xd71c0023                                           // 000000191D3C: D71C0023
	v_cndmask_b32_e32 v1, v35, v46, vcc_lo                     // 000000191D40: 02025D23
	v_fma_f32 v53, -v43, v45, v42                              // 000000191D44: D6130035 24AA5B2B
	v_exp_f32_e32 v46, v57                                     // 000000191D4C: 7E5C4B39
	global_store_d16_hi_b16 v[7:8], v25, off offset:128        // 000000191D50: DC960080 007C1907
	v_fmac_f32_e32 v44, v58, v44                               // 000000191D58: 5658593A
	v_div_scale_f32 v58, s0, v28, v36, v28                     // 000000191D5C: D6FC003A 0472491C
	v_fmac_f32_e32 v45, v53, v33                               // 000000191D64: 565A4335
	v_cndmask_b32_e64 v35, 0, v35, s1                          // 000000191D68: D5010023 00064680
	.long 0xd41b0001                                           // 000000191D70: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v37, vcc_lo              // 000000191D74: 02024AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v26, off offset:128      // 000000191D7C: DC960080 007C1A2F
	v_mul_f32_e32 v61, v58, v44                                // 000000191D84: 107A593A
	v_fma_f32 v42, -v43, v45, v42                              // 000000191D88: D613002A 24AA5B2B
	v_cndmask_b32_e64 v35, 0x7f800000, v35, s1                 // 000000191D90: D5010023 000646FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000191D9C: BF870193
	v_fma_f32 v41, -v34, v61, v58                              // 000000191DA0: D6130029 24EA7B22
	v_div_fmas_f32 v33, v42, v33, v45                          // 000000191DA8: D6370021 04B6432A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v54                  // 000000191DB0: 7C3C6CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000191DB8: BF870214
	v_add_f32_e32 v35, 1.0, v35                                // 000000191DBC: 064646F2
	v_fmac_f32_e32 v61, v41, v44                               // 000000191DC0: 567A5929
	v_cvt_i32_f32_e32 v41, v60                                 // 000000191DC4: 7E52113C
	v_div_fixup_f32 v27, v33, v38, v27                         // 000000191DC8: D627001B 046E4D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000191DD0: BF870193
	v_fma_f32 v34, -v34, v61, v58                              // 000000191DD4: D6130022 24EA7B22
	.long 0xd71c0025                                           // 000000191DDC: D71C0025
	v_cndmask_b32_e32 v1, v46, v41, vcc_lo                     // 000000191DE0: 0202532E
	v_div_scale_f32 v41, null, v35, v35, v29                   // 000000191DE4: D6FC7C29 04764723
	s_waitcnt vmcnt(3)                                         // 000000191DEC: BF890FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000191DF0: BF8700A2
	v_dual_cndmask_b32 v37, 0, v37 :: v_dual_lshlrev_b32 v46, 16, v131// 000000191DF4: CA624A80 252F0690
	s_mov_b32 vcc_lo, s0                                       // 000000191DFC: BEEA0000
	v_mul_f32_e32 v53, 0xbfb8aa3b, v46                         // 000000191E00: 106A5CFF BFB8AA3B
	v_div_fmas_f32 v34, v34, v44, v61                          // 000000191E08: D6370022 04F65922
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v54                  // 000000191E10: 7C366CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000191E18: BF870193
	v_fma_f32 v57, 0xbfb8aa3b, v46, -v53                       // 000000191E1C: D6130039 84D65CFF BFB8AA3B
	v_div_fixup_f32 v25, v34, v36, v28                         // 000000191E28: D6270019 04724922
	v_dual_cndmask_b32 v37, 0x7f800000, v37 :: v_dual_mul_f32 v28, v30, v51// 000000191E30: CA464AFF 251C671E 7F800000
	v_lshlrev_b32_e32 v36, 16, v87                             // 000000191E3C: 3048AE90
	v_rcp_f32_e32 v30, v41                                     // 000000191E40: 7E3C5529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000191E44: BF870193
	.long 0x7e003999                                           // 000000191E48: 7E003999
	v_add_f32_e32 v34, 1.0, v37                                // 000000191E4C: 06444AF2
	v_rndne_f32_e32 v58, v53                                   // 000000191E50: 7E744735
	v_mul_f32_e32 v33, 0xbfb8aa3b, v36                         // 000000191E54: 104248FF BFB8AA3B
	.long 0x7e4a399b                                           // 000000191E5C: 7E4A399B
	.long 0x7f4a3980                                           // 000000191E60: 7F4A3980
	v_div_scale_f32 v26, null, v34, v34, v28                   // 000000191E64: D6FC7C1A 04724522
	v_and_b32_e32 v45, 1, v0                                   // 000000191E6C: 365A0081
	v_fma_f32 v43, 0xbfb8aa3b, v36, -v33                       // 000000191E70: D613002B 848648FF BFB8AA3B
	v_rndne_f32_e32 v44, v33                                   // 000000191E7C: 7E584721
	v_fma_f32 v38, -v41, v30, 1.0                              // 000000191E80: D6130026 23CA3D29
	v_rcp_f32_e32 v42, v26                                     // 000000191E88: 7E54551A
	v_fmac_f32_e32 v57, 0xb2a5705f, v46                        // 000000191E8C: 56725CFF B2A5705F
	v_fmac_f32_e32 v43, 0xb2a5705f, v36                        // 000000191E94: 565648FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000191E9C: BF870243
	v_dual_sub_f32 v33, v33, v44 :: v_dual_fmac_f32 v30, v38, v30// 000000191EA0: C9405921 211E3D26
	v_div_scale_f32 v38, vcc_lo, v29, v35, v29                 // 000000191EA8: D6FC6A26 0476471D
	v_sub_f32_e32 v53, v53, v58                                // 000000191EB0: 086A7535
	v_and_b32_e32 v37, 1, v37                                  // 000000191EB4: 364A4A81
	v_add_f32_e32 v33, v33, v43                                // 000000191EB8: 06425721
	v_add3_u32 v25, v25, v45, 0x7fff                           // 000000191EBC: D6550019 03FE5B19 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000191EC8: BF8701C5
	v_fma_f32 v54, -v26, v42, 1.0                              // 000000191ECC: D6130036 23CA551A
	v_mul_f32_e32 v43, v38, v30                                // 000000191ED4: 10563D26
	v_cvt_i32_f32_e32 v44, v44                                 // 000000191ED8: 7E58112C
	v_exp_f32_e32 v33, v33                                     // 000000191EDC: 7E424B21
	v_dual_add_f32 v53, v53, v57 :: v_dual_fmac_f32 v42, v54, v42// 000000191EE0: C9007335 352A5536
	v_div_scale_f32 v54, s0, v28, v34, v28                     // 000000191EE8: D6FC0036 0472451C
	v_fma_f32 v45, -v41, v43, v38                              // 000000191EF0: D613002D 249A5729
	v_add3_u32 v27, v27, v37, 0x7fff                           // 000000191EF8: D655001B 03FE4B1B 00007FFF
	.long 0xd41e0001                                           // 000000191F04: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v36, vcc_lo              // 000000191F08: 020248FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000191F10: BF870214
	v_mul_f32_e32 v59, v54, v42                                // 000000191F14: 10765536
	v_fmac_f32_e32 v43, v45, v30                               // 000000191F18: 56563D2D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000191F1C: BF870005
	.long 0xd71c0021                                           // 000000191F20: D71C0021
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 000000191F24: 02025921
	v_exp_f32_e32 v44, v53                                     // 000000191F28: 7E584B35
	global_store_d16_hi_b16 v[15:16], v27, off offset:128      // 000000191F2C: DC960080 007C1B0F
	v_fma_f32 v37, -v26, v59, v54                              // 000000191F34: D6130025 24DA771A
	v_fma_f32 v38, -v41, v43, v38                              // 000000191F3C: D6130026 249A5729
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 000000191F44: D5010021 00064280
	.long 0xd41b0001                                           // 000000191F4C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v36, vcc_lo              // 000000191F50: 020248FF C2B17218
	global_store_d16_hi_b16 v[23:24], v25, off offset:128      // 000000191F58: DC960080 007C1917
	v_fmac_f32_e32 v59, v37, v42                               // 000000191F60: 56765525
	v_cvt_i32_f32_e32 v37, v58                                 // 000000191F64: 7E4A113A
	v_div_fmas_f32 v30, v38, v30, v43                          // 000000191F68: D637001E 04AE3D26
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 000000191F70: 7C3C5CFF 42CE8ED0
	v_cndmask_b32_e64 v33, 0x7f800000, v33, s1                 // 000000191F78: D5010021 000642FF 7F800000
	v_fma_f32 v26, -v26, v59, v54                              // 000000191F84: D613001A 24DA771A
	.long 0xd71c0024                                           // 000000191F8C: D71C0024
	v_cndmask_b32_e32 v1, v44, v37, vcc_lo                     // 000000191F90: 02024B2C
	v_div_fixup_f32 v29, v30, v35, v29                         // 000000191F94: D627001D 0476471E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000191F9C: BF870224
	v_dual_add_f32 v33, 1.0, v33 :: v_dual_lshlrev_b32 v44, 16, v123// 000000191FA0: C92242F2 212CF690
	.long 0x7f463980                                           // 000000191FA8: 7F463980
	v_cndmask_b32_e32 v36, 0, v36, vcc_lo                      // 000000191FAC: 02484880
	s_mov_b32 vcc_lo, s0                                       // 000000191FB0: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000191FB4: BF870003
	v_mul_f32_e32 v45, 0xbfb8aa3b, v44                         // 000000191FB8: 105A58FF BFB8AA3B
	v_div_fmas_f32 v26, v26, v42, v59                          // 000000191FC0: D637001A 04EE551A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 000000191FC8: 7C365CFF C2B17218
	v_div_scale_f32 v37, null, v33, v33, v17                   // 000000191FD0: D6FC7C25 04464321
	.long 0x7e46399d                                           // 000000191FD8: 7E46399D
	v_fma_f32 v53, 0xbfb8aa3b, v44, -v45                       // 000000191FDC: D6130035 84B658FF BFB8AA3B
	v_div_fixup_f32 v26, v26, v34, v28                         // 000000191FE8: D627001A 0472451A
	v_cndmask_b32_e32 v36, 0x7f800000, v36, vcc_lo             // 000000191FF0: 024848FF 7F800000
	v_lshlrev_b32_e32 v34, 16, v124                            // 000000191FF8: 3044F890
	v_rcp_f32_e32 v27, v37                                     // 000000191FFC: 7E365525
	v_rndne_f32_e32 v54, v45                                   // 000000192000: 7E6C472D
	.long 0x7e00399a                                           // 000000192004: 7E00399A
	v_add_f32_e32 v28, 1.0, v36                                // 000000192008: 063848F2
	v_mul_f32_e32 v30, 0xbfb8aa3b, v34                         // 00000019200C: 103C44FF BFB8AA3B
	v_fmac_f32_e32 v53, 0xb2a5705f, v44                        // 000000192014: 566A58FF B2A5705F
	v_sub_f32_e32 v45, v45, v54                                // 00000019201C: 085A6D2D
	v_and_b32_e32 v43, 1, v0                                   // 000000192020: 36560081
	v_div_scale_f32 v25, null, v28, v28, v18                   // 000000192024: D6FC7C19 044A391C
	v_fma_f32 v41, 0xbfb8aa3b, v34, -v30                       // 00000019202C: D6130029 847A44FF BFB8AA3B
	v_rndne_f32_e32 v42, v30                                   // 000000192038: 7E54471E
	v_fma_f32 v36, -v37, v27, 1.0                              // 00000019203C: D6130024 23CA3725
	v_and_b32_e32 v35, 1, v35                                  // 000000192044: 36464681
	v_rcp_f32_e32 v38, v25                                     // 000000192048: 7E4C5519
	v_fmac_f32_e32 v41, 0xb2a5705f, v34                        // 00000019204C: 565244FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000192054: BF870243
	v_dual_sub_f32 v30, v30, v42 :: v_dual_fmac_f32 v27, v36, v27// 000000192058: C940551E 1E1A3724
	v_div_scale_f32 v36, vcc_lo, v17, v33, v17                 // 000000192060: D6FC6A24 04464311
	v_add3_u32 v26, v26, v43, 0x7fff                           // 000000192068: D655001A 03FE571A 00007FFF
	v_cvt_i32_f32_e32 v42, v42                                 // 000000192074: 7E54112A
	v_add_f32_e32 v30, v30, v41                                // 000000192078: 063C531E
	v_add_f32_e32 v45, v45, v53                                // 00000019207C: 065A6B2D
	v_mul_f32_e32 v41, v36, v27                                // 000000192080: 10523724
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000192084: BF870005
	v_fma_f32 v46, -v25, v38, 1.0                              // 000000192088: D613002E 23CA4D19
	v_add3_u32 v29, v29, v35, 0x7fff                           // 000000192090: D655001D 03FE471D 00007FFF
	v_exp_f32_e32 v30, v30                                     // 00000019209C: 7E3C4B1E
	.long 0xd41e0001                                           // 0000001920A0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v34, vcc_lo              // 0000001920A4: 020244FF 42CE8ED0
	v_fma_f32 v43, -v37, v41, v36                              // 0000001920AC: D613002B 24925325
	v_fmac_f32_e32 v38, v46, v38                               // 0000001920B4: 564C4D2E
	v_div_scale_f32 v46, s0, v18, v28, v18                     // 0000001920B8: D6FC002E 044A3912
	s_clause 0x1                                               // 0000001920C0: BF850001
	global_store_d16_hi_b16 v[31:32], v29, off offset:128      // 0000001920C4: DC960080 007C1D1F
	global_store_d16_hi_b16 v[39:40], v26, off offset:128      // 0000001920CC: DC960080 007C1A27
	v_dual_fmac_f32 v41, v43, v27 :: v_dual_lshlrev_b32 v26, 16, v126// 0000001920D4: C822372B 291AFC90
	v_mul_f32_e32 v57, v46, v38                                // 0000001920DC: 10724D2E
	.long 0xd71c001e                                           // 0000001920E0: D71C001E
	v_cndmask_b32_e32 v1, v30, v42, vcc_lo                     // 0000001920E4: 0202551E
	v_exp_f32_e32 v42, v45                                     // 0000001920E8: 7E544B2D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001920EC: BF870003
	v_fma_f32 v36, -v37, v41, v36                              // 0000001920F0: D6130024 24925325
	.long 0x7f3a3980                                           // 0000001920F8: 7F3A3980
	v_fma_f32 v35, -v25, v57, v46                              // 0000001920FC: D6130023 24BA7319
	v_cndmask_b32_e64 v30, 0, v30, s1                          // 000000192104: D501001E 00063C80
	.long 0xd41b0001                                           // 00000019210C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v34, vcc_lo              // 000000192110: 020244FF C2B17218
	v_div_fmas_f32 v27, v36, v27, v41                          // 000000192118: D637001B 04A63724
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v44                  // 000000192120: 7C3C58FF 42CE8ED0
	v_fmac_f32_e32 v57, v35, v38                               // 000000192128: 56724D23
	v_cvt_i32_f32_e32 v35, v54                                 // 00000019212C: 7E461136
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 000000192130: D501001E 00063CFF 7F800000
	v_div_fixup_f32 v17, v27, v33, v17                         // 00000019213C: D6270011 0446431B
	v_mul_f32_e32 v33, 0xbfb8aa3b, v26                         // 000000192144: 104234FF BFB8AA3B
	v_fma_f32 v25, -v25, v57, v46                              // 00000019214C: D6130019 24BA7319
	.long 0xd71c0022                                           // 000000192154: D71C0022
	v_cndmask_b32_e32 v1, v42, v35, vcc_lo                     // 000000192158: 0202472A
	v_add_f32_e32 v30, 1.0, v30                                // 00000019215C: 063C3CF2
	.long 0xd41e0001                                           // 000000192160: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v26, vcc_lo              // 000000192164: 020234FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v26, -v33                       // 00000019216C: D6130029 848634FF BFB8AA3B
	v_rndne_f32_e32 v42, v33                                   // 000000192178: 7E544721
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000019217C: 02444480
	s_mov_b32 vcc_lo, s0                                       // 000000192180: BEEA0000
	v_div_scale_f32 v35, null, v30, v30, v19                   // 000000192184: D6FC7C23 044E3D1E
	v_div_fmas_f32 v25, v25, v38, v57                          // 00000019218C: D6370019 04E64D19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v44                  // 000000192194: 7C3658FF C2B17218
	v_dual_fmac_f32 v41, 0xb2a5705f, v26 :: v_dual_lshlrev_b32 v38, 16, v125// 00000019219C: C82234FF 2926FA90 B2A5705F
	v_sub_f32_e32 v33, v33, v42                                // 0000001921A8: 08425521
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001921AC: BF870004
	v_div_fixup_f32 v18, v25, v28, v18                         // 0000001921B0: D6270012 044A3919
	v_cndmask_b32_e32 v34, 0x7f800000, v34, vcc_lo             // 0000001921B8: 024444FF 7F800000
	v_rcp_f32_e32 v25, v35                                     // 0000001921C0: 7E325523
	v_mul_f32_e32 v43, 0xbfb8aa3b, v38                         // 0000001921C4: 10564CFF BFB8AA3B
	v_add_f32_e32 v33, v33, v41                                // 0000001921CC: 06425321
	.long 0x7e003992                                           // 0000001921D0: 7E003992
	v_add_f32_e32 v28, 1.0, v34                                // 0000001921D4: 063844F2
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001921D8: 7E54112A
	v_fma_f32 v46, 0xbfb8aa3b, v38, -v43                       // 0000001921DC: D613002E 84AE4CFF BFB8AA3B
	v_rndne_f32_e32 v53, v43                                   // 0000001921E8: 7E6A472B
	v_exp_f32_e32 v33, v33                                     // 0000001921EC: 7E424B21
	v_div_scale_f32 v27, null, v28, v28, v20                   // 0000001921F0: D6FC7C1B 0452391C
	v_fma_f32 v34, -v35, v25, 1.0                              // 0000001921F8: D6130022 23CA3323
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000192200: BF870223
	v_dual_fmac_f32 v46, 0xb2a5705f, v38 :: v_dual_sub_f32 v43, v43, v53// 000000192204: C80A4CFF 2E2A6B2B B2A5705F
	v_div_scale_f32 v41, s0, v20, v28, v20                     // 000000192210: D6FC0029 04523914
	v_rcp_f32_e32 v36, v27                                     // 000000192218: 7E48551B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019221C: BF870003
	v_fmac_f32_e32 v25, v34, v25                               // 000000192220: 56323322
	v_div_scale_f32 v34, vcc_lo, v19, v30, v19                 // 000000192224: D6FC6A22 044E3D13
	v_and_b32_e32 v37, 1, v0                                   // 00000019222C: 364A0081
	v_add_f32_e32 v43, v43, v46                                // 000000192230: 06565D2B
	.long 0xd71c0021                                           // 000000192234: D71C0021
	v_cndmask_b32_e32 v1, v33, v42, vcc_lo                     // 000000192238: 02025521
	.long 0x7e3a3991                                           // 00000019223C: 7E3A3991
	v_mul_f32_e32 v45, v34, v25                                // 000000192240: 105A3322
	v_add3_u32 v18, v18, v37, 0x7fff                           // 000000192244: D6550012 03FE4B12 00007FFF
	v_exp_f32_e32 v37, v43                                     // 000000192250: 7E4A4B2B
	v_fma_f32 v44, -v27, v36, 1.0                              // 000000192254: D613002C 23CA491B
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 00000019225C: D5010021 00064280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000192264: BF870122
	v_dual_fmac_f32 v36, v44, v36 :: v_dual_and_b32 v29, 1, v29// 000000192268: C824492C 241C3A81
	v_fma_f32 v44, -v35, v45, v34                              // 000000192270: D613002C 248A5B23
	v_add3_u32 v17, v17, v29, 0x7fff                           // 000000192278: D6550011 03FE3B11 00007FFF
	v_lshlrev_b32_e32 v29, 16, v92                             // 000000192284: 303AB890
	s_delay_alu instid0(VALU_DEP_3)                            // 000000192288: BF870003
	v_dual_mul_f32 v54, v41, v36 :: v_dual_fmac_f32 v45, v44, v25// 00000019228C: C8C04929 362C332C
	s_clause 0x1                                               // 000000192294: BF850001
	global_store_d16_hi_b16 v[7:8], v17, off offset:160        // 000000192298: DC9600A0 007C1107
	global_store_d16_hi_b16 v[47:48], v18, off offset:160      // 0000001922A0: DC9600A0 007C122F
	v_fma_f32 v44, -v27, v54, v41                              // 0000001922A8: D613002C 24A66D1B
	v_fma_f32 v34, -v35, v45, v34                              // 0000001922B0: D6130022 248A5B23
	v_cvt_i32_f32_e32 v35, v53                                 // 0000001922B8: 7E461135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001922BC: BF870193
	v_fmac_f32_e32 v54, v44, v36                               // 0000001922C0: 566C492C
	v_div_fmas_f32 v25, v34, v25, v45                          // 0000001922C4: D6370019 04B63322
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v26                  // 0000001922CC: 7C3634FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001922D4: BF870004
	.long 0xd71c0022                                           // 0000001922D8: D71C0022
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 0000001922DC: 02024725
	v_mul_f32_e32 v35, 0xbfb8aa3b, v29                         // 0000001922E0: 10463AFF BFB8AA3B
	v_fma_f32 v27, -v27, v54, v41                              // 0000001922E8: D613001B 24A66D1B
	v_div_fixup_f32 v17, v25, v30, v19                         // 0000001922F0: D6270011 044E3D19
	v_cndmask_b32_e32 v26, 0x7f800000, v33, vcc_lo             // 0000001922F8: 023442FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 000000192300: 7C3C4CFF 42CE8ED0
	.long 0x7f3c3980                                           // 000000192308: 7F3C3980
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019230C: BF870214
	.long 0x7e3c3991                                           // 000000192310: 7E3C3991
	v_add_f32_e32 v26, 1.0, v26                                // 000000192314: 063434F2
	v_cndmask_b32_e32 v33, 0, v34, vcc_lo                      // 000000192318: 02424480
	s_mov_b32 vcc_lo, s0                                       // 00000019231C: BEEA0000
	v_div_fmas_f32 v27, v27, v36, v54                          // 000000192320: D637001B 04DA491B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 000000192328: 7C364CFF C2B17218
	v_rndne_f32_e32 v36, v35                                   // 000000192330: 7E484723
	s_waitcnt vmcnt(2)                                         // 000000192334: BF890BF7
	v_lshlrev_b32_e32 v38, 16, v68                             // 000000192338: 304C8890
	v_and_b32_e32 v30, 1, v30                                  // 00000019233C: 363C3C81
	v_div_fixup_f32 v20, v27, v28, v20                         // 000000192340: D6270014 0452391B
	v_cndmask_b32_e32 v33, 0x7f800000, v33, vcc_lo             // 000000192348: 024242FF 7F800000
	v_div_scale_f32 v27, null, v26, v26, v21                   // 000000192350: D6FC7C1B 0456351A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000192358: BF870214
	v_add3_u32 v17, v17, v30, 0x7fff                           // 00000019235C: D6550011 03FE3D11 00007FFF
	.long 0x7e003994                                           // 000000192368: 7E003994
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019236C: BF870214
	v_add_f32_e32 v28, 1.0, v33                                // 000000192370: 063842F2
	v_rcp_f32_e32 v19, v27                                     // 000000192374: 7E26551B
	global_store_d16_hi_b16 v[15:16], v17, off offset:160      // 000000192378: DC9600A0 007C110F
	v_and_b32_e32 v33, 1, v0                                   // 000000192380: 36420081
	v_div_scale_f32 v25, null, v28, v28, v22                   // 000000192384: D6FC7C19 045A391C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019238C: BF870112
	v_add3_u32 v20, v20, v33, 0x7fff                           // 000000192390: D6550014 03FE4314 00007FFF
	v_rcp_f32_e32 v34, v25                                     // 00000019239C: 7E445519
	v_fma_f32 v18, -v27, v19, 1.0                              // 0000001923A0: D6130012 23CA271B
	v_fma_f32 v33, 0xbfb8aa3b, v29, -v35                       // 0000001923A8: D6130021 848E3AFF BFB8AA3B
	v_sub_f32_e32 v35, v35, v36                                // 0000001923B4: 08464923
	v_cvt_i32_f32_e32 v36, v36                                 // 0000001923B8: 7E481124
	global_store_d16_hi_b16 v[23:24], v20, off offset:160      // 0000001923BC: DC9600A0 007C1417
	v_fmac_f32_e32 v19, v18, v19                               // 0000001923C4: 56262712
	v_div_scale_f32 v18, vcc_lo, v21, v26, v21                 // 0000001923C8: D6FC6A12 04563515
	v_fmac_f32_e32 v33, 0xb2a5705f, v29                        // 0000001923D0: 56423AFF B2A5705F
	v_fma_f32 v37, -v25, v34, 1.0                              // 0000001923D8: D6130025 23CA4519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001923E0: BF870193
	v_mul_f32_e32 v41, v18, v19                                // 0000001923E4: 10522712
	v_add_f32_e32 v33, v35, v33                                // 0000001923E8: 06424323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v38                         // 0000001923EC: 10464CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001923F4: BF870004
	v_fmac_f32_e32 v34, v37, v34                               // 0000001923F8: 56444525
	v_div_scale_f32 v37, s0, v22, v28, v22                     // 0000001923FC: D6FC0025 045A3916
	v_fma_f32 v30, -v27, v41, v18                              // 000000192404: D613001E 244A531B
	v_exp_f32_e32 v33, v33                                     // 00000019240C: 7E424B21
	v_fma_f32 v43, 0xbfb8aa3b, v38, -v35                       // 000000192410: D613002B 848E4CFF BFB8AA3B
	v_rndne_f32_e32 v44, v35                                   // 00000019241C: 7E584723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000192420: BF870193
	v_dual_mul_f32 v42, v37, v34 :: v_dual_fmac_f32 v41, v30, v19// 000000192424: C8C04525 2A28271E
	v_fmac_f32_e32 v43, 0xb2a5705f, v38                        // 00000019242C: 56564CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000192434: BF870193
	v_sub_f32_e32 v35, v35, v44                                // 000000192438: 08465923
	v_fma_f32 v30, -v25, v42, v37                              // 00000019243C: D613001E 24965519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000192444: BF870294
	v_fma_f32 v17, -v27, v41, v18                              // 000000192448: D6130011 244A531B
	.long 0xd71c0012                                           // 000000192450: D71C0012
	v_cndmask_b32_e32 v1, v33, v36, vcc_lo                     // 000000192454: 02024921
	v_cvt_i32_f32_e32 v20, v44                                 // 000000192458: 7E28112C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019245C: BF870214
	v_dual_add_f32 v27, v35, v43 :: v_dual_fmac_f32 v42, v30, v34// 000000192460: C9005723 1B2A451E
	v_div_fmas_f32 v17, v17, v19, v41                          // 000000192468: D6370011 04A62711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 000000192470: 7C3C3AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000192478: BF870213
	v_fma_f32 v19, -v25, v42, v37                              // 00000019247C: D6130013 24965519
	v_exp_f32_e32 v25, v27                                     // 000000192484: 7E324B1B
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000192488: 02242480
	s_mov_b32 vcc_lo, s0                                       // 00000019248C: BEEA0000
	v_div_fixup_f32 v17, v17, v26, v21                         // 000000192490: D6270011 04563511
	v_div_fmas_f32 v19, v19, v34, v42                          // 000000192498: D6370013 04AA4513
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001924A0: 7C363AFF C2B17218
	.long 0x7f2a3980                                           // 0000001924A8: 7F2A3980
	v_lshlrev_b32_e32 v34, 16, v70                             // 0000001924AC: 30448C90
	.long 0x7e2a3991                                           // 0000001924B0: 7E2A3991
	v_div_fixup_f32 v19, v19, v28, v22                         // 0000001924B4: D6270013 045A3913
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001924BC: 022424FF 7F800000
	.long 0xd71c0014                                           // 0000001924C4: D71C0014
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000001924C8: 02022919
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 0000001924CC: 7C3C4CFF 42CE8ED0
	v_lshlrev_b32_e32 v25, 16, v104                            // 0000001924D4: 3032D090
	.long 0x7e003993                                           // 0000001924D8: 7E003993
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_and_b32 v21, 1, v21 // 0000001924DC: C92424F2 12142A81
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001924E4: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 0000001924E8: 7C364CFF C2B17218
	v_mul_f32_e32 v27, 0xbfb8aa3b, v25                         // 0000001924F0: 103632FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001924F8: BF870234
	v_div_scale_f32 v22, null, v18, v18, v9                    // 0000001924FC: D6FC7C16 04262512
	v_dual_mul_f32 v37, 0xbfb8aa3b, v34 :: v_dual_and_b32 v28, 1, v0// 000000192504: C8E444FF 251C0081 BFB8AA3B
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 000000192510: 022828FF 7F800000
	v_fma_f32 v29, 0xbfb8aa3b, v25, -v27                       // 000000192518: D613001D 846E32FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000192524: BF8701B4
	v_rcp_f32_e32 v26, v22                                     // 000000192528: 7E345516
	v_rndne_f32_e32 v30, v27                                   // 00000019252C: 7E3C471B
	v_add3_u32 v17, v17, v21, 0x7fff                           // 000000192530: D6550011 03FE2B11 00007FFF
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_fmac_f32 v29, 0xb2a5705f, v25// 00000019253C: C90028F2 141C32FF B2A5705F
	v_add3_u32 v19, v19, v28, 0x7fff                           // 000000192548: D6550013 03FE3913 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000192554: BF870224
	v_sub_f32_e32 v27, v27, v30                                // 000000192558: 08363D1B
	v_rndne_f32_e32 v28, v37                                   // 00000019255C: 7E384725
	v_div_scale_f32 v33, null, v20, v20, v10                   // 000000192560: D6FC7C21 042A2914
	v_cvt_i32_f32_e32 v30, v30                                 // 000000192568: 7E3C111E
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019256C: BF870005
	v_fma_f32 v35, -v22, v26, 1.0                              // 000000192570: D6130023 23CA3516
	v_add_f32_e32 v21, v27, v29                                // 000000192578: 062A3B1B
	v_fma_f32 v27, 0xbfb8aa3b, v34, -v37                       // 00000019257C: D613001B 849644FF BFB8AA3B
	v_rcp_f32_e32 v36, v33                                     // 000000192588: 7E485521
	v_div_scale_f32 v29, vcc_lo, v9, v18, v9                   // 00000019258C: D6FC6A1D 04262509
	v_fmac_f32_e32 v26, v35, v26                               // 000000192594: 56343523
	v_exp_f32_e32 v21, v21                                     // 000000192598: 7E2A4B15
	v_fmac_f32_e32 v27, 0xb2a5705f, v34                        // 00000019259C: 563644FF B2A5705F
	v_sub_f32_e32 v37, v37, v28                                // 0000001925A4: 084A3925
	global_store_d16_hi_b16 v[31:32], v17, off offset:160      // 0000001925A8: DC9600A0 007C111F
	v_mul_f32_e32 v38, v29, v26                                // 0000001925B0: 104C351D
	.long 0xd41e0001                                           // 0000001925B4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001925B8: 020232FF 42CE8ED0
	v_cvt_i32_f32_e32 v28, v28                                 // 0000001925C0: 7E38111C
	v_fma_f32 v35, -v33, v36, 1.0                              // 0000001925C4: D6130023 23CA4921
	v_add_f32_e32 v27, v37, v27                                // 0000001925CC: 06363725
	global_store_d16_hi_b16 v[39:40], v19, off offset:160      // 0000001925D0: DC9600A0 007C1327
	.long 0xd71c0011                                           // 0000001925D8: D71C0011
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                     // 0000001925DC: 02023D15
	v_fma_f32 v21, -v22, v38, v29                              // 0000001925E0: D6130015 24764D16
	v_fmac_f32_e32 v36, v35, v36                               // 0000001925E8: 56484923
	v_div_scale_f32 v35, s0, v10, v20, v10                     // 0000001925EC: D6FC0023 042A290A
	v_exp_f32_e32 v27, v27                                     // 0000001925F4: 7E364B1B
	v_cndmask_b32_e64 v17, 0, v17, s1                          // 0000001925F8: D5010011 00062280
	v_fmac_f32_e32 v38, v21, v26                               // 000000192600: 564C3515
	.long 0xd41b0001                                           // 000000192604: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v25, vcc_lo              // 000000192608: 020232FF C2B17218
	v_dual_mul_f32 v30, v35, v36 :: v_dual_lshlrev_b32 v19, 16, v106// 000000192610: C8E24923 1E12D490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000192618: BF870193
	v_fma_f32 v22, -v22, v38, v29                              // 00000019261C: D6130016 24764D16
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 000000192624: D5010011 000622FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000192630: BF870213
	v_fma_f32 v21, -v33, v30, v35                              // 000000192634: D6130015 248E3D21
	.long 0xd41e0001                                           // 00000019263C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v19, vcc_lo              // 000000192640: 020226FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000192648: BF870224
	v_div_fmas_f32 v22, v22, v26, v38                          // 00000019264C: D6370016 049A3516
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 000000192654: 7C3C44FF 42CE8ED0
	v_fmac_f32_e32 v30, v21, v36                               // 00000019265C: 563C4915
	.long 0xd71c0015                                           // 000000192660: D71C0015
	v_cndmask_b32_e32 v1, v27, v28, vcc_lo                     // 000000192664: 0202391B
	v_add_f32_e32 v17, 1.0, v17                                // 000000192668: 062222F2
	v_div_fixup_f32 v9, v22, v18, v9                           // 00000019266C: D6270009 04262516
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000192674: BF870214
	v_fma_f32 v25, -v33, v30, v35                              // 000000192678: D6130019 248E3D21
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 000000192680: 022A2A80
	s_mov_b32 vcc_lo, s0                                       // 000000192684: BEEA0000
	v_div_scale_f32 v26, null, v17, v17, v11                   // 000000192688: D6FC7C1A 042E2311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000192690: BF870233
	v_div_fmas_f32 v25, v25, v36, v30                          // 000000192694: D6370019 047A4919
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 00000019269C: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v34, 16, v105                            // 0000001926A4: 3044D290
	v_rcp_f32_e32 v27, v26                                     // 0000001926A8: 7E36551A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001926AC: BF870003
	v_div_fixup_f32 v10, v25, v20, v10                         // 0000001926B0: D627000A 042A2919
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001926B8: 022A2AFF 7F800000
	v_mul_f32_e32 v25, 0xbfb8aa3b, v19                         // 0000001926C0: 103226FF BFB8AA3B
	v_div_scale_f32 v33, vcc_lo, v11, v17, v11                 // 0000001926C8: D6FC6A21 042E230B
	v_mul_f32_e32 v36, 0xbfb8aa3b, v34                         // 0000001926D0: 104844FF BFB8AA3B
	.long 0x7e00398a                                           // 0000001926D8: 7E00398A
	v_add_f32_e32 v18, 1.0, v21                                // 0000001926DC: 06242AF2
	v_fma_f32 v29, 0xbfb8aa3b, v19, -v25                       // 0000001926E0: D613001D 846626FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001926EC: BF870005
	v_fma_f32 v21, -v26, v27, 1.0                              // 0000001926F0: D6130015 23CA371A
	v_rndne_f32_e32 v30, v25                                   // 0000001926F8: 7E3C4719
	v_and_b32_e32 v28, 1, v0                                   // 0000001926FC: 36380081
	v_div_scale_f32 v22, null, v18, v18, v12                   // 000000192700: D6FC7C16 04322512
	v_fmac_f32_e32 v29, 0xb2a5705f, v19                        // 000000192708: 563A26FF B2A5705F
	v_fmac_f32_e32 v27, v21, v27                               // 000000192710: 56363715
	v_sub_f32_e32 v25, v25, v30                                // 000000192714: 08323D19
	.long 0x7e283989                                           // 000000192718: 7E283989
	v_rcp_f32_e32 v21, v22                                     // 00000019271C: 7E2A5516
	.long 0x7f283980                                           // 000000192720: 7F283980
	v_mul_f32_e32 v35, v33, v27                                // 000000192724: 10463721
	v_add_f32_e32 v25, v25, v29                                // 000000192728: 06323B19
	v_fma_f32 v37, 0xbfb8aa3b, v34, -v36                       // 00000019272C: D6130025 849244FF BFB8AA3B
	v_rndne_f32_e32 v38, v36                                   // 000000192738: 7E4C4724
	v_add3_u32 v10, v10, v28, 0x7fff                           // 00000019273C: D655000A 03FE390A 00007FFF
	v_and_b32_e32 v20, 1, v20                                  // 000000192748: 36282881
	v_fma_f32 v29, -v26, v35, v33                              // 00000019274C: D613001D 2486471A
	v_exp_f32_e32 v25, v25                                     // 000000192754: 7E324B19
	v_fma_f32 v28, -v22, v21, 1.0                              // 000000192758: D613001C 23CA2B16
	v_fmac_f32_e32 v37, 0xb2a5705f, v34                        // 000000192760: 564A44FF B2A5705F
	v_sub_f32_e32 v36, v36, v38                                // 000000192768: 08484D24
	v_add3_u32 v9, v9, v20, 0x7fff                             // 00000019276C: D6550009 03FE2909 00007FFF
	v_cvt_i32_f32_e32 v20, v30                                 // 000000192778: 7E28111E
	v_fmac_f32_e32 v21, v28, v21                               // 00000019277C: 562A2B1C
	v_div_scale_f32 v28, s0, v12, v18, v12                     // 000000192780: D6FC001C 0432250C
	v_dual_fmac_f32 v35, v29, v27 :: v_dual_add_f32 v30, v36, v37// 000000192788: C808371D 231E4B24
	global_store_d16_hi_b16 v[7:8], v9, off offset:192         // 000000192790: DC9600C0 007C0907
	.long 0xd71c0009                                           // 000000192798: D71C0009
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 00000019279C: 02022919
	v_mul_f32_e32 v29, v28, v21                                // 0000001927A0: 103A2B1C
	v_fma_f32 v20, -v26, v35, v33                              // 0000001927A4: D6130014 2486471A
	v_exp_f32_e32 v26, v30                                     // 0000001927AC: 7E344B1E
	global_store_d16_hi_b16 v[47:48], v10, off offset:192      // 0000001927B0: DC9600C0 007C0A2F
	v_cndmask_b32_e64 v9, 0, v9, s1                            // 0000001927B8: D5010009 00061280
	v_fma_f32 v25, -v22, v29, v28                              // 0000001927C0: D6130019 24723B16
	v_div_fmas_f32 v20, v20, v27, v35                          // 0000001927C8: D6370014 048E3714
	v_cvt_i32_f32_e32 v27, v38                                 // 0000001927D0: 7E361126
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v19                  // 0000001927D4: 7C3626FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001927DC: BF870214
	v_fmac_f32_e32 v29, v25, v21                               // 0000001927E0: 563A2B19
	v_div_fixup_f32 v11, v20, v17, v11                         // 0000001927E4: D627000B 042E2314
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001927EC: BF870004
	.long 0xd71c0011                                           // 0000001927F0: D71C0011
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000001927F4: 0202371A
	v_cndmask_b32_e32 v9, 0x7f800000, v9, vcc_lo               // 0000001927F8: 021212FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 000000192800: 7C3C44FF 42CE8ED0
	v_fma_f32 v19, -v22, v29, v28                              // 000000192808: D6130013 24723B16
	s_waitcnt vmcnt(1)                                         // 000000192810: BF8907F7
	v_lshlrev_b32_e32 v25, 16, v67                             // 000000192814: 30328690
	.long 0x7e2c398b                                           // 000000192818: 7E2C398B
	v_add_f32_e32 v9, 1.0, v9                                  // 00000019281C: 061212F2
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000192820: 02222280
	s_mov_b32 vcc_lo, s0                                       // 000000192824: BEEA0000
	v_mul_f32_e32 v30, 0xbfb8aa3b, v25                         // 000000192828: 103C32FF BFB8AA3B
	v_div_fmas_f32 v19, v19, v21, v29                          // 000000192830: D6370013 04762B13
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 000000192838: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v21, 16, v69                             // 000000192840: 302A8A90
	v_div_scale_f32 v20, null, v9, v9, v13                     // 000000192844: D6FC7C14 04361309
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v30                       // 00000019284C: D6130022 847A32FF BFB8AA3B
	v_div_fixup_f32 v12, v19, v18, v12                         // 000000192858: D627000C 04322513
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 000000192860: 022222FF 7F800000
	v_mul_f32_e32 v19, 0xbfb8aa3b, v21                         // 000000192868: 10262AFF BFB8AA3B
	v_rcp_f32_e32 v18, v20                                     // 000000192870: 7E245514
	v_rndne_f32_e32 v35, v30                                   // 000000192874: 7E46471E
	v_fmac_f32_e32 v34, 0xb2a5705f, v25                        // 000000192878: 564432FF B2A5705F
	v_add_f32_e32 v17, 1.0, v17                                // 000000192880: 062222F2
	v_fma_f32 v27, 0xbfb8aa3b, v21, -v19                       // 000000192884: D613001B 844E2AFF BFB8AA3B
	v_rndne_f32_e32 v28, v19                                   // 000000192890: 7E384713
	.long 0xd41e0001                                           // 000000192894: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v21, vcc_lo              // 000000192898: 02022AFF 42CE8ED0
	.long 0x7e00398c                                           // 0000001928A0: 7E00398C
	v_div_scale_f32 v26, null, v17, v17, v14                   // 0000001928A4: D6FC7C1A 043A2311
	v_fmac_f32_e32 v27, 0xb2a5705f, v21                        // 0000001928AC: 56362AFF B2A5705F
	v_sub_f32_e32 v19, v19, v28                                // 0000001928B4: 08263913
	v_fma_f32 v29, -v20, v18, 1.0                              // 0000001928B8: D613001D 23CA2514
	v_cvt_i32_f32_e32 v28, v28                                 // 0000001928C0: 7E38111C
	v_rcp_f32_e32 v33, v26                                     // 0000001928C4: 7E42551A
	.long 0x7f2c3980                                           // 0000001928C8: 7F2C3980
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001928CC: BF8701B3
	v_dual_add_f32 v19, v19, v27 :: v_dual_fmac_f32 v18, v29, v18// 0000001928D0: C9003713 1312251D
	v_div_scale_f32 v27, vcc_lo, v13, v9, v13                  // 0000001928D8: D6FC6A1B 0436130D
	v_dual_sub_f32 v29, v30, v35 :: v_dual_and_b32 v36, 1, v0  // 0000001928E0: C964471E 1D240081
	v_exp_f32_e32 v19, v19                                     // 0000001928E8: 7E264B13
	v_and_b32_e32 v22, 1, v22                                  // 0000001928EC: 362C2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001928F0: BF870313
	v_mul_f32_e32 v37, v27, v18                                // 0000001928F4: 104A251B
	v_fma_f32 v30, -v26, v33, 1.0                              // 0000001928F8: D613001E 23CA431A
	v_add_f32_e32 v29, v29, v34                                // 000000192900: 063A451D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000192904: BF870214
	v_add3_u32 v10, v11, v22, 0x7fff                           // 000000192908: D655000A 03FE2D0B 00007FFF
	v_fma_f32 v34, -v20, v37, v27                              // 000000192914: D6130022 246E4B14
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019291C: BF870004
	v_fmac_f32_e32 v33, v30, v33                               // 000000192920: 5642431E
	v_div_scale_f32 v30, s0, v14, v17, v14                     // 000000192924: D6FC001E 043A230E
	v_exp_f32_e32 v29, v29                                     // 00000019292C: 7E3A4B1D
	.long 0xd71c0013                                           // 000000192930: D71C0013
	v_cndmask_b32_e32 v1, v19, v28, vcc_lo                     // 000000192934: 02023913
	v_fmac_f32_e32 v37, v34, v18                               // 000000192938: 564A2522
	v_cvt_i32_f32_e32 v34, v35                                 // 00000019293C: 7E441123
	v_mul_f32_e32 v28, v30, v33                                // 000000192940: 1038431E
	v_add3_u32 v11, v12, v36, 0x7fff                           // 000000192944: D655000B 03FE490C 00007FFF
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 000000192950: D5010013 00062680
	.long 0xd41b0001                                           // 000000192958: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v21, vcc_lo              // 00000019295C: 02022AFF C2B17218
	v_fma_f32 v20, -v20, v37, v27                              // 000000192964: D6130014 246E4B14
	v_fma_f32 v35, -v26, v28, v30                              // 00000019296C: D6130023 247A391A
	.long 0xd71c001b                                           // 000000192974: D71C001B
	v_cndmask_b32_e32 v1, v29, v34, vcc_lo                     // 000000192978: 0202451D
	global_store_d16_hi_b16 v[15:16], v10, off offset:192      // 00000019297C: DC9600C0 007C0A0F
	v_cndmask_b32_e64 v19, 0x7f800000, v19, s1                 // 000000192984: D5010013 000626FF 7F800000
	.long 0xd41e0001                                           // 000000192990: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 000000192994: 020232FF 42CE8ED0
	v_fmac_f32_e32 v28, v35, v33                               // 00000019299C: 56384323
	v_div_fmas_f32 v18, v20, v18, v37                          // 0000001929A0: D6370012 04962514
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001929A8: 7C3632FF C2B17218
	v_add_f32_e32 v19, 1.0, v19                                // 0000001929B0: 062626F2
	v_cndmask_b32_e64 v21, 0, v27, s1                          // 0000001929B4: D5010015 00063680
	v_fma_f32 v20, -v26, v28, v30                              // 0000001929BC: D6130014 247A391A
	v_div_fixup_f32 v9, v18, v9, v13                           // 0000001929C4: D6270009 04361312
	global_store_d16_hi_b16 v[23:24], v11, off offset:192      // 0000001929CC: DC9600C0 007C0B17
	v_div_scale_f32 v26, null, v19, v19, v1                    // 0000001929D4: D6FC7C1A 04062713
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001929DC: 022A2AFF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001929E4: BEEA0000
	v_lshlrev_b32_e32 v18, 16, v56                             // 0000001929E8: 30247090
	v_div_fmas_f32 v20, v20, v33, v28                          // 0000001929EC: D6370014 04724314
	v_rcp_f32_e32 v25, v26                                     // 0000001929F4: 7E32551A
	v_add_f32_e32 v21, 1.0, v21                                // 0000001929F8: 062A2AF2
	v_lshlrev_b32_e32 v29, 16, v55                             // 0000001929FC: 303A6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000192A00: BF870223
	v_div_fixup_f32 v12, v20, v17, v14                         // 000000192A04: D627000C 043A2314
	.long 0x7e223989                                           // 000000192A0C: 7E223989
	v_div_scale_f32 v14, null, v21, v21, v2                    // 000000192A10: D6FC7C0E 040A2B15
	.long 0x7f223980                                           // 000000192A18: 7F223980
	v_mul_f32_e32 v30, 0xbfb8aa3b, v29                         // 000000192A1C: 103C3AFF BFB8AA3B
	.long 0x7e00398c                                           // 000000192A24: 7E00398C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000192A28: BF8701B5
	v_fma_f32 v10, -v26, v25, 1.0                              // 000000192A2C: D613000A 23CA331A
	v_rcp_f32_e32 v13, v14                                     // 000000192A34: 7E1A550E
	v_and_b32_e32 v17, 1, v17                                  // 000000192A38: 36222281
	v_and_b32_e32 v11, 1, v0                                   // 000000192A3C: 36160081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000192A40: BF870223
	v_fmac_f32_e32 v25, v10, v25                               // 000000192A44: 5632330A
	v_div_scale_f32 v10, vcc_lo, v1, v19, v1                   // 000000192A48: D6FC6A0A 04062701
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000192A50: D6550009 03FE2309 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000192A5C: BF870224
	v_add3_u32 v11, v12, v11, 0x7fff                           // 000000192A60: D655000B 03FE170C 00007FFF
	v_mul_f32_e32 v12, 0xbfb8aa3b, v18                         // 000000192A6C: 101824FF BFB8AA3B
	v_mul_f32_e32 v20, v10, v25                                // 000000192A74: 1028330A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000192A78: BF870005
	v_fma_f32 v22, -v14, v13, 1.0                              // 000000192A7C: D6130016 23CA1B0E
	s_clause 0x1                                               // 000000192A84: BF850001
	global_store_d16_hi_b16 v[31:32], v9, off offset:192       // 000000192A88: DC9600C0 007C091F
	global_store_d16_hi_b16 v[39:40], v11, off offset:192      // 000000192A90: DC9600C0 007C0B27
	v_fma_f32 v27, 0xbfb8aa3b, v18, -v12                       // 000000192A98: D613001B 843224FF BFB8AA3B
	v_fma_f32 v17, -v26, v20, v10                              // 000000192AA4: D6130011 242A291A
	v_fmac_f32_e32 v13, v22, v13                               // 000000192AAC: 561A1B16
	v_div_scale_f32 v22, s0, v2, v21, v2                       // 000000192AB0: D6FC0016 040A2B02
	v_rndne_f32_e32 v28, v12                                   // 000000192AB8: 7E38470C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000192ABC: BF870114
	v_dual_fmac_f32 v27, 0xb2a5705f, v18 :: v_dual_fmac_f32 v20, v17, v25// 000000192AC0: C80024FF 1B143311 B2A5705F
	v_dual_mul_f32 v17, v22, v13 :: v_dual_sub_f32 v12, v12, v28// 000000192ACC: C8CA1B16 110C390C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000192AD4: BF8701A2
	v_fma_f32 v9, -v26, v20, v10                               // 000000192AD8: D6130009 242A291A
	v_fma_f32 v26, 0xbfb8aa3b, v29, -v30                       // 000000192AE0: D613001A 847A3AFF BFB8AA3B
	v_fma_f32 v10, -v14, v17, v22                              // 000000192AEC: D613000A 245A230E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000192AF4: BF870004
	v_add_f32_e32 v12, v12, v27                                // 000000192AF8: 0618370C
	v_rndne_f32_e32 v27, v30                                   // 000000192AFC: 7E36471E
	v_div_fmas_f32 v9, v9, v25, v20                            // 000000192B00: D6370009 04523309
	v_fmac_f32_e32 v26, 0xb2a5705f, v29                        // 000000192B08: 56343AFF B2A5705F
	v_fmac_f32_e32 v17, v10, v13                               // 000000192B10: 56221B0A
	v_exp_f32_e32 v10, v12                                     // 000000192B14: 7E144B0C
	v_sub_f32_e32 v12, v30, v27                                // 000000192B18: 0818371E
	v_lshlrev_b32_e32 v20, 16, v63                             // 000000192B1C: 30287E90
	v_cvt_i32_f32_e32 v25, v28                                 // 000000192B20: 7E32111C
	v_fma_f32 v14, -v14, v17, v22                              // 000000192B24: D613000E 245A230E
	s_waitcnt vmcnt(0)                                         // 000000192B2C: BF8903F7
	v_lshlrev_b32_e32 v22, 16, v64                             // 000000192B30: 302C8090
	v_add_f32_e32 v12, v12, v26                                // 000000192B34: 0618350C
	v_mul_f32_e32 v26, 0xbfb8aa3b, v20                         // 000000192B38: 103428FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v18                  // 000000192B40: 7C3C24FF 42CE8ED0
	v_cvt_i32_f32_e32 v27, v27                                 // 000000192B48: 7E36111B
	v_mul_f32_e32 v28, 0xbfb8aa3b, v22                         // 000000192B4C: 10382CFF BFB8AA3B
	.long 0xd71c000a                                           // 000000192B54: D71C000A
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 000000192B58: 0202330A
	v_fma_f32 v25, 0xbfb8aa3b, v20, -v26                       // 000000192B5C: D6130019 846A28FF BFB8AA3B
	v_rndne_f32_e32 v30, v26                                   // 000000192B68: 7E3C471A
	v_exp_f32_e32 v12, v12                                     // 000000192B6C: 7E184B0C
	v_fma_f32 v33, 0xbfb8aa3b, v22, -v28                       // 000000192B70: D6130021 84722CFF BFB8AA3B
	v_rndne_f32_e32 v34, v28                                   // 000000192B7C: 7E44471C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000192B80: BF870223
	v_dual_fmac_f32 v25, 0xb2a5705f, v20 :: v_dual_sub_f32 v26, v26, v30// 000000192B84: C80A28FF 191A3D1A B2A5705F
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000192B90: 02141480
	v_fmac_f32_e32 v33, 0xb2a5705f, v22                        // 000000192B94: 56422CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 000000192B9C: BF8702B4
	v_sub_f32_e32 v28, v28, v34                                // 000000192BA0: 0838451C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v18                  // 000000192BA4: 7C3624FF C2B17218
	v_add_f32_e32 v25, v26, v25                                // 000000192BAC: 0632331A
	.long 0xd71c000c                                           // 000000192BB0: D71C000C
	v_cndmask_b32_e32 v1, v12, v27, vcc_lo                     // 000000192BB4: 0202370C
	v_cvt_i32_f32_e32 v27, v34                                 // 000000192BB8: 7E361122
	v_add_f32_e32 v26, v28, v33                                // 000000192BBC: 0634431C
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo             // 000000192BC0: 021414FF 7F800000
	v_exp_f32_e32 v18, v25                                     // 000000192BC8: 7E244B19
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 000000192BCC: 7C3C3AFF 42CE8ED0
	v_div_fixup_f32 v1, v9, v19, v1                            // 000000192BD4: D6270001 04062709
	v_exp_f32_e32 v25, v26                                     // 000000192BDC: 7E324B1A
	v_cvt_i32_f32_e32 v26, v30                                 // 000000192BE0: 7E34111E
	v_add_f32_e32 v10, 1.0, v10                                // 000000192BE4: 061414F2
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 000000192BE8: 02181880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 000000192BEC: 7C363AFF C2B17218
	.long 0x7e443981                                           // 000000192BF4: 7E443981
	.long 0x7f443980                                           // 000000192BF8: 7F443980
	.long 0xd71c0012                                           // 000000192BFC: D71C0012
	v_cndmask_b32_e32 v1, v18, v26, vcc_lo                     // 000000192C00: 02023512
	v_div_scale_f32 v26, null, v10, v10, v3                    // 000000192C04: D6FC7C1A 040E150A
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 000000192C0C: 021818FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v20                  // 000000192C14: 7C3C28FF 42CE8ED0
	.long 0xd71c0019                                           // 000000192C1C: D71C0019
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 000000192C20: 02023719
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000192C24: BF870194
	v_rcp_f32_e32 v27, v26                                     // 000000192C28: 7E36551A
	v_add_f32_e32 v12, 1.0, v12                                // 000000192C2C: 061818F2
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000192C30: 02242480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v22                  // 000000192C34: 7C3C2CFF 42CE8ED0
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000192C3C: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v20                  // 000000192C40: 7C3628FF C2B17218
	v_div_scale_f32 v20, null, v12, v12, v4                    // 000000192C48: D6FC7C14 0412190C
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 000000192C50: 022424FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v22                  // 000000192C58: 7C362CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000192C60: BF870113
	v_rcp_f32_e32 v28, v20                                     // 000000192C64: 7E385514
	v_add_f32_e32 v18, 1.0, v18                                // 000000192C68: 062424F2
	v_cndmask_b32_e32 v22, 0x7f800000, v25, vcc_lo             // 000000192C6C: 022C32FF 7F800000
	v_fma_f32 v25, -v26, v27, 1.0                              // 000000192C74: D6130019 23CA371A
	s_mov_b32 vcc_lo, s0                                       // 000000192C7C: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000192C80: BF870193
	v_div_scale_f32 v29, null, v18, v18, v5                    // 000000192C84: D6FC7C1D 04162512
	v_add_f32_e32 v22, 1.0, v22                                // 000000192C8C: 062C2CF2
	v_div_fmas_f32 v13, v14, v13, v17                          // 000000192C90: D637000D 04461B0E
	v_fmac_f32_e32 v27, v25, v27                               // 000000192C98: 56363719
	v_div_scale_f32 v17, vcc_lo, v3, v10, v3                   // 000000192C9C: D6FC6A11 040E1503
	v_rcp_f32_e32 v14, v29                                     // 000000192CA4: 7E1C551D
	v_div_scale_f32 v25, null, v22, v22, v6                    // 000000192CA8: D6FC7C19 041A2D16
	v_fma_f32 v30, -v20, v28, 1.0                              // 000000192CB0: D613001E 23CA3914
	v_div_fixup_f32 v2, v13, v21, v2                           // 000000192CB8: D6270002 040A2B0D
	v_mul_f32_e32 v11, v17, v27                                // 000000192CC0: 10163711
	v_div_scale_f32 v21, s0, v4, v12, v4                       // 000000192CC4: D6FC0015 04121904
	v_rcp_f32_e32 v13, v25                                     // 000000192CCC: 7E1A5519
	v_fmac_f32_e32 v28, v30, v28                               // 000000192CD0: 5638391E
	.long 0x7e003982                                           // 000000192CD4: 7E003982
	v_fma_f32 v9, -v26, v11, v17                               // 000000192CD8: D6130009 2446171A
	v_fma_f32 v30, -v29, v14, 1.0                              // 000000192CE0: D613001E 23CA1D1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000192CE8: BF870114
	v_mul_f32_e32 v19, v21, v28                                // 000000192CEC: 10263915
	v_dual_fmac_f32 v11, v9, v27 :: v_dual_fmac_f32 v14, v30, v14// 000000192CF0: C8003709 0B0E1D1E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000192CF8: BF870225
	v_fma_f32 v33, -v25, v13, 1.0                              // 000000192CFC: D6130021 23CA1B19
	v_div_scale_f32 v30, s1, v5, v18, v5                       // 000000192D04: D6FC011E 04162505
	v_fma_f32 v9, -v20, v19, v21                               // 000000192D0C: D6130009 24562714
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000192D14: BF870214
	v_fma_f32 v17, -v26, v11, v17                              // 000000192D18: D6130011 2446171A
	v_fmac_f32_e32 v13, v33, v13                               // 000000192D20: 561A1B21
	v_div_scale_f32 v33, s2, v6, v22, v6                       // 000000192D24: D6FC0221 041A2D06
	v_mul_f32_e32 v35, v30, v14                                // 000000192D2C: 10461D1E
	v_fmac_f32_e32 v19, v9, v28                                // 000000192D30: 56263909
	v_div_fmas_f32 v11, v17, v27, v11                          // 000000192D34: D637000B 042E3711
	s_mov_b32 vcc_lo, s0                                       // 000000192D3C: BEEA0000
	v_mul_f32_e32 v26, v33, v13                                // 000000192D40: 10341B21
	v_fma_f32 v9, -v29, v35, v30                               // 000000192D44: D6130009 247A471D
	v_fma_f32 v17, -v20, v19, v21                              // 000000192D4C: D6130011 24562714
	v_div_fixup_f32 v3, v11, v10, v3                           // 000000192D54: D6270003 040E150B
	v_and_b32_e32 v11, 1, v34                                  // 000000192D5C: 36164481
	v_fma_f32 v20, -v25, v26, v33                              // 000000192D60: D6130014 24863519
	v_fmac_f32_e32 v35, v9, v14                                // 000000192D68: 56461D09
	v_div_fmas_f32 v9, v17, v28, v19                           // 000000192D6C: D6370009 044E3911
	s_mov_b32 vcc_lo, s1                                       // 000000192D74: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000192D78: BF870193
	v_dual_fmac_f32 v26, v20, v13 :: v_dual_and_b32 v17, 1, v0 // 000000192D7C: C8241B14 1A100081
	v_fma_f32 v10, -v29, v35, v30                              // 000000192D84: D613000A 247A471D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000192D8C: BF870003
	v_div_fixup_f32 v4, v9, v12, v4                            // 000000192D90: D6270004 04121909
	.long 0x7f183980                                           // 000000192D98: 7F183980
	v_add3_u32 v1, v1, v11, 0x7fff                             // 000000192D9C: D6550001 03FE1701 00007FFF
	v_fma_f32 v9, -v25, v26, v33                               // 000000192DA8: D6130009 24863519
	v_div_fmas_f32 v10, v10, v14, v35                          // 000000192DB0: D637000A 048E1D0A
	s_mov_b32 vcc_lo, s2                                       // 000000192DB8: BEEA0002
	.long 0x7e003984                                           // 000000192DBC: 7E003984
	v_add3_u32 v2, v2, v17, 0x7fff                             // 000000192DC0: D6550002 03FE2302 00007FFF
	v_div_fmas_f32 v9, v9, v13, v26                            // 000000192DCC: D6370009 046A1B09
	v_div_fixup_f32 v5, v10, v18, v5                           // 000000192DD4: D6270005 0416250A
	.long 0x7e143983                                           // 000000192DDC: 7E143983
	.long 0x7f143980                                           // 000000192DE0: 7F143980
	global_store_d16_hi_b16 v[7:8], v1, off offset:224         // 000000192DE4: DC9600E0 007C0107
	v_div_fixup_f32 v6, v9, v22, v6                            // 000000192DEC: D6270006 041A2D09
	.long 0x7e183985                                           // 000000192DF4: 7E183985
	v_and_b32_e32 v9, 1, v0                                    // 000000192DF8: 36120081
	v_and_b32_e32 v10, 1, v10                                  // 000000192DFC: 36141481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000192E00: BF870214
	.long 0x7e003986                                           // 000000192E04: 7E003986
	v_and_b32_e32 v11, 1, v12                                  // 000000192E08: 36161881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000192E0C: BF870223
	v_add3_u32 v1, v3, v10, 0x7fff                             // 000000192E10: D6550001 03FE1503 00007FFF
	v_add3_u32 v3, v4, v9, 0x7fff                              // 000000192E1C: D6550003 03FE1304 00007FFF
	v_and_b32_e32 v0, 1, v0                                    // 000000192E28: 36000081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000192E2C: BF870114
	v_add3_u32 v4, v5, v11, 0x7fff                             // 000000192E30: D6550004 03FE1705 00007FFF
	v_add3_u32 v0, v6, v0, 0x7fff                              // 000000192E3C: D6550000 03FE0106 00007FFF
	s_clause 0x4                                               // 000000192E48: BF850004
	global_store_d16_hi_b16 v[47:48], v2, off offset:224       // 000000192E4C: DC9600E0 007C022F
	global_store_d16_hi_b16 v[15:16], v1, off offset:224       // 000000192E54: DC9600E0 007C010F
	global_store_d16_hi_b16 v[23:24], v3, off offset:224       // 000000192E5C: DC9600E0 007C0317
	global_store_d16_hi_b16 v[31:32], v4, off offset:224       // 000000192E64: DC9600E0 007C041F
	global_store_d16_hi_b16 v[39:40], v0, off offset:224       // 000000192E6C: DC9600E0 007C0027
	s_nop 0                                                    // 000000192E74: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000192E78: BFB60003
	s_endpgm                                                   // 000000192E7C: BFB00000
		...

