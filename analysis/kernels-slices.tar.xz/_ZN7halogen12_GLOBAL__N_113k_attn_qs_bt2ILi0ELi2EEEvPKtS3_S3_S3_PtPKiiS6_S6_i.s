00000000001bba00 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 0000001BBA00: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 0000001BBA04: F4080300 F8000020
	s_load_b128 s[24:27], s[0:1], 0x38                         // 0000001BBA0C: F4080600 F8000038
	s_mov_b32 s20, s3                                          // 0000001BBA14: BE940003
	s_ashr_i32 s3, s2, 31                                      // 0000001BBA18: 86039F02
	s_waitcnt lgkmcnt(0)                                       // 0000001BBA1C: BF89FC07
	s_load_b32 s6, s[14:15], null                              // 0000001BBA20: F4000187 F8000000
	s_load_b32 s30, s[0:1], 0x48                               // 0000001BBA28: F4000780 F8000048
	s_lshl_b64 s[4:5], s[2:3], 2                               // 0000001BBA30: 84848202
	s_waitcnt lgkmcnt(0)                                       // 0000001BBA34: BF89FC07
	s_add_i32 s16, s6, s2                                      // 0000001BBA38: 81100206
	s_add_u32 s14, s26, s4                                     // 0000001BBA3C: 800E041A
	s_addc_u32 s15, s27, s5                                    // 0000001BBA40: 820F051B
	s_load_b256 s[4:11], s[0:1], null                          // 0000001BBA44: F40C0100 F8000000
	s_load_b32 s3, s[14:15], null                              // 0000001BBA4C: F40000C7 F8000000
	s_add_i32 s17, s16, 1                                      // 0000001BBA54: 81118110
	s_mul_hi_i32 s15, s30, s2                                  // 0000001BBA58: 970F021E
	s_ashr_i32 s0, s17, 31                                     // 0000001BBA5C: 86009F11
	s_mul_i32 s14, s30, s2                                     // 0000001BBA60: 960E021E
	s_lshr_b32 s0, s0, 30                                      // 0000001BBA64: 85009E00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001BBA68: BF870499
	s_add_i32 s17, s17, s0                                     // 0000001BBA6C: 81110011
	s_and_b32 s0, s17, -4                                      // 0000001BBA70: 8B00C411
	s_ashr_i32 s26, s17, 2                                     // 0000001BBA74: 861A8211
	s_sub_i32 s1, s16, s0                                      // 0000001BBA78: 81810010
	s_mov_b32 s27, s26                                         // 0000001BBA7C: BE9B001A
	s_cmp_gt_i32 s1, -1                                        // 0000001BBA80: BF02C101
	s_cselect_b32 s16, -1, 0                                   // 0000001BBA84: 981080C1
	s_lshl_b64 s[14:15], s[14:15], 2                           // 0000001BBA88: 848E820E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BBA8C: BF870009
	s_add_u32 s14, s24, s14                                    // 0000001BBA90: 800E0E18
	s_addc_u32 s15, s25, s15                                   // 0000001BBA94: 820F0F19
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000001BBA98: 8B6A107E
	s_cbranch_vccnz 11                                         // 0000001BBA9C: BFA4000B <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xcc>
	s_waitcnt lgkmcnt(0)                                       // 0000001BBAA0: BF89FC07
	s_max_i32 s18, s3, 1                                       // 0000001BBAA4: 8A128103
	s_mov_b32 s19, 0                                           // 0000001BBAA8: BE930080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001BBAAC: BF870499
	s_lshl_b64 s[18:19], s[18:19], 2                           // 0000001BBAB0: 84928212
	s_add_u32 s0, s14, s18                                     // 0000001BBAB4: 8000120E
	s_addc_u32 s17, s15, s19                                   // 0000001BBAB8: 8211130F
	s_add_u32 s18, s0, -4                                      // 0000001BBABC: 8012C400
	s_addc_u32 s19, s17, -1                                    // 0000001BBAC0: 8213C111
	s_load_b32 s27, s[18:19], null                             // 0000001BBAC4: F40006C9 F8000000
	v_lshrrev_b32_e32 v7, 5, v0                                // 0000001BBACC: 320E0085
	s_mov_b32 s17, exec_lo                                     // 0000001BBAD0: BE91007E
	v_cmpx_gt_u32_e32 0x180, v0                                // 0000001BBAD4: 7D9800FF 00000180
	s_cbranch_execz 61                                         // 0000001BBADC: BFA5003D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1d4>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001BBAE0: BF870002
	v_mul_u32_u24_e32 v1, 0x210, v7                            // 0000001BBAE4: 16020EFF 00000210
	v_and_b32_e32 v2, 31, v0                                   // 0000001BBAEC: 3604009F
	s_mul_i32 s18, s20, 0xc00                                  // 0000001BBAF0: 9612FF14 00000C00
	s_mul_i32 s21, s2, 0x3000                                  // 0000001BBAF8: 9615FF02 00003000
	s_ashr_i32 s19, s18, 31                                    // 0000001BBB00: 86139F12
	s_mul_hi_i32 s0, s2, 0x3000                                // 0000001BBB04: 9700FF02 00003000
	s_lshl_b64 s[18:19], s[18:19], 1                           // 0000001BBB0C: 84928112
	v_lshl_add_u32 v4, v2, 4, v1                               // 0000001BBB10: D6460004 04050902
	v_lshlrev_b32_e32 v1, 4, v0                                // 0000001BBB18: 30020084
	s_waitcnt lgkmcnt(0)                                       // 0000001BBB1C: BF89FC07
	s_add_u32 s4, s4, s18                                      // 0000001BBB20: 80041204
	s_addc_u32 s5, s5, s19                                     // 0000001BBB24: 82051305
	s_add_u32 s4, s4, s21                                      // 0000001BBB28: 80041504
	s_addc_u32 s0, s5, s0                                      // 0000001BBB2C: 82000005
	.long 0xd7000401                                           // 0000001BBB30: D7000401
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000001BBB34: 02020204
	v_lshl_or_b32 v3, v0, 3, 0xfffffe00                        // 0000001BBB38: D6560003 03FD0700 FFFFFE00
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 0000001BBB44: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 0000001BBB4C: BE840080
	s_nop 0                                                    // 0000001BBB50: BF800000
	s_nop 0                                                    // 0000001BBB54: BF800000
	s_nop 0                                                    // 0000001BBB58: BF800000
	s_nop 0                                                    // 0000001BBB5C: BF800000
	s_nop 0                                                    // 0000001BBB60: BF800000
	s_nop 0                                                    // 0000001BBB64: BF800000
	s_nop 0                                                    // 0000001BBB68: BF800000
	s_nop 0                                                    // 0000001BBB6C: BF800000
	s_nop 0                                                    // 0000001BBB70: BF800000
	s_nop 0                                                    // 0000001BBB74: BF800000
	s_nop 0                                                    // 0000001BBB78: BF800000
	s_nop 0                                                    // 0000001BBB7C: BF800000
	global_load_b128 v[8:11], v[1:2], off                      // 0000001BBB80: DC5E0000 087C0001
	v_add_nc_u32_e32 v3, 0x200, v3                             // 0000001BBB88: 4A0606FF 00000200
	.long 0xd7006a01                                           // 0000001BBB90: D7006A01
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001BBB94: 020202FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BBB9C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000001BBBA0: D5207C02 01AA0480
	.long 0xd4490000                                           // 0000001BBBA8: D4490000
	v_cndmask_b32_e32 v1, 0x9ff, v3, vcc_lo                    // 0000001BBBAC: 020206FF 000009FF
	s_or_b32 s4, s0, s4                                        // 0000001BBBB4: 8C040400
	s_waitcnt vmcnt(0)                                         // 0000001BBBB8: BF8903F7
	ds_store_b128 v4, v[8:11] offset:1024                      // 0000001BBBBC: DB7C0400 00000804
	v_add_nc_u32_e32 v4, 0x420, v4                             // 0000001BBBC4: 4A0808FF 00000420
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001BBBCC: 917E047E
	s_cbranch_execnz 65515                                     // 0000001BBBD0: BFA6FFEB <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x180>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BBBD4: 8C7E117E
	v_cndmask_b32_e64 v1, 0, 1, s16                            // 0000001BBBD8: D5010001 00410280
	v_lshlrev_b32_e32 v91, 7, v7                               // 0000001BBBE0: 30B60E87
	s_waitcnt lgkmcnt(0)                                       // 0000001BBBE4: BF89FC07
	s_barrier                                                  // 0000001BBBE8: BFBD0000
	buffer_gl0_inv                                             // 0000001BBBEC: E0AC0000 00000000
	v_readfirstlane_b32 s0, v1                                 // 0000001BBBF4: 7E000501
	s_add_i32 s28, s3, s0                                      // 0000001BBBF8: 811C0003
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001BBBFC: BF870499
	s_add_i32 s0, s28, 3                                       // 0000001BBC00: 8100831C
	s_ashr_i32 s29, s0, 2                                      // 0000001BBC04: 861D8200
	s_mov_b32 s0, 0                                            // 0000001BBC08: BE800080
	s_cmp_gt_i32 s29, 0                                        // 0000001BBC0C: BF02801D
	s_cbranch_scc1 2                                           // 0000001BBC10: BFA20002 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x21c>
	v_lshlrev_b32_e32 v8, 7, v7                                // 0000001BBC14: 30100E87
	s_branch 1                                                 // 0000001BBC18: BFA00001 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x220>
	s_mov_b32 s0, -1                                           // 0000001BBC1C: BE8000C1
	v_dual_mov_b32 v38, 0 :: v_dual_and_b32 v89, 15, v0        // 0000001BBC20: CA240080 2658008F
	v_bfe_u32 v90, v0, 4, 1                                    // 0000001BBC28: D610005A 02050900
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000001BBC30: 916A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001BBC34: BF870002
	v_mov_b32_e32 v37, v38                                     // 0000001BBC38: 7E4A0326
	v_mov_b32_e32 v36, v38                                     // 0000001BBC3C: 7E480326
	v_mov_b32_e32 v35, v38                                     // 0000001BBC40: 7E460326
	v_mov_b32_e32 v34, v38                                     // 0000001BBC44: 7E440326
	v_mov_b32_e32 v33, v38                                     // 0000001BBC48: 7E420326
	v_mov_b32_e32 v46, v38                                     // 0000001BBC4C: 7E5C0326
	v_mov_b32_e32 v45, v38                                     // 0000001BBC50: 7E5A0326
	v_mov_b32_e32 v44, v38                                     // 0000001BBC54: 7E580326
	v_mov_b32_e32 v43, v38                                     // 0000001BBC58: 7E560326
	v_mov_b32_e32 v42, v38                                     // 0000001BBC5C: 7E540326
	v_mov_b32_e32 v41, v38                                     // 0000001BBC60: 7E520326
	v_mov_b32_e32 v54, v38                                     // 0000001BBC64: 7E6C0326
	v_mov_b32_e32 v53, v38                                     // 0000001BBC68: 7E6A0326
	v_mov_b32_e32 v52, v38                                     // 0000001BBC6C: 7E680326
	v_mov_b32_e32 v51, v38                                     // 0000001BBC70: 7E660326
	v_mov_b32_e32 v50, v38                                     // 0000001BBC74: 7E640326
	v_mov_b32_e32 v49, v38                                     // 0000001BBC78: 7E620326
	v_mov_b32_e32 v62, v38                                     // 0000001BBC7C: 7E7C0326
	v_mov_b32_e32 v61, v38                                     // 0000001BBC80: 7E7A0326
	v_mov_b32_e32 v60, v38                                     // 0000001BBC84: 7E780326
	v_mov_b32_e32 v59, v38                                     // 0000001BBC88: 7E760326
	v_mov_b32_e32 v58, v38                                     // 0000001BBC8C: 7E740326
	v_mov_b32_e32 v57, v38                                     // 0000001BBC90: 7E720326
	v_mov_b32_e32 v30, v38                                     // 0000001BBC94: 7E3C0326
	v_mov_b32_e32 v29, v38                                     // 0000001BBC98: 7E3A0326
	v_mov_b32_e32 v28, v38                                     // 0000001BBC9C: 7E380326
	v_mov_b32_e32 v27, v38                                     // 0000001BBCA0: 7E360326
	v_mov_b32_e32 v26, v38                                     // 0000001BBCA4: 7E340326
	v_mov_b32_e32 v25, v38                                     // 0000001BBCA8: 7E320326
	v_mov_b32_e32 v22, v38                                     // 0000001BBCAC: 7E2C0326
	v_mov_b32_e32 v21, v38                                     // 0000001BBCB0: 7E2A0326
	v_mov_b32_e32 v20, v38                                     // 0000001BBCB4: 7E280326
	v_mov_b32_e32 v19, v38                                     // 0000001BBCB8: 7E260326
	v_mov_b32_e32 v18, v38                                     // 0000001BBCBC: 7E240326
	v_mov_b32_e32 v17, v38                                     // 0000001BBCC0: 7E220326
	v_mov_b32_e32 v14, v38                                     // 0000001BBCC4: 7E1C0326
	v_mov_b32_e32 v13, v38                                     // 0000001BBCC8: 7E1A0326
	v_mov_b32_e32 v12, v38                                     // 0000001BBCCC: 7E180326
	v_mov_b32_e32 v11, v38                                     // 0000001BBCD0: 7E160326
	v_mov_b32_e32 v10, v38                                     // 0000001BBCD4: 7E140326
	v_mov_b32_e32 v9, v38                                      // 0000001BBCD8: 7E120326
	v_mov_b32_e32 v6, v38                                      // 0000001BBCDC: 7E0C0326
	v_mov_b32_e32 v5, v38                                      // 0000001BBCE0: 7E0A0326
	v_mov_b32_e32 v4, v38                                      // 0000001BBCE4: 7E080326
	v_mov_b32_e32 v3, v38                                      // 0000001BBCE8: 7E060326
	v_mov_b32_e32 v2, v38                                      // 0000001BBCEC: 7E040326
	v_mov_b32_e32 v1, v38                                      // 0000001BBCF0: 7E020326
	v_mov_b32_e32 v77, v38                                     // 0000001BBCF4: 7E9A0326
	v_mov_b32_e32 v76, v38                                     // 0000001BBCF8: 7E980326
	v_mov_b32_e32 v75, v38                                     // 0000001BBCFC: 7E960326
	v_mov_b32_e32 v74, v38                                     // 0000001BBD00: 7E940326
	v_mov_b32_e32 v88, v38                                     // 0000001BBD04: 7EB00326
	v_mov_b32_e32 v73, v38                                     // 0000001BBD08: 7E920326
	s_cbranch_vccnz 1430                                       // 0000001BBD0C: BFA40596 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1968>
	v_cmp_gt_u32_e32 vcc_lo, 12, v89                           // 0000001BBD10: 7C98B28C
	s_lshl2_add_u32 s0, s3, s1                                 // 0000001BBD14: 87800103
	s_ashr_i32 s21, s20, 31                                    // 0000001BBD18: 86159F14
	v_dual_mov_b32 v65, 0 :: v_dual_lshlrev_b32 v0, 5, v0      // 0000001BBD1C: CA220080 41000085
	v_dual_cndmask_b32 v2, 0, v89 :: v_dual_lshlrev_b32 v3, 10, v7// 0000001BBD24: CA62B280 02020E8A
	s_add_i32 s31, s0, 1                                       // 0000001BBD2C: 811F8100
	s_lshl_b64 s[0:1], s[20:21], 11                            // 0000001BBD30: 84808B14
	s_add_i32 s30, s30, -4                                     // 0000001BBD34: 811EC41E
	s_add_u32 s0, s6, s0                                       // 0000001BBD38: 80000006
	v_dual_mov_b32 v66, v65 :: v_dual_lshlrev_b32 v1, 2, v89   // 0000001BBD3C: CA220141 4200B282
	s_load_b128 s[16:19], s[14:15], null                       // 0000001BBD44: F4080407 F8000000
	s_addc_u32 s1, s7, s1                                      // 0000001BBD4C: 82010107
	v_dual_mov_b32 v67, v65 :: v_dual_and_b32 v0, 0x60, v0     // 0000001BBD50: CA240141 430000FF 00000060
	.long 0xd7000005                                           // 0000001BBD5C: D7000005
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000001BBD60: 02020600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BBD64: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s1, 0, s0                    // 0000001BBD68: D5207C06 00010001
	v_lshl_or_b32 v1, v90, 6, v1                               // 0000001BBD70: D6560001 04050D5A
	.long 0xd7000000                                           // 0000001BBD78: D7000000
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000001BBD7C: 02020105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BBD80: BF870001
	v_add_co_ci_u32_e64 v93, null, 0, v6, s0                   // 0000001BBD84: D5207C5D 00020C80
	s_movk_i32 s0, 0x210                                       // 0000001BBD8C: B0000210
	v_dual_mov_b32 v68, v65 :: v_dual_add_nc_u32 v1, 0x1cc0, v1// 0000001BBD90: CA200141 440002FF 00001CC0
	v_xor_b32_e32 v5, 1, v7                                    // 0000001BBD9C: 3A0A0E81
	v_dual_mov_b32 v103, 0xf149f2ca :: v_dual_lshlrev_b32 v6, 5, v90// 0000001BBDA0: CA2200FF 6706B485 F149F2CA
	v_dual_mov_b32 v69, v65 :: v_dual_lshlrev_b32 v8, 1, v89   // 0000001BBDAC: CA220141 4508B281
	v_mad_u32_u24 v2, v2, s0, 0x400                            // 0000001BBDB4: D60B0002 03FC0102 00000400
	s_lshl_b64 s[0:1], s[20:21], 8                             // 0000001BBDC0: 84808814
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BBDC4: BF870009
	v_dual_mov_b32 v99, s1 :: v_dual_lshlrev_b32 v4, 9, v7     // 0000001BBDC8: CA220001 63040E89
	v_dual_mov_b32 v70, v65 :: v_dual_lshlrev_b32 v7, 8, v7    // 0000001BBDD0: CA220141 46060E88
	v_lshrrev_b32_e32 v92, 2, v89                              // 0000001BBDD8: 32B8B282
	v_dual_mov_b32 v87, 0xf149f2ca :: v_dual_add_nc_u32 v94, v1, v3// 0000001BBDDC: CA2000FF 575E0701 F149F2CA
	v_lshl_add_u32 v95, v5, 10, v1                             // 0000001BBDE8: D646005F 04051505
	v_or3_b32 v96, v4, v6, v8                                  // 0000001BBDF0: D6580060 04220D04
	v_lshl_or_b32 v97, v89, 5, v4                              // 0000001BBDF8: D6560061 04110B59
	v_or3_b32 v98, s0, v89, v91                                // 0000001BBE00: D6580062 056EB200
	v_dual_mov_b32 v71, v65 :: v_dual_add_nc_u32 v100, v2, v7  // 0000001BBE08: CA200141 47640F02
	v_dual_mov_b32 v72, v65 :: v_dual_mov_b32 v85, 0xf149f2ca  // 0000001BBE10: CA100141 485400FF F149F2CA
	v_dual_mov_b32 v86, 0xf149f2ca :: v_dual_mov_b32 v83, 0xf149f2ca// 0000001BBE1C: CA1000FF 565200FF F149F2CA
	v_dual_mov_b32 v78, 0xf149f2ca :: v_dual_mov_b32 v79, 0xf149f2ca// 0000001BBE28: CA1000FF 4E4E00FF F149F2CA
	v_dual_mov_b32 v80, 0xf149f2ca :: v_dual_mov_b32 v73, v65  // 0000001BBE34: CA1000FF 50480141 F149F2CA
	v_mov_b32_e32 v88, v65                                     // 0000001BBE40: 7EB00341
	v_mov_b32_e32 v74, v65                                     // 0000001BBE44: 7E940341
	v_mov_b32_e32 v75, v65                                     // 0000001BBE48: 7E960341
	v_mov_b32_e32 v76, v65                                     // 0000001BBE4C: 7E980341
	v_mov_b32_e32 v77, v65                                     // 0000001BBE50: 7E9A0341
	v_mov_b32_e32 v102, v65                                    // 0000001BBE54: 7ECC0341
	v_mov_b32_e32 v101, v65                                    // 0000001BBE58: 7ECA0341
	v_mov_b32_e32 v1, v65                                      // 0000001BBE5C: 7E020341
	v_mov_b32_e32 v2, v65                                      // 0000001BBE60: 7E040341
	v_mov_b32_e32 v3, v65                                      // 0000001BBE64: 7E060341
	v_mov_b32_e32 v4, v65                                      // 0000001BBE68: 7E080341
	v_mov_b32_e32 v5, v65                                      // 0000001BBE6C: 7E0A0341
	v_mov_b32_e32 v6, v65                                      // 0000001BBE70: 7E0C0341
	v_mov_b32_e32 v7, v65                                      // 0000001BBE74: 7E0E0341
	v_mov_b32_e32 v8, v65                                      // 0000001BBE78: 7E100341
	v_mov_b32_e32 v9, v65                                      // 0000001BBE7C: 7E120341
	v_mov_b32_e32 v10, v65                                     // 0000001BBE80: 7E140341
	v_mov_b32_e32 v11, v65                                     // 0000001BBE84: 7E160341
	v_mov_b32_e32 v12, v65                                     // 0000001BBE88: 7E180341
	v_mov_b32_e32 v13, v65                                     // 0000001BBE8C: 7E1A0341
	v_mov_b32_e32 v14, v65                                     // 0000001BBE90: 7E1C0341
	v_mov_b32_e32 v15, v65                                     // 0000001BBE94: 7E1E0341
	v_mov_b32_e32 v16, v65                                     // 0000001BBE98: 7E200341
	v_mov_b32_e32 v17, v65                                     // 0000001BBE9C: 7E220341
	v_mov_b32_e32 v18, v65                                     // 0000001BBEA0: 7E240341
	v_mov_b32_e32 v19, v65                                     // 0000001BBEA4: 7E260341
	v_mov_b32_e32 v20, v65                                     // 0000001BBEA8: 7E280341
	v_mov_b32_e32 v21, v65                                     // 0000001BBEAC: 7E2A0341
	v_mov_b32_e32 v22, v65                                     // 0000001BBEB0: 7E2C0341
	v_mov_b32_e32 v23, v65                                     // 0000001BBEB4: 7E2E0341
	v_mov_b32_e32 v24, v65                                     // 0000001BBEB8: 7E300341
	v_mov_b32_e32 v25, v65                                     // 0000001BBEBC: 7E320341
	v_mov_b32_e32 v26, v65                                     // 0000001BBEC0: 7E340341
	v_mov_b32_e32 v27, v65                                     // 0000001BBEC4: 7E360341
	v_mov_b32_e32 v28, v65                                     // 0000001BBEC8: 7E380341
	v_mov_b32_e32 v29, v65                                     // 0000001BBECC: 7E3A0341
	v_mov_b32_e32 v30, v65                                     // 0000001BBED0: 7E3C0341
	v_mov_b32_e32 v31, v65                                     // 0000001BBED4: 7E3E0341
	v_mov_b32_e32 v32, v65                                     // 0000001BBED8: 7E400341
	v_mov_b32_e32 v57, v65                                     // 0000001BBEDC: 7E720341
	v_mov_b32_e32 v58, v65                                     // 0000001BBEE0: 7E740341
	v_mov_b32_e32 v59, v65                                     // 0000001BBEE4: 7E760341
	v_mov_b32_e32 v60, v65                                     // 0000001BBEE8: 7E780341
	v_mov_b32_e32 v61, v65                                     // 0000001BBEEC: 7E7A0341
	v_mov_b32_e32 v62, v65                                     // 0000001BBEF0: 7E7C0341
	v_mov_b32_e32 v63, v65                                     // 0000001BBEF4: 7E7E0341
	v_mov_b32_e32 v64, v65                                     // 0000001BBEF8: 7E800341
	v_mov_b32_e32 v49, v65                                     // 0000001BBEFC: 7E620341
	v_mov_b32_e32 v50, v65                                     // 0000001BBF00: 7E640341
	v_mov_b32_e32 v51, v65                                     // 0000001BBF04: 7E660341
	v_mov_b32_e32 v52, v65                                     // 0000001BBF08: 7E680341
	v_mov_b32_e32 v53, v65                                     // 0000001BBF0C: 7E6A0341
	v_mov_b32_e32 v54, v65                                     // 0000001BBF10: 7E6C0341
	v_mov_b32_e32 v55, v65                                     // 0000001BBF14: 7E6E0341
	v_mov_b32_e32 v56, v65                                     // 0000001BBF18: 7E700341
	v_mov_b32_e32 v41, v65                                     // 0000001BBF1C: 7E520341
	v_mov_b32_e32 v42, v65                                     // 0000001BBF20: 7E540341
	v_mov_b32_e32 v43, v65                                     // 0000001BBF24: 7E560341
	v_mov_b32_e32 v44, v65                                     // 0000001BBF28: 7E580341
	v_mov_b32_e32 v45, v65                                     // 0000001BBF2C: 7E5A0341
	v_mov_b32_e32 v46, v65                                     // 0000001BBF30: 7E5C0341
	v_mov_b32_e32 v47, v65                                     // 0000001BBF34: 7E5E0341
	v_mov_b32_e32 v48, v65                                     // 0000001BBF38: 7E600341
	v_mov_b32_e32 v33, v65                                     // 0000001BBF3C: 7E420341
	v_mov_b32_e32 v34, v65                                     // 0000001BBF40: 7E440341
	v_mov_b32_e32 v35, v65                                     // 0000001BBF44: 7E460341
	v_mov_b32_e32 v36, v65                                     // 0000001BBF48: 7E480341
	v_mov_b32_e32 v37, v65                                     // 0000001BBF4C: 7E4A0341
	v_mov_b32_e32 v38, v65                                     // 0000001BBF50: 7E4C0341
	v_mov_b32_e32 v39, v65                                     // 0000001BBF54: 7E4E0341
	v_mov_b32_e32 v40, v65                                     // 0000001BBF58: 7E500341
	s_mov_b32 s21, 0                                           // 0000001BBF5C: BE950080
	v_cmp_eq_u32_e32 vcc_lo, 2, v92                            // 0000001BBF60: 7C94B882
	s_branch 239                                               // 0000001BBF64: BFA000EF <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x924>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001BBF68: 8C7E017E
	s_ashr_i32 s23, s22, 31                                    // 0000001BBF6C: 86179F16
	s_ashr_i32 s25, s24, 31                                    // 0000001BBF70: 86199F18
	s_lshl_b64 s[0:1], s[22:23], 9                             // 0000001BBF74: 84808916
	s_lshl_b64 s[22:23], s[24:25], 9                           // 0000001BBF78: 84968918
	.long 0xd700007f                                           // 0000001BBF7C: D700007F
	v_cndmask_b32_e32 v1, s0, v98, vcc_lo                      // 0000001BBF80: 0202C400
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BBF84: BF870001
	v_add_co_ci_u32_e64 v128, null, s1, v99, s0                // 0000001BBF88: D5207C80 0002C601
	s_ashr_i32 s17, s16, 31                                    // 0000001BBF90: 86119F10
	.long 0xd7000081                                           // 0000001BBF94: D7000081
	v_cndmask_b32_e32 v1, s22, v98, vcc_lo                     // 0000001BBF98: 0202C416
	s_lshl_b64 s[16:17], s[16:17], 9                           // 0000001BBF9C: 84908910
	.long 0xd73c007f                                           // 0000001BBFA0: D73C007F
	v_cndmask_b32_e32 v1, 3, v127, vcc_lo                      // 0000001BBFA4: 0202FE83
	v_add_co_ci_u32_e64 v130, null, s23, v99, s0               // 0000001BBFA8: D5207C82 0002C617
	.long 0xd7000083                                           // 0000001BBFB0: D7000083
	v_cndmask_b32_e32 v1, s16, v98, vcc_lo                     // 0000001BBFB4: 0202C410
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BBFB8: BF870001
	v_add_co_ci_u32_e64 v132, null, s17, v99, s0               // 0000001BBFBC: D5207C84 0002C611
	s_ashr_i32 s19, s18, 31                                    // 0000001BBFC4: 86139F12
	.long 0xd70000a1                                           // 0000001BBFC8: D70000A1
	v_cndmask_b32_e32 v1, s8, v127, vcc_lo                     // 0000001BBFCC: 0202FE08
	s_lshl_b64 s[18:19], s[18:19], 9                           // 0000001BBFD0: 84928912
	v_add_co_ci_u32_e64 v162, null, s9, v128, s0               // 0000001BBFD4: D5207CA2 00030009
	.long 0xd73c007f                                           // 0000001BBFDC: D73C007F
	v_cndmask_b32_e32 v1, 3, v129, vcc_lo                      // 0000001BBFE0: 02030283
	.long 0xd73c0081                                           // 0000001BBFE4: D73C0081
	v_cndmask_b32_e32 v1, 3, v131, vcc_lo                      // 0000001BBFE8: 02030683
	.long 0xd7000083                                           // 0000001BBFEC: D7000083
	v_cndmask_b32_e32 v1, s18, v98, vcc_lo                     // 0000001BBFF0: 0202C412
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BBFF4: BF870211
	v_add_co_ci_u32_e64 v132, null, s19, v99, s0               // 0000001BBFF8: D5207C84 0002C613
	.long 0xd70000a3                                           // 0000001BC000: D70000A3
	v_cndmask_b32_e32 v1, s8, v127, vcc_lo                     // 0000001BC004: 0202FE08
	v_bfe_u32 v111, v116, 16, 1                                // 0000001BC008: D610006F 02052174
	v_add_co_ci_u32_e64 v164, null, s9, v128, s0               // 0000001BC010: D5207CA4 00030009
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BC018: BF870224
	.long 0xd73c007f                                           // 0000001BC01C: D73C007F
	v_cndmask_b32_e32 v1, 3, v131, vcc_lo                      // 0000001BC020: 02030683
	.long 0xd70000a5                                           // 0000001BC024: D70000A5
	v_cndmask_b32_e32 v1, s8, v129, vcc_lo                     // 0000001BC028: 02030208
	v_add3_u32 v111, v116, v111, 0x7fff                        // 0000001BC02C: D655006F 03FEDF74 00007FFF
	v_add_co_ci_u32_e64 v166, null, s9, v130, s0               // 0000001BC038: D5207CA6 00030409
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC040: BF870094
	.long 0xd70000bd                                           // 0000001BC044: D70000BD
	v_cndmask_b32_e32 v1, s8, v127, vcc_lo                     // 0000001BC048: 0202FE08
	v_add_co_ci_u32_e64 v190, null, s9, v128, s0               // 0000001BC04C: D5207CBE 00030009
	ds_store_b16_d16_hi v96, v111 offset:448                   // 0000001BC054: DA8401C0 00006F60
	ds_load_b128 v[119:122], v97                               // 0000001BC05C: DBFC0000 77000061
	ds_load_b128 v[123:126], v97 offset:16                     // 0000001BC064: DBFC0010 7B000061
	s_clause 0x1f                                              // 0000001BC06C: BF85001F
	global_load_b64 v[127:128], v[161:162], off                // 0000001BC070: DC560000 7F7C00A1
	global_load_b64 v[135:136], v[161:162], off offset:128     // 0000001BC078: DC560080 877C00A1
	global_load_b64 v[143:144], v[161:162], off offset:256     // 0000001BC080: DC560100 8F7C00A1
	global_load_b64 v[151:152], v[161:162], off offset:384     // 0000001BC088: DC560180 977C00A1
	global_load_b64 v[129:130], v[163:164], off                // 0000001BC090: DC560000 817C00A3
	global_load_b64 v[137:138], v[163:164], off offset:128     // 0000001BC098: DC560080 897C00A3
	global_load_b64 v[145:146], v[163:164], off offset:256     // 0000001BC0A0: DC560100 917C00A3
	global_load_b64 v[153:154], v[163:164], off offset:384     // 0000001BC0A8: DC560180 997C00A3
	global_load_b64 v[131:132], v[165:166], off                // 0000001BC0B0: DC560000 837C00A5
	global_load_b64 v[139:140], v[165:166], off offset:128     // 0000001BC0B8: DC560080 8B7C00A5
	global_load_b64 v[147:148], v[165:166], off offset:256     // 0000001BC0C0: DC560100 937C00A5
	global_load_b64 v[155:156], v[165:166], off offset:384     // 0000001BC0C8: DC560180 9B7C00A5
	global_load_b64 v[133:134], v[189:190], off                // 0000001BC0D0: DC560000 857C00BD
	global_load_b64 v[141:142], v[189:190], off offset:128     // 0000001BC0D8: DC560080 8D7C00BD
	global_load_b64 v[149:150], v[189:190], off offset:256     // 0000001BC0E0: DC560100 957C00BD
	global_load_b64 v[157:158], v[189:190], off offset:384     // 0000001BC0E8: DC560180 9D7C00BD
	global_load_b64 v[159:160], v[161:162], off offset:512     // 0000001BC0F0: DC560200 9F7C00A1
	global_load_b64 v[167:168], v[161:162], off offset:640     // 0000001BC0F8: DC560280 A77C00A1
	global_load_b64 v[175:176], v[161:162], off offset:768     // 0000001BC100: DC560300 AF7C00A1
	global_load_b64 v[183:184], v[161:162], off offset:896     // 0000001BC108: DC560380 B77C00A1
	global_load_b64 v[161:162], v[163:164], off offset:512     // 0000001BC110: DC560200 A17C00A3
	global_load_b64 v[169:170], v[163:164], off offset:640     // 0000001BC118: DC560280 A97C00A3
	global_load_b64 v[177:178], v[163:164], off offset:768     // 0000001BC120: DC560300 B17C00A3
	global_load_b64 v[185:186], v[163:164], off offset:896     // 0000001BC128: DC560380 B97C00A3
	global_load_b64 v[163:164], v[165:166], off offset:512     // 0000001BC130: DC560200 A37C00A5
	global_load_b64 v[171:172], v[165:166], off offset:640     // 0000001BC138: DC560280 AB7C00A5
	global_load_b64 v[179:180], v[165:166], off offset:768     // 0000001BC140: DC560300 B37C00A5
	global_load_b64 v[187:188], v[165:166], off offset:896     // 0000001BC148: DC560380 BB7C00A5
	global_load_b64 v[165:166], v[189:190], off offset:512     // 0000001BC150: DC560200 A57C00BD
	global_load_b64 v[173:174], v[189:190], off offset:640     // 0000001BC158: DC560280 AD7C00BD
	global_load_b64 v[181:182], v[189:190], off offset:768     // 0000001BC160: DC560300 B57C00BD
	global_load_b64 v[189:190], v[189:190], off offset:896     // 0000001BC168: DC560380 BD7C00BD
	v_dual_fmac_f32 v84, v102, v81 :: v_dual_mul_f32 v57, v57, v110// 0000001BC170: C806A366 5438DD39
	v_dual_mul_f32 v58, v58, v112 :: v_dual_mul_f32 v59, v59, v114// 0000001BC178: C8C6E13A 3A3AE53B
	v_dual_mul_f32 v60, v60, v115 :: v_dual_mul_f32 v61, v61, v117// 0000001BC180: C8C6E73C 3C3CEB3D
	v_dual_mul_f32 v62, v62, v118 :: v_dual_mul_f32 v63, v63, v81// 0000001BC188: C8C6ED3E 3E3EA33F
	v_dual_mul_f32 v64, v64, v82 :: v_dual_mul_f32 v53, v53, v117// 0000001BC190: C8C6A540 4034EB35
	v_dual_mul_f32 v49, v49, v110 :: v_dual_mul_f32 v50, v50, v112// 0000001BC198: C8C6DD31 3132E132
	v_dual_mul_f32 v51, v51, v114 :: v_dual_mul_f32 v52, v52, v115// 0000001BC1A0: C8C6E533 3334E734
	v_dual_mul_f32 v54, v54, v118 :: v_dual_mul_f32 v55, v55, v81// 0000001BC1A8: C8C6ED36 3636A337
	v_dual_mul_f32 v56, v56, v82 :: v_dual_mul_f32 v45, v45, v117// 0000001BC1B0: C8C6A538 382CEB2D
	v_dual_mul_f32 v41, v41, v110 :: v_dual_mul_f32 v42, v42, v112// 0000001BC1B8: C8C6DD29 292AE12A
	v_dual_mul_f32 v43, v43, v114 :: v_dual_mul_f32 v44, v44, v115// 0000001BC1C0: C8C6E52B 2B2CE72C
	v_dual_mul_f32 v46, v46, v118 :: v_dual_mul_f32 v47, v47, v81// 0000001BC1C8: C8C6ED2E 2E2EA32F
	v_dual_mul_f32 v48, v48, v82 :: v_dual_mul_f32 v37, v37, v117// 0000001BC1D0: C8C6A530 3024EB25
	v_dual_mul_f32 v33, v33, v110 :: v_dual_mul_f32 v34, v34, v112// 0000001BC1D8: C8C6DD21 2122E122
	v_dual_mul_f32 v35, v35, v114 :: v_dual_mul_f32 v36, v36, v115// 0000001BC1E0: C8C6E523 2324E724
	v_dual_mul_f32 v38, v38, v118 :: v_dual_mul_f32 v39, v39, v81// 0000001BC1E8: C8C6ED26 2626A327
	v_dual_mul_f32 v40, v40, v82 :: v_dual_mul_f32 v29, v29, v117// 0000001BC1F0: C8C6A528 281CEB1D
	v_dual_mul_f32 v25, v25, v110 :: v_dual_mul_f32 v26, v26, v112// 0000001BC1F8: C8C6DD19 191AE11A
	v_dual_mul_f32 v27, v27, v114 :: v_dual_mul_f32 v28, v28, v115// 0000001BC200: C8C6E51B 1B1CE71C
	v_dual_mul_f32 v30, v30, v118 :: v_dual_mul_f32 v31, v31, v81// 0000001BC208: C8C6ED1E 1E1EA31F
	v_dual_mul_f32 v32, v32, v82 :: v_dual_mul_f32 v21, v21, v117// 0000001BC210: C8C6A520 2014EB15
	v_dual_mul_f32 v17, v17, v110 :: v_dual_mul_f32 v18, v18, v112// 0000001BC218: C8C6DD11 1112E112
	v_dual_mul_f32 v19, v19, v114 :: v_dual_mul_f32 v20, v20, v115// 0000001BC220: C8C6E513 1314E714
	v_dual_mul_f32 v22, v22, v118 :: v_dual_mul_f32 v23, v23, v81// 0000001BC228: C8C6ED16 1616A317
	v_dual_mul_f32 v24, v24, v82 :: v_dual_mul_f32 v13, v13, v117// 0000001BC230: C8C6A518 180CEB0D
	v_dual_mul_f32 v9, v9, v110 :: v_dual_mul_f32 v10, v10, v112// 0000001BC238: C8C6DD09 090AE10A
	v_dual_mul_f32 v11, v11, v114 :: v_dual_mul_f32 v12, v12, v115// 0000001BC240: C8C6E50B 0B0CE70C
	v_dual_mul_f32 v14, v14, v118 :: v_dual_mul_f32 v15, v15, v81// 0000001BC248: C8C6ED0E 0E0EA30F
	v_dual_mul_f32 v16, v16, v82 :: v_dual_mul_f32 v5, v5, v117// 0000001BC250: C8C6A510 1004EB05
	v_dual_mul_f32 v1, v1, v110 :: v_dual_mul_f32 v2, v2, v112 // 0000001BC258: C8C6DD01 0102E102
	v_dual_mul_f32 v3, v3, v114 :: v_dual_mul_f32 v4, v4, v115 // 0000001BC260: C8C6E503 0304E704
	v_dual_mul_f32 v6, v6, v118 :: v_dual_mul_f32 v7, v7, v81  // 0000001BC268: C8C6ED06 0606A307
	v_mul_f32_e32 v8, v8, v82                                  // 0000001BC270: 1010A508
	v_dual_fmac_f32 v73, v109, v110 :: v_dual_fmac_f32 v88, v108, v112// 0000001BC274: C800DD6D 4958E16C
	v_dual_fmac_f32 v74, v107, v114 :: v_dual_fmac_f32 v75, v106, v115// 0000001BC27C: C800E56B 4A4AE76A
	v_dual_fmac_f32 v76, v105, v117 :: v_dual_fmac_f32 v77, v104, v118// 0000001BC284: C800EB69 4C4CED68
	v_fma_f32 v101, v101, v82, v116                            // 0000001BC28C: D6130065 05D2A565
	v_mov_b32_e32 v102, v84                                    // 0000001BC294: 7ECC0354
	s_add_i32 s29, s29, -1                                     // 0000001BC298: 811DC11D
	s_add_i32 s31, s31, -16                                    // 0000001BC29C: 811FD01F
	s_mov_b32 s19, s7                                          // 0000001BC2A0: BE930007
	s_mov_b32 s18, s6                                          // 0000001BC2A4: BE920006
	s_mov_b32 s17, s5                                          // 0000001BC2A8: BE910005
	s_mov_b32 s16, s4                                          // 0000001BC2AC: BE900004
	s_cmp_lg_u32 s29, 0                                        // 0000001BC2B0: BF07801D
	s_waitcnt vmcnt(19) lgkmcnt(0)                             // 0000001BC2B4: BF894C07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[119:126], v[127:134], v[57:64]// 0000001BC2B8: CC414039 1CE6FF77
	s_waitcnt vmcnt(18)                                        // 0000001BC2C0: BF894BF7
	v_wmma_f32_16x16x16_bf16 v[49:56], v[119:126], v[135:142], v[49:56]// 0000001BC2C4: CC414031 1CC70F77
	s_waitcnt vmcnt(17)                                        // 0000001BC2CC: BF8947F7
	v_wmma_f32_16x16x16_bf16 v[41:48], v[119:126], v[143:150], v[41:48]// 0000001BC2D0: CC414029 1CA71F77
	s_waitcnt vmcnt(16)                                        // 0000001BC2D8: BF8943F7
	v_wmma_f32_16x16x16_bf16 v[33:40], v[119:126], v[151:158], v[33:40]// 0000001BC2DC: CC414021 1C872F77
	s_waitcnt vmcnt(3)                                         // 0000001BC2E4: BF890FF7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[119:126], v[159:166], v[25:32]// 0000001BC2E8: CC414019 1C673F77
	s_waitcnt vmcnt(2)                                         // 0000001BC2F0: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[17:24], v[119:126], v[167:174], v[17:24]// 0000001BC2F4: CC414011 1C474F77
	s_waitcnt vmcnt(1)                                         // 0000001BC2FC: BF8907F7
	v_wmma_f32_16x16x16_bf16 v[9:16], v[119:126], v[175:182], v[9:16]// 0000001BC300: CC414009 1C275F77
	s_waitcnt vmcnt(0)                                         // 0000001BC308: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[1:8], v[119:126], v[183:190], v[1:8]// 0000001BC30C: CC414001 1C076F77
	s_barrier                                                  // 0000001BC314: BFBD0000
	buffer_gl0_inv                                             // 0000001BC318: E0AC0000 00000000
	s_cbranch_scc0 1040                                        // 0000001BC320: BFA10410 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1964>
	s_mov_b32 s0, s21                                          // 0000001BC324: BE800015
	s_add_i32 s21, s21, 4                                      // 0000001BC328: 81158415
	v_dual_mov_b32 v104, v77 :: v_dual_mov_b32 v105, v76       // 0000001BC32C: CA10014D 6868014C
	s_min_i32 s4, s21, s30                                     // 0000001BC334: 89041E15
	v_dual_mov_b32 v106, v75 :: v_dual_mov_b32 v107, v74       // 0000001BC338: CA10014B 6A6A014A
	s_ashr_i32 s5, s4, 31                                      // 0000001BC340: 86059F04
	v_dual_mov_b32 v108, v88 :: v_dual_mov_b32 v109, v73       // 0000001BC344: CA100158 6C6C0149
	s_lshl_b64 s[4:5], s[4:5], 2                               // 0000001BC34C: 84848204
	v_dual_mov_b32 v111, v80 :: v_dual_mov_b32 v116, v78       // 0000001BC350: CA100150 6F74014E
	s_add_u32 s4, s14, s4                                      // 0000001BC358: 8004040E
	s_addc_u32 s5, s15, s5                                     // 0000001BC35C: 8205050F
	s_cmp_lt_i32 s0, s28                                       // 0000001BC360: BF041C00
	s_load_b128 s[4:7], s[4:5], null                           // 0000001BC364: F4080102 F8000000
	s_cselect_b32 s1, s26, s27                                 // 0000001BC36C: 98011B1A
	s_cmp_lt_i32 s0, s3                                        // 0000001BC370: BF040300
	v_mov_b32_e32 v113, v79                                    // 0000001BC374: 7EE2034F
	s_waitcnt lgkmcnt(0)                                       // 0000001BC378: BF89FC07
	s_cselect_b32 s22, s16, s1                                 // 0000001BC37C: 98160110
	s_add_i32 s1, s0, 1                                        // 0000001BC380: 81018100
	v_dual_mov_b32 v118, v83 :: v_dual_mov_b32 v117, v86       // 0000001BC384: CA100153 76740156
	s_cmp_lt_i32 s1, s28                                       // 0000001BC38C: BF041C01
	v_dual_mov_b32 v115, v85 :: v_dual_mov_b32 v114, v87       // 0000001BC390: CA100155 73720157
	s_cselect_b32 s16, s26, s27                                // 0000001BC398: 98101B1A
	s_cmp_lt_i32 s1, s3                                        // 0000001BC39C: BF040301
	v_dual_mov_b32 v112, v103 :: v_dual_mov_b32 v73, s22       // 0000001BC3A0: CA100167 70480016
	s_cselect_b32 s24, s17, s16                                // 0000001BC3A8: 98181011
	s_add_i32 s1, s0, 2                                        // 0000001BC3AC: 81018200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001BC3B0: BF8704D9
	s_cmp_lt_i32 s1, s28                                       // 0000001BC3B4: BF041C01
	s_cselect_b32 s16, s26, s27                                // 0000001BC3B8: 98101B1A
	s_cmp_lt_i32 s1, s3                                        // 0000001BC3BC: BF040301
	s_cselect_b32 s16, s18, s16                                // 0000001BC3C0: 98101012
	s_add_i32 s1, s0, 3                                        // 0000001BC3C4: 81018300
	s_cmp_lt_i32 s1, s28                                       // 0000001BC3C8: BF041C01
	s_cselect_b32 s17, s26, s27                                // 0000001BC3CC: 98111B1A
	s_cmp_lt_i32 s1, s3                                        // 0000001BC3D0: BF040301
	s_mov_b32 s1, exec_lo                                      // 0000001BC3D4: BE81007E
	s_cselect_b32 s18, s19, s17                                // 0000001BC3D8: 98121113
	v_cmpx_lt_i32_e32 0, v92                                   // 0000001BC3DC: 7D82B880
	s_cbranch_execz 11                                         // 0000001BC3E0: BFA5000B <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xa10>
	.long 0xd44d0000                                           // 0000001BC3E4: D44D0000
	v_cndmask_b32_e32 v1, 1, v92, vcc_lo                       // 0000001BC3E8: 0202B881
	s_and_saveexec_b32 s17, s0                                 // 0000001BC3EC: BE912000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001BC3F0: BF870009
	s_xor_b32 s0, exec_lo, s17                                 // 0000001BC3F4: 8D00117E
	v_mov_b32_e32 v73, s16                                     // 0000001BC3F8: 7E920210
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC3FC: BF870001
	v_cndmask_b32_e32 v73, s18, v73, vcc_lo                    // 0000001BC400: 02929212
	s_and_not1_saveexec_b32 s0, s0                             // 0000001BC404: BE803000
	v_mov_b32_e32 v73, s24                                     // 0000001BC408: 7E920218
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001BC40C: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC410: BF870099
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001BC414: 8C7E017E
	v_ashrrev_i32_e32 v74, 31, v73                             // 0000001BC418: 3494929F
	ds_load_b128 v[81:84], v100                                // 0000001BC41C: DBFC0000 51000064
	ds_load_b128 v[85:88], v100 offset:16                      // 0000001BC424: DBFC0010 55000064
	ds_load_b128 v[119:122], v100 offset:32                    // 0000001BC42C: DBFC0020 77000064
	ds_load_b128 v[123:126], v100 offset:48                    // 0000001BC434: DBFC0030 7B000064
	ds_load_b128 v[131:134], v100 offset:80                    // 0000001BC43C: DBFC0050 83000064
	ds_load_b128 v[127:130], v100 offset:64                    // 0000001BC444: DBFC0040 7F000064
	ds_load_b128 v[163:166], v100 offset:112                   // 0000001BC44C: DBFC0070 A3000064
	ds_load_b128 v[159:162], v100 offset:96                    // 0000001BC454: DBFC0060 9F000064
	ds_load_b128 v[179:182], v100 offset:144                   // 0000001BC45C: DBFC0090 B3000064
	ds_load_b128 v[175:178], v100 offset:128                   // 0000001BC464: DBFC0080 AF000064
	.long 0xd73c0049                                           // 0000001BC46C: D73C0049
	v_cndmask_b32_e32 v1, 12, v73, vcc_lo                      // 0000001BC470: 0202928C
	ds_load_b128 v[195:198], v100 offset:176                   // 0000001BC474: DBFC00B0 C3000064
	ds_load_b128 v[191:194], v100 offset:160                   // 0000001BC47C: DBFC00A0 BF000064
	ds_load_b128 v[211:214], v100 offset:208                   // 0000001BC484: DBFC00D0 D3000064
	ds_load_b128 v[207:210], v100 offset:192                   // 0000001BC48C: DBFC00C0 CF000064
	ds_load_b128 v[227:230], v100 offset:240                   // 0000001BC494: DBFC00F0 E3000064
	ds_load_b128 v[223:226], v100 offset:224                   // 0000001BC49C: DBFC00E0 DF000064
	.long 0xd7000049                                           // 0000001BC4A4: D7000049
	v_cndmask_b32_e32 v1, v0, v73, vcc_lo                      // 0000001BC4A8: 02029300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC4AC: BF870001
	v_add_co_ci_u32_e64 v74, null, v93, v74, s0                // 0000001BC4B0: D5207C4A 0002955D
	.long 0xd4440000                                           // 0000001BC4B8: D4440000
	v_cndmask_b32_e32 v1, s31, v89, vcc_lo                     // 0000001BC4BC: 0202B21F
	s_clause 0xf                                               // 0000001BC4C0: BF85000F
	global_load_b128 v[139:142], v[73:74], off offset:16       // 0000001BC4C4: DC5E0010 8B7C0049
	global_load_b128 v[135:138], v[73:74], off                 // 0000001BC4CC: DC5E0000 877C0049
	global_load_b128 v[147:150], v[73:74], off offset:144      // 0000001BC4D4: DC5E0090 937C0049
	global_load_b128 v[143:146], v[73:74], off offset:128      // 0000001BC4DC: DC5E0080 8F7C0049
	global_load_b128 v[155:158], v[73:74], off offset:272      // 0000001BC4E4: DC5E0110 9B7C0049
	global_load_b128 v[151:154], v[73:74], off offset:256      // 0000001BC4EC: DC5E0100 977C0049
	global_load_b128 v[171:174], v[73:74], off offset:400      // 0000001BC4F4: DC5E0190 AB7C0049
	global_load_b128 v[167:170], v[73:74], off offset:384      // 0000001BC4FC: DC5E0180 A77C0049
	global_load_b128 v[187:190], v[73:74], off offset:528      // 0000001BC504: DC5E0210 BB7C0049
	global_load_b128 v[183:186], v[73:74], off offset:512      // 0000001BC50C: DC5E0200 B77C0049
	global_load_b128 v[203:206], v[73:74], off offset:656      // 0000001BC514: DC5E0290 CB7C0049
	global_load_b128 v[199:202], v[73:74], off offset:640      // 0000001BC51C: DC5E0280 C77C0049
	global_load_b128 v[219:222], v[73:74], off offset:784      // 0000001BC524: DC5E0310 DB7C0049
	global_load_b128 v[215:218], v[73:74], off offset:768      // 0000001BC52C: DC5E0300 D77C0049
	global_load_b128 v[235:238], v[73:74], off offset:912      // 0000001BC534: DC5E0390 EB7C0049
	global_load_b128 v[231:234], v[73:74], off offset:896      // 0000001BC53C: DC5E0380 E77C0049
	s_waitcnt vmcnt(14) lgkmcnt(14)                            // 0000001BC544: BF8938E7
	v_wmma_f32_16x16x16_bf16 v[73:80], v[81:88], v[135:142], v[65:72]// 0000001BC548: CC414049 1D070F51
	s_waitcnt vmcnt(12) lgkmcnt(12)                            // 0000001BC550: BF8930C7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BC554: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[73:80], v[119:126], v[143:150], v[73:80]// 0000001BC558: CC414049 1D271F77
	s_waitcnt vmcnt(10) lgkmcnt(10)                            // 0000001BC560: BF8928A7
	v_wmma_f32_16x16x16_bf16 v[73:80], v[127:134], v[151:158], v[73:80]// 0000001BC564: CC414049 1D272F7F
	s_waitcnt vmcnt(8) lgkmcnt(8)                              // 0000001BC56C: BF892087
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BC570: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[73:80], v[159:166], v[167:174], v[73:80]// 0000001BC574: CC414049 1D274F9F
	s_waitcnt vmcnt(6) lgkmcnt(6)                              // 0000001BC57C: BF891867
	v_wmma_f32_16x16x16_bf16 v[73:80], v[175:182], v[183:190], v[73:80]// 0000001BC580: CC414049 1D276FAF
	s_waitcnt vmcnt(4) lgkmcnt(4)                              // 0000001BC588: BF891047
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BC58C: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[73:80], v[191:198], v[199:206], v[73:80]// 0000001BC590: CC414049 1D278FBF
	s_waitcnt vmcnt(2) lgkmcnt(2)                              // 0000001BC598: BF890827
	v_wmma_f32_16x16x16_bf16 v[73:80], v[207:214], v[215:222], v[73:80]// 0000001BC59C: CC414049 1D27AFCF
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001BC5A4: BF890007
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC5A8: BF870001
	v_wmma_f32_16x16x16_bf16 v[73:80], v[223:230], v[231:238], v[73:80]// 0000001BC5AC: CC414049 1D27CFDF
	ds_store_2addr_b32 v94, v73, v74 offset1:32                // 0000001BC5B4: D8382000 004A495E
	ds_store_2addr_b32 v94, v75, v76 offset0:64 offset1:96     // 0000001BC5BC: D8386040 004C4B5E
	ds_store_2addr_b32 v94, v77, v78 offset0:128 offset1:160   // 0000001BC5C4: D838A080 004E4D5E
	ds_store_2addr_b32 v94, v79, v80 offset0:192 offset1:224   // 0000001BC5CC: D838E0C0 00504F5E
	s_waitcnt lgkmcnt(0)                                       // 0000001BC5D4: BF89FC07
	s_barrier                                                  // 0000001BC5D8: BFBD0000
	buffer_gl0_inv                                             // 0000001BC5DC: E0AC0000 00000000
	ds_load_2addr_b32 v[86:87], v95 offset1:32                 // 0000001BC5E4: D8DC2000 5600005F
	s_waitcnt lgkmcnt(0)                                       // 0000001BC5EC: BF89FC07
	v_add_f32_e32 v73, v73, v86                                // 0000001BC5F0: 0692AD49
	ds_load_2addr_b32 v[85:86], v95 offset0:64 offset1:96      // 0000001BC5F4: D8DC6040 5500005F
	ds_load_2addr_b32 v[83:84], v95 offset0:128 offset1:160    // 0000001BC5FC: D8DCA080 5300005F
	v_mul_f32_e32 v110, 0x3d800000, v73                        // 0000001BC604: 10DC92FF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC60C: BF870091
	v_cndmask_b32_e64 v73, 0xf149f2ca, v110, s0                // 0000001BC610: D5010049 0002DCFF F149F2CA
	v_mov_b32_dpp v81, v73 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BC61C: 7EA202FA FF096149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC624: BF870091
	v_max_f32_e32 v81, v81, v81                                // 0000001BC628: 20A2A351
	v_max_f32_e32 v73, v73, v81                                // 0000001BC62C: 2092A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC630: BF870091
	v_mov_b32_dpp v81, v73 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BC634: 7EA202FA FF096249
	v_max_f32_e32 v81, v81, v81                                // 0000001BC63C: 20A2A351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC640: BF870091
	v_max_f32_e32 v73, v73, v81                                // 0000001BC644: 2092A349
	v_mov_b32_dpp v81, v73 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BC648: 7EA202FA FF096449
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001BC650: BF8700B1
	v_max_f32_e32 v88, v81, v81                                // 0000001BC654: 20B0A351
	ds_load_2addr_b32 v[81:82], v95 offset0:192 offset1:224    // 0000001BC658: D8DCE0C0 5100005F
	v_dual_max_f32 v73, v73, v88 :: v_dual_mov_b32 v88, 0      // 0000001BC660: CA90B149 49580080
	v_mov_b32_dpp v103, v73 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BC668: 7ECE02FA FF096849
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC670: BF870001
	v_max3_f32 v103, v112, v73, v103                           // 0000001BC674: D61C0067 059E9370
	v_mov_b32_e32 v73, 0                                       // 0000001BC67C: 7E920280
	s_and_saveexec_b32 s17, s0                                 // 0000001BC680: BE912000
	s_cbranch_execz 31                                         // 0000001BC684: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd04>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC688: BF870092
	v_sub_f32_e32 v73, v110, v103                              // 0000001BC68C: 0892CF6E
	v_mul_f32_e32 v110, 0x3fb8aa3b, v73                        // 0000001BC690: 10DC92FF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001BC698: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v73, vcc_lo              // 0000001BC69C: 020292FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BC6A4: BF8700A2
	v_fma_f32 v119, 0x3fb8aa3b, v73, -v110                     // 0000001BC6A8: D6130077 85BA92FF 3FB8AA3B
	v_rndne_f32_e32 v120, v110                                 // 0000001BC6B4: 7EF0476E
	v_dual_fmac_f32 v119, 0x32a5705f, v73 :: v_dual_sub_f32 v110, v110, v120// 0000001BC6B8: C80A92FF 776EF16E 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC6C4: BF870121
	v_add_f32_e32 v110, v110, v119                             // 0000001BC6C8: 06DCEF6E
	v_cvt_i32_f32_e32 v119, v120                               // 0000001BC6CC: 7EEE1178
	v_exp_f32_e32 v110, v110                                   // 0000001BC6D0: 7EDC4B6E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC6D4: BF870095
	.long 0xd71c006e                                           // 0000001BC6D8: D71C006E
	v_cndmask_b32_e32 v1, v110, v119, vcc_lo                   // 0000001BC6DC: 0202EF6E
	v_cndmask_b32_e64 v110, 0, v110, s1                        // 0000001BC6E0: D501006E 0006DC80
	.long 0xd41e0001                                           // 0000001BC6E8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v73, vcc_lo              // 0000001BC6EC: 020292FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC6F4: BF870001
	v_cndmask_b32_e64 v73, 0x7f800000, v110, s1                // 0000001BC6F8: D5010049 0006DCFF 7F800000
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BC704: 8C7E117E
	v_mov_b32_e32 v110, 0                                      // 0000001BC708: 7EDC0280
	s_mov_b32 s17, exec_lo                                     // 0000001BC70C: BE91007E
	v_cmpx_lt_f32_e32 0xefa18f08, v112                         // 0000001BC710: 7D22E0FF EFA18F08
	s_cbranch_execz 30                                         // 0000001BC718: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd94>
	v_sub_f32_e32 v110, v112, v103                             // 0000001BC71C: 08DCCF70
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC720: BF870121
	v_mul_f32_e32 v112, 0x3fb8aa3b, v110                       // 0000001BC724: 10E0DCFF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001BC72C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v110, vcc_lo             // 0000001BC730: 0202DCFF C2CE8ED0
	v_fma_f32 v119, 0x3fb8aa3b, v110, -v112                    // 0000001BC738: D6130077 85C2DCFF 3FB8AA3B
	v_rndne_f32_e32 v120, v112                                 // 0000001BC744: 7EF04770
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC748: BF870091
	v_dual_fmac_f32 v119, 0x32a5705f, v110 :: v_dual_sub_f32 v112, v112, v120// 0000001BC74C: C80ADCFF 7770F170 32A5705F
	v_add_f32_e32 v112, v112, v119                             // 0000001BC758: 06E0EF70
	v_cvt_i32_f32_e32 v119, v120                               // 0000001BC75C: 7EEE1178
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001BC760: BF870292
	v_exp_f32_e32 v112, v112                                   // 0000001BC764: 7EE04B70
	.long 0xd71c0070                                           // 0000001BC768: D71C0070
	v_cndmask_b32_e32 v1, v112, v119, vcc_lo                   // 0000001BC76C: 0202EF70
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BC770: BF8700A1
	v_cndmask_b32_e64 v112, 0, v112, s1                        // 0000001BC774: D5010070 0006E080
	.long 0xd41e0001                                           // 0000001BC77C: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v110, vcc_lo             // 0000001BC780: 0202DCFF 42B17218
	v_cndmask_b32_e64 v110, 0x7f800000, v112, s1               // 0000001BC788: D501006E 0006E0FF 7F800000
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BC794: 8C7E117E
	v_add_f32_e32 v74, v74, v87                                // 0000001BC798: 0694AF4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC79C: BF870091
	v_mul_f32_e32 v74, 0x3d800000, v74                         // 0000001BC7A0: 109494FF 3D800000
	v_cndmask_b32_e64 v87, 0xf149f2ca, v74, s0                 // 0000001BC7A8: D5010057 000294FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC7B4: BF870091
	v_mov_b32_dpp v112, v87 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BC7B8: 7EE002FA FF096157
	v_max_f32_e32 v112, v112, v112                             // 0000001BC7C0: 20E0E170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC7C4: BF870091
	v_max_f32_e32 v87, v87, v112                               // 0000001BC7C8: 20AEE157
	v_mov_b32_dpp v112, v87 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BC7CC: 7EE002FA FF096257
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC7D4: BF870091
	v_max_f32_e32 v112, v112, v112                             // 0000001BC7D8: 20E0E170
	v_max_f32_e32 v87, v87, v112                               // 0000001BC7DC: 20AEE157
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC7E0: BF870091
	v_mov_b32_dpp v112, v87 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BC7E4: 7EE002FA FF096457
	v_max_f32_e32 v112, v112, v112                             // 0000001BC7EC: 20E0E170
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC7F0: BF870121
	v_max_f32_e32 v87, v87, v112                               // 0000001BC7F4: 20AEE157
	v_bfe_u32 v112, v73, 16, 1                                 // 0000001BC7F8: D6100070 02052149
	v_mov_b32_dpp v119, v87 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BC800: 7EEE02FA FF096857
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BC808: BF870112
	v_add3_u32 v112, v73, v112, 0x7fff                         // 0000001BC80C: D6550070 03FEE149 00007FFF
	v_max3_f32 v87, v114, v87, v119                            // 0000001BC818: D61C0057 05DEAF72
	ds_store_b16_d16_hi v96, v112                              // 0000001BC820: DA840000 00007060
	s_and_saveexec_b32 s17, s0                                 // 0000001BC828: BE912000
	s_cbranch_execz 31                                         // 0000001BC82C: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xeac>
	v_sub_f32_e32 v74, v74, v87                                // 0000001BC830: 0894AF4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC834: BF870121
	v_mul_f32_e32 v88, 0x3fb8aa3b, v74                         // 0000001BC838: 10B094FF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001BC840: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v74, vcc_lo              // 0000001BC844: 020294FF C2CE8ED0
	v_fma_f32 v112, 0x3fb8aa3b, v74, -v88                      // 0000001BC84C: D6130070 856294FF 3FB8AA3B
	v_rndne_f32_e32 v119, v88                                  // 0000001BC858: 7EEE4758
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BC85C: BF870112
	v_fmac_f32_e32 v112, 0x32a5705f, v74                       // 0000001BC860: 56E094FF 32A5705F
	v_sub_f32_e32 v88, v88, v119                               // 0000001BC868: 08B0EF58
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC86C: BF870121
	v_add_f32_e32 v88, v88, v112                               // 0000001BC870: 06B0E158
	v_cvt_i32_f32_e32 v112, v119                               // 0000001BC874: 7EE01177
	v_exp_f32_e32 v88, v88                                     // 0000001BC878: 7EB04B58
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC87C: BF870095
	.long 0xd71c0058                                           // 0000001BC880: D71C0058
	v_cndmask_b32_e32 v1, v88, v112, vcc_lo                    // 0000001BC884: 0202E158
	v_cndmask_b32_e64 v88, 0, v88, s1                          // 0000001BC888: D5010058 0006B080
	.long 0xd41e0001                                           // 0000001BC890: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v74, vcc_lo              // 0000001BC894: 020294FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC89C: BF870001
	v_cndmask_b32_e64 v88, 0x7f800000, v88, s1                 // 0000001BC8A0: D5010058 0006B0FF 7F800000
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BC8AC: 8C7E117E
	v_mov_b32_e32 v74, 0                                       // 0000001BC8B0: 7E940280
	v_mov_b32_e32 v112, 0                                      // 0000001BC8B4: 7EE00280
	s_mov_b32 s17, exec_lo                                     // 0000001BC8B8: BE91007E
	v_cmpx_lt_f32_e32 0xefa18f08, v114                         // 0000001BC8BC: 7D22E4FF EFA18F08
	s_cbranch_execz 31                                         // 0000001BC8C4: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xf44>
	v_sub_f32_e32 v112, v114, v87                              // 0000001BC8C8: 08E0AF72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC8CC: BF870121
	v_mul_f32_e32 v114, 0x3fb8aa3b, v112                       // 0000001BC8D0: 10E4E0FF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001BC8D8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v112, vcc_lo             // 0000001BC8DC: 0202E0FF C2CE8ED0
	v_fma_f32 v119, 0x3fb8aa3b, v112, -v114                    // 0000001BC8E4: D6130077 85CAE0FF 3FB8AA3B
	v_rndne_f32_e32 v120, v114                                 // 0000001BC8F0: 7EF04772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BC8F4: BF870112
	v_fmac_f32_e32 v119, 0x32a5705f, v112                      // 0000001BC8F8: 56EEE0FF 32A5705F
	v_sub_f32_e32 v114, v114, v120                             // 0000001BC900: 08E4F172
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC904: BF870121
	v_add_f32_e32 v114, v114, v119                             // 0000001BC908: 06E4EF72
	v_cvt_i32_f32_e32 v119, v120                               // 0000001BC90C: 7EEE1178
	v_exp_f32_e32 v114, v114                                   // 0000001BC910: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC914: BF870095
	.long 0xd71c0072                                           // 0000001BC918: D71C0072
	v_cndmask_b32_e32 v1, v114, v119, vcc_lo                   // 0000001BC91C: 0202EF72
	v_cndmask_b32_e64 v114, 0, v114, s1                        // 0000001BC920: D5010072 0006E480
	.long 0xd41e0001                                           // 0000001BC928: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v112, vcc_lo             // 0000001BC92C: 0202E0FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BC934: BF870001
	v_cndmask_b32_e64 v112, 0x7f800000, v114, s1               // 0000001BC938: D5010070 0006E4FF 7F800000
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BC944: 8C7E117E
	s_waitcnt lgkmcnt(3)                                       // 0000001BC948: BF89FC37
	v_add_f32_e32 v75, v75, v85                                // 0000001BC94C: 0696AB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC950: BF870091
	v_mul_f32_e32 v75, 0x3d800000, v75                         // 0000001BC954: 109696FF 3D800000
	v_cndmask_b32_e64 v85, 0xf149f2ca, v75, s0                 // 0000001BC95C: D5010055 000296FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC968: BF870091
	v_mov_b32_dpp v114, v85 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BC96C: 7EE402FA FF096155
	v_max_f32_e32 v114, v114, v114                             // 0000001BC974: 20E4E572
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC978: BF870091
	v_max_f32_e32 v85, v85, v114                               // 0000001BC97C: 20AAE555
	v_mov_b32_dpp v114, v85 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BC980: 7EE402FA FF096255
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC988: BF870091
	v_max_f32_e32 v114, v114, v114                             // 0000001BC98C: 20E4E572
	v_max_f32_e32 v85, v85, v114                               // 0000001BC990: 20AAE555
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BC994: BF870091
	v_mov_b32_dpp v114, v85 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BC998: 7EE402FA FF096455
	v_max_f32_e32 v114, v114, v114                             // 0000001BC9A0: 20E4E572
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC9A4: BF870121
	v_max_f32_e32 v85, v85, v114                               // 0000001BC9A8: 20AAE555
	v_bfe_u32 v114, v88, 16, 1                                 // 0000001BC9AC: D6100072 02052158
	v_mov_b32_dpp v119, v85 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BC9B4: 7EEE02FA FF096855
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BC9BC: BF870112
	v_add3_u32 v114, v88, v114, 0x7fff                         // 0000001BC9C0: D6550072 03FEE558 00007FFF
	v_max3_f32 v85, v115, v85, v119                            // 0000001BC9CC: D61C0055 05DEAB73
	ds_store_b16_d16_hi v96, v114 offset:64                    // 0000001BC9D4: DA840040 00007260
	s_and_saveexec_b32 s17, s0                                 // 0000001BC9DC: BE912000
	s_cbranch_execz 30                                         // 0000001BC9E0: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x105c>
	v_sub_f32_e32 v74, v75, v85                                // 0000001BC9E4: 0894AB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BC9E8: BF870121
	v_mul_f32_e32 v75, 0x3fb8aa3b, v74                         // 0000001BC9EC: 109694FF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001BC9F4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v74, vcc_lo              // 0000001BC9F8: 020294FF C2CE8ED0
	v_fma_f32 v114, 0x3fb8aa3b, v74, -v75                      // 0000001BCA00: D6130072 852E94FF 3FB8AA3B
	v_rndne_f32_e32 v119, v75                                  // 0000001BCA0C: 7EEE474B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCA10: BF870091
	v_dual_fmac_f32 v114, 0x32a5705f, v74 :: v_dual_sub_f32 v75, v75, v119// 0000001BCA14: C80A94FF 724AEF4B 32A5705F
	v_add_f32_e32 v75, v75, v114                               // 0000001BCA20: 0696E54B
	v_cvt_i32_f32_e32 v114, v119                               // 0000001BCA24: 7EE41177
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001BCA28: BF870292
	v_exp_f32_e32 v75, v75                                     // 0000001BCA2C: 7E964B4B
	.long 0xd71c004b                                           // 0000001BCA30: D71C004B
	v_cndmask_b32_e32 v1, v75, v114, vcc_lo                    // 0000001BCA34: 0202E54B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BCA38: BF8700A1
	v_cndmask_b32_e64 v75, 0, v75, s1                          // 0000001BCA3C: D501004B 00069680
	.long 0xd41e0001                                           // 0000001BCA44: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v74, vcc_lo              // 0000001BCA48: 020294FF 42B17218
	v_cndmask_b32_e64 v74, 0x7f800000, v75, s1                 // 0000001BCA50: D501004A 000696FF 7F800000
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BCA5C: 8C7E117E
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v114, 0            // 0000001BCA60: CA100080 4B720080
	s_mov_b32 s17, exec_lo                                     // 0000001BCA68: BE91007E
	v_cmpx_lt_f32_e32 0xefa18f08, v115                         // 0000001BCA6C: 7D22E6FF EFA18F08
	s_cbranch_execz 31                                         // 0000001BCA74: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x10f4>
	v_sub_f32_e32 v114, v115, v85                              // 0000001BCA78: 08E4AB73
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCA7C: BF870121
	v_mul_f32_e32 v115, 0x3fb8aa3b, v114                       // 0000001BCA80: 10E6E4FF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001BCA88: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v114, vcc_lo             // 0000001BCA8C: 0202E4FF C2CE8ED0
	v_fma_f32 v119, 0x3fb8aa3b, v114, -v115                    // 0000001BCA94: D6130077 85CEE4FF 3FB8AA3B
	v_rndne_f32_e32 v120, v115                                 // 0000001BCAA0: 7EF04773
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BCAA4: BF870112
	v_fmac_f32_e32 v119, 0x32a5705f, v114                      // 0000001BCAA8: 56EEE4FF 32A5705F
	v_sub_f32_e32 v115, v115, v120                             // 0000001BCAB0: 08E6F173
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCAB4: BF870121
	v_add_f32_e32 v115, v115, v119                             // 0000001BCAB8: 06E6EF73
	v_cvt_i32_f32_e32 v119, v120                               // 0000001BCABC: 7EEE1178
	v_exp_f32_e32 v115, v115                                   // 0000001BCAC0: 7EE64B73
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCAC4: BF870095
	.long 0xd71c0073                                           // 0000001BCAC8: D71C0073
	v_cndmask_b32_e32 v1, v115, v119, vcc_lo                   // 0000001BCACC: 0202EF73
	v_cndmask_b32_e64 v115, 0, v115, s1                        // 0000001BCAD0: D5010073 0006E680
	.long 0xd41e0001                                           // 0000001BCAD8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v114, vcc_lo             // 0000001BCADC: 0202E4FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BCAE4: BF870001
	v_cndmask_b32_e64 v114, 0x7f800000, v115, s1               // 0000001BCAE8: D5010072 0006E6FF 7F800000
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BCAF4: 8C7E117E
	v_add_f32_e32 v76, v76, v86                                // 0000001BCAF8: 0698AD4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCAFC: BF870091
	v_mul_f32_e32 v76, 0x3d800000, v76                         // 0000001BCB00: 109898FF 3D800000
	v_cndmask_b32_e64 v86, 0xf149f2ca, v76, s0                 // 0000001BCB08: D5010056 000298FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCB14: BF870091
	v_mov_b32_dpp v115, v86 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BCB18: 7EE602FA FF096156
	v_max_f32_e32 v115, v115, v115                             // 0000001BCB20: 20E6E773
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCB24: BF870091
	v_max_f32_e32 v86, v86, v115                               // 0000001BCB28: 20ACE756
	v_mov_b32_dpp v115, v86 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BCB2C: 7EE602FA FF096256
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCB34: BF870091
	v_max_f32_e32 v115, v115, v115                             // 0000001BCB38: 20E6E773
	v_max_f32_e32 v86, v86, v115                               // 0000001BCB3C: 20ACE756
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCB40: BF870091
	v_mov_b32_dpp v115, v86 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BCB44: 7EE602FA FF096456
	v_max_f32_e32 v115, v115, v115                             // 0000001BCB4C: 20E6E773
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCB50: BF870121
	v_max_f32_e32 v86, v86, v115                               // 0000001BCB54: 20ACE756
	v_bfe_u32 v115, v74, 16, 1                                 // 0000001BCB58: D6100073 0205214A
	v_mov_b32_dpp v119, v86 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BCB60: 7EEE02FA FF096856
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BCB68: BF870112
	v_add3_u32 v115, v74, v115, 0x7fff                         // 0000001BCB6C: D6550073 03FEE74A 00007FFF
	v_max3_f32 v86, v117, v86, v119                            // 0000001BCB78: D61C0056 05DEAD75
	ds_store_b16_d16_hi v96, v115 offset:128                   // 0000001BCB80: DA840080 00007360
	s_and_saveexec_b32 s17, s0                                 // 0000001BCB88: BE912000
	s_cbranch_execz 31                                         // 0000001BCB8C: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x120c>
	v_sub_f32_e32 v75, v76, v86                                // 0000001BCB90: 0896AD4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCB94: BF870121
	v_mul_f32_e32 v76, 0x3fb8aa3b, v75                         // 0000001BCB98: 109896FF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001BCBA0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v75, vcc_lo              // 0000001BCBA4: 020296FF C2CE8ED0
	v_fma_f32 v115, 0x3fb8aa3b, v75, -v76                      // 0000001BCBAC: D6130073 853296FF 3FB8AA3B
	v_rndne_f32_e32 v119, v76                                  // 0000001BCBB8: 7EEE474C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BCBBC: BF870112
	v_fmac_f32_e32 v115, 0x32a5705f, v75                       // 0000001BCBC0: 56E696FF 32A5705F
	v_sub_f32_e32 v76, v76, v119                               // 0000001BCBC8: 0898EF4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCBCC: BF870121
	v_add_f32_e32 v76, v76, v115                               // 0000001BCBD0: 0698E74C
	v_cvt_i32_f32_e32 v115, v119                               // 0000001BCBD4: 7EE61177
	v_exp_f32_e32 v76, v76                                     // 0000001BCBD8: 7E984B4C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCBDC: BF870095
	.long 0xd71c004c                                           // 0000001BCBE0: D71C004C
	v_cndmask_b32_e32 v1, v76, v115, vcc_lo                    // 0000001BCBE4: 0202E74C
	v_cndmask_b32_e64 v76, 0, v76, s1                          // 0000001BCBE8: D501004C 00069880
	.long 0xd41e0001                                           // 0000001BCBF0: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v75, vcc_lo              // 0000001BCBF4: 020296FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BCBFC: BF870001
	v_cndmask_b32_e64 v75, 0x7f800000, v76, s1                 // 0000001BCC00: D501004B 000698FF 7F800000
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BCC0C: 8C7E117E
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v115, 0            // 0000001BCC10: CA100080 4C720080
	s_mov_b32 s17, exec_lo                                     // 0000001BCC18: BE91007E
	v_cmpx_lt_f32_e32 0xefa18f08, v117                         // 0000001BCC1C: 7D22EAFF EFA18F08
	s_cbranch_execz 31                                         // 0000001BCC24: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x12a4>
	v_sub_f32_e32 v115, v117, v86                              // 0000001BCC28: 08E6AD75
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCC2C: BF870121
	v_mul_f32_e32 v117, 0x3fb8aa3b, v115                       // 0000001BCC30: 10EAE6FF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001BCC38: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v115, vcc_lo             // 0000001BCC3C: 0202E6FF C2CE8ED0
	v_fma_f32 v119, 0x3fb8aa3b, v115, -v117                    // 0000001BCC44: D6130077 85D6E6FF 3FB8AA3B
	v_rndne_f32_e32 v120, v117                                 // 0000001BCC50: 7EF04775
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BCC54: BF870112
	v_fmac_f32_e32 v119, 0x32a5705f, v115                      // 0000001BCC58: 56EEE6FF 32A5705F
	v_sub_f32_e32 v117, v117, v120                             // 0000001BCC60: 08EAF175
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCC64: BF870121
	v_add_f32_e32 v117, v117, v119                             // 0000001BCC68: 06EAEF75
	v_cvt_i32_f32_e32 v119, v120                               // 0000001BCC6C: 7EEE1178
	v_exp_f32_e32 v117, v117                                   // 0000001BCC70: 7EEA4B75
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCC74: BF870095
	.long 0xd71c0075                                           // 0000001BCC78: D71C0075
	v_cndmask_b32_e32 v1, v117, v119, vcc_lo                   // 0000001BCC7C: 0202EF75
	v_cndmask_b32_e64 v117, 0, v117, s1                        // 0000001BCC80: D5010075 0006EA80
	.long 0xd41e0001                                           // 0000001BCC88: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v115, vcc_lo             // 0000001BCC8C: 0202E6FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BCC94: BF870001
	v_cndmask_b32_e64 v115, 0x7f800000, v117, s1               // 0000001BCC98: D5010073 0006EAFF 7F800000
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BCCA4: 8C7E117E
	s_waitcnt lgkmcnt(4)                                       // 0000001BCCA8: BF89FC47
	v_add_f32_e32 v77, v77, v83                                // 0000001BCCAC: 069AA74D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCCB0: BF870091
	v_mul_f32_e32 v77, 0x3d800000, v77                         // 0000001BCCB4: 109A9AFF 3D800000
	v_cndmask_b32_e64 v83, 0xf149f2ca, v77, s0                 // 0000001BCCBC: D5010053 00029AFF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCCC8: BF870091
	v_mov_b32_dpp v117, v83 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BCCCC: 7EEA02FA FF096153
	v_max_f32_e32 v117, v117, v117                             // 0000001BCCD4: 20EAEB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCCD8: BF870091
	v_max_f32_e32 v83, v83, v117                               // 0000001BCCDC: 20A6EB53
	v_mov_b32_dpp v117, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BCCE0: 7EEA02FA FF096253
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCCE8: BF870091
	v_max_f32_e32 v117, v117, v117                             // 0000001BCCEC: 20EAEB75
	v_max_f32_e32 v83, v83, v117                               // 0000001BCCF0: 20A6EB53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCCF4: BF870091
	v_mov_b32_dpp v117, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BCCF8: 7EEA02FA FF096453
	v_max_f32_e32 v117, v117, v117                             // 0000001BCD00: 20EAEB75
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCD04: BF870121
	v_max_f32_e32 v83, v83, v117                               // 0000001BCD08: 20A6EB53
	v_bfe_u32 v117, v75, 16, 1                                 // 0000001BCD0C: D6100075 0205214B
	v_mov_b32_dpp v119, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BCD14: 7EEE02FA FF096853
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BCD1C: BF870112
	v_add3_u32 v117, v75, v117, 0x7fff                         // 0000001BCD20: D6550075 03FEEB4B 00007FFF
	v_max3_f32 v83, v118, v83, v119                            // 0000001BCD2C: D61C0053 05DEA776
	ds_store_b16_d16_hi v96, v117 offset:192                   // 0000001BCD34: DA8400C0 00007560
	s_and_saveexec_b32 s17, s0                                 // 0000001BCD3C: BE912000
	s_cbranch_execz 31                                         // 0000001BCD40: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x13c0>
	v_sub_f32_e32 v76, v77, v83                                // 0000001BCD44: 0898A74D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCD48: BF870121
	v_mul_f32_e32 v77, 0x3fb8aa3b, v76                         // 0000001BCD4C: 109A98FF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001BCD54: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v76, vcc_lo              // 0000001BCD58: 020298FF C2CE8ED0
	v_fma_f32 v117, 0x3fb8aa3b, v76, -v77                      // 0000001BCD60: D6130075 853698FF 3FB8AA3B
	v_rndne_f32_e32 v119, v77                                  // 0000001BCD6C: 7EEE474D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BCD70: BF870112
	v_fmac_f32_e32 v117, 0x32a5705f, v76                       // 0000001BCD74: 56EA98FF 32A5705F
	v_sub_f32_e32 v77, v77, v119                               // 0000001BCD7C: 089AEF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCD80: BF870121
	v_add_f32_e32 v77, v77, v117                               // 0000001BCD84: 069AEB4D
	v_cvt_i32_f32_e32 v117, v119                               // 0000001BCD88: 7EEA1177
	v_exp_f32_e32 v77, v77                                     // 0000001BCD8C: 7E9A4B4D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCD90: BF870095
	.long 0xd71c004d                                           // 0000001BCD94: D71C004D
	v_cndmask_b32_e32 v1, v77, v117, vcc_lo                    // 0000001BCD98: 0202EB4D
	v_cndmask_b32_e64 v77, 0, v77, s1                          // 0000001BCD9C: D501004D 00069A80
	.long 0xd41e0001                                           // 0000001BCDA4: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v76, vcc_lo              // 0000001BCDA8: 020298FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BCDB0: BF870001
	v_cndmask_b32_e64 v76, 0x7f800000, v77, s1                 // 0000001BCDB4: D501004C 00069AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BCDC0: 8C7E117E
	v_mov_b32_e32 v77, 0                                       // 0000001BCDC4: 7E9A0280
	v_mov_b32_e32 v117, 0                                      // 0000001BCDC8: 7EEA0280
	s_mov_b32 s17, exec_lo                                     // 0000001BCDCC: BE91007E
	v_cmpx_lt_f32_e32 0xefa18f08, v118                         // 0000001BCDD0: 7D22ECFF EFA18F08
	s_cbranch_execz 30                                         // 0000001BCDD8: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1454>
	v_sub_f32_e32 v117, v118, v83                              // 0000001BCDDC: 08EAA776
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCDE0: BF870121
	v_mul_f32_e32 v118, 0x3fb8aa3b, v117                       // 0000001BCDE4: 10ECEAFF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001BCDEC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v117, vcc_lo             // 0000001BCDF0: 0202EAFF C2CE8ED0
	v_fma_f32 v119, 0x3fb8aa3b, v117, -v118                    // 0000001BCDF8: D6130077 85DAEAFF 3FB8AA3B
	v_rndne_f32_e32 v120, v118                                 // 0000001BCE04: 7EF04776
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCE08: BF870091
	v_dual_fmac_f32 v119, 0x32a5705f, v117 :: v_dual_sub_f32 v118, v118, v120// 0000001BCE0C: C80AEAFF 7776F176 32A5705F
	v_add_f32_e32 v118, v118, v119                             // 0000001BCE18: 06ECEF76
	v_cvt_i32_f32_e32 v119, v120                               // 0000001BCE1C: 7EEE1178
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001BCE20: BF870292
	v_exp_f32_e32 v118, v118                                   // 0000001BCE24: 7EEC4B76
	.long 0xd71c0076                                           // 0000001BCE28: D71C0076
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                   // 0000001BCE2C: 0202EF76
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BCE30: BF8700A1
	v_cndmask_b32_e64 v118, 0, v118, s1                        // 0000001BCE34: D5010076 0006EC80
	.long 0xd41e0001                                           // 0000001BCE3C: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v117, vcc_lo             // 0000001BCE40: 0202EAFF 42B17218
	v_cndmask_b32_e64 v117, 0x7f800000, v118, s1               // 0000001BCE48: D5010075 0006ECFF 7F800000
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BCE54: 8C7E117E
	v_add_f32_e32 v78, v78, v84                                // 0000001BCE58: 069CA94E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCE5C: BF870091
	v_mul_f32_e32 v84, 0x3d800000, v78                         // 0000001BCE60: 10A89CFF 3D800000
	v_cndmask_b32_e64 v78, 0xf149f2ca, v84, s0                 // 0000001BCE68: D501004E 0002A8FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCE74: BF870091
	v_mov_b32_dpp v118, v78 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BCE78: 7EEC02FA FF09614E
	v_max_f32_e32 v118, v118, v118                             // 0000001BCE80: 20ECED76
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCE84: BF870091
	v_max_f32_e32 v78, v78, v118                               // 0000001BCE88: 209CED4E
	v_mov_b32_dpp v118, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BCE8C: 7EEC02FA FF09624E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCE94: BF870091
	v_max_f32_e32 v118, v118, v118                             // 0000001BCE98: 20ECED76
	v_max_f32_e32 v78, v78, v118                               // 0000001BCE9C: 209CED4E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCEA0: BF870091
	v_mov_b32_dpp v118, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BCEA4: 7EEC02FA FF09644E
	v_max_f32_e32 v118, v118, v118                             // 0000001BCEAC: 20ECED76
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCEB0: BF870121
	v_max_f32_e32 v78, v78, v118                               // 0000001BCEB4: 209CED4E
	v_bfe_u32 v118, v76, 16, 1                                 // 0000001BCEB8: D6100076 0205214C
	v_mov_b32_dpp v119, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BCEC0: 7EEE02FA FF09684E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BCEC8: BF870112
	v_add3_u32 v118, v76, v118, 0x7fff                         // 0000001BCECC: D6550076 03FEED4C 00007FFF
	v_max3_f32 v78, v116, v78, v119                            // 0000001BCED8: D61C004E 05DE9D74
	ds_store_b16_d16_hi v96, v118 offset:256                   // 0000001BCEE0: DA840100 00007660
	s_and_saveexec_b32 s17, s0                                 // 0000001BCEE8: BE912000
	s_cbranch_execz 31                                         // 0000001BCEEC: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x156c>
	v_sub_f32_e32 v77, v84, v78                                // 0000001BCEF0: 089A9D54
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCEF4: BF870121
	v_mul_f32_e32 v84, 0x3fb8aa3b, v77                         // 0000001BCEF8: 10A89AFF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001BCF00: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v77, vcc_lo              // 0000001BCF04: 02029AFF C2CE8ED0
	v_fma_f32 v118, 0x3fb8aa3b, v77, -v84                      // 0000001BCF0C: D6130076 85529AFF 3FB8AA3B
	v_rndne_f32_e32 v119, v84                                  // 0000001BCF18: 7EEE4754
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BCF1C: BF870112
	v_fmac_f32_e32 v118, 0x32a5705f, v77                       // 0000001BCF20: 56EC9AFF 32A5705F
	v_sub_f32_e32 v84, v84, v119                               // 0000001BCF28: 08A8EF54
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCF2C: BF870121
	v_add_f32_e32 v84, v84, v118                               // 0000001BCF30: 06A8ED54
	v_cvt_i32_f32_e32 v118, v119                               // 0000001BCF34: 7EEC1177
	v_exp_f32_e32 v84, v84                                     // 0000001BCF38: 7EA84B54
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCF3C: BF870095
	.long 0xd71c0054                                           // 0000001BCF40: D71C0054
	v_cndmask_b32_e32 v1, v84, v118, vcc_lo                    // 0000001BCF44: 0202ED54
	v_cndmask_b32_e64 v84, 0, v84, s1                          // 0000001BCF48: D5010054 0006A880
	.long 0xd41e0001                                           // 0000001BCF50: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v77, vcc_lo              // 0000001BCF54: 02029AFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BCF5C: BF870001
	v_cndmask_b32_e64 v77, 0x7f800000, v84, s1                 // 0000001BCF60: D501004D 0006A8FF 7F800000
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BCF6C: 8C7E117E
	v_mov_b32_e32 v84, 0                                       // 0000001BCF70: 7EA80280
	v_mov_b32_e32 v118, 0                                      // 0000001BCF74: 7EEC0280
	s_mov_b32 s17, exec_lo                                     // 0000001BCF78: BE91007E
	v_cmpx_lt_f32_e32 0xefa18f08, v116                         // 0000001BCF7C: 7D22E8FF EFA18F08
	s_cbranch_execz 31                                         // 0000001BCF84: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1604>
	v_sub_f32_e32 v116, v116, v78                              // 0000001BCF88: 08E89D74
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCF8C: BF870121
	v_mul_f32_e32 v118, 0x3fb8aa3b, v116                       // 0000001BCF90: 10ECE8FF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001BCF98: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v116, vcc_lo             // 0000001BCF9C: 0202E8FF C2CE8ED0
	v_fma_f32 v119, 0x3fb8aa3b, v116, -v118                    // 0000001BCFA4: D6130077 85DAE8FF 3FB8AA3B
	v_rndne_f32_e32 v120, v118                                 // 0000001BCFB0: 7EF04776
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BCFB4: BF870112
	v_fmac_f32_e32 v119, 0x32a5705f, v116                      // 0000001BCFB8: 56EEE8FF 32A5705F
	v_sub_f32_e32 v118, v118, v120                             // 0000001BCFC0: 08ECF176
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BCFC4: BF870121
	v_add_f32_e32 v118, v118, v119                             // 0000001BCFC8: 06ECEF76
	v_cvt_i32_f32_e32 v119, v120                               // 0000001BCFCC: 7EEE1178
	v_exp_f32_e32 v118, v118                                   // 0000001BCFD0: 7EEC4B76
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BCFD4: BF870095
	.long 0xd71c0076                                           // 0000001BCFD8: D71C0076
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                   // 0000001BCFDC: 0202EF76
	v_cndmask_b32_e64 v118, 0, v118, s1                        // 0000001BCFE0: D5010076 0006EC80
	.long 0xd41e0001                                           // 0000001BCFE8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v116, vcc_lo             // 0000001BCFEC: 0202E8FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BCFF4: BF870001
	v_cndmask_b32_e64 v118, 0x7f800000, v118, s1               // 0000001BCFF8: D5010076 0006ECFF 7F800000
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BD004: 8C7E117E
	s_waitcnt lgkmcnt(5)                                       // 0000001BD008: BF89FC57
	v_add_f32_e32 v79, v79, v81                                // 0000001BD00C: 069EA34F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD010: BF870091
	v_mul_f32_e32 v81, 0x3d800000, v79                         // 0000001BD014: 10A29EFF 3D800000
	v_cndmask_b32_e64 v79, 0xf149f2ca, v81, s0                 // 0000001BD01C: D501004F 0002A2FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD028: BF870091
	v_mov_b32_dpp v116, v79 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD02C: 7EE802FA FF09614F
	v_max_f32_e32 v116, v116, v116                             // 0000001BD034: 20E8E974
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD038: BF870091
	v_max_f32_e32 v79, v79, v116                               // 0000001BD03C: 209EE94F
	v_mov_b32_dpp v116, v79 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD040: 7EE802FA FF09624F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD048: BF870091
	v_max_f32_e32 v116, v116, v116                             // 0000001BD04C: 20E8E974
	v_max_f32_e32 v79, v79, v116                               // 0000001BD050: 209EE94F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD054: BF870091
	v_mov_b32_dpp v116, v79 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD058: 7EE802FA FF09644F
	v_max_f32_e32 v116, v116, v116                             // 0000001BD060: 20E8E974
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BD064: BF870121
	v_max_f32_e32 v79, v79, v116                               // 0000001BD068: 209EE94F
	v_bfe_u32 v116, v77, 16, 1                                 // 0000001BD06C: D6100074 0205214D
	v_mov_b32_dpp v119, v79 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD074: 7EEE02FA FF09684F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BD07C: BF870112
	v_add3_u32 v116, v77, v116, 0x7fff                         // 0000001BD080: D6550074 03FEE94D 00007FFF
	v_max3_f32 v79, v113, v79, v119                            // 0000001BD08C: D61C004F 05DE9F71
	ds_store_b16_d16_hi v96, v116 offset:320                   // 0000001BD094: DA840140 00007460
	s_and_saveexec_b32 s17, s0                                 // 0000001BD09C: BE912000
	s_cbranch_execz 31                                         // 0000001BD0A0: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1720>
	v_sub_f32_e32 v81, v81, v79                                // 0000001BD0A4: 08A29F51
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD0A8: BF870091
	v_mul_f32_e32 v84, 0x3fb8aa3b, v81                         // 0000001BD0AC: 10A8A2FF 3FB8AA3B
	v_fma_f32 v116, 0x3fb8aa3b, v81, -v84                      // 0000001BD0B4: D6130074 8552A2FF 3FB8AA3B
	v_rndne_f32_e32 v119, v84                                  // 0000001BD0C0: 7EEE4754
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BD0C4: BF870112
	v_fmac_f32_e32 v116, 0x32a5705f, v81                       // 0000001BD0C8: 56E8A2FF 32A5705F
	v_sub_f32_e32 v84, v84, v119                               // 0000001BD0D0: 08A8EF54
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001BD0D4: BF8701B1
	v_add_f32_e32 v84, v84, v116                               // 0000001BD0D8: 06A8E954
	v_cvt_i32_f32_e32 v116, v119                               // 0000001BD0DC: 7EE81177
	.long 0xd41b0001                                           // 0000001BD0E0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v81, vcc_lo              // 0000001BD0E4: 0202A2FF C2CE8ED0
	v_exp_f32_e32 v84, v84                                     // 0000001BD0EC: 7EA84B54
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD0F0: BF870095
	.long 0xd71c0054                                           // 0000001BD0F4: D71C0054
	v_cndmask_b32_e32 v1, v84, v116, vcc_lo                    // 0000001BD0F8: 0202E954
	v_cndmask_b32_e64 v84, 0, v84, s1                          // 0000001BD0FC: D5010054 0006A880
	.long 0xd41e0001                                           // 0000001BD104: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v81, vcc_lo              // 0000001BD108: 0202A2FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BD110: BF870001
	v_cndmask_b32_e64 v84, 0x7f800000, v84, s1                 // 0000001BD114: D5010054 0006A8FF 7F800000
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BD120: 8C7E117E
	v_dual_mov_b32 v116, 0 :: v_dual_mov_b32 v81, 0            // 0000001BD124: CA100080 74500080
	s_mov_b32 s17, exec_lo                                     // 0000001BD12C: BE91007E
	v_cmpx_lt_f32_e32 0xefa18f08, v113                         // 0000001BD130: 7D22E2FF EFA18F08
	s_cbranch_execz 31                                         // 0000001BD138: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x17b8>
	v_sub_f32_e32 v81, v113, v79                               // 0000001BD13C: 08A29F71
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BD140: BF870121
	v_mul_f32_e32 v113, 0x3fb8aa3b, v81                        // 0000001BD144: 10E2A2FF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001BD14C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v81, vcc_lo              // 0000001BD150: 0202A2FF C2CE8ED0
	v_fma_f32 v119, 0x3fb8aa3b, v81, -v113                     // 0000001BD158: D6130077 85C6A2FF 3FB8AA3B
	v_rndne_f32_e32 v120, v113                                 // 0000001BD164: 7EF04771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BD168: BF870112
	v_fmac_f32_e32 v119, 0x32a5705f, v81                       // 0000001BD16C: 56EEA2FF 32A5705F
	v_sub_f32_e32 v113, v113, v120                             // 0000001BD174: 08E2F171
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BD178: BF870121
	v_add_f32_e32 v113, v113, v119                             // 0000001BD17C: 06E2EF71
	v_cvt_i32_f32_e32 v119, v120                               // 0000001BD180: 7EEE1178
	v_exp_f32_e32 v113, v113                                   // 0000001BD184: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD188: BF870095
	.long 0xd71c0071                                           // 0000001BD18C: D71C0071
	v_cndmask_b32_e32 v1, v113, v119, vcc_lo                   // 0000001BD190: 0202EF71
	v_cndmask_b32_e64 v113, 0, v113, s1                        // 0000001BD194: D5010071 0006E280
	.long 0xd41e0001                                           // 0000001BD19C: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v81, vcc_lo              // 0000001BD1A0: 0202A2FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BD1A8: BF870001
	v_cndmask_b32_e64 v81, 0x7f800000, v113, s1                // 0000001BD1AC: D5010051 0006E2FF 7F800000
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001BD1B8: 8C7E117E
	v_add_f32_e32 v80, v80, v82                                // 0000001BD1BC: 06A0A550
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD1C0: BF870091
	v_mul_f32_e32 v82, 0x3d800000, v80                         // 0000001BD1C4: 10A4A0FF 3D800000
	v_cndmask_b32_e64 v80, 0xf149f2ca, v82, s0                 // 0000001BD1CC: D5010050 0002A4FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD1D8: BF870091
	v_mov_b32_dpp v113, v80 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD1DC: 7EE202FA FF096150
	v_max_f32_e32 v113, v113, v113                             // 0000001BD1E4: 20E2E371
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD1E8: BF870091
	v_max_f32_e32 v80, v80, v113                               // 0000001BD1EC: 20A0E350
	v_mov_b32_dpp v113, v80 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD1F0: 7EE202FA FF096250
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD1F8: BF870091
	v_max_f32_e32 v113, v113, v113                             // 0000001BD1FC: 20E2E371
	v_max_f32_e32 v80, v80, v113                               // 0000001BD200: 20A0E350
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD204: BF870091
	v_mov_b32_dpp v113, v80 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD208: 7EE202FA FF096450
	v_max_f32_e32 v113, v113, v113                             // 0000001BD210: 20E2E371
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BD214: BF870121
	v_max_f32_e32 v80, v80, v113                               // 0000001BD218: 20A0E350
	v_bfe_u32 v113, v84, 16, 1                                 // 0000001BD21C: D6100071 02052154
	v_mov_b32_dpp v119, v80 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD224: 7EEE02FA FF096850
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BD22C: BF870112
	v_add3_u32 v113, v84, v113, 0x7fff                         // 0000001BD230: D6550071 03FEE354 00007FFF
	v_max3_f32 v80, v111, v80, v119                            // 0000001BD23C: D61C0050 05DEA16F
	ds_store_b16_d16_hi v96, v113 offset:384                   // 0000001BD244: DA840180 00007160
	s_and_saveexec_b32 s1, s0                                  // 0000001BD24C: BE812000
	s_cbranch_execz 30                                         // 0000001BD250: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x18cc>
	v_sub_f32_e32 v82, v82, v80                                // 0000001BD254: 08A4A152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD258: BF870091
	v_mul_f32_e32 v113, 0x3fb8aa3b, v82                        // 0000001BD25C: 10E2A4FF 3FB8AA3B
	v_fma_f32 v116, 0x3fb8aa3b, v82, -v113                     // 0000001BD264: D6130074 85C6A4FF 3FB8AA3B
	v_rndne_f32_e32 v119, v113                                 // 0000001BD270: 7EEE4771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BD274: BF870121
	v_dual_sub_f32 v113, v113, v119 :: v_dual_fmac_f32 v116, 0x32a5705f, v82// 0000001BD278: C940EF71 7174A4FF 32A5705F
	.long 0xd41b0000                                           // 0000001BD284: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v82, vcc_lo              // 0000001BD288: 0202A4FF C2CE8ED0
	v_add_f32_e32 v113, v113, v116                             // 0000001BD290: 06E2E971
	v_cvt_i32_f32_e32 v116, v119                               // 0000001BD294: 7EE81177
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001BD298: BF870292
	v_exp_f32_e32 v113, v113                                   // 0000001BD29C: 7EE24B71
	.long 0xd71c0071                                           // 0000001BD2A0: D71C0071
	v_cndmask_b32_e32 v1, v113, v116, vcc_lo                   // 0000001BD2A4: 0202E971
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BD2A8: BF8700A1
	v_cndmask_b32_e64 v113, 0, v113, s0                        // 0000001BD2AC: D5010071 0002E280
	.long 0xd41e0000                                           // 0000001BD2B4: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v82, vcc_lo              // 0000001BD2B8: 0202A4FF 42B17218
	v_cndmask_b32_e64 v116, 0x7f800000, v113, s0               // 0000001BD2C0: D5010074 0002E2FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001BD2CC: 8C7E017E
	v_mov_b32_e32 v82, 0                                       // 0000001BD2D0: 7EA40280
	s_mov_b32 s1, exec_lo                                      // 0000001BD2D4: BE81007E
	v_cmpx_lt_f32_e32 0xefa18f08, v111                         // 0000001BD2D8: 7D22DEFF EFA18F08
	s_cbranch_execz 64289                                      // 0000001BD2E0: BFA5FB21 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x568>
	v_sub_f32_e32 v82, v111, v80                               // 0000001BD2E4: 08A4A16F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BD2E8: BF870121
	v_mul_f32_e32 v111, 0x3fb8aa3b, v82                        // 0000001BD2EC: 10DEA4FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001BD2F4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v82, vcc_lo              // 0000001BD2F8: 0202A4FF C2CE8ED0
	v_fma_f32 v113, 0x3fb8aa3b, v82, -v111                     // 0000001BD300: D6130071 85BEA4FF 3FB8AA3B
	v_rndne_f32_e32 v119, v111                                 // 0000001BD30C: 7EEE476F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BD310: BF870112
	v_fmac_f32_e32 v113, 0x32a5705f, v82                       // 0000001BD314: 56E2A4FF 32A5705F
	v_sub_f32_e32 v111, v111, v119                             // 0000001BD31C: 08DEEF6F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BD320: BF870121
	v_add_f32_e32 v111, v111, v113                             // 0000001BD324: 06DEE36F
	v_cvt_i32_f32_e32 v113, v119                               // 0000001BD328: 7EE21177
	v_exp_f32_e32 v111, v111                                   // 0000001BD32C: 7EDE4B6F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BD330: BF870095
	.long 0xd71c006f                                           // 0000001BD334: D71C006F
	v_cndmask_b32_e32 v1, v111, v113, vcc_lo                   // 0000001BD338: 0202E36F
	v_cndmask_b32_e64 v111, 0, v111, s0                        // 0000001BD33C: D501006F 0002DE80
	.long 0xd41e0000                                           // 0000001BD344: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v82, vcc_lo              // 0000001BD348: 0202A4FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BD350: BF870001
	v_cndmask_b32_e64 v82, 0x7f800000, v111, s0                // 0000001BD354: D5010052 0002DEFF 7F800000
	s_branch 64257                                             // 0000001BD360: BFA0FB01 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi2EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x568>
	v_mov_b32_e32 v8, v91                                      // 0000001BD364: 7E10035B
	s_mul_i32 s0, s20, 12                                      // 0000001BD368: 96008C14
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BD36C: BF870001
	v_or_b32_e32 v7, v8, v89                                   // 0000001BD370: 380EB308
	v_or_b32_e32 v0, s0, v90                                   // 0000001BD374: 3800B400
	v_mov_b32_dpp v79, v74 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD378: 7E9E02FA FF09614A
	v_mov_b32_dpp v83, v75 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD380: 7EA602FA FF09614B
	v_mov_b32_dpp v85, v77 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD388: 7EAA02FA FF09614D
	v_mov_b32_dpp v84, v76 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD390: 7EA802FA FF09614C
	v_lshlrev_b32_e32 v0, 8, v0                                // 0000001BD398: 30000088
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BD39C: BF870214
	v_dual_mov_b32 v8, 0 :: v_dual_add_f32 v83, v75, v83       // 0000001BD3A0: CA080080 0852A74B
	v_add_f32_e32 v77, v77, v85                                // 0000001BD3A8: 069AAB4D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BD3AC: BF870193
	v_add_nc_u32_e32 v23, 0x400, v0                            // 0000001BD3B0: 4A2E00FF 00000400
	v_mad_i64_i32 v[7:8], null, 0x1800, s2, v[7:8]             // 0000001BD3B8: D6FF7C07 041C04FF 00001800
	v_ashrrev_i32_e32 v16, 31, v0                              // 0000001BD3C4: 3420009F
	v_add_nc_u32_e32 v31, 0x600, v0                            // 0000001BD3C8: 4A3E00FF 00000600
	v_add_nc_u32_e32 v39, 0x800, v0                            // 0000001BD3D0: 4A4E00FF 00000800
	v_ashrrev_i32_e32 v24, 31, v23                             // 0000001BD3D8: 34302E9F
	v_or_b32_e32 v65, 0x200, v0                                // 0000001BD3DC: 388200FF 00000200
	v_add_f32_dpp v83, v83, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD3E4: 06A6A6FA FF096253
	v_ashrrev_i32_e32 v32, 31, v31                             // 0000001BD3EC: 34403E9F
	.long 0xd7006a0f                                           // 0000001BD3F0: D7006A0F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000001BD3F4: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BD3F8: BF8700A1
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 0000001BD3FC: D5207C10 01AA2108
	.long 0xd7006a17                                           // 0000001BD404: D7006A17
	v_cndmask_b32_e32 v1, v7, v23, vcc_lo                      // 0000001BD408: 02022F07
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 0000001BD40C: D5207C18 01AA3108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001BD414: BF870233
	.long 0xd73c000f                                           // 0000001BD418: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000001BD41C: 02021E81
	v_add_nc_u32_e32 v0, 0xa00, v0                             // 0000001BD420: 4A0000FF 00000A00
	v_ashrrev_i32_e32 v40, 31, v39                             // 0000001BD428: 34504E9F
	.long 0xd73c0017                                           // 0000001BD42C: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000001BD430: 02022E81
	v_ashrrev_i32_e32 v66, 31, v65                             // 0000001BD434: 3484829F
	v_add_f32_dpp v83, v83, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD438: 06A6A6FA FF096453
	.long 0xd7006a45                                           // 0000001BD440: D7006A45
	v_cndmask_b32_e32 v1, s10, v15, vcc_lo                     // 0000001BD444: 02021E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BD448: BF8700A1
	v_add_co_ci_u32_e64 v70, null, s11, v16, vcc_lo            // 0000001BD44C: D5207C46 01AA200B
	.long 0xd7006a1f                                           // 0000001BD454: D7006A1F
	v_cndmask_b32_e32 v1, v7, v31, vcc_lo                      // 0000001BD458: 02023F07
	v_add_co_ci_u32_e64 v32, null, v8, v32, vcc_lo             // 0000001BD45C: D5207C20 01AA4108
	.long 0xd7006a37                                           // 0000001BD464: D7006A37
	v_cndmask_b32_e32 v1, s10, v23, vcc_lo                     // 0000001BD468: 02022E0A
	v_ashrrev_i32_e32 v48, 31, v0                              // 0000001BD46C: 3460009F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001BD470: BF8700B3
	.long 0xd73c001f                                           // 0000001BD474: D73C001F
	v_cndmask_b32_e32 v1, 1, v31, vcc_lo                       // 0000001BD478: 02023E81
	v_add_co_ci_u32_e64 v56, null, s11, v24, vcc_lo            // 0000001BD47C: D5207C38 01AA300B
	.long 0xd7006a27                                           // 0000001BD484: D7006A27
	v_cndmask_b32_e32 v1, v7, v39, vcc_lo                      // 0000001BD488: 02024F07
	v_add_co_ci_u32_e64 v40, null, v8, v40, vcc_lo             // 0000001BD48C: D5207C28 01AA5108
	.long 0xd7006a2f                                           // 0000001BD494: D7006A2F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000001BD498: 02020107
	global_load_u16 v78, v[69:70], off offset:1024             // 0000001BD49C: DC4A0400 4E7C0045
	v_add_co_ci_u32_e64 v48, null, v8, v48, vcc_lo             // 0000001BD4A4: D5207C30 01AA6108
	.long 0xd7006a3f                                           // 0000001BD4AC: D7006A3F
	v_cndmask_b32_e32 v1, s10, v31, vcc_lo                     // 0000001BD4B0: 02023E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BD4B4: BF8700A1
	v_add_co_ci_u32_e64 v64, null, s11, v32, vcc_lo            // 0000001BD4B8: D5207C40 01AA400B
	.long 0xd7006a07                                           // 0000001BD4C0: D7006A07
	v_cndmask_b32_e32 v1, v7, v65, vcc_lo                      // 0000001BD4C4: 02028307
	v_add_co_ci_u32_e64 v8, null, v8, v66, vcc_lo              // 0000001BD4C8: D5207C08 01AA8508
	s_clause 0x2                                               // 0000001BD4D0: BF850002
	global_load_u16 v81, v[69:70], off                         // 0000001BD4D4: DC4A0000 517C0045
	global_load_u16 v82, v[69:70], off offset:32               // 0000001BD4DC: DC4A0020 527C0045
	global_load_u16 v103, v[69:70], off offset:64              // 0000001BD4E4: DC4A0040 677C0045
	.long 0xd73c0027                                           // 0000001BD4EC: D73C0027
	v_cndmask_b32_e32 v1, 1, v39, vcc_lo                       // 0000001BD4F0: 02024E81
	.long 0xd73c002f                                           // 0000001BD4F4: D73C002F
	v_cndmask_b32_e32 v1, 1, v47, vcc_lo                       // 0000001BD4F8: 02025E81
	.long 0xd73c0056                                           // 0000001BD4FC: D73C0056
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000001BD500: 02020E81
	v_mov_b32_dpp v8, v88 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD504: 7E1002FA FF096158
	v_mov_b32_dpp v7, v73 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD50C: 7E0E02FA FF096149
	v_add_f32_dpp v77, v77, v77 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD514: 069A9AFA FF09624D
	.long 0xd7006a43                                           // 0000001BD51C: D7006A43
	v_cndmask_b32_e32 v1, s10, v39, vcc_lo                     // 0000001BD520: 02024E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BD524: BF8700A1
	v_add_co_ci_u32_e64 v68, null, s11, v40, vcc_lo            // 0000001BD528: D5207C44 01AA500B
	.long 0xd7006a41                                           // 0000001BD530: D7006A41
	v_cndmask_b32_e32 v1, s10, v47, vcc_lo                     // 0000001BD534: 02025E0A
	v_add_co_ci_u32_e64 v66, null, s11, v48, vcc_lo            // 0000001BD538: D5207C42 01AA600B
	.long 0xd7006a47                                           // 0000001BD540: D7006A47
	v_cndmask_b32_e32 v1, s10, v86, vcc_lo                     // 0000001BD544: 0202AC0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BD548: BF870001
	v_add_co_ci_u32_e64 v72, null, s11, v87, vcc_lo            // 0000001BD54C: D5207C48 01AAAE0B
	s_clause 0x9                                               // 0000001BD554: BF850009
	global_load_u16 v99, v[63:64], off                         // 0000001BD558: DC4A0000 637C003F
	global_load_u16 v98, v[55:56], off                         // 0000001BD560: DC4A0000 627C0037
	global_load_u16 v101, v[65:66], off                        // 0000001BD568: DC4A0000 657C0041
	global_load_u16 v100, v[67:68], off                        // 0000001BD570: DC4A0000 647C0043
	global_load_u16 v102, v[71:72], off offset:32              // 0000001BD578: DC4A0020 667C0047
	global_load_u16 v94, v[63:64], off offset:32               // 0000001BD580: DC4A0020 5E7C003F
	global_load_u16 v93, v[55:56], off offset:32               // 0000001BD588: DC4A0020 5D7C0037
	global_load_u16 v96, v[65:66], off offset:32               // 0000001BD590: DC4A0020 607C0041
	global_load_u16 v95, v[67:68], off offset:32               // 0000001BD598: DC4A0020 5F7C0043
	global_load_u16 v97, v[71:72], off offset:64               // 0000001BD5A0: DC4A0040 617C0047
	v_dual_add_f32 v8, v88, v8 :: v_dual_add_f32 v7, v73, v7   // 0000001BD5A8: C9081158 08060F49
	v_add_f32_e32 v88, v74, v79                                // 0000001BD5B0: 06B09F4A
	v_add_f32_dpp v77, v77, v77 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD5B4: 069A9AFA FF09644D
	.long 0x7f003880                                           // 0000001BD5BC: 7F003880
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BD5C0: BF870224
	v_add_f32_dpp v8, v8, v8 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD5C4: 061010FA FF096208
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD5CC: 060E0EFA FF096207
	v_add_f32_dpp v77, v77, v77 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD5D4: 069A9AFA FF09684D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BD5DC: BF870214
	.long 0x7f9e3980                                           // 0000001BD5E0: 7F9E3980
	v_add_f32_dpp v8, v8, v8 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD5E4: 061010FA FF096408
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BD5EC: BF870004
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD5F0: 060E0EFA FF096407
	.long 0x7fa03980                                           // 0000001BD5F8: 7FA03980
	v_div_scale_f32 v115, null, v77, v77, 1.0                  // 0000001BD5FC: D6FC7C73 03CA9B4D
	v_div_scale_f32 v116, s1, 1.0, v77, 1.0                    // 0000001BD604: D6FC0174 03CA9AF2
	v_add_f32_dpp v107, v8, v8 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD60C: 06D610FA FF096808
	v_add_f32_dpp v108, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD614: 06D80EFA FF096807
	.long 0xd7000507                                           // 0000001BD61C: D7000507
	v_cndmask_b32_e32 v1, s12, v15, vcc_lo                     // 0000001BD620: 02021E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BD624: BF870211
	v_add_co_ci_u32_e64 v8, null, s13, v16, s5                 // 0000001BD628: D5207C08 0016200D
	v_div_scale_f32 v118, null, v107, v107, 1.0                // 0000001BD630: D6FC7C76 03CAD76B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BD638: BF8700A4
	v_div_scale_f32 v117, null, v108, v108, 1.0                // 0000001BD63C: D6FC7C75 03CAD96C
	.long 0xd700050f                                           // 0000001BD644: D700050F
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 0000001BD648: 02022E0C
	v_add_co_ci_u32_e64 v16, null, s13, v24, s5                // 0000001BD64C: D5207C10 0016300D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000001BD654: BF8701D4
	v_rcp_f32_e32 v121, v118                                   // 0000001BD658: 7EF25576
	v_add_f32_e32 v76, v76, v84                                // 0000001BD65C: 0698A94C
	v_add_f32_dpp v84, v88, v88 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD660: 06A8B0FA FF096258
	v_rcp_f32_e32 v122, v117                                   // 0000001BD668: 7EF45575
	.long 0xd7000517                                           // 0000001BD66C: D7000517
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 0000001BD670: 02023E0C
	v_add_f32_dpp v76, v76, v76 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD674: 069898FA FF09624C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001BD67C: BF870233
	v_add_f32_dpp v84, v84, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD680: 06A8A8FA FF096454
	v_add_co_ci_u32_e64 v24, null, s13, v32, s5                // 0000001BD688: D5207C18 0016400D
	.long 0xd700051f                                           // 0000001BD690: D700051F
	v_cndmask_b32_e32 v1, s12, v39, vcc_lo                     // 0000001BD694: 02024E0C
	v_add_f32_dpp v76, v76, v76 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD698: 069898FA FF09644C
	v_add_co_ci_u32_e64 v32, null, s13, v40, s5                // 0000001BD6A0: D5207C20 0016500D
	.long 0xd7000527                                           // 0000001BD6A8: D7000527
	v_cndmask_b32_e32 v1, s12, v47, vcc_lo                     // 0000001BD6AC: 02025E0C
	v_add_f32_dpp v88, v83, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD6B0: 06B0A6FA FF096853
	v_add_f32_dpp v89, v84, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD6B8: 06B2A8FA FF096854
	v_add_f32_dpp v83, v76, v76 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001BD6C0: 06A698FA FF09684C
	v_add_co_ci_u32_e64 v40, null, s13, v48, s5                // 0000001BD6C8: D5207C28 0016600D
	.long 0xd700052f                                           // 0000001BD6D0: D700052F
	v_cndmask_b32_e32 v1, s12, v86, vcc_lo                     // 0000001BD6D4: 0202AC0C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BD6D8: BF870001
	v_add_co_ci_u32_e64 v48, null, s13, v87, s5                // 0000001BD6DC: D5207C30 0016AE0D
	s_clause 0x1f                                              // 0000001BD6E4: BF85001F
	global_load_u16 v76, v[69:70], off offset:96               // 0000001BD6E8: DC4A0060 4C7C0045
	global_load_u16 v86, v[69:70], off offset:128              // 0000001BD6F0: DC4A0080 567C0045
	global_load_u16 v87, v[69:70], off offset:160              // 0000001BD6F8: DC4A00A0 577C0045
	global_load_u16 v92, v[69:70], off offset:192              // 0000001BD700: DC4A00C0 5C7C0045
	global_load_u16 v69, v[69:70], off offset:224              // 0000001BD708: DC4A00E0 457C0045
	global_load_u16 v138, v[55:56], off offset:64              // 0000001BD710: DC4A0040 8A7C0037
	global_load_u16 v133, v[55:56], off offset:96              // 0000001BD718: DC4A0060 857C0037
	global_load_u16 v128, v[55:56], off offset:128             // 0000001BD720: DC4A0080 807C0037
	global_load_u16 v124, v[55:56], off offset:160             // 0000001BD728: DC4A00A0 7C7C0037
	global_load_u16 v104, v[55:56], off offset:192             // 0000001BD730: DC4A00C0 687C0037
	global_load_u16 v137, v[63:64], off offset:64              // 0000001BD738: DC4A0040 897C003F
	global_load_u16 v132, v[63:64], off offset:96              // 0000001BD740: DC4A0060 847C003F
	global_load_u16 v127, v[63:64], off offset:128             // 0000001BD748: DC4A0080 7F7C003F
	global_load_u16 v123, v[63:64], off offset:160             // 0000001BD750: DC4A00A0 7B7C003F
	global_load_u16 v70, v[63:64], off offset:192              // 0000001BD758: DC4A00C0 467C003F
	global_load_u16 v56, v[55:56], off offset:224              // 0000001BD760: DC4A00E0 387C0037
	global_load_u16 v140, v[67:68], off offset:64              // 0000001BD768: DC4A0040 8C7C0043
	global_load_u16 v135, v[67:68], off offset:96              // 0000001BD770: DC4A0060 877C0043
	global_load_u16 v130, v[67:68], off offset:128             // 0000001BD778: DC4A0080 827C0043
	global_load_u16 v126, v[67:68], off offset:160             // 0000001BD780: DC4A00A0 7E7C0043
	global_load_u16 v106, v[67:68], off offset:192             // 0000001BD788: DC4A00C0 6A7C0043
	global_load_u16 v55, v[63:64], off offset:224              // 0000001BD790: DC4A00E0 377C003F
	global_load_u16 v139, v[65:66], off offset:64              // 0000001BD798: DC4A0040 8B7C0041
	global_load_u16 v134, v[65:66], off offset:96              // 0000001BD7A0: DC4A0060 867C0041
	global_load_u16 v129, v[65:66], off offset:128             // 0000001BD7A8: DC4A0080 817C0041
	global_load_u16 v125, v[65:66], off offset:160             // 0000001BD7B0: DC4A00A0 7D7C0041
	global_load_u16 v105, v[65:66], off offset:192             // 0000001BD7B8: DC4A00C0 697C0041
	global_load_u16 v63, v[67:68], off offset:224              // 0000001BD7C0: DC4A00E0 3F7C0043
	global_load_u16 v141, v[71:72], off offset:96              // 0000001BD7C8: DC4A0060 8D7C0047
	global_load_u16 v136, v[71:72], off offset:128             // 0000001BD7D0: DC4A0080 887C0047
	global_load_u16 v131, v[71:72], off offset:160             // 0000001BD7D8: DC4A00A0 837C0047
	global_load_u16 v68, v[71:72], off offset:192              // 0000001BD7E0: DC4A00C0 447C0047
	s_clause 0x1                                               // 0000001BD7E8: BF850001
	global_load_u16 v67, v[71:72], off offset:224              // 0000001BD7EC: DC4A00E0 437C0047
	global_load_u16 v64, v[65:66], off offset:224              // 0000001BD7F4: DC4A00E0 407C0041
	v_fma_f32 v65, -v117, v122, 1.0                            // 0000001BD7FC: D6130041 23CAF575
	v_div_scale_f32 v109, null, v89, v89, 1.0                  // 0000001BD804: D6FC7C6D 03CAB359
	v_div_scale_f32 v111, null, v83, v83, 1.0                  // 0000001BD80C: D6FC7C6F 03CAA753
	v_fma_f32 v66, -v118, v121, 1.0                            // 0000001BD814: D6130042 23CAF376
	v_div_scale_f32 v119, vcc_lo, 1.0, v108, 1.0               // 0000001BD81C: D6FC6A77 03CAD8F2
	v_fmac_f32_e32 v122, v65, v122                             // 0000001BD824: 56F4F541
	v_div_scale_f32 v120, s4, 1.0, v107, 1.0                   // 0000001BD828: D6FC0478 03CAD6F2
	v_div_scale_f32 v110, null, v88, v88, 1.0                  // 0000001BD830: D6FC7C6E 03CAB158
	v_rcp_f32_e32 v91, v109                                    // 0000001BD838: 7EB6556D
	v_rcp_f32_e32 v85, v111                                    // 0000001BD83C: 7EAA556F
	v_fmac_f32_e32 v121, v66, v121                             // 0000001BD840: 56F2F342
	v_mul_f32_e32 v65, v119, v122                              // 0000001BD844: 1082F577
	v_rcp_f32_e32 v90, v110                                    // 0000001BD848: 7EB4556E
	v_rcp_f32_e32 v84, v115                                    // 0000001BD84C: 7EA85573
	v_div_scale_f32 v112, s2, 1.0, v89, 1.0                    // 0000001BD850: D6FC0270 03CAB2F2
	v_mul_f32_e32 v66, v120, v121                              // 0000001BD858: 1084F378
	v_fma_f32 v144, -v117, v65, v119                           // 0000001BD85C: D6130090 25DE8375
	v_div_scale_f32 v114, s0, 1.0, v83, 1.0                    // 0000001BD864: D6FC0072 03CAA6F2
	v_fma_f32 v71, -v109, v91, 1.0                             // 0000001BD86C: D6130047 23CAB76D
	v_fma_f32 v142, -v111, v85, 1.0                            // 0000001BD874: D613008E 23CAAB6F
	v_fma_f32 v145, -v118, v66, v120                           // 0000001BD87C: D6130091 25E28576
	v_fmac_f32_e32 v65, v144, v122                             // 0000001BD884: 5682F590
	v_fma_f32 v72, -v110, v90, 1.0                             // 0000001BD888: D6130048 23CAB56E
	v_fma_f32 v143, -v115, v84, 1.0                            // 0000001BD890: D613008F 23CAA973
	v_fmac_f32_e32 v91, v71, v91                               // 0000001BD898: 56B6B747
	v_fmac_f32_e32 v85, v142, v85                              // 0000001BD89C: 56AAAB8E
	v_fmac_f32_e32 v66, v145, v121                             // 0000001BD8A0: 5684F391
	v_fma_f32 v117, -v117, v65, v119                           // 0000001BD8A4: D6130075 25DE8375
	v_div_scale_f32 v113, s3, 1.0, v88, 1.0                    // 0000001BD8AC: D6FC0371 03CAB0F2
	v_fmac_f32_e32 v90, v72, v90                               // 0000001BD8B4: 56B4B548
	v_dual_fmac_f32 v84, v143, v84 :: v_dual_mul_f32 v71, v112, v91// 0000001BD8B8: C806A98F 5446B770
	v_mul_f32_e32 v142, v114, v85                              // 0000001BD8C0: 111CAB72
	v_fma_f32 v118, -v118, v66, v120                           // 0000001BD8C4: D6130076 25E28576
	v_div_fmas_f32 v65, v117, v122, v65                        // 0000001BD8CC: D6370041 0506F575
	s_mov_b32 vcc_lo, s4                                       // 0000001BD8D4: BEEA0004
	v_dual_mul_f32 v72, v113, v90 :: v_dual_mul_f32 v143, v116, v84// 0000001BD8D8: C8C6B571 488EA974
	v_fma_f32 v146, -v109, v71, v112                           // 0000001BD8E0: D6130092 25C28F6D
	v_fma_f32 v148, -v111, v142, v114                          // 0000001BD8E8: D6130094 25CB1D6F
	v_div_fmas_f32 v117, v118, v121, v66                       // 0000001BD8F0: D6370075 050AF376
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BD8F8: BF870224
	v_fma_f32 v147, -v110, v72, v113                           // 0000001BD8FC: D6130093 25C6916E
	v_div_fixup_f32 v66, v65, v108, 1.0                        // 0000001BD904: D6270042 03CAD941
	v_dual_fmac_f32 v71, v146, v91 :: v_dual_fmac_f32 v142, v148, v85// 0000001BD90C: C800B792 478EAB94
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001BD914: BF870234
	v_div_fixup_f32 v65, v117, v107, 1.0                       // 0000001BD918: D6270041 03CAD775
	v_fma_f32 v144, -v115, v143, v116                          // 0000001BD920: D6130090 25D31F73
	v_fmac_f32_e32 v72, v147, v90                              // 0000001BD928: 5690B593
	v_fma_f32 v109, -v109, v71, v112                           // 0000001BD92C: D613006D 25C28F6D
	v_mul_f32_e32 v57, v57, v66                                // 0000001BD934: 10728539
	v_fma_f32 v107, -v111, v142, v114                          // 0000001BD938: D613006B 25CB1D6F
	v_mul_f32_e32 v111, v49, v66                               // 0000001BD940: 10DE8531
	v_dual_fmac_f32 v143, v144, v84 :: v_dual_mul_f32 v58, v58, v65// 0000001BD944: C806A990 8F3A833A
	v_fma_f32 v108, -v110, v72, v113                           // 0000001BD94C: D613006C 25C6916E
	.long 0x7f943980                                           // 0000001BD954: 7F943980
	.long 0x7f963980                                           // 0000001BD958: 7F963980
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BD95C: BF870004
	v_fma_f32 v110, -v115, v143, v116                          // 0000001BD960: D613006E 25D31F73
	.long 0x7f923980                                           // 0000001BD968: 7F923980
	v_mul_f32_e32 v25, v25, v66                                // 0000001BD96C: 10328519
	v_dual_mul_f32 v17, v17, v66 :: v_dual_mul_f32 v2, v2, v65 // 0000001BD970: C8C68511 11028302
	v_mul_f32_e32 v9, v9, v66                                  // 0000001BD978: 10128509
	v_mul_f32_e32 v1, v1, v66                                  // 0000001BD97C: 10028501
	v_dual_mul_f32 v41, v41, v66 :: v_dual_mul_f32 v42, v42, v65// 0000001BD980: C8C68529 292A832A
	v_mul_f32_e32 v34, v34, v65                                // 0000001BD988: 10448322
	v_mul_f32_e32 v26, v26, v65                                // 0000001BD98C: 1034831A
	v_mul_f32_e32 v18, v18, v65                                // 0000001BD990: 10248312
	v_mul_f32_e32 v10, v10, v65                                // 0000001BD994: 1014830A
	s_waitcnt vmcnt(47)                                        // 0000001BD998: BF89BFF7
	v_lshlrev_b32_e32 v78, 16, v78                             // 0000001BD99C: 309C9C90
	s_waitcnt vmcnt(46)                                        // 0000001BD9A0: BF89BBF7
	v_lshlrev_b32_e32 v49, 16, v81                             // 0000001BD9A4: 3062A290
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001BD9A8: BF870002
	v_dual_mul_f32 v81, v50, v65 :: v_dual_mul_f32 v112, 0xbfb8aa3b, v78// 0000001BD9AC: C8C68332 51709CFF BFB8AA3B
	s_waitcnt vmcnt(45)                                        // 0000001BD9B8: BF89B7F7
	v_lshlrev_b32_e32 v50, 16, v82                             // 0000001BD9BC: 3064A490
	s_waitcnt vmcnt(44)                                        // 0000001BD9C0: BF89B3F7
	v_dual_mul_f32 v103, 0xbfb8aa3b, v49 :: v_dual_lshlrev_b32 v82, 16, v103// 0000001BD9C4: C8E262FF 6752CE90 BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001BD9D0: 7C3C62FF 42CE8ED0
	v_fma_f32 v117, 0xbfb8aa3b, v78, -v112                     // 0000001BD9D8: D6130075 85C29CFF BFB8AA3B
	v_mul_f32_e32 v113, 0xbfb8aa3b, v50                        // 0000001BD9E4: 10E264FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BD9EC: BF870004
	v_mul_f32_e32 v114, 0xbfb8aa3b, v82                        // 0000001BD9F0: 10E4A4FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v49, -v103                     // 0000001BD9F8: D6130073 859E62FF BFB8AA3B
	v_rndne_f32_e32 v116, v103                                 // 0000001BDA04: 7EE84767
	s_waitcnt vmcnt(43)                                        // 0000001BDA08: BF89AFF7
	v_lshlrev_b32_e32 v99, 16, v99                             // 0000001BDA0C: 30C6C690
	v_rndne_f32_e32 v118, v112                                 // 0000001BDA10: 7EEC4770
	v_rndne_f32_e32 v152, v114                                 // 0000001BDA14: 7F304772
	s_waitcnt vmcnt(40)                                        // 0000001BDA18: BF89A3F7
	v_lshlrev_b32_e32 v100, 16, v100                           // 0000001BDA1C: 30C8C890
	v_lshlrev_b32_e32 v98, 16, v98                             // 0000001BDA20: 30C4C490
	v_fma_f32 v151, 0xbfb8aa3b, v82, -v114                     // 0000001BDA24: D6130097 85CAA4FF BFB8AA3B
	s_waitcnt vmcnt(37)                                        // 0000001BDA30: BF8997F7
	v_lshlrev_b32_e32 v93, 16, v93                             // 0000001BDA34: 30BABA90
	v_dual_mul_f32 v121, 0xbfb8aa3b, v100 :: v_dual_lshlrev_b32 v102, 16, v102// 0000001BDA38: C8E2C8FF 7966CC90 BFB8AA3B
	s_waitcnt vmcnt(36)                                        // 0000001BDA44: BF8993F7
	v_dual_mul_f32 v119, 0xbfb8aa3b, v98 :: v_dual_lshlrev_b32 v96, 16, v96// 0000001BDA48: C8E2C4FF 7760C090 BFB8AA3B
	v_dual_fmac_f32 v115, 0xb2a5705f, v49 :: v_dual_sub_f32 v112, v112, v118// 0000001BDA54: C80A62FF 7370ED70 B2A5705F
	v_dual_fmac_f32 v117, 0xb2a5705f, v78 :: v_dual_sub_f32 v114, v114, v152// 0000001BDA60: C80A9CFF 75733172 B2A5705F
	v_sub_f32_e32 v103, v103, v116                             // 0000001BDA6C: 08CEE967
	v_dual_mul_f32 v120, 0xbfb8aa3b, v99 :: v_dual_lshlrev_b32 v101, 16, v101// 0000001BDA70: C8E2C6FF 7864CA90 BFB8AA3B
	v_fma_f32 v145, 0xbfb8aa3b, v50, -v113                     // 0000001BDA7C: D6130091 85C664FF BFB8AA3B
	v_rndne_f32_e32 v146, v113                                 // 0000001BDA88: 7F244771
	v_dual_mul_f32 v147, 0xbfb8aa3b, v93 :: v_dual_mul_f32 v144, 0xbfb8aa3b, v102// 0000001BDA8C: C8C6BAFF 9390CCFF BFB8AA3B
	v_fma_f32 v154, 0xbfb8aa3b, v98, -v119                     // 0000001BDA98: D613009A 85DEC4FF BFB8AA3B
	v_dual_add_f32 v112, v112, v117 :: v_dual_add_f32 v103, v103, v115// 0000001BDAA4: C908EB70 7066E767
	s_waitcnt vmcnt(35)                                        // 0000001BDAAC: BF898FF7
	v_dual_mul_f32 v122, 0xbfb8aa3b, v101 :: v_dual_lshlrev_b32 v95, 16, v95// 0000001BDAB0: C8E2CAFF 7A5EBE90 BFB8AA3B
	v_fma_f32 v156, 0xbfb8aa3b, v99, -v120                     // 0000001BDABC: D613009C 85E2C6FF BFB8AA3B
	v_fma_f32 v158, 0xbfb8aa3b, v100, -v121                    // 0000001BDAC8: D613009E 85E6C8FF BFB8AA3B
	v_rndne_f32_e32 v163, v144                                 // 0000001BDAD4: 7F464790
	v_fmac_f32_e32 v145, 0xb2a5705f, v50                       // 0000001BDAD8: 572264FF B2A5705F
	v_sub_f32_e32 v113, v113, v146                             // 0000001BDAE0: 08E32571
	v_fmac_f32_e32 v154, 0xb2a5705f, v98                       // 0000001BDAE4: 5734C4FF B2A5705F
	v_exp_f32_e32 v103, v103                                   // 0000001BDAEC: 7ECE4B67
	v_dual_mul_f32 v149, 0xbfb8aa3b, v95 :: v_dual_lshlrev_b32 v94, 16, v94// 0000001BDAF0: C8E2BEFF 955EBC90 BFB8AA3B
	v_cvt_i32_f32_e32 v116, v116                               // 0000001BDAFC: 7EE81174
	v_rndne_f32_e32 v155, v119                                 // 0000001BDB00: 7F364777
	v_fma_f32 v160, 0xbfb8aa3b, v101, -v122                    // 0000001BDB04: D61300A0 85EACAFF BFB8AA3B
	v_rndne_f32_e32 v161, v122                                 // 0000001BDB10: 7F42477A
	v_fma_f32 v162, 0xbfb8aa3b, v102, -v144                    // 0000001BDB14: D61300A2 8642CCFF BFB8AA3B
	v_fmac_f32_e32 v156, 0xb2a5705f, v99                       // 0000001BDB20: 5738C6FF B2A5705F
	v_fmac_f32_e32 v158, 0xb2a5705f, v100                      // 0000001BDB28: 573CC8FF B2A5705F
	v_dual_sub_f32 v144, v144, v163 :: v_dual_add_f32 v113, v113, v145// 0000001BDB30: C9494790 90712371
	v_exp_f32_e32 v112, v112                                   // 0000001BDB38: 7EE04B70
	s_waitcnt vmcnt(34)                                        // 0000001BDB3C: BF898BF7
	v_dual_mul_f32 v148, 0xbfb8aa3b, v94 :: v_dual_lshlrev_b32 v97, 16, v97// 0000001BDB40: C8E2BCFF 9460C290 BFB8AA3B
	v_mul_f32_e32 v150, 0xbfb8aa3b, v96                        // 0000001BDB4C: 112CC0FF BFB8AA3B
	v_cvt_i32_f32_e32 v118, v118                               // 0000001BDB54: 7EEC1176
	v_dual_fmac_f32 v151, 0xb2a5705f, v82 :: v_dual_fmac_f32 v160, 0xb2a5705f, v101// 0000001BDB58: C800A4FF 97A0CAFF B2A5705F
	v_dual_sub_f32 v115, v119, v155 :: v_dual_sub_f32 v122, v122, v161// 0000001BDB64: C94B3777 737B437A
	v_exp_f32_e32 v113, v113                                   // 0000001BDB6C: 7EE24B71
	.long 0xd71c0067                                           // 0000001BDB70: D71C0067
	v_cndmask_b32_e32 v1, v103, v116, vcc_lo                   // 0000001BDB74: 0202E967
	v_mul_f32_e32 v153, 0xbfb8aa3b, v97                        // 0000001BDB78: 1132C2FF BFB8AA3B
	v_rndne_f32_e32 v157, v120                                 // 0000001BDB80: 7F3A4778
	v_rndne_f32_e32 v159, v121                                 // 0000001BDB84: 7F3E4779
	v_cvt_i32_f32_e32 v146, v146                               // 0000001BDB88: 7F241192
	v_fma_f32 v164, 0xbfb8aa3b, v93, -v147                     // 0000001BDB8C: D61300A4 864EBAFF BFB8AA3B
	v_fma_f32 v168, 0xbfb8aa3b, v95, -v149                     // 0000001BDB98: D61300A8 8656BEFF BFB8AA3B
	v_fma_f32 v170, 0xbfb8aa3b, v96, -v150                     // 0000001BDBA4: D61300AA 865AC0FF BFB8AA3B
	v_rndne_f32_e32 v171, v150                                 // 0000001BDBB0: 7F564796
	v_dual_add_f32 v122, v122, v160 :: v_dual_cndmask_b32 v103, 0, v103// 0000001BDBB4: C913417A 7A66CE80
	.long 0xd71c0070                                           // 0000001BDBBC: D71C0070
	v_cndmask_b32_e32 v1, v112, v118, vcc_lo                   // 0000001BDBC0: 0202ED70
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v78                  // 0000001BDBC4: 7C3C9CFF 42CE8ED0
	v_dual_sub_f32 v119, v120, v157 :: v_dual_fmac_f32 v162, 0xb2a5705f, v102// 0000001BDBCC: C9413B78 77A2CCFF B2A5705F
	v_dual_sub_f32 v121, v121, v159 :: v_dual_fmac_f32 v164, 0xb2a5705f, v93// 0000001BDBD8: C9413F79 79A4BAFF B2A5705F
	v_dual_fmac_f32 v168, 0xb2a5705f, v95 :: v_dual_add_f32 v115, v115, v154// 0000001BDBE4: C808BEFF A8733573 B2A5705F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BDBF0: BF870212
	v_dual_fmac_f32 v170, 0xb2a5705f, v96 :: v_dual_add_f32 v121, v121, v158// 0000001BDBF4: C808C0FF AA793D79 B2A5705F
	v_dual_sub_f32 v150, v150, v171 :: v_dual_add_f32 v119, v119, v156// 0000001BDC00: C9495796 96773977
	.long 0xd71c0071                                           // 0000001BDC08: D71C0071
	v_cndmask_b32_e32 v1, v113, v146, vcc_lo                   // 0000001BDC0C: 02032571
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 0000001BDC10: 02E0E080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v50                  // 0000001BDC14: 7C3C64FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BDC1C: BF870004
	v_add_f32_e32 v150, v150, v170                             // 0000001BDC20: 072D5596
	v_exp_f32_e32 v115, v115                                   // 0000001BDC24: 7EE64B73
	v_cvt_i32_f32_e32 v117, v155                               // 0000001BDC28: 7EEA119B
	v_exp_f32_e32 v119, v119                                   // 0000001BDC2C: 7EEE4B77
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000001BDC30: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001BDC34: 7C3662FF C2B17218
	v_rndne_f32_e32 v165, v147                                 // 0000001BDC3C: 7F4A4793
	v_fma_f32 v166, 0xbfb8aa3b, v94, -v148                     // 0000001BDC40: D61300A6 8652BCFF BFB8AA3B
	v_cvt_i32_f32_e32 v120, v157                               // 0000001BDC4C: 7EF0119D
	v_exp_f32_e32 v121, v121                                   // 0000001BDC50: 7EF24B79
	v_cndmask_b32_e32 v49, 0x7f800000, v103, vcc_lo            // 0000001BDC54: 0262CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v78                  // 0000001BDC5C: 7C369CFF C2B17218
	.long 0xd71c0073                                           // 0000001BDC64: D71C0073
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                   // 0000001BDC68: 0202EB73
	v_rndne_f32_e32 v167, v148                                 // 0000001BDC6C: 7F4E4794
	v_cvt_i32_f32_e32 v155, v159                               // 0000001BDC70: 7F36119F
	v_dual_sub_f32 v145, v147, v165 :: v_dual_fmac_f32 v166, 0xb2a5705f, v94// 0000001BDC74: C9414B93 91A6BCFF B2A5705F
	v_cndmask_b32_e32 v78, 0x7f800000, v112, vcc_lo            // 0000001BDC80: 029CE0FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v98                  // 0000001BDC88: 7C3CC4FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BDC90: BF870003
	v_dual_add_f32 v144, v144, v162 :: v_dual_add_f32 v145, v145, v164// 0000001BDC94: C9094590 90914991
	v_exp_f32_e32 v122, v122                                   // 0000001BDC9C: 7EF44B7A
	.long 0xd71c0075                                           // 0000001BDCA0: D71C0075
	v_cndmask_b32_e32 v1, v119, v120, vcc_lo                   // 0000001BDCA4: 0202F177
	v_cndmask_b32_e32 v103, 0, v115, vcc_lo                    // 0000001BDCA8: 02CEE680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v99                  // 0000001BDCAC: 7C3CC6FF 42CE8ED0
	v_rndne_f32_e32 v169, v149                                 // 0000001BDCB4: 7F524795
	v_cvt_i32_f32_e32 v157, v161                               // 0000001BDCB8: 7F3A11A1
	v_sub_f32_e32 v148, v148, v167                             // 0000001BDCBC: 09294F94
	v_exp_f32_e32 v144, v144                                   // 0000001BDCC0: 7F204B90
	.long 0xd71c0076                                           // 0000001BDCC4: D71C0076
	v_cndmask_b32_e32 v1, v121, v155, vcc_lo                   // 0000001BDCC8: 02033779
	v_cndmask_b32_e32 v112, 0, v117, vcc_lo                    // 0000001BDCCC: 02E0EA80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 0000001BDCD0: 7C3CC8FF 42CE8ED0
	v_cvt_i32_f32_e32 v159, v163                               // 0000001BDCD8: 7F3E11A3
	v_dual_sub_f32 v149, v149, v169 :: v_dual_add_f32 v148, v148, v166// 0000001BDCDC: C9495395 95954D94
	.long 0xd71c0077                                           // 0000001BDCE4: D71C0077
	v_cndmask_b32_e32 v1, v122, v157, vcc_lo                   // 0000001BDCE8: 02033B7A
	v_cndmask_b32_e32 v115, 0, v118, vcc_lo                    // 0000001BDCEC: 02E6EC80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v101                 // 0000001BDCF0: 7C3CCAFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BDCF8: BF870004
	v_add_f32_e32 v149, v149, v168                             // 0000001BDCFC: 072B5195
	v_exp_f32_e32 v145, v145                                   // 0000001BDD00: 7F224B91
	v_exp_f32_e32 v148, v148                                   // 0000001BDD04: 7F284B94
	.long 0xd71c0078                                           // 0000001BDD08: D71C0078
	v_cndmask_b32_e32 v1, v144, v159, vcc_lo                   // 0000001BDD0C: 02033F90
	v_cndmask_b32_e32 v117, 0, v119, vcc_lo                    // 0000001BDD10: 02EAEE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 0000001BDD14: 7C3CCCFF 42CE8ED0
	v_cvt_i32_f32_e32 v147, v165                               // 0000001BDD1C: 7F2611A5
	v_cvt_i32_f32_e32 v161, v167                               // 0000001BDD20: 7F4211A7
	v_exp_f32_e32 v149, v149                                   // 0000001BDD24: 7F2A4B95
	v_cvt_i32_f32_e32 v163, v169                               // 0000001BDD28: 7F4611A9
	v_cndmask_b32_e32 v118, 0, v120, vcc_lo                    // 0000001BDD2C: 02ECF080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v50                  // 0000001BDD30: 7C3664FF C2B17218
	.long 0xd71c0079                                           // 0000001BDD38: D71C0079
	v_cndmask_b32_e32 v1, v145, v147, vcc_lo                   // 0000001BDD3C: 02032791
	.long 0xd71c007a                                           // 0000001BDD40: D71C007A
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 0000001BDD44: 02034394
	v_exp_f32_e32 v116, v150                                   // 0000001BDD48: 7EE84B96
	v_cvt_i32_f32_e32 v165, v171                               // 0000001BDD4C: 7F4A11AB
	v_cndmask_b32_e32 v50, 0x7f800000, v113, vcc_lo            // 0000001BDD50: 0264E2FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v93                  // 0000001BDD58: 7C3CBAFF 42CE8ED0
	.long 0xd71c0090                                           // 0000001BDD60: D71C0090
	v_cndmask_b32_e32 v1, v149, v163, vcc_lo                   // 0000001BDD64: 02034795
	v_add_f32_e32 v78, 1.0, v78                                // 0000001BDD68: 069C9CF2
	.long 0xd41b0005                                           // 0000001BDD6C: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v94, vcc_lo              // 0000001BDD70: 0202BCFF C2B17218
	v_cndmask_b32_e32 v113, 0, v121, vcc_lo                    // 0000001BDD78: 02E2F280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v94                  // 0000001BDD7C: 7C3CBCFF 42CE8ED0
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001BDD84: BF870255
	.long 0xd71c0074                                           // 0000001BDD88: D71C0074
	v_cndmask_b32_e32 v1, v116, v165, vcc_lo                   // 0000001BDD8C: 02034B74
	v_cndmask_b32_e32 v119, 0, v122, vcc_lo                    // 0000001BDD90: 02EEF480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v95                  // 0000001BDD94: 7C3CBEFF 42CE8ED0
	v_add_f32_e32 v120, 1.0, v49                               // 0000001BDD9C: 06F062F2
	v_div_scale_f32 v122, null, v78, v78, v58                  // 0000001BDDA0: D6FC7C7A 04EA9D4E
	v_cndmask_b32_e64 v94, 0x7f800000, v119, s5                // 0000001BDDA8: D501005E 0016EEFF 7F800000
	v_cndmask_b32_e32 v49, 0, v144, vcc_lo                     // 0000001BDDB4: 02632080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000001BDDB8: 7C3CC0FF 42CE8ED0
	v_div_scale_f32 v121, null, v120, v120, v57                // 0000001BDDC0: D6FC7C79 04E6F178
	.long 0xd41b0005                                           // 0000001BDDC8: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v95, vcc_lo              // 0000001BDDCC: 0202BEFF C2B17218
	v_cndmask_b32_e32 v116, 0, v116, vcc_lo                    // 0000001BDDD4: 02E8E880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v98                  // 0000001BDDD8: 7C36C4FF C2B17218
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BDDE0: BF870003
	v_cndmask_b32_e64 v95, 0x7f800000, v49, s5                 // 0000001BDDE4: D501005F 001662FF 7F800000
	.long 0xd41b0005                                           // 0000001BDDF0: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v96, vcc_lo              // 0000001BDDF4: 0202C0FF C2B17218
	v_cndmask_b32_e32 v98, 0x7f800000, v103, vcc_lo            // 0000001BDDFC: 02C4CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v99                  // 0000001BDE04: 7C36C6FF C2B17218
	v_rcp_f32_e32 v103, v121                                   // 0000001BDE0C: 7ECE5579
	v_add_f32_e32 v95, 1.0, v95                                // 0000001BDE10: 06BEBEF2
	v_cndmask_b32_e32 v99, 0x7f800000, v112, vcc_lo            // 0000001BDE14: 02C6E0FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 0000001BDE1C: 7C36C8FF C2B17218
	v_rcp_f32_e32 v112, v122                                   // 0000001BDE24: 7EE0557A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(TRANS32_DEP_2)// 0000001BDE28: BF870332
	v_add_f32_e32 v99, 1.0, v99                                // 0000001BDE2C: 06C6C6F2
	v_dual_cndmask_b32 v100, 0x7f800000, v115 :: v_dual_add_f32 v115, 1.0, v50// 0000001BDE30: CA48E6FF 647264F2 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v101                 // 0000001BDE3C: 7C36CAFF C2B17218
	v_fma_f32 v50, -v121, v103, 1.0                            // 0000001BDE44: D6130032 23CACF79
	v_cndmask_b32_e32 v101, 0x7f800000, v117, vcc_lo           // 0000001BDE4C: 02CAEAFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 0000001BDE54: 7C36CCFF C2B17218
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BDE5C: BF870003
	v_fmac_f32_e32 v103, v50, v103                             // 0000001BDE60: 56CECF32
	v_cndmask_b32_e64 v96, 0x7f800000, v116, s5                // 0000001BDE64: D5010060 0016E8FF 7F800000
	v_div_scale_f32 v116, s5, v111, v115, v111                 // 0000001BDE70: D6FC0574 05BEE76F
	v_cndmask_b32_e32 v102, 0x7f800000, v118, vcc_lo           // 0000001BDE78: 02CCECFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v93                  // 0000001BDE80: 7C36BAFF C2B17218
	v_div_scale_f32 v118, s4, v58, v78, v58                    // 0000001BDE88: D6FC0476 04EA9D3A
	v_cndmask_b32_e32 v93, 0x7f800000, v113, vcc_lo            // 0000001BDE90: 02BAE2FF 7F800000
	v_fma_f32 v113, -v122, v112, 1.0                           // 0000001BDE98: D6130071 23CAE17A
	v_div_scale_f32 v117, vcc_lo, v57, v120, v57               // 0000001BDEA0: D6FC6A75 04E6F139
	v_add_f32_e32 v102, 1.0, v102                              // 0000001BDEA8: 06CCCCF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BDEAC: BF870214
	v_dual_add_f32 v98, 1.0, v98 :: v_dual_add_f32 v93, 1.0, v93// 0000001BDEB0: C908C4F2 625CBAF2
	v_fmac_f32_e32 v112, v113, v112                            // 0000001BDEB8: 56E0E171
	v_div_scale_f32 v113, null, v115, v115, v111               // 0000001BDEBC: D6FC7C71 05BEE773
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BDEC4: BF8701A4
	v_div_scale_f32 v119, null, v102, v102, v81                // 0000001BDEC8: D6FC7C77 0546CD66
	v_mul_f32_e32 v50, v117, v103                              // 0000001BDED0: 1064CF75
	v_rcp_f32_e32 v145, v113                                   // 0000001BDED4: 7F225571
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BDED8: BF870092
	v_rcp_f32_e32 v146, v119                                   // 0000001BDEDC: 7F245577
	v_fma_f32 v49, -v121, v50, v117                            // 0000001BDEE0: D6130031 25D66579
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001BDEE8: BF870311
	v_fmac_f32_e32 v50, v49, v103                              // 0000001BDEEC: 5664CF31
	v_fma_f32 v49, -v113, v145, 1.0                            // 0000001BDEF0: D6130031 23CB2371
	v_mul_f32_e32 v144, v118, v112                             // 0000001BDEF8: 1120E176
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001BDEFC: BF870293
	v_fma_f32 v117, -v121, v50, v117                           // 0000001BDF00: D6130075 25D66579
	v_fma_f32 v121, -v119, v146, 1.0                           // 0000001BDF08: D6130079 23CB2577
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BDF10: BF870214
	v_fmac_f32_e32 v145, v49, v145                             // 0000001BDF14: 57232331
	v_fma_f32 v147, -v122, v144, v118                          // 0000001BDF18: D6130093 25DB217A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BDF20: BF870214
	v_div_fmas_f32 v103, v117, v103, v50                       // 0000001BDF24: D6370067 04CACF75
	v_fmac_f32_e32 v146, v121, v146                            // 0000001BDF2C: 57252579
	s_mov_b32 vcc_lo, s4                                       // 0000001BDF30: BEEA0004
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BDF34: BF870193
	v_fmac_f32_e32 v144, v147, v112                            // 0000001BDF38: 5720E193
	v_div_fixup_f32 v57, v103, v120, v57                       // 0000001BDF3C: D6270039 04E6F167
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BDF44: BF870112
	v_fma_f32 v118, -v122, v144, v118                          // 0000001BDF48: D6130076 25DB217A
	.long 0x7ea039b9                                           // 0000001BDF50: 7EA039B9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000001BDF54: BF870142
	v_div_fmas_f32 v112, v118, v112, v144                      // 0000001BDF58: D6370070 0642E176
	s_mov_b32 vcc_lo, s2                                       // 0000001BDF60: BEEA0002
	v_div_fmas_f32 v50, v109, v91, v71                         // 0000001BDF64: D6370032 051EB76D
	s_mov_b32 vcc_lo, s3                                       // 0000001BDF6C: BEEA0003
	v_div_fixup_f32 v58, v112, v78, v58                        // 0000001BDF70: D627003A 04EA9D70
	v_div_fmas_f32 v71, v108, v90, v72                         // 0000001BDF78: D6370047 0522B56C
	v_div_scale_f32 v72, s2, v81, v102, v81                    // 0000001BDF80: D6FC0248 0546CD51
	v_div_fixup_f32 v50, v50, v89, 1.0                         // 0000001BDF88: D6270032 03CAB332
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BDF90: BF870214
	.long 0x7e0039ba                                           // 0000001BDF94: 7E0039BA
	v_div_fixup_f32 v49, v71, v88, 1.0                         // 0000001BDF98: D6270031 03CAB147
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BDFA0: BF8701A3
	v_dual_mul_f32 v88, v116, v145 :: v_dual_mul_f32 v59, v59, v50// 0000001BDFA4: C8C72374 583A653B
	v_dual_mul_f32 v89, v72, v146 :: v_dual_add_f32 v90, 1.0, v100// 0000001BDFAC: C8C92548 595AC8F2
	v_dual_mul_f32 v60, v60, v49 :: v_dual_mul_f32 v103, v51, v50// 0000001BDFB4: C8C6633C 3C666533
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BDFBC: BF870213
	v_fma_f32 v91, -v113, v88, v116                            // 0000001BDFC0: D613005B 25D2B171
	v_div_scale_f32 v100, null, v98, v98, v59                  // 0000001BDFC8: D6FC7C64 04EEC562
	v_add_f32_e32 v71, 1.0, v101                               // 0000001BDFD0: 068ECAF2
	v_fma_f32 v101, -v119, v89, v72                            // 0000001BDFD4: D6130065 2522B377
	v_div_scale_f32 v108, null, v99, v99, v60                  // 0000001BDFDC: D6FC7C6C 04F2C763
	v_fmac_f32_e32 v88, v91, v145                              // 0000001BDFE4: 56B1235B
	v_rcp_f32_e32 v91, v100                                    // 0000001BDFE8: 7EB65564
	v_div_scale_f32 v117, null, v93, v93, v103                 // 0000001BDFEC: D6FC7C75 059EBB5D
	v_fmac_f32_e32 v89, v101, v146                             // 0000001BDFF4: 56B32565
	v_rcp_f32_e32 v101, v108                                   // 0000001BDFF8: 7ECA556C
	v_fma_f32 v109, -v113, v88, v116                           // 0000001BDFFC: D613006D 25D2B171
	v_mul_f32_e32 v113, v52, v49                               // 0000001BE004: 10E26334
	v_div_scale_f32 v116, vcc_lo, v59, v98, v59                // 0000001BE008: D6FC6A74 04EEC53B
	v_rcp_f32_e32 v112, v117                                   // 0000001BE010: 7EE05575
	v_div_scale_f32 v122, s4, v103, v93, v103                  // 0000001BE014: D6FC047A 059EBB67
	v_fma_f32 v72, -v119, v89, v72                             // 0000001BE01C: D6130048 2522B377
	v_fma_f32 v51, -v100, v91, 1.0                             // 0000001BE024: D6130033 23CAB764
	v_add_f32_e32 v94, 1.0, v94                                // 0000001BE02C: 06BCBCF2
	v_mul_f32_e32 v43, v43, v50                                // 0000001BE030: 1056652B
	v_fma_f32 v52, -v108, v101, 1.0                            // 0000001BE034: D6130034 23CACB6C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001BE03C: BF870234
	v_dual_add_f32 v96, 1.0, v96 :: v_dual_fmac_f32 v91, v51, v91// 0000001BE040: C900C0F2 605AB733
	v_div_scale_f32 v51, s3, v60, v99, v60                     // 0000001BE048: D6FC0333 04F2C73C
	v_div_scale_f32 v78, null, v94, v94, v113                  // 0000001BE050: D6FC7C4E 05C6BD5E
	v_fmac_f32_e32 v101, v52, v101                             // 0000001BE058: 56CACB34
	v_mul_f32_e32 v36, v36, v49                                // 0000001BE05C: 10486324
	v_mul_f32_e32 v52, v116, v91                               // 0000001BE060: 1068B774
	v_mul_f32_e32 v28, v28, v49                                // 0000001BE064: 1038631C
	v_rcp_f32_e32 v119, v78                                    // 0000001BE068: 7EEE554E
	v_dual_mul_f32 v35, v35, v50 :: v_dual_mul_f32 v20, v20, v49// 0000001BE06C: C8C66523 23146314
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001BE074: BF870243
	v_fma_f32 v120, -v100, v52, v116                           // 0000001BE078: D6130078 25D26964
	v_mul_f32_e32 v27, v27, v50                                // 0000001BE080: 1036651B
	v_mul_f32_e32 v19, v19, v50                                // 0000001BE084: 10266513
	v_mul_f32_e32 v11, v11, v50                                // 0000001BE088: 1016650B
	v_dual_mul_f32 v3, v3, v50 :: v_dual_fmac_f32 v52, v120, v91// 0000001BE08C: C8C06503 0334B778
	v_fma_f32 v120, -v117, v112, 1.0                           // 0000001BE094: D6130078 23CAE175
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001BE09C: BF870245
	v_fma_f32 v144, -v78, v119, 1.0                            // 0000001BE0A0: D6130090 23CAEF4E
	v_mul_f32_e32 v12, v12, v49                                // 0000001BE0A8: 1018630C
	v_mul_f32_e32 v4, v4, v49                                  // 0000001BE0AC: 10086304
	v_fma_f32 v100, -v100, v52, v116                           // 0000001BE0B0: D6130064 25D26964
	v_fmac_f32_e32 v119, v144, v119                            // 0000001BE0B8: 56EEEF90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BE0BC: BF8700A2
	v_div_fmas_f32 v91, v100, v91, v52                         // 0000001BE0C0: D637005B 04D2B764
	s_mov_b32 vcc_lo, s3                                       // 0000001BE0C8: BEEA0003
	v_div_fixup_f32 v59, v91, v98, v59                         // 0000001BE0CC: D627003B 04EEC55B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BE0D4: BF870091
	.long 0x7e9e39bb                                           // 0000001BE0D8: 7E9E39BB
	v_dual_fmac_f32 v112, v120, v112 :: v_dual_and_b32 v79, 1, v79// 0000001BE0DC: C824E178 704E9E81
	v_mul_f32_e32 v118, v51, v101                              // 0000001BE0E4: 10ECCB33
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BE0E8: BF870112
	v_add3_u32 v59, v59, v79, 0x7fff                           // 0000001BE0EC: D655003B 03FE9F3B 00007FFF
	v_fma_f32 v121, -v108, v118, v51                           // 0000001BE0F8: D6130079 24CEED6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001BE100: BF8701B1
	v_fmac_f32_e32 v118, v121, v101                            // 0000001BE104: 56ECCB79
	v_div_scale_f32 v121, s6, v113, v94, v113                  // 0000001BE108: D6FC0679 05C6BD71
	v_and_b32_e32 v80, 1, v80                                  // 0000001BE110: 36A0A081
	v_fma_f32 v51, -v108, v118, v51                            // 0000001BE114: D6130033 24CEED6C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001BE11C: BF870001
	v_div_fmas_f32 v100, v51, v101, v118                       // 0000001BE120: D6370064 05DACB33
	s_mov_b32 vcc_lo, s0                                       // 0000001BE128: BEEA0000
	v_div_fmas_f32 v51, v107, v85, v142                        // 0000001BE12C: D6370033 063AAB6B
	s_mov_b32 vcc_lo, s1                                       // 0000001BE134: BEEA0001
	v_and_b32_e32 v85, 1, v0                                   // 0000001BE138: 36AA0081
	v_div_fmas_f32 v84, v110, v84, v143                        // 0000001BE13C: D6370054 063EA96E
	v_div_fixup_f32 v60, v100, v99, v60                        // 0000001BE144: D627003C 04F2C764
	v_div_fixup_f32 v52, v51, v83, 1.0                         // 0000001BE14C: D6270034 03CAA733
	v_mul_f32_e32 v83, v122, v112                              // 0000001BE154: 10A6E17A
	v_add3_u32 v58, v58, v85, 0x7fff                           // 0000001BE158: D655003A 03FEAB3A 00007FFF
	v_div_fixup_f32 v51, v84, v77, 1.0                         // 0000001BE164: D6270033 03CA9B54
	v_mul_f32_e32 v77, v121, v119                              // 0000001BE16C: 109AEF79
	v_mul_f32_e32 v61, v61, v52                                // 0000001BE170: 107A693D
	v_add3_u32 v57, v57, v80, 0x7fff                           // 0000001BE174: D6550039 03FEA139 00007FFF
	v_fma_f32 v80, -v117, v83, v122                            // 0000001BE180: D6130050 25EAA775
	v_mul_f32_e32 v62, v62, v51                                // 0000001BE188: 107C673E
	v_fma_f32 v84, -v78, v77, v121                             // 0000001BE18C: D6130054 25E69B4E
	v_div_scale_f32 v85, null, v90, v90, v61                   // 0000001BE194: D6FC7C55 04F6B55A
	s_clause 0x1                                               // 0000001BE19C: BF850001
	global_store_d16_hi_b16 v[7:8], v57, off                   // 0000001BE1A0: DC960000 007C3907
	global_store_d16_hi_b16 v[7:8], v58, off offset:1024       // 0000001BE1A8: DC960400 007C3A07
	v_fmac_f32_e32 v83, v80, v112                              // 0000001BE1B0: 56A6E150
	v_div_scale_f32 v80, null, v71, v71, v62                   // 0000001BE1B4: D6FC7C50 04FA8F47
	v_fmac_f32_e32 v77, v84, v119                              // 0000001BE1BC: 569AEF54
	v_rcp_f32_e32 v84, v85                                     // 0000001BE1C0: 7EA85555
	v_dual_mul_f32 v53, v53, v52 :: v_dual_mul_f32 v54, v54, v51// 0000001BE1C4: C8C66935 35366736
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BE1CC: BF870113
	v_rcp_f32_e32 v91, v80                                     // 0000001BE1D0: 7EB65550
	v_fma_f32 v58, -v78, v77, v121                             // 0000001BE1D4: D613003A 25E69B4E
	v_div_scale_f32 v99, vcc_lo, v61, v90, v61                 // 0000001BE1DC: D6FC6A63 04F6B53D
	.long 0x7e0039bc                                           // 0000001BE1E4: 7E0039BC
	v_div_scale_f32 v100, null, v95, v95, v53                  // 0000001BE1E8: D6FC7C64 04D6BF5F
	v_fma_f32 v57, -v117, v83, v122                            // 0000001BE1F0: D6130039 25EAA775
	global_store_d16_hi_b16 v[15:16], v59, off                 // 0000001BE1F8: DC960000 007C3B0F
	v_fma_f32 v78, -v85, v84, 1.0                              // 0000001BE200: D613004E 23CAA955
	v_div_scale_f32 v116, null, v96, v96, v54                  // 0000001BE208: D6FC7C74 04DAC160
	v_rcp_f32_e32 v107, v100                                   // 0000001BE210: 7ED65564
	v_fma_f32 v98, -v80, v91, 1.0                              // 0000001BE214: D6130062 23CAB750
	v_div_scale_f32 v110, s1, v53, v95, v53                    // 0000001BE21C: D6FC016E 04D6BF35
	v_fmac_f32_e32 v84, v78, v84                               // 0000001BE224: 56A8A94E
	v_div_scale_f32 v78, s0, v62, v71, v62                     // 0000001BE228: D6FC004E 04FA8F3E
	v_mul_f32_e32 v45, v45, v52                                // 0000001BE230: 105A692D
	v_dual_fmac_f32 v91, v98, v91 :: v_dual_and_b32 v98, 1, v0 // 0000001BE234: C824B762 5B620081
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001BE23C: BF8702A4
	v_mul_f32_e32 v101, v99, v84                               // 0000001BE240: 10CAA963
	v_mul_f32_e32 v33, v33, v66                                // 0000001BE244: 10428521
	v_fma_f32 v59, -v100, v107, 1.0                            // 0000001BE248: D613003B 23CAD764
	v_mul_f32_e32 v37, v37, v52                                // 0000001BE250: 104A6925
	v_add3_u32 v60, v60, v98, 0x7fff                           // 0000001BE254: D655003C 03FEC53C 00007FFF
	v_fma_f32 v79, -v85, v101, v99                             // 0000001BE260: D613004F 258ECB55
	v_mul_f32_e32 v108, v78, v91                               // 0000001BE268: 10D8B74E
	v_fmac_f32_e32 v107, v59, v107                             // 0000001BE26C: 56D6D73B
	v_mul_f32_e32 v22, v22, v51                                // 0000001BE270: 102C6716
	global_store_d16_hi_b16 v[23:24], v60, off                 // 0000001BE274: DC960000 007C3C17
	v_fmac_f32_e32 v101, v79, v84                              // 0000001BE27C: 56CAA94F
	v_fma_f32 v117, -v80, v108, v78                            // 0000001BE280: D6130075 253AD950
	v_rcp_f32_e32 v79, v116                                    // 0000001BE288: 7E9E5574
	v_dual_mul_f32 v29, v29, v52 :: v_dual_mul_f32 v14, v14, v51// 0000001BE28C: C8C6691D 1D0E670E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BE294: BF870193
	v_fma_f32 v60, -v85, v101, v99                             // 0000001BE298: D613003C 258ECB55
	v_fmac_f32_e32 v108, v117, v91                             // 0000001BE2A0: 56D8B775
	v_mul_f32_e32 v21, v21, v52                                // 0000001BE2A4: 102A6915
	v_mul_f32_e32 v13, v13, v52                                // 0000001BE2A8: 101A690D
	v_mul_f32_e32 v5, v5, v52                                  // 0000001BE2AC: 100A6905
	v_div_fmas_f32 v60, v60, v84, v101                         // 0000001BE2B0: D637003C 0596A93C
	v_fma_f32 v59, -v80, v108, v78                             // 0000001BE2B8: D613003B 253AD950
	s_mov_b32 vcc_lo, s0                                       // 0000001BE2C0: BEEA0000
	v_mul_f32_e32 v6, v6, v51                                  // 0000001BE2C4: 100C6706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BE2C8: BF870193
	v_div_fixup_f32 v60, v60, v90, v61                         // 0000001BE2CC: D627003C 04F6B53C
	v_div_fmas_f32 v59, v59, v91, v108                         // 0000001BE2D4: D637003B 05B2B73B
	s_mov_b32 vcc_lo, s2                                       // 0000001BE2DC: BEEA0002
	v_div_fmas_f32 v72, v72, v146, v89                         // 0000001BE2E0: D6370048 05672548
	s_mov_b32 vcc_lo, s5                                       // 0000001BE2E8: BEEA0005
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001BE2EC: BF870002
	v_div_fixup_f32 v59, v59, v71, v62                         // 0000001BE2F0: D627003B 04FA8F3B
	v_div_fmas_f32 v61, v109, v145, v88                        // 0000001BE2F8: D637003D 0563236D
	s_mov_b32 vcc_lo, s4                                       // 0000001BE300: BEEA0004
	v_div_fixup_f32 v62, v72, v102, v81                        // 0000001BE304: D627003E 0546CD48
	v_div_fmas_f32 v57, v57, v112, v83                         // 0000001BE30C: D6370039 054EE139
	.long 0x7e0039bb                                           // 0000001BE314: 7E0039BB
	v_div_fixup_f32 v61, v61, v115, v111                       // 0000001BE318: D627003D 05BEE73D
	s_mov_b32 vcc_lo, s6                                       // 0000001BE320: BEEA0006
	.long 0x7e9639bc                                           // 0000001BE324: 7E9639BC
	v_div_fmas_f32 v58, v58, v119, v77                         // 0000001BE328: D637003A 0536EF3A
	.long 0x7e9439be                                           // 0000001BE330: 7E9439BE
	v_and_b32_e32 v71, 1, v0                                   // 0000001BE334: 368E0081
	.long 0x7e0039bd                                           // 0000001BE338: 7E0039BD
	v_div_fixup_f32 v57, v57, v93, v103                        // 0000001BE33C: D6270039 059EBB39
	v_and_b32_e32 v72, 1, v75                                  // 0000001BE344: 36909681
	v_div_fixup_f32 v58, v58, v94, v113                        // 0000001BE348: D627003A 05C6BD3A
	v_and_b32_e32 v74, 1, v74                                  // 0000001BE350: 36949481
	v_and_b32_e32 v75, 1, v0                                   // 0000001BE354: 36960081
	.long 0x7e9239b9                                           // 0000001BE358: 7E9239B9
	v_add3_u32 v60, v60, v72, 0x7fff                           // 0000001BE35C: D655003C 03FE913C 00007FFF
	.long 0x7e0039ba                                           // 0000001BE368: 7E0039BA
	v_fma_f32 v72, 0xbfb8aa3b, v97, -v153                      // 0000001BE36C: D6130048 8666C2FF BFB8AA3B
	v_add3_u32 v61, v61, v75, 0x7fff                           // 0000001BE378: D655003D 03FE973D 00007FFF
	v_add3_u32 v59, v59, v71, 0x7fff                           // 0000001BE384: D655003B 03FE8F3B 00007FFF
	v_add3_u32 v62, v62, v74, 0x7fff                           // 0000001BE390: D655003E 03FE953E 00007FFF
	s_clause 0x1                                               // 0000001BE39C: BF850001
	global_store_d16_hi_b16 v[31:32], v60, off                 // 0000001BE3A0: DC960000 007C3C1F
	global_store_d16_hi_b16 v[39:40], v59, off                 // 0000001BE3A8: DC960000 007C3B27
	v_dual_fmac_f32 v72, 0xb2a5705f, v97 :: v_dual_and_b32 v59, 1, v0// 0000001BE3B0: C824C2FF 483A0081 B2A5705F
	v_and_b32_e32 v71, 1, v73                                  // 0000001BE3BC: 368E9281
	s_clause 0x1                                               // 0000001BE3C0: BF850001
	global_store_d16_hi_b16 v[7:8], v61, off offset:32         // 0000001BE3C4: DC960020 007C3D07
	global_store_d16_hi_b16 v[47:48], v62, off offset:32       // 0000001BE3CC: DC960020 007C3E2F
	v_fma_f32 v60, -v116, v79, 1.0                             // 0000001BE3D4: D613003C 23CA9F74
	v_rndne_f32_e32 v73, v153                                  // 0000001BE3DC: 7E924799
	v_add_f32_e32 v61, v114, v151                              // 0000001BE3E0: 067B2F72
	v_mul_f32_e32 v62, v110, v107                              // 0000001BE3E4: 107CD76E
	v_add3_u32 v58, v58, v59, 0x7fff                           // 0000001BE3E8: D655003A 03FE773A 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BE3F4: BF870214
	v_dual_fmac_f32 v79, v60, v79 :: v_dual_sub_f32 v74, v153, v73// 0000001BE3F8: C80A9F3C 4F4A9399
	v_exp_f32_e32 v60, v61                                     // 0000001BE400: 7E784B3D
	v_div_scale_f32 v61, s0, v54, v96, v54                     // 0000001BE404: D6FC003D 04DAC136
	v_cvt_i32_f32_e32 v59, v152                                // 0000001BE40C: 7E761198
	v_fma_f32 v75, -v100, v62, v110                            // 0000001BE410: D613004B 25BA7D64
	v_add_f32_e32 v72, v74, v72                                // 0000001BE418: 0690914A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v82                  // 0000001BE41C: 7C3CA4FF 42CE8ED0
	v_mul_f32_e32 v77, v61, v79                                // 0000001BE424: 109A9F3D
	v_add3_u32 v57, v57, v71, 0x7fff                           // 0000001BE428: D6550039 03FE8F39 00007FFF
	v_fmac_f32_e32 v62, v75, v107                              // 0000001BE434: 567CD74B
	v_exp_f32_e32 v71, v72                                     // 0000001BE438: 7E8E4B48
	.long 0xd71c003b                                           // 0000001BE43C: D71C003B
	v_cndmask_b32_e32 v1, v60, v59, vcc_lo                     // 0000001BE440: 0202773C
	v_fma_f32 v60, -v116, v77, v61                             // 0000001BE444: D613003C 24F69B74
	global_store_d16_hi_b16 v[15:16], v57, off offset:32       // 0000001BE44C: DC960020 007C390F
	v_fma_f32 v72, -v100, v62, v110                            // 0000001BE454: D6130048 25BA7D64
	global_store_d16_hi_b16 v[23:24], v58, off offset:32       // 0000001BE45C: DC960020 007C3A17
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 0000001BE464: 02767680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v82                  // 0000001BE468: 7C36A4FF C2B17218
	v_fmac_f32_e32 v77, v60, v79                               // 0000001BE470: 569A9F3C
	v_cvt_i32_f32_e32 v60, v73                                 // 0000001BE474: 7E781149
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BE478: BF870124
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 0000001BE47C: 027676FF 7F800000
	s_mov_b32 vcc_lo, s1                                       // 0000001BE484: BEEA0001
	.long 0xd71c003c                                           // 0000001BE488: D71C003C
	v_cndmask_b32_e32 v1, v71, v60, vcc_lo                     // 0000001BE48C: 02027947
	v_div_fmas_f32 v62, v72, v107, v62                         // 0000001BE490: D637003E 04FAD748
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001BE498: 7C3CC2FF 42CE8ED0
	v_fma_f32 v61, -v116, v77, v61                             // 0000001BE4A0: D613003D 24F69B74
	.long 0x7f903980                                           // 0000001BE4A8: 7F903980
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BE4AC: BF870004
	v_div_fixup_f32 v53, v62, v95, v53                         // 0000001BE4B0: D6270035 04D6BF3E
	v_cndmask_b32_e32 v60, 0, v60, vcc_lo                      // 0000001BE4B8: 02787880
	s_mov_b32 vcc_lo, s0                                       // 0000001BE4BC: BEEA0000
	v_div_fmas_f32 v61, v61, v79, v77                          // 0000001BE4C0: D637003D 05369F3D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001BE4C8: 7C36C2FF C2B17218
	.long 0x7e9039b5                                           // 0000001BE4D0: 7E9039B5
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001BE4D4: BF8701B3
	v_div_fixup_f32 v54, v61, v96, v54                         // 0000001BE4D8: D6270036 04DAC13D
	s_waitcnt vmcnt(28)                                        // 0000001BE4E0: BF8973F7
	v_dual_cndmask_b32 v60, 0x7f800000, v60 :: v_dual_lshlrev_b32 v61, 16, v138// 0000001BE4E4: CA6278FF 3C3D1490 7F800000
	v_and_b32_e32 v72, 1, v72                                  // 0000001BE4F0: 36909081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BE4F4: BF870193
	.long 0x7e0039b6                                           // 0000001BE4F8: 7E0039B6
	v_mul_f32_e32 v62, 0xbfb8aa3b, v61                         // 0000001BE4FC: 107C7AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BE504: BF870004
	v_add_f32_e32 v60, 1.0, v60                                // 0000001BE508: 067878F2
	.long 0xd41e0001                                           // 0000001BE50C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v61, vcc_lo              // 0000001BE510: 02027AFF 42CE8ED0
	v_add3_u32 v53, v53, v72, 0x7fff                           // 0000001BE518: D6550035 03FE9135 00007FFF
	v_dual_add_f32 v59, 1.0, v59 :: v_dual_and_b32 v78, 1, v0  // 0000001BE524: C92476F2 3B4E0081
	v_fma_f32 v75, 0xbfb8aa3b, v61, -v62                       // 0000001BE52C: D613004B 84FA7AFF BFB8AA3B
	v_rndne_f32_e32 v77, v62                                   // 0000001BE538: 7E9A473E
	v_div_scale_f32 v58, null, v60, v60, v42                   // 0000001BE53C: D6FC7C3A 04AA793C
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BE544: BF870004
	v_add3_u32 v54, v54, v78, 0x7fff                           // 0000001BE548: D6550036 03FE9D36 00007FFF
	v_div_scale_f32 v71, null, v59, v59, v41                   // 0000001BE554: D6FC7C47 04A6773B
	v_fmac_f32_e32 v75, 0xb2a5705f, v61                        // 0000001BE55C: 56967AFF B2A5705F
	v_sub_f32_e32 v62, v62, v77                                // 0000001BE564: 087C9B3E
	s_waitcnt vmcnt(23)                                        // 0000001BE568: BF895FF7
	v_lshlrev_b32_e32 v79, 16, v137                            // 0000001BE56C: 309F1290
	v_rcp_f32_e32 v74, v58                                     // 0000001BE570: 7E94553A
	v_rcp_f32_e32 v57, v71                                     // 0000001BE574: 7E725547
	v_cvt_i32_f32_e32 v77, v77                                 // 0000001BE578: 7E9A114D
	v_add_f32_e32 v62, v62, v75                                // 0000001BE57C: 067C973E
	v_mul_f32_e32 v80, 0xbfb8aa3b, v79                         // 0000001BE580: 10A09EFF BFB8AA3B
	s_clause 0x1                                               // 0000001BE588: BF850001
	global_store_d16_hi_b16 v[31:32], v53, off offset:32       // 0000001BE58C: DC960020 007C351F
	global_store_d16_hi_b16 v[39:40], v54, off offset:32       // 0000001BE594: DC960020 007C3627
	v_exp_f32_e32 v62, v62                                     // 0000001BE59C: 7E7C4B3E
	v_fma_f32 v82, 0xbfb8aa3b, v79, -v80                       // 0000001BE5A0: D6130052 85429EFF BFB8AA3B
	v_fma_f32 v81, -v58, v74, 1.0                              // 0000001BE5AC: D6130051 23CA953A
	v_fma_f32 v73, -v71, v57, 1.0                              // 0000001BE5B4: D6130049 23CA7347
	v_rndne_f32_e32 v83, v80                                   // 0000001BE5BC: 7EA64750
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001BE5C0: BF8702A2
	v_dual_fmac_f32 v82, 0xb2a5705f, v79 :: v_dual_fmac_f32 v57, v73, v57// 0000001BE5C4: C8009EFF 52387349 B2A5705F
	v_div_scale_f32 v73, vcc_lo, v41, v59, v41                 // 0000001BE5D0: D6FC6A49 04A67729
	.long 0xd71c003e                                           // 0000001BE5D8: D71C003E
	v_cndmask_b32_e32 v1, v62, v77, vcc_lo                     // 0000001BE5DC: 02029B3E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BE5E0: BF870112
	v_mul_f32_e32 v75, v73, v57                                // 0000001BE5E4: 10967349
	v_cndmask_b32_e64 v62, 0, v62, s1                          // 0000001BE5E8: D501003E 00067C80
	.long 0xd41b0001                                           // 0000001BE5F0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v61, vcc_lo              // 0000001BE5F4: 02027AFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001BE5FC: BF870233
	v_fma_f32 v78, -v71, v75, v73                              // 0000001BE600: D613004E 25269747
	v_fmac_f32_e32 v74, v81, v74                               // 0000001BE608: 56949551
	v_div_scale_f32 v81, s0, v42, v60, v42                     // 0000001BE60C: D6FC0051 04AA792A
	v_cndmask_b32_e64 v61, 0x7f800000, v62, s1                 // 0000001BE614: D501003D 00067CFF 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BE620: BF870114
	v_dual_sub_f32 v80, v80, v83 :: v_dual_fmac_f32 v75, v78, v57// 0000001BE624: C940A750 504A734E
	v_dual_mul_f32 v84, v81, v74 :: v_dual_add_f32 v61, 1.0, v61// 0000001BE62C: C8C89551 543C7AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BE634: BF870192
	v_add_f32_e32 v80, v80, v82                                // 0000001BE638: 06A0A550
	v_fma_f32 v71, -v71, v75, v73                              // 0000001BE63C: D6130047 25269747
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BE644: BF870193
	v_fma_f32 v72, -v58, v84, v81                              // 0000001BE648: D6130048 2546A93A
	v_exp_f32_e32 v77, v80                                     // 0000001BE650: 7E9A4B50
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BE654: BF8701A2
	v_div_fmas_f32 v57, v71, v57, v75                          // 0000001BE658: D6370039 052E7347
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v79                  // 0000001BE660: 7C3C9EFF 42CE8ED0
	v_fmac_f32_e32 v84, v72, v74                               // 0000001BE668: 56A89548
	v_cvt_i32_f32_e32 v72, v83                                 // 0000001BE66C: 7E901153
	v_div_scale_f32 v71, null, v61, v61, v43                   // 0000001BE670: D6FC7C47 04AE7B3D
	v_div_fixup_f32 v41, v57, v59, v41                         // 0000001BE678: D6270029 04A67739
	.long 0x7f763980                                           // 0000001BE680: 7F763980
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 0000001BE684: BF870205
	.long 0xd71c003e                                           // 0000001BE688: D71C003E
	v_cndmask_b32_e32 v1, v77, v72, vcc_lo                     // 0000001BE68C: 0202914D
	s_waitcnt vmcnt(11)                                        // 0000001BE690: BF892FF7
	v_lshlrev_b32_e32 v77, 16, v139                            // 0000001BE694: 309B1690
	v_fma_f32 v58, -v58, v84, v81                              // 0000001BE698: D613003A 2546A93A
	v_rcp_f32_e32 v53, v71                                     // 0000001BE6A0: 7E6A5547
	.long 0x7e7639a9                                           // 0000001BE6A4: 7E7639A9
	v_cndmask_b32_e32 v62, 0, v62, vcc_lo                      // 0000001BE6A8: 027C7C80
	s_mov_b32 vcc_lo, s0                                       // 0000001BE6AC: BEEA0000
	v_mul_f32_e32 v78, 0xbfb8aa3b, v77                         // 0000001BE6B0: 109C9AFF BFB8AA3B
	v_div_fmas_f32 v58, v58, v74, v84                          // 0000001BE6B8: D637003A 0552953A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v79                  // 0000001BE6C0: 7C369EFF C2B17218
	v_and_b32_e32 v59, 1, v59                                  // 0000001BE6C8: 36767681
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BE6CC: BF870214
	v_fma_f32 v80, 0xbfb8aa3b, v77, -v78                       // 0000001BE6D0: D6130050 853A9AFF BFB8AA3B
	v_div_fixup_f32 v42, v58, v60, v42                         // 0000001BE6DC: D627002A 04AA793A
	v_lshlrev_b32_e32 v60, 16, v140                            // 0000001BE6E4: 30791890
	v_rndne_f32_e32 v81, v78                                   // 0000001BE6E8: 7EA2474E
	v_add3_u32 v41, v41, v59, 0x7fff                           // 0000001BE6EC: D6550029 03FE7729 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BE6F8: BF870194
	.long 0x7e0039aa                                           // 0000001BE6FC: 7E0039AA
	v_dual_mul_f32 v57, 0xbfb8aa3b, v60 :: v_dual_sub_f32 v78, v78, v81// 0000001BE700: C8CA78FF 394EA34E BFB8AA3B
	global_store_d16_hi_b16 v[7:8], v41, off offset:64         // 0000001BE70C: DC960040 007C2907
	v_and_b32_e32 v75, 1, v0                                   // 0000001BE714: 36960081
	v_fma_f32 v73, 0xbfb8aa3b, v60, -v57                       // 0000001BE718: D6130049 84E678FF BFB8AA3B
	v_rndne_f32_e32 v74, v57                                   // 0000001BE724: 7E944739
	v_mul_f32_e32 v44, v44, v49                                // 0000001BE728: 1058632C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BE72C: BF870214
	v_add3_u32 v42, v42, v75, 0x7fff                           // 0000001BE730: D655002A 03FE972A 00007FFF
	v_fmac_f32_e32 v73, 0xb2a5705f, v60                        // 0000001BE73C: 569278FF B2A5705F
	v_cndmask_b32_e32 v62, 0x7f800000, v62, vcc_lo             // 0000001BE744: 027C7CFF 7F800000
	v_sub_f32_e32 v57, v57, v74                                // 0000001BE74C: 08729539
	v_cvt_i32_f32_e32 v74, v74                                 // 0000001BE750: 7E94114A
	global_store_d16_hi_b16 v[47:48], v42, off offset:64       // 0000001BE754: DC960040 007C2A2F
	v_add_f32_e32 v58, 1.0, v62                                // 0000001BE75C: 06747CF2
	v_fma_f32 v62, -v71, v53, 1.0                              // 0000001BE760: D613003E 23CA6B47
	v_add_f32_e32 v57, v57, v73                                // 0000001BE768: 06729339
	.long 0xd41e0001                                           // 0000001BE76C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v60, vcc_lo              // 0000001BE770: 020278FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000001BE778: BF870143
	v_fmac_f32_e32 v53, v62, v53                               // 0000001BE77C: 566A6B3E
	v_div_scale_f32 v54, null, v58, v58, v44                   // 0000001BE780: D6FC7C36 04B2753A
	v_div_scale_f32 v62, vcc_lo, v43, v61, v43                 // 0000001BE788: D6FC6A3E 04AE7B2B
	v_exp_f32_e32 v57, v57                                     // 0000001BE790: 7E724B39
	v_rcp_f32_e32 v72, v54                                     // 0000001BE794: 7E905536
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001BE798: BF870296
	.long 0xd71c0039                                           // 0000001BE79C: D71C0039
	v_cndmask_b32_e32 v1, v57, v74, vcc_lo                     // 0000001BE7A0: 02029539
	v_fma_f32 v79, -v54, v72, 1.0                              // 0000001BE7A4: D613004F 23CA9136
	v_mul_f32_e32 v73, v62, v53                                // 0000001BE7AC: 10926B3E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BE7B0: BF870223
	v_cndmask_b32_e64 v57, 0, v57, s1                          // 0000001BE7B4: D5010039 00067280
	.long 0xd41b0001                                           // 0000001BE7BC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v60, vcc_lo              // 0000001BE7C0: 020278FF C2B17218
	v_fmac_f32_e32 v72, v79, v72                               // 0000001BE7C8: 5690914F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BE7CC: BF870224
	v_fma_f32 v75, -v71, v73, v62                              // 0000001BE7D0: D613004B 24FA9347
	v_div_scale_f32 v79, s0, v44, v58, v44                     // 0000001BE7D8: D6FC004F 04B2752C
	v_cndmask_b32_e64 v57, 0x7f800000, v57, s1                 // 0000001BE7E0: D5010039 000672FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BE7EC: BF870113
	v_fmac_f32_e32 v73, v75, v53                               // 0000001BE7F0: 56926B4B
	v_dual_mul_f32 v82, v79, v72 :: v_dual_add_f32 v57, 1.0, v57// 0000001BE7F4: C8C8914F 523872F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BE7FC: BF870112
	v_fma_f32 v62, -v71, v73, v62                              // 0000001BE800: D613003E 24FA9347
	v_fma_f32 v59, -v54, v82, v79                              // 0000001BE808: D613003B 253EA536
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BE810: BF870193
	v_div_scale_f32 v60, null, v57, v57, v45                   // 0000001BE814: D6FC7C3C 04B67339
	v_div_fmas_f32 v53, v62, v53, v73                          // 0000001BE81C: D6370035 05266B3E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v77                  // 0000001BE824: 7C3C9AFF 42CE8ED0
	v_fmac_f32_e32 v80, 0xb2a5705f, v77                        // 0000001BE82C: 56A09AFF B2A5705F
	v_fmac_f32_e32 v82, v59, v72                               // 0000001BE834: 56A4913B
	v_cvt_i32_f32_e32 v59, v81                                 // 0000001BE838: 7E761151
	v_div_fixup_f32 v43, v53, v61, v43                         // 0000001BE83C: D627002B 04AE7B35
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BE844: BF870214
	v_add_f32_e32 v78, v78, v80                                // 0000001BE848: 069CA14E
	v_fma_f32 v54, -v54, v82, v79                              // 0000001BE84C: D6130036 253EA536
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001BE854: BF870292
	v_exp_f32_e32 v74, v78                                     // 0000001BE858: 7E944B4E
	.long 0xd71c003b                                           // 0000001BE85C: D71C003B
	v_cndmask_b32_e32 v1, v74, v59, vcc_lo                     // 0000001BE860: 0202774A
	s_waitcnt vmcnt(5)                                         // 0000001BE864: BF8917F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BE868: BF8700A1
	v_dual_cndmask_b32 v59, 0, v59 :: v_dual_lshlrev_b32 v74, 16, v141// 0000001BE86C: CA627680 3B4B1A90
	s_mov_b32 vcc_lo, s0                                       // 0000001BE874: BEEA0000
	v_mul_f32_e32 v75, 0xbfb8aa3b, v74                         // 0000001BE878: 109694FF BFB8AA3B
	v_div_fmas_f32 v54, v54, v72, v82                          // 0000001BE880: D6370036 054A9136
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v77                  // 0000001BE888: 7C369AFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BE890: BF870193
	v_rndne_f32_e32 v78, v75                                   // 0000001BE894: 7E9C474B
	v_div_fixup_f32 v41, v54, v58, v44                         // 0000001BE898: D6270029 04B27536
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 0000001BE8A0: 027676FF 7F800000
	v_mul_f32_e32 v44, v46, v51                                // 0000001BE8A8: 1058672E
	v_rcp_f32_e32 v46, v60                                     // 0000001BE8AC: 7E5C553C
	v_lshlrev_b32_e32 v58, 16, v76                             // 0000001BE8B0: 30749890
	.long 0x7e0039a9                                           // 0000001BE8B4: 7E0039A9
	v_add_f32_e32 v54, 1.0, v59                                // 0000001BE8B8: 066C76F2
	.long 0x7e7639ab                                           // 0000001BE8BC: 7E7639AB
	.long 0x7f763980                                           // 0000001BE8C0: 7F763980
	v_mul_f32_e32 v53, 0xbfb8aa3b, v58                         // 0000001BE8C4: 106A74FF BFB8AA3B
	v_and_b32_e32 v73, 1, v0                                   // 0000001BE8CC: 36920081
	v_div_scale_f32 v42, null, v54, v54, v44                   // 0000001BE8D0: D6FC7C2A 04B26D36
	.long 0xd41e0001                                           // 0000001BE8D8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v58, vcc_lo              // 0000001BE8DC: 020274FF 42CE8ED0
	v_fma_f32 v61, -v60, v46, 1.0                              // 0000001BE8E4: D613003D 23CA5D3C
	v_fma_f32 v71, 0xbfb8aa3b, v58, -v53                       // 0000001BE8EC: D6130047 84D674FF BFB8AA3B
	v_rndne_f32_e32 v72, v53                                   // 0000001BE8F8: 7E904735
	v_rcp_f32_e32 v62, v42                                     // 0000001BE8FC: 7E7C552A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BE900: BF870193
	v_dual_fmac_f32 v46, v61, v46 :: v_dual_and_b32 v59, 1, v59// 0000001BE904: C8245D3D 2E3A7681
	v_fmac_f32_e32 v71, 0xb2a5705f, v58                        // 0000001BE90C: 568E74FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BE914: BF870003
	v_sub_f32_e32 v53, v53, v72                                // 0000001BE918: 086A9135
	v_div_scale_f32 v61, vcc_lo, v45, v57, v45                 // 0000001BE91C: D6FC6A3D 04B6732D
	v_add3_u32 v41, v41, v73, 0x7fff                           // 0000001BE924: D6550029 03FE9329 00007FFF
	v_fma_f32 v77, 0xbfb8aa3b, v74, -v75                       // 0000001BE930: D613004D 852E94FF BFB8AA3B
	v_sub_f32_e32 v75, v75, v78                                // 0000001BE93C: 08969D4B
	v_cvt_i32_f32_e32 v72, v72                                 // 0000001BE940: 7E901148
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001BE944: BF870005
	v_fma_f32 v76, -v42, v62, 1.0                              // 0000001BE948: D613004C 23CA7D2A
	v_add_f32_e32 v53, v53, v71                                // 0000001BE950: 066A8F35
	v_mul_f32_e32 v71, v61, v46                                // 0000001BE954: 108E5D3D
	v_fmac_f32_e32 v77, 0xb2a5705f, v74                        // 0000001BE958: 569A94FF B2A5705F
	v_add3_u32 v43, v43, v59, 0x7fff                           // 0000001BE960: D655002B 03FE772B 00007FFF
	v_fmac_f32_e32 v62, v76, v62                               // 0000001BE96C: 567C7D4C
	v_exp_f32_e32 v53, v53                                     // 0000001BE970: 7E6A4B35
	v_fma_f32 v73, -v60, v71, v61                              // 0000001BE974: D6130049 24F68F3C
	v_div_scale_f32 v76, s0, v44, v54, v44                     // 0000001BE97C: D6FC004C 04B26D2C
	s_clause 0x1                                               // 0000001BE984: BF850001
	global_store_d16_hi_b16 v[15:16], v43, off offset:64       // 0000001BE988: DC960040 007C2B0F
	global_store_d16_hi_b16 v[23:24], v41, off offset:64       // 0000001BE990: DC960040 007C2917
	v_fmac_f32_e32 v71, v73, v46                               // 0000001BE998: 568E5D49
	v_mul_f32_e32 v79, v76, v62                                // 0000001BE99C: 109E7D4C
	.long 0xd71c0035                                           // 0000001BE9A0: D71C0035
	v_cndmask_b32_e32 v1, v53, v72, vcc_lo                     // 0000001BE9A4: 02029135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BE9A8: BF870193
	v_fma_f32 v60, -v60, v71, v61                              // 0000001BE9AC: D613003C 24F68F3C
	v_fma_f32 v59, -v42, v79, v76                              // 0000001BE9B4: D613003B 25329F2A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BE9BC: BF870193
	v_cndmask_b32_e64 v53, 0, v53, s1                          // 0000001BE9C0: D5010035 00066A80
	v_div_fmas_f32 v46, v60, v46, v71                          // 0000001BE9C8: D637002E 051E5D3C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v74                  // 0000001BE9D0: 7C3C94FF 42CE8ED0
	v_add_f32_e32 v75, v75, v77                                // 0000001BE9D8: 06969B4B
	v_fmac_f32_e32 v79, v59, v62                               // 0000001BE9DC: 569E7D3B
	v_cvt_i32_f32_e32 v59, v78                                 // 0000001BE9E0: 7E76114E
	.long 0xd41b0001                                           // 0000001BE9E4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v58, vcc_lo              // 0000001BE9E8: 020274FF C2B17218
	v_div_fixup_f32 v45, v46, v57, v45                         // 0000001BE9F0: D627002D 04B6732E
	v_exp_f32_e32 v72, v75                                     // 0000001BE9F8: 7E904B4B
	v_fma_f32 v42, -v42, v79, v76                              // 0000001BE9FC: D613002A 25329F2A
	.long 0x7f723980                                           // 0000001BEA04: 7F723980
	v_cndmask_b32_e64 v53, 0x7f800000, v53, s1                 // 0000001BEA08: D5010035 00066AFF 7F800000
	.long 0x7e7239ad                                           // 0000001BEA14: 7E7239AD
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BEA18: BF870125
	.long 0xd71c003a                                           // 0000001BEA1C: D71C003A
	v_cndmask_b32_e32 v1, v72, v59, vcc_lo                     // 0000001BEA20: 02027748
	v_lshlrev_b32_e32 v72, 16, v132                            // 0000001BEA24: 30910890
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000001BEA28: 02747480
	s_mov_b32 vcc_lo, s0                                       // 0000001BEA2C: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001BEA30: BF870242
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000001BEA34: 109290FF BFB8AA3B
	v_div_fmas_f32 v42, v42, v62, v79                          // 0000001BEA3C: D637002A 053E7D2A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v74                  // 0000001BEA44: 7C3694FF C2B17218
	v_add_f32_e32 v53, 1.0, v53                                // 0000001BEA4C: 066A6AF2
	v_fma_f32 v75, 0xbfb8aa3b, v72, -v73                       // 0000001BEA50: D613004B 852690FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BEA5C: BF870224
	v_div_fixup_f32 v42, v42, v54, v44                         // 0000001BEA60: D627002A 04B26D2A
	v_cndmask_b32_e32 v58, 0x7f800000, v58, vcc_lo             // 0000001BEA68: 027474FF 7F800000
	v_div_scale_f32 v59, null, v53, v53, v33                   // 0000001BEA70: D6FC7C3B 04866B35
	v_lshlrev_b32_e32 v54, 16, v133                            // 0000001BEA78: 306D0A90
	v_rndne_f32_e32 v76, v73                                   // 0000001BEA7C: 7E984749
	.long 0x7e0039aa                                           // 0000001BEA80: 7E0039AA
	v_add_f32_e32 v44, 1.0, v58                                // 0000001BEA84: 065874F2
	v_rcp_f32_e32 v43, v59                                     // 0000001BEA88: 7E56553B
	.long 0xd41e0001                                           // 0000001BEA8C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v54, vcc_lo              // 0000001BEA90: 02026CFF 42CE8ED0
	v_fmac_f32_e32 v75, 0xb2a5705f, v72                        // 0000001BEA98: 569690FF B2A5705F
	v_and_b32_e32 v71, 1, v0                                   // 0000001BEAA0: 368E0081
	v_div_scale_f32 v41, null, v44, v44, v34                   // 0000001BEAA4: D6FC7C29 048A592C
	v_sub_f32_e32 v73, v73, v76                                // 0000001BEAAC: 08929949
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BEAB0: BF870193
	v_add3_u32 v42, v42, v71, 0x7fff                           // 0000001BEAB4: D655002A 03FE8F2A 00007FFF
	v_rcp_f32_e32 v60, v41                                     // 0000001BEAC0: 7E785529
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BEAC4: BF870196
	v_fma_f32 v58, -v59, v43, 1.0                              // 0000001BEAC8: D613003A 23CA573B
	v_dual_mul_f32 v46, 0xbfb8aa3b, v54 :: v_dual_add_f32 v73, v73, v75// 0000001BEAD0: C8C86CFF 2E489749 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BEADC: BF870112
	v_fmac_f32_e32 v43, v58, v43                               // 0000001BEAE0: 5656573A
	v_fma_f32 v61, 0xbfb8aa3b, v54, -v46                       // 0000001BEAE4: D613003D 84BA6CFF BFB8AA3B
	v_rndne_f32_e32 v62, v46                                   // 0000001BEAF0: 7E7C472E
	v_div_scale_f32 v58, vcc_lo, v33, v53, v33                 // 0000001BEAF4: D6FC6A3A 04866B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BEAFC: BF870215
	v_fma_f32 v74, -v41, v60, 1.0                              // 0000001BEB00: D613004A 23CA7929
	v_fmac_f32_e32 v61, 0xb2a5705f, v54                        // 0000001BEB08: 567A6CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BEB10: BF870224
	v_sub_f32_e32 v46, v46, v62                                // 0000001BEB14: 085C7D2E
	v_cvt_i32_f32_e32 v62, v62                                 // 0000001BEB18: 7E7C113E
	v_fmac_f32_e32 v60, v74, v60                               // 0000001BEB1C: 5678794A
	v_div_scale_f32 v74, s0, v34, v44, v34                     // 0000001BEB20: D6FC004A 048A5922
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BEB28: BF870114
	v_add_f32_e32 v46, v46, v61                                // 0000001BEB2C: 065C7B2E
	v_mul_f32_e32 v77, v74, v60                                // 0000001BEB30: 109A794A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001BEB34: BF870292
	v_exp_f32_e32 v46, v46                                     // 0000001BEB38: 7E5C4B2E
	.long 0xd71c002e                                           // 0000001BEB3C: D71C002E
	v_cndmask_b32_e32 v1, v46, v62, vcc_lo                     // 0000001BEB40: 02027D2E
	v_exp_f32_e32 v62, v73                                     // 0000001BEB44: 7E7C4B49
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BEB48: BF8700A1
	v_cndmask_b32_e64 v46, 0, v46, s1                          // 0000001BEB4C: D501002E 00065C80
	.long 0xd41b0001                                           // 0000001BEB54: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v54, vcc_lo              // 0000001BEB58: 02026CFF C2B17218
	v_cndmask_b32_e64 v46, 0x7f800000, v46, s1                 // 0000001BEB60: D501002E 00065CFF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BEB6C: BF870091
	v_dual_add_f32 v46, 1.0, v46 :: v_dual_and_b32 v57, 1, v57 // 0000001BEB70: C9245CF2 2E387281
	v_add3_u32 v45, v45, v57, 0x7fff                           // 0000001BEB78: D655002D 03FE732D 00007FFF
	v_fma_f32 v57, -v41, v77, v74                              // 0000001BEB84: D6130039 252A9B29
	global_store_d16_hi_b16 v[31:32], v45, off offset:64       // 0000001BEB8C: DC960040 007C2D1F
	v_fmac_f32_e32 v77, v57, v60                               // 0000001BEB94: 569A7939
	v_cvt_i32_f32_e32 v57, v76                                 // 0000001BEB98: 7E72114C
	v_lshlrev_b32_e32 v45, 16, v135                            // 0000001BEB9C: 305B0E90
	global_store_d16_hi_b16 v[39:40], v42, off offset:64       // 0000001BEBA0: DC960040 007C2A27
	v_fma_f32 v41, -v41, v77, v74                              // 0000001BEBA8: D6130029 252A9B29
	.long 0xd71c0036                                           // 0000001BEBB0: D71C0036
	v_cndmask_b32_e32 v1, v62, v57, vcc_lo                     // 0000001BEBB4: 0202733E
	v_dual_mul_f32 v61, v58, v43 :: v_dual_lshlrev_b32 v62, 16, v134// 0000001BEBB8: C8E2573A 3D3F0C90
	.long 0xd41e0001                                           // 0000001BEBC0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v45, vcc_lo              // 0000001BEBC4: 02025AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BEBCC: BF870092
	v_fma_f32 v71, -v59, v61, v58                              // 0000001BEBD0: D6130047 24EA7B3B
	v_fmac_f32_e32 v61, v71, v43                               // 0000001BEBD8: 567A5747
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BEBDC: BF870114
	v_mul_f32_e32 v71, 0xbfb8aa3b, v62                         // 0000001BEBE0: 108E7CFF BFB8AA3B
	v_fma_f32 v58, -v59, v61, v58                              // 0000001BEBE8: D613003A 24EA7B3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BEBF0: BF8701A2
	v_fma_f32 v73, 0xbfb8aa3b, v62, -v71                       // 0000001BEBF4: D6130049 851E7CFF BFB8AA3B
	v_rndne_f32_e32 v74, v71                                   // 0000001BEC00: 7E944747
	v_div_fmas_f32 v43, v58, v43, v61                          // 0000001BEC04: D637002B 04F6573A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000001BEC0C: 7C3C90FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BEC14: BF870214
	v_fmac_f32_e32 v73, 0xb2a5705f, v62                        // 0000001BEC18: 56927CFF B2A5705F
	v_sub_f32_e32 v71, v71, v74                                // 0000001BEC20: 088E9547
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BEC24: BF870004
	v_div_fixup_f32 v33, v43, v53, v33                         // 0000001BEC28: D6270021 04866B2B
	v_cndmask_b32_e32 v54, 0, v54, vcc_lo                      // 0000001BEC30: 026C6C80
	s_mov_b32 vcc_lo, s0                                       // 0000001BEC34: BEEA0000
	v_mul_f32_e32 v43, 0xbfb8aa3b, v45                         // 0000001BEC38: 10565AFF BFB8AA3B
	v_div_fmas_f32 v41, v41, v60, v77                          // 0000001BEC40: D6370029 05367929
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000001BEC48: 7C3690FF C2B17218
	.long 0x7e6a39a1                                           // 0000001BEC50: 7E6A39A1
	.long 0x7f6a3980                                           // 0000001BEC54: 7F6A3980
	v_fma_f32 v59, 0xbfb8aa3b, v45, -v43                       // 0000001BEC58: D613003B 84AE5AFF BFB8AA3B
	v_div_fixup_f32 v34, v41, v44, v34                         // 0000001BEC64: D6270022 048A5929
	v_cndmask_b32_e32 v54, 0x7f800000, v54, vcc_lo             // 0000001BEC6C: 026C6CFF 7F800000
	v_rndne_f32_e32 v60, v43                                   // 0000001BEC74: 7E78472B
	v_and_b32_e32 v53, 1, v53                                  // 0000001BEC78: 366A6A81
	v_fmac_f32_e32 v59, 0xb2a5705f, v45                        // 0000001BEC7C: 56765AFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BEC84: BF870214
	v_dual_add_f32 v71, v71, v73 :: v_dual_add_f32 v44, 1.0, v54// 0000001BEC88: C9089347 472C6CF2
	v_sub_f32_e32 v43, v43, v60                                // 0000001BEC90: 0856792B
	v_cvt_i32_f32_e32 v60, v60                                 // 0000001BEC94: 7E78113C
	v_add3_u32 v33, v33, v53, 0x7fff                           // 0000001BEC98: D6550021 03FE6B21 00007FFF
	.long 0x7e0039a2                                           // 0000001BECA4: 7E0039A2
	v_div_scale_f32 v42, null, v44, v44, v36                   // 0000001BECA8: D6FC7C2A 0492592C
	v_add_f32_e32 v43, v43, v59                                // 0000001BECB0: 0656772B
	global_store_d16_hi_b16 v[7:8], v33, off offset:96         // 0000001BECB4: DC960060 007C2107
	v_and_b32_e32 v61, 1, v0                                   // 0000001BECBC: 367A0081
	v_rcp_f32_e32 v58, v42                                     // 0000001BECC0: 7E74552A
	v_exp_f32_e32 v43, v43                                     // 0000001BECC4: 7E564B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000001BECC8: BF870151
	v_add3_u32 v34, v34, v61, 0x7fff                           // 0000001BECCC: D6550022 03FE7B22 00007FFF
	global_store_d16_hi_b16 v[47:48], v34, off offset:96       // 0000001BECD8: DC960060 007C222F
	v_fma_f32 v72, -v42, v58, 1.0                              // 0000001BECE0: D6130048 23CA752A
	.long 0xd71c002b                                           // 0000001BECE8: D71C002B
	v_cndmask_b32_e32 v1, v43, v60, vcc_lo                     // 0000001BECEC: 0202792B
	v_exp_f32_e32 v60, v71                                     // 0000001BECF0: 7E784B47
	v_fmac_f32_e32 v58, v72, v58                               // 0000001BECF4: 56747548
	v_div_scale_f32 v72, s0, v36, v44, v36                     // 0000001BECF8: D6FC0048 04925924
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BED00: BF8701A3
	v_cndmask_b32_e64 v43, 0, v43, s1                          // 0000001BED04: D501002B 00065680
	.long 0xd41b0001                                           // 0000001BED0C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v45, vcc_lo              // 0000001BED10: 02025AFF C2B17218
	v_mul_f32_e32 v75, v72, v58                                // 0000001BED18: 10967548
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BED1C: BF870112
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 0000001BED20: D501002B 000656FF 7F800000
	v_fma_f32 v53, -v42, v75, v72                              // 0000001BED2C: D6130035 2522972A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BED34: BF870112
	v_add_f32_e32 v43, 1.0, v43                                // 0000001BED38: 065656F2
	v_fmac_f32_e32 v75, v53, v58                               // 0000001BED3C: 56967535
	v_cvt_i32_f32_e32 v53, v74                                 // 0000001BED40: 7E6A114A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BED44: BF870112
	v_fma_f32 v42, -v42, v75, v72                              // 0000001BED48: D613002A 2522972A
	.long 0xd71c002d                                           // 0000001BED50: D71C002D
	v_cndmask_b32_e32 v1, v60, v53, vcc_lo                     // 0000001BED54: 02026B3C
	s_waitcnt vmcnt(4)                                         // 0000001BED58: BF8913F7
	v_lshlrev_b32_e32 v60, 16, v136                            // 0000001BED5C: 30791090
	v_div_scale_f32 v57, null, v46, v46, v35                   // 0000001BED60: D6FC7C39 048E5D2E
	v_div_scale_f32 v53, null, v43, v43, v37                   // 0000001BED68: D6FC7C35 0496572B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001BED70: BF870292
	v_rcp_f32_e32 v41, v57                                     // 0000001BED74: 7E525539
	v_fma_f32 v54, -v57, v41, 1.0                              // 0000001BED78: D6130036 23CA5339
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BED80: BF8700A1
	v_fmac_f32_e32 v41, v54, v41                               // 0000001BED84: 56525336
	v_div_scale_f32 v54, vcc_lo, v35, v46, v35                 // 0000001BED88: D6FC6A36 048E5D23
	v_mul_f32_e32 v59, v54, v41                                // 0000001BED90: 10765336
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BED94: BF870091
	v_fma_f32 v61, -v57, v59, v54                              // 0000001BED98: D613003D 24DA7739
	v_fmac_f32_e32 v59, v61, v41                               // 0000001BEDA0: 5676533D
	v_mul_f32_e32 v61, 0xbfb8aa3b, v60                         // 0000001BEDA4: 107A78FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BEDAC: BF870112
	v_fma_f32 v54, -v57, v59, v54                              // 0000001BEDB0: D6130036 24DA7739
	v_fma_f32 v71, 0xbfb8aa3b, v60, -v61                       // 0000001BEDB8: D6130047 84F678FF BFB8AA3B
	v_rndne_f32_e32 v72, v61                                   // 0000001BEDC4: 7E90473D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BEDC8: BF870223
	v_div_fmas_f32 v41, v54, v41, v59                          // 0000001BEDCC: D6370029 04EE5336
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v62                  // 0000001BEDD4: 7C3C7CFF 42CE8ED0
	v_fmac_f32_e32 v71, 0xb2a5705f, v60                        // 0000001BEDDC: 568E78FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BEDE4: BF870214
	v_sub_f32_e32 v61, v61, v72                                // 0000001BEDE8: 087A913D
	v_div_fixup_f32 v35, v41, v46, v35                         // 0000001BEDEC: D6270023 048E5D29
	v_cndmask_b32_e32 v45, 0, v45, vcc_lo                      // 0000001BEDF4: 025A5A80
	s_mov_b32 vcc_lo, s0                                       // 0000001BEDF8: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001BEDFC: BF870133
	v_add_f32_e32 v61, v61, v71                                // 0000001BEE00: 067A8F3D
	v_div_fmas_f32 v42, v42, v58, v75                          // 0000001BEE04: D637002A 052E752A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v62                  // 0000001BEE0C: 7C367CFF C2B17218
	v_div_fixup_f32 v33, v42, v44, v36                         // 0000001BEE14: D6270021 0492592A
	v_dual_cndmask_b32 v45, 0x7f800000, v45 :: v_dual_mul_f32 v36, v38, v51// 0000001BEE1C: CA465AFF 2D246726 7F800000
	v_lshlrev_b32_e32 v44, 16, v86                             // 0000001BEE28: 3058AC90
	v_rcp_f32_e32 v38, v53                                     // 0000001BEE2C: 7E4C5535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BEE30: BF870193
	.long 0x7e0039a1                                           // 0000001BEE34: 7E0039A1
	v_add_f32_e32 v42, 1.0, v45                                // 0000001BEE38: 06545AF2
	.long 0x7e5a39a3                                           // 0000001BEE3C: 7E5A39A3
	v_mul_f32_e32 v41, 0xbfb8aa3b, v44                         // 0000001BEE40: 105258FF BFB8AA3B
	.long 0x7f5a3980                                           // 0000001BEE48: 7F5A3980
	v_and_b32_e32 v59, 1, v0                                   // 0000001BEE4C: 36760081
	v_div_scale_f32 v34, null, v42, v42, v36                   // 0000001BEE50: D6FC7C22 0492552A
	.long 0xd41e0001                                           // 0000001BEE58: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v44, vcc_lo              // 0000001BEE5C: 020258FF 42CE8ED0
	v_fma_f32 v57, 0xbfb8aa3b, v44, -v41                       // 0000001BEE64: D6130039 84A658FF BFB8AA3B
	v_rndne_f32_e32 v58, v41                                   // 0000001BEE70: 7E744729
	v_fma_f32 v46, -v53, v38, 1.0                              // 0000001BEE74: D613002E 23CA4D35
	v_rcp_f32_e32 v54, v34                                     // 0000001BEE7C: 7E6C5522
	v_and_b32_e32 v45, 1, v45                                  // 0000001BEE80: 365A5A81
	v_fmac_f32_e32 v57, 0xb2a5705f, v44                        // 0000001BEE84: 567258FF B2A5705F
	v_sub_f32_e32 v41, v41, v58                                // 0000001BEE8C: 08527529
	v_fmac_f32_e32 v38, v46, v38                               // 0000001BEE90: 564C4D2E
	v_div_scale_f32 v46, vcc_lo, v37, v43, v37                 // 0000001BEE94: D6FC6A2E 04965725
	v_add3_u32 v33, v33, v59, 0x7fff                           // 0000001BEE9C: D6550021 03FE7721 00007FFF
	v_cvt_i32_f32_e32 v58, v58                                 // 0000001BEEA8: 7E74113A
	v_add_f32_e32 v41, v41, v57                                // 0000001BEEAC: 06527329
	v_add3_u32 v35, v35, v45, 0x7fff                           // 0000001BEEB0: D6550023 03FE5B23 00007FFF
	v_fma_f32 v62, -v34, v54, 1.0                              // 0000001BEEBC: D613003E 23CA6D22
	v_mul_f32_e32 v57, v46, v38                                // 0000001BEEC4: 10724D2E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BEEC8: BF870004
	v_exp_f32_e32 v41, v41                                     // 0000001BEECC: 7E524B29
	global_store_d16_hi_b16 v[15:16], v35, off offset:96       // 0000001BEED0: DC960060 007C230F
	v_fmac_f32_e32 v54, v62, v54                               // 0000001BEED8: 566C6D3E
	v_div_scale_f32 v62, s0, v36, v42, v36                     // 0000001BEEDC: D6FC003E 04925524
	v_fma_f32 v59, -v53, v57, v46                              // 0000001BEEE4: D613003B 24BA7335
	global_store_d16_hi_b16 v[23:24], v33, off offset:96       // 0000001BEEEC: DC960060 007C2117
	v_mul_f32_e32 v73, v62, v54                                // 0000001BEEF4: 10926D3E
	v_fmac_f32_e32 v57, v59, v38                               // 0000001BEEF8: 56724D3B
	.long 0xd71c0029                                           // 0000001BEEFC: D71C0029
	v_cndmask_b32_e32 v1, v41, v58, vcc_lo                     // 0000001BEF00: 02027529
	v_exp_f32_e32 v58, v61                                     // 0000001BEF04: 7E744B3D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BEF08: BF870193
	v_fma_f32 v45, -v34, v73, v62                              // 0000001BEF0C: D613002D 24FA9322
	v_fma_f32 v46, -v53, v57, v46                              // 0000001BEF14: D613002E 24BA7335
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BEF1C: BF870223
	v_cndmask_b32_e64 v41, 0, v41, s1                          // 0000001BEF20: D5010029 00065280
	.long 0xd41b0001                                           // 0000001BEF28: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v44, vcc_lo              // 0000001BEF2C: 020258FF C2B17218
	v_fmac_f32_e32 v73, v45, v54                               // 0000001BEF34: 56926D2D
	v_cvt_i32_f32_e32 v45, v72                                 // 0000001BEF38: 7E5A1148
	v_div_fmas_f32 v38, v46, v38, v57                          // 0000001BEF3C: D6370026 04E64D2E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v60                  // 0000001BEF44: 7C3C78FF 42CE8ED0
	v_cndmask_b32_e64 v41, 0x7f800000, v41, s1                 // 0000001BEF4C: D5010029 000652FF 7F800000
	v_fma_f32 v34, -v34, v73, v62                              // 0000001BEF58: D6130022 24FA9322
	.long 0xd71c002c                                           // 0000001BEF60: D71C002C
	v_cndmask_b32_e32 v1, v58, v45, vcc_lo                     // 0000001BEF64: 02025B3A
	v_div_fixup_f32 v37, v38, v43, v37                         // 0000001BEF68: D6270025 04965726
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BEF70: BF870224
	v_dual_add_f32 v41, 1.0, v41 :: v_dual_lshlrev_b32 v58, 16, v127// 0000001BEF74: C92252F2 293AFE90
	.long 0x7f563980                                           // 0000001BEF7C: 7F563980
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 0000001BEF80: 02585880
	s_mov_b32 vcc_lo, s0                                       // 0000001BEF84: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BEF88: BF870003
	v_mul_f32_e32 v59, 0xbfb8aa3b, v58                         // 0000001BEF8C: 107674FF BFB8AA3B
	v_div_fmas_f32 v34, v34, v54, v73                          // 0000001BEF94: D6370022 05266D22
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v60                  // 0000001BEF9C: 7C3678FF C2B17218
	v_div_scale_f32 v45, null, v41, v41, v25                   // 0000001BEFA4: D6FC7C2D 04665329
	.long 0x7e5639a5                                           // 0000001BEFAC: 7E5639A5
	v_fma_f32 v61, 0xbfb8aa3b, v58, -v59                       // 0000001BEFB0: D613003D 84EE74FF BFB8AA3B
	v_div_fixup_f32 v34, v34, v42, v36                         // 0000001BEFBC: D6270022 04925522
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo             // 0000001BEFC4: 025858FF 7F800000
	v_lshlrev_b32_e32 v42, 16, v128                            // 0000001BEFCC: 30550090
	v_rcp_f32_e32 v35, v45                                     // 0000001BEFD0: 7E46552D
	v_rndne_f32_e32 v62, v59                                   // 0000001BEFD4: 7E7C473B
	.long 0x7e0039a2                                           // 0000001BEFD8: 7E0039A2
	v_add_f32_e32 v36, 1.0, v44                                // 0000001BEFDC: 064858F2
	v_mul_f32_e32 v38, 0xbfb8aa3b, v42                         // 0000001BEFE0: 104C54FF BFB8AA3B
	v_fmac_f32_e32 v61, 0xb2a5705f, v58                        // 0000001BEFE8: 567A74FF B2A5705F
	v_sub_f32_e32 v59, v59, v62                                // 0000001BEFF0: 08767D3B
	v_and_b32_e32 v57, 1, v0                                   // 0000001BEFF4: 36720081
	v_div_scale_f32 v33, null, v36, v36, v26                   // 0000001BEFF8: D6FC7C21 046A4924
	v_fma_f32 v53, 0xbfb8aa3b, v42, -v38                       // 0000001BF000: D6130035 849A54FF BFB8AA3B
	v_rndne_f32_e32 v54, v38                                   // 0000001BF00C: 7E6C4726
	v_fma_f32 v44, -v45, v35, 1.0                              // 0000001BF010: D613002C 23CA472D
	v_and_b32_e32 v43, 1, v43                                  // 0000001BF018: 36565681
	v_rcp_f32_e32 v46, v33                                     // 0000001BF01C: 7E5C5521
	v_fmac_f32_e32 v53, 0xb2a5705f, v42                        // 0000001BF020: 566A54FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001BF028: BF870243
	v_dual_sub_f32 v38, v38, v54 :: v_dual_fmac_f32 v35, v44, v35// 0000001BF02C: C9406D26 2622472C
	v_div_scale_f32 v44, vcc_lo, v25, v41, v25                 // 0000001BF034: D6FC6A2C 04665319
	v_add3_u32 v34, v34, v57, 0x7fff                           // 0000001BF03C: D6550022 03FE7322 00007FFF
	v_cvt_i32_f32_e32 v54, v54                                 // 0000001BF048: 7E6C1136
	v_add_f32_e32 v38, v38, v53                                // 0000001BF04C: 064C6B26
	v_add_f32_e32 v59, v59, v61                                // 0000001BF050: 06767B3B
	v_mul_f32_e32 v53, v44, v35                                // 0000001BF054: 106A472C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001BF058: BF870005
	v_fma_f32 v60, -v33, v46, 1.0                              // 0000001BF05C: D613003C 23CA5D21
	v_add3_u32 v37, v37, v43, 0x7fff                           // 0000001BF064: D6550025 03FE5725 00007FFF
	v_exp_f32_e32 v38, v38                                     // 0000001BF070: 7E4C4B26
	.long 0xd41e0001                                           // 0000001BF074: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v42, vcc_lo              // 0000001BF078: 020254FF 42CE8ED0
	v_fma_f32 v57, -v45, v53, v44                              // 0000001BF080: D6130039 24B26B2D
	v_fmac_f32_e32 v46, v60, v46                               // 0000001BF088: 565C5D3C
	v_div_scale_f32 v60, s0, v26, v36, v26                     // 0000001BF08C: D6FC003C 046A491A
	global_store_d16_hi_b16 v[31:32], v37, off offset:96       // 0000001BF094: DC960060 007C251F
	v_lshlrev_b32_e32 v37, 16, v130                            // 0000001BF09C: 304B0490
	v_fmac_f32_e32 v53, v57, v35                               // 0000001BF0A0: 566A4739
	global_store_d16_hi_b16 v[39:40], v34, off offset:96       // 0000001BF0A4: DC960060 007C2227
	v_mul_f32_e32 v71, v60, v46                                // 0000001BF0AC: 108E5D3C
	.long 0xd71c0026                                           // 0000001BF0B0: D71C0026
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 0000001BF0B4: 02026D26
	v_exp_f32_e32 v54, v59                                     // 0000001BF0B8: 7E6C4B3B
	v_fma_f32 v44, -v45, v53, v44                              // 0000001BF0BC: D613002C 24B26B2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BF0C4: BF870193
	v_fma_f32 v43, -v33, v71, v60                              // 0000001BF0C8: D613002B 24F28F21
	v_cndmask_b32_e64 v38, 0, v38, s1                          // 0000001BF0D0: D5010026 00064C80
	.long 0xd41b0001                                           // 0000001BF0D8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v42, vcc_lo              // 0000001BF0DC: 020254FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BF0E4: BF870004
	v_div_fmas_f32 v35, v44, v35, v53                          // 0000001BF0E8: D6370023 04D6472C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v58                  // 0000001BF0F0: 7C3C74FF 42CE8ED0
	v_fmac_f32_e32 v71, v43, v46                               // 0000001BF0F8: 568E5D2B
	v_cvt_i32_f32_e32 v43, v62                                 // 0000001BF0FC: 7E56113E
	v_cndmask_b32_e64 v38, 0x7f800000, v38, s1                 // 0000001BF100: D5010026 00064CFF 7F800000
	v_div_fixup_f32 v25, v35, v41, v25                         // 0000001BF10C: D6270019 04665323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v37                         // 0000001BF114: 10464AFF BFB8AA3B
	v_fma_f32 v33, -v33, v71, v60                              // 0000001BF11C: D6130021 24F28F21
	.long 0xd71c002a                                           // 0000001BF124: D71C002A
	v_cndmask_b32_e32 v1, v54, v43, vcc_lo                     // 0000001BF128: 02025736
	v_add_f32_e32 v38, 1.0, v38                                // 0000001BF12C: 064C4CF2
	v_lshlrev_b32_e32 v54, 16, v129                            // 0000001BF130: 306D0290
	v_fma_f32 v45, 0xbfb8aa3b, v37, -v35                       // 0000001BF134: D613002D 848E4AFF BFB8AA3B
	.long 0x7e523999                                           // 0000001BF140: 7E523999
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000001BF144: 02545480
	s_mov_b32 vcc_lo, s0                                       // 0000001BF148: BEEA0000
	v_div_scale_f32 v43, null, v38, v38, v27                   // 0000001BF14C: D6FC7C2B 046E4D26
	v_div_fmas_f32 v33, v33, v46, v71                          // 0000001BF154: D6370021 051E5D21
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v58                  // 0000001BF15C: 7C3674FF C2B17218
	v_rndne_f32_e32 v46, v35                                   // 0000001BF164: 7E5C4723
	v_fmac_f32_e32 v45, 0xb2a5705f, v37                        // 0000001BF168: 565A4AFF B2A5705F
	v_mul_f32_e32 v57, 0xbfb8aa3b, v54                         // 0000001BF170: 10726CFF BFB8AA3B
	v_div_fixup_f32 v26, v33, v36, v26                         // 0000001BF178: D627001A 046A4921
	v_cndmask_b32_e32 v42, 0x7f800000, v42, vcc_lo             // 0000001BF180: 025454FF 7F800000
	v_rcp_f32_e32 v33, v43                                     // 0000001BF188: 7E42552B
	v_sub_f32_e32 v35, v35, v46                                // 0000001BF18C: 08465D23
	v_fma_f32 v59, 0xbfb8aa3b, v54, -v57                       // 0000001BF190: D613003B 84E66CFF BFB8AA3B
	.long 0x7e00399a                                           // 0000001BF19C: 7E00399A
	v_add_f32_e32 v36, 1.0, v42                                // 0000001BF1A0: 064854F2
	v_rndne_f32_e32 v60, v57                                   // 0000001BF1A4: 7E784739
	v_add_f32_e32 v35, v35, v45                                // 0000001BF1A8: 06465B23
	.long 0x7f523980                                           // 0000001BF1AC: 7F523980
	v_and_b32_e32 v53, 1, v0                                   // 0000001BF1B0: 366A0081
	v_div_scale_f32 v34, null, v36, v36, v28                   // 0000001BF1B4: D6FC7C22 04724924
	v_fma_f32 v42, -v43, v33, 1.0                              // 0000001BF1BC: D613002A 23CA432B
	v_exp_f32_e32 v35, v35                                     // 0000001BF1C4: 7E464B23
	v_fmac_f32_e32 v59, 0xb2a5705f, v54                        // 0000001BF1C8: 56766CFF B2A5705F
	v_sub_f32_e32 v57, v57, v60                                // 0000001BF1D0: 08727939
	v_rcp_f32_e32 v44, v34                                     // 0000001BF1D4: 7E585522
	v_fmac_f32_e32 v33, v42, v33                               // 0000001BF1D8: 5642432A
	v_div_scale_f32 v42, vcc_lo, v27, v38, v27                 // 0000001BF1DC: D6FC6A2A 046E4D1B
	v_and_b32_e32 v41, 1, v41                                  // 0000001BF1E4: 36525281
	v_add3_u32 v26, v26, v53, 0x7fff                           // 0000001BF1E8: D655001A 03FE6B1A 00007FFF
	v_cvt_i32_f32_e32 v46, v46                                 // 0000001BF1F4: 7E5C112E
	v_add_f32_e32 v57, v57, v59                                // 0000001BF1F8: 06727739
	v_mul_f32_e32 v45, v42, v33                                // 0000001BF1FC: 105A432A
	v_add3_u32 v25, v25, v41, 0x7fff                           // 0000001BF200: D6550019 03FE5319 00007FFF
	.long 0xd41e0001                                           // 0000001BF20C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v37, vcc_lo              // 0000001BF210: 02024AFF 42CE8ED0
	v_fma_f32 v58, -v34, v44, 1.0                              // 0000001BF218: D613003A 23CA5922
	.long 0xd71c0023                                           // 0000001BF220: D71C0023
	v_cndmask_b32_e32 v1, v35, v46, vcc_lo                     // 0000001BF224: 02025D23
	v_fma_f32 v53, -v43, v45, v42                              // 0000001BF228: D6130035 24AA5B2B
	v_exp_f32_e32 v46, v57                                     // 0000001BF230: 7E5C4B39
	global_store_d16_hi_b16 v[7:8], v25, off offset:128        // 0000001BF234: DC960080 007C1907
	v_fmac_f32_e32 v44, v58, v44                               // 0000001BF23C: 5658593A
	v_div_scale_f32 v58, s0, v28, v36, v28                     // 0000001BF240: D6FC003A 0472491C
	v_fmac_f32_e32 v45, v53, v33                               // 0000001BF248: 565A4335
	v_cndmask_b32_e64 v35, 0, v35, s1                          // 0000001BF24C: D5010023 00064680
	.long 0xd41b0001                                           // 0000001BF254: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v37, vcc_lo              // 0000001BF258: 02024AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v26, off offset:128      // 0000001BF260: DC960080 007C1A2F
	v_mul_f32_e32 v61, v58, v44                                // 0000001BF268: 107A593A
	v_fma_f32 v42, -v43, v45, v42                              // 0000001BF26C: D613002A 24AA5B2B
	v_cndmask_b32_e64 v35, 0x7f800000, v35, s1                 // 0000001BF274: D5010023 000646FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BF280: BF870193
	v_fma_f32 v41, -v34, v61, v58                              // 0000001BF284: D6130029 24EA7B22
	v_div_fmas_f32 v33, v42, v33, v45                          // 0000001BF28C: D6370021 04B6432A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v54                  // 0000001BF294: 7C3C6CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BF29C: BF870214
	v_add_f32_e32 v35, 1.0, v35                                // 0000001BF2A0: 064646F2
	v_fmac_f32_e32 v61, v41, v44                               // 0000001BF2A4: 567A5929
	v_cvt_i32_f32_e32 v41, v60                                 // 0000001BF2A8: 7E52113C
	v_div_fixup_f32 v27, v33, v38, v27                         // 0000001BF2AC: D627001B 046E4D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BF2B4: BF870193
	v_fma_f32 v34, -v34, v61, v58                              // 0000001BF2B8: D6130022 24EA7B22
	.long 0xd71c0025                                           // 0000001BF2C0: D71C0025
	v_cndmask_b32_e32 v1, v46, v41, vcc_lo                     // 0000001BF2C4: 0202532E
	v_div_scale_f32 v41, null, v35, v35, v29                   // 0000001BF2C8: D6FC7C29 04764723
	s_waitcnt vmcnt(3)                                         // 0000001BF2D0: BF890FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BF2D4: BF8700A2
	v_dual_cndmask_b32 v37, 0, v37 :: v_dual_lshlrev_b32 v46, 16, v131// 0000001BF2D8: CA624A80 252F0690
	s_mov_b32 vcc_lo, s0                                       // 0000001BF2E0: BEEA0000
	v_mul_f32_e32 v53, 0xbfb8aa3b, v46                         // 0000001BF2E4: 106A5CFF BFB8AA3B
	v_div_fmas_f32 v34, v34, v44, v61                          // 0000001BF2EC: D6370022 04F65922
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v54                  // 0000001BF2F4: 7C366CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BF2FC: BF870193
	v_fma_f32 v57, 0xbfb8aa3b, v46, -v53                       // 0000001BF300: D6130039 84D65CFF BFB8AA3B
	v_div_fixup_f32 v25, v34, v36, v28                         // 0000001BF30C: D6270019 04724922
	v_dual_cndmask_b32 v37, 0x7f800000, v37 :: v_dual_mul_f32 v28, v30, v51// 0000001BF314: CA464AFF 251C671E 7F800000
	v_lshlrev_b32_e32 v36, 16, v87                             // 0000001BF320: 3048AE90
	v_rcp_f32_e32 v30, v41                                     // 0000001BF324: 7E3C5529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BF328: BF870193
	.long 0x7e003999                                           // 0000001BF32C: 7E003999
	v_add_f32_e32 v34, 1.0, v37                                // 0000001BF330: 06444AF2
	v_rndne_f32_e32 v58, v53                                   // 0000001BF334: 7E744735
	v_mul_f32_e32 v33, 0xbfb8aa3b, v36                         // 0000001BF338: 104248FF BFB8AA3B
	.long 0x7e4a399b                                           // 0000001BF340: 7E4A399B
	.long 0x7f4a3980                                           // 0000001BF344: 7F4A3980
	v_div_scale_f32 v26, null, v34, v34, v28                   // 0000001BF348: D6FC7C1A 04724522
	v_and_b32_e32 v45, 1, v0                                   // 0000001BF350: 365A0081
	v_fma_f32 v43, 0xbfb8aa3b, v36, -v33                       // 0000001BF354: D613002B 848648FF BFB8AA3B
	v_rndne_f32_e32 v44, v33                                   // 0000001BF360: 7E584721
	v_fma_f32 v38, -v41, v30, 1.0                              // 0000001BF364: D6130026 23CA3D29
	v_rcp_f32_e32 v42, v26                                     // 0000001BF36C: 7E54551A
	v_fmac_f32_e32 v57, 0xb2a5705f, v46                        // 0000001BF370: 56725CFF B2A5705F
	v_fmac_f32_e32 v43, 0xb2a5705f, v36                        // 0000001BF378: 565648FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001BF380: BF870243
	v_dual_sub_f32 v33, v33, v44 :: v_dual_fmac_f32 v30, v38, v30// 0000001BF384: C9405921 211E3D26
	v_div_scale_f32 v38, vcc_lo, v29, v35, v29                 // 0000001BF38C: D6FC6A26 0476471D
	v_sub_f32_e32 v53, v53, v58                                // 0000001BF394: 086A7535
	v_and_b32_e32 v37, 1, v37                                  // 0000001BF398: 364A4A81
	v_add_f32_e32 v33, v33, v43                                // 0000001BF39C: 06425721
	v_add3_u32 v25, v25, v45, 0x7fff                           // 0000001BF3A0: D6550019 03FE5B19 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001BF3AC: BF8701C5
	v_fma_f32 v54, -v26, v42, 1.0                              // 0000001BF3B0: D6130036 23CA551A
	v_mul_f32_e32 v43, v38, v30                                // 0000001BF3B8: 10563D26
	v_cvt_i32_f32_e32 v44, v44                                 // 0000001BF3BC: 7E58112C
	v_exp_f32_e32 v33, v33                                     // 0000001BF3C0: 7E424B21
	v_dual_add_f32 v53, v53, v57 :: v_dual_fmac_f32 v42, v54, v42// 0000001BF3C4: C9007335 352A5536
	v_div_scale_f32 v54, s0, v28, v34, v28                     // 0000001BF3CC: D6FC0036 0472451C
	v_fma_f32 v45, -v41, v43, v38                              // 0000001BF3D4: D613002D 249A5729
	v_add3_u32 v27, v27, v37, 0x7fff                           // 0000001BF3DC: D655001B 03FE4B1B 00007FFF
	.long 0xd41e0001                                           // 0000001BF3E8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v36, vcc_lo              // 0000001BF3EC: 020248FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BF3F4: BF870214
	v_mul_f32_e32 v59, v54, v42                                // 0000001BF3F8: 10765536
	v_fmac_f32_e32 v43, v45, v30                               // 0000001BF3FC: 56563D2D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001BF400: BF870005
	.long 0xd71c0021                                           // 0000001BF404: D71C0021
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 0000001BF408: 02025921
	v_exp_f32_e32 v44, v53                                     // 0000001BF40C: 7E584B35
	global_store_d16_hi_b16 v[15:16], v27, off offset:128      // 0000001BF410: DC960080 007C1B0F
	v_fma_f32 v37, -v26, v59, v54                              // 0000001BF418: D6130025 24DA771A
	v_fma_f32 v38, -v41, v43, v38                              // 0000001BF420: D6130026 249A5729
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 0000001BF428: D5010021 00064280
	.long 0xd41b0001                                           // 0000001BF430: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v36, vcc_lo              // 0000001BF434: 020248FF C2B17218
	global_store_d16_hi_b16 v[23:24], v25, off offset:128      // 0000001BF43C: DC960080 007C1917
	v_fmac_f32_e32 v59, v37, v42                               // 0000001BF444: 56765525
	v_cvt_i32_f32_e32 v37, v58                                 // 0000001BF448: 7E4A113A
	v_div_fmas_f32 v30, v38, v30, v43                          // 0000001BF44C: D637001E 04AE3D26
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 0000001BF454: 7C3C5CFF 42CE8ED0
	v_cndmask_b32_e64 v33, 0x7f800000, v33, s1                 // 0000001BF45C: D5010021 000642FF 7F800000
	v_fma_f32 v26, -v26, v59, v54                              // 0000001BF468: D613001A 24DA771A
	.long 0xd71c0024                                           // 0000001BF470: D71C0024
	v_cndmask_b32_e32 v1, v44, v37, vcc_lo                     // 0000001BF474: 02024B2C
	v_div_fixup_f32 v29, v30, v35, v29                         // 0000001BF478: D627001D 0476471E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BF480: BF870224
	v_dual_add_f32 v33, 1.0, v33 :: v_dual_lshlrev_b32 v44, 16, v123// 0000001BF484: C92242F2 212CF690
	.long 0x7f463980                                           // 0000001BF48C: 7F463980
	v_cndmask_b32_e32 v36, 0, v36, vcc_lo                      // 0000001BF490: 02484880
	s_mov_b32 vcc_lo, s0                                       // 0000001BF494: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BF498: BF870003
	v_mul_f32_e32 v45, 0xbfb8aa3b, v44                         // 0000001BF49C: 105A58FF BFB8AA3B
	v_div_fmas_f32 v26, v26, v42, v59                          // 0000001BF4A4: D637001A 04EE551A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 0000001BF4AC: 7C365CFF C2B17218
	v_div_scale_f32 v37, null, v33, v33, v17                   // 0000001BF4B4: D6FC7C25 04464321
	.long 0x7e46399d                                           // 0000001BF4BC: 7E46399D
	v_fma_f32 v53, 0xbfb8aa3b, v44, -v45                       // 0000001BF4C0: D6130035 84B658FF BFB8AA3B
	v_div_fixup_f32 v26, v26, v34, v28                         // 0000001BF4CC: D627001A 0472451A
	v_cndmask_b32_e32 v36, 0x7f800000, v36, vcc_lo             // 0000001BF4D4: 024848FF 7F800000
	v_lshlrev_b32_e32 v34, 16, v124                            // 0000001BF4DC: 3044F890
	v_rcp_f32_e32 v27, v37                                     // 0000001BF4E0: 7E365525
	v_rndne_f32_e32 v54, v45                                   // 0000001BF4E4: 7E6C472D
	.long 0x7e00399a                                           // 0000001BF4E8: 7E00399A
	v_add_f32_e32 v28, 1.0, v36                                // 0000001BF4EC: 063848F2
	v_mul_f32_e32 v30, 0xbfb8aa3b, v34                         // 0000001BF4F0: 103C44FF BFB8AA3B
	v_fmac_f32_e32 v53, 0xb2a5705f, v44                        // 0000001BF4F8: 566A58FF B2A5705F
	v_sub_f32_e32 v45, v45, v54                                // 0000001BF500: 085A6D2D
	v_and_b32_e32 v43, 1, v0                                   // 0000001BF504: 36560081
	v_div_scale_f32 v25, null, v28, v28, v18                   // 0000001BF508: D6FC7C19 044A391C
	v_fma_f32 v41, 0xbfb8aa3b, v34, -v30                       // 0000001BF510: D6130029 847A44FF BFB8AA3B
	v_rndne_f32_e32 v42, v30                                   // 0000001BF51C: 7E54471E
	v_fma_f32 v36, -v37, v27, 1.0                              // 0000001BF520: D6130024 23CA3725
	v_and_b32_e32 v35, 1, v35                                  // 0000001BF528: 36464681
	v_rcp_f32_e32 v38, v25                                     // 0000001BF52C: 7E4C5519
	v_fmac_f32_e32 v41, 0xb2a5705f, v34                        // 0000001BF530: 565244FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001BF538: BF870243
	v_dual_sub_f32 v30, v30, v42 :: v_dual_fmac_f32 v27, v36, v27// 0000001BF53C: C940551E 1E1A3724
	v_div_scale_f32 v36, vcc_lo, v17, v33, v17                 // 0000001BF544: D6FC6A24 04464311
	v_add3_u32 v26, v26, v43, 0x7fff                           // 0000001BF54C: D655001A 03FE571A 00007FFF
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001BF558: 7E54112A
	v_add_f32_e32 v30, v30, v41                                // 0000001BF55C: 063C531E
	v_add_f32_e32 v45, v45, v53                                // 0000001BF560: 065A6B2D
	v_mul_f32_e32 v41, v36, v27                                // 0000001BF564: 10523724
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001BF568: BF870005
	v_fma_f32 v46, -v25, v38, 1.0                              // 0000001BF56C: D613002E 23CA4D19
	v_add3_u32 v29, v29, v35, 0x7fff                           // 0000001BF574: D655001D 03FE471D 00007FFF
	v_exp_f32_e32 v30, v30                                     // 0000001BF580: 7E3C4B1E
	.long 0xd41e0001                                           // 0000001BF584: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v34, vcc_lo              // 0000001BF588: 020244FF 42CE8ED0
	v_fma_f32 v43, -v37, v41, v36                              // 0000001BF590: D613002B 24925325
	v_fmac_f32_e32 v38, v46, v38                               // 0000001BF598: 564C4D2E
	v_div_scale_f32 v46, s0, v18, v28, v18                     // 0000001BF59C: D6FC002E 044A3912
	s_clause 0x1                                               // 0000001BF5A4: BF850001
	global_store_d16_hi_b16 v[31:32], v29, off offset:128      // 0000001BF5A8: DC960080 007C1D1F
	global_store_d16_hi_b16 v[39:40], v26, off offset:128      // 0000001BF5B0: DC960080 007C1A27
	v_dual_fmac_f32 v41, v43, v27 :: v_dual_lshlrev_b32 v26, 16, v126// 0000001BF5B8: C822372B 291AFC90
	v_mul_f32_e32 v57, v46, v38                                // 0000001BF5C0: 10724D2E
	.long 0xd71c001e                                           // 0000001BF5C4: D71C001E
	v_cndmask_b32_e32 v1, v30, v42, vcc_lo                     // 0000001BF5C8: 0202551E
	v_exp_f32_e32 v42, v45                                     // 0000001BF5CC: 7E544B2D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BF5D0: BF870003
	v_fma_f32 v36, -v37, v41, v36                              // 0000001BF5D4: D6130024 24925325
	.long 0x7f3a3980                                           // 0000001BF5DC: 7F3A3980
	v_fma_f32 v35, -v25, v57, v46                              // 0000001BF5E0: D6130023 24BA7319
	v_cndmask_b32_e64 v30, 0, v30, s1                          // 0000001BF5E8: D501001E 00063C80
	.long 0xd41b0001                                           // 0000001BF5F0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v34, vcc_lo              // 0000001BF5F4: 020244FF C2B17218
	v_div_fmas_f32 v27, v36, v27, v41                          // 0000001BF5FC: D637001B 04A63724
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v44                  // 0000001BF604: 7C3C58FF 42CE8ED0
	v_fmac_f32_e32 v57, v35, v38                               // 0000001BF60C: 56724D23
	v_cvt_i32_f32_e32 v35, v54                                 // 0000001BF610: 7E461136
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000001BF614: D501001E 00063CFF 7F800000
	v_div_fixup_f32 v17, v27, v33, v17                         // 0000001BF620: D6270011 0446431B
	v_mul_f32_e32 v33, 0xbfb8aa3b, v26                         // 0000001BF628: 104234FF BFB8AA3B
	v_fma_f32 v25, -v25, v57, v46                              // 0000001BF630: D6130019 24BA7319
	.long 0xd71c0022                                           // 0000001BF638: D71C0022
	v_cndmask_b32_e32 v1, v42, v35, vcc_lo                     // 0000001BF63C: 0202472A
	v_add_f32_e32 v30, 1.0, v30                                // 0000001BF640: 063C3CF2
	.long 0xd41e0001                                           // 0000001BF644: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v26, vcc_lo              // 0000001BF648: 020234FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v26, -v33                       // 0000001BF650: D6130029 848634FF BFB8AA3B
	v_rndne_f32_e32 v42, v33                                   // 0000001BF65C: 7E544721
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000001BF660: 02444480
	s_mov_b32 vcc_lo, s0                                       // 0000001BF664: BEEA0000
	v_div_scale_f32 v35, null, v30, v30, v19                   // 0000001BF668: D6FC7C23 044E3D1E
	v_div_fmas_f32 v25, v25, v38, v57                          // 0000001BF670: D6370019 04E64D19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v44                  // 0000001BF678: 7C3658FF C2B17218
	v_dual_fmac_f32 v41, 0xb2a5705f, v26 :: v_dual_lshlrev_b32 v38, 16, v125// 0000001BF680: C82234FF 2926FA90 B2A5705F
	v_sub_f32_e32 v33, v33, v42                                // 0000001BF68C: 08425521
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BF690: BF870004
	v_div_fixup_f32 v18, v25, v28, v18                         // 0000001BF694: D6270012 044A3919
	v_cndmask_b32_e32 v34, 0x7f800000, v34, vcc_lo             // 0000001BF69C: 024444FF 7F800000
	v_rcp_f32_e32 v25, v35                                     // 0000001BF6A4: 7E325523
	v_mul_f32_e32 v43, 0xbfb8aa3b, v38                         // 0000001BF6A8: 10564CFF BFB8AA3B
	v_add_f32_e32 v33, v33, v41                                // 0000001BF6B0: 06425321
	.long 0x7e003992                                           // 0000001BF6B4: 7E003992
	v_add_f32_e32 v28, 1.0, v34                                // 0000001BF6B8: 063844F2
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001BF6BC: 7E54112A
	v_fma_f32 v46, 0xbfb8aa3b, v38, -v43                       // 0000001BF6C0: D613002E 84AE4CFF BFB8AA3B
	v_rndne_f32_e32 v53, v43                                   // 0000001BF6CC: 7E6A472B
	v_exp_f32_e32 v33, v33                                     // 0000001BF6D0: 7E424B21
	v_div_scale_f32 v27, null, v28, v28, v20                   // 0000001BF6D4: D6FC7C1B 0452391C
	v_fma_f32 v34, -v35, v25, 1.0                              // 0000001BF6DC: D6130022 23CA3323
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BF6E4: BF870223
	v_dual_fmac_f32 v46, 0xb2a5705f, v38 :: v_dual_sub_f32 v43, v43, v53// 0000001BF6E8: C80A4CFF 2E2A6B2B B2A5705F
	v_div_scale_f32 v41, s0, v20, v28, v20                     // 0000001BF6F4: D6FC0029 04523914
	v_rcp_f32_e32 v36, v27                                     // 0000001BF6FC: 7E48551B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BF700: BF870003
	v_fmac_f32_e32 v25, v34, v25                               // 0000001BF704: 56323322
	v_div_scale_f32 v34, vcc_lo, v19, v30, v19                 // 0000001BF708: D6FC6A22 044E3D13
	v_and_b32_e32 v37, 1, v0                                   // 0000001BF710: 364A0081
	v_add_f32_e32 v43, v43, v46                                // 0000001BF714: 06565D2B
	.long 0xd71c0021                                           // 0000001BF718: D71C0021
	v_cndmask_b32_e32 v1, v33, v42, vcc_lo                     // 0000001BF71C: 02025521
	.long 0x7e3a3991                                           // 0000001BF720: 7E3A3991
	v_mul_f32_e32 v45, v34, v25                                // 0000001BF724: 105A3322
	v_add3_u32 v18, v18, v37, 0x7fff                           // 0000001BF728: D6550012 03FE4B12 00007FFF
	v_exp_f32_e32 v37, v43                                     // 0000001BF734: 7E4A4B2B
	v_fma_f32 v44, -v27, v36, 1.0                              // 0000001BF738: D613002C 23CA491B
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 0000001BF740: D5010021 00064280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BF748: BF870122
	v_dual_fmac_f32 v36, v44, v36 :: v_dual_and_b32 v29, 1, v29// 0000001BF74C: C824492C 241C3A81
	v_fma_f32 v44, -v35, v45, v34                              // 0000001BF754: D613002C 248A5B23
	v_add3_u32 v17, v17, v29, 0x7fff                           // 0000001BF75C: D6550011 03FE3B11 00007FFF
	v_lshlrev_b32_e32 v29, 16, v92                             // 0000001BF768: 303AB890
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BF76C: BF870003
	v_dual_mul_f32 v54, v41, v36 :: v_dual_fmac_f32 v45, v44, v25// 0000001BF770: C8C04929 362C332C
	s_clause 0x1                                               // 0000001BF778: BF850001
	global_store_d16_hi_b16 v[7:8], v17, off offset:160        // 0000001BF77C: DC9600A0 007C1107
	global_store_d16_hi_b16 v[47:48], v18, off offset:160      // 0000001BF784: DC9600A0 007C122F
	v_fma_f32 v44, -v27, v54, v41                              // 0000001BF78C: D613002C 24A66D1B
	v_fma_f32 v34, -v35, v45, v34                              // 0000001BF794: D6130022 248A5B23
	v_cvt_i32_f32_e32 v35, v53                                 // 0000001BF79C: 7E461135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BF7A0: BF870193
	v_fmac_f32_e32 v54, v44, v36                               // 0000001BF7A4: 566C492C
	v_div_fmas_f32 v25, v34, v25, v45                          // 0000001BF7A8: D6370019 04B63322
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v26                  // 0000001BF7B0: 7C3634FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BF7B8: BF870004
	.long 0xd71c0022                                           // 0000001BF7BC: D71C0022
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 0000001BF7C0: 02024725
	v_mul_f32_e32 v35, 0xbfb8aa3b, v29                         // 0000001BF7C4: 10463AFF BFB8AA3B
	v_fma_f32 v27, -v27, v54, v41                              // 0000001BF7CC: D613001B 24A66D1B
	v_div_fixup_f32 v17, v25, v30, v19                         // 0000001BF7D4: D6270011 044E3D19
	v_cndmask_b32_e32 v26, 0x7f800000, v33, vcc_lo             // 0000001BF7DC: 023442FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 0000001BF7E4: 7C3C4CFF 42CE8ED0
	.long 0x7f3c3980                                           // 0000001BF7EC: 7F3C3980
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BF7F0: BF870214
	.long 0x7e3c3991                                           // 0000001BF7F4: 7E3C3991
	v_add_f32_e32 v26, 1.0, v26                                // 0000001BF7F8: 063434F2
	v_cndmask_b32_e32 v33, 0, v34, vcc_lo                      // 0000001BF7FC: 02424480
	s_mov_b32 vcc_lo, s0                                       // 0000001BF800: BEEA0000
	v_div_fmas_f32 v27, v27, v36, v54                          // 0000001BF804: D637001B 04DA491B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 0000001BF80C: 7C364CFF C2B17218
	v_rndne_f32_e32 v36, v35                                   // 0000001BF814: 7E484723
	s_waitcnt vmcnt(2)                                         // 0000001BF818: BF890BF7
	v_lshlrev_b32_e32 v38, 16, v68                             // 0000001BF81C: 304C8890
	v_and_b32_e32 v30, 1, v30                                  // 0000001BF820: 363C3C81
	v_div_fixup_f32 v20, v27, v28, v20                         // 0000001BF824: D6270014 0452391B
	v_cndmask_b32_e32 v33, 0x7f800000, v33, vcc_lo             // 0000001BF82C: 024242FF 7F800000
	v_div_scale_f32 v27, null, v26, v26, v21                   // 0000001BF834: D6FC7C1B 0456351A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BF83C: BF870214
	v_add3_u32 v17, v17, v30, 0x7fff                           // 0000001BF840: D6550011 03FE3D11 00007FFF
	.long 0x7e003994                                           // 0000001BF84C: 7E003994
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BF850: BF870214
	v_add_f32_e32 v28, 1.0, v33                                // 0000001BF854: 063842F2
	v_rcp_f32_e32 v19, v27                                     // 0000001BF858: 7E26551B
	global_store_d16_hi_b16 v[15:16], v17, off offset:160      // 0000001BF85C: DC9600A0 007C110F
	v_and_b32_e32 v33, 1, v0                                   // 0000001BF864: 36420081
	v_div_scale_f32 v25, null, v28, v28, v22                   // 0000001BF868: D6FC7C19 045A391C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BF870: BF870112
	v_add3_u32 v20, v20, v33, 0x7fff                           // 0000001BF874: D6550014 03FE4314 00007FFF
	v_rcp_f32_e32 v34, v25                                     // 0000001BF880: 7E445519
	v_fma_f32 v18, -v27, v19, 1.0                              // 0000001BF884: D6130012 23CA271B
	v_fma_f32 v33, 0xbfb8aa3b, v29, -v35                       // 0000001BF88C: D6130021 848E3AFF BFB8AA3B
	v_sub_f32_e32 v35, v35, v36                                // 0000001BF898: 08464923
	v_cvt_i32_f32_e32 v36, v36                                 // 0000001BF89C: 7E481124
	global_store_d16_hi_b16 v[23:24], v20, off offset:160      // 0000001BF8A0: DC9600A0 007C1417
	v_fmac_f32_e32 v19, v18, v19                               // 0000001BF8A8: 56262712
	v_div_scale_f32 v18, vcc_lo, v21, v26, v21                 // 0000001BF8AC: D6FC6A12 04563515
	v_fmac_f32_e32 v33, 0xb2a5705f, v29                        // 0000001BF8B4: 56423AFF B2A5705F
	v_fma_f32 v37, -v25, v34, 1.0                              // 0000001BF8BC: D6130025 23CA4519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BF8C4: BF870193
	v_mul_f32_e32 v41, v18, v19                                // 0000001BF8C8: 10522712
	v_add_f32_e32 v33, v35, v33                                // 0000001BF8CC: 06424323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v38                         // 0000001BF8D0: 10464CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BF8D8: BF870004
	v_fmac_f32_e32 v34, v37, v34                               // 0000001BF8DC: 56444525
	v_div_scale_f32 v37, s0, v22, v28, v22                     // 0000001BF8E0: D6FC0025 045A3916
	v_fma_f32 v30, -v27, v41, v18                              // 0000001BF8E8: D613001E 244A531B
	v_exp_f32_e32 v33, v33                                     // 0000001BF8F0: 7E424B21
	v_fma_f32 v43, 0xbfb8aa3b, v38, -v35                       // 0000001BF8F4: D613002B 848E4CFF BFB8AA3B
	v_rndne_f32_e32 v44, v35                                   // 0000001BF900: 7E584723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BF904: BF870193
	v_dual_mul_f32 v42, v37, v34 :: v_dual_fmac_f32 v41, v30, v19// 0000001BF908: C8C04525 2A28271E
	v_fmac_f32_e32 v43, 0xb2a5705f, v38                        // 0000001BF910: 56564CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BF918: BF870193
	v_sub_f32_e32 v35, v35, v44                                // 0000001BF91C: 08465923
	v_fma_f32 v30, -v25, v42, v37                              // 0000001BF920: D613001E 24965519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001BF928: BF870294
	v_fma_f32 v17, -v27, v41, v18                              // 0000001BF92C: D6130011 244A531B
	.long 0xd71c0012                                           // 0000001BF934: D71C0012
	v_cndmask_b32_e32 v1, v33, v36, vcc_lo                     // 0000001BF938: 02024921
	v_cvt_i32_f32_e32 v20, v44                                 // 0000001BF93C: 7E28112C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BF940: BF870214
	v_dual_add_f32 v27, v35, v43 :: v_dual_fmac_f32 v42, v30, v34// 0000001BF944: C9005723 1B2A451E
	v_div_fmas_f32 v17, v17, v19, v41                          // 0000001BF94C: D6370011 04A62711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001BF954: 7C3C3AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BF95C: BF870213
	v_fma_f32 v19, -v25, v42, v37                              // 0000001BF960: D6130013 24965519
	v_exp_f32_e32 v25, v27                                     // 0000001BF968: 7E324B1B
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001BF96C: 02242480
	s_mov_b32 vcc_lo, s0                                       // 0000001BF970: BEEA0000
	v_div_fixup_f32 v17, v17, v26, v21                         // 0000001BF974: D6270011 04563511
	v_div_fmas_f32 v19, v19, v34, v42                          // 0000001BF97C: D6370013 04AA4513
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001BF984: 7C363AFF C2B17218
	.long 0x7f2a3980                                           // 0000001BF98C: 7F2A3980
	v_lshlrev_b32_e32 v34, 16, v70                             // 0000001BF990: 30448C90
	.long 0x7e2a3991                                           // 0000001BF994: 7E2A3991
	v_div_fixup_f32 v19, v19, v28, v22                         // 0000001BF998: D6270013 045A3913
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001BF9A0: 022424FF 7F800000
	.long 0xd71c0014                                           // 0000001BF9A8: D71C0014
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000001BF9AC: 02022919
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 0000001BF9B0: 7C3C4CFF 42CE8ED0
	v_lshlrev_b32_e32 v25, 16, v104                            // 0000001BF9B8: 3032D090
	.long 0x7e003993                                           // 0000001BF9BC: 7E003993
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_and_b32 v21, 1, v21 // 0000001BF9C0: C92424F2 12142A81
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001BF9C8: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 0000001BF9CC: 7C364CFF C2B17218
	v_mul_f32_e32 v27, 0xbfb8aa3b, v25                         // 0000001BF9D4: 103632FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001BF9DC: BF870234
	v_div_scale_f32 v22, null, v18, v18, v9                    // 0000001BF9E0: D6FC7C16 04262512
	v_dual_mul_f32 v37, 0xbfb8aa3b, v34 :: v_dual_and_b32 v28, 1, v0// 0000001BF9E8: C8E444FF 251C0081 BFB8AA3B
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 0000001BF9F4: 022828FF 7F800000
	v_fma_f32 v29, 0xbfb8aa3b, v25, -v27                       // 0000001BF9FC: D613001D 846E32FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001BFA08: BF8701B4
	v_rcp_f32_e32 v26, v22                                     // 0000001BFA0C: 7E345516
	v_rndne_f32_e32 v30, v27                                   // 0000001BFA10: 7E3C471B
	v_add3_u32 v17, v17, v21, 0x7fff                           // 0000001BFA14: D6550011 03FE2B11 00007FFF
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_fmac_f32 v29, 0xb2a5705f, v25// 0000001BFA20: C90028F2 141C32FF B2A5705F
	v_add3_u32 v19, v19, v28, 0x7fff                           // 0000001BFA2C: D6550013 03FE3913 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BFA38: BF870224
	v_sub_f32_e32 v27, v27, v30                                // 0000001BFA3C: 08363D1B
	v_rndne_f32_e32 v28, v37                                   // 0000001BFA40: 7E384725
	v_div_scale_f32 v33, null, v20, v20, v10                   // 0000001BFA44: D6FC7C21 042A2914
	v_cvt_i32_f32_e32 v30, v30                                 // 0000001BFA4C: 7E3C111E
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001BFA50: BF870005
	v_fma_f32 v35, -v22, v26, 1.0                              // 0000001BFA54: D6130023 23CA3516
	v_add_f32_e32 v21, v27, v29                                // 0000001BFA5C: 062A3B1B
	v_fma_f32 v27, 0xbfb8aa3b, v34, -v37                       // 0000001BFA60: D613001B 849644FF BFB8AA3B
	v_rcp_f32_e32 v36, v33                                     // 0000001BFA6C: 7E485521
	v_div_scale_f32 v29, vcc_lo, v9, v18, v9                   // 0000001BFA70: D6FC6A1D 04262509
	v_fmac_f32_e32 v26, v35, v26                               // 0000001BFA78: 56343523
	v_exp_f32_e32 v21, v21                                     // 0000001BFA7C: 7E2A4B15
	v_fmac_f32_e32 v27, 0xb2a5705f, v34                        // 0000001BFA80: 563644FF B2A5705F
	v_sub_f32_e32 v37, v37, v28                                // 0000001BFA88: 084A3925
	global_store_d16_hi_b16 v[31:32], v17, off offset:160      // 0000001BFA8C: DC9600A0 007C111F
	v_mul_f32_e32 v38, v29, v26                                // 0000001BFA94: 104C351D
	.long 0xd41e0001                                           // 0000001BFA98: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001BFA9C: 020232FF 42CE8ED0
	v_cvt_i32_f32_e32 v28, v28                                 // 0000001BFAA4: 7E38111C
	v_fma_f32 v35, -v33, v36, 1.0                              // 0000001BFAA8: D6130023 23CA4921
	v_add_f32_e32 v27, v37, v27                                // 0000001BFAB0: 06363725
	global_store_d16_hi_b16 v[39:40], v19, off offset:160      // 0000001BFAB4: DC9600A0 007C1327
	.long 0xd71c0011                                           // 0000001BFABC: D71C0011
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                     // 0000001BFAC0: 02023D15
	v_fma_f32 v21, -v22, v38, v29                              // 0000001BFAC4: D6130015 24764D16
	v_fmac_f32_e32 v36, v35, v36                               // 0000001BFACC: 56484923
	v_div_scale_f32 v35, s0, v10, v20, v10                     // 0000001BFAD0: D6FC0023 042A290A
	v_exp_f32_e32 v27, v27                                     // 0000001BFAD8: 7E364B1B
	v_cndmask_b32_e64 v17, 0, v17, s1                          // 0000001BFADC: D5010011 00062280
	v_fmac_f32_e32 v38, v21, v26                               // 0000001BFAE4: 564C3515
	.long 0xd41b0001                                           // 0000001BFAE8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v25, vcc_lo              // 0000001BFAEC: 020232FF C2B17218
	v_dual_mul_f32 v30, v35, v36 :: v_dual_lshlrev_b32 v19, 16, v106// 0000001BFAF4: C8E24923 1E12D490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BFAFC: BF870193
	v_fma_f32 v22, -v22, v38, v29                              // 0000001BFB00: D6130016 24764D16
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 0000001BFB08: D5010011 000622FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BFB14: BF870213
	v_fma_f32 v21, -v33, v30, v35                              // 0000001BFB18: D6130015 248E3D21
	.long 0xd41e0001                                           // 0000001BFB20: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v19, vcc_lo              // 0000001BFB24: 020226FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BFB2C: BF870224
	v_div_fmas_f32 v22, v22, v26, v38                          // 0000001BFB30: D6370016 049A3516
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 0000001BFB38: 7C3C44FF 42CE8ED0
	v_fmac_f32_e32 v30, v21, v36                               // 0000001BFB40: 563C4915
	.long 0xd71c0015                                           // 0000001BFB44: D71C0015
	v_cndmask_b32_e32 v1, v27, v28, vcc_lo                     // 0000001BFB48: 0202391B
	v_add_f32_e32 v17, 1.0, v17                                // 0000001BFB4C: 062222F2
	v_div_fixup_f32 v9, v22, v18, v9                           // 0000001BFB50: D6270009 04262516
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BFB58: BF870214
	v_fma_f32 v25, -v33, v30, v35                              // 0000001BFB5C: D6130019 248E3D21
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 0000001BFB64: 022A2A80
	s_mov_b32 vcc_lo, s0                                       // 0000001BFB68: BEEA0000
	v_div_scale_f32 v26, null, v17, v17, v11                   // 0000001BFB6C: D6FC7C1A 042E2311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001BFB74: BF870233
	v_div_fmas_f32 v25, v25, v36, v30                          // 0000001BFB78: D6370019 047A4919
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 0000001BFB80: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v34, 16, v105                            // 0000001BFB88: 3044D290
	v_rcp_f32_e32 v27, v26                                     // 0000001BFB8C: 7E36551A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BFB90: BF870003
	v_div_fixup_f32 v10, v25, v20, v10                         // 0000001BFB94: D627000A 042A2919
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001BFB9C: 022A2AFF 7F800000
	v_mul_f32_e32 v25, 0xbfb8aa3b, v19                         // 0000001BFBA4: 103226FF BFB8AA3B
	v_div_scale_f32 v33, vcc_lo, v11, v17, v11                 // 0000001BFBAC: D6FC6A21 042E230B
	v_mul_f32_e32 v36, 0xbfb8aa3b, v34                         // 0000001BFBB4: 104844FF BFB8AA3B
	.long 0x7e00398a                                           // 0000001BFBBC: 7E00398A
	v_add_f32_e32 v18, 1.0, v21                                // 0000001BFBC0: 06242AF2
	v_fma_f32 v29, 0xbfb8aa3b, v19, -v25                       // 0000001BFBC4: D613001D 846626FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001BFBD0: BF870005
	v_fma_f32 v21, -v26, v27, 1.0                              // 0000001BFBD4: D6130015 23CA371A
	v_rndne_f32_e32 v30, v25                                   // 0000001BFBDC: 7E3C4719
	v_and_b32_e32 v28, 1, v0                                   // 0000001BFBE0: 36380081
	v_div_scale_f32 v22, null, v18, v18, v12                   // 0000001BFBE4: D6FC7C16 04322512
	v_fmac_f32_e32 v29, 0xb2a5705f, v19                        // 0000001BFBEC: 563A26FF B2A5705F
	v_fmac_f32_e32 v27, v21, v27                               // 0000001BFBF4: 56363715
	v_sub_f32_e32 v25, v25, v30                                // 0000001BFBF8: 08323D19
	.long 0x7e283989                                           // 0000001BFBFC: 7E283989
	v_rcp_f32_e32 v21, v22                                     // 0000001BFC00: 7E2A5516
	.long 0x7f283980                                           // 0000001BFC04: 7F283980
	v_mul_f32_e32 v35, v33, v27                                // 0000001BFC08: 10463721
	v_add_f32_e32 v25, v25, v29                                // 0000001BFC0C: 06323B19
	v_fma_f32 v37, 0xbfb8aa3b, v34, -v36                       // 0000001BFC10: D6130025 849244FF BFB8AA3B
	v_rndne_f32_e32 v38, v36                                   // 0000001BFC1C: 7E4C4724
	v_add3_u32 v10, v10, v28, 0x7fff                           // 0000001BFC20: D655000A 03FE390A 00007FFF
	v_and_b32_e32 v20, 1, v20                                  // 0000001BFC2C: 36282881
	v_fma_f32 v29, -v26, v35, v33                              // 0000001BFC30: D613001D 2486471A
	v_exp_f32_e32 v25, v25                                     // 0000001BFC38: 7E324B19
	v_fma_f32 v28, -v22, v21, 1.0                              // 0000001BFC3C: D613001C 23CA2B16
	v_fmac_f32_e32 v37, 0xb2a5705f, v34                        // 0000001BFC44: 564A44FF B2A5705F
	v_sub_f32_e32 v36, v36, v38                                // 0000001BFC4C: 08484D24
	v_add3_u32 v9, v9, v20, 0x7fff                             // 0000001BFC50: D6550009 03FE2909 00007FFF
	v_cvt_i32_f32_e32 v20, v30                                 // 0000001BFC5C: 7E28111E
	v_fmac_f32_e32 v21, v28, v21                               // 0000001BFC60: 562A2B1C
	v_div_scale_f32 v28, s0, v12, v18, v12                     // 0000001BFC64: D6FC001C 0432250C
	v_dual_fmac_f32 v35, v29, v27 :: v_dual_add_f32 v30, v36, v37// 0000001BFC6C: C808371D 231E4B24
	global_store_d16_hi_b16 v[7:8], v9, off offset:192         // 0000001BFC74: DC9600C0 007C0907
	.long 0xd71c0009                                           // 0000001BFC7C: D71C0009
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000001BFC80: 02022919
	v_mul_f32_e32 v29, v28, v21                                // 0000001BFC84: 103A2B1C
	v_fma_f32 v20, -v26, v35, v33                              // 0000001BFC88: D6130014 2486471A
	v_exp_f32_e32 v26, v30                                     // 0000001BFC90: 7E344B1E
	global_store_d16_hi_b16 v[47:48], v10, off offset:192      // 0000001BFC94: DC9600C0 007C0A2F
	v_cndmask_b32_e64 v9, 0, v9, s1                            // 0000001BFC9C: D5010009 00061280
	v_fma_f32 v25, -v22, v29, v28                              // 0000001BFCA4: D6130019 24723B16
	v_div_fmas_f32 v20, v20, v27, v35                          // 0000001BFCAC: D6370014 048E3714
	v_cvt_i32_f32_e32 v27, v38                                 // 0000001BFCB4: 7E361126
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v19                  // 0000001BFCB8: 7C3626FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BFCC0: BF870214
	v_fmac_f32_e32 v29, v25, v21                               // 0000001BFCC4: 563A2B19
	v_div_fixup_f32 v11, v20, v17, v11                         // 0000001BFCC8: D627000B 042E2314
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BFCD0: BF870004
	.long 0xd71c0011                                           // 0000001BFCD4: D71C0011
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000001BFCD8: 0202371A
	v_cndmask_b32_e32 v9, 0x7f800000, v9, vcc_lo               // 0000001BFCDC: 021212FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 0000001BFCE4: 7C3C44FF 42CE8ED0
	v_fma_f32 v19, -v22, v29, v28                              // 0000001BFCEC: D6130013 24723B16
	s_waitcnt vmcnt(1)                                         // 0000001BFCF4: BF8907F7
	v_lshlrev_b32_e32 v25, 16, v67                             // 0000001BFCF8: 30328690
	.long 0x7e2c398b                                           // 0000001BFCFC: 7E2C398B
	v_add_f32_e32 v9, 1.0, v9                                  // 0000001BFD00: 061212F2
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000001BFD04: 02222280
	s_mov_b32 vcc_lo, s0                                       // 0000001BFD08: BEEA0000
	v_mul_f32_e32 v30, 0xbfb8aa3b, v25                         // 0000001BFD0C: 103C32FF BFB8AA3B
	v_div_fmas_f32 v19, v19, v21, v29                          // 0000001BFD14: D6370013 04762B13
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 0000001BFD1C: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v21, 16, v69                             // 0000001BFD24: 302A8A90
	v_div_scale_f32 v20, null, v9, v9, v13                     // 0000001BFD28: D6FC7C14 04361309
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v30                       // 0000001BFD30: D6130022 847A32FF BFB8AA3B
	v_div_fixup_f32 v12, v19, v18, v12                         // 0000001BFD3C: D627000C 04322513
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 0000001BFD44: 022222FF 7F800000
	v_mul_f32_e32 v19, 0xbfb8aa3b, v21                         // 0000001BFD4C: 10262AFF BFB8AA3B
	v_rcp_f32_e32 v18, v20                                     // 0000001BFD54: 7E245514
	v_rndne_f32_e32 v35, v30                                   // 0000001BFD58: 7E46471E
	v_fmac_f32_e32 v34, 0xb2a5705f, v25                        // 0000001BFD5C: 564432FF B2A5705F
	v_add_f32_e32 v17, 1.0, v17                                // 0000001BFD64: 062222F2
	v_fma_f32 v27, 0xbfb8aa3b, v21, -v19                       // 0000001BFD68: D613001B 844E2AFF BFB8AA3B
	v_rndne_f32_e32 v28, v19                                   // 0000001BFD74: 7E384713
	.long 0xd41e0001                                           // 0000001BFD78: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v21, vcc_lo              // 0000001BFD7C: 02022AFF 42CE8ED0
	.long 0x7e00398c                                           // 0000001BFD84: 7E00398C
	v_div_scale_f32 v26, null, v17, v17, v14                   // 0000001BFD88: D6FC7C1A 043A2311
	v_fmac_f32_e32 v27, 0xb2a5705f, v21                        // 0000001BFD90: 56362AFF B2A5705F
	v_sub_f32_e32 v19, v19, v28                                // 0000001BFD98: 08263913
	v_fma_f32 v29, -v20, v18, 1.0                              // 0000001BFD9C: D613001D 23CA2514
	v_cvt_i32_f32_e32 v28, v28                                 // 0000001BFDA4: 7E38111C
	v_rcp_f32_e32 v33, v26                                     // 0000001BFDA8: 7E42551A
	.long 0x7f2c3980                                           // 0000001BFDAC: 7F2C3980
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001BFDB0: BF8701B3
	v_dual_add_f32 v19, v19, v27 :: v_dual_fmac_f32 v18, v29, v18// 0000001BFDB4: C9003713 1312251D
	v_div_scale_f32 v27, vcc_lo, v13, v9, v13                  // 0000001BFDBC: D6FC6A1B 0436130D
	v_dual_sub_f32 v29, v30, v35 :: v_dual_and_b32 v36, 1, v0  // 0000001BFDC4: C964471E 1D240081
	v_exp_f32_e32 v19, v19                                     // 0000001BFDCC: 7E264B13
	v_and_b32_e32 v22, 1, v22                                  // 0000001BFDD0: 362C2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001BFDD4: BF870313
	v_mul_f32_e32 v37, v27, v18                                // 0000001BFDD8: 104A251B
	v_fma_f32 v30, -v26, v33, 1.0                              // 0000001BFDDC: D613001E 23CA431A
	v_add_f32_e32 v29, v29, v34                                // 0000001BFDE4: 063A451D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BFDE8: BF870214
	v_add3_u32 v10, v11, v22, 0x7fff                           // 0000001BFDEC: D655000A 03FE2D0B 00007FFF
	v_fma_f32 v34, -v20, v37, v27                              // 0000001BFDF8: D6130022 246E4B14
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BFE00: BF870004
	v_fmac_f32_e32 v33, v30, v33                               // 0000001BFE04: 5642431E
	v_div_scale_f32 v30, s0, v14, v17, v14                     // 0000001BFE08: D6FC001E 043A230E
	v_exp_f32_e32 v29, v29                                     // 0000001BFE10: 7E3A4B1D
	.long 0xd71c0013                                           // 0000001BFE14: D71C0013
	v_cndmask_b32_e32 v1, v19, v28, vcc_lo                     // 0000001BFE18: 02023913
	v_fmac_f32_e32 v37, v34, v18                               // 0000001BFE1C: 564A2522
	v_cvt_i32_f32_e32 v34, v35                                 // 0000001BFE20: 7E441123
	v_mul_f32_e32 v28, v30, v33                                // 0000001BFE24: 1038431E
	v_add3_u32 v11, v12, v36, 0x7fff                           // 0000001BFE28: D655000B 03FE490C 00007FFF
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 0000001BFE34: D5010013 00062680
	.long 0xd41b0001                                           // 0000001BFE3C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v21, vcc_lo              // 0000001BFE40: 02022AFF C2B17218
	v_fma_f32 v20, -v20, v37, v27                              // 0000001BFE48: D6130014 246E4B14
	v_fma_f32 v35, -v26, v28, v30                              // 0000001BFE50: D6130023 247A391A
	.long 0xd71c001b                                           // 0000001BFE58: D71C001B
	v_cndmask_b32_e32 v1, v29, v34, vcc_lo                     // 0000001BFE5C: 0202451D
	global_store_d16_hi_b16 v[15:16], v10, off offset:192      // 0000001BFE60: DC9600C0 007C0A0F
	v_cndmask_b32_e64 v19, 0x7f800000, v19, s1                 // 0000001BFE68: D5010013 000626FF 7F800000
	.long 0xd41e0001                                           // 0000001BFE74: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001BFE78: 020232FF 42CE8ED0
	v_fmac_f32_e32 v28, v35, v33                               // 0000001BFE80: 56384323
	v_div_fmas_f32 v18, v20, v18, v37                          // 0000001BFE84: D6370012 04962514
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001BFE8C: 7C3632FF C2B17218
	v_add_f32_e32 v19, 1.0, v19                                // 0000001BFE94: 062626F2
	v_cndmask_b32_e64 v21, 0, v27, s1                          // 0000001BFE98: D5010015 00063680
	v_fma_f32 v20, -v26, v28, v30                              // 0000001BFEA0: D6130014 247A391A
	v_div_fixup_f32 v9, v18, v9, v13                           // 0000001BFEA8: D6270009 04361312
	global_store_d16_hi_b16 v[23:24], v11, off offset:192      // 0000001BFEB0: DC9600C0 007C0B17
	v_div_scale_f32 v26, null, v19, v19, v1                    // 0000001BFEB8: D6FC7C1A 04062713
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001BFEC0: 022A2AFF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001BFEC8: BEEA0000
	v_lshlrev_b32_e32 v18, 16, v56                             // 0000001BFECC: 30247090
	v_div_fmas_f32 v20, v20, v33, v28                          // 0000001BFED0: D6370014 04724314
	v_rcp_f32_e32 v25, v26                                     // 0000001BFED8: 7E32551A
	v_add_f32_e32 v21, 1.0, v21                                // 0000001BFEDC: 062A2AF2
	v_lshlrev_b32_e32 v29, 16, v55                             // 0000001BFEE0: 303A6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BFEE4: BF870223
	v_div_fixup_f32 v12, v20, v17, v14                         // 0000001BFEE8: D627000C 043A2314
	.long 0x7e223989                                           // 0000001BFEF0: 7E223989
	v_div_scale_f32 v14, null, v21, v21, v2                    // 0000001BFEF4: D6FC7C0E 040A2B15
	.long 0x7f223980                                           // 0000001BFEFC: 7F223980
	v_mul_f32_e32 v30, 0xbfb8aa3b, v29                         // 0000001BFF00: 103C3AFF BFB8AA3B
	.long 0x7e00398c                                           // 0000001BFF08: 7E00398C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001BFF0C: BF8701B5
	v_fma_f32 v10, -v26, v25, 1.0                              // 0000001BFF10: D613000A 23CA331A
	v_rcp_f32_e32 v13, v14                                     // 0000001BFF18: 7E1A550E
	v_and_b32_e32 v17, 1, v17                                  // 0000001BFF1C: 36222281
	v_and_b32_e32 v11, 1, v0                                   // 0000001BFF20: 36160081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BFF24: BF870223
	v_fmac_f32_e32 v25, v10, v25                               // 0000001BFF28: 5632330A
	v_div_scale_f32 v10, vcc_lo, v1, v19, v1                   // 0000001BFF2C: D6FC6A0A 04062701
	v_add3_u32 v9, v9, v17, 0x7fff                             // 0000001BFF34: D6550009 03FE2309 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BFF40: BF870224
	v_add3_u32 v11, v12, v11, 0x7fff                           // 0000001BFF44: D655000B 03FE170C 00007FFF
	v_mul_f32_e32 v12, 0xbfb8aa3b, v18                         // 0000001BFF50: 101824FF BFB8AA3B
	v_mul_f32_e32 v20, v10, v25                                // 0000001BFF58: 1028330A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001BFF5C: BF870005
	v_fma_f32 v22, -v14, v13, 1.0                              // 0000001BFF60: D6130016 23CA1B0E
	s_clause 0x1                                               // 0000001BFF68: BF850001
	global_store_d16_hi_b16 v[31:32], v9, off offset:192       // 0000001BFF6C: DC9600C0 007C091F
	global_store_d16_hi_b16 v[39:40], v11, off offset:192      // 0000001BFF74: DC9600C0 007C0B27
	v_fma_f32 v27, 0xbfb8aa3b, v18, -v12                       // 0000001BFF7C: D613001B 843224FF BFB8AA3B
	v_fma_f32 v17, -v26, v20, v10                              // 0000001BFF88: D6130011 242A291A
	v_fmac_f32_e32 v13, v22, v13                               // 0000001BFF90: 561A1B16
	v_div_scale_f32 v22, s0, v2, v21, v2                       // 0000001BFF94: D6FC0016 040A2B02
	v_rndne_f32_e32 v28, v12                                   // 0000001BFF9C: 7E38470C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BFFA0: BF870114
	v_dual_fmac_f32 v27, 0xb2a5705f, v18 :: v_dual_fmac_f32 v20, v17, v25// 0000001BFFA4: C80024FF 1B143311 B2A5705F
	v_dual_mul_f32 v17, v22, v13 :: v_dual_sub_f32 v12, v12, v28// 0000001BFFB0: C8CA1B16 110C390C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BFFB8: BF8701A2
	v_fma_f32 v9, -v26, v20, v10                               // 0000001BFFBC: D6130009 242A291A
	v_fma_f32 v26, 0xbfb8aa3b, v29, -v30                       // 0000001BFFC4: D613001A 847A3AFF BFB8AA3B
	v_fma_f32 v10, -v14, v17, v22                              // 0000001BFFD0: D613000A 245A230E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BFFD8: BF870004
	v_add_f32_e32 v12, v12, v27                                // 0000001BFFDC: 0618370C
	v_rndne_f32_e32 v27, v30                                   // 0000001BFFE0: 7E36471E
	v_div_fmas_f32 v9, v9, v25, v20                            // 0000001BFFE4: D6370009 04523309
	v_fmac_f32_e32 v26, 0xb2a5705f, v29                        // 0000001BFFEC: 56343AFF B2A5705F
	v_fmac_f32_e32 v17, v10, v13                               // 0000001BFFF4: 56221B0A
	v_exp_f32_e32 v10, v12                                     // 0000001BFFF8: 7E144B0C
	v_sub_f32_e32 v12, v30, v27                                // 0000001BFFFC: 0818371E
	v_lshlrev_b32_e32 v20, 16, v63                             // 0000001C0000: 30287E90
	v_cvt_i32_f32_e32 v25, v28                                 // 0000001C0004: 7E32111C
	v_fma_f32 v14, -v14, v17, v22                              // 0000001C0008: D613000E 245A230E
	s_waitcnt vmcnt(0)                                         // 0000001C0010: BF8903F7
	v_lshlrev_b32_e32 v22, 16, v64                             // 0000001C0014: 302C8090
	v_add_f32_e32 v12, v12, v26                                // 0000001C0018: 0618350C
	v_mul_f32_e32 v26, 0xbfb8aa3b, v20                         // 0000001C001C: 103428FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v18                  // 0000001C0024: 7C3C24FF 42CE8ED0
	v_cvt_i32_f32_e32 v27, v27                                 // 0000001C002C: 7E36111B
	v_mul_f32_e32 v28, 0xbfb8aa3b, v22                         // 0000001C0030: 10382CFF BFB8AA3B
	.long 0xd71c000a                                           // 0000001C0038: D71C000A
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 0000001C003C: 0202330A
	v_fma_f32 v25, 0xbfb8aa3b, v20, -v26                       // 0000001C0040: D6130019 846A28FF BFB8AA3B
	v_rndne_f32_e32 v30, v26                                   // 0000001C004C: 7E3C471A
	v_exp_f32_e32 v12, v12                                     // 0000001C0050: 7E184B0C
	v_fma_f32 v33, 0xbfb8aa3b, v22, -v28                       // 0000001C0054: D6130021 84722CFF BFB8AA3B
	v_rndne_f32_e32 v34, v28                                   // 0000001C0060: 7E44471C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C0064: BF870223
	v_dual_fmac_f32 v25, 0xb2a5705f, v20 :: v_dual_sub_f32 v26, v26, v30// 0000001C0068: C80A28FF 191A3D1A B2A5705F
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000001C0074: 02141480
	v_fmac_f32_e32 v33, 0xb2a5705f, v22                        // 0000001C0078: 56422CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 0000001C0080: BF8702B4
	v_sub_f32_e32 v28, v28, v34                                // 0000001C0084: 0838451C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v18                  // 0000001C0088: 7C3624FF C2B17218
	v_add_f32_e32 v25, v26, v25                                // 0000001C0090: 0632331A
	.long 0xd71c000c                                           // 0000001C0094: D71C000C
	v_cndmask_b32_e32 v1, v12, v27, vcc_lo                     // 0000001C0098: 0202370C
	v_cvt_i32_f32_e32 v27, v34                                 // 0000001C009C: 7E361122
	v_add_f32_e32 v26, v28, v33                                // 0000001C00A0: 0634431C
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo             // 0000001C00A4: 021414FF 7F800000
	v_exp_f32_e32 v18, v25                                     // 0000001C00AC: 7E244B19
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001C00B0: 7C3C3AFF 42CE8ED0
	v_div_fixup_f32 v1, v9, v19, v1                            // 0000001C00B8: D6270001 04062709
	v_exp_f32_e32 v25, v26                                     // 0000001C00C0: 7E324B1A
	v_cvt_i32_f32_e32 v26, v30                                 // 0000001C00C4: 7E34111E
	v_add_f32_e32 v10, 1.0, v10                                // 0000001C00C8: 061414F2
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 0000001C00CC: 02181880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001C00D0: 7C363AFF C2B17218
	.long 0x7e443981                                           // 0000001C00D8: 7E443981
	.long 0x7f443980                                           // 0000001C00DC: 7F443980
	.long 0xd71c0012                                           // 0000001C00E0: D71C0012
	v_cndmask_b32_e32 v1, v18, v26, vcc_lo                     // 0000001C00E4: 02023512
	v_div_scale_f32 v26, null, v10, v10, v3                    // 0000001C00E8: D6FC7C1A 040E150A
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 0000001C00F0: 021818FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v20                  // 0000001C00F8: 7C3C28FF 42CE8ED0
	.long 0xd71c0019                                           // 0000001C0100: D71C0019
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 0000001C0104: 02023719
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C0108: BF870194
	v_rcp_f32_e32 v27, v26                                     // 0000001C010C: 7E36551A
	v_add_f32_e32 v12, 1.0, v12                                // 0000001C0110: 061818F2
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001C0114: 02242480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v22                  // 0000001C0118: 7C3C2CFF 42CE8ED0
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000001C0120: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v20                  // 0000001C0124: 7C3628FF C2B17218
	v_div_scale_f32 v20, null, v12, v12, v4                    // 0000001C012C: D6FC7C14 0412190C
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001C0134: 022424FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v22                  // 0000001C013C: 7C362CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C0144: BF870113
	v_rcp_f32_e32 v28, v20                                     // 0000001C0148: 7E385514
	v_add_f32_e32 v18, 1.0, v18                                // 0000001C014C: 062424F2
	v_cndmask_b32_e32 v22, 0x7f800000, v25, vcc_lo             // 0000001C0150: 022C32FF 7F800000
	v_fma_f32 v25, -v26, v27, 1.0                              // 0000001C0158: D6130019 23CA371A
	s_mov_b32 vcc_lo, s0                                       // 0000001C0160: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C0164: BF870193
	v_div_scale_f32 v29, null, v18, v18, v5                    // 0000001C0168: D6FC7C1D 04162512
	v_add_f32_e32 v22, 1.0, v22                                // 0000001C0170: 062C2CF2
	v_div_fmas_f32 v13, v14, v13, v17                          // 0000001C0174: D637000D 04461B0E
	v_fmac_f32_e32 v27, v25, v27                               // 0000001C017C: 56363719
	v_div_scale_f32 v17, vcc_lo, v3, v10, v3                   // 0000001C0180: D6FC6A11 040E1503
	v_rcp_f32_e32 v14, v29                                     // 0000001C0188: 7E1C551D
	v_div_scale_f32 v25, null, v22, v22, v6                    // 0000001C018C: D6FC7C19 041A2D16
	v_fma_f32 v30, -v20, v28, 1.0                              // 0000001C0194: D613001E 23CA3914
	v_div_fixup_f32 v2, v13, v21, v2                           // 0000001C019C: D6270002 040A2B0D
	v_mul_f32_e32 v11, v17, v27                                // 0000001C01A4: 10163711
	v_div_scale_f32 v21, s0, v4, v12, v4                       // 0000001C01A8: D6FC0015 04121904
	v_rcp_f32_e32 v13, v25                                     // 0000001C01B0: 7E1A5519
	v_fmac_f32_e32 v28, v30, v28                               // 0000001C01B4: 5638391E
	.long 0x7e003982                                           // 0000001C01B8: 7E003982
	v_fma_f32 v9, -v26, v11, v17                               // 0000001C01BC: D6130009 2446171A
	v_fma_f32 v30, -v29, v14, 1.0                              // 0000001C01C4: D613001E 23CA1D1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C01CC: BF870114
	v_mul_f32_e32 v19, v21, v28                                // 0000001C01D0: 10263915
	v_dual_fmac_f32 v11, v9, v27 :: v_dual_fmac_f32 v14, v30, v14// 0000001C01D4: C8003709 0B0E1D1E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C01DC: BF870225
	v_fma_f32 v33, -v25, v13, 1.0                              // 0000001C01E0: D6130021 23CA1B19
	v_div_scale_f32 v30, s1, v5, v18, v5                       // 0000001C01E8: D6FC011E 04162505
	v_fma_f32 v9, -v20, v19, v21                               // 0000001C01F0: D6130009 24562714
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C01F8: BF870214
	v_fma_f32 v17, -v26, v11, v17                              // 0000001C01FC: D6130011 2446171A
	v_fmac_f32_e32 v13, v33, v13                               // 0000001C0204: 561A1B21
	v_div_scale_f32 v33, s2, v6, v22, v6                       // 0000001C0208: D6FC0221 041A2D06
	v_mul_f32_e32 v35, v30, v14                                // 0000001C0210: 10461D1E
	v_fmac_f32_e32 v19, v9, v28                                // 0000001C0214: 56263909
	v_div_fmas_f32 v11, v17, v27, v11                          // 0000001C0218: D637000B 042E3711
	s_mov_b32 vcc_lo, s0                                       // 0000001C0220: BEEA0000
	v_mul_f32_e32 v26, v33, v13                                // 0000001C0224: 10341B21
	v_fma_f32 v9, -v29, v35, v30                               // 0000001C0228: D6130009 247A471D
	v_fma_f32 v17, -v20, v19, v21                              // 0000001C0230: D6130011 24562714
	v_div_fixup_f32 v3, v11, v10, v3                           // 0000001C0238: D6270003 040E150B
	v_and_b32_e32 v11, 1, v34                                  // 0000001C0240: 36164481
	v_fma_f32 v20, -v25, v26, v33                              // 0000001C0244: D6130014 24863519
	v_fmac_f32_e32 v35, v9, v14                                // 0000001C024C: 56461D09
	v_div_fmas_f32 v9, v17, v28, v19                           // 0000001C0250: D6370009 044E3911
	s_mov_b32 vcc_lo, s1                                       // 0000001C0258: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C025C: BF870193
	v_dual_fmac_f32 v26, v20, v13 :: v_dual_and_b32 v17, 1, v0 // 0000001C0260: C8241B14 1A100081
	v_fma_f32 v10, -v29, v35, v30                              // 0000001C0268: D613000A 247A471D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C0270: BF870003
	v_div_fixup_f32 v4, v9, v12, v4                            // 0000001C0274: D6270004 04121909
	.long 0x7f183980                                           // 0000001C027C: 7F183980
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001C0280: D6550001 03FE1701 00007FFF
	v_fma_f32 v9, -v25, v26, v33                               // 0000001C028C: D6130009 24863519
	v_div_fmas_f32 v10, v10, v14, v35                          // 0000001C0294: D637000A 048E1D0A
	s_mov_b32 vcc_lo, s2                                       // 0000001C029C: BEEA0002
	.long 0x7e003984                                           // 0000001C02A0: 7E003984
	v_add3_u32 v2, v2, v17, 0x7fff                             // 0000001C02A4: D6550002 03FE2302 00007FFF
	v_div_fmas_f32 v9, v9, v13, v26                            // 0000001C02B0: D6370009 046A1B09
	v_div_fixup_f32 v5, v10, v18, v5                           // 0000001C02B8: D6270005 0416250A
	.long 0x7e143983                                           // 0000001C02C0: 7E143983
	.long 0x7f143980                                           // 0000001C02C4: 7F143980
	global_store_d16_hi_b16 v[7:8], v1, off offset:224         // 0000001C02C8: DC9600E0 007C0107
	v_div_fixup_f32 v6, v9, v22, v6                            // 0000001C02D0: D6270006 041A2D09
	.long 0x7e183985                                           // 0000001C02D8: 7E183985
	v_and_b32_e32 v9, 1, v0                                    // 0000001C02DC: 36120081
	v_and_b32_e32 v10, 1, v10                                  // 0000001C02E0: 36141481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C02E4: BF870214
	.long 0x7e003986                                           // 0000001C02E8: 7E003986
	v_and_b32_e32 v11, 1, v12                                  // 0000001C02EC: 36161881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C02F0: BF870223
	v_add3_u32 v1, v3, v10, 0x7fff                             // 0000001C02F4: D6550001 03FE1503 00007FFF
	v_add3_u32 v3, v4, v9, 0x7fff                              // 0000001C0300: D6550003 03FE1304 00007FFF
	v_and_b32_e32 v0, 1, v0                                    // 0000001C030C: 36000081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C0310: BF870114
	v_add3_u32 v4, v5, v11, 0x7fff                             // 0000001C0314: D6550004 03FE1705 00007FFF
	v_add3_u32 v0, v6, v0, 0x7fff                              // 0000001C0320: D6550000 03FE0106 00007FFF
	s_clause 0x4                                               // 0000001C032C: BF850004
	global_store_d16_hi_b16 v[47:48], v2, off offset:224       // 0000001C0330: DC9600E0 007C022F
	global_store_d16_hi_b16 v[15:16], v1, off offset:224       // 0000001C0338: DC9600E0 007C010F
	global_store_d16_hi_b16 v[23:24], v3, off offset:224       // 0000001C0340: DC9600E0 007C0317
	global_store_d16_hi_b16 v[31:32], v4, off offset:224       // 0000001C0348: DC9600E0 007C041F
	global_store_d16_hi_b16 v[39:40], v0, off offset:224       // 0000001C0350: DC9600E0 007C0027
	s_nop 0                                                    // 0000001C0358: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001C035C: BFB60003
	s_endpgm                                                   // 0000001C0360: BFB00000
		...

