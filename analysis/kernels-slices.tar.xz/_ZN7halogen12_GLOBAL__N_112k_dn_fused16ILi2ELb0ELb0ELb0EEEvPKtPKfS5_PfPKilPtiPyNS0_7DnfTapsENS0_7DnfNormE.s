000000000002b000 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE>:
; _ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE():
	s_clause 0x1                                               // 00000002B000: BF850001
	s_load_b256 s[20:27], s[0:1], 0x20                         // 00000002B004: F40C0500 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 00000002B00C: F40C0200 F8000000
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 5, v0       // 00000002B014: CA220080 02020085
	s_ashr_i32 s3, s2, 31                                      // 00000002B01C: 86039F02
	s_mov_b32 s28, 0                                           // 00000002B020: BE9C0080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002B024: BF870001
	v_and_b32_e32 v3, 0x200, v3                                // 00000002B028: 360606FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 00000002B030: BF89FC07
	s_load_b32 s16, s[20:21], null                             // 00000002B034: F400040A F8000000
	v_readfirstlane_b32 s20, v0                                // 00000002B03C: 7E280500
	s_lshl_b64 s[4:5], s[22:23], 2                             // 00000002B040: 84848216
	s_lshr_b32 s21, s20, 5                                     // 00000002B044: 85158514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000002B048: BF8704D9
	s_lshl_b32 s33, s21, 4                                     // 00000002B04C: 84218415
	s_add_u32 s4, s14, s4                                      // 00000002B050: 8004040E
	v_and_or_b32 v1, v0, 15, s33                               // 00000002B054: D6570001 00851F00
	s_addc_u32 s5, s15, s5                                     // 00000002B05C: 8205050F
	s_lshl_b64 s[6:7], s[2:3], 16                              // 00000002B060: 84869002
	s_add_u32 s4, s4, s6                                       // 00000002B064: 80040604
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002B068: BF870001
	.long 0xd73c0001                                           // 00000002B06C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000002B070: 02020282
	s_addc_u32 s5, s5, s7                                      // 00000002B074: 82050705
	s_waitcnt lgkmcnt(0)                                       // 00000002B078: BF89FC07
	s_mul_i32 s14, s16, 0x9000000                              // 00000002B07C: 960EFF10 09000000
	s_mul_hi_i32 s15, s16, 0x9000000                           // 00000002B084: 970FFF10 09000000
	s_add_u32 s4, s4, s14                                      // 00000002B08C: 80040E04
	s_addc_u32 s5, s5, s15                                     // 00000002B090: 82050F05
	.long 0xd7006a01                                           // 00000002B094: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000002B098: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000002B09C: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000002B0A0: D5207C02 01AA0405
	s_or_b32 s5, s21, s2                                       // 00000002B0A8: 8C050215
	.long 0xd7006abb                                           // 00000002B0AC: D7006ABB
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000002B0B0: 02020701
	v_add_co_ci_u32_e64 v188, null, 0, v2, vcc_lo              // 00000002B0B4: D5207CBC 01AA0480
	s_cselect_b32 s38, 0, -1                                   // 00000002B0BC: 9826C180
	.long 0xd7006a09                                           // 00000002B0C0: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v187, vcc_lo                 // 00000002B0C4: 020376FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002B0CC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v188, vcc_lo             // 00000002B0D0: D5207C0A 01AB7880
	.long 0xd7006a34                                           // 00000002B0D8: D7006A34
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000002B0DC: 0201FFBB
	.long 0x00002000                                           // 00000002B0E0: 00002000
	v_add_co_ci_u32_e64 v53, null, 0, v188, vcc_lo             // 00000002B0E4: D5207C35 01AB7880
	.long 0xd7006a0d                                           // 00000002B0EC: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v187, vcc_lo                 // 00000002B0F0: 020376FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002B0F8: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v188, vcc_lo             // 00000002B0FC: D5207C0E 01AB7880
	.long 0xd7006a0f                                           // 00000002B104: D7006A0F
	v_cndmask_b32_e32 v1, 0x3000, v187, vcc_lo                 // 00000002B108: 020376FF 00003000
	v_add_co_ci_u32_e64 v16, null, 0, v188, vcc_lo             // 00000002B110: D5207C10 01AB7880
	.long 0xd7006a3c                                           // 00000002B118: D7006A3C
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000002B11C: 0201FFBB
	.long 0x00004000                                           // 00000002B120: 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002B124: BF870001
	v_add_co_ci_u32_e64 v61, null, 0, v188, vcc_lo             // 00000002B128: D5207C3D 01AB7880
	.long 0xd7006a11                                           // 00000002B130: D7006A11
	v_cndmask_b32_e32 v1, 0x4000, v187, vcc_lo                 // 00000002B134: 020376FF 00004000
	s_clause 0x7                                               // 00000002B13C: BF850007
	global_load_b32 v5, v[187:188], off                        // 00000002B140: DC520000 057C00BB
	global_load_b32 v6, v[187:188], off offset:1024            // 00000002B148: DC520400 067C00BB
	global_load_b32 v7, v[187:188], off offset:2048            // 00000002B150: DC520800 077C00BB
	global_load_b32 v8, v[187:188], off offset:3072            // 00000002B158: DC520C00 087C00BB
	global_load_b32 v2, v[9:10], off offset:1024               // 00000002B160: DC520400 027C0009
	global_load_b32 v3, v[9:10], off offset:2048               // 00000002B168: DC520800 037C0009
	global_load_b32 v4, v[9:10], off offset:3072               // 00000002B170: DC520C00 047C0009
	global_load_b32 v1, v[13:14], off offset:1024              // 00000002B178: DC520400 017C000D
	v_add_co_ci_u32_e64 v18, null, 0, v188, vcc_lo             // 00000002B180: D5207C12 01AB7880
	s_clause 0x7                                               // 00000002B188: BF850007
	global_load_b32 v12, v[13:14], off offset:2048             // 00000002B18C: DC520800 0C7C000D
	global_load_b32 v13, v[13:14], off offset:3072             // 00000002B194: DC520C00 0D7C000D
	global_load_b32 v9, v[15:16], off offset:1024              // 00000002B19C: DC520400 097C000F
	global_load_b32 v10, v[15:16], off offset:2048             // 00000002B1A4: DC520800 0A7C000F
	global_load_b32 v11, v[15:16], off offset:3072             // 00000002B1AC: DC520C00 0B7C000F
	global_load_b32 v14, v[17:18], off offset:1024             // 00000002B1B4: DC520400 0E7C0011
	global_load_b32 v15, v[17:18], off offset:2048             // 00000002B1BC: DC520800 0F7C0011
	global_load_b32 v16, v[17:18], off offset:3072             // 00000002B1C4: DC520C00 107C0011
	.long 0xd7006a11                                           // 00000002B1CC: D7006A11
	v_cndmask_b32_e32 v1, 0x5000, v187, vcc_lo                 // 00000002B1D0: 020376FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002B1D8: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v188, vcc_lo             // 00000002B1DC: D5207C12 01AB7880
	.long 0xd7006a41                                           // 00000002B1E4: D7006A41
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000002B1E8: 0201FFBB
	.long 0x00006000                                           // 00000002B1EC: 00006000
	v_add_co_ci_u32_e64 v66, null, 0, v188, vcc_lo             // 00000002B1F0: D5207C42 01AB7880
	.long 0xd7006a17                                           // 00000002B1F8: D7006A17
	v_cndmask_b32_e32 v1, 0x6000, v187, vcc_lo                 // 00000002B1FC: 020376FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002B204: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v188, vcc_lo             // 00000002B208: D5207C18 01AB7880
	.long 0xd7006a19                                           // 00000002B210: D7006A19
	v_cndmask_b32_e32 v1, 0x7000, v187, vcc_lo                 // 00000002B214: 020376FF 00007000
	v_add_co_ci_u32_e64 v26, null, 0, v188, vcc_lo             // 00000002B21C: D5207C1A 01AB7880
	.long 0xd7006a29                                           // 00000002B224: D7006A29
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000002B228: 0201FFBB
	.long 0x00008000                                           // 00000002B22C: 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002B230: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v188, vcc_lo             // 00000002B234: D5207C2A 01AB7880
	.long 0xd7006a20                                           // 00000002B23C: D7006A20
	v_cndmask_b32_e32 v1, 0x8000, v187, vcc_lo                 // 00000002B240: 020376FF 00008000
	v_add_co_ci_u32_e64 v33, null, 0, v188, vcc_lo             // 00000002B248: D5207C21 01AB7880
	.long 0xd7006a22                                           // 00000002B250: D7006A22
	v_cndmask_b32_e32 v1, 0x9000, v187, vcc_lo                 // 00000002B254: 020376FF 00009000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002B25C: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v188, vcc_lo             // 00000002B260: D5207C23 01AB7880
	.long 0xd7006a2b                                           // 00000002B268: D7006A2B
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000002B26C: 0201FFBB
	.long 0x0000a000                                           // 00000002B270: 0000A000
	v_add_co_ci_u32_e64 v44, null, 0, v188, vcc_lo             // 00000002B274: D5207C2C 01AB7880
	.long 0xd7006a25                                           // 00000002B27C: D7006A25
	v_cndmask_b32_e32 v1, 0xa000, v187, vcc_lo                 // 00000002B280: 020376FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002B288: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v188, vcc_lo             // 00000002B28C: D5207C26 01AB7880
	.long 0xd7006a27                                           // 00000002B294: D7006A27
	v_cndmask_b32_e32 v1, 0xb000, v187, vcc_lo                 // 00000002B298: 020376FF 0000B000
	v_add_co_ci_u32_e64 v40, null, 0, v188, vcc_lo             // 00000002B2A0: D5207C28 01AB7880
	.long 0xd7006a2d                                           // 00000002B2A8: D7006A2D
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000002B2AC: 0201FFBB
	.long 0x0000c000                                           // 00000002B2B0: 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002B2B4: BF8700A1
	v_add_co_ci_u32_e64 v46, null, 0, v188, vcc_lo             // 00000002B2B8: D5207C2E 01AB7880
	.long 0xd7006a2f                                           // 00000002B2C0: D7006A2F
	v_cndmask_b32_e32 v1, 0xc000, v187, vcc_lo                 // 00000002B2C4: 020376FF 0000C000
	v_add_co_ci_u32_e64 v48, null, 0, v188, vcc_lo             // 00000002B2CC: D5207C30 01AB7880
	.long 0xd7006a36                                           // 00000002B2D4: D7006A36
	v_cndmask_b32_e32 v1, 0xd000, v187, vcc_lo                 // 00000002B2D8: 020376FF 0000D000
	s_clause 0x17                                              // 00000002B2E0: BF850017
	global_load_b32 v20, v[17:18], off offset:1024             // 00000002B2E4: DC520400 147C0011
	global_load_b32 v21, v[17:18], off offset:2048             // 00000002B2EC: DC520800 157C0011
	global_load_b32 v22, v[17:18], off offset:3072             // 00000002B2F4: DC520C00 167C0011
	global_load_b32 v17, v[23:24], off offset:1024             // 00000002B2FC: DC520400 117C0017
	global_load_b32 v18, v[23:24], off offset:2048             // 00000002B304: DC520800 127C0017
	global_load_b32 v19, v[23:24], off offset:3072             // 00000002B30C: DC520C00 137C0017
	global_load_b32 v23, v[25:26], off offset:1024             // 00000002B314: DC520400 177C0019
	global_load_b32 v24, v[25:26], off offset:2048             // 00000002B31C: DC520800 187C0019
	global_load_b32 v31, v[25:26], off offset:3072             // 00000002B324: DC520C00 1F7C0019
	global_load_b32 v28, v[32:33], off offset:1024             // 00000002B32C: DC520400 1C7C0020
	global_load_b32 v29, v[32:33], off offset:2048             // 00000002B334: DC520800 1D7C0020
	global_load_b32 v30, v[32:33], off offset:3072             // 00000002B33C: DC520C00 1E7C0020
	global_load_b32 v25, v[34:35], off offset:1024             // 00000002B344: DC520400 197C0022
	global_load_b32 v26, v[34:35], off offset:2048             // 00000002B34C: DC520800 1A7C0022
	global_load_b32 v27, v[34:35], off offset:3072             // 00000002B354: DC520C00 1B7C0022
	global_load_b32 v32, v[37:38], off offset:1024             // 00000002B35C: DC520400 207C0025
	global_load_b32 v36, v[37:38], off offset:2048             // 00000002B364: DC520800 247C0025
	global_load_b32 v37, v[37:38], off offset:3072             // 00000002B36C: DC520C00 257C0025
	global_load_b32 v33, v[39:40], off offset:1024             // 00000002B374: DC520400 217C0027
	global_load_b32 v34, v[39:40], off offset:2048             // 00000002B37C: DC520800 227C0027
	global_load_b32 v35, v[39:40], off offset:3072             // 00000002B384: DC520C00 237C0027
	global_load_b32 v38, v[47:48], off offset:1024             // 00000002B38C: DC520400 267C002F
	global_load_b32 v39, v[47:48], off offset:2048             // 00000002B394: DC520800 277C002F
	global_load_b32 v40, v[47:48], off offset:3072             // 00000002B39C: DC520C00 287C002F
	v_add_co_ci_u32_e64 v55, null, 0, v188, vcc_lo             // 00000002B3A4: D5207C37 01AB7880
	.long 0xd7006a2f                                           // 00000002B3AC: D7006A2F
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000002B3B0: 0201FFBB
	.long 0x0000e000                                           // 00000002B3B4: 0000E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002B3B8: BF8700A1
	v_add_co_ci_u32_e64 v48, null, 0, v188, vcc_lo             // 00000002B3BC: D5207C30 01AB7880
	.long 0xd7006a3e                                           // 00000002B3C4: D7006A3E
	v_cndmask_b32_e32 v1, 0xe000, v187, vcc_lo                 // 00000002B3C8: 020376FF 0000E000
	v_add_co_ci_u32_e64 v63, null, 0, v188, vcc_lo             // 00000002B3D0: D5207C3F 01AB7880
	.long 0xd7006a43                                           // 00000002B3D8: D7006A43
	v_cndmask_b32_e32 v1, 0xf000, v187, vcc_lo                 // 00000002B3DC: 020376FF 0000F000
	s_clause 0x7                                               // 00000002B3E4: BF850007
	global_load_b32 v51, v[41:42], off offset:-4096            // 00000002B3E8: DC521000 337C0029
	global_load_b32 v58, v[41:42], off                         // 00000002B3F0: DC520000 3A7C0029
	global_load_b32 v50, v[43:44], off offset:-4096            // 00000002B3F8: DC521000 327C002B
	global_load_b32 v56, v[43:44], off                         // 00000002B400: DC520000 387C002B
	global_load_b32 v44, v[45:46], off offset:-4096            // 00000002B408: DC521000 2C7C002D
	global_load_b32 v43, v[45:46], off                         // 00000002B410: DC520000 2B7C002D
	global_load_b32 v42, v[47:48], off offset:-4096            // 00000002B418: DC521000 2A7C002F
	global_load_b32 v41, v[47:48], off                         // 00000002B420: DC520000 297C002F
	v_add_co_ci_u32_e64 v68, null, 0, v188, vcc_lo             // 00000002B428: D5207C44 01AB7880
	s_clause 0xf                                               // 00000002B430: BF85000F
	global_load_b32 v48, v[54:55], off offset:1024             // 00000002B434: DC520400 307C0036
	global_load_b32 v49, v[54:55], off offset:2048             // 00000002B43C: DC520800 317C0036
	global_load_b32 v55, v[54:55], off offset:3072             // 00000002B444: DC520C00 377C0036
	global_load_b32 v45, v[62:63], off offset:1024             // 00000002B44C: DC520400 2D7C003E
	global_load_b32 v46, v[62:63], off offset:2048             // 00000002B454: DC520800 2E7C003E
	global_load_b32 v47, v[62:63], off offset:3072             // 00000002B45C: DC520C00 2F7C003E
	global_load_b32 v57, v[67:68], off                         // 00000002B464: DC520000 397C0043
	global_load_b32 v59, v[67:68], off offset:1024             // 00000002B46C: DC520400 3B7C0043
	global_load_b32 v54, v[52:53], off offset:-4096            // 00000002B474: DC521000 367C0034
	global_load_b32 v64, v[52:53], off                         // 00000002B47C: DC520000 407C0034
	global_load_b32 v53, v[60:61], off offset:-4096            // 00000002B484: DC521000 357C003C
	global_load_b32 v63, v[60:61], off                         // 00000002B48C: DC520000 3F7C003C
	global_load_b32 v52, v[65:66], off offset:-4096            // 00000002B494: DC521000 347C0041
	global_load_b32 v62, v[65:66], off                         // 00000002B49C: DC520000 3E7C0041
	global_load_b32 v60, v[67:68], off offset:2048             // 00000002B4A4: DC520800 3C7C0043
	global_load_b32 v61, v[67:68], off offset:3072             // 00000002B4AC: DC520C00 3D7C0043
	v_lshlrev_b32_e32 v65, 3, v0                               // 00000002B4B4: 30820083
	s_cbranch_scc1 1                                           // 00000002B4B8: BFA20001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4c0>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 00000002B4BC: BE9C4D83
	s_load_b32 s39, s[0:1], 0x38                               // 00000002B4C0: F40009C0 F8000038
	v_lshrrev_b32_e32 v69, 4, v0                               // 00000002B4C8: 328A0084
	s_mul_hi_i32 s4, s2, 0x55555556                            // 00000002B4CC: 9704FF02 55555556
	v_and_b32_e32 v67, 0x78, v65                               // 00000002B4D4: 368682FF 00000078
	s_lshr_b32 s14, s4, 31                                     // 00000002B4DC: 850E9F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000002B4E0: BF870499
	s_add_i32 s4, s4, s14                                      // 00000002B4E4: 81040E04
	s_lshl_b32 s14, s4, 7                                      // 00000002B4E8: 840E8704
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002B4EC: BF870001
	v_lshlrev_b32_e32 v67, 1, v67                              // 00000002B4F0: 30868681
	s_ashr_i32 s15, s14, 31                                    // 00000002B4F4: 860F9F0E
	s_mov_b32 s4, exec_lo                                      // 00000002B4F8: BE84007E
	s_lshl_b64 s[14:15], s[14:15], 1                           // 00000002B4FC: 848E810E
	s_waitcnt lgkmcnt(0)                                       // 00000002B500: BF89FC07
	s_add_i32 s40, s39, -1                                     // 00000002B504: 8128C127
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002B508: BF870099
	v_min_i32_e32 v66, s40, v69                                // 00000002B50C: 22848A28
	v_mad_i64_i32 v[65:66], null, 0x5000, v66, s[8:9]          // 00000002B510: D6FF7C41 002284FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002B51C: BF870091
	.long 0xd7006a41                                           // 00000002B520: D7006A41
	v_cndmask_b32_e32 v0, v65, v14, vcc_lo                     // 00000002B524: 02001D41
	v_add_co_ci_u32_e64 v66, null, s15, v66, vcc_lo            // 00000002B528: D5207C42 01AA840F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002B530: BF870092
	.long 0xd7006a41                                           // 00000002B534: D7006A41
	v_cndmask_b32_e32 v1, v65, v67, vcc_lo                     // 00000002B538: 02028741
	v_add_co_ci_u32_e64 v66, null, 0, v66, vcc_lo              // 00000002B53C: D5207C42 01AA8480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002B544: BF870092
	.long 0xd7006a43                                           // 00000002B548: D7006A43
	v_cndmask_b32_e32 v1, 0x1000, v65, vcc_lo                  // 00000002B54C: 020282FF 00001000
	v_add_co_ci_u32_e64 v68, null, 0, v66, vcc_lo              // 00000002B554: D5207C44 01AA8480
	s_clause 0x1                                               // 00000002B55C: BF850001
	global_load_b128 v[74:77], v[65:66], off                   // 00000002B560: DC5E0000 4A7C0041
	global_load_b128 v[78:81], v[67:68], off                   // 00000002B568: DC5E0000 4E7C0043
	.long 0xd4c3007e                                           // 00000002B570: D4C3007E
	v_cndmask_b32_e32 v1, s39, v69, vcc_lo                     // 00000002B574: 02028A27
	s_cbranch_execz 11                                         // 00000002B578: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5a8>
	s_waitcnt vmcnt(1)                                         // 00000002B57C: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 00000002B580: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002B584: BF870001
	v_mov_b32_e32 v75, v76                                     // 00000002B588: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 00000002B58C: 7E94034C
	s_waitcnt vmcnt(0)                                         // 00000002B590: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 00000002B594: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 00000002B598: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 00000002B59C: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 00000002B5A0: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 00000002B5A4: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000002B5A8: 8C7E047E
	v_cmp_gt_u32_e32 vcc_lo, 16, v0                            // 00000002B5AC: 7C980090
	.long 0xd4440004                                           // 00000002B5B0: D4440004
	v_cndmask_b32_e32 v1, s39, v0, vcc_lo                      // 00000002B5B4: 02020027
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v140, 0            // 00000002B5B8: CA100080 418C0080
	s_and_b32 s16, vcc_lo, s4                                  // 00000002B5C0: 8B10046A
	scratch_store_b32 off, v65, off                            // 00000002B5C4: DC690000 007C4100
	s_and_saveexec_b32 s4, s16                                 // 00000002B5CC: BE842010
	s_cbranch_execz 30                                         // 00000002B5D0: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x64c>
	v_mul_u32_u24_e32 v65, 0xc0, v0                            // 00000002B5D4: 168200FF 000000C0
	s_lshl_b64 s[16:17], s[2:3], 2                             // 00000002B5DC: 84908202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002B5E0: BF870091
	.long 0xd7001242                                           // 00000002B5E4: D7001242
	v_cndmask_b32_e32 v1, s10, v65, vcc_lo                     // 00000002B5E8: 0202820A
	v_add_co_ci_u32_e64 v67, null, s11, 0, s18                 // 00000002B5EC: D5207C43 0049000B
	.long 0xd7001244                                           // 00000002B5F4: D7001244
	v_cndmask_b32_e32 v1, s12, v65, vcc_lo                     // 00000002B5F8: 0202820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002B5FC: BF870211
	v_add_co_ci_u32_e64 v69, null, s13, 0, s18                 // 00000002B600: D5207C45 0049000D
	.long 0xd7006a41                                           // 00000002B608: D7006A41
	v_cndmask_b32_e32 v0, v66, v16, vcc_lo                     // 00000002B60C: 02002142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002B610: BF870211
	v_add_co_ci_u32_e64 v66, null, s17, v67, vcc_lo            // 00000002B614: D5207C42 01AA8611
	.long 0xd7006a43                                           // 00000002B61C: D7006A43
	v_cndmask_b32_e32 v0, v68, v16, vcc_lo                     // 00000002B620: 02002144
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002B624: BF870001
	v_add_co_ci_u32_e64 v68, null, s17, v69, vcc_lo            // 00000002B628: D5207C44 01AA8A11
	global_load_b32 v140, v[65:66], off                        // 00000002B630: DC520000 8C7C0041
	global_load_b32 v65, v[67:68], off                         // 00000002B638: DC520000 417C0043
	s_waitcnt vmcnt(0)                                         // 00000002B640: BF8903F7
	scratch_store_b32 off, v65, off                            // 00000002B644: DC690000 007C4100
	s_or_b32 exec_lo, exec_lo, s4                              // 00000002B64C: 8C7E047E
	s_waitcnt vmcnt(62)                                        // 00000002B650: BF89FBF7
	v_dual_mul_f32 v139, 0x43800000, v5 :: v_dual_mul_f32 v138, 0x43800000, v6// 00000002B654: C8C60AFF 8B8A0CFF 43800000
	v_dual_mul_f32 v137, 0x43800000, v7 :: v_dual_mul_f32 v136, 0x43800000, v8// 00000002B660: C8C60EFF 898810FF 43800000
	s_waitcnt vmcnt(9)                                         // 00000002B66C: BF8927F7
	v_dual_mul_f32 v135, 0x43800000, v54 :: v_dual_mul_f32 v54, 0x43800000, v4// 00000002B670: C8C66CFF 873608FF 43800000
	v_dual_mul_f32 v134, 0x43800000, v2 :: v_dual_mul_f32 v133, 0x43800000, v3// 00000002B67C: C8C604FF 868406FF 43800000
	s_waitcnt vmcnt(8)                                         // 00000002B688: BF8923F7
	v_dual_mul_f32 v132, 0x43800000, v64 :: v_dual_mul_f32 v131, 0x43800000, v1// 00000002B68C: C8C680FF 848202FF 43800000
	v_dual_mul_f32 v130, 0x43800000, v12 :: v_dual_mul_f32 v129, 0x43800000, v13// 00000002B698: C8C618FF 82801AFF 43800000
	s_waitcnt vmcnt(7)                                         // 00000002B6A4: BF891FF7
	v_dual_mul_f32 v128, 0x43800000, v53 :: v_dual_mul_f32 v53, 0x43800000, v11// 00000002B6A8: C8C66AFF 803416FF 43800000
	v_dual_mul_f32 v127, 0x43800000, v9 :: v_dual_mul_f32 v126, 0x43800000, v10// 00000002B6B4: C8C612FF 7F7E14FF 43800000
	s_waitcnt vmcnt(6)                                         // 00000002B6C0: BF891BF7
	v_dual_mul_f32 v125, 0x43800000, v63 :: v_dual_mul_f32 v124, 0x43800000, v14// 00000002B6C4: C8C67EFF 7D7C1CFF 43800000
	v_dual_mul_f32 v123, 0x43800000, v15 :: v_dual_mul_f32 v122, 0x43800000, v16// 00000002B6D0: C8C61EFF 7B7A20FF 43800000
	s_waitcnt vmcnt(5)                                         // 00000002B6DC: BF8917F7
	v_dual_mul_f32 v121, 0x43800000, v52 :: v_dual_mul_f32 v52, 0x43800000, v22// 00000002B6E0: C8C668FF 79342CFF 43800000
	v_dual_mul_f32 v120, 0x43800000, v20 :: v_dual_mul_f32 v119, 0x43800000, v21// 00000002B6EC: C8C628FF 78762AFF 43800000
	s_waitcnt vmcnt(4)                                         // 00000002B6F8: BF8913F7
	v_dual_mul_f32 v118, 0x43800000, v62 :: v_dual_mul_f32 v117, 0x43800000, v17// 00000002B6FC: C8C67CFF 767422FF 43800000
	v_dual_mul_f32 v116, 0x43800000, v18 :: v_dual_mul_f32 v115, 0x43800000, v19// 00000002B708: C8C624FF 747226FF 43800000
	v_dual_mul_f32 v114, 0x43800000, v51 :: v_dual_mul_f32 v111, 0x43800000, v58// 00000002B714: C8C666FF 726E74FF 43800000
	v_dual_mul_f32 v113, 0x43800000, v23 :: v_dual_mul_f32 v112, 0x43800000, v24// 00000002B720: C8C62EFF 717030FF 43800000
	v_dual_mul_f32 v51, 0x43800000, v31 :: v_dual_mul_f32 v110, 0x43800000, v28// 00000002B72C: C8C63EFF 336E38FF 43800000
	v_dual_mul_f32 v109, 0x43800000, v29 :: v_dual_mul_f32 v108, 0x43800000, v30// 00000002B738: C8C63AFF 6D6C3CFF 43800000
	v_dual_mul_f32 v107, 0x43800000, v50 :: v_dual_mul_f32 v106, 0x43800000, v25// 00000002B744: C8C664FF 6B6A32FF 43800000
	v_dual_mul_f32 v105, 0x43800000, v26 :: v_dual_mul_f32 v50, 0x43800000, v27// 00000002B750: C8C634FF 693236FF 43800000
	v_dual_mul_f32 v104, 0x43800000, v56 :: v_dual_mul_f32 v101, 0x43800000, v37// 00000002B75C: C8C670FF 68644AFF 43800000
	v_dual_mul_f32 v103, 0x43800000, v32 :: v_dual_mul_f32 v98, 0x43800000, v34// 00000002B768: C8C640FF 676244FF 43800000
	v_dual_mul_f32 v102, 0x43800000, v36 :: v_dual_mul_f32 v99, 0x43800000, v33// 00000002B774: C8C648FF 666242FF 43800000
	v_dual_mul_f32 v100, 0x43800000, v44 :: v_dual_mul_f32 v97, 0x43800000, v43// 00000002B780: C8C658FF 646056FF 43800000
	v_dual_mul_f32 v58, 0x43800000, v35 :: v_dual_mul_f32 v93, 0x43800000, v42// 00000002B78C: C8C646FF 3A5C54FF 43800000
	v_dual_mul_f32 v96, 0x43800000, v38 :: v_dual_mul_f32 v95, 0x43800000, v39// 00000002B798: C8C64CFF 605E4EFF 43800000
	v_dual_mul_f32 v94, 0x43800000, v40 :: v_dual_mul_f32 v91, 0x43800000, v49// 00000002B7A4: C8C650FF 5E5A62FF 43800000
	v_dual_mul_f32 v92, 0x43800000, v48 :: v_dual_mul_f32 v141, 0x43800000, v45// 00000002B7B0: C8C660FF 5C8C5AFF 43800000
	v_dual_mul_f32 v152, 0x43800000, v55 :: v_dual_mul_f32 v191, 0x43800000, v57// 00000002B7BC: C8C66EFF 98BE72FF 43800000
	v_dual_mul_f32 v90, 0x43800000, v41 :: v_dual_mul_f32 v189, 0x43800000, v59// 00000002B7C8: C8C652FF 5ABC76FF 43800000
	s_waitcnt vmcnt(2)                                         // 00000002B7D4: BF890BF7
	v_dual_mul_f32 v150, 0x43800000, v46 :: v_dual_mul_f32 v151, 0x43800000, v61// 00000002B7D8: C8C65CFF 96967AFF 43800000
	v_mul_f32_e32 v142, 0x43800000, v47                        // 00000002B7E4: 111C5EFF 43800000
	v_mul_f32_e32 v190, 0x43800000, v60                        // 00000002B7EC: 117C78FF 43800000
	s_cmp_lt_i32 s39, 1                                        // 00000002B7F4: BF048127
	s_cbranch_scc1 4714                                        // 00000002B7F8: BFA2126A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x51a4>
	s_add_u32 s30, s8, s14                                     // 00000002B7FC: 801E0E08
	s_addc_u32 s31, s9, s15                                    // 00000002B800: 821F0F09
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000002B804: 848E8202
	s_load_b64 s[26:27], s[0:1], 0x68                          // 00000002B808: F4040680 F8000068
	s_add_u32 s10, s10, s14                                    // 00000002B810: 800A0E0A
	s_addc_u32 s11, s11, s15                                   // 00000002B814: 820B0F0B
	s_add_u32 s34, s12, s14                                    // 00000002B818: 80220E0C
	s_addc_u32 s35, s13, s15                                   // 00000002B81C: 82230F0D
	s_add_i32 s3, s39, 15                                      // 00000002B820: 81038F27
	s_load_b256 s[12:19], s[0:1], 0x48                         // 00000002B824: F40C0300 F8000048
	s_ashr_i32 s4, s3, 31                                      // 00000002B82C: 86049F03
	.long 0xd71f008f                                           // 00000002B830: D71F008F
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000002B834: 020100C1
	s_lshr_b32 s4, s4, 28                                      // 00000002B838: 85049C04
	v_mov_b32_e32 v1, 0                                        // 00000002B83C: 7E020280
	s_add_i32 s3, s3, s4                                       // 00000002B840: 81030403
	v_mov_b32_e32 v149, 0x1000504                              // 00000002B844: 7F2A02FF 01000504
	s_ashr_i32 s41, s3, 4                                      // 00000002B84C: 86298403
	s_cmp_lg_u32 s21, 0                                        // 00000002B850: BF078015
	s_movk_i32 s3, 0x5f40                                      // 00000002B854: B0035F40
	s_waitcnt lgkmcnt(0)                                       // 00000002B858: BF89FC07
	s_cselect_b32 s15, -1, 0                                   // 00000002B85C: 980F80C1
	s_lshl_b32 s22, s2, 7                                      // 00000002B860: 84168702
	v_and_b32_e32 v2, 16, v143                                 // 00000002B864: 36051E90
	s_ashr_i32 s23, s22, 31                                    // 00000002B868: 86179F16
	s_cmp_gt_u32 s20, 63                                       // 00000002B86C: BF08BF14
	v_xor_b32_e32 v146, 2, v143                                // 00000002B870: 3B251E82
	s_cselect_b32 s42, -1, 0                                   // 00000002B874: 982A80C1
	s_cmp_eq_u32 s21, 0                                        // 00000002B878: BF068015
	v_add_nc_u32_e32 v144, 16, v2                              // 00000002B87C: 4B200490
	s_cselect_b32 s2, -1, 0                                    // 00000002B880: 980280C1
	v_xor_b32_e32 v147, 4, v143                                // 00000002B884: 3B271E84
	s_and_b32 s4, s2, exec_lo                                  // 00000002B888: 8B047E02
	s_cselect_b32 s43, s3, 0x5f80                              // 00000002B88C: 982BFF03 00005F80
	s_lshl_b64 s[36:37], s[22:23], 1                           // 00000002B894: 84A48116
	v_xor_b32_e32 v148, 8, v143                                // 00000002B898: 3B291E88
	s_add_u32 s44, s24, s36                                    // 00000002B89C: 802C2418
	s_addc_u32 s45, s25, s37                                   // 00000002B8A0: 822D2519
	s_max_i32 s46, s41, 1                                      // 00000002B8A4: 8A2E8129
	s_add_u32 s16, s16, s6                                     // 00000002B8A8: 80100610
	s_addc_u32 s17, s17, s7                                    // 00000002B8AC: 82110711
	s_add_u32 s18, s18, s6                                     // 00000002B8B0: 80120612
	s_mov_b32 s20, 0                                           // 00000002B8B4: BE940080
	s_addc_u32 s19, s19, s7                                    // 00000002B8B8: 82130713
	s_add_u32 s47, s26, s6                                     // 00000002B8BC: 802F061A
	s_addc_u32 s7, s27, s7                                     // 00000002B8C0: 8207071B
	s_mov_b32 s48, 0x41800000                                  // 00000002B8C4: BEB000FF 41800000
	s_movk_i32 s49, 0x1800                                     // 00000002B8CC: B0311800
	s_movk_i32 s50, 0x2900                                     // 00000002B8D0: B0322900
	s_mov_b32 s21, s20                                         // 00000002B8D4: BE950014
	s_mov_b32 s22, s20                                         // 00000002B8D8: BE960014
	s_mov_b32 s23, s20                                         // 00000002B8DC: BE970014
	s_mov_b32 s24, s20                                         // 00000002B8E0: BE980014
	s_mov_b32 s25, s20                                         // 00000002B8E4: BE990014
	s_mov_b32 s26, s20                                         // 00000002B8E8: BE9A0014
	s_mov_b32 s27, s20                                         // 00000002B8EC: BE9B0014
	s_mov_b32 s51, 0x3d800000                                  // 00000002B8F0: BEB300FF 3D800000
	s_mov_b32 s52, 0x76543210                                  // 00000002B8F8: BEB400FF 76543210
	s_mov_b32 s53, s20                                         // 00000002B900: BEB50014
	s_mov_b32 s6, s20                                          // 00000002B904: BE860014
	s_branch 10                                                // 00000002B908: BFA0000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x934>
	v_mov_b32_e32 v151, v65                                    // 00000002B90C: 7F2E0341
	v_mov_b32_e32 v152, v57                                    // 00000002B910: 7F300339
	v_mov_b32_e32 v58, v49                                     // 00000002B914: 7E740331
	v_mov_b32_e32 v50, v9                                      // 00000002B918: 7E640309
	v_mov_b32_e32 v51, v17                                     // 00000002B91C: 7E660311
	v_mov_b32_e32 v52, v25                                     // 00000002B920: 7E680319
	v_mov_b32_e32 v53, v33                                     // 00000002B924: 7E6A0321
	v_mov_b32_e32 v54, v41                                     // 00000002B928: 7E6C0329
	s_cmp_eq_u32 s53, s46                                      // 00000002B92C: BF062E35
	s_cbranch_scc1 4626                                        // 00000002B930: BFA21212 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x517c>
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 00000002B934: 916A267E
	v_mov_b32_e32 v44, v0                                      // 00000002B938: 7E580300
	s_cbranch_vccnz 1                                          // 00000002B93C: BFA40001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x944>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 00000002B940: BE9C4D83
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002B944: BF8701B1
	v_ashrrev_i32_e32 v2, 4, v44                               // 00000002B948: 34045884
	v_and_b32_e32 v55, 15, v44                                 // 00000002B94C: 366E588F
	.long 0xd4440003                                           // 00000002B950: D4440003
	v_cndmask_b32_e32 v1, 16, v44, vcc_lo                      // 00000002B954: 02025890
	.long 0xd72c0003                                           // 00000002B958: D72C0003
	v_cndmask_b32_e32 v1, 0x110, v2, vcc_lo                    // 00000002B95C: 020204FF 00000110
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002B964: BF870001
	v_lshl_add_u32 v3, v55, 4, v3                              // 00000002B968: D6460003 040D0937
	s_waitcnt vmcnt(1)                                         // 00000002B970: BF8907F7
	ds_store_b128 v3, v[74:77] offset:10496                    // 00000002B974: DB7C2900 00004A03
	s_waitcnt vmcnt(0)                                         // 00000002B97C: BF8903F7
	ds_store_b128 v3, v[78:81] offset:6144                     // 00000002B980: DB7C1800 00004E03
	s_and_saveexec_b32 s4, s3                                  // 00000002B988: BE842003
	s_cbranch_execz 6                                          // 00000002B98C: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x9a8>
	scratch_load_b32 v4, off, off                              // 00000002B990: DC510000 047C0000
	v_lshlrev_b32_e32 v3, 2, v44                               // 00000002B998: 30065882
	s_waitcnt vmcnt(0)                                         // 00000002B99C: BF8903F7
	ds_store_b32 v3, v4 offset:24064                           // 00000002B9A0: D8345E00 00000403
	s_or_b32 exec_lo, exec_lo, s4                              // 00000002B9A8: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002B9AC: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 00000002B9B0: 916A267E
	s_cbranch_vccnz 5                                          // 00000002B9B4: BFA40005 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x9cc>
	s_sendmsg_rtn_b64 s[54:55], sendmsg(MSG_RTN_GET_REALTIME)  // 00000002B9B8: BEB64D83
	s_waitcnt lgkmcnt(0)                                       // 00000002B9BC: BF89FC07
	s_sub_i32 s4, s6, s28                                      // 00000002B9C0: 81841C06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002B9C4: BF870009
	s_add_i32 s6, s4, s54                                      // 00000002B9C8: 81063604
	v_and_b32_e32 v34, 1, v44                                  // 00000002B9CC: 36445881
	s_waitcnt lgkmcnt(0)                                       // 00000002B9D0: BF89FC07
	s_lshl_b32 s29, s53, 4                                     // 00000002B9D4: 841D8435
	v_or_b32_e32 v153, s33, v55                                // 00000002B9D8: 39326E21
	s_mov_b32 s54, exec_lo                                     // 00000002B9DC: BEB6007E
	v_or_b32_e32 v15, s29, v34                                 // 00000002B9E0: 381E441D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002B9E4: BF870112
	v_and_b32_e32 v6, 0x7ffffffe, v153                         // 00000002B9E8: 360D32FF 7FFFFFFE
	v_min_i32_e32 v3, s40, v15                                 // 00000002B9F0: 22061E28
	v_or_b32_e32 v5, 2, v15                                    // 00000002B9F4: 380A1E82
	v_or_b32_e32 v7, 4, v15                                    // 00000002B9F8: 380E1E84
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002B9FC: BF870004
	v_lshlrev_b32_e32 v19, 1, v6                               // 00000002BA00: 30260C81
	v_or_b32_e32 v8, 6, v15                                    // 00000002BA04: 38101E86
	v_mad_i64_i32 v[3:4], null, 0x5000, v3, s[8:9]             // 00000002BA08: D6FF7C03 002206FF 00005000
	v_min_i32_e32 v5, s40, v5                                  // 00000002BA14: 220A0A28
	v_min_i32_e32 v7, s40, v7                                  // 00000002BA18: 220E0E28
	v_or_b32_e32 v17, 12, v15                                  // 00000002BA1C: 38221E8C
	v_min_i32_e32 v8, s40, v8                                  // 00000002BA20: 22101028
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002BA24: BF8700A4
	v_mad_i64_i32 v[5:6], null, 0x5000, v5, s[8:9]             // 00000002BA28: D6FF7C05 00220AFF 00005000
	.long 0xd7006a09                                           // 00000002BA34: D7006A09
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000002BA38: 02004903
	v_add_co_ci_u32_e64 v10, null, s37, v4, vcc_lo             // 00000002BA3C: D5207C0A 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v7, s[8:9]             // 00000002BA44: D6FF7C03 00220EFF 00005000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002BA50: BF870093
	.long 0xd7006a07                                           // 00000002BA54: D7006A07
	v_cndmask_b32_e32 v1, v9, v19, vcc_lo                      // 00000002BA58: 02022709
	v_add_co_ci_u32_e64 v9, null, 0, v10, vcc_lo               // 00000002BA5C: D5207C09 01AA1480
	.long 0xd7006a0a                                           // 00000002BA64: D7006A0A
	v_cndmask_b32_e32 v0, v5, v36, vcc_lo                      // 00000002BA68: 02004905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002BA6C: BF870211
	v_add_co_ci_u32_e64 v11, null, s37, v6, vcc_lo             // 00000002BA70: D5207C0B 01AA0C25
	.long 0xd7006a05                                           // 00000002BA78: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 00000002BA7C: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002BA84: BF870211
	v_add_co_ci_u32_e64 v6, null, 0, v9, vcc_lo                // 00000002BA88: D5207C06 01AA1280
	.long 0xd7006a07                                           // 00000002BA90: D7006A07
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 00000002BA94: 0202270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002BA98: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v11, vcc_lo               // 00000002BA9C: D5207C09 01AA1680
	.long 0xd7006a0a                                           // 00000002BAA4: D7006A0A
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000002BAA8: 02004903
	v_add_co_ci_u32_e64 v11, null, s37, v4, vcc_lo             // 00000002BAAC: D5207C0B 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v8, s[8:9]             // 00000002BAB4: D6FF7C03 002210FF 00005000
	.long 0xd7006a07                                           // 00000002BAC0: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 00000002BAC4: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002BACC: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v9, vcc_lo                // 00000002BAD0: D5207C08 01AA1280
	.long 0xd7006a09                                           // 00000002BAD8: D7006A09
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 00000002BADC: 0202270A
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo              // 00000002BAE0: D5207C0A 01AA1680
	v_or_b32_e32 v11, 8, v15                                   // 00000002BAE8: 38161E88
	.long 0xd7006a03                                           // 00000002BAEC: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000002BAF0: 02004903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002BAF4: BF870191
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 00000002BAF8: D5207C04 01AA0825
	v_min_i32_e32 v11, s40, v11                                // 00000002BB00: 22161628
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002BB04: BF870093
	.long 0xd7006a0c                                           // 00000002BB08: D7006A0C
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000002BB0C: 02022703
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000002BB10: D5207C0D 01AA0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002BB18: BF8700A3
	v_mad_i64_i32 v[3:4], null, 0x5000, v11, s[8:9]            // 00000002BB1C: D6FF7C03 002216FF 00005000
	.long 0xd7006a09                                           // 00000002BB28: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v9, vcc_lo                   // 00000002BB2C: 020212FF 00002000
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 00000002BB34: D5207C0A 01AA1480
	.long 0xd7006a0b                                           // 00000002BB3C: D7006A0B
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 00000002BB40: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000002BB48: BF8700B1
	v_add_co_ci_u32_e64 v12, null, 0, v13, vcc_lo              // 00000002BB4C: D5207C0C 01AA1A80
	v_or_b32_e32 v13, 10, v15                                  // 00000002BB54: 381A1E8A
	.long 0xd7006a03                                           // 00000002BB58: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000002BB5C: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 00000002BB60: D5207C04 01AA0825
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002BB68: BF870193
	v_min_i32_e32 v13, s40, v13                                // 00000002BB6C: 221A1A28
	.long 0xd7006a0e                                           // 00000002BB70: D7006A0E
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000002BB74: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002BB78: BF870191
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000002BB7C: D5207C10 01AA0880
	v_mad_i64_i32 v[3:4], null, 0x5000, v13, s[8:9]            // 00000002BB84: D6FF7C03 00221AFF 00005000
	v_or_b32_e32 v15, 14, v15                                  // 00000002BB90: 381E1E8E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002BB94: BF870094
	.long 0xd7006a0d                                           // 00000002BB98: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v14, vcc_lo                  // 00000002BB9C: 02021CFF 00002000
	v_add_co_ci_u32_e64 v14, null, 0, v16, vcc_lo              // 00000002BBA4: D5207C0E 01AA2080
	v_min_i32_e32 v16, s40, v17                                // 00000002BBAC: 22202228
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002BBB0: BF8700A4
	v_min_i32_e32 v15, s40, v15                                // 00000002BBB4: 221E1E28
	.long 0xd7006a11                                           // 00000002BBB8: D7006A11
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000002BBBC: 02004903
	v_add_co_ci_u32_e64 v18, null, s37, v4, vcc_lo             // 00000002BBC0: D5207C12 01AA0825
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002BBC8: BF870194
	v_mad_i64_i32 v[3:4], null, 0x5000, v16, s[8:9]            // 00000002BBCC: D6FF7C03 002220FF 00005000
	.long 0xd7006a11                                           // 00000002BBD8: D7006A11
	v_cndmask_b32_e32 v1, v17, v19, vcc_lo                     // 00000002BBDC: 02022711
	v_mad_i64_i32 v[15:16], null, 0x5000, v15, s[8:9]          // 00000002BBE0: D6FF7C0F 00221EFF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002BBEC: BF870194
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 00000002BBF0: D5207C12 01AA2480
	.long 0xd7006a11                                           // 00000002BBF8: D7006A11
	v_cndmask_b32_e32 v1, 0x2000, v17, vcc_lo                  // 00000002BBFC: 020222FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002BC04: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 00000002BC08: D5207C12 01AA2480
	.long 0xd7006a03                                           // 00000002BC10: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000002BC14: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 00000002BC18: D5207C04 01AA0825
	.long 0xd7006a0f                                           // 00000002BC20: D7006A0F
	v_cndmask_b32_e32 v0, v15, v36, vcc_lo                     // 00000002BC24: 0200490F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002BC28: BF870211
	v_add_co_ci_u32_e64 v16, null, s37, v16, vcc_lo            // 00000002BC2C: D5207C10 01AA2025
	.long 0xd7006a03                                           // 00000002BC34: D7006A03
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000002BC38: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002BC3C: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000002BC40: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 00000002BC48: D7006A0F
	v_cndmask_b32_e32 v1, v15, v19, vcc_lo                     // 00000002BC4C: 0202270F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002BC50: BF870211
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 00000002BC54: D5207C10 01AA2080
	.long 0xd7006a03                                           // 00000002BC5C: D7006A03
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 00000002BC60: 020206FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002BC68: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000002BC6C: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 00000002BC74: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v15, vcc_lo                  // 00000002BC78: 02021EFF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002BC80: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 00000002BC84: D5207C10 01AA2080
	s_clause 0x7                                               // 00000002BC8C: BF850007
	global_load_b32 v42, v[5:6], off                           // 00000002BC90: DC520000 2A7C0005
	global_load_b32 v41, v[7:8], off                           // 00000002BC98: DC520000 297C0007
	global_load_b32 v40, v[9:10], off                          // 00000002BCA0: DC520000 287C0009
	global_load_b32 v39, v[11:12], off                         // 00000002BCA8: DC520000 277C000B
	global_load_b32 v38, v[13:14], off                         // 00000002BCB0: DC520000 267C000D
	global_load_b32 v37, v[17:18], off                         // 00000002BCB8: DC520000 257C0011
	global_load_b32 v35, v[3:4], off                           // 00000002BCC0: DC520000 237C0003
	global_load_b32 v36, v[15:16], off                         // 00000002BCC8: DC520000 247C000F
	v_lshlrev_b32_e32 v5, 16, v78                              // 00000002BCD0: 300A9C90
	v_and_b32_e32 v4, 0xffff0000, v74                          // 00000002BCD4: 360894FF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v75                          // 00000002BCDC: 361096FF FFFF0000
	v_lshlrev_b32_e32 v3, 16, v74                              // 00000002BCE4: 30069490
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002BCE8: BF8701A4
	v_dual_mul_f32 v5, v5, v5 :: v_dual_lshlrev_b32 v12, 16, v80// 00000002BCEC: C8E20B05 050CA090
	v_lshlrev_b32_e32 v7, 16, v75                              // 00000002BCF4: 300E9690
	v_dual_mul_f32 v3, v3, v3 :: v_dual_and_b32 v6, 0xffff0000, v78// 00000002BCF8: C8E40703 03069CFF FFFF0000
	v_mul_f32_e32 v4, v4, v4                                   // 00000002BD04: 10080904
	v_and_b32_e32 v13, 0xffff0000, v80                         // 00000002BD08: 361AA0FF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v76                         // 00000002BD10: 361498FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002BD18: BF8701B4
	v_dual_mul_f32 v6, v6, v6 :: v_dual_and_b32 v11, 0xffff0000, v77// 00000002BD1C: C8E40D06 060A9AFF FFFF0000
	v_mul_f32_e32 v12, v12, v12                                // 00000002BD28: 1018190C
	v_add_f32_e32 v3, v3, v4                                   // 00000002BD2C: 06060903
	v_dual_add_f32 v4, v5, v6 :: v_dual_lshlrev_b32 v9, 16, v76// 00000002BD30: C9220D05 04089890
	v_dual_mul_f32 v5, v7, v7 :: v_dual_mul_f32 v6, v8, v8     // 00000002BD38: C8C60F07 05061108
	v_lshlrev_b32_e32 v7, 16, v79                              // 00000002BD40: 300E9E90
	v_dual_mul_f32 v13, v13, v13 :: v_dual_and_b32 v8, 0xffff0000, v79// 00000002BD44: C8E41B0D 0D089EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002BD50: BF870113
	v_dual_add_f32 v5, v5, v6 :: v_dual_and_b32 v14, 0xffff0000, v81// 00000002BD54: C9240D05 050EA2FF FFFF0000
	v_dual_mul_f32 v6, v7, v7 :: v_dual_mul_f32 v7, v8, v8     // 00000002BD60: C8C60F07 06061108
	v_dual_mul_f32 v8, v9, v9 :: v_dual_mul_f32 v9, v10, v10   // 00000002BD68: C8C61309 0808150A
	v_lshlrev_b32_e32 v10, 16, v77                             // 00000002BD70: 30149A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002BD74: BF870113
	v_dual_add_f32 v6, v6, v7 :: v_dual_add_f32 v7, v12, v13   // 00000002BD78: C9080F06 06061B0C
	v_dual_add_f32 v8, v8, v9 :: v_dual_mul_f32 v9, v10, v10   // 00000002BD80: C9061308 0808150A
	v_dual_mul_f32 v10, v11, v11 :: v_dual_lshlrev_b32 v11, 16, v81// 00000002BD88: C8E2170B 0A0AA290
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002BD90: BF870113
	v_add_f32_e32 v4, v4, v6                                   // 00000002BD94: 06080D04
	v_dual_add_f32 v9, v9, v10 :: v_dual_mul_f32 v10, v11, v11 // 00000002BD98: C9061509 090A170B
	v_mul_f32_e32 v11, v14, v14                                // 00000002BDA0: 10161D0E
	v_add_f32_e32 v3, v3, v5                                   // 00000002BDA4: 06060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002BDA8: BF870123
	v_add_f32_e32 v5, v8, v9                                   // 00000002BDAC: 060A1308
	v_xor_b32_e32 v9, 1, v143                                  // 00000002BDB0: 3A131E81
	v_dual_add_f32 v8, v10, v11 :: v_dual_add_f32 v3, v3, v5   // 00000002BDB4: C908170A 08020B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002BDBC: BF8701A2
	v_cmp_lt_u32_e32 vcc_lo, v9, v144                          // 00000002BDC0: 7C932109
	v_cndmask_b32_e32 v9, v143, v9, vcc_lo                     // 00000002BDC4: 0212138F
	v_add_f32_e32 v5, v7, v8                                   // 00000002BDC8: 060A1107
	v_cmp_lt_u32_e32 vcc_lo, v146, v144                        // 00000002BDCC: 7C932192
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002BDD0: BF870193
	v_lshlrev_b32_e32 v6, 2, v9                                // 00000002BDD4: 300C1282
	v_dual_add_f32 v4, v4, v5 :: v_dual_cndmask_b32 v7, v143, v146// 00000002BDD8: C9120B04 0407258F
	v_cmp_lt_u32_e32 vcc_lo, v147, v144                        // 00000002BDE0: 7C932193
	ds_bpermute_b32 v5, v6, v3                                 // 00000002BDE4: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 00000002BDEC: DACC0000 06000406
	s_waitcnt lgkmcnt(0)                                       // 00000002BDF4: BF89FC07
	v_dual_add_f32 v4, v4, v6 :: v_dual_add_f32 v3, v3, v5     // 00000002BDF8: C9080D04 04020B03
	v_lshlrev_b32_e32 v5, 2, v7                                // 00000002BE00: 300A0E82
	ds_bpermute_b32 v6, v5, v3                                 // 00000002BE04: DACC0000 06000305
	ds_bpermute_b32 v5, v5, v4                                 // 00000002BE0C: DACC0000 05000405
	v_cndmask_b32_e32 v7, v143, v147, vcc_lo                   // 00000002BE14: 020F278F
	v_cmp_lt_u32_e32 vcc_lo, v148, v144                        // 00000002BE18: 7C932194
	s_waitcnt lgkmcnt(0)                                       // 00000002BE1C: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v5     // 00000002BE20: C9080D03 03040B04
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002BE28: BF870003
	v_dual_cndmask_b32 v7, v143, v148 :: v_dual_lshlrev_b32 v6, 2, v7// 00000002BE2C: CA63298F 07060E82
	ds_bpermute_b32 v5, v6, v3                                 // 00000002BE34: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 00000002BE3C: DACC0000 06000406
	v_lshlrev_b32_e32 v7, 2, v7                                // 00000002BE44: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 00000002BE48: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000002BE4C: C9080B03 03040D04
	ds_bpermute_b32 v5, v7, v3                                 // 00000002BE54: DACC0000 05000307
	ds_bpermute_b32 v6, v7, v4                                 // 00000002BE5C: DACC0000 06000407
	v_cmpx_eq_u32_e32 0, v55                                   // 00000002BE64: 7D946E80
	s_cbranch_execz 41                                         // 00000002BE68: BFA50029 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xf10>
	s_waitcnt lgkmcnt(0)                                       // 00000002BE6C: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000002BE70: C9080B03 03040D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002BE78: BF870091
	v_dual_add_f32 v3, 0x358637bd, v3 :: v_dual_add_f32 v4, 0x358637bd, v4// 00000002BE7C: C90806FF 030408FF 358637BD
	v_dual_mul_f32 v5, 0x4b800000, v3 :: v_dual_mul_f32 v6, 0x4b800000, v4// 00000002BE88: C8C606FF 050608FF 4B800000
	.long 0xd4140004                                           // 00000002BE94: D4140004
	v_cndmask_b32_e32 v1, 0x800000, v4, vcc_lo                 // 00000002BE98: 020208FF 00800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v3                      // 00000002BEA0: 7C2806FF 00800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002BEA8: BF870092
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 00000002BEAC: D5010004 00120D04
	v_rsq_f32_e32 v4, v4                                       // 00000002BEB4: 7E085D04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002BEB8: BF870095
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_mul_f32 v6, 0x45800000, v4// 00000002BEBC: CA460B03 030608FF 45800000
	v_rsq_f32_e32 v3, v3                                       // 00000002BEC8: 7E065D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 00000002BECC: BF870321
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 00000002BED0: D5010004 00120D04
	v_rsq_f32_e32 v6, 0x43000000                               // 00000002BED8: 7E0C5CFF 43000000
	v_mul_f32_e32 v5, 0x45800000, v3                           // 00000002BEE0: 100A06FF 45800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002BEE8: BF870001
	v_cndmask_b32_e32 v3, v3, v5, vcc_lo                       // 00000002BEEC: 02060B03
	v_lshlrev_b32_e32 v5, 2, v2                                // 00000002BEF0: 300A0482
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 00000002BEF4: BF870105
	v_mul_f32_e32 v3, v6, v3                                   // 00000002BEF8: 10060706
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002BEFC: BF870002
	v_add_nc_u32_e32 v5, 0x5c00, v5                            // 00000002BF00: 4A0A0AFF 00005C00
	ds_store_2addr_b32 v5, v4, v3 offset0:208 offset1:224      // 00000002BF08: D838E0D0 00030405
	s_or_b32 exec_lo, exec_lo, s54                             // 00000002BF10: 8C7E367E
	v_and_b32_e32 v43, 31, v44                                 // 00000002BF14: 3656589F
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 00000002BF18: 916A027E
	s_cbranch_vccnz 119                                        // 00000002BF1C: BFA40077 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10fc>
	.long 0xd7600045                                           // 00000002BF20: D7600045
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                   // 00000002BF24: 0201018C
	.long 0xd7600044                                           // 00000002BF28: D7600044
	v_cndmask_b32_e32 v0, v140, v129, vcc_lo                   // 00000002BF2C: 0201038C
	.long 0xd7600043                                           // 00000002BF30: D7600043
	v_cndmask_b32_e32 v0, v140, v130, vcc_lo                   // 00000002BF34: 0201058C
	.long 0xd7600042                                           // 00000002BF38: D7600042
	v_cndmask_b32_e32 v0, v140, v131, vcc_lo                   // 00000002BF3C: 0201078C
	.long 0xd7600041                                           // 00000002BF40: D7600041
	v_cndmask_b32_e32 v0, v140, v132, vcc_lo                   // 00000002BF44: 0201098C
	.long 0xd7600040                                           // 00000002BF48: D7600040
	v_cndmask_b32_e32 v0, v140, v133, vcc_lo                   // 00000002BF4C: 02010B8C
	.long 0xd760003f                                           // 00000002BF50: D760003F
	v_cndmask_b32_e32 v0, v140, v134, vcc_lo                   // 00000002BF54: 02010D8C
	.long 0xd760003e                                           // 00000002BF58: D760003E
	v_cndmask_b32_e32 v0, v140, v135, vcc_lo                   // 00000002BF5C: 02010F8C
	.long 0xd760003d                                           // 00000002BF60: D760003D
	v_cndmask_b32_e32 v0, v140, v136, vcc_lo                   // 00000002BF64: 0201118C
	.long 0xd760003c                                           // 00000002BF68: D760003C
	v_cndmask_b32_e32 v0, v140, v137, vcc_lo                   // 00000002BF6C: 0201138C
	.long 0xd760003b                                           // 00000002BF70: D760003B
	v_cndmask_b32_e32 v0, v140, v138, vcc_lo                   // 00000002BF74: 0201158C
	.long 0xd760003a                                           // 00000002BF78: D760003A
	v_cndmask_b32_e32 v0, v140, v139, vcc_lo                   // 00000002BF7C: 0201178C
	.long 0xd7600039                                           // 00000002BF80: D7600039
	v_cndmask_b32_e32 v0, v140, v140, vcc_lo                   // 00000002BF84: 0201198C
	.long 0xd7600038                                           // 00000002BF88: D7600038
	v_cndmask_b32_e32 v0, v140, v141, vcc_lo                   // 00000002BF8C: 02011B8C
	.long 0xd7600037                                           // 00000002BF90: D7600037
	v_cndmask_b32_e32 v0, v140, v142, vcc_lo                   // 00000002BF94: 02011D8C
	.long 0xd7600036                                           // 00000002BF98: D7600036
	v_cndmask_b32_e32 v0, v140, v143, vcc_lo                   // 00000002BF9C: 02011F8C
	s_mov_b32 s4, exec_lo                                      // 00000002BFA0: BE84007E
	v_cmpx_gt_u32_e32 16, v43                                  // 00000002BFA4: 7D985690
	s_cbranch_execz 83                                         // 00000002BFA8: BFA50053 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10f8>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000002BFAC: 7C945680
	s_add_f32 s69, s69, 0                                      // 00000002BFB0: A0458045
	v_lshlrev_b32_e32 v4, 2, v43                               // 00000002BFB4: 30085682
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000002BFB8: BF8704BA
	s_add_f32 s68, s69, s68                                    // 00000002BFBC: A0444445
	v_cndmask_b32_e64 v3, 0, s69, vcc_lo                       // 00000002BFC0: D5010003 01A88A80
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 00000002BFC8: 7C945681
	s_add_f32 s67, s68, s67                                    // 00000002BFCC: A0434344
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002BFD0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s68, vcc_lo                      // 00000002BFD4: D5010003 01A88903
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 00000002BFDC: 7C945682
	s_add_f32 s66, s67, s66                                    // 00000002BFE0: A0424243
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002BFE4: BF8704A2
	v_cndmask_b32_e64 v3, v3, s67, vcc_lo                      // 00000002BFE8: D5010003 01A88703
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 00000002BFF0: 7C945683
	s_add_f32 s65, s66, s65                                    // 00000002BFF4: A0414142
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002BFF8: BF8704A2
	v_cndmask_b32_e64 v3, v3, s66, vcc_lo                      // 00000002BFFC: D5010003 01A88503
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 00000002C004: 7C945684
	s_add_f32 s64, s65, s64                                    // 00000002C008: A0404041
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002C00C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s65, vcc_lo                      // 00000002C010: D5010003 01A88303
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 00000002C018: 7C945685
	s_add_f32 s63, s64, s63                                    // 00000002C01C: A03F3F40
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002C020: BF8704A2
	v_cndmask_b32_e64 v3, v3, s64, vcc_lo                      // 00000002C024: D5010003 01A88103
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 00000002C02C: 7C945686
	s_add_f32 s62, s63, s62                                    // 00000002C030: A03E3E3F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002C034: BF8704A2
	v_cndmask_b32_e64 v3, v3, s63, vcc_lo                      // 00000002C038: D5010003 01A87F03
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 00000002C040: 7C945687
	s_add_f32 s61, s62, s61                                    // 00000002C044: A03D3D3E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002C048: BF8704A2
	v_cndmask_b32_e64 v3, v3, s62, vcc_lo                      // 00000002C04C: D5010003 01A87D03
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 00000002C054: 7C945688
	s_add_f32 s60, s61, s60                                    // 00000002C058: A03C3C3D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002C05C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s61, vcc_lo                      // 00000002C060: D5010003 01A87B03
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 00000002C068: 7C945689
	s_add_f32 s59, s60, s59                                    // 00000002C06C: A03B3B3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002C070: BF8704A2
	v_cndmask_b32_e64 v3, v3, s60, vcc_lo                      // 00000002C074: D5010003 01A87903
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000002C07C: 7C94568A
	s_add_f32 s58, s59, s58                                    // 00000002C080: A03A3A3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002C084: BF8704A2
	v_cndmask_b32_e64 v3, v3, s59, vcc_lo                      // 00000002C088: D5010003 01A87703
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 00000002C090: 7C94568B
	s_add_f32 s57, s58, s57                                    // 00000002C094: A039393A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002C098: BF8704A2
	v_cndmask_b32_e64 v3, v3, s58, vcc_lo                      // 00000002C09C: D5010003 01A87503
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 00000002C0A4: 7C94568C
	s_add_f32 s56, s57, s56                                    // 00000002C0A8: A0383839
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002C0AC: BF8704A2
	v_cndmask_b32_e64 v3, v3, s57, vcc_lo                      // 00000002C0B0: D5010003 01A87303
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 00000002C0B8: 7C94568D
	s_add_f32 s55, s56, s55                                    // 00000002C0BC: A0373738
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002C0C0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s56, vcc_lo                      // 00000002C0C4: D5010003 01A87103
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 00000002C0CC: 7C94568E
	s_add_f32 s54, s55, s54                                    // 00000002C0D0: A0363637
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002C0D4: BF870002
	v_cndmask_b32_e64 v3, v3, s55, vcc_lo                      // 00000002C0D8: D5010003 01A86F03
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 00000002C0E0: 7C94568F
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 00000002C0E4: BF870482
	v_cndmask_b32_e64 v3, v3, s54, vcc_lo                      // 00000002C0E8: D5010003 01A86D03
	ds_store_b32 v4, v3 offset:24128                           // 00000002C0F0: D8345E40 00000304
	s_or_b32 exec_lo, exec_lo, s4                              // 00000002C0F8: 8C7E047E
	s_add_i32 s53, s53, 1                                      // 00000002C0FC: 81358135
	s_waitcnt lgkmcnt(0)                                       // 00000002C100: BF89FC07
	s_barrier                                                  // 00000002C104: BFBD0000
	s_cmp_ge_i32 s53, s41                                      // 00000002C108: BF032935
	s_cbranch_scc1 71                                          // 00000002C10C: BFA20047 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x122c>
	s_lshl_b32 s4, s53, 4                                      // 00000002C110: 84048435
	v_lshlrev_b32_e32 v4, 4, v44                               // 00000002C114: 30085884
	s_waitcnt lgkmcnt(0)                                       // 00000002C118: BF89FC07
	v_add_nc_u32_e32 v6, s4, v2                                // 00000002C11C: 4A0C0404
	s_mov_b32 s54, exec_lo                                     // 00000002C120: BEB6007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002C124: BF870112
	v_and_b32_e32 v4, 0xf0, v4                                 // 00000002C128: 360808FF 000000F0
	v_min_i32_e32 v2, s40, v6                                  // 00000002C130: 22040C28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C134: BF870091
	v_mad_i64_i32 v[2:3], null, 0x5000, v2, s[30:31]           // 00000002C138: D6FF7C02 007A04FF 00005000
	.long 0xd7006a02                                           // 00000002C144: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000002C148: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002C14C: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000002C150: D5207C03 01AA0680
	.long 0xd7006a04                                           // 00000002C158: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000002C15C: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002C164: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 00000002C168: D5207C05 01AA0680
	s_clause 0x1                                               // 00000002C170: BF850001
	global_load_b128 v[74:77], v[2:3], off                     // 00000002C174: DC5E0000 4A7C0002
	global_load_b128 v[78:81], v[4:5], off                     // 00000002C17C: DC5E0000 4E7C0004
	.long 0xd4c3007e                                           // 00000002C184: D4C3007E
	v_cndmask_b32_e32 v1, s39, v6, vcc_lo                      // 00000002C188: 02020C27
	s_cbranch_execz 11                                         // 00000002C18C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11bc>
	s_waitcnt vmcnt(1)                                         // 00000002C190: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 00000002C194: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002C198: BF870001
	v_mov_b32_e32 v75, v76                                     // 00000002C19C: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 00000002C1A0: 7E94034C
	s_waitcnt vmcnt(0)                                         // 00000002C1A4: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 00000002C1A8: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 00000002C1AC: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 00000002C1B0: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 00000002C1B4: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 00000002C1B8: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s54                             // 00000002C1BC: 8C7E367E
	s_and_saveexec_b32 s54, s3                                 // 00000002C1C0: BEB62003
	s_cbranch_execz 23                                         // 00000002C1C4: BFA50017 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1224>
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, s4, v44      // 00000002C1C8: CA200080 03025804
	v_mov_b32_e32 v140, 0                                      // 00000002C1D0: 7F180280
	s_mov_b32 s3, exec_lo                                      // 00000002C1D4: BE83007E
	scratch_store_b32 off, v3, off                             // 00000002C1D8: DC690000 007C0300
	.long 0xd4c4007e                                           // 00000002C1E0: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000002C1E4: 02020427
	s_cbranch_execz 13                                         // 00000002C1E8: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1220>
	v_mad_i64_i32 v[3:4], null, 0xc0, v2, s[10:11]             // 00000002C1EC: D6FF7C03 002A04FF 000000C0
	v_mad_i64_i32 v[5:6], null, 0xc0, v2, s[34:35]             // 00000002C1F8: D6FF7C05 008A04FF 000000C0
	global_load_b32 v140, v[3:4], off                          // 00000002C204: DC520000 8C7C0003
	global_load_b32 v2, v[5:6], off                            // 00000002C20C: DC520000 027C0005
	s_waitcnt vmcnt(0)                                         // 00000002C214: BF8903F7
	scratch_store_b32 off, v2, off                             // 00000002C218: DC690000 007C0200
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002C220: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002C224: BF870009
	s_or_b32 exec_lo, exec_lo, s54                             // 00000002C228: 8C7E367E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002C22C: BF870009
	s_and_b32 vcc_lo, exec_lo, s42                             // 00000002C230: 8B6A2A7E
	s_mov_b32 s3, -1                                           // 00000002C234: BE8300C1
	s_cbranch_vccz 81                                          // 00000002C238: BFA30051 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1380>
	v_and_b32_e32 v2, -16, v44                                 // 00000002C23C: 360458D0
	s_mov_b32 s3, exec_lo                                      // 00000002C240: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002C244: BF870001
	v_cmpx_eq_u32_e32 64, v2                                   // 00000002C248: 7D9404C0
	s_cbranch_execz 74                                         // 00000002C24C: BFA5004A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1378>
	v_lshlrev_b32_e32 v4, 2, v44                               // 00000002C250: 30085882
	s_waitcnt lgkmcnt(1)                                       // 00000002C254: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002C258: BF870001
	v_add_nc_u32_e32 v5, 0x5c00, v4                            // 00000002C25C: 4A0A08FF 00005C00
	ds_load_2addr_b32 v[2:3], v5 offset0:64 offset1:80         // 00000002C264: D8DC5040 02000005
	s_waitcnt lgkmcnt(1)                                       // 00000002C26C: BF89FC17
	ds_load_b32 v6, v1 offset:24188                            // 00000002C270: D8D85E7C 06000001
	s_waitcnt lgkmcnt(1)                                       // 00000002C278: BF89FC17
	v_mul_f32_e32 v7, 0x3fb8aa3b, v3                           // 00000002C27C: 100E06FF 3FB8AA3B
	ds_load_b32 v8, v4 offset:24128                            // 00000002C284: D8D85E40 08000004
	s_waitcnt lgkmcnt(1)                                       // 00000002C28C: BF89FC17
	v_sub_f32_e32 v6, v6, v3                                   // 00000002C290: 080C0706
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000002C294: 7C3606FF C2CE8ED0
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v7                          // 00000002C29C: D6130009 841E06FF 3FB8AA3B
	v_rndne_f32_e32 v10, v7                                    // 00000002C2A8: 7E144707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002C2AC: BF870114
	v_mul_f32_e32 v11, 0x3fb8aa3b, v6                          // 00000002C2B0: 10160CFF 3FB8AA3B
	v_sub_f32_e32 v7, v7, v10                                  // 00000002C2B8: 080E1507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000002C2BC: BF8701C2
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v11                        // 00000002C2C0: D613000C 842E0CFF 3FB8AA3B
	v_fmac_f32_e32 v9, 0x32a5705f, v3                          // 00000002C2CC: 561206FF 32A5705F
	v_cvt_i32_f32_e32 v10, v10                                 // 00000002C2D4: 7E14110A
	v_rndne_f32_e32 v13, v11                                   // 00000002C2D8: 7E1A470B
	v_dual_fmac_f32 v12, 0x32a5705f, v6 :: v_dual_add_f32 v7, v7, v9// 00000002C2DC: C8080CFF 0C061307 32A5705F
	s_waitcnt lgkmcnt(0)                                       // 00000002C2E8: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002C2EC: BF870112
	v_dual_sub_f32 v9, v11, v13 :: v_dual_mul_f32 v2, v8, v2   // 00000002C2F0: C9461B0B 09020508
	v_exp_f32_e32 v7, v7                                       // 00000002C2F8: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002C2FC: BF870125
	.long 0xd71c0007                                           // 00000002C300: D71C0007
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 00000002C304: 02021507
	v_cvt_i32_f32_e32 v10, v13                                 // 00000002C308: 7E14110D
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 00000002C30C: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000002C310: 7C3C06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002C318: BF8701B2
	v_cndmask_b32_e32 v3, 0x7f800000, v7, vcc_lo               // 00000002C31C: 02060EFF 7F800000
	v_add_f32_e32 v9, v9, v12                                  // 00000002C324: 06121909
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 00000002C328: 7C360CFF C2CE8ED0
	v_mul_f32_e32 v2, v3, v2                                   // 00000002C330: 10040503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C334: BF870093
	v_exp_f32_e32 v9, v9                                       // 00000002C338: 7E124B09
	v_mul_f32_e32 v2, 0x41800000, v2                           // 00000002C33C: 100404FF 41800000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C344: BF870095
	.long 0xd71c0009                                           // 00000002C348: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000002C34C: 02021509
	v_cndmask_b32_e32 v7, 0, v9, vcc_lo                        // 00000002C350: 020E1280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 00000002C354: 7C3C0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002C35C: BF870002
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 00000002C360: 020C0EFF 7F800000
	ds_store_b32 v4, v3 offset:24064                           // 00000002C368: D8345E00 00000304
	ds_store_2addr_b32 v5, v6, v2 offset0:96 offset1:112       // 00000002C370: D8387060 00020605
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002C378: 8C7E037E
	s_mov_b32 s3, 0                                            // 00000002C37C: BE830080
	v_lshrrev_b32_e32 v154, 4, v43                             // 00000002C380: 33345684
	v_mul_u32_u24_e32 v57, 0x110, v55                          // 00000002C384: 16726EFF 00000110
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 00000002C38C: 916A037E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002C390: BF870002
	v_lshlrev_b32_e32 v56, 2, v154                             // 00000002C394: 30713482
	s_cbranch_vccnz 872                                        // 00000002C398: BFA40368 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x213c>
	v_mad_u32_u24 v2, 0x110, v55, s49                          // 00000002C39C: D60B0002 00C66EFF 00000110
	s_and_b32 s3, s2, exec_lo                                  // 00000002C3A8: 8B037E02
	s_cselect_b32 s3, 0, 0x1100                                // 00000002C3AC: 9803FF80 00001100
	v_mad_u32_u24 v3, 0x110, v55, s50                          // 00000002C3B4: D60B0003 00CA6EFF 00000110
	ds_load_b128 v[10:13], v57 offset:6144                     // 00000002C3C0: DBFC1800 0A000039
	ds_load_b128 v[14:17], v57 offset:6160                     // 00000002C3C8: DBFC1810 0E000039
	v_add_nc_u32_e32 v4, s3, v2                                // 00000002C3D0: 4A080403
	v_mov_b32_e32 v8, v1                                       // 00000002C3D4: 7E100301
	s_waitcnt lgkmcnt(3)                                       // 00000002C3D8: BF89FC37
	v_mov_b32_e32 v5, v1                                       // 00000002C3DC: 7E0A0301
	v_cndmask_b32_e64 v45, v3, v2, s2                          // 00000002C3E0: D501002D 000A0503
	v_mov_b32_e32 v3, v1                                       // 00000002C3E8: 7E060301
	ds_load_b128 v[18:21], v4                                  // 00000002C3EC: DBFC0000 12000004
	ds_load_b128 v[22:25], v4 offset:16                        // 00000002C3F4: DBFC0010 16000004
	ds_load_b128 v[26:29], v57 offset:6176                     // 00000002C3FC: DBFC1820 1A000039
	ds_load_b128 v[30:33], v57 offset:6192                     // 00000002C404: DBFC1830 1E000039
	ds_load_b128 v[59:62], v45 offset:32                       // 00000002C40C: DBFC0020 3B00002D
	ds_load_b128 v[63:66], v45 offset:48                       // 00000002C414: DBFC0030 3F00002D
	ds_load_b128 v[155:158], v45 offset:64                     // 00000002C41C: DBFC0040 9B00002D
	ds_load_b128 v[159:162], v45 offset:80                     // 00000002C424: DBFC0050 9F00002D
	ds_load_b128 v[167:170], v57 offset:6224                   // 00000002C42C: DBFC1850 A7000039
	ds_load_b128 v[163:166], v57 offset:6208                   // 00000002C434: DBFC1840 A3000039
	v_mov_b32_e32 v2, v1                                       // 00000002C43C: 7E040301
	v_mov_b32_e32 v4, v1                                       // 00000002C440: 7E080301
	s_waitcnt lgkmcnt(12)                                      // 00000002C444: BF89FCC7
	v_mov_b32_e32 v6, v1                                       // 00000002C448: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000002C44C: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 00000002C450: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002C454: BF870212
	v_mov_b32_e32 v8, v7                                       // 00000002C458: 7E100307
	v_mov_b32_e32 v7, v6                                       // 00000002C45C: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 00000002C460: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 00000002C464: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 00000002C468: 7E080303
	v_mov_b32_e32 v3, v2                                       // 00000002C46C: 7E060302
	v_mov_b32_e32 v2, v1                                       // 00000002C470: 7E040301
	ds_load_b128 v[175:178], v57 offset:6256                   // 00000002C474: DBFC1870 AF000039
	ds_load_b128 v[171:174], v57 offset:6240                   // 00000002C47C: DBFC1860 AB000039
	ds_load_b128 v[183:186], v45 offset:112                    // 00000002C484: DBFC0070 B700002D
	ds_load_b128 v[179:182], v45 offset:96                     // 00000002C48C: DBFC0060 B300002D
	v_or_b32_e32 v49, 6, v154                                  // 00000002C494: 38633486
	v_or_b32_e32 v48, 8, v154                                  // 00000002C498: 38613488
	v_or_b32_e32 v47, 10, v154                                 // 00000002C49C: 385F348A
	s_waitcnt lgkmcnt(12)                                      // 00000002C4A0: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 00000002C4A4: CC414002 1C0A1512
	ds_load_b128 v[14:17], v57 offset:6288                     // 00000002C4AC: DBFC1890 0E000039
	ds_load_b128 v[10:13], v57 offset:6272                     // 00000002C4B4: DBFC1880 0A000039
	ds_load_b128 v[22:25], v45 offset:144                      // 00000002C4BC: DBFC0090 1600002D
	ds_load_b128 v[18:21], v45 offset:128                      // 00000002C4C4: DBFC0080 1200002D
	s_and_not1_b32 vcc_lo, exec_lo, s15                        // 00000002C4CC: 916A0F7E
	s_mov_b32 s3, -1                                           // 00000002C4D0: BE8300C1
	s_waitcnt lgkmcnt(12)                                      // 00000002C4D4: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[59:66], v[26:33], v[2:9]// 00000002C4D8: CC414002 1C0A353B
	ds_load_b128 v[30:33], v57 offset:6320                     // 00000002C4E0: DBFC18B0 1E000039
	ds_load_b128 v[26:29], v57 offset:6304                     // 00000002C4E8: DBFC18A0 1A000039
	ds_load_b128 v[65:68], v45 offset:176                      // 00000002C4F0: DBFC00B0 4100002D
	ds_load_b128 v[61:64], v45 offset:160                      // 00000002C4F8: DBFC00A0 3D00002D
	v_lshlrev_b32_e32 v60, 2, v55                              // 00000002C500: 30786E82
	v_or_b32_e32 v59, 4, v154                                  // 00000002C504: 38773484
	s_waitcnt lgkmcnt(12)                                      // 00000002C508: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[155:162], v[163:170], v[2:9]// 00000002C50C: CC414002 1C0B479B
	ds_load_b128 v[159:162], v57 offset:6352                   // 00000002C514: DBFC18D0 9F000039
	ds_load_b128 v[155:158], v57 offset:6336                   // 00000002C51C: DBFC18C0 9B000039
	v_add_nc_u32_e32 v46, 64, v60                              // 00000002C524: 4A5C78C0
	ds_load_b128 v[167:170], v57 offset:6384                   // 00000002C528: DBFC18F0 A7000039
	ds_load_b128 v[163:166], v57 offset:6368                   // 00000002C530: DBFC18E0 A3000039
	s_waitcnt lgkmcnt(12)                                      // 00000002C538: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[179:186], v[171:178], v[2:9]// 00000002C53C: CC414002 1C0B57B3
	ds_load_b128 v[175:178], v45 offset:208                    // 00000002C544: DBFC00D0 AF00002D
	ds_load_b128 v[171:174], v45 offset:192                    // 00000002C54C: DBFC00C0 AB00002D
	s_waitcnt lgkmcnt(10)                                      // 00000002C554: BF89FCA7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 00000002C558: CC414002 1C0A1512
	v_add_nc_u32_e32 v10, 0x5c00, v56                          // 00000002C560: 4A1470FF 00005C00
	v_add_nc_u32_e32 v11, s43, v56                             // 00000002C568: 4A16702B
	ds_load_b128 v[183:186], v45 offset:240                    // 00000002C56C: DBFC00F0 B700002D
	ds_load_b128 v[179:182], v45 offset:224                    // 00000002C574: DBFC00E0 B300002D
	ds_load_2addr_stride64_b32 v[12:13], v46 offset0:94 offset1:95// 00000002C57C: D8E05F5E 0C00002E
	v_or_b32_e32 v46, 12, v154                                 // 00000002C584: 385D348C
	s_waitcnt lgkmcnt(9)                                       // 00000002C588: BF89FC97
	v_wmma_f32_16x16x16_bf16 v[2:9], v[61:68], v[26:33], v[2:9]// 00000002C58C: CC414002 1C0A353D
	ds_load_2addr_b32 v[28:29], v10 offset0:144 offset1:146    // 00000002C594: D8DC9290 1C00000A
	ds_load_2addr_b32 v[24:25], v10 offset0:148 offset1:150    // 00000002C59C: D8DC9694 1800000A
	ds_load_2addr_b32 v[20:21], v10 offset0:152 offset1:154    // 00000002C5A4: D8DC9A98 1400000A
	ds_load_2addr_b32 v[16:17], v10 offset0:156 offset1:158    // 00000002C5AC: D8DC9E9C 1000000A
	ds_load_2addr_b32 v[26:27], v11 offset1:2                  // 00000002C5B4: D8DC0200 1A00000B
	ds_load_2addr_b32 v[22:23], v11 offset0:4 offset1:6        // 00000002C5BC: D8DC0604 1600000B
	ds_load_2addr_b32 v[18:19], v11 offset0:8 offset1:10       // 00000002C5C4: D8DC0A08 1200000B
	ds_load_2addr_b32 v[14:15], v11 offset0:12 offset1:14      // 00000002C5CC: D8DC0E0C 0E00000B
	v_or_b32_e32 v61, 2, v154                                  // 00000002C5D4: 387B3482
	v_or_b32_e32 v45, 14, v154                                 // 00000002C5D8: 385B348E
	s_waitcnt lgkmcnt(11)                                      // 00000002C5DC: BF89FCB7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[171:178], v[155:162], v[2:9]// 00000002C5E0: CC414002 1C0B37AB
	s_waitcnt lgkmcnt(9)                                       // 00000002C5E8: BF89FC97
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002C5EC: BF870001
	v_wmma_f32_16x16x16_bf16 v[2:9], v[179:186], v[163:170], v[2:9]// 00000002C5F0: CC414002 1C0B47B3
	s_cbranch_vccnz 353                                        // 00000002C5F8: BFA40161 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b80>
	.long 0x7e143880                                           // 00000002C5FC: 7E143880
	s_mov_b32 s3, exec_lo                                      // 00000002C600: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002C604: BF870001
	.long 0x7f14390a                                           // 00000002C608: 7F14390A
	.long 0xd4cb007e                                           // 00000002C60C: D4CB007E
	v_cndmask_b32_e32 v1, v55, v154, vcc_lo                    // 00000002C610: 02033537
	s_cbranch_execz 34                                         // 00000002C614: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x16a0>
	s_waitcnt lgkmcnt(7)                                       // 00000002C618: BF89FC77
	v_sub_f32_e32 v11, v28, v12                                // 00000002C61C: 0816191C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C620: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v11                         // 00000002C624: 103C16FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v11, -v30                       // 00000002C62C: D613001F 847A16FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 00000002C638: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C63C: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v11 :: v_dual_sub_f32 v30, v30, v32// 00000002C640: C80A16FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 00000002C64C: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 00000002C650: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000002C654: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002C65C: BF870293
	v_exp_f32_e32 v30, v30                                     // 00000002C660: 7E3C4B1E
	.long 0xd71c001e                                           // 00000002C664: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 00000002C668: 02023F1E
	s_waitcnt lgkmcnt(3)                                       // 00000002C66C: BF89FC37
	v_mul_f32_e32 v31, v2, v26                                 // 00000002C670: 103E3502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002C674: BF870122
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 00000002C678: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000002C67C: 7C3C16FF 42B17218
	v_dual_cndmask_b32 v11, 0x7f800000, v30 :: v_dual_mul_f32 v30, v13, v31// 00000002C684: CA463CFF 0B1E3F0D 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C690: BF870091
	v_mul_f32_e32 v11, v11, v30                                // 00000002C694: 10163D0B
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 00000002C698: CC22000A 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002C6A0: 8C7E037E
	v_mul_u32_u24_e32 v11, 48, v154                            // 00000002C6A4: 161734B0
	s_mov_b32 s3, exec_lo                                      // 00000002C6A8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002C6AC: BF870001
	v_lshl_add_u32 v11, v55, 1, v11                            // 00000002C6B0: D646000B 042D0337
	ds_store_b16_d16_hi v11, v10 offset:23296                  // 00000002C6B8: DA845B00 00000A0B
	.long 0xd4cb007e                                           // 00000002C6C0: D4CB007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 00000002C6C4: 02027B37
	s_cbranch_execz 34                                         // 00000002C6C8: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1754>
	s_waitcnt lgkmcnt(8)                                       // 00000002C6CC: BF89FC87
	v_sub_f32_e32 v10, v29, v12                                // 00000002C6D0: 0814191D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C6D4: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v10                         // 00000002C6D8: 103C14FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v30                       // 00000002C6E0: D613001F 847A14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 00000002C6EC: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C6F0: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v10 :: v_dual_sub_f32 v30, v30, v32// 00000002C6F4: C80A14FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 00000002C700: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 00000002C704: 7E3E1120
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002C708: BF870292
	v_exp_f32_e32 v30, v30                                     // 00000002C70C: 7E3C4B1E
	.long 0xd71c001e                                           // 00000002C710: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 00000002C714: 02023F1E
	s_waitcnt lgkmcnt(4)                                       // 00000002C718: BF89FC47
	v_mul_f32_e32 v31, v3, v27                                 // 00000002C71C: 103E3703
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000002C720: 7C3614FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002C728: BF870123
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 00000002C72C: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000002C730: 7C3C14FF 42B17218
	v_cndmask_b32_e32 v10, 0x7f800000, v30, vcc_lo             // 00000002C738: 02143CFF 7F800000
	v_mul_f32_e32 v30, v13, v31                                // 00000002C740: 103C3F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C744: BF870091
	v_mul_f32_e32 v10, v10, v30                                // 00000002C748: 10143D0A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 00000002C74C: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002C754: 8C7E037E
	.long 0x7f143880                                           // 00000002C758: 7F143880
	v_or_b32_e32 v30, 0x5b00, v11                              // 00000002C75C: 383C16FF 00005B00
	s_mov_b32 s3, exec_lo                                      // 00000002C764: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002C768: BF870002
	.long 0x7e16398a                                           // 00000002C76C: 7E16398A
	ds_store_b16 v30, v10 offset:96                            // 00000002C770: D87C0060 00000A1E
	.long 0xd4cb007e                                           // 00000002C778: D4CB007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 00000002C77C: 02027737
	s_cbranch_execz 35                                         // 00000002C780: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1810>
	s_waitcnt lgkmcnt(8)                                       // 00000002C784: BF89FC87
	v_sub_f32_e32 v11, v24, v12                                // 00000002C788: 08161918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002C78C: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000002C790: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000002C798: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000002C7A0: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000002C7AC: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C7B0: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000002C7B4: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000002C7C0: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000002C7C4: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002C7C8: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000002C7CC: 7E3E4B1F
	.long 0xd71c001f                                           // 00000002C7D0: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000002C7D4: 0202411F
	s_waitcnt lgkmcnt(4)                                       // 00000002C7D8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002C7DC: BF870121
	v_dual_mul_f32 v32, v4, v22 :: v_dual_cndmask_b32 v31, 0, v31// 00000002C7E0: C8D22D04 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000002C7E8: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000002C7F0: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C7F8: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 00000002C7FC: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 00000002C800: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002C804: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000002C808: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002C810: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002C814: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000002C818: BE83007E
	ds_store_b16 v30, v11 offset:192                           // 00000002C81C: D87C00C0 00000B1E
	.long 0xd4cb007e                                           // 00000002C824: D4CB007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 00000002C828: 02026337
	s_cbranch_execz 35                                         // 00000002C82C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x18bc>
	s_waitcnt lgkmcnt(9)                                       // 00000002C830: BF89FC97
	v_sub_f32_e32 v10, v25, v12                                // 00000002C834: 08141919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C838: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000002C83C: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000002C844: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000002C850: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002C854: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000002C858: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000002C860: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002C864: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000002C868: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000002C86C: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000002C870: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000002C878: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000002C87C: BF870135
	.long 0xd71c000b                                           // 00000002C880: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000002C884: 02023F0B
	s_waitcnt lgkmcnt(5)                                       // 00000002C888: BF89FC57
	v_mul_f32_e32 v31, v5, v23                                 // 00000002C88C: 103E2F05
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000002C890: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000002C894: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002C89C: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000002C8A0: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000002C8A8: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C8AC: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000002C8B0: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 00000002C8B4: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002C8BC: 8C7E037E
	.long 0x7e143880                                           // 00000002C8C0: 7E143880
	s_mov_b32 s3, exec_lo                                      // 00000002C8C4: BE83007E
	ds_store_b16_d16_hi v30, v10 offset:288                    // 00000002C8C8: DA840120 00000A1E
	.long 0x7e16390a                                           // 00000002C8D0: 7E16390A
	.long 0xd4cb007e                                           // 00000002C8D4: D4CB007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 00000002C8D8: 02026137
	s_cbranch_execz 34                                         // 00000002C8DC: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1968>
	s_waitcnt lgkmcnt(9)                                       // 00000002C8E0: BF89FC97
	v_sub_f32_e32 v11, v20, v12                                // 00000002C8E4: 08161914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C8E8: BF870091
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000002C8EC: 103E16FF 3FB8AA3B
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000002C8F4: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000002C900: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C904: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000002C908: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000002C914: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000002C918: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002C91C: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000002C920: 7E3E4B1F
	.long 0xd71c001f                                           // 00000002C924: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000002C928: 0202411F
	s_waitcnt lgkmcnt(5)                                       // 00000002C92C: BF89FC57
	v_mul_f32_e32 v32, v6, v18                                 // 00000002C930: 10402506
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000002C934: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002C93C: BF870123
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 00000002C940: 023E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000002C944: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000002C94C: 02163EFF 7F800000
	v_mul_f32_e32 v31, v13, v32                                // 00000002C954: 103E410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C958: BF870091
	v_mul_f32_e32 v11, v11, v31                                // 00000002C95C: 10163F0B
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000002C960: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002C968: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002C96C: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000002C970: BE83007E
	ds_store_b16 v30, v11 offset:384                           // 00000002C974: D87C0180 00000B1E
	.long 0xd4cb007e                                           // 00000002C97C: D4CB007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 00000002C980: 02025F37
	s_cbranch_execz 35                                         // 00000002C984: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1a14>
	s_waitcnt lgkmcnt(10)                                      // 00000002C988: BF89FCA7
	v_sub_f32_e32 v10, v21, v12                                // 00000002C98C: 08141915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002C990: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000002C994: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000002C99C: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000002C9A8: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002C9AC: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000002C9B0: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000002C9B8: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002C9BC: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000002C9C0: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000002C9C4: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000002C9C8: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000002C9D0: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000002C9D4: BF870135
	.long 0xd71c000b                                           // 00000002C9D8: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000002C9DC: 02023F0B
	s_waitcnt lgkmcnt(6)                                       // 00000002C9E0: BF89FC67
	v_mul_f32_e32 v31, v7, v19                                 // 00000002C9E4: 103E2707
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000002C9E8: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000002C9EC: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002C9F4: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000002C9F8: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000002CA00: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002CA04: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000002CA08: 1014170A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 00000002CA0C: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002CA14: 8C7E037E
	.long 0x7f143880                                           // 00000002CA18: 7F143880
	s_mov_b32 s3, exec_lo                                      // 00000002CA1C: BE83007E
	ds_store_b16 v30, v10 offset:480                           // 00000002CA20: D87C01E0 00000A1E
	.long 0x7e16398a                                           // 00000002CA28: 7E16398A
	.long 0xd4cb007e                                           // 00000002CA2C: D4CB007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 00000002CA30: 02025D37
	s_cbranch_execz 35                                         // 00000002CA34: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1ac4>
	s_waitcnt lgkmcnt(10)                                      // 00000002CA38: BF89FCA7
	v_sub_f32_e32 v11, v16, v12                                // 00000002CA3C: 08161910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002CA40: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000002CA44: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000002CA4C: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000002CA54: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000002CA60: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002CA64: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000002CA68: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000002CA74: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000002CA78: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002CA7C: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000002CA80: 7E3E4B1F
	.long 0xd71c001f                                           // 00000002CA84: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000002CA88: 0202411F
	s_waitcnt lgkmcnt(6)                                       // 00000002CA8C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002CA90: BF870121
	v_dual_mul_f32 v32, v8, v14 :: v_dual_cndmask_b32 v31, 0, v31// 00000002CA94: C8D21D08 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000002CA9C: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000002CAA4: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002CAAC: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 00000002CAB0: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 00000002CAB4: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002CAB8: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000002CABC: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002CAC4: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002CAC8: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000002CACC: BE83007E
	ds_store_b16 v30, v11 offset:576                           // 00000002CAD0: D87C0240 00000B1E
	.long 0xd4cb007e                                           // 00000002CAD8: D4CB007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 00000002CADC: 02025B37
	s_cbranch_execz 35                                         // 00000002CAE0: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b70>
	s_waitcnt lgkmcnt(11)                                      // 00000002CAE4: BF89FCB7
	v_sub_f32_e32 v10, v17, v12                                // 00000002CAE8: 08141911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002CAEC: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000002CAF0: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000002CAF8: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000002CB04: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002CB08: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000002CB0C: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000002CB14: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002CB18: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000002CB1C: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000002CB20: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000002CB24: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000002CB2C: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000002CB30: BF870135
	.long 0xd71c000b                                           // 00000002CB34: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000002CB38: 02023F0B
	s_waitcnt lgkmcnt(7)                                       // 00000002CB3C: BF89FC77
	v_mul_f32_e32 v31, v9, v15                                 // 00000002CB40: 103E1F09
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000002CB44: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000002CB48: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002CB50: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000002CB54: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000002CB5C: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002CB60: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000002CB64: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 00000002CB68: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002CB70: 8C7E037E
	s_mov_b32 s3, 0                                            // 00000002CB74: BE830080
	ds_store_b16_d16_hi v30, v10 offset:672                    // 00000002CB78: DA8402A0 00000A1E
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000002CB80: 8B6A037E
	s_cbranch_vccz 365                                         // 00000002CB84: BFA3016D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x213c>
	v_or_b32_e32 v10, 0x5e40, v56                              // 00000002CB88: 381470FF 00005E40
	v_mov_b32_e32 v63, 0                                       // 00000002CB90: 7E7E0280
	v_mov_b32_e32 v65, 0                                       // 00000002CB94: 7E820280
	s_mov_b32 s3, exec_lo                                      // 00000002CB98: BE83007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002CB9C: BF870003
	v_subrev_nc_u32_e32 v64, 64, v10                           // 00000002CBA0: 4E8014C0
	ds_load_2addr_b32 v[32:33], v64 offset0:2 offset1:4        // 00000002CBA4: D8DC0402 20000040
	ds_load_2addr_b32 v[30:31], v64 offset0:6 offset1:8        // 00000002CBAC: D8DC0806 1E000040
	ds_load_2addr_b32 v[10:11], v64 offset0:10 offset1:12      // 00000002CBB4: D8DC0C0A 0A000040
	ds_load_b32 v62, v64 offset:56                             // 00000002CBBC: D8D80038 3E000040
	.long 0xd4c9007e                                           // 00000002CBC4: D4C9007E
	v_cndmask_b32_e32 v1, v55, v154, vcc_lo                    // 00000002CBC8: 02033537
	s_cbranch_execz 37                                         // 00000002CBCC: BFA50025 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1c64>
	s_waitcnt lgkmcnt(11)                                      // 00000002CBD0: BF89FCB7
	v_sub_f32_e32 v28, v28, v12                                // 00000002CBD4: 0838191C
	ds_load_b32 v64, v64                                       // 00000002CBD8: D8D80000 40000040
	s_waitcnt lgkmcnt(8)                                       // 00000002CBE0: BF89FC87
	v_dual_mul_f32 v2, v2, v26 :: v_dual_mul_f32 v65, 0x3fb8aa3b, v28// 00000002CBE4: C8C63502 024038FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002CBF0: BF870111
	v_mul_f32_e32 v2, v13, v2                                  // 00000002CBF4: 1004050D
	v_fma_f32 v66, 0x3fb8aa3b, v28, -v65                       // 00000002CBF8: D6130042 850638FF 3FB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000002CC04: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000002CC08: BF8701C1
	v_dual_sub_f32 v65, v65, v67 :: v_dual_fmac_f32 v66, 0x32a5705f, v28// 00000002CC0C: C9408741 414238FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v28                  // 00000002CC18: 7C3638FF C2CE8ED0
	s_waitcnt lgkmcnt(0)                                       // 00000002CC20: BF89FC07
	v_mul_f32_e32 v2, v64, v2                                  // 00000002CC24: 10040540
	v_add_f32_e32 v65, v65, v66                                // 00000002CC28: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000002CC2C: 7E841143
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002CC30: BF870292
	v_exp_f32_e32 v65, v65                                     // 00000002CC34: 7E824B41
	.long 0xd71c0041                                           // 00000002CC38: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000002CC3C: 02028541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002CC40: BF870121
	v_cndmask_b32_e32 v26, 0, v65, vcc_lo                      // 00000002CC44: 02348280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v28                  // 00000002CC48: 7C3C38FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 00000002CC50: 023434FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002CC58: BF870001
	.long 0xd5080041                                           // 00000002CC5C: D5080041
	v_sub_co_ci_u32_e32 v1, vcc_lo, v2, v26, vcc_lo            // 00000002CC60: 42023502
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002CC64: 8C7E037E
	v_or_b32_e32 v2, 0x5e40, v60                               // 00000002CC68: 380478FF 00005E40
	s_waitcnt lgkmcnt(7)                                       // 00000002CC70: BF89FC77
	v_lshlrev_b32_e32 v26, 6, v154                             // 00000002CC74: 30353486
	s_mov_b32 s3, exec_lo                                      // 00000002CC78: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002CC7C: BF870001
	v_add3_u32 v2, v2, v26, 0xfffff8c0                         // 00000002CC80: D6550002 03FE3502 FFFFF8C0
	ds_store_b32 v2, v65                                       // 00000002CC8C: D8340000 00004102
	.long 0xd4c9007e                                           // 00000002CC94: D4C9007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 00000002CC98: 02027B37
	s_cbranch_execz 33                                         // 00000002CC9C: BFA50021 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1d24>
	v_dual_sub_f32 v26, v29, v12 :: v_dual_mul_f32 v3, v3, v27 // 00000002CCA0: C946191D 1A023703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002CCA8: BF870121
	v_dual_mul_f32 v28, 0x3fb8aa3b, v26 :: v_dual_mul_f32 v3, v13, v3// 00000002CCAC: C8C634FF 1C02070D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v26                  // 00000002CCB8: 7C3634FF C2CE8ED0
	v_fma_f32 v29, 0x3fb8aa3b, v26, -v28                       // 00000002CCC0: D613001D 847234FF 3FB8AA3B
	v_rndne_f32_e32 v60, v28                                   // 00000002CCCC: 7E78471C
	s_waitcnt lgkmcnt(4)                                       // 00000002CCD0: BF89FC47
	v_mul_f32_e32 v3, v32, v3                                  // 00000002CCD4: 10060720
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002CCD8: BF870092
	v_dual_fmac_f32 v29, 0x32a5705f, v26 :: v_dual_sub_f32 v28, v28, v60// 00000002CCDC: C80A34FF 1D1C791C 32A5705F
	v_add_f32_e32 v28, v28, v29                                // 00000002CCE8: 06383B1C
	v_cvt_i32_f32_e32 v29, v60                                 // 00000002CCEC: 7E3A113C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002CCF0: BF870292
	v_exp_f32_e32 v28, v28                                     // 00000002CCF4: 7E384B1C
	.long 0xd71c001c                                           // 00000002CCF8: D71C001C
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                     // 00000002CCFC: 02023B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002CD00: BF870121
	v_cndmask_b32_e32 v27, 0, v28, vcc_lo                      // 00000002CD04: 02363880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v26                  // 00000002CD08: 7C3C34FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v27, vcc_lo             // 00000002CD10: 023436FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002CD18: BF870001
	.long 0xd508003f                                           // 00000002CD1C: D508003F
	v_sub_co_ci_u32_e32 v1, vcc_lo, v3, v26, vcc_lo            // 00000002CD20: 42023503
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002CD24: 8C7E037E
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v26, 0              // 00000002CD28: CA100080 031A0080
	s_mov_b32 s3, exec_lo                                      // 00000002CD30: BE83007E
	ds_store_b32 v2, v63 offset:128                            // 00000002CD34: D8340080 00003F02
	.long 0xd4c9007e                                           // 00000002CD3C: D4C9007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 00000002CD40: 02027737
	s_cbranch_execz 35                                         // 00000002CD44: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1dd4>
	v_sub_f32_e32 v24, v24, v12                                // 00000002CD48: 08301918
	s_waitcnt lgkmcnt(8)                                       // 00000002CD4C: BF89FC87
	v_mul_f32_e32 v4, v4, v22                                  // 00000002CD50: 10082D04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002CD54: BF8701A2
	v_mul_f32_e32 v26, 0x3fb8aa3b, v24                         // 00000002CD58: 103430FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v24                  // 00000002CD60: 7C3630FF C2CE8ED0
	v_mul_f32_e32 v4, v13, v4                                  // 00000002CD68: 1008090D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002CD6C: BF8701B3
	v_fma_f32 v27, 0x3fb8aa3b, v24, -v26                       // 00000002CD70: D613001B 846A30FF 3FB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000002CD7C: 7E38471A
	s_waitcnt lgkmcnt(5)                                       // 00000002CD80: BF89FC57
	v_mul_f32_e32 v4, v33, v4                                  // 00000002CD84: 10080921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002CD88: BF870193
	v_fmac_f32_e32 v27, 0x32a5705f, v24                        // 00000002CD8C: 563630FF 32A5705F
	v_sub_f32_e32 v26, v26, v28                                // 00000002CD94: 0834391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002CD98: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000002CD9C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000002CDA0: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000002CDA4: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002CDA8: BF870095
	.long 0xd71c001a                                           // 00000002CDAC: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000002CDB0: 0202371A
	v_cndmask_b32_e32 v22, 0, v26, vcc_lo                      // 00000002CDB4: 022C3480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v24                  // 00000002CDB8: 7C3C30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002CDC0: BF870092
	v_cndmask_b32_e32 v22, 0x7f800000, v22, vcc_lo             // 00000002CDC4: 022C2CFF 7F800000
	.long 0xd508001a                                           // 00000002CDCC: D508001A
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v22, vcc_lo            // 00000002CDD0: 42022D04
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002CDD4: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002CDD8: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000002CDDC: BE83007E
	ds_store_b32 v2, v26 offset:256                            // 00000002CDE0: D8340100 00001A02
	.long 0xd4c9007e                                           // 00000002CDE8: D4C9007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 00000002CDEC: 02026337
	s_cbranch_execz 34                                         // 00000002CDF0: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1e7c>
	v_sub_f32_e32 v3, v25, v12                                 // 00000002CDF4: 08061919
	s_waitcnt lgkmcnt(9)                                       // 00000002CDF8: BF89FC97
	v_mul_f32_e32 v5, v5, v23                                  // 00000002CDFC: 100A2F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002CE00: BF870091
	v_dual_mul_f32 v4, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, v13, v5// 00000002CE04: C8C606FF 04040B0D 3FB8AA3B
	v_fma_f32 v22, 0x3fb8aa3b, v3, -v4                         // 00000002CE10: D6130016 841206FF 3FB8AA3B
	v_rndne_f32_e32 v24, v4                                    // 00000002CE1C: 7E304704
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002CE20: BF870112
	v_fmac_f32_e32 v22, 0x32a5705f, v3                         // 00000002CE24: 562C06FF 32A5705F
	v_sub_f32_e32 v4, v4, v24                                  // 00000002CE2C: 08083104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002CE30: BF8701B1
	v_add_f32_e32 v4, v4, v22                                  // 00000002CE34: 06082D04
	v_cvt_i32_f32_e32 v22, v24                                 // 00000002CE38: 7E2C1118
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000002CE3C: 7C3606FF C2CE8ED0
	v_exp_f32_e32 v4, v4                                       // 00000002CE44: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002CE48: BF870095
	.long 0xd71c0004                                           // 00000002CE4C: D71C0004
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 00000002CE50: 02022D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 00000002CE54: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000002CE58: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(5)                                       // 00000002CE60: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002CE64: BF870092
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v30, v5// 00000002CE68: CA4608FF 03040B1E 7F800000
	.long 0xd5080003                                           // 00000002CE74: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000002CE78: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002CE7C: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000002CE80: CA100080 04040080
	s_mov_b32 s3, exec_lo                                      // 00000002CE88: BE83007E
	ds_store_b32 v2, v3 offset:384                             // 00000002CE8C: D8340180 00000302
	.long 0xd4c9007e                                           // 00000002CE94: D4C9007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 00000002CE98: 02026137
	s_cbranch_execz 34                                         // 00000002CE9C: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1f28>
	s_waitcnt lgkmcnt(9)                                       // 00000002CEA0: BF89FC97
	v_dual_sub_f32 v3, v20, v12 :: v_dual_mul_f32 v6, v6, v18  // 00000002CEA4: C9461914 03062506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002CEAC: BF870121
	v_dual_mul_f32 v5, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v6, v13, v6// 00000002CEB0: C8C606FF 05060D0D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000002CEBC: 7C3606FF C2CE8ED0
	v_fma_f32 v20, 0x3fb8aa3b, v3, -v5                         // 00000002CEC4: D6130014 841606FF 3FB8AA3B
	v_rndne_f32_e32 v22, v5                                    // 00000002CED0: 7E2C4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002CED4: BF870091
	v_dual_fmac_f32 v20, 0x32a5705f, v3 :: v_dual_sub_f32 v5, v5, v22// 00000002CED8: C80A06FF 14042D05 32A5705F
	v_add_f32_e32 v5, v5, v20                                  // 00000002CEE4: 060A2905
	v_cvt_i32_f32_e32 v20, v22                                 // 00000002CEE8: 7E281116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000002CEEC: BF870292
	v_exp_f32_e32 v5, v5                                       // 00000002CEF0: 7E0A4B05
	.long 0xd71c0005                                           // 00000002CEF4: D71C0005
	v_cndmask_b32_e32 v1, v5, v20, vcc_lo                      // 00000002CEF8: 02022905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002CEFC: BF870121
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 00000002CF00: 020A0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000002CF04: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v3, 0x7f800000, v5, vcc_lo               // 00000002CF0C: 02060AFF 7F800000
	s_waitcnt lgkmcnt(6)                                       // 00000002CF14: BF89FC67
	v_mul_f32_e32 v5, v31, v6                                  // 00000002CF18: 100A0D1F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002CF1C: BF870001
	.long 0xd5080005                                           // 00000002CF20: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v3, vcc_lo             // 00000002CF24: 42020705
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002CF28: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002CF2C: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000002CF30: BE83007E
	ds_store_b32 v2, v5 offset:512                             // 00000002CF34: D8340200 00000502
	.long 0xd4c9007e                                           // 00000002CF3C: D4C9007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 00000002CF40: 02025F37
	s_cbranch_execz 35                                         // 00000002CF44: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1fd4>
	v_sub_f32_e32 v3, v21, v12                                 // 00000002CF48: 08061915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002CF4C: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000002CF50: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 00000002CF58: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 00000002CF64: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002CF68: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000002CF6C: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000002CF70: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 00000002CF78: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002CF80: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 00000002CF84: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 00000002CF88: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000002CF8C: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002CF90: BF8700A5
	.long 0xd71c0004                                           // 00000002CF94: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000002CF98: 02020B04
	s_waitcnt lgkmcnt(10)                                      // 00000002CF9C: BF89FCA7
	v_dual_mul_f32 v5, v7, v19 :: v_dual_cndmask_b32 v4, 0, v4 // 00000002CFA0: C8D22707 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000002CFA8: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000002CFAC: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000002CFB0: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(6)                                       // 00000002CFB8: BF89FC67
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v10, v5// 00000002CFBC: CA4608FF 03040B0A 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002CFC8: BF870001
	.long 0xd5080004                                           // 00000002CFCC: D5080004
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000002CFD0: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002CFD4: 8C7E037E
	v_mov_b32_e32 v3, 0                                        // 00000002CFD8: 7E060280
	v_mov_b32_e32 v5, 0                                        // 00000002CFDC: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 00000002CFE0: BE83007E
	ds_store_b32 v2, v4 offset:640                             // 00000002CFE4: D8340280 00000402
	.long 0xd4c9007e                                           // 00000002CFEC: D4C9007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 00000002CFF0: 02025D37
	s_cbranch_execz 35                                         // 00000002CFF4: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2084>
	v_sub_f32_e32 v4, v16, v12                                 // 00000002CFF8: 08081910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002CFFC: BF870091
	v_mul_f32_e32 v5, 0x3fb8aa3b, v4                           // 00000002D000: 100A08FF 3FB8AA3B
	v_fma_f32 v6, 0x3fb8aa3b, v4, -v5                          // 00000002D008: D6130006 841608FF 3FB8AA3B
	v_rndne_f32_e32 v7, v5                                     // 00000002D014: 7E0E4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002D018: BF870221
	v_sub_f32_e32 v5, v5, v7                                   // 00000002D01C: 080A0F05
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 00000002D020: 7C3608FF C2CE8ED0
	v_fmac_f32_e32 v6, 0x32a5705f, v4                          // 00000002D028: 560C08FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002D030: BF870121
	v_add_f32_e32 v5, v5, v6                                   // 00000002D034: 060A0D05
	v_cvt_i32_f32_e32 v6, v7                                   // 00000002D038: 7E0C1107
	v_exp_f32_e32 v5, v5                                       // 00000002D03C: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002D040: BF8700A5
	.long 0xd71c0005                                           // 00000002D044: D71C0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 00000002D048: 02020D05
	s_waitcnt lgkmcnt(10)                                      // 00000002D04C: BF89FCA7
	v_dual_mul_f32 v6, v8, v14 :: v_dual_cndmask_b32 v5, 0, v5 // 00000002D050: C8D21D08 06040A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000002D058: BF870131
	v_mul_f32_e32 v6, v13, v6                                  // 00000002D05C: 100C0D0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 00000002D060: 7C3C08FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 00000002D068: BF89FC77
	v_dual_cndmask_b32 v4, 0x7f800000, v5 :: v_dual_mul_f32 v5, v11, v6// 00000002D06C: CA460AFF 04040D0B 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002D078: BF870001
	.long 0xd5080005                                           // 00000002D07C: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v4, vcc_lo             // 00000002D080: 42020905
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002D084: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002D088: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000002D08C: BE83007E
	ds_store_b32 v2, v5 offset:768                             // 00000002D090: D8340300 00000502
	.long 0xd4c9007e                                           // 00000002D098: D4C9007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 00000002D09C: 02025B37
	s_cbranch_execz 35                                         // 00000002D0A0: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2130>
	v_sub_f32_e32 v3, v17, v12                                 // 00000002D0A4: 08061911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002D0A8: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000002D0AC: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 00000002D0B4: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 00000002D0C0: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002D0C4: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000002D0C8: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000002D0CC: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 00000002D0D4: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002D0DC: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 00000002D0E0: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 00000002D0E4: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000002D0E8: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002D0EC: BF8700A5
	.long 0xd71c0004                                           // 00000002D0F0: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000002D0F4: 02020B04
	s_waitcnt lgkmcnt(11)                                      // 00000002D0F8: BF89FCB7
	v_dual_mul_f32 v5, v9, v15 :: v_dual_cndmask_b32 v4, 0, v4 // 00000002D0FC: C8D21F09 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000002D104: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000002D108: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000002D10C: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 00000002D114: BF89FC77
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v62, v5// 00000002D118: CA4608FF 03040B3E 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002D124: BF870001
	.long 0xd5080003                                           // 00000002D128: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000002D12C: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002D130: 8C7E037E
	ds_store_b32 v2, v3 offset:896                             // 00000002D134: D8340380 00000302
	s_waitcnt lgkmcnt(0)                                       // 00000002D13C: BF89FC07
	s_barrier                                                  // 00000002D140: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s15                             // 00000002D144: 8B6A0F7E
	s_mov_b32 s3, -1                                           // 00000002D148: BE8300C1
	s_cbranch_vccz 176                                         // 00000002D14C: BFA300B0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2410>
	s_mov_b32 s3, exec_lo                                      // 00000002D150: BE83007E
	v_cmpx_gt_i32_e32 0x120, v44                               // 00000002D154: 7D8858FF 00000120
	s_cbranch_execz 170                                        // 00000002D15C: BFA500AA <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2408>
	v_add_nc_u32_e32 v2, 0xffffff00, v44                       // 00000002D160: 4A0458FF FFFFFF00
	s_mov_b32 s4, 0                                            // 00000002D168: BE840080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002D16C: BF870001
	v_mov_b32_e32 v3, v2                                       // 00000002D170: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002D174: BF8700A1
	v_add_nc_u32_e32 v3, 0xe0, v3                              // 00000002D178: 4A0606FF 000000E0
	s_waitcnt lgkmcnt(4)                                       // 00000002D180: BF89FC47
	v_ashrrev_i32_e32 v16, 7, v3                               // 00000002D184: 34200687
	v_and_b32_e32 v12, 0x7f, v3                                // 00000002D188: 361806FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002D190: BF870092
	.long 0xd72c0004                                           // 00000002D194: D72C0004
	v_cndmask_b32_e32 v1, 0x880, v16, vcc_lo                   // 00000002D198: 020220FF 00000880
	v_lshl_add_u32 v4, v12, 1, v4                              // 00000002D1A0: D6460004 0411030C
	ds_load_u16 v20, v4 offset:7776                            // 00000002D1A8: D8F01E60 14000004
	ds_load_u16 v21, v4 offset:7232                            // 00000002D1B0: D8F01C40 15000004
	s_waitcnt lgkmcnt(4)                                       // 00000002D1B8: BF89FC47
	ds_load_u16 v22, v4 offset:6688                            // 00000002D1BC: D8F01A20 16000004
	ds_load_u16 v23, v4 offset:6144                            // 00000002D1C4: D8F01800 17000004
	ds_load_u16 v24, v4 offset:6416                            // 00000002D1CC: D8F01910 18000004
	s_waitcnt lgkmcnt(3)                                       // 00000002D1D4: BF89FC37
	v_lshlrev_b32_e32 v21, 16, v21                             // 00000002D1D8: 302A2A90
	s_waitcnt lgkmcnt(1)                                       // 00000002D1DC: BF89FC17
	v_lshlrev_b32_e32 v23, 16, v23                             // 00000002D1E0: 302E2E90
	v_lshlrev_b32_e32 v17, 5, v16                              // 00000002D1E4: 30222085
	ds_load_u16 v25, v4 offset:6960                            // 00000002D1E8: D8F01B30 19000004
	ds_load_u16 v26, v4 offset:7504                            // 00000002D1F0: D8F01D50 1A000004
	ds_load_u16 v27, v4 offset:8048                            // 00000002D1F8: D8F01F70 1B000004
	ds_load_b128 v[4:7], v17 offset:24384                      // 00000002D200: DBFC5F40 04000011
	ds_load_b128 v[8:11], v17 offset:24400                     // 00000002D208: DBFC5F50 08000011
	v_lshlrev_b32_e32 v20, 16, v20                             // 00000002D210: 30282890
	s_waitcnt lgkmcnt(0)                                       // 00000002D214: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002D218: BF870091
	v_dual_mul_f32 v10, v10, v20 :: v_dual_lshlrev_b32 v25, 16, v25// 00000002D21C: C8E2290A 0A183290
	v_dual_mul_f32 v7, v7, v25 :: v_dual_lshlrev_b32 v24, 16, v24// 00000002D224: C8E23307 07183090
	v_mul_f32_e32 v8, v8, v21                                  // 00000002D22C: 10102B08
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002D230: BF870002
	v_dual_mul_f32 v4, v4, v23 :: v_dual_mul_f32 v5, v5, v24   // 00000002D234: C8C62F04 04043105
	v_mul_u32_u24_e32 v18, 48, v12                             // 00000002D23C: 162418B0
	ds_load_b128 v[12:15], v17 offset:24192                    // 00000002D240: DBFC5E80 0C000011
	v_lshlrev_b32_e32 v26, 16, v26                             // 00000002D248: 30343490
	v_lshlrev_b32_e32 v27, 16, v27                             // 00000002D24C: 30363690
	v_lshl_add_u32 v28, v16, 4, v18                            // 00000002D250: D646001C 04490910
	ds_load_b128 v[16:19], v17 offset:24208                    // 00000002D258: DBFC5E90 10000011
	s_waitcnt lgkmcnt(1)                                       // 00000002D260: BF89FC17
	v_mul_f32_e32 v12, v12, v4                                 // 00000002D264: 1018090C
	v_mul_f32_e32 v4, v13, v5                                  // 00000002D268: 10080B0D
	v_dual_mul_f32 v11, v11, v27 :: v_dual_lshlrev_b32 v22, 16, v22// 00000002D26C: C8E2370B 0B162C90
	v_mul_f32_e32 v5, v15, v7                                  // 00000002D274: 100A0F0F
	v_mul_f32_e32 v9, v9, v26                                  // 00000002D278: 10123509
	s_waitcnt lgkmcnt(0)                                       // 00000002D27C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000002D280: BF870243
	v_dual_mul_f32 v7, v16, v8 :: v_dual_mul_f32 v6, v6, v22   // 00000002D284: C8C61110 07062D06
	v_cmp_lt_i32_e32 vcc_lo, 31, v3                            // 00000002D28C: 7C82069F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 00000002D290: CC220004 02006104
	v_dual_mul_f32 v8, v17, v9 :: v_dual_mul_f32 v9, v18, v10  // 00000002D298: C8C61311 08081512
	v_mul_f32_e32 v6, v14, v6                                  // 00000002D2A0: 100C0D0E
	v_mul_f32_e32 v10, v19, v11                                // 00000002D2A4: 10141713
	v_fma_mixlo_f16 v4, v12, s48, 0                            // 00000002D2A8: CC210004 0200610C
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 00000002D2B0: CC220005 02006105
	s_or_b32 s4, vcc_lo, s4                                    // 00000002D2B8: 8C04046A
	v_fma_mixlo_f16 v5, v6, s48, 0                             // 00000002D2BC: CC210005 02006106
	v_fma_mixhi_f16 v6, v8, s48, 0                             // 00000002D2C4: CC220006 02006108
	v_fma_mixlo_f16 v6, v7, s48, 0                             // 00000002D2CC: CC210006 02006107
	v_fma_mixhi_f16 v7, v10, s48, 0                            // 00000002D2D4: CC220007 0200610A
	v_fma_mixlo_f16 v7, v9, s48, 0                             // 00000002D2DC: CC210007 02006109
	ds_store_b128 v28, v[4:7]                                  // 00000002D2E4: DB7C0000 0000041C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000002D2EC: 917E047E
	s_cbranch_execnz 65440                                     // 00000002D2F0: BFA6FFA0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2174>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000002D2F4: 8C7E047E
	v_lshl_add_u32 v3, v44, 3, 0xffffff00                      // 00000002D2F8: D6460003 03FD072C FFFFFF00
	s_mov_b32 s4, 0                                            // 00000002D304: BE840080
	v_add_nc_u32_e32 v2, 0xe0, v2                              // 00000002D308: 4A0404FF 000000E0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002D310: BF8701A2
	v_and_b32_e32 v4, 0x78, v3                                 // 00000002D314: 360806FF 00000078
	v_add_nc_u32_e32 v3, 0x700, v3                             // 00000002D31C: 4A0606FF 00000700
	v_ashrrev_i32_e32 v5, 4, v2                                // 00000002D324: 340A0484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002D328: BF870121
	.long 0xd72c0006                                           // 00000002D32C: D72C0006
	v_cndmask_b32_e32 v1, 0x110, v5, vcc_lo                    // 00000002D330: 02020AFF 00000110
	v_lshlrev_b32_e32 v8, 2, v5                                // 00000002D338: 30100A82
	v_lshl_add_u32 v9, v4, 1, v6                               // 00000002D33C: D6460009 04190304
	ds_load_b128 v[4:7], v9 offset:10496                       // 00000002D344: DBFC2900 04000009
	ds_load_b32 v8, v8 offset:24448                            // 00000002D34C: D8D85F80 08000008
	s_waitcnt lgkmcnt(1)                                       // 00000002D354: BF89FC17
	v_and_b32_e32 v12, 0xffff0000, v6                          // 00000002D358: 36180CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000002D360: 300C0C90
	v_and_b32_e32 v13, 0xffff0000, v7                          // 00000002D364: 361A0EFF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v4                          // 00000002D36C: 361408FF FFFF0000
	v_lshlrev_b32_e32 v4, 16, v4                               // 00000002D374: 30080890
	v_and_b32_e32 v11, 0xffff0000, v5                          // 00000002D378: 36160AFF FFFF0000
	v_lshlrev_b32_e32 v5, 16, v5                               // 00000002D380: 300A0A90
	s_waitcnt lgkmcnt(0)                                       // 00000002D384: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002D388: BF8701A3
	v_dual_mul_f32 v14, v8, v4 :: v_dual_lshlrev_b32 v7, 16, v7// 00000002D38C: C8E20908 0E060E90
	v_mul_f32_e32 v4, v8, v10                                  // 00000002D394: 10081508
	v_mul_f32_e32 v10, v8, v5                                  // 00000002D398: 10140B08
	v_mul_f32_e32 v5, v8, v11                                  // 00000002D39C: 100A1708
	v_mul_f32_e32 v11, v8, v6                                  // 00000002D3A0: 10160D08
	v_mul_f32_e32 v6, v8, v12                                  // 00000002D3A4: 100C1908
	v_mul_f32_e32 v12, v8, v7                                  // 00000002D3A8: 10180F08
	v_mul_f32_e32 v7, v8, v13                                  // 00000002D3AC: 100E1B08
	v_cmp_lt_i32_e32 vcc_lo, 31, v2                            // 00000002D3B0: 7C82049F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 00000002D3B4: CC220004 02006104
	v_fma_mixlo_f16 v4, v14, s48, 0                            // 00000002D3BC: CC210004 0200610E
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 00000002D3C4: CC220005 02006105
	v_fma_mixlo_f16 v5, v10, s48, 0                            // 00000002D3CC: CC210005 0200610A
	v_fma_mixhi_f16 v6, v6, s48, 0                             // 00000002D3D4: CC220006 02006106
	v_fma_mixlo_f16 v6, v11, s48, 0                            // 00000002D3DC: CC210006 0200610B
	v_fma_mixhi_f16 v7, v7, s48, 0                             // 00000002D3E4: CC220007 02006107
	v_fma_mixlo_f16 v7, v12, s48, 0                            // 00000002D3EC: CC210007 0200610C
	s_or_b32 s4, vcc_lo, s4                                    // 00000002D3F4: 8C04046A
	ds_store_b128 v9, v[4:7] offset:10496                      // 00000002D3F8: DB7C2900 00000409
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000002D400: 917E047E
	s_cbranch_execnz 65472                                     // 00000002D404: BFA6FFC0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2308>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002D408: 8C7E037E
	s_mov_b32 s3, 0                                            // 00000002D40C: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002D410: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 00000002D414: 916A037E
	s_cbranch_vccnz 533                                        // 00000002D418: BFA40215 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c70>
	s_mov_b32 s3, exec_lo                                      // 00000002D41C: BE83007E
	v_cmpx_gt_u32_e32 16, v43                                  // 00000002D420: 7D985690
	s_cbranch_execz 529                                        // 00000002D424: BFA50211 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c6c>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000002D428: 7C945680
	s_waitcnt lgkmcnt(0)                                       // 00000002D42C: BF89FC07
	ds_load_b96 v[14:16], v1 offset:23280                      // 00000002D430: DBF85AF0 0E000001
	ds_load_b128 v[59:62], v1 offset:23248                     // 00000002D438: DBFC5AD0 3B000001
	ds_load_b128 v[63:66], v1 offset:23264                     // 00000002D440: DBFC5AE0 3F000001
	ds_load_b128 v[10:13], v1 offset:23168                     // 00000002D448: DBFC5A80 0A000001
	ds_load_b128 v[6:9], v1 offset:23184                       // 00000002D450: DBFC5A90 06000001
	ds_load_b128 v[2:5], v1 offset:23200                       // 00000002D458: DBFC5AA0 02000001
	ds_load_b64 v[17:18], v1 offset:23216                      // 00000002D460: D9D85AB0 11000001
	v_cndmask_b32_e64 v44, 0, 1.0, vcc_lo                      // 00000002D468: D501002C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 00000002D470: 7C945681
	ds_load_b128 v[45:48], v1 offset:23232                     // 00000002D474: DBFC5AC0 2D000001
	v_cndmask_b32_e64 v33, 0, 1.0, vcc_lo                      // 00000002D47C: D5010021 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 00000002D484: 7C945682
	v_cndmask_b32_e64 v32, 0, 1.0, vcc_lo                      // 00000002D488: D5010020 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 00000002D490: 7C945683
	v_cndmask_b32_e64 v31, 0, 1.0, vcc_lo                      // 00000002D494: D501001F 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 00000002D49C: 7C945684
	v_cndmask_b32_e64 v29, 0, 1.0, vcc_lo                      // 00000002D4A0: D501001D 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 00000002D4A8: 7C945685
	v_cndmask_b32_e64 v30, 0, 1.0, vcc_lo                      // 00000002D4AC: D501001E 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 00000002D4B4: 7C945686
	v_cndmask_b32_e64 v28, 0, 1.0, vcc_lo                      // 00000002D4B8: D501001C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 00000002D4C0: 7C945687
	v_cndmask_b32_e64 v27, 0, 1.0, vcc_lo                      // 00000002D4C4: D501001B 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 00000002D4CC: 7C945688
	v_cndmask_b32_e64 v25, 0, 1.0, vcc_lo                      // 00000002D4D0: D5010019 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 00000002D4D8: 7C945689
	v_cndmask_b32_e64 v23, 0, 1.0, vcc_lo                      // 00000002D4DC: D5010017 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000002D4E4: 7C94568A
	v_cndmask_b32_e64 v26, 0, 1.0, vcc_lo                      // 00000002D4E8: D501001A 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 00000002D4F0: 7C94568B
	v_cndmask_b32_e64 v24, 0, 1.0, vcc_lo                      // 00000002D4F4: D5010018 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 00000002D4FC: 7C94568C
	v_cndmask_b32_e64 v20, 0, 1.0, vcc_lo                      // 00000002D500: D5010014 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 00000002D508: 7C94568D
	v_cndmask_b32_e64 v22, 0, 1.0, vcc_lo                      // 00000002D50C: D5010016 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 00000002D514: 7C94568E
	v_cndmask_b32_e64 v21, 0, 1.0, vcc_lo                      // 00000002D518: D5010015 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 00000002D520: 7C94568F
	v_cndmask_b32_e64 v19, 0, 1.0, vcc_lo                      // 00000002D524: D5010013 01A9E480
	s_waitcnt lgkmcnt(7)                                       // 00000002D52C: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000002D530: BF8700B1
	v_fmac_f32_e32 v22, v19, v15                               // 00000002D534: 562C1F13
	v_fmac_f32_e32 v21, v19, v16                               // 00000002D538: 562A2113
	s_waitcnt lgkmcnt(1)                                       // 00000002D53C: BF89FC17
	v_dual_fmac_f32 v23, v19, v64 :: v_dual_fmac_f32 v22, v21, v18// 00000002D540: C8008113 17162515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000002D548: BF8700D1
	v_dual_fmac_f32 v26, v19, v65 :: v_dual_fmac_f32 v23, v21, v3// 00000002D54C: C8008313 1A160715
	v_fmac_f32_e32 v25, v19, v63                               // 00000002D554: 56327F13
	ds_load_b32 v18, v1 offset:22880                           // 00000002D558: D8D85960 12000001
	v_fmac_f32_e32 v26, v21, v4                                // 00000002D560: 56340915
	v_dual_fmac_f32 v28, v19, v61 :: v_dual_fmac_f32 v25, v21, v2// 00000002D564: C8007B13 1C180515
	v_dual_fmac_f32 v29, v19, v59 :: v_dual_fmac_f32 v28, v21, v8// 00000002D56C: C8007713 1D1C1115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002D574: BF870091
	v_dual_fmac_f32 v30, v19, v60 :: v_dual_fmac_f32 v29, v21, v6// 00000002D578: C8007913 1E1C0D15
	v_dual_fmac_f32 v27, v19, v62 :: v_dual_fmac_f32 v30, v21, v7// 00000002D580: C8007D13 1B1E0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002D588: BF870091
	v_dual_fmac_f32 v24, v19, v66 :: v_dual_fmac_f32 v27, v21, v9// 00000002D58C: C8008513 181A1315
	v_fmac_f32_e32 v24, v21, v5                                // 00000002D594: 56300B15
	ds_load_b128 v[2:5], v1 offset:23072                       // 00000002D598: DBFC5A20 02000001
	s_waitcnt lgkmcnt(2)                                       // 00000002D5A0: BF89FC27
	v_fmac_f32_e32 v31, v19, v48                               // 00000002D5A4: 563E6113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002D5A8: BF870091
	v_dual_fmac_f32 v32, v19, v47 :: v_dual_fmac_f32 v31, v21, v13// 00000002D5AC: C8005F13 201E1B15
	v_dual_fmac_f32 v33, v19, v46 :: v_dual_fmac_f32 v32, v21, v12// 00000002D5B4: C8005D13 21201915
	v_fmac_f32_e32 v44, v19, v45                               // 00000002D5BC: 56585B13
	ds_load_b128 v[45:48], v1 offset:24064                     // 00000002D5C0: DBFC5E00 2D000001
	v_dual_fmac_f32 v33, v21, v11 :: v_dual_fmac_f32 v20, v19, v14// 00000002D5C8: C8001715 21141D13
	ds_load_b128 v[59:62], v1 offset:23104                     // 00000002D5D0: DBFC5A40 3B000001
	ds_load_b128 v[63:66], v1 offset:23136                     // 00000002D5D8: DBFC5A60 3F000001
	ds_load_b128 v[67:70], v1 offset:23120                     // 00000002D5E0: DBFC5A50 43000001
	ds_load_b32 v14, v1 offset:23152                           // 00000002D5E8: D8D85A70 0E000001
	v_fmac_f32_e32 v44, v21, v10                               // 00000002D5F0: 56581515
	ds_load_b128 v[6:9], v1 offset:23056                       // 00000002D5F4: DBFC5A10 06000001
	ds_load_b128 v[10:13], v1 offset:23040                     // 00000002D5FC: DBFC5A00 0A000001
	s_waitcnt lgkmcnt(5)                                       // 00000002D604: BF89FC57
	v_fmac_f32_e32 v44, v22, v59                               // 00000002D608: 56587716
	v_dual_fmac_f32 v33, v22, v60 :: v_dual_fmac_f32 v20, v21, v17// 00000002D60C: C8007916 21142315
	s_waitcnt lgkmcnt(3)                                       // 00000002D614: BF89FC37
	v_fmac_f32_e32 v29, v22, v67                               // 00000002D618: 563A8716
	v_fmac_f32_e32 v31, v22, v62                               // 00000002D61C: 563E7D16
	s_waitcnt lgkmcnt(2)                                       // 00000002D620: BF89FC27
	v_fmac_f32_e32 v20, v22, v14                               // 00000002D624: 56281D16
	ds_load_b128 v[14:17], v1 offset:22976                     // 00000002D628: DBFC59C0 0E000001
	v_fmac_f32_e32 v24, v22, v66                               // 00000002D630: 56308516
	v_fmac_f32_e32 v32, v22, v61                               // 00000002D634: 56407B16
	ds_load_b64 v[66:67], v1 offset:22944                      // 00000002D638: D9D859A0 42000001
	s_waitcnt lgkmcnt(2)                                       // 00000002D640: BF89FC27
	v_fmac_f32_e32 v33, v20, v11                               // 00000002D644: 56421714
	v_fmac_f32_e32 v24, v20, v5                                // 00000002D648: 56300B14
	s_waitcnt lgkmcnt(1)                                       // 00000002D64C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002D650: BF8701B1
	v_dual_fmac_f32 v33, v24, v15 :: v_dual_fmac_f32 v30, v22, v68// 00000002D654: C8001F18 211E8916
	v_fmac_f32_e32 v29, v20, v6                                // 00000002D65C: 563A0D14
	v_dual_fmac_f32 v25, v22, v63 :: v_dual_fmac_f32 v44, v20, v10// 00000002D660: C8007F16 192C1514
	v_dual_fmac_f32 v23, v22, v64 :: v_dual_fmac_f32 v30, v20, v7// 00000002D668: C8008116 171E0F14
	v_fmac_f32_e32 v26, v22, v65                               // 00000002D670: 56348316
	ds_load_b128 v[59:62], v1 offset:22992                     // 00000002D674: DBFC59D0 3B000001
	ds_load_b96 v[63:65], v1 offset:23008                      // 00000002D67C: DBF859E0 3F000001
	v_dual_fmac_f32 v28, v22, v69 :: v_dual_fmac_f32 v25, v20, v2// 00000002D684: C8008B16 1C180514
	v_dual_fmac_f32 v27, v22, v70 :: v_dual_fmac_f32 v32, v20, v12// 00000002D68C: C8008D16 1B201914
	v_fmac_f32_e32 v23, v20, v3                                // 00000002D694: 562E0714
	v_fmac_f32_e32 v26, v20, v4                                // 00000002D698: 56340914
	v_fmac_f32_e32 v31, v20, v13                               // 00000002D69C: 563E1B14
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002D6A0: BF870004
	v_fmac_f32_e32 v27, v20, v9                                // 00000002D6A4: 56361314
	ds_load_b128 v[2:5], v1 offset:22848                       // 00000002D6A8: DBFC5940 02000001
	s_waitcnt lgkmcnt(1)                                       // 00000002D6B0: BF89FC17
	v_fmac_f32_e32 v26, v24, v65                               // 00000002D6B4: 56348318
	v_fmac_f32_e32 v28, v20, v8                                // 00000002D6B8: 56381114
	ds_load_b128 v[6:9], v1 offset:22928                       // 00000002D6BC: DBFC5990 06000001
	ds_load_b128 v[10:13], v1 offset:22912                     // 00000002D6C4: DBFC5980 0A000001
	v_fmac_f32_e32 v29, v24, v59                               // 00000002D6CC: 563A7718
	s_waitcnt lgkmcnt(1)                                       // 00000002D6D0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002D6D4: BF870001
	v_fmac_f32_e32 v29, v26, v6                                // 00000002D6D8: 563A0D1A
	v_fmac_f32_e32 v31, v24, v17                               // 00000002D6DC: 563E2318
	v_fmac_f32_e32 v44, v24, v14                               // 00000002D6E0: 56581D18
	v_fmac_f32_e32 v23, v24, v64                               // 00000002D6E4: 562E8118
	v_fmac_f32_e32 v32, v24, v16                               // 00000002D6E8: 56402118
	ds_load_b128 v[14:17], v1 offset:22864                     // 00000002D6EC: DBFC5950 0E000001
	v_fmac_f32_e32 v23, v26, v67                               // 00000002D6F4: 562E871A
	s_waitcnt lgkmcnt(0)                                       // 00000002D6F8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002D6FC: BF870001
	v_fmac_f32_e32 v29, v23, v14                               // 00000002D700: 563A1D17
	v_fmac_f32_e32 v27, v24, v62                               // 00000002D704: 56367D18
	v_fmac_f32_e32 v30, v24, v60                               // 00000002D708: 563C7918
	v_fmac_f32_e32 v25, v24, v63                               // 00000002D70C: 56327F18
	v_dual_fmac_f32 v33, v26, v11 :: v_dual_fmac_f32 v28, v24, v61// 00000002D710: C800171A 211C7B18
	ds_load_b128 v[59:62], v1 offset:22800                     // 00000002D718: DBFC5910 3B000001
	v_fmac_f32_e32 v32, v26, v12                               // 00000002D720: 5640191A
	v_fmac_f32_e32 v31, v26, v13                               // 00000002D724: 563E1B1A
	v_fmac_f32_e32 v44, v26, v10                               // 00000002D728: 5658151A
	ds_load_b128 v[10:13], v1 offset:22784                     // 00000002D72C: DBFC5900 0A000001
	ds_load_b96 v[63:65], v1 offset:22736                      // 00000002D734: DBF858D0 3F000001
	v_fmac_f32_e32 v27, v26, v9                                // 00000002D73C: 5636131A
	v_fmac_f32_e32 v30, v26, v7                                // 00000002D740: 563C0F1A
	v_fmac_f32_e32 v25, v26, v66                               // 00000002D744: 5632851A
	v_fmac_f32_e32 v28, v26, v8                                // 00000002D748: 5638111A
	ds_load_b128 v[6:9], v1 offset:22720                       // 00000002D74C: DBFC58C0 06000001
	ds_load_b64 v[66:67], v1 offset:22672                      // 00000002D754: D9D85890 42000001
	v_fmac_f32_e32 v33, v23, v3                                // 00000002D75C: 56420717
	v_fmac_f32_e32 v25, v23, v18                               // 00000002D760: 56322517
	v_fmac_f32_e32 v28, v23, v16                               // 00000002D764: 56382117
	v_fmac_f32_e32 v27, v23, v17                               // 00000002D768: 56362317
	v_fmac_f32_e32 v30, v23, v15                               // 00000002D76C: 563C1F17
	ds_load_b128 v[14:17], v1 offset:22528                     // 00000002D770: DBFC5800 0E000001
	s_waitcnt lgkmcnt(5)                                       // 00000002D778: BF89FC57
	v_fmac_f32_e32 v27, v25, v62                               // 00000002D77C: 56367D19
	v_fmac_f32_e32 v28, v25, v61                               // 00000002D780: 56387B19
	v_fmac_f32_e32 v30, v25, v60                               // 00000002D784: 563C7919
	s_waitcnt lgkmcnt(3)                                       // 00000002D788: BF89FC37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002D78C: BF870112
	v_fmac_f32_e32 v28, v27, v65                               // 00000002D790: 5638831B
	v_fmac_f32_e32 v30, v27, v64                               // 00000002D794: 563C811B
	s_waitcnt lgkmcnt(1)                                       // 00000002D798: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002D79C: BF870001
	v_fmac_f32_e32 v30, v28, v67                               // 00000002D7A0: 563C871C
	v_dual_fmac_f32 v44, v23, v2 :: v_dual_fmac_f32 v33, v25, v11// 00000002D7A4: C8000517 2C201719
	v_fmac_f32_e32 v31, v23, v5                                // 00000002D7AC: 563E0B17
	v_fmac_f32_e32 v32, v23, v4                                // 00000002D7B0: 56400917
	ds_load_b128 v[2:5], v1 offset:22656                       // 00000002D7B4: DBFC5880 02000001
	v_fmac_f32_e32 v44, v25, v10                               // 00000002D7BC: 56581519
	v_fmac_f32_e32 v29, v25, v59                               // 00000002D7C0: 563A7719
	v_fmac_f32_e32 v31, v25, v13                               // 00000002D7C4: 563E1B19
	v_fmac_f32_e32 v32, v25, v12                               // 00000002D7C8: 56401919
	ds_load_b128 v[10:13], v1 offset:22592                     // 00000002D7CC: DBFC5840 0A000001
	ds_load_b32 v18, v1 offset:22608                           // 00000002D7D4: D8D85850 12000001
	v_fmac_f32_e32 v33, v27, v7                                // 00000002D7DC: 56420F1B
	v_fmac_f32_e32 v29, v27, v63                               // 00000002D7E0: 563A7F1B
	ds_load_b64 v[59:60], v1 offset:22400                      // 00000002D7E4: D9D85780 3B000001
	v_dual_fmac_f32 v32, v27, v8 :: v_dual_fmac_f32 v29, v28, v66// 00000002D7EC: C800111B 201C851C
	ds_load_b128 v[63:66], v1 offset:24304                     // 00000002D7F4: DBFC5EF0 3F000001
	s_waitcnt lgkmcnt(2)                                       // 00000002D7FC: BF89FC27
	v_fmac_f32_e32 v29, v30, v18                               // 00000002D800: 563A251E
	v_dual_fmac_f32 v44, v27, v6 :: v_dual_fmac_f32 v33, v28, v3// 00000002D804: C8000D1B 2C20071C
	v_fmac_f32_e32 v31, v27, v9                                // 00000002D80C: 563E131B
	ds_load_b96 v[6:8], v1 offset:22464                        // 00000002D810: DBF857C0 06000001
	ds_load_b32 v9, v1 offset:22336                            // 00000002D818: D8D85740 09000001
	v_fmac_f32_e32 v44, v28, v2                                // 00000002D820: 5658051C
	v_fmac_f32_e32 v32, v28, v4                                // 00000002D824: 5640091C
	v_fmac_f32_e32 v31, v28, v5                                // 00000002D828: 563E0B1C
	v_fmac_f32_e32 v33, v30, v11                               // 00000002D82C: 5642171E
	ds_load_b128 v[2:5], v1 offset:24256                       // 00000002D830: DBFC5EC0 02000001
	v_fmac_f32_e32 v44, v30, v10                               // 00000002D838: 5658151E
	v_fmac_f32_e32 v32, v30, v12                               // 00000002D83C: 5640191E
	v_fmac_f32_e32 v31, v30, v13                               // 00000002D840: 563E1B1E
	v_fmac_f32_e32 v33, v29, v15                               // 00000002D844: 56421F1D
	s_waitcnt lgkmcnt(3)                                       // 00000002D848: BF89FC37
	v_mul_f32_e32 v72, v65, v21                                // 00000002D84C: 10902B41
	v_fmac_f32_e32 v44, v29, v14                               // 00000002D850: 56581D1D
	v_fmac_f32_e32 v32, v29, v16                               // 00000002D854: 5640211D
	v_fmac_f32_e32 v31, v29, v17                               // 00000002D858: 563E231D
	s_waitcnt lgkmcnt(2)                                       // 00000002D85C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002D860: BF8700A1
	v_fmac_f32_e32 v32, v31, v8                                // 00000002D864: 5640111F
	v_fmac_f32_e32 v33, v31, v7                                // 00000002D868: 56420F1F
	v_dual_fmac_f32 v44, v31, v6 :: v_dual_fmac_f32 v33, v32, v60// 00000002D86C: C8000D1F 2C207920
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002D874: BF870001
	v_fmac_f32_e32 v44, v32, v59                               // 00000002D878: 56587720
	ds_load_b128 v[59:62], v1 offset:24288                     // 00000002D87C: DBFC5EE0 3B000001
	s_waitcnt lgkmcnt(1)                                       // 00000002D884: BF89FC17
	v_fma_mixlo_f16 v49, v5, v31, 0                            // 00000002D888: CC210031 02023F05
	v_mul_f32_e32 v15, v3, v33                                 // 00000002D890: 101E4303
	v_fmac_f32_e32 v44, v33, v9                                // 00000002D894: 56581321
	ds_load_b128 v[6:9], v1 offset:24272                       // 00000002D898: DBFC5ED0 06000001
	ds_load_b128 v[10:13], v1 offset:24112                     // 00000002D8A0: DBFC5E30 0A000001
	v_fma_mixlo_f16 v18, v3, v33, 0                            // 00000002D8A8: CC210012 02024303
	v_mul_f32_e32 v14, v2, v44                                 // 00000002D8B0: 101C5902
	v_fma_mixlo_f16 v2, v2, v44, 0                             // 00000002D8B4: CC210002 02025902
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002D8BC: BF870113
	v_fma_mix_f32 v15, v18, -1.0, v15 op_sel_hi:[1,1,0]        // 00000002D8C0: CC20000F 1C3DE712
	v_fma_mix_f32 v3, v2, -1.0, v14 op_sel_hi:[1,1,0]          // 00000002D8C8: CC200003 1C39E702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000002D8D0: BF870232
	.long 0x7f1c150f                                           // 00000002D8D4: 7F1C150F
	v_mul_f32_e32 v15, v4, v32                                 // 00000002D8D8: 101E4104
	.long 0x7f043912                                           // 00000002D8DC: 7F043912
	v_cvt_f16_f32_e32 v14, v3                                  // 00000002D8E0: 7E1C1503
	v_fma_mixlo_f16 v3, v4, v32, 0                             // 00000002D8E4: CC210003 02024104
	v_mul_f32_e32 v4, v5, v31                                  // 00000002D8EC: 10083F05
	s_waitcnt lgkmcnt(2)                                       // 00000002D8F0: BF89FC27
	v_fma_mixlo_f16 v69, v60, v23, 0                           // 00000002D8F4: CC210045 02022F3C
	s_waitcnt lgkmcnt(1)                                       // 00000002D8FC: BF89FC17
	v_mul_f32_e32 v16, v7, v30                                 // 00000002D900: 10203D07
	v_fma_mixlo_f16 v67, v7, v30, 0                            // 00000002D904: CC210043 02023D07
	v_fma_mix_f32 v7, v3, -1.0, v15 op_sel_hi:[1,1,0]          // 00000002D90C: CC200007 1C3DE703
	v_mul_f32_e32 v5, v6, v29                                  // 00000002D914: 100A3B06
	v_fma_mixlo_f16 v68, v9, v27, 0                            // 00000002D918: CC210044 02023709
	.long 0x7f063931                                           // 00000002D920: 7F063931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000002D924: BF8701D4
	v_cvt_f16_f32_e32 v15, v7                                  // 00000002D928: 7E1E1507
	v_mul_f32_e32 v7, v8, v28                                  // 00000002D92C: 100E3908
	v_fma_mix_f32 v17, v49, -1.0, v4 op_sel_hi:[1,1,0]         // 00000002D930: CC200011 1C11E731
	v_fma_mixlo_f16 v4, v6, v29, 0                             // 00000002D938: CC210004 02023B06
	v_fma_mix_f32 v6, v67, -1.0, v16 op_sel_hi:[1,1,0]         // 00000002D940: CC200006 1C41E743
	.long 0x7f1e1511                                           // 00000002D948: 7F1E1511
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002D94C: BF870193
	v_fma_mix_f32 v5, v4, -1.0, v5 op_sel_hi:[1,1,0]           // 00000002D950: CC200005 1C15E704
	.long 0x7f201506                                           // 00000002D958: 7F201506
	v_fma_mixlo_f16 v6, v59, v25, 0                            // 00000002D95C: CC210006 0202333B
	.long 0x7f083943                                           // 00000002D964: 7F083943
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000002D968: BF8701C4
	v_cvt_f16_f32_e32 v16, v5                                  // 00000002D96C: 7E201505
	v_fma_mixlo_f16 v5, v8, v28, 0                             // 00000002D970: CC210005 02023908
	v_dual_mul_f32 v8, v9, v27 :: v_dual_mul_f32 v9, v59, v25  // 00000002D978: C8C63709 0808333B
	v_dual_mul_f32 v59, v60, v23 :: v_dual_mul_f32 v60, v61, v26// 00000002D980: C8C62F3C 3B3C353D
	v_fma_mix_f32 v7, v5, -1.0, v7 op_sel_hi:[1,1,0]           // 00000002D988: CC200007 1C1DE705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002D990: BF870213
	v_fma_mix_f32 v8, v68, -1.0, v8 op_sel_hi:[1,1,0]          // 00000002D994: CC200008 1C21E744
	v_fma_mix_f32 v9, v6, -1.0, v9 op_sel_hi:[1,1,0]           // 00000002D99C: CC200009 1C25E706
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002D9A4: BF870004
	v_fma_mix_f32 v70, v69, -1.0, v59 op_sel_hi:[1,1,0]        // 00000002D9A8: CC200046 1CEDE745
	.long 0x7f0c3945                                           // 00000002D9B0: 7F0C3945
	v_cvt_f16_f32_e32 v17, v7                                  // 00000002D9B4: 7E221507
	v_fma_mixlo_f16 v7, v61, v26, 0                            // 00000002D9B8: CC210007 0202353D
	.long 0x7f221508                                           // 00000002D9C0: 7F221508
	v_cvt_f16_f32_e32 v59, v9                                  // 00000002D9C4: 7E761509
	.long 0x7f761546                                           // 00000002D9C8: 7F761546
	v_mul_f32_e32 v9, v62, v24                                 // 00000002D9CC: 1012313E
	v_fma_mix_f32 v8, v7, -1.0, v60 op_sel_hi:[1,1,0]          // 00000002D9D0: CC200008 1CF1E707
	v_fma_mixlo_f16 v70, v62, v24, 0                           // 00000002D9D8: CC210046 0202313E
	v_dual_mul_f32 v61, v63, v20 :: v_dual_mul_f32 v62, v64, v22// 00000002D9E0: C8C6293F 3D3E2D40
	v_fma_mixlo_f16 v64, v64, v22, 0                           // 00000002D9E8: CC210040 02022D40
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002D9F0: BF870214
	v_cvt_f16_f32_e32 v60, v8                                  // 00000002D9F4: 7E781508
	v_fma_mix_f32 v71, v70, -1.0, v9 op_sel_hi:[1,1,0]         // 00000002D9F8: CC200047 1C25E746
	v_fma_mixlo_f16 v8, v63, v20, 0                            // 00000002DA00: CC210008 0202293F
	v_fma_mixlo_f16 v9, v65, v21, 0                            // 00000002DA08: CC210009 02022B41
	v_fma_mix_f32 v62, v64, -1.0, v62 op_sel_hi:[1,1,0]        // 00000002DA10: CC20003E 1CF9E740
	v_mul_f32_e32 v65, v66, v19                                // 00000002DA18: 10822742
	v_fma_mixlo_f16 v66, v66, v19, 0                           // 00000002DA1C: CC210042 02022742
	v_fma_mix_f32 v61, v8, -1.0, v61 op_sel_hi:[1,1,0]         // 00000002DA24: CC20003D 1CF5E708
	v_fma_mix_f32 v63, v9, -1.0, v72 op_sel_hi:[1,1,0]         // 00000002DA2C: CC20003F 1D21E709
	.long 0x7f781547                                           // 00000002DA34: 7F781547
	.long 0x7f103940                                           // 00000002DA38: 7F103940
	v_fma_mix_f32 v71, v66, -1.0, v65 op_sel_hi:[1,1,0]        // 00000002DA3C: CC200047 1D05E742
	v_cvt_f16_f32_e32 v61, v61                                 // 00000002DA44: 7E7A153D
	.long 0x7f7a153e                                           // 00000002DA48: 7F7A153E
	v_cvt_f16_f32_e32 v62, v63                                 // 00000002DA4C: 7E7C153F
	.long 0x7f123942                                           // 00000002DA50: 7F123942
	ds_load_b128 v[63:66], v1 offset:24080                     // 00000002DA54: DBFC5E10 3F000001
	v_mul_u32_u24_e32 v72, 48, v43                             // 00000002DA5C: 169056B0
	.long 0x7f0e3946                                           // 00000002DA60: 7F0E3946
	.long 0x7f0a3944                                           // 00000002DA64: 7F0A3944
	v_mul_f32_e32 v18, v45, v44                                // 00000002DA68: 1024592D
	v_fma_mixlo_f16 v43, v45, v44, 0                           // 00000002DA6C: CC21002B 0202592D
	v_mul_f32_e32 v44, v46, v33                                // 00000002DA74: 1058432E
	v_fma_mixlo_f16 v33, v46, v33, 0                           // 00000002DA78: CC210021 0202432E
	ds_store_b128 v72, v[6:9] offset:19216                     // 00000002DA80: DB7C4B10 00000648
	ds_store_b128 v72, v[2:5] offset:19200                     // 00000002DA88: DB7C4B00 00000248
	ds_load_b128 v[2:5], v1 offset:24096                       // 00000002DA90: DBFC5E20 02000001
	v_dual_mul_f32 v7, v47, v32 :: v_dual_mul_f32 v8, v48, v31 // 00000002DA98: C8C6412F 07083F30
	v_fma_mix_f32 v44, v33, -1.0, v44 op_sel_hi:[1,1,0]        // 00000002DAA0: CC20002C 1CB1E721
	.long 0x7f7c1547                                           // 00000002DAA8: 7F7C1547
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002DAAC: BF870002
	.long 0x7f0c152c                                           // 00000002DAB0: 7F0C152C
	v_fma_mixlo_f16 v44, v47, v32, 0                           // 00000002DAB4: CC21002C 0202412F
	s_waitcnt lgkmcnt(3)                                       // 00000002DABC: BF89FC37
	v_mul_f32_e32 v9, v63, v29                                 // 00000002DAC0: 10123B3F
	v_fma_mix_f32 v18, v43, -1.0, v18 op_sel_hi:[1,1,0]        // 00000002DAC4: CC200012 1C49E72B
	v_fma_mixlo_f16 v45, v63, v29, 0                           // 00000002DACC: CC21002D 02023B3F
	v_fma_mix_f32 v7, v44, -1.0, v7 op_sel_hi:[1,1,0]          // 00000002DAD4: CC200007 1C1DE72C
	v_fma_mixlo_f16 v46, v65, v28, 0                           // 00000002DADC: CC21002E 02023941
	.long 0x7f563921                                           // 00000002DAE4: 7F563921
	v_cvt_f16_f32_e32 v6, v18                                  // 00000002DAE8: 7E0C1512
	v_fma_mixlo_f16 v18, v48, v31, 0                           // 00000002DAEC: CC210012 02023F30
	v_mul_f32_e32 v31, v64, v30                                // 00000002DAF4: 103E3D40
	v_fma_mixlo_f16 v30, v64, v30, 0                           // 00000002DAF8: CC21001E 02023D40
	v_fma_mix_f32 v9, v45, -1.0, v9 op_sel_hi:[1,1,0]          // 00000002DB00: CC200009 1C25E72D
	v_cvt_f16_f32_e32 v7, v7                                   // 00000002DB08: 7E0E1507
	.long 0x7f583912                                           // 00000002DB0C: 7F583912
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002DB10: BF870004
	v_fma_mix_f32 v29, v30, -1.0, v31 op_sel_hi:[1,1,0]        // 00000002DB14: CC20001D 1C7DE71E
	v_mul_f32_e32 v31, v65, v28                                // 00000002DB1C: 103E3941
	v_fma_mix_f32 v8, v18, -1.0, v8 op_sel_hi:[1,1,0]          // 00000002DB20: CC200008 1C21E712
	v_mul_f32_e32 v28, v66, v27                                // 00000002DB28: 10383742
	v_fma_mixlo_f16 v27, v66, v27, 0                           // 00000002DB2C: CC21001B 02023742
	.long 0x7f5a391e                                           // 00000002DB34: 7F5A391E
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002DB38: BF870004
	.long 0x7f0e1508                                           // 00000002DB3C: 7F0E1508
	v_cvt_f16_f32_e32 v8, v9                                   // 00000002DB40: 7E101509
	.long 0x7f10151d                                           // 00000002DB44: 7F10151D
	v_fma_mix_f32 v9, v46, -1.0, v31 op_sel_hi:[1,1,0]         // 00000002DB48: CC200009 1C7DE72E
	s_waitcnt lgkmcnt(0)                                       // 00000002DB50: BF89FC07
	v_mul_f32_e32 v29, v2, v25                                 // 00000002DB54: 103A3302
	v_fma_mixlo_f16 v2, v2, v25, 0                             // 00000002DB58: CC210002 02023302
	v_mul_f32_e32 v25, v3, v23                                 // 00000002DB60: 10322F03
	v_fma_mixlo_f16 v31, v3, v23, 0                            // 00000002DB64: CC21001F 02022F03
	v_fma_mix_f32 v3, v27, -1.0, v28 op_sel_hi:[1,1,0]         // 00000002DB6C: CC200003 1C71E71B
	v_cvt_f16_f32_e32 v9, v9                                   // 00000002DB74: 7E121509
	v_mul_f32_e32 v23, v4, v26                                 // 00000002DB78: 102E3504
	.long 0x7f5c391b                                           // 00000002DB7C: 7F5C391B
	v_fma_mix_f32 v25, v31, -1.0, v25 op_sel_hi:[1,1,0]        // 00000002DB80: CC200019 1C65E71F
	.long 0x7f121503                                           // 00000002DB88: 7F121503
	v_fma_mixlo_f16 v3, v4, v26, 0                             // 00000002DB8C: CC210003 02023504
	v_mul_f32_e32 v26, v11, v22                                // 00000002DB94: 10342D0B
	v_fma_mix_f32 v28, v2, -1.0, v29 op_sel_hi:[1,1,0]         // 00000002DB98: CC20001C 1C75E702
	v_fma_mixlo_f16 v11, v11, v22, 0                           // 00000002DBA0: CC21000B 02022D0B
	.long 0x7f04391f                                           // 00000002DBA8: 7F04391F
	v_fma_mix_f32 v4, v3, -1.0, v23 op_sel_hi:[1,1,0]          // 00000002DBAC: CC200004 1C5DE703
	.long 0x7f2e1519                                           // 00000002DBB4: 7F2E1519
	v_cvt_f16_f32_e32 v23, v28                                 // 00000002DBB8: 7E2E151C
	v_mul_f32_e32 v25, v5, v24                                 // 00000002DBBC: 10323105
	v_fma_mixlo_f16 v28, v5, v24, 0                            // 00000002DBC0: CC21001C 02023105
	v_cvt_f16_f32_e32 v24, v4                                  // 00000002DBC8: 7E301504
	v_mul_f32_e32 v5, v10, v20                                 // 00000002DBCC: 100A290A
	v_fma_mixlo_f16 v4, v10, v20, 0                            // 00000002DBD0: CC210004 0202290A
	v_fma_mix_f32 v20, v11, -1.0, v26 op_sel_hi:[1,1,0]        // 00000002DBD8: CC200014 1C69E70B
	v_fma_mix_f32 v22, v28, -1.0, v25 op_sel_hi:[1,1,0]        // 00000002DBE0: CC200016 1C65E71C
	v_mul_f32_e32 v25, v12, v21                                // 00000002DBE8: 10322B0C
	.long 0x7f06391c                                           // 00000002DBEC: 7F06391C
	v_fma_mix_f32 v10, v4, -1.0, v5 op_sel_hi:[1,1,0]          // 00000002DBF0: CC20000A 1C15E704
	v_fma_mixlo_f16 v5, v12, v21, 0                            // 00000002DBF8: CC210005 02022B0C
	v_mul_f32_e32 v21, v13, v19                                // 00000002DC00: 102A270D
	v_fma_mixlo_f16 v13, v13, v19, 0                           // 00000002DC04: CC21000D 0202270D
	.long 0x7f08390b                                           // 00000002DC0C: 7F08390B
	.long 0x7f301516                                           // 00000002DC10: 7F301516
	v_fma_mix_f32 v12, v5, -1.0, v25 op_sel_hi:[1,1,0]         // 00000002DC14: CC20000C 1C65E705
	v_cvt_f16_f32_e32 v25, v10                                 // 00000002DC1C: 7E32150A
	v_fma_mix_f32 v10, v13, -1.0, v21 op_sel_hi:[1,1,0]        // 00000002DC20: CC20000A 1C55E70D
	.long 0x7f0a390d                                           // 00000002DC28: 7F0A390D
	.long 0x7f321514                                           // 00000002DC2C: 7F321514
	v_cvt_f16_f32_e32 v26, v12                                 // 00000002DC30: 7E34150C
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002DC34: BF870004
	.long 0x7f34150a                                           // 00000002DC38: 7F34150A
	ds_store_b128 v72, v[59:62] offset:19984                   // 00000002DC3C: DB7C4E10 00003B48
	ds_store_b128 v72, v[14:17] offset:19968                   // 00000002DC44: DB7C4E00 00000E48
	ds_store_b128 v72, v[2:5] offset:20752                     // 00000002DC4C: DB7C5110 00000248
	ds_store_b128 v72, v[43:46] offset:20736                   // 00000002DC54: DB7C5100 00002B48
	ds_store_b128 v72, v[23:26] offset:21520                   // 00000002DC5C: DB7C5410 00001748
	ds_store_b128 v72, v[6:9] offset:21504                     // 00000002DC64: DB7C5400 00000648
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002DC6C: 8C7E037E
	v_lshlrev_b32_e32 v59, 1, v153                             // 00000002DC70: 30773281
	s_waitcnt lgkmcnt(0)                                       // 00000002DC74: BF89FC07
	s_barrier                                                  // 00000002DC78: BFBD0000
	v_cmp_eq_u32_e32 vcc_lo, 0, v34                            // 00000002DC7C: 7C944480
	v_mul_u32_u24_e32 v60, 48, v55                             // 00000002DC80: 16786EB0
	s_cmp_lt_i32 s29, s39                                      // 00000002DC84: BF04271D
	ds_load_u16 v2, v59 offset:6416                            // 00000002DC88: D8F01910 0200003B
	ds_load_u16 v3, v59 offset:7776                            // 00000002DC90: D8F01E60 0300003B
	ds_load_u16 v4, v59 offset:7232                            // 00000002DC98: D8F01C40 0400003B
	s_waitcnt lgkmcnt(4)                                       // 00000002DCA0: BF89FC47
	ds_load_u16 v5, v59 offset:6688                            // 00000002DCA4: D8F01A20 0500003B
	s_waitcnt lgkmcnt(4)                                       // 00000002DCAC: BF89FC47
	ds_load_u16 v6, v59 offset:6144                            // 00000002DCB0: D8F01800 0600003B
	ds_load_b128 v[22:25], v60 offset:19984                    // 00000002DCB8: DBFC4E10 1600003C
	ds_load_b128 v[18:21], v60 offset:19968                    // 00000002DCC0: DBFC4E00 1200003C
	ds_load_b128 v[26:29], v60 offset:19200                    // 00000002DCC8: DBFC4B00 1A00003C
	ds_load_b128 v[30:33], v60 offset:19216                    // 00000002DCD0: DBFC4B10 1E00003C
	s_cselect_b32 s3, -1, 0                                    // 00000002DCD8: 980380C1
	s_or_b32 s4, s29, 1                                        // 00000002DCDC: 8C04811D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002DCE0: BF870009
	s_cmp_lt_i32 s4, s39                                       // 00000002DCE4: BF042704
	s_cselect_b32 s4, -1, 0                                    // 00000002DCE8: 980480C1
	s_waitcnt lgkmcnt(8)                                       // 00000002DCEC: BF89FC87
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000002DCF0: 30040490
	s_waitcnt lgkmcnt(4)                                       // 00000002DCF4: BF89FC47
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000002DCF8: 300C0C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000002DCFC: BF8700D2
	.long 0x7f141502                                           // 00000002DD00: 7F141502
	ds_load_u16 v2, v59 offset:6960                            // 00000002DD04: D8F01B30 0200003B
	v_cvt_f16_f32_e32 v10, v6                                  // 00000002DD0C: 7E141506
	s_waitcnt lgkmcnt(0)                                       // 00000002DD10: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000002DD14: 30040490
	.long 0x7f161502                                           // 00000002DD18: 7F161502
	v_lshlrev_b32_e32 v2, 16, v5                               // 00000002DD1C: 30040A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000002DD20: BF8700C1
	v_cvt_f16_f32_e32 v11, v2                                  // 00000002DD24: 7E161502
	ds_load_u16 v2, v59 offset:7504                            // 00000002DD28: D8F01D50 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000002DD30: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000002DD34: 30040490
	.long 0x7f181502                                           // 00000002DD38: 7F181502
	v_lshlrev_b32_e32 v2, 16, v4                               // 00000002DD3C: 30040890
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000002DD40: BF8700C1
	v_cvt_f16_f32_e32 v12, v2                                  // 00000002DD44: 7E181502
	ds_load_u16 v2, v59 offset:8048                            // 00000002DD48: D8F01F70 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000002DD50: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000002DD54: 30040490
	.long 0x7f1a1502                                           // 00000002DD58: 7F1A1502
	v_lshlrev_b32_e32 v2, 16, v3                               // 00000002DD5C: 30040690
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002DD60: BF870001
	v_cvt_f16_f32_e32 v13, v2                                  // 00000002DD64: 7E1A1502
	ds_load_u16 v2, v59 offset:8592                            // 00000002DD68: D8F02190 0200003B
	ds_load_u16 v3, v59 offset:9952                            // 00000002DD70: D8F026E0 0300003B
	ds_load_u16 v4, v59 offset:9408                            // 00000002DD78: D8F024C0 0400003B
	ds_load_u16 v5, v59 offset:8864                            // 00000002DD80: D8F022A0 0500003B
	ds_load_u16 v6, v59 offset:8320                            // 00000002DD88: D8F02080 0600003B
	s_waitcnt lgkmcnt(4)                                       // 00000002DD90: BF89FC47
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000002DD94: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000002DD98: BF8700B1
	.long 0x7f1c1502                                           // 00000002DD9C: 7F1C1502
	s_waitcnt lgkmcnt(0)                                       // 00000002DDA0: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v6                               // 00000002DDA4: 30040C90
	v_cvt_f16_f32_e32 v14, v2                                  // 00000002DDA8: 7E1C1502
	ds_load_u16 v2, v59 offset:9136                            // 00000002DDAC: D8F023B0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000002DDB4: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000002DDB8: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002DDBC: BF8700A1
	.long 0x7f1e1502                                           // 00000002DDC0: 7F1E1502
	v_lshlrev_b32_e32 v2, 16, v5                               // 00000002DDC4: 30040A90
	v_cvt_f16_f32_e32 v15, v2                                  // 00000002DDC8: 7E1E1502
	ds_load_u16 v2, v59 offset:9680                            // 00000002DDCC: D8F025D0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000002DDD4: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000002DDD8: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002DDDC: BF8700A1
	.long 0x7f201502                                           // 00000002DDE0: 7F201502
	v_lshlrev_b32_e32 v2, 16, v4                               // 00000002DDE4: 30040890
	v_cvt_f16_f32_e32 v16, v2                                  // 00000002DDE8: 7E201502
	ds_load_u16 v2, v59 offset:10224                           // 00000002DDEC: D8F027F0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000002DDF4: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000002DDF8: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002DDFC: BF8700A1
	.long 0x7f221502                                           // 00000002DE00: 7F221502
	v_lshlrev_b32_e32 v2, 16, v3                               // 00000002DE04: 30040690
	v_cvt_f16_f32_e32 v17, v2                                  // 00000002DE08: 7E221502
	v_dual_mov_b32 v2, s20 :: v_dual_mov_b32 v3, s21           // 00000002DE0C: CA100014 02020015
	v_dual_mov_b32 v4, s22 :: v_dual_mov_b32 v5, s23           // 00000002DE14: CA100016 04040017
	v_dual_mov_b32 v6, s24 :: v_dual_mov_b32 v7, s25           // 00000002DE1C: CA100018 06060019
	v_dual_mov_b32 v8, s26 :: v_dual_mov_b32 v9, s27           // 00000002DE24: CA10001A 0808001B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002DE2C: BF870121
	v_wmma_f32_16x16x16_f16 v[61:68], v[18:25], v[10:17], v[2:9]// 00000002DE30: CC40403D 1C0A1512
	v_mov_b32_e32 v18, 0                                       // 00000002DE38: 7E240280
	v_wmma_f32_16x16x16_f16 v[61:68], v[26:33], v[10:17], v[61:68]// 00000002DE3C: CC40403D 1CF6151A
	v_dual_mov_b32 v10, 0 :: v_dual_cndmask_b32 v11, 0x7060302, v149// 00000002DE44: CA120080 0A0B2AFF 07060302
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 00000002DE50: CA100080 0C0C0080
	v_mov_b32_e32 v14, 0                                       // 00000002DE58: 7E1C0280
	s_waitcnt vmcnt(7)                                         // 00000002DE5C: BF891FF7
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002DE60: BF870003
	v_mov_b32_dpp v10, v42 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000002DE64: 7E1402FA FF00B12A
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 00000002DE6C: CA100080 0F100080
	v_mov_b32_e32 v17, 0                                       // 00000002DE74: 7E220280
	s_waitcnt vmcnt(6)                                         // 00000002DE78: BF891BF7
	v_mov_b32_dpp v12, v41 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000002DE7C: 7E1802FA FF00B129
	v_perm_b32 v10, v42, v10, v11                              // 00000002DE84: D644000A 042E152A
	s_waitcnt vmcnt(5)                                         // 00000002DE8C: BF8917F7
	v_mov_b32_dpp v13, v40 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000002DE90: 7E1A02FA FF00B128
	s_waitcnt vmcnt(4)                                         // 00000002DE98: BF8913F7
	v_mov_b32_dpp v14, v39 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000002DE9C: 7E1C02FA FF00B127
	s_waitcnt vmcnt(3)                                         // 00000002DEA4: BF890FF7
	v_mov_b32_dpp v15, v38 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000002DEA8: 7E1E02FA FF00B126
	s_waitcnt vmcnt(2)                                         // 00000002DEB0: BF890BF7
	v_mov_b32_dpp v16, v37 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000002DEB4: 7E2002FA FF00B125
	s_waitcnt vmcnt(1)                                         // 00000002DEBC: BF8907F7
	v_mov_b32_dpp v17, v35 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000002DEC0: 7E2202FA FF00B123
	s_waitcnt vmcnt(0)                                         // 00000002DEC8: BF8903F7
	v_mov_b32_dpp v18, v36 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000002DECC: 7E2402FA FF00B124
	v_perm_b32 v12, v41, v12, v11                              // 00000002DED4: D644000C 042E1929
	v_perm_b32 v13, v40, v13, v11                              // 00000002DEDC: D644000D 042E1B28
	v_perm_b32 v14, v39, v14, v11                              // 00000002DEE4: D644000E 042E1D27
	v_perm_b32 v15, v38, v15, v11                              // 00000002DEEC: D644000F 042E1F26
	v_perm_b32 v16, v37, v16, v11                              // 00000002DEF4: D6440010 042E2125
	v_perm_b32 v17, v35, v17, v11                              // 00000002DEFC: D6440011 042E2323
	v_perm_b32 v11, v36, v18, v11                              // 00000002DF04: D644000B 042E2524
	v_lshlrev_b32_e32 v18, 16, v10                             // 00000002DF0C: 30241490
	v_and_b32_e32 v19, 0xffff0000, v10                         // 00000002DF10: 362614FF FFFF0000
	ds_load_b128 v[30:33], v60 offset:21520                    // 00000002DF18: DBFC5410 1E00003C
	ds_load_b128 v[26:29], v60 offset:21504                    // 00000002DF20: DBFC5400 1A00003C
	ds_load_b128 v[38:41], v60 offset:20752                    // 00000002DF28: DBFC5110 2600003C
	ds_load_b128 v[34:37], v60 offset:20736                    // 00000002DF30: DBFC5100 2200003C
	v_cmp_eq_u32_e32 vcc_lo, 0, v154                           // 00000002DF38: 7C953480
	v_cvt_f16_f32_e32 v10, v18                                 // 00000002DF3C: 7E141512
	.long 0x7f141513                                           // 00000002DF40: 7F141513
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002DF44: BF870112
	v_cndmask_b16 v18, 0, v10, s3                              // 00000002DF48: D65D0012 000E1480
	v_cndmask_b16 v18, 0, v10, s4                              // 00000002DF50: D65D5012 00121480
	v_lshlrev_b32_e32 v10, 16, v12                             // 00000002DF58: 30141890
	s_or_b32 s3, s29, 2                                        // 00000002DF5C: 8C03821D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002DF60: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000002DF64: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000002DF68: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000002DF6C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000002DF70: BF870481
	v_cndmask_b16 v19, 0, v10, s3                              // 00000002DF74: D65D0013 000E1480
	v_and_b32_e32 v10, 0xffff0000, v12                         // 00000002DF7C: 361418FF FFFF0000
	s_or_b32 s3, s29, 3                                        // 00000002DF84: 8C03831D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002DF88: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000002DF8C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000002DF90: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000002DF94: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000002DF98: BF870481
	v_cndmask_b16 v19, 0, v10, s3                              // 00000002DF9C: D65D4013 000E1480
	v_lshlrev_b32_e32 v10, 16, v13                             // 00000002DFA4: 30141A90
	s_or_b32 s3, s29, 4                                        // 00000002DFA8: 8C03841D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002DFAC: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000002DFB0: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000002DFB4: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000002DFB8: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000002DFBC: BF870481
	v_cndmask_b16 v20, 0, v10, s3                              // 00000002DFC0: D65D0014 000E1480
	v_and_b32_e32 v10, 0xffff0000, v13                         // 00000002DFC8: 36141AFF FFFF0000
	s_or_b32 s3, s29, 5                                        // 00000002DFD0: 8C03851D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002DFD4: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000002DFD8: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000002DFDC: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000002DFE0: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000002DFE4: BF870481
	v_cndmask_b16 v20, 0, v10, s3                              // 00000002DFE8: D65D4014 000E1480
	v_lshlrev_b32_e32 v10, 16, v14                             // 00000002DFF0: 30141C90
	s_or_b32 s3, s29, 6                                        // 00000002DFF4: 8C03861D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002DFF8: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000002DFFC: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000002E000: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000002E004: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000002E008: BF870481
	v_cndmask_b16 v21, 0, v10, s3                              // 00000002E00C: D65D0015 000E1480
	v_and_b32_e32 v10, 0xffff0000, v14                         // 00000002E014: 36141CFF FFFF0000
	s_or_b32 s3, s29, 7                                        // 00000002E01C: 8C03871D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E020: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000002E024: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000002E028: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000002E02C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000002E030: BF870481
	v_cndmask_b16 v21, 0, v10, s3                              // 00000002E034: D65D4015 000E1480
	v_lshlrev_b32_e32 v10, 16, v15                             // 00000002E03C: 30141E90
	s_or_b32 s3, s29, 8                                        // 00000002E040: 8C03881D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E044: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000002E048: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000002E04C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000002E050: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000002E054: BF870481
	v_cndmask_b16 v22, 0, v10, s3                              // 00000002E058: D65D0016 000E1480
	v_and_b32_e32 v10, 0xffff0000, v15                         // 00000002E060: 36141EFF FFFF0000
	s_or_b32 s3, s29, 9                                        // 00000002E068: 8C03891D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E06C: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000002E070: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000002E074: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000002E078: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000002E07C: BF870481
	v_cndmask_b16 v22, 0, v10, s3                              // 00000002E080: D65D4016 000E1480
	v_lshlrev_b32_e32 v10, 16, v16                             // 00000002E088: 30142090
	s_or_b32 s3, s29, 10                                       // 00000002E08C: 8C038A1D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E090: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000002E094: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000002E098: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000002E09C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000002E0A0: BF870481
	v_cndmask_b16 v23, 0, v10, s3                              // 00000002E0A4: D65D0017 000E1480
	v_and_b32_e32 v10, 0xffff0000, v16                         // 00000002E0AC: 361420FF FFFF0000
	s_or_b32 s3, s29, 11                                       // 00000002E0B4: 8C038B1D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E0B8: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000002E0BC: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000002E0C0: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000002E0C4: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000002E0C8: BF870481
	v_cndmask_b16 v23, 0, v10, s3                              // 00000002E0CC: D65D4017 000E1480
	v_lshlrev_b32_e32 v10, 16, v17                             // 00000002E0D4: 30142290
	s_or_b32 s3, s29, 12                                       // 00000002E0D8: 8C038C1D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E0DC: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000002E0E0: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000002E0E4: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000002E0E8: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000002E0EC: BF870481
	v_cndmask_b16 v24, 0, v10, s3                              // 00000002E0F0: D65D0018 000E1480
	v_and_b32_e32 v10, 0xffff0000, v17                         // 00000002E0F8: 361422FF FFFF0000
	s_or_b32 s3, s29, 13                                       // 00000002E100: 8C038D1D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E104: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000002E108: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000002E10C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000002E110: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000002E114: BF870481
	v_cndmask_b16 v24, 0, v10, s3                              // 00000002E118: D65D4018 000E1480
	v_lshlrev_b32_e32 v10, 16, v11                             // 00000002E120: 30141690
	s_or_b32 s3, s29, 14                                       // 00000002E124: 8C038E1D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E128: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000002E12C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000002E130: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000002E134: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000002E138: BF870481
	v_cndmask_b16 v25, 0, v10, s3                              // 00000002E13C: D65D0019 000E1480
	v_and_b32_e32 v10, 0xffff0000, v11                         // 00000002E144: 361416FF FFFF0000
	s_or_b32 s3, s29, 15                                       // 00000002E14C: 8C038F1D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E150: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000002E154: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000002E158: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000002E15C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000002E160: BF870481
	v_cndmask_b16 v25, 0, v10, s3                              // 00000002E164: D65D4019 000E1480
	s_waitcnt lgkmcnt(2)                                       // 00000002E16C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002E170: BF8700A1
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[18:25], v[2:9]// 00000002E174: CC40400A 1C0A251A
	s_waitcnt lgkmcnt(0)                                       // 00000002E17C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[34:41], v[18:25], v[10:17]// 00000002E180: CC40400A 1C2A2522
	v_cvt_f16_f32_e32 v18, v61                                 // 00000002E188: 7E24153D
	v_mad_u32_u24 v22, 0x110, v154, v59                        // 00000002E18C: D60B0016 04EF34FF 00000110
	.long 0x7f24153e                                           // 00000002E198: 7F24153E
	v_cvt_f16_f32_e32 v19, v63                                 // 00000002E19C: 7E26153F
	.long 0x7f261540                                           // 00000002E1A0: 7F261540
	v_cvt_f16_f32_e32 v20, v65                                 // 00000002E1A4: 7E281541
	.long 0x7f281542                                           // 00000002E1A8: 7F281542
	v_cvt_f16_f32_e32 v21, v67                                 // 00000002E1AC: 7E2A1543
	.long 0x7f2a1544                                           // 00000002E1B0: 7F2A1544
	ds_store_b16 v22, v18 offset:14848                         // 00000002E1B4: D87C3A00 00001216
	ds_store_b16_d16_hi v22, v18 offset:15392                  // 00000002E1BC: DA843C20 00001216
	ds_store_b16 v22, v19 offset:15936                         // 00000002E1C4: D87C3E40 00001316
	ds_store_b16_d16_hi v22, v19 offset:16480                  // 00000002E1CC: DA844060 00001316
	ds_store_b16 v22, v20 offset:17024                         // 00000002E1D4: D87C4280 00001416
	ds_store_b16_d16_hi v22, v20 offset:17568                  // 00000002E1DC: DA8444A0 00001416
	ds_store_b16 v22, v21 offset:18112                         // 00000002E1E4: D87C46C0 00001516
	ds_store_b16_d16_hi v22, v21 offset:18656                  // 00000002E1EC: DA8448E0 00001516
	v_fma_mixlo_f16 v18, v139, s51, 0                          // 00000002E1F4: CC210012 0200678B
	v_fma_mixhi_f16 v18, v138, s51, 0                          // 00000002E1FC: CC220012 0200678A
	v_mov_b32_e32 v20, 0x3020706                               // 00000002E204: 7E2802FF 03020706
	v_cndmask_b32_e32 v61, 0x5040100, v149, vcc_lo             // 00000002E20C: 027B2AFF 05040100
	s_waitcnt lgkmcnt(0)                                       // 00000002E214: BF89FC07
	s_barrier                                                  // 00000002E218: BFBD0000
	ds_load_b128 v[46:49], v57 offset:14864                    // 00000002E21C: DBFC3A10 2E000039
	ds_load_b128 v[42:45], v57 offset:14848                    // 00000002E224: DBFC3A00 2A000039
	ds_load_b128 v[67:70], v57 offset:14896                    // 00000002E22C: DBFC3A30 43000039
	ds_load_b128 v[63:66], v57 offset:14880                    // 00000002E234: DBFC3A20 3F000039
	v_dual_mov_b32 v19, v18 :: v_dual_cndmask_b32 v62, 0x7060302, v20// 00000002E23C: CA120112 133E28FF 07060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E248: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000002E24C: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v26, v18, v19, v61                              // 00000002E258: D644001A 04F62712
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000002E260: BF8700B3
	v_perm_b32 v27, v18, v19, v62                              // 00000002E264: D644001B 04FA2712
	v_fma_mixlo_f16 v18, v137, s51, 0                          // 00000002E26C: CC210012 02006789
	v_fma_mixhi_f16 v18, v136, s51, 0                          // 00000002E274: CC220012 02006788
	v_mov_b32_e32 v19, v18                                     // 00000002E27C: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E280: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000002E284: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v28, v18, v19, v61                              // 00000002E290: D644001C 04F62712
	v_perm_b32 v29, v18, v19, v62                              // 00000002E298: D644001D 04FA2712
	v_fma_mixlo_f16 v18, v135, s51, 0                          // 00000002E2A0: CC210012 02006787
	v_fma_mixhi_f16 v18, v134, s51, 0                          // 00000002E2A8: CC220012 02006786
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E2B0: BF870091
	v_mov_b32_e32 v19, v18                                     // 00000002E2B4: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000002E2B8: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000002E2C4: BF8700C1
	v_perm_b32 v30, v18, v19, v61                              // 00000002E2C8: D644001E 04F62712
	v_perm_b32 v31, v18, v19, v62                              // 00000002E2D0: D644001F 04FA2712
	v_fma_mixlo_f16 v18, v133, s51, 0                          // 00000002E2D8: CC210012 02006785
	v_fma_mixhi_f16 v18, v54, s51, 0                           // 00000002E2E0: CC220012 02006736
	v_mov_b32_e32 v19, v18                                     // 00000002E2E8: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E2EC: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000002E2F0: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v32, v18, v19, v61                              // 00000002E2FC: D6440020 04F62712
	v_perm_b32 v33, v18, v19, v62                              // 00000002E304: D6440021 04FA2712
	v_fma_mixlo_f16 v18, v132, s51, 0                          // 00000002E30C: CC210012 02006784
	v_fma_mixhi_f16 v18, v131, s51, 0                          // 00000002E314: CC220012 02006783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E31C: BF870091
	v_mov_b32_e32 v19, v18                                     // 00000002E320: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000002E324: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000002E330: BF8700C1
	v_perm_b32 v34, v18, v19, v61                              // 00000002E334: D6440022 04F62712
	v_perm_b32 v35, v18, v19, v62                              // 00000002E33C: D6440023 04FA2712
	v_fma_mixlo_f16 v18, v130, s51, 0                          // 00000002E344: CC210012 02006782
	v_fma_mixhi_f16 v18, v129, s51, 0                          // 00000002E34C: CC220012 02006781
	v_mov_b32_e32 v19, v18                                     // 00000002E354: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E358: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000002E35C: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v36, v18, v19, v61                              // 00000002E368: D6440024 04F62712
	v_perm_b32 v37, v18, v19, v62                              // 00000002E370: D6440025 04FA2712
	v_fma_mixlo_f16 v18, v128, s51, 0                          // 00000002E378: CC210012 02006780
	v_fma_mixhi_f16 v18, v127, s51, 0                          // 00000002E380: CC220012 0200677F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E388: BF870091
	v_mov_b32_e32 v19, v18                                     // 00000002E38C: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000002E390: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000002E39C: BF8700C1
	v_perm_b32 v38, v18, v19, v61                              // 00000002E3A0: D6440026 04F62712
	v_perm_b32 v39, v18, v19, v62                              // 00000002E3A8: D6440027 04FA2712
	v_fma_mixlo_f16 v18, v126, s51, 0                          // 00000002E3B0: CC210012 0200677E
	v_fma_mixhi_f16 v18, v53, s51, 0                           // 00000002E3B8: CC220012 02006735
	v_mov_b32_e32 v19, v18                                     // 00000002E3C0: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E3C4: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000002E3C8: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v40, v18, v19, v61                              // 00000002E3D4: D6440028 04F62712
	v_perm_b32 v41, v18, v19, v62                              // 00000002E3DC: D6440029 04FA2712
	s_waitcnt lgkmcnt(2)                                       // 00000002E3E4: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[26:33], v[2:9]// 00000002E3E8: CC404012 1C0A352A
	s_waitcnt lgkmcnt(0)                                       // 00000002E3F0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002E3F4: BF870001
	v_wmma_f32_16x16x16_f16 v[18:25], v[63:70], v[34:41], v[18:25]// 00000002E3F8: CC404012 1C4A453F
	ds_load_b128 v[63:66], v57 offset:10496                    // 00000002E400: DBFC2900 3F000039
	ds_load_b128 v[67:70], v57 offset:10512                    // 00000002E408: DBFC2910 43000039
	s_waitcnt lgkmcnt(0)                                       // 00000002E410: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[63:70], v[26:33], v[2:9]// 00000002E414: CC40402A 1C0A353F
	ds_load_b128 v[26:29], v57 offset:10528                    // 00000002E41C: DBFC2920 1A000039
	ds_load_b128 v[30:33], v57 offset:10544                    // 00000002E424: DBFC2930 1E000039
	s_waitcnt lgkmcnt(0)                                       // 00000002E42C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[26:33], v[34:41], v[42:49]// 00000002E430: CC40402A 1CAA451A
	v_fma_mixlo_f16 v27, v125, s51, 0                          // 00000002E438: CC21001B 0200677D
	v_fma_mixhi_f16 v27, v124, s51, 0                          // 00000002E440: CC22001B 0200677C
	v_fma_mixlo_f16 v29, v123, s51, 0                          // 00000002E448: CC21001D 0200677B
	v_fma_mixhi_f16 v29, v122, s51, 0                          // 00000002E450: CC22001D 0200677A
	v_fma_mixlo_f16 v31, v121, s51, 0                          // 00000002E458: CC21001F 02006779
	v_fma_mixhi_f16 v31, v120, s51, 0                          // 00000002E460: CC22001F 02006778
	v_fma_mixlo_f16 v33, v119, s51, 0                          // 00000002E468: CC210021 02006777
	v_fma_mixhi_f16 v33, v52, s51, 0                           // 00000002E470: CC220021 02006734
	v_mov_b32_e32 v28, v27                                     // 00000002E478: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000002E47C: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000002E480: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E484: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000002E488: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000002E48C: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E498: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000002E49C: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000002E4A8: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E4B4: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000002E4B8: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000002E4C4: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000002E4CC: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000002E4D4: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000002E4DC: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000002E4E4: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000002E4EC: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000002E4F4: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000002E4FC: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14928                    // 00000002E504: DBFC3A50 26000039
	ds_load_b128 v[34:37], v57 offset:14912                    // 00000002E50C: DBFC3A40 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000002E514: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000002E518: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10576                    // 00000002E520: DBFC2950 26000039
	ds_load_b128 v[34:37], v57 offset:10560                    // 00000002E528: DBFC2940 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000002E530: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000002E534: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v118, s51, 0                          // 00000002E53C: CC21001B 02006776
	v_fma_mixhi_f16 v27, v117, s51, 0                          // 00000002E544: CC22001B 02006775
	v_fma_mixlo_f16 v29, v116, s51, 0                          // 00000002E54C: CC21001D 02006774
	v_fma_mixhi_f16 v29, v115, s51, 0                          // 00000002E554: CC22001D 02006773
	v_fma_mixlo_f16 v31, v114, s51, 0                          // 00000002E55C: CC21001F 02006772
	v_fma_mixhi_f16 v31, v113, s51, 0                          // 00000002E564: CC22001F 02006771
	v_fma_mixlo_f16 v33, v112, s51, 0                          // 00000002E56C: CC210021 02006770
	v_fma_mixhi_f16 v33, v51, s51, 0                           // 00000002E574: CC220021 02006733
	v_mov_b32_e32 v28, v27                                     // 00000002E57C: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000002E580: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000002E584: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E588: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000002E58C: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000002E590: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E59C: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000002E5A0: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000002E5AC: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E5B8: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000002E5BC: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000002E5C8: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000002E5D0: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000002E5D8: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000002E5E0: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000002E5E8: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000002E5F0: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000002E5F8: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000002E600: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14960                    // 00000002E608: DBFC3A70 26000039
	ds_load_b128 v[34:37], v57 offset:14944                    // 00000002E610: DBFC3A60 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000002E618: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000002E61C: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10608                    // 00000002E624: DBFC2970 26000039
	ds_load_b128 v[34:37], v57 offset:10592                    // 00000002E62C: DBFC2960 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000002E634: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000002E638: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v111, s51, 0                          // 00000002E640: CC21001B 0200676F
	v_fma_mixhi_f16 v27, v110, s51, 0                          // 00000002E648: CC22001B 0200676E
	v_fma_mixlo_f16 v29, v109, s51, 0                          // 00000002E650: CC21001D 0200676D
	v_fma_mixhi_f16 v29, v108, s51, 0                          // 00000002E658: CC22001D 0200676C
	v_fma_mixlo_f16 v31, v107, s51, 0                          // 00000002E660: CC21001F 0200676B
	v_fma_mixhi_f16 v31, v106, s51, 0                          // 00000002E668: CC22001F 0200676A
	v_fma_mixlo_f16 v33, v105, s51, 0                          // 00000002E670: CC210021 02006769
	v_fma_mixhi_f16 v33, v50, s51, 0                           // 00000002E678: CC220021 02006732
	v_mov_b32_e32 v28, v27                                     // 00000002E680: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000002E684: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000002E688: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E68C: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000002E690: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000002E694: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E6A0: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000002E6A4: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000002E6B0: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E6BC: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000002E6C0: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000002E6CC: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000002E6D4: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000002E6DC: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000002E6E4: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000002E6EC: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000002E6F4: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000002E6FC: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000002E704: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14992                    // 00000002E70C: DBFC3A90 26000039
	ds_load_b128 v[34:37], v57 offset:14976                    // 00000002E714: DBFC3A80 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000002E71C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000002E720: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10640                    // 00000002E728: DBFC2990 26000039
	ds_load_b128 v[34:37], v57 offset:10624                    // 00000002E730: DBFC2980 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000002E738: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000002E73C: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v104, s51, 0                          // 00000002E744: CC21001B 02006768
	v_fma_mixhi_f16 v27, v103, s51, 0                          // 00000002E74C: CC22001B 02006767
	v_fma_mixlo_f16 v29, v102, s51, 0                          // 00000002E754: CC21001D 02006766
	v_fma_mixhi_f16 v29, v101, s51, 0                          // 00000002E75C: CC22001D 02006765
	v_fma_mixlo_f16 v31, v100, s51, 0                          // 00000002E764: CC21001F 02006764
	v_fma_mixhi_f16 v31, v99, s51, 0                           // 00000002E76C: CC22001F 02006763
	v_fma_mixlo_f16 v33, v98, s51, 0                           // 00000002E774: CC210021 02006762
	v_fma_mixhi_f16 v33, v58, s51, 0                           // 00000002E77C: CC220021 0200673A
	v_mov_b32_e32 v28, v27                                     // 00000002E784: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000002E788: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000002E78C: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E790: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000002E794: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000002E798: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E7A4: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000002E7A8: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000002E7B4: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E7C0: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000002E7C4: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000002E7D0: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000002E7D8: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000002E7E0: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000002E7E8: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000002E7F0: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000002E7F8: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000002E800: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000002E808: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15024                    // 00000002E810: DBFC3AB0 26000039
	ds_load_b128 v[34:37], v57 offset:15008                    // 00000002E818: DBFC3AA0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000002E820: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000002E824: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10672                    // 00000002E82C: DBFC29B0 26000039
	ds_load_b128 v[34:37], v57 offset:10656                    // 00000002E834: DBFC29A0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000002E83C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000002E840: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v97, s51, 0                           // 00000002E848: CC21001B 02006761
	v_fma_mixhi_f16 v27, v96, s51, 0                           // 00000002E850: CC22001B 02006760
	v_fma_mixlo_f16 v29, v95, s51, 0                           // 00000002E858: CC21001D 0200675F
	v_fma_mixhi_f16 v29, v94, s51, 0                           // 00000002E860: CC22001D 0200675E
	v_fma_mixlo_f16 v31, v93, s51, 0                           // 00000002E868: CC21001F 0200675D
	v_fma_mixhi_f16 v31, v92, s51, 0                           // 00000002E870: CC22001F 0200675C
	v_fma_mixlo_f16 v33, v91, s51, 0                           // 00000002E878: CC210021 0200675B
	v_fma_mixhi_f16 v33, v152, s51, 0                          // 00000002E880: CC220021 02006798
	v_mov_b32_e32 v28, v27                                     // 00000002E888: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000002E88C: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000002E890: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E894: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000002E898: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000002E89C: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E8A8: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000002E8AC: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000002E8B8: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E8C4: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000002E8C8: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000002E8D4: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000002E8DC: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000002E8E4: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000002E8EC: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000002E8F4: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000002E8FC: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000002E904: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000002E90C: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15056                    // 00000002E914: DBFC3AD0 26000039
	ds_load_b128 v[34:37], v57 offset:15040                    // 00000002E91C: DBFC3AC0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000002E924: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000002E928: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10704                    // 00000002E930: DBFC29D0 26000039
	ds_load_b128 v[34:37], v57 offset:10688                    // 00000002E938: DBFC29C0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000002E940: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000002E944: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v90, s51, 0                           // 00000002E94C: CC21001B 0200675A
	v_fma_mixhi_f16 v27, v141, s51, 0                          // 00000002E954: CC22001B 0200678D
	v_fma_mixlo_f16 v29, v150, s51, 0                          // 00000002E95C: CC21001D 02006796
	v_fma_mixhi_f16 v29, v142, s51, 0                          // 00000002E964: CC22001D 0200678E
	v_fma_mixlo_f16 v31, v191, s51, 0                          // 00000002E96C: CC21001F 020067BF
	v_fma_mixhi_f16 v31, v189, s51, 0                          // 00000002E974: CC22001F 020067BD
	v_fma_mixlo_f16 v33, v190, s51, 0                          // 00000002E97C: CC210021 020067BE
	v_fma_mixhi_f16 v33, v151, s51, 0                          // 00000002E984: CC220021 02006797
	v_mov_b32_e32 v28, v27                                     // 00000002E98C: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000002E990: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000002E994: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E998: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000002E99C: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000002E9A0: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E9AC: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000002E9B0: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000002E9BC: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E9C8: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000002E9CC: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000002E9D8: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000002E9E0: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000002E9E8: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000002E9F0: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000002E9F8: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000002EA00: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000002EA08: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000002EA10: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15088                    // 00000002EA18: DBFC3AF0 26000039
	ds_load_b128 v[34:37], v57 offset:15072                    // 00000002EA20: DBFC3AE0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000002EA28: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000002EA2C: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10736                    // 00000002EA34: DBFC29F0 26000039
	ds_load_b128 v[34:37], v57 offset:10720                    // 00000002EA3C: DBFC29E0 22000039
	v_dual_mul_f32 v18, 0x3b800000, v18 :: v_dual_mul_f32 v19, 0x3b800000, v19// 00000002EA44: C8C624FF 121226FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v20 :: v_dual_mul_f32 v21, 0x3b800000, v21// 00000002EA50: C8C628FF 14142AFF 3B800000
	v_mul_f32_e32 v22, 0x3b800000, v22                         // 00000002EA5C: 102C2CFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002EA64: BF870223
	v_sub_f32_e32 v10, v10, v18                                // 00000002EA68: 0814250A
	v_or_b32_e32 v18, s29, v154                                // 00000002EA6C: 3825341D
	v_dual_sub_f32 v11, v11, v19 :: v_dual_sub_f32 v12, v12, v20// 00000002EA70: C94A270B 0B0C290C
	v_sub_f32_e32 v13, v13, v21                                // 00000002EA78: 081A2B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002EA7C: BF870214
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 00000002EA80: CC21000A 0200610A
	v_or_b32_e32 v19, 2, v18                                   // 00000002EA88: 38262482
	.long 0xd4440003                                           // 00000002EA8C: D4440003
	v_cndmask_b32_e32 v1, s39, v18, vcc_lo                     // 00000002EA90: 02022427
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 00000002EA94: CC22000A 0200610B
	v_dual_mul_f32 v23, 0x3b800000, v23 :: v_dual_sub_f32 v14, v14, v22// 00000002EA9C: C8CA2EFF 170E2D0E 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002EAA8: BF870214
	v_cmp_gt_i32_e32 vcc_lo, s39, v19                          // 00000002EAAC: 7C882627
	v_cndmask_b16 v10, 0, v10, s3                              // 00000002EAB0: D65D000A 000E1480
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000002EAB8: BF8701D3
	v_dual_mul_f32 v24, 0x3b800000, v24 :: v_dual_sub_f32 v15, v15, v23// 00000002EABC: C8CA30FF 180E2F0F 3B800000
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 00000002EAC8: 103232FF 3B800000
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000002EAD0: D65D500A 01AA1480
	s_waitcnt lgkmcnt(0)                                       // 00000002EAD8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000002EADC: CC40402A 1CAA3522
	v_dual_sub_f32 v16, v16, v24 :: v_dual_sub_f32 v17, v17, v25// 00000002EAE4: C94A3110 10103311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000002EAEC: BF8700C3
	v_mov_b32_e32 v11, v10                                     // 00000002EAF0: 7E16030A
	ds_load_b128 v[19:22], v60 offset:23296                    // 00000002EAF4: DBFC5B00 1300003C
	ds_load_b128 v[23:26], v60 offset:23312                    // 00000002EAFC: DBFC5B10 1700003C
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000002EB04: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v66, v10, v11, v61                              // 00000002EB10: D6440042 04F6170A
	v_perm_b32 v67, v10, v11, v62                              // 00000002EB18: D6440043 04FA170A
	v_or_b32_e32 v10, 4, v18                                   // 00000002EB20: 38142484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002EB24: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 00000002EB28: 7C881427
	v_or_b32_e32 v10, 6, v18                                   // 00000002EB2C: 38142486
	.long 0xd4440004                                           // 00000002EB30: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 00000002EB34: 02021427
	v_fma_mixlo_f16 v10, v12, s48, 0                           // 00000002EB38: CC21000A 0200610C
	v_fma_mixhi_f16 v10, v13, s48, 0                           // 00000002EB40: CC22000A 0200610D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002EB48: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000002EB4C: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s4                              // 00000002EB54: D65D500A 00121480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EB5C: BF870091
	v_mov_b32_e32 v11, v10                                     // 00000002EB60: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000002EB64: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000002EB70: BF8700B1
	v_perm_b32 v68, v10, v11, v61                              // 00000002EB74: D6440044 04F6170A
	v_perm_b32 v69, v10, v11, v62                              // 00000002EB7C: D6440045 04FA170A
	v_or_b32_e32 v10, 8, v18                                   // 00000002EB84: 38142488
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 00000002EB88: 7C881427
	v_or_b32_e32 v10, 10, v18                                  // 00000002EB8C: 3814248A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000002EB90: BF870131
	.long 0xd4440004                                           // 00000002EB94: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 00000002EB98: 02021427
	v_fma_mixlo_f16 v10, v14, s48, 0                           // 00000002EB9C: CC21000A 0200610E
	v_fma_mixhi_f16 v10, v15, s48, 0                           // 00000002EBA4: CC22000A 0200610F
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000002EBAC: D65D000A 01AA1480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EBB4: BF870092
	v_cndmask_b16 v10, 0, v10, s4                              // 00000002EBB8: D65D500A 00121480
	v_mov_b32_e32 v11, v10                                     // 00000002EBC0: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EBC4: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000002EBC8: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v70, v10, v11, v61                              // 00000002EBD4: D6440046 04F6170A
	v_perm_b32 v71, v10, v11, v62                              // 00000002EBDC: D6440047 04FA170A
	v_or_b32_e32 v10, 12, v18                                  // 00000002EBE4: 3814248C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002EBE8: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 00000002EBEC: 7C881427
	v_or_b32_e32 v10, 14, v18                                  // 00000002EBF0: 3814248E
	.long 0xd4440004                                           // 00000002EBF4: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 00000002EBF8: 02021427
	v_fma_mixlo_f16 v10, v16, s48, 0                           // 00000002EBFC: CC21000A 02006110
	v_fma_mixhi_f16 v10, v17, s48, 0                           // 00000002EC04: CC22000A 02006111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002EC0C: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000002EC10: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s4                              // 00000002EC18: D65D500A 00121480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EC20: BF870091
	v_mov_b32_e32 v11, v10                                     // 00000002EC24: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000002EC28: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000002EC34: BF8700B1
	v_perm_b32 v72, v10, v11, v61                              // 00000002EC38: D6440048 04F6170A
	v_perm_b32 v73, v10, v11, v62                              // 00000002EC40: D6440049 04FA170A
	s_waitcnt lgkmcnt(0)                                       // 00000002EC48: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[19:26], v[66:73], v[2:9]// 00000002EC4C: CC40400A 1C0A8513
	.long 0xd7000402                                           // 00000002EC54: D7000402
	v_cndmask_b32_e32 v1, s44, v59, vcc_lo                     // 00000002EC58: 0202762C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EC5C: BF870001
	v_add_co_ci_u32_e64 v3, null, s45, 0, s4                   // 00000002EC60: D5207C03 0011002D
	s_and_saveexec_b32 s4, s3                                  // 00000002EC68: BE842003
	s_cbranch_execz 19                                         // 00000002EC6C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3cbc>
	ds_load_b32 v4, v56 offset:24320                           // 00000002EC70: D8D85F00 04000038
	s_waitcnt lgkmcnt(0)                                       // 00000002EC78: BF89FC07
	v_mul_f32_e32 v4, v42, v4                                  // 00000002EC7C: 1008092A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EC80: BF870091
	v_add_f32_e32 v4, v10, v4                                  // 00000002EC84: 0608090A
	v_mul_f32_e32 v6, 0x3b800000, v4                           // 00000002EC88: 100C08FF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v18, v[2:3]            // 00000002EC90: D6FE7C04 040A24FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EC9C: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000002ECA0: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000002ECA8: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000002ECB4: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s4                              // 00000002ECBC: 8C7E047E
	v_or3_b32 v4, v154, s29, 2                                 // 00000002ECC0: D6580004 02083B9A
	s_mov_b32 s3, exec_lo                                      // 00000002ECC8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002ECCC: BF870001
	.long 0xd4c4007e                                           // 00000002ECD0: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000002ECD4: 02020827
	s_cbranch_execz 19                                         // 00000002ECD8: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d28>
	ds_load_b32 v5, v56 offset:24328                           // 00000002ECDC: D8D85F08 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000002ECE4: BF89FC07
	v_mul_f32_e32 v5, v43, v5                                  // 00000002ECE8: 100A0B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002ECEC: BF870091
	v_add_f32_e32 v5, v11, v5                                  // 00000002ECF0: 060A0B0B
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000002ECF4: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000002ECFC: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002ED08: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000002ED0C: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000002ED14: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000002ED20: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002ED28: 8C7E037E
	v_or3_b32 v4, v154, s29, 4                                 // 00000002ED2C: D6580004 02103B9A
	s_mov_b32 s3, exec_lo                                      // 00000002ED34: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002ED38: BF870001
	.long 0xd4c4007e                                           // 00000002ED3C: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000002ED40: 02020827
	s_cbranch_execz 19                                         // 00000002ED44: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d94>
	ds_load_b32 v5, v56 offset:24336                           // 00000002ED48: D8D85F10 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000002ED50: BF89FC07
	v_mul_f32_e32 v5, v44, v5                                  // 00000002ED54: 100A0B2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002ED58: BF870091
	v_add_f32_e32 v5, v12, v5                                  // 00000002ED5C: 060A0B0C
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000002ED60: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000002ED68: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002ED74: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000002ED78: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000002ED80: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000002ED8C: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002ED94: 8C7E037E
	v_or3_b32 v4, v154, s29, 6                                 // 00000002ED98: D6580004 02183B9A
	s_mov_b32 s3, exec_lo                                      // 00000002EDA0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EDA4: BF870001
	.long 0xd4c4007e                                           // 00000002EDA8: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000002EDAC: 02020827
	s_cbranch_execz 19                                         // 00000002EDB0: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3e00>
	ds_load_b32 v5, v56 offset:24344                           // 00000002EDB4: D8D85F18 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000002EDBC: BF89FC07
	v_mul_f32_e32 v5, v45, v5                                  // 00000002EDC0: 100A0B2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EDC4: BF870091
	v_add_f32_e32 v5, v13, v5                                  // 00000002EDC8: 060A0B0D
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000002EDCC: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000002EDD4: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EDE0: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000002EDE4: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000002EDEC: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000002EDF8: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002EE00: 8C7E037E
	v_or3_b32 v4, v154, s29, 8                                 // 00000002EE04: D6580004 02203B9A
	s_mov_b32 s3, exec_lo                                      // 00000002EE0C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EE10: BF870001
	.long 0xd4c4007e                                           // 00000002EE14: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000002EE18: 02020827
	s_cbranch_execz 19                                         // 00000002EE1C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3e6c>
	ds_load_b32 v5, v56 offset:24352                           // 00000002EE20: D8D85F20 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000002EE28: BF89FC07
	v_mul_f32_e32 v5, v46, v5                                  // 00000002EE2C: 100A0B2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EE30: BF870091
	v_add_f32_e32 v5, v14, v5                                  // 00000002EE34: 060A0B0E
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000002EE38: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000002EE40: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EE4C: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000002EE50: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000002EE58: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000002EE64: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002EE6C: 8C7E037E
	v_or3_b32 v4, v154, s29, 10                                // 00000002EE70: D6580004 02283B9A
	s_mov_b32 s3, exec_lo                                      // 00000002EE78: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EE7C: BF870001
	.long 0xd4c4007e                                           // 00000002EE80: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000002EE84: 02020827
	s_cbranch_execz 19                                         // 00000002EE88: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3ed8>
	ds_load_b32 v5, v56 offset:24360                           // 00000002EE8C: D8D85F28 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000002EE94: BF89FC07
	v_mul_f32_e32 v5, v47, v5                                  // 00000002EE98: 100A0B2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EE9C: BF870091
	v_add_f32_e32 v5, v15, v5                                  // 00000002EEA0: 060A0B0F
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000002EEA4: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000002EEAC: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EEB8: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000002EEBC: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000002EEC4: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000002EED0: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002EED8: 8C7E037E
	v_or3_b32 v4, v154, s29, 12                                // 00000002EEDC: D6580004 02303B9A
	s_mov_b32 s3, exec_lo                                      // 00000002EEE4: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EEE8: BF870001
	.long 0xd4c4007e                                           // 00000002EEEC: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000002EEF0: 02020827
	s_cbranch_execz 19                                         // 00000002EEF4: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3f44>
	ds_load_b32 v5, v56 offset:24368                           // 00000002EEF8: D8D85F30 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000002EF00: BF89FC07
	v_mul_f32_e32 v5, v48, v5                                  // 00000002EF04: 100A0B30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EF08: BF870091
	v_add_f32_e32 v5, v16, v5                                  // 00000002EF0C: 060A0B10
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000002EF10: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000002EF18: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EF24: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000002EF28: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000002EF30: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000002EF3C: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002EF44: 8C7E037E
	v_or3_b32 v4, v154, s29, 14                                // 00000002EF48: D6580004 02383B9A
	s_mov_b32 s3, exec_lo                                      // 00000002EF50: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EF54: BF870001
	.long 0xd4c4007e                                           // 00000002EF58: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000002EF5C: 02020827
	s_cbranch_execz 19                                         // 00000002EF60: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3fb0>
	ds_load_b32 v5, v56 offset:24376                           // 00000002EF64: D8D85F38 05000038
	v_mad_u64_u32 v[2:3], null, 0x3000, v4, v[2:3]             // 00000002EF6C: D6FE7C02 040A08FF 00003000
	s_waitcnt lgkmcnt(0)                                       // 00000002EF78: BF89FC07
	v_mul_f32_e32 v5, v49, v5                                  // 00000002EF7C: 100A0B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EF80: BF870091
	v_add_f32_e32 v5, v17, v5                                  // 00000002EF84: 060A0B11
	v_mul_f32_e32 v5, 0x3b800000, v5                           // 00000002EF88: 100A0AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EF90: BF870091
	v_bfe_u32 v6, v5, 16, 1                                    // 00000002EF94: D6100006 02052105
	v_add3_u32 v4, v5, v6, 0x7fff                              // 00000002EF9C: D6550004 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000002EFA8: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000002EFB0: 8C7E037E
	ds_load_b32 v56, v1 offset:24188                           // 00000002EFB4: D8D85E7C 38000001
	v_mad_u32_u24 v2, v55, 48, 0x4b00                          // 00000002EFBC: D60B0002 03FD6137 00004B00
	s_add_i32 s29, s29, 16                                     // 00000002EFC8: 811D901D
	v_mov_b32_e32 v178, s27                                    // 00000002EFCC: 7F64021B
	v_dual_mov_b32 v176, s25 :: v_dual_mov_b32 v173, s22       // 00000002EFD0: CA100019 B0AC0016
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002EFD8: BF870003
	v_dual_mov_b32 v174, s23 :: v_dual_add_nc_u32 v55, 0xffffb500, v2// 00000002EFDC: CA200017 AE3604FF FFFFB500
	v_dual_mov_b32 v171, s20 :: v_dual_mov_b32 v172, s21       // 00000002EFE8: CA100014 ABAC0015
	ds_load_b128 v[159:162], v55 offset:2320                   // 00000002EFF0: DBFC0910 9F000037
	ds_load_b128 v[155:158], v55 offset:2304                   // 00000002EFF8: DBFC0900 9B000037
	ds_load_b128 v[167:170], v55 offset:3088                   // 00000002F000: DBFC0C10 A7000037
	ds_load_b128 v[163:166], v55 offset:3072                   // 00000002F008: DBFC0C00 A3000037
	ds_load_b128 v[2:5], v55                                   // 00000002F010: DBFC0000 02000037
	ds_load_b128 v[6:9], v55 offset:16                         // 00000002F018: DBFC0010 06000037
	ds_load_b128 v[82:85], v55 offset:4608                     // 00000002F020: DBFC1200 52000037
	ds_load_b128 v[183:186], v55 offset:3856                   // 00000002F028: DBFC0F10 B7000037
	ds_load_b128 v[179:182], v55 offset:3840                   // 00000002F030: DBFC0F00 B3000037
	ds_load_b128 v[86:89], v55 offset:4624                     // 00000002F038: DBFC1210 56000037
	v_mov_b32_e32 v177, s26                                    // 00000002F040: 7F62021A
	v_mov_b32_e32 v175, s24                                    // 00000002F044: 7F5E0218
	s_waitcnt lgkmcnt(10)                                      // 00000002F048: BF89FCA7
	v_readfirstlane_b32 s3, v56                                // 00000002F04C: 7E060538
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v56                  // 00000002F050: 7C3670FF C2CE8ED0
	s_mul_f32 s3, s3, 0x3fb8aa3b                               // 00000002F058: A203FF03 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 00000002F060: BF87000B
	s_xor_b32 s4, s3, 0x80000000                               // 00000002F064: 8D04FF03 80000000
	s_cmp_lg_u32 s12, s29                                      // 00000002F06C: BF071D0C
	v_fma_f32 v10, 0x3fb8aa3b, v56, s4                         // 00000002F070: D613000A 001270FF 3FB8AA3B
	s_rndne_f32 s4, s3                                         // 00000002F07C: BE846303
	s_waitcnt lgkmcnt(4)                                       // 00000002F080: BF89FC47
	v_wmma_f32_16x16x16_f16 v[34:41], v[2:9], v[66:73], v[171:178]// 00000002F084: CC404022 1EAE8502
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002F08C: BF870002
	v_fmac_f32_e32 v10, 0x32a5705f, v56                        // 00000002F090: 561470FF 32A5705F
	s_sub_f32 s3, s3, s4                                       // 00000002F098: A0830403
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_3)    // 00000002F09C: BF870581
	v_add_f32_e32 v18, s3, v10                                 // 00000002F0A0: 06241403
	s_cvt_i32_f32 s3, s4                                       // 00000002F0A4: BE836604
	ds_load_b128 v[14:17], v55 offset:784                      // 00000002F0A8: DBFC0310 0E000037
	ds_load_b128 v[10:13], v55 offset:768                      // 00000002F0B0: DBFC0300 0A000037
	ds_load_b128 v[46:49], v55 offset:1552                     // 00000002F0B8: DBFC0610 2E000037
	ds_load_b128 v[42:45], v55 offset:1536                     // 00000002F0C0: DBFC0600 2A000037
	v_exp_f32_e32 v18, v18                                     // 00000002F0C8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F0CC: BF870095
	.long 0xd71c0012                                           // 00000002F0D0: D71C0012
	v_cndmask_b32_e32 v0, v18, v3, vcc_lo                      // 00000002F0D4: 02000712
	v_cndmask_b32_e32 v2, 0, v18, vcc_lo                       // 00000002F0D8: 02042480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v56                  // 00000002F0DC: 7C3C70FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F0E4: BF870092
	v_cndmask_b32_e32 v145, 0x7f800000, v2, vcc_lo             // 00000002F0E8: 032204FF 7F800000
	v_fmac_f32_e32 v41, v54, v145                              // 00000002F0F0: 56532336
	s_waitcnt lgkmcnt(2)                                       // 00000002F0F4: BF89FC27
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[66:73], v[171:178]// 00000002F0F8: CC40401A 1EAE850A
	v_wmma_f32_16x16x16_f16 v[10:17], v[155:162], v[66:73], v[171:178]// 00000002F100: CC40400A 1EAE859B
	ds_load_b128 v[159:162], v55 offset:5392                   // 00000002F108: DBFC1510 9F000037
	ds_load_b128 v[155:158], v55 offset:5376                   // 00000002F110: DBFC1500 9B000037
	s_waitcnt lgkmcnt(2)                                       // 00000002F118: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[66:73], v[171:178]// 00000002F11C: CC404012 1EAE852A
	v_wmma_f32_16x16x16_f16 v[2:9], v[163:170], v[66:73], v[171:178]// 00000002F124: CC404002 1EAE85A3
	v_wmma_f32_16x16x16_f16 v[42:49], v[179:186], v[66:73], v[171:178]// 00000002F12C: CC40402A 1EAE85B3
	v_fma_f32 v138, v138, v145, v35                            // 00000002F134: D613008A 048F238A
	v_fma_f32 v136, v136, v145, v37                            // 00000002F13C: D6130088 04972388
	v_fma_f32 v135, v135, v145, v38                            // 00000002F144: D6130087 049B2387
	v_fma_f32 v131, v131, v145, v27                            // 00000002F14C: D6130083 046F2383
	v_fmac_f32_e32 v33, v53, v145                              // 00000002F154: 56432335
	v_fmac_f32_e32 v25, v52, v145                              // 00000002F158: 56332334
	v_fmac_f32_e32 v17, v51, v145                              // 00000002F15C: 56232333
	v_fmac_f32_e32 v9, v50, v145                               // 00000002F160: 56132332
	v_wmma_f32_16x16x16_f16 v[50:57], v[82:89], v[66:73], v[171:178]// 00000002F164: CC404032 1EAE8552
	v_fmac_f32_e32 v49, v58, v145                              // 00000002F16C: 5663233A
	v_fma_f32 v139, v139, v145, v34                            // 00000002F170: D613008B 048B238B
	v_fma_f32 v137, v137, v145, v36                            // 00000002F178: D6130089 04932389
	s_waitcnt lgkmcnt(0)                                       // 00000002F180: BF89FC07
	v_wmma_f32_16x16x16_f16 v[58:65], v[155:162], v[66:73], v[171:178]// 00000002F184: CC40403A 1EAE859B
	v_fma_f32 v134, v134, v145, v39                            // 00000002F18C: D6130086 049F2386
	v_fma_f32 v133, v133, v145, v40                            // 00000002F194: D6130085 04A32385
	v_fma_f32 v132, v132, v145, v26                            // 00000002F19C: D6130084 046B2384
	v_fma_f32 v130, v130, v145, v28                            // 00000002F1A4: D6130082 04732382
	v_fma_f32 v129, v129, v145, v29                            // 00000002F1AC: D6130081 04772381
	v_fma_f32 v128, v128, v145, v30                            // 00000002F1B4: D6130080 047B2380
	v_fma_f32 v127, v127, v145, v31                            // 00000002F1BC: D613007F 047F237F
	v_fma_f32 v126, v126, v145, v32                            // 00000002F1C4: D613007E 0483237E
	v_fma_f32 v125, v125, v145, v18                            // 00000002F1CC: D613007D 044B237D
	v_fma_f32 v124, v124, v145, v19                            // 00000002F1D4: D613007C 044F237C
	v_fma_f32 v123, v123, v145, v20                            // 00000002F1DC: D613007B 0453237B
	v_fma_f32 v122, v122, v145, v21                            // 00000002F1E4: D613007A 0457237A
	v_fma_f32 v121, v121, v145, v22                            // 00000002F1EC: D6130079 045B2379
	v_fma_f32 v120, v120, v145, v23                            // 00000002F1F4: D6130078 045F2378
	v_fma_f32 v119, v119, v145, v24                            // 00000002F1FC: D6130077 04632377
	v_fma_f32 v118, v118, v145, v10                            // 00000002F204: D6130076 042B2376
	v_fma_f32 v117, v117, v145, v11                            // 00000002F20C: D6130075 042F2375
	v_fma_f32 v116, v116, v145, v12                            // 00000002F214: D6130074 04332374
	v_fma_f32 v115, v115, v145, v13                            // 00000002F21C: D6130073 04372373
	v_fma_f32 v114, v114, v145, v14                            // 00000002F224: D6130072 043B2372
	v_fma_f32 v113, v113, v145, v15                            // 00000002F22C: D6130071 043F2371
	v_fma_f32 v112, v112, v145, v16                            // 00000002F234: D6130070 04432370
	v_fma_f32 v111, v111, v145, v2                             // 00000002F23C: D613006F 040B236F
	v_fma_f32 v110, v110, v145, v3                             // 00000002F244: D613006E 040F236E
	v_fma_f32 v109, v109, v145, v4                             // 00000002F24C: D613006D 0413236D
	v_fma_f32 v108, v108, v145, v5                             // 00000002F254: D613006C 0417236C
	v_fma_f32 v107, v107, v145, v6                             // 00000002F25C: D613006B 041B236B
	v_fma_f32 v106, v106, v145, v7                             // 00000002F264: D613006A 041F236A
	v_fma_f32 v105, v105, v145, v8                             // 00000002F26C: D6130069 04232369
	v_fma_f32 v104, v104, v145, v42                            // 00000002F274: D6130068 04AB2368
	v_fma_f32 v103, v103, v145, v43                            // 00000002F27C: D6130067 04AF2367
	v_fma_f32 v102, v102, v145, v44                            // 00000002F284: D6130066 04B32366
	v_fma_f32 v101, v101, v145, v45                            // 00000002F28C: D6130065 04B72365
	v_fma_f32 v100, v100, v145, v46                            // 00000002F294: D6130064 04BB2364
	v_fma_f32 v99, v99, v145, v47                              // 00000002F29C: D6130063 04BF2363
	v_fma_f32 v98, v98, v145, v48                              // 00000002F2A4: D6130062 04C32362
	v_fma_f32 v97, v97, v145, v50                              // 00000002F2AC: D6130061 04CB2361
	v_fma_f32 v96, v96, v145, v51                              // 00000002F2B4: D6130060 04CF2360
	v_fma_f32 v95, v95, v145, v52                              // 00000002F2BC: D613005F 04D3235F
	v_fma_f32 v94, v94, v145, v53                              // 00000002F2C4: D613005E 04D7235E
	v_fma_f32 v93, v93, v145, v54                              // 00000002F2CC: D613005D 04DB235D
	v_fma_f32 v92, v92, v145, v55                              // 00000002F2D4: D613005C 04DF235C
	v_fma_f32 v91, v91, v145, v56                              // 00000002F2DC: D613005B 04E3235B
	v_fmac_f32_e32 v57, v152, v145                             // 00000002F2E4: 56732398
	v_fma_f32 v90, v90, v145, v58                              // 00000002F2E8: D613005A 04EB235A
	v_fma_f32 v141, v141, v145, v59                            // 00000002F2F0: D613008D 04EF238D
	v_fma_f32 v150, v150, v145, v60                            // 00000002F2F8: D6130096 04F32396
	v_fma_f32 v142, v142, v145, v61                            // 00000002F300: D613008E 04F7238E
	v_fma_f32 v191, v191, v145, v62                            // 00000002F308: D61300BF 04FB23BF
	v_fma_f32 v189, v189, v145, v63                            // 00000002F310: D61300BD 04FF23BD
	v_fma_f32 v190, v190, v145, v64                            // 00000002F318: D61300BE 050323BE
	v_dual_fmac_f32 v65, v151, v145 :: v_dual_mul_f32 v6, 0x3b800000, v128// 00000002F320: C8072397 410700FF 3B800000
	v_lshl_add_u32 v2, v154, 7, v153                           // 00000002F32C: D6460002 06650F9A
	v_dual_mul_f32 v69, 0x3b800000, v139 :: v_dual_mul_f32 v152, 0x3b800000, v41// 00000002F334: C8C716FF 459852FF 3B800000
	v_dual_mul_f32 v70, 0x3b800000, v138 :: v_dual_mul_f32 v71, 0x3b800000, v137// 00000002F340: C8C714FF 464712FF 3B800000
	v_mul_f32_e32 v64, 0x3b800000, v127                        // 00000002F34C: 1080FEFF 3B800000
	v_mul_f32_e32 v72, 0x3b800000, v136                        // 00000002F354: 109110FF 3B800000
	v_dual_mul_f32 v4, 0x3b800000, v135 :: v_dual_mul_f32 v73, 0x3b800000, v134// 00000002F35C: C8C70EFF 04490CFF 3B800000
	v_dual_mul_f32 v60, 0x3b800000, v123 :: v_dual_mul_f32 v151, 0x3b800000, v133// 00000002F368: C8C6F6FF 3C970AFF 3B800000
	v_dual_mul_f32 v66, 0x3b800000, v126 :: v_dual_mul_f32 v5, 0x3b800000, v132// 00000002F374: C8C6FCFF 420508FF 3B800000
	v_mul_f32_e32 v8, 0x3b800000, v121                         // 00000002F380: 1010F2FF 3B800000
	v_mul_f32_e32 v68, 0x3b800000, v131                        // 00000002F388: 108906FF 3B800000
	v_dual_mul_f32 v62, 0x3b800000, v130 :: v_dual_mul_f32 v63, 0x3b800000, v129// 00000002F390: C8C704FF 3E3F02FF 3B800000
	v_dual_mul_f32 v52, 0x3b800000, v120 :: v_dual_mul_f32 v67, 0x3b800000, v33// 00000002F39C: C8C6F0FF 344242FF 3B800000
	v_dual_mul_f32 v10, 0x3b800000, v118 :: v_dual_mul_f32 v7, 0x3b800000, v125// 00000002F3A8: C8C6ECFF 0A06FAFF 3B800000
	v_mul_f32_e32 v56, 0x3b800000, v116                        // 00000002F3B4: 1070E8FF 3B800000
	v_dual_mul_f32 v59, 0x3b800000, v124 :: v_dual_mul_f32 v54, 0x3b800000, v25// 00000002F3BC: C8C6F8FF 3B3632FF 3B800000
	v_dual_mul_f32 v61, 0x3b800000, v122 :: v_dual_mul_f32 v58, 0x3b800000, v115// 00000002F3C8: C8C6F4FF 3D3AE6FF 3B800000
	v_dual_mul_f32 v53, 0x3b800000, v119 :: v_dual_mul_f32 v50, 0x3b800000, v113// 00000002F3D4: C8C6EEFF 3532E2FF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v117 :: v_dual_mul_f32 v12, 0x3b800000, v111// 00000002F3E0: C8C6EAFF 370CDEFF 3B800000
	v_dual_mul_f32 v11, 0x3b800000, v114 :: v_dual_mul_f32 v40, 0x3b800000, v17// 00000002F3EC: C8C6E4FF 0B2822FF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v112 :: v_dual_mul_f32 v44, 0x3b800000, v109// 00000002F3F8: C8C6E0FF 332CDAFF 3B800000
	v_dual_mul_f32 v43, 0x3b800000, v110 :: v_dual_mul_f32 v14, 0x3b800000, v107// 00000002F404: C8C6DCFF 2B0ED6FF 3B800000
	v_dual_mul_f32 v45, 0x3b800000, v108 :: v_dual_mul_f32 v46, 0x3b800000, v106// 00000002F410: C8C6D8FF 2D2ED4FF 3B800000
	v_dual_mul_f32 v47, 0x3b800000, v105 :: v_dual_mul_f32 v42, 0x3b800000, v103// 00000002F41C: C8C6D2FF 2F2ACEFF 3B800000
	v_dual_mul_f32 v48, 0x3b800000, v9 :: v_dual_mul_f32 v15, 0x3b800000, v104// 00000002F428: C8C612FF 300ED0FF 3B800000
	v_dual_mul_f32 v35, 0x3b800000, v102 :: v_dual_mul_f32 v36, 0x3b800000, v101// 00000002F434: C8C6CCFF 2324CAFF 3B800000
	v_dual_mul_f32 v27, 0x3b800000, v100 :: v_dual_mul_f32 v38, 0x3b800000, v98// 00000002F440: C8C6C8FF 1B26C4FF 3B800000
	v_dual_mul_f32 v37, 0x3b800000, v99 :: v_dual_mul_f32 v28, 0x3b800000, v97// 00000002F44C: C8C6C6FF 251CC2FF 3B800000
	v_dual_mul_f32 v39, 0x3b800000, v49 :: v_dual_mul_f32 v32, 0x3b800000, v95// 00000002F458: C8C662FF 2720BEFF 3B800000
	v_dual_mul_f32 v31, 0x3b800000, v96 :: v_dual_mul_f32 v34, 0x3b800000, v94// 00000002F464: C8C6C0FF 1F22BCFF 3B800000
	v_dual_mul_f32 v29, 0x3b800000, v93 :: v_dual_mul_f32 v20, 0x3b800000, v92// 00000002F470: C8C6BAFF 1D14B8FF 3B800000
	v_dual_mul_f32 v21, 0x3b800000, v91 :: v_dual_mul_f32 v22, 0x3b800000, v57// 00000002F47C: C8C6B6FF 151672FF 3B800000
	v_dual_mul_f32 v30, 0x3b800000, v90 :: v_dual_mul_f32 v23, 0x3b800000, v141// 00000002F488: C8C6B4FF 1E171AFF 3B800000
	v_dual_mul_f32 v24, 0x3b800000, v150 :: v_dual_mul_f32 v13, 0x3b800000, v65// 00000002F494: C8C72CFF 180C82FF 3B800000
	v_mul_f32_e32 v26, 0x3b800000, v142                        // 00000002F4A0: 10351CFF 3B800000
	v_dual_mul_f32 v16, 0x3b800000, v191 :: v_dual_mul_f32 v19, 0x3b800000, v190// 00000002F4A8: C8C77EFF 10137CFF 3B800000
	v_mul_f32_e32 v18, 0x3b800000, v189                        // 00000002F4B4: 10257AFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 00000002F4BC: BF89FC07
	s_barrier                                                  // 00000002F4C0: BFBD0000
	s_cbranch_scc0 5                                           // 00000002F4C4: BFA10005 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44dc>
	s_cmp_lg_u32 s13, s29                                      // 00000002F4C8: BF071D0D
	s_cbranch_scc0 273                                         // 00000002F4CC: BFA10111 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4914>
	s_cmp_lg_u32 s14, s29                                      // 00000002F4D0: BF071D0E
	s_cbranch_scc1 61709                                       // 00000002F4D4: BFA2F10D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	s_branch 540                                               // 00000002F4D8: BFA0021C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4d4c>
	v_mov_b32_e32 v82, v2                                      // 00000002F4DC: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F4E0: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 00000002F4E4: 34A6A49F
	.long 0xd73c0052                                           // 00000002F4E8: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 00000002F4EC: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F4F0: BF870091
	.long 0xd7006a52                                           // 00000002F4F4: D7006A52
	v_cndmask_b32_e32 v1, s16, v82, vcc_lo                     // 00000002F4F8: 0202A410
	v_add_co_ci_u32_e64 v83, null, s17, v83, vcc_lo            // 00000002F4FC: D5207C53 01AAA611
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F504: BF870092
	.long 0xd7006a54                                           // 00000002F508: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 00000002F50C: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000002F514: D5207C55 01AAA680
	.long 0xd7006a56                                           // 00000002F51C: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000002F520: 0201FF52
	.long 0x00002000                                           // 00000002F524: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002F528: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 00000002F52C: D5207C57 01AAA680
	.long 0xd7006a58                                           // 00000002F534: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 00000002F538: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000002F540: D5207C59 01AAA680
	s_clause 0x7                                               // 00000002F548: BF850007
	global_store_b32 v[82:83], v69, off                        // 00000002F54C: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 00000002F554: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 00000002F55C: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 00000002F564: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 00000002F56C: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 00000002F574: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 00000002F57C: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 00000002F584: DC6A0400 007C4458
	.long 0xd7006a54                                           // 00000002F58C: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 00000002F590: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002F598: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000002F59C: D5207C55 01AAA680
	.long 0xd7006a99                                           // 00000002F5A4: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000002F5A8: 0201FF52
	.long 0x00004000                                           // 00000002F5AC: 00004000
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 00000002F5B0: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 00000002F5B8: D7006A9B
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 00000002F5BC: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F5C4: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000002F5C8: D5207C9C 01AAA680
	s_clause 0x7                                               // 00000002F5D0: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 00000002F5D4: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 00000002F5DC: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 00000002F5E4: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 00000002F5EC: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 00000002F5F4: DC6A0C00 007C4354
	global_store_b32 v[155:156], v59, off offset:1024          // 00000002F5FC: DC6A0400 007C3B9B
	global_store_b32 v[155:156], v60, off offset:2048          // 00000002F604: DC6A0800 007C3C9B
	global_store_b32 v[155:156], v61, off offset:3072          // 00000002F60C: DC6A0C00 007C3D9B
	.long 0xd7006a54                                           // 00000002F614: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 00000002F618: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002F620: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000002F624: D5207C55 01AAA680
	.long 0xd7006a58                                           // 00000002F62C: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000002F630: 0201FF52
	.long 0x00006000                                           // 00000002F634: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000002F638: D5207C59 01AAA680
	.long 0xd7006a9b                                           // 00000002F640: D7006A9B
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 00000002F644: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002F64C: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000002F650: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000002F658: D7006A9D
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 00000002F65C: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000002F664: D5207C9E 01AAA680
	.long 0xd7006a9f                                           // 00000002F66C: D7006A9F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000002F670: 0201FF52
	.long 0x00008000                                           // 00000002F674: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F678: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v83, vcc_lo             // 00000002F67C: D5207CA0 01AAA680
	s_clause 0x7                                               // 00000002F684: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 00000002F688: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 00000002F690: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 00000002F698: DC6A0C00 007C3654
	global_store_b32 v[155:156], v55, off offset:1024          // 00000002F6A0: DC6A0400 007C379B
	global_store_b32 v[155:156], v56, off offset:2048          // 00000002F6A8: DC6A0800 007C389B
	global_store_b32 v[155:156], v58, off offset:3072          // 00000002F6B0: DC6A0C00 007C3A9B
	global_store_b32 v[157:158], v50, off offset:1024          // 00000002F6B8: DC6A0400 007C329D
	global_store_b32 v[157:158], v51, off offset:2048          // 00000002F6C0: DC6A0800 007C339D
	.long 0xd7006a54                                           // 00000002F6C8: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 00000002F6CC: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002F6D4: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000002F6D8: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000002F6E0: D7006A9B
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 00000002F6E4: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000002F6EC: D5207C9C 01AAA680
	.long 0xd7006aa1                                           // 00000002F6F4: D7006AA1
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000002F6F8: 0201FF52
	.long 0x0000a000                                           // 00000002F6FC: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002F700: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v83, vcc_lo             // 00000002F704: D5207CA2 01AAA680
	.long 0xd7006aa3                                           // 00000002F70C: D7006AA3
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 00000002F710: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000002F718: D5207CA4 01AAA680
	s_clause 0x7                                               // 00000002F720: BF850007
	global_store_b32 v[157:158], v40, off offset:3072          // 00000002F724: DC6A0C00 007C289D
	global_store_b32 v[84:85], v43, off offset:1024            // 00000002F72C: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 00000002F734: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 00000002F73C: DC6A0C00 007C2D54
	global_store_b32 v[155:156], v46, off offset:1024          // 00000002F744: DC6A0400 007C2E9B
	global_store_b32 v[155:156], v47, off offset:2048          // 00000002F74C: DC6A0800 007C2F9B
	global_store_b32 v[155:156], v48, off offset:3072          // 00000002F754: DC6A0C00 007C309B
	global_store_b32 v[163:164], v42, off offset:1024          // 00000002F75C: DC6A0400 007C2AA3
	.long 0xd7006a54                                           // 00000002F764: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 00000002F768: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002F770: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000002F774: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000002F77C: D7006A9B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000002F780: 0201FF52
	.long 0x0000c000                                           // 00000002F784: 0000C000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000002F788: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000002F790: D7006A9D
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 00000002F794: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F79C: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000002F7A0: D5207C9E 01AAA680
	s_clause 0x7                                               // 00000002F7A8: BF850007
	global_store_b32 v[163:164], v35, off offset:2048          // 00000002F7AC: DC6A0800 007C23A3
	global_store_b32 v[163:164], v36, off offset:3072          // 00000002F7B4: DC6A0C00 007C24A3
	global_store_b32 v[84:85], v37, off offset:1024            // 00000002F7BC: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 00000002F7C4: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 00000002F7CC: DC6A0C00 007C2754
	global_store_b32 v[157:158], v31, off offset:1024          // 00000002F7D4: DC6A0400 007C1F9D
	global_store_b32 v[157:158], v32, off offset:2048          // 00000002F7DC: DC6A0800 007C209D
	global_store_b32 v[157:158], v34, off offset:3072          // 00000002F7E4: DC6A0C00 007C229D
	.long 0xd7006a54                                           // 00000002F7EC: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 00000002F7F0: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002F7F8: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000002F7FC: D5207C55 01AAA680
	.long 0xd7006a9d                                           // 00000002F804: D7006A9D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000002F808: 0201FF52
	.long 0x0000e000                                           // 00000002F80C: 0000E000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000002F810: D5207C9E 01AAA680
	.long 0xd7006aa3                                           // 00000002F818: D7006AA3
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 00000002F81C: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F824: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000002F828: D5207CA4 01AAA680
	.long 0xd7006a52                                           // 00000002F830: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 00000002F834: 0202A4FF 0000F000
	s_clause 0x7                                               // 00000002F83C: BF850007
	global_store_b32 v[159:160], v11, off offset:-4096         // 00000002F840: DC6A1000 007C0B9F
	global_store_b32 v[159:160], v12, off                      // 00000002F848: DC6A0000 007C0C9F
	global_store_b32 v[161:162], v14, off offset:-4096         // 00000002F850: DC6A1000 007C0EA1
	global_store_b32 v[161:162], v15, off                      // 00000002F858: DC6A0000 007C0FA1
	global_store_b32 v[155:156], v27, off offset:-4096         // 00000002F860: DC6A1000 007C1B9B
	global_store_b32 v[155:156], v28, off                      // 00000002F868: DC6A0000 007C1C9B
	global_store_b32 v[157:158], v29, off offset:-4096         // 00000002F870: DC6A1000 007C1D9D
	global_store_b32 v[157:158], v30, off                      // 00000002F878: DC6A0000 007C1E9D
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 00000002F880: D5207C53 01AAA680
	s_clause 0xf                                               // 00000002F888: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 00000002F88C: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 00000002F894: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 00000002F89C: DC6A0C00 007C1654
	global_store_b32 v[163:164], v23, off offset:1024          // 00000002F8A4: DC6A0400 007C17A3
	global_store_b32 v[163:164], v24, off offset:2048          // 00000002F8AC: DC6A0800 007C18A3
	global_store_b32 v[163:164], v26, off offset:3072          // 00000002F8B4: DC6A0C00 007C1AA3
	global_store_b32 v[82:83], v16, off                        // 00000002F8BC: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 00000002F8C4: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 00000002F8CC: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 00000002F8D4: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 00000002F8DC: DC6A0000 007C0556
	global_store_b32 v[153:154], v6, off offset:-4096          // 00000002F8E4: DC6A1000 007C0699
	global_store_b32 v[153:154], v7, off                       // 00000002F8EC: DC6A0000 007C0799
	global_store_b32 v[88:89], v8, off offset:-4096            // 00000002F8F4: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 00000002F8FC: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 00000002F904: DC6A0C00 007C0D52
	s_cmp_lg_u32 s13, s29                                      // 00000002F90C: BF071D0D
	s_cbranch_scc1 65263                                       // 00000002F910: BFA2FEEF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44d0>
	v_mov_b32_e32 v82, v2                                      // 00000002F914: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F918: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 00000002F91C: 34A6A49F
	.long 0xd73c0052                                           // 00000002F920: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 00000002F924: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F928: BF870091
	.long 0xd7006a52                                           // 00000002F92C: D7006A52
	v_cndmask_b32_e32 v1, s18, v82, vcc_lo                     // 00000002F930: 0202A412
	v_add_co_ci_u32_e64 v83, null, s19, v83, vcc_lo            // 00000002F934: D5207C53 01AAA613
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F93C: BF870092
	.long 0xd7006a54                                           // 00000002F940: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 00000002F944: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000002F94C: D5207C55 01AAA680
	.long 0xd7006a56                                           // 00000002F954: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000002F958: 0201FF52
	.long 0x00002000                                           // 00000002F95C: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002F960: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 00000002F964: D5207C57 01AAA680
	.long 0xd7006a58                                           // 00000002F96C: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 00000002F970: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000002F978: D5207C59 01AAA680
	s_clause 0x7                                               // 00000002F980: BF850007
	global_store_b32 v[82:83], v69, off                        // 00000002F984: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 00000002F98C: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 00000002F994: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 00000002F99C: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 00000002F9A4: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 00000002F9AC: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 00000002F9B4: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 00000002F9BC: DC6A0400 007C4458
	.long 0xd7006a54                                           // 00000002F9C4: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 00000002F9C8: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002F9D0: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000002F9D4: D5207C55 01AAA680
	.long 0xd7006a99                                           // 00000002F9DC: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000002F9E0: 0201FF52
	.long 0x00004000                                           // 00000002F9E4: 00004000
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 00000002F9E8: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 00000002F9F0: D7006A9B
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 00000002F9F4: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F9FC: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000002FA00: D5207C9C 01AAA680
	s_clause 0x7                                               // 00000002FA08: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 00000002FA0C: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 00000002FA14: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 00000002FA1C: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 00000002FA24: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 00000002FA2C: DC6A0C00 007C4354
	global_store_b32 v[155:156], v59, off offset:1024          // 00000002FA34: DC6A0400 007C3B9B
	global_store_b32 v[155:156], v60, off offset:2048          // 00000002FA3C: DC6A0800 007C3C9B
	global_store_b32 v[155:156], v61, off offset:3072          // 00000002FA44: DC6A0C00 007C3D9B
	.long 0xd7006a54                                           // 00000002FA4C: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 00000002FA50: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002FA58: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000002FA5C: D5207C55 01AAA680
	.long 0xd7006a58                                           // 00000002FA64: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000002FA68: 0201FF52
	.long 0x00006000                                           // 00000002FA6C: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000002FA70: D5207C59 01AAA680
	.long 0xd7006a9b                                           // 00000002FA78: D7006A9B
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 00000002FA7C: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002FA84: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000002FA88: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000002FA90: D7006A9D
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 00000002FA94: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000002FA9C: D5207C9E 01AAA680
	.long 0xd7006a9f                                           // 00000002FAA4: D7006A9F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000002FAA8: 0201FF52
	.long 0x00008000                                           // 00000002FAAC: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002FAB0: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v83, vcc_lo             // 00000002FAB4: D5207CA0 01AAA680
	s_clause 0x7                                               // 00000002FABC: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 00000002FAC0: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 00000002FAC8: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 00000002FAD0: DC6A0C00 007C3654
	global_store_b32 v[155:156], v55, off offset:1024          // 00000002FAD8: DC6A0400 007C379B
	global_store_b32 v[155:156], v56, off offset:2048          // 00000002FAE0: DC6A0800 007C389B
	global_store_b32 v[155:156], v58, off offset:3072          // 00000002FAE8: DC6A0C00 007C3A9B
	global_store_b32 v[157:158], v50, off offset:1024          // 00000002FAF0: DC6A0400 007C329D
	global_store_b32 v[157:158], v51, off offset:2048          // 00000002FAF8: DC6A0800 007C339D
	.long 0xd7006a54                                           // 00000002FB00: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 00000002FB04: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002FB0C: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000002FB10: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000002FB18: D7006A9B
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 00000002FB1C: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000002FB24: D5207C9C 01AAA680
	.long 0xd7006aa1                                           // 00000002FB2C: D7006AA1
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000002FB30: 0201FF52
	.long 0x0000a000                                           // 00000002FB34: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002FB38: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v83, vcc_lo             // 00000002FB3C: D5207CA2 01AAA680
	.long 0xd7006aa3                                           // 00000002FB44: D7006AA3
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 00000002FB48: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000002FB50: D5207CA4 01AAA680
	s_clause 0x7                                               // 00000002FB58: BF850007
	global_store_b32 v[157:158], v40, off offset:3072          // 00000002FB5C: DC6A0C00 007C289D
	global_store_b32 v[84:85], v43, off offset:1024            // 00000002FB64: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 00000002FB6C: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 00000002FB74: DC6A0C00 007C2D54
	global_store_b32 v[155:156], v46, off offset:1024          // 00000002FB7C: DC6A0400 007C2E9B
	global_store_b32 v[155:156], v47, off offset:2048          // 00000002FB84: DC6A0800 007C2F9B
	global_store_b32 v[155:156], v48, off offset:3072          // 00000002FB8C: DC6A0C00 007C309B
	global_store_b32 v[163:164], v42, off offset:1024          // 00000002FB94: DC6A0400 007C2AA3
	.long 0xd7006a54                                           // 00000002FB9C: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 00000002FBA0: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002FBA8: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000002FBAC: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000002FBB4: D7006A9B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000002FBB8: 0201FF52
	.long 0x0000c000                                           // 00000002FBBC: 0000C000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000002FBC0: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000002FBC8: D7006A9D
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 00000002FBCC: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002FBD4: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000002FBD8: D5207C9E 01AAA680
	s_clause 0x7                                               // 00000002FBE0: BF850007
	global_store_b32 v[163:164], v35, off offset:2048          // 00000002FBE4: DC6A0800 007C23A3
	global_store_b32 v[163:164], v36, off offset:3072          // 00000002FBEC: DC6A0C00 007C24A3
	global_store_b32 v[84:85], v37, off offset:1024            // 00000002FBF4: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 00000002FBFC: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 00000002FC04: DC6A0C00 007C2754
	global_store_b32 v[157:158], v31, off offset:1024          // 00000002FC0C: DC6A0400 007C1F9D
	global_store_b32 v[157:158], v32, off offset:2048          // 00000002FC14: DC6A0800 007C209D
	global_store_b32 v[157:158], v34, off offset:3072          // 00000002FC1C: DC6A0C00 007C229D
	.long 0xd7006a54                                           // 00000002FC24: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 00000002FC28: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002FC30: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000002FC34: D5207C55 01AAA680
	.long 0xd7006a9d                                           // 00000002FC3C: D7006A9D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000002FC40: 0201FF52
	.long 0x0000e000                                           // 00000002FC44: 0000E000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000002FC48: D5207C9E 01AAA680
	.long 0xd7006aa3                                           // 00000002FC50: D7006AA3
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 00000002FC54: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002FC5C: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000002FC60: D5207CA4 01AAA680
	.long 0xd7006a52                                           // 00000002FC68: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 00000002FC6C: 0202A4FF 0000F000
	s_clause 0x7                                               // 00000002FC74: BF850007
	global_store_b32 v[159:160], v11, off offset:-4096         // 00000002FC78: DC6A1000 007C0B9F
	global_store_b32 v[159:160], v12, off                      // 00000002FC80: DC6A0000 007C0C9F
	global_store_b32 v[161:162], v14, off offset:-4096         // 00000002FC88: DC6A1000 007C0EA1
	global_store_b32 v[161:162], v15, off                      // 00000002FC90: DC6A0000 007C0FA1
	global_store_b32 v[155:156], v27, off offset:-4096         // 00000002FC98: DC6A1000 007C1B9B
	global_store_b32 v[155:156], v28, off                      // 00000002FCA0: DC6A0000 007C1C9B
	global_store_b32 v[157:158], v29, off offset:-4096         // 00000002FCA8: DC6A1000 007C1D9D
	global_store_b32 v[157:158], v30, off                      // 00000002FCB0: DC6A0000 007C1E9D
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 00000002FCB8: D5207C53 01AAA680
	s_clause 0xf                                               // 00000002FCC0: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 00000002FCC4: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 00000002FCCC: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 00000002FCD4: DC6A0C00 007C1654
	global_store_b32 v[163:164], v23, off offset:1024          // 00000002FCDC: DC6A0400 007C17A3
	global_store_b32 v[163:164], v24, off offset:2048          // 00000002FCE4: DC6A0800 007C18A3
	global_store_b32 v[163:164], v26, off offset:3072          // 00000002FCEC: DC6A0C00 007C1AA3
	global_store_b32 v[82:83], v16, off                        // 00000002FCF4: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 00000002FCFC: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 00000002FD04: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 00000002FD0C: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 00000002FD14: DC6A0000 007C0556
	global_store_b32 v[153:154], v6, off offset:-4096          // 00000002FD1C: DC6A1000 007C0699
	global_store_b32 v[153:154], v7, off                       // 00000002FD24: DC6A0000 007C0799
	global_store_b32 v[88:89], v8, off offset:-4096            // 00000002FD2C: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 00000002FD34: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 00000002FD3C: DC6A0C00 007C0D52
	s_cmp_lg_u32 s14, s29                                      // 00000002FD44: BF071D0E
	s_cbranch_scc1 61168                                       // 00000002FD48: BFA2EEF0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000002FD4C: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002FD50: BF870091
	.long 0xd73c0002                                           // 00000002FD54: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000002FD58: 02020482
	.long 0xd7006a02                                           // 00000002FD5C: D7006A02
	v_cndmask_b32_e32 v1, s47, v2, vcc_lo                      // 00000002FD60: 0202042F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002FD64: BF870111
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 00000002FD68: D5207C03 01AA0607
	.long 0xd7006a52                                           // 00000002FD70: D7006A52
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000002FD74: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002FD7C: BF8700A1
	v_add_co_ci_u32_e64 v83, null, 0, v3, vcc_lo               // 00000002FD80: D5207C53 01AA0680
	.long 0xd7006a54                                           // 00000002FD88: D7006A54
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000002FD8C: 0201FF02
	.long 0x00002000                                           // 00000002FD90: 00002000
	v_add_co_ci_u32_e64 v85, null, 0, v3, vcc_lo               // 00000002FD94: D5207C55 01AA0680
	.long 0xd7006a56                                           // 00000002FD9C: D7006A56
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 00000002FDA0: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002FDA8: BF870001
	v_add_co_ci_u32_e64 v87, null, 0, v3, vcc_lo               // 00000002FDAC: D5207C57 01AA0680
	s_clause 0x7                                               // 00000002FDB4: BF850007
	global_store_b32 v[2:3], v69, off                          // 00000002FDB8: DC6A0000 007C4502
	global_store_b32 v[2:3], v70, off offset:1024              // 00000002FDC0: DC6A0400 007C4602
	global_store_b32 v[2:3], v71, off offset:2048              // 00000002FDC8: DC6A0800 007C4702
	global_store_b32 v[2:3], v72, off offset:3072              // 00000002FDD0: DC6A0C00 007C4802
	global_store_b32 v[82:83], v73, off offset:1024            // 00000002FDD8: DC6A0400 007C4952
	global_store_b32 v[82:83], v151, off offset:2048           // 00000002FDE0: DC6A0800 007C9752
	global_store_b32 v[82:83], v152, off offset:3072           // 00000002FDE8: DC6A0C00 007C9852
	global_store_b32 v[86:87], v68, off offset:1024            // 00000002FDF0: DC6A0400 007C4456
	.long 0xd7006a44                                           // 00000002FDF8: D7006A44
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 00000002FDFC: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002FE04: BF8700A1
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 00000002FE08: D5207C45 01AA0680
	.long 0xd7006a46                                           // 00000002FE10: D7006A46
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000002FE14: 0201FF02
	.long 0x00004000                                           // 00000002FE18: 00004000
	v_add_co_ci_u32_e64 v71, null, 0, v3, vcc_lo               // 00000002FE1C: D5207C47 01AA0680
	.long 0xd7006a48                                           // 00000002FE24: D7006A48
	v_cndmask_b32_e32 v1, 0x4000, v2, vcc_lo                   // 00000002FE28: 020204FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002FE30: BF870001
	v_add_co_ci_u32_e64 v73, null, 0, v3, vcc_lo               // 00000002FE34: D5207C49 01AA0680
	s_clause 0x7                                               // 00000002FE3C: BF850007
	global_store_b32 v[86:87], v62, off offset:2048            // 00000002FE40: DC6A0800 007C3E56
	global_store_b32 v[86:87], v63, off offset:3072            // 00000002FE48: DC6A0C00 007C3F56
	global_store_b32 v[68:69], v64, off offset:1024            // 00000002FE50: DC6A0400 007C4044
	global_store_b32 v[68:69], v66, off offset:2048            // 00000002FE58: DC6A0800 007C4244
	global_store_b32 v[68:69], v67, off offset:3072            // 00000002FE60: DC6A0C00 007C4344
	global_store_b32 v[72:73], v59, off offset:1024            // 00000002FE68: DC6A0400 007C3B48
	global_store_b32 v[72:73], v60, off offset:2048            // 00000002FE70: DC6A0800 007C3C48
	global_store_b32 v[72:73], v61, off offset:3072            // 00000002FE78: DC6A0C00 007C3D48
	.long 0xd7006a3b                                           // 00000002FE80: D7006A3B
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 00000002FE84: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002FE8C: BF8700A1
	v_add_co_ci_u32_e64 v60, null, 0, v3, vcc_lo               // 00000002FE90: D5207C3C 01AA0680
	.long 0xd7006a3d                                           // 00000002FE98: D7006A3D
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000002FE9C: 0201FF02
	.long 0x00006000                                           // 00000002FEA0: 00006000
	v_add_co_ci_u32_e64 v62, null, 0, v3, vcc_lo               // 00000002FEA4: D5207C3E 01AA0680
	.long 0xd7006a3f                                           // 00000002FEAC: D7006A3F
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 00000002FEB0: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002FEB8: BF8700A1
	v_add_co_ci_u32_e64 v64, null, 0, v3, vcc_lo               // 00000002FEBC: D5207C40 01AA0680
	.long 0xd7006a42                                           // 00000002FEC4: D7006A42
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 00000002FEC8: 020204FF 00007000
	v_add_co_ci_u32_e64 v67, null, 0, v3, vcc_lo               // 00000002FED0: D5207C43 01AA0680
	.long 0xd7006a44                                           // 00000002FED8: D7006A44
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000002FEDC: 0201FF02
	.long 0x00008000                                           // 00000002FEE0: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002FEE4: BF870001
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 00000002FEE8: D5207C45 01AA0680
	s_clause 0x7                                               // 00000002FEF0: BF850007
	global_store_b32 v[59:60], v52, off offset:1024            // 00000002FEF4: DC6A0400 007C343B
	global_store_b32 v[59:60], v53, off offset:2048            // 00000002FEFC: DC6A0800 007C353B
	global_store_b32 v[59:60], v54, off offset:3072            // 00000002FF04: DC6A0C00 007C363B
	global_store_b32 v[63:64], v55, off offset:1024            // 00000002FF0C: DC6A0400 007C373F
	global_store_b32 v[63:64], v56, off offset:2048            // 00000002FF14: DC6A0800 007C383F
	global_store_b32 v[63:64], v58, off offset:3072            // 00000002FF1C: DC6A0C00 007C3A3F
	global_store_b32 v[66:67], v50, off offset:1024            // 00000002FF24: DC6A0400 007C3242
	global_store_b32 v[66:67], v51, off offset:2048            // 00000002FF2C: DC6A0800 007C3342
	.long 0xd7006a32                                           // 00000002FF34: D7006A32
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 00000002FF38: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002FF40: BF8700A1
	v_add_co_ci_u32_e64 v51, null, 0, v3, vcc_lo               // 00000002FF44: D5207C33 01AA0680
	.long 0xd7006a34                                           // 00000002FF4C: D7006A34
	v_cndmask_b32_e32 v1, 0x9000, v2, vcc_lo                   // 00000002FF50: 020204FF 00009000
	v_add_co_ci_u32_e64 v53, null, 0, v3, vcc_lo               // 00000002FF58: D5207C35 01AA0680
	.long 0xd7006a36                                           // 00000002FF60: D7006A36
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000002FF64: 0201FF02
	.long 0x0000a000                                           // 00000002FF68: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002FF6C: BF8700A1
	v_add_co_ci_u32_e64 v55, null, 0, v3, vcc_lo               // 00000002FF70: D5207C37 01AA0680
	.long 0xd7006a3a                                           // 00000002FF78: D7006A3A
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 00000002FF7C: 020204FF 0000A000
	v_add_co_ci_u32_e64 v59, null, 0, v3, vcc_lo               // 00000002FF84: D5207C3B 01AA0680
	s_clause 0x7                                               // 00000002FF8C: BF850007
	global_store_b32 v[66:67], v40, off offset:3072            // 00000002FF90: DC6A0C00 007C2842
	global_store_b32 v[50:51], v43, off offset:1024            // 00000002FF98: DC6A0400 007C2B32
	global_store_b32 v[50:51], v44, off offset:2048            // 00000002FFA0: DC6A0800 007C2C32
	global_store_b32 v[50:51], v45, off offset:3072            // 00000002FFA8: DC6A0C00 007C2D32
	global_store_b32 v[52:53], v46, off offset:1024            // 00000002FFB0: DC6A0400 007C2E34
	global_store_b32 v[52:53], v47, off offset:2048            // 00000002FFB8: DC6A0800 007C2F34
	global_store_b32 v[52:53], v48, off offset:3072            // 00000002FFC0: DC6A0C00 007C3034
	global_store_b32 v[58:59], v42, off offset:1024            // 00000002FFC8: DC6A0400 007C2A3A
	.long 0xd7006a2a                                           // 00000002FFD0: D7006A2A
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 00000002FFD4: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002FFDC: BF8700A1
	v_add_co_ci_u32_e64 v43, null, 0, v3, vcc_lo               // 00000002FFE0: D5207C2B 01AA0680
	.long 0xd7006a2c                                           // 00000002FFE8: D7006A2C
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000002FFEC: 0201FF02
	.long 0x0000c000                                           // 00000002FFF0: 0000C000
	v_add_co_ci_u32_e64 v45, null, 0, v3, vcc_lo               // 00000002FFF4: D5207C2D 01AA0680
	.long 0xd7006a2e                                           // 00000002FFFC: D7006A2E
	v_cndmask_b32_e32 v1, 0xc000, v2, vcc_lo                   // 000000030000: 020204FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000030008: BF870001
	v_add_co_ci_u32_e64 v47, null, 0, v3, vcc_lo               // 00000003000C: D5207C2F 01AA0680
	s_clause 0x7                                               // 000000030014: BF850007
	global_store_b32 v[58:59], v35, off offset:2048            // 000000030018: DC6A0800 007C233A
	global_store_b32 v[58:59], v36, off offset:3072            // 000000030020: DC6A0C00 007C243A
	global_store_b32 v[42:43], v37, off offset:1024            // 000000030028: DC6A0400 007C252A
	global_store_b32 v[42:43], v38, off offset:2048            // 000000030030: DC6A0800 007C262A
	global_store_b32 v[42:43], v39, off offset:3072            // 000000030038: DC6A0C00 007C272A
	global_store_b32 v[46:47], v31, off offset:1024            // 000000030040: DC6A0400 007C1F2E
	global_store_b32 v[46:47], v32, off offset:2048            // 000000030048: DC6A0800 007C202E
	global_store_b32 v[46:47], v34, off offset:3072            // 000000030050: DC6A0C00 007C222E
	.long 0xd7006a1f                                           // 000000030058: D7006A1F
	v_cndmask_b32_e32 v1, 0xd000, v2, vcc_lo                   // 00000003005C: 020204FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000030064: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v3, vcc_lo               // 000000030068: D5207C20 01AA0680
	.long 0xd7006a22                                           // 000000030070: D7006A22
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000030074: 0201FF02
	.long 0x0000e000                                           // 000000030078: 0000E000
	v_add_co_ci_u32_e64 v35, null, 0, v3, vcc_lo               // 00000003007C: D5207C23 01AA0680
	.long 0xd7006a24                                           // 000000030084: D7006A24
	v_cndmask_b32_e32 v1, 0xe000, v2, vcc_lo                   // 000000030088: 020204FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000030090: BF870001
	v_add_co_ci_u32_e64 v37, null, 0, v3, vcc_lo               // 000000030094: D5207C25 01AA0680
	.long 0xd7006a02                                           // 00000003009C: D7006A02
	v_cndmask_b32_e32 v1, 0xf000, v2, vcc_lo                   // 0000000300A0: 020204FF 0000F000
	s_clause 0x7                                               // 0000000300A8: BF850007
	global_store_b32 v[68:69], v11, off offset:-4096           // 0000000300AC: DC6A1000 007C0B44
	global_store_b32 v[68:69], v12, off                        // 0000000300B4: DC6A0000 007C0C44
	global_store_b32 v[54:55], v14, off offset:-4096           // 0000000300BC: DC6A1000 007C0E36
	global_store_b32 v[54:55], v15, off                        // 0000000300C4: DC6A0000 007C0F36
	global_store_b32 v[44:45], v27, off offset:-4096           // 0000000300CC: DC6A1000 007C1B2C
	global_store_b32 v[44:45], v28, off                        // 0000000300D4: DC6A0000 007C1C2C
	global_store_b32 v[34:35], v29, off offset:-4096           // 0000000300DC: DC6A1000 007C1D22
	global_store_b32 v[34:35], v30, off                        // 0000000300E4: DC6A0000 007C1E22
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000000300EC: D5207C03 01AA0680
	s_clause 0xf                                               // 0000000300F4: BF85000F
	global_store_b32 v[31:32], v20, off offset:1024            // 0000000300F8: DC6A0400 007C141F
	global_store_b32 v[31:32], v21, off offset:2048            // 000000030100: DC6A0800 007C151F
	global_store_b32 v[31:32], v22, off offset:3072            // 000000030108: DC6A0C00 007C161F
	global_store_b32 v[36:37], v23, off offset:1024            // 000000030110: DC6A0400 007C1724
	global_store_b32 v[36:37], v24, off offset:2048            // 000000030118: DC6A0800 007C1824
	global_store_b32 v[36:37], v26, off offset:3072            // 000000030120: DC6A0C00 007C1A24
	global_store_b32 v[2:3], v16, off                          // 000000030128: DC6A0000 007C1002
	global_store_b32 v[2:3], v18, off offset:1024              // 000000030130: DC6A0400 007C1202
	global_store_b32 v[2:3], v19, off offset:2048              // 000000030138: DC6A0800 007C1302
	global_store_b32 v[84:85], v4, off offset:-4096            // 000000030140: DC6A1000 007C0454
	global_store_b32 v[84:85], v5, off                         // 000000030148: DC6A0000 007C0554
	global_store_b32 v[70:71], v6, off offset:-4096            // 000000030150: DC6A1000 007C0646
	global_store_b32 v[70:71], v7, off                         // 000000030158: DC6A0000 007C0746
	global_store_b32 v[61:62], v8, off offset:-4096            // 000000030160: DC6A1000 007C083D
	global_store_b32 v[61:62], v10, off                        // 000000030168: DC6A0000 007C0A3D
	global_store_b32 v[2:3], v13, off offset:3072              // 000000030170: DC6A0C00 007C0D02
	s_branch 60900                                             // 000000030178: BFA0EDE4 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	v_mov_b32_e32 v54, v41                                     // 00000003017C: 7E6C0329
	v_mov_b32_e32 v53, v33                                     // 000000030180: 7E6A0321
	v_mov_b32_e32 v52, v25                                     // 000000030184: 7E680319
	v_mov_b32_e32 v51, v17                                     // 000000030188: 7E660311
	v_mov_b32_e32 v50, v9                                      // 00000003018C: 7E640309
	v_mov_b32_e32 v58, v49                                     // 000000030190: 7E740331
	v_mov_b32_e32 v152, v57                                    // 000000030194: 7F300339
	v_mov_b32_e32 v151, v65                                    // 000000030198: 7F2E0341
	s_mov_b32 s7, 0                                            // 00000003019C: BE870080
	s_branch 1                                                 // 0000000301A0: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x51a8>
	s_mov_b64 s[6:7], 0                                        // 0000000301A4: BE860180
	v_dual_mul_f32 v3, 0x3b800000, v139 :: v_dual_mul_f32 v4, 0x3b800000, v138// 0000000301A8: C8C716FF 030514FF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v137 :: v_dual_mul_f32 v6, 0x3b800000, v136// 0000000301B4: C8C712FF 050710FF 3B800000
	.long 0xd7006a01                                           // 0000000301C0: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000301C4: 0201FFBB
	.long 0x00002000                                           // 0000000301C8: 00002000
	v_dual_mul_f32 v7, 0x3b800000, v135 :: v_dual_mul_f32 v8, 0x3b800000, v134// 0000000301CC: C8C70EFF 07090CFF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 0000000301D8: D5207C02 01AB7880
	v_dual_mul_f32 v9, 0x3b800000, v133 :: v_dual_mul_f32 v10, 0x3b800000, v54// 0000000301E0: C8C70AFF 090A6CFF 3B800000
	s_clause 0x7                                               // 0000000301EC: BF850007
	global_store_b32 v[187:188], v3, off                       // 0000000301F0: DC6A0000 007C03BB
	global_store_b32 v[187:188], v4, off offset:1024           // 0000000301F8: DC6A0400 007C04BB
	global_store_b32 v[187:188], v5, off offset:2048           // 000000030200: DC6A0800 007C05BB
	global_store_b32 v[187:188], v6, off offset:3072           // 000000030208: DC6A0C00 007C06BB
	global_store_b32 v[1:2], v7, off offset:-4096              // 000000030210: DC6A1000 007C0701
	global_store_b32 v[1:2], v8, off offset:-3072              // 000000030218: DC6A1400 007C0801
	global_store_b32 v[1:2], v9, off offset:-2048              // 000000030220: DC6A1800 007C0901
	global_store_b32 v[1:2], v10, off offset:-1024             // 000000030228: DC6A1C00 007C0A01
	v_dual_mul_f32 v5, 0x3b800000, v132 :: v_dual_mul_f32 v6, 0x3b800000, v131// 000000030230: C8C708FF 050706FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v130 :: v_dual_mul_f32 v8, 0x3b800000, v129// 00000003023C: C8C704FF 070902FF 3B800000
	.long 0xd7006a03                                           // 000000030248: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000003024C: 0201FFBB
	.long 0x00004000                                           // 000000030250: 00004000
	v_dual_mul_f32 v9, 0x3b800000, v128 :: v_dual_mul_f32 v10, 0x3b800000, v127// 000000030254: C8C700FF 090AFEFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000030260: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v126 :: v_dual_mul_f32 v12, 0x3b800000, v53// 000000030268: C8C6FCFF 0B0C6AFF 3B800000
	s_clause 0x7                                               // 000000030274: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000030278: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000030280: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 000000030288: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 000000030290: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 000000030298: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 0000000302A0: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 0000000302A8: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 0000000302B0: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v125 :: v_dual_mul_f32 v6, 0x3b800000, v124// 0000000302B8: C8C6FAFF 0506F8FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v123 :: v_dual_mul_f32 v8, 0x3b800000, v122// 0000000302C4: C8C6F6FF 0708F4FF 3B800000
	.long 0xd7006a01                                           // 0000000302D0: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000302D4: 0201FFBB
	.long 0x00006000                                           // 0000000302D8: 00006000
	v_dual_mul_f32 v9, 0x3b800000, v121 :: v_dual_mul_f32 v10, 0x3b800000, v120// 0000000302DC: C8C6F2FF 090AF0FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 0000000302E8: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v119 :: v_dual_mul_f32 v12, 0x3b800000, v52// 0000000302F0: C8C6EEFF 0B0C68FF 3B800000
	s_clause 0x7                                               // 0000000302FC: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000030300: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 000000030308: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000030310: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 000000030318: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000030320: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000030328: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000030330: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000030338: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v118 :: v_dual_mul_f32 v6, 0x3b800000, v117// 000000030340: C8C6ECFF 0506EAFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v116 :: v_dual_mul_f32 v8, 0x3b800000, v115// 00000003034C: C8C6E8FF 0708E6FF 3B800000
	.long 0xd7006a03                                           // 000000030358: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000003035C: 0201FFBB
	.long 0x00008000                                           // 000000030360: 00008000
	v_dual_mul_f32 v9, 0x3b800000, v114 :: v_dual_mul_f32 v10, 0x3b800000, v113// 000000030364: C8C6E4FF 090AE2FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000030370: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v112 :: v_dual_mul_f32 v12, 0x3b800000, v51// 000000030378: C8C6E0FF 0B0C66FF 3B800000
	s_clause 0x7                                               // 000000030384: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000030388: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000030390: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 000000030398: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 0000000303A0: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 0000000303A8: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 0000000303B0: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 0000000303B8: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 0000000303C0: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v111 :: v_dual_mul_f32 v6, 0x3b800000, v110// 0000000303C8: C8C6DEFF 0506DCFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v109 :: v_dual_mul_f32 v8, 0x3b800000, v108// 0000000303D4: C8C6DAFF 0708D8FF 3B800000
	.long 0xd7006a01                                           // 0000000303E0: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000303E4: 0201FFBB
	.long 0x0000a000                                           // 0000000303E8: 0000A000
	v_dual_mul_f32 v9, 0x3b800000, v107 :: v_dual_mul_f32 v10, 0x3b800000, v106// 0000000303EC: C8C6D6FF 090AD4FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 0000000303F8: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v105 :: v_dual_mul_f32 v12, 0x3b800000, v50// 000000030400: C8C6D2FF 0B0C64FF 3B800000
	s_clause 0x7                                               // 00000003040C: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000030410: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 000000030418: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000030420: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 000000030428: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000030430: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000030438: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000030440: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000030448: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v104 :: v_dual_mul_f32 v6, 0x3b800000, v103// 000000030450: C8C6D0FF 0506CEFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v102 :: v_dual_mul_f32 v8, 0x3b800000, v101// 00000003045C: C8C6CCFF 0708CAFF 3B800000
	.long 0xd7006a03                                           // 000000030468: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000003046C: 0201FFBB
	.long 0x0000c000                                           // 000000030470: 0000C000
	v_dual_mul_f32 v9, 0x3b800000, v100 :: v_dual_mul_f32 v10, 0x3b800000, v99// 000000030474: C8C6C8FF 090AC6FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000030480: D5207C04 01AB7880
	v_mul_f32_e32 v11, 0x3b800000, v98                         // 000000030488: 1016C4FF 3B800000
	v_mul_f32_e32 v12, 0x3b800000, v58                         // 000000030490: 101874FF 3B800000
	s_clause 0x7                                               // 000000030498: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000003049C: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 0000000304A4: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 0000000304AC: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 0000000304B4: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 0000000304BC: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 0000000304C4: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 0000000304CC: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 0000000304D4: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v97 :: v_dual_mul_f32 v6, 0x3b800000, v96// 0000000304DC: C8C6C2FF 0506C0FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v95 :: v_dual_mul_f32 v8, 0x3b800000, v94// 0000000304E8: C8C6BEFF 0708BCFF 3B800000
	.long 0xd7006a01                                           // 0000000304F4: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000304F8: 0201FFBB
	.long 0x0000e000                                           // 0000000304FC: 0000E000
	v_dual_mul_f32 v9, 0x3b800000, v93 :: v_dual_mul_f32 v10, 0x3b800000, v92// 000000030500: C8C6BAFF 090AB8FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 00000003050C: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v91 :: v_dual_mul_f32 v12, 0x3b800000, v152// 000000030514: C8C6B6FF 0B0D30FF 3B800000
	s_clause 0x7                                               // 000000030520: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000030524: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 00000003052C: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000030534: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 00000003053C: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000030544: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 00000003054C: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000030554: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 00000003055C: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v90 :: v_dual_mul_f32 v6, 0x3b800000, v141// 000000030564: C8C6B4FF 05071AFF 3B800000
	v_and_or_b32 v0, v0, 31, s5                                // 000000030570: D6570000 00153F00
	v_dual_mul_f32 v7, 0x3b800000, v150 :: v_dual_mul_f32 v10, 0x3b800000, v189// 000000030578: C8C72CFF 070B7AFF 3B800000
	.long 0xd7006a03                                           // 000000030584: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000030588: 0201FFBB
	.long 0x0000fc00                                           // 00000003058C: 0000FC00
	v_dual_mul_f32 v8, 0x3b800000, v142 :: v_dual_mul_f32 v9, 0x3b800000, v191// 000000030590: C8C71CFF 08097EFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 00000003059C: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v190 :: v_dual_mul_f32 v12, 0x3b800000, v151// 0000000305A4: C8C77CFF 0B0D2EFF 3B800000
	s_clause 0x7                                               // 0000000305B0: BF850007
	global_store_b32 v[1:2], v5, off                           // 0000000305B4: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 0000000305BC: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 0000000305C4: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 0000000305CC: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-3072              // 0000000305D4: DC6A1400 007C0903
	global_store_b32 v[3:4], v10, off offset:-2048             // 0000000305DC: DC6A1800 007C0A03
	global_store_b32 v[3:4], v11, off offset:-1024             // 0000000305E4: DC6A1C00 007C0B03
	global_store_b32 v[3:4], v12, off                          // 0000000305EC: DC6A0000 007C0C03
	s_mov_b32 s2, exec_lo                                      // 0000000305F4: BE82007E
	v_cmpx_eq_u32_e32 0, v0                                    // 0000000305F8: 7D940080
	s_cbranch_execz 8                                          // 0000000305FC: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi2ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5620>
	s_load_b64 s[0:1], s[0:1], 0x40                            // 000000030600: F4040000 F8000040
	v_mov_b32_e32 v0, s6                                       // 000000030608: 7E000206
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, s7              // 00000003060C: CA100080 02000007
	s_waitcnt lgkmcnt(0)                                       // 000000030614: BF89FC07
	global_store_b64 v2, v[0:1], s[0:1] offset:8               // 000000030618: DC6E0008 00000002
	s_endpgm                                                   // 000000030620: BFB00000
		...

