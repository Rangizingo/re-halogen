0000000000186900 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE():
	s_load_b256 s[16:23], s[0:1], 0x38                         // 000000186900: F40C0400 F8000038
	s_lshl_b32 s6, s3, 6                                       // 000000186908: 84068603
	s_ashr_i32 s3, s2, 31                                      // 00000018690C: 86039F02
	s_ashr_i32 s7, s6, 31                                      // 000000186910: 86079F06
	v_and_b32_e32 v1, 63, v0                                   // 000000186914: 360200BF
	v_mov_b32_e32 v5, v0                                       // 000000186918: 7E0A0300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000018691C: BF8704D2
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000186920: 30060282
	v_mul_u32_u24_e32 v2, 0x210, v1                            // 000000186924: 160402FF 00000210
	s_waitcnt lgkmcnt(0)                                       // 00000018692C: BF89FC07
	s_load_b32 s4, s[18:19], null                              // 000000186930: F4000109 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 000000186938: 84928214
	s_add_u32 s5, s16, s18                                     // 00000018693C: 80051210
	s_addc_u32 s8, s17, s19                                    // 000000186940: 82081311
	s_lshl_b64 s[34:35], s[2:3], 16                            // 000000186944: 84A29002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000186948: BF870009
	s_add_u32 s5, s5, s34                                      // 00000018694C: 80052205
	s_addc_u32 s8, s8, s35                                     // 000000186950: 82082308
	s_waitcnt lgkmcnt(0)                                       // 000000186954: BF89FC07
	s_mul_i32 s33, s4, 0x9000000                               // 000000186958: 9621FF04 09000000
	s_mul_hi_i32 s15, s4, 0x9000000                            // 000000186960: 970FFF04 09000000
	s_add_u32 s4, s5, s33                                      // 000000186968: 80042105
	s_addc_u32 s5, s8, s15                                     // 00000018696C: 82050F08
	s_lshl_b64 s[48:49], s[6:7], 2                             // 000000186970: 84B08206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000186974: BF8700B9
	s_add_u32 s4, s4, s48                                      // 000000186978: 80043004
	s_addc_u32 s5, s5, s49                                     // 00000018697C: 82053105
	.long 0xd7000403                                           // 000000186980: D7000403
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 000000186984: 02020604
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 000000186988: D5207C04 00110005
	s_mov_b32 s4, 0                                            // 000000186990: BE840080
	s_nop 0                                                    // 000000186994: BF800000
	s_nop 0                                                    // 000000186998: BF800000
	s_nop 0                                                    // 00000018699C: BF800000
	s_nop 0                                                    // 0000001869A0: BF800000
	s_nop 0                                                    // 0000001869A4: BF800000
	s_nop 0                                                    // 0000001869A8: BF800000
	s_nop 0                                                    // 0000001869AC: BF800000
	s_nop 0                                                    // 0000001869B0: BF800000
	s_nop 0                                                    // 0000001869B4: BF800000
	s_nop 0                                                    // 0000001869B8: BF800000
	s_nop 0                                                    // 0000001869BC: BF800000
	v_lshrrev_b32_e32 v8, 6, v5                                // 0000001869C0: 32100A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001869C4: BF870121
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000001869C8: 300C1089
	v_lshl_add_u32 v8, v8, 2, v2                               // 0000001869CC: D6460008 04090508
	.long 0xd7006a06                                           // 0000001869D4: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000001869D8: 02020D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001869DC: BF8700D1
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000001869E0: D5207C07 01AA0880
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v5                        // 0000001869E8: 7C920AFF 00001F7F
	global_load_b32 v6, v[6:7], off                            // 0000001869F0: DC520000 067C0006
	v_add_nc_u32_e32 v7, 0x80, v5                              // 0000001869F8: 4A0E0AFF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 000000186A00: 8C04046A
	v_mov_b32_e32 v5, v7                                       // 000000186A04: 7E0A0307
	s_waitcnt vmcnt(0)                                         // 000000186A08: BF8903F7
	ds_store_b32 v8, v6                                        // 000000186A0C: D8340000 00000608
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000186A14: 917E047E
	s_cbranch_execnz 65513                                     // 000000186A18: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000186A1C: 8C7E047E
	s_load_b32 s50, s[0:1], 0x58                               // 000000186A20: F4000C80 F8000058
	v_or_b32_e32 v127, 0xffffff80, v0                          // 000000186A28: 38FE00FF FFFFFF80
	v_lshlrev_b32_e32 v5, 3, v0                                // 000000186A30: 300A0083
	v_lshlrev_b32_e32 v126, 2, v1                              // 000000186A34: 30FC0282
	v_mul_u32_u24_e32 v3, 0x210, v1                            // 000000186A38: 160602FF 00000210
	v_lshrrev_b32_e32 v4, 4, v0                                // 000000186A40: 32080084
	s_mov_b32 s4, 0                                            // 000000186A44: BE840080
	s_waitcnt lgkmcnt(0)                                       // 000000186A48: BF89FC07
	s_barrier                                                  // 000000186A4C: BFBD0000
	buffer_gl0_inv                                             // 000000186A50: E0AC0000 00000000
	s_cmp_gt_i32 s50, 0                                        // 000000186A58: BF028032
	s_cbranch_scc1 14                                          // 000000186A5C: BFA2000E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	v_dual_mov_b32 v115, 0 :: v_dual_and_b32 v114, 0x200, v5   // 000000186A60: CA240080 73720AFF 00000200
	v_or_b32_e32 v6, 0xffffff80, v0                            // 000000186A6C: 380C00FF FFFFFF80
	v_and_or_b32 v128, v4, 4, v3                               // 000000186A74: D6570080 040D0904
	s_delay_alu instid0(VALU_DEP_3)                            // 000000186A7C: BF870003
	v_dual_mov_b32 v1, s48 :: v_dual_mov_b32 v132, v115        // 000000186A80: CA100030 01840173
	v_mov_b32_e32 v2, s49                                      // 000000186A88: 7E040231
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 000000186A8C: 916A047E
	s_cbranch_vccz 1                                           // 000000186A90: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	s_branch 5565                                              // 000000186A94: BFA015BD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x588c>
	s_clause 0x2                                               // 000000186A98: BF850002
	s_load_b128 s[28:31], s[0:1], 0x18                         // 000000186A9C: F4080700 F8000018
	s_load_b64 s[8:9], s[0:1], 0x70                            // 000000186AA4: F4040200 F8000070
	s_load_b128 s[44:47], s[0:1], 0x60                         // 000000186AAC: F4080B00 F8000060
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000186AB4: 32020085
	s_add_i32 s10, s50, 63                                     // 000000186AB8: 810ABF32
	v_dual_mov_b32 v115, 0 :: v_dual_and_b32 v2, 15, v0        // 000000186ABC: CA240080 7302008F
	s_add_i32 s51, s2, 0xbd0                                   // 000000186AC4: 8133FF02 00000BD0
	s_add_i32 s52, s50, -1                                     // 000000186ACC: 8134C132
	s_lshr_b32 s53, s10, 6                                     // 000000186AD0: 8535860A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000186AD4: BF870001
	v_dual_mov_b32 v132, v115 :: v_dual_lshlrev_b32 v7, 4, v1  // 000000186AD8: CA220173 84060284
	v_mul_u32_u24_e32 v8, 0x2100, v1                           // 000000186AE0: 161002FF 00002100
	s_movk_i32 s11, 0x90                                       // 000000186AE8: B00B0090
	v_bfe_u32 v6, v0, 4, 1                                     // 000000186AEC: D6100006 02050900
	v_mad_u32_u24 v131, v2, s11, 0x8400                        // 000000186AF4: D60B0083 03FC1702 00008400
	v_or_b32_e32 v133, v7, v2                                  // 000000186B00: 390A0507
	v_mad_u32_u24 v8, 0x210, v2, v8                            // 000000186B04: D60B0008 042204FF 00000210
	s_mov_b32 s20, 0                                           // 000000186B10: BE940080
	s_load_b256 s[36:43], s[0:1], 0x80                         // 000000186B14: F40C0900 F8000080
	s_waitcnt lgkmcnt(0)                                       // 000000186B1C: BF89FC07
	s_add_u32 s12, s30, s48                                    // 000000186B20: 800C301E
	s_addc_u32 s13, s31, s49                                   // 000000186B24: 820D311F
	s_lshl_b32 s10, s2, 7                                      // 000000186B28: 840A8702
	s_mov_b32 s21, s20                                         // 000000186B2C: BE950014
	s_ashr_i32 s11, s10, 31                                    // 000000186B30: 860B9F0A
	s_mov_b32 s24, s20                                         // 000000186B34: BE980014
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000186B38: 848A810A
	s_mov_b32 s25, s20                                         // 000000186B3C: BE990014
	s_add_u32 s10, s22, s10                                    // 000000186B40: 800A0A16
	s_addc_u32 s11, s23, s11                                   // 000000186B44: 820B0B17
	s_mov_b32 s22, s20                                         // 000000186B48: BE960014
	s_mov_b32 s23, s20                                         // 000000186B4C: BE970014
	s_mov_b32 s26, s20                                         // 000000186B50: BE9A0014
	s_mov_b32 s27, s20                                         // 000000186B54: BE9B0014
	v_lshlrev_b32_e32 v9, 2, v2                                // 000000186B58: 30120482
	v_mul_u32_u24_e32 v130, 0x210, v2                          // 000000186B5C: 170404FF 00000210
	v_or_b32_e32 v134, v7, v6                                  // 000000186B64: 390C0D07
	v_lshl_or_b32 v135, v6, 2, v8                              // 000000186B68: D6560087 04210506
	v_lshlrev_b32_e32 v6, 7, v133                              // 000000186B70: 300D0A87
	v_lshlrev_b32_e32 v2, 1, v2                                // 000000186B74: 30040481
	s_lshl_b64 s[6:7], s[6:7], 1                               // 000000186B78: 84868106
	s_load_b64 s[0:1], s[0:1], 0xa0                            // 000000186B7C: F4040000 F80000A0
	s_add_u32 s10, s10, s6                                     // 000000186B84: 800A060A
	.long 0xd7000688                                           // 000000186B88: D7000688
	v_cndmask_b32_e32 v1, s12, v9, vcc_lo                      // 000000186B8C: 0202120C
	v_and_b32_e32 v114, 0x200, v5                              // 000000186B90: 36E40AFF 00000200
	s_addc_u32 s11, s11, s7                                    // 000000186B98: 820B070B
	v_add_co_ci_u32_e64 v137, null, s13, 0, s6                 // 000000186B9C: D5207C89 0019000D
	.long 0xd700068b                                           // 000000186BA4: D700068B
	v_cndmask_b32_e32 v1, s8, v6, vcc_lo                       // 000000186BA8: 02020C08
	.long 0xd7000874                                           // 000000186BAC: D7000874
	v_cndmask_b32_e32 v1, s10, v2, vcc_lo                      // 000000186BB0: 0202040A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000186BB4: BF870001
	v_add_co_ci_u32_e64 v117, null, s11, 0, s8                 // 000000186BB8: D5207C75 0021000B
	s_add_u32 s8, s48, s34                                     // 000000186BC0: 80082230
	v_add_co_ci_u32_e64 v140, null, s9, 0, s6                  // 000000186BC4: D5207C8C 00190009
	.long 0xd44d0006                                           // 000000186BCC: D44D0006
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000186BD0: 02020280
	s_addc_u32 s9, s49, s35                                    // 000000186BD4: 82092331
	.long 0xd7000801                                           // 000000186BD8: D7000801
	v_cndmask_b32_e32 v1, s8, v114, vcc_lo                     // 000000186BDC: 0202E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000186BE0: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s9, 0, s8                    // 000000186BE4: D5207C02 00210009
	v_and_or_b32 v128, v4, 4, v3                               // 000000186BEC: D6570080 040D0904
	.long 0xd7006a01                                           // 000000186BF4: D7006A01
	v_cndmask_b32_e32 v1, v1, v126, vcc_lo                     // 000000186BF8: 0202FD01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000186BFC: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000186C00: D5207C02 01AA0480
	.long 0xd44c0004                                           // 000000186C08: D44C0004
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 000000186C0C: 020200C0
	.long 0xd7006a76                                           // 000000186C10: D7006A76
	v_cndmask_b32_e32 v1, s40, v1, vcc_lo                      // 000000186C14: 02020228
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000186C18: BF8700A1
	v_add_co_ci_u32_e64 v119, null, s41, v2, vcc_lo            // 000000186C1C: D5207C77 01AA0429
	.long 0xd7006a78                                           // 000000186C24: D7006A78
	v_cndmask_b32_e32 v1, s42, v1, vcc_lo                      // 000000186C28: 0202022A
	v_add_co_ci_u32_e64 v121, null, s43, v2, vcc_lo            // 000000186C2C: D5207C79 01AA042B
	s_waitcnt lgkmcnt(0)                                       // 000000186C34: BF89FC07
	.long 0xd7006a7a                                           // 000000186C38: D7006A7A
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 000000186C3C: 02020200
	s_delay_alu instid0(VALU_DEP_1)                            // 000000186C40: BF870001
	v_add_co_ci_u32_e64 v123, null, s1, v2, vcc_lo             // 000000186C44: D5207C7B 01AA0401
	v_mov_b32_e32 v1, s20                                      // 000000186C4C: 7E020214
	.long 0xd4490005                                           // 000000186C50: D4490005
	v_cndmask_b32_e32 v1, 63, v0, vcc_lo                       // 000000186C54: 020200BF
	v_lshl_or_b32 v129, v0, 2, 0xa800                          // 000000186C58: D6560081 03FD0500 0000A800
	v_lshl_add_u32 v138, v134, 1, v131                         // 000000186C64: D646008A 060D0386
	.long 0xd4490007                                           // 000000186C6C: D4490007
	v_cndmask_b32_e32 v1, 0x5f, v0, vcc_lo                     // 000000186C70: 020200FF 0000005F
	v_lshl_or_b32 v141, v134, 2, 0xa800                        // 000000186C78: D656008D 03FD0586 0000A800
	v_dual_mov_b32 v2, s21 :: v_dual_mov_b32 v3, s22           // 000000186C84: CA100015 02020016
	v_dual_mov_b32 v4, s23 :: v_dual_mov_b32 v7, s26           // 000000186C8C: CA100017 0406001A
	v_dual_mov_b32 v5, s24 :: v_dual_mov_b32 v6, s25           // 000000186C94: CA100018 05060019
	v_mov_b32_e32 v8, s27                                      // 000000186C9C: 7E10021B
	s_mov_b32 s30, 0x41800000                                  // 000000186CA0: BE9E00FF 41800000
	s_mov_b32 s31, s20                                         // 000000186CA8: BE9F0014
	s_branch 4                                                 // 000000186CAC: BFA00004 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3c0>
	s_add_i32 s31, s31, 1                                      // 000000186CB0: 811F811F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000186CB4: BF870009
	s_cmp_eq_u32 s31, s53                                      // 000000186CB8: BF06351F
	s_cbranch_scc1 5424                                        // 000000186CBC: BFA21530 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5880>
	s_mul_i32 s0, s31, 0xc00                                   // 000000186CC0: 9600FF1F 00000C00
	s_lshl_b32 s40, s31, 6                                     // 000000186CC8: 8428861F
	s_add_i32 s0, s51, s0                                      // 000000186CCC: 81000033
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000186CD0: BF870499
	s_ashr_i32 s1, s0, 31                                      // 000000186CD4: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 000000186CD8: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000186CDC: BF870009
	s_add_u32 s0, s28, s0                                      // 000000186CE0: 8000001C
	s_addc_u32 s1, s29, s1                                     // 000000186CE4: 8201011D
	global_load_b32 v9, v115, s[0:1]                           // 000000186CE8: DC520000 09000073
	s_waitcnt vmcnt(0)                                         // 000000186CF0: BF8903F7
	v_readfirstlane_b32 s39, v9                                // 000000186CF4: 7E4E0509
	s_and_saveexec_b32 s0, s4                                  // 000000186CF8: BE802004
	s_cbranch_execz 42                                         // 000000186CFC: BFA5002A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4a8>
	v_or_b32_e32 v9, s40, v0                                   // 000000186D00: 38120028
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000186D04: BF870091
	v_mad_u64_u32 v[9:10], null, v9, 48, s[2:3]                // 000000186D08: D6FE7C09 00096109
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000186D10: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000186D14: BF870091
	.long 0xd73c0009                                           // 000000186D18: D73C0009
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000186D1C: 02021282
	.long 0xd7006a09                                           // 000000186D20: D7006A09
	v_cndmask_b32_e32 v1, s28, v9, vcc_lo                      // 000000186D24: 0202121C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000186D28: BF870151
	v_add_co_ci_u32_e64 v10, null, s29, v10, vcc_lo            // 000000186D2C: D5207C0A 01AA141D
	global_load_b32 v9, v[9:10], off                           // 000000186D34: DC520000 097C0009
	s_waitcnt vmcnt(0)                                         // 000000186D3C: BF8903F7
	v_mul_f32_e32 v10, 0x3fb8aa3b, v9                          // 000000186D40: 101412FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v9                   // 000000186D48: 7C3612FF C2CE8ED0
	v_fma_f32 v11, 0x3fb8aa3b, v9, -v10                        // 000000186D50: D613000B 842A12FF 3FB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000186D5C: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000186D60: BF870091
	v_dual_fmac_f32 v11, 0x32a5705f, v9 :: v_dual_sub_f32 v10, v10, v12// 000000186D64: C80A12FF 0B0A190A 32A5705F
	v_add_f32_e32 v10, v10, v11                                // 000000186D70: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000186D74: 7E16110C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000186D78: BF870292
	v_exp_f32_e32 v10, v10                                     // 000000186D7C: 7E144B0A
	.long 0xd71c000a                                           // 000000186D80: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000186D84: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000186D88: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000186D8C: 02141480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v9                   // 000000186D90: 7C3C12FF 42B17218
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000186D98: 021214FF 7F800000
	ds_store_b32 v129, v9                                      // 000000186DA0: D8340000 00000981
	s_or_b32 exec_lo, exec_lo, s0                              // 000000186DA8: 8C7E007E
	v_add_nc_u32_e32 v17, s40, v133                            // 000000186DAC: 4A230A28
	s_waitcnt lgkmcnt(0)                                       // 000000186DB0: BF89FC07
	s_barrier                                                  // 000000186DB4: BFBD0000
	buffer_gl0_inv                                             // 000000186DB8: E0AC0000 00000000
	v_min_i32_e32 v9, s52, v17                                 // 000000186DC0: 22122234
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000186DC4: BF870091
	v_mad_i64_i32 v[9:10], null, v9, 48, s[2:3]                // 000000186DC8: D6FF7C09 00096109
	.long 0xd73c0069                                           // 000000186DD0: D73C0069
	v_cndmask_b32_e32 v1, 8, v9, vcc_lo                        // 000000186DD4: 02021288
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000186DD8: BF870091
	.long 0xd7006a0d                                           // 000000186DDC: D7006A0D
	v_cndmask_b32_e32 v1, s46, v105, vcc_lo                    // 000000186DE0: 0202D22E
	v_add_co_ci_u32_e64 v14, null, s47, v106, vcc_lo           // 000000186DE4: D5207C0E 01AAD42F
	v_cmp_le_i32_e32 vcc_lo, s50, v17                          // 000000186DEC: 7C862232
	s_clause 0xf                                               // 000000186DF0: BF85000F
	global_load_b128 v[97:100], v[13:14], off                  // 000000186DF4: DC5E0000 617C000D
	global_load_b128 v[101:104], v[13:14], off offset:16       // 000000186DFC: DC5E0010 657C000D
	global_load_b128 v[89:92], v[13:14], off offset:32         // 000000186E04: DC5E0020 597C000D
	global_load_b128 v[93:96], v[13:14], off offset:48         // 000000186E0C: DC5E0030 5D7C000D
	global_load_b128 v[81:84], v[13:14], off offset:64         // 000000186E14: DC5E0040 517C000D
	global_load_b128 v[85:88], v[13:14], off offset:80         // 000000186E1C: DC5E0050 557C000D
	global_load_b128 v[73:76], v[13:14], off offset:96         // 000000186E24: DC5E0060 497C000D
	global_load_b128 v[77:80], v[13:14], off offset:112        // 000000186E2C: DC5E0070 4D7C000D
	global_load_b128 v[65:68], v[13:14], off offset:128        // 000000186E34: DC5E0080 417C000D
	global_load_b128 v[69:72], v[13:14], off offset:144        // 000000186E3C: DC5E0090 457C000D
	global_load_b128 v[57:60], v[13:14], off offset:160        // 000000186E44: DC5E00A0 397C000D
	global_load_b128 v[61:64], v[13:14], off offset:176        // 000000186E4C: DC5E00B0 3D7C000D
	global_load_b128 v[49:52], v[13:14], off offset:192        // 000000186E54: DC5E00C0 317C000D
	global_load_b128 v[53:56], v[13:14], off offset:208        // 000000186E5C: DC5E00D0 357C000D
	global_load_b128 v[9:12], v[13:14], off offset:224         // 000000186E64: DC5E00E0 097C000D
	global_load_b128 v[13:16], v[13:14], off offset:240        // 000000186E6C: DC5E00F0 0D7C000D
	s_and_saveexec_b32 s0, vcc_lo                              // 000000186E74: BE80206A
	s_cbranch_execz 67                                         // 000000186E78: BFA50043 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x688>
	s_waitcnt vmcnt(1)                                         // 000000186E7C: BF8907F7
	v_mov_b32_e32 v9, 0                                        // 000000186E80: 7E120280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000186E84: BF870001
	v_mov_b32_e32 v10, v9                                      // 000000186E88: 7E140309
	v_mov_b32_e32 v11, v9                                      // 000000186E8C: 7E160309
	v_mov_b32_e32 v12, v9                                      // 000000186E90: 7E180309
	s_waitcnt vmcnt(0)                                         // 000000186E94: BF8903F7
	v_mov_b32_e32 v13, v9                                      // 000000186E98: 7E1A0309
	v_mov_b32_e32 v14, v9                                      // 000000186E9C: 7E1C0309
	v_mov_b32_e32 v15, v9                                      // 000000186EA0: 7E1E0309
	v_mov_b32_e32 v16, v9                                      // 000000186EA4: 7E200309
	v_mov_b32_e32 v49, v9                                      // 000000186EA8: 7E620309
	v_mov_b32_e32 v50, v9                                      // 000000186EAC: 7E640309
	v_mov_b32_e32 v51, v9                                      // 000000186EB0: 7E660309
	v_mov_b32_e32 v52, v9                                      // 000000186EB4: 7E680309
	v_mov_b32_e32 v53, v9                                      // 000000186EB8: 7E6A0309
	v_mov_b32_e32 v54, v9                                      // 000000186EBC: 7E6C0309
	v_mov_b32_e32 v55, v9                                      // 000000186EC0: 7E6E0309
	v_mov_b32_e32 v56, v9                                      // 000000186EC4: 7E700309
	v_mov_b32_e32 v57, v9                                      // 000000186EC8: 7E720309
	v_mov_b32_e32 v58, v9                                      // 000000186ECC: 7E740309
	v_mov_b32_e32 v59, v9                                      // 000000186ED0: 7E760309
	v_mov_b32_e32 v60, v9                                      // 000000186ED4: 7E780309
	v_mov_b32_e32 v61, v9                                      // 000000186ED8: 7E7A0309
	v_mov_b32_e32 v62, v9                                      // 000000186EDC: 7E7C0309
	v_mov_b32_e32 v63, v9                                      // 000000186EE0: 7E7E0309
	v_mov_b32_e32 v64, v9                                      // 000000186EE4: 7E800309
	v_mov_b32_e32 v65, v9                                      // 000000186EE8: 7E820309
	v_mov_b32_e32 v66, v9                                      // 000000186EEC: 7E840309
	v_mov_b32_e32 v67, v9                                      // 000000186EF0: 7E860309
	v_mov_b32_e32 v68, v9                                      // 000000186EF4: 7E880309
	v_mov_b32_e32 v69, v9                                      // 000000186EF8: 7E8A0309
	v_mov_b32_e32 v70, v9                                      // 000000186EFC: 7E8C0309
	v_mov_b32_e32 v71, v9                                      // 000000186F00: 7E8E0309
	v_mov_b32_e32 v72, v9                                      // 000000186F04: 7E900309
	v_mov_b32_e32 v73, v9                                      // 000000186F08: 7E920309
	v_mov_b32_e32 v74, v9                                      // 000000186F0C: 7E940309
	v_mov_b32_e32 v75, v9                                      // 000000186F10: 7E960309
	v_mov_b32_e32 v76, v9                                      // 000000186F14: 7E980309
	v_mov_b32_e32 v77, v9                                      // 000000186F18: 7E9A0309
	v_mov_b32_e32 v78, v9                                      // 000000186F1C: 7E9C0309
	v_mov_b32_e32 v79, v9                                      // 000000186F20: 7E9E0309
	v_mov_b32_e32 v80, v9                                      // 000000186F24: 7EA00309
	v_mov_b32_e32 v81, v9                                      // 000000186F28: 7EA20309
	v_mov_b32_e32 v82, v9                                      // 000000186F2C: 7EA40309
	v_mov_b32_e32 v83, v9                                      // 000000186F30: 7EA60309
	v_mov_b32_e32 v84, v9                                      // 000000186F34: 7EA80309
	v_mov_b32_e32 v85, v9                                      // 000000186F38: 7EAA0309
	v_mov_b32_e32 v86, v9                                      // 000000186F3C: 7EAC0309
	v_mov_b32_e32 v87, v9                                      // 000000186F40: 7EAE0309
	v_mov_b32_e32 v88, v9                                      // 000000186F44: 7EB00309
	v_mov_b32_e32 v89, v9                                      // 000000186F48: 7EB20309
	v_mov_b32_e32 v90, v9                                      // 000000186F4C: 7EB40309
	v_mov_b32_e32 v91, v9                                      // 000000186F50: 7EB60309
	v_mov_b32_e32 v92, v9                                      // 000000186F54: 7EB80309
	v_mov_b32_e32 v93, v9                                      // 000000186F58: 7EBA0309
	v_mov_b32_e32 v94, v9                                      // 000000186F5C: 7EBC0309
	v_mov_b32_e32 v95, v9                                      // 000000186F60: 7EBE0309
	v_mov_b32_e32 v96, v9                                      // 000000186F64: 7EC00309
	v_mov_b32_e32 v97, v9                                      // 000000186F68: 7EC20309
	v_mov_b32_e32 v98, v9                                      // 000000186F6C: 7EC40309
	v_mov_b32_e32 v99, v9                                      // 000000186F70: 7EC60309
	v_mov_b32_e32 v100, v9                                     // 000000186F74: 7EC80309
	v_mov_b32_e32 v101, v9                                     // 000000186F78: 7ECA0309
	v_mov_b32_e32 v102, v9                                     // 000000186F7C: 7ECC0309
	v_mov_b32_e32 v103, v9                                     // 000000186F80: 7ECE0309
	v_mov_b32_e32 v104, v9                                     // 000000186F84: 7ED00309
	s_or_b32 exec_lo, exec_lo, s0                              // 000000186F88: 8C7E007E
	ds_load_b128 v[17:20], v130                                // 000000186F8C: DBFC0000 11000082
	ds_load_b128 v[21:24], v130 offset:16                      // 000000186F94: DBFC0010 15000082
	ds_load_b128 v[25:28], v130 offset:32                      // 000000186F9C: DBFC0020 19000082
	ds_load_b128 v[29:32], v130 offset:48                      // 000000186FA4: DBFC0030 1D000082
	ds_load_b128 v[33:36], v130 offset:8448                    // 000000186FAC: DBFC2100 21000082
	ds_load_b128 v[37:40], v130 offset:8464                    // 000000186FB4: DBFC2110 25000082
	ds_load_b128 v[41:44], v130 offset:8480                    // 000000186FBC: DBFC2120 29000082
	ds_load_b128 v[45:48], v130 offset:8496                    // 000000186FC4: DBFC2130 2D000082
	ds_load_b128 v[107:110], v130 offset:16896                 // 000000186FCC: DBFC4200 6B000082
	ds_load_b128 v[142:145], v130 offset:16912                 // 000000186FD4: DBFC4210 8E000082
	ds_load_b128 v[146:149], v130 offset:25344                 // 000000186FDC: DBFC6300 92000082
	ds_load_b128 v[150:153], v130 offset:25360                 // 000000186FE4: DBFC6310 96000082
	ds_load_b128 v[158:161], v130 offset:64                    // 000000186FEC: DBFC0040 9E000082
	ds_load_b128 v[162:165], v130 offset:16992                 // 000000186FF4: DBFC4260 A2000082
	ds_load_b128 v[166:169], v130 offset:17008                 // 000000186FFC: DBFC4270 A6000082
	ds_load_b128 v[174:177], v130 offset:25440                 // 000000187004: DBFC6360 AE000082
	ds_load_b128 v[178:181], v130 offset:25456                 // 00000018700C: DBFC6370 B2000082
	ds_load_b128 v[154:157], v130 offset:25392                 // 000000187014: DBFC6330 9A000082
	ds_load_b128 v[170:173], v130 offset:25424                 // 00000018701C: DBFC6350 AA000082
	s_waitcnt lgkmcnt(18)                                      // 000000187024: BF89FD27
	v_fma_mixlo_f16 v17, v17, s30, 0                           // 000000187028: CC210011 02003D11
	v_fma_mixhi_f16 v17, v18, s30, 0                           // 000000187030: CC220011 02003D12
	v_fma_mixlo_f16 v18, v19, s30, 0                           // 000000187038: CC210012 02003D13
	v_fma_mixhi_f16 v18, v20, s30, 0                           // 000000187040: CC220012 02003D14
	s_waitcnt lgkmcnt(17)                                      // 000000187048: BF89FD17
	v_fma_mixlo_f16 v19, v21, s30, 0                           // 00000018704C: CC210013 02003D15
	v_fma_mixhi_f16 v19, v22, s30, 0                           // 000000187054: CC220013 02003D16
	v_fma_mixlo_f16 v20, v23, s30, 0                           // 00000018705C: CC210014 02003D17
	v_fma_mixhi_f16 v20, v24, s30, 0                           // 000000187064: CC220014 02003D18
	s_waitcnt lgkmcnt(16)                                      // 00000018706C: BF89FD07
	v_fma_mixlo_f16 v21, v25, s30, 0                           // 000000187070: CC210015 02003D19
	v_fma_mixhi_f16 v21, v26, s30, 0                           // 000000187078: CC220015 02003D1A
	v_fma_mixlo_f16 v22, v27, s30, 0                           // 000000187080: CC210016 02003D1B
	v_fma_mixhi_f16 v22, v28, s30, 0                           // 000000187088: CC220016 02003D1C
	s_waitcnt lgkmcnt(15)                                      // 000000187090: BF89FCF7
	v_fma_mixlo_f16 v23, v29, s30, 0                           // 000000187094: CC210017 02003D1D
	v_fma_mixhi_f16 v23, v30, s30, 0                           // 00000018709C: CC220017 02003D1E
	v_fma_mixlo_f16 v24, v31, s30, 0                           // 0000001870A4: CC210018 02003D1F
	v_fma_mixhi_f16 v24, v32, s30, 0                           // 0000001870AC: CC220018 02003D20
	s_waitcnt lgkmcnt(14)                                      // 0000001870B4: BF89FCE7
	v_fma_mixlo_f16 v25, v33, s30, 0                           // 0000001870B8: CC210019 02003D21
	v_fma_mixhi_f16 v25, v34, s30, 0                           // 0000001870C0: CC220019 02003D22
	v_fma_mixlo_f16 v26, v35, s30, 0                           // 0000001870C8: CC21001A 02003D23
	v_fma_mixhi_f16 v26, v36, s30, 0                           // 0000001870D0: CC22001A 02003D24
	s_waitcnt lgkmcnt(13)                                      // 0000001870D8: BF89FCD7
	v_fma_mixlo_f16 v27, v37, s30, 0                           // 0000001870DC: CC21001B 02003D25
	v_fma_mixhi_f16 v27, v38, s30, 0                           // 0000001870E4: CC22001B 02003D26
	v_fma_mixlo_f16 v28, v39, s30, 0                           // 0000001870EC: CC21001C 02003D27
	v_fma_mixhi_f16 v28, v40, s30, 0                           // 0000001870F4: CC22001C 02003D28
	s_waitcnt lgkmcnt(12)                                      // 0000001870FC: BF89FCC7
	v_fma_mixlo_f16 v29, v41, s30, 0                           // 000000187100: CC21001D 02003D29
	v_fma_mixhi_f16 v29, v42, s30, 0                           // 000000187108: CC22001D 02003D2A
	v_fma_mixlo_f16 v30, v43, s30, 0                           // 000000187110: CC21001E 02003D2B
	v_fma_mixhi_f16 v30, v44, s30, 0                           // 000000187118: CC22001E 02003D2C
	s_waitcnt lgkmcnt(11)                                      // 000000187120: BF89FCB7
	v_fma_mixlo_f16 v31, v45, s30, 0                           // 000000187124: CC21001F 02003D2D
	v_fma_mixhi_f16 v31, v46, s30, 0                           // 00000018712C: CC22001F 02003D2E
	v_fma_mixlo_f16 v32, v47, s30, 0                           // 000000187134: CC210020 02003D2F
	v_fma_mixhi_f16 v32, v48, s30, 0                           // 00000018713C: CC220020 02003D30
	s_waitcnt vmcnt(14)                                        // 000000187144: BF893BF7
	v_wmma_f32_16x16x16_f16 v[33:40], v[97:104], v[17:24], v[1:8]// 000000187148: CC404021 1C062361
	ds_load_b128 v[41:44], v130 offset:16928                   // 000000187150: DBFC4220 29000082
	ds_load_b128 v[45:48], v130 offset:16944                   // 000000187158: DBFC4230 2D000082
	v_wmma_f32_16x16x16_f16 v[17:24], v[97:104], v[25:32], v[1:8]// 000000187160: CC404011 1C063361
	s_waitcnt lgkmcnt(12)                                      // 000000187168: BF89FCC7
	v_fma_mixlo_f16 v25, v107, s30, 0                          // 00000018716C: CC210019 02003D6B
	v_fma_mixhi_f16 v25, v108, s30, 0                          // 000000187174: CC220019 02003D6C
	v_fma_mixlo_f16 v26, v109, s30, 0                          // 00000018717C: CC21001A 02003D6D
	v_fma_mixhi_f16 v26, v110, s30, 0                          // 000000187184: CC22001A 02003D6E
	ds_load_b128 v[107:110], v130 offset:25376                 // 00000018718C: DBFC6320 6B000082
	s_waitcnt lgkmcnt(12)                                      // 000000187194: BF89FCC7
	v_fma_mixlo_f16 v27, v142, s30, 0                          // 000000187198: CC21001B 02003D8E
	v_fma_mixlo_f16 v28, v144, s30, 0                          // 0000001871A0: CC21001C 02003D90
	v_fma_mixhi_f16 v28, v145, s30, 0                          // 0000001871A8: CC22001C 02003D91
	s_waitcnt lgkmcnt(11)                                      // 0000001871B0: BF89FCB7
	v_fma_mixlo_f16 v142, v146, s30, 0                         // 0000001871B4: CC21008E 02003D92
	v_fma_mixhi_f16 v142, v147, s30, 0                         // 0000001871BC: CC22008E 02003D93
	s_waitcnt lgkmcnt(10)                                      // 0000001871C4: BF89FCA7
	v_fma_mixlo_f16 v144, v150, s30, 0                         // 0000001871C8: CC210090 02003D96
	v_fma_mixhi_f16 v144, v151, s30, 0                         // 0000001871D0: CC220090 02003D97
	v_fma_mixlo_f16 v145, v152, s30, 0                         // 0000001871D8: CC210091 02003D98
	v_fma_mixhi_f16 v145, v153, s30, 0                         // 0000001871E0: CC220091 02003D99
	ds_load_b128 v[150:153], v130 offset:80                    // 0000001871E8: DBFC0050 96000082
	v_fma_mixhi_f16 v27, v143, s30, 0                          // 0000001871F0: CC22001B 02003D8F
	s_waitcnt lgkmcnt(3)                                       // 0000001871F8: BF89FC37
	v_fma_mixlo_f16 v29, v41, s30, 0                           // 0000001871FC: CC21001D 02003D29
	v_fma_mixhi_f16 v29, v42, s30, 0                           // 000000187204: CC22001D 02003D2A
	v_fma_mixlo_f16 v30, v43, s30, 0                           // 00000018720C: CC21001E 02003D2B
	v_fma_mixhi_f16 v30, v44, s30, 0                           // 000000187214: CC22001E 02003D2C
	s_waitcnt lgkmcnt(2)                                       // 00000018721C: BF89FC27
	v_fma_mixlo_f16 v31, v45, s30, 0                           // 000000187220: CC21001F 02003D2D
	v_fma_mixhi_f16 v31, v46, s30, 0                           // 000000187228: CC22001F 02003D2E
	v_fma_mixlo_f16 v32, v47, s30, 0                           // 000000187230: CC210020 02003D2F
	v_fma_mixhi_f16 v32, v48, s30, 0                           // 000000187238: CC220020 02003D30
	s_waitcnt lgkmcnt(1)                                       // 000000187240: BF89FC17
	v_fma_mixlo_f16 v146, v107, s30, 0                         // 000000187244: CC210092 02003D6B
	v_fma_mixhi_f16 v146, v108, s30, 0                         // 00000018724C: CC220092 02003D6C
	v_fma_mixlo_f16 v147, v109, s30, 0                         // 000000187254: CC210093 02003D6D
	v_fma_mixhi_f16 v147, v110, s30, 0                         // 00000018725C: CC220093 02003D6E
	ds_load_b128 v[107:110], v130 offset:96                    // 000000187264: DBFC0060 6B000082
	v_fma_mixlo_f16 v143, v148, s30, 0                         // 00000018726C: CC21008F 02003D94
	v_fma_mixhi_f16 v143, v149, s30, 0                         // 000000187274: CC22008F 02003D95
	v_fma_mixlo_f16 v148, v154, s30, 0                         // 00000018727C: CC210094 02003D9A
	v_fma_mixhi_f16 v148, v155, s30, 0                         // 000000187284: CC220094 02003D9B
	v_fma_mixlo_f16 v149, v156, s30, 0                         // 00000018728C: CC210095 02003D9C
	v_fma_mixhi_f16 v149, v157, s30, 0                         // 000000187294: CC220095 02003D9D
	ds_load_b128 v[154:157], v130 offset:112                   // 00000018729C: DBFC0070 9A000082
	v_wmma_f32_16x16x16_f16 v[41:48], v[97:104], v[25:32], v[1:8]// 0000001872A4: CC404029 1C063361
	v_wmma_f32_16x16x16_f16 v[25:32], v[97:104], v[142:149], v[1:8]// 0000001872AC: CC404019 1C071D61
	ds_load_b128 v[142:145], v130 offset:8512                  // 0000001872B4: DBFC2140 8E000082
	ds_load_b128 v[146:149], v130 offset:8528                  // 0000001872BC: DBFC2150 92000082
	s_waitcnt lgkmcnt(4)                                       // 0000001872C4: BF89FC47
	v_fma_mixlo_f16 v99, v150, s30, 0                          // 0000001872C8: CC210063 02003D96
	v_fma_mixhi_f16 v99, v151, s30, 0                          // 0000001872D0: CC220063 02003D97
	v_fma_mixlo_f16 v100, v152, s30, 0                         // 0000001872D8: CC210064 02003D98
	v_fma_mixhi_f16 v100, v153, s30, 0                         // 0000001872E0: CC220064 02003D99
	ds_load_b128 v[150:153], v130 offset:8544                  // 0000001872E8: DBFC2160 96000082
	s_waitcnt lgkmcnt(4)                                       // 0000001872F0: BF89FC47
	v_fma_mixlo_f16 v101, v107, s30, 0                         // 0000001872F4: CC210065 02003D6B
	v_fma_mixhi_f16 v101, v108, s30, 0                         // 0000001872FC: CC220065 02003D6C
	v_fma_mixlo_f16 v102, v109, s30, 0                         // 000000187304: CC210066 02003D6D
	v_fma_mixhi_f16 v102, v110, s30, 0                         // 00000018730C: CC220066 02003D6E
	ds_load_b128 v[107:110], v130 offset:8560                  // 000000187314: DBFC2170 6B000082
	v_fma_mixlo_f16 v97, v158, s30, 0                          // 00000018731C: CC210061 02003D9E
	v_fma_mixhi_f16 v97, v159, s30, 0                          // 000000187324: CC220061 02003D9F
	v_fma_mixlo_f16 v98, v160, s30, 0                          // 00000018732C: CC210062 02003DA0
	v_fma_mixhi_f16 v98, v161, s30, 0                          // 000000187334: CC220062 02003DA1
	s_waitcnt lgkmcnt(4)                                       // 00000018733C: BF89FC47
	v_fma_mixlo_f16 v103, v154, s30, 0                         // 000000187340: CC210067 02003D9A
	v_fma_mixhi_f16 v103, v155, s30, 0                         // 000000187348: CC220067 02003D9B
	v_fma_mixlo_f16 v104, v156, s30, 0                         // 000000187350: CC210068 02003D9C
	v_fma_mixhi_f16 v104, v157, s30, 0                         // 000000187358: CC220068 02003D9D
	s_waitcnt lgkmcnt(3)                                       // 000000187360: BF89FC37
	v_fma_mixlo_f16 v142, v142, s30, 0                         // 000000187364: CC21008E 02003D8E
	ds_load_b128 v[154:157], v130 offset:16960                 // 00000018736C: DBFC4240 9A000082
	ds_load_b128 v[158:161], v130 offset:16976                 // 000000187374: DBFC4250 9E000082
	v_fma_mixhi_f16 v142, v143, s30, 0                         // 00000018737C: CC22008E 02003D8F
	v_fma_mixhi_f16 v143, v145, s30, 0                         // 000000187384: CC22008F 02003D91
	s_waitcnt lgkmcnt(4)                                       // 00000018738C: BF89FC47
	v_fma_mixlo_f16 v145, v148, s30, 0                         // 000000187390: CC210091 02003D94
	v_fma_mixhi_f16 v145, v149, s30, 0                         // 000000187398: CC220091 02003D95
	v_fma_mixlo_f16 v143, v144, s30, 0                         // 0000001873A0: CC21008F 02003D90
	v_fma_mixhi_f16 v144, v147, s30, 0                         // 0000001873A8: CC220090 02003D93
	s_waitcnt lgkmcnt(3)                                       // 0000001873B0: BF89FC37
	v_fma_mixlo_f16 v147, v152, s30, 0                         // 0000001873B4: CC210093 02003D98
	v_fma_mixlo_f16 v144, v146, s30, 0                         // 0000001873BC: CC210090 02003D92
	s_waitcnt lgkmcnt(2)                                       // 0000001873C4: BF89FC27
	v_fma_mixlo_f16 v148, v107, s30, 0                         // 0000001873C8: CC210094 02003D6B
	v_fma_mixhi_f16 v148, v108, s30, 0                         // 0000001873D0: CC220094 02003D6C
	v_fma_mixlo_f16 v149, v109, s30, 0                         // 0000001873D8: CC210095 02003D6D
	v_fma_mixhi_f16 v149, v110, s30, 0                         // 0000001873E0: CC220095 02003D6E
	ds_load_b128 v[107:110], v130 offset:25408                 // 0000001873E8: DBFC6340 6B000082
	v_fma_mixlo_f16 v146, v150, s30, 0                         // 0000001873F0: CC210092 02003D96
	v_fma_mixhi_f16 v146, v151, s30, 0                         // 0000001873F8: CC220092 02003D97
	v_fma_mixhi_f16 v147, v153, s30, 0                         // 000000187400: CC220093 02003D99
	s_waitcnt vmcnt(12)                                        // 000000187408: BF8933F7
	v_wmma_f32_16x16x16_f16 v[33:40], v[89:96], v[97:104], v[33:40]// 00000018740C: CC404021 1C86C359
	ds_load_b128 v[97:100], v130 offset:176                    // 000000187414: DBFC00B0 61000082
	s_waitcnt lgkmcnt(3)                                       // 00000018741C: BF89FC37
	v_fma_mixlo_f16 v150, v154, s30, 0                         // 000000187420: CC210096 02003D9A
	s_waitcnt lgkmcnt(2)                                       // 000000187428: BF89FC27
	v_fma_mixlo_f16 v152, v158, s30, 0                         // 00000018742C: CC210098 02003D9E
	v_fma_mixhi_f16 v152, v159, s30, 0                         // 000000187434: CC220098 02003D9F
	v_fma_mixhi_f16 v150, v155, s30, 0                         // 00000018743C: CC220096 02003D9B
	v_fma_mixlo_f16 v151, v156, s30, 0                         // 000000187444: CC210097 02003D9C
	v_fma_mixhi_f16 v151, v157, s30, 0                         // 00000018744C: CC220097 02003D9D
	v_fma_mixlo_f16 v153, v160, s30, 0                         // 000000187454: CC210099 02003DA0
	v_fma_mixhi_f16 v153, v161, s30, 0                         // 00000018745C: CC220099 02003DA1
	v_fma_mixlo_f16 v154, v162, s30, 0                         // 000000187464: CC21009A 02003DA2
	v_fma_mixhi_f16 v154, v163, s30, 0                         // 00000018746C: CC22009A 02003DA3
	v_fma_mixlo_f16 v155, v164, s30, 0                         // 000000187474: CC21009B 02003DA4
	v_fma_mixhi_f16 v155, v165, s30, 0                         // 00000018747C: CC22009B 02003DA5
	v_fma_mixlo_f16 v156, v166, s30, 0                         // 000000187484: CC21009C 02003DA6
	v_fma_mixhi_f16 v156, v167, s30, 0                         // 00000018748C: CC22009C 02003DA7
	s_waitcnt lgkmcnt(1)                                       // 000000187494: BF89FC17
	v_fma_mixlo_f16 v158, v107, s30, 0                         // 000000187498: CC21009E 02003D6B
	v_fma_mixhi_f16 v158, v108, s30, 0                         // 0000001874A0: CC22009E 02003D6C
	v_fma_mixlo_f16 v159, v109, s30, 0                         // 0000001874A8: CC21009F 02003D6D
	v_fma_mixhi_f16 v159, v110, s30, 0                         // 0000001874B0: CC22009F 02003D6E
	ds_load_b128 v[107:110], v130 offset:128                   // 0000001874B8: DBFC0080 6B000082
	v_fma_mixlo_f16 v157, v168, s30, 0                         // 0000001874C0: CC21009D 02003DA8
	v_fma_mixhi_f16 v157, v169, s30, 0                         // 0000001874C8: CC22009D 02003DA9
	v_fma_mixlo_f16 v160, v170, s30, 0                         // 0000001874D0: CC2100A0 02003DAA
	v_fma_mixhi_f16 v160, v171, s30, 0                         // 0000001874D8: CC2200A0 02003DAB
	v_fma_mixlo_f16 v161, v172, s30, 0                         // 0000001874E0: CC2100A1 02003DAC
	v_fma_mixhi_f16 v161, v173, s30, 0                         // 0000001874E8: CC2200A1 02003DAD
	v_fma_mixlo_f16 v162, v174, s30, 0                         // 0000001874F0: CC2100A2 02003DAE
	v_fma_mixhi_f16 v162, v175, s30, 0                         // 0000001874F8: CC2200A2 02003DAF
	v_fma_mixlo_f16 v163, v176, s30, 0                         // 000000187500: CC2100A3 02003DB0
	v_fma_mixhi_f16 v163, v177, s30, 0                         // 000000187508: CC2200A3 02003DB1
	v_fma_mixlo_f16 v164, v178, s30, 0                         // 000000187510: CC2100A4 02003DB2
	v_fma_mixhi_f16 v164, v179, s30, 0                         // 000000187518: CC2200A4 02003DB3
	v_fma_mixlo_f16 v165, v180, s30, 0                         // 000000187520: CC2100A5 02003DB4
	v_fma_mixhi_f16 v165, v181, s30, 0                         // 000000187528: CC2200A5 02003DB5
	ds_load_b128 v[166:169], v130 offset:144                   // 000000187530: DBFC0090 A6000082
	ds_load_b128 v[170:173], v130 offset:160                   // 000000187538: DBFC00A0 AA000082
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[142:149], v[17:24]// 000000187540: CC404011 1C471D59
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[150:157], v[41:48]// 000000187548: CC404029 1CA72D59
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[158:165], v[25:32]// 000000187550: CC404019 1C673D59
	ds_load_b128 v[101:104], v130 offset:8576                  // 000000187558: DBFC2180 65000082
	s_waitcnt lgkmcnt(3)                                       // 000000187560: BF89FC37
	v_fma_mixlo_f16 v89, v107, s30, 0                          // 000000187564: CC210059 02003D6B
	v_fma_mixhi_f16 v89, v108, s30, 0                          // 00000018756C: CC220059 02003D6C
	v_fma_mixlo_f16 v90, v109, s30, 0                          // 000000187574: CC21005A 02003D6D
	v_fma_mixhi_f16 v90, v110, s30, 0                          // 00000018757C: CC22005A 02003D6E
	ds_load_b128 v[107:110], v130 offset:8592                  // 000000187584: DBFC2190 6B000082
	ds_load_b128 v[142:145], v130 offset:8608                  // 00000018758C: DBFC21A0 8E000082
	ds_load_b128 v[146:149], v130 offset:8624                  // 000000187594: DBFC21B0 92000082
	v_fma_mixlo_f16 v96, v99, s30, 0                           // 00000018759C: CC210060 02003D63
	v_fma_mixhi_f16 v96, v100, s30, 0                          // 0000001875A4: CC220060 02003D64
	ds_load_b128 v[150:153], v130 offset:17024                 // 0000001875AC: DBFC4280 96000082
	ds_load_b128 v[154:157], v130 offset:17040                 // 0000001875B4: DBFC4290 9A000082
	ds_load_b128 v[158:161], v130 offset:17072                 // 0000001875BC: DBFC42B0 9E000082
	ds_load_b128 v[162:165], v130 offset:25472                 // 0000001875C4: DBFC6380 A2000082
	ds_load_b128 v[174:177], v130 offset:25520                 // 0000001875CC: DBFC63B0 AE000082
	s_waitcnt lgkmcnt(10)                                      // 0000001875D4: BF89FCA7
	v_fma_mixlo_f16 v91, v166, s30, 0                          // 0000001875D8: CC21005B 02003DA6
	v_fma_mixhi_f16 v91, v167, s30, 0                          // 0000001875E0: CC22005B 02003DA7
	v_fma_mixlo_f16 v92, v168, s30, 0                          // 0000001875E8: CC21005C 02003DA8
	v_fma_mixhi_f16 v92, v169, s30, 0                          // 0000001875F0: CC22005C 02003DA9
	s_waitcnt lgkmcnt(9)                                       // 0000001875F8: BF89FC97
	v_fma_mixlo_f16 v93, v170, s30, 0                          // 0000001875FC: CC21005D 02003DAA
	v_fma_mixhi_f16 v93, v171, s30, 0                          // 000000187604: CC22005D 02003DAB
	v_fma_mixlo_f16 v94, v172, s30, 0                          // 00000018760C: CC21005E 02003DAC
	v_fma_mixhi_f16 v94, v173, s30, 0                          // 000000187614: CC22005E 02003DAD
	ds_load_b128 v[166:169], v130 offset:25488                 // 00000018761C: DBFC6390 A6000082
	ds_load_b128 v[170:173], v130 offset:25504                 // 000000187624: DBFC63A0 AA000082
	s_waitcnt lgkmcnt(9)                                       // 00000018762C: BF89FC97
	v_fma_mixlo_f16 v99, v107, s30, 0                          // 000000187630: CC210063 02003D6B
	v_fma_mixhi_f16 v99, v108, s30, 0                          // 000000187638: CC220063 02003D6C
	v_fma_mixlo_f16 v100, v109, s30, 0                         // 000000187640: CC210064 02003D6D
	v_fma_mixhi_f16 v100, v110, s30, 0                         // 000000187648: CC220064 02003D6E
	ds_load_b128 v[107:110], v130 offset:17056                 // 000000187650: DBFC42A0 6B000082
	v_fma_mixhi_f16 v95, v98, s30, 0                           // 000000187658: CC22005F 02003D62
	v_fma_mixlo_f16 v98, v103, s30, 0                          // 000000187660: CC210062 02003D67
	s_waitcnt lgkmcnt(8)                                       // 000000187668: BF89FC87
	v_fma_mixlo_f16 v103, v146, s30, 0                         // 00000018766C: CC210067 02003D92
	v_fma_mixhi_f16 v103, v147, s30, 0                         // 000000187674: CC220067 02003D93
	v_fma_mixlo_f16 v95, v97, s30, 0                           // 00000018767C: CC21005F 02003D61
	v_fma_mixlo_f16 v97, v101, s30, 0                          // 000000187684: CC210061 02003D65
	v_fma_mixhi_f16 v97, v102, s30, 0                          // 00000018768C: CC220061 02003D66
	v_fma_mixhi_f16 v98, v104, s30, 0                          // 000000187694: CC220062 02003D68
	v_fma_mixlo_f16 v101, v142, s30, 0                         // 00000018769C: CC210065 02003D8E
	v_fma_mixhi_f16 v101, v143, s30, 0                         // 0000001876A4: CC220065 02003D8F
	v_fma_mixlo_f16 v102, v144, s30, 0                         // 0000001876AC: CC210066 02003D90
	v_fma_mixhi_f16 v102, v145, s30, 0                         // 0000001876B4: CC220066 02003D91
	v_fma_mixlo_f16 v104, v148, s30, 0                         // 0000001876BC: CC210068 02003D94
	v_fma_mixhi_f16 v104, v149, s30, 0                         // 0000001876C4: CC220068 02003D95
	s_waitcnt lgkmcnt(7)                                       // 0000001876CC: BF89FC77
	v_fma_mixlo_f16 v142, v150, s30, 0                         // 0000001876D0: CC21008E 02003D96
	v_fma_mixhi_f16 v142, v151, s30, 0                         // 0000001876D8: CC22008E 02003D97
	v_fma_mixlo_f16 v143, v152, s30, 0                         // 0000001876E0: CC21008F 02003D98
	v_fma_mixhi_f16 v143, v153, s30, 0                         // 0000001876E8: CC22008F 02003D99
	s_waitcnt lgkmcnt(6)                                       // 0000001876F0: BF89FC67
	v_fma_mixlo_f16 v144, v154, s30, 0                         // 0000001876F4: CC210090 02003D9A
	s_waitcnt lgkmcnt(0)                                       // 0000001876FC: BF89FC07
	v_fma_mixlo_f16 v146, v107, s30, 0                         // 000000187700: CC210092 02003D6B
	v_fma_mixhi_f16 v146, v108, s30, 0                         // 000000187708: CC220092 02003D6C
	v_fma_mixlo_f16 v147, v109, s30, 0                         // 000000187710: CC210093 02003D6D
	v_fma_mixhi_f16 v147, v110, s30, 0                         // 000000187718: CC220093 02003D6E
	ds_load_b128 v[107:110], v130 offset:192                   // 000000187720: DBFC00C0 6B000082
	v_fma_mixhi_f16 v144, v155, s30, 0                         // 000000187728: CC220090 02003D9B
	v_fma_mixlo_f16 v145, v156, s30, 0                         // 000000187730: CC210091 02003D9C
	v_fma_mixhi_f16 v145, v157, s30, 0                         // 000000187738: CC220091 02003D9D
	v_fma_mixlo_f16 v148, v158, s30, 0                         // 000000187740: CC210094 02003D9E
	v_fma_mixhi_f16 v148, v159, s30, 0                         // 000000187748: CC220094 02003D9F
	v_fma_mixlo_f16 v149, v160, s30, 0                         // 000000187750: CC210095 02003DA0
	v_fma_mixhi_f16 v149, v161, s30, 0                         // 000000187758: CC220095 02003DA1
	v_fma_mixlo_f16 v150, v162, s30, 0                         // 000000187760: CC210096 02003DA2
	v_fma_mixhi_f16 v150, v163, s30, 0                         // 000000187768: CC220096 02003DA3
	v_fma_mixlo_f16 v151, v164, s30, 0                         // 000000187770: CC210097 02003DA4
	v_fma_mixhi_f16 v151, v165, s30, 0                         // 000000187778: CC220097 02003DA5
	v_fma_mixlo_f16 v152, v166, s30, 0                         // 000000187780: CC210098 02003DA6
	v_fma_mixhi_f16 v152, v167, s30, 0                         // 000000187788: CC220098 02003DA7
	v_fma_mixlo_f16 v153, v168, s30, 0                         // 000000187790: CC210099 02003DA8
	v_fma_mixhi_f16 v153, v169, s30, 0                         // 000000187798: CC220099 02003DA9
	v_fma_mixlo_f16 v154, v170, s30, 0                         // 0000001877A0: CC21009A 02003DAA
	v_fma_mixhi_f16 v154, v171, s30, 0                         // 0000001877A8: CC22009A 02003DAB
	v_fma_mixlo_f16 v155, v172, s30, 0                         // 0000001877B0: CC21009B 02003DAC
	v_fma_mixhi_f16 v155, v173, s30, 0                         // 0000001877B8: CC22009B 02003DAD
	v_fma_mixlo_f16 v156, v174, s30, 0                         // 0000001877C0: CC21009C 02003DAE
	v_fma_mixhi_f16 v156, v175, s30, 0                         // 0000001877C8: CC22009C 02003DAF
	v_fma_mixlo_f16 v157, v176, s30, 0                         // 0000001877D0: CC21009D 02003DB0
	v_fma_mixhi_f16 v157, v177, s30, 0                         // 0000001877D8: CC22009D 02003DB1
	ds_load_b128 v[158:161], v130 offset:208                   // 0000001877E0: DBFC00D0 9E000082
	ds_load_b128 v[162:165], v130 offset:224                   // 0000001877E8: DBFC00E0 A2000082
	s_waitcnt vmcnt(10)                                        // 0000001877F0: BF892BF7
	v_wmma_f32_16x16x16_f16 v[33:40], v[81:88], v[89:96], v[33:40]// 0000001877F4: CC404021 1C86B351
	ds_load_b128 v[89:92], v130 offset:240                     // 0000001877FC: DBFC00F0 59000082
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[97:104], v[17:24]// 000000187804: CC404011 1C46C351
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[142:149], v[41:48]// 00000018780C: CC404029 1CA71D51
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[150:157], v[25:32]// 000000187814: CC404019 1C672D51
	ds_load_b128 v[93:96], v130 offset:8640                    // 00000018781C: DBFC21C0 5D000082
	ds_load_b128 v[97:100], v130 offset:8656                   // 000000187824: DBFC21D0 61000082
	s_waitcnt lgkmcnt(5)                                       // 00000018782C: BF89FC57
	v_fma_mixlo_f16 v81, v107, s30, 0                          // 000000187830: CC210051 02003D6B
	v_fma_mixhi_f16 v81, v108, s30, 0                          // 000000187838: CC220051 02003D6C
	v_fma_mixlo_f16 v82, v109, s30, 0                          // 000000187840: CC210052 02003D6D
	v_fma_mixhi_f16 v82, v110, s30, 0                          // 000000187848: CC220052 02003D6E
	ds_load_b128 v[101:104], v130 offset:8672                  // 000000187850: DBFC21E0 65000082
	ds_load_b128 v[107:110], v130 offset:8688                  // 000000187858: DBFC21F0 6B000082
	ds_load_b128 v[142:145], v130 offset:17088                 // 000000187860: DBFC42C0 8E000082
	ds_load_b128 v[146:149], v130 offset:17104                 // 000000187868: DBFC42D0 92000082
	ds_load_b128 v[150:153], v130 offset:17120                 // 000000187870: DBFC42E0 96000082
	ds_load_b128 v[154:157], v130 offset:17136                 // 000000187878: DBFC42F0 9A000082
	s_waitcnt lgkmcnt(10)                                      // 000000187880: BF89FCA7
	v_fma_mixlo_f16 v83, v158, s30, 0                          // 000000187884: CC210053 02003D9E
	v_fma_mixhi_f16 v83, v159, s30, 0                          // 00000018788C: CC220053 02003D9F
	v_fma_mixlo_f16 v84, v160, s30, 0                          // 000000187894: CC210054 02003DA0
	s_waitcnt lgkmcnt(8)                                       // 00000018789C: BF89FC87
	v_fma_mixhi_f16 v87, v90, s30, 0                           // 0000001878A0: CC220057 02003D5A
	v_fma_mixhi_f16 v84, v161, s30, 0                          // 0000001878A8: CC220054 02003DA1
	v_fma_mixlo_f16 v85, v162, s30, 0                          // 0000001878B0: CC210055 02003DA2
	v_fma_mixhi_f16 v85, v163, s30, 0                          // 0000001878B8: CC220055 02003DA3
	s_waitcnt lgkmcnt(7)                                       // 0000001878C0: BF89FC77
	v_fma_mixlo_f16 v90, v95, s30, 0                           // 0000001878C4: CC21005A 02003D5F
	v_fma_mixhi_f16 v90, v96, s30, 0                           // 0000001878CC: CC22005A 02003D60
	v_fma_mixlo_f16 v86, v164, s30, 0                          // 0000001878D4: CC210056 02003DA4
	v_fma_mixhi_f16 v86, v165, s30, 0                          // 0000001878DC: CC220056 02003DA5
	v_fma_mixlo_f16 v87, v89, s30, 0                           // 0000001878E4: CC210057 02003D59
	v_fma_mixhi_f16 v88, v92, s30, 0                           // 0000001878EC: CC220058 02003D5C
	v_fma_mixlo_f16 v89, v93, s30, 0                           // 0000001878F4: CC210059 02003D5D
	s_waitcnt lgkmcnt(4)                                       // 0000001878FC: BF89FC47
	v_fma_mixlo_f16 v95, v107, s30, 0                          // 000000187900: CC21005F 02003D6B
	v_fma_mixhi_f16 v95, v108, s30, 0                          // 000000187908: CC22005F 02003D6C
	v_fma_mixlo_f16 v96, v109, s30, 0                          // 000000187910: CC210060 02003D6D
	v_fma_mixhi_f16 v96, v110, s30, 0                          // 000000187918: CC220060 02003D6E
	ds_load_b128 v[107:110], v130 offset:25536                 // 000000187920: DBFC63C0 6B000082
	ds_load_b128 v[158:161], v130 offset:25552                 // 000000187928: DBFC63D0 9E000082
	v_fma_mixhi_f16 v92, v100, s30, 0                          // 000000187930: CC22005C 02003D64
	v_fma_mixlo_f16 v93, v101, s30, 0                          // 000000187938: CC21005D 02003D65
	s_waitcnt lgkmcnt(4)                                       // 000000187940: BF89FC47
	v_fma_mixlo_f16 v100, v148, s30, 0                         // 000000187944: CC210064 02003D94
	ds_load_b128 v[162:165], v130 offset:25568                 // 00000018794C: DBFC63E0 A2000082
	v_fma_mixhi_f16 v100, v149, s30, 0                         // 000000187954: CC220064 02003D95
	s_waitcnt lgkmcnt(4)                                       // 00000018795C: BF89FC47
	v_fma_mixlo_f16 v101, v150, s30, 0                         // 000000187960: CC210065 02003D96
	v_fma_mixhi_f16 v101, v151, s30, 0                         // 000000187968: CC220065 02003D97
	ds_load_b128 v[148:151], v130 offset:25584                 // 000000187970: DBFC63F0 94000082
	v_fma_mixlo_f16 v88, v91, s30, 0                           // 000000187978: CC210058 02003D5B
	v_fma_mixlo_f16 v91, v97, s30, 0                           // 000000187980: CC21005B 02003D61
	v_fma_mixlo_f16 v97, v142, s30, 0                          // 000000187988: CC210061 02003D8E
	v_fma_mixhi_f16 v97, v143, s30, 0                          // 000000187990: CC220061 02003D8F
	v_fma_mixhi_f16 v89, v94, s30, 0                           // 000000187998: CC220059 02003D5E
	v_fma_mixhi_f16 v91, v98, s30, 0                           // 0000001879A0: CC22005B 02003D62
	v_fma_mixlo_f16 v92, v99, s30, 0                           // 0000001879A8: CC21005C 02003D63
	v_fma_mixhi_f16 v93, v102, s30, 0                          // 0000001879B0: CC22005D 02003D66
	v_fma_mixlo_f16 v94, v103, s30, 0                          // 0000001879B8: CC21005E 02003D67
	v_fma_mixhi_f16 v94, v104, s30, 0                          // 0000001879C0: CC22005E 02003D68
	s_waitcnt lgkmcnt(3)                                       // 0000001879C8: BF89FC37
	v_fma_mixlo_f16 v142, v107, s30, 0                         // 0000001879CC: CC21008E 02003D6B
	v_fma_mixhi_f16 v142, v108, s30, 0                         // 0000001879D4: CC22008E 02003D6C
	v_fma_mixlo_f16 v143, v109, s30, 0                         // 0000001879DC: CC21008F 02003D6D
	v_fma_mixhi_f16 v143, v110, s30, 0                         // 0000001879E4: CC22008F 02003D6E
	ds_load_b128 v[107:110], v130 offset:256                   // 0000001879EC: DBFC0100 6B000082
	v_fma_mixlo_f16 v98, v144, s30, 0                          // 0000001879F4: CC210062 02003D90
	v_fma_mixhi_f16 v98, v145, s30, 0                          // 0000001879FC: CC220062 02003D91
	v_fma_mixlo_f16 v99, v146, s30, 0                          // 000000187A04: CC210063 02003D92
	v_fma_mixhi_f16 v99, v147, s30, 0                          // 000000187A0C: CC220063 02003D93
	v_fma_mixlo_f16 v102, v152, s30, 0                         // 000000187A14: CC210066 02003D98
	v_fma_mixhi_f16 v102, v153, s30, 0                         // 000000187A1C: CC220066 02003D99
	v_fma_mixlo_f16 v103, v154, s30, 0                         // 000000187A24: CC210067 02003D9A
	v_fma_mixhi_f16 v103, v155, s30, 0                         // 000000187A2C: CC220067 02003D9B
	v_fma_mixlo_f16 v104, v156, s30, 0                         // 000000187A34: CC210068 02003D9C
	v_fma_mixhi_f16 v104, v157, s30, 0                         // 000000187A3C: CC220068 02003D9D
	s_waitcnt lgkmcnt(3)                                       // 000000187A44: BF89FC37
	v_fma_mixlo_f16 v144, v158, s30, 0                         // 000000187A48: CC210090 02003D9E
	v_fma_mixhi_f16 v144, v159, s30, 0                         // 000000187A50: CC220090 02003D9F
	v_fma_mixlo_f16 v145, v160, s30, 0                         // 000000187A58: CC210091 02003DA0
	v_fma_mixhi_f16 v145, v161, s30, 0                         // 000000187A60: CC220091 02003DA1
	s_waitcnt lgkmcnt(2)                                       // 000000187A68: BF89FC27
	v_fma_mixlo_f16 v146, v162, s30, 0                         // 000000187A6C: CC210092 02003DA2
	v_fma_mixhi_f16 v146, v163, s30, 0                         // 000000187A74: CC220092 02003DA3
	v_fma_mixlo_f16 v147, v164, s30, 0                         // 000000187A7C: CC210093 02003DA4
	v_fma_mixhi_f16 v147, v165, s30, 0                         // 000000187A84: CC220093 02003DA5
	s_waitcnt lgkmcnt(1)                                       // 000000187A8C: BF89FC17
	v_fma_mixlo_f16 v148, v148, s30, 0                         // 000000187A90: CC210094 02003D94
	v_fma_mixhi_f16 v148, v149, s30, 0                         // 000000187A98: CC220094 02003D95
	v_fma_mixlo_f16 v149, v150, s30, 0                         // 000000187AA0: CC210095 02003D96
	v_fma_mixhi_f16 v149, v151, s30, 0                         // 000000187AA8: CC220095 02003D97
	ds_load_b128 v[152:155], v130 offset:272                   // 000000187AB0: DBFC0110 98000082
	ds_load_b128 v[156:159], v130 offset:288                   // 000000187AB8: DBFC0120 9C000082
	s_waitcnt vmcnt(8)                                         // 000000187AC0: BF8923F7
	v_wmma_f32_16x16x16_f16 v[33:40], v[73:80], v[81:88], v[33:40]// 000000187AC4: CC404021 1C86A349
	ds_load_b128 v[81:84], v130 offset:304                     // 000000187ACC: DBFC0130 51000082
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[89:96], v[17:24]// 000000187AD4: CC404011 1C46B349
	v_wmma_f32_16x16x16_f16 v[41:48], v[73:80], v[97:104], v[41:48]// 000000187ADC: CC404029 1CA6C349
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[142:149], v[25:32]// 000000187AE4: CC404019 1C671D49
	ds_load_b128 v[85:88], v130 offset:8704                    // 000000187AEC: DBFC2200 55000082
	ds_load_b128 v[89:92], v130 offset:8720                    // 000000187AF4: DBFC2210 59000082
	s_waitcnt lgkmcnt(5)                                       // 000000187AFC: BF89FC57
	v_fma_mixlo_f16 v73, v107, s30, 0                          // 000000187B00: CC210049 02003D6B
	v_fma_mixhi_f16 v73, v108, s30, 0                          // 000000187B08: CC220049 02003D6C
	v_fma_mixlo_f16 v74, v109, s30, 0                          // 000000187B10: CC21004A 02003D6D
	v_fma_mixhi_f16 v74, v110, s30, 0                          // 000000187B18: CC22004A 02003D6E
	ds_load_b128 v[93:96], v130 offset:8736                    // 000000187B20: DBFC2220 5D000082
	ds_load_b128 v[97:100], v130 offset:8752                   // 000000187B28: DBFC2230 61000082
	ds_load_b128 v[101:104], v130 offset:17152                 // 000000187B30: DBFC4300 65000082
	ds_load_b128 v[107:110], v130 offset:17168                 // 000000187B38: DBFC4310 6B000082
	ds_load_b128 v[142:145], v130 offset:17184                 // 000000187B40: DBFC4320 8E000082
	ds_load_b128 v[146:149], v130 offset:17200                 // 000000187B48: DBFC4330 92000082
	s_waitcnt lgkmcnt(10)                                      // 000000187B50: BF89FCA7
	v_fma_mixlo_f16 v75, v152, s30, 0                          // 000000187B54: CC21004B 02003D98
	v_fma_mixhi_f16 v75, v153, s30, 0                          // 000000187B5C: CC22004B 02003D99
	ds_load_b128 v[150:153], v130 offset:25616                 // 000000187B64: DBFC6410 96000082
	s_waitcnt lgkmcnt(9)                                       // 000000187B6C: BF89FC97
	v_fma_mixhi_f16 v79, v82, s30, 0                           // 000000187B70: CC22004F 02003D52
	v_fma_mixlo_f16 v80, v83, s30, 0                           // 000000187B78: CC210050 02003D53
	v_fma_mixhi_f16 v80, v84, s30, 0                           // 000000187B80: CC220050 02003D54
	v_fma_mixlo_f16 v76, v154, s30, 0                          // 000000187B88: CC21004C 02003D9A
	s_waitcnt lgkmcnt(8)                                       // 000000187B90: BF89FC87
	v_fma_mixlo_f16 v82, v87, s30, 0                           // 000000187B94: CC210052 02003D57
	v_fma_mixhi_f16 v82, v88, s30, 0                           // 000000187B9C: CC220052 02003D58
	s_waitcnt lgkmcnt(7)                                       // 000000187BA4: BF89FC77
	v_fma_mixlo_f16 v83, v89, s30, 0                           // 000000187BA8: CC210053 02003D59
	v_fma_mixhi_f16 v83, v90, s30, 0                           // 000000187BB0: CC220053 02003D5A
	v_fma_mixlo_f16 v84, v91, s30, 0                           // 000000187BB8: CC210054 02003D5B
	v_fma_mixhi_f16 v84, v92, s30, 0                           // 000000187BC0: CC220054 02003D5C
	v_fma_mixhi_f16 v76, v155, s30, 0                          // 000000187BC8: CC22004C 02003D9B
	s_waitcnt lgkmcnt(5)                                       // 000000187BD0: BF89FC57
	v_fma_mixlo_f16 v87, v97, s30, 0                           // 000000187BD4: CC210057 02003D61
	v_fma_mixhi_f16 v87, v98, s30, 0                           // 000000187BDC: CC220057 02003D62
	v_fma_mixlo_f16 v88, v99, s30, 0                           // 000000187BE4: CC210058 02003D63
	v_fma_mixhi_f16 v88, v100, s30, 0                          // 000000187BEC: CC220058 02003D64
	ds_load_b128 v[97:100], v130 offset:25600                  // 000000187BF4: DBFC6400 61000082
	s_waitcnt lgkmcnt(5)                                       // 000000187BFC: BF89FC57
	v_fma_mixlo_f16 v89, v101, s30, 0                          // 000000187C00: CC210059 02003D65
	v_fma_mixhi_f16 v89, v102, s30, 0                          // 000000187C08: CC220059 02003D66
	v_fma_mixlo_f16 v90, v103, s30, 0                          // 000000187C10: CC21005A 02003D67
	v_fma_mixhi_f16 v90, v104, s30, 0                          // 000000187C18: CC22005A 02003D68
	s_waitcnt lgkmcnt(4)                                       // 000000187C20: BF89FC47
	v_fma_mixlo_f16 v91, v107, s30, 0                          // 000000187C24: CC21005B 02003D6B
	v_fma_mixhi_f16 v91, v108, s30, 0                          // 000000187C2C: CC22005B 02003D6C
	v_fma_mixlo_f16 v92, v109, s30, 0                          // 000000187C34: CC21005C 02003D6D
	ds_load_b128 v[101:104], v130 offset:25632                 // 000000187C3C: DBFC6420 65000082
	v_fma_mixhi_f16 v92, v110, s30, 0                          // 000000187C44: CC22005C 02003D6E
	ds_load_b128 v[107:110], v130 offset:25648                 // 000000187C4C: DBFC6430 6B000082
	v_fma_mixlo_f16 v77, v156, s30, 0                          // 000000187C54: CC21004D 02003D9C
	v_fma_mixhi_f16 v77, v157, s30, 0                          // 000000187C5C: CC22004D 02003D9D
	v_fma_mixlo_f16 v78, v158, s30, 0                          // 000000187C64: CC21004E 02003D9E
	v_fma_mixhi_f16 v78, v159, s30, 0                          // 000000187C6C: CC22004E 02003D9F
	v_fma_mixlo_f16 v79, v81, s30, 0                           // 000000187C74: CC21004F 02003D51
	v_fma_mixlo_f16 v81, v85, s30, 0                           // 000000187C7C: CC210051 02003D55
	v_fma_mixhi_f16 v81, v86, s30, 0                           // 000000187C84: CC220051 02003D56
	v_fma_mixlo_f16 v85, v93, s30, 0                           // 000000187C8C: CC210055 02003D5D
	v_fma_mixhi_f16 v85, v94, s30, 0                           // 000000187C94: CC220055 02003D5E
	v_fma_mixlo_f16 v86, v95, s30, 0                           // 000000187C9C: CC210056 02003D5F
	v_fma_mixhi_f16 v86, v96, s30, 0                           // 000000187CA4: CC220056 02003D60
	s_waitcnt lgkmcnt(5)                                       // 000000187CAC: BF89FC57
	v_fma_mixlo_f16 v93, v142, s30, 0                          // 000000187CB0: CC21005D 02003D8E
	v_fma_mixhi_f16 v93, v143, s30, 0                          // 000000187CB8: CC22005D 02003D8F
	v_fma_mixlo_f16 v94, v144, s30, 0                          // 000000187CC0: CC21005E 02003D90
	v_fma_mixhi_f16 v94, v145, s30, 0                          // 000000187CC8: CC22005E 02003D91
	s_waitcnt lgkmcnt(4)                                       // 000000187CD0: BF89FC47
	v_fma_mixlo_f16 v95, v146, s30, 0                          // 000000187CD4: CC21005F 02003D92
	v_fma_mixhi_f16 v95, v147, s30, 0                          // 000000187CDC: CC22005F 02003D93
	v_fma_mixlo_f16 v96, v148, s30, 0                          // 000000187CE4: CC210060 02003D94
	v_fma_mixhi_f16 v96, v149, s30, 0                          // 000000187CEC: CC220060 02003D95
	s_waitcnt lgkmcnt(2)                                       // 000000187CF4: BF89FC27
	v_fma_mixlo_f16 v97, v97, s30, 0                           // 000000187CF8: CC210061 02003D61
	v_fma_mixhi_f16 v97, v98, s30, 0                           // 000000187D00: CC220061 02003D62
	v_fma_mixlo_f16 v98, v99, s30, 0                           // 000000187D08: CC210062 02003D63
	v_fma_mixhi_f16 v98, v100, s30, 0                          // 000000187D10: CC220062 02003D64
	v_fma_mixlo_f16 v99, v150, s30, 0                          // 000000187D18: CC210063 02003D96
	v_fma_mixhi_f16 v99, v151, s30, 0                          // 000000187D20: CC220063 02003D97
	v_fma_mixlo_f16 v100, v152, s30, 0                         // 000000187D28: CC210064 02003D98
	v_fma_mixhi_f16 v100, v153, s30, 0                         // 000000187D30: CC220064 02003D99
	s_waitcnt lgkmcnt(1)                                       // 000000187D38: BF89FC17
	v_fma_mixlo_f16 v101, v101, s30, 0                         // 000000187D3C: CC210065 02003D65
	v_fma_mixhi_f16 v101, v102, s30, 0                         // 000000187D44: CC220065 02003D66
	v_fma_mixlo_f16 v102, v103, s30, 0                         // 000000187D4C: CC210066 02003D67
	v_fma_mixhi_f16 v102, v104, s30, 0                         // 000000187D54: CC220066 02003D68
	s_waitcnt lgkmcnt(0)                                       // 000000187D5C: BF89FC07
	v_fma_mixlo_f16 v103, v107, s30, 0                         // 000000187D60: CC210067 02003D6B
	v_fma_mixhi_f16 v103, v108, s30, 0                         // 000000187D68: CC220067 02003D6C
	v_fma_mixlo_f16 v104, v109, s30, 0                         // 000000187D70: CC210068 02003D6D
	v_fma_mixhi_f16 v104, v110, s30, 0                         // 000000187D78: CC220068 02003D6E
	ds_load_b128 v[142:145], v130 offset:320                   // 000000187D80: DBFC0140 8E000082
	ds_load_b128 v[146:149], v130 offset:336                   // 000000187D88: DBFC0150 92000082
	ds_load_b128 v[150:153], v130 offset:352                   // 000000187D90: DBFC0160 96000082
	s_waitcnt vmcnt(6)                                         // 000000187D98: BF891BF7
	v_wmma_f32_16x16x16_f16 v[33:40], v[65:72], v[73:80], v[33:40]// 000000187D9C: CC404021 1C869341
	ds_load_b128 v[73:76], v130 offset:368                     // 000000187DA4: DBFC0170 49000082
	v_wmma_f32_16x16x16_f16 v[17:24], v[65:72], v[81:88], v[17:24]// 000000187DAC: CC404011 1C46A341
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[89:96], v[41:48]// 000000187DB4: CC404029 1CA6B341
	v_wmma_f32_16x16x16_f16 v[25:32], v[65:72], v[97:104], v[25:32]// 000000187DBC: CC404019 1C66C341
	ds_load_b128 v[77:80], v130 offset:8768                    // 000000187DC4: DBFC2240 4D000082
	ds_load_b128 v[81:84], v130 offset:8784                    // 000000187DCC: DBFC2250 51000082
	ds_load_b128 v[85:88], v130 offset:8800                    // 000000187DD4: DBFC2260 55000082
	ds_load_b128 v[89:92], v130 offset:8816                    // 000000187DDC: DBFC2270 59000082
	ds_load_b128 v[93:96], v130 offset:17216                   // 000000187DE4: DBFC4340 5D000082
	ds_load_b128 v[97:100], v130 offset:17232                  // 000000187DEC: DBFC4350 61000082
	ds_load_b128 v[101:104], v130 offset:17248                 // 000000187DF4: DBFC4360 65000082
	ds_load_b128 v[107:110], v130 offset:17264                 // 000000187DFC: DBFC4370 6B000082
	s_waitcnt lgkmcnt(11)                                      // 000000187E04: BF89FCB7
	v_fma_mixlo_f16 v65, v142, s30, 0                          // 000000187E08: CC210041 02003D8E
	v_fma_mixhi_f16 v65, v143, s30, 0                          // 000000187E10: CC220041 02003D8F
	v_fma_mixlo_f16 v66, v144, s30, 0                          // 000000187E18: CC210042 02003D90
	v_fma_mixhi_f16 v66, v145, s30, 0                          // 000000187E20: CC220042 02003D91
	s_waitcnt lgkmcnt(8)                                       // 000000187E28: BF89FC87
	v_fma_mixhi_f16 v71, v74, s30, 0                           // 000000187E2C: CC220047 02003D4A
	v_fma_mixlo_f16 v72, v75, s30, 0                           // 000000187E34: CC210048 02003D4B
	v_fma_mixhi_f16 v72, v76, s30, 0                           // 000000187E3C: CC220048 02003D4C
	ds_load_b128 v[142:145], v130 offset:25680                 // 000000187E44: DBFC6450 8E000082
	s_waitcnt lgkmcnt(8)                                       // 000000187E4C: BF89FC87
	v_fma_mixlo_f16 v74, v79, s30, 0                           // 000000187E50: CC21004A 02003D4F
	v_fma_mixhi_f16 v74, v80, s30, 0                           // 000000187E58: CC22004A 02003D50
	s_waitcnt lgkmcnt(7)                                       // 000000187E60: BF89FC77
	v_fma_mixlo_f16 v75, v81, s30, 0                           // 000000187E64: CC21004B 02003D51
	v_fma_mixhi_f16 v75, v82, s30, 0                           // 000000187E6C: CC22004B 02003D52
	v_fma_mixlo_f16 v76, v83, s30, 0                           // 000000187E74: CC21004C 02003D53
	v_fma_mixhi_f16 v76, v84, s30, 0                           // 000000187E7C: CC22004C 02003D54
	s_waitcnt lgkmcnt(5)                                       // 000000187E84: BF89FC57
	v_fma_mixlo_f16 v79, v89, s30, 0                           // 000000187E88: CC21004F 02003D59
	v_fma_mixhi_f16 v79, v90, s30, 0                           // 000000187E90: CC22004F 02003D5A
	v_fma_mixlo_f16 v80, v91, s30, 0                           // 000000187E98: CC210050 02003D5B
	v_fma_mixhi_f16 v80, v92, s30, 0                           // 000000187EA0: CC220050 02003D5C
	ds_load_b128 v[89:92], v130 offset:25664                   // 000000187EA8: DBFC6440 59000082
	s_waitcnt lgkmcnt(5)                                       // 000000187EB0: BF89FC57
	v_fma_mixlo_f16 v81, v93, s30, 0                           // 000000187EB4: CC210051 02003D5D
	v_fma_mixhi_f16 v81, v94, s30, 0                           // 000000187EBC: CC220051 02003D5E
	v_fma_mixlo_f16 v82, v95, s30, 0                           // 000000187EC4: CC210052 02003D5F
	v_fma_mixhi_f16 v82, v96, s30, 0                           // 000000187ECC: CC220052 02003D60
	s_waitcnt lgkmcnt(4)                                       // 000000187ED4: BF89FC47
	v_fma_mixlo_f16 v83, v97, s30, 0                           // 000000187ED8: CC210053 02003D61
	v_fma_mixhi_f16 v83, v98, s30, 0                           // 000000187EE0: CC220053 02003D62
	v_fma_mixlo_f16 v84, v99, s30, 0                           // 000000187EE8: CC210054 02003D63
	ds_load_b128 v[93:96], v130 offset:25696                   // 000000187EF0: DBFC6460 5D000082
	v_fma_mixhi_f16 v84, v100, s30, 0                          // 000000187EF8: CC220054 02003D64
	ds_load_b128 v[97:100], v130 offset:25712                  // 000000187F00: DBFC6470 61000082
	v_fma_mixlo_f16 v67, v146, s30, 0                          // 000000187F08: CC210043 02003D92
	v_fma_mixhi_f16 v67, v147, s30, 0                          // 000000187F10: CC220043 02003D93
	v_fma_mixlo_f16 v68, v148, s30, 0                          // 000000187F18: CC210044 02003D94
	v_fma_mixhi_f16 v68, v149, s30, 0                          // 000000187F20: CC220044 02003D95
	v_fma_mixlo_f16 v69, v150, s30, 0                          // 000000187F28: CC210045 02003D96
	v_fma_mixhi_f16 v69, v151, s30, 0                          // 000000187F30: CC220045 02003D97
	v_fma_mixlo_f16 v70, v152, s30, 0                          // 000000187F38: CC210046 02003D98
	v_fma_mixhi_f16 v70, v153, s30, 0                          // 000000187F40: CC220046 02003D99
	v_fma_mixlo_f16 v71, v73, s30, 0                           // 000000187F48: CC210047 02003D49
	v_fma_mixlo_f16 v73, v77, s30, 0                           // 000000187F50: CC210049 02003D4D
	v_fma_mixhi_f16 v73, v78, s30, 0                           // 000000187F58: CC220049 02003D4E
	v_fma_mixlo_f16 v77, v85, s30, 0                           // 000000187F60: CC21004D 02003D55
	v_fma_mixhi_f16 v77, v86, s30, 0                           // 000000187F68: CC22004D 02003D56
	v_fma_mixlo_f16 v78, v87, s30, 0                           // 000000187F70: CC21004E 02003D57
	v_fma_mixhi_f16 v78, v88, s30, 0                           // 000000187F78: CC22004E 02003D58
	s_waitcnt lgkmcnt(5)                                       // 000000187F80: BF89FC57
	v_fma_mixlo_f16 v85, v101, s30, 0                          // 000000187F84: CC210055 02003D65
	v_fma_mixhi_f16 v85, v102, s30, 0                          // 000000187F8C: CC220055 02003D66
	v_fma_mixlo_f16 v86, v103, s30, 0                          // 000000187F94: CC210056 02003D67
	v_fma_mixhi_f16 v86, v104, s30, 0                          // 000000187F9C: CC220056 02003D68
	s_waitcnt lgkmcnt(4)                                       // 000000187FA4: BF89FC47
	v_fma_mixlo_f16 v87, v107, s30, 0                          // 000000187FA8: CC210057 02003D6B
	v_fma_mixhi_f16 v87, v108, s30, 0                          // 000000187FB0: CC220057 02003D6C
	v_fma_mixlo_f16 v88, v109, s30, 0                          // 000000187FB8: CC210058 02003D6D
	v_fma_mixhi_f16 v88, v110, s30, 0                          // 000000187FC0: CC220058 02003D6E
	s_waitcnt lgkmcnt(2)                                       // 000000187FC8: BF89FC27
	v_fma_mixlo_f16 v89, v89, s30, 0                           // 000000187FCC: CC210059 02003D59
	v_fma_mixhi_f16 v89, v90, s30, 0                           // 000000187FD4: CC220059 02003D5A
	v_fma_mixlo_f16 v90, v91, s30, 0                           // 000000187FDC: CC21005A 02003D5B
	v_fma_mixhi_f16 v90, v92, s30, 0                           // 000000187FE4: CC22005A 02003D5C
	v_fma_mixlo_f16 v91, v142, s30, 0                          // 000000187FEC: CC21005B 02003D8E
	v_fma_mixhi_f16 v91, v143, s30, 0                          // 000000187FF4: CC22005B 02003D8F
	v_fma_mixlo_f16 v92, v144, s30, 0                          // 000000187FFC: CC21005C 02003D90
	v_fma_mixhi_f16 v92, v145, s30, 0                          // 000000188004: CC22005C 02003D91
	s_waitcnt lgkmcnt(1)                                       // 00000018800C: BF89FC17
	v_fma_mixlo_f16 v93, v93, s30, 0                           // 000000188010: CC21005D 02003D5D
	v_fma_mixhi_f16 v93, v94, s30, 0                           // 000000188018: CC22005D 02003D5E
	v_fma_mixlo_f16 v94, v95, s30, 0                           // 000000188020: CC21005E 02003D5F
	v_fma_mixhi_f16 v94, v96, s30, 0                           // 000000188028: CC22005E 02003D60
	s_waitcnt lgkmcnt(0)                                       // 000000188030: BF89FC07
	v_fma_mixlo_f16 v95, v97, s30, 0                           // 000000188034: CC21005F 02003D61
	v_fma_mixhi_f16 v95, v98, s30, 0                           // 00000018803C: CC22005F 02003D62
	v_fma_mixlo_f16 v96, v99, s30, 0                           // 000000188044: CC210060 02003D63
	v_fma_mixhi_f16 v96, v100, s30, 0                          // 00000018804C: CC220060 02003D64
	ds_load_b128 v[101:104], v130 offset:384                   // 000000188054: DBFC0180 65000082
	ds_load_b128 v[107:110], v130 offset:400                   // 00000018805C: DBFC0190 6B000082
	ds_load_b128 v[142:145], v130 offset:416                   // 000000188064: DBFC01A0 8E000082
	s_waitcnt vmcnt(4)                                         // 00000018806C: BF8913F7
	v_wmma_f32_16x16x16_f16 v[33:40], v[57:64], v[65:72], v[33:40]// 000000188070: CC404021 1C868339
	ds_load_b128 v[65:68], v130 offset:432                     // 000000188078: DBFC01B0 41000082
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[73:80], v[17:24]// 000000188080: CC404011 1C469339
	v_wmma_f32_16x16x16_f16 v[41:48], v[57:64], v[81:88], v[41:48]// 000000188088: CC404029 1CA6A339
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[89:96], v[25:32]// 000000188090: CC404019 1C66B339
	ds_load_b128 v[69:72], v130 offset:8832                    // 000000188098: DBFC2280 45000082
	ds_load_b128 v[73:76], v130 offset:8848                    // 0000001880A0: DBFC2290 49000082
	ds_load_b128 v[77:80], v130 offset:8864                    // 0000001880A8: DBFC22A0 4D000082
	ds_load_b128 v[81:84], v130 offset:8880                    // 0000001880B0: DBFC22B0 51000082
	ds_load_b128 v[85:88], v130 offset:17280                   // 0000001880B8: DBFC4380 55000082
	ds_load_b128 v[89:92], v130 offset:17296                   // 0000001880C0: DBFC4390 59000082
	ds_load_b128 v[93:96], v130 offset:17312                   // 0000001880C8: DBFC43A0 5D000082
	ds_load_b128 v[97:100], v130 offset:17328                  // 0000001880D0: DBFC43B0 61000082
	s_waitcnt lgkmcnt(11)                                      // 0000001880D8: BF89FCB7
	v_fma_mixlo_f16 v57, v101, s30, 0                          // 0000001880DC: CC210039 02003D65
	v_fma_mixhi_f16 v57, v102, s30, 0                          // 0000001880E4: CC220039 02003D66
	v_fma_mixlo_f16 v58, v103, s30, 0                          // 0000001880EC: CC21003A 02003D67
	v_fma_mixhi_f16 v58, v104, s30, 0                          // 0000001880F4: CC22003A 02003D68
	s_waitcnt lgkmcnt(8)                                       // 0000001880FC: BF89FC87
	v_fma_mixhi_f16 v63, v66, s30, 0                           // 000000188100: CC22003F 02003D42
	v_fma_mixlo_f16 v64, v67, s30, 0                           // 000000188108: CC210040 02003D43
	v_fma_mixhi_f16 v64, v68, s30, 0                           // 000000188110: CC220040 02003D44
	ds_load_b128 v[101:104], v130 offset:25744                 // 000000188118: DBFC6490 65000082
	s_waitcnt lgkmcnt(8)                                       // 000000188120: BF89FC87
	v_fma_mixlo_f16 v66, v71, s30, 0                           // 000000188124: CC210042 02003D47
	v_fma_mixhi_f16 v66, v72, s30, 0                           // 00000018812C: CC220042 02003D48
	s_waitcnt lgkmcnt(7)                                       // 000000188134: BF89FC77
	v_fma_mixlo_f16 v67, v73, s30, 0                           // 000000188138: CC210043 02003D49
	v_fma_mixhi_f16 v67, v74, s30, 0                           // 000000188140: CC220043 02003D4A
	v_fma_mixlo_f16 v68, v75, s30, 0                           // 000000188148: CC210044 02003D4B
	v_fma_mixhi_f16 v68, v76, s30, 0                           // 000000188150: CC220044 02003D4C
	s_waitcnt lgkmcnt(5)                                       // 000000188158: BF89FC57
	v_fma_mixlo_f16 v71, v81, s30, 0                           // 00000018815C: CC210047 02003D51
	v_fma_mixhi_f16 v71, v82, s30, 0                           // 000000188164: CC220047 02003D52
	v_fma_mixlo_f16 v72, v83, s30, 0                           // 00000018816C: CC210048 02003D53
	v_fma_mixhi_f16 v72, v84, s30, 0                           // 000000188174: CC220048 02003D54
	ds_load_b128 v[81:84], v130 offset:25728                   // 00000018817C: DBFC6480 51000082
	s_waitcnt lgkmcnt(5)                                       // 000000188184: BF89FC57
	v_fma_mixlo_f16 v73, v85, s30, 0                           // 000000188188: CC210049 02003D55
	v_fma_mixhi_f16 v73, v86, s30, 0                           // 000000188190: CC220049 02003D56
	v_fma_mixlo_f16 v74, v87, s30, 0                           // 000000188198: CC21004A 02003D57
	v_fma_mixhi_f16 v74, v88, s30, 0                           // 0000001881A0: CC22004A 02003D58
	s_waitcnt lgkmcnt(4)                                       // 0000001881A8: BF89FC47
	v_fma_mixlo_f16 v75, v89, s30, 0                           // 0000001881AC: CC21004B 02003D59
	v_fma_mixhi_f16 v75, v90, s30, 0                           // 0000001881B4: CC22004B 02003D5A
	v_fma_mixlo_f16 v76, v91, s30, 0                           // 0000001881BC: CC21004C 02003D5B
	ds_load_b128 v[85:88], v130 offset:25760                   // 0000001881C4: DBFC64A0 55000082
	v_fma_mixhi_f16 v76, v92, s30, 0                           // 0000001881CC: CC22004C 02003D5C
	ds_load_b128 v[89:92], v130 offset:25776                   // 0000001881D4: DBFC64B0 59000082
	v_fma_mixlo_f16 v59, v107, s30, 0                          // 0000001881DC: CC21003B 02003D6B
	v_fma_mixhi_f16 v59, v108, s30, 0                          // 0000001881E4: CC22003B 02003D6C
	v_fma_mixlo_f16 v60, v109, s30, 0                          // 0000001881EC: CC21003C 02003D6D
	v_fma_mixhi_f16 v60, v110, s30, 0                          // 0000001881F4: CC22003C 02003D6E
	v_fma_mixlo_f16 v61, v142, s30, 0                          // 0000001881FC: CC21003D 02003D8E
	v_fma_mixhi_f16 v61, v143, s30, 0                          // 000000188204: CC22003D 02003D8F
	v_fma_mixlo_f16 v62, v144, s30, 0                          // 00000018820C: CC21003E 02003D90
	v_fma_mixhi_f16 v62, v145, s30, 0                          // 000000188214: CC22003E 02003D91
	v_fma_mixlo_f16 v63, v65, s30, 0                           // 00000018821C: CC21003F 02003D41
	v_fma_mixlo_f16 v65, v69, s30, 0                           // 000000188224: CC210041 02003D45
	v_fma_mixhi_f16 v65, v70, s30, 0                           // 00000018822C: CC220041 02003D46
	v_fma_mixlo_f16 v69, v77, s30, 0                           // 000000188234: CC210045 02003D4D
	v_fma_mixhi_f16 v69, v78, s30, 0                           // 00000018823C: CC220045 02003D4E
	v_fma_mixlo_f16 v70, v79, s30, 0                           // 000000188244: CC210046 02003D4F
	v_fma_mixhi_f16 v70, v80, s30, 0                           // 00000018824C: CC220046 02003D50
	s_waitcnt lgkmcnt(5)                                       // 000000188254: BF89FC57
	v_fma_mixlo_f16 v77, v93, s30, 0                           // 000000188258: CC21004D 02003D5D
	v_fma_mixhi_f16 v77, v94, s30, 0                           // 000000188260: CC22004D 02003D5E
	v_fma_mixlo_f16 v78, v95, s30, 0                           // 000000188268: CC21004E 02003D5F
	v_fma_mixhi_f16 v78, v96, s30, 0                           // 000000188270: CC22004E 02003D60
	s_waitcnt lgkmcnt(4)                                       // 000000188278: BF89FC47
	v_fma_mixlo_f16 v79, v97, s30, 0                           // 00000018827C: CC21004F 02003D61
	v_fma_mixhi_f16 v79, v98, s30, 0                           // 000000188284: CC22004F 02003D62
	v_fma_mixlo_f16 v80, v99, s30, 0                           // 00000018828C: CC210050 02003D63
	v_fma_mixhi_f16 v80, v100, s30, 0                          // 000000188294: CC220050 02003D64
	s_waitcnt lgkmcnt(2)                                       // 00000018829C: BF89FC27
	v_fma_mixlo_f16 v81, v81, s30, 0                           // 0000001882A0: CC210051 02003D51
	v_fma_mixhi_f16 v81, v82, s30, 0                           // 0000001882A8: CC220051 02003D52
	v_fma_mixlo_f16 v82, v83, s30, 0                           // 0000001882B0: CC210052 02003D53
	v_fma_mixhi_f16 v82, v84, s30, 0                           // 0000001882B8: CC220052 02003D54
	v_fma_mixlo_f16 v83, v101, s30, 0                          // 0000001882C0: CC210053 02003D65
	v_fma_mixhi_f16 v83, v102, s30, 0                          // 0000001882C8: CC220053 02003D66
	v_fma_mixlo_f16 v84, v103, s30, 0                          // 0000001882D0: CC210054 02003D67
	v_fma_mixhi_f16 v84, v104, s30, 0                          // 0000001882D8: CC220054 02003D68
	s_waitcnt lgkmcnt(1)                                       // 0000001882E0: BF89FC17
	v_fma_mixlo_f16 v85, v85, s30, 0                           // 0000001882E4: CC210055 02003D55
	v_fma_mixhi_f16 v85, v86, s30, 0                           // 0000001882EC: CC220055 02003D56
	v_fma_mixlo_f16 v86, v87, s30, 0                           // 0000001882F4: CC210056 02003D57
	v_fma_mixhi_f16 v86, v88, s30, 0                           // 0000001882FC: CC220056 02003D58
	s_waitcnt lgkmcnt(0)                                       // 000000188304: BF89FC07
	v_fma_mixlo_f16 v87, v89, s30, 0                           // 000000188308: CC210057 02003D59
	v_fma_mixhi_f16 v87, v90, s30, 0                           // 000000188310: CC220057 02003D5A
	v_fma_mixlo_f16 v88, v91, s30, 0                           // 000000188318: CC210058 02003D5B
	v_fma_mixhi_f16 v88, v92, s30, 0                           // 000000188320: CC220058 02003D5C
	ds_load_b128 v[93:96], v130 offset:448                     // 000000188328: DBFC01C0 5D000082
	ds_load_b128 v[97:100], v130 offset:464                    // 000000188330: DBFC01D0 61000082
	ds_load_b128 v[101:104], v130 offset:480                   // 000000188338: DBFC01E0 65000082
	s_waitcnt vmcnt(2)                                         // 000000188340: BF890BF7
	v_wmma_f32_16x16x16_f16 v[33:40], v[49:56], v[57:64], v[33:40]// 000000188344: CC404021 1C867331
	ds_load_b128 v[57:60], v130 offset:496                     // 00000018834C: DBFC01F0 39000082
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[65:72], v[17:24]// 000000188354: CC404011 1C468331
	v_wmma_f32_16x16x16_f16 v[41:48], v[49:56], v[73:80], v[41:48]// 00000018835C: CC404029 1CA69331
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[81:88], v[25:32]// 000000188364: CC404019 1C66A331
	ds_load_b128 v[61:64], v130 offset:8896                    // 00000018836C: DBFC22C0 3D000082
	ds_load_b128 v[65:68], v130 offset:8912                    // 000000188374: DBFC22D0 41000082
	ds_load_b128 v[69:72], v130 offset:8928                    // 00000018837C: DBFC22E0 45000082
	ds_load_b128 v[73:76], v130 offset:8944                    // 000000188384: DBFC22F0 49000082
	ds_load_b128 v[77:80], v130 offset:17344                   // 00000018838C: DBFC43C0 4D000082
	ds_load_b128 v[81:84], v130 offset:17360                   // 000000188394: DBFC43D0 51000082
	ds_load_b128 v[85:88], v130 offset:17376                   // 00000018839C: DBFC43E0 55000082
	ds_load_b128 v[89:92], v130 offset:17392                   // 0000001883A4: DBFC43F0 59000082
	s_waitcnt lgkmcnt(11)                                      // 0000001883AC: BF89FCB7
	v_fma_mixlo_f16 v49, v93, s30, 0                           // 0000001883B0: CC210031 02003D5D
	v_fma_mixhi_f16 v49, v94, s30, 0                           // 0000001883B8: CC220031 02003D5E
	v_fma_mixlo_f16 v50, v95, s30, 0                           // 0000001883C0: CC210032 02003D5F
	v_fma_mixhi_f16 v50, v96, s30, 0                           // 0000001883C8: CC220032 02003D60
	s_waitcnt lgkmcnt(8)                                       // 0000001883D0: BF89FC87
	v_fma_mixhi_f16 v55, v58, s30, 0                           // 0000001883D4: CC220037 02003D3A
	v_fma_mixlo_f16 v56, v59, s30, 0                           // 0000001883DC: CC210038 02003D3B
	v_fma_mixhi_f16 v56, v60, s30, 0                           // 0000001883E4: CC220038 02003D3C
	ds_load_b128 v[93:96], v130 offset:25808                   // 0000001883EC: DBFC64D0 5D000082
	s_waitcnt lgkmcnt(8)                                       // 0000001883F4: BF89FC87
	v_fma_mixlo_f16 v58, v63, s30, 0                           // 0000001883F8: CC21003A 02003D3F
	v_fma_mixhi_f16 v58, v64, s30, 0                           // 000000188400: CC22003A 02003D40
	s_waitcnt lgkmcnt(7)                                       // 000000188408: BF89FC77
	v_fma_mixlo_f16 v59, v65, s30, 0                           // 00000018840C: CC21003B 02003D41
	v_fma_mixhi_f16 v59, v66, s30, 0                           // 000000188414: CC22003B 02003D42
	v_fma_mixlo_f16 v60, v67, s30, 0                           // 00000018841C: CC21003C 02003D43
	v_fma_mixhi_f16 v60, v68, s30, 0                           // 000000188424: CC22003C 02003D44
	s_waitcnt lgkmcnt(5)                                       // 00000018842C: BF89FC57
	v_fma_mixlo_f16 v63, v73, s30, 0                           // 000000188430: CC21003F 02003D49
	v_fma_mixhi_f16 v63, v74, s30, 0                           // 000000188438: CC22003F 02003D4A
	v_fma_mixlo_f16 v64, v75, s30, 0                           // 000000188440: CC210040 02003D4B
	v_fma_mixhi_f16 v64, v76, s30, 0                           // 000000188448: CC220040 02003D4C
	ds_load_b128 v[73:76], v130 offset:25792                   // 000000188450: DBFC64C0 49000082
	s_waitcnt lgkmcnt(5)                                       // 000000188458: BF89FC57
	v_fma_mixlo_f16 v65, v77, s30, 0                           // 00000018845C: CC210041 02003D4D
	v_fma_mixhi_f16 v65, v78, s30, 0                           // 000000188464: CC220041 02003D4E
	v_fma_mixlo_f16 v66, v79, s30, 0                           // 00000018846C: CC210042 02003D4F
	v_fma_mixhi_f16 v66, v80, s30, 0                           // 000000188474: CC220042 02003D50
	s_waitcnt lgkmcnt(4)                                       // 00000018847C: BF89FC47
	v_fma_mixlo_f16 v67, v81, s30, 0                           // 000000188480: CC210043 02003D51
	v_fma_mixhi_f16 v67, v82, s30, 0                           // 000000188488: CC220043 02003D52
	ds_load_b128 v[77:80], v130 offset:25824                   // 000000188490: DBFC64E0 4D000082
	v_fma_mixlo_f16 v68, v83, s30, 0                           // 000000188498: CC210044 02003D53
	v_fma_mixhi_f16 v68, v84, s30, 0                           // 0000001884A0: CC220044 02003D54
	ds_load_b128 v[81:84], v130 offset:25840                   // 0000001884A8: DBFC64F0 51000082
	v_fma_mixlo_f16 v51, v97, s30, 0                           // 0000001884B0: CC210033 02003D61
	v_fma_mixhi_f16 v51, v98, s30, 0                           // 0000001884B8: CC220033 02003D62
	v_fma_mixlo_f16 v52, v99, s30, 0                           // 0000001884C0: CC210034 02003D63
	v_fma_mixhi_f16 v52, v100, s30, 0                          // 0000001884C8: CC220034 02003D64
	v_fma_mixlo_f16 v53, v101, s30, 0                          // 0000001884D0: CC210035 02003D65
	v_fma_mixhi_f16 v53, v102, s30, 0                          // 0000001884D8: CC220035 02003D66
	v_fma_mixlo_f16 v54, v103, s30, 0                          // 0000001884E0: CC210036 02003D67
	v_fma_mixhi_f16 v54, v104, s30, 0                          // 0000001884E8: CC220036 02003D68
	v_fma_mixlo_f16 v55, v57, s30, 0                           // 0000001884F0: CC210037 02003D39
	v_fma_mixlo_f16 v57, v61, s30, 0                           // 0000001884F8: CC210039 02003D3D
	v_fma_mixhi_f16 v57, v62, s30, 0                           // 000000188500: CC220039 02003D3E
	v_fma_mixlo_f16 v61, v69, s30, 0                           // 000000188508: CC21003D 02003D45
	v_fma_mixhi_f16 v61, v70, s30, 0                           // 000000188510: CC22003D 02003D46
	v_fma_mixlo_f16 v62, v71, s30, 0                           // 000000188518: CC21003E 02003D47
	v_fma_mixhi_f16 v62, v72, s30, 0                           // 000000188520: CC22003E 02003D48
	s_waitcnt lgkmcnt(5)                                       // 000000188528: BF89FC57
	v_fma_mixlo_f16 v69, v85, s30, 0                           // 00000018852C: CC210045 02003D55
	v_fma_mixhi_f16 v69, v86, s30, 0                           // 000000188534: CC220045 02003D56
	v_fma_mixlo_f16 v70, v87, s30, 0                           // 00000018853C: CC210046 02003D57
	v_fma_mixhi_f16 v70, v88, s30, 0                           // 000000188544: CC220046 02003D58
	s_waitcnt lgkmcnt(4)                                       // 00000018854C: BF89FC47
	v_fma_mixlo_f16 v71, v89, s30, 0                           // 000000188550: CC210047 02003D59
	v_fma_mixhi_f16 v71, v90, s30, 0                           // 000000188558: CC220047 02003D5A
	v_fma_mixlo_f16 v72, v91, s30, 0                           // 000000188560: CC210048 02003D5B
	v_fma_mixhi_f16 v72, v92, s30, 0                           // 000000188568: CC220048 02003D5C
	s_waitcnt lgkmcnt(2)                                       // 000000188570: BF89FC27
	v_fma_mixlo_f16 v73, v73, s30, 0                           // 000000188574: CC210049 02003D49
	v_fma_mixhi_f16 v73, v74, s30, 0                           // 00000018857C: CC220049 02003D4A
	v_fma_mixlo_f16 v74, v75, s30, 0                           // 000000188584: CC21004A 02003D4B
	v_fma_mixhi_f16 v74, v76, s30, 0                           // 00000018858C: CC22004A 02003D4C
	v_fma_mixlo_f16 v75, v93, s30, 0                           // 000000188594: CC21004B 02003D5D
	v_fma_mixhi_f16 v75, v94, s30, 0                           // 00000018859C: CC22004B 02003D5E
	v_fma_mixlo_f16 v76, v95, s30, 0                           // 0000001885A4: CC21004C 02003D5F
	v_fma_mixhi_f16 v76, v96, s30, 0                           // 0000001885AC: CC22004C 02003D60
	s_waitcnt lgkmcnt(1)                                       // 0000001885B4: BF89FC17
	v_fma_mixlo_f16 v77, v77, s30, 0                           // 0000001885B8: CC21004D 02003D4D
	v_fma_mixhi_f16 v77, v78, s30, 0                           // 0000001885C0: CC22004D 02003D4E
	v_fma_mixlo_f16 v78, v79, s30, 0                           // 0000001885C8: CC21004E 02003D4F
	v_fma_mixhi_f16 v78, v80, s30, 0                           // 0000001885D0: CC22004E 02003D50
	s_waitcnt lgkmcnt(0)                                       // 0000001885D8: BF89FC07
	v_fma_mixlo_f16 v79, v81, s30, 0                           // 0000001885DC: CC21004F 02003D51
	v_fma_mixhi_f16 v79, v82, s30, 0                           // 0000001885E4: CC22004F 02003D52
	v_fma_mixlo_f16 v80, v83, s30, 0                           // 0000001885EC: CC210050 02003D53
	v_fma_mixhi_f16 v80, v84, s30, 0                           // 0000001885F4: CC220050 02003D54
	s_waitcnt vmcnt(0)                                         // 0000001885FC: BF8903F7
	v_wmma_f32_16x16x16_f16 v[33:40], v[9:16], v[49:56], v[33:40]// 000000188600: CC404021 1C866309
	v_wmma_f32_16x16x16_f16 v[17:24], v[9:16], v[57:64], v[17:24]// 000000188608: CC404011 1C467309
	v_wmma_f32_16x16x16_f16 v[41:48], v[9:16], v[65:72], v[41:48]// 000000188610: CC404029 1CA68309
	v_wmma_f32_16x16x16_f16 v[25:32], v[9:16], v[73:80], v[25:32]// 000000188618: CC404019 1C669309
	v_add_nc_u32_e32 v142, s40, v134                           // 000000188620: 4B1D0C28
	s_delay_alu instid0(VALU_DEP_1)                            // 000000188624: BF870001
	v_or_b32_e32 v9, 2, v142                                   // 000000188628: 38131C82
	v_or_b32_e32 v10, 4, v142                                  // 00000018862C: 38151C84
	v_or_b32_e32 v13, 6, v142                                  // 000000188630: 381B1C86
	v_or_b32_e32 v15, 8, v142                                  // 000000188634: 381F1C88
	v_or_b32_e32 v16, 10, v142                                 // 000000188638: 38211C8A
	v_min_i32_e32 v9, s52, v9                                  // 00000018863C: 22121234
	v_min_i32_e32 v14, s52, v10                                // 000000188640: 221C1434
	v_min_i32_e32 v50, s52, v13                                // 000000188644: 22641A34
	v_or_b32_e32 v49, 12, v142                                 // 000000188648: 38631C8C
	v_min_i32_e32 v51, s52, v15                                // 00000018864C: 22661E34
	v_mad_i64_i32 v[9:10], null, v9, 48, s[2:3]                // 000000188650: D6FF7C09 00096109
	v_mad_i64_i32 v[13:14], null, v14, 48, s[2:3]              // 000000188658: D6FF7C0D 0009610E
	v_min_i32_e32 v53, s52, v16                                // 000000188660: 226A2034
	v_mad_i64_i32 v[15:16], null, v50, 48, s[2:3]              // 000000188664: D6FF7C0F 00096132
	v_min_i32_e32 v54, s52, v49                                // 00000018866C: 226C6234
	v_mad_i64_i32 v[49:50], null, v51, 48, s[2:3]              // 000000188670: D6FF7C31 00096133
	v_or_b32_e32 v55, 14, v142                                 // 000000188678: 386F1C8E
	v_min_i32_e32 v11, s52, v142                               // 00000018867C: 22171C34
	.long 0xd73c0009                                           // 000000188680: D73C0009
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 000000188684: 02021289
	.long 0xd73c000d                                           // 000000188688: D73C000D
	v_cndmask_b32_e32 v1, 9, v13, vcc_lo                       // 00000018868C: 02021A89
	.long 0xd444000a                                           // 000000188690: D444000A
	v_cndmask_b32_e32 v1, s50, v142, vcc_lo                    // 000000188694: 02031C32
	v_min_i32_e32 v55, s52, v55                                // 000000188698: 226E6E34
	v_mad_i64_i32 v[11:12], null, v11, 48, s[2:3]              // 00000018869C: D6FF7C0B 0009610B
	.long 0xd73c0031                                           // 0000001886A4: D73C0031
	v_cndmask_b32_e32 v1, 9, v49, vcc_lo                       // 0000001886A8: 02026289
	.long 0xd7000033                                           // 0000001886AC: D7000033
	v_cndmask_b32_e32 v1, v136, v9, vcc_lo                     // 0000001886B0: 02021388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001886B4: BF8700D1
	v_add_co_ci_u32_e64 v52, null, v137, v10, s0               // 0000001886B8: D5207C34 00021589
	.long 0xd73c0009                                           // 0000001886C0: D73C0009
	v_cndmask_b32_e32 v1, 9, v15, vcc_lo                       // 0000001886C4: 02021E89
	v_mad_i64_i32 v[15:16], null, v53, 48, s[2:3]              // 0000001886C8: D6FF7C0F 00096135
	v_mad_i64_i32 v[53:54], null, v54, 48, s[2:3]              // 0000001886D0: D6FF7C35 00096136
	.long 0xd700000d                                           // 0000001886D8: D700000D
	v_cndmask_b32_e32 v1, v136, v13, vcc_lo                    // 0000001886DC: 02021B88
	v_add_co_ci_u32_e64 v14, null, v137, v14, s0               // 0000001886E0: D5207C0E 00021D89
	.long 0xd7000038                                           // 0000001886E8: D7000038
	v_cndmask_b32_e32 v1, v136, v9, vcc_lo                     // 0000001886EC: 02021388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001886F0: BF8700B1
	v_add_co_ci_u32_e64 v57, null, v137, v10, s0               // 0000001886F4: D5207C39 00021589
	.long 0xd73c0009                                           // 0000001886FC: D73C0009
	v_cndmask_b32_e32 v1, 9, v15, vcc_lo                       // 000000188700: 02021E89
	.long 0xd700000f                                           // 000000188704: D700000F
	v_cndmask_b32_e32 v1, v136, v49, vcc_lo                    // 000000188708: 02026388
	v_add_co_ci_u32_e64 v16, null, v137, v50, s0               // 00000018870C: D5207C10 00026589
	.long 0xd73c0031                                           // 000000188714: D73C0031
	v_cndmask_b32_e32 v1, 9, v53, vcc_lo                       // 000000188718: 02026A89
	v_mad_i64_i32 v[53:54], null, v55, 48, s[2:3]              // 00000018871C: D6FF7C35 00096137
	.long 0xd700003e                                           // 000000188724: D700003E
	v_cndmask_b32_e32 v1, v136, v9, vcc_lo                     // 000000188728: 02021388
	.long 0xd73c000b                                           // 00000018872C: D73C000B
	v_cndmask_b32_e32 v1, 9, v11, vcc_lo                       // 000000188730: 02021689
	v_add_co_ci_u32_e64 v63, null, v137, v10, s0               // 000000188734: D5207C3F 00021589
	.long 0xd700004b                                           // 00000018873C: D700004B
	v_cndmask_b32_e32 v1, v136, v49, vcc_lo                    // 000000188740: 02026388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000188744: BF8700B1
	v_add_co_ci_u32_e64 v76, null, v137, v50, s0               // 000000188748: D5207C4C 00026589
	.long 0xd73c0031                                           // 000000188750: D73C0031
	v_cndmask_b32_e32 v1, 9, v53, vcc_lo                       // 000000188754: 02026A89
	.long 0xd700000a                                           // 000000188758: D700000A
	v_cndmask_b32_e32 v1, v136, v11, vcc_lo                    // 00000018875C: 02021788
	v_add_co_ci_u32_e64 v11, null, v137, v12, s0               // 000000188760: D5207C0B 00021989
	.long 0x7e123880                                           // 000000188768: 7E123880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018876C: BF870094
	.long 0xd700004d                                           // 000000188770: D700004D
	v_cndmask_b32_e32 v1, v136, v49, vcc_lo                    // 000000188774: 02026388
	v_add_co_ci_u32_e64 v78, null, v137, v50, s0               // 000000188778: D5207C4E 00026589
	s_clause 0x1e                                              // 000000188780: BF85001E
	global_load_b32 v71, v[51:52], off                         // 000000188784: DC520000 477C0033
	global_load_b32 v68, v[13:14], off                         // 00000018878C: DC520000 447C000D
	global_load_b32 v64, v[10:11], off offset:64               // 000000188794: DC520040 407C000A
	global_load_b32 v65, v[51:52], off offset:64               // 00000018879C: DC520040 417C0033
	global_load_b32 v59, v[10:11], off offset:128              // 0000001887A4: DC520080 3B7C000A
	global_load_b32 v55, v[51:52], off offset:128              // 0000001887AC: DC520080 377C0033
	global_load_b32 v49, v[51:52], off offset:192              // 0000001887B4: DC5200C0 317C0033
	global_load_b32 v50, v[10:11], off offset:192              // 0000001887BC: DC5200C0 327C000A
	global_load_b32 v74, v[56:57], off                         // 0000001887C4: DC520000 4A7C0038
	global_load_b32 v73, v[15:16], off                         // 0000001887CC: DC520000 497C000F
	global_load_b32 v67, v[13:14], off offset:64               // 0000001887D4: DC520040 437C000D
	global_load_b32 v66, v[56:57], off offset:64               // 0000001887DC: DC520040 427C0038
	global_load_b32 v58, v[13:14], off offset:128              // 0000001887E4: DC520080 3A7C000D
	global_load_b32 v52, v[56:57], off offset:128              // 0000001887EC: DC520080 347C0038
	global_load_b32 v12, v[56:57], off offset:192              // 0000001887F4: DC5200C0 0C7C0038
	global_load_b32 v51, v[13:14], off offset:192              // 0000001887FC: DC5200C0 337C000D
	global_load_b32 v72, v[62:63], off                         // 000000188804: DC520000 487C003E
	global_load_b32 v69, v[75:76], off                         // 00000018880C: DC520000 457C004B
	global_load_b32 v60, v[15:16], off offset:64               // 000000188814: DC520040 3C7C000F
	global_load_b32 v61, v[62:63], off offset:64               // 00000018881C: DC520040 3D7C003E
	global_load_b32 v56, v[15:16], off offset:128              // 000000188824: DC520080 387C000F
	global_load_b32 v57, v[62:63], off offset:128              // 00000018882C: DC520080 397C003E
	global_load_b32 v13, v[62:63], off offset:192              // 000000188834: DC5200C0 0D7C003E
	global_load_b32 v14, v[15:16], off offset:192              // 00000018883C: DC5200C0 0E7C000F
	global_load_b32 v70, v[77:78], off                         // 000000188844: DC520000 467C004D
	global_load_b32 v62, v[75:76], off offset:64               // 00000018884C: DC520040 3E7C004B
	global_load_b32 v63, v[77:78], off offset:64               // 000000188854: DC520040 3F7C004D
	global_load_b32 v53, v[75:76], off offset:128              // 00000018885C: DC520080 357C004B
	global_load_b32 v54, v[77:78], off offset:128              // 000000188864: DC520080 367C004D
	global_load_b32 v15, v[77:78], off offset:192              // 00000018886C: DC5200C0 0F7C004D
	global_load_b32 v16, v[75:76], off offset:192              // 000000188874: DC5200C0 107C004B
	s_and_saveexec_b32 s0, s10                                 // 00000018887C: BE80200A
	s_cbranch_execz 8                                          // 000000188880: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x1fa4>
	global_load_b32 v9, v[10:11], off                          // 000000188884: DC520000 097C000A
	s_waitcnt vmcnt(0)                                         // 00000018888C: BF8903F7
	v_fmac_f32_e32 v9, 0xbb800000, v33                         // 000000188890: 561242FF BB800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000188898: BF870001
	v_fma_mixlo_f16 v9, v9, s30, 0                             // 00000018889C: CC210009 02003D09
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001888A4: 8C7E007E
	s_waitcnt vmcnt(29)                                        // 0000001888A8: BF8977F7
	v_dual_fmac_f32 v68, 0xbb800000, v35 :: v_dual_add_nc_u32 v149, 2, v142// 0000001888AC: C82046FF 44951C82 BB800000
	s_waitcnt vmcnt(22)                                        // 0000001888B8: BF895BF7
	v_dual_fmac_f32 v71, 0xbb800000, v34 :: v_dual_fmac_f32 v74, 0xbb800000, v36// 0000001888BC: C80044FF 474A48FF BB800000
	s_waitcnt vmcnt(21)                                        // 0000001888C8: BF8957F7
	v_dual_fmac_f32 v73, 0xbb800000, v37 :: v_dual_add_nc_u32 v148, 4, v142// 0000001888CC: C8204AFF 49951C84 BB800000
	s_waitcnt vmcnt(6)                                         // 0000001888D8: BF891BF7
	v_dual_fmac_f32 v70, 0xbb800000, v40 :: v_dual_add_nc_u32 v147, 6, v142// 0000001888DC: C82050FF 46931C86 BB800000
	v_dual_fmac_f32 v69, 0xbb800000, v39 :: v_dual_add_nc_u32 v146, 8, v142// 0000001888E8: C8204EFF 45931C88 BB800000
	v_dual_fmac_f32 v64, 0xbb800000, v17 :: v_dual_add_nc_u32 v145, 10, v142// 0000001888F4: C82022FF 40911C8A BB800000
	v_dual_fmac_f32 v72, 0xbb800000, v38 :: v_dual_fmac_f32 v67, 0xbb800000, v19// 000000188900: C8004CFF 484226FF BB800000
	s_waitcnt vmcnt(4)                                         // 00000018890C: BF8913F7
	v_dual_fmac_f32 v63, 0xbb800000, v24 :: v_dual_add_nc_u32 v144, 12, v142// 000000188910: C82030FF 3F911C8C BB800000
	v_dual_fmac_f32 v66, 0xbb800000, v20 :: v_dual_add_nc_u32 v143, 14, v142// 00000018891C: C82028FF 428F1C8E BB800000
	.long 0xd444000d                                           // 000000188928: D444000D
	v_cndmask_b32_e32 v1, s50, v149, vcc_lo                    // 00000018892C: 02032A32
	v_fma_mixhi_f16 v9, v71, s30, 0                            // 000000188930: CC220009 02003D47
	.long 0xd444000c                                           // 000000188938: D444000C
	v_cndmask_b32_e32 v1, s50, v148, vcc_lo                    // 00000018893C: 02032832
	v_fma_mixlo_f16 v10, v68, s30, 0                           // 000000188940: CC21000A 02003D44
	.long 0xd444000b                                           // 000000188948: D444000B
	v_cndmask_b32_e32 v1, s50, v147, vcc_lo                    // 00000018894C: 02032632
	v_fma_mixhi_f16 v10, v74, s30, 0                           // 000000188950: CC22000A 02003D4A
	v_dual_fmac_f32 v65, 0xbb800000, v18 :: v_dual_fmac_f32 v60, 0xbb800000, v21// 000000188958: C80024FF 413C2AFF BB800000
	.long 0xd4440009                                           // 000000188964: D4440009
	v_cndmask_b32_e32 v1, s50, v146, vcc_lo                    // 000000188968: 02032432
	v_fma_mixlo_f16 v11, v73, s30, 0                           // 00000018896C: CC21000B 02003D49
	.long 0xd4440001                                           // 000000188974: D4440001
	v_cndmask_b32_e32 v1, s50, v145, vcc_lo                    // 000000188978: 02032232
	v_fma_mixhi_f16 v11, v72, s30, 0                           // 00000018897C: CC22000B 02003D48
	.long 0xd4440008                                           // 000000188984: D4440008
	v_cndmask_b32_e32 v1, s50, v144, vcc_lo                    // 000000188988: 02032032
	v_fma_mixlo_f16 v33, v69, s30, 0                           // 00000018898C: CC210021 02003D45
	.long 0xd4440000                                           // 000000188994: D4440000
	v_cndmask_b32_e32 v1, s50, v143, vcc_lo                    // 000000188998: 02031E32
	v_fma_mixhi_f16 v33, v70, s30, 0                           // 00000018899C: CC220021 02003D46
	v_cndmask_b16 v9, 0, v9, s13                               // 0000001889A4: D65D5009 00361280
	v_cndmask_b16 v10, 0, v10, s12                             // 0000001889AC: D65D000A 00321480
	v_fma_mixlo_f16 v18, v64, s30, 0                           // 0000001889B4: CC210012 02003D40
	v_dual_fmac_f32 v61, 0xbb800000, v22 :: v_dual_fmac_f32 v62, 0xbb800000, v23// 0000001889BC: C8002CFF 3D3E2EFF BB800000
	v_cndmask_b16 v10, 0, v10, s11                             // 0000001889C8: D65D500A 002E1480
	v_fma_mixhi_f16 v18, v65, s30, 0                           // 0000001889D0: CC220012 02003D41
	v_cndmask_b16 v11, 0, v11, s9                              // 0000001889D8: D65D000B 00261680
	v_fma_mixlo_f16 v19, v67, s30, 0                           // 0000001889E0: CC210013 02003D43
	v_cndmask_b16 v11, 0, v11, s1                              // 0000001889E8: D65D500B 00061680
	v_cndmask_b16 v17, 0, v33, s8                              // 0000001889F0: D65D0011 00224280
	v_cndmask_b16 v17, 0, v33, s0                              // 0000001889F8: D65D5011 00024280
	ds_store_b16 v138, v9                                      // 000000188A00: D87C0000 0000098A
	ds_store_b16_d16_hi v138, v9 offset:4                      // 000000188A08: DA840004 0000098A
	ds_store_b16 v138, v10 offset:8                            // 000000188A10: D87C0008 00000A8A
	ds_store_b16_d16_hi v138, v10 offset:12                    // 000000188A18: DA84000C 00000A8A
	ds_store_b16 v138, v11 offset:16                           // 000000188A20: D87C0010 00000B8A
	ds_store_b16_d16_hi v138, v11 offset:20                    // 000000188A28: DA840014 00000B8A
	ds_store_b16 v138, v17 offset:24                           // 000000188A30: D87C0018 0000118A
	ds_store_b16_d16_hi v138, v17 offset:28                    // 000000188A38: DA84001C 0000118A
	v_fma_mixhi_f16 v10, v66, s30, 0                           // 000000188A40: CC22000A 02003D42
	v_fma_mixlo_f16 v11, v60, s30, 0                           // 000000188A48: CC21000B 02003D3C
	v_dual_fmac_f32 v59, 0xbb800000, v41 :: v_dual_fmac_f32 v58, 0xbb800000, v43// 000000188A50: C80052FF 3B3A56FF BB800000
	v_cndmask_b16 v9, 0, v18, s10                              // 000000188A5C: D65D0009 002A2480
	v_fma_mixhi_f16 v11, v61, s30, 0                           // 000000188A64: CC22000B 02003D3D
	v_fma_mixlo_f16 v17, v62, s30, 0                           // 000000188A6C: CC210011 02003D3E
	v_fma_mixhi_f16 v17, v63, s30, 0                           // 000000188A74: CC220011 02003D3F
	v_dual_fmac_f32 v55, 0xbb800000, v42 :: v_dual_fmac_f32 v52, 0xbb800000, v44// 000000188A7C: C80054FF 373458FF BB800000
	v_cndmask_b16 v9, 0, v18, s13                              // 000000188A88: D65D5009 00362480
	v_cndmask_b16 v10, 0, v19, s12                             // 000000188A90: D65D000A 00322680
	v_cndmask_b16 v10, 0, v10, s11                             // 000000188A98: D65D500A 002E1480
	v_dual_fmac_f32 v56, 0xbb800000, v45 :: v_dual_fmac_f32 v57, 0xbb800000, v46// 000000188AA0: C8005AFF 38385CFF BB800000
	v_cndmask_b16 v11, 0, v11, s9                              // 000000188AAC: D65D000B 00261680
	v_fma_mixlo_f16 v18, v59, s30, 0                           // 000000188AB4: CC210012 02003D3B
	s_waitcnt vmcnt(2)                                         // 000000188ABC: BF890BF7
	v_dual_fmac_f32 v53, 0xbb800000, v47 :: v_dual_fmac_f32 v54, 0xbb800000, v48// 000000188AC0: C8005EFF 353660FF BB800000
	v_cndmask_b16 v11, 0, v11, s1                              // 000000188ACC: D65D500B 00061680
	v_cndmask_b16 v17, 0, v17, s8                              // 000000188AD4: D65D0011 00222280
	v_cndmask_b16 v17, 0, v17, s0                              // 000000188ADC: D65D5011 00022280
	ds_store_b16 v138, v9 offset:2304                          // 000000188AE4: D87C0900 0000098A
	ds_store_b16_d16_hi v138, v9 offset:2308                   // 000000188AEC: DA840904 0000098A
	ds_store_b16 v138, v10 offset:2312                         // 000000188AF4: D87C0908 00000A8A
	ds_store_b16_d16_hi v138, v10 offset:2316                  // 000000188AFC: DA84090C 00000A8A
	ds_store_b16 v138, v11 offset:2320                         // 000000188B04: D87C0910 00000B8A
	ds_store_b16_d16_hi v138, v11 offset:2324                  // 000000188B0C: DA840914 00000B8A
	ds_store_b16 v138, v17 offset:2328                         // 000000188B14: D87C0918 0000118A
	ds_store_b16_d16_hi v138, v17 offset:2332                  // 000000188B1C: DA84091C 0000118A
	v_fma_mixhi_f16 v9, v55, s30, 0                            // 000000188B24: CC220009 02003D37
	v_fma_mixlo_f16 v10, v58, s30, 0                           // 000000188B2C: CC21000A 02003D3A
	v_dual_fmac_f32 v50, 0xbb800000, v25 :: v_dual_fmac_f32 v49, 0xbb800000, v26// 000000188B34: C80032FF 323034FF BB800000
	v_fma_mixhi_f16 v10, v52, s30, 0                           // 000000188B40: CC22000A 02003D34
	v_fma_mixlo_f16 v11, v56, s30, 0                           // 000000188B48: CC21000B 02003D38
	v_dual_fmac_f32 v51, 0xbb800000, v27 :: v_dual_fmac_f32 v12, 0xbb800000, v28// 000000188B50: C80036FF 330C38FF BB800000
	v_cndmask_b16 v9, 0, v18, s10                              // 000000188B5C: D65D0009 002A2480
	v_fma_mixhi_f16 v11, v57, s30, 0                           // 000000188B64: CC22000B 02003D39
	v_fma_mixlo_f16 v17, v53, s30, 0                           // 000000188B6C: CC210011 02003D35
	v_fma_mixhi_f16 v17, v54, s30, 0                           // 000000188B74: CC220011 02003D36
	v_cndmask_b16 v9, 0, v9, s13                               // 000000188B7C: D65D5009 00361280
	v_dual_fmac_f32 v14, 0xbb800000, v29 :: v_dual_fmac_f32 v13, 0xbb800000, v30// 000000188B84: C8003AFF 0E0C3CFF BB800000
	v_cndmask_b16 v10, 0, v10, s12                             // 000000188B90: D65D000A 00321480
	v_fma_mixlo_f16 v18, v50, s30, 0                           // 000000188B98: CC210012 02003D32
	s_waitcnt vmcnt(0)                                         // 000000188BA0: BF8903F7
	v_dual_fmac_f32 v16, 0xbb800000, v31 :: v_dual_fmac_f32 v15, 0xbb800000, v32// 000000188BA4: C8003EFF 100E40FF BB800000
	v_cndmask_b16 v10, 0, v10, s11                             // 000000188BB0: D65D500A 002E1480
	v_fma_mixhi_f16 v18, v49, s30, 0                           // 000000188BB8: CC220012 02003D31
	v_cndmask_b16 v11, 0, v11, s9                              // 000000188BC0: D65D000B 00261680
	v_fma_mixlo_f16 v19, v51, s30, 0                           // 000000188BC8: CC210013 02003D33
	v_cndmask_b16 v11, 0, v11, s1                              // 000000188BD0: D65D500B 00061680
	v_cndmask_b16 v17, 0, v17, s8                              // 000000188BD8: D65D0011 00222280
	v_cndmask_b16 v17, 0, v17, s0                              // 000000188BE0: D65D5011 00022280
	ds_store_b16 v138, v9 offset:4608                          // 000000188BE8: D87C1200 0000098A
	ds_store_b16_d16_hi v138, v9 offset:4612                   // 000000188BF0: DA841204 0000098A
	ds_store_b16 v138, v10 offset:4616                         // 000000188BF8: D87C1208 00000A8A
	ds_store_b16_d16_hi v138, v10 offset:4620                  // 000000188C00: DA84120C 00000A8A
	ds_store_b16 v138, v11 offset:4624                         // 000000188C08: D87C1210 00000B8A
	ds_store_b16_d16_hi v138, v11 offset:4628                  // 000000188C10: DA841214 00000B8A
	ds_store_b16 v138, v17 offset:4632                         // 000000188C18: D87C1218 0000118A
	ds_store_b16_d16_hi v138, v17 offset:4636                  // 000000188C20: DA84121C 0000118A
	v_fma_mixhi_f16 v10, v12, s30, 0                           // 000000188C28: CC22000A 02003D0C
	v_fma_mixlo_f16 v11, v14, s30, 0                           // 000000188C30: CC21000B 02003D0E
	v_cndmask_b16 v9, 0, v18, s10                              // 000000188C38: D65D0009 002A2480
	v_fma_mixhi_f16 v11, v13, s30, 0                           // 000000188C40: CC22000B 02003D0D
	v_fma_mixlo_f16 v12, v16, s30, 0                           // 000000188C48: CC21000C 02003D10
	v_fma_mixhi_f16 v12, v15, s30, 0                           // 000000188C50: CC22000C 02003D0F
	v_cndmask_b16 v9, 0, v18, s13                              // 000000188C58: D65D5009 00362480
	v_cndmask_b16 v10, 0, v19, s12                             // 000000188C60: D65D000A 00322680
	v_cndmask_b16 v10, 0, v10, s11                             // 000000188C68: D65D500A 002E1480
	v_cndmask_b16 v11, 0, v11, s9                              // 000000188C70: D65D000B 00261680
	v_cndmask_b16 v11, 0, v11, s1                              // 000000188C78: D65D500B 00061680
	v_cndmask_b16 v12, 0, v12, s8                              // 000000188C80: D65D000C 00221880
	v_cndmask_b16 v12, 0, v12, s0                              // 000000188C88: D65D500C 00021880
	ds_store_b16 v138, v9 offset:6912                          // 000000188C90: D87C1B00 0000098A
	ds_store_b16_d16_hi v138, v9 offset:6916                   // 000000188C98: DA841B04 0000098A
	ds_store_b16 v138, v10 offset:6920                         // 000000188CA0: D87C1B08 00000A8A
	ds_store_b16_d16_hi v138, v10 offset:6924                  // 000000188CA8: DA841B0C 00000A8A
	ds_store_b16 v138, v11 offset:6928                         // 000000188CB0: D87C1B10 00000B8A
	ds_store_b16_d16_hi v138, v11 offset:6932                  // 000000188CB8: DA841B14 00000B8A
	ds_store_b16 v138, v12 offset:6936                         // 000000188CC0: D87C1B18 00000C8A
	ds_store_b16_d16_hi v138, v12 offset:6940                  // 000000188CC8: DA841B1C 00000C8A
	.long 0xd7000e09                                           // 000000188CD0: D7000E09
	v_cndmask_b32_e32 v1, s44, v105, vcc_lo                    // 000000188CD4: 0202D22C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000188CD8: BF870001
	v_add_co_ci_u32_e64 v10, null, s45, v106, s14              // 000000188CDC: D5207C0A 003AD42D
	s_waitcnt lgkmcnt(0)                                       // 000000188CE4: BF89FC07
	s_barrier                                                  // 000000188CE8: BFBD0000
	buffer_gl0_inv                                             // 000000188CEC: E0AC0000 00000000
	s_clause 0xf                                               // 000000188CF4: BF85000F
	global_load_b128 v[105:108], v[9:10], off                  // 000000188CF8: DC5E0000 697C0009
	global_load_b128 v[109:112], v[9:10], off offset:16        // 000000188D00: DC5E0010 6D7C0009
	global_load_b128 v[97:100], v[9:10], off offset:32         // 000000188D08: DC5E0020 617C0009
	global_load_b128 v[101:104], v[9:10], off offset:48        // 000000188D10: DC5E0030 657C0009
	global_load_b128 v[89:92], v[9:10], off offset:64          // 000000188D18: DC5E0040 597C0009
	global_load_b128 v[93:96], v[9:10], off offset:80          // 000000188D20: DC5E0050 5D7C0009
	global_load_b128 v[81:84], v[9:10], off offset:96          // 000000188D28: DC5E0060 517C0009
	global_load_b128 v[85:88], v[9:10], off offset:112         // 000000188D30: DC5E0070 557C0009
	global_load_b128 v[65:68], v[9:10], off offset:128         // 000000188D38: DC5E0080 417C0009
	global_load_b128 v[69:72], v[9:10], off offset:144         // 000000188D40: DC5E0090 457C0009
	global_load_b128 v[57:60], v[9:10], off offset:160         // 000000188D48: DC5E00A0 397C0009
	global_load_b128 v[61:64], v[9:10], off offset:176         // 000000188D50: DC5E00B0 3D7C0009
	global_load_b128 v[49:52], v[9:10], off offset:192         // 000000188D58: DC5E00C0 317C0009
	global_load_b128 v[53:56], v[9:10], off offset:208         // 000000188D60: DC5E00D0 357C0009
	global_load_b128 v[41:44], v[9:10], off offset:224         // 000000188D68: DC5E00E0 297C0009
	global_load_b128 v[45:48], v[9:10], off offset:240         // 000000188D70: DC5E00F0 2D7C0009
	s_and_saveexec_b32 s14, vcc_lo                             // 000000188D78: BE8E206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000188D7C: BF870009
	s_xor_b32 s14, exec_lo, s14                                // 000000188D80: 8D0E0E7E
	s_cbranch_execz 81                                         // 000000188D84: BFA50051 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x25cc>
	s_waitcnt vmcnt(15)                                        // 000000188D88: BF893FF7
	v_mov_b32_e32 v105, 0                                      // 000000188D8C: 7ED20280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000188D90: BF870001
	v_mov_b32_e32 v106, v105                                   // 000000188D94: 7ED40369
	v_mov_b32_e32 v107, v105                                   // 000000188D98: 7ED60369
	v_mov_b32_e32 v108, v105                                   // 000000188D9C: 7ED80369
	s_waitcnt vmcnt(14)                                        // 000000188DA0: BF893BF7
	v_mov_b32_e32 v109, v105                                   // 000000188DA4: 7EDA0369
	v_mov_b32_e32 v110, v105                                   // 000000188DA8: 7EDC0369
	v_mov_b32_e32 v111, v105                                   // 000000188DAC: 7EDE0369
	v_mov_b32_e32 v112, v105                                   // 000000188DB0: 7EE00369
	s_waitcnt vmcnt(13)                                        // 000000188DB4: BF8937F7
	v_mov_b32_e32 v97, v105                                    // 000000188DB8: 7EC20369
	v_mov_b32_e32 v98, v105                                    // 000000188DBC: 7EC40369
	v_mov_b32_e32 v99, v105                                    // 000000188DC0: 7EC60369
	v_mov_b32_e32 v100, v105                                   // 000000188DC4: 7EC80369
	s_waitcnt vmcnt(12)                                        // 000000188DC8: BF8933F7
	v_mov_b32_e32 v101, v105                                   // 000000188DCC: 7ECA0369
	v_mov_b32_e32 v102, v105                                   // 000000188DD0: 7ECC0369
	v_mov_b32_e32 v103, v105                                   // 000000188DD4: 7ECE0369
	v_mov_b32_e32 v104, v105                                   // 000000188DD8: 7ED00369
	s_waitcnt vmcnt(11)                                        // 000000188DDC: BF892FF7
	v_mov_b32_e32 v89, v105                                    // 000000188DE0: 7EB20369
	v_mov_b32_e32 v90, v105                                    // 000000188DE4: 7EB40369
	v_mov_b32_e32 v91, v105                                    // 000000188DE8: 7EB60369
	v_mov_b32_e32 v92, v105                                    // 000000188DEC: 7EB80369
	s_waitcnt vmcnt(10)                                        // 000000188DF0: BF892BF7
	v_mov_b32_e32 v93, v105                                    // 000000188DF4: 7EBA0369
	v_mov_b32_e32 v94, v105                                    // 000000188DF8: 7EBC0369
	v_mov_b32_e32 v95, v105                                    // 000000188DFC: 7EBE0369
	v_mov_b32_e32 v96, v105                                    // 000000188E00: 7EC00369
	s_waitcnt vmcnt(9)                                         // 000000188E04: BF8927F7
	v_mov_b32_e32 v81, v105                                    // 000000188E08: 7EA20369
	v_mov_b32_e32 v82, v105                                    // 000000188E0C: 7EA40369
	v_mov_b32_e32 v83, v105                                    // 000000188E10: 7EA60369
	v_mov_b32_e32 v84, v105                                    // 000000188E14: 7EA80369
	s_waitcnt vmcnt(8)                                         // 000000188E18: BF8923F7
	v_mov_b32_e32 v85, v105                                    // 000000188E1C: 7EAA0369
	v_mov_b32_e32 v86, v105                                    // 000000188E20: 7EAC0369
	v_mov_b32_e32 v87, v105                                    // 000000188E24: 7EAE0369
	v_mov_b32_e32 v88, v105                                    // 000000188E28: 7EB00369
	s_waitcnt vmcnt(7)                                         // 000000188E2C: BF891FF7
	v_mov_b32_e32 v65, v105                                    // 000000188E30: 7E820369
	v_mov_b32_e32 v66, v105                                    // 000000188E34: 7E840369
	v_mov_b32_e32 v67, v105                                    // 000000188E38: 7E860369
	v_mov_b32_e32 v68, v105                                    // 000000188E3C: 7E880369
	s_waitcnt vmcnt(6)                                         // 000000188E40: BF891BF7
	v_mov_b32_e32 v69, v105                                    // 000000188E44: 7E8A0369
	v_mov_b32_e32 v70, v105                                    // 000000188E48: 7E8C0369
	v_mov_b32_e32 v71, v105                                    // 000000188E4C: 7E8E0369
	v_mov_b32_e32 v72, v105                                    // 000000188E50: 7E900369
	s_waitcnt vmcnt(5)                                         // 000000188E54: BF8917F7
	v_mov_b32_e32 v57, v105                                    // 000000188E58: 7E720369
	v_mov_b32_e32 v58, v105                                    // 000000188E5C: 7E740369
	v_mov_b32_e32 v59, v105                                    // 000000188E60: 7E760369
	v_mov_b32_e32 v60, v105                                    // 000000188E64: 7E780369
	s_waitcnt vmcnt(4)                                         // 000000188E68: BF8913F7
	v_mov_b32_e32 v61, v105                                    // 000000188E6C: 7E7A0369
	v_mov_b32_e32 v62, v105                                    // 000000188E70: 7E7C0369
	v_mov_b32_e32 v63, v105                                    // 000000188E74: 7E7E0369
	v_mov_b32_e32 v64, v105                                    // 000000188E78: 7E800369
	s_waitcnt vmcnt(3)                                         // 000000188E7C: BF890FF7
	v_mov_b32_e32 v49, v105                                    // 000000188E80: 7E620369
	v_mov_b32_e32 v50, v105                                    // 000000188E84: 7E640369
	v_mov_b32_e32 v51, v105                                    // 000000188E88: 7E660369
	v_mov_b32_e32 v52, v105                                    // 000000188E8C: 7E680369
	s_waitcnt vmcnt(2)                                         // 000000188E90: BF890BF7
	v_mov_b32_e32 v53, v105                                    // 000000188E94: 7E6A0369
	v_mov_b32_e32 v54, v105                                    // 000000188E98: 7E6C0369
	v_mov_b32_e32 v55, v105                                    // 000000188E9C: 7E6E0369
	v_mov_b32_e32 v56, v105                                    // 000000188EA0: 7E700369
	s_waitcnt vmcnt(1)                                         // 000000188EA4: BF8907F7
	v_mov_b32_e32 v41, v105                                    // 000000188EA8: 7E520369
	v_mov_b32_e32 v42, v105                                    // 000000188EAC: 7E540369
	v_mov_b32_e32 v43, v105                                    // 000000188EB0: 7E560369
	v_mov_b32_e32 v44, v105                                    // 000000188EB4: 7E580369
	s_waitcnt vmcnt(0)                                         // 000000188EB8: BF8903F7
	v_mov_b32_e32 v45, v105                                    // 000000188EBC: 7E5A0369
	v_mov_b32_e32 v46, v105                                    // 000000188EC0: 7E5C0369
	v_mov_b32_e32 v47, v105                                    // 000000188EC4: 7E5E0369
	v_mov_b32_e32 v48, v105                                    // 000000188EC8: 7E600369
	s_or_b32 exec_lo, exec_lo, s14                             // 000000188ECC: 8C7E0E7E
	ds_load_b128 v[9:12], v130                                 // 000000188ED0: DBFC0000 09000082
	ds_load_b128 v[13:16], v130 offset:16                      // 000000188ED8: DBFC0010 0D000082
	ds_load_b128 v[17:20], v130 offset:32                      // 000000188EE0: DBFC0020 11000082
	ds_load_b128 v[21:24], v130 offset:48                      // 000000188EE8: DBFC0030 15000082
	ds_load_b128 v[25:28], v130 offset:8448                    // 000000188EF0: DBFC2100 19000082
	ds_load_b128 v[29:32], v130 offset:8464                    // 000000188EF8: DBFC2110 1D000082
	ds_load_b128 v[33:36], v130 offset:8480                    // 000000188F00: DBFC2120 21000082
	ds_load_b128 v[37:40], v130 offset:8496                    // 000000188F08: DBFC2130 25000082
	ds_load_b128 v[150:153], v130 offset:16896                 // 000000188F10: DBFC4200 96000082
	ds_load_b128 v[154:157], v130 offset:16912                 // 000000188F18: DBFC4210 9A000082
	ds_load_b128 v[158:161], v130 offset:16928                 // 000000188F20: DBFC4220 9E000082
	ds_load_b128 v[162:165], v130 offset:16944                 // 000000188F28: DBFC4230 A2000082
	ds_load_b128 v[166:169], v130 offset:25376                 // 000000188F30: DBFC6320 A6000082
	v_dual_mov_b32 v80, s27 :: v_dual_mov_b32 v79, s26         // 000000188F38: CA10001B 504E001A
	v_dual_mov_b32 v78, s25 :: v_dual_mov_b32 v77, s24         // 000000188F40: CA100019 4E4C0018
	v_dual_mov_b32 v76, s23 :: v_dual_mov_b32 v75, s22         // 000000188F48: CA100017 4C4A0016
	v_dual_mov_b32 v74, s21 :: v_dual_mov_b32 v73, s20         // 000000188F50: CA100015 4A480014
	s_waitcnt lgkmcnt(12)                                      // 000000188F58: BF89FCC7
	v_fma_mixlo_f16 v9, v9, s30, 0                             // 000000188F5C: CC210009 02003D09
	v_fma_mixhi_f16 v9, v10, s30, 0                            // 000000188F64: CC220009 02003D0A
	v_fma_mixlo_f16 v10, v11, s30, 0                           // 000000188F6C: CC21000A 02003D0B
	v_fma_mixhi_f16 v10, v12, s30, 0                           // 000000188F74: CC22000A 02003D0C
	s_waitcnt lgkmcnt(11)                                      // 000000188F7C: BF89FCB7
	v_fma_mixlo_f16 v11, v13, s30, 0                           // 000000188F80: CC21000B 02003D0D
	v_fma_mixhi_f16 v11, v14, s30, 0                           // 000000188F88: CC22000B 02003D0E
	v_fma_mixlo_f16 v12, v15, s30, 0                           // 000000188F90: CC21000C 02003D0F
	v_fma_mixhi_f16 v12, v16, s30, 0                           // 000000188F98: CC22000C 02003D10
	s_waitcnt lgkmcnt(10)                                      // 000000188FA0: BF89FCA7
	v_fma_mixlo_f16 v13, v17, s30, 0                           // 000000188FA4: CC21000D 02003D11
	v_fma_mixhi_f16 v13, v18, s30, 0                           // 000000188FAC: CC22000D 02003D12
	v_fma_mixlo_f16 v14, v19, s30, 0                           // 000000188FB4: CC21000E 02003D13
	v_fma_mixhi_f16 v14, v20, s30, 0                           // 000000188FBC: CC22000E 02003D14
	s_waitcnt lgkmcnt(9)                                       // 000000188FC4: BF89FC97
	v_fma_mixlo_f16 v15, v21, s30, 0                           // 000000188FC8: CC21000F 02003D15
	v_fma_mixhi_f16 v15, v22, s30, 0                           // 000000188FD0: CC22000F 02003D16
	v_fma_mixlo_f16 v16, v23, s30, 0                           // 000000188FD8: CC210010 02003D17
	v_fma_mixhi_f16 v16, v24, s30, 0                           // 000000188FE0: CC220010 02003D18
	s_waitcnt lgkmcnt(8)                                       // 000000188FE8: BF89FC87
	v_fma_mixlo_f16 v25, v25, s30, 0                           // 000000188FEC: CC210019 02003D19
	v_fma_mixhi_f16 v25, v26, s30, 0                           // 000000188FF4: CC220019 02003D1A
	v_fma_mixlo_f16 v26, v27, s30, 0                           // 000000188FFC: CC21001A 02003D1B
	v_fma_mixhi_f16 v26, v28, s30, 0                           // 000000189004: CC22001A 02003D1C
	s_waitcnt lgkmcnt(7)                                       // 00000018900C: BF89FC77
	v_fma_mixlo_f16 v27, v29, s30, 0                           // 000000189010: CC21001B 02003D1D
	v_fma_mixhi_f16 v27, v30, s30, 0                           // 000000189018: CC22001B 02003D1E
	v_fma_mixlo_f16 v28, v31, s30, 0                           // 000000189020: CC21001C 02003D1F
	v_fma_mixhi_f16 v28, v32, s30, 0                           // 000000189028: CC22001C 02003D20
	s_waitcnt lgkmcnt(6)                                       // 000000189030: BF89FC67
	v_fma_mixlo_f16 v29, v33, s30, 0                           // 000000189034: CC21001D 02003D21
	v_fma_mixhi_f16 v29, v34, s30, 0                           // 00000018903C: CC22001D 02003D22
	v_fma_mixlo_f16 v30, v35, s30, 0                           // 000000189044: CC21001E 02003D23
	v_fma_mixhi_f16 v30, v36, s30, 0                           // 00000018904C: CC22001E 02003D24
	s_waitcnt lgkmcnt(5)                                       // 000000189054: BF89FC57
	v_fma_mixlo_f16 v31, v37, s30, 0                           // 000000189058: CC21001F 02003D25
	v_fma_mixhi_f16 v31, v38, s30, 0                           // 000000189060: CC22001F 02003D26
	v_fma_mixlo_f16 v32, v39, s30, 0                           // 000000189068: CC210020 02003D27
	v_fma_mixhi_f16 v32, v40, s30, 0                           // 000000189070: CC220020 02003D28
	s_waitcnt vmcnt(14)                                        // 000000189078: BF893BF7
	v_wmma_f32_16x16x16_f16 v[33:40], v[105:112], v[9:16], v[73:80]// 00000018907C: CC404021 1D261369
	s_waitcnt lgkmcnt(3)                                       // 000000189084: BF89FC37
	v_fma_mixlo_f16 v12, v156, s30, 0                          // 000000189088: CC21000C 02003D9C
	v_fma_mixhi_f16 v12, v157, s30, 0                          // 000000189090: CC22000C 02003D9D
	v_wmma_f32_16x16x16_f16 v[17:24], v[105:112], v[25:32], v[73:80]// 000000189098: CC404011 1D263369
	ds_load_b128 v[25:28], v130 offset:25344                   // 0000001890A0: DBFC6300 19000082
	ds_load_b128 v[29:32], v130 offset:25360                   // 0000001890A8: DBFC6310 1D000082
	s_waitcnt lgkmcnt(4)                                       // 0000001890B0: BF89FC47
	v_fma_mixlo_f16 v13, v158, s30, 0                          // 0000001890B4: CC21000D 02003D9E
	v_fma_mixhi_f16 v13, v159, s30, 0                          // 0000001890BC: CC22000D 02003D9F
	ds_load_b128 v[156:159], v130 offset:25392                 // 0000001890C4: DBFC6330 9C000082
	v_fma_mixlo_f16 v11, v154, s30, 0                          // 0000001890CC: CC21000B 02003D9A
	v_fma_mixlo_f16 v14, v160, s30, 0                          // 0000001890D4: CC21000E 02003DA0
	v_fma_mixhi_f16 v14, v161, s30, 0                          // 0000001890DC: CC22000E 02003DA1
	s_waitcnt lgkmcnt(4)                                       // 0000001890E4: BF89FC47
	v_fma_mixlo_f16 v15, v162, s30, 0                          // 0000001890E8: CC21000F 02003DA2
	v_fma_mixhi_f16 v15, v163, s30, 0                          // 0000001890F0: CC22000F 02003DA3
	v_fma_mixlo_f16 v16, v164, s30, 0                          // 0000001890F8: CC210010 02003DA4
	v_fma_mixhi_f16 v16, v165, s30, 0                          // 000000189100: CC220010 02003DA5
	ds_load_b128 v[160:163], v130 offset:64                    // 000000189108: DBFC0040 A0000082
	ds_load_b128 v[170:173], v130 offset:80                    // 000000189110: DBFC0050 AA000082
	s_waitcnt lgkmcnt(5)                                       // 000000189118: BF89FC57
	v_fma_mixlo_f16 v154, v166, s30, 0                         // 00000018911C: CC21009A 02003DA6
	v_fma_mixhi_f16 v154, v167, s30, 0                         // 000000189124: CC22009A 02003DA7
	ds_load_b128 v[164:167], v130 offset:96                    // 00000018912C: DBFC0060 A4000082
	ds_load_b128 v[174:177], v130 offset:112                   // 000000189134: DBFC0070 AE000082
	v_fma_mixlo_f16 v9, v150, s30, 0                           // 00000018913C: CC210009 02003D96
	v_fma_mixhi_f16 v9, v151, s30, 0                           // 000000189144: CC220009 02003D97
	v_fma_mixlo_f16 v10, v152, s30, 0                          // 00000018914C: CC21000A 02003D98
	v_fma_mixhi_f16 v10, v153, s30, 0                          // 000000189154: CC22000A 02003D99
	v_fma_mixhi_f16 v11, v155, s30, 0                          // 00000018915C: CC22000B 02003D9B
	s_waitcnt lgkmcnt(6)                                       // 000000189164: BF89FC67
	v_fma_mixlo_f16 v150, v25, s30, 0                          // 000000189168: CC210096 02003D19
	v_fma_mixhi_f16 v150, v26, s30, 0                          // 000000189170: CC220096 02003D1A
	v_fma_mixlo_f16 v151, v27, s30, 0                          // 000000189178: CC210097 02003D1B
	v_fma_mixhi_f16 v151, v28, s30, 0                          // 000000189180: CC220097 02003D1C
	s_waitcnt lgkmcnt(5)                                       // 000000189188: BF89FC57
	v_fma_mixlo_f16 v152, v29, s30, 0                          // 00000018918C: CC210098 02003D1D
	v_fma_mixhi_f16 v152, v30, s30, 0                          // 000000189194: CC220098 02003D1E
	v_fma_mixlo_f16 v153, v31, s30, 0                          // 00000018919C: CC210099 02003D1F
	v_fma_mixhi_f16 v153, v32, s30, 0                          // 0000001891A4: CC220099 02003D20
	v_fma_mixlo_f16 v155, v168, s30, 0                         // 0000001891AC: CC21009B 02003DA8
	v_fma_mixhi_f16 v155, v169, s30, 0                         // 0000001891B4: CC22009B 02003DA9
	s_waitcnt lgkmcnt(4)                                       // 0000001891BC: BF89FC47
	v_fma_mixlo_f16 v156, v156, s30, 0                         // 0000001891C0: CC21009C 02003D9C
	v_fma_mixhi_f16 v156, v157, s30, 0                         // 0000001891C8: CC22009C 02003D9D
	v_fma_mixlo_f16 v157, v158, s30, 0                         // 0000001891D0: CC21009D 02003D9E
	v_fma_mixhi_f16 v157, v159, s30, 0                         // 0000001891D8: CC22009D 02003D9F
	v_wmma_f32_16x16x16_f16 v[25:32], v[105:112], v[9:16], v[73:80]// 0000001891E0: CC404019 1D261369
	ds_load_b128 v[178:181], v130 offset:17008                 // 0000001891E8: DBFC4270 B2000082
	ds_load_b128 v[182:185], v130 offset:25408                 // 0000001891F0: DBFC6340 B6000082
	ds_load_b128 v[186:189], v130 offset:25424                 // 0000001891F8: DBFC6350 BA000082
	v_wmma_f32_16x16x16_f16 v[9:16], v[105:112], v[150:157], v[73:80]// 000000189200: CC404009 1D272D69
	ds_load_b128 v[150:153], v130 offset:8512                  // 000000189208: DBFC2140 96000082
	ds_load_b128 v[154:157], v130 offset:8528                  // 000000189210: DBFC2150 9A000082
	s_waitcnt lgkmcnt(8)                                       // 000000189218: BF89FC87
	v_fma_mixlo_f16 v105, v160, s30, 0                         // 00000018921C: CC210069 02003DA0
	v_fma_mixhi_f16 v105, v161, s30, 0                         // 000000189224: CC220069 02003DA1
	v_fma_mixlo_f16 v106, v162, s30, 0                         // 00000018922C: CC21006A 02003DA2
	v_fma_mixhi_f16 v106, v163, s30, 0                         // 000000189234: CC22006A 02003DA3
	s_waitcnt lgkmcnt(7)                                       // 00000018923C: BF89FC77
	v_fma_mixlo_f16 v107, v170, s30, 0                         // 000000189240: CC21006B 02003DAA
	v_fma_mixhi_f16 v107, v171, s30, 0                         // 000000189248: CC22006B 02003DAB
	v_fma_mixlo_f16 v108, v172, s30, 0                         // 000000189250: CC21006C 02003DAC
	v_fma_mixhi_f16 v108, v173, s30, 0                         // 000000189258: CC22006C 02003DAD
	ds_load_b128 v[158:161], v130 offset:8544                  // 000000189260: DBFC2160 9E000082
	s_waitcnt lgkmcnt(7)                                       // 000000189268: BF89FC77
	v_fma_mixlo_f16 v109, v164, s30, 0                         // 00000018926C: CC21006D 02003DA4
	v_fma_mixhi_f16 v109, v165, s30, 0                         // 000000189274: CC22006D 02003DA5
	v_fma_mixlo_f16 v110, v166, s30, 0                         // 00000018927C: CC21006E 02003DA6
	v_fma_mixhi_f16 v110, v167, s30, 0                         // 000000189284: CC22006E 02003DA7
	ds_load_b128 v[162:165], v130 offset:8560                  // 00000018928C: DBFC2170 A2000082
	s_waitcnt lgkmcnt(7)                                       // 000000189294: BF89FC77
	v_fma_mixlo_f16 v111, v174, s30, 0                         // 000000189298: CC21006F 02003DAE
	v_fma_mixhi_f16 v111, v175, s30, 0                         // 0000001892A0: CC22006F 02003DAF
	v_fma_mixlo_f16 v112, v176, s30, 0                         // 0000001892A8: CC210070 02003DB0
	v_fma_mixhi_f16 v112, v177, s30, 0                         // 0000001892B0: CC220070 02003DB1
	ds_load_b128 v[166:169], v130 offset:16960                 // 0000001892B8: DBFC4240 A6000082
	ds_load_b128 v[170:173], v130 offset:16976                 // 0000001892C0: DBFC4250 AA000082
	ds_load_b128 v[174:177], v130 offset:16992                 // 0000001892C8: DBFC4260 AE000082
	s_waitcnt lgkmcnt(6)                                       // 0000001892D0: BF89FC67
	v_fma_mixlo_f16 v150, v150, s30, 0                         // 0000001892D4: CC210096 02003D96
	v_fma_mixhi_f16 v150, v151, s30, 0                         // 0000001892DC: CC220096 02003D97
	v_fma_mixlo_f16 v151, v152, s30, 0                         // 0000001892E4: CC210097 02003D98
	v_fma_mixhi_f16 v151, v153, s30, 0                         // 0000001892EC: CC220097 02003D99
	s_waitcnt lgkmcnt(5)                                       // 0000001892F4: BF89FC57
	v_fma_mixhi_f16 v152, v155, s30, 0                         // 0000001892F8: CC220098 02003D9B
	v_fma_mixlo_f16 v153, v156, s30, 0                         // 000000189300: CC210099 02003D9C
	ds_load_b128 v[190:193], v130 offset:25440                 // 000000189308: DBFC6360 BE000082
	s_waitcnt lgkmcnt(5)                                       // 000000189310: BF89FC57
	v_fma_mixhi_f16 v155, v161, s30, 0                         // 000000189314: CC22009B 02003DA1
	v_fma_mixlo_f16 v152, v154, s30, 0                         // 00000018931C: CC210098 02003D9A
	v_fma_mixhi_f16 v153, v157, s30, 0                         // 000000189324: CC220099 02003D9D
	v_fma_mixlo_f16 v154, v158, s30, 0                         // 00000018932C: CC21009A 02003D9E
	v_fma_mixhi_f16 v154, v159, s30, 0                         // 000000189334: CC22009A 02003D9F
	s_waitcnt lgkmcnt(4)                                       // 00000018933C: BF89FC47
	v_fma_mixlo_f16 v156, v162, s30, 0                         // 000000189340: CC21009C 02003DA2
	v_fma_mixlo_f16 v155, v160, s30, 0                         // 000000189348: CC21009B 02003DA0
	v_fma_mixhi_f16 v156, v163, s30, 0                         // 000000189350: CC22009C 02003DA3
	v_fma_mixlo_f16 v157, v164, s30, 0                         // 000000189358: CC21009D 02003DA4
	v_fma_mixhi_f16 v157, v165, s30, 0                         // 000000189360: CC22009D 02003DA5
	s_waitcnt lgkmcnt(3)                                       // 000000189368: BF89FC37
	v_fma_mixlo_f16 v158, v166, s30, 0                         // 00000018936C: CC21009E 02003DA6
	s_waitcnt lgkmcnt(2)                                       // 000000189374: BF89FC27
	v_fma_mixlo_f16 v161, v172, s30, 0                         // 000000189378: CC2100A1 02003DAC
	v_fma_mixhi_f16 v161, v173, s30, 0                         // 000000189380: CC2200A1 02003DAD
	s_waitcnt lgkmcnt(1)                                       // 000000189388: BF89FC17
	v_fma_mixlo_f16 v162, v174, s30, 0                         // 00000018938C: CC2100A2 02003DAE
	v_fma_mixhi_f16 v162, v175, s30, 0                         // 000000189394: CC2200A2 02003DAF
	ds_load_b128 v[172:175], v130 offset:25456                 // 00000018939C: DBFC6370 AC000082
	v_fma_mixhi_f16 v158, v167, s30, 0                         // 0000001893A4: CC22009E 02003DA7
	v_fma_mixlo_f16 v159, v168, s30, 0                         // 0000001893AC: CC21009F 02003DA8
	v_fma_mixhi_f16 v159, v169, s30, 0                         // 0000001893B4: CC22009F 02003DA9
	v_fma_mixlo_f16 v160, v170, s30, 0                         // 0000001893BC: CC2100A0 02003DAA
	v_fma_mixhi_f16 v160, v171, s30, 0                         // 0000001893C4: CC2200A0 02003DAB
	v_fma_mixlo_f16 v163, v176, s30, 0                         // 0000001893CC: CC2100A3 02003DB0
	v_fma_mixhi_f16 v163, v177, s30, 0                         // 0000001893D4: CC2200A3 02003DB1
	v_fma_mixlo_f16 v164, v178, s30, 0                         // 0000001893DC: CC2100A4 02003DB2
	v_fma_mixhi_f16 v164, v179, s30, 0                         // 0000001893E4: CC2200A4 02003DB3
	v_fma_mixlo_f16 v165, v180, s30, 0                         // 0000001893EC: CC2100A5 02003DB4
	v_fma_mixhi_f16 v165, v181, s30, 0                         // 0000001893F4: CC2200A5 02003DB5
	v_fma_mixlo_f16 v166, v182, s30, 0                         // 0000001893FC: CC2100A6 02003DB6
	v_fma_mixhi_f16 v166, v183, s30, 0                         // 000000189404: CC2200A6 02003DB7
	v_fma_mixlo_f16 v167, v184, s30, 0                         // 00000018940C: CC2100A7 02003DB8
	v_fma_mixhi_f16 v167, v185, s30, 0                         // 000000189414: CC2200A7 02003DB9
	v_fma_mixlo_f16 v168, v186, s30, 0                         // 00000018941C: CC2100A8 02003DBA
	v_fma_mixhi_f16 v168, v187, s30, 0                         // 000000189424: CC2200A8 02003DBB
	v_fma_mixlo_f16 v169, v188, s30, 0                         // 00000018942C: CC2100A9 02003DBC
	v_fma_mixhi_f16 v169, v189, s30, 0                         // 000000189434: CC2200A9 02003DBD
	s_waitcnt lgkmcnt(1)                                       // 00000018943C: BF89FC17
	v_fma_mixlo_f16 v170, v190, s30, 0                         // 000000189440: CC2100AA 02003DBE
	v_fma_mixhi_f16 v170, v191, s30, 0                         // 000000189448: CC2200AA 02003DBF
	v_fma_mixlo_f16 v171, v192, s30, 0                         // 000000189450: CC2100AB 02003DC0
	v_fma_mixhi_f16 v171, v193, s30, 0                         // 000000189458: CC2200AB 02003DC1
	s_waitcnt lgkmcnt(0)                                       // 000000189460: BF89FC07
	v_fma_mixlo_f16 v172, v172, s30, 0                         // 000000189464: CC2100AC 02003DAC
	v_fma_mixhi_f16 v172, v173, s30, 0                         // 00000018946C: CC2200AC 02003DAD
	v_fma_mixlo_f16 v173, v174, s30, 0                         // 000000189474: CC2100AD 02003DAE
	v_fma_mixhi_f16 v173, v175, s30, 0                         // 00000018947C: CC2200AD 02003DAF
	ds_load_b128 v[176:179], v130 offset:128                   // 000000189484: DBFC0080 B0000082
	ds_load_b128 v[180:183], v130 offset:144                   // 00000018948C: DBFC0090 B4000082
	ds_load_b128 v[184:187], v130 offset:160                   // 000000189494: DBFC00A0 B8000082
	s_waitcnt vmcnt(12)                                        // 00000018949C: BF8933F7
	v_wmma_f32_16x16x16_f16 v[33:40], v[97:104], v[105:112], v[33:40]// 0000001894A0: CC404021 1C86D361
	ds_load_b128 v[105:108], v130 offset:176                   // 0000001894A8: DBFC00B0 69000082
	v_wmma_f32_16x16x16_f16 v[17:24], v[97:104], v[150:157], v[17:24]// 0000001894B0: CC404011 1C472D61
	v_wmma_f32_16x16x16_f16 v[25:32], v[97:104], v[158:165], v[25:32]// 0000001894B8: CC404019 1C673D61
	v_wmma_f32_16x16x16_f16 v[9:16], v[97:104], v[166:173], v[9:16]// 0000001894C0: CC404009 1C274D61
	ds_load_b128 v[109:112], v130 offset:8576                  // 0000001894C8: DBFC2180 6D000082
	ds_load_b128 v[150:153], v130 offset:8592                  // 0000001894D0: DBFC2190 96000082
	ds_load_b128 v[154:157], v130 offset:8608                  // 0000001894D8: DBFC21A0 9A000082
	ds_load_b128 v[158:161], v130 offset:8624                  // 0000001894E0: DBFC21B0 9E000082
	ds_load_b128 v[162:165], v130 offset:17024                 // 0000001894E8: DBFC4280 A2000082
	ds_load_b128 v[166:169], v130 offset:17040                 // 0000001894F0: DBFC4290 A6000082
	ds_load_b128 v[170:173], v130 offset:17056                 // 0000001894F8: DBFC42A0 AA000082
	s_mul_i32 s14, s31, 48                                     // 000000189500: 960EB01F
	s_mul_hi_u32 s41, s31, 48                                  // 000000189504: 96A9B01F
	s_add_u32 s42, s14, s2                                     // 000000189508: 802A020E
	s_addc_u32 s43, s41, s3                                    // 00000018950C: 822B0329
	ds_load_b128 v[190:193], v130 offset:25648                 // 000000189510: DBFC6430 BE000082
	s_waitcnt lgkmcnt(11)                                      // 000000189518: BF89FCB7
	v_fma_mixlo_f16 v97, v176, s30, 0                          // 00000018951C: CC210061 02003DB0
	v_fma_mixhi_f16 v97, v177, s30, 0                          // 000000189524: CC220061 02003DB1
	v_fma_mixlo_f16 v98, v178, s30, 0                          // 00000018952C: CC210062 02003DB2
	v_fma_mixhi_f16 v98, v179, s30, 0                          // 000000189534: CC220062 02003DB3
	s_waitcnt lgkmcnt(10)                                      // 00000018953C: BF89FCA7
	v_fma_mixlo_f16 v99, v180, s30, 0                          // 000000189540: CC210063 02003DB4
	v_fma_mixhi_f16 v99, v181, s30, 0                          // 000000189548: CC220063 02003DB5
	s_waitcnt lgkmcnt(8)                                       // 000000189550: BF89FC87
	v_fma_mixhi_f16 v103, v106, s30, 0                         // 000000189554: CC220067 02003D6A
	v_fma_mixlo_f16 v104, v107, s30, 0                         // 00000018955C: CC210068 02003D6B
	v_fma_mixhi_f16 v104, v108, s30, 0                         // 000000189564: CC220068 02003D6C
	s_waitcnt lgkmcnt(7)                                       // 00000018956C: BF89FC77
	v_fma_mixlo_f16 v106, v111, s30, 0                         // 000000189570: CC21006A 02003D6F
	v_fma_mixhi_f16 v106, v112, s30, 0                         // 000000189578: CC22006A 02003D70
	s_waitcnt lgkmcnt(6)                                       // 000000189580: BF89FC67
	v_fma_mixlo_f16 v107, v150, s30, 0                         // 000000189584: CC21006B 02003D96
	v_fma_mixhi_f16 v107, v151, s30, 0                         // 00000018958C: CC22006B 02003D97
	v_fma_mixlo_f16 v108, v152, s30, 0                         // 000000189594: CC21006C 02003D98
	v_fma_mixhi_f16 v108, v153, s30, 0                         // 00000018959C: CC22006C 02003D99
	s_waitcnt lgkmcnt(4)                                       // 0000001895A4: BF89FC47
	v_fma_mixlo_f16 v111, v158, s30, 0                         // 0000001895A8: CC21006F 02003D9E
	ds_load_b128 v[174:177], v130 offset:17072                 // 0000001895B0: DBFC42B0 AE000082
	v_fma_mixhi_f16 v111, v159, s30, 0                         // 0000001895B8: CC22006F 02003D9F
	v_fma_mixlo_f16 v112, v160, s30, 0                         // 0000001895C0: CC210070 02003DA0
	v_fma_mixhi_f16 v112, v161, s30, 0                         // 0000001895C8: CC220070 02003DA1
	ds_load_b128 v[158:161], v130 offset:25472                 // 0000001895D0: DBFC6380 9E000082
	ds_load_b128 v[178:181], v130 offset:25488                 // 0000001895D8: DBFC6390 B2000082
	s_waitcnt lgkmcnt(6)                                       // 0000001895E0: BF89FC67
	v_fma_mixlo_f16 v150, v162, s30, 0                         // 0000001895E4: CC210096 02003DA2
	v_fma_mixhi_f16 v150, v163, s30, 0                         // 0000001895EC: CC220096 02003DA3
	v_fma_mixlo_f16 v151, v164, s30, 0                         // 0000001895F4: CC210097 02003DA4
	v_fma_mixhi_f16 v151, v165, s30, 0                         // 0000001895FC: CC220097 02003DA5
	s_waitcnt lgkmcnt(5)                                       // 000000189604: BF89FC57
	v_fma_mixlo_f16 v152, v166, s30, 0                         // 000000189608: CC210098 02003DA6
	v_fma_mixhi_f16 v152, v167, s30, 0                         // 000000189610: CC220098 02003DA7
	v_fma_mixlo_f16 v153, v168, s30, 0                         // 000000189618: CC210099 02003DA8
	ds_load_b128 v[162:165], v130 offset:25504                 // 000000189620: DBFC63A0 A2000082
	v_fma_mixhi_f16 v153, v169, s30, 0                         // 000000189628: CC220099 02003DA9
	ds_load_b128 v[166:169], v130 offset:25520                 // 000000189630: DBFC63B0 A6000082
	v_fma_mixlo_f16 v100, v182, s30, 0                         // 000000189638: CC210064 02003DB6
	v_fma_mixhi_f16 v100, v183, s30, 0                         // 000000189640: CC220064 02003DB7
	v_fma_mixlo_f16 v101, v184, s30, 0                         // 000000189648: CC210065 02003DB8
	v_fma_mixhi_f16 v101, v185, s30, 0                         // 000000189650: CC220065 02003DB9
	v_fma_mixlo_f16 v102, v186, s30, 0                         // 000000189658: CC210066 02003DBA
	v_fma_mixhi_f16 v102, v187, s30, 0                         // 000000189660: CC220066 02003DBB
	v_fma_mixlo_f16 v103, v105, s30, 0                         // 000000189668: CC210067 02003D69
	v_fma_mixlo_f16 v105, v109, s30, 0                         // 000000189670: CC210069 02003D6D
	v_fma_mixhi_f16 v105, v110, s30, 0                         // 000000189678: CC220069 02003D6E
	v_fma_mixlo_f16 v109, v154, s30, 0                         // 000000189680: CC21006D 02003D9A
	v_fma_mixhi_f16 v109, v155, s30, 0                         // 000000189688: CC22006D 02003D9B
	v_fma_mixlo_f16 v110, v156, s30, 0                         // 000000189690: CC21006E 02003D9C
	v_fma_mixhi_f16 v110, v157, s30, 0                         // 000000189698: CC22006E 02003D9D
	s_waitcnt lgkmcnt(6)                                       // 0000001896A0: BF89FC67
	v_fma_mixlo_f16 v154, v170, s30, 0                         // 0000001896A4: CC21009A 02003DAA
	v_fma_mixhi_f16 v154, v171, s30, 0                         // 0000001896AC: CC22009A 02003DAB
	v_fma_mixlo_f16 v155, v172, s30, 0                         // 0000001896B4: CC21009B 02003DAC
	v_fma_mixhi_f16 v155, v173, s30, 0                         // 0000001896BC: CC22009B 02003DAD
	s_waitcnt lgkmcnt(4)                                       // 0000001896C4: BF89FC47
	v_fma_mixlo_f16 v156, v174, s30, 0                         // 0000001896C8: CC21009C 02003DAE
	v_fma_mixhi_f16 v156, v175, s30, 0                         // 0000001896D0: CC22009C 02003DAF
	v_fma_mixlo_f16 v157, v176, s30, 0                         // 0000001896D8: CC21009D 02003DB0
	v_fma_mixhi_f16 v157, v177, s30, 0                         // 0000001896E0: CC22009D 02003DB1
	s_waitcnt lgkmcnt(3)                                       // 0000001896E8: BF89FC37
	v_fma_mixlo_f16 v158, v158, s30, 0                         // 0000001896EC: CC21009E 02003D9E
	v_fma_mixhi_f16 v158, v159, s30, 0                         // 0000001896F4: CC22009E 02003D9F
	v_fma_mixlo_f16 v159, v160, s30, 0                         // 0000001896FC: CC21009F 02003DA0
	v_fma_mixhi_f16 v159, v161, s30, 0                         // 000000189704: CC22009F 02003DA1
	s_waitcnt lgkmcnt(2)                                       // 00000018970C: BF89FC27
	v_fma_mixlo_f16 v160, v178, s30, 0                         // 000000189710: CC2100A0 02003DB2
	v_fma_mixhi_f16 v160, v179, s30, 0                         // 000000189718: CC2200A0 02003DB3
	v_fma_mixlo_f16 v161, v180, s30, 0                         // 000000189720: CC2100A1 02003DB4
	v_fma_mixhi_f16 v161, v181, s30, 0                         // 000000189728: CC2200A1 02003DB5
	s_waitcnt lgkmcnt(1)                                       // 000000189730: BF89FC17
	v_fma_mixlo_f16 v162, v162, s30, 0                         // 000000189734: CC2100A2 02003DA2
	v_fma_mixhi_f16 v162, v163, s30, 0                         // 00000018973C: CC2200A2 02003DA3
	v_fma_mixlo_f16 v163, v164, s30, 0                         // 000000189744: CC2100A3 02003DA4
	v_fma_mixhi_f16 v163, v165, s30, 0                         // 00000018974C: CC2200A3 02003DA5
	s_waitcnt lgkmcnt(0)                                       // 000000189754: BF89FC07
	v_fma_mixlo_f16 v164, v166, s30, 0                         // 000000189758: CC2100A4 02003DA6
	v_fma_mixhi_f16 v164, v167, s30, 0                         // 000000189760: CC2200A4 02003DA7
	v_fma_mixlo_f16 v165, v168, s30, 0                         // 000000189768: CC2100A5 02003DA8
	v_fma_mixhi_f16 v165, v169, s30, 0                         // 000000189770: CC2200A5 02003DA9
	ds_load_b128 v[170:173], v130 offset:192                   // 000000189778: DBFC00C0 AA000082
	ds_load_b128 v[174:177], v130 offset:208                   // 000000189780: DBFC00D0 AE000082
	ds_load_b128 v[178:181], v130 offset:224                   // 000000189788: DBFC00E0 B2000082
	s_waitcnt vmcnt(10)                                        // 000000189790: BF892BF7
	v_wmma_f32_16x16x16_f16 v[33:40], v[89:96], v[97:104], v[33:40]// 000000189794: CC404021 1C86C359
	ds_load_b128 v[97:100], v130 offset:240                    // 00000018979C: DBFC00F0 61000082
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[105:112], v[17:24]// 0000001897A4: CC404011 1C46D359
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[150:157], v[25:32]// 0000001897AC: CC404019 1C672D59
	v_wmma_f32_16x16x16_f16 v[9:16], v[89:96], v[158:165], v[9:16]// 0000001897B4: CC404009 1C273D59
	ds_load_b128 v[101:104], v130 offset:8640                  // 0000001897BC: DBFC21C0 65000082
	ds_load_b128 v[105:108], v130 offset:8656                  // 0000001897C4: DBFC21D0 69000082
	ds_load_b128 v[109:112], v130 offset:8672                  // 0000001897CC: DBFC21E0 6D000082
	ds_load_b128 v[150:153], v130 offset:8688                  // 0000001897D4: DBFC21F0 96000082
	ds_load_b128 v[154:157], v130 offset:17088                 // 0000001897DC: DBFC42C0 9A000082
	ds_load_b128 v[158:161], v130 offset:17104                 // 0000001897E4: DBFC42D0 9E000082
	ds_load_b128 v[162:165], v130 offset:17120                 // 0000001897EC: DBFC42E0 A2000082
	ds_load_b128 v[166:169], v130 offset:17136                 // 0000001897F4: DBFC42F0 A6000082
	s_lshl_b64 s[42:43], s[42:43], 13                          // 0000001897FC: 84AA8D2A
	ds_load_b128 v[182:185], v130 offset:25616                 // 000000189800: DBFC6410 B6000082
	.long 0xd7006a7c                                           // 000000189808: D7006A7C
	v_cndmask_b32_e32 v0, v139, v42, vcc_lo                    // 00000018980C: 0200558B
	s_waitcnt lgkmcnt(12)                                      // 000000189810: BF89FCC7
	v_fma_mixlo_f16 v89, v170, s30, 0                          // 000000189814: CC210059 02003DAA
	v_fma_mixhi_f16 v89, v171, s30, 0                          // 00000018981C: CC220059 02003DAB
	v_fma_mixlo_f16 v90, v172, s30, 0                          // 000000189824: CC21005A 02003DAC
	v_fma_mixhi_f16 v90, v173, s30, 0                          // 00000018982C: CC22005A 02003DAD
	s_waitcnt lgkmcnt(9)                                       // 000000189834: BF89FC97
	v_fma_mixhi_f16 v95, v98, s30, 0                           // 000000189838: CC22005F 02003D62
	v_fma_mixlo_f16 v96, v99, s30, 0                           // 000000189840: CC210060 02003D63
	v_fma_mixhi_f16 v96, v100, s30, 0                          // 000000189848: CC220060 02003D64
	ds_load_b128 v[170:173], v130 offset:25552                 // 000000189850: DBFC63D0 AA000082
	s_waitcnt lgkmcnt(9)                                       // 000000189858: BF89FC97
	v_fma_mixlo_f16 v98, v103, s30, 0                          // 00000018985C: CC210062 02003D67
	v_fma_mixhi_f16 v98, v104, s30, 0                          // 000000189864: CC220062 02003D68
	s_waitcnt lgkmcnt(8)                                       // 00000018986C: BF89FC87
	v_fma_mixlo_f16 v99, v105, s30, 0                          // 000000189870: CC210063 02003D69
	v_fma_mixhi_f16 v99, v106, s30, 0                          // 000000189878: CC220063 02003D6A
	v_fma_mixlo_f16 v100, v107, s30, 0                         // 000000189880: CC210064 02003D6B
	v_fma_mixhi_f16 v100, v108, s30, 0                         // 000000189888: CC220064 02003D6C
	s_waitcnt lgkmcnt(6)                                       // 000000189890: BF89FC67
	v_fma_mixlo_f16 v103, v150, s30, 0                         // 000000189894: CC210067 02003D96
	v_fma_mixhi_f16 v103, v151, s30, 0                         // 00000018989C: CC220067 02003D97
	v_fma_mixlo_f16 v104, v152, s30, 0                         // 0000001898A4: CC210068 02003D98
	v_fma_mixhi_f16 v104, v153, s30, 0                         // 0000001898AC: CC220068 02003D99
	ds_load_b128 v[150:153], v130 offset:25536                 // 0000001898B4: DBFC63C0 96000082
	s_waitcnt lgkmcnt(6)                                       // 0000001898BC: BF89FC67
	v_fma_mixlo_f16 v105, v154, s30, 0                         // 0000001898C0: CC210069 02003D9A
	v_fma_mixhi_f16 v105, v155, s30, 0                         // 0000001898C8: CC220069 02003D9B
	v_fma_mixlo_f16 v106, v156, s30, 0                         // 0000001898D0: CC21006A 02003D9C
	v_fma_mixhi_f16 v106, v157, s30, 0                         // 0000001898D8: CC22006A 02003D9D
	s_waitcnt lgkmcnt(5)                                       // 0000001898E0: BF89FC57
	v_fma_mixlo_f16 v107, v158, s30, 0                         // 0000001898E4: CC21006B 02003D9E
	v_fma_mixhi_f16 v107, v159, s30, 0                         // 0000001898EC: CC22006B 02003D9F
	v_fma_mixlo_f16 v108, v160, s30, 0                         // 0000001898F4: CC21006C 02003DA0
	v_fma_mixhi_f16 v108, v161, s30, 0                         // 0000001898FC: CC22006C 02003DA1
	ds_load_b128 v[154:157], v130 offset:25568                 // 000000189904: DBFC63E0 9A000082
	ds_load_b128 v[158:161], v130 offset:25584                 // 00000018990C: DBFC63F0 9E000082
	v_fma_mixlo_f16 v91, v174, s30, 0                          // 000000189914: CC21005B 02003DAE
	v_fma_mixhi_f16 v91, v175, s30, 0                          // 00000018991C: CC22005B 02003DAF
	v_fma_mixlo_f16 v92, v176, s30, 0                          // 000000189924: CC21005C 02003DB0
	v_fma_mixhi_f16 v92, v177, s30, 0                          // 00000018992C: CC22005C 02003DB1
	v_fma_mixlo_f16 v93, v178, s30, 0                          // 000000189934: CC21005D 02003DB2
	v_fma_mixhi_f16 v93, v179, s30, 0                          // 00000018993C: CC22005D 02003DB3
	v_fma_mixlo_f16 v94, v180, s30, 0                          // 000000189944: CC21005E 02003DB4
	v_fma_mixhi_f16 v94, v181, s30, 0                          // 00000018994C: CC22005E 02003DB5
	v_fma_mixlo_f16 v95, v97, s30, 0                           // 000000189954: CC21005F 02003D61
	v_fma_mixlo_f16 v97, v101, s30, 0                          // 00000018995C: CC210061 02003D65
	v_fma_mixhi_f16 v97, v102, s30, 0                          // 000000189964: CC220061 02003D66
	v_fma_mixlo_f16 v101, v109, s30, 0                         // 00000018996C: CC210065 02003D6D
	v_fma_mixhi_f16 v101, v110, s30, 0                         // 000000189974: CC220065 02003D6E
	v_fma_mixlo_f16 v102, v111, s30, 0                         // 00000018997C: CC210066 02003D6F
	v_fma_mixhi_f16 v102, v112, s30, 0                         // 000000189984: CC220066 02003D70
	s_waitcnt lgkmcnt(6)                                       // 00000018998C: BF89FC67
	v_fma_mixlo_f16 v109, v162, s30, 0                         // 000000189990: CC21006D 02003DA2
	v_fma_mixhi_f16 v109, v163, s30, 0                         // 000000189998: CC22006D 02003DA3
	v_fma_mixlo_f16 v110, v164, s30, 0                         // 0000001899A0: CC21006E 02003DA4
	v_fma_mixhi_f16 v110, v165, s30, 0                         // 0000001899A8: CC22006E 02003DA5
	s_waitcnt lgkmcnt(5)                                       // 0000001899B0: BF89FC57
	v_fma_mixlo_f16 v111, v166, s30, 0                         // 0000001899B4: CC21006F 02003DA6
	v_fma_mixhi_f16 v111, v167, s30, 0                         // 0000001899BC: CC22006F 02003DA7
	v_fma_mixlo_f16 v112, v168, s30, 0                         // 0000001899C4: CC210070 02003DA8
	v_fma_mixhi_f16 v112, v169, s30, 0                         // 0000001899CC: CC220070 02003DA9
	s_waitcnt vmcnt(8)                                         // 0000001899D4: BF8923F7
	v_wmma_f32_16x16x16_f16 v[33:40], v[81:88], v[89:96], v[33:40]// 0000001899D8: CC404021 1C86B351
	ds_load_b128 v[89:92], v130 offset:8704                    // 0000001899E0: DBFC2200 59000082
	ds_load_b128 v[93:96], v130 offset:8720                    // 0000001899E8: DBFC2210 5D000082
	s_waitcnt lgkmcnt(4)                                       // 0000001899F0: BF89FC47
	v_fma_mixlo_f16 v150, v150, s30, 0                         // 0000001899F4: CC210096 02003D96
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[105:112], v[25:32]// 0000001899FC: CC404019 1C66D351
	ds_load_b128 v[110:113], v130 offset:8736                  // 000000189A04: DBFC2220 6E000082
	v_fma_mixhi_f16 v150, v151, s30, 0                         // 000000189A0C: CC220096 02003D97
	v_fma_mixlo_f16 v151, v152, s30, 0                         // 000000189A14: CC210097 02003D98
	v_fma_mixhi_f16 v151, v153, s30, 0                         // 000000189A1C: CC220097 02003D99
	v_fma_mixlo_f16 v152, v170, s30, 0                         // 000000189A24: CC210098 02003DAA
	v_fma_mixhi_f16 v152, v171, s30, 0                         // 000000189A2C: CC220098 02003DAB
	v_fma_mixlo_f16 v153, v172, s30, 0                         // 000000189A34: CC210099 02003DAC
	v_fma_mixhi_f16 v153, v173, s30, 0                         // 000000189A3C: CC220099 02003DAD
	s_waitcnt lgkmcnt(4)                                       // 000000189A44: BF89FC47
	v_fma_mixlo_f16 v154, v154, s30, 0                         // 000000189A48: CC21009A 02003D9A
	v_fma_mixhi_f16 v154, v155, s30, 0                         // 000000189A50: CC22009A 02003D9B
	v_fma_mixlo_f16 v155, v156, s30, 0                         // 000000189A58: CC21009B 02003D9C
	v_fma_mixhi_f16 v155, v157, s30, 0                         // 000000189A60: CC22009B 02003D9D
	s_waitcnt lgkmcnt(3)                                       // 000000189A68: BF89FC37
	v_fma_mixlo_f16 v156, v158, s30, 0                         // 000000189A6C: CC21009C 02003D9E
	v_fma_mixhi_f16 v156, v159, s30, 0                         // 000000189A74: CC22009C 02003D9F
	v_fma_mixlo_f16 v157, v160, s30, 0                         // 000000189A7C: CC21009D 02003DA0
	v_fma_mixhi_f16 v157, v161, s30, 0                         // 000000189A84: CC22009D 02003DA1
	v_add_co_ci_u32_e64 v125, null, s43, v140, vcc_lo          // 000000189A8C: D5207C7D 01AB182B
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[97:104], v[17:24]// 000000189A94: CC404011 1C46C351
	s_waitcnt lgkmcnt(2)                                       // 000000189A9C: BF89FC27
	v_fma_mixlo_f16 v89, v89, s30, 0                           // 000000189AA0: CC210059 02003D59
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[150:157], v[9:16]// 000000189AA8: CC404009 1C272D51
	s_clause 0x1                                               // 000000189AB0: BF850001
	global_load_b128 v[154:157], v[124:125], off offset:16     // 000000189AB4: DC5E0010 9A7C007C
	global_load_b128 v[150:153], v[124:125], off               // 000000189ABC: DC5E0000 967C007C
	v_fma_mixhi_f16 v89, v90, s30, 0                           // 000000189AC4: CC220059 02003D5A
	v_fma_mixlo_f16 v90, v91, s30, 0                           // 000000189ACC: CC21005A 02003D5B
	ds_load_b128 v[158:161], v130 offset:8752                  // 000000189AD4: DBFC2230 9E000082
	s_waitcnt lgkmcnt(2)                                       // 000000189ADC: BF89FC27
	v_fma_mixlo_f16 v91, v93, s30, 0                           // 000000189AE0: CC21005B 02003D5D
	v_fma_mixhi_f16 v91, v94, s30, 0                           // 000000189AE8: CC22005B 02003D5E
	s_waitcnt lgkmcnt(1)                                       // 000000189AF0: BF89FC17
	v_fma_mixlo_f16 v93, v110, s30, 0                          // 000000189AF4: CC21005D 02003D6E
	v_fma_mixhi_f16 v93, v111, s30, 0                          // 000000189AFC: CC22005D 02003D6F
	v_fma_mixlo_f16 v94, v112, s30, 0                          // 000000189B04: CC21005E 02003D70
	s_clause 0x3                                               // 000000189B0C: BF850003
	global_load_b128 v[109:112], v[124:125], off offset:80     // 000000189B10: DC5E0050 6D7C007C
	global_load_b128 v[105:108], v[124:125], off offset:64     // 000000189B18: DC5E0040 697C007C
	global_load_b128 v[101:104], v[124:125], off offset:112    // 000000189B20: DC5E0070 657C007C
	global_load_b128 v[97:100], v[124:125], off offset:96      // 000000189B28: DC5E0060 617C007C
	ds_load_b128 v[162:165], v130 offset:256                   // 000000189B30: DBFC0100 A2000082
	ds_load_b128 v[166:169], v130 offset:272                   // 000000189B38: DBFC0110 A6000082
	ds_load_b128 v[170:173], v130 offset:288                   // 000000189B40: DBFC0120 AA000082
	ds_load_b128 v[174:177], v130 offset:304                   // 000000189B48: DBFC0130 AE000082
	ds_load_b128 v[178:181], v130 offset:25600                 // 000000189B50: DBFC6400 B2000082
	ds_load_b128 v[186:189], v130 offset:25632                 // 000000189B58: DBFC6420 BA000082
	v_fma_mixhi_f16 v90, v92, s30, 0                           // 000000189B60: CC22005A 02003D5C
	v_fma_mixlo_f16 v92, v95, s30, 0                           // 000000189B68: CC21005C 02003D5F
	v_fma_mixhi_f16 v92, v96, s30, 0                           // 000000189B70: CC22005C 02003D60
	v_fma_mixhi_f16 v94, v113, s30, 0                          // 000000189B78: CC22005E 02003D71
	s_waitcnt lgkmcnt(6)                                       // 000000189B80: BF89FC67
	v_fma_mixlo_f16 v95, v158, s30, 0                          // 000000189B84: CC21005F 02003D9E
	v_fma_mixhi_f16 v95, v159, s30, 0                          // 000000189B8C: CC22005F 02003D9F
	v_fma_mixlo_f16 v96, v160, s30, 0                          // 000000189B94: CC210060 02003DA0
	v_fma_mixhi_f16 v96, v161, s30, 0                          // 000000189B9C: CC220060 02003DA1
	s_waitcnt lgkmcnt(5)                                       // 000000189BA4: BF89FC57
	v_fma_mixlo_f16 v81, v162, s30, 0                          // 000000189BA8: CC210051 02003DA2
	v_fma_mixhi_f16 v81, v163, s30, 0                          // 000000189BB0: CC220051 02003DA3
	v_fma_mixlo_f16 v82, v164, s30, 0                          // 000000189BB8: CC210052 02003DA4
	v_fma_mixhi_f16 v82, v165, s30, 0                          // 000000189BC0: CC220052 02003DA5
	s_waitcnt lgkmcnt(4)                                       // 000000189BC8: BF89FC47
	v_fma_mixlo_f16 v83, v166, s30, 0                          // 000000189BCC: CC210053 02003DA6
	v_fma_mixhi_f16 v83, v167, s30, 0                          // 000000189BD4: CC220053 02003DA7
	v_fma_mixlo_f16 v84, v168, s30, 0                          // 000000189BDC: CC210054 02003DA8
	v_fma_mixhi_f16 v84, v169, s30, 0                          // 000000189BE4: CC220054 02003DA9
	s_waitcnt lgkmcnt(3)                                       // 000000189BEC: BF89FC37
	v_fma_mixlo_f16 v85, v170, s30, 0                          // 000000189BF0: CC210055 02003DAA
	v_fma_mixhi_f16 v85, v171, s30, 0                          // 000000189BF8: CC220055 02003DAB
	v_fma_mixlo_f16 v86, v172, s30, 0                          // 000000189C00: CC210056 02003DAC
	v_fma_mixhi_f16 v86, v173, s30, 0                          // 000000189C08: CC220056 02003DAD
	s_waitcnt lgkmcnt(2)                                       // 000000189C10: BF89FC27
	v_fma_mixlo_f16 v87, v174, s30, 0                          // 000000189C14: CC210057 02003DAE
	v_fma_mixhi_f16 v87, v175, s30, 0                          // 000000189C1C: CC220057 02003DAF
	v_fma_mixlo_f16 v88, v176, s30, 0                          // 000000189C24: CC210058 02003DB0
	v_fma_mixhi_f16 v88, v177, s30, 0                          // 000000189C2C: CC220058 02003DB1
	ds_load_b128 v[162:165], v130 offset:17152                 // 000000189C34: DBFC4300 A2000082
	ds_load_b128 v[166:169], v130 offset:17168                 // 000000189C3C: DBFC4310 A6000082
	ds_load_b128 v[170:173], v130 offset:17184                 // 000000189C44: DBFC4320 AA000082
	ds_load_b128 v[174:177], v130 offset:17200                 // 000000189C4C: DBFC4330 AE000082
	s_waitcnt vmcnt(12)                                        // 000000189C54: BF8933F7
	v_wmma_f32_16x16x16_f16 v[33:40], v[65:72], v[81:88], v[33:40]// 000000189C58: CC404021 1C86A341
	ds_load_b128 v[81:84], v130 offset:368                     // 000000189C60: DBFC0170 51000082
	v_wmma_f32_16x16x16_f16 v[17:24], v[65:72], v[89:96], v[17:24]// 000000189C68: CC404011 1C46B341
	ds_load_b128 v[85:88], v130 offset:8768                    // 000000189C70: DBFC2240 55000082
	ds_load_b128 v[89:92], v130 offset:8784                    // 000000189C78: DBFC2250 59000082
	ds_load_b128 v[93:96], v130 offset:8800                    // 000000189C80: DBFC2260 5D000082
	s_waitcnt lgkmcnt(7)                                       // 000000189C88: BF89FC77
	v_fma_mixlo_f16 v158, v162, s30, 0                         // 000000189C8C: CC21009E 02003DA2
	v_fma_mixhi_f16 v158, v163, s30, 0                         // 000000189C94: CC22009E 02003DA3
	v_fma_mixlo_f16 v159, v164, s30, 0                         // 000000189C9C: CC21009F 02003DA4
	v_fma_mixhi_f16 v159, v165, s30, 0                         // 000000189CA4: CC22009F 02003DA5
	s_waitcnt lgkmcnt(6)                                       // 000000189CAC: BF89FC67
	v_fma_mixlo_f16 v160, v166, s30, 0                         // 000000189CB0: CC2100A0 02003DA6
	v_fma_mixhi_f16 v160, v167, s30, 0                         // 000000189CB8: CC2200A0 02003DA7
	v_fma_mixlo_f16 v161, v168, s30, 0                         // 000000189CC0: CC2100A1 02003DA8
	v_fma_mixhi_f16 v161, v169, s30, 0                         // 000000189CC8: CC2200A1 02003DA9
	s_waitcnt lgkmcnt(5)                                       // 000000189CD0: BF89FC57
	v_fma_mixlo_f16 v162, v170, s30, 0                         // 000000189CD4: CC2100A2 02003DAA
	v_fma_mixhi_f16 v162, v171, s30, 0                         // 000000189CDC: CC2200A2 02003DAB
	v_fma_mixlo_f16 v163, v172, s30, 0                         // 000000189CE4: CC2100A3 02003DAC
	v_fma_mixhi_f16 v163, v173, s30, 0                         // 000000189CEC: CC2200A3 02003DAD
	s_waitcnt lgkmcnt(4)                                       // 000000189CF4: BF89FC47
	v_fma_mixlo_f16 v164, v174, s30, 0                         // 000000189CF8: CC2100A4 02003DAE
	v_fma_mixhi_f16 v164, v175, s30, 0                         // 000000189D00: CC2200A4 02003DAF
	v_fma_mixlo_f16 v165, v176, s30, 0                         // 000000189D08: CC2100A5 02003DB0
	v_fma_mixhi_f16 v165, v177, s30, 0                         // 000000189D10: CC2200A5 02003DB1
	v_fma_mixlo_f16 v166, v178, s30, 0                         // 000000189D18: CC2100A6 02003DB2
	v_fma_mixhi_f16 v166, v179, s30, 0                         // 000000189D20: CC2200A6 02003DB3
	v_fma_mixlo_f16 v167, v180, s30, 0                         // 000000189D28: CC2100A7 02003DB4
	v_fma_mixhi_f16 v167, v181, s30, 0                         // 000000189D30: CC2200A7 02003DB5
	v_fma_mixlo_f16 v168, v182, s30, 0                         // 000000189D38: CC2100A8 02003DB6
	v_fma_mixhi_f16 v168, v183, s30, 0                         // 000000189D40: CC2200A8 02003DB7
	v_fma_mixlo_f16 v169, v184, s30, 0                         // 000000189D48: CC2100A9 02003DB8
	v_fma_mixhi_f16 v169, v185, s30, 0                         // 000000189D50: CC2200A9 02003DB9
	v_fma_mixlo_f16 v170, v186, s30, 0                         // 000000189D58: CC2100AA 02003DBA
	v_fma_mixhi_f16 v170, v187, s30, 0                         // 000000189D60: CC2200AA 02003DBB
	v_fma_mixlo_f16 v171, v188, s30, 0                         // 000000189D68: CC2100AB 02003DBC
	v_fma_mixhi_f16 v171, v189, s30, 0                         // 000000189D70: CC2200AB 02003DBD
	v_fma_mixlo_f16 v172, v190, s30, 0                         // 000000189D78: CC2100AC 02003DBE
	v_fma_mixhi_f16 v172, v191, s30, 0                         // 000000189D80: CC2200AC 02003DBF
	v_fma_mixlo_f16 v173, v192, s30, 0                         // 000000189D88: CC2100AD 02003DC0
	v_fma_mixhi_f16 v173, v193, s30, 0                         // 000000189D90: CC2200AD 02003DC1
	ds_load_b128 v[174:177], v130 offset:320                   // 000000189D98: DBFC0140 AE000082
	ds_load_b128 v[178:181], v130 offset:336                   // 000000189DA0: DBFC0150 B2000082
	ds_load_b128 v[182:185], v130 offset:352                   // 000000189DA8: DBFC0160 B6000082
	v_wmma_f32_16x16x16_f16 v[25:32], v[65:72], v[158:165], v[25:32]// 000000189DB0: CC404019 1C673D41
	v_wmma_f32_16x16x16_f16 v[9:16], v[65:72], v[166:173], v[9:16]// 000000189DB8: CC404009 1C274D41
	ds_load_b128 v[158:161], v130 offset:8816                  // 000000189DC0: DBFC2270 9E000082
	ds_load_b128 v[162:165], v130 offset:17216                 // 000000189DC8: DBFC4340 A2000082
	ds_load_b128 v[166:169], v130 offset:17232                 // 000000189DD0: DBFC4350 A6000082
	s_waitcnt lgkmcnt(9)                                       // 000000189DD8: BF89FC97
	v_fma_mixhi_f16 v71, v82, s30, 0                           // 000000189DDC: CC220047 02003D52
	v_fma_mixlo_f16 v72, v83, s30, 0                           // 000000189DE4: CC210048 02003D53
	v_fma_mixhi_f16 v72, v84, s30, 0                           // 000000189DEC: CC220048 02003D54
	s_waitcnt lgkmcnt(8)                                       // 000000189DF4: BF89FC87
	v_fma_mixlo_f16 v82, v87, s30, 0                           // 000000189DF8: CC210052 02003D57
	v_fma_mixhi_f16 v82, v88, s30, 0                           // 000000189E00: CC220052 02003D58
	s_waitcnt lgkmcnt(7)                                       // 000000189E08: BF89FC77
	v_fma_mixlo_f16 v83, v89, s30, 0                           // 000000189E0C: CC210053 02003D59
	v_fma_mixhi_f16 v83, v90, s30, 0                           // 000000189E14: CC220053 02003D5A
	v_fma_mixlo_f16 v84, v91, s30, 0                           // 000000189E1C: CC210054 02003D5B
	v_fma_mixhi_f16 v84, v92, s30, 0                           // 000000189E24: CC220054 02003D5C
	ds_load_b128 v[170:173], v130 offset:17248                 // 000000189E2C: DBFC4360 AA000082
	v_fma_mixlo_f16 v71, v81, s30, 0                           // 000000189E34: CC210047 02003D51
	v_fma_mixlo_f16 v81, v85, s30, 0                           // 000000189E3C: CC210051 02003D55
	s_waitcnt lgkmcnt(6)                                       // 000000189E44: BF89FC67
	v_fma_mixlo_f16 v65, v174, s30, 0                          // 000000189E48: CC210041 02003DAE
	v_fma_mixhi_f16 v65, v175, s30, 0                          // 000000189E50: CC220041 02003DAF
	v_fma_mixlo_f16 v66, v176, s30, 0                          // 000000189E58: CC210042 02003DB0
	v_fma_mixhi_f16 v66, v177, s30, 0                          // 000000189E60: CC220042 02003DB1
	s_waitcnt lgkmcnt(5)                                       // 000000189E68: BF89FC57
	v_fma_mixlo_f16 v67, v178, s30, 0                          // 000000189E6C: CC210043 02003DB2
	v_fma_mixhi_f16 v67, v179, s30, 0                          // 000000189E74: CC220043 02003DB3
	v_fma_mixlo_f16 v68, v180, s30, 0                          // 000000189E7C: CC210044 02003DB4
	v_fma_mixhi_f16 v68, v181, s30, 0                          // 000000189E84: CC220044 02003DB5
	s_waitcnt lgkmcnt(3)                                       // 000000189E8C: BF89FC37
	v_fma_mixlo_f16 v87, v158, s30, 0                          // 000000189E90: CC210057 02003D9E
	ds_load_b128 v[174:177], v130 offset:17264                 // 000000189E98: DBFC4370 AE000082
	v_fma_mixhi_f16 v87, v159, s30, 0                          // 000000189EA0: CC220057 02003D9F
	v_fma_mixlo_f16 v88, v160, s30, 0                          // 000000189EA8: CC210058 02003DA0
	v_fma_mixhi_f16 v88, v161, s30, 0                          // 000000189EB0: CC220058 02003DA1
	ds_load_b128 v[158:161], v130 offset:25664                 // 000000189EB8: DBFC6440 9E000082
	ds_load_b128 v[178:181], v130 offset:25680                 // 000000189EC0: DBFC6450 B2000082
	s_waitcnt lgkmcnt(5)                                       // 000000189EC8: BF89FC57
	v_fma_mixlo_f16 v89, v162, s30, 0                          // 000000189ECC: CC210059 02003DA2
	v_fma_mixhi_f16 v89, v163, s30, 0                          // 000000189ED4: CC220059 02003DA3
	v_fma_mixlo_f16 v90, v164, s30, 0                          // 000000189EDC: CC21005A 02003DA4
	v_fma_mixhi_f16 v90, v165, s30, 0                          // 000000189EE4: CC22005A 02003DA5
	s_waitcnt lgkmcnt(4)                                       // 000000189EEC: BF89FC47
	v_fma_mixlo_f16 v91, v166, s30, 0                          // 000000189EF0: CC21005B 02003DA6
	v_fma_mixhi_f16 v91, v167, s30, 0                          // 000000189EF8: CC22005B 02003DA7
	v_fma_mixlo_f16 v92, v168, s30, 0                          // 000000189F00: CC21005C 02003DA8
	ds_load_b128 v[162:165], v130 offset:25696                 // 000000189F08: DBFC6460 A2000082
	v_fma_mixhi_f16 v92, v169, s30, 0                          // 000000189F10: CC22005C 02003DA9
	ds_load_b128 v[166:169], v130 offset:25712                 // 000000189F18: DBFC6470 A6000082
	v_fma_mixlo_f16 v69, v182, s30, 0                          // 000000189F20: CC210045 02003DB6
	v_fma_mixhi_f16 v69, v183, s30, 0                          // 000000189F28: CC220045 02003DB7
	v_fma_mixlo_f16 v70, v184, s30, 0                          // 000000189F30: CC210046 02003DB8
	v_fma_mixhi_f16 v70, v185, s30, 0                          // 000000189F38: CC220046 02003DB9
	v_fma_mixhi_f16 v81, v86, s30, 0                           // 000000189F40: CC220051 02003D56
	v_fma_mixlo_f16 v85, v93, s30, 0                           // 000000189F48: CC210055 02003D5D
	v_fma_mixhi_f16 v85, v94, s30, 0                           // 000000189F50: CC220055 02003D5E
	v_fma_mixlo_f16 v86, v95, s30, 0                           // 000000189F58: CC210056 02003D5F
	v_fma_mixhi_f16 v86, v96, s30, 0                           // 000000189F60: CC220056 02003D60
	s_waitcnt lgkmcnt(5)                                       // 000000189F68: BF89FC57
	v_fma_mixlo_f16 v93, v170, s30, 0                          // 000000189F6C: CC21005D 02003DAA
	v_fma_mixhi_f16 v93, v171, s30, 0                          // 000000189F74: CC22005D 02003DAB
	v_fma_mixlo_f16 v94, v172, s30, 0                          // 000000189F7C: CC21005E 02003DAC
	v_fma_mixhi_f16 v94, v173, s30, 0                          // 000000189F84: CC22005E 02003DAD
	s_waitcnt lgkmcnt(4)                                       // 000000189F8C: BF89FC47
	v_fma_mixlo_f16 v95, v174, s30, 0                          // 000000189F90: CC21005F 02003DAE
	v_fma_mixhi_f16 v95, v175, s30, 0                          // 000000189F98: CC22005F 02003DAF
	v_fma_mixlo_f16 v96, v176, s30, 0                          // 000000189FA0: CC210060 02003DB0
	v_fma_mixhi_f16 v96, v177, s30, 0                          // 000000189FA8: CC220060 02003DB1
	s_waitcnt lgkmcnt(3)                                       // 000000189FB0: BF89FC37
	v_fma_mixlo_f16 v158, v158, s30, 0                         // 000000189FB4: CC21009E 02003D9E
	v_fma_mixhi_f16 v158, v159, s30, 0                         // 000000189FBC: CC22009E 02003D9F
	v_fma_mixlo_f16 v159, v160, s30, 0                         // 000000189FC4: CC21009F 02003DA0
	v_fma_mixhi_f16 v159, v161, s30, 0                         // 000000189FCC: CC22009F 02003DA1
	s_waitcnt lgkmcnt(2)                                       // 000000189FD4: BF89FC27
	v_fma_mixlo_f16 v160, v178, s30, 0                         // 000000189FD8: CC2100A0 02003DB2
	v_fma_mixhi_f16 v160, v179, s30, 0                         // 000000189FE0: CC2200A0 02003DB3
	v_fma_mixlo_f16 v161, v180, s30, 0                         // 000000189FE8: CC2100A1 02003DB4
	v_fma_mixhi_f16 v161, v181, s30, 0                         // 000000189FF0: CC2200A1 02003DB5
	s_waitcnt lgkmcnt(1)                                       // 000000189FF8: BF89FC17
	v_fma_mixlo_f16 v162, v162, s30, 0                         // 000000189FFC: CC2100A2 02003DA2
	v_fma_mixhi_f16 v162, v163, s30, 0                         // 00000018A004: CC2200A2 02003DA3
	v_fma_mixlo_f16 v163, v164, s30, 0                         // 00000018A00C: CC2100A3 02003DA4
	v_fma_mixhi_f16 v163, v165, s30, 0                         // 00000018A014: CC2200A3 02003DA5
	s_waitcnt lgkmcnt(0)                                       // 00000018A01C: BF89FC07
	v_fma_mixlo_f16 v164, v166, s30, 0                         // 00000018A020: CC2100A4 02003DA6
	v_fma_mixhi_f16 v164, v167, s30, 0                         // 00000018A028: CC2200A4 02003DA7
	v_fma_mixlo_f16 v165, v168, s30, 0                         // 00000018A030: CC2100A5 02003DA8
	v_fma_mixhi_f16 v165, v169, s30, 0                         // 00000018A038: CC2200A5 02003DA9
	ds_load_b128 v[170:173], v130 offset:384                   // 00000018A040: DBFC0180 AA000082
	ds_load_b128 v[174:177], v130 offset:400                   // 00000018A048: DBFC0190 AE000082
	ds_load_b128 v[178:181], v130 offset:416                   // 00000018A050: DBFC01A0 B2000082
	s_waitcnt vmcnt(10)                                        // 00000018A058: BF892BF7
	v_wmma_f32_16x16x16_f16 v[33:40], v[57:64], v[65:72], v[33:40]// 00000018A05C: CC404021 1C868339
	ds_load_b128 v[65:68], v130 offset:432                     // 00000018A064: DBFC01B0 41000082
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[81:88], v[17:24]// 00000018A06C: CC404011 1C46A339
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[89:96], v[25:32]// 00000018A074: CC404019 1C66B339
	v_wmma_f32_16x16x16_f16 v[9:16], v[57:64], v[158:165], v[9:16]// 00000018A07C: CC404009 1C273D39
	ds_load_b128 v[69:72], v130 offset:8832                    // 00000018A084: DBFC2280 45000082
	ds_load_b128 v[81:84], v130 offset:8848                    // 00000018A08C: DBFC2290 51000082
	ds_load_b128 v[85:88], v130 offset:8864                    // 00000018A094: DBFC22A0 55000082
	ds_load_b128 v[89:92], v130 offset:8880                    // 00000018A09C: DBFC22B0 59000082
	ds_load_b128 v[93:96], v130 offset:17280                   // 00000018A0A4: DBFC4380 5D000082
	ds_load_b128 v[158:161], v130 offset:17296                 // 00000018A0AC: DBFC4390 9E000082
	ds_load_b128 v[162:165], v130 offset:17312                 // 00000018A0B4: DBFC43A0 A2000082
	ds_load_b128 v[166:169], v130 offset:17328                 // 00000018A0BC: DBFC43B0 A6000082
	ds_load_b128 v[185:188], v130 offset:25840                 // 00000018A0C4: DBFC64F0 B9000082
	s_waitcnt lgkmcnt(12)                                      // 00000018A0CC: BF89FCC7
	v_fma_mixlo_f16 v57, v170, s30, 0                          // 00000018A0D0: CC210039 02003DAA
	v_fma_mixhi_f16 v57, v171, s30, 0                          // 00000018A0D8: CC220039 02003DAB
	v_fma_mixlo_f16 v58, v172, s30, 0                          // 00000018A0E0: CC21003A 02003DAC
	v_fma_mixhi_f16 v58, v173, s30, 0                          // 00000018A0E8: CC22003A 02003DAD
	s_waitcnt lgkmcnt(9)                                       // 00000018A0F0: BF89FC97
	v_fma_mixhi_f16 v63, v66, s30, 0                           // 00000018A0F4: CC22003F 02003D42
	v_fma_mixlo_f16 v64, v67, s30, 0                           // 00000018A0FC: CC210040 02003D43
	v_fma_mixhi_f16 v64, v68, s30, 0                           // 00000018A104: CC220040 02003D44
	ds_load_b128 v[170:173], v130 offset:25744                 // 00000018A10C: DBFC6490 AA000082
	s_waitcnt lgkmcnt(9)                                       // 00000018A114: BF89FC97
	v_fma_mixlo_f16 v66, v71, s30, 0                           // 00000018A118: CC210042 02003D47
	v_fma_mixhi_f16 v66, v72, s30, 0                           // 00000018A120: CC220042 02003D48
	s_waitcnt lgkmcnt(8)                                       // 00000018A128: BF89FC87
	v_fma_mixlo_f16 v67, v81, s30, 0                           // 00000018A12C: CC210043 02003D51
	v_fma_mixhi_f16 v67, v82, s30, 0                           // 00000018A134: CC220043 02003D52
	v_fma_mixlo_f16 v68, v83, s30, 0                           // 00000018A13C: CC210044 02003D53
	v_fma_mixhi_f16 v68, v84, s30, 0                           // 00000018A144: CC220044 02003D54
	s_waitcnt lgkmcnt(6)                                       // 00000018A14C: BF89FC67
	v_fma_mixlo_f16 v71, v89, s30, 0                           // 00000018A150: CC210047 02003D59
	v_fma_mixhi_f16 v71, v90, s30, 0                           // 00000018A158: CC220047 02003D5A
	v_fma_mixlo_f16 v72, v91, s30, 0                           // 00000018A160: CC210048 02003D5B
	v_fma_mixhi_f16 v72, v92, s30, 0                           // 00000018A168: CC220048 02003D5C
	ds_load_b128 v[89:92], v130 offset:25728                   // 00000018A170: DBFC6480 59000082
	s_waitcnt lgkmcnt(6)                                       // 00000018A178: BF89FC67
	v_fma_mixlo_f16 v81, v93, s30, 0                           // 00000018A17C: CC210051 02003D5D
	v_fma_mixhi_f16 v81, v94, s30, 0                           // 00000018A184: CC220051 02003D5E
	v_fma_mixlo_f16 v82, v95, s30, 0                           // 00000018A18C: CC210052 02003D5F
	v_fma_mixhi_f16 v82, v96, s30, 0                           // 00000018A194: CC220052 02003D60
	s_waitcnt lgkmcnt(5)                                       // 00000018A19C: BF89FC57
	v_fma_mixlo_f16 v83, v158, s30, 0                          // 00000018A1A0: CC210053 02003D9E
	v_fma_mixhi_f16 v83, v159, s30, 0                          // 00000018A1A8: CC220053 02003D9F
	v_fma_mixlo_f16 v84, v160, s30, 0                          // 00000018A1B0: CC210054 02003DA0
	ds_load_b128 v[93:96], v130 offset:25760                   // 00000018A1B8: DBFC64A0 5D000082
	v_fma_mixhi_f16 v84, v161, s30, 0                          // 00000018A1C0: CC220054 02003DA1
	ds_load_b128 v[158:161], v130 offset:25776                 // 00000018A1C8: DBFC64B0 9E000082
	v_fma_mixlo_f16 v63, v65, s30, 0                           // 00000018A1D0: CC21003F 02003D41
	v_fma_mixlo_f16 v65, v69, s30, 0                           // 00000018A1D8: CC210041 02003D45
	v_fma_mixlo_f16 v69, v85, s30, 0                           // 00000018A1E0: CC210045 02003D55
	v_fma_mixhi_f16 v69, v86, s30, 0                           // 00000018A1E8: CC220045 02003D56
	s_waitcnt lgkmcnt(6)                                       // 00000018A1F0: BF89FC67
	v_fma_mixlo_f16 v85, v162, s30, 0                          // 00000018A1F4: CC210055 02003DA2
	v_fma_mixhi_f16 v85, v163, s30, 0                          // 00000018A1FC: CC220055 02003DA3
	v_fma_mixlo_f16 v86, v164, s30, 0                          // 00000018A204: CC210056 02003DA4
	v_fma_mixhi_f16 v86, v165, s30, 0                          // 00000018A20C: CC220056 02003DA5
	ds_load_b128 v[162:165], v130 offset:448                   // 00000018A214: DBFC01C0 A2000082
	s_waitcnt lgkmcnt(3)                                       // 00000018A21C: BF89FC37
	v_fma_mixlo_f16 v89, v89, s30, 0                           // 00000018A220: CC210059 02003D59
	v_fma_mixhi_f16 v89, v90, s30, 0                           // 00000018A228: CC220059 02003D5A
	v_fma_mixlo_f16 v90, v91, s30, 0                           // 00000018A230: CC21005A 02003D5B
	v_fma_mixhi_f16 v90, v92, s30, 0                           // 00000018A238: CC22005A 02003D5C
	v_fma_mixlo_f16 v91, v170, s30, 0                          // 00000018A240: CC21005B 02003DAA
	v_fma_mixhi_f16 v91, v171, s30, 0                          // 00000018A248: CC22005B 02003DAB
	v_fma_mixlo_f16 v92, v172, s30, 0                          // 00000018A250: CC21005C 02003DAC
	v_fma_mixhi_f16 v92, v173, s30, 0                          // 00000018A258: CC22005C 02003DAD
	s_waitcnt lgkmcnt(2)                                       // 00000018A260: BF89FC27
	v_fma_mixlo_f16 v93, v93, s30, 0                           // 00000018A264: CC21005D 02003D5D
	v_fma_mixhi_f16 v93, v94, s30, 0                           // 00000018A26C: CC22005D 02003D5E
	v_fma_mixlo_f16 v94, v95, s30, 0                           // 00000018A274: CC21005E 02003D5F
	v_fma_mixhi_f16 v94, v96, s30, 0                           // 00000018A27C: CC22005E 02003D60
	s_waitcnt lgkmcnt(1)                                       // 00000018A284: BF89FC17
	v_fma_mixlo_f16 v95, v158, s30, 0                          // 00000018A288: CC21005F 02003D9E
	ds_load_b128 v[170:173], v130 offset:480                   // 00000018A290: DBFC01E0 AA000082
	v_fma_mixhi_f16 v95, v159, s30, 0                          // 00000018A298: CC22005F 02003D9F
	v_fma_mixlo_f16 v96, v160, s30, 0                          // 00000018A2A0: CC210060 02003DA0
	v_fma_mixhi_f16 v96, v161, s30, 0                          // 00000018A2A8: CC220060 02003DA1
	ds_load_b128 v[158:161], v130 offset:496                   // 00000018A2B0: DBFC01F0 9E000082
	v_fma_mixlo_f16 v59, v174, s30, 0                          // 00000018A2B8: CC21003B 02003DAE
	v_fma_mixhi_f16 v59, v175, s30, 0                          // 00000018A2C0: CC22003B 02003DAF
	v_fma_mixlo_f16 v60, v176, s30, 0                          // 00000018A2C8: CC21003C 02003DB0
	v_fma_mixhi_f16 v60, v177, s30, 0                          // 00000018A2D0: CC22003C 02003DB1
	v_fma_mixlo_f16 v61, v178, s30, 0                          // 00000018A2D8: CC21003D 02003DB2
	v_fma_mixhi_f16 v61, v179, s30, 0                          // 00000018A2E0: CC22003D 02003DB3
	v_fma_mixlo_f16 v62, v180, s30, 0                          // 00000018A2E8: CC21003E 02003DB4
	v_fma_mixhi_f16 v62, v181, s30, 0                          // 00000018A2F0: CC22003E 02003DB5
	v_fma_mixhi_f16 v65, v70, s30, 0                           // 00000018A2F8: CC220041 02003D46
	v_fma_mixlo_f16 v70, v87, s30, 0                           // 00000018A300: CC210046 02003D57
	v_fma_mixhi_f16 v70, v88, s30, 0                           // 00000018A308: CC220046 02003D58
	v_fma_mixlo_f16 v87, v166, s30, 0                          // 00000018A310: CC210057 02003DA6
	v_fma_mixhi_f16 v87, v167, s30, 0                          // 00000018A318: CC220057 02003DA7
	v_fma_mixlo_f16 v88, v168, s30, 0                          // 00000018A320: CC210058 02003DA8
	v_fma_mixhi_f16 v88, v169, s30, 0                          // 00000018A328: CC220058 02003DA9
	ds_load_b128 v[166:169], v130 offset:464                   // 00000018A330: DBFC01D0 A6000082
	s_waitcnt vmcnt(8)                                         // 00000018A338: BF8923F7
	v_wmma_f32_16x16x16_f16 v[33:40], v[49:56], v[57:64], v[33:40]// 00000018A33C: CC404021 1C867331
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[65:72], v[17:24]// 00000018A344: CC404011 1C468331
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[89:96], v[9:16]// 00000018A34C: CC404009 1C26B331
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[81:88], v[25:32]// 00000018A354: CC404019 1C66A331
	ds_load_b128 v[57:60], v130 offset:8896                    // 00000018A35C: DBFC22C0 39000082
	ds_load_b128 v[61:64], v130 offset:8912                    // 00000018A364: DBFC22D0 3D000082
	s_waitcnt lgkmcnt(5)                                       // 00000018A36C: BF89FC57
	v_fma_mixlo_f16 v49, v162, s30, 0                          // 00000018A370: CC210031 02003DA2
	v_fma_mixhi_f16 v49, v163, s30, 0                          // 00000018A378: CC220031 02003DA3
	v_fma_mixlo_f16 v50, v164, s30, 0                          // 00000018A380: CC210032 02003DA4
	v_fma_mixhi_f16 v50, v165, s30, 0                          // 00000018A388: CC220032 02003DA5
	ds_load_b128 v[65:68], v130 offset:8928                    // 00000018A390: DBFC22E0 41000082
	ds_load_b128 v[69:72], v130 offset:8944                    // 00000018A398: DBFC22F0 45000082
	s_waitcnt lgkmcnt(5)                                       // 00000018A3A0: BF89FC57
	v_fma_mixlo_f16 v55, v158, s30, 0                          // 00000018A3A4: CC210037 02003D9E
	v_fma_mixhi_f16 v55, v159, s30, 0                          // 00000018A3AC: CC220037 02003D9F
	v_fma_mixlo_f16 v56, v160, s30, 0                          // 00000018A3B4: CC210038 02003DA0
	v_fma_mixhi_f16 v56, v161, s30, 0                          // 00000018A3BC: CC220038 02003DA1
	ds_load_b128 v[81:84], v130 offset:17344                   // 00000018A3C4: DBFC43C0 51000082
	ds_load_b128 v[85:88], v130 offset:17360                   // 00000018A3CC: DBFC43D0 55000082
	ds_load_b128 v[89:92], v130 offset:17376                   // 00000018A3D4: DBFC43E0 59000082
	ds_load_b128 v[93:96], v130 offset:17392                   // 00000018A3DC: DBFC43F0 5D000082
	ds_load_b128 v[158:161], v130 offset:25792                 // 00000018A3E4: DBFC64C0 9E000082
	ds_load_b128 v[162:165], v130 offset:25808                 // 00000018A3EC: DBFC64D0 A2000082
	ds_load_b128 v[181:184], v130 offset:25824                 // 00000018A3F4: DBFC64E0 B5000082
	s_waitcnt lgkmcnt(11)                                      // 00000018A3FC: BF89FCB7
	v_fma_mixlo_f16 v51, v166, s30, 0                          // 00000018A400: CC210033 02003DA6
	v_fma_mixhi_f16 v51, v167, s30, 0                          // 00000018A408: CC220033 02003DA7
	v_fma_mixlo_f16 v52, v168, s30, 0                          // 00000018A410: CC210034 02003DA8
	v_fma_mixhi_f16 v52, v169, s30, 0                          // 00000018A418: CC220034 02003DA9
	v_fma_mixlo_f16 v53, v170, s30, 0                          // 00000018A420: CC210035 02003DAA
	v_fma_mixhi_f16 v53, v171, s30, 0                          // 00000018A428: CC220035 02003DAB
	v_fma_mixlo_f16 v54, v172, s30, 0                          // 00000018A430: CC210036 02003DAC
	v_fma_mixhi_f16 v54, v173, s30, 0                          // 00000018A438: CC220036 02003DAD
	s_waitcnt lgkmcnt(10)                                      // 00000018A440: BF89FCA7
	v_fma_mixlo_f16 v57, v57, s30, 0                           // 00000018A444: CC210039 02003D39
	v_fma_mixhi_f16 v57, v58, s30, 0                           // 00000018A44C: CC220039 02003D3A
	v_fma_mixlo_f16 v58, v59, s30, 0                           // 00000018A454: CC21003A 02003D3B
	v_fma_mixhi_f16 v58, v60, s30, 0                           // 00000018A45C: CC22003A 02003D3C
	s_waitcnt lgkmcnt(9)                                       // 00000018A464: BF89FC97
	v_fma_mixlo_f16 v59, v61, s30, 0                           // 00000018A468: CC21003B 02003D3D
	v_fma_mixhi_f16 v59, v62, s30, 0                           // 00000018A470: CC22003B 02003D3E
	v_fma_mixlo_f16 v60, v63, s30, 0                           // 00000018A478: CC21003C 02003D3F
	v_fma_mixhi_f16 v60, v64, s30, 0                           // 00000018A480: CC22003C 02003D40
	s_waitcnt lgkmcnt(8)                                       // 00000018A488: BF89FC87
	v_fma_mixlo_f16 v61, v65, s30, 0                           // 00000018A48C: CC21003D 02003D41
	v_fma_mixhi_f16 v61, v66, s30, 0                           // 00000018A494: CC22003D 02003D42
	v_fma_mixlo_f16 v62, v67, s30, 0                           // 00000018A49C: CC21003E 02003D43
	s_waitcnt lgkmcnt(7)                                       // 00000018A4A4: BF89FC77
	v_fma_mixlo_f16 v63, v69, s30, 0                           // 00000018A4A8: CC21003F 02003D45
	v_fma_mixhi_f16 v63, v70, s30, 0                           // 00000018A4B0: CC22003F 02003D46
	v_fma_mixlo_f16 v64, v71, s30, 0                           // 00000018A4B8: CC210040 02003D47
	v_fma_mixhi_f16 v64, v72, s30, 0                           // 00000018A4C0: CC220040 02003D48
	s_waitcnt lgkmcnt(6)                                       // 00000018A4C8: BF89FC67
	v_fma_mixlo_f16 v65, v81, s30, 0                           // 00000018A4CC: CC210041 02003D51
	v_fma_mixhi_f16 v65, v82, s30, 0                           // 00000018A4D4: CC220041 02003D52
	v_fma_mixlo_f16 v66, v83, s30, 0                           // 00000018A4DC: CC210042 02003D53
	v_fma_mixhi_f16 v66, v84, s30, 0                           // 00000018A4E4: CC220042 02003D54
	s_waitcnt lgkmcnt(5)                                       // 00000018A4EC: BF89FC57
	v_fma_mixlo_f16 v67, v85, s30, 0                           // 00000018A4F0: CC210043 02003D55
	s_waitcnt lgkmcnt(4)                                       // 00000018A4F8: BF89FC47
	v_fma_mixlo_f16 v69, v89, s30, 0                           // 00000018A4FC: CC210045 02003D59
	v_fma_mixhi_f16 v69, v90, s30, 0                           // 00000018A504: CC220045 02003D5A
	v_fma_mixlo_f16 v70, v91, s30, 0                           // 00000018A50C: CC210046 02003D5B
	v_fma_mixhi_f16 v70, v92, s30, 0                           // 00000018A514: CC220046 02003D5C
	s_waitcnt lgkmcnt(3)                                       // 00000018A51C: BF89FC37
	v_fma_mixlo_f16 v71, v93, s30, 0                           // 00000018A520: CC210047 02003D5D
	v_fma_mixhi_f16 v71, v94, s30, 0                           // 00000018A528: CC220047 02003D5E
	v_fma_mixlo_f16 v72, v95, s30, 0                           // 00000018A530: CC210048 02003D5F
	v_fma_mixhi_f16 v72, v96, s30, 0                           // 00000018A538: CC220048 02003D60
	s_waitcnt lgkmcnt(2)                                       // 00000018A540: BF89FC27
	v_fma_mixlo_f16 v81, v158, s30, 0                          // 00000018A544: CC210051 02003D9E
	v_fma_mixhi_f16 v81, v159, s30, 0                          // 00000018A54C: CC220051 02003D9F
	v_fma_mixlo_f16 v82, v160, s30, 0                          // 00000018A554: CC210052 02003DA0
	v_fma_mixhi_f16 v82, v161, s30, 0                          // 00000018A55C: CC220052 02003DA1
	s_waitcnt lgkmcnt(1)                                       // 00000018A564: BF89FC17
	v_fma_mixlo_f16 v83, v162, s30, 0                          // 00000018A568: CC210053 02003DA2
	v_fma_mixhi_f16 v83, v163, s30, 0                          // 00000018A570: CC220053 02003DA3
	v_fma_mixlo_f16 v84, v164, s30, 0                          // 00000018A578: CC210054 02003DA4
	v_fma_mixhi_f16 v84, v165, s30, 0                          // 00000018A580: CC220054 02003DA5
	s_waitcnt lgkmcnt(0)                                       // 00000018A588: BF89FC07
	v_fma_mixlo_f16 v85, v181, s30, 0                          // 00000018A58C: CC210055 02003DB5
	ds_load_b128 v[89:92], v131                                // 00000018A594: DBFC0000 59000083
	ds_load_b128 v[93:96], v131 offset:16                      // 00000018A59C: DBFC0010 5D000083
	ds_load_b128 v[162:165], v131 offset:2320                  // 00000018A5A4: DBFC0910 A2000083
	ds_load_b128 v[158:161], v131 offset:2304                  // 00000018A5AC: DBFC0900 9E000083
	ds_load_b128 v[170:173], v131 offset:4624                  // 00000018A5B4: DBFC1210 AA000083
	ds_load_b128 v[166:169], v131 offset:4608                  // 00000018A5BC: DBFC1200 A6000083
	ds_load_b128 v[178:181], v131 offset:6928                  // 00000018A5C4: DBFC1B10 B2000083
	ds_load_b128 v[174:177], v131 offset:6912                  // 00000018A5CC: DBFC1B00 AE000083
	v_fma_mixhi_f16 v62, v68, s30, 0                           // 00000018A5D4: CC22003E 02003D44
	v_fma_mixhi_f16 v67, v86, s30, 0                           // 00000018A5DC: CC220043 02003D56
	v_fma_mixlo_f16 v68, v87, s30, 0                           // 00000018A5E4: CC210044 02003D57
	v_fma_mixhi_f16 v68, v88, s30, 0                           // 00000018A5EC: CC220044 02003D58
	v_fma_mixhi_f16 v85, v182, s30, 0                          // 00000018A5F4: CC220055 02003DB6
	v_fma_mixlo_f16 v86, v183, s30, 0                          // 00000018A5FC: CC210056 02003DB7
	v_fma_mixhi_f16 v86, v184, s30, 0                          // 00000018A604: CC220056 02003DB8
	v_fma_mixlo_f16 v87, v185, s30, 0                          // 00000018A60C: CC210057 02003DB9
	v_fma_mixhi_f16 v87, v186, s30, 0                          // 00000018A614: CC220057 02003DBA
	v_fma_mixlo_f16 v88, v187, s30, 0                          // 00000018A61C: CC210058 02003DBB
	v_fma_mixhi_f16 v88, v188, s30, 0                          // 00000018A624: CC220058 02003DBC
	s_waitcnt vmcnt(6)                                         // 00000018A62C: BF891BF7
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[49:56], v[33:40]// 00000018A630: CC404021 1C866329
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[57:64], v[17:24]// 00000018A638: CC404011 1C467329
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[65:72], v[25:32]// 00000018A640: CC404019 1C668329
	s_waitcnt vmcnt(4) lgkmcnt(6)                              // 00000018A648: BF891067
	v_wmma_f32_16x16x16_f16 v[65:72], v[150:157], v[89:96], v[73:80]// 00000018A64C: CC404041 1D26B396
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[81:88], v[9:16]// 00000018A654: CC404009 1C26A329
	s_waitcnt lgkmcnt(4)                                       // 00000018A65C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[57:64], v[150:157], v[158:165], v[73:80]// 00000018A660: CC404039 1D273D96
	s_waitcnt lgkmcnt(2)                                       // 00000018A668: BF89FC27
	v_wmma_f32_16x16x16_f16 v[49:56], v[150:157], v[166:173], v[73:80]// 00000018A66C: CC404031 1D274D96
	s_waitcnt lgkmcnt(0)                                       // 00000018A674: BF89FC07
	v_wmma_f32_16x16x16_f16 v[41:48], v[150:157], v[174:181], v[73:80]// 00000018A678: CC404029 1D275D96
	s_and_saveexec_b32 s14, s6                                 // 00000018A680: BE8E2006
	s_cbranch_execnz 883                                       // 00000018A684: BFA60373 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4b54>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018A688: 8C7E0E7E
	s_and_saveexec_b32 s14, s5                                 // 00000018A68C: BE8E2005
	s_cbranch_execnz 916                                       // 00000018A690: BFA60394 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4be4>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018A694: 8C7E0E7E
	s_and_saveexec_b32 s14, s7                                 // 00000018A698: BE8E2007
	s_cbranch_execz 30                                         // 00000018A69C: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3e18>
	ds_load_b128 v[73:76], v131 offset:96                      // 00000018A6A0: DBFC0060 49000083
	ds_load_b128 v[77:80], v131 offset:112                     // 00000018A6A8: DBFC0070 4D000083
	ds_load_b128 v[85:88], v131 offset:2416                    // 00000018A6B0: DBFC0970 55000083
	ds_load_b128 v[81:84], v131 offset:2400                    // 00000018A6B8: DBFC0960 51000083
	ds_load_b128 v[93:96], v131 offset:4720                    // 00000018A6C0: DBFC1270 5D000083
	ds_load_b128 v[89:92], v131 offset:4704                    // 00000018A6C8: DBFC1260 59000083
	s_waitcnt vmcnt(3)                                         // 00000018A6D0: BF890FF7
	ds_load_b128 v[109:112], v131 offset:7024                  // 00000018A6D4: DBFC1B70 6D000083
	s_waitcnt vmcnt(2)                                         // 00000018A6DC: BF890BF7
	ds_load_b128 v[105:108], v131 offset:7008                  // 00000018A6E0: DBFC1B60 69000083
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 00000018A6E8: BF890067
	v_wmma_f32_16x16x16_f16 v[65:72], v[97:104], v[73:80], v[65:72]// 00000018A6EC: CC404041 1D069361
	s_waitcnt lgkmcnt(4)                                       // 00000018A6F4: BF89FC47
	v_wmma_f32_16x16x16_f16 v[57:64], v[97:104], v[81:88], v[57:64]// 00000018A6F8: CC404039 1CE6A361
	s_waitcnt lgkmcnt(2)                                       // 00000018A700: BF89FC27
	v_wmma_f32_16x16x16_f16 v[49:56], v[97:104], v[89:96], v[49:56]// 00000018A704: CC404031 1CC6B361
	s_waitcnt lgkmcnt(0)                                       // 00000018A70C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[41:48], v[97:104], v[105:112], v[41:48]// 00000018A710: CC404029 1CA6D361
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018A718: 8C7E0E7E
	s_add_i32 s40, s40, 64                                     // 00000018A71C: 8128C028
	s_mov_b32 s14, -1                                          // 00000018A720: BE8E00C1
	s_cmp_le_i32 s40, s50                                      // 00000018A724: BF053228
	s_cbranch_scc0 392                                         // 00000018A728: BFA10188 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x444c>
	ds_load_2addr_b32 v[73:74], v141 offset1:2                 // 00000018A72C: D8DC0200 4900008D
	ds_load_2addr_b32 v[75:76], v141 offset0:4 offset1:6       // 00000018A734: D8DC0604 4B00008D
	ds_load_2addr_b32 v[77:78], v141 offset0:8 offset1:10      // 00000018A73C: D8DC0A08 4D00008D
	ds_load_2addr_b32 v[79:80], v141 offset0:12 offset1:14     // 00000018A744: D8DC0E0C 4F00008D
	v_mad_u64_u32 v[81:82], null, 0x3000, v142, v[116:117]     // 00000018A74C: D6FE7C51 05D31CFF 00003000
	v_mad_u64_u32 v[83:84], null, 0x3000, v149, v[116:117]     // 00000018A758: D6FE7C53 05D32AFF 00003000
	v_mad_u64_u32 v[85:86], null, 0x3000, v148, v[116:117]     // 00000018A764: D6FE7C55 05D328FF 00003000
	v_mad_u64_u32 v[87:88], null, 0x3000, v147, v[116:117]     // 00000018A770: D6FE7C57 05D326FF 00003000
	s_mov_b32 s14, 0                                           // 00000018A77C: BE8E0080
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 00000018A780: BF890437
	v_fma_f32 v104, v17, v73, v57                              // 00000018A784: D6130068 04E69311
	v_fma_f32 v105, v18, v74, v58                              // 00000018A78C: D6130069 04EA9512
	s_waitcnt lgkmcnt(2)                                       // 00000018A794: BF89FC27
	v_fma_f32 v106, v19, v75, v59                              // 00000018A798: D613006A 04EE9713
	v_fma_f32 v108, v20, v76, v60                              // 00000018A7A0: D613006C 04F29914
	s_waitcnt lgkmcnt(1)                                       // 00000018A7A8: BF89FC17
	v_fma_f32 v112, v21, v77, v61                              // 00000018A7AC: D6130070 04F69B15
	v_dual_mul_f32 v104, 0x3b800000, v104 :: v_dual_mul_f32 v105, 0x3b800000, v105// 00000018A7B4: C8C6D0FF 6868D2FF 3B800000
	v_mul_f32_e32 v106, 0x3b800000, v106                       // 00000018A7C0: 10D4D4FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 00000018A7C8: BF89FC07
	v_fma_f32 v113, v24, v80, v64                              // 00000018A7CC: D6130071 0502A118
	v_mul_f32_e32 v108, 0x3b800000, v108                       // 00000018A7D4: 10D8D8FF 3B800000
	v_bfe_u32 v109, v104, 16, 1                                // 00000018A7DC: D610006D 02052168
	v_bfe_u32 v110, v105, 16, 1                                // 00000018A7E4: D610006E 02052169
	v_bfe_u32 v111, v106, 16, 1                                // 00000018A7EC: D610006F 0205216A
	v_mul_f32_e32 v113, 0x3b800000, v113                       // 00000018A7F4: 10E2E2FF 3B800000
	v_fma_f32 v151, v26, v74, v50                              // 00000018A7FC: D6130097 04CA951A
	v_add3_u32 v104, v104, v109, 0x7fff                        // 00000018A804: D6550068 03FEDB68 00007FFF
	v_add3_u32 v105, v105, v110, 0x7fff                        // 00000018A810: D6550069 03FEDD69 00007FFF
	v_add3_u32 v106, v106, v111, 0x7fff                        // 00000018A81C: D655006A 03FEDF6A 00007FFF
	v_bfe_u32 v109, v108, 16, 1                                // 00000018A828: D610006D 0205216C
	v_mul_f32_e32 v110, 0x3b800000, v112                       // 00000018A830: 10DCE0FF 3B800000
	v_fma_f32 v111, v22, v78, v62                              // 00000018A838: D613006F 04FA9D16
	v_fma_f32 v112, v23, v79, v63                              // 00000018A840: D6130070 04FE9F17
	v_fma_f32 v124, v25, v73, v49                              // 00000018A848: D613007C 04C69319
	v_add3_u32 v108, v108, v109, 0x7fff                        // 00000018A850: D655006C 03FEDB6C 00007FFF
	v_bfe_u32 v109, v110, 16, 1                                // 00000018A85C: D610006D 0205216E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000018A864: BF870234
	v_dual_mul_f32 v111, 0x3b800000, v111 :: v_dual_mul_f32 v112, 0x3b800000, v112// 00000018A868: C8C6DEFF 6F70E0FF 3B800000
	v_bfe_u32 v150, v113, 16, 1                                // 00000018A874: D6100096 02052171
	v_fma_f32 v153, v30, v78, v54                              // 00000018A87C: D6130099 04DA9D1E
	v_add3_u32 v109, v110, v109, 0x7fff                        // 00000018A884: D655006D 03FEDB6E 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000018A890: BF870224
	v_bfe_u32 v110, v111, 16, 1                                // 00000018A894: D610006E 0205216F
	v_bfe_u32 v125, v112, 16, 1                                // 00000018A89C: D610007D 02052170
	v_dual_mul_f32 v124, 0x3b800000, v124 :: v_dual_mul_f32 v153, 0x3b800000, v153// 00000018A8A4: C8C6F8FF 7C9932FF 3B800000
	v_fma_f32 v152, v29, v77, v53                              // 00000018A8B0: D6130098 04D69B1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000018A8B8: BF870214
	v_add3_u32 v110, v111, v110, 0x7fff                        // 00000018A8BC: D655006E 03FEDD6F 00007FFF
	v_add3_u32 v111, v112, v125, 0x7fff                        // 00000018A8C8: D655006F 03FEFB70 00007FFF
	v_add3_u32 v112, v113, v150, 0x7fff                        // 00000018A8D4: D6550070 03FF2D71 00007FFF
	v_bfe_u32 v113, v124, 16, 1                                // 00000018A8E0: D6100071 0205217C
	v_mul_f32_e32 v125, 0x3b800000, v151                       // 00000018A8E8: 10FB2EFF 3B800000
	v_fma_f32 v150, v27, v75, v51                              // 00000018A8F0: D6130096 04CE971B
	v_fma_f32 v151, v28, v76, v52                              // 00000018A8F8: D6130097 04D2991C
	v_fma_f32 v89, v33, v73, v65                               // 00000018A900: D6130059 05069321
	v_add3_u32 v113, v124, v113, 0x7fff                        // 00000018A908: D6550071 03FEE37C 00007FFF
	v_bfe_u32 v124, v125, 16, 1                                // 00000018A914: D610007C 0205217D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000018A91C: BF870234
	v_dual_mul_f32 v150, 0x3b800000, v150 :: v_dual_mul_f32 v151, 0x3b800000, v151// 00000018A920: C8C72CFF 96972EFF 3B800000
	v_fma_f32 v73, v9, v73, v41                                // 00000018A92C: D6130049 04A69309
	v_mul_f32_e32 v152, 0x3b800000, v152                       // 00000018A934: 113130FF 3B800000
	v_add3_u32 v124, v125, v124, 0x7fff                        // 00000018A93C: D655007C 03FEF97D 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000018A948: BF870004
	v_bfe_u32 v125, v150, 16, 1                                // 00000018A94C: D610007D 02052196
	v_bfe_u32 v154, v151, 16, 1                                // 00000018A954: D610009A 02052197
	v_fma_f32 v156, v31, v79, v55                              // 00000018A95C: D613009C 04DE9F1F
	v_mul_f32_e32 v73, 0x3b800000, v73                         // 00000018A964: 109292FF 3B800000
	v_bfe_u32 v155, v152, 16, 1                                // 00000018A96C: D610009B 02052198
	v_fma_f32 v91, v35, v75, v67                               // 00000018A974: D613005B 050E9723
	v_add3_u32 v125, v150, v125, 0x7fff                        // 00000018A97C: D655007D 03FEFB96 00007FFF
	v_add3_u32 v150, v151, v154, 0x7fff                        // 00000018A988: D6550096 03FF3597 00007FFF
	v_fma_f32 v75, v11, v75, v43                               // 00000018A994: D613004B 04AE970B
	v_add3_u32 v151, v152, v155, 0x7fff                        // 00000018A99C: D6550097 03FF3798 00007FFF
	v_bfe_u32 v152, v153, 16, 1                                // 00000018A9A8: D6100098 02052199
	v_mul_f32_e32 v154, 0x3b800000, v156                       // 00000018A9B0: 113538FF 3B800000
	v_fma_f32 v155, v32, v80, v56                              // 00000018A9B8: D613009B 04E2A120
	v_fma_f32 v90, v34, v74, v66                               // 00000018A9C0: D613005A 050A9522
	v_fma_f32 v74, v10, v74, v42                               // 00000018A9C8: D613004A 04AA950A
	v_mul_f32_e32 v89, 0x3b800000, v89                         // 00000018A9D0: 10B2B2FF 3B800000
	v_add3_u32 v152, v153, v152, 0x7fff                        // 00000018A9D8: D6550098 03FF3199 00007FFF
	v_mul_f32_e32 v155, 0x3b800000, v155                       // 00000018A9E4: 113736FF 3B800000
	v_mul_f32_e32 v75, 0x3b800000, v75                         // 00000018A9EC: 109696FF 3B800000
	v_bfe_u32 v153, v154, 16, 1                                // 00000018A9F4: D6100099 0205219A
	v_mul_f32_e32 v90, 0x3b800000, v90                         // 00000018A9FC: 10B4B4FF 3B800000
	v_fma_f32 v93, v37, v77, v69                               // 00000018AA04: D613005D 05169B25
	v_fma_f32 v77, v13, v77, v45                               // 00000018AA0C: D613004D 04B69B0D
	v_mul_f32_e32 v74, 0x3b800000, v74                         // 00000018AA14: 109494FF 3B800000
	v_fma_f32 v92, v36, v76, v68                               // 00000018AA1C: D613005C 05129924
	v_fma_f32 v95, v39, v79, v71                               // 00000018AA24: D613005F 051E9F27
	s_waitcnt vmcnt(0)                                         // 00000018AA2C: BF8903F7
	v_bfe_u32 v97, v89, 16, 1                                  // 00000018AA30: D6100061 02052159
	v_add3_u32 v153, v154, v153, 0x7fff                        // 00000018AA38: D6550099 03FF339A 00007FFF
	v_bfe_u32 v154, v155, 16, 1                                // 00000018AA44: D610009A 0205219B
	v_fma_f32 v76, v12, v76, v44                               // 00000018AA4C: D613004C 04B2990C
	v_fma_f32 v94, v38, v78, v70                               // 00000018AA54: D613005E 051A9D26
	v_bfe_u32 v98, v90, 16, 1                                  // 00000018AA5C: D6100062 0205215A
	v_bfe_u32 v156, v73, 16, 1                                 // 00000018AA64: D610009C 02052149
	v_bfe_u32 v157, v74, 16, 1                                 // 00000018AA6C: D610009D 0205214A
	v_fma_f32 v96, v40, v80, v72                               // 00000018AA74: D6130060 0522A128
	v_dual_mul_f32 v91, 0x3b800000, v91 :: v_dual_mul_f32 v92, 0x3b800000, v92// 00000018AA7C: C8C6B6FF 5B5CB8FF 3B800000
	v_mul_f32_e32 v95, 0x3b800000, v95                         // 00000018AA88: 10BEBEFF 3B800000
	v_add3_u32 v97, v89, v97, 0x7fff                           // 00000018AA90: D6550061 03FEC359 00007FFF
	v_add3_u32 v154, v155, v154, 0x7fff                        // 00000018AA9C: D655009A 03FF359B 00007FFF
	v_bfe_u32 v155, v75, 16, 1                                 // 00000018AAA8: D610009B 0205214B
	v_fma_f32 v78, v14, v78, v46                               // 00000018AAB0: D613004E 04BA9D0E
	v_dual_mul_f32 v76, 0x3b800000, v76 :: v_dual_mul_f32 v93, 0x3b800000, v93// 00000018AAB8: C8C698FF 4C5CBAFF 3B800000
	v_mul_f32_e32 v94, 0x3b800000, v94                         // 00000018AAC4: 10BCBCFF 3B800000
	v_add3_u32 v98, v90, v98, 0x7fff                           // 00000018AACC: D6550062 03FEC55A 00007FFF
	v_add3_u32 v73, v73, v156, 0x7fff                          // 00000018AAD8: D6550049 03FF3949 00007FFF
	v_add3_u32 v74, v74, v157, 0x7fff                          // 00000018AAE4: D655004A 03FF3B4A 00007FFF
	v_mul_f32_e32 v96, 0x3b800000, v96                         // 00000018AAF0: 10C0C0FF 3B800000
	v_bfe_u32 v99, v91, 16, 1                                  // 00000018AAF8: D6100063 0205215B
	v_bfe_u32 v103, v95, 16, 1                                 // 00000018AB00: D6100067 0205215F
	s_clause 0x7                                               // 00000018AB08: BF850007
	global_store_d16_hi_b16 v[81:82], v97, off                 // 00000018AB0C: DC960000 007C6151
	global_store_d16_hi_b16 v[81:82], v104, off offset:32      // 00000018AB14: DC960020 007C6851
	global_store_d16_hi_b16 v[81:82], v113, off offset:64      // 00000018AB1C: DC960040 007C7151
	global_store_d16_hi_b16 v[83:84], v98, off                 // 00000018AB24: DC960000 007C6253
	global_store_d16_hi_b16 v[83:84], v105, off offset:32      // 00000018AB2C: DC960020 007C6953
	global_store_d16_hi_b16 v[83:84], v124, off offset:64      // 00000018AB34: DC960040 007C7C53
	global_store_d16_hi_b16 v[81:82], v73, off offset:96       // 00000018AB3C: DC960060 007C4951
	global_store_d16_hi_b16 v[83:84], v74, off offset:96       // 00000018AB44: DC960060 007C4A53
	v_add3_u32 v73, v75, v155, 0x7fff                          // 00000018AB4C: D6550049 03FF374B 00007FFF
	v_mul_f32_e32 v75, 0x3b800000, v77                         // 00000018AB58: 10969AFF 3B800000
	v_mul_f32_e32 v77, 0x3b800000, v78                         // 00000018AB60: 109A9CFF 3B800000
	v_bfe_u32 v74, v76, 16, 1                                  // 00000018AB68: D610004A 0205214C
	v_fma_f32 v78, v15, v79, v47                               // 00000018AB70: D613004E 04BE9F0F
	v_fma_f32 v79, v16, v80, v48                               // 00000018AB78: D613004F 04C2A110
	v_bfe_u32 v101, v93, 16, 1                                 // 00000018AB80: D6100065 0205215D
	v_bfe_u32 v102, v94, 16, 1                                 // 00000018AB88: D6100066 0205215E
	v_bfe_u32 v100, v92, 16, 1                                 // 00000018AB90: D6100064 0205215C
	v_add3_u32 v99, v91, v99, 0x7fff                           // 00000018AB98: D6550063 03FEC75B 00007FFF
	v_add3_u32 v103, v95, v103, 0x7fff                         // 00000018ABA4: D6550067 03FECF5F 00007FFF
	v_bfe_u32 v95, v96, 16, 1                                  // 00000018ABB0: D610005F 02052160
	v_add3_u32 v74, v76, v74, 0x7fff                           // 00000018ABB8: D655004A 03FE954C 00007FFF
	v_bfe_u32 v76, v75, 16, 1                                  // 00000018ABC4: D610004C 0205214B
	v_dual_mul_f32 v78, 0x3b800000, v78 :: v_dual_mul_f32 v79, 0x3b800000, v79// 00000018ABCC: C8C69CFF 4E4E9EFF 3B800000
	v_add3_u32 v101, v93, v101, 0x7fff                         // 00000018ABD8: D6550065 03FECB5D 00007FFF
	v_mad_u64_u32 v[89:90], null, 0x3000, v146, v[116:117]     // 00000018ABE4: D6FE7C59 05D324FF 00003000
	v_add3_u32 v102, v94, v102, 0x7fff                         // 00000018ABF0: D6550066 03FECD5E 00007FFF
	v_mad_u64_u32 v[93:94], null, 0x3000, v144, v[116:117]     // 00000018ABFC: D6FE7C5D 05D320FF 00003000
	v_add3_u32 v100, v92, v100, 0x7fff                         // 00000018AC08: D6550064 03FEC95C 00007FFF
	v_bfe_u32 v80, v77, 16, 1                                  // 00000018AC14: D6100050 0205214D
	v_mad_u64_u32 v[91:92], null, 0x3000, v145, v[116:117]     // 00000018AC1C: D6FE7C5B 05D322FF 00003000
	v_add3_u32 v107, v96, v95, 0x7fff                          // 00000018AC28: D655006B 03FEBF60 00007FFF
	v_mad_u64_u32 v[95:96], null, 0x3000, v143, v[116:117]     // 00000018AC34: D6FE7C5F 05D31EFF 00003000
	s_clause 0x7                                               // 00000018AC40: BF850007
	global_store_d16_hi_b16 v[85:86], v99, off                 // 00000018AC44: DC960000 007C6355
	global_store_d16_hi_b16 v[85:86], v106, off offset:32      // 00000018AC4C: DC960020 007C6A55
	global_store_d16_hi_b16 v[85:86], v125, off offset:64      // 00000018AC54: DC960040 007C7D55
	global_store_d16_hi_b16 v[87:88], v100, off                // 00000018AC5C: DC960000 007C6457
	global_store_d16_hi_b16 v[87:88], v108, off offset:32      // 00000018AC64: DC960020 007C6C57
	global_store_d16_hi_b16 v[87:88], v150, off offset:64      // 00000018AC6C: DC960040 007C9657
	global_store_d16_hi_b16 v[85:86], v73, off offset:96       // 00000018AC74: DC960060 007C4955
	global_store_d16_hi_b16 v[87:88], v74, off offset:96       // 00000018AC7C: DC960060 007C4A57
	v_add3_u32 v73, v75, v76, 0x7fff                           // 00000018AC84: D6550049 03FE994B 00007FFF
	v_bfe_u32 v75, v78, 16, 1                                  // 00000018AC90: D610004B 0205214E
	v_bfe_u32 v76, v79, 16, 1                                  // 00000018AC98: D610004C 0205214F
	v_add3_u32 v74, v77, v80, 0x7fff                           // 00000018ACA0: D655004A 03FEA14D 00007FFF
	s_clause 0x7                                               // 00000018ACAC: BF850007
	global_store_d16_hi_b16 v[89:90], v101, off                // 00000018ACB0: DC960000 007C6559
	global_store_d16_hi_b16 v[89:90], v109, off offset:32      // 00000018ACB8: DC960020 007C6D59
	global_store_d16_hi_b16 v[89:90], v151, off offset:64      // 00000018ACC0: DC960040 007C9759
	global_store_d16_hi_b16 v[91:92], v102, off                // 00000018ACC8: DC960000 007C665B
	global_store_d16_hi_b16 v[91:92], v110, off offset:32      // 00000018ACD0: DC960020 007C6E5B
	global_store_d16_hi_b16 v[91:92], v152, off offset:64      // 00000018ACD8: DC960040 007C985B
	global_store_d16_hi_b16 v[89:90], v73, off offset:96       // 00000018ACE0: DC960060 007C4959
	global_store_d16_hi_b16 v[91:92], v74, off offset:96       // 00000018ACE8: DC960060 007C4A5B
	v_add3_u32 v73, v78, v75, 0x7fff                           // 00000018ACF0: D6550049 03FE974E 00007FFF
	v_add3_u32 v74, v79, v76, 0x7fff                           // 00000018ACFC: D655004A 03FE994F 00007FFF
	s_clause 0x7                                               // 00000018AD08: BF850007
	global_store_d16_hi_b16 v[93:94], v103, off                // 00000018AD0C: DC960000 007C675D
	global_store_d16_hi_b16 v[93:94], v111, off offset:32      // 00000018AD14: DC960020 007C6F5D
	global_store_d16_hi_b16 v[93:94], v153, off offset:64      // 00000018AD1C: DC960040 007C995D
	global_store_d16_hi_b16 v[95:96], v107, off                // 00000018AD24: DC960000 007C6B5F
	global_store_d16_hi_b16 v[95:96], v112, off offset:32      // 00000018AD2C: DC960020 007C705F
	global_store_d16_hi_b16 v[95:96], v154, off offset:64      // 00000018AD34: DC960040 007C9A5F
	global_store_d16_hi_b16 v[93:94], v73, off offset:96       // 00000018AD3C: DC960060 007C495D
	global_store_d16_hi_b16 v[95:96], v74, off offset:96       // 00000018AD44: DC960060 007C4A5F
	s_and_not1_b32 vcc_lo, exec_lo, s14                        // 00000018AD4C: 916A0E7E
	s_cbranch_vccnz 114                                        // 00000018AD50: BFA40072 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x461c>
	s_and_saveexec_b32 s14, s10                                // 00000018AD54: BE8E200A
	s_cbranch_execnz 606                                       // 00000018AD58: BFA6025E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4dd4>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AD5C: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 00000018AD60: BE8E200D
	s_cbranch_execnz 625                                       // 00000018AD64: BFA60271 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4e2c>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AD68: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 00000018AD6C: BE8E200C
	s_cbranch_execnz 644                                       // 00000018AD70: BFA60284 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4e84>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AD74: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 00000018AD78: BE8E200B
	s_cbranch_execnz 663                                       // 00000018AD7C: BFA60297 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4edc>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AD80: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 00000018AD84: BE8E2009
	s_cbranch_execnz 682                                       // 00000018AD88: BFA602AA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4f34>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AD8C: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 00000018AD90: BE8E2001
	s_cbranch_execnz 701                                       // 00000018AD94: BFA602BD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4f8c>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AD98: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 00000018AD9C: BE8E2008
	s_cbranch_execnz 720                                       // 00000018ADA0: BFA602D0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4fe4>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018ADA4: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 00000018ADA8: BE8E2000
	s_cbranch_execnz 739                                       // 00000018ADAC: BFA602E3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x503c>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018ADB0: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 00000018ADB4: BE8E200A
	s_cbranch_execnz 758                                       // 00000018ADB8: BFA602F6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5094>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018ADBC: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 00000018ADC0: BE8E200D
	s_cbranch_execnz 777                                       // 00000018ADC4: BFA60309 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x50ec>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018ADC8: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 00000018ADCC: BE8E200C
	s_cbranch_execnz 796                                       // 00000018ADD0: BFA6031C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5144>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018ADD4: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 00000018ADD8: BE8E200B
	s_cbranch_execnz 815                                       // 00000018ADDC: BFA6032F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x519c>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018ADE0: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 00000018ADE4: BE8E2009
	s_cbranch_execnz 834                                       // 00000018ADE8: BFA60342 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x51f4>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018ADEC: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 00000018ADF0: BE8E2001
	s_cbranch_execnz 853                                       // 00000018ADF4: BFA60355 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x524c>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018ADF8: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 00000018ADFC: BE8E2008
	s_cbranch_execnz 872                                       // 00000018AE00: BFA60368 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x52a4>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AE04: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 00000018AE08: BE8E2000
	s_cbranch_execnz 891                                       // 00000018AE0C: BFA6037B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x52fc>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AE10: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 00000018AE14: BE8E200A
	s_cbranch_execnz 910                                       // 00000018AE18: BFA6038E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5354>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AE1C: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 00000018AE20: BE8E200D
	s_cbranch_execnz 929                                       // 00000018AE24: BFA603A1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x53ac>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AE28: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 00000018AE2C: BE8E200C
	s_cbranch_execnz 948                                       // 00000018AE30: BFA603B4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5404>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AE34: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 00000018AE38: BE8E200B
	s_cbranch_execnz 967                                       // 00000018AE3C: BFA603C7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x545c>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AE40: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 00000018AE44: BE8E2009
	s_cbranch_execnz 986                                       // 00000018AE48: BFA603DA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x54b4>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AE4C: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 00000018AE50: BE8E2001
	s_cbranch_execnz 1005                                      // 00000018AE54: BFA603ED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x550c>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AE58: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 00000018AE5C: BE8E2008
	s_cbranch_execnz 1024                                      // 00000018AE60: BFA60400 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5564>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AE64: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 00000018AE68: BE8E2000
	s_cbranch_execnz 1043                                      // 00000018AE6C: BFA60413 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x55bc>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AE70: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 00000018AE74: BE8E200A
	s_cbranch_execnz 1062                                      // 00000018AE78: BFA60426 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5614>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018AE7C: 8C7E0E7E
	s_and_saveexec_b32 s10, s13                                // 00000018AE80: BE8A200D
	s_cbranch_execnz 1081                                      // 00000018AE84: BFA60439 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x566c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000018AE88: 8C7E0A7E
	s_and_saveexec_b32 s10, s12                                // 00000018AE8C: BE8A200C
	s_cbranch_execnz 1100                                      // 00000018AE90: BFA6044C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x56c4>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000018AE94: 8C7E0A7E
	s_and_saveexec_b32 s10, s11                                // 00000018AE98: BE8A200B
	s_cbranch_execnz 1119                                      // 00000018AE9C: BFA6045F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x571c>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000018AEA0: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 00000018AEA4: BE8A2009
	s_cbranch_execnz 1138                                      // 00000018AEA8: BFA60472 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5774>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000018AEAC: 8C7E0A7E
	s_and_saveexec_b32 s9, s1                                  // 00000018AEB0: BE892001
	s_cbranch_execnz 1157                                      // 00000018AEB4: BFA60485 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x57cc>
	s_or_b32 exec_lo, exec_lo, s9                              // 00000018AEB8: 8C7E097E
	s_and_saveexec_b32 s1, s8                                  // 00000018AEBC: BE812008
	s_cbranch_execnz 1176                                      // 00000018AEC0: BFA60498 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5824>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000018AEC4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000018AEC8: BE812000
	s_cbranch_execz 18                                         // 00000018AECC: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4618>
	ds_load_b32 v9, v141 offset:56                             // 00000018AED0: D8D80038 0900008D
	s_waitcnt lgkmcnt(0)                                       // 00000018AED8: BF89FC07
	v_fmac_f32_e32 v48, v16, v9                                // 00000018AEDC: 56601310
	v_mad_u64_u32 v[9:10], null, 0x3000, v143, v[116:117]      // 00000018AEE0: D6FE7C09 05D31EFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018AEEC: BF870092
	v_mul_f32_e32 v11, 0x3b800000, v48                         // 00000018AEF0: 101660FF 3B800000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000018AEF8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018AF00: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000018AF04: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 00000018AF10: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s1                              // 00000018AF18: 8C7E017E
	s_waitcnt vmcnt(0)                                         // 00000018AF1C: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 00000018AF20: BC7C0000
	s_barrier                                                  // 00000018AF24: BFBD0000
	buffer_gl0_inv                                             // 00000018AF28: E0AC0000 00000000
	ds_load_2addr_b32 v[9:10], v135 offset1:2                  // 00000018AF30: D8DC0200 09000087
	ds_load_2addr_b32 v[11:12], v135 offset0:4 offset1:6       // 00000018AF38: D8DC0604 0B000087
	ds_load_2addr_b32 v[13:14], v135 offset0:8 offset1:10      // 00000018AF40: D8DC0A08 0D000087
	ds_load_2addr_b32 v[15:16], v135 offset0:12 offset1:14     // 00000018AF48: D8DC0E0C 0F000087
	ds_load_2addr_b32 v[17:18], v135 offset0:16 offset1:18     // 00000018AF50: D8DC1210 11000087
	ds_load_2addr_b32 v[19:20], v135 offset0:20 offset1:22     // 00000018AF58: D8DC1614 13000087
	ds_load_2addr_b32 v[21:22], v135 offset0:24 offset1:26     // 00000018AF60: D8DC1A18 15000087
	ds_load_2addr_b32 v[23:24], v135 offset0:28 offset1:30     // 00000018AF68: D8DC1E1C 17000087
	ds_load_2addr_b32 v[25:26], v135 offset0:32 offset1:34     // 00000018AF70: D8DC2220 19000087
	ds_load_2addr_b32 v[27:28], v135 offset0:36 offset1:38     // 00000018AF78: D8DC2624 1B000087
	ds_load_2addr_b32 v[29:30], v135 offset0:40 offset1:42     // 00000018AF80: D8DC2A28 1D000087
	ds_load_2addr_b32 v[31:32], v135 offset0:44 offset1:46     // 00000018AF88: D8DC2E2C 1F000087
	ds_load_2addr_b32 v[33:34], v135 offset0:48 offset1:50     // 00000018AF90: D8DC3230 21000087
	ds_load_2addr_b32 v[35:36], v135 offset0:52 offset1:54     // 00000018AF98: D8DC3634 23000087
	ds_load_2addr_b32 v[37:38], v135 offset0:56 offset1:58     // 00000018AFA0: D8DC3A38 25000087
	ds_load_2addr_b32 v[39:40], v135 offset0:60 offset1:62     // 00000018AFA8: D8DC3E3C 27000087
	ds_load_2addr_b32 v[41:42], v135 offset0:64 offset1:66     // 00000018AFB0: D8DC4240 29000087
	ds_load_2addr_b32 v[43:44], v135 offset0:68 offset1:70     // 00000018AFB8: D8DC4644 2B000087
	ds_load_2addr_b32 v[45:46], v135 offset0:72 offset1:74     // 00000018AFC0: D8DC4A48 2D000087
	ds_load_2addr_b32 v[47:48], v135 offset0:76 offset1:78     // 00000018AFC8: D8DC4E4C 2F000087
	ds_load_2addr_b32 v[49:50], v135 offset0:80 offset1:82     // 00000018AFD0: D8DC5250 31000087
	ds_load_2addr_b32 v[51:52], v135 offset0:84 offset1:86     // 00000018AFD8: D8DC5654 33000087
	ds_load_2addr_b32 v[53:54], v135 offset0:88 offset1:90     // 00000018AFE0: D8DC5A58 35000087
	ds_load_2addr_b32 v[55:56], v135 offset0:92 offset1:94     // 00000018AFE8: D8DC5E5C 37000087
	ds_load_2addr_b32 v[57:58], v135 offset0:96 offset1:98     // 00000018AFF0: D8DC6260 39000087
	ds_load_2addr_b32 v[59:60], v135 offset0:100 offset1:102   // 00000018AFF8: D8DC6664 3B000087
	ds_load_2addr_b32 v[61:62], v135 offset0:104 offset1:106   // 00000018B000: D8DC6A68 3D000087
	ds_load_2addr_b32 v[63:64], v135 offset0:108 offset1:110   // 00000018B008: D8DC6E6C 3F000087
	ds_load_2addr_b32 v[65:66], v135 offset0:112 offset1:114   // 00000018B010: D8DC7270 41000087
	ds_load_2addr_b32 v[67:68], v135 offset0:116 offset1:118   // 00000018B018: D8DC7674 43000087
	ds_load_2addr_b32 v[69:70], v135 offset0:120 offset1:122   // 00000018B020: D8DC7A78 45000087
	ds_load_2addr_b32 v[71:72], v135 offset0:124 offset1:126   // 00000018B028: D8DC7E7C 47000087
	s_mul_f32 s0, s39, 0x3fb8aa3b                              // 00000018B030: A200FF27 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000018B038: BF8704CB
	s_xor_b32 s1, s0, 0x80000000                               // 00000018B03C: 8D01FF00 80000000
	s_rndne_f32 s8, s0                                         // 00000018B044: BE886300
	s_fmamk_f32 s1, s39, 0x3fb8aa3b, s1                        // 00000018B048: A3010127 3FB8AA3B
	s_cmp_nlt_f32 s39, 0xc2ce8ed0                              // 00000018B050: BF4EFF27 C2CE8ED0
	s_sub_f32 s0, s0, s8                                       // 00000018B058: A0800800
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000018B05C: BF8704B9
	s_fmamk_f32 s1, s39, 0x32a5705f, s1                        // 00000018B060: A3010127 32A5705F
	s_cselect_b32 vcc_lo, -1, 0                                // 00000018B068: 986A80C1
	s_cmp_ngt_f32 s39, 0x42b17218                              // 00000018B06C: BF4BFF27 42B17218
	s_add_f32 s0, s0, s1                                       // 00000018B074: A0000100
	s_delay_alu instid0(SALU_CYCLE_3)                          // 00000018B078: BF87000B
	v_exp_f32_e32 v73, s0                                      // 00000018B07C: 7E924A00
	s_cvt_i32_f32 s0, s8                                       // 00000018B080: BE806608
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000018B084: BF870585
	.long 0xd71c0049                                           // 00000018B088: D71C0049
	v_cndmask_b32_e32 v0, v73, v0, vcc_lo                      // 00000018B08C: 02000149
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000018B090: BF8700B1
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000018B094: 02929280
	s_cselect_b32 vcc_lo, -1, 0                                // 00000018B098: 986A80C1
	s_cmp_lg_u32 s31, s36                                      // 00000018B09C: BF07241F
	v_cndmask_b32_e32 v73, 0x7f800000, v73, vcc_lo             // 00000018B0A0: 029292FF 7F800000
	s_waitcnt lgkmcnt(31)                                      // 00000018B0A8: BF89FDF7
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018B0AC: BF870001
	v_fma_f32 v9, v73, v9, 0                                   // 00000018B0B0: D6130009 02021349
	v_fma_f32 v10, v73, v10, 0                                 // 00000018B0B8: D613000A 02021549
	s_waitcnt lgkmcnt(30)                                      // 00000018B0C0: BF89FDE7
	v_fma_f32 v11, v73, v11, 0                                 // 00000018B0C4: D613000B 02021749
	v_fma_f32 v12, v73, v12, 0                                 // 00000018B0CC: D613000C 02021949
	s_waitcnt lgkmcnt(29)                                      // 00000018B0D4: BF89FDD7
	v_fma_f32 v13, v73, v13, 0                                 // 00000018B0D8: D613000D 02021B49
	v_fma_f32 v14, v73, v14, 0                                 // 00000018B0E0: D613000E 02021D49
	s_waitcnt lgkmcnt(28)                                      // 00000018B0E8: BF89FDC7
	v_fma_f32 v15, v73, v15, 0                                 // 00000018B0EC: D613000F 02021F49
	v_fma_f32 v16, v73, v16, 0                                 // 00000018B0F4: D6130010 02022149
	s_waitcnt lgkmcnt(27)                                      // 00000018B0FC: BF89FDB7
	v_fma_f32 v17, v73, v17, 0                                 // 00000018B100: D6130011 02022349
	v_fma_f32 v18, v73, v18, 0                                 // 00000018B108: D6130012 02022549
	s_waitcnt lgkmcnt(26)                                      // 00000018B110: BF89FDA7
	v_fma_f32 v19, v73, v19, 0                                 // 00000018B114: D6130013 02022749
	v_fma_f32 v20, v73, v20, 0                                 // 00000018B11C: D6130014 02022949
	s_waitcnt lgkmcnt(25)                                      // 00000018B124: BF89FD97
	v_fma_f32 v21, v73, v21, 0                                 // 00000018B128: D6130015 02022B49
	v_fma_f32 v22, v73, v22, 0                                 // 00000018B130: D6130016 02022D49
	s_waitcnt lgkmcnt(24)                                      // 00000018B138: BF89FD87
	v_fma_f32 v23, v73, v23, 0                                 // 00000018B13C: D6130017 02022F49
	v_fma_f32 v24, v73, v24, 0                                 // 00000018B144: D6130018 02023149
	s_waitcnt lgkmcnt(23)                                      // 00000018B14C: BF89FD77
	v_fma_f32 v25, v73, v25, 0                                 // 00000018B150: D6130019 02023349
	v_fma_f32 v26, v73, v26, 0                                 // 00000018B158: D613001A 02023549
	s_waitcnt lgkmcnt(22)                                      // 00000018B160: BF89FD67
	v_fma_f32 v27, v73, v27, 0                                 // 00000018B164: D613001B 02023749
	v_fma_f32 v28, v73, v28, 0                                 // 00000018B16C: D613001C 02023949
	s_waitcnt lgkmcnt(21)                                      // 00000018B174: BF89FD57
	v_fma_f32 v29, v73, v29, 0                                 // 00000018B178: D613001D 02023B49
	v_fma_f32 v30, v73, v30, 0                                 // 00000018B180: D613001E 02023D49
	s_waitcnt lgkmcnt(20)                                      // 00000018B188: BF89FD47
	v_fma_f32 v31, v73, v31, 0                                 // 00000018B18C: D613001F 02023F49
	v_fma_f32 v32, v73, v32, 0                                 // 00000018B194: D6130020 02024149
	s_waitcnt lgkmcnt(19)                                      // 00000018B19C: BF89FD37
	v_fma_f32 v33, v73, v33, 0                                 // 00000018B1A0: D6130021 02024349
	v_fma_f32 v34, v73, v34, 0                                 // 00000018B1A8: D6130022 02024549
	s_waitcnt lgkmcnt(18)                                      // 00000018B1B0: BF89FD27
	v_fma_f32 v35, v73, v35, 0                                 // 00000018B1B4: D6130023 02024749
	v_fma_f32 v36, v73, v36, 0                                 // 00000018B1BC: D6130024 02024949
	s_waitcnt lgkmcnt(17)                                      // 00000018B1C4: BF89FD17
	v_fma_f32 v37, v73, v37, 0                                 // 00000018B1C8: D6130025 02024B49
	v_fma_f32 v38, v73, v38, 0                                 // 00000018B1D0: D6130026 02024D49
	s_waitcnt lgkmcnt(16)                                      // 00000018B1D8: BF89FD07
	v_fma_f32 v39, v73, v39, 0                                 // 00000018B1DC: D6130027 02024F49
	v_fma_f32 v40, v73, v40, 0                                 // 00000018B1E4: D6130028 02025149
	s_waitcnt lgkmcnt(15)                                      // 00000018B1EC: BF89FCF7
	v_fma_f32 v41, v73, v41, 0                                 // 00000018B1F0: D6130029 02025349
	v_fma_f32 v42, v73, v42, 0                                 // 00000018B1F8: D613002A 02025549
	s_waitcnt lgkmcnt(14)                                      // 00000018B200: BF89FCE7
	v_fma_f32 v43, v73, v43, 0                                 // 00000018B204: D613002B 02025749
	v_fma_f32 v44, v73, v44, 0                                 // 00000018B20C: D613002C 02025949
	s_waitcnt lgkmcnt(13)                                      // 00000018B214: BF89FCD7
	v_fma_f32 v45, v73, v45, 0                                 // 00000018B218: D613002D 02025B49
	v_fma_f32 v46, v73, v46, 0                                 // 00000018B220: D613002E 02025D49
	s_waitcnt lgkmcnt(12)                                      // 00000018B228: BF89FCC7
	v_fma_f32 v47, v73, v47, 0                                 // 00000018B22C: D613002F 02025F49
	v_fma_f32 v48, v73, v48, 0                                 // 00000018B234: D6130030 02026149
	s_waitcnt lgkmcnt(11)                                      // 00000018B23C: BF89FCB7
	v_fma_f32 v49, v73, v49, 0                                 // 00000018B240: D6130031 02026349
	v_fma_f32 v50, v73, v50, 0                                 // 00000018B248: D6130032 02026549
	s_waitcnt lgkmcnt(10)                                      // 00000018B250: BF89FCA7
	v_fma_f32 v51, v73, v51, 0                                 // 00000018B254: D6130033 02026749
	v_fma_f32 v52, v73, v52, 0                                 // 00000018B25C: D6130034 02026949
	s_waitcnt lgkmcnt(9)                                       // 00000018B264: BF89FC97
	v_fma_f32 v53, v73, v53, 0                                 // 00000018B268: D6130035 02026B49
	v_fma_f32 v54, v73, v54, 0                                 // 00000018B270: D6130036 02026D49
	s_waitcnt lgkmcnt(8)                                       // 00000018B278: BF89FC87
	v_fma_f32 v55, v73, v55, 0                                 // 00000018B27C: D6130037 02026F49
	v_fma_f32 v56, v73, v56, 0                                 // 00000018B284: D6130038 02027149
	s_waitcnt lgkmcnt(7)                                       // 00000018B28C: BF89FC77
	v_fma_f32 v57, v73, v57, 0                                 // 00000018B290: D6130039 02027349
	v_fma_f32 v58, v73, v58, 0                                 // 00000018B298: D613003A 02027549
	s_waitcnt lgkmcnt(6)                                       // 00000018B2A0: BF89FC67
	v_fma_f32 v59, v73, v59, 0                                 // 00000018B2A4: D613003B 02027749
	v_fma_f32 v60, v73, v60, 0                                 // 00000018B2AC: D613003C 02027949
	s_waitcnt lgkmcnt(5)                                       // 00000018B2B4: BF89FC57
	v_fma_f32 v61, v73, v61, 0                                 // 00000018B2B8: D613003D 02027B49
	v_fma_f32 v62, v73, v62, 0                                 // 00000018B2C0: D613003E 02027D49
	s_waitcnt lgkmcnt(4)                                       // 00000018B2C8: BF89FC47
	v_fma_f32 v63, v73, v63, 0                                 // 00000018B2CC: D613003F 02027F49
	v_fma_f32 v64, v73, v64, 0                                 // 00000018B2D4: D6130040 02028149
	s_waitcnt lgkmcnt(3)                                       // 00000018B2DC: BF89FC37
	v_fma_f32 v65, v73, v65, 0                                 // 00000018B2E0: D6130041 02028349
	v_fma_f32 v66, v73, v66, 0                                 // 00000018B2E8: D6130042 02028549
	s_waitcnt lgkmcnt(2)                                       // 00000018B2F0: BF89FC27
	v_fma_f32 v67, v73, v67, 0                                 // 00000018B2F4: D6130043 02028749
	v_fma_f32 v68, v73, v68, 0                                 // 00000018B2FC: D6130044 02028949
	s_waitcnt lgkmcnt(1)                                       // 00000018B304: BF89FC17
	v_fma_f32 v69, v73, v69, 0                                 // 00000018B308: D6130045 02028B49
	v_fma_f32 v70, v73, v70, 0                                 // 00000018B310: D6130046 02028D49
	s_waitcnt lgkmcnt(0)                                       // 00000018B318: BF89FC07
	v_fma_f32 v71, v73, v71, 0                                 // 00000018B31C: D6130047 02028F49
	v_fma_f32 v72, v73, v72, 0                                 // 00000018B324: D6130048 02029149
	ds_store_2addr_b32 v135, v9, v10 offset1:2                 // 00000018B32C: D8380200 000A0987
	ds_store_2addr_b32 v135, v11, v12 offset0:4 offset1:6      // 00000018B334: D8380604 000C0B87
	ds_store_2addr_b32 v135, v13, v14 offset0:8 offset1:10     // 00000018B33C: D8380A08 000E0D87
	ds_store_2addr_b32 v135, v15, v16 offset0:12 offset1:14    // 00000018B344: D8380E0C 00100F87
	ds_store_2addr_b32 v135, v17, v18 offset0:16 offset1:18    // 00000018B34C: D8381210 00121187
	ds_store_2addr_b32 v135, v19, v20 offset0:20 offset1:22    // 00000018B354: D8381614 00141387
	ds_store_2addr_b32 v135, v21, v22 offset0:24 offset1:26    // 00000018B35C: D8381A18 00161587
	ds_store_2addr_b32 v135, v23, v24 offset0:28 offset1:30    // 00000018B364: D8381E1C 00181787
	ds_store_2addr_b32 v135, v25, v26 offset0:32 offset1:34    // 00000018B36C: D8382220 001A1987
	ds_store_2addr_b32 v135, v27, v28 offset0:36 offset1:38    // 00000018B374: D8382624 001C1B87
	ds_store_2addr_b32 v135, v29, v30 offset0:40 offset1:42    // 00000018B37C: D8382A28 001E1D87
	ds_store_2addr_b32 v135, v31, v32 offset0:44 offset1:46    // 00000018B384: D8382E2C 00201F87
	ds_store_2addr_b32 v135, v33, v34 offset0:48 offset1:50    // 00000018B38C: D8383230 00222187
	ds_store_2addr_b32 v135, v35, v36 offset0:52 offset1:54    // 00000018B394: D8383634 00242387
	ds_store_2addr_b32 v135, v37, v38 offset0:56 offset1:58    // 00000018B39C: D8383A38 00262587
	ds_store_2addr_b32 v135, v39, v40 offset0:60 offset1:62    // 00000018B3A4: D8383E3C 00282787
	ds_store_2addr_b32 v135, v41, v42 offset0:64 offset1:66    // 00000018B3AC: D8384240 002A2987
	ds_store_2addr_b32 v135, v43, v44 offset0:68 offset1:70    // 00000018B3B4: D8384644 002C2B87
	ds_store_2addr_b32 v135, v45, v46 offset0:72 offset1:74    // 00000018B3BC: D8384A48 002E2D87
	ds_store_2addr_b32 v135, v47, v48 offset0:76 offset1:78    // 00000018B3C4: D8384E4C 00302F87
	ds_store_2addr_b32 v135, v49, v50 offset0:80 offset1:82    // 00000018B3CC: D8385250 00323187
	ds_store_2addr_b32 v135, v51, v52 offset0:84 offset1:86    // 00000018B3D4: D8385654 00343387
	ds_store_2addr_b32 v135, v53, v54 offset0:88 offset1:90    // 00000018B3DC: D8385A58 00363587
	ds_store_2addr_b32 v135, v55, v56 offset0:92 offset1:94    // 00000018B3E4: D8385E5C 00383787
	ds_store_2addr_b32 v135, v57, v58 offset0:96 offset1:98    // 00000018B3EC: D8386260 003A3987
	ds_store_2addr_b32 v135, v59, v60 offset0:100 offset1:102  // 00000018B3F4: D8386664 003C3B87
	ds_store_2addr_b32 v135, v61, v62 offset0:104 offset1:106  // 00000018B3FC: D8386A68 003E3D87
	ds_store_2addr_b32 v135, v63, v64 offset0:108 offset1:110  // 00000018B404: D8386E6C 00403F87
	ds_store_2addr_b32 v135, v65, v66 offset0:112 offset1:114  // 00000018B40C: D8387270 00424187
	ds_store_2addr_b32 v135, v67, v68 offset0:116 offset1:118  // 00000018B414: D8387674 00444387
	ds_store_2addr_b32 v135, v69, v70 offset0:120 offset1:122  // 00000018B41C: D8387A78 00464587
	ds_store_2addr_b32 v135, v71, v72 offset0:124 offset1:126  // 00000018B424: D8387E7C 00484787
	s_waitcnt lgkmcnt(0)                                       // 00000018B42C: BF89FC07
	s_barrier                                                  // 00000018B430: BFBD0000
	buffer_gl0_inv                                             // 00000018B434: E0AC0000 00000000
	s_cbranch_scc0 73                                          // 00000018B43C: BFA10049 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4c64>
	s_cmp_lg_u32 s31, s37                                      // 00000018B440: BF07251F
	s_cbranch_scc0 100                                         // 00000018B444: BFA10064 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4cd8>
	s_cmp_lg_u32 s31, s38                                      // 00000018B448: BF07261F
	s_cbranch_scc1 60952                                       // 00000018B44C: BFA2EE18 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3b0>
	s_branch 129                                               // 00000018B450: BFA00081 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4d58>
	s_clause 0x1                                               // 00000018B454: BF850001
	global_load_b128 v[77:80], v[124:125], off offset:48       // 00000018B458: DC5E0030 4D7C007C
	global_load_b128 v[73:76], v[124:125], off offset:32       // 00000018B460: DC5E0020 497C007C
	ds_load_b128 v[81:84], v131 offset:32                      // 00000018B468: DBFC0020 51000083
	ds_load_b128 v[85:88], v131 offset:48                      // 00000018B470: DBFC0030 55000083
	ds_load_b128 v[93:96], v131 offset:2352                    // 00000018B478: DBFC0930 5D000083
	ds_load_b128 v[89:92], v131 offset:2336                    // 00000018B480: DBFC0920 59000083
	ds_load_b128 v[154:157], v131 offset:4656                  // 00000018B488: DBFC1230 9A000083
	ds_load_b128 v[150:153], v131 offset:4640                  // 00000018B490: DBFC1220 96000083
	ds_load_b128 v[162:165], v131 offset:6960                  // 00000018B498: DBFC1B30 A2000083
	ds_load_b128 v[158:161], v131 offset:6944                  // 00000018B4A0: DBFC1B20 9E000083
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 00000018B4A8: BF890067
	v_wmma_f32_16x16x16_f16 v[65:72], v[73:80], v[81:88], v[65:72]// 00000018B4AC: CC404041 1D06A349
	s_waitcnt lgkmcnt(4)                                       // 00000018B4B4: BF89FC47
	v_wmma_f32_16x16x16_f16 v[57:64], v[73:80], v[89:96], v[57:64]// 00000018B4B8: CC404039 1CE6B349
	s_waitcnt lgkmcnt(2)                                       // 00000018B4C0: BF89FC27
	v_wmma_f32_16x16x16_f16 v[49:56], v[73:80], v[150:157], v[49:56]// 00000018B4C4: CC404031 1CC72D49
	s_waitcnt lgkmcnt(0)                                       // 00000018B4CC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[41:48], v[73:80], v[158:165], v[41:48]// 00000018B4D0: CC404029 1CA73D49
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018B4D8: 8C7E0E7E
	s_and_saveexec_b32 s14, s5                                 // 00000018B4DC: BE8E2005
	s_cbranch_execz 64620                                      // 00000018B4E0: BFA5FC6C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3d94>
	ds_load_b128 v[73:76], v131 offset:64                      // 00000018B4E4: DBFC0040 49000083
	ds_load_b128 v[77:80], v131 offset:80                      // 00000018B4EC: DBFC0050 4D000083
	ds_load_b128 v[85:88], v131 offset:2384                    // 00000018B4F4: DBFC0950 55000083
	ds_load_b128 v[81:84], v131 offset:2368                    // 00000018B4FC: DBFC0940 51000083
	ds_load_b128 v[93:96], v131 offset:4688                    // 00000018B504: DBFC1250 5D000083
	ds_load_b128 v[89:92], v131 offset:4672                    // 00000018B50C: DBFC1240 59000083
	ds_load_b128 v[154:157], v131 offset:6992                  // 00000018B514: DBFC1B50 9A000083
	ds_load_b128 v[150:153], v131 offset:6976                  // 00000018B51C: DBFC1B40 96000083
	s_waitcnt vmcnt(2) lgkmcnt(6)                              // 00000018B524: BF890867
	v_wmma_f32_16x16x16_f16 v[65:72], v[105:112], v[73:80], v[65:72]// 00000018B528: CC404041 1D069369
	s_waitcnt lgkmcnt(4)                                       // 00000018B530: BF89FC47
	v_wmma_f32_16x16x16_f16 v[57:64], v[105:112], v[81:88], v[57:64]// 00000018B534: CC404039 1CE6A369
	s_waitcnt lgkmcnt(2)                                       // 00000018B53C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[49:56], v[105:112], v[89:96], v[49:56]// 00000018B540: CC404031 1CC6B369
	s_waitcnt lgkmcnt(0)                                       // 00000018B548: BF89FC07
	v_wmma_f32_16x16x16_f16 v[41:48], v[105:112], v[150:157], v[41:48]// 00000018B54C: CC404029 1CA72D69
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018B554: 8C7E0E7E
	s_and_saveexec_b32 s14, s7                                 // 00000018B558: BE8E2007
	s_cbranch_execnz 64592                                     // 00000018B55C: BFA6FC50 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3da0>
	s_branch 64621                                             // 00000018B560: BFA0FC6D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3e18>
	v_dual_mov_b32 v9, v118 :: v_dual_mov_b32 v12, v127        // 00000018B564: CA100176 090C017F
	v_dual_mov_b32 v11, v128 :: v_dual_mov_b32 v10, v119       // 00000018B56C: CA100180 0B0A0177
	s_mov_b32 s1, 0                                            // 00000018B574: BE810080
	s_nop 0                                                    // 00000018B578: BF800000
	s_nop 0                                                    // 00000018B57C: BF800000
	ds_load_b32 v13, v11                                       // 00000018B580: D8D80000 0D00000B
	v_add_nc_u32_e32 v12, 0x80, v12                            // 00000018B588: 4A1818FF 00000080
	v_add_nc_u32_e32 v11, 8, v11                               // 00000018B590: 4A161688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000018B594: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v12                       // 00000018B598: 7C9218FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 00000018B5A0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000018B5A4: BF89FC07
	global_store_b32 v[9:10], v13, off                         // 00000018B5A8: DC6A0000 007C0D09
	.long 0xd7000009                                           // 00000018B5B0: D7000009
	v_cndmask_b32_e32 v1, 0x400, v9, vcc_lo                    // 00000018B5B4: 020212FF 00000400
	v_add_co_ci_u32_e64 v10, null, 0, v10, s0                  // 00000018B5BC: D5207C0A 00021480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000018B5C4: 917E017E
	s_cbranch_execnz 65517                                     // 00000018B5C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4c80>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000018B5CC: 8C7E017E
	s_cmp_lg_u32 s31, s37                                      // 00000018B5D0: BF07251F
	s_cbranch_scc1 65436                                       // 00000018B5D4: BFA2FF9C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4b48>
	v_dual_mov_b32 v9, v120 :: v_dual_mov_b32 v12, v127        // 00000018B5D8: CA100178 090C017F
	v_dual_mov_b32 v11, v128 :: v_dual_mov_b32 v10, v121       // 00000018B5E0: CA100180 0B0A0179
	s_mov_b32 s1, 0                                            // 00000018B5E8: BE810080
	s_nop 0                                                    // 00000018B5EC: BF800000
	s_nop 0                                                    // 00000018B5F0: BF800000
	s_nop 0                                                    // 00000018B5F4: BF800000
	s_nop 0                                                    // 00000018B5F8: BF800000
	s_nop 0                                                    // 00000018B5FC: BF800000
	ds_load_b32 v13, v11                                       // 00000018B600: D8D80000 0D00000B
	v_add_nc_u32_e32 v12, 0x80, v12                            // 00000018B608: 4A1818FF 00000080
	v_add_nc_u32_e32 v11, 8, v11                               // 00000018B610: 4A161688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000018B614: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v12                       // 00000018B618: 7C9218FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 00000018B620: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000018B624: BF89FC07
	global_store_b32 v[9:10], v13, off                         // 00000018B628: DC6A0000 007C0D09
	.long 0xd7000009                                           // 00000018B630: D7000009
	v_cndmask_b32_e32 v1, 0x400, v9, vcc_lo                    // 00000018B634: 020212FF 00000400
	v_add_co_ci_u32_e64 v10, null, 0, v10, s0                  // 00000018B63C: D5207C0A 00021480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000018B644: 917E017E
	s_cbranch_execnz 65517                                     // 00000018B648: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4d00>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000018B64C: 8C7E017E
	s_cmp_lg_u32 s31, s38                                      // 00000018B650: BF07261F
	s_cbranch_scc1 60822                                       // 00000018B654: BFA2ED96 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3b0>
	v_dual_mov_b32 v9, v122 :: v_dual_mov_b32 v12, v127        // 00000018B658: CA10017A 090C017F
	v_dual_mov_b32 v11, v128 :: v_dual_mov_b32 v10, v123       // 00000018B660: CA100180 0B0A017B
	s_mov_b32 s1, 0                                            // 00000018B668: BE810080
	s_nop 0                                                    // 00000018B66C: BF800000
	s_nop 0                                                    // 00000018B670: BF800000
	s_nop 0                                                    // 00000018B674: BF800000
	s_nop 0                                                    // 00000018B678: BF800000
	s_nop 0                                                    // 00000018B67C: BF800000
	ds_load_b32 v13, v11                                       // 00000018B680: D8D80000 0D00000B
	v_add_nc_u32_e32 v12, 0x80, v12                            // 00000018B688: 4A1818FF 00000080
	v_add_nc_u32_e32 v11, 8, v11                               // 00000018B690: 4A161688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000018B694: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v12                       // 00000018B698: 7C9218FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 00000018B6A0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000018B6A4: BF89FC07
	global_store_b32 v[9:10], v13, off                         // 00000018B6A8: DC6A0000 007C0D09
	.long 0xd7000009                                           // 00000018B6B0: D7000009
	v_cndmask_b32_e32 v1, 0x400, v9, vcc_lo                    // 00000018B6B4: 020212FF 00000400
	v_add_co_ci_u32_e64 v10, null, 0, v10, s0                  // 00000018B6BC: D5207C0A 00021480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000018B6C4: 917E017E
	s_cbranch_execnz 65517                                     // 00000018B6C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4d80>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000018B6CC: 8C7E017E
	s_branch 60791                                             // 00000018B6D0: BFA0ED77 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3b0>
	ds_load_b32 v73, v141                                      // 00000018B6D4: D8D80000 4900008D
	s_waitcnt lgkmcnt(0)                                       // 00000018B6DC: BF89FC07
	v_fma_f32 v33, v33, v73, v65                               // 00000018B6E0: D6130021 05069321
	v_mad_u64_u32 v[73:74], null, 0x3000, v142, v[116:117]     // 00000018B6E8: D6FE7C49 05D31CFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018B6F4: BF870092
	v_mul_f32_e32 v33, 0x3b800000, v33                         // 00000018B6F8: 104242FF 3B800000
	v_bfe_u32 v65, v33, 16, 1                                  // 00000018B700: D6100041 02052121
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018B708: BF870001
	v_add3_u32 v33, v33, v65, 0x7fff                           // 00000018B70C: D6550021 03FE8321 00007FFF
	global_store_d16_hi_b16 v[73:74], v33, off                 // 00000018B718: DC960000 007C2149
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018B720: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 00000018B724: BE8E200D
	s_cbranch_execz 64911                                      // 00000018B728: BFA5FD8F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4468>
	ds_load_b32 v33, v141 offset:8                             // 00000018B72C: D8D80008 2100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018B734: BF89FC07
	v_fma_f32 v33, v34, v33, v66                               // 00000018B738: D6130021 050A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018B740: BF870121
	v_mul_f32_e32 v65, 0x3b800000, v33                         // 00000018B744: 108242FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v149, v[116:117]     // 00000018B74C: D6FE7C21 05D32AFF 00003000
	v_bfe_u32 v66, v65, 16, 1                                  // 00000018B758: D6100042 02052141
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018B760: BF870001
	v_add3_u32 v65, v65, v66, 0x7fff                           // 00000018B764: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[33:34], v65, off                 // 00000018B770: DC960000 007C4121
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018B778: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 00000018B77C: BE8E200C
	s_cbranch_execz 64892                                      // 00000018B780: BFA5FD7C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4474>
	ds_load_b32 v33, v141 offset:16                            // 00000018B784: D8D80010 2100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018B78C: BF89FC07
	v_fma_f32 v33, v35, v33, v67                               // 00000018B790: D6130021 050E4323
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018B798: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 00000018B79C: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v148, v[116:117]     // 00000018B7A4: D6FE7C21 05D328FF 00003000
	v_bfe_u32 v65, v35, 16, 1                                  // 00000018B7B0: D6100041 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018B7B8: BF870001
	v_add3_u32 v35, v35, v65, 0x7fff                           // 00000018B7BC: D6550023 03FE8323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 00000018B7C8: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018B7D0: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 00000018B7D4: BE8E200B
	s_cbranch_execz 64873                                      // 00000018B7D8: BFA5FD69 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4480>
	ds_load_b32 v33, v141 offset:24                            // 00000018B7DC: D8D80018 2100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018B7E4: BF89FC07
	v_fma_f32 v33, v36, v33, v68                               // 00000018B7E8: D6130021 05124324
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018B7F0: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 00000018B7F4: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v147, v[116:117]     // 00000018B7FC: D6FE7C21 05D326FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 00000018B808: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018B810: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000018B814: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 00000018B820: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018B828: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 00000018B82C: BE8E2009
	s_cbranch_execz 64854                                      // 00000018B830: BFA5FD56 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x448c>
	ds_load_b32 v33, v141 offset:32                            // 00000018B834: D8D80020 2100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018B83C: BF89FC07
	v_fma_f32 v33, v37, v33, v69                               // 00000018B840: D6130021 05164325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018B848: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 00000018B84C: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v146, v[116:117]     // 00000018B854: D6FE7C21 05D324FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 00000018B860: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018B868: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000018B86C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 00000018B878: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018B880: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 00000018B884: BE8E2001
	s_cbranch_execz 64835                                      // 00000018B888: BFA5FD43 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4498>
	ds_load_b32 v33, v141 offset:40                            // 00000018B88C: D8D80028 2100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018B894: BF89FC07
	v_fma_f32 v33, v38, v33, v70                               // 00000018B898: D6130021 051A4326
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018B8A0: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 00000018B8A4: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v145, v[116:117]     // 00000018B8AC: D6FE7C21 05D322FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 00000018B8B8: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018B8C0: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000018B8C4: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 00000018B8D0: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018B8D8: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 00000018B8DC: BE8E2008
	s_cbranch_execz 64816                                      // 00000018B8E0: BFA5FD30 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x44a4>
	ds_load_b32 v33, v141 offset:48                            // 00000018B8E4: D8D80030 2100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018B8EC: BF89FC07
	v_fma_f32 v33, v39, v33, v71                               // 00000018B8F0: D6130021 051E4327
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018B8F8: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 00000018B8FC: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v144, v[116:117]     // 00000018B904: D6FE7C21 05D320FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 00000018B910: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018B918: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000018B91C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 00000018B928: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018B930: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 00000018B934: BE8E2000
	s_cbranch_execz 64797                                      // 00000018B938: BFA5FD1D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x44b0>
	ds_load_b32 v33, v141 offset:56                            // 00000018B93C: D8D80038 2100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018B944: BF89FC07
	v_fma_f32 v33, v40, v33, v72                               // 00000018B948: D6130021 05224328
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018B950: BF870121
	v_mul_f32_e32 v35, 0x3b800000, v33                         // 00000018B954: 104642FF 3B800000
	v_mad_u64_u32 v[33:34], null, 0x3000, v143, v[116:117]     // 00000018B95C: D6FE7C21 05D31EFF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 00000018B968: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018B970: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000018B974: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off                 // 00000018B980: DC960000 007C2321
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018B988: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 00000018B98C: BE8E200A
	s_cbranch_execz 64778                                      // 00000018B990: BFA5FD0A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x44bc>
	ds_load_b32 v33, v141                                      // 00000018B994: D8D80000 2100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018B99C: BF89FC07
	v_fma_f32 v17, v17, v33, v57                               // 00000018B9A0: D6130011 04E64311
	v_mad_u64_u32 v[33:34], null, 0x3000, v142, v[116:117]     // 00000018B9A8: D6FE7C21 05D31CFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018B9B4: BF870092
	v_mul_f32_e32 v17, 0x3b800000, v17                         // 00000018B9B8: 102222FF 3B800000
	v_bfe_u32 v35, v17, 16, 1                                  // 00000018B9C0: D6100023 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018B9C8: BF870001
	v_add3_u32 v17, v17, v35, 0x7fff                           // 00000018B9CC: D6550011 03FE4711 00007FFF
	global_store_d16_hi_b16 v[33:34], v17, off offset:32       // 00000018B9D8: DC960020 007C1121
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018B9E0: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 00000018B9E4: BE8E200D
	s_cbranch_execz 64759                                      // 00000018B9E8: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x44c8>
	ds_load_b32 v17, v141 offset:8                             // 00000018B9EC: D8D80008 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018B9F4: BF89FC07
	v_fma_f32 v17, v18, v17, v58                               // 00000018B9F8: D6130011 04EA2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BA00: BF870121
	v_mul_f32_e32 v33, 0x3b800000, v17                         // 00000018BA04: 104222FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v149, v[116:117]     // 00000018BA0C: D6FE7C11 05D32AFF 00003000
	v_bfe_u32 v34, v33, 16, 1                                  // 00000018BA18: D6100022 02052121
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BA20: BF870001
	v_add3_u32 v33, v33, v34, 0x7fff                           // 00000018BA24: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[17:18], v33, off offset:32       // 00000018BA30: DC960020 007C2111
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BA38: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 00000018BA3C: BE8E200C
	s_cbranch_execz 64740                                      // 00000018BA40: BFA5FCE4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x44d4>
	ds_load_b32 v17, v141 offset:16                            // 00000018BA44: D8D80010 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BA4C: BF89FC07
	v_fma_f32 v17, v19, v17, v59                               // 00000018BA50: D6130011 04EE2313
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BA58: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000018BA5C: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v148, v[116:117]     // 00000018BA64: D6FE7C11 05D328FF 00003000
	v_bfe_u32 v33, v19, 16, 1                                  // 00000018BA70: D6100021 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BA78: BF870001
	v_add3_u32 v19, v19, v33, 0x7fff                           // 00000018BA7C: D6550013 03FE4313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:32       // 00000018BA88: DC960020 007C1311
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BA90: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 00000018BA94: BE8E200B
	s_cbranch_execz 64721                                      // 00000018BA98: BFA5FCD1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x44e0>
	ds_load_b32 v17, v141 offset:24                            // 00000018BA9C: D8D80018 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BAA4: BF89FC07
	v_fma_f32 v17, v20, v17, v60                               // 00000018BAA8: D6130011 04F22314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BAB0: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000018BAB4: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v147, v[116:117]     // 00000018BABC: D6FE7C11 05D326FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000018BAC8: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BAD0: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000018BAD4: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:32       // 00000018BAE0: DC960020 007C1311
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BAE8: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 00000018BAEC: BE8E2009
	s_cbranch_execz 64702                                      // 00000018BAF0: BFA5FCBE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x44ec>
	ds_load_b32 v17, v141 offset:32                            // 00000018BAF4: D8D80020 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BAFC: BF89FC07
	v_fma_f32 v17, v21, v17, v61                               // 00000018BB00: D6130011 04F62315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BB08: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000018BB0C: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v146, v[116:117]     // 00000018BB14: D6FE7C11 05D324FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000018BB20: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BB28: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000018BB2C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:32       // 00000018BB38: DC960020 007C1311
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BB40: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 00000018BB44: BE8E2001
	s_cbranch_execz 64683                                      // 00000018BB48: BFA5FCAB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x44f8>
	ds_load_b32 v17, v141 offset:40                            // 00000018BB4C: D8D80028 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BB54: BF89FC07
	v_fma_f32 v17, v22, v17, v62                               // 00000018BB58: D6130011 04FA2316
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BB60: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000018BB64: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v145, v[116:117]     // 00000018BB6C: D6FE7C11 05D322FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000018BB78: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BB80: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000018BB84: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:32       // 00000018BB90: DC960020 007C1311
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BB98: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 00000018BB9C: BE8E2008
	s_cbranch_execz 64664                                      // 00000018BBA0: BFA5FC98 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4504>
	ds_load_b32 v17, v141 offset:48                            // 00000018BBA4: D8D80030 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BBAC: BF89FC07
	v_fma_f32 v17, v23, v17, v63                               // 00000018BBB0: D6130011 04FE2317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BBB8: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000018BBBC: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v144, v[116:117]     // 00000018BBC4: D6FE7C11 05D320FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000018BBD0: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BBD8: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000018BBDC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:32       // 00000018BBE8: DC960020 007C1311
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BBF0: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 00000018BBF4: BE8E2000
	s_cbranch_execz 64645                                      // 00000018BBF8: BFA5FC85 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4510>
	ds_load_b32 v17, v141 offset:56                            // 00000018BBFC: D8D80038 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BC04: BF89FC07
	v_fma_f32 v17, v24, v17, v64                               // 00000018BC08: D6130011 05022318
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BC10: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000018BC14: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v143, v[116:117]     // 00000018BC1C: D6FE7C11 05D31EFF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000018BC28: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BC30: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000018BC34: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:32       // 00000018BC40: DC960020 007C1311
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BC48: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 00000018BC4C: BE8E200A
	s_cbranch_execz 64626                                      // 00000018BC50: BFA5FC72 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x451c>
	ds_load_b32 v17, v141                                      // 00000018BC54: D8D80000 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BC5C: BF89FC07
	v_fma_f32 v17, v25, v17, v49                               // 00000018BC60: D6130011 04C62319
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BC68: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000018BC6C: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v142, v[116:117]     // 00000018BC74: D6FE7C11 05D31CFF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000018BC80: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BC88: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000018BC8C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 00000018BC98: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BCA0: 8C7E0E7E
	s_and_saveexec_b32 s14, s13                                // 00000018BCA4: BE8E200D
	s_cbranch_execz 64607                                      // 00000018BCA8: BFA5FC5F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4528>
	ds_load_b32 v17, v141 offset:8                             // 00000018BCAC: D8D80008 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BCB4: BF89FC07
	v_fma_f32 v17, v26, v17, v50                               // 00000018BCB8: D6130011 04CA231A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BCC0: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000018BCC4: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v149, v[116:117]     // 00000018BCCC: D6FE7C11 05D32AFF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000018BCD8: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BCE0: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000018BCE4: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 00000018BCF0: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BCF8: 8C7E0E7E
	s_and_saveexec_b32 s14, s12                                // 00000018BCFC: BE8E200C
	s_cbranch_execz 64588                                      // 00000018BD00: BFA5FC4C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4534>
	ds_load_b32 v17, v141 offset:16                            // 00000018BD04: D8D80010 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BD0C: BF89FC07
	v_fma_f32 v17, v27, v17, v51                               // 00000018BD10: D6130011 04CE231B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BD18: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000018BD1C: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v148, v[116:117]     // 00000018BD24: D6FE7C11 05D328FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000018BD30: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BD38: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000018BD3C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 00000018BD48: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BD50: 8C7E0E7E
	s_and_saveexec_b32 s14, s11                                // 00000018BD54: BE8E200B
	s_cbranch_execz 64569                                      // 00000018BD58: BFA5FC39 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4540>
	ds_load_b32 v17, v141 offset:24                            // 00000018BD5C: D8D80018 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BD64: BF89FC07
	v_fma_f32 v17, v28, v17, v52                               // 00000018BD68: D6130011 04D2231C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BD70: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000018BD74: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v147, v[116:117]     // 00000018BD7C: D6FE7C11 05D326FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000018BD88: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BD90: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000018BD94: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 00000018BDA0: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BDA8: 8C7E0E7E
	s_and_saveexec_b32 s14, s9                                 // 00000018BDAC: BE8E2009
	s_cbranch_execz 64550                                      // 00000018BDB0: BFA5FC26 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x454c>
	ds_load_b32 v17, v141 offset:32                            // 00000018BDB4: D8D80020 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BDBC: BF89FC07
	v_fma_f32 v17, v29, v17, v53                               // 00000018BDC0: D6130011 04D6231D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BDC8: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000018BDCC: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v146, v[116:117]     // 00000018BDD4: D6FE7C11 05D324FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000018BDE0: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BDE8: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000018BDEC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 00000018BDF8: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BE00: 8C7E0E7E
	s_and_saveexec_b32 s14, s1                                 // 00000018BE04: BE8E2001
	s_cbranch_execz 64531                                      // 00000018BE08: BFA5FC13 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4558>
	ds_load_b32 v17, v141 offset:40                            // 00000018BE0C: D8D80028 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BE14: BF89FC07
	v_fma_f32 v17, v30, v17, v54                               // 00000018BE18: D6130011 04DA231E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BE20: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000018BE24: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v145, v[116:117]     // 00000018BE2C: D6FE7C11 05D322FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000018BE38: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BE40: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000018BE44: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 00000018BE50: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BE58: 8C7E0E7E
	s_and_saveexec_b32 s14, s8                                 // 00000018BE5C: BE8E2008
	s_cbranch_execz 64512                                      // 00000018BE60: BFA5FC00 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4564>
	ds_load_b32 v17, v141 offset:48                            // 00000018BE64: D8D80030 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BE6C: BF89FC07
	v_fma_f32 v17, v31, v17, v55                               // 00000018BE70: D6130011 04DE231F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BE78: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000018BE7C: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v144, v[116:117]     // 00000018BE84: D6FE7C11 05D320FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000018BE90: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BE98: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000018BE9C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 00000018BEA8: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BEB0: 8C7E0E7E
	s_and_saveexec_b32 s14, s0                                 // 00000018BEB4: BE8E2000
	s_cbranch_execz 64493                                      // 00000018BEB8: BFA5FBED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4570>
	ds_load_b32 v17, v141 offset:56                            // 00000018BEBC: D8D80038 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BEC4: BF89FC07
	v_fma_f32 v17, v32, v17, v56                               // 00000018BEC8: D6130011 04E22320
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BED0: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 00000018BED4: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v143, v[116:117]     // 00000018BEDC: D6FE7C11 05D31EFF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 00000018BEE8: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BEF0: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000018BEF4: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 00000018BF00: DC960040 007C1311
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BF08: 8C7E0E7E
	s_and_saveexec_b32 s14, s10                                // 00000018BF0C: BE8E200A
	s_cbranch_execz 64474                                      // 00000018BF10: BFA5FBDA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x457c>
	ds_load_b32 v17, v141                                      // 00000018BF14: D8D80000 1100008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BF1C: BF89FC07
	v_fma_f32 v9, v9, v17, v41                                 // 00000018BF20: D6130009 04A62309
	v_mad_u64_u32 v[17:18], null, 0x3000, v142, v[116:117]     // 00000018BF28: D6FE7C11 05D31CFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018BF34: BF870092
	v_mul_f32_e32 v9, 0x3b800000, v9                           // 00000018BF38: 101212FF 3B800000
	v_bfe_u32 v19, v9, 16, 1                                   // 00000018BF40: D6100013 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BF48: BF870001
	v_add3_u32 v9, v9, v19, 0x7fff                             // 00000018BF4C: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:96        // 00000018BF58: DC960060 007C0911
	s_or_b32 exec_lo, exec_lo, s14                             // 00000018BF60: 8C7E0E7E
	s_and_saveexec_b32 s10, s13                                // 00000018BF64: BE8A200D
	s_cbranch_execz 64455                                      // 00000018BF68: BFA5FBC7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4588>
	ds_load_b32 v9, v141 offset:8                              // 00000018BF6C: D8D80008 0900008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BF74: BF89FC07
	v_fma_f32 v9, v10, v9, v42                                 // 00000018BF78: D6130009 04AA130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BF80: BF870121
	v_mul_f32_e32 v17, 0x3b800000, v9                          // 00000018BF84: 102212FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v149, v[116:117]      // 00000018BF8C: D6FE7C09 05D32AFF 00003000
	v_bfe_u32 v18, v17, 16, 1                                  // 00000018BF98: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BFA0: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 00000018BFA4: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:96        // 00000018BFB0: DC960060 007C1109
	s_or_b32 exec_lo, exec_lo, s10                             // 00000018BFB8: 8C7E0A7E
	s_and_saveexec_b32 s10, s12                                // 00000018BFBC: BE8A200C
	s_cbranch_execz 64436                                      // 00000018BFC0: BFA5FBB4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4594>
	ds_load_b32 v9, v141 offset:16                             // 00000018BFC4: D8D80010 0900008D
	s_waitcnt lgkmcnt(0)                                       // 00000018BFCC: BF89FC07
	v_fma_f32 v9, v11, v9, v43                                 // 00000018BFD0: D6130009 04AE130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018BFD8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000018BFDC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v148, v[116:117]      // 00000018BFE4: D6FE7C09 05D328FF 00003000
	v_bfe_u32 v17, v11, 16, 1                                  // 00000018BFF0: D6100011 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018BFF8: BF870001
	v_add3_u32 v11, v11, v17, 0x7fff                           // 00000018BFFC: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 00000018C008: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s10                             // 00000018C010: 8C7E0A7E
	s_and_saveexec_b32 s10, s11                                // 00000018C014: BE8A200B
	s_cbranch_execz 64417                                      // 00000018C018: BFA5FBA1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x45a0>
	ds_load_b32 v9, v141 offset:24                             // 00000018C01C: D8D80018 0900008D
	s_waitcnt lgkmcnt(0)                                       // 00000018C024: BF89FC07
	v_fma_f32 v9, v12, v9, v44                                 // 00000018C028: D6130009 04B2130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018C030: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000018C034: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v147, v[116:117]      // 00000018C03C: D6FE7C09 05D326FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000018C048: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018C050: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000018C054: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 00000018C060: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s10                             // 00000018C068: 8C7E0A7E
	s_and_saveexec_b32 s10, s9                                 // 00000018C06C: BE8A2009
	s_cbranch_execz 64398                                      // 00000018C070: BFA5FB8E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x45ac>
	ds_load_b32 v9, v141 offset:32                             // 00000018C074: D8D80020 0900008D
	s_waitcnt lgkmcnt(0)                                       // 00000018C07C: BF89FC07
	v_fma_f32 v9, v13, v9, v45                                 // 00000018C080: D6130009 04B6130D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018C088: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000018C08C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v146, v[116:117]      // 00000018C094: D6FE7C09 05D324FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000018C0A0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018C0A8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000018C0AC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 00000018C0B8: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s10                             // 00000018C0C0: 8C7E0A7E
	s_and_saveexec_b32 s9, s1                                  // 00000018C0C4: BE892001
	s_cbranch_execz 64379                                      // 00000018C0C8: BFA5FB7B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x45b8>
	ds_load_b32 v9, v141 offset:40                             // 00000018C0CC: D8D80028 0900008D
	s_waitcnt lgkmcnt(0)                                       // 00000018C0D4: BF89FC07
	v_fma_f32 v9, v14, v9, v46                                 // 00000018C0D8: D6130009 04BA130E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018C0E0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000018C0E4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v145, v[116:117]      // 00000018C0EC: D6FE7C09 05D322FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000018C0F8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018C100: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000018C104: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 00000018C110: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s9                              // 00000018C118: 8C7E097E
	s_and_saveexec_b32 s1, s8                                  // 00000018C11C: BE812008
	s_cbranch_execz 64360                                      // 00000018C120: BFA5FB68 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x45c4>
	ds_load_b32 v9, v141 offset:48                             // 00000018C124: D8D80030 0900008D
	s_waitcnt lgkmcnt(0)                                       // 00000018C12C: BF89FC07
	v_fma_f32 v9, v15, v9, v47                                 // 00000018C130: D6130009 04BE130F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018C138: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 00000018C13C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v144, v[116:117]      // 00000018C144: D6FE7C09 05D320FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 00000018C150: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018C158: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000018C15C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:96        // 00000018C168: DC960060 007C0B09
	s_or_b32 exec_lo, exec_lo, s1                              // 00000018C170: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000018C174: BE812000
	s_cbranch_execnz 64341                                     // 00000018C178: BFA6FB55 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x45d0>
	s_branch 64358                                             // 00000018C17C: BFA0FB66 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4618>
	v_dual_mov_b32 v1, s48 :: v_dual_mov_b32 v2, s49           // 00000018C180: CA100030 01020031
	v_mov_b32_e32 v6, v127                                     // 00000018C188: 7E0C037F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018C18C: BF870092
	.long 0xd7006a00                                           // 00000018C190: D7006A00
	v_cndmask_b32_e32 v0, v1, v18, vcc_lo                      // 00000018C194: 02002501
	v_add_co_ci_u32_e64 v1, null, s19, v2, vcc_lo              // 00000018C198: D5207C01 01AA0413
	s_add_u32 s0, s33, s34                                     // 00000018C1A0: 80002221
	s_addc_u32 s1, s15, s35                                    // 00000018C1A4: 8201230F
	.long 0xd7006a00                                           // 00000018C1A8: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000018C1AC: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000018C1B0: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000018C1B4: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000018C1BC: BE810080
	.long 0xd7006a00                                           // 00000018C1C0: D7006A00
	v_cndmask_b32_e32 v1, v0, v114, vcc_lo                     // 00000018C1C4: 0202E500
	v_add_co_ci_u32_e64 v1, null, v1, v115, vcc_lo             // 00000018C1C8: D5207C01 01AAE701
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018C1D0: BF870092
	.long 0xd7006a00                                           // 00000018C1D4: D7006A00
	v_cndmask_b32_e32 v1, v0, v126, vcc_lo                     // 00000018C1D8: 0202FD00
	v_add_co_ci_u32_e64 v1, null, v1, v132, vcc_lo             // 00000018C1DC: D5207C01 01AB0901
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018C1E4: BF870092
	.long 0xd7006a00                                           // 00000018C1E8: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000018C1EC: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000018C1F0: D5207C01 01AA0211
	s_nop 0                                                    // 00000018C1F8: BF800000
	s_nop 0                                                    // 00000018C1FC: BF800000
	ds_load_b32 v2, v128                                       // 00000018C200: D8D80000 02000080
	v_add_nc_u32_e32 v6, 0x80, v6                              // 00000018C208: 4A0C0CFF 00000080
	v_add_nc_u32_e32 v128, 8, v128                             // 00000018C210: 4B010088
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000018C214: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v6                        // 00000018C218: 7C920CFF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 00000018C220: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000018C224: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 00000018C228: DC6A0000 007C0200
	.long 0xd7000000                                           // 00000018C230: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 00000018C234: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000018C23C: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000018C244: 917E017E
	s_cbranch_execnz 65517                                     // 00000018C248: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi1ELi4ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5900>
	s_nop 0                                                    // 00000018C24C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000018C250: BFB60003
	s_endpgm                                                   // 00000018C254: BFB00000
		...

