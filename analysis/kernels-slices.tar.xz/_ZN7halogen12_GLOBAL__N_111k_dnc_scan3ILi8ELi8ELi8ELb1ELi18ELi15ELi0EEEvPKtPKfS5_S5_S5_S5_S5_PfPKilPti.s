00000000000dd500 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000DD500: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000DD504: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000DD50C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000DD514: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000DD518: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000DD51C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000DD520: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000DD528: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000DD52C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000DD530: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000DD534: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000DD53C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000DD540: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000DD544: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000DD548: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DD54C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000DD550: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000DD554: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000DD558: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000DD55C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000DD564: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000DD56C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000DD570: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000DD574: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000DD578: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000DD57C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000DD580: 821E191E
	.long 0xd7001f02                                           // 0000000DD584: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000DD588: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000DD58C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000DD594: BE9E0080
	s_nop 0                                                    // 0000000DD598: BF800000
	s_nop 0                                                    // 0000000DD59C: BF800000
	s_nop 0                                                    // 0000000DD5A0: BF800000
	s_nop 0                                                    // 0000000DD5A4: BF800000
	s_nop 0                                                    // 0000000DD5A8: BF800000
	s_nop 0                                                    // 0000000DD5AC: BF800000
	s_nop 0                                                    // 0000000DD5B0: BF800000
	s_nop 0                                                    // 0000000DD5B4: BF800000
	s_nop 0                                                    // 0000000DD5B8: BF800000
	s_nop 0                                                    // 0000000DD5BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000DD5C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000DD5C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DD5CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000DD5D0: 300C1089
	.long 0xd7006a06                                           // 0000000DD5D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000DD5D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DD5DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000DD5E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000DD5E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000DD5F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000DD5F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000DD5FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000DD608: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000DD60C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000DD610: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000DD618: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000DD61C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000DD620: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000DD624: F4000780 F8000058
	v_or_b32_e32 v36, 0xffffff80, v0                           // 0000000DD62C: 384800FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000DD634: 32040084
	s_mov_b32 s0, 0                                            // 0000000DD638: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000DD63C: BF89FC07
	s_barrier                                                  // 0000000DD640: BFBD0000
	buffer_gl0_inv                                             // 0000000DD644: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000DD64C: BF02801E
	s_cbranch_scc1 12                                          // 0000000DD650: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000DD654: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000DD65C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000DD664: BF870002
	v_lshl_add_u32 v35, v5, 2, v3                              // 0000000DD668: D6460023 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000DD670: 7E060280
	v_lshlrev_b32_e32 v37, 2, v5                               // 0000000DD674: 304A0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000DD678: 916A007E
	s_cbranch_vccz 2                                           // 0000000DD67C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2201                                              // 0000000DD680: BFA00899 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23e8>
	v_lshlrev_b32_e32 v37, 2, v5                               // 0000000DD684: 304A0A82
	s_add_i32 s0, s30, 63                                      // 0000000DD688: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000DD68C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000DD694: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000DD698: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000DD69C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000DD6A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v38, 2, v0      // 0000000DD6A4: CA220080 03260082
	s_ashr_i32 s1, s0, 31                                      // 0000000DD6AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000DD6B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000DD6B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000DD6B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000DD6BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000DD6C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000DD6C4: 848A811A
	v_mad_u32_u24 v35, 0x44, v2, v37                           // 0000000DD6C8: D60B0023 049604FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000DD6D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000DD6D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000DD6DC: B00A0204
	.long 0xd7000b2a                                           // 0000000DD6E0: D7000B2A
	v_cndmask_b32_e32 v1, s34, v37, vcc_lo                     // 0000000DD6E4: 02024A22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000DD6E8: BF8704B1
	v_add_co_ci_u32_e64 v43, null, s35, 0, s11                 // 0000000DD6EC: D5207C2B 002D0023
	v_mad_u32_u24 v44, v2, s10, 0x3300                         // 0000000DD6F4: D60B002C 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000DD700: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v39, 0x4320, v38// 0000000DD704: CA20000B 0C264CFF 00004320
	v_or_b32_e32 v11, s10, v38                                 // 0000000DD710: 38164C0A
	.long 0xd7000a05                                           // 0000000DD714: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000DD718: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DD71C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000DD720: D5207C06 00290001
	.long 0xd7000107                                           // 0000000DD728: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000DD72C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DD730: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000DD734: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000DD73C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000DD740: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000DD744: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000DD74C: 84848E02
	.long 0xd700010b                                           // 0000000DD750: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000DD754: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000DD758: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000DD75C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000DD764: 8205050F
	.long 0xd700010d                                           // 0000000DD768: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000DD76C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DD770: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000DD774: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000DD77C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000DD780: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000DD788: D5207C10 00061880
	.long 0xd7000111                                           // 0000000DD790: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000DD794: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DD79C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000DD7A0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000DD7A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000DD7AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000DD7B4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000DD7BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000DD7C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000DD7C8: BF8700D1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000DD7CC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000DD7D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000DD7D8: 020216FF 000F0000
	v_or_b32_e32 v45, 0x2200, v1                               // 0000000DD7E0: 385A02FF 00002200
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000DD7E8: D5207C18 00061880
	.long 0xd7000119                                           // 0000000DD7F0: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000DD7F4: 020216FF 00120000
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000DD7FC: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000DD804: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000DD808: 020216FF 00150000
	v_add_nc_u32_e32 v40, 0x4420, v38                          // 0000000DD810: 4A504CFF 00004420
	.long 0xd44c0000                                           // 0000000DD818: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000DD81C: 020200FF 00000080
	v_add_nc_u32_e32 v41, 1, v2                                // 0000000DD824: 4A520481
	v_add_nc_u32_e32 v4, 0x2200, v35                           // 0000000DD828: 4A0846FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000DD830: D5207C1C 00061880
	v_add_nc_u32_e32 v46, 0x400, v45                           // 0000000DD838: 4A5C5AFF 00000400
	v_add_nc_u32_e32 v47, 0x600, v45                           // 0000000DD840: 4A5E5AFF 00000600
	v_add_nc_u32_e32 v48, 0x800, v45                           // 0000000DD848: 4A605AFF 00000800
	s_mov_b32 s5, 0                                            // 0000000DD850: BE850080
	s_mov_b32 s6, 0x44800000                                   // 0000000DD854: BE8600FF 44800000
	s_mov_b32 s7, 0x3a800000                                   // 0000000DD85C: BE8700FF 3A800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000DD864: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000DD868: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000DD870: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000DD874: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000DD878: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DD87C: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000DD880: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000DD884: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000DD888: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000DD88C: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000DD890: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000DD898: BE84206A
	s_cbranch_execz 77                                         // 0000000DD89C: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4d4>
	v_or_b32_e32 v29, s11, v0                                  // 0000000DD8A0: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DD8A4: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000DD8A8: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000DD8B0: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DD8B4: BF870091
	.long 0xd73c001d                                           // 0000000DD8B8: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000DD8BC: 02023A82
	.long 0xd700011d                                           // 0000000DD8C0: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000DD8C4: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000DD8C8: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000DD8CC: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000DD8D4: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DD8DC: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000DD8E0: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000DD8E4: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000DD8F0: BF8701A1
	v_fma_f32 v49, 0x3fb8aa3b, v29, -v32                       // 0000000DD8F4: D6130031 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v50, v32                                   // 0000000DD900: 7E644720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000DD904: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000DD910: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000DD914: BF870113
	v_dual_fmac_f32 v49, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v50// 0000000DD918: C80A3AFF 31206520 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000DD924: 083E451F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DD928: BF870122
	v_dual_fmac_f32 v33, 0x32a5705f, v30 :: v_dual_add_f32 v32, v32, v49// 0000000DD92C: C8083CFF 21206320 32A5705F
	.long 0xd41b0001                                           // 0000000DD938: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000DD93C: 02023CFF C2CE8ED0
	v_add_f32_e32 v31, v31, v33                                // 0000000DD944: 063E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000DD948: 7E421122
	v_cvt_i32_f32_e32 v34, v50                                 // 0000000DD94C: 7E441132
	v_exp_f32_e32 v32, v32                                     // 0000000DD950: 7E404B20
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000000DD954: BF870313
	v_exp_f32_e32 v31, v31                                     // 0000000DD958: 7E3E4B1F
	.long 0xd71c0020                                           // 0000000DD95C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000DD960: 02024520
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DD964: BF870095
	.long 0xd71c001f                                           // 0000000DD968: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000DD96C: 0202431F
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000DD970: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000DD978: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000DD97C: 02023AFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DD984: BF8700A1
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000DD988: D5010020 00064080
	.long 0xd41e0001                                           // 0000000DD990: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000DD994: 02023CFF 42B17218
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000DD99C: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000DD9A8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000DD9AC: 02023AFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DD9B4: BF870001
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000DD9B8: D501001D 000640FF 7F800000
	ds_store_b32 v39, v30                                      // 0000000DD9C4: D8340000 00001E27
	ds_store_b32 v40, v29                                      // 0000000DD9CC: D8340000 00001D28
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DD9D4: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000DD9D8: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000DD9E0: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000DD9E4: BF89FC07
	s_barrier                                                  // 0000000DD9E8: BFBD0000
	buffer_gl0_inv                                             // 0000000DD9EC: E0AC0000 00000000
	s_branch 15                                                // 0000000DD9F4: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DD9F8: 8C7E047E
	.long 0xd700011d                                           // 0000000DD9FC: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000DDA00: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDA08: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000DDA0C: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000DDA14: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000DDA18: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000DDA1C: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000DDA20: BF89FC07
	s_barrier                                                  // 0000000DDA24: BFBD0000
	buffer_gl0_inv                                             // 0000000DDA28: E0AC0000 00000000
	s_cbranch_scc1 185                                         // 0000000DDA30: BFA200B9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x818>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000DDA34: CA10011E 201E011D
	v_dual_mov_b32 v33, v38 :: v_dual_mov_b32 v34, v36         // 0000000DDA3C: CA100126 21220124
	s_mov_b32 s13, 0                                           // 0000000DDA44: BE8D0080
	s_nop 0                                                    // 0000000DDA48: BF800000
	s_nop 0                                                    // 0000000DDA4C: BF800000
	s_nop 0                                                    // 0000000DDA50: BF800000
	s_nop 0                                                    // 0000000DDA54: BF800000
	s_nop 0                                                    // 0000000DDA58: BF800000
	s_nop 0                                                    // 0000000DDA5C: BF800000
	s_nop 0                                                    // 0000000DDA60: BF800000
	s_nop 0                                                    // 0000000DDA64: BF800000
	s_nop 0                                                    // 0000000DDA68: BF800000
	s_nop 0                                                    // 0000000DDA6C: BF800000
	s_nop 0                                                    // 0000000DDA70: BF800000
	s_nop 0                                                    // 0000000DDA74: BF800000
	s_nop 0                                                    // 0000000DDA78: BF800000
	s_nop 0                                                    // 0000000DDA7C: BF800000
	global_load_b32 v49, v[31:32], off                         // 0000000DDA80: DC520000 317C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000DDA88: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000DDA90: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000DDA94: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DDA9C: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000DDAA0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000DDAA8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000DDAAC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000DDAB4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000DDAB8: BF8903F7
	ds_store_b32 v33, v49 offset:13056                         // 0000000DDABC: D8343300 00003121
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000DDAC4: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000DDACC: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000DDAD0: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000DDAD4: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000DDAD8: BF89FC07
	s_barrier                                                  // 0000000DDADC: BFBD0000
	buffer_gl0_inv                                             // 0000000DDAE0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000DDAE8: BE842000
	s_cbranch_execz 65474                                      // 0000000DDAEC: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f8>
	v_or3_b32 v31, s12, s11, v2                                // 0000000DDAF0: D658001F 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DDAF8: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 0000000DDAFC: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 0000000DDB04: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 0000000DDB08: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DDB0C: BF870091
	.long 0xd700011f                                           // 0000000DDB10: D700011F
	v_cndmask_b32_e32 v1, v42, v31, vcc_lo                     // 0000000DDB14: 02023F2A
	v_add_co_ci_u32_e64 v32, null, v43, v32, s1                // 0000000DDB18: D5207C20 0006412B
	s_mov_b32 s1, 0                                            // 0000000DDB20: BE810080
	global_load_b32 v31, v[31:32], off                         // 0000000DDB24: DC520000 1F7C001F
	v_mad_u64_u32 v[32:33], null, 0x44, s1, v[1:2]             // 0000000DDB2C: D6FE7C20 040402FF 00000044
	s_add_i32 s13, s1, 8                                       // 0000000DDB38: 810D8801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000DDB3C: B6810078
	ds_load_2addr_b32 v[33:34], v32 offset1:17                 // 0000000DDB40: D8DC1100 21000020
	ds_load_2addr_b32 v[49:50], v32 offset0:34 offset1:51      // 0000000DDB48: D8DC3322 31000020
	ds_load_2addr_b32 v[51:52], v32 offset0:68 offset1:85      // 0000000DDB50: D8DC5544 33000020
	ds_load_2addr_b32 v[53:54], v32 offset0:102 offset1:119    // 0000000DDB58: D8DC7766 35000020
	v_lshl_add_u32 v32, s1, 2, v44                             // 0000000DDB60: D6460020 04B10401
	s_mov_b32 s1, s13                                          // 0000000DDB68: BE81000D
	ds_load_2addr_b32 v[55:56], v32 offset1:1                  // 0000000DDB6C: D8DC0100 37000020
	ds_load_2addr_b32 v[57:58], v32 offset0:2 offset1:3        // 0000000DDB74: D8DC0302 39000020
	ds_load_2addr_b32 v[59:60], v32 offset0:4 offset1:5        // 0000000DDB7C: D8DC0504 3B000020
	ds_load_2addr_b32 v[61:62], v32 offset0:6 offset1:7        // 0000000DDB84: D8DC0706 3D000020
	s_waitcnt lgkmcnt(7)                                       // 0000000DDB8C: BF89FC77
	v_fma_mixlo_f16 v32, v33, s6, 0                            // 0000000DDB90: CC210020 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000DDB98: CC210022 02000D22
	s_waitcnt lgkmcnt(6)                                       // 0000000DDBA0: BF89FC67
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000DDBA4: CC210031 02000D31
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DDBAC: BF870193
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDBB0: CC200020 8A000F20
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDBB8: CC200022 8A000F22
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000DDBC0: BF870003
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDBC4: CC200031 8A000F31
	s_waitcnt lgkmcnt(3)                                       // 0000000DDBCC: BF89FC37
	v_fma_mixlo_f16 v33, v55, s6, 0                            // 0000000DDBD0: CC210021 02000D37
	v_fma_mixlo_f16 v55, v56, s6, 0                            // 0000000DDBD8: CC210037 02000D38
	s_waitcnt lgkmcnt(2)                                       // 0000000DDBE0: BF89FC27
	v_fma_mixlo_f16 v56, v57, s6, 0                            // 0000000DDBE4: CC210038 02000D39
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DDBEC: BF870193
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDBF0: CC200021 8A000F21
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDBF8: CC200037 8A000F37
	s_waitcnt vmcnt(0)                                         // 0000000DDC00: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000DDC04: BF870242
	v_fma_f32 v31, -v33, v32, v31                              // 0000000DDC08: D613001F 247E4121
	v_fma_mixlo_f16 v32, v50, s6, 0                            // 0000000DDC10: CC210020 02000D32
	v_fma_mixlo_f16 v33, v58, s6, 0                            // 0000000DDC18: CC210021 02000D3A
	v_fma_mix_f32 v50, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDC20: CC200032 8A000F38
	v_fma_f32 v31, -v55, v34, v31                              // 0000000DDC28: D613001F 247E4537
	v_fma_mixlo_f16 v34, v51, s6, 0                            // 0000000DDC30: CC210022 02000D33
	s_waitcnt lgkmcnt(1)                                       // 0000000DDC38: BF89FC17
	v_fma_mixlo_f16 v51, v59, s6, 0                            // 0000000DDC3C: CC210033 02000D3B
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDC44: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDC4C: CC200021 8A000F21
	v_fma_f32 v31, -v50, v49, v31                              // 0000000DDC54: D613001F 247E6332
	v_fma_mixlo_f16 v49, v52, s6, 0                            // 0000000DDC5C: CC210031 02000D34
	v_fma_mixlo_f16 v50, v60, s6, 0                            // 0000000DDC64: CC210032 02000D3C
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDC6C: CC200022 8A000F22
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDC74: CC200033 8A000F33
	v_fma_f32 v31, -v33, v32, v31                              // 0000000DDC7C: D613001F 247E4121
	v_fma_mixlo_f16 v32, v53, s6, 0                            // 0000000DDC84: CC210020 02000D35
	s_waitcnt lgkmcnt(0)                                       // 0000000DDC8C: BF89FC07
	v_fma_mixlo_f16 v33, v61, s6, 0                            // 0000000DDC90: CC210021 02000D3D
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDC98: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDCA0: CC200032 8A000F32
	v_fma_f32 v31, -v51, v34, v31                              // 0000000DDCA8: D613001F 247E4533
	v_fma_mixlo_f16 v34, v54, s6, 0                            // 0000000DDCB0: CC210022 02000D36
	v_fma_mixlo_f16 v51, v62, s6, 0                            // 0000000DDCB8: CC210033 02000D3E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDCC0: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDCC8: CC200021 8A000F21
	v_fma_f32 v31, -v50, v49, v31                              // 0000000DDCD0: D613001F 247E6332
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDCD8: CC200022 8A000F22
	v_fma_mix_f32 v49, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDCE0: CC200031 8A000F33
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DDCE8: BF870093
	v_fma_f32 v31, -v33, v32, v31                              // 0000000DDCEC: D613001F 247E4121
	v_fma_f32 v31, -v49, v34, v31                              // 0000000DDCF4: D613001F 247E4531
	s_cbranch_scc1 65419                                       // 0000000DDCFC: BFA2FF8B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x62c>
	v_mad_u64_u32 v[32:33], null, 0x44, s12, v[4:5]            // 0000000DDD00: D6FE7C20 041018FF 00000044
	ds_store_b32 v32, v31                                      // 0000000DDD0C: D8340000 00001F20
	s_branch 65336                                             // 0000000DDD14: BFA0FF38 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f8>
	v_mov_b32_e32 v30, v14                                     // 0000000DDD18: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000DDD1C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000DDD24: 7E3E0309
	v_mov_b32_e32 v49, v41                                     // 0000000DDD28: 7E620329
	s_mov_b32 s12, 0                                           // 0000000DDD2C: BE8C0080
	s_branch 21                                                // 0000000DDD30: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x888>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000DDD34: 8C7E0D7E
	.long 0xd700011f                                           // 0000000DDD38: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000DDD3C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DDD44: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000DDD48: D5207C20 00064080
	.long 0xd700011d                                           // 0000000DDD50: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000DDD54: 02023AFF 00000800
	v_add_nc_u32_e32 v49, 8, v49                               // 0000000DDD5C: 4A626288
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000DDD60: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000DDD68: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000DDD6C: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000DDD70: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000DDD74: BC7C0000
	s_barrier                                                  // 0000000DDD78: BFBD0000
	buffer_gl0_inv                                             // 0000000DDD7C: E0AC0000 00000000
	s_cbranch_scc1 217                                         // 0000000DDD84: BFA200D9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xbec>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000DDD88: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000DDD8C: CA100120 2220011F
	v_dual_mov_b32 v50, v38 :: v_dual_mov_b32 v51, v36         // 0000000DDD94: CA100126 32320124
	s_mov_b32 s13, 0                                           // 0000000DDD9C: BE8D0080
	s_nop 0                                                    // 0000000DDDA0: BF800000
	s_nop 0                                                    // 0000000DDDA4: BF800000
	s_nop 0                                                    // 0000000DDDA8: BF800000
	s_nop 0                                                    // 0000000DDDAC: BF800000
	s_nop 0                                                    // 0000000DDDB0: BF800000
	s_nop 0                                                    // 0000000DDDB4: BF800000
	s_nop 0                                                    // 0000000DDDB8: BF800000
	s_nop 0                                                    // 0000000DDDBC: BF800000
	global_load_b32 v52, v[33:34], off                         // 0000000DDDC0: DC520000 347C0021
	v_add_nc_u32_e32 v51, 0x80, v51                            // 0000000DDDC8: 4A6666FF 00000080
	.long 0xd7000121                                           // 0000000DDDD0: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000DDDD4: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DDDDC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000DDDE0: D5207C22 00064480
	.long 0xd4490004                                           // 0000000DDDE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v51, vcc_lo                   // 0000000DDDEC: 020266FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000DDDF4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000DDDF8: BF8903F7
	ds_store_b32 v50, v52 offset:13056                         // 0000000DDDFC: D8343300 00003432
	v_add_nc_u32_e32 v50, 0x204, v50                           // 0000000DDE04: 4A6464FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000DDE0C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000DDE10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000DDE14: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000DDE18: BF89FC07
	s_barrier                                                  // 0000000DDE1C: BFBD0000
	buffer_gl0_inv                                             // 0000000DDE20: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000DDE28: BE8D2000
	s_cbranch_execz 65473                                      // 0000000DDE2C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	v_or_b32_e32 v33, s12, v2                                  // 0000000DDE30: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DDE34: BF870091
	v_or_b32_e32 v50, s11, v33                                 // 0000000DDE38: 3864420B
	.long 0xd4440001                                           // 0000000DDE3C: D4440001
	v_cndmask_b32_e32 v1, s30, v50, vcc_lo                     // 0000000DDE40: 0202641E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000DDE44: 8B7E017E
	s_cbranch_execz 65466                                      // 0000000DDE48: BFA5FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	v_mov_b32_e32 v51, 0                                       // 0000000DDE4C: 7E660280
	s_mov_b32 s1, 0                                            // 0000000DDE50: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000DDE54: BF870009
	v_lshl_add_u32 v34, s1, 2, v44                             // 0000000DDE58: D6460022 04B10401
	s_add_i32 s4, s1, 8                                        // 0000000DDE60: 81048801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000DDE64: B6810078
	ds_load_2addr_b32 v[61:62], v34 offset1:1                  // 0000000DDE68: D8DC0100 3D000022
	ds_load_2addr_b32 v[63:64], v34 offset0:2 offset1:3        // 0000000DDE70: D8DC0302 3F000022
	ds_load_2addr_b32 v[65:66], v34 offset0:4 offset1:5        // 0000000DDE78: D8DC0504 41000022
	ds_load_2addr_b32 v[67:68], v34 offset0:6 offset1:7        // 0000000DDE80: D8DC0706 43000022
	v_mad_u64_u32 v[52:53], null, 0x44, s1, v[1:2]             // 0000000DDE88: D6FE7C34 040402FF 00000044
	s_mov_b32 s1, s4                                           // 0000000DDE94: BE810004
	ds_load_2addr_b32 v[53:54], v52 offset1:17                 // 0000000DDE98: D8DC1100 35000034
	ds_load_2addr_b32 v[55:56], v52 offset0:34 offset1:51      // 0000000DDEA0: D8DC3322 37000034
	ds_load_2addr_b32 v[57:58], v52 offset0:68 offset1:85      // 0000000DDEA8: D8DC5544 39000034
	ds_load_2addr_b32 v[59:60], v52 offset0:102 offset1:119    // 0000000DDEB0: D8DC7766 3B000034
	s_waitcnt lgkmcnt(7)                                       // 0000000DDEB8: BF89FC77
	v_fma_mixlo_f16 v52, v61, s6, 0                            // 0000000DDEBC: CC210034 02000D3D
	s_waitcnt lgkmcnt(6)                                       // 0000000DDEC4: BF89FC67
	v_fma_mixlo_f16 v61, v63, s6, 0                            // 0000000DDEC8: CC21003D 02000D3F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000DDED0: BF870002
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDED4: CC200034 8A000F34
	s_waitcnt lgkmcnt(3)                                       // 0000000DDEDC: BF89FC37
	v_fma_mixlo_f16 v34, v53, s6, 0                            // 0000000DDEE0: CC210022 02000D35
	v_fma_mixlo_f16 v53, v54, s6, 0                            // 0000000DDEE8: CC210035 02000D36
	v_fma_mixlo_f16 v54, v62, s6, 0                            // 0000000DDEF0: CC210036 02000D3E
	s_waitcnt lgkmcnt(2)                                       // 0000000DDEF8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000DDEFC: CC210037 02000D37
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDF04: CC200022 8A000F22
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDF0C: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDF14: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000DDF1C: BF870214
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDF20: CC200037 8A000F37
	v_fmac_f32_e32 v51, v52, v34                               // 0000000DDF28: 56664534
	v_fma_mixlo_f16 v34, v56, s6, 0                            // 0000000DDF2C: CC210022 02000D38
	v_fma_mixlo_f16 v52, v64, s6, 0                            // 0000000DDF34: CC210034 02000D40
	v_fma_mix_f32 v56, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDF3C: CC200038 8A000F3D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000DDF44: BF870004
	v_fmac_f32_e32 v51, v54, v53                               // 0000000DDF48: 56666B36
	s_waitcnt lgkmcnt(1)                                       // 0000000DDF4C: BF89FC17
	v_fma_mixlo_f16 v53, v57, s6, 0                            // 0000000DDF50: CC210035 02000D39
	v_fma_mixlo_f16 v54, v65, s6, 0                            // 0000000DDF58: CC210036 02000D41
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDF60: CC200022 8A000F22
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDF68: CC200034 8A000F34
	v_fmac_f32_e32 v51, v56, v55                               // 0000000DDF70: 56666F38
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000DDF74: CC210037 02000D3A
	v_fma_mixlo_f16 v56, v66, s6, 0                            // 0000000DDF7C: CC210038 02000D42
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDF84: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDF8C: CC200036 8A000F36
	v_fmac_f32_e32 v51, v52, v34                               // 0000000DDF94: 56664534
	s_waitcnt lgkmcnt(0)                                       // 0000000DDF98: BF89FC07
	v_fma_mixlo_f16 v34, v59, s6, 0                            // 0000000DDF9C: CC210022 02000D3B
	v_fma_mixlo_f16 v52, v67, s6, 0                            // 0000000DDFA4: CC210034 02000D43
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDFAC: CC200037 8A000F37
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDFB4: CC200038 8A000F38
	v_fmac_f32_e32 v51, v54, v53                               // 0000000DDFBC: 56666B36
	v_fma_mixlo_f16 v53, v60, s6, 0                            // 0000000DDFC0: CC210035 02000D3C
	v_fma_mixlo_f16 v54, v68, s6, 0                            // 0000000DDFC8: CC210036 02000D44
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDFD0: CC200022 8A000F22
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDFD8: CC200034 8A000F34
	v_fmac_f32_e32 v51, v56, v55                               // 0000000DDFE0: 56666F38
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDFE4: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DDFEC: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DDFF4: BF870093
	v_fmac_f32_e32 v51, v52, v34                               // 0000000DDFF8: 56664534
	v_fmac_f32_e32 v51, v54, v53                               // 0000000DDFFC: 56666B36
	s_cbranch_scc1 65428                                       // 0000000DE000: BFA2FF94 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x954>
	v_dual_mov_b32 v52, v1 :: v_dual_lshlrev_b32 v33, 2, v33   // 0000000DE004: CA220101 34204282
	s_mov_b32 s14, 0                                           // 0000000DE00C: BE8E0080
	ds_load_b32 v53, v33 offset:17440                          // 0000000DE010: D8D84420 35000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000DE018: CA10011E 2220011D
	s_waitcnt lgkmcnt(0)                                       // 0000000DE020: BF89FC07
	v_mul_f32_e32 v51, v51, v53                                // 0000000DE024: 10666B33
	v_mov_b32_e32 v53, v49                                     // 0000000DE028: 7E6A0331
	s_nop 0                                                    // 0000000DE02C: BF800000
	s_nop 0                                                    // 0000000DE030: BF800000
	s_nop 0                                                    // 0000000DE034: BF800000
	s_nop 0                                                    // 0000000DE038: BF800000
	s_nop 0                                                    // 0000000DE03C: BF800000
	global_load_b32 v54, v[33:34], off                         // 0000000DE040: DC520000 367C0021
	ds_load_b32 v55, v52 offset:8704                           // 0000000DE048: D8D82200 37000034
	v_add_nc_u32_e32 v53, -1, v53                              // 0000000DE050: 4A6A6AC1
	.long 0xd7000121                                           // 0000000DE054: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000DE058: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DE05C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000DE060: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000DE068: D44A0004
	v_cndmask_b32_e32 v1, 0, v53, vcc_lo                       // 0000000DE06C: 02026A80
	v_add_nc_u32_e32 v52, 0x44, v52                            // 0000000DE070: 4A6868FF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000DE078: 8C0E0E04
	s_waitcnt lgkmcnt(0)                                       // 0000000DE07C: BF89FC07
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000DE080: CC210037 02000D37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000DE088: BF8700B1
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE08C: CC200037 8A000F37
	s_waitcnt vmcnt(0)                                         // 0000000DE094: BF8903F7
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000DE098: CC210036 02000D36
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE0A0: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DE0A8: BF870001
	v_fmac_f32_e32 v51, v54, v55                               // 0000000DE0AC: 56666F36
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000DE0B0: 917E0E7E
	s_cbranch_execnz 65506                                     // 0000000DE0B4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb40>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000DE0B8: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DE0BC: BF870121
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000DE0C0: D6100034 02052133
	v_mad_u64_u32 v[33:34], null, 0x3000, v50, v[5:6]          // 0000000DE0C8: D6FE7C21 041664FF 00003000
	v_add3_u32 v50, v51, v52, 0x7fff                           // 0000000DE0D4: D6550032 03FE6933 00007FFF
	global_store_d16_hi_b16 v[33:34], v50, off                 // 0000000DE0E0: DC960000 007C3221
	s_branch 65298                                             // 0000000DE0E8: BFA0FF12 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000DE0EC: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v36                                     // 0000000DE0F4: 7E3E0324
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000DE0F8: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000DE0FC: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000DE104: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000DE108: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000DE110: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000DE118: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000DE11C: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000DE120: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000DE128: A0010401
	s_mov_b32 s4, 0                                            // 0000000DE12C: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000DE130: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000DE134: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000DE138: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000DE13C: BF870585
	.long 0xd71c001d                                           // 0000000DE140: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000DE144: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000DE148: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000DE14C: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000DE154: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000DE158: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000DE160: 980180C1
	v_mov_b32_e32 v29, v35                                     // 0000000DE164: 7E3A0323
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000DE168: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000DE174: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000DE17C: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DE184: BF870001
	.long 0xd4490001                                           // 0000000DE188: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000DE18C: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000DE194: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000DE198: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000DE19C: 1040411E
	ds_store_b32 v29, v32                                      // 0000000DE1A0: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000DE1A8: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000DE1B0: 917E047E
	s_cbranch_execnz 65519                                     // 0000000DE1B4: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc74>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DE1B8: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000DE1BC: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v38           // 0000000DE1C4: CA100080 1F200126
	v_mov_b32_e32 v33, v36                                     // 0000000DE1CC: 7E420324
	s_mov_b32 s10, 0                                           // 0000000DE1D0: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000DE1D4: BF89FC07
	s_barrier                                                  // 0000000DE1D8: BFBD0000
	buffer_gl0_inv                                             // 0000000DE1DC: E0AC0000 00000000
	s_nop 0                                                    // 0000000DE1E4: BF800000
	s_nop 0                                                    // 0000000DE1E8: BF800000
	s_nop 0                                                    // 0000000DE1EC: BF800000
	s_nop 0                                                    // 0000000DE1F0: BF800000
	s_nop 0                                                    // 0000000DE1F4: BF800000
	s_nop 0                                                    // 0000000DE1F8: BF800000
	s_nop 0                                                    // 0000000DE1FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000DE200: DC520000 227C001D
	ds_load_b32 v49, v31 offset:17184                          // 0000000DE208: D8D84320 3100001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000DE210: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000DE218: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000DE21C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000DE224: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000DE228: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000DE230: BF870004
	.long 0xd4490004                                           // 0000000DE234: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000DE238: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000DE240: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DE244: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000DE248: 10446322
	ds_store_b32 v32, v34 offset:13056                         // 0000000DE24C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000DE254: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000DE25C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000DE260: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000DE264: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000DE268: BF89FC07
	s_barrier                                                  // 0000000DE26C: BFBD0000
	buffer_gl0_inv                                             // 0000000DE270: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v45 offset1:17                 // 0000000DE278: D8DC1100 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:34 offset1:51      // 0000000DE280: D8DC3322 1F00002D
	ds_load_2addr_b32 v[33:34], v45 offset0:68 offset1:85      // 0000000DE288: D8DC5544 2100002D
	ds_load_2addr_b32 v[49:50], v45 offset0:102 offset1:119    // 0000000DE290: D8DC7766 3100002D
	v_mov_b32_e32 v51, v0                                      // 0000000DE298: 7E660300
	s_mov_b32 s4, 0                                            // 0000000DE29C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000DE2A0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000DE2A4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000DE2AC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000DE2B4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000DE2B8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000DE2C0: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000DE2C8: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000DE2CC: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000DE2D4: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000DE2DC: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000DE2E0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000DE2E8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE2F0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE2F8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE300: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE308: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE310: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE318: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE320: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE328: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000DE330: 326C6684
	.long 0xd4490001                                           // 0000000DE334: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000DE338: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000DE340: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000DE344: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000DE348: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000DE354: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000DE358: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000DE360: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000DE368: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000DE370: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000DE378: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000DE380: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000DE388: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000DE390: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000DE398: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000DE39C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000DE3A4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000DE3A8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000DE3B0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000DE3B8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000DE3C0: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000DE3C4: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE3CC: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE3D4: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000DE3DC: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE3E4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE3EC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE3F4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000DE3FC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE400: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000DE404: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000DE408: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000DE40C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000DE414: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000DE418: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000DE41C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000DE420: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE428: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000DE430: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000DE438: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DE43C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE440: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE448: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE450: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000DE454: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000DE458: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000DE45C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DE464: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000DE468: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000DE470: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000DE478: 917E047E
	s_cbranch_execnz 65452                                     // 0000000DE47C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe30>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DE480: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v31, v38         // 0000000DE484: CA100110 1E1E0126
	v_dual_mov_b32 v29, v15 :: v_dual_mov_b32 v32, 0           // 0000000DE48C: CA10010F 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000DE494: 7E420324
	s_mov_b32 s10, 0                                           // 0000000DE498: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000DE49C: BF89FC07
	s_barrier                                                  // 0000000DE4A0: BFBD0000
	buffer_gl0_inv                                             // 0000000DE4A4: E0AC0000 00000000
	s_nop 0                                                    // 0000000DE4AC: BF800000
	s_nop 0                                                    // 0000000DE4B0: BF800000
	s_nop 0                                                    // 0000000DE4B4: BF800000
	s_nop 0                                                    // 0000000DE4B8: BF800000
	s_nop 0                                                    // 0000000DE4BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000DE4C0: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17216                          // 0000000DE4C8: D8D84340 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000DE4D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000DE4D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000DE4DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000DE4E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000DE4E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000DE4F0: BF870004
	.long 0xd4490004                                           // 0000000DE4F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000DE4F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000DE500: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DE504: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000DE508: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000DE50C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000DE514: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000DE51C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000DE520: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000DE524: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000DE528: BF89FC07
	s_barrier                                                  // 0000000DE52C: BFBD0000
	buffer_gl0_inv                                             // 0000000DE530: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v45 offset0:136 offset1:153    // 0000000DE538: D8DC9988 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:170 offset1:187    // 0000000DE540: D8DCBBAA 1F00002D
	ds_load_2addr_b32 v[33:34], v45 offset0:204 offset1:221    // 0000000DE548: D8DCDDCC 2100002D
	ds_load_2addr_b32 v[49:50], v45 offset0:238 offset1:255    // 0000000DE550: D8DCFFEE 3100002D
	v_mov_b32_e32 v51, v0                                      // 0000000DE558: 7E660300
	s_mov_b32 s4, 0                                            // 0000000DE55C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000DE560: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000DE564: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000DE56C: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000DE574: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000DE578: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000DE580: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000DE588: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000DE58C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000DE594: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000DE59C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000DE5A0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000DE5A8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE5B0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE5B8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE5C0: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE5C8: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE5D0: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE5D8: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE5E0: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE5E8: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000DE5F0: 326C6684
	.long 0xd4490001                                           // 0000000DE5F4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000DE5F8: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000DE600: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000DE604: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000DE608: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000DE614: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000DE618: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000DE620: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000DE628: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000DE630: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000DE638: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000DE640: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000DE648: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000DE650: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000DE658: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000DE65C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000DE664: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000DE668: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000DE670: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000DE678: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000DE680: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000DE684: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE68C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE694: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000DE69C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE6A4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE6AC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE6B4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000DE6BC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE6C0: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000DE6C4: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000DE6C8: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000DE6CC: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000DE6D4: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000DE6D8: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000DE6DC: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000DE6E0: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE6E8: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000DE6F0: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000DE6F8: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DE6FC: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE700: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE708: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE710: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000DE714: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000DE718: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000DE71C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DE724: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000DE728: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000DE730: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000DE738: 917E047E
	s_cbranch_execnz 65452                                     // 0000000DE73C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10f0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DE740: 8C7E047E
	v_mov_b32_e32 v30, v18                                     // 0000000DE744: 7E3C0312
	v_mov_b32_e32 v31, v38                                     // 0000000DE748: 7E3E0326
	v_dual_mov_b32 v29, v17 :: v_dual_mov_b32 v32, 0           // 0000000DE74C: CA100111 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000DE754: 7E420324
	s_mov_b32 s10, 0                                           // 0000000DE758: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000DE75C: BF89FC07
	s_barrier                                                  // 0000000DE760: BFBD0000
	buffer_gl0_inv                                             // 0000000DE764: E0AC0000 00000000
	s_nop 0                                                    // 0000000DE76C: BF800000
	s_nop 0                                                    // 0000000DE770: BF800000
	s_nop 0                                                    // 0000000DE774: BF800000
	s_nop 0                                                    // 0000000DE778: BF800000
	s_nop 0                                                    // 0000000DE77C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000DE780: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17248                          // 0000000DE788: D8D84360 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000DE790: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000DE798: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000DE79C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000DE7A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000DE7A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000DE7B0: BF870004
	.long 0xd4490004                                           // 0000000DE7B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000DE7B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000DE7C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DE7C4: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000DE7C8: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000DE7CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000DE7D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000DE7DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000DE7E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1280>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000DE7E4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000DE7E8: BF89FC07
	s_barrier                                                  // 0000000DE7EC: BFBD0000
	buffer_gl0_inv                                             // 0000000DE7F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v46 offset0:16 offset1:33      // 0000000DE7F8: D8DC2110 1D00002E
	ds_load_2addr_b32 v[31:32], v46 offset0:50 offset1:67      // 0000000DE800: D8DC4332 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:84 offset1:101     // 0000000DE808: D8DC6554 2100002E
	ds_load_2addr_b32 v[49:50], v46 offset0:118 offset1:135    // 0000000DE810: D8DC8776 3100002E
	v_mov_b32_e32 v51, v0                                      // 0000000DE818: 7E660300
	s_mov_b32 s4, 0                                            // 0000000DE81C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000DE820: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000DE824: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000DE82C: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000DE834: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000DE838: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000DE840: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000DE848: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000DE84C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000DE854: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000DE85C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000DE860: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000DE868: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE870: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE878: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE880: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE888: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE890: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE898: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE8A0: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE8A8: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000DE8B0: 326C6684
	.long 0xd4490001                                           // 0000000DE8B4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000DE8B8: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000DE8C0: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000DE8C4: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000DE8C8: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000DE8D4: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000DE8D8: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000DE8E0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000DE8E8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000DE8F0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000DE8F8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000DE900: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000DE908: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000DE910: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000DE918: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000DE91C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000DE924: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000DE928: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000DE930: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000DE938: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000DE940: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000DE944: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE94C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE954: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000DE95C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE964: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE96C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE974: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000DE97C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE980: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000DE984: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000DE988: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000DE98C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000DE994: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000DE998: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000DE99C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000DE9A0: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE9A8: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000DE9B0: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000DE9B8: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DE9BC: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE9C0: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DE9C8: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DE9D0: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000DE9D4: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000DE9D8: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000DE9DC: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DE9E4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000DE9E8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000DE9F0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000DE9F8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000DE9FC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13b0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DEA00: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v31, v38         // 0000000DEA04: CA100114 1E1E0126
	v_dual_mov_b32 v29, v19 :: v_dual_mov_b32 v32, 0           // 0000000DEA0C: CA100113 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000DEA14: 7E420324
	s_mov_b32 s10, 0                                           // 0000000DEA18: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000DEA1C: BF89FC07
	s_barrier                                                  // 0000000DEA20: BFBD0000
	buffer_gl0_inv                                             // 0000000DEA24: E0AC0000 00000000
	s_nop 0                                                    // 0000000DEA2C: BF800000
	s_nop 0                                                    // 0000000DEA30: BF800000
	s_nop 0                                                    // 0000000DEA34: BF800000
	s_nop 0                                                    // 0000000DEA38: BF800000
	s_nop 0                                                    // 0000000DEA3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000DEA40: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17280                          // 0000000DEA48: D8D84380 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000DEA50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000DEA58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000DEA5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000DEA64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000DEA68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000DEA70: BF870004
	.long 0xd4490004                                           // 0000000DEA74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000DEA78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000DEA80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DEA84: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000DEA88: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000DEA8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000DEA94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000DEA9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000DEAA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1540>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000DEAA4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000DEAA8: BF89FC07
	s_barrier                                                  // 0000000DEAAC: BFBD0000
	buffer_gl0_inv                                             // 0000000DEAB0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v46 offset0:152 offset1:169    // 0000000DEAB8: D8DCA998 1D00002E
	ds_load_2addr_b32 v[31:32], v46 offset0:186 offset1:203    // 0000000DEAC0: D8DCCBBA 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:220 offset1:237    // 0000000DEAC8: D8DCEDDC 2100002E
	ds_load_2addr_b32 v[49:50], v47 offset0:126 offset1:143    // 0000000DEAD0: D8DC8F7E 3100002F
	v_mov_b32_e32 v51, v0                                      // 0000000DEAD8: 7E660300
	s_mov_b32 s4, 0                                            // 0000000DEADC: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000DEAE0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000DEAE4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000DEAEC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000DEAF4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000DEAF8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000DEB00: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000DEB08: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000DEB0C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000DEB14: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000DEB1C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000DEB20: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000DEB28: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEB30: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEB38: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEB40: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEB48: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEB50: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEB58: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEB60: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEB68: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000DEB70: 326C6684
	.long 0xd4490001                                           // 0000000DEB74: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000DEB78: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000DEB80: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000DEB84: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000DEB88: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000DEB94: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000DEB98: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000DEBA0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000DEBA8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000DEBB0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000DEBB8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000DEBC0: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000DEBC8: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000DEBD0: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000DEBD8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000DEBDC: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000DEBE4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000DEBE8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000DEBF0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000DEBF8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000DEC00: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000DEC04: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEC0C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEC14: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000DEC1C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEC24: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEC2C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEC34: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000DEC3C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DEC40: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000DEC44: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000DEC48: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000DEC4C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000DEC54: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000DEC58: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000DEC5C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000DEC60: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEC68: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000DEC70: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000DEC78: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DEC7C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEC80: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEC88: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DEC90: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000DEC94: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000DEC98: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000DEC9C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DECA4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000DECA8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000DECB0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000DECB8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000DECBC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1670>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DECC0: 8C7E047E
	v_mov_b32_e32 v30, v22                                     // 0000000DECC4: 7E3C0316
	v_mov_b32_e32 v31, v38                                     // 0000000DECC8: 7E3E0326
	v_dual_mov_b32 v29, v21 :: v_dual_mov_b32 v32, 0           // 0000000DECCC: CA100115 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000DECD4: 7E420324
	s_mov_b32 s10, 0                                           // 0000000DECD8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000DECDC: BF89FC07
	s_barrier                                                  // 0000000DECE0: BFBD0000
	buffer_gl0_inv                                             // 0000000DECE4: E0AC0000 00000000
	s_nop 0                                                    // 0000000DECEC: BF800000
	s_nop 0                                                    // 0000000DECF0: BF800000
	s_nop 0                                                    // 0000000DECF4: BF800000
	s_nop 0                                                    // 0000000DECF8: BF800000
	s_nop 0                                                    // 0000000DECFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000DED00: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17312                          // 0000000DED08: D8D843A0 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000DED10: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000DED18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000DED1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000DED24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000DED28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000DED30: BF870004
	.long 0xd4490004                                           // 0000000DED34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000DED38: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000DED40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DED44: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000DED48: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000DED4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000DED54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000DED5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000DED60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1800>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000DED64: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000DED68: BF89FC07
	s_barrier                                                  // 0000000DED6C: BFBD0000
	buffer_gl0_inv                                             // 0000000DED70: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v48 offset0:32 offset1:49      // 0000000DED78: D8DC3120 1D000030
	ds_load_2addr_b32 v[31:32], v48 offset0:66 offset1:83      // 0000000DED80: D8DC5342 1F000030
	ds_load_2addr_b32 v[33:34], v48 offset0:100 offset1:117    // 0000000DED88: D8DC7564 21000030
	ds_load_2addr_b32 v[49:50], v48 offset0:134 offset1:151    // 0000000DED90: D8DC9786 31000030
	v_mov_b32_e32 v51, v0                                      // 0000000DED98: 7E660300
	s_mov_b32 s4, 0                                            // 0000000DED9C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000DEDA0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000DEDA4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000DEDAC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000DEDB4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000DEDB8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000DEDC0: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000DEDC8: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000DEDCC: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000DEDD4: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000DEDDC: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000DEDE0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000DEDE8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEDF0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEDF8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEE00: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEE08: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEE10: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEE18: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEE20: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEE28: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000DEE30: 326C6684
	.long 0xd4490001                                           // 0000000DEE34: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000DEE38: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000DEE40: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000DEE44: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000DEE48: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000DEE54: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000DEE58: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000DEE60: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000DEE68: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000DEE70: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000DEE78: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000DEE80: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000DEE88: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000DEE90: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000DEE98: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000DEE9C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000DEEA4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000DEEA8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000DEEB0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000DEEB8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000DEEC0: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000DEEC4: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEECC: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEED4: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000DEEDC: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEEE4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEEEC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEEF4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000DEEFC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DEF00: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000DEF04: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000DEF08: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000DEF0C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000DEF14: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000DEF18: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000DEF1C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000DEF20: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEF28: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000DEF30: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000DEF38: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DEF3C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEF40: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DEF48: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DEF50: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000DEF54: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000DEF58: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000DEF5C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DEF64: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000DEF68: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000DEF70: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000DEF78: 917E047E
	s_cbranch_execnz 65452                                     // 0000000DEF7C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1930>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DEF80: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v31, v38         // 0000000DEF84: CA100118 1E1E0126
	v_dual_mov_b32 v29, v23 :: v_dual_mov_b32 v32, 0           // 0000000DEF8C: CA100117 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000DEF94: 7E420324
	s_mov_b32 s10, 0                                           // 0000000DEF98: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000DEF9C: BF89FC07
	s_barrier                                                  // 0000000DEFA0: BFBD0000
	buffer_gl0_inv                                             // 0000000DEFA4: E0AC0000 00000000
	s_nop 0                                                    // 0000000DEFAC: BF800000
	s_nop 0                                                    // 0000000DEFB0: BF800000
	s_nop 0                                                    // 0000000DEFB4: BF800000
	s_nop 0                                                    // 0000000DEFB8: BF800000
	s_nop 0                                                    // 0000000DEFBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000DEFC0: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17344                          // 0000000DEFC8: D8D843C0 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000DEFD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000DEFD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000DEFDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000DEFE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000DEFE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000DEFF0: BF870004
	.long 0xd4490004                                           // 0000000DEFF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000DEFF8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000DF000: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DF004: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000DF008: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000DF00C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000DF014: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000DF01C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000DF020: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ac0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000DF024: 8C7E0A7E
	v_add_nc_u32_e32 v31, 0xc00, v45                           // 0000000DF028: 4A3E5AFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000DF030: BF89FC07
	s_barrier                                                  // 0000000DF034: BFBD0000
	buffer_gl0_inv                                             // 0000000DF038: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v48 offset0:168 offset1:185    // 0000000DF040: D8DCB9A8 1D000030
	ds_load_2addr_b32 v[32:33], v48 offset0:202 offset1:219    // 0000000DF048: D8DCDBCA 20000030
	ds_load_2addr_b32 v[49:50], v48 offset0:236 offset1:253    // 0000000DF050: D8DCFDEC 31000030
	ds_load_2addr_b32 v[51:52], v31 offset0:14 offset1:31      // 0000000DF058: D8DC1F0E 3300001F
	s_mov_b32 s4, 0                                            // 0000000DF060: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000DF064: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000DF068: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000DF070: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000DF078: BF89FC27
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000DF07C: CC210020 02000D20
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000DF084: CC210021 02000D21
	s_waitcnt lgkmcnt(1)                                       // 0000000DF08C: BF89FC17
	v_fma_mixlo_f16 v34, v49, s6, 0                            // 0000000DF090: CC210022 02000D31
	v_fma_mixlo_f16 v49, v50, s6, 0                            // 0000000DF098: CC210031 02000D32
	s_waitcnt lgkmcnt(0)                                       // 0000000DF0A0: BF89FC07
	v_fma_mixlo_f16 v50, v51, s6, 0                            // 0000000DF0A4: CC210032 02000D33
	v_fma_mixlo_f16 v51, v52, s6, 0                            // 0000000DF0AC: CC210033 02000D34
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF0B4: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF0BC: CC20001E 8A000F1E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF0C4: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF0CC: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF0D4: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF0DC: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF0E4: CC200032 8A000F32
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF0EC: CC200033 8A000F33
	v_mov_b32_e32 v52, v0                                      // 0000000DF0F4: 7E680300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DF0F8: BF870121
	v_lshrrev_b32_e32 v55, 4, v52                              // 0000000DF0FC: 326E6884
	.long 0xd4490001                                           // 0000000DF100: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v52, vcc_lo                   // 0000000DF104: 020268FF 0000077F
	v_lshlrev_b32_e32 v60, 2, v55                              // 0000000DF10C: 30786E82
	v_mad_u64_u32 v[55:56], null, 0x44, v55, v[1:2]            // 0000000DF110: D6FE7C37 04066EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000DF11C: 8C040401
	v_add_nc_u32_e32 v53, 0x3200, v60                          // 0000000DF120: 4A6A78FF 00003200
	v_add_nc_u32_e32 v56, 0x3600, v60                          // 0000000DF128: 4A7078FF 00003600
	v_add_nc_u32_e32 v58, 0x3a00, v60                          // 0000000DF130: 4A7478FF 00003A00
	v_add_nc_u32_e32 v60, 0x3e00, v60                          // 0000000DF138: 4A7878FF 00003E00
	ds_load_b32 v61, v55                                       // 0000000DF140: D8D80000 3D000037
	ds_load_2addr_b32 v[56:57], v56 offset0:66 offset1:195     // 0000000DF148: D8DCC342 38000038
	ds_load_2addr_b32 v[53:54], v53 offset0:64 offset1:193     // 0000000DF150: D8DCC140 35000035
	ds_load_2addr_b32 v[58:59], v58 offset0:68 offset1:197     // 0000000DF158: D8DCC544 3A00003A
	s_waitcnt lgkmcnt(2)                                       // 0000000DF160: BF89FC27
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000DF164: CC210038 02000D38
	s_waitcnt lgkmcnt(1)                                       // 0000000DF16C: BF89FC17
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000DF170: CC210035 02000D35
	v_fma_mixlo_f16 v62, v54, s6, 0                            // 0000000DF178: CC21003E 02000D36
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000DF180: CC210039 02000D39
	s_waitcnt lgkmcnt(0)                                       // 0000000DF188: BF89FC07
	v_fma_mixlo_f16 v58, v58, s6, 0                            // 0000000DF18C: CC21003A 02000D3A
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF194: CC200038 8A000F38
	v_fma_mix_f32 v63, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF19C: CC20003F 8A000F35
	ds_load_2addr_b32 v[53:54], v60 offset0:70 offset1:199     // 0000000DF1A4: D8DCC746 3500003C
	v_fma_mix_f32 v60, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF1AC: CC20003C 8A000F3E
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF1B4: CC200039 8A000F39
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF1BC: CC20003A 8A000F3A
	v_fmac_f32_e32 v61, v63, v29                               // 0000000DF1C4: 567A3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF1C8: BF870091
	v_fmac_f32_e32 v61, v60, v30                               // 0000000DF1CC: 567A3D3C
	v_fmac_f32_e32 v61, v56, v32                               // 0000000DF1D0: 567A4138
	v_fma_mixlo_f16 v56, v59, s6, 0                            // 0000000DF1D4: CC210038 02000D3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000DF1DC: BF8701B2
	v_fmac_f32_e32 v61, v57, v33                               // 0000000DF1E0: 567A4339
	s_waitcnt lgkmcnt(0)                                       // 0000000DF1E4: BF89FC07
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000DF1E8: CC210035 02000D35
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF1F0: CC200038 8A000F38
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000DF1F8: CC210036 02000D36
	v_fmac_f32_e32 v61, v58, v34                               // 0000000DF200: 567A453A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DF204: BF870194
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF208: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF210: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF218: BF870093
	v_fmac_f32_e32 v61, v56, v49                               // 0000000DF21C: 567A6338
	v_fmac_f32_e32 v61, v53, v50                               // 0000000DF220: 567A6535
	v_add_nc_u32_e32 v53, 0x80, v52                            // 0000000DF224: 4A6A68FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DF22C: BF870001
	v_dual_fmac_f32 v61, v54, v51 :: v_dual_mov_b32 v52, v53   // 0000000DF230: C8106736 3D340135
	ds_store_b32 v55, v61                                      // 0000000DF238: D8340000 00003D37
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000DF240: 917E047E
	s_cbranch_execnz 65452                                     // 0000000DF244: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1bf8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DF248: 8C7E047E
	v_mov_b32_e32 v30, v26                                     // 0000000DF24C: 7E3C031A
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v29, v25         // 0000000DF250: CA100126 201C0119
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 0000000DF258: CA100080 21220124
	s_mov_b32 s10, 0                                           // 0000000DF260: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000DF264: BF89FC07
	s_barrier                                                  // 0000000DF268: BFBD0000
	buffer_gl0_inv                                             // 0000000DF26C: E0AC0000 00000000
	s_nop 0                                                    // 0000000DF274: BF800000
	s_nop 0                                                    // 0000000DF278: BF800000
	s_nop 0                                                    // 0000000DF27C: BF800000
	global_load_b32 v49, v[29:30], off                         // 0000000DF280: DC520000 317C001D
	ds_load_b32 v50, v33 offset:17376                          // 0000000DF288: D8D843E0 32000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000DF290: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000DF298: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000DF29C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000DF2A4: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000DF2A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000DF2B0: BF870004
	.long 0xd4490004                                           // 0000000DF2B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000DF2B8: 020244FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000DF2C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DF2C4: BF890007
	v_mul_f32_e32 v49, v49, v50                                // 0000000DF2C8: 10626531
	ds_store_b32 v32, v49 offset:13056                         // 0000000DF2CC: D8343300 00003120
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000DF2D4: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000DF2DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000DF2E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000DF2E4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000DF2E8: BF89FC07
	s_barrier                                                  // 0000000DF2EC: BFBD0000
	buffer_gl0_inv                                             // 0000000DF2F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:48 offset1:65      // 0000000DF2F8: D8DC4130 1D00001F
	ds_load_2addr_b32 v[32:33], v31 offset0:82 offset1:99      // 0000000DF300: D8DC6352 2000001F
	ds_load_2addr_b32 v[49:50], v31 offset0:116 offset1:133    // 0000000DF308: D8DC8574 3100001F
	ds_load_2addr_b32 v[51:52], v31 offset0:150 offset1:167    // 0000000DF310: D8DCA796 3300001F
	s_mov_b32 s4, 0                                            // 0000000DF318: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000DF31C: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000DF320: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000DF328: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000DF330: BF89FC27
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000DF334: CC210020 02000D20
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000DF33C: CC210021 02000D21
	s_waitcnt lgkmcnt(1)                                       // 0000000DF344: BF89FC17
	v_fma_mixlo_f16 v34, v49, s6, 0                            // 0000000DF348: CC210022 02000D31
	v_fma_mixlo_f16 v49, v50, s6, 0                            // 0000000DF350: CC210031 02000D32
	s_waitcnt lgkmcnt(0)                                       // 0000000DF358: BF89FC07
	v_fma_mixlo_f16 v50, v51, s6, 0                            // 0000000DF35C: CC210032 02000D33
	v_fma_mixlo_f16 v51, v52, s6, 0                            // 0000000DF364: CC210033 02000D34
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF36C: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF374: CC20001E 8A000F1E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF37C: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF384: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF38C: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF394: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF39C: CC200032 8A000F32
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF3A4: CC200033 8A000F33
	v_mov_b32_e32 v52, v0                                      // 0000000DF3AC: 7E680300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000DF3B0: BF870121
	v_lshrrev_b32_e32 v55, 4, v52                              // 0000000DF3B4: 326E6884
	.long 0xd4490001                                           // 0000000DF3B8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v52, vcc_lo                   // 0000000DF3BC: 020268FF 0000077F
	v_lshlrev_b32_e32 v60, 2, v55                              // 0000000DF3C4: 30786E82
	v_mad_u64_u32 v[55:56], null, 0x44, v55, v[1:2]            // 0000000DF3C8: D6FE7C37 04066EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000DF3D4: 8C040401
	v_add_nc_u32_e32 v53, 0x3200, v60                          // 0000000DF3D8: 4A6A78FF 00003200
	v_add_nc_u32_e32 v56, 0x3600, v60                          // 0000000DF3E0: 4A7078FF 00003600
	v_add_nc_u32_e32 v58, 0x3a00, v60                          // 0000000DF3E8: 4A7478FF 00003A00
	v_add_nc_u32_e32 v60, 0x3e00, v60                          // 0000000DF3F0: 4A7878FF 00003E00
	ds_load_b32 v61, v55                                       // 0000000DF3F8: D8D80000 3D000037
	ds_load_2addr_b32 v[56:57], v56 offset0:66 offset1:195     // 0000000DF400: D8DCC342 38000038
	ds_load_2addr_b32 v[53:54], v53 offset0:64 offset1:193     // 0000000DF408: D8DCC140 35000035
	ds_load_2addr_b32 v[58:59], v58 offset0:68 offset1:197     // 0000000DF410: D8DCC544 3A00003A
	s_waitcnt lgkmcnt(2)                                       // 0000000DF418: BF89FC27
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000DF41C: CC210038 02000D38
	s_waitcnt lgkmcnt(1)                                       // 0000000DF424: BF89FC17
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000DF428: CC210035 02000D35
	v_fma_mixlo_f16 v62, v54, s6, 0                            // 0000000DF430: CC21003E 02000D36
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000DF438: CC210039 02000D39
	s_waitcnt lgkmcnt(0)                                       // 0000000DF440: BF89FC07
	v_fma_mixlo_f16 v58, v58, s6, 0                            // 0000000DF444: CC21003A 02000D3A
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF44C: CC200038 8A000F38
	v_fma_mix_f32 v63, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF454: CC20003F 8A000F35
	ds_load_2addr_b32 v[53:54], v60 offset0:70 offset1:199     // 0000000DF45C: D8DCC746 3500003C
	v_fma_mix_f32 v60, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF464: CC20003C 8A000F3E
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF46C: CC200039 8A000F39
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF474: CC20003A 8A000F3A
	v_fmac_f32_e32 v61, v63, v29                               // 0000000DF47C: 567A3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF480: BF870091
	v_fmac_f32_e32 v61, v60, v30                               // 0000000DF484: 567A3D3C
	v_fmac_f32_e32 v61, v56, v32                               // 0000000DF488: 567A4138
	v_fma_mixlo_f16 v56, v59, s6, 0                            // 0000000DF48C: CC210038 02000D3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000DF494: BF8701B2
	v_fmac_f32_e32 v61, v57, v33                               // 0000000DF498: 567A4339
	s_waitcnt lgkmcnt(0)                                       // 0000000DF49C: BF89FC07
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000DF4A0: CC210035 02000D35
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF4A8: CC200038 8A000F38
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000DF4B0: CC210036 02000D36
	v_fmac_f32_e32 v61, v58, v34                               // 0000000DF4B8: 567A453A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DF4BC: BF870194
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF4C0: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF4C8: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF4D0: BF870093
	v_fmac_f32_e32 v61, v56, v49                               // 0000000DF4D4: 567A6338
	v_fmac_f32_e32 v61, v53, v50                               // 0000000DF4D8: 567A6535
	v_add_nc_u32_e32 v53, 0x80, v52                            // 0000000DF4DC: 4A6A68FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DF4E4: BF870001
	v_dual_fmac_f32 v61, v54, v51 :: v_dual_mov_b32 v52, v53   // 0000000DF4E8: C8106736 3D340135
	ds_store_b32 v55, v61                                      // 0000000DF4F0: D8340000 00003D37
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000DF4F8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000DF4FC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1eb0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DF500: 8C7E047E
	v_mov_b32_e32 v30, v28                                     // 0000000DF504: 7E3C031C
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v29, v27         // 0000000DF508: CA100126 201C011B
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 0000000DF510: CA100080 21220124
	s_mov_b32 s10, 0                                           // 0000000DF518: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000DF51C: BF89FC07
	s_barrier                                                  // 0000000DF520: BFBD0000
	buffer_gl0_inv                                             // 0000000DF524: E0AC0000 00000000
	s_nop 0                                                    // 0000000DF52C: BF800000
	s_nop 0                                                    // 0000000DF530: BF800000
	s_nop 0                                                    // 0000000DF534: BF800000
	s_nop 0                                                    // 0000000DF538: BF800000
	s_nop 0                                                    // 0000000DF53C: BF800000
	global_load_b32 v49, v[29:30], off                         // 0000000DF540: DC520000 317C001D
	ds_load_b32 v50, v33 offset:17408                          // 0000000DF548: D8D84400 32000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000DF550: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000DF558: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000DF55C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000DF564: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000DF568: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000DF570: BF870004
	.long 0xd4490004                                           // 0000000DF574: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000DF578: 020244FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000DF580: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000DF584: BF890007
	v_mul_f32_e32 v49, v49, v50                                // 0000000DF588: 10626531
	ds_store_b32 v32, v49 offset:13056                         // 0000000DF58C: D8343300 00003120
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000DF594: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000DF59C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000DF5A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000DF5A4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v45                           // 0000000DF5A8: 4A425AFF 00000E00
	v_add_nc_u32_e32 v49, 0x1000, v45                          // 0000000DF5B0: 4A625AFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000DF5B8: BF89FC07
	s_barrier                                                  // 0000000DF5BC: BFBD0000
	buffer_gl0_inv                                             // 0000000DF5C0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:184 offset1:201    // 0000000DF5C8: D8DCC9B8 1D00001F
	ds_load_2addr_b32 v[31:32], v31 offset0:218 offset1:235    // 0000000DF5D0: D8DCEBDA 1F00001F
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000DF5D8: D8DC8D7C 21000021
	ds_load_2addr_b32 v[49:50], v49 offset0:30 offset1:47      // 0000000DF5E0: D8DC2F1E 31000031
	v_mov_b32_e32 v51, v0                                      // 0000000DF5E8: 7E660300
	s_mov_b32 s4, 0                                            // 0000000DF5EC: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000DF5F0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000DF5F4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000DF5FC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000DF604: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000DF608: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000DF610: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000DF618: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000DF61C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000DF624: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000DF62C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000DF630: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000DF638: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF640: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF648: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF650: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF658: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF660: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF668: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF670: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF678: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000DF680: 326C6684
	.long 0xd4490001                                           // 0000000DF684: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000DF688: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000DF690: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000DF694: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000DF698: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000DF6A4: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000DF6A8: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000DF6B0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000DF6B8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000DF6C0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000DF6C8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000DF6D0: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000DF6D8: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000DF6E0: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000DF6E8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000DF6EC: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000DF6F4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000DF6F8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000DF700: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000DF708: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000DF710: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000DF714: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF71C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF724: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000DF72C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF734: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF73C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF744: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000DF74C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF750: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000DF754: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000DF758: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000DF75C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000DF764: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000DF768: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000DF76C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000DF770: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF778: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000DF780: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000DF788: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000DF78C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF790: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000DF798: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF7A0: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000DF7A4: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000DF7A8: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000DF7AC: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DF7B4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000DF7B8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000DF7C0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000DF7C8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000DF7CC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000DF7D0: 8C7E047E
	.long 0xd7000107                                           // 0000000DF7D4: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000DF7D8: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DF7E0: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000DF7E4: D5207C08 00061080
	.long 0xd7000109                                           // 0000000DF7EC: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000DF7F0: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000DF7F8: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000DF800: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000DF804: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DF80C: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000DF810: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000DF818: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000DF81C: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000DF824: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000DF82C: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000DF830: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DF838: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000DF83C: D5207C10 00062080
	.long 0xd7000111                                           // 0000000DF844: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000DF848: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000DF850: D5207C12 00062480
	.long 0xd7000113                                           // 0000000DF858: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000DF85C: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DF864: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000DF868: D5207C14 00062880
	.long 0xd7000115                                           // 0000000DF870: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000DF874: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000DF87C: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000DF884: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000DF888: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000DF890: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000DF894: D5207C18 00063080
	.long 0xd7000119                                           // 0000000DF89C: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000DF8A0: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000DF8A8: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000DF8B0: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000DF8B4: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000DF8BC: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000DF8C0: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000DF8C8: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000DF8CC: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000DF8D0: BF062105
	s_barrier                                                  // 0000000DF8D4: BFBD0000
	buffer_gl0_inv                                             // 0000000DF8D8: E0AC0000 00000000
	s_cbranch_scc0 63457                                       // 0000000DF8E0: BFA1F7E1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x368>
	v_mov_b32_e32 v4, v36                                      // 0000000DF8E4: 7E080324
	s_add_u32 s0, s28, s20                                     // 0000000DF8E8: 8000141C
	.long 0xd73c0000                                           // 0000000DF8EC: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000DF8F0: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000DF8F4: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000DF8F8: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000DF8FC: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000DF900: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000DF904: 82010103
	.long 0xd7006a00                                           // 0000000DF908: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000DF90C: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000DF910: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000DF914: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000DF91C: BE810080
	.long 0xd7006a00                                           // 0000000DF920: D7006A00
	v_cndmask_b32_e32 v1, v0, v37, vcc_lo                      // 0000000DF924: 02024B00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000DF928: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000DF930: BF870092
	.long 0xd7006a00                                           // 0000000DF934: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000DF938: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000DF93C: D5207C01 01AA0211
	s_nop 0                                                    // 0000000DF944: BF800000
	s_nop 0                                                    // 0000000DF948: BF800000
	s_nop 0                                                    // 0000000DF94C: BF800000
	s_nop 0                                                    // 0000000DF950: BF800000
	s_nop 0                                                    // 0000000DF954: BF800000
	s_nop 0                                                    // 0000000DF958: BF800000
	s_nop 0                                                    // 0000000DF95C: BF800000
	s_nop 0                                                    // 0000000DF960: BF800000
	s_nop 0                                                    // 0000000DF964: BF800000
	s_nop 0                                                    // 0000000DF968: BF800000
	s_nop 0                                                    // 0000000DF96C: BF800000
	s_nop 0                                                    // 0000000DF970: BF800000
	s_nop 0                                                    // 0000000DF974: BF800000
	s_nop 0                                                    // 0000000DF978: BF800000
	s_nop 0                                                    // 0000000DF97C: BF800000
	ds_load_b32 v2, v35                                        // 0000000DF980: D8D80000 02000023
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000DF988: 4A0808FF 00000080
	v_add_nc_u32_e32 v35, 0x220, v35                           // 0000000DF990: 4A4646FF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000DF998: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000DF99C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000DF9A4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000DF9A8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000DF9AC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000DF9B4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000DF9B8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000DF9C0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000DF9C8: 917E017E
	s_cbranch_execnz 65516                                     // 0000000DF9CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2480>
	s_endpgm                                                   // 0000000DF9D0: BFB00000
		...

