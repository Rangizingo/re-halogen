0000000000840100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000840100: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000840108: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000084010C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 3                               // 000000840110: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000840114: BF8701A9
	v_dual_mov_b32 v10, s3 :: v_dual_and_b32 v1, 15, v0        // 000000840118: CA240003 0A00008F
	.long 0x7f103880                                           // 000000840120: 7F103880
	v_and_b32_e32 v2, 60, v2                                   // 000000840124: 360404BC
	s_delay_alu instid0(VALU_DEP_3)                            // 000000840128: BF870003
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 00000084012C: CA220080 12000282
	v_dual_mov_b32 v3, 0 :: v_dual_and_b32 v16, 31, v0         // 000000840134: CA240080 0310009F
	v_mov_b32_e32 v17, 0                                       // 00000084013C: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 000000840140: BF89FC07
	s_clause 0x1                                               // 000000840144: BF850001
	global_load_b32 v4, v1, s[4:5]                             // 000000840148: DC520000 04040001
	global_load_b32 v7, v2, s[4:5]                             // 000000840150: DC520000 07040002
	v_lshrrev_b32_e32 v2, 5, v0                                // 000000840158: 32040085
	s_add_u32 s14, s4, s14                                     // 00000084015C: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 000000840160: 820F0F05
	v_mov_b32_e32 v1, 0                                        // 000000840164: 7E020280
	s_delay_alu instid0(VALU_DEP_2)                            // 000000840168: BF870002
	v_or_b32_e32 v9, s2, v2                                    // 00000084016C: 38120402
	s_lshr_b32 s2, s11, 31                                     // 000000840170: 85029F0B
	v_mov_b32_e32 v2, 0                                        // 000000840174: 7E040280
	s_add_u32 s20, s10, s2                                     // 000000840178: 8014020A
	s_addc_u32 s21, s11, 0                                     // 00000084017C: 8215800B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 000000840180: 7CA8120C
	s_ashr_i32 s22, s11, 31                                    // 000000840184: 86169F0B
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 000000840188: 02161280
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 00000084018C: D501000E 01A80680
	s_ashr_i64 s[2:3], s[20:21], 1                             // 000000840194: 86828114
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000840198: BF870481
	.long 0xd72c0014                                           // 00000084019C: D72C0014
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000008401A0: 0200050E
	.long 0xd72c000e                                           // 0000008401A4: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000008401A8: 02021C12
	s_waitcnt vmcnt(1)                                         // 0000008401AC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 0000008401B0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 0000008401B8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 0000008401BC: D6100013 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008401C4: BF870112
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000008401C8: D6550004 03FE1904 00007FFF
	v_add3_u32 v7, v7, v19, 0x7fff                             // 0000008401D4: D6550007 03FE2707 00007FFF
	v_lshlrev_b32_e32 v19, 2, v0                               // 0000008401E0: 30260082
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008401E4: BF870003
	.long 0x7e103984                                           // 0000008401E8: 7E103984
	v_mov_b32_e32 v4, 0                                        // 0000008401EC: 7E080280
	.long 0xd72c000d                                           // 0000008401F0: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 0000008401F4: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 0000008401F8: D6FE7C05 02021612
	.long 0xd72c000f                                           // 000000840200: D72C000F
	v_cndmask_b32_e32 v0, v11, v3, vcc_lo                      // 000000840204: 0200070B
	v_mad_u64_u32 v[11:12], null, v11, s2, s[14:15]            // 000000840208: D6FE7C0B 0038050B
	s_lshr_b32 s19, s22, 27                                    // 000000840210: 85139B16
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 000000840214: D6570007 04220EFF FFFF0000
	s_add_u32 s14, s10, s19                                    // 000000840220: 800E130A
	s_addc_u32 s15, s11, 0                                     // 000000840224: 820F800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000840228: BF870009
	s_lshr_b64 s[14:15], s[14:15], 5                           // 00000084022C: 858E850E
	v_add3_u32 v6, v6, v14, v13                                // 000000840230: D6550006 04361D06
	.long 0xd4440002                                           // 000000840238: D4440002
	v_cndmask_b32_e32 v1, s14, v16, vcc_lo                     // 00000084023C: 0202200E
	v_add3_u32 v0, v20, v12, v15                               // 000000840240: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 000000840248: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 000000840250: BF89FC07
	s_barrier                                                  // 000000840254: BFBD0000
	buffer_gl0_inv                                             // 000000840258: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 000000840260: BE8F2002
	s_cbranch_execz 26                                         // 000000840264: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1d0>
	s_add_u32 s3, s4, s16                                      // 000000840268: 80031004
	s_addc_u32 s18, s5, s17                                    // 00000084026C: 82121105
	v_lshlrev_b32_e32 v1, 1, v16                               // 000000840270: 30022081
	.long 0xd7000302                                           // 000000840274: D7000302
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 000000840278: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084027C: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s18, v6, s3                  // 000000840280: D5207C03 000E0C12
	v_lshlrev_b32_e32 v4, 4, v16                               // 000000840288: 30082084
	.long 0xd7000301                                           // 00000084028C: D7000301
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000840290: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000840294: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s3                    // 000000840298: D5207C02 000E0680
	.long 0xd7000303                                           // 0000008402A0: D7000303
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 0000008402A4: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008402A8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s3                    // 0000008402AC: D5207C04 000E0080
	s_clause 0x1                                               // 0000008402B4: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 0000008402B8: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008402C0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008402C8: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 0000008402CC: 7E241707
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008402D0: 8C7E0F7E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000008402D4: CA100080 13140080
	s_and_saveexec_b32 s15, s2                                 // 0000008402DC: BE8F2002
	s_cbranch_execz 331                                        // 0000008402E0: BFA5014B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x710>
	v_dual_mov_b32 v22, v16 :: v_dual_lshlrev_b32 v7, 1, v16   // 0000008402E4: CA220110 16062081
	.long 0xd7000205                                           // 0000008402EC: D7000205
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 0000008402F0: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008402F4: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s2                  // 0000008402F8: D5207C06 000A0C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 000000840300: CA220080 0D0C2085
	.long 0xd7000205                                           // 000000840308: D7000205
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000084030C: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000840310: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s2                    // 000000840314: D5207C06 000A0C80
	v_lshl_or_b32 v21, v16, 4, 0x200                           // 00000084031C: D6560015 03FD0910 00000200
	.long 0xd7000205                                           // 000000840328: D7000205
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 00000084032C: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000840330: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s2                   // 000000840334: D5207C06 000A0C05
	v_dual_mov_b32 v20, v13 :: v_dual_mov_b32 v23, v18         // 00000084033C: CA10010D 14160112
	.long 0xd700020e                                           // 000000840344: D700020E
	v_cndmask_b32_e32 v0, v5, v192, vcc_lo                     // 000000840348: 02018105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084034C: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s2                   // 000000840350: D5207C0F 000A0C80
	v_mov_b32_e32 v19, v13                                     // 000000840358: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 00000084035C: 7E22030D
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000840360: 8484820A
	s_mov_b32 s16, 0                                           // 000000840364: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000840368: 848A810A
	s_branch 270                                               // 00000084036C: BFA0010E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x6a8>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000840370: 8C7E117E
	.long 0xd73c0018                                           // 000000840374: D73C0018
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000840378: 02021881
	v_and_b32_e32 v72, 0xff, v1                                // 00000084037C: 369002FF 000000FF
	v_lshrrev_b32_e32 v73, 6, v1                               // 000000840384: 32920286
	v_lshrrev_b32_e32 v74, 14, v1                              // 000000840388: 3294028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 00000084038C: 32020296
	v_and_b32_e32 v75, 0xff, v2                                // 000000840390: 369604FF 000000FF
	.long 0xd700033c                                           // 000000840398: D700033C
	v_cndmask_b32_e32 v1, s6, v24, vcc_lo                      // 00000084039C: 02023006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008403A0: BF8701A1
	v_add_co_ci_u32_e64 v61, null, s7, v25, s3                 // 0000008403A4: D5207C3D 000E3207
	v_lshlrev_b32_e32 v72, 2, v72                              // 0000008403AC: 30909082
	.long 0xd7000340                                           // 0000008403B0: D7000340
	v_cndmask_b32_e32 v0, v60, v10, vcc_lo                     // 0000008403B4: 0200153C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008403B8: BF8700A1
	v_add_co_ci_u32_e64 v65, null, s11, v61, s3                // 0000008403BC: D5207C41 000E7A0B
	.long 0xd7000344                                           // 0000008403C4: D7000344
	v_cndmask_b32_e32 v0, v60, v4, vcc_lo                      // 0000008403C8: 0200093C
	v_add_co_ci_u32_e64 v69, null, s5, v61, s3                 // 0000008403CC: D5207C45 000E7A05
	s_clause 0xb                                               // 0000008403D4: BF85000B
	global_load_b128 v[24:27], v[60:61], off                   // 0000008403D8: DC5E0000 187C003C
	global_load_b128 v[28:31], v[64:65], off                   // 0000008403E0: DC5E0000 1C7C0040
	global_load_b128 v[32:35], v[68:69], off                   // 0000008403E8: DC5E0000 207C0044
	global_load_b128 v[36:39], v[60:61], off offset:16         // 0000008403F0: DC5E0010 247C003C
	global_load_b128 v[40:43], v[64:65], off offset:16         // 0000008403F8: DC5E0010 287C0040
	global_load_b128 v[44:47], v[68:69], off offset:16         // 000000840400: DC5E0010 2C7C0044
	global_load_b128 v[48:51], v[60:61], off offset:32         // 000000840408: DC5E0020 307C003C
	global_load_b128 v[52:55], v[64:65], off offset:32         // 000000840410: DC5E0020 347C0040
	global_load_b128 v[56:59], v[68:69], off offset:32         // 000000840418: DC5E0020 387C0044
	global_load_b128 v[60:63], v[60:61], off offset:48         // 000000840420: DC5E0030 3C7C003C
	global_load_b128 v[64:67], v[64:65], off offset:48         // 000000840428: DC5E0030 407C0040
	global_load_b128 v[68:71], v[68:69], off offset:48         // 000000840430: DC5E0030 447C0044
	v_and_b32_e32 v73, 0x3fc, v73                              // 000000840438: 369292FF 000003FC
	ds_load_b32 v72, v72                                       // 000000840440: D8D80000 48000048
	v_and_b32_e32 v74, 0x3fc, v74                              // 000000840448: 369494FF 000003FC
	v_lshrrev_b32_e32 v76, 6, v2                               // 000000840450: 32980486
	v_lshrrev_b32_e32 v77, 14, v2                              // 000000840454: 329A048E
	ds_load_b32 v73, v73                                       // 000000840458: D8D80000 49000049
	v_lshrrev_b32_e32 v2, 22, v2                               // 000000840460: 32040496
	ds_load_b32 v74, v74                                       // 000000840464: D8D80000 4A00004A
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000084046C: 360202FF 000003FC
	v_lshlrev_b32_e32 v75, 2, v75                              // 000000840474: 30969682
	v_and_b32_e32 v76, 0x3fc, v76                              // 000000840478: 369898FF 000003FC
	v_and_b32_e32 v77, 0x3fc, v77                              // 000000840480: 369A9AFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000840488: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 000000840490: D8D80000 01000001
	ds_load_b32 v75, v75                                       // 000000840498: D8D80000 4B00004B
	ds_load_b32 v76, v76                                       // 0000008404A0: D8D80000 4C00004C
	ds_load_b32 v77, v77                                       // 0000008404A8: D8D80000 4D00004D
	ds_load_b32 v2, v2                                         // 0000008404B0: D8D80000 02000002
	v_and_b32_e32 v78, 0xff, v3                                // 0000008404B8: 369C06FF 000000FF
	v_lshrrev_b32_e32 v79, 6, v3                               // 0000008404C0: 329E0686
	v_lshrrev_b32_e32 v80, 14, v3                              // 0000008404C4: 32A0068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000008404C8: 32060696
	v_and_b32_e32 v81, 0xff, v4                                // 0000008404CC: 36A208FF 000000FF
	v_lshrrev_b32_e32 v82, 14, v4                              // 0000008404D4: 32A4088E
	s_and_b32 s3, exec_lo, s2                                  // 0000008404D8: 8B03027E
	.long 0xd700020e                                           // 0000008404DC: D700020E
	v_cndmask_b32_e32 v0, v14, v192, vcc_lo                    // 0000008404E0: 0201810E
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000008404E4: 360606FF 000003FC
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008404EC: 4A1818FF 00000400
	v_add_nc_u32_e32 v21, 0x200, v21                           // 0000008404F4: 4A2A2AFF 00000200
	v_add_co_ci_u32_e64 v15, null, 0, v15, s2                  // 0000008404FC: D5207C0F 000A1E80
	s_or_b32 s16, s3, s16                                      // 000000840504: 8C101003
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 000000840508: BF892C77
	v_dot2_f32_bf16 v24, v24, v72, 0                           // 00000084050C: CC1A4018 1A029118
	s_waitcnt vmcnt(10)                                        // 000000840514: BF892BF7
	v_dot2_f32_bf16 v28, v28, v72, 0                           // 000000840518: CC1A401C 1A02911C
	s_waitcnt vmcnt(9)                                         // 000000840520: BF8927F7
	v_dot2_f32_bf16 v32, v32, v72, 0                           // 000000840524: CC1A4020 1A029120
	v_lshrrev_b32_e32 v72, 6, v4                               // 00000084052C: 32900886
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000840530: 32080896
	s_waitcnt lgkmcnt(6)                                       // 000000840534: BF89FC67
	v_dot2_f32_bf16 v24, v25, v73, v24                         // 000000840538: CC1A4018 1C629319
	v_dot2_f32_bf16 v25, v29, v73, v28                         // 000000840540: CC1A4019 1C72931D
	v_dot2_f32_bf16 v28, v33, v73, v32                         // 000000840548: CC1A401C 1C829321
	v_lshlrev_b32_e32 v29, 2, v78                              // 000000840550: 303A9C82
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000840554: 360808FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 00000084055C: BF89FC57
	v_dot2_f32_bf16 v24, v26, v74, v24                         // 000000840560: CC1A4018 1C62951A
	v_dot2_f32_bf16 v25, v30, v74, v25                         // 000000840568: CC1A4019 1C66951E
	v_dot2_f32_bf16 v26, v34, v74, v28                         // 000000840570: CC1A401A 1C729522
	v_and_b32_e32 v28, 0x3fc, v79                              // 000000840578: 36389EFF 000003FC
	v_and_b32_e32 v30, 0x3fc, v80                              // 000000840580: 363CA0FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000840588: BF89FC47
	v_dot2_f32_bf16 v24, v27, v1, v24                          // 00000084058C: CC1A4018 1C62031B
	v_dot2_f32_bf16 v25, v31, v1, v25                          // 000000840594: CC1A4019 1C66031F
	v_dot2_f32_bf16 v1, v35, v1, v26                           // 00000084059C: CC1A4001 1C6A0323
	ds_load_b32 v27, v29                                       // 0000008405A4: D8D80000 1B00001D
	ds_load_b32 v30, v30                                       // 0000008405AC: D8D80000 1E00001E
	ds_load_b32 v28, v28                                       // 0000008405B4: D8D80000 1C00001C
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 0000008405BC: BF892067
	v_dot2_f32_bf16 v24, v36, v75, v24                         // 0000008405C0: CC1A4018 1C629724
	s_waitcnt vmcnt(7)                                         // 0000008405C8: BF891FF7
	v_dot2_f32_bf16 v25, v40, v75, v25                         // 0000008405CC: CC1A4019 1C669728
	s_waitcnt vmcnt(6)                                         // 0000008405D4: BF891BF7
	v_dot2_f32_bf16 v1, v44, v75, v1                           // 0000008405D8: CC1A4001 1C06972C
	v_lshlrev_b32_e32 v26, 2, v81                              // 0000008405E0: 3034A282
	v_and_b32_e32 v29, 0x3fc, v72                              // 0000008405E4: 363A90FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000008405EC: BF89FC57
	v_dot2_f32_bf16 v24, v37, v76, v24                         // 0000008405F0: CC1A4018 1C629925
	v_dot2_f32_bf16 v25, v41, v76, v25                         // 0000008405F8: CC1A4019 1C669929
	v_dot2_f32_bf16 v1, v45, v76, v1                           // 000000840600: CC1A4001 1C06992D
	v_and_b32_e32 v31, 0x3fc, v82                              // 000000840608: 363EA4FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000840610: BF89FC47
	v_dot2_f32_bf16 v24, v38, v77, v24                         // 000000840614: CC1A4018 1C629B26
	v_dot2_f32_bf16 v25, v42, v77, v25                         // 00000084061C: CC1A4019 1C669B2A
	v_dot2_f32_bf16 v1, v46, v77, v1                           // 000000840624: CC1A4001 1C069B2E
	s_waitcnt lgkmcnt(3)                                       // 00000084062C: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000840630: BF870193
	v_dot2_f32_bf16 v24, v39, v2, v24                          // 000000840634: CC1A4018 1C620527
	v_dot2_f32_bf16 v25, v43, v2, v25                          // 00000084063C: CC1A4019 1C66052B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000840644: BF870003
	v_dot2_f32_bf16 v1, v47, v2, v1                            // 000000840648: CC1A4001 1C06052F
	ds_load_b32 v2, v3                                         // 000000840650: D8D80000 02000003
	ds_load_b32 v3, v26                                        // 000000840658: D8D80000 0300001A
	ds_load_b32 v26, v29                                       // 000000840660: D8D80000 1A00001D
	ds_load_b32 v29, v31                                       // 000000840668: D8D80000 1D00001F
	ds_load_b32 v31, v4                                        // 000000840670: D8D80000 1F000004
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 000000840678: BF891477
	v_dot2_f32_bf16 v4, v48, v27, v24                          // 00000084067C: CC1A4004 1C623730
	s_waitcnt vmcnt(4)                                         // 000000840684: BF8913F7
	v_dot2_f32_bf16 v24, v52, v27, v25                         // 000000840688: CC1A4018 1C663734
	s_waitcnt vmcnt(3)                                         // 000000840690: BF890FF7
	v_dot2_f32_bf16 v1, v56, v27, v1                           // 000000840694: CC1A4001 1C063738
	s_waitcnt lgkmcnt(5)                                       // 00000084069C: BF89FC57
	v_dot2_f32_bf16 v4, v49, v28, v4                           // 0000008406A0: CC1A4004 1C123931
	v_dot2_f32_bf16 v24, v53, v28, v24                         // 0000008406A8: CC1A4018 1C623935
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008406B0: BF870193
	v_dot2_f32_bf16 v1, v57, v28, v1                           // 0000008406B4: CC1A4001 1C063939
	v_dot2_f32_bf16 v4, v50, v30, v4                           // 0000008406BC: CC1A4004 1C123D32
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008406C4: BF870193
	v_dot2_f32_bf16 v24, v54, v30, v24                         // 0000008406C8: CC1A4018 1C623D36
	v_dot2_f32_bf16 v1, v58, v30, v1                           // 0000008406D0: CC1A4001 1C063D3A
	s_waitcnt lgkmcnt(4)                                       // 0000008406D8: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008406DC: BF870193
	v_dot2_f32_bf16 v4, v51, v2, v4                            // 0000008406E0: CC1A4004 1C120533
	v_dot2_f32_bf16 v24, v55, v2, v24                          // 0000008406E8: CC1A4018 1C620537
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008406F0: BF8701A3
	v_dot2_f32_bf16 v1, v59, v2, v1                            // 0000008406F4: CC1A4001 1C06053B
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000008406FC: BF890837
	v_dot2_f32_bf16 v2, v60, v3, v4                            // 000000840700: CC1A4002 1C12073C
	s_waitcnt vmcnt(1)                                         // 000000840708: BF8907F7
	v_dot2_f32_bf16 v4, v64, v3, v24                           // 00000084070C: CC1A4004 1C620740
	s_waitcnt vmcnt(0)                                         // 000000840714: BF8903F7
	v_dot2_f32_bf16 v1, v68, v3, v1                            // 000000840718: CC1A4001 1C060744
	s_waitcnt lgkmcnt(2)                                       // 000000840720: BF89FC27
	v_dot2_f32_bf16 v2, v61, v26, v2                           // 000000840724: CC1A4002 1C0A353D
	v_dot2_f32_bf16 v3, v65, v26, v4                           // 00000084072C: CC1A4003 1C123541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000840734: BF870003
	v_dot2_f32_bf16 v1, v69, v26, v1                           // 000000840738: CC1A4001 1C063545
	v_mov_b32_e32 v4, v8                                       // 000000840740: 7E080308
	s_waitcnt lgkmcnt(1)                                       // 000000840744: BF89FC17
	v_dot2_f32_bf16 v2, v62, v29, v2                           // 000000840748: CC1A4002 1C0A3B3E
	v_dot2_f32_bf16 v24, v66, v29, v3                          // 000000840750: CC1A4018 1C0E3B42
	v_dot2_f32_bf16 v1, v70, v29, v1                           // 000000840758: CC1A4001 1C063B46
	v_mov_b32_e32 v3, v7                                       // 000000840760: 7E060307
	s_waitcnt lgkmcnt(0)                                       // 000000840764: BF89FC07
	v_dot2_f32_bf16 v7, v63, v31, v2                           // 000000840768: CC1A4007 1C0A3F3F
	v_dot2_f32_bf16 v8, v67, v31, v24                          // 000000840770: CC1A4008 1C623F43
	v_dot2_f32_bf16 v24, v71, v31, v1                          // 000000840778: CC1A4018 1C063F47
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 000000840780: CA100106 02000105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000840788: BF870214
	v_fmac_f32_e32 v20, v18, v7                                // 00000084078C: 56280F12
	v_fmac_f32_e32 v19, v18, v8                                // 000000840790: 56261112
	s_delay_alu instid0(VALU_DEP_4)                            // 000000840794: BF870004
	v_dual_fmac_f32 v17, v18, v24 :: v_dual_mov_b32 v18, v23   // 000000840798: C8103112 11120117
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008407A0: 917E107E
	s_cbranch_execz 25                                         // 0000008407A4: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x70c>
	s_waitcnt vmcnt(0)                                         // 0000008407A8: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v22, 32, v22    // 0000008407AC: CA200101 05162CA0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 0000008407B4: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 0000008407BC: 7E100304
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008407C0: BF870003
	.long 0xd4430002                                           // 0000008407C4: D4430002
	v_cndmask_b32_e32 v1, s14, v22, vcc_lo                     // 0000008407C8: 02022C0E
	s_mov_b32 s17, exec_lo                                     // 0000008407CC: BE91007E
	.long 0xd4c4007e                                           // 0000008407D0: D4C4007E
	v_cndmask_b32_e32 v1, s14, v22, vcc_lo                     // 0000008407D4: 02022C0E
	s_cbranch_execz 65253                                      // 0000008407D8: BFA5FEE5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x270>
	.long 0xd7000305                                           // 0000008407DC: D7000305
	v_cndmask_b32_e32 v1, v11, v21, vcc_lo                     // 0000008407E0: 02022B0B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008407E4: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s3                    // 0000008407E8: D5207C06 000E0080
	global_load_d16_b16 v23, v[14:15], off                     // 0000008407F0: DC820000 177C000E
	global_load_b128 v[5:8], v[5:6], off                       // 0000008407F8: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 000000840800: BF8907F7
	v_cvt_f32_f16_e32 v23, v23                                 // 000000840804: 7E2E1717
	s_branch 65241                                             // 000000840808: BFA0FED9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x270>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000084080C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000840810: BF8700B9
	s_or_b32 exec_lo, exec_lo, s15                             // 000000840814: 8C7E0F7E
	.long 0xd71f0000                                           // 000000840818: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000084081C: 020100C1
	s_waitcnt vmcnt(0)                                         // 000000840820: BF8903F7
	v_xor_b32_e32 v1, 16, v0                                   // 000000840824: 3A020090
	v_xor_b32_e32 v4, 8, v0                                    // 000000840828: 3A080088
	v_xor_b32_e32 v7, 4, v0                                    // 00000084082C: 3A0E0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000840830: BF870093
	.long 0xd44c0002                                           // 000000840834: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000840838: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 00000084083C: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000840844: BF870114
	.long 0xd44c0002                                           // 000000840848: D44C0002
	v_cndmask_b32_e32 v1, 32, v4, vcc_lo                       // 00000084084C: 020208A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000840850: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000840854: BF870002
	v_cndmask_b32_e64 v4, v0, v4, s2                           // 000000840858: D5010004 000A0900
	.long 0xd44c0002                                           // 000000840860: D44C0002
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 000000840864: 02020EA0
	ds_bpermute_b32 v2, v1, v20                                // 000000840868: DACC0000 02001401
	v_cndmask_b32_e64 v7, v0, v7, s2                           // 000000840870: D5010007 000A0F00
	s_waitcnt lgkmcnt(0)                                       // 000000840878: BF89FC07
	v_add_f32_e32 v2, v20, v2                                  // 00000084087C: 06040514
	ds_bpermute_b32 v3, v1, v19                                // 000000840880: DACC0000 03001301
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000840888: 30080882
	ds_bpermute_b32 v1, v1, v17                                // 00000084088C: DACC0000 01001101
	s_waitcnt lgkmcnt(1)                                       // 000000840894: BF89FC17
	v_add_f32_e32 v3, v19, v3                                  // 000000840898: 06060713
	ds_bpermute_b32 v5, v4, v2                                 // 00000084089C: DACC0000 05000204
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000008408A4: 300E0E82
	ds_bpermute_b32 v6, v4, v3                                 // 0000008408A8: DACC0000 06000304
	s_waitcnt lgkmcnt(1)                                       // 0000008408B0: BF89FC17
	v_add_f32_e32 v2, v2, v5                                   // 0000008408B4: 06040B02
	v_add_f32_e32 v1, v17, v1                                  // 0000008408B8: 06020311
	ds_bpermute_b32 v4, v4, v1                                 // 0000008408BC: DACC0000 04000104
	s_waitcnt lgkmcnt(0)                                       // 0000008408C4: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 0000008408C8: 06020901
	ds_bpermute_b32 v4, v7, v2                                 // 0000008408CC: DACC0000 04000207
	s_waitcnt lgkmcnt(0)                                       // 0000008408D4: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v3, v3, v6     // 0000008408D8: C9080902 02020D03
	ds_bpermute_b32 v6, v7, v1                                 // 0000008408E0: DACC0000 06000107
	ds_bpermute_b32 v5, v7, v3                                 // 0000008408E8: DACC0000 05000307
	v_xor_b32_e32 v7, 2, v0                                    // 0000008408F0: 3A0E0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008408F4: BF870091
	.long 0xd44c0002                                           // 0000008408F8: D44C0002
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 0000008408FC: 02020EA0
	v_cndmask_b32_e64 v7, v0, v7, s2                           // 000000840900: D5010007 000A0F00
	s_waitcnt lgkmcnt(1)                                       // 000000840908: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084090C: BF870001
	v_dual_add_f32 v4, v1, v6 :: v_dual_lshlrev_b32 v7, 2, v7  // 000000840910: C9220D01 04060E82
	s_waitcnt lgkmcnt(0)                                       // 000000840918: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000084091C: 06060B03
	ds_bpermute_b32 v1, v7, v2                                 // 000000840920: DACC0000 01000207
	ds_bpermute_b32 v6, v7, v4                                 // 000000840928: DACC0000 06000407
	ds_bpermute_b32 v5, v7, v3                                 // 000000840930: DACC0000 05000307
	v_xor_b32_e32 v7, 1, v0                                    // 000000840938: 3A0E0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084093C: BF870091
	.long 0xd44c0002                                           // 000000840940: D44C0002
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 000000840944: 02020EA0
	v_cndmask_b32_e64 v0, v0, v7, s2                           // 000000840948: D5010000 000A0F00
	.long 0xd44a0002                                           // 000000840950: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000840954: 02022080
	s_waitcnt lgkmcnt(2)                                       // 000000840958: BF89FC27
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084095C: BF870002
	v_dual_add_f32 v0, v2, v1 :: v_dual_lshlrev_b32 v7, 2, v0  // 000000840960: C9220302 00060082
	s_waitcnt lgkmcnt(1)                                       // 000000840968: BF89FC17
	v_add_f32_e32 v2, v4, v6                                   // 00000084096C: 06040D04
	s_and_b32 s2, s2, vcc_lo                                   // 000000840970: 8B026A02
	s_waitcnt lgkmcnt(0)                                       // 000000840974: BF89FC07
	v_add_f32_e32 v1, v3, v5                                   // 000000840978: 06020B03
	ds_bpermute_b32 v3, v7, v0                                 // 00000084097C: DACC0000 03000007
	ds_bpermute_b32 v5, v7, v2                                 // 000000840984: DACC0000 05000207
	ds_bpermute_b32 v4, v7, v1                                 // 00000084098C: DACC0000 04000107
	s_and_saveexec_b32 s3, s2                                  // 000000840994: BE832002
	s_cbranch_execz 147                                        // 000000840998: BFA50093 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xae8>
	s_load_b32 s0, s[0:1], 0x48                                // 00000084099C: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000008409A4: BF89FC07
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v1, v1, v4     // 0000008409A8: C9080700 00000901
	s_lshl_b64 s[2:3], s[12:13], 2                             // 0000008409B0: 8482820C
	s_lshl_b64 s[4:5], s[12:13], 3                             // 0000008409B4: 8484830C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008409B8: BF870111
	v_bfe_u32 v3, v0, 16, 1                                    // 0000008409BC: D6100003 02052100
	v_bfe_u32 v4, v1, 16, 1                                    // 0000008409C4: D6100004 02052101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008409CC: BF870112
	v_add3_u32 v0, v0, v3, 0x7fff                              // 0000008409D0: D6550000 03FE0700 00007FFF
	v_add3_u32 v1, v1, v4, 0x7fff                              // 0000008409DC: D6550001 03FE0901 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008409E8: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000008409EC: 360202FF FFFF0000
	v_dual_mul_f32 v1, s0, v1 :: v_dual_and_b32 v0, 0xffff0000, v0// 0000008409F4: C8E40200 010000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000840A00: BF870091
	v_dual_mul_f32 v0, s0, v0 :: v_dual_mul_f32 v1, 0xbfb8aa3b, v1// 000000840A04: C8C60000 000002FF BFB8AA3B
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000840A10: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000840A18: BF870092
	v_exp_f32_e32 v1, v1                                       // 000000840A1C: 7E024B01
	v_exp_f32_e32 v0, v0                                       // 000000840A20: 7E004B00
	v_add_f32_e32 v2, v2, v5                                   // 000000840A24: 06040B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000840A28: BF870115
	v_dual_add_f32 v4, 1.0, v1 :: v_dual_add_f32 v3, 1.0, v0   // 000000840A2C: C90802F2 040200F2
	v_bfe_u32 v5, v2, 16, 1                                    // 000000840A34: D6100005 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000840A3C: BF870192
	v_div_scale_f32 v6, null, v4, v4, 1.0                      // 000000840A40: D6FC7C06 03CA0904
	v_div_scale_f32 v13, vcc_lo, 1.0, v3, 1.0                  // 000000840A48: D6FC6A0D 03CA06F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000840A50: BF870223
	v_add3_u32 v2, v2, v5, 0x7fff                              // 000000840A54: D6550002 03FE0B02 00007FFF
	v_div_scale_f32 v5, null, v3, v3, 1.0                      // 000000840A60: D6FC7C05 03CA0703
	v_rcp_f32_e32 v11, v6                                      // 000000840A68: 7E165506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000840A6C: BF870311
	v_rcp_f32_e32 v8, v5                                       // 000000840A70: 7E105505
	v_fma_f32 v1, -v6, v11, 1.0                                // 000000840A74: D6130001 23CA1706
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000840A7C: 360404FF FFFF0000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000840A84: BF870115
	v_fma_f32 v0, -v5, v8, 1.0                                 // 000000840A88: D6130000 23CA1105
	v_dual_fmac_f32 v11, v1, v11 :: v_dual_mul_f32 v2, s0, v2  // 000000840A90: C8061701 0B020400
	v_div_scale_f32 v15, s0, 1.0, v4, 1.0                      // 000000840A98: D6FC000F 03CA08F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000840AA0: BF8701A3
	v_fmac_f32_e32 v8, v0, v8                                  // 000000840AA4: 56101100
	.long 0xd73c0000                                           // 000000840AA8: D73C0000
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000840AAC: 02021282
	v_mul_f32_e32 v17, v15, v11                                // 000000840AB0: 1022170F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000840AB4: BF870091
	v_fma_f32 v20, -v6, v17, v15                               // 000000840AB8: D6130014 243E2306
	v_dual_mul_f32 v2, 0xbfb8aa3b, v2 :: v_dual_fmac_f32 v17, v20, v11// 000000840AC0: C8C004FF 02101714 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000840ACC: BF870091
	v_exp_f32_e32 v2, v2                                       // 000000840AD0: 7E044B02
	v_fma_f32 v6, -v6, v17, v15                                // 000000840AD4: D6130006 243E2306
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000840ADC: BF870095
	v_add_f32_e32 v2, 1.0, v2                                  // 000000840AE0: 060404F2
	v_div_scale_f32 v7, null, v2, v2, 1.0                      // 000000840AE4: D6FC7C07 03CA0502
	v_div_scale_f32 v16, s1, 1.0, v2, 1.0                      // 000000840AEC: D6FC0110 03CA04F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000840AF4: BF870292
	v_rcp_f32_e32 v12, v7                                      // 000000840AF8: 7E185507
	v_fma_f32 v14, -v7, v12, 1.0                               // 000000840AFC: D613000E 23CA1907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000840B04: BF870121
	v_fmac_f32_e32 v12, v14, v12                               // 000000840B08: 5618190E
	v_mul_f32_e32 v14, v13, v8                                 // 000000840B0C: 101C110D
	v_mul_f32_e32 v18, v16, v12                                // 000000840B10: 10241910
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000840B14: BF870112
	v_fma_f32 v19, -v5, v14, v13                               // 000000840B18: D6130013 24361D05
	v_fma_f32 v21, -v7, v18, v16                               // 000000840B20: D6130015 24422507
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000840B28: BF870112
	v_fmac_f32_e32 v14, v19, v8                                // 000000840B2C: 561C1113
	v_fmac_f32_e32 v18, v21, v12                               // 000000840B30: 56241915
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000840B34: BF870112
	v_fma_f32 v5, -v5, v14, v13                                // 000000840B38: D6130005 24361D05
	v_fma_f32 v7, -v7, v18, v16                                // 000000840B40: D6130007 24422507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000840B48: BF870142
	v_div_fmas_f32 v5, v5, v8, v14                             // 000000840B4C: D6370005 043A1105
	s_mov_b32 vcc_lo, s0                                       // 000000840B54: BEEA0000
	v_div_fmas_f32 v6, v6, v11, v17                            // 000000840B58: D6370006 04461706
	s_mov_b32 vcc_lo, s1                                       // 000000840B60: BEEA0001
	v_div_fixup_f32 v5, v5, v3, 1.0                            // 000000840B64: D6270005 03CA0705
	v_div_fmas_f32 v7, v7, v12, v18                            // 000000840B6C: D6370007 044A1907
	.long 0xd7006a00                                           // 000000840B74: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000840B78: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000840B7C: BF870221
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000840B80: D5207C01 01AA0209
	v_div_fixup_f32 v4, v6, v4, 1.0                            // 000000840B88: D6270004 03CA0906
	v_div_fixup_f32 v6, v7, v2, 1.0                            // 000000840B90: D6270006 03CA0507
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000840B98: BF870094
	.long 0xd7006a02                                           // 000000840B9C: D7006A02
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 000000840BA0: 02000500
	v_add_co_ci_u32_e64 v3, null, s3, v1, vcc_lo               // 000000840BA4: D5207C03 01AA0203
	s_delay_alu instid0(VALU_DEP_4)                            // 000000840BAC: BF870004
	v_dual_add_f32 v7, v5, v5 :: v_dual_add_f32 v8, v4, v4     // 000000840BB0: C9080B05 07080904
	.long 0xd7006a04                                           // 000000840BB8: D7006A04
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000840BBC: 02000900
	v_add_f32_e32 v6, v6, v6                                   // 000000840BC0: 060C0D06
	v_add_co_ci_u32_e64 v5, null, s5, v1, vcc_lo               // 000000840BC4: D5207C05 01AA0205
	s_clause 0x2                                               // 000000840BCC: BF850002
	global_store_b32 v[0:1], v7, off                           // 000000840BD0: DC6A0000 007C0700
	global_store_b32 v[2:3], v8, off                           // 000000840BD8: DC6A0000 007C0802
	global_store_b32 v[4:5], v6, off                           // 000000840BE0: DC6A0000 007C0604
	s_endpgm                                                   // 000000840BE8: BFB00000
		...

