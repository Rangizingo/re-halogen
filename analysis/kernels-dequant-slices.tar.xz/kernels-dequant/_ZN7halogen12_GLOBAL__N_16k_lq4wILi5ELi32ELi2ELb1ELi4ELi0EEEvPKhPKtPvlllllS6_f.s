0000000000f98d00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000F98D00: F4100100 F8000000
	v_dual_mov_b32 v28, 0 :: v_dual_and_b32 v1, 15, v0         // 000000F98D08: CA240080 1C00008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000F98D10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000F98D14: 86039F02
	v_mov_b32_e32 v5, 0                                        // 000000F98D18: 7E0A0280
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000F98D1C: 84828202
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F98D20: 30020282
	v_and_b32_e32 v2, 60, v2                                   // 000000F98D24: 360404BC
	v_lshrrev_b32_e32 v14, 6, v0                               // 000000F98D28: 321C0086
	v_bfe_u32 v15, v0, 5, 1                                    // 000000F98D2C: D610000F 02050B00
	.long 0x7f103880                                           // 000000F98D34: 7F103880
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v6, 0              // 000000F98D38: CA100080 11060080
	s_waitcnt lgkmcnt(0)                                       // 000000F98D40: BF89FC07
	s_clause 0x1                                               // 000000F98D44: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000F98D48: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000F98D50: DC520000 04040002
	v_mov_b32_e32 v2, s3                                       // 000000F98D58: 7E040203
	v_or_b32_e32 v1, s2, v14                                   // 000000F98D5C: 38021C02
	s_add_u32 s0, s4, s14                                      // 000000F98D60: 80000E04
	s_addc_u32 s1, s5, s15                                     // 000000F98D64: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 000000F98D68: 850E9F0B
	v_and_b32_e32 v16, 31, v0                                  // 000000F98D6C: 3620009F
	s_add_u32 s14, s10, s14                                    // 000000F98D70: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000F98D74: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000F98D78: 86149F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000F98D7C: 7CA8020C
	s_lshr_b32 s20, s20, 27                                    // 000000F98D80: 85149B14
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000F98D84: 868E810E
	s_add_u32 s20, s10, s20                                    // 000000F98D88: 8014140A
	s_addc_u32 s21, s11, 0                                     // 000000F98D8C: 8215800B
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000F98D90: 02020280
	s_lshr_b64 s[20:21], s[20:21], 5                           // 000000F98D94: 85948514
	v_cndmask_b32_e64 v7, 0, s3, vcc_lo                        // 000000F98D98: D5010007 01A80680
	s_add_i32 s21, s20, 1                                      // 000000F98DA0: 81158114
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F98DA4: BF870002
	.long 0xd72c0002                                           // 000000F98DA8: D72C0002
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000F98DAC: 02020213
	s_lshr_b32 s19, s21, 31                                    // 000000F98DB0: 85139F15
	.long 0xd72c000d                                           // 000000F98DB4: D72C000D
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 000000F98DB8: 02001F01
	s_add_i32 s21, s21, s19                                    // 000000F98DBC: 81151315
	v_mad_u64_u32 v[9:10], null, v1, s14, s[0:1]               // 000000F98DC0: D6FE7C09 00001D01
	s_ashr_i32 s15, s21, 1                                     // 000000F98DC8: 860F8115
	s_add_u32 s0, s4, s16                                      // 000000F98DCC: 80001004
	.long 0xd72c0012                                           // 000000F98DD0: D72C0012
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 000000F98DD4: 02021E0F
	s_addc_u32 s1, s5, s17                                     // 000000F98DD8: 82011105
	.long 0xd72c0014                                           // 000000F98DDC: D72C0014
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 000000F98DE0: 02001D07
	.long 0xd72c0015                                           // 000000F98DE4: D72C0015
	v_cndmask_b32_e32 v1, s18, v7, vcc_lo                      // 000000F98DE8: 02020E12
	v_mov_b32_e32 v7, 0                                        // 000000F98DEC: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000F98DF0: BF870153
	v_add3_u32 v10, v20, v10, v13                              // 000000F98DF4: D655000A 04361514
	s_waitcnt vmcnt(1)                                         // 000000F98DFC: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 000000F98E00: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 000000F98E08: BF8903F7
	v_bfe_u32 v19, v4, 16, 1                                   // 000000F98E0C: D6100013 02052104
	v_add3_u32 v3, v3, v11, 0x7fff                             // 000000F98E14: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v1, s[0:1]              // 000000F98E20: D6FE7C0B 00020212
	v_add_nc_u32_e32 v1, s15, v18                              // 000000F98E28: 4A02240F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000F98E2C: BF870004
	v_add3_u32 v4, v4, v19, 0x7fff                             // 000000F98E30: D6550004 03FE2704 00007FFF
	v_add_nc_u32_e32 v18, v18, v16                             // 000000F98E3C: 4A242112
	.long 0x7e103983                                           // 000000F98E40: 7E103983
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000F98E44: 30060082
	v_min_i32_e32 v19, s20, v1                                 // 000000F98E48: 22260214
	v_add3_u32 v20, v2, v12, v21                               // 000000F98E4C: D6550014 04561902
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F98E54: BF870224
	v_and_or_b32 v1, 0xffff0000, v4, v8                        // 000000F98E58: D6570001 042208FF FFFF0000
	v_mov_b32_e32 v8, 0                                        // 000000F98E64: 7E100280
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 000000F98E68: 7C822712
	ds_store_b32 v3, v1                                        // 000000F98E6C: D8340000 00000103
	s_waitcnt lgkmcnt(0)                                       // 000000F98E74: BF89FC07
	s_barrier                                                  // 000000F98E78: BFBD0000
	buffer_gl0_inv                                             // 000000F98E7C: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000F98E84: BE81206A
	s_cbranch_execz 21                                         // 000000F98E88: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x1e0>
	v_lshlrev_b32_e32 v1, 1, v18                               // 000000F98E8C: 30022481
	v_lshlrev_b32_e32 v3, 4, v18                               // 000000F98E90: 30062484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F98E94: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000F98E98: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000F98E9C: 3408069F
	.long 0xd7000001                                           // 000000F98EA0: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000F98EA4: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F98EA8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000F98EAC: D5207C02 00020514
	.long 0xd7000003                                           // 000000F98EB4: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 000000F98EB8: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 000000F98EBC: D5207C04 0002090A
	s_clause 0x1                                               // 000000F98EC4: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 000000F98EC8: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 000000F98ED0: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 000000F98ED8: BF8907F7
	v_cvt_f32_f16_e32 v28, v1                                  // 000000F98EDC: 7E381701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F98EE0: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000F98EE4: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v21, 0             // 000000F98EEC: CA100080 18140080
	s_and_saveexec_b32 s1, vcc_lo                              // 000000F98EF4: BE81206A
	s_cbranch_execz 460                                        // 000000F98EF8: BFA501CC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x92c>
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v1, 32, v18     // 000000F98EFC: CA200080 180024A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v18    // 000000F98F04: CA220080 150C2485
	v_mov_b32_e32 v17, 0                                       // 000000F98F0C: 7E220280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F98F10: BF870003
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v25, 4, v1     // 000000F98F14: CA220080 16180284
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v26, 1, v1     // 000000F98F1C: CA220080 171A0281
	v_mov_b32_e32 v27, v28                                     // 000000F98F24: 7E36031C
	s_mul_i32 s0, s11, 6                                       // 000000F98F28: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000F98F2C: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000F98F30: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000F98F34: 810E000E
	s_mul_i32 s16, s10, 6                                      // 000000F98F38: 9610860A
	s_mov_b32 s15, 0                                           // 000000F98F3C: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000F98F40: 848A810A
	s_branch 409                                               // 000000F98F44: BFA00199 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x8ac>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000F98F48: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 000000F98F4C: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000F98F54: 8B006A7E
	v_add_nc_u32_e32 v25, 0x200, v25                           // 000000F98F58: 4A3232FF 00000200
	s_or_b32 s15, s0, s15                                      // 000000F98F60: 8C0F0F00
	v_add_nc_u32_e32 v26, 64, v26                              // 000000F98F64: 4A3434C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000F98F68: 301A1A82
	ds_load_b32 v45, v13                                       // 000000F98F6C: D8D80000 2D00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 000000F98F74: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F98F78: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000F98F7C: 361A1AFF 000003FC
	ds_load_b32 v46, v13                                       // 000000F98F84: D8D80000 2E00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 000000F98F8C: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 000000F98F90: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000F98F94: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000F98F9C: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F98FA0: 360A0AFF 000003FC
	ds_load_b32 v47, v13                                       // 000000F98FA8: D8D80000 2F00000D
	ds_load_b32 v48, v5                                        // 000000F98FB0: D8D80000 30000005
	v_and_b32_e32 v5, 0xff, v6                                 // 000000F98FB8: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000F98FC0: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000F98FC4: 300A0A82
	ds_load_b32 v49, v5                                        // 000000F98FC8: D8D80000 31000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 000000F98FD0: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F98FD4: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F98FD8: 360A0AFF 000003FC
	ds_load_b32 v50, v5                                        // 000000F98FE0: D8D80000 32000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 000000F98FE8: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F98FEC: 360A0AFF 000003FC
	ds_load_b32 v51, v5                                        // 000000F98FF4: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 000000F98FFC: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F99000: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F99004: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 000000F9900C: D8D80000 34000005
	v_and_b32_e32 v5, 0xff, v7                                 // 000000F99014: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000F9901C: 300A0A82
	ds_load_b32 v53, v5                                        // 000000F99020: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 000000F99028: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F9902C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F99030: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 000000F99038: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000F99040: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F99044: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 000000F9904C: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 000000F99054: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F99058: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F9905C: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 000000F99064: D8D80000 38000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000F9906C: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000F99074: 300A0A82
	ds_load_b32 v57, v5                                        // 000000F99078: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000F99080: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F99084: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F99088: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 000000F99090: D8D80000 3A000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 000000F99098: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F9909C: 360A0AFF 000003FC
	ds_load_b32 v59, v5                                        // 000000F990A4: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 000000F990AC: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F990B0: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000F990B4: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 000000F990BC: D8D80000 3C000005
	.long 0xd73c0005                                           // 000000F990C4: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000F990C8: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000F990CC: 4A1818FF 00000400
	.long 0xd7006a29                                           // 000000F990D4: D7006A29
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000F990D8: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F990DC: BF870001
	v_add_co_ci_u32_e64 v42, null, s7, v6, vcc_lo              // 000000F990E0: D5207C2A 01AA0C07
	s_clause 0x3                                               // 000000F990E8: BF850003
	global_load_b128 v[5:8], v[41:42], off                     // 000000F990EC: DC5E0000 057C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 000000F990F4: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 000000F990FC: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 000000F99104: DC5E0030 257C0029
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000F9910C: BF890CF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 000000F99110: CC1A4005 1A025B05
	s_waitcnt lgkmcnt(14)                                      // 000000F99118: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F9911C: BF8700A1
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 000000F99120: CC1A4005 1C165D06
	s_waitcnt lgkmcnt(13)                                      // 000000F99128: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 000000F9912C: CC1A4005 1C165F07
	s_waitcnt lgkmcnt(12)                                      // 000000F99134: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F99138: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000F9913C: CC1A4005 1C166108
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000F99144: BF8908B7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000F99148: CC1A4005 1C16631D
	s_waitcnt lgkmcnt(10)                                      // 000000F99150: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F99154: BF8700A1
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000F99158: CC1A4005 1C16651E
	s_waitcnt lgkmcnt(9)                                       // 000000F99160: BF89FC97
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000F99164: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(8)                                       // 000000F9916C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F99170: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000F99174: CC1A4005 1C166920
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000F9917C: BF890477
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000F99180: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(6)                                       // 000000F99188: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F9918C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000F99190: CC1A4005 1C166D22
	s_waitcnt lgkmcnt(5)                                       // 000000F99198: BF89FC57
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000F9919C: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(4)                                       // 000000F991A4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F991A8: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000F991AC: CC1A4005 1C167124
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000F991B4: BF890037
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000F991B8: CC1A4005 1C167325
	.long 0xd7006a25                                           // 000000F991C0: D7006A25
	v_cndmask_b32_e32 v0, v41, v10, vcc_lo                     // 000000F991C4: 02001529
	s_waitcnt lgkmcnt(2)                                       // 000000F991C8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000F991CC: BF8701C2
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000F991D0: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s11, v42, vcc_lo            // 000000F991D8: D5207C26 01AA540B
	.long 0xd7006a2b                                           // 000000F991E0: D7006A2B
	v_cndmask_b32_e32 v0, v41, v4, vcc_lo                      // 000000F991E4: 02000929
	s_waitcnt lgkmcnt(1)                                       // 000000F991E8: BF89FC17
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000F991EC: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v44, null, s5, v42, vcc_lo             // 000000F991F4: D5207C2C 01AA5405
	s_waitcnt lgkmcnt(0)                                       // 000000F991FC: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F99200: BF870092
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000F99204: CC1A4005 1C167928
	v_fmac_f32_e32 v21, v28, v5                                // 000000F9920C: 562A0B1C
	s_clause 0x3                                               // 000000F99210: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 000000F99214: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 000000F9921C: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 000000F99224: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 000000F9922C: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 000000F99234: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 000000F99238: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F99240: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 000000F99244: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 000000F9924C: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F99254: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000F99258: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 000000F99260: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000F99264: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9926C: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000F99270: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000F99278: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F99280: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000F99284: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 000000F9928C: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000F99290: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F99298: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000F9929C: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000F992A4: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F992AC: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000F992B0: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 000000F992B8: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000F992BC: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F992C4: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000F992C8: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000F992D0: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F992D8: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000F992DC: CC1A4005 1C167928
	v_fmac_f32_e32 v24, v28, v5                                // 000000F992E4: 56300B1C
	s_clause 0x3                                               // 000000F992E8: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 000000F992EC: DC5E0000 057C002B
	global_load_b128 v[29:32], v[43:44], off offset:16         // 000000F992F4: DC5E0010 1D7C002B
	global_load_b128 v[33:36], v[43:44], off offset:32         // 000000F992FC: DC5E0020 217C002B
	global_load_b128 v[37:40], v[43:44], off offset:48         // 000000F99304: DC5E0030 257C002B
	s_waitcnt vmcnt(3)                                         // 000000F9930C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 000000F99310: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F99318: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 000000F9931C: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 000000F99324: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F9932C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000F99330: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 000000F99338: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000F9933C: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F99344: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000F99348: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000F99350: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F99358: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000F9935C: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 000000F99364: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000F99368: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F99370: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000F99374: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000F9937C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F99384: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000F99388: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 000000F99390: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000F99394: CC1A4005 1C167325
	.long 0xd7006a25                                           // 000000F9939C: D7006A25
	v_cndmask_b32_e32 v0, v41, v16, vcc_lo                     // 000000F993A0: 02002129
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F993A4: BF870122
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000F993A8: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s14, v42, vcc_lo            // 000000F993B0: D5207C26 01AA540E
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000F993B8: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F993C0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000F993C4: CC1A4005 1C167928
	v_fmac_f32_e32 v23, v28, v5                                // 000000F993CC: 562E0B1C
	s_clause 0x3                                               // 000000F993D0: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 000000F993D4: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 000000F993DC: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 000000F993E4: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 000000F993EC: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 000000F993F4: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 000000F993F8: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F99400: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 000000F99404: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 000000F9940C: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F99414: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000F99418: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 000000F99420: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000F99424: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9942C: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000F99430: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000F99438: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F99440: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000F99444: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 000000F9944C: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000F99450: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F99458: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000F9945C: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000F99464: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F9946C: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000F99470: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 000000F99478: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000F9947C: CC1A4005 1C167325
	.long 0xd7006a25                                           // 000000F99484: D7006A25
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 000000F99488: 0200092B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F9948C: BF870122
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000F99490: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s5, v44, vcc_lo             // 000000F99498: D5207C26 01AA5805
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000F994A0: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F994A8: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000F994AC: CC1A4005 1C167928
	v_fmac_f32_e32 v22, v28, v5                                // 000000F994B4: 562C0B1C
	s_clause 0x3                                               // 000000F994B8: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 000000F994BC: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 000000F994C4: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 000000F994CC: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 000000F994D4: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 000000F994DC: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 000000F994E0: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F994E8: BF870121
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 000000F994EC: CC1A4005 1C165D06
	v_mov_b32_e32 v6, v2                                       // 000000F994F4: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 000000F994F8: CC1A4005 1C165F07
	v_mov_b32_e32 v7, v3                                       // 000000F99500: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000F99504: BF870132
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000F99508: CC1A4005 1C166108
	v_mov_b32_e32 v8, v4                                       // 000000F99510: 7E100304
	s_waitcnt vmcnt(2)                                         // 000000F99514: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000F99518: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F99520: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000F99524: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000F9952C: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F99534: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000F99538: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 000000F99540: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000F99544: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9954C: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000F99550: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000F99558: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F99560: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000F99564: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 000000F9956C: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000F99570: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F99578: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000F9957C: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000F99584: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9958C: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000F99590: CC1A4005 1C167928
	v_fmac_f32_e32 v17, v28, v5                                // 000000F99598: 56220B1C
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v28, v27           // 000000F9959C: CA100101 051C011B
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000F995A4: 917E0F7E
	s_cbranch_execz 31                                         // 000000F995A8: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x928>
	s_waitcnt vmcnt(0)                                         // 000000F995AC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000F995B0: BF8701C1
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v18, 32, v18    // 000000F995B4: CA200105 011224A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000F995BC: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 000000F995C4: 7E080308
	s_mov_b32 s17, exec_lo                                     // 000000F995C8: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 000000F995CC: 7C8C2712
	.long 0xd4c1007e                                           // 000000F995D0: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000F995D4: 02022712
	s_cbranch_execz 65115                                      // 000000F995D8: BFA5FE5B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x248>
	v_ashrrev_i32_e32 v2, 31, v26                              // 000000F995DC: 3404349F
	v_ashrrev_i32_e32 v4, 31, v25                              // 000000F995E0: 3408329F
	.long 0xd7000001                                           // 000000F995E4: D7000001
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 000000F995E8: 0202350B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F995EC: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000F995F0: D5207C02 00020514
	.long 0xd7000003                                           // 000000F995F8: D7000003
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 000000F995FC: 02023309
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 000000F99600: D5207C04 0002090A
	s_clause 0x1                                               // 000000F99608: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 000000F9960C: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000F99614: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000F9961C: BF8907F7
	v_cvt_f32_f16_e32 v27, v13                                 // 000000F99620: 7E36170D
	s_branch 65096                                             // 000000F99624: BFA0FE48 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x248>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000F99628: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F9962C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F99630: 8C7E017E
	.long 0xd71f0001                                           // 000000F99634: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000F99638: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000F9963C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000F99640: 3A040290
	s_waitcnt vmcnt(0)                                         // 000000F99644: BF8903F7
	v_xor_b32_e32 v7, 8, v1                                    // 000000F99648: 3A0E0288
	v_xor_b32_e32 v12, 4, v1                                   // 000000F9964C: 3A180284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F99650: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000F99654: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000F99658: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 000000F9965C: 7C980EA0
	v_cndmask_b32_e32 v7, v1, v7, vcc_lo                       // 000000F99660: 020E0F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000F99664: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F99668: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000F9966C: 300E0E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000F99670: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 000000F99674: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 000000F9967C: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 000000F99680: 06060715
	ds_bpermute_b32 v4, v2, v24                                // 000000F99684: DACC0000 04001802
	ds_bpermute_b32 v5, v2, v23                                // 000000F9968C: DACC0000 05001702
	ds_bpermute_b32 v6, v2, v22                                // 000000F99694: DACC0000 06001602
	ds_bpermute_b32 v2, v2, v17                                // 000000F9969C: DACC0000 02001102
	ds_bpermute_b32 v8, v7, v3                                 // 000000F996A4: DACC0000 08000307
	s_waitcnt lgkmcnt(3)                                       // 000000F996AC: BF89FC37
	v_dual_add_f32 v4, v24, v4 :: v_dual_add_f32 v5, v23, v5   // 000000F996B0: C9080918 04040B17
	s_waitcnt lgkmcnt(2)                                       // 000000F996B8: BF89FC27
	v_add_f32_e32 v6, v22, v6                                  // 000000F996BC: 060C0D16
	s_waitcnt lgkmcnt(0)                                       // 000000F996C0: BF89FC07
	v_dual_add_f32 v2, v17, v2 :: v_dual_add_f32 v3, v3, v8    // 000000F996C4: C9080511 02021103
	ds_bpermute_b32 v9, v7, v4                                 // 000000F996CC: DACC0000 09000407
	ds_bpermute_b32 v10, v7, v5                                // 000000F996D4: DACC0000 0A000507
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 000000F996DC: 02181901
	ds_bpermute_b32 v11, v7, v6                                // 000000F996E0: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v2                                 // 000000F996E8: DACC0000 07000207
	v_lshlrev_b32_e32 v12, 2, v12                              // 000000F996F0: 30181882
	s_waitcnt lgkmcnt(2)                                       // 000000F996F4: BF89FC27
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v10    // 000000F996F8: C9081304 04041505
	ds_bpermute_b32 v8, v12, v4                                // 000000F99700: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 000000F99708: DACC0000 0900050C
	s_waitcnt lgkmcnt(3)                                       // 000000F99710: BF89FC37
	v_add_f32_e32 v6, v6, v11                                  // 000000F99714: 060C1706
	s_waitcnt lgkmcnt(1)                                       // 000000F99718: BF89FC17
	v_add_f32_e32 v4, v4, v8                                   // 000000F9971C: 06081104
	v_add_f32_e32 v2, v2, v7                                   // 000000F99720: 06040F02
	ds_bpermute_b32 v7, v12, v3                                // 000000F99724: DACC0000 0700030C
	s_waitcnt lgkmcnt(1)                                       // 000000F9972C: BF89FC17
	v_add_f32_e32 v5, v5, v9                                   // 000000F99730: 060A1305
	ds_bpermute_b32 v10, v12, v6                               // 000000F99734: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 000000F9973C: DACC0000 0B00020C
	v_xor_b32_e32 v12, 2, v1                                   // 000000F99744: 3A180282
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F99748: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000F9974C: 7C9818A0
	s_waitcnt lgkmcnt(2)                                       // 000000F99750: BF89FC27
	v_dual_add_f32 v3, v3, v7 :: v_dual_cndmask_b32 v12, v1, v12// 000000F99754: C9120F03 030C1901
	s_waitcnt lgkmcnt(1)                                       // 000000F9975C: BF89FC17
	v_add_f32_e32 v6, v6, v10                                  // 000000F99760: 060C1506
	s_waitcnt lgkmcnt(0)                                       // 000000F99764: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 000000F99768: 06041702
	v_lshlrev_b32_e32 v12, 2, v12                              // 000000F9976C: 30181882
	ds_bpermute_b32 v7, v12, v3                                // 000000F99770: DACC0000 0700030C
	ds_bpermute_b32 v8, v12, v4                                // 000000F99778: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 000000F99780: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 000000F99788: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 000000F99790: DACC0000 0B00020C
	v_xor_b32_e32 v12, 1, v1                                   // 000000F99798: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F9979C: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000F997A0: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 000000F997A4: 02021901
	s_waitcnt lgkmcnt(4)                                       // 000000F997A8: BF89FC47
	v_dual_add_f32 v1, v3, v7 :: v_dual_lshlrev_b32 v12, 2, v1 // 000000F997AC: C9220F03 010C0282
	s_waitcnt lgkmcnt(2)                                       // 000000F997B4: BF89FC27
	v_dual_add_f32 v3, v4, v8 :: v_dual_add_f32 v4, v5, v9     // 000000F997B8: C9081104 03041305
	s_waitcnt lgkmcnt(1)                                       // 000000F997C0: BF89FC17
	v_add_f32_e32 v7, v6, v10                                  // 000000F997C4: 060E1506
	s_waitcnt lgkmcnt(0)                                       // 000000F997C8: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 000000F997CC: 06041702
	ds_bpermute_b32 v5, v12, v1                                // 000000F997D0: DACC0000 0500010C
	ds_bpermute_b32 v8, v12, v3                                // 000000F997D8: DACC0000 0800030C
	ds_bpermute_b32 v9, v12, v4                                // 000000F997E0: DACC0000 0900040C
	ds_bpermute_b32 v10, v12, v7                               // 000000F997E8: DACC0000 0A00070C
	ds_bpermute_b32 v6, v12, v2                                // 000000F997F0: DACC0000 0600020C
	v_cmpx_eq_u32_e32 0, v16                                   // 000000F997F8: 7D942080
	s_cbranch_execz 21                                         // 000000F997FC: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xb54>
	.long 0xd72c000b                                           // 000000F99800: D72C000B
	v_cndmask_b32_e32 v0, v14, v168, vcc_lo                    // 000000F99804: 0201510E
	s_waitcnt lgkmcnt(0)                                       // 000000F99808: BF89FC07
	v_dual_add_f32 v1, v1, v5 :: v_dual_add_f32 v2, v2, v6     // 000000F9980C: C9080B01 01020D02
	v_dual_add_f32 v7, v7, v10 :: v_dual_add_f32 v4, v4, v9    // 000000F99814: C9081507 07041304
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9981C: BF870093
	v_mad_u32_u24 v11, v15, 20, v11                            // 000000F99820: D60B000B 042D290F
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_nc_u32 v8, 0x408, v11// 000000F99828: C9201103 030816FF 00000408
	v_add_nc_u32_e32 v5, 0x400, v11                            // 000000F99834: 4A0A16FF 00000400
	ds_store_2addr_b32 v5, v1, v3 offset1:1                    // 000000F9983C: D8380100 00030105
	ds_store_2addr_b32 v8, v4, v7 offset1:1                    // 000000F99844: D8380100 00070408
	ds_store_b32 v11, v2 offset:1040                           // 000000F9984C: D8340410 0000020B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000F99854: 8C7E007E
	.long 0xd7050001                                           // 000000F99858: D7050001
	v_cndmask_b32_e32 v1, 0xcd, v0, vcc_lo                     // 000000F9985C: 020200FF 000000CD
	.long 0x7f063880                                           // 000000F99864: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 000000F99868: BF89FC07
	s_barrier                                                  // 000000F9986C: BFBD0000
	buffer_gl0_inv                                             // 000000F99870: E0AC0000 00000000
	.long 0xd7390003                                           // 000000F99878: D7390003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000F9987C: 0202028A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F99880: BF870091
	.long 0xd7000001                                           // 000000F99884: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000F99888: 02020602
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 000000F9988C: D5207C02 00010003
	.long 0xd44c0000                                           // 000000F99894: D44C0000
	v_cndmask_b32_e32 v1, 20, v0, vcc_lo                       // 000000F99898: 02020094
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000F9989C: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000F998A0: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 000000F998A4: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 000000F998A8: BE812000
	s_cbranch_execz 68                                         // 000000F998AC: BFA50044 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xcc0>
	.long 0xd7054000                                           // 000000F998B0: D7054000
	v_cndmask_b32_e32 v0, v3, v133, vcc_lo                     // 000000F998B4: 02010B03
	v_mul_u32_u24_e32 v3, 40, v3                               // 000000F998B8: 160606A8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F998BC: BF870092
	.long 0xd7041000                                           // 000000F998C0: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 000000F998C4: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 000000F998C8: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F998D0: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 000000F998D4: D6460003 040D0500
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000F998DC: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:5                     // 000000F998E4: D8DC0500 03000003
	s_waitcnt lgkmcnt(0)                                       // 000000F998EC: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 000000F998F0: 06060680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F998F4: BF870091
	v_add_f32_e32 v3, v3, v4                                   // 000000F998F8: 06060903
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 000000F998FC: 100606FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000F99904: BF870291
	v_exp_f32_e32 v3, v3                                       // 000000F99908: 7E064B03
	v_add_f32_e32 v6, 1.0, v3                                  // 000000F9990C: 060C06F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F99910: BF870121
	v_div_scale_f32 v7, null, v6, v6, 1.0                      // 000000F99914: D6FC7C07 03CA0D06
	v_div_scale_f32 v9, vcc_lo, 1.0, v6, 1.0                   // 000000F9991C: D6FC6A09 03CA0CF2
	v_rcp_f32_e32 v8, v7                                       // 000000F99924: 7E105507
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F99928: BF870095
	v_fma_f32 v3, -v7, v8, 1.0                                 // 000000F9992C: D6130003 23CA1107
	v_fmac_f32_e32 v8, v3, v8                                  // 000000F99934: 56101103
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000F99938: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F99940: BF870112
	v_mul_f32_e32 v10, v9, v8                                  // 000000F99944: 10141109
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000F99948: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F99950: BF870122
	v_fma_f32 v11, -v7, v10, v9                                // 000000F99954: D613000B 24261507
	.long 0xd73c0000                                           // 000000F9995C: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000F99960: 02020282
	v_fmac_f32_e32 v10, v11, v8                                // 000000F99964: 5614110B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F99968: BF870114
	.long 0xd73c0003                                           // 000000F9996C: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000F99970: 02020682
	v_fma_f32 v5, -v7, v10, v9                                 // 000000F99974: D6130005 24261507
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F9997C: BF870191
	v_div_fmas_f32 v2, v5, v8, v10                             // 000000F99980: D6370002 042A1105
	.long 0xd7006a03                                           // 000000F99988: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000F9998C: 02020608
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F99990: BF870191
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000F99994: D5207C04 01AA0809
	v_div_fixup_f32 v2, v2, v6, 1.0                            // 000000F9999C: D6270002 03CA0D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F999A4: BF870093
	.long 0xd7006a00                                           // 000000F999A8: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000F999AC: 02020103
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000F999B0: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 000000F999B8: DC6A0000 007C0200
	s_endpgm                                                   // 000000F999C0: BFB00000
		...

