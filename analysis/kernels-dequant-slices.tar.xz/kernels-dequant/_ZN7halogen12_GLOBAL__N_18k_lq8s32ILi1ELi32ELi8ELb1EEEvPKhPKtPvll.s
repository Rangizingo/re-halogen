0000000000722a00 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi8ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi8ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000722A00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000722A04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000722A0C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 000000722A14: BE830080
	v_lshrrev_b32_e32 v14, 5, v0                               // 000000722A18: 321C0085
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v15, 31, v0         // 000000722A1C: CA240080 060E009F
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v5, 0              // 000000722A24: CA100080 10040080
	.long 0x7e2c3880                                           // 000000722A2C: 7E2C3880
	v_mov_b32_e32 v8, 0                                        // 000000722A30: 7E100280
	s_waitcnt lgkmcnt(0)                                       // 000000722A34: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000722A38: 86009F0B
	.long 0xd451000e                                           // 000000722A3C: D451000E
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000722A40: 02001802
	s_lshr_b32 s0, s0, 28                                      // 000000722A44: 85009C00
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v2, s5             // 000000722A48: CA100004 01020005
	s_add_u32 s0, s10, s0                                      // 000000722A50: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000722A54: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000722A58: BF870499
	s_ashr_i64 s[0:1], s[0:1], 4                               // 000000722A5C: 86808400
	s_add_u32 s15, s10, s0                                     // 000000722A60: 800F000A
	s_addc_u32 s1, s11, s1                                     // 000000722A64: 8201010B
	s_add_u32 s15, s15, 15                                     // 000000722A68: 800F8F0F
	s_addc_u32 s1, s1, 0                                       // 000000722A6C: 82018001
	s_and_b32 s15, s15, -16                                    // 000000722A70: 8B0FD00F
	s_and_b32 s14, s14, exec_lo                                // 000000722A74: 8B0E7E0E
	s_cselect_b32 s14, s2, 0                                   // 000000722A78: 980E8002
	s_add_i32 s16, s0, 7                                       // 000000722A7C: 81108700
	v_mad_u64_u32 v[10:11], null, s14, s15, v[1:2]             // 000000722A80: D6FE7C0A 04041E0E
	s_ashr_i32 s17, s16, 31                                    // 000000722A88: 86119F10
	s_mul_i32 s14, s14, s1                                     // 000000722A8C: 960E010E
	s_lshr_b32 s17, s17, 29                                    // 000000722A90: 85119D11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000722A94: BF870499
	s_add_i32 s16, s16, s17                                    // 000000722A98: 81101110
	s_ashr_i32 s4, s16, 3                                      // 000000722A9C: 86048310
	v_add_nc_u32_e32 v11, s14, v11                             // 000000722AA0: 4A16160E
	.long 0xd72c0003                                           // 000000722AA4: D72C0003
	v_cndmask_b32_e32 v1, s4, v14, vcc_lo                      // 000000722AA8: 02021C04
	.long 0xd7006a13                                           // 000000722AAC: D7006A13
	v_cndmask_b32_e32 v0, v10, v10, vcc_lo                     // 000000722AB0: 0200150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000722AB4: BF870191
	v_add_co_ci_u32_e64 v20, null, s11, v11, vcc_lo            // 000000722AB8: D5207C14 01AA160B
	v_add_nc_u32_e32 v1, s4, v3                                // 000000722AC0: 4A020604
	v_add_nc_u32_e32 v17, v3, v15                              // 000000722AC4: 4A221F03
	v_mov_b32_e32 v7, 0                                        // 000000722AC8: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000722ACC: BF870193
	v_min_i32_e32 v18, s0, v1                                  // 000000722AD0: 22240200
	v_lshlrev_b32_e32 v12, 4, v17                              // 000000722AD4: 30182284
	s_delay_alu instid0(VALU_DEP_2)                            // 000000722AD8: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v17, v18                          // 000000722ADC: 7C822511
	s_and_saveexec_b32 s1, vcc_lo                              // 000000722AE0: BE81206A
	s_cbranch_execz 19                                         // 000000722AE4: BFA50013 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi8ELb1EEEvPKhPKtPvll+0x134>
	v_lshlrev_b32_e32 v1, 4, v17                               // 000000722AE8: 30022284
	v_and_b32_e32 v3, -2, v17                                  // 000000722AEC: 360622C2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000722AF0: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000722AF4: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000722AF8: 3408069F
	.long 0xd7000001                                           // 000000722AFC: D7000001
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 000000722B00: 0202030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000722B04: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 000000722B08: D5207C02 0002050B
	.long 0xd7000003                                           // 000000722B10: D7000003
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 000000722B14: 02020713
	v_add_co_ci_u32_e64 v4, null, v20, v4, s0                  // 000000722B18: D5207C04 00020914
	s_clause 0x1                                               // 000000722B20: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 000000722B24: DC5E0000 057C0001
	global_load_d16_b16 v22, v[3:4], off                       // 000000722B2C: DC820000 167C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 000000722B34: 8C7E017E
	s_and_saveexec_b32 s1, vcc_lo                              // 000000722B38: BE81206A
	s_cbranch_execz 282                                        // 000000722B3C: BFA5011A <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi8ELb1EEEvPKhPKtPvll+0x5a8>
	v_dual_mov_b32 v16, 0 :: v_dual_add_nc_u32 v21, 0x200, v12 // 000000722B40: CA200080 101418FF 00000200
	s_mov_b32 s4, 0                                            // 000000722B4C: BE840080
	s_branch 244                                               // 000000722B50: BFA000F4 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi8ELb1EEEvPKhPKtPvll+0x524>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000722B54: 8C7E057E
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000722B58: 341A189F
	v_bfe_i32 v31, v5, 8, 8                                    // 000000722B5C: D611001F 02211105
	v_bfe_i32 v32, v5, 16, 8                                   // 000000722B64: D6110020 02212105
	.long 0x7f2c3880                                           // 000000722B6C: 7F2C3880
	v_bfe_i32 v33, v6, 0, 8                                    // 000000722B70: D6110021 02210106
	.long 0xd73c0017                                           // 000000722B78: D73C0017
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000722B7C: 02021881
	v_bfe_i32 v13, v5, 0, 8                                    // 000000722B80: D611000D 02210105
	v_ashrrev_i32_e32 v5, 24, v5                               // 000000722B88: 340A0A98
	v_cvt_f32_i32_e32 v31, v31                                 // 000000722B8C: 7E3E0B1F
	v_cvt_f32_i32_e32 v32, v32                                 // 000000722B90: 7E400B20
	v_bfe_i32 v34, v6, 8, 8                                    // 000000722B94: D6110022 02211106
	.long 0xd700001b                                           // 000000722B9C: D700001B
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 000000722BA0: 02022E06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000722BA4: BF870001
	v_add_co_ci_u32_e64 v28, null, s7, v24, s0                 // 000000722BA8: D5207C1C 00023007
	v_cvt_f32_i32_e32 v13, v13                                 // 000000722BB0: 7E1A0B0D
	v_bfe_i32 v35, v6, 16, 8                                   // 000000722BB4: D6110023 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 000000722BBC: 340C0C98
	s_clause 0x1                                               // 000000722BC0: BF850001
	global_load_b128 v[23:26], v[27:28], off                   // 000000722BC4: DC5E0000 177C001B
	global_load_b128 v[27:30], v[27:28], off offset:16         // 000000722BCC: DC5E0010 1B7C001B
	v_bfe_i32 v36, v7, 0, 8                                    // 000000722BD4: D6110024 02210107
	v_fma_mix_f32 v13, v22, v13, neg(0) op_sel_hi:[1,0,0]      // 000000722BDC: CC20000D 8A021B16
	v_bfe_i32 v37, v7, 8, 8                                    // 000000722BE4: D6110025 02211107
	v_bfe_i32 v38, v7, 16, 8                                   // 000000722BEC: D6110026 02212107
	v_ashrrev_i32_e32 v7, 24, v7                               // 000000722BF4: 340E0E98
	v_bfe_i32 v39, v8, 0, 8                                    // 000000722BF8: D6110027 02210108
	v_bfe_i32 v40, v8, 8, 8                                    // 000000722C00: D6110028 02211108
	v_bfe_i32 v41, v8, 16, 8                                   // 000000722C08: D6110029 02212108
	v_ashrrev_i32_e32 v8, 24, v8                               // 000000722C10: 34101098
	v_cvt_f32_i32_e32 v5, v5                                   // 000000722C14: 7E0A0B05
	v_cvt_f32_i32_e32 v33, v33                                 // 000000722C18: 7E420B21
	v_fma_mix_f32 v31, v22, v31, neg(0) op_sel_hi:[1,0,0]      // 000000722C1C: CC20001F 8A023F16
	v_fma_mix_f32 v32, v22, v32, neg(0) op_sel_hi:[1,0,0]      // 000000722C24: CC200020 8A024116
	v_bfe_u32 v45, v13, 16, 1                                  // 000000722C2C: D610002D 0205210D
	v_cvt_f32_i32_e32 v34, v34                                 // 000000722C34: 7E440B22
	v_cvt_f32_i32_e32 v35, v35                                 // 000000722C38: 7E460B23
	v_cvt_f32_i32_e32 v6, v6                                   // 000000722C3C: 7E0C0B06
	v_cvt_f32_i32_e32 v36, v36                                 // 000000722C40: 7E480B24
	v_cvt_f32_i32_e32 v37, v37                                 // 000000722C44: 7E4A0B25
	v_cvt_f32_i32_e32 v38, v38                                 // 000000722C48: 7E4C0B26
	v_cvt_f32_i32_e32 v7, v7                                   // 000000722C4C: 7E0E0B07
	v_cvt_f32_i32_e32 v39, v39                                 // 000000722C50: 7E4E0B27
	v_cvt_f32_i32_e32 v40, v40                                 // 000000722C54: 7E500B28
	v_cvt_f32_i32_e32 v41, v41                                 // 000000722C58: 7E520B29
	v_cvt_f32_i32_e32 v8, v8                                   // 000000722C5C: 7E100B08
	v_fma_mix_f32 v5, v22, v5, neg(0) op_sel_hi:[1,0,0]        // 000000722C60: CC200005 8A020B16
	v_fma_mix_f32 v33, v22, v33, neg(0) op_sel_hi:[1,0,0]      // 000000722C68: CC200021 8A024316
	v_bfe_u32 v46, v31, 16, 1                                  // 000000722C70: D610002E 0205211F
	v_bfe_u32 v47, v32, 16, 1                                  // 000000722C78: D610002F 02052120
	v_add3_u32 v13, v13, v45, 0x7fff                           // 000000722C80: D655000D 03FE5B0D 00007FFF
	v_fma_mix_f32 v34, v22, v34, neg(0) op_sel_hi:[1,0,0]      // 000000722C8C: CC200022 8A024516
	v_fma_mix_f32 v35, v22, v35, neg(0) op_sel_hi:[1,0,0]      // 000000722C94: CC200023 8A024716
	v_fma_mix_f32 v6, v22, v6, neg(0) op_sel_hi:[1,0,0]        // 000000722C9C: CC200006 8A020D16
	v_fma_mix_f32 v36, v22, v36, neg(0) op_sel_hi:[1,0,0]      // 000000722CA4: CC200024 8A024916
	v_fma_mix_f32 v37, v22, v37, neg(0) op_sel_hi:[1,0,0]      // 000000722CAC: CC200025 8A024B16
	v_fma_mix_f32 v38, v22, v38, neg(0) op_sel_hi:[1,0,0]      // 000000722CB4: CC200026 8A024D16
	v_fma_mix_f32 v7, v22, v7, neg(0) op_sel_hi:[1,0,0]        // 000000722CBC: CC200007 8A020F16
	v_fma_mix_f32 v39, v22, v39, neg(0) op_sel_hi:[1,0,0]      // 000000722CC4: CC200027 8A024F16
	v_fma_mix_f32 v40, v22, v40, neg(0) op_sel_hi:[1,0,0]      // 000000722CCC: CC200028 8A025116
	v_fma_mix_f32 v41, v22, v41, neg(0) op_sel_hi:[1,0,0]      // 000000722CD4: CC200029 8A025316
	v_fma_mix_f32 v8, v22, v8, neg(0) op_sel_hi:[1,0,0]        // 000000722CDC: CC200008 8A021116
	v_bfe_u32 v48, v5, 16, 1                                   // 000000722CE4: D6100030 02052105
	v_bfe_u32 v49, v33, 16, 1                                  // 000000722CEC: D6100031 02052121
	v_add3_u32 v32, v32, v47, 0x7fff                           // 000000722CF4: D6550020 03FE5F20 00007FFF
	v_add3_u32 v31, v31, v46, 0x7fff                           // 000000722D00: D655001F 03FE5D1F 00007FFF
	.long 0x7e2c398d                                           // 000000722D0C: 7E2C398D
	.long 0x7f543996                                           // 000000722D10: 7F543996
	v_bfe_u32 v50, v34, 16, 1                                  // 000000722D14: D6100032 02052122
	v_bfe_u32 v51, v35, 16, 1                                  // 000000722D1C: D6100033 02052123
	v_add3_u32 v5, v5, v48, 0x7fff                             // 000000722D24: D6550005 03FE6105 00007FFF
	.long 0x7e5439a0                                           // 000000722D30: 7E5439A0
	v_add3_u32 v32, v33, v49, 0x7fff                           // 000000722D34: D6550020 03FE6321 00007FFF
	v_and_or_b32 v31, 0xffff0000, v31, v22                     // 000000722D40: D657001F 045A3EFF FFFF0000
	v_bfe_u32 v52, v6, 16, 1                                   // 000000722D4C: D6100034 02052106
	v_bfe_u32 v53, v36, 16, 1                                  // 000000722D54: D6100035 02052124
	v_add3_u32 v33, v34, v50, 0x7fff                           // 000000722D5C: D6550021 03FE6522 00007FFF
	v_add3_u32 v34, v35, v51, 0x7fff                           // 000000722D68: D6550022 03FE6723 00007FFF
	v_and_or_b32 v5, 0xffff0000, v5, v42                       // 000000722D74: D6570005 04AA0AFF FFFF0000
	.long 0x7e2c39a0                                           // 000000722D80: 7E2C39A0
	.long 0x7f563996                                           // 000000722D84: 7F563996
	v_bfe_u32 v54, v37, 16, 1                                  // 000000722D88: D6100036 02052125
	v_bfe_u32 v55, v38, 16, 1                                  // 000000722D90: D6100037 02052126
	v_add3_u32 v6, v6, v52, 0x7fff                             // 000000722D98: D6550006 03FE6906 00007FFF
	.long 0x7e5639a2                                           // 000000722DA4: 7E5639A2
	v_and_or_b32 v32, 0xffff0000, v33, v22                     // 000000722DA8: D6570020 045A42FF FFFF0000
	v_bfe_u32 v56, v7, 16, 1                                   // 000000722DB4: D6100038 02052107
	v_bfe_u32 v57, v39, 16, 1                                  // 000000722DBC: D6100039 02052127
	.long 0x7f583996                                           // 000000722DC4: 7F583996
	v_and_or_b32 v6, 0xffff0000, v6, v43                       // 000000722DC8: D6570006 04AE0CFF FFFF0000
	v_bfe_u32 v45, v40, 16, 1                                  // 000000722DD4: D610002D 02052128
	v_bfe_u32 v58, v41, 16, 1                                  // 000000722DDC: D610003A 02052129
	v_add3_u32 v7, v7, v56, 0x7fff                             // 000000722DE4: D6550007 03FE7107 00007FFF
	v_bfe_u32 v13, v8, 16, 1                                   // 000000722DF0: D610000D 02052108
	v_add_nc_u32_e32 v21, 0x200, v21                           // 000000722DF8: 4A2A2AFF 00000200
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000722E00: 8B006A7E
	v_add_nc_u32_e32 v12, 0x200, v12                           // 000000722E04: 4A1818FF 00000200
	s_or_b32 s4, s0, s4                                        // 000000722E0C: 8C040400
	v_add3_u32 v8, v8, v13, 0x7fff                             // 000000722E10: D6550008 03FE1B08 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000722E1C: BF8907F7
	v_dot2_f32_bf16 v23, v23, v31, 0                           // 000000722E20: CC1A4017 1A023F17
	v_add3_u32 v31, v36, v53, 0x7fff                           // 000000722E28: D655001F 03FE6B24 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000722E34: BF870232
	v_dot2_f32_bf16 v5, v24, v5, v23                           // 000000722E38: CC1A4005 1C5E0B18
	v_add3_u32 v23, v37, v54, 0x7fff                           // 000000722E40: D6550017 03FE6D25 00007FFF
	v_add3_u32 v24, v38, v55, 0x7fff                           // 000000722E4C: D6550018 03FE6F26 00007FFF
	.long 0x7e2c399f                                           // 000000722E58: 7E2C399F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000722E5C: BF870224
	v_dot2_f32_bf16 v5, v25, v32, v5                           // 000000722E60: CC1A4005 1C164119
	v_add3_u32 v25, v39, v57, 0x7fff                           // 000000722E68: D6550019 03FE7327 00007FFF
	.long 0x7e583998                                           // 000000722E74: 7E583998
	s_delay_alu instid0(VALU_DEP_4)                            // 000000722E78: BF870004
	v_and_or_b32 v23, 0xffff0000, v23, v22                     // 000000722E7C: D6570017 045A2EFF FFFF0000
	v_add3_u32 v24, v41, v58, 0x7fff                           // 000000722E88: D6550018 03FE7529 00007FFF
	v_dot2_f32_bf16 v5, v26, v6, v5                            // 000000722E94: CC1A4005 1C160D1A
	v_add3_u32 v6, v40, v45, 0x7fff                            // 000000722E9C: D6550006 03FE5B28 00007FFF
	v_and_or_b32 v7, 0xffff0000, v7, v44                       // 000000722EA8: D6570007 04B20EFF FFFF0000
	.long 0x7e2c3999                                           // 000000722EB4: 7E2C3999
	s_waitcnt vmcnt(0)                                         // 000000722EB8: BF8903F7
	v_dot2_f32_bf16 v5, v27, v23, v5                           // 000000722EBC: CC1A4005 1C162F1B
	.long 0x7f2e3996                                           // 000000722EC4: 7F2E3996
	.long 0x7e2e3998                                           // 000000722EC8: 7E2E3998
	v_and_or_b32 v6, 0xffff0000, v6, v22                       // 000000722ECC: D6570006 045A0CFF FFFF0000
	.long 0x7e2c3909                                           // 000000722ED8: 7E2C3909
	v_dot2_f32_bf16 v5, v28, v7, v5                            // 000000722EDC: CC1A4005 1C160F1C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000722EE4: BF8701A4
	v_and_or_b32 v7, 0xffff0000, v8, v23                       // 000000722EE8: D6570007 045E10FF FFFF0000
	v_mov_b32_e32 v8, v4                                       // 000000722EF4: 7E100304
	v_dot2_f32_bf16 v5, v29, v6, v5                            // 000000722EF8: CC1A4005 1C160D1D
	v_mov_b32_e32 v6, v2                                       // 000000722F00: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000722F04: BF870122
	v_dot2_f32_bf16 v4, v30, v7, v5                            // 000000722F08: CC1A4004 1C160F1E
	v_mov_b32_e32 v7, v3                                       // 000000722F10: 7E0E0303
	v_dual_mov_b32 v5, v1 :: v_dual_add_f32 v16, v16, v4       // 000000722F14: CA080101 05100910
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000722F1C: 917E047E
	s_cbranch_execz 32                                         // 000000722F20: BFA50020 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi8ELb1EEEvPKhPKtPvll+0x5a4>
	s_waitcnt vmcnt(1)                                         // 000000722F24: BF8907F7
	v_dual_mov_b32 v2, v6 :: v_dual_add_nc_u32 v17, 32, v17    // 000000722F28: CA200106 021022A0
	s_waitcnt vmcnt(0)                                         // 000000722F30: BF8903F7
	.long 0x7e123916                                           // 000000722F34: 7E123916
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v4, v8             // 000000722F38: CA100105 01040108
	v_mov_b32_e32 v3, v7                                       // 000000722F40: 7E060307
	s_mov_b32 s5, exec_lo                                      // 000000722F44: BE85007E
	v_cmp_ge_i32_e32 vcc_lo, v17, v18                          // 000000722F48: 7C8C2511
	.long 0xd4c1007e                                           // 000000722F4C: D4C1007E
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000722F50: 02022511
	s_cbranch_execz 65279                                      // 000000722F54: BFA5FEFF <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi8ELb1EEEvPKhPKtPvll+0x154>
	v_and_b32_e32 v3, -2, v17                                  // 000000722F58: 360622C2
	v_ashrrev_i32_e32 v2, 31, v21                              // 000000722F5C: 34042A9F
	.long 0xd7000001                                           // 000000722F60: D7000001
	v_cndmask_b32_e32 v1, v10, v21, vcc_lo                     // 000000722F64: 02022B0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000722F68: BF870193
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000722F6C: 3408069F
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 000000722F70: D5207C02 0002050B
	.long 0xd7000017                                           // 000000722F78: D7000017
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 000000722F7C: 02020713
	s_delay_alu instid0(VALU_DEP_1)                            // 000000722F80: BF870001
	v_add_co_ci_u32_e64 v24, null, v20, v4, s0                 // 000000722F84: D5207C18 00020914
	s_clause 0x1                                               // 000000722F8C: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 000000722F90: DC5E0000 017C0001
	global_load_d16_b16 v9, v[23:24], off                      // 000000722F98: DC820000 097C0017
	s_branch 65260                                             // 000000722FA0: BFA0FEEC <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi8ELb1EEEvPKhPKtPvll+0x154>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000722FA4: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000722FA8: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000722FAC: 8C7E017E
	.long 0xd71f0001                                           // 000000722FB0: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000722FB4: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000722FB8: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000722FBC: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 000000722FC0: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 000000722FC4: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000722FC8: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000722FCC: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000722FD0: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 000000722FD4: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 000000722FD8: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000722FDC: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000722FE0: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000722FE4: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000722FE8: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000722FEC: 02080901
	ds_bpermute_b32 v2, v2, v16                                // 000000722FF0: DACC0000 02001002
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000722FF8: 30080882
	s_waitcnt lgkmcnt(0)                                       // 000000722FFC: BF89FC07
	v_add_f32_e32 v2, v16, v2                                  // 000000723000: 06040510
	ds_bpermute_b32 v3, v3, v2                                 // 000000723004: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 00000072300C: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000723010: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000723014: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 00000072301C: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000723020: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000723024: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000723028: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000072302C: 30080882
	s_waitcnt lgkmcnt(0)                                       // 000000723030: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000723034: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000723038: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 000000723040: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000723044: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000723048: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 00000072304C: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 000000723050: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 000000723058: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 00000072305C: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v15                                   // 000000723064: 7D941E80
	s_cbranch_execz 5                                          // 000000723068: BFA50005 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi8ELb1EEEvPKhPKtPvll+0x680>
	s_waitcnt lgkmcnt(0)                                       // 00000072306C: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 000000723070: 06020501
	v_lshlrev_b32_e32 v2, 2, v14                               // 000000723074: 30041C82
	ds_store_b32 v2, v1                                        // 000000723078: D8340000 00000102
	s_or_b32 exec_lo, exec_lo, s0                              // 000000723080: 8C7E007E
	.long 0xd4510000                                           // 000000723084: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000723088: 02001802
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 00000072308C: 7C940080
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000723090: BF890007
	s_barrier                                                  // 000000723094: BFBD0000
	buffer_gl0_inv                                             // 000000723098: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000007230A0: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007230A4: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000007230A8: BE812000
	s_cbranch_execz 24                                         // 0000007230AC: BFA50018 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi8ELb1EEEvPKhPKtPvll+0x710>
	v_mov_b32_e32 v8, 0                                        // 0000007230B0: 7E100280
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000007230B4: 84808202
	ds_load_b128 v[0:3], v8                                    // 0000007230B8: DBFC0000 00000008
	ds_load_b128 v[4:7], v8 offset:16                          // 0000007230C0: DBFC0010 04000008
	s_add_u32 s0, s8, s0                                       // 0000007230C8: 80000008
	s_addc_u32 s1, s9, s1                                      // 0000007230CC: 82010109
	s_waitcnt lgkmcnt(1)                                       // 0000007230D0: BF89FC17
	v_add_f32_e32 v0, 0, v0                                    // 0000007230D4: 06000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007230D8: BF870091
	v_add_f32_e32 v0, v0, v1                                   // 0000007230DC: 06000300
	v_add_f32_e32 v0, v0, v2                                   // 0000007230E0: 06000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007230E4: BF8700A1
	v_add_f32_e32 v0, v0, v3                                   // 0000007230E8: 06000700
	s_waitcnt lgkmcnt(0)                                       // 0000007230EC: BF89FC07
	v_add_f32_e32 v0, v0, v4                                   // 0000007230F0: 06000900
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007230F4: BF870091
	v_add_f32_e32 v0, v0, v5                                   // 0000007230F8: 06000B00
	v_add_f32_e32 v0, v0, v6                                   // 0000007230FC: 06000D00
	s_delay_alu instid0(VALU_DEP_1)                            // 000000723100: BF870001
	v_add_f32_e32 v0, v0, v7                                   // 000000723104: 06000F00
	global_store_b32 v8, v0, s[0:1]                            // 000000723108: DC6A0000 00000008
	s_endpgm                                                   // 000000723110: BFB00000
		...

