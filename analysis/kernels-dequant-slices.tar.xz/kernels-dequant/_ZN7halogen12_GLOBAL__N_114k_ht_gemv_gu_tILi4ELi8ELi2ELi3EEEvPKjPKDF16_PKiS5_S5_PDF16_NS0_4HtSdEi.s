0000000000a00300 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi():
	s_clause 0x1                                               // 000000A00300: BF850001
	s_load_b32 s3, s[0:1], 0x88                                // 000000A00304: F40000C0 F8000088
	s_load_b512 s[12:27], s[0:1], null                         // 000000A0030C: F4100300 F8000000
	v_and_b32_e32 v41, 31, v0                                  // 000000A00314: 3652009F
	v_lshrrev_b32_e32 v40, 5, v0                               // 000000A00318: 32500085
	s_mov_b32 s4, -1                                           // 000000A0031C: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000A00320: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 000000A00324: BF040302
	s_cbranch_scc1 2424                                        // 000000A00328: BFA20978 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x260c>
	s_load_b64 s[8:9], s[0:1], 0x7c                            // 000000A0032C: F4040200 F800007C
	s_sub_i32 s3, s2, s3                                       // 000000A00334: 81830302
	s_clause 0x1                                               // 000000A00338: BF850001
	s_load_b256 s[44:51], s[0:1], 0x60                         // 000000A0033C: F40C0B00 F8000060
	s_load_b256 s[36:43], s[0:1], 0x40                         // 000000A00344: F40C0900 F8000040
	s_mov_b32 s34, 0                                           // 000000A0034C: BEA20080
	s_mov_b32 s33, exec_lo                                     // 000000A00350: BEA1007E
	s_waitcnt lgkmcnt(0)                                       // 000000A00354: BF89FC07
	s_abs_i32 s4, s9                                           // 000000A00358: BE841509
	s_ashr_i32 s7, s9, 31                                      // 000000A0035C: 86079F09
	s_cvt_f32_u32 s5, s4                                       // 000000A00360: BE856504
	s_sub_i32 s6, 0, s4                                        // 000000A00364: 81860480
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000A00368: BF87029A
	v_rcp_iflag_f32_e32 v1, s5                                 // 000000A0036C: 7E025605
	v_readfirstlane_b32 s5, v1                                 // 000000A00370: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 000000A00374: A205FF05 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000A0037C: BF87059B
	s_cvt_u32_f32 s5, s5                                       // 000000A00380: BE856705
	s_mul_i32 s6, s6, s5                                       // 000000A00384: 96060506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A00388: BF870499
	s_mul_hi_u32 s6, s5, s6                                    // 000000A0038C: 96860605
	s_add_i32 s5, s5, s6                                       // 000000A00390: 81050605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A00394: BF870499
	s_mul_hi_u32 s5, s3, s5                                    // 000000A00398: 96850503
	s_mul_i32 s6, s5, s4                                       // 000000A0039C: 96060405
	s_add_i32 s10, s5, 1                                       // 000000A003A0: 810A8105
	s_sub_i32 s6, s3, s6                                       // 000000A003A4: 81860603
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A003A8: BF870009
	s_sub_i32 s11, s6, s4                                      // 000000A003AC: 818B0406
	s_cmp_ge_u32 s6, s4                                        // 000000A003B0: BF090406
	s_cselect_b32 s5, s10, s5                                  // 000000A003B4: 9805050A
	s_cselect_b32 s6, s11, s6                                  // 000000A003B8: 9806060B
	s_add_i32 s10, s5, 1                                       // 000000A003BC: 810A8105
	s_cmp_ge_u32 s6, s4                                        // 000000A003C0: BF090406
	s_cselect_b32 s4, s10, s5                                  // 000000A003C4: 9804050A
	s_ashr_i32 s11, s50, 31                                    // 000000A003C8: 860B9F32
	s_xor_b32 s4, s4, s7                                       // 000000A003CC: 8D040704
	s_lshr_b32 s1, s11, 25                                     // 000000A003D0: 8501990B
	s_sub_i32 s10, s4, s7                                      // 000000A003D4: 818A0704
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A003D8: BF870499
	s_mul_i32 s0, s10, s9                                      // 000000A003DC: 9600090A
	s_sub_i32 s30, s3, s0                                      // 000000A003E0: 819E0003
	s_add_i32 s0, s50, s1                                      // 000000A003E4: 81000132
	s_mul_i32 s31, s30, s8                                     // 000000A003E8: 961F081E
	s_ashr_i32 s0, s0, 7                                       // 000000A003EC: 86008700
	s_add_i32 s1, s31, s8                                      // 000000A003F0: 8101081F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A003F4: BF870499
	s_min_i32 s0, s0, s1                                       // 000000A003F8: 89000100
	s_sub_i32 s29, s0, s31                                     // 000000A003FC: 819D1F00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A00400: BF870499
	s_lshl_b32 s28, s29, 1                                     // 000000A00404: 841C811D
	.long 0xd4c4007e                                           // 000000A00408: D4C4007E
	v_cndmask_b32_e32 v1, s28, v40, vcc_lo                     // 000000A0040C: 0202501C
	s_cbranch_execz 503                                        // 000000A00410: BFA501F7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8f0>
	s_add_i32 s35, s48, -1                                     // 000000A00414: 8123C130
	s_cmp_lg_u64 s[40:41], 0                                   // 000000A00418: BF118028
	v_dual_mov_b32 v8, v40 :: v_dual_and_b32 v1, 1, v0         // 000000A0041C: CA240128 08000081
	s_cselect_b32 s51, -1, 0                                   // 000000A00424: 983380C1
	s_abs_i32 s52, s29                                         // 000000A00428: BEB4151D
	v_and_b32_e32 v2, 2, v0                                    // 000000A0042C: 36040082
	s_cvt_f32_u32 s0, s52                                      // 000000A00430: BE806534
	v_lshlrev_b32_e32 v6, 3, v41                               // 000000A00434: 300C5283
	v_lshlrev_b32_e32 v7, 7, v40                               // 000000A00438: 300E5087
	v_and_b32_e32 v3, 4, v0                                    // 000000A0043C: 36060084
	v_rcp_iflag_f32_e32 v4, s0                                 // 000000A00440: 7E085600
	v_and_b32_e32 v5, 8, v0                                    // 000000A00444: 360A0088
	.long 0xd44a0001                                           // 000000A00448: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000A0044C: 02020280
	.long 0xd44a0003                                           // 000000A00450: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000A00454: 02020480
	v_lshl_or_b32 v1, v40, 8, v6                               // 000000A00458: D6560001 04191128
	v_lshl_add_u32 v2, s31, 7, v7                              // 000000A00460: D6460002 041D0E1F
	s_ashr_i32 s54, s29, 31                                    // 000000A00468: 86369F1D
	s_sub_i32 s56, 0, s52                                      // 000000A0046C: 81B83480
	s_mul_i32 s8, s54, 0x1400                                  // 000000A00470: 9608FF36 00001400
	.long 0xd44c0000                                           // 000000A00478: D44C0000
	v_cndmask_b32_e32 v1, 16, v41, vcc_lo                      // 000000A0047C: 02025290
	v_readfirstlane_b32 s5, v4                                 // 000000A00480: 7E0A0504
	.long 0xd44a0004                                           // 000000A00484: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000A00488: 02020680
	v_subrev_nc_u32_e32 v9, s8, v1                             // 000000A0048C: 4E120208
	v_lshl_or_b32 v1, v41, 2, v2                               // 000000A00490: D6560001 04090529
	s_lshl_b32 s6, s29, 7                                      // 000000A00498: 8406871D
	s_mul_f32 s7, s5, 0x4f7ffffe                               // 000000A0049C: A207FF05 4F7FFFFE
	.long 0xd44a0005                                           // 000000A004A4: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000A004A8: 02020A80
	s_mov_b32 s53, 0x76543210                                  // 000000A004AC: BEB500FF 76543210
	s_lshl_b32 s55, s29, 8                                     // 000000A004B4: 8437881D
	s_cvt_u32_f32 s7, s7                                       // 000000A004B8: BE876707
	s_mov_b32 s58, 0x3db504f3                                  // 000000A004BC: BEBA00FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A004C4: BF87049A
	s_mul_i32 s56, s56, s7                                     // 000000A004C8: 96380738
	s_mul_hi_u32 s8, s7, s56                                   // 000000A004CC: 96883807
	s_sub_i32 s56, 0, s6                                       // 000000A004D0: 81B80680
	s_add_i32 s57, s7, s8                                      // 000000A004D4: 81390807
	s_branch 164                                               // 000000A004D8: BFA000A4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x46c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A004DC: BF870091
	.long 0xd7006a02                                           // 000000A004E0: D7006A02
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A004E4: 0202041A
	v_add_co_ci_u32_e64 v3, null, s27, v3, vcc_lo              // 000000A004E8: D5207C03 01AA061B
	v_sub_f32_e32 v4, v15, v13                                 // 000000A004F0: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000A004F4: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000A004FC: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000A00504: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 000000A00508: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 000000A00510: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 000000A00518: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A0051C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000A00520: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000A00524: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000A00528: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000A0052C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A00530: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A00534: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0053C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A00544: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000A0054C: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A00554: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 000000A00558: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0055C: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000A00564: D5010007 20060F07
	.long 0xd72c0006                                           // 000000A0056C: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 000000A00570: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 000000A00578: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0057C: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000A00584: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A0058C: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 000000A00590: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A00594: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000A0059C: D5010003 20060703
	.long 0xd72c0007                                           // 000000A005A4: D72C0007
	v_cndmask_b32_e32 v1, s55, v10, vcc_lo                     // 000000A005A8: 02021437
	v_add_f32_e32 v2, v2, v13                                  // 000000A005AC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A005B0: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000A005B8: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 000000A005C0: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A005C4: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A005C8: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000A005D0: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 000000A005D8: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A005DC: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000A005E4: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A005EC: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000A005F4: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 000000A005FC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A00600: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 000000A00608: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000A0060C: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 000000A00614: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A00618: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000A00620: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A00628: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000A00630: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A00638: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000A00640: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 000000A00648: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000A0064C: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 000000A00650: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A00654: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 000000A00658: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0065C: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000A00664: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A0066C: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A00670: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000A00678: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000A00680: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A00684: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000A0068C: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 000000A00694: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 000000A0069C: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s28, v8                           // 000000A006A0: 7C86101C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A006A4: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 000000A006A8: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 000000A006B0: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A006B8: BF870234
	v_mov_b32_e32 v13, v2                                      // 000000A006BC: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000A006C0: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000A006C8: D5010004 20020904
	v_permlanex16_b32 v11, v11, s53, 0xfedcba98                // 000000A006D0: D65C000B 03FC6B0B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 000000A006DC: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000A006E0: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000A006E8: D5010003 20020703
	v_permlanex16_b32 v10, v10, s53, 0xfedcba98                // 000000A006F0: D65C000A 03FC6B0A FEDCBA98
	v_permlanex16_b32 v13, v13, s53, 0xfedcba98                // 000000A006FC: D65C000D 03FC6B0D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000A00708: 060A1705
	v_permlanex16_b32 v12, v12, s53, 0xfedcba98                // 000000A0070C: D65C000C 03FC6B0C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A00718: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 000000A0071C: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 000000A00728: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0072C: BF870214
	v_fma_mixhi_f16 v2, v5, s58, 0                             // 000000A00730: CC220002 02007505
	v_add_f32_e32 v10, v3, v12                                 // 000000A00738: 06141903
	s_or_b32 s34, vcc_lo, s34                                  // 000000A0073C: 8C22226A
	v_fma_mixlo_f16 v2, v4, s58, 0                             // 000000A00740: CC210002 02007504
	v_fma_mixhi_f16 v3, v7, s58, 0                             // 000000A00748: CC220003 02007507
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A00750: BF870003
	v_fma_mixlo_f16 v3, v10, s58, 0                            // 000000A00754: CC210003 0200750A
	ds_store_b64 v6, v[2:3] offset:22016                       // 000000A0075C: D9345600 00000206
	s_and_not1_b32 exec_lo, exec_lo, s34                       // 000000A00764: 917E227E
	s_cbranch_execz 289                                        // 000000A00768: BFA50121 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8f0>
	.long 0xd72d0002                                           // 000000A0076C: D72D0002
	v_cndmask_b32_e32 v0, v8, v57, vcc_lo                      // 000000A00770: 02007308
	s_mov_b32 s6, -1                                           // 000000A00774: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A00778: BF870091
	.long 0xd72c0003                                           // 000000A0077C: D72C0003
	v_cndmask_b32_e32 v0, v2, v52, vcc_lo                      // 000000A00780: 02006902
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000A00784: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A00788: BF870121
	v_subrev_nc_u32_e32 v5, s52, v3                            // 000000A0078C: 4E0A0634
	v_cmp_le_u32_e32 vcc_lo, s52, v3                           // 000000A00790: 7C960634
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000A00794: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0079C: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000A007A0: 02040902
	v_cmp_le_u32_e32 vcc_lo, s52, v3                           // 000000A007A4: 7C960634
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A007A8: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000A007AC: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000A007B0: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s51                        // 000000A007B4: 916A337E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A007B8: BF870091
	v_xor_b32_e32 v11, s54, v2                                 // 000000A007BC: 3A160436
	v_subrev_nc_u32_e32 v10, s54, v11                          // 000000A007C0: 4E141636
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A007C4: BF8700A1
	v_mad_u64_u32 v[6:7], null, s56, v10, v[1:2]               // 000000A007C8: D6FE7C06 04061438
	v_min_i32_e32 v2, s35, v10                                 // 000000A007D0: 22041423
	v_mad_i64_i32 v[4:5], null, v2, s50, 0                     // 000000A007D4: D6FF7C04 02006502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A007DC: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000A007E0: 340E0C9F
	.long 0xd73c0002                                           // 000000A007E4: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000A007E8: 02020C81
	s_cbranch_vccnz 212                                        // 000000A007EC: BFA400D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x840>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A007F0: BF870093
	.long 0xd7006a06                                           // 000000A007F4: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000A007F8: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000A007FC: D5207C07 01AA0F05
	.long 0x7f383880                                           // 000000A00804: 7F383880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A00808: BF870112
	.long 0xd73c0006                                           // 000000A0080C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000A00810: 02020C81
	.long 0x7f3e399c                                           // 000000A00814: 7F3E399C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A00818: BF870092
	.long 0xd7006a0c                                           // 000000A0081C: D7006A0C
	v_cndmask_b32_e32 v1, s38, v6, vcc_lo                      // 000000A00820: 02020C26
	v_add_co_ci_u32_e64 v13, null, s39, v7, vcc_lo             // 000000A00824: D5207C0D 01AA0E27
	.long 0xd7006a06                                           // 000000A0082C: D7006A06
	v_cndmask_b32_e32 v1, s40, v6, vcc_lo                      // 000000A00830: 02020C28
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A00834: BF870001
	v_add_co_ci_u32_e64 v7, null, s41, v7, vcc_lo              // 000000A00838: D5207C07 01AA0E29
	global_load_b64 v[12:13], v[12:13], off                    // 000000A00840: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 000000A00848: D7006A0E
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A0084C: 0202041A
	global_load_b64 v[6:7], v[6:7], off                        // 000000A00850: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s27, v3, vcc_lo             // 000000A00858: D5207C0F 01AA061B
	s_clause 0x1                                               // 000000A00860: BF850001
	global_load_b32 v16, v[14:15], off                         // 000000A00864: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 000000A0086C: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 000000A00874: BF890FF7
	.long 0x7e1e390c                                           // 000000A00878: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 000000A0087C: BF890BF7
	v_and_b32_e32 v38, 0xffff0000, v6                          // 000000A00880: 364C0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000A00888: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0088C: BF870093
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000A00890: 301E1E90
	v_mul_f32_e32 v19, 0xbfb8aa3b, v15                         // 000000A00894: 10261EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000A0089C: BF870291
	v_exp_f32_e32 v19, v19                                     // 000000A008A0: 7E264B13
	v_dual_add_f32 v19, 1.0, v19 :: v_dual_and_b32 v12, 0xffff0000, v12// 000000A008A4: C92426F2 130C18FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A008B0: BF870111
	v_mul_f32_e32 v18, 0xbfb8aa3b, v12                         // 000000A008B4: 102418FF BFB8AA3B
	v_div_scale_f32 v23, null, v19, v19, v15                   // 000000A008BC: D6FC7C17 043E2713
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A008C4: BF8701B2
	v_exp_f32_e32 v18, v18                                     // 000000A008C8: 7E244B12
	v_lshlrev_b32_e32 v17, 16, v13                             // 000000A008CC: 30221A90
	v_div_scale_f32 v36, s7, v15, v19, v15                     // 000000A008D0: D6FC0724 043E270F
	v_rcp_f32_e32 v27, v23                                     // 000000A008D8: 7E365517
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A008DC: BF870196
	v_add_f32_e32 v18, 1.0, v18                                // 000000A008E0: 062424F2
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 000000A008E4: 102822FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A008EC: BF870195
	v_fma_f32 v35, -v23, v27, 1.0                              // 000000A008F0: D6130023 23CA3717
	v_div_scale_f32 v22, null, v18, v18, v12                   // 000000A008F8: D6FC7C16 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A00900: BF8701B3
	v_exp_f32_e32 v20, v20                                     // 000000A00904: 7E284B14
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000A00908: 361A1AFF FFFF0000
	v_div_scale_f32 v32, vcc_lo, v12, v18, v12                 // 000000A00910: D6FC6A20 0432250C
	v_rcp_f32_e32 v25, v22                                     // 000000A00918: 7E325516
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000A0091C: BF870106
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_mul_f32 v21, 0xbfb8aa3b, v13// 000000A00920: C90628F2 14141AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0092C: BF870115
	v_fma_f32 v33, -v22, v25, 1.0                              // 000000A00930: D6130021 23CA3316
	v_div_scale_f32 v24, null, v20, v20, v17                   // 000000A00938: D6FC7C18 04462914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A00940: BF8701A3
	v_exp_f32_e32 v21, v21                                     // 000000A00944: 7E2A4B15
	v_div_scale_f32 v34, s6, v17, v20, v17                     // 000000A00948: D6FC0622 04462911
	v_fmac_f32_e32 v25, v33, v25                               // 000000A00950: 56323321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000A00954: BF870313
	v_rcp_f32_e32 v29, v24                                     // 000000A00958: 7E3A5518
	v_add_f32_e32 v21, 1.0, v21                                // 000000A0095C: 062A2AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A00960: BF870115
	v_fma_f32 v37, -v24, v29, 1.0                              // 000000A00964: D6130025 23CA3B18
	v_div_scale_f32 v26, null, v21, v21, v13                   // 000000A0096C: D6FC7C1A 04362B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A00974: BF8701A2
	v_fmac_f32_e32 v29, v37, v29                               // 000000A00978: 563A3B25
	v_mul_f32_e32 v37, v32, v25                                // 000000A0097C: 104A3320
	v_rcp_f32_e32 v30, v26                                     // 000000A00980: 7E3C551A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A00984: BF870091
	v_fma_f32 v42, -v22, v37, v32                              // 000000A00988: D613002A 24824B16
	v_fmac_f32_e32 v37, v42, v25                               // 000000A00990: 564A332A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A00994: BF870115
	v_fma_f32 v33, -v26, v30, 1.0                              // 000000A00998: D6130021 23CA3D1A
	v_fma_f32 v22, -v22, v37, v32                              // 000000A009A0: D6130016 24824B16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A009A8: BF870112
	v_fmac_f32_e32 v30, v33, v30                               // 000000A009AC: 563C3D21
	v_div_fmas_f32 v22, v22, v25, v37                          // 000000A009B0: D6370016 04963316
	s_mov_b32 vcc_lo, s7                                       // 000000A009B8: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A009BC: BF8701B1
	v_div_fixup_f32 v12, v22, v18, v12                         // 000000A009C0: D627000C 04322516
	v_fmac_f32_e32 v27, v35, v27                               // 000000A009C8: 56363723
	v_div_scale_f32 v35, s8, v13, v21, v13                     // 000000A009CC: D6FC0823 04362B0D
	v_mul_f32_e32 v12, v12, v38                                // 000000A009D4: 10184D0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A009D8: BF870193
	v_mul_f32_e32 v33, v36, v27                                // 000000A009DC: 10423724
	v_mul_f32_e32 v43, v35, v30                                // 000000A009E0: 10563D23
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A009E4: BF870193
	.long 0x7e38398c                                           // 000000A009E8: 7E38398C
	v_fma_f32 v44, -v23, v33, v36                              // 000000A009EC: D613002C 24924317
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A009F4: BF870113
	v_fma_f32 v42, -v26, v43, v35                              // 000000A009F8: D613002A 248E571A
	v_fmac_f32_e32 v33, v44, v27                               // 000000A00A00: 5642372C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A00A04: BF870112
	v_fmac_f32_e32 v43, v42, v30                               // 000000A00A08: 56563D2A
	v_fma_f32 v23, -v23, v33, v36                              // 000000A00A0C: D6130017 24924317
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A00A14: BF870112
	v_fma_f32 v22, -v26, v43, v35                              // 000000A00A18: D6130016 248E571A
	v_div_fmas_f32 v23, v23, v27, v33                          // 000000A00A20: D6370017 04863717
	s_mov_b32 vcc_lo, s6                                       // 000000A00A28: BEEA0006
	s_mov_b32 s6, 0                                            // 000000A00A2C: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A00A30: BF870121
	v_div_fixup_f32 v15, v23, v19, v15                         // 000000A00A34: D627000F 043E2717
	v_lshlrev_b32_e32 v19, 16, v7                              // 000000A00A3C: 30260E90
	v_dual_mul_f32 v6, v15, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 000000A00A40: C8E40D0F 06060EFF FFFF0000
	v_mul_f32_e32 v39, v34, v29                                // 000000A00A4C: 104E3B22
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A00A50: BF870112
	.long 0x7e3e3986                                           // 000000A00A54: 7E3E3986
	v_fma_f32 v45, -v24, v39, v34                              // 000000A00A58: D613002D 248A4F18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A00A60: BF870091
	v_fmac_f32_e32 v39, v45, v29                               // 000000A00A64: 564E3B2D
	v_fma_f32 v24, -v24, v39, v34                              // 000000A00A68: D6130018 248A4F18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A00A70: BF870131
	v_div_fmas_f32 v18, v24, v29, v39                          // 000000A00A74: D6370012 049E3B18
	s_mov_b32 vcc_lo, s8                                       // 000000A00A7C: BEEA0008
	v_div_fmas_f32 v15, v22, v30, v43                          // 000000A00A80: D637000F 04AE3D16
	v_div_fixup_f32 v17, v18, v20, v17                         // 000000A00A88: D6270011 04462912
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A00A90: BF8701A2
	v_div_fixup_f32 v13, v15, v21, v13                         // 000000A00A94: D627000D 04362B0F
	v_and_b32_e32 v15, 1, v28                                  // 000000A00A9C: 361E3881
	v_mul_f32_e32 v17, v17, v19                                // 000000A00AA0: 10222711
	v_and_b32_e32 v19, 1, v31                                  // 000000A00AA4: 36263E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A00AA8: BF870214
	v_mul_f32_e32 v7, v13, v7                                  // 000000A00AAC: 100E0F0D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000A00AB0: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A00ABC: BF870214
	v_bfe_u32 v18, v17, 16, 1                                  // 000000A00AC0: D6100012 02052111
	v_add3_u32 v6, v6, v19, 0x7fff                             // 000000A00AC8: D6550006 03FE2706 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A00AD4: BF870214
	v_bfe_u32 v15, v7, 16, 1                                   // 000000A00AD8: D610000F 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 000000A00AE0: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A00AE8: BF870214
	v_add3_u32 v13, v17, v18, 0x7fff                           // 000000A00AEC: D655000D 03FE2511 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000A00AF8: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A00B00: BF870194
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000A00B04: D6550007 03FE1F07 00007FFF
	v_and_b32_e32 v17, 0xffff0000, v13                         // 000000A00B10: 36221AFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000A00B18: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000A00B1C: CC20080D 8A021910
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 000000A00B24: CC20000F 8A020D10
	s_waitcnt vmcnt(0)                                         // 000000A00B2C: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 000000A00B30: CC20000C 8A02230E
	v_and_b32_e32 v14, 0xffff0000, v7                          // 000000A00B38: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000A00B40: 916A067E
	s_cbranch_vccnz 65125                                      // 000000A00B44: BFA4FE65 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1dc>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A00B48: BF870093
	.long 0xd73c0004                                           // 000000A00B4C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000A00B50: 02020881
	.long 0xd7006a04                                           // 000000A00B54: D7006A04
	v_cndmask_b32_e32 v1, s38, v4, vcc_lo                      // 000000A00B58: 02020826
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A00B5C: BF870111
	v_add_co_ci_u32_e64 v5, null, s39, v5, vcc_lo              // 000000A00B60: D5207C05 01AA0A27
	.long 0xd7006a04                                           // 000000A00B68: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000A00B6C: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A00B70: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000A00B74: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000A00B7C: D7006A06
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A00B80: 0202041A
	v_add_co_ci_u32_e64 v7, null, s27, v3, vcc_lo              // 000000A00B84: D5207C07 01AA061B
	global_load_b64 v[4:5], v[4:5], off                        // 000000A00B8C: DC560000 047C0004
	s_clause 0x1                                               // 000000A00B94: BF850001
	global_load_b32 v14, v[6:7], off                           // 000000A00B98: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000A00BA0: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000A00BA8: BF890BF7
	.long 0x7e0e3904                                           // 000000A00BAC: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000A00BB0: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 000000A00BB8: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A00BBC: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000A00BC0: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000A00BC4: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000A00BC8: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 000000A00BD0: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 000000A00BD4: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 000000A00BDC: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 000000A00BE4: 361C0AFF FFFF0000
	s_branch 65083                                             // 000000A00BEC: BFA0FE3B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1dc>
	s_or_b32 exec_lo, exec_lo, s33                             // 000000A00BF0: 8C7E217E
	s_bfe_i32 s28, s29, 0x1001c                                // 000000A00BF4: 939CFF1D 0001001C
	s_lshr_b32 s3, s11, 28                                     // 000000A00BFC: 85039C0B
	s_lshr_b64 s[0:1], s[28:29], 29                            // 000000A00C00: 85809D1C
	s_add_i32 s3, s50, s3                                      // 000000A00C04: 81030332
	s_add_i32 s0, s0, 7                                        // 000000A00C08: 81008700
	s_lshl_b32 s1, s29, 3                                      // 000000A00C0C: 8401831D
	s_ashr_i32 s0, s0, 3                                       // 000000A00C10: 86008300
	s_lshl_b32 s4, s31, 3                                      // 000000A00C14: 8404831F
	.long 0xd72c0001                                           // 000000A00C18: D72C0001
	v_cndmask_b32_e32 v1, s0, v40, vcc_lo                      // 000000A00C1C: 02025000
	v_lshlrev_b32_e32 v11, 2, v41                              // 000000A00C20: 30165282
	s_waitcnt lgkmcnt(0)                                       // 000000A00C24: BF89FC07
	s_barrier                                                  // 000000A00C28: BFBD0000
	buffer_gl0_inv                                             // 000000A00C2C: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000A00C34: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 000000A00C38: 86008403
	s_ashr_i32 s3, s4, 31                                      // 000000A00C3C: 86039F04
	s_mul_hi_i32 s5, s10, s0                                   // 000000A00C40: 9705000A
	s_mul_i32 s0, s10, s0                                      // 000000A00C44: 9600000A
	v_min_i32_e32 v12, s1, v2                                  // 000000A00C48: 22180401
	s_add_u32 s0, s0, s4                                       // 000000A00C4C: 80000400
	s_addc_u32 s1, s5, s3                                      // 000000A00C50: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A00C54: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 000000A00C58: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v12                           // 000000A00C5C: 7C821901
	s_add_u32 s1, s24, s4                                      // 000000A00C60: 80010418
	s_addc_u32 s3, s25, s5                                     // 000000A00C64: 82030519
	s_and_saveexec_b32 s4, vcc_lo                              // 000000A00C68: BE84206A
	s_cbranch_execz 93                                         // 000000A00C6C: BFA5005D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xae4>
	.long 0xd7010002                                           // 000000A00C70: D7010002
	v_cndmask_b32_e32 v0, v41, v129, vcc_lo                    // 000000A00C74: 02010329
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A00C78: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000A00C7C: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000A00C84: 3404029F
	.long 0xd44c0000                                           // 000000A00C88: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000A00C8C: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A00C90: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 000000A00C94: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 000000A00CA0: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A00CA8: BF870114
	.long 0xd73c0005                                           // 000000A00CAC: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000A00CB0: 0202028A
	.long 0xd73c0002                                           // 000000A00CB4: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000A00CB8: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A00CBC: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 000000A00CC0: 30080E98
	v_bfe_i32 v8, v7, 7, 1                                     // 000000A00CC4: D6110008 02050F07
	.long 0xd7000009                                           // 000000A00CCC: D7000009
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000A00CD0: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A00CD4: BF870211
	v_add_co_ci_u32_e64 v10, null, s3, v6, s0                  // 000000A00CD8: D5207C0A 00020C03
	v_ashrrev_i32_e32 v4, 22, v4                               // 000000A00CE0: 34080896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A00CE4: BF870093
	.long 0xd7000005                                           // 000000A00CE8: D7000005
	v_cndmask_b32_e32 v1, v9, v2, vcc_lo                       // 000000A00CEC: 02020509
	v_add_co_ci_u32_e64 v6, null, v10, v3, s0                  // 000000A00CF0: D5207C06 0002070A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A00CF8: BF870093
	.long 0xd7000007                                           // 000000A00CFC: D7000007
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 000000A00D00: 02020909
	v_add_co_ci_u32_e64 v8, null, v10, v8, s0                  // 000000A00D04: D5207C08 0002110A
	.long 0xd7000009                                           // 000000A00D0C: D7000009
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 000000A00D10: 02021709
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A00D14: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v10, s0                  // 000000A00D18: D5207C0A 00021480
	s_clause 0x17                                              // 000000A00D20: BF850017
	global_load_b32 v4, v[5:6], off                            // 000000A00D24: DC520000 047C0005
	global_load_b32 v2, v[5:6], off offset:128                 // 000000A00D2C: DC520080 027C0005
	global_load_b32 v65, v[5:6], off offset:256                // 000000A00D34: DC520100 417C0005
	global_load_b32 v62, v[5:6], off offset:384                // 000000A00D3C: DC520180 3E7C0005
	global_load_b32 v59, v[5:6], off offset:512                // 000000A00D44: DC520200 3B7C0005
	global_load_b32 v56, v[5:6], off offset:640                // 000000A00D4C: DC520280 387C0005
	global_load_b32 v53, v[5:6], off offset:768                // 000000A00D54: DC520300 357C0005
	global_load_b32 v33, v[5:6], off offset:896                // 000000A00D5C: DC520380 217C0005
	global_load_b32 v6, v[7:8], off                            // 000000A00D64: DC520000 067C0007
	global_load_b32 v3, v[7:8], off offset:128                 // 000000A00D6C: DC520080 037C0007
	global_load_b32 v66, v[7:8], off offset:256                // 000000A00D74: DC520100 427C0007
	global_load_b32 v63, v[7:8], off offset:384                // 000000A00D7C: DC520180 3F7C0007
	global_load_b32 v60, v[7:8], off offset:512                // 000000A00D84: DC520200 3C7C0007
	global_load_b32 v57, v[7:8], off offset:640                // 000000A00D8C: DC520280 397C0007
	global_load_b32 v55, v[7:8], off offset:768                // 000000A00D94: DC520300 377C0007
	global_load_b32 v34, v[7:8], off offset:896                // 000000A00D9C: DC520380 227C0007
	global_load_b32 v5, v[9:10], off                           // 000000A00DA4: DC520000 057C0009
	global_load_b32 v67, v[9:10], off offset:128               // 000000A00DAC: DC520080 437C0009
	global_load_b32 v64, v[9:10], off offset:256               // 000000A00DB4: DC520100 407C0009
	global_load_b32 v61, v[9:10], off offset:384               // 000000A00DBC: DC520180 3D7C0009
	global_load_b32 v58, v[9:10], off offset:512               // 000000A00DC4: DC520200 3A7C0009
	global_load_b32 v54, v[9:10], off offset:640               // 000000A00DCC: DC520280 367C0009
	global_load_b32 v52, v[9:10], off offset:768               // 000000A00DD4: DC520300 347C0009
	global_load_b32 v32, v[9:10], off offset:896               // 000000A00DDC: DC520380 207C0009
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A00DE4: 8C7E047E
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v18, 0             // 000000A00DE8: CA100080 0D120080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v20, 0             // 000000A00DF0: CA100080 11140080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v22, 0             // 000000A00DF8: CA100080 13160080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v14, 0             // 000000A00E00: CA100080 150E0080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v15, 0             // 000000A00E08: CA100080 180E0080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v23, 0             // 000000A00E10: CA100080 1A160080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v25, 0             // 000000A00E18: CA100080 10180080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 000000A00E20: CA100080 1B1C0080
	s_ashr_i32 s11, s10, 31                                    // 000000A00E28: 860B9F0A
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A00E2C: BE80206A
	s_cbranch_execz 1005                                       // 000000A00E30: BFA503ED <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1ae8>
	v_dual_mov_b32 v18, 0 :: v_dual_add_nc_u32 v7, -1, v0      // 000000A00E34: CA200080 120600C1
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v30, 2, v41    // 000000A00E3C: CA220080 0D1E5282
	v_and_or_b32 v29, v0, 16, 0x5600                           // 000000A00E44: D657001D 03FD2100 00005600
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A00E50: BF870243
	v_dual_mov_b32 v22, 0 :: v_dual_and_b32 v7, 31, v7         // 000000A00E54: CA240080 16060E9F
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v20, 0             // 000000A00E5C: CA100080 11140080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v14, 0             // 000000A00E64: CA100080 130E0080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v24, 0             // 000000A00E6C: CA100080 15180080
	v_dual_mov_b32 v26, 0 :: v_dual_lshlrev_b32 v31, 2, v7     // 000000A00E74: CA220080 1A1E0E82
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 000000A00E7C: CA100080 0F100080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v28, 0             // 000000A00E84: CA100080 171C0080
	v_mov_b32_e32 v25, 0                                       // 000000A00E8C: 7E320280
	v_mov_b32_e32 v27, 0                                       // 000000A00E90: 7E360280
	s_mov_b32 s4, 0                                            // 000000A00E94: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000A00E98: B0051EEE
	s_branch 919                                               // 000000A00E9C: BFA00397 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x19fc>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000A00EA0: 8C7E067E
	s_waitcnt vmcnt(15)                                        // 000000A00EA4: BF893FF7
	v_alignbit_b32 v4, v4, v6, 16                              // 000000A00EA8: D6160004 02420D04
	s_waitcnt vmcnt(7)                                         // 000000A00EB0: BF891FF7
	v_bfe_u32 v68, v5, 12, 16                                  // 000000A00EB4: D6100044 02411905
	v_bfe_u32 v69, v5, 8, 16                                   // 000000A00EBC: D6100045 02411105
	v_bfe_u32 v70, v5, 4, 16                                   // 000000A00EC4: D6100046 02410905
	v_lshl_add_u32 v1, v1, 5, v29                              // 000000A00ECC: D6460001 04750B01
	v_and_b32_e32 v7, 0xffff, v4                               // 000000A00ED4: 360E08FF 0000FFFF
	v_bfe_u32 v74, v4, 4, 16                                   // 000000A00EDC: D610004A 02410904
	.long 0xd72c0044                                           // 000000A00EE4: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A00EE8: 020288FF 83DCD12D
	.long 0xd72c0045                                           // 000000A00EF0: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A00EF4: 02028AFF 83DCD12D
	v_bfe_u32 v6, v4, 12, 16                                   // 000000A00EFC: D6100006 02411904
	.long 0xd72c004c                                           // 000000A00F04: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 000000A00F08: 02020EFF 83DCD12D
	.long 0xd72c004a                                           // 000000A00F10: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A00F14: 020294FF 83DCD12D
	v_alignbit_b32 v72, v2, v3, 16                             // 000000A00F1C: D6160048 02420702
	.long 0xd72c0046                                           // 000000A00F24: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A00F28: 02028CFF 83DCD12D
	.long 0xd72c0049                                           // 000000A00F30: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 000000A00F34: 02020CFF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A00F3C: D6220044 03FD0144 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A00F48: D6220045 03FD0145 00006400
	v_alignbit_b32 v62, v62, v63, 16                           // 000000A00F54: D616003E 02427F3E
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A00F5C: D622004C 03FD014C 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A00F68: D622004A 03FD014A 00006400
	v_and_b32_e32 v68, 0xffff, v68                             // 000000A00F74: 368888FF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A00F7C: D6220046 03FD0146 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A00F88: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000A00F94: 30989890
	s_waitcnt vmcnt(6)                                         // 000000A00F98: BF891BF7
	v_bfe_u32 v77, v67, 4, 16                                  // 000000A00F9C: D610004D 02410943
	v_lshl_or_b32 v68, v69, 16, v68                            // 000000A00FA4: D6560044 05112145
	v_alignbit_b32 v65, v65, v66, 16                           // 000000A00FAC: D6160041 02428541
	v_alignbit_b32 v59, v59, v60, 16                           // 000000A00FB4: D616003B 0242793B
	v_and_or_b32 v74, 0xffff, v74, v76                         // 000000A00FBC: D657004A 053294FF 0000FFFF
	v_bfe_u32 v76, v67, 8, 16                                  // 000000A00FC8: D610004C 02411143
	v_pk_fma_f16 v68, v68, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A00FD0: CC0E0044 0BFC0B44 0000C931
	v_alignbit_b32 v56, v56, v57, 16                           // 000000A00FDC: D6160038 02427338
	v_alignbit_b32 v53, v53, v55, 16                           // 000000A00FE4: D6160035 02426F35
	v_pk_fma_f16 v69, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A00FEC: CC0E0045 0BFC0B4A 0000C931
	v_and_b32_e32 v71, 0xffff, v5                              // 000000A00FF8: 368E0AFF 0000FFFF
	v_bfe_u32 v5, v4, 8, 16                                    // 000000A01000: D6100005 02411104
	v_bfe_u32 v74, v72, 12, 16                                 // 000000A01008: D610004A 02411948
	.long 0xd72c004c                                           // 000000A01010: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A01014: 020298FF 83DCD12D
	v_bfe_u32 v55, v53, 12, 16                                 // 000000A0101C: D6100037 02411935
	v_alignbit_b32 v33, v33, v34, 16                           // 000000A01024: D6160021 02424521
	.long 0xd72c004b                                           // 000000A0102C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000A01030: 02020AFF 83DCD12D
	ds_load_b128 v[5:8], v1                                    // 000000A01038: DBFC0000 05000001
	ds_load_b128 v[1:4], v1 offset:5120                        // 000000A01040: DBFC1400 01000001
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A01048: 369292FF 0000FFFF
	.long 0xd72c004a                                           // 000000A01050: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A01054: 020294FF 83DCD12D
	.long 0xd72c0037                                           // 000000A0105C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A01060: 02026EFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A01068: D622004C 03FD014C 00006400
	v_cmp_eq_u32_e32 vcc_lo, v9, v12                           // 000000A01074: 7C941909
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A01078: D622004B 03FD014B 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A01084: D622004A 03FD014A 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A01090: D6220037 03FD0137 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A0109C: BF8701C3
	v_lshl_or_b32 v73, v75, 16, v73                            // 000000A010A0: D6560049 0525214B
	v_bfe_u32 v75, v72, 8, 16                                  // 000000A010A8: D610004B 02411148
	s_or_b32 s4, vcc_lo, s4                                    // 000000A010B0: 8C04046A
	v_and_b32_e32 v74, 0xffff, v74                             // 000000A010B4: 369494FF 0000FFFF
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A010BC: CC0E0049 0BFC0B49 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A010C8: BF870123
	.long 0xd72c004b                                           // 000000A010CC: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A010D0: 020296FF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 000000A010D8: BF89FC17
	v_dot2acc_f32_f16 v28, v73, v5                             // 000000A010DC: 04380B49
	s_waitcnt lgkmcnt(0)                                       // 000000A010E0: BF89FC07
	v_dot2acc_f32_f16 v27, v73, v1                             // 000000A010E4: 04360349
	v_bfe_u32 v73, v67, 12, 16                                 // 000000A010E8: D6100049 02411943
	v_and_b32_e32 v67, 0xffff, v67                             // 000000A010F0: 368686FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A010F8: D622004B 03FD014B 00006400
	v_dot2acc_f32_f16 v28, v69, v6                             // 000000A01104: 04380D45
	.long 0xd72c0047                                           // 000000A01108: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A0110C: 02028EFF 83DCD12D
	v_dot2acc_f32_f16 v27, v69, v2                             // 000000A01114: 04360545
	.long 0xd72c0049                                           // 000000A01118: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0111C: 020292FF 83DCD12D
	v_lshl_or_b32 v74, v75, 16, v74                            // 000000A01124: D656004A 0529214B
	v_dot2acc_f32_f16 v28, v68, v7                             // 000000A0112C: 04380F44
	.long 0xd72c0043                                           // 000000A01130: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A01134: 020286FF 83DCD12D
	v_dot2acc_f32_f16 v27, v68, v3                             // 000000A0113C: 04360744
	.long 0xd72c004b                                           // 000000A01140: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A01144: 02029AFF 83DCD12D
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A0114C: D6220047 03FD0147 00006400
	v_bfe_u32 v68, v65, 4, 16                                  // 000000A01158: D6100044 02410941
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A01160: D6220049 03FD0149 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0116C: BF870223
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000A01170: 308E8E90
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A01174: D6220043 03FD0143 00006400
	.long 0xd72c0044                                           // 000000A01180: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A01184: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A0118C: BF870243
	v_and_or_b32 v70, 0xffff, v70, v71                         // 000000A01190: D6570046 051E8CFF 0000FFFF
	v_and_b32_e32 v71, 0xffff, v72                             // 000000A0119C: 368E90FF 0000FFFF
	v_bfe_u32 v72, v72, 4, 16                                  // 000000A011A4: D6100048 02410948
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000A011AC: 30868690
	v_pk_fma_f16 v70, v70, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A011B0: CC0E0046 0BFC0B46 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A011BC: BF870214
	.long 0xd72c0047                                           // 000000A011C0: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A011C4: 02028EFF 83DCD12D
	.long 0xd72c0048                                           // 000000A011CC: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A011D0: 020290FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A011D8: BF870003
	v_dot2acc_f32_f16 v28, v70, v8                             // 000000A011DC: 04381146
	v_dot2acc_f32_f16 v27, v70, v4                             // 000000A011E0: 04360946
	s_waitcnt vmcnt(5)                                         // 000000A011E4: BF8917F7
	v_bfe_u32 v70, v64, 8, 16                                  // 000000A011E8: D6100046 02411140
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A011F0: D6220047 03FD0147 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A011FC: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A01208: BF870193
	.long 0xd72c0046                                           // 000000A0120C: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A01210: 02028CFF 83DCD12D
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000A01218: 308E8E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0121C: BF870221
	v_and_or_b32 v69, 0xffff, v72, v71                         // 000000A01220: D6570045 051E90FF 0000FFFF
	v_pk_fma_f16 v71, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0122C: CC0E0047 0BFC0B4A 0000C931
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A01238: D6220046 03FD0146 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A01244: BF870193
	v_pk_fma_f16 v69, v69, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A01248: CC0E0045 0BFC0B45 0000C931
	v_dot2acc_f32_f16 v25, v71, v5                             // 000000A01254: 04320B47
	v_dot2acc_f32_f16 v23, v71, v1                             // 000000A01258: 042E0347
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0125C: BF870112
	v_dot2acc_f32_f16 v25, v69, v6                             // 000000A01260: 04320D45
	v_dot2acc_f32_f16 v23, v69, v2                             // 000000A01264: 042E0545
	v_bfe_u32 v69, v64, 12, 16                                 // 000000A01268: D6100045 02411940
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A01270: BF870091
	.long 0xd72c0045                                           // 000000A01274: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A01278: 02028AFF 83DCD12D
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A01280: D6220045 03FD0145 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0128C: BF870091
	v_and_b32_e32 v69, 0xffff, v69                             // 000000A01290: 368A8AFF 0000FFFF
	v_lshl_or_b32 v63, v70, 16, v69                            // 000000A01298: D656003F 05152146
	v_bfe_u32 v69, v62, 8, 16                                  // 000000A012A0: D6100045 0241113E
	s_waitcnt vmcnt(4)                                         // 000000A012A8: BF8913F7
	v_bfe_u32 v70, v61, 12, 16                                 // 000000A012AC: D6100046 0241193D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A012B4: BF870233
	v_pk_fma_f16 v63, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A012B8: CC0E003F 0BFC0B3F 0000C931
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A012C4: 369292FF 0000FFFF
	.long 0xd72c0045                                           // 000000A012CC: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A012D0: 02028AFF 83DCD12D
	.long 0xd72c0046                                           // 000000A012D8: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A012DC: 02028CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A012E4: BF870223
	v_lshl_or_b32 v72, v76, 16, v73                            // 000000A012E8: D6560048 0525214C
	v_sad_u8 v73, v75, 0, 0x6400                               // 000000A012F0: D6220049 03FD014B 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A012FC: D6220045 03FD0145 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A01308: BF870193
	v_pk_fma_f16 v71, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0130C: CC0E0047 0BFC0B48 0000C931
	v_and_or_b32 v67, 0xffff, v73, v67                         // 000000A01318: D6570043 050E92FF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A01324: D6220046 03FD0146 00006400
	v_bfe_u32 v72, v61, 4, 16                                  // 000000A01330: D6100048 0241093D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A01338: BF870214
	v_dot2acc_f32_f16 v25, v71, v7                             // 000000A0133C: 04320F47
	v_pk_fma_f16 v66, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A01340: CC0E0042 0BFC0B43 0000C931
	v_bfe_u32 v67, v65, 12, 16                                 // 000000A0134C: D6100043 02411941
	v_dot2acc_f32_f16 v23, v71, v3                             // 000000A01354: 042E0747
	v_and_b32_e32 v71, 0xffff, v64                             // 000000A01358: 368E80FF 0000FFFF
	v_bfe_u32 v64, v64, 4, 16                                  // 000000A01360: D6100040 02410940
	v_dot2acc_f32_f16 v25, v66, v8                             // 000000A01368: 04321142
	.long 0xd72c0043                                           // 000000A0136C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A01370: 020286FF 83DCD12D
	v_dot2acc_f32_f16 v23, v66, v4                             // 000000A01378: 042E0942
	v_bfe_u32 v66, v65, 8, 16                                  // 000000A0137C: D6100042 02411141
	v_and_b32_e32 v65, 0xffff, v65                             // 000000A01384: 368282FF 0000FFFF
	.long 0xd72c0047                                           // 000000A0138C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A01390: 02028EFF 83DCD12D
	.long 0xd72c0040                                           // 000000A01398: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A0139C: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A013A4: BF870214
	.long 0xd72c0042                                           // 000000A013A8: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A013AC: 020284FF 83DCD12D
	.long 0xd72c0041                                           // 000000A013B4: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A013B8: 020282FF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A013C0: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A013CC: BF870114
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A013D0: D6220040 03FD0140 00006400
	v_and_b32_e32 v67, 0xffff, v67                             // 000000A013DC: 368686FF 0000FFFF
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A013E4: D6220042 03FD0142 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A013F0: D6220041 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A013FC: BF870232
	v_lshl_or_b32 v66, v66, 16, v67                            // 000000A01400: D6560042 050D2142
	v_sad_u8 v67, v68, 0, 0x6400                               // 000000A01408: D6220043 03FD0144 00006400
	v_sad_u8 v68, v71, 0, 0x6400                               // 000000A01414: D6220044 03FD0147 00006400
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000A01420: 30828290
	v_bfe_u32 v71, v61, 8, 16                                  // 000000A01424: D6100047 0241113D
	v_pk_fma_f16 v66, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0142C: CC0E0042 0BFC0B42 0000C931
	v_and_b32_e32 v61, 0xffff, v61                             // 000000A01438: 367A7AFF 0000FFFF
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000A01440: 30888890
	v_and_or_b32 v65, 0xffff, v67, v65                         // 000000A01444: D6570041 050686FF 0000FFFF
	v_bfe_u32 v67, v62, 12, 16                                 // 000000A01450: D6100043 0241193E
	v_dot2acc_f32_f16 v16, v66, v5                             // 000000A01458: 04200B42
	v_dot2acc_f32_f16 v15, v66, v1                             // 000000A0145C: 041E0342
	v_and_or_b32 v64, 0xffff, v64, v68                         // 000000A01460: D6570040 051280FF 0000FFFF
	v_and_b32_e32 v68, 0xffff, v62                             // 000000A0146C: 36887CFF 0000FFFF
	.long 0xd72c0043                                           // 000000A01474: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A01478: 020286FF 83DCD12D
	v_bfe_u32 v62, v62, 4, 16                                  // 000000A01480: D610003E 0241093E
	.long 0xd72c0047                                           // 000000A01488: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A0148C: 02028EFF 83DCD12D
	v_pk_fma_f16 v65, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A01494: CC0E0041 0BFC0B41 0000C931
	.long 0xd72c0044                                           // 000000A014A0: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A014A4: 020288FF 83DCD12D
	v_pk_fma_f16 v64, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A014AC: CC0E0040 0BFC0B40 0000C931
	.long 0xd72c003e                                           // 000000A014B8: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A014BC: 02027CFF 83DCD12D
	.long 0xd72c003d                                           // 000000A014C4: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A014C8: 02027AFF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A014D0: D6220043 03FD0143 00006400
	v_dot2acc_f32_f16 v16, v65, v6                             // 000000A014DC: 04200D41
	v_dot2acc_f32_f16 v15, v65, v2                             // 000000A014E0: 041E0541
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A014E4: D6220044 03FD0144 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A014F0: BF870004
	v_and_b32_e32 v67, 0xffff, v67                             // 000000A014F4: 368686FF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A014FC: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v16, v63, v7                             // 000000A01508: 04200F3F
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A0150C: D622003D 03FD013D 00006400
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000A01518: 30888890
	v_lshl_or_b32 v67, v69, 16, v67                            // 000000A0151C: D6560043 050D2145
	v_and_b32_e32 v69, 0xffff, v70                             // 000000A01524: 368A8CFF 0000FFFF
	v_sad_u8 v70, v71, 0, 0x6400                               // 000000A0152C: D6220046 03FD0147 00006400
	v_dot2acc_f32_f16 v16, v64, v8                             // 000000A01538: 04201140
	v_and_or_b32 v62, 0xffff, v62, v68                         // 000000A0153C: D657003E 05127CFF 0000FFFF
	v_pk_fma_f16 v66, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A01548: CC0E0042 0BFC0B43 0000C931
	.long 0xd72c0044                                           // 000000A01554: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A01558: 020290FF 83DCD12D
	v_lshl_or_b32 v67, v70, 16, v69                            // 000000A01560: D6560043 05152146
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A01568: BF870214
	v_pk_fma_f16 v62, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0156C: CC0E003E 0BFC0B3E 0000C931
	v_dot2acc_f32_f16 v26, v66, v5                             // 000000A01578: 04340B42
	v_dot2acc_f32_f16 v24, v66, v1                             // 000000A0157C: 04300342
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A01580: BF870004
	v_pk_fma_f16 v65, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A01584: CC0E0041 0BFC0B43 0000C931
	s_waitcnt vmcnt(2)                                         // 000000A01590: BF890BF7
	v_bfe_u32 v66, v54, 4, 16                                  // 000000A01594: D6100042 02410936
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A0159C: D6220044 03FD0144 00006400
	v_dot2acc_f32_f16 v26, v62, v6                             // 000000A015A8: 04340D3E
	v_dot2acc_f32_f16 v24, v62, v2                             // 000000A015AC: 0430053E
	v_dual_mov_b32 v67, v50 :: v_dual_and_b32 v62, 0xffff, v59 // 000000A015B0: CA240132 433E76FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A015BC: BF870193
	v_dot2acc_f32_f16 v26, v65, v7                             // 000000A015C0: 04340F41
	v_dot2acc_f32_f16 v24, v65, v3                             // 000000A015C4: 04300741
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A015C8: BF8700A3
	.long 0xd72c003e                                           // 000000A015CC: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A015D0: 02027CFF 83DCD12D
	v_bfe_u32 v65, v58, 4, 16                                  // 000000A015D8: D6100041 0241093A
	.long 0xd72c0041                                           // 000000A015E0: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A015E4: 020282FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A015EC: BF870133
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A015F0: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v15, v63, v3                             // 000000A015FC: 041E073F
	v_bfe_u32 v63, v58, 12, 16                                 // 000000A01600: D610003F 0241193A
	v_dual_dot2acc_f32_f16 v15, v64, v4 :: v_dual_lshlrev_b32 v62, 16, v62// 000000A01608: CB220940 0F3E7C90
	v_bfe_u32 v64, v58, 8, 16                                  // 000000A01610: D6100040 0241113A
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A01618: 367474FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A01620: BF870224
	.long 0xd72c003f                                           // 000000A01624: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A01628: 02027EFF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A01630: D6220041 03FD0141 00006400
	.long 0xd72c0040                                           // 000000A0163C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A01640: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A01648: BF870214
	.long 0xd72c003a                                           // 000000A0164C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A01650: 020274FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A01658: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A01664: BF870193
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A01668: D6220040 03FD0140 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A01674: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A01680: BF870091
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000A01684: 30747490
	v_and_or_b32 v58, 0xffff, v65, v58                         // 000000A01688: D657003A 04EA82FF 0000FFFF
	v_bfe_u32 v65, v54, 8, 16                                  // 000000A01694: D6100041 02411136
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A0169C: BF8701A2
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A016A0: CC0E003A 0BFC0B3A 0000C931
	v_and_b32_e32 v63, 0xffff, v63                             // 000000A016AC: 367E7EFF 0000FFFF
	.long 0xd72c0041                                           // 000000A016B4: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A016B8: 020282FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A016C0: BF8701B2
	v_lshl_or_b32 v57, v64, 16, v63                            // 000000A016C4: D6560039 04FD2140
	v_bfe_u32 v63, v56, 8, 16                                  // 000000A016CC: D610003F 02411138
	v_bfe_u32 v64, v54, 12, 16                                 // 000000A016D4: D6100040 02411936
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A016DC: CC0E0039 0BFC0B39 0000C931
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000A016E8: 307A7A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A016EC: BF870214
	.long 0xd72c003f                                           // 000000A016F0: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A016F4: 02027EFF 83DCD12D
	.long 0xd72c0040                                           // 000000A016FC: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A01700: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A01708: BF870193
	v_and_or_b32 v61, 0xffff, v68, v61                         // 000000A0170C: D657003D 04F688FF 0000FFFF
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A01718: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A01724: BF8701B2
	v_pk_fma_f16 v60, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A01728: CC0E003C 0BFC0B3D 0000C931
	v_bfe_u32 v61, v59, 12, 16                                 // 000000A01734: D610003D 0241193B
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A0173C: D6220040 03FD0140 00006400
	v_dot2acc_f32_f16 v26, v60, v8                             // 000000A01748: 0434113C
	v_dot2acc_f32_f16 v24, v60, v4                             // 000000A0174C: 0430093C
	v_bfe_u32 v60, v59, 8, 16                                  // 000000A01750: D610003C 0241113B
	.long 0xd72c003d                                           // 000000A01758: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A0175C: 02027AFF 83DCD12D
	v_bfe_u32 v59, v59, 4, 16                                  // 000000A01764: D610003B 0241093B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0176C: BF870113
	.long 0xd72c003c                                           // 000000A01770: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A01774: 020278FF 83DCD12D
	.long 0xd72c003b                                           // 000000A0177C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A01780: 020276FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A01788: BF870194
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A0178C: D622003D 03FD013D 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A01798: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A017A4: BF870212
	v_and_b32_e32 v61, 0xffff, v61                             // 000000A017A8: 367A7AFF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A017B0: D622003B 03FD013B 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A017BC: BF8701A2
	v_lshl_or_b32 v60, v60, 16, v61                            // 000000A017C0: D656003C 04F5213C
	v_bfe_u32 v61, v56, 12, 16                                 // 000000A017C8: D610003D 02411938
	v_and_or_b32 v59, 0xffff, v59, v62                         // 000000A017D0: D657003B 04FA76FF 0000FFFF
	v_and_b32_e32 v62, 0xffff, v56                             // 000000A017DC: 367C70FF 0000FFFF
	v_bfe_u32 v56, v56, 4, 16                                  // 000000A017E4: D6100038 02410938
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A017EC: CC0E003C 0BFC0B3C 0000C931
	.long 0xd72c003d                                           // 000000A017F8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A017FC: 02027AFF 83DCD12D
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A01804: CC0E003B 0BFC0B3B 0000C931
	.long 0xd72c003e                                           // 000000A01810: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A01814: 02027CFF 83DCD12D
	.long 0xd72c0038                                           // 000000A0181C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A01820: 020270FF 83DCD12D
	v_dot2acc_f32_f16 v22, v60, v1                             // 000000A01828: 042C033C
	v_dot2acc_f32_f16 v14, v60, v5                             // 000000A0182C: 041C0B3C
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A01830: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A0183C: BF870243
	v_dot2acc_f32_f16 v22, v59, v2                             // 000000A01840: 042C053B
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A01844: D622003E 03FD013E 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A01850: D6220038 03FD0138 00006400
	v_dot2acc_f32_f16 v14, v59, v6                             // 000000A0185C: 041C0D3B
	v_dual_dot2acc_f32_f16 v22, v57, v3 :: v_dual_and_b32 v61, 0xffff, v61// 000000A01860: CB240739 163C7AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0186C: BF870112
	v_dot2acc_f32_f16 v14, v57, v7                             // 000000A01870: 041C0F39
	v_dot2acc_f32_f16 v22, v58, v4                             // 000000A01874: 042C093A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A01878: BF870003
	v_lshl_or_b32 v61, v63, 16, v61                            // 000000A0187C: D656003D 04F5213F
	v_and_b32_e32 v63, 0xffff, v64                             // 000000A01884: 367E80FF 0000FFFF
	v_sad_u8 v64, v65, 0, 0x6400                               // 000000A0188C: D6220040 03FD0141 00006400
	v_dot2acc_f32_f16 v14, v58, v8                             // 000000A01898: 041C113A
	s_waitcnt vmcnt(1)                                         // 000000A0189C: BF8907F7
	v_bfe_u32 v58, v52, 12, 16                                 // 000000A018A0: D610003A 02411934
	v_pk_fma_f16 v60, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A018A8: CC0E003C 0BFC0B3D 0000C931
	v_and_b32_e32 v54, 0xffff, v54                             // 000000A018B4: 366C6CFF 0000FFFF
	v_lshl_or_b32 v61, v64, 16, v63                            // 000000A018BC: D656003D 04FD2140
	v_mov_b32_e32 v63, v48                                     // 000000A018C4: 7E7E0330
	.long 0xd72c003a                                           // 000000A018C8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A018CC: 020274FF 83DCD12D
	v_dot2acc_f32_f16 v21, v60, v5                             // 000000A018D4: 042A0B3C
	v_dot2acc_f32_f16 v20, v60, v1                             // 000000A018D8: 0428033C
	v_pk_fma_f16 v59, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A018DC: CC0E003B 0BFC0B3D 0000C931
	v_lshlrev_b32_e32 v62, 16, v62                             // 000000A018E8: 307C7C90
	.long 0xd72c0036                                           // 000000A018EC: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A018F0: 02026CFF 83DCD12D
	v_bfe_u32 v60, v52, 4, 16                                  // 000000A018F8: D610003C 02410934
	s_waitcnt vmcnt(0)                                         // 000000A01900: BF8903F7
	v_bfe_u32 v61, v32, 4, 16                                  // 000000A01904: D610003D 02410920
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A0190C: D622003A 03FD013A 00006400
	v_and_or_b32 v56, 0xffff, v56, v62                         // 000000A01918: D6570038 04FA70FF 0000FFFF
	.long 0xd72c003e                                           // 000000A01924: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A01928: 020284FF 83DCD12D
	.long 0xd72c003c                                           // 000000A01930: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A01934: 020278FF 83DCD12D
	v_mov_b32_e32 v65, v39                                     // 000000A0193C: 7E820327
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000A01940: D6220036 03FD0136 00006400
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0194C: CC0E0038 0BFC0B38 0000C931
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A01958: 367474FF 0000FFFF
	v_mov_b32_e32 v64, v49                                     // 000000A01960: 7E800331
	v_mov_b32_e32 v66, v49                                     // 000000A01964: 7E840331
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A01968: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v21, v56, v6                             // 000000A01974: 042A0D38
	v_dot2acc_f32_f16 v20, v56, v2                             // 000000A01978: 04280538
	v_bfe_u32 v56, v53, 8, 16                                  // 000000A0197C: D6100038 02411135
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A01984: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A01990: BF870214
	v_dot2acc_f32_f16 v21, v59, v7                             // 000000A01994: 042A0F3B
	v_dot2acc_f32_f16 v20, v59, v3                             // 000000A01998: 0428073B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A0199C: BF870144
	.long 0xd72c0038                                           // 000000A019A0: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A019A4: 020270FF 83DCD12D
	v_and_b32_e32 v55, 0xffff, v55                             // 000000A019AC: 366E6EFF 0000FFFF
	v_bfe_u32 v59, v52, 8, 16                                  // 000000A019B4: D610003B 02411134
	v_and_b32_e32 v52, 0xffff, v52                             // 000000A019BC: 366868FF 0000FFFF
	.long 0xd72c003b                                           // 000000A019C4: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A019C8: 020276FF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A019D0: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A019DC: BF870113
	.long 0xd72c0034                                           // 000000A019E0: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000A019E4: 020268FF 83DCD12D
	v_lshl_or_b32 v55, v56, 16, v55                            // 000000A019EC: D6560037 04DD2138
	v_bfe_u32 v56, v33, 12, 16                                 // 000000A019F4: D6100038 02411921
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A019FC: D622003B 03FD013B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A01A08: BF870214
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000A01A0C: D6220034 03FD0134 00006400
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A01A18: CC0E0037 0BFC0B37 0000C931
	v_lshlrev_b32_e32 v54, 16, v54                             // 000000A01A24: 306C6C90
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A01A28: BF870004
	v_lshl_or_b32 v34, v59, 16, v58                            // 000000A01A2C: D6560022 04E9213B
	.long 0xd72c0038                                           // 000000A01A34: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A01A38: 020270FF 83DCD12D
	v_bfe_u32 v58, v33, 8, 16                                  // 000000A01A40: D610003A 02411121
	v_dot2acc_f32_f16 v19, v55, v5                             // 000000A01A48: 04260B37
	v_and_or_b32 v54, 0xffff, v62, v54                         // 000000A01A4C: D6570036 04DA7CFF 0000FFFF
	v_dot2acc_f32_f16 v18, v55, v1                             // 000000A01A58: 04240337
	v_and_b32_e32 v57, 0xffff, v53                             // 000000A01A5C: 36726AFF 0000FFFF
	v_bfe_u32 v53, v53, 4, 16                                  // 000000A01A64: D6100035 02410935
	v_pk_fma_f16 v34, v34, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A01A6C: CC0E0022 0BFC0B22 0000C931
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A01A78: CC0E0036 0BFC0B36 0000C931
	.long 0xd72c003a                                           // 000000A01A84: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A01A88: 020274FF 83DCD12D
	.long 0xd72c0039                                           // 000000A01A90: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A01A94: 020272FF 83DCD12D
	.long 0xd72c0035                                           // 000000A01A9C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A01AA0: 02026AFF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A01AA8: D6220038 03FD0138 00006400
	v_dot2acc_f32_f16 v21, v54, v8                             // 000000A01AB4: 042A1136
	v_bfe_u32 v59, v32, 12, 16                                 // 000000A01AB8: D610003B 02411920
	v_dot2acc_f32_f16 v20, v54, v4                             // 000000A01AC0: 04280936
	v_mov_b32_e32 v54, v46                                     // 000000A01AC4: 7E6C032E
	v_and_b32_e32 v56, 0xffff, v56                             // 000000A01AC8: 367070FF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000A01AD0: D6220039 03FD0139 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A01ADC: D6220035 03FD0135 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A01AE8: D622003A 03FD013A 00006400
	.long 0xd72c003b                                           // 000000A01AF4: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A01AF8: 020276FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A01B00: BF870194
	v_dual_mov_b32 v62, v38 :: v_dual_lshlrev_b32 v57, 16, v57 // 000000A01B04: CA220126 3E387290
	v_lshl_or_b32 v56, v58, 16, v56                            // 000000A01B0C: D6560038 04E1213A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A01B14: BF870212
	v_and_or_b32 v53, 0xffff, v53, v57                         // 000000A01B18: D6570035 04E66AFF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A01B24: D622003B 03FD013B 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A01B30: BF870193
	v_pk_fma_f16 v55, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A01B34: CC0E0037 0BFC0B38 0000C931
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A01B40: CC0E0035 0BFC0B35 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A01B4C: BF870232
	v_dual_dot2acc_f32_f16 v17, v55, v5 :: v_dual_lshlrev_b32 v52, 16, v52// 000000A01B50: CB220B37 11346890
	v_dot2acc_f32_f16 v13, v55, v1                             // 000000A01B58: 041A0337
	v_mov_b32_e32 v55, v45                                     // 000000A01B5C: 7E6E032D
	v_dot2acc_f32_f16 v19, v53, v6                             // 000000A01B60: 04260D35
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A01B64: BF870234
	v_and_or_b32 v52, 0xffff, v60, v52                         // 000000A01B68: D6570034 04D278FF 0000FFFF
	v_dot2acc_f32_f16 v18, v53, v2                             // 000000A01B74: 04240535
	v_bfe_u32 v60, v32, 8, 16                                  // 000000A01B78: D610003C 02411120
	v_dual_dot2acc_f32_f16 v19, v34, v7 :: v_dual_and_b32 v32, 0xffff, v32// 000000A01B80: CB240F22 132040FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A01B8C: BF870214
	v_pk_fma_f16 v52, v52, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A01B90: CC0E0034 0BFC0B34 0000C931
	v_dual_dot2acc_f32_f16 v18, v34, v3 :: v_dual_and_b32 v57, 0xffff, v33// 000000A01B9C: CB240722 123842FF 0000FFFF
	v_bfe_u32 v33, v33, 4, 16                                  // 000000A01BA8: D6100021 02410921
	.long 0xd72c003c                                           // 000000A01BB0: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A01BB4: 020278FF 83DCD12D
	.long 0xd72c0020                                           // 000000A01BBC: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000A01BC0: 020240FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A01BC8: BF870004
	v_dot2acc_f32_f16 v18, v52, v4                             // 000000A01BCC: 04240934
	.long 0xd72c0039                                           // 000000A01BD0: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A01BD4: 020272FF 83DCD12D
	.long 0xd72c0021                                           // 000000A01BDC: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000A01BE0: 020242FF 83DCD12D
	v_dot2acc_f32_f16 v19, v52, v8                             // 000000A01BE8: 04261134
	v_dual_mov_b32 v53, v35 :: v_dual_mov_b32 v52, v45         // 000000A01BEC: CA100123 3534012D
	v_mov_b32_e32 v34, v43                                     // 000000A01BF4: 7E44032B
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000A01BF8: D6220020 03FD0120 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000A01C04: D6220039 03FD0139 00006400
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000A01C10: D6220021 03FD0121 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A01C1C: BF870193
	v_lshlrev_b32_e32 v32, 16, v32                             // 000000A01C20: 30404090
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000A01C24: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A01C28: BF8701B1
	v_and_or_b32 v33, 0xffff, v33, v57                         // 000000A01C2C: D6570021 04E642FF 0000FFFF
	.long 0xd72c0039                                           // 000000A01C38: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A01C3C: 02027AFF 83DCD12D
	v_mov_b32_e32 v61, v48                                     // 000000A01C44: 7E7A0330
	v_pk_fma_f16 v33, v33, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A01C48: CC0E0021 0BFC0B21 0000C931
	v_and_b32_e32 v58, 0xffff, v59                             // 000000A01C54: 367476FF 0000FFFF
	v_sad_u8 v59, v60, 0, 0x6400                               // 000000A01C5C: D622003B 03FD013C 00006400
	v_mov_b32_e32 v60, v47                                     // 000000A01C68: 7E78032F
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000A01C6C: D6220039 03FD0139 00006400
	v_dot2acc_f32_f16 v17, v33, v6                             // 000000A01C78: 04220D21
	v_dot2acc_f32_f16 v13, v33, v2                             // 000000A01C7C: 041A0521
	v_lshl_or_b32 v56, v59, 16, v58                            // 000000A01C80: D6560038 04E9213B
	v_mov_b32_e32 v58, v47                                     // 000000A01C88: 7E74032F
	v_and_or_b32 v5, 0xffff, v57, v32                          // 000000A01C8C: D6570005 048272FF 0000FFFF
	v_mov_b32_e32 v57, v46                                     // 000000A01C98: 7E72032E
	v_mov_b32_e32 v59, v37                                     // 000000A01C9C: 7E760325
	v_pk_fma_f16 v1, v56, s5, 0xc931 op_sel_hi:[1,0,0]         // 000000A01CA0: CC0E0001 0BFC0B38 0000C931
	v_mov_b32_e32 v56, v36                                     // 000000A01CAC: 7E700324
	v_pk_fma_f16 v2, v5, s5, 0xc931 op_sel_hi:[1,0,0]          // 000000A01CB0: CC0E0002 0BFC0B05 0000C931
	v_mov_b32_e32 v5, v51                                      // 000000A01CBC: 7E0A0333
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A01CC0: BF870244
	v_dual_mov_b32 v6, v51 :: v_dual_dot2acc_f32_f16 v17, v1, v7// 000000A01CC4: CA180133 06100F01
	v_dot2acc_f32_f16 v13, v1, v3                              // 000000A01CCC: 041A0701
	v_dual_mov_b32 v3, v50 :: v_dual_mov_b32 v32, v43          // 000000A01CD0: CA100132 0320012B
	v_mov_b32_e32 v33, v10                                     // 000000A01CD8: 7E42030A
	v_dot2acc_f32_f16 v17, v2, v8                              // 000000A01CDC: 04221102
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A01CE0: BF870004
	v_dual_dot2acc_f32_f16 v13, v2, v4 :: v_dual_mov_b32 v2, v44// 000000A01CE4: CB100902 0D02012C
	v_dual_mov_b32 v4, v42 :: v_dual_mov_b32 v1, v9            // 000000A01CEC: CA10012A 04000109
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A01CF4: 917E047E
	s_cbranch_execz 58                                         // 000000A01CF8: BFA5003A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1ae4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A01CFC: BF8700A1
	v_add_nc_u32_e32 v9, 1, v1                                 // 000000A01D00: 4A120281
	s_mov_b32 s6, exec_lo                                      // 000000A01D04: BE86007E
	.long 0xd4c1007e                                           // 000000A01D08: D4C1007E
	v_cndmask_b32_e32 v1, v9, v12, vcc_lo                      // 000000A01D0C: 02021909
	s_cbranch_execz 64611                                      // 000000A01D10: BFA5FC63 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xba0>
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000A01D14: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A01D18: BF870091
	.long 0xd73c0007                                           // 000000A01D1C: D73C0007
	v_cndmask_b32_e32 v1, 10, v9, vcc_lo                       // 000000A01D20: 0202128A
	.long 0xd7006a0a                                           // 000000A01D24: D7006A0A
	v_cndmask_b32_e32 v1, s1, v7, vcc_lo                       // 000000A01D28: 02020E01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A01D2C: BF870111
	v_add_co_ci_u32_e64 v35, null, s3, v8, vcc_lo              // 000000A01D30: D5207C23 01AA1003
	.long 0xd7006a07                                           // 000000A01D38: D7006A07
	v_cndmask_b32_e32 v1, v10, v31, vcc_lo                     // 000000A01D3C: 02023F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A01D40: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v35, vcc_lo               // 000000A01D44: D5207C08 01AA4680
	.long 0xd7006a44                                           // 000000A01D4C: D7006A44
	v_cndmask_b32_e32 v1, v10, v30, vcc_lo                     // 000000A01D50: 02023D0A
	v_add_co_ci_u32_e64 v69, null, 0, v35, vcc_lo              // 000000A01D54: D5207C45 01AA4680
	s_clause 0xf                                               // 000000A01D5C: BF85000F
	global_load_b32 v42, v[7:8], off                           // 000000A01D60: DC520000 2A7C0007
	global_load_b32 v44, v[7:8], off offset:128                // 000000A01D68: DC520080 2C7C0007
	global_load_b32 v39, v[7:8], off offset:256                // 000000A01D70: DC520100 277C0007
	global_load_b32 v38, v[7:8], off offset:384                // 000000A01D78: DC520180 267C0007
	global_load_b32 v37, v[7:8], off offset:512                // 000000A01D80: DC520200 257C0007
	global_load_b32 v36, v[7:8], off offset:640                // 000000A01D88: DC520280 247C0007
	global_load_b32 v35, v[7:8], off offset:768                // 000000A01D90: DC520300 237C0007
	global_load_b32 v10, v[7:8], off offset:896                // 000000A01D98: DC520380 0A7C0007
	global_load_b32 v51, v[68:69], off                         // 000000A01DA0: DC520000 337C0044
	global_load_b32 v50, v[68:69], off offset:128              // 000000A01DA8: DC520080 327C0044
	global_load_b32 v49, v[68:69], off offset:256              // 000000A01DB0: DC520100 317C0044
	global_load_b32 v48, v[68:69], off offset:384              // 000000A01DB8: DC520180 307C0044
	global_load_b32 v47, v[68:69], off offset:512              // 000000A01DC0: DC520200 2F7C0044
	global_load_b32 v46, v[68:69], off offset:640              // 000000A01DC8: DC520280 2E7C0044
	global_load_b32 v45, v[68:69], off offset:768              // 000000A01DD0: DC520300 2D7C0044
	global_load_b32 v43, v[68:69], off offset:896              // 000000A01DD8: DC520380 2B7C0044
	s_branch 64559                                             // 000000A01DE0: BFA0FC2F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xba0>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A01DE4: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A01DE8: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A01DEC: 8C7E007E
	s_waitcnt vmcnt(22)                                        // 000000A01DF0: BF895BF7
	v_dual_mov_b32 v1, v28 :: v_dual_mov_b32 v2, v27           // 000000A01DF4: CA10011C 0102011B
	s_waitcnt vmcnt(14)                                        // 000000A01DFC: BF893BF7
	v_dual_mov_b32 v4, v25 :: v_dual_mov_b32 v3, v16           // 000000A01E00: CA100119 04020110
	v_dual_mov_b32 v6, v23 :: v_dual_mov_b32 v9, v24           // 000000A01E08: CA100117 06080118
	s_waitcnt vmcnt(7)                                         // 000000A01E10: BF891FF7
	v_dual_mov_b32 v5, v15 :: v_dual_mov_b32 v8, v26           // 000000A01E14: CA10010F 0508011A
	v_dual_mov_b32 v7, v14 :: v_dual_mov_b32 v12, v21          // 000000A01E1C: CA10010E 070C0115
	v_dual_mov_b32 v10, v22 :: v_dual_mov_b32 v29, v20         // 000000A01E24: CA100116 0A1C0114
	v_dual_mov_b32 v30, v19 :: v_dual_mov_b32 v31, v18         // 000000A01E2C: CA100113 1E1E0112
	s_waitcnt vmcnt(0)                                         // 000000A01E34: BF8903F7
	v_mov_b32_e32 v32, v17                                     // 000000A01E38: 7E400311
	v_mov_b32_e32 v33, v13                                     // 000000A01E3C: 7E42030D
	s_mov_b32 s0, 0x76543210                                   // 000000A01E40: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A01E48: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000A01E4C: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A01E58: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A01E64: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A01E70: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A01E7C: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A01E88: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000A01E94: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000A01EA0: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000A01EAC: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A01EB8: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000A01EC4: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v29, v29, s0, 0xfedcba98                 // 000000A01ED0: D65C001D 03FC011D FEDCBA98
	v_permlanex16_b32 v30, v30, s0, 0xfedcba98                 // 000000A01EDC: D65C001E 03FC011E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 000000A01EE8: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 000000A01EF4: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 000000A01F00: D65C0021 03FC0121 FEDCBA98
	.long 0xd44c0000                                           // 000000A01F0C: D44C0000
	v_cndmask_b32_e32 v1, 16, v41, vcc_lo                      // 000000A01F10: 02025290
	s_barrier                                                  // 000000A01F14: BFBD0000
	buffer_gl0_inv                                             // 000000A01F18: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000A01F20: BE812000
	s_cbranch_execz 39                                         // 000000A01F24: BFA50027 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1cc4>
	v_lshl_or_b32 v11, v40, 10, v11                            // 000000A01F28: D656000B 042D1528
	v_dual_add_f32 v19, v19, v30 :: v_dual_add_f32 v12, v21, v12// 000000A01F30: C9083D13 130C1915
	v_dual_add_f32 v8, v26, v8 :: v_dual_add_f32 v1, v28, v1   // 000000A01F38: C908111A 0800031C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A01F40: BF870003
	v_dual_add_f32 v6, v23, v6 :: v_dual_add_nc_u32 v21, 0x5400, v11// 000000A01F44: C9200D17 061416FF 00005400
	v_dual_add_f32 v4, v25, v4 :: v_dual_add_nc_u32 v11, 0x5800, v11// 000000A01F50: C9200919 040A16FF 00005800
	v_dual_add_f32 v2, v27, v2 :: v_dual_add_f32 v3, v16, v3   // 000000A01F5C: C908051B 02020710
	v_dual_add_f32 v10, v22, v10 :: v_dual_add_f32 v9, v24, v9 // 000000A01F64: C9081516 0A081318
	v_add_f32_e32 v5, v15, v5                                  // 000000A01F6C: 060A0B0F
	v_add_f32_e32 v7, v14, v7                                  // 000000A01F70: 060E0F0E
	v_dual_add_f32 v13, v13, v33 :: v_dual_add_f32 v18, v18, v31// 000000A01F74: C908430D 0D123F12
	v_dual_add_f32 v17, v17, v32 :: v_dual_add_f32 v20, v20, v29// 000000A01F7C: C9084111 11143B14
	ds_store_2addr_b32 v21, v1, v4 offset0:128 offset1:144     // 000000A01F84: D8389080 00040115
	ds_store_2addr_b32 v11, v2, v6 offset1:16                  // 000000A01F8C: D8381000 0006020B
	ds_store_2addr_b32 v21, v3, v8 offset0:160 offset1:176     // 000000A01F94: D838B0A0 00080315
	ds_store_2addr_b32 v11, v5, v9 offset0:32 offset1:48       // 000000A01F9C: D8383020 0009050B
	ds_store_2addr_b32 v21, v7, v12 offset0:192 offset1:208    // 000000A01FA4: D838D0C0 000C0715
	ds_store_2addr_b32 v11, v10, v20 offset0:64 offset1:80     // 000000A01FAC: D8385040 00140A0B
	ds_store_2addr_b32 v21, v19, v17 offset0:224 offset1:240   // 000000A01FB4: D838F0E0 00111315
	ds_store_2addr_b32 v11, v18, v13 offset0:96 offset1:112    // 000000A01FBC: D8387060 000D120B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A01FC4: 8C7E017E
	.long 0xd44c0001                                           // 000000A01FC8: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000A01FCC: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000A01FD4: BF89FC07
	s_barrier                                                  // 000000A01FD8: BFBD0000
	buffer_gl0_inv                                             // 000000A01FDC: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000A01FE4: BE832001
	s_cbranch_execnz 7                                         // 000000A01FE8: BFA60007 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d08>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A01FEC: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 000000A01FF0: BF048209
	s_mov_b32 s3, -1                                           // 000000A01FF4: BE8300C1
	s_cbranch_scc0 33                                          // 000000A01FF8: BFA10021 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d80>
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000A01FFC: 8B6A037E
	s_cbranch_vccnz 196                                        // 000000A02000: BFA400C4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2014>
	s_branch 576                                               // 000000A02004: BFA00240 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2608>
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000A02008: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:86 offset1:90// 000000A0200C: D8E05A56 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:94 offset1:98// 000000A02014: D8E0625E 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:102 offset1:106// 000000A0201C: D8E06A66 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000A02024: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000A02028: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A0202C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000A02030: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000A02034: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000A02038: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:110 offset1:114// 000000A0203C: D8E0726E 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000A02044: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000A02048: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0204C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000A02050: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000A02054: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000A02058: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0205C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000A02060: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000A02064: 06020501
	ds_store_b32 v7, v1 offset:30208                           // 000000A02068: D8347600 00000107
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A02070: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 000000A02074: BF048209
	s_mov_b32 s3, -1                                           // 000000A02078: BE8300C1
	s_cbranch_scc1 65503                                       // 000000A0207C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1cfc>
	s_waitcnt lgkmcnt(0)                                       // 000000A02080: BF89FC07
	s_barrier                                                  // 000000A02084: BFBD0000
	buffer_gl0_inv                                             // 000000A02088: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000A02090: BE832001
	s_cbranch_execz 41                                         // 000000A02094: BFA50029 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1e3c>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000A02098: 32020087
	s_ashr_i32 s4, s49, 31                                     // 000000A0209C: 86049F31
	v_lshlrev_b32_e32 v4, 2, v0                                // 000000A020A0: 30080082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000A020A4: BF8704D2
	v_lshl_or_b32 v1, s30, 1, v1                               // 000000A020A8: D6560001 0405021E
	ds_load_b32 v4, v4 offset:30208                            // 000000A020B0: D8D87600 04000004
	.long 0xd72c0003                                           // 000000A020B8: D72C0003
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000A020BC: 02000901
	v_mad_u64_u32 v[1:2], null, v1, s49, 0                     // 000000A020C0: D6FE7C01 02006301
	s_ashr_i32 s4, s30, 31                                     // 000000A020C8: 86049F1E
	s_mul_i32 s4, s4, s49                                      // 000000A020CC: 96043104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A020D0: BF870149
	v_add3_u32 v2, v2, v3, s4                                  // 000000A020D4: D6550002 00120702
	s_lshl_b32 s4, s10, 7                                      // 000000A020DC: 8404870A
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000A020E0: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 000000A020E8: 86059F04
	.long 0xd73c0001                                           // 000000A020EC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000A020F0: 02020282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000A020F4: 84848204
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A020F8: BF870132
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000A020FC: 30060682
	s_add_u32 s4, s44, s4                                      // 000000A02100: 8004042C
	s_addc_u32 s5, s45, s5                                     // 000000A02104: 8205052D
	.long 0xd7006a01                                           // 000000A02108: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000A0210C: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A02110: BF870111
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000A02114: D5207C02 01AA0405
	.long 0xd7006a01                                           // 000000A0211C: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000A02120: 02020701
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A02124: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A02128: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 000000A02130: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 000000A02134: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A0213C: 8C7E037E
	.long 0xd44a0003                                           // 000000A02140: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000A02144: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000A02148: BC7C0000
	buffer_gl1_inv                                             // 000000A0214C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000A02154: E0AC0000 00000000
	s_barrier                                                  // 000000A0215C: BFBD0000
	buffer_gl0_inv                                             // 000000A02160: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 000000A02168: BE842003
	s_cbranch_execz 29                                         // 000000A0216C: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1ee4>
	s_mov_b32 s6, exec_lo                                      // 000000A02170: BE86007E
	s_mov_b32 s5, exec_lo                                      // 000000A02174: BE85007E
	.long 0xd71f0001                                           // 000000A02178: D71F0001
	v_cndmask_b32_e32 v0, s6, v128, vcc_lo                     // 000000A0217C: 02010006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A02180: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000A02184: 7D940280
	s_cbranch_execz 9                                          // 000000A02188: BFA50009 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1eb0>
	s_lshl_b64 s[24:25], s[10:11], 2                           // 000000A0218C: 8498820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000A02190: BF8704B9
	s_add_u32 s24, s46, s24                                    // 000000A02194: 8018182E
	s_addc_u32 s25, s47, s25                                   // 000000A02198: 8219192F
	s_bcnt1_i32_b32 s6, s6                                     // 000000A0219C: BE861806
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s6              // 000000A021A0: CA100080 02020006
	global_atomic_add_u32 v2, v2, v3, s[24:25] glc             // 000000A021A8: DCD64000 02180302
	s_or_b32 exec_lo, exec_lo, s5                              // 000000A021B0: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 000000A021B4: BF8903F7
	v_readfirstlane_b32 s5, v2                                 // 000000A021B8: 7E0A0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A021BC: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v1       // 000000A021C0: CA200080 02000205
	s_add_i32 s5, s9, -1                                       // 000000A021C8: 8105C109
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000A021CC: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s5, v1                            // 000000A021D0: 7C940205
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000A021D4: D5010001 01A90280
	ds_store_b32 v2, v1 offset:32256                           // 000000A021DC: D8347E00 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A021E4: 8C7E047E
	v_mov_b32_e32 v1, 0                                        // 000000A021E8: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000A021EC: BF89FC07
	s_barrier                                                  // 000000A021F0: BFBD0000
	buffer_gl0_inv                                             // 000000A021F4: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:32256                            // 000000A021FC: D8D87E00 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000A02204: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000A02208: 7C940280
	s_cbranch_vccnz 64                                         // 000000A0220C: BFA40040 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2010>
	buffer_gl1_inv                                             // 000000A02210: E0B00000 00000000
	buffer_gl0_inv                                             // 000000A02218: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 000000A02220: BE842001
	s_cbranch_execz 46                                         // 000000A02224: BFA5002E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1fe0>
	v_and_b32_e32 v2, 0x7f, v0                                 // 000000A02228: 360400FF 0000007F
	s_lshl_b32 s6, s10, 7                                      // 000000A02230: 8406870A
	s_ashr_i32 s1, s49, 31                                     // 000000A02234: 86019F31
	s_ashr_i32 s7, s6, 31                                      // 000000A02238: 86079F06
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000A0223C: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 000000A02240: CA220080 02020482
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000A02248: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A0224C: BF8700A9
	s_add_u32 s5, s44, s6                                      // 000000A02250: 8005062C
	s_addc_u32 s6, s45, s7                                     // 000000A02254: 8206072D
	.long 0xd7000503                                           // 000000A02258: D7000503
	v_cndmask_b32_e32 v1, s5, v3, vcc_lo                       // 000000A0225C: 02020605
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A02260: BF870001
	v_add_co_ci_u32_e64 v4, null, s6, 0, s5                    // 000000A02264: D5207C04 00150006
	s_mov_b32 s5, s49                                          // 000000A0226C: BE850031
	s_nop 0                                                    // 000000A02270: BF800000
	s_nop 0                                                    // 000000A02274: BF800000
	s_nop 0                                                    // 000000A02278: BF800000
	s_nop 0                                                    // 000000A0227C: BF800000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000A02280: BF8704A9
	v_mad_u64_u32 v[5:6], null, v1, s5, 0                      // 000000A02284: D6FE7C05 02000B01
	s_add_i32 s9, s9, -1                                       // 000000A0228C: 8109C109
	s_cmp_eq_u32 s9, 0                                         // 000000A02290: BF068009
	v_mad_u64_u32 v[6:7], null, v1, s1, v[6:7]                 // 000000A02294: D6FE7C06 04180301
	v_add_nc_u32_e32 v1, 2, v1                                 // 000000A0229C: 4A020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A022A0: BF870092
	.long 0xd73c0005                                           // 000000A022A4: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000A022A8: 02020A82
	.long 0xd7006a05                                           // 000000A022AC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000A022B0: 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A022B4: BF870001
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 000000A022B8: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 000000A022C0: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000A022C8: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 000000A022CC: 06040B02
	s_cbranch_scc0 65515                                       // 000000A022D0: BFA1FFEB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1f80>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000A022D4: 30020082
	ds_store_b32 v1, v2 offset:30208                           // 000000A022D8: D8347600 00000201
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A022E0: 8C7E047E
	s_and_saveexec_b32 s1, s3                                  // 000000A022E4: BE812003
	s_cbranch_execz 6                                          // 000000A022E8: BFA50006 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2004>
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000A022EC: 8484820A
	v_mov_b32_e32 v1, 0                                        // 000000A022F0: 7E020280
	s_add_u32 s4, s46, s4                                      // 000000A022F4: 8004042E
	s_addc_u32 s5, s47, s5                                     // 000000A022F8: 8205052F
	global_store_b32 v1, v1, s[4:5]                            // 000000A022FC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A02304: 8C7E017E
	s_cbranch_execnz 2                                         // 000000A02308: BFA60002 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2014>
	s_branch 382                                               // 000000A0230C: BFA0017E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2608>
	s_branch 381                                               // 000000A02310: BFA0017D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2608>
	v_cmp_gt_i32_e32 vcc_lo, s48, v40                          // 000000A02314: 7C885030
	.long 0xd44c0001                                           // 000000A02318: D44C0001
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 000000A0231C: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 000000A02320: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000A02324: BC7C0000
	s_barrier                                                  // 000000A02328: BFBD0000
	buffer_gl0_inv                                             // 000000A0232C: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 000000A02334: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A02338: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000A0233C: BE832001
	s_cbranch_execz 368                                        // 000000A02340: BFA50170 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2604>
	v_and_b32_e32 v1, 15, v0                                   // 000000A02344: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A02348: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000A0234C: 30040282
	v_lshl_or_b32 v2, v40, 9, v2                               // 000000A02350: D6560002 04091328
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A02358: BF870001
	v_add_nc_u32_e32 v8, 0x7400, v2                            // 000000A0235C: 4A1004FF 00007400
	ds_load_2addr_b32 v[2:3], v8 offset0:128 offset1:144       // 000000A02364: D8DC9080 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:160 offset1:176       // 000000A0236C: D8DCB0A0 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:192 offset1:208       // 000000A02374: D8DCD0C0 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:224 offset1:240       // 000000A0237C: D8DCF0E0 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000A02384: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000A02388: 36160082
	s_waitcnt lgkmcnt(3)                                       // 000000A0238C: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000A02390: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000A02398: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000A0239C: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000A023A4: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000A023A8: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000A023B0: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000A023B4: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000A023BC: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000A023C4: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A023C8: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000A023CC: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000A023D4: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000A023DC: 7C941480
	.long 0xd44a0001                                           // 000000A023E0: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000A023E4: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000A023E8: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000A023F0: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000A023F4: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A023F8: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000A023FC: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000A02400: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000A02408: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000A0240C: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000A02410: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A02414: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000A0241C: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A02424: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000A0242C: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A02434: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000A0243C: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A02444: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000A0244C: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A02454: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000A0245C: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A02464: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000A0246C: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A02474: 7E2402FA FF016103
	v_cndmask_b32_e64 v19, -v3, v3, vcc_lo                     // 000000A0247C: D5010013 21AA0703
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 000000A02484: D5010015 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000A0248C: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 000000A02490: C9080D07 03082108
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A02498: 7E2802FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 000000A024A0: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A024A8: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A024AC: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000A024B4: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 000000A024BC: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A024C0: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000A024C8: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A024D0: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 000000A024D8: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A024DC: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000A024E4: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 000000A024EC: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000A024F0: D5010008 21AA1108
	v_add_f32_e32 v13, v21, v20                                // 000000A024F8: 061A2915
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A024FC: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 000000A02504: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A02508: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000A02510: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000A02518: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 000000A02520: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A02524: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000A0252C: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 000000A02534: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A02538: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000A02540: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 000000A02548: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0254C: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A02554: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 000000A0255C: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 000000A02560: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 000000A02564: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0256C: 7E0402FA FF016402
	v_add_f32_e32 v6, v6, v11                                  // 000000A02574: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A02578: 7E1602FA FF016408
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000A02580: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A02588: BF870234
	v_add_f32_e32 v7, v7, v2                                   // 000000A0258C: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A02590: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A02598: D5010004 20060904
	v_add_f32_e32 v14, v14, v11                                // 000000A025A0: 061C170E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A025A4: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A025AC: 7E0A02FA FF016807
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A025B4: 7E1002FA FF016806
	v_add_f32_e32 v4, v4, v10                                  // 000000A025BC: 06081504
	v_add_f32_e32 v10, v19, v18                                // 000000A025C0: 06142513
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A025C4: BF8700A1
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A025C8: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000A025D0: D501000A 21AA150A
	v_add_f32_e32 v10, v10, v12                                // 000000A025D8: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 000000A025DC: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A025E0: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A025E8: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A025F0: BF870214
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A025F4: 7E1E02FA FF01640A
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A025FC: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A02604: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000A0260C: D501000C 2006190C
	v_add_f32_e32 v16, v9, v13                                 // 000000A02614: 06201B09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A02618: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A02620: BF870214
	v_add_f32_e32 v15, v10, v15                                // 000000A02624: 061E1F0A
	v_add_f32_e32 v17, v12, v17                                // 000000A02628: 0622230C
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0262C: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A02634: 7E1602FA FF016810
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0263C: BF870214
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A02640: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A02648: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 000000A02650: 8B7E007E
	s_cbranch_execz 171                                        // 000000A02654: BFA500AB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2604>
	v_lshl_or_b32 v18, s10, 7, v1                              // 000000A02658: D6560012 04050E0A
	v_and_b32_e32 v1, 8, v0                                    // 000000A02660: 36020088
	.long 0x7f2c3880                                           // 000000A02664: 7F2C3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A02668: BF870113
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000A0266C: 3426249F
	.long 0x7f323996                                           // 000000A02670: 7F323996
	.long 0x7f2e3996                                           // 000000A02674: 7F2E3996
	.long 0x7f303996                                           // 000000A02678: 7F303996
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0267C: BF870094
	.long 0xd73c0012                                           // 000000A02680: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000A02684: 02022481
	.long 0xd7006a14                                           // 000000A02688: D7006A14
	v_cndmask_b32_e32 v1, s36, v18, vcc_lo                     // 000000A0268C: 02022424
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A02690: BF870001
	v_add_co_ci_u32_e64 v21, null, s37, v19, vcc_lo            // 000000A02694: D5207C15 01AA2625
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000A0269C: 7C940280
	s_clause 0x7                                               // 000000A026A0: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000A026A4: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000A026AC: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 000000A026B4: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 000000A026BC: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 000000A026C4: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 000000A026CC: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 000000A026D4: DC8200C0 1C7C0014
	global_load_d16_b16 v29, v[20:21], off offset:224          // 000000A026DC: DC8200E0 1D7C0014
	v_mad_i64_i32 v[20:21], null, s49, v40, 0                  // 000000A026E4: D6FF7C14 02025031
	v_cndmask_b32_e64 v1, -v7, v7, vcc_lo                      // 000000A026EC: D5010001 21AA0F07
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000A026F4: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000A026FC: D501000E 21AA1D0E
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000A02704: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000A0270C: D501000F 21AA1F0F
	v_add_f32_e32 v1, v1, v5                                   // 000000A02714: 06020B01
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 000000A02718: D5010005 21AA0D06
	.long 0xd73c0014                                           // 000000A02720: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000A02724: 02022881
	v_cndmask_b32_e64 v6, -v16, v16, vcc_lo                    // 000000A02728: D5010006 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000A02730: D5010010 21AA2311
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A02738: BF8700B4
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v8     // 000000A0273C: C9081304 04041105
	v_add_f32_e32 v8, v14, v10                                 // 000000A02744: 0610150E
	.long 0xd7006a11                                           // 000000A02748: D7006A11
	v_cndmask_b32_e32 v1, s42, v20, vcc_lo                     // 000000A0274C: 0202282A
	v_add_co_ci_u32_e64 v20, null, s43, v21, vcc_lo            // 000000A02750: D5207C14 01AA2A2B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A02758: BF8701C4
	v_dual_mul_f32 v21, 0x3db504f3, v1 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000A0275C: C8C602FF 150408FF 3DB504F3
	v_dual_add_f32 v3, v3, v2 :: v_dual_add_f32 v6, v6, v11    // 000000A02768: C9080503 03061706
	v_dual_add_f32 v9, v15, v12 :: v_dual_add_f32 v10, v16, v13// 000000A02770: C908190F 090A1B10
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000A02778: 100A0AFF 3DB504F3
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000A02780: C8C606FF 030810FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0278C: BF870214
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000A02790: 100C0CFF 3DB504F3
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000A02798: 101414FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000A027A0: BF891FF7
	.long 0x7f0e3996                                           // 000000A027A4: 7F0E3996
	.long 0xd7006a01                                           // 000000A027A8: D7006A01
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000A027AC: 02022511
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A027B0: BF870001
	v_add_co_ci_u32_e64 v2, null, v20, v19, vcc_lo             // 000000A027B4: D5207C02 01AA2714
	v_fma_mix_f32 v11, v22, v21, neg(0) op_sel_hi:[1,0,0]      // 000000A027BC: CC20000B 8A022B16
	s_waitcnt vmcnt(6)                                         // 000000A027C4: BF891BF7
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 000000A027C8: CC200003 8A020717
	s_waitcnt vmcnt(5)                                         // 000000A027D0: BF8917F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000A027D4: CC200005 8A020B18
	s_waitcnt vmcnt(4)                                         // 000000A027DC: BF8913F7
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A027E0: CC200004 8A020919
	s_waitcnt vmcnt(3)                                         // 000000A027E8: BF890FF7
	v_fma_mix_f32 v8, v26, v8, neg(0) op_sel_hi:[1,0,0]        // 000000A027EC: CC200008 8A02111A
	.long 0x7e2c398b                                           // 000000A027F4: 7E2C398B
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000A027F8: 101212FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 000000A02800: BF890BF7
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 000000A02804: CC200006 8A020D1B
	s_waitcnt vmcnt(0)                                         // 000000A0280C: BF8903F7
	v_fma_mix_f32 v10, v29, v10, neg(0) op_sel_hi:[1,0,0]      // 000000A02810: CC20000A 8A02151D
	.long 0x7e0e3983                                           // 000000A02818: 7E0E3983
	v_and_b32_e32 v12, 1, v22                                  // 000000A0281C: 36182C81
	.long 0x7e2c3984                                           // 000000A02820: 7E2C3984
	v_fma_mix_f32 v9, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A02824: CC200009 8A02131C
	.long 0x7e2e3985                                           // 000000A0282C: 7E2E3985
	.long 0x7e303988                                           // 000000A02830: 7E303988
	v_and_b32_e32 v7, 1, v7                                    // 000000A02834: 360E0E81
	v_and_b32_e32 v13, 1, v22                                  // 000000A02838: 361A2C81
	.long 0x7e2c3986                                           // 000000A0283C: 7E2C3986
	.long 0x7e323989                                           // 000000A02840: 7E323989
	v_and_b32_e32 v14, 1, v23                                  // 000000A02844: 361C2E81
	v_and_b32_e32 v15, 1, v24                                  // 000000A02848: 361E3081
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000A0284C: D6550003 03FE0F03 00007FFF
	v_and_b32_e32 v16, 1, v22                                  // 000000A02858: 36202C81
	.long 0x7e2c398a                                           // 000000A0285C: 7E2C398A
	v_and_b32_e32 v17, 1, v25                                  // 000000A02860: 36223281
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000A02864: D655000B 03FE190B 00007FFF
	v_add3_u32 v5, v5, v14, 0x7fff                             // 000000A02870: D6550005 03FE1D05 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 000000A0287C: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v7, 1, v22                                   // 000000A02888: 360E2C81
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000A0288C: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000A02898: D6550009 03FE2309 00007FFF
	v_add3_u32 v6, v6, v16, 0x7fff                             // 000000A028A4: D6550006 03FE2106 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A028B0: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 000000A028B4: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 000000A028C0: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 000000A028C4: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v11, off offset:32         // 000000A028CC: DC960020 007C0B01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 000000A028D4: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 000000A028DC: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 000000A028E4: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v6, off offset:160         // 000000A028EC: DC9600A0 007C0601
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 000000A028F4: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v7, off offset:224         // 000000A028FC: DC9600E0 007C0701
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A02904: 8C7E037E
	s_mov_b32 s4, 0                                            // 000000A02908: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A0290C: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000A02910: 8B6A047E
	s_cbranch_vccz 5329                                        // 000000A02914: BFA314D1 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x795c>
	s_mul_hi_i32 s0, s2, 0x66666667                            // 000000A02918: 9700FF02 66666667
	v_mov_b32_e32 v1, 0                                        // 000000A02920: 7E020280
	s_lshr_b32 s1, s0, 31                                      // 000000A02924: 85019F00
	s_ashr_i32 s0, s0, 1                                       // 000000A02928: 86008100
	s_mov_b32 s3, exec_lo                                      // 000000A0292C: BE83007E
	s_add_i32 s10, s0, s1                                      // 000000A02930: 810A0100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A02934: BF870499
	s_ashr_i32 s11, s10, 31                                    // 000000A02938: 860B9F0A
	s_lshl_b64 s[0:1], s[10:11], 2                             // 000000A0293C: 8480820A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A02940: BF870009
	s_add_u32 s0, s16, s0                                      // 000000A02944: 80000010
	s_addc_u32 s1, s17, s1                                     // 000000A02948: 82010111
	global_load_b32 v1, v1, s[0:1]                             // 000000A0294C: DC520000 01000001
	s_waitcnt vmcnt(0)                                         // 000000A02954: BF8903F7
	v_readfirstlane_b32 s1, v1                                 // 000000A02958: 7E020501
	v_cmpx_gt_u32_e32 0x140, v0                                // 000000A0295C: 7D9800FF 00000140
	s_cbranch_execz 42                                         // 000000A02964: BFA5002A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2710>
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 000000A02968: 9700FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000A02970: 30080084
	s_lshr_b32 s4, s0, 31                                      // 000000A02974: 85049F00
	s_ashr_i32 s0, s0, 4                                       // 000000A02978: 86008400
	v_or_b32_e32 v3, 0xffffff00, v0                            // 000000A0297C: 380600FF FFFFFF00
	s_add_i32 s0, s0, s4                                       // 000000A02984: 81000400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A02988: BF8700D9
	s_mul_i32 s4, s0, 0x1400                                   // 000000A0298C: 9604FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 000000A02994: 9700FF00 00001400
	s_add_u32 s4, s14, s4                                      // 000000A0299C: 8004040E
	s_addc_u32 s0, s15, s0                                     // 000000A029A0: 8200000F
	.long 0xd7000401                                           // 000000A029A4: D7000401
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000A029A8: 02020804
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 000000A029AC: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 000000A029B4: BE840080
	s_nop 0                                                    // 000000A029B8: BF800000
	s_nop 0                                                    // 000000A029BC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 000000A029C0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 000000A029C8: 4A0606FF 00000100
	.long 0xd7006a01                                           // 000000A029D0: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 000000A029D4: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A029DC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A029E0: D5207C02 01AA0480
	.long 0xd4490000                                           // 000000A029E8: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 000000A029EC: 020206BF
	s_or_b32 s4, s0, s4                                        // 000000A029F0: 8C040400
	s_waitcnt vmcnt(0)                                         // 000000A029F4: BF8903F7
	ds_store_b128 v4, v[5:8]                                   // 000000A029F8: DB7C0000 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 000000A02A00: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A02A08: 917E047E
	s_cbranch_execnz 65516                                     // 000000A02A0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x26c0>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A02A10: 8C7E037E
	v_mul_u32_u24_e32 v71, 20, v40                             // 000000A02A14: 168E5094
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v42, 2, v41     // 000000A02A18: CA220080 012A5282
	s_mul_i32 s0, s10, -5                                      // 000000A02A20: 9600C50A
	s_mul_i32 s5, s1, 0x190000                                 // 000000A02A24: 9605FF01 00190000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A02A2C: BF870112
	v_min_u32_e32 v3, 0x8c, v71                                // 000000A02A30: 26068EFF 0000008C
	v_mov_b32_e32 v16, v1                                      // 000000A02A38: 7E200301
	v_mov_b32_e32 v2, v1                                       // 000000A02A3C: 7E040301
	v_mov_b32_e32 v4, v1                                       // 000000A02A40: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000A02A44: 7E0A0301
	v_add_nc_u32_e32 v43, 20, v3                               // 000000A02A48: 4A560694
	v_mov_b32_e32 v3, v1                                       // 000000A02A4C: 7E060301
	v_mov_b32_e32 v6, v1                                       // 000000A02A50: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000A02A54: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000A02A58: 7E100301
	v_mov_b32_e32 v9, v1                                       // 000000A02A5C: 7E120301
	v_mov_b32_e32 v10, v1                                      // 000000A02A60: 7E140301
	v_mov_b32_e32 v11, v1                                      // 000000A02A64: 7E160301
	v_mov_b32_e32 v12, v1                                      // 000000A02A68: 7E180301
	v_mov_b32_e32 v13, v1                                      // 000000A02A6C: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 000000A02A70: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 000000A02A74: 7E1E0301
	s_add_i32 s2, s0, s2                                       // 000000A02A78: 81020200
	s_mul_hi_i32 s4, s1, 0x190000                              // 000000A02A7C: 9704FF01 00190000
	v_mov_b32_e32 v32, v16                                     // 000000A02A84: 7E400310
	s_add_u32 s0, s12, s5                                      // 000000A02A88: 8000050C
	s_mul_i32 s6, s2, 0x50000                                  // 000000A02A8C: 9606FF02 00050000
	v_cmp_lt_u32_e32 vcc_lo, v71, v43                          // 000000A02A94: 7C925747
	v_dual_mov_b32 v31, v15 :: v_dual_mov_b32 v30, v14         // 000000A02A98: CA10010F 1F1E010E
	v_dual_mov_b32 v29, v13 :: v_dual_mov_b32 v28, v12         // 000000A02AA0: CA10010D 1D1C010C
	v_dual_mov_b32 v27, v11 :: v_dual_mov_b32 v26, v10         // 000000A02AA8: CA10010B 1B1A010A
	v_dual_mov_b32 v25, v9 :: v_dual_mov_b32 v24, v8           // 000000A02AB0: CA100109 19180108
	v_dual_mov_b32 v23, v7 :: v_dual_mov_b32 v22, v6           // 000000A02AB8: CA100107 17160106
	v_dual_mov_b32 v21, v5 :: v_dual_mov_b32 v20, v4           // 000000A02AC0: CA100105 15140104
	v_dual_mov_b32 v19, v3 :: v_dual_mov_b32 v18, v2           // 000000A02AC8: CA100103 13120102
	v_mov_b32_e32 v17, v1                                      // 000000A02AD0: 7E220301
	s_addc_u32 s3, s13, s4                                     // 000000A02AD4: 8203040D
	s_mul_hi_i32 s7, s2, 0x50000                               // 000000A02AD8: 9707FF02 00050000
	s_add_u32 s8, s0, s6                                       // 000000A02AE0: 80080600
	s_addc_u32 s9, s3, s7                                      // 000000A02AE4: 82090703
	s_waitcnt lgkmcnt(0)                                       // 000000A02AE8: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000A02AEC: BC7C0000
	s_barrier                                                  // 000000A02AF0: BFBD0000
	buffer_gl0_inv                                             // 000000A02AF4: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 000000A02AFC: BE83206A
	s_cbranch_execz 45                                         // 000000A02B00: BFA5002D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x28b8>
	v_mul_u32_u24_e32 v17, 0xa000, v40                         // 000000A02B04: 162250FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A02B0C: BF870091
	.long 0xd7000011                                           // 000000A02B10: D7000011
	v_cndmask_b32_e32 v1, s8, v17, vcc_lo                      // 000000A02B14: 02022208
	v_add_co_ci_u32_e64 v18, null, s9, 0, s0                   // 000000A02B18: D5207C12 00010009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A02B20: BF870092
	.long 0xd7000020                                           // 000000A02B24: D7000020
	v_cndmask_b32_e32 v1, v17, v42, vcc_lo                     // 000000A02B28: 02025511
	v_add_co_ci_u32_e64 v33, null, 0, v18, s0                  // 000000A02B2C: D5207C21 00022480
	s_clause 0xf                                               // 000000A02B34: BF85000F
	global_load_b32 v17, v[32:33], off                         // 000000A02B38: DC520000 117C0020
	global_load_b32 v18, v[32:33], off offset:128              // 000000A02B40: DC520080 127C0020
	global_load_b32 v19, v[32:33], off offset:256              // 000000A02B48: DC520100 137C0020
	global_load_b32 v20, v[32:33], off offset:384              // 000000A02B50: DC520180 147C0020
	global_load_b32 v21, v[32:33], off offset:512              // 000000A02B58: DC520200 157C0020
	global_load_b32 v22, v[32:33], off offset:640              // 000000A02B60: DC520280 167C0020
	global_load_b32 v23, v[32:33], off offset:768              // 000000A02B68: DC520300 177C0020
	global_load_b32 v24, v[32:33], off offset:896              // 000000A02B70: DC520380 187C0020
	global_load_b32 v25, v[32:33], off offset:1024             // 000000A02B78: DC520400 197C0020
	global_load_b32 v26, v[32:33], off offset:1152             // 000000A02B80: DC520480 1A7C0020
	global_load_b32 v27, v[32:33], off offset:1280             // 000000A02B88: DC520500 1B7C0020
	global_load_b32 v28, v[32:33], off offset:1408             // 000000A02B90: DC520580 1C7C0020
	global_load_b32 v29, v[32:33], off offset:1536             // 000000A02B98: DC520600 1D7C0020
	global_load_b32 v30, v[32:33], off offset:1664             // 000000A02BA0: DC520680 1E7C0020
	global_load_b32 v31, v[32:33], off offset:1792             // 000000A02BA8: DC520700 1F7C0020
	global_load_b32 v32, v[32:33], off offset:1920             // 000000A02BB0: DC520780 207C0020
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A02BB8: 8C7E037E
	v_or_b32_e32 v33, 1, v71                                   // 000000A02BBC: 38428E81
	s_mov_b32 s3, exec_lo                                      // 000000A02BC0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A02BC4: BF870001
	.long 0xd4c9007e                                           // 000000A02BC8: D4C9007E
	v_cndmask_b32_e32 v1, v33, v43, vcc_lo                     // 000000A02BCC: 02025721
	s_cbranch_execz 44                                         // 000000A02BD0: BFA5002C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2984>
	v_lshlrev_b32_e32 v1, 11, v33                              // 000000A02BD4: 3002428B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A02BD8: BF870091
	.long 0xd7000001                                           // 000000A02BDC: D7000001
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000A02BE0: 02020208
	v_add_co_ci_u32_e64 v2, null, s9, 0, s0                    // 000000A02BE4: D5207C02 00010009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A02BEC: BF870092
	.long 0xd7000021                                           // 000000A02BF0: D7000021
	v_cndmask_b32_e32 v1, v1, v42, vcc_lo                      // 000000A02BF4: 02025501
	v_add_co_ci_u32_e64 v34, null, 0, v2, s0                   // 000000A02BF8: D5207C22 00020480
	s_clause 0xf                                               // 000000A02C00: BF85000F
	global_load_b32 v1, v[33:34], off                          // 000000A02C04: DC520000 017C0021
	global_load_b32 v2, v[33:34], off offset:128               // 000000A02C0C: DC520080 027C0021
	global_load_b32 v3, v[33:34], off offset:256               // 000000A02C14: DC520100 037C0021
	global_load_b32 v4, v[33:34], off offset:384               // 000000A02C1C: DC520180 047C0021
	global_load_b32 v5, v[33:34], off offset:512               // 000000A02C24: DC520200 057C0021
	global_load_b32 v6, v[33:34], off offset:640               // 000000A02C2C: DC520280 067C0021
	global_load_b32 v7, v[33:34], off offset:768               // 000000A02C34: DC520300 077C0021
	global_load_b32 v8, v[33:34], off offset:896               // 000000A02C3C: DC520380 087C0021
	global_load_b32 v9, v[33:34], off offset:1024              // 000000A02C44: DC520400 097C0021
	global_load_b32 v10, v[33:34], off offset:1152             // 000000A02C4C: DC520480 0A7C0021
	global_load_b32 v11, v[33:34], off offset:1280             // 000000A02C54: DC520500 0B7C0021
	global_load_b32 v12, v[33:34], off offset:1408             // 000000A02C5C: DC520580 0C7C0021
	global_load_b32 v13, v[33:34], off offset:1536             // 000000A02C64: DC520600 0D7C0021
	global_load_b32 v14, v[33:34], off offset:1664             // 000000A02C6C: DC520680 0E7C0021
	global_load_b32 v15, v[33:34], off offset:1792             // 000000A02C74: DC520700 0F7C0021
	global_load_b32 v16, v[33:34], off offset:1920             // 000000A02C7C: DC520780 107C0021
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A02C84: 8C7E037E
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v45, 0             // 000000A02C88: CA100080 3A2C0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v47, 0             // 000000A02C90: CA100080 2C2E0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v49, 0             // 000000A02C98: CA100080 2E300080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v51, 0             // 000000A02CA0: CA100080 30320080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v53, 0             // 000000A02CA8: CA100080 32340080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v55, 0             // 000000A02CB0: CA100080 34360080
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v57, 0             // 000000A02CB8: CA100080 36380080
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v59, 0             // 000000A02CC0: CA100080 383A0080
	s_and_saveexec_b32 s3, vcc_lo                              // 000000A02CC8: BE83206A
	s_cbranch_execz 3633                                       // 000000A02CCC: BFA50E31 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x6294>
	v_cmp_ne_u32_e32 vcc_lo, 0, v41                            // 000000A02CD0: 7C9A5280
	v_lshlrev_b32_e32 v33, 5, v41                              // 000000A02CD4: 30425285
	v_dual_mov_b32 v59, 0 :: v_dual_lshlrev_b32 v44, 11, v71   // 000000A02CD8: CA220080 3B2C8E8B
	.long 0xd700003c                                           // 000000A02CE0: D700003C
	v_cndmask_b32_e32 v1, s8, v42, vcc_lo                      // 000000A02CE4: 02025408
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A02CE8: BF870003
	v_dual_mov_b32 v37, 0 :: v_dual_add_nc_u32 v34, 0x3f0, v33 // 000000A02CEC: CA200080 252242FF 000003F0
	v_add_co_ci_u32_e64 v61, null, s9, 0, s0                   // 000000A02CF8: D5207C3D 00010009
	s_add_u32 s0, s5, s6                                       // 000000A02D00: 80000605
	v_lshrrev_b32_e32 v38, 5, v34                              // 000000A02D04: 324C4485
	s_addc_u32 s4, s4, s7                                      // 000000A02D08: 82040704
	.long 0xd700002c                                           // 000000A02D0C: D700002C
	v_cndmask_b32_e32 v1, s0, v44, vcc_lo                      // 000000A02D10: 02025800
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A02D14: BF870191
	v_add_co_ci_u32_e64 v45, null, s4, 0, s0                   // 000000A02D18: D5207C2D 00010004
	v_subrev_nc_u32_e32 v38, 32, v38                           // 000000A02D20: 4E4C4CA0
	v_dual_mov_b32 v57, 0 :: v_dual_and_b32 v34, 0x7e0, v34    // 000000A02D24: CA240080 392244FF 000007E0
	v_mul_u32_u24_e32 v35, 0x840, v40                          // 000000A02D30: 164650FF 00000840
	v_mad_u32_u24 v36, 0x840, v40, v42                         // 000000A02D38: D60B0024 04AA50FF 00000840
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A02D44: BF8700A4
	v_cndmask_b32_e32 v38, 31, v38, vcc_lo                     // 000000A02D48: 024C4C9F
	.long 0xd7006a2c                                           // 000000A02D4C: D7006A2C
	v_cndmask_b32_e32 v1, v44, v42, vcc_lo                     // 000000A02D50: 0202552C
	v_add_co_ci_u32_e64 v45, null, 0, v45, vcc_lo              // 000000A02D54: D5207C2D 01AA5A80
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A02D5C: BF870223
	v_dual_mov_b32 v55, 0 :: v_dual_add_nc_u32 v46, 1, v38     // 000000A02D60: CA200080 372E4C81
	v_sub_nc_u32_e32 v33, v34, v33                             // 000000A02D68: 4C424322
	.long 0xd7006a2c                                           // 000000A02D6C: D7006A2C
	v_cndmask_b32_e32 v1, s12, v44, vcc_lo                     // 000000A02D70: 0202580C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A02D74: BF870003
	v_dual_mov_b32 v53, 0 :: v_dual_and_b32 v34, 31, v46       // 000000A02D78: CA240080 35225C9F
	v_dual_mov_b32 v56, 0 :: v_dual_and_b32 v39, 16, v0        // 000000A02D80: CA240080 38260090
	v_add_co_ci_u32_e64 v45, null, s13, v45, vcc_lo            // 000000A02D88: D5207C2D 01AA5A0D
	v_dual_mov_b32 v51, 0 :: v_dual_add_nc_u32 v62, 0xfffffc30, v33// 000000A02D90: CA200080 333E42FF FFFFFC30
	v_lshl_add_u32 v33, v38, 2, v35                            // 000000A02D9C: D6460021 048D0526
	v_lshl_add_u32 v34, v34, 2, v35                            // 000000A02DA4: D6460022 048D0522
	.long 0xd7006a26                                           // 000000A02DAC: D7006A26
	v_cndmask_b32_e32 v1, 0x1400, v44, vcc_lo                  // 000000A02DB0: 020258FF 00001400
	v_lshl_or_b32 v63, v71, 5, v39                             // 000000A02DB8: D656003F 049D0B47
	v_add_co_ci_u32_e64 v39, null, 0, v45, vcc_lo              // 000000A02DC0: D5207C27 01AA5A80
	v_dual_mov_b32 v49, 0 :: v_dual_add_nc_u32 v64, 0x1400, v36// 000000A02DC8: CA200080 314048FF 00001400
	v_dual_mov_b32 v54, 0 :: v_dual_add_nc_u32 v65, 0x1800, v36// 000000A02DD4: CA200080 364048FF 00001800
	v_dual_mov_b32 v47, 0 :: v_dual_add_nc_u32 v66, 0x1400, v33// 000000A02DE0: CA200080 2F4242FF 00001400
	v_dual_mov_b32 v52, 0 :: v_dual_add_nc_u32 v67, 0x1400, v34// 000000A02DEC: CA200080 344244FF 00001400
	v_dual_mov_b32 v45, 0 :: v_dual_add_nc_u32 v68, 0x1800, v33// 000000A02DF8: CA200080 2D4442FF 00001800
	v_dual_mov_b32 v50, 0 :: v_dual_add_nc_u32 v69, 0x1800, v34// 000000A02E04: CA200080 324444FF 00001800
	v_mov_b32_e32 v48, 0                                       // 000000A02E10: 7E600280
	v_mov_b32_e32 v46, 0                                       // 000000A02E14: 7E5C0280
	v_mov_b32_e32 v44, 0                                       // 000000A02E18: 7E580280
	v_mov_b32_e32 v58, 0                                       // 000000A02E1C: 7E740280
	s_mov_b32 s4, 0                                            // 000000A02E20: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000A02E24: B0051EEE
	s_branch 1714                                              // 000000A02E28: BFA006B2 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x45f4>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000A02E2C: 8C7E077E
	ds_load_2addr_b32 v[71:72], v67 offset1:32                 // 000000A02E30: D8DC2000 47000043
	ds_load_2addr_b32 v[77:78], v64 offset1:32                 // 000000A02E38: D8DC2000 4D000040
	ds_load_2addr_b32 v[75:76], v66 offset1:32                 // 000000A02E40: D8DC2000 4B000042
	ds_load_b128 v[33:36], v63 offset:32                       // 000000A02E48: DBFC0020 2100003F
	s_waitcnt lgkmcnt(3)                                       // 000000A02E50: BF89FC37
	v_mov_b32_e32 v74, v71                                     // 000000A02E54: 7E940347
	s_waitcnt lgkmcnt(2)                                       // 000000A02E58: BF89FC27
	v_bfe_u32 v71, v77, 12, 16                                 // 000000A02E5C: D6100047 0241194D
	s_waitcnt lgkmcnt(1)                                       // 000000A02E64: BF89FC17
	v_mov_b32_e32 v73, v76                                     // 000000A02E68: 7E92034C
	v_bfe_u32 v79, v77, 8, 16                                  // 000000A02E6C: D610004F 0241114D
	v_bfe_u32 v80, v77, 4, 16                                  // 000000A02E74: D6100050 0241094D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A02E7C: 369A9AFF 0000FFFF
	.long 0xd73d004a                                           // 000000A02E84: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000A02E88: 0202953E
	v_bfe_u32 v76, v78, 12, 16                                 // 000000A02E8C: D610004C 0241194E
	v_bfe_u32 v81, v78, 8, 16                                  // 000000A02E94: D6100051 0241114E
	v_bfe_u32 v82, v78, 4, 16                                  // 000000A02E9C: D6100052 0241094E
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A02EA4: 369C9CFF 0000FFFF
	.long 0xd72c004b                                           // 000000A02EAC: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A02EB0: 02028EFF 83DCD12D
	.long 0xd73d0047                                           // 000000A02EB8: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A02EBC: 0202913E
	.long 0xd72c004d                                           // 000000A02EC0: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A02EC4: 02029AFF 83DCD12D
	.long 0xd72c0050                                           // 000000A02ECC: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A02ED0: 0202A0FF 83DCD12D
	.long 0xd72c004f                                           // 000000A02ED8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A02EDC: 02029EFF 83DCD12D
	v_bfe_u32 v83, v74, 4, 16                                  // 000000A02EE4: D6100053 0241094A
	v_bfe_u32 v72, v74, 12, 16                                 // 000000A02EEC: D6100048 0241194A
	v_bfe_u32 v84, v71, 12, 16                                 // 000000A02EF4: D6100054 02411947
	v_bfe_u32 v85, v71, 8, 16                                  // 000000A02EFC: D6100055 02411147
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A02F04: D622004B 03FD014B 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A02F10: D622004D 03FD014D 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A02F1C: D6220050 03FD0150 00006400
	.long 0xd72c0054                                           // 000000A02F28: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A02F2C: 0202A8FF 83DCD12D
	.long 0xd72c0053                                           // 000000A02F34: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A02F38: 0202A6FF 83DCD12D
	.long 0xd72c0055                                           // 000000A02F40: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A02F44: 0202AAFF 83DCD12D
	v_lshlrev_b32_e32 v77, 16, v77                             // 000000A02F4C: 309A9A90
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A02F50: D622004F 03FD014F 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A02F5C: 369696FF 0000FFFF
	.long 0xd72c0049                                           // 000000A02F64: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A02F68: 020298FF 83DCD12D
	v_bfe_u32 v76, v74, 8, 16                                  // 000000A02F70: D610004C 0241114A
	v_and_or_b32 v80, 0xffff, v80, v77                         // 000000A02F78: D6570050 0536A0FF 0000FFFF
	v_sad_u8 v77, v84, 0, 0x6400                               // 000000A02F84: D622004D 03FD0154 00006400
	.long 0xd72c0048                                           // 000000A02F90: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A02F94: 020290FF 83DCD12D
	v_lshl_or_b32 v75, v79, 16, v75                            // 000000A02F9C: D656004B 052D214F
	v_sad_u8 v79, v83, 0, 0x6400                               // 000000A02FA4: D622004F 03FD0153 00006400
	v_sad_u8 v83, v85, 0, 0x6400                               // 000000A02FB0: D6220053 03FD0155 00006400
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A02FBC: 369A9AFF 0000FFFF
	.long 0xd72c004c                                           // 000000A02FC4: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A02FC8: 020298FF 83DCD12D
	v_bfe_u32 v86, v71, 4, 16                                  // 000000A02FD0: D6100056 02410947
	v_and_b32_e32 v71, 0xffff, v71                             // 000000A02FD8: 368E8EFF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A02FE0: D6220048 03FD0148 00006400
	v_lshl_or_b32 v77, v83, 16, v77                            // 000000A02FEC: D656004D 05352153
	.long 0xd72c0051                                           // 000000A02FF4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A02FF8: 0202A2FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A03000: D6220049 03FD0149 00006400
	.long 0xd72c0047                                           // 000000A0300C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A03010: 02028EFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A03018: D622004C 03FD014C 00006400
	v_pk_fma_f16 v83, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03024: CC0E0053 0BFC0B4D 0000C931
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A03030: 369090FF 0000FFFF
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A03038: 369292FF 0000FFFF
	.long 0xd72c0056                                           // 000000A03040: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A03044: 0202ACFF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0304C: D6220051 03FD0151 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000A03058: BF89FC07
	v_dot2acc_f32_f16 v57, v83, v33                            // 000000A0305C: 04724353
	v_lshl_or_b32 v72, v76, 16, v72                            // 000000A03060: D6560048 0521214C
	v_sad_u8 v76, v71, 0, 0x6400                               // 000000A03068: D622004C 03FD0147 00006400
	.long 0xd72c004e                                           // 000000A03074: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A03078: 02029CFF 83DCD12D
	v_lshl_or_b32 v81, v81, 16, v73                            // 000000A03080: D6560051 05252151
	.long 0xd72c0052                                           // 000000A03088: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0308C: 0202A4FF 83DCD12D
	v_pk_fma_f16 v84, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03094: CC0E0054 0BFC0B48 0000C931
	v_and_b32_e32 v74, 0xffff, v74                             // 000000A030A0: 369494FF 0000FFFF
	ds_load_2addr_b32 v[71:72], v67 offset0:64 offset1:96      // 000000A030A8: D8DC6040 47000043
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000A030B0: D6220056 03FD0156 00006400
	v_dot2acc_f32_f16 v59, v84, v33                            // 000000A030BC: 04764354
	.long 0xd72c004a                                           // 000000A030C0: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A030C4: 020294FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A030CC: D622004E 03FD014E 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A030D8: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A030E4: BF8700A3
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A030E8: D622004A 03FD014A 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000A030F4: BF89FC07
	v_dual_mov_b32 v73, v71 :: v_dual_lshlrev_b32 v74, 16, v74 // 000000A030F8: CA220147 494A9490
	v_pk_fma_f16 v71, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03100: CC0E0047 0BFC0B51 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A0310C: BF870122
	v_and_or_b32 v74, 0xffff, v79, v74                         // 000000A03110: D657004A 052A9EFF 0000FFFF
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0311C: CC0E004F 0BFC0B4B 0000C931
	v_pk_fma_f16 v85, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03128: CC0E0055 0BFC0B4A 0000C931
	ds_load_2addr_b32 v[74:75], v66 offset0:64 offset1:96      // 000000A03134: D8DC6040 4A000042
	v_dual_dot2acc_f32_f16 v59, v85, v34 :: v_dual_lshlrev_b32 v76, 16, v76// 000000A0313C: CB224555 3B4C9890
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000A03144: 309C9C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A03148: BF870192
	v_and_or_b32 v76, 0xffff, v86, v76                         // 000000A0314C: D657004C 0532ACFF 0000FFFF
	v_dot2acc_f32_f16 v59, v79, v35                            // 000000A03158: 0476474F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0315C: BF870193
	v_and_or_b32 v78, 0xffff, v82, v78                         // 000000A03160: D657004E 053AA4FF 0000FFFF
	v_pk_fma_f16 v84, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0316C: CC0E0054 0BFC0B4C 0000C931
	ds_load_2addr_b32 v[76:77], v64 offset0:64 offset1:96      // 000000A03178: D8DC6040 4C000040
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03180: CC0E004E 0BFC0B4E 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A0318C: BF89FC17
	.long 0xd73d0049                                           // 000000A03190: D73D0049
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A03194: 0202933E
	v_dot2acc_f32_f16 v57, v84, v34                            // 000000A03198: 04724554
	v_pk_fma_f16 v74, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0319C: CC0E004A 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A031A8: BF870113
	v_bfe_u32 v79, v73, 8, 16                                  // 000000A031AC: D610004F 02411149
	v_dual_dot2acc_f32_f16 v59, v74, v36 :: v_dual_and_b32 v74, 0xffff, v73// 000000A031B4: CB24494A 3B4A92FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A031C0: BF870004
	v_dot2acc_f32_f16 v57, v71, v35                            // 000000A031C4: 04724747
	v_bfe_u32 v71, v73, 12, 16                                 // 000000A031C8: D6100047 02411949
	v_bfe_u32 v73, v73, 4, 16                                  // 000000A031D0: D6100049 02410949
	s_waitcnt lgkmcnt(0)                                       // 000000A031D8: BF89FC07
	v_bfe_u32 v80, v76, 8, 16                                  // 000000A031DC: D6100050 0241114C
	.long 0xd72c004a                                           // 000000A031E4: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A031E8: 020294FF 83DCD12D
	v_dot2acc_f32_f16 v57, v78, v36                            // 000000A031F0: 0472494E
	.long 0xd72c0047                                           // 000000A031F4: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A031F8: 02028EFF 83DCD12D
	v_bfe_u32 v78, v76, 12, 16                                 // 000000A03200: D610004E 0241194C
	.long 0xd72c004f                                           // 000000A03208: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A0320C: 02029EFF 83DCD12D
	v_bfe_u32 v81, v76, 4, 16                                  // 000000A03214: D6100051 0241094C
	.long 0xd72c0049                                           // 000000A0321C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A03220: 020292FF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A03228: 369898FF 0000FFFF
	.long 0xd72c004e                                           // 000000A03230: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A03234: 02029CFF 83DCD12D
	.long 0xd72c0050                                           // 000000A0323C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A03240: 0202A0FF 83DCD12D
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A03248: D6220047 03FD0147 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A03254: D622004A 03FD014A 00006400
	.long 0xd72c004c                                           // 000000A03260: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A03264: 020298FF 83DCD12D
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A0326C: D622004F 03FD014F 00006400
	v_sad_u8 v82, v73, 0, 0x6400                               // 000000A03278: D6220052 03FD0149 00006400
	v_and_b32_e32 v71, 0xffff, v71                             // 000000A03284: 368E8EFF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A0328C: D622004E 03FD014E 00006400
	v_mov_b32_e32 v73, v75                                     // 000000A03298: 7E92034B
	.long 0xd72c0051                                           // 000000A0329C: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A032A0: 0202A2FF 83DCD12D
	v_lshlrev_b32_e32 v74, 16, v74                             // 000000A032A8: 30949490
	v_sad_u8 v75, v80, 0, 0x6400                               // 000000A032AC: D622004B 03FD0150 00006400
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A032B8: 369C9CFF 0000FFFF
	v_lshl_or_b32 v79, v79, 16, v71                            // 000000A032C0: D656004F 051D214F
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A032C8: D622004C 03FD014C 00006400
	.long 0xd73d0047                                           // 000000A032D4: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A032D8: 0202913E
	v_and_or_b32 v74, 0xffff, v82, v74                         // 000000A032DC: D657004A 052AA4FF 0000FFFF
	v_lshl_or_b32 v72, v75, 16, v78                            // 000000A032E8: D6560048 0539214B
	v_sad_u8 v73, v81, 0, 0x6400                               // 000000A032F0: D6220049 03FD0151 00006400
	v_lshlrev_b32_e32 v75, 16, v76                             // 000000A032FC: 30969890
	v_pk_fma_f16 v76, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03300: CC0E004C 0BFC0B4F 0000C931
	v_bfe_u32 v78, v71, 12, 16                                 // 000000A0330C: D610004E 02411947
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03314: CC0E004A 0BFC0B4A 0000C931
	v_pk_fma_f16 v79, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03320: CC0E004F 0BFC0B48 0000C931
	v_and_or_b32 v72, 0xffff, v73, v75                         // 000000A0332C: D6570048 052E92FF 0000FFFF
	v_dot2acc_f32_f16 v56, v76, v33                            // 000000A03338: 0470434C
	v_bfe_u32 v73, v71, 8, 16                                  // 000000A0333C: D6100049 02411147
	.long 0xd72c004b                                           // 000000A03344: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A03348: 02029CFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v71                             // 000000A03350: 36988EFF 0000FFFF
	v_pk_fma_f16 v78, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03358: CC0E004E 0BFC0B48 0000C931
	v_dot2acc_f32_f16 v56, v74, v34                            // 000000A03364: 0470454A
	v_bfe_u32 v74, v71, 4, 16                                  // 000000A03368: D610004A 02410947
	ds_load_2addr_b32 v[71:72], v67 offset0:128 offset1:160    // 000000A03370: D8DCA080 47000043
	.long 0xd72c0049                                           // 000000A03378: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0337C: 020292FF 83DCD12D
	.long 0xd72c004c                                           // 000000A03384: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A03388: 020298FF 83DCD12D
	v_sad_u8 v80, v75, 0, 0x6400                               // 000000A03390: D6220050 03FD014B 00006400
	.long 0xd72c0053                                           // 000000A0339C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A033A0: 020294FF 83DCD12D
	ds_load_2addr_b32 v[74:75], v66 offset0:128 offset1:160    // 000000A033A8: D8DCA080 4A000042
	v_bfe_u32 v81, v77, 12, 16                                 // 000000A033B0: D6100051 0241194D
	v_bfe_u32 v82, v77, 8, 16                                  // 000000A033B8: D6100052 0241114D
	v_and_b32_e32 v80, 0xffff, v80                             // 000000A033C0: 36A0A0FF 0000FFFF
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A033C8: D6220049 03FD0149 00006400
	v_bfe_u32 v84, v77, 4, 16                                  // 000000A033D4: D6100054 0241094D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A033DC: 369A9AFF 0000FFFF
	.long 0xd72c0051                                           // 000000A033E4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A033E8: 0202A2FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A033F0: D622004C 03FD014C 00006400
	v_lshl_or_b32 v73, v73, 16, v80                            // 000000A033FC: D6560049 05412149
	.long 0xd72c0052                                           // 000000A03404: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A03408: 0202A4FF 83DCD12D
	.long 0xd72c004d                                           // 000000A03410: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A03414: 02029AFF 83DCD12D
	v_sad_u8 v80, v83, 0, 0x6400                               // 000000A0341C: D6220050 03FD0153 00006400
	v_dot2acc_f32_f16 v56, v79, v35                            // 000000A03428: 0470474F
	v_pk_fma_f16 v83, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0342C: CC0E0053 0BFC0B49 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A03438: BF89FC17
	v_dual_mov_b32 v73, v71 :: v_dual_lshlrev_b32 v76, 16, v76 // 000000A0343C: CA220147 494C9890
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A03444: D6220051 03FD0151 00006400
	.long 0xd72c0047                                           // 000000A03450: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A03454: 0202A8FF 83DCD12D
	v_sad_u8 v84, v77, 0, 0x6400                               // 000000A0345C: D6220054 03FD014D 00006400
	v_dot2acc_f32_f16 v55, v83, v33                            // 000000A03468: 046E4353
	v_and_or_b32 v80, 0xffff, v80, v76                         // 000000A0346C: D6570050 0532A0FF 0000FFFF
	ds_load_2addr_b32 v[76:77], v64 offset0:128 offset1:160    // 000000A03478: D8DCA080 4C000040
	s_waitcnt lgkmcnt(1)                                       // 000000A03480: BF89FC17
	.long 0xd73d0049                                           // 000000A03484: D73D0049
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A03488: 0202933E
	v_and_b32_e32 v81, 0xffff, v81                             // 000000A0348C: 36A2A2FF 0000FFFF
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A03494: D6220052 03FD0152 00006400
	v_pk_fma_f16 v74, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A034A0: CC0E004A 0BFC0B50 0000C931
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A034AC: D6220047 03FD0147 00006400
	v_dot2acc_f32_f16 v56, v78, v36                            // 000000A034B8: 0470494E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A034BC: BF870244
	v_lshl_or_b32 v80, v82, 16, v81                            // 000000A034C0: D6560050 05452152
	v_lshlrev_b32_e32 v81, 16, v84                             // 000000A034C8: 30A2A890
	v_bfe_u32 v82, v73, 12, 16                                 // 000000A034CC: D6100052 02411949
	v_dot2acc_f32_f16 v55, v74, v34                            // 000000A034D4: 046E454A
	v_pk_fma_f16 v79, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A034D8: CC0E004F 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A034E4: BF870214
	v_and_or_b32 v71, 0xffff, v71, v81                         // 000000A034E8: D6570047 05468EFF 0000FFFF
	.long 0xd72c004a                                           // 000000A034F4: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A034F8: 0202A4FF 83DCD12D
	v_bfe_u32 v80, v73, 8, 16                                  // 000000A03500: D6100050 02411149
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A03508: BF870003
	v_pk_fma_f16 v78, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0350C: CC0E004E 0BFC0B47 0000C931
	v_bfe_u32 v71, v73, 4, 16                                  // 000000A03518: D6100047 02410949
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A03520: 369292FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A03528: BF89FC07
	v_and_b32_e32 v82, 0xffff, v76                             // 000000A0352C: 36A498FF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A03534: D622004A 03FD014A 00006400
	v_dot2acc_f32_f16 v55, v79, v35                            // 000000A03540: 046E474F
	.long 0xd72c004f                                           // 000000A03544: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A03548: 0202A0FF 83DCD12D
	v_bfe_u32 v80, v76, 12, 16                                 // 000000A03550: D6100050 0241194C
	.long 0xd72c0049                                           // 000000A03558: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0355C: 020292FF 83DCD12D
	.long 0xd72c0047                                           // 000000A03564: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A03568: 02028EFF 83DCD12D
	.long 0xd72c0052                                           // 000000A03570: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A03574: 0202A4FF 83DCD12D
	v_bfe_u32 v81, v76, 8, 16                                  // 000000A0357C: D6100051 0241114C
	.long 0xd72c0050                                           // 000000A03584: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A03588: 0202A0FF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v74                             // 000000A03590: 369494FF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A03598: D622004F 03FD014F 00006400
	v_bfe_u32 v76, v76, 4, 16                                  // 000000A035A4: D610004C 0241094C
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A035AC: D6220049 03FD0149 00006400
	v_dot2acc_f32_f16 v55, v78, v36                            // 000000A035B8: 046E494E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A035BC: BF870004
	v_lshl_or_b32 v74, v79, 16, v74                            // 000000A035C0: D656004A 0529214F
	.long 0xd72c004f                                           // 000000A035C8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A035CC: 0202A2FF 83DCD12D
	.long 0xd72c004c                                           // 000000A035D4: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A035D8: 020298FF 83DCD12D
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A035E0: D6220050 03FD0150 00006400
	v_sad_u8 v81, v71, 0, 0x6400                               // 000000A035EC: D6220051 03FD0147 00006400
	v_lshlrev_b32_e32 v83, 16, v73                             // 000000A035F8: 30A69290
	v_sad_u8 v71, v82, 0, 0x6400                               // 000000A035FC: D6220047 03FD0152 00006400
	v_mov_b32_e32 v73, v75                                     // 000000A03608: 7E92034B
	v_and_b32_e32 v75, 0xffff, v80                             // 000000A0360C: 3696A0FF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A03614: D622004F 03FD014F 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A03620: D622004C 03FD014C 00006400
	v_lshlrev_b32_e32 v80, 16, v71                             // 000000A0362C: 30A08E90
	.long 0xd73d0047                                           // 000000A03630: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A03634: 0202913E
	v_pk_fma_f16 v73, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03638: CC0E0049 0BFC0B4A 0000C931
	v_lshl_or_b32 v74, v79, 16, v75                            // 000000A03644: D656004A 052D214F
	v_and_or_b32 v72, 0xffff, v81, v83                         // 000000A0364C: D6570048 054EA2FF 0000FFFF
	v_and_or_b32 v75, 0xffff, v76, v80                         // 000000A03658: D657004B 054298FF 0000FFFF
	v_bfe_u32 v80, v77, 8, 16                                  // 000000A03664: D6100050 0241114D
	v_bfe_u32 v76, v71, 12, 16                                 // 000000A0366C: D610004C 02411947
	v_dot2acc_f32_f16 v54, v73, v33                            // 000000A03674: 046C4349
	v_pk_fma_f16 v78, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03678: CC0E004E 0BFC0B4A 0000C931
	v_bfe_u32 v74, v71, 8, 16                                  // 000000A03684: D610004A 02411147
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0368C: CC0E0048 0BFC0B48 0000C931
	.long 0xd72c0049                                           // 000000A03698: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0369C: 020298FF 83DCD12D
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A036A4: CC0E004F 0BFC0B4B 0000C931
	v_bfe_u32 v75, v71, 4, 16                                  // 000000A036B0: D610004B 02410947
	v_and_b32_e32 v71, 0xffff, v71                             // 000000A036B8: 368E8EFF 0000FFFF
	.long 0xd72c004a                                           // 000000A036C0: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A036C4: 020294FF 83DCD12D
	v_dot2acc_f32_f16 v54, v72, v34                            // 000000A036CC: 046C4548
	v_bfe_u32 v76, v77, 12, 16                                 // 000000A036D0: D610004C 0241194D
	v_bfe_u32 v81, v77, 4, 16                                  // 000000A036D8: D6100051 0241094D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A036E0: D6220049 03FD0149 00006400
	.long 0xd72c0052                                           // 000000A036EC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A036F0: 02028EFF 83DCD12D
	ds_load_2addr_b32 v[71:72], v67 offset0:192 offset1:224    // 000000A036F8: D8DCE0C0 47000043
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A03700: 369A9AFF 0000FFFF
	v_sad_u8 v83, v74, 0, 0x6400                               // 000000A03708: D6220053 03FD014A 00006400
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A03714: 369292FF 0000FFFF
	.long 0xd72c0054                                           // 000000A0371C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A03720: 020296FF 83DCD12D
	ds_load_2addr_b32 v[74:75], v66 offset0:192 offset1:224    // 000000A03728: D8DCE0C0 4A000042
	.long 0xd72c004d                                           // 000000A03730: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A03734: 02029AFF 83DCD12D
	.long 0xd72c004c                                           // 000000A0373C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A03740: 020298FF 83DCD12D
	v_lshl_or_b32 v83, v83, 16, v73                            // 000000A03748: D6560053 05252153
	v_sad_u8 v73, v82, 0, 0x6400                               // 000000A03750: D6220049 03FD0152 00006400
	.long 0xd72c0050                                           // 000000A0375C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A03760: 0202A0FF 83DCD12D
	.long 0xd72c0051                                           // 000000A03768: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0376C: 0202A2FF 83DCD12D
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A03774: D6220054 03FD0154 00006400
	v_pk_fma_f16 v83, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03780: CC0E0053 0BFC0B53 0000C931
	v_lshlrev_b32_e32 v85, 16, v73                             // 000000A0378C: 30AA9290
	v_sad_u8 v73, v77, 0, 0x6400                               // 000000A03790: D6220049 03FD014D 00006400
	v_sad_u8 v82, v76, 0, 0x6400                               // 000000A0379C: D6220052 03FD014C 00006400
	ds_load_2addr_b32 v[76:77], v64 offset0:192 offset1:224    // 000000A037A8: D8DCE0C0 4C000040
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A037B0: D6220050 03FD0150 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A037BC: D6220051 03FD0151 00006400
	s_waitcnt lgkmcnt(2)                                       // 000000A037C8: BF89FC27
	v_dual_mov_b32 v73, v71 :: v_dual_lshlrev_b32 v86, 16, v73 // 000000A037CC: CA220147 49569290
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A037D4: 36A4A4FF 0000FFFF
	v_and_or_b32 v71, 0xffff, v84, v85                         // 000000A037DC: D6570047 0556A8FF 0000FFFF
	v_dot2acc_f32_f16 v53, v83, v33                            // 000000A037E8: 046A4353
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A037EC: BF870004
	v_and_or_b32 v81, 0xffff, v81, v86                         // 000000A037F0: D6570051 055AA2FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 000000A037FC: BF89FC17
	.long 0xd73d0049                                           // 000000A03800: D73D0049
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A03804: 0202933E
	v_lshl_or_b32 v80, v80, 16, v82                            // 000000A03808: D6560050 05492150
	v_pk_fma_f16 v71, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03810: CC0E0047 0BFC0B47 0000C931
	v_dot2acc_f32_f16 v54, v78, v35                            // 000000A0381C: 046C474E
	v_pk_fma_f16 v78, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03820: CC0E004E 0BFC0B51 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0382C: BF870224
	v_pk_fma_f16 v74, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03830: CC0E004A 0BFC0B50 0000C931
	v_bfe_u32 v80, v73, 12, 16                                 // 000000A0383C: D6100050 02411949
	v_dual_dot2acc_f32_f16 v54, v79, v36 :: v_dual_and_b32 v81, 0xffff, v73// 000000A03844: CB24494F 365092FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A03850: BF89FC07
	v_bfe_u32 v82, v76, 12, 16                                 // 000000A03854: D6100052 0241194C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A0385C: BF870003
	.long 0xd72c0050                                           // 000000A03860: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A03864: 0202A0FF 83DCD12D
	v_bfe_u32 v83, v76, 8, 16                                  // 000000A0386C: D6100053 0241114C
	.long 0xd72c0051                                           // 000000A03874: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A03878: 0202A2FF 83DCD12D
	v_bfe_u32 v84, v76, 4, 16                                  // 000000A03880: D6100054 0241094C
	.long 0xd72c0052                                           // 000000A03888: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0388C: 0202A4FF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A03894: 369898FF 0000FFFF
	.long 0xd72c0053                                           // 000000A0389C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A038A0: 0202A6FF 83DCD12D
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A038A8: D6220050 03FD0150 00006400
	v_dot2acc_f32_f16 v53, v71, v34                            // 000000A038B4: 046A4547
	v_bfe_u32 v71, v73, 8, 16                                  // 000000A038B8: D6100047 02411149
	v_bfe_u32 v73, v73, 4, 16                                  // 000000A038C0: D6100049 02410949
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A038C8: D6220051 03FD0151 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A038D4: D6220052 03FD0152 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A038E0: D6220053 03FD0153 00006400
	.long 0xd72c0047                                           // 000000A038EC: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A038F0: 02028EFF 83DCD12D
	.long 0xd72c0049                                           // 000000A038F8: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A038FC: 020292FF 83DCD12D
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000A03904: 30A2A290
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A03908: 36A4A4FF 0000FFFF
	v_and_b32_e32 v80, 0xffff, v80                             // 000000A03910: 36A0A0FF 0000FFFF
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A03918: D6220047 03FD0147 00006400
	v_sad_u8 v85, v73, 0, 0x6400                               // 000000A03924: D6220055 03FD0149 00006400
	v_mov_b32_e32 v73, v75                                     // 000000A03930: 7E92034B
	.long 0xd72c004b                                           // 000000A03934: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A03938: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A03940: BF870214
	v_lshl_or_b32 v80, v71, 16, v80                            // 000000A03944: D6560050 05412147
	v_and_or_b32 v76, 0xffff, v85, v81                         // 000000A0394C: D657004C 0546AAFF 0000FFFF
	v_lshl_or_b32 v81, v83, 16, v82                            // 000000A03958: D6560051 05492153
	.long 0xd72c0052                                           // 000000A03960: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A03964: 0202A8FF 83DCD12D
	.long 0xd73d0047                                           // 000000A0396C: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A03970: 0202913E
	v_pk_fma_f16 v73, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03974: CC0E0049 0BFC0B50 0000C931
	v_sad_u8 v72, v75, 0, 0x6400                               // 000000A03980: D6220048 03FD014B 00006400
	v_dot2acc_f32_f16 v53, v74, v35                            // 000000A0398C: 046A474A
	v_pk_fma_f16 v80, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03990: CC0E0050 0BFC0B4C 0000C931
	v_bfe_u32 v84, v77, 8, 16                                  // 000000A0399C: D6100054 0241114D
	v_bfe_u32 v74, v71, 12, 16                                 // 000000A039A4: D610004A 02411947
	v_sad_u8 v75, v82, 0, 0x6400                               // 000000A039AC: D622004B 03FD0152 00006400
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000A039B8: 30909090
	v_and_b32_e32 v76, 0xffff, v71                             // 000000A039BC: 36988EFF 0000FFFF
	v_bfe_u32 v82, v71, 8, 16                                  // 000000A039C4: D6100052 02411147
	v_bfe_u32 v71, v71, 4, 16                                  // 000000A039CC: D6100047 02410947
	.long 0xd72c004a                                           // 000000A039D4: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A039D8: 020294FF 83DCD12D
	v_and_or_b32 v83, 0xffff, v75, v72                         // 000000A039E0: D6570053 052296FF 0000FFFF
	v_bfe_u32 v72, v77, 12, 16                                 // 000000A039EC: D6100048 0241194D
	.long 0xd72c004b                                           // 000000A039F4: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A039F8: 0202A4FF 83DCD12D
	.long 0xd72c0052                                           // 000000A03A00: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A03A04: 02028EFF 83DCD12D
	v_dot2acc_f32_f16 v52, v73, v33                            // 000000A03A0C: 04684349
	v_and_b32_e32 v85, 0xffff, v77                             // 000000A03A10: 36AA9AFF 0000FFFF
	.long 0xd72c0056                                           // 000000A03A18: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A03A1C: 020290FF 83DCD12D
	ds_load_2addr_b32 v[71:72], v69 offset1:32                 // 000000A03A24: D8DC2000 47000045
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A03A2C: D622004A 03FD014A 00006400
	v_bfe_u32 v77, v77, 4, 16                                  // 000000A03A38: D610004D 0241094D
	v_sad_u8 v88, v75, 0, 0x6400                               // 000000A03A40: D6220058 03FD014B 00006400
	.long 0xd72c0054                                           // 000000A03A4C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A03A50: 0202A8FF 83DCD12D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A03A58: D6220052 03FD0152 00006400
	v_and_b32_e32 v87, 0xffff, v74                             // 000000A03A64: 36AE94FF 0000FFFF
	ds_load_2addr_b32 v[74:75], v68 offset1:32                 // 000000A03A6C: D8DC2000 4A000044
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000A03A74: D6220056 03FD0156 00006400
	.long 0xd72c0055                                           // 000000A03A80: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A03A84: 0202AAFF 83DCD12D
	.long 0xd72c004d                                           // 000000A03A8C: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A03A90: 02029AFF 83DCD12D
	v_lshl_or_b32 v87, v88, 16, v87                            // 000000A03A98: D6560057 055D2158
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A03AA0: D6220054 03FD0154 00006400
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03AAC: CC0E0051 0BFC0B51 0000C931
	v_dot2acc_f32_f16 v52, v80, v34                            // 000000A03AB8: 04684550
	v_pk_fma_f16 v80, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03ABC: CC0E0050 0BFC0B53 0000C931
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A03AC8: D6220055 03FD0155 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A03AD4: BF89FC17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A03AD8: BF8701B3
	v_dual_dot2acc_f32_f16 v52, v81, v35 :: v_dual_mov_b32 v73, v71// 000000A03ADC: CB104751 34480147
	.long 0xd72c004c                                           // 000000A03AE4: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A03AE8: 020298FF 83DCD12D
	v_sad_u8 v71, v77, 0, 0x6400                               // 000000A03AF0: D6220047 03FD014D 00006400
	v_dot2acc_f32_f16 v52, v80, v36                            // 000000A03AFC: 04684950
	s_waitcnt lgkmcnt(0)                                       // 000000A03B00: BF89FC07
	.long 0xd73d0049                                           // 000000A03B04: D73D0049
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A03B08: 0202933E
	v_dot2acc_f32_f16 v53, v78, v36                            // 000000A03B0C: 046A494E
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A03B10: D622004C 03FD014C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A03B1C: BF870113
	v_and_b32_e32 v78, 0xffff, v73                             // 000000A03B20: 369C92FF 0000FFFF
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000A03B28: 30989890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A03B2C: BF870112
	.long 0xd72c004e                                           // 000000A03B30: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A03B34: 02029CFF 83DCD12D
	v_and_or_b32 v76, 0xffff, v82, v76                         // 000000A03B3C: D657004C 0532A4FF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v86                             // 000000A03B48: 36A4ACFF 0000FFFF
	v_pk_fma_f16 v86, v87, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03B50: CC0E0056 0BFC0B57 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000A03B5C: BF8701D3
	v_pk_fma_f16 v87, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03B60: CC0E0057 0BFC0B4C 0000C931
	ds_load_2addr_b32 v[76:77], v65 offset1:32                 // 000000A03B6C: D8DC2000 4C000041
	v_lshl_or_b32 v82, v84, 16, v82                            // 000000A03B74: D6560052 05492154
	v_dot2acc_f32_f16 v51, v86, v33                            // 000000A03B7C: 04664356
	v_lshlrev_b32_e32 v84, 16, v85                             // 000000A03B80: 30A8AA90
	v_pk_fma_f16 v74, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03B84: CC0E004A 0BFC0B52 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A03B90: BF870223
	v_dot2acc_f32_f16 v51, v87, v34                            // 000000A03B94: 04664557
	v_bfe_u32 v82, v73, 12, 16                                 // 000000A03B98: D6100052 02411949
	v_and_or_b32 v71, 0xffff, v71, v84                         // 000000A03BA0: D6570047 05528EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A03BAC: BF870193
	v_dot2acc_f32_f16 v51, v74, v35                            // 000000A03BB0: 0466474A
	.long 0xd72c004a                                           // 000000A03BB4: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A03BB8: 0202A4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A03BC0: BF8701B3
	v_pk_fma_f16 v71, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03BC4: CC0E0047 0BFC0B47 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000A03BD0: BF89FC07
	v_bfe_u32 v79, v76, 12, 16                                 // 000000A03BD4: D610004F 0241194C
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A03BDC: D622004A 03FD014A 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A03BE8: BF870003
	v_dot2acc_f32_f16 v51, v71, v36                            // 000000A03BEC: 04664947
	v_bfe_u32 v71, v73, 8, 16                                  // 000000A03BF0: D6100047 02411149
	v_bfe_u32 v73, v73, 4, 16                                  // 000000A03BF8: D6100049 02410949
	.long 0xd72c004f                                           // 000000A03C00: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A03C04: 02029EFF 83DCD12D
	v_bfe_u32 v80, v76, 8, 16                                  // 000000A03C0C: D6100050 0241114C
	v_bfe_u32 v81, v76, 4, 16                                  // 000000A03C14: D6100051 0241094C
	.long 0xd72c0047                                           // 000000A03C1C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A03C20: 02028EFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A03C28: 369898FF 0000FFFF
	.long 0xd72c0052                                           // 000000A03C30: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A03C34: 020292FF 83DCD12D
	v_mov_b32_e32 v73, v75                                     // 000000A03C3C: 7E92034B
	.long 0xd72c0051                                           // 000000A03C40: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A03C44: 0202A2FF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v74                             // 000000A03C4C: 369494FF 0000FFFF
	.long 0xd72c004b                                           // 000000A03C54: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A03C58: 020298FF 83DCD12D
	v_bfe_u32 v85, v77, 4, 16                                  // 000000A03C60: D6100055 0241094D
	v_sad_u8 v83, v71, 0, 0x6400                               // 000000A03C68: D6220053 03FD0147 00006400
	v_sad_u8 v71, v78, 0, 0x6400                               // 000000A03C74: D6220047 03FD014E 00006400
	v_sad_u8 v78, v79, 0, 0x6400                               // 000000A03C80: D622004E 03FD014F 00006400
	.long 0xd72c004f                                           // 000000A03C8C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A03C90: 0202A0FF 83DCD12D
	v_sad_u8 v76, v82, 0, 0x6400                               // 000000A03C98: D622004C 03FD0152 00006400
	v_lshl_or_b32 v74, v83, 16, v74                            // 000000A03CA4: D656004A 05292153
	v_lshlrev_b32_e32 v80, 16, v71                             // 000000A03CAC: 30A08E90
	.long 0xd73d0047                                           // 000000A03CB0: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A03CB4: 0202913E
	v_and_b32_e32 v72, 0xffff, v78                             // 000000A03CB8: 36909CFF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A03CC0: D622004B 03FD014B 00006400
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03CCC: CC0E004A 0BFC0B4A 0000C931
	v_sad_u8 v73, v79, 0, 0x6400                               // 000000A03CD8: D6220049 03FD014F 00006400
	v_and_or_b32 v76, 0xffff, v76, v80                         // 000000A03CE4: D657004C 054298FF 0000FFFF
	v_bfe_u32 v78, v71, 12, 16                                 // 000000A03CF0: D610004E 02411947
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A03CF8: BF870214
	v_dual_dot2acc_f32_f16 v50, v74, v33 :: v_dual_lshlrev_b32 v75, 16, v75// 000000A03CFC: CB22434A 324A9690
	v_lshl_or_b32 v72, v73, 16, v72                            // 000000A03D04: D6560048 05212149
	v_sad_u8 v73, v81, 0, 0x6400                               // 000000A03D0C: D6220049 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A03D18: BF870004
	.long 0xd72c004e                                           // 000000A03D1C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A03D20: 02029CFF 83DCD12D
	v_pk_fma_f16 v79, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03D28: CC0E004F 0BFC0B4C 0000C931
	v_bfe_u32 v74, v71, 4, 16                                  // 000000A03D34: D610004A 02410947
	v_pk_fma_f16 v80, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03D3C: CC0E0050 0BFC0B48 0000C931
	v_bfe_u32 v72, v71, 8, 16                                  // 000000A03D48: D6100048 02411147
	v_and_or_b32 v81, 0xffff, v73, v75                         // 000000A03D50: D6570051 052E92FF 0000FFFF
	v_and_b32_e32 v73, 0xffff, v71                             // 000000A03D5C: 36928EFF 0000FFFF
	.long 0xd72c0054                                           // 000000A03D64: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A03D68: 020294FF 83DCD12D
	v_sad_u8 v75, v78, 0, 0x6400                               // 000000A03D70: D622004B 03FD014E 00006400
	.long 0xd72c004c                                           // 000000A03D7C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A03D80: 020290FF 83DCD12D
	ds_load_2addr_b32 v[71:72], v69 offset0:64 offset1:96      // 000000A03D88: D8DC6040 47000045
	.long 0xd72c0049                                           // 000000A03D90: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A03D94: 020292FF 83DCD12D
	v_bfe_u32 v78, v77, 12, 16                                 // 000000A03D9C: D610004E 0241194D
	v_and_b32_e32 v83, 0xffff, v75                             // 000000A03DA4: 36A696FF 0000FFFF
	ds_load_2addr_b32 v[74:75], v68 offset0:64 offset1:96      // 000000A03DAC: D8DC6040 4A000044
	v_bfe_u32 v82, v77, 8, 16                                  // 000000A03DB4: D6100052 0241114D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A03DBC: 369A9AFF 0000FFFF
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A03DC4: D622004C 03FD014C 00006400
	.long 0xd72c004e                                           // 000000A03DD0: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A03DD4: 02029CFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A03DDC: D6220049 03FD0149 00006400
	.long 0xd72c0052                                           // 000000A03DE8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A03DEC: 0202A4FF 83DCD12D
	.long 0xd72c004d                                           // 000000A03DF4: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A03DF8: 02029AFF 83DCD12D
	v_lshl_or_b32 v76, v76, 16, v83                            // 000000A03E00: D656004C 054D214C
	v_sad_u8 v83, v84, 0, 0x6400                               // 000000A03E08: D6220053 03FD0154 00006400
	v_dual_dot2acc_f32_f16 v50, v79, v34 :: v_dual_lshlrev_b32 v73, 16, v73// 000000A03E14: CB22454F 32489290
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A03E1C: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A03E28: BF870224
	v_pk_fma_f16 v84, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03E2C: CC0E0054 0BFC0B4C 0000C931
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03E38: CC0E0051 0BFC0B51 0000C931
	v_and_or_b32 v76, 0xffff, v83, v73                         // 000000A03E44: D657004C 0526A6FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 000000A03E50: BF89FC17
	v_mov_b32_e32 v73, v71                                     // 000000A03E54: 7E920347
	.long 0xd72c0053                                           // 000000A03E58: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A03E5C: 0202AAFF 83DCD12D
	v_and_b32_e32 v71, 0xffff, v78                             // 000000A03E64: 368E9CFF 0000FFFF
	v_sad_u8 v78, v82, 0, 0x6400                               // 000000A03E6C: D622004E 03FD0152 00006400
	v_sad_u8 v85, v77, 0, 0x6400                               // 000000A03E78: D6220055 03FD014D 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000A03E84: BF89FC07
	.long 0xd73d0049                                           // 000000A03E88: D73D0049
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A03E8C: 0202933E
	v_pk_fma_f16 v82, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03E90: CC0E0052 0BFC0B4C 0000C931
	ds_load_2addr_b32 v[76:77], v65 offset0:64 offset1:96      // 000000A03E9C: D8DC6040 4C000041
	v_lshl_or_b32 v71, v78, 16, v71                            // 000000A03EA4: D6560047 051D214E
	v_sad_u8 v74, v83, 0, 0x6400                               // 000000A03EAC: D622004A 03FD0153 00006400
	v_dot2acc_f32_f16 v49, v84, v33                            // 000000A03EB8: 04624354
	v_lshlrev_b32_e32 v78, 16, v85                             // 000000A03EBC: 309CAA90
	v_bfe_u32 v83, v73, 12, 16                                 // 000000A03EC0: D6100053 02411949
	v_pk_fma_f16 v71, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03EC8: CC0E0047 0BFC0B47 0000C931
	v_bfe_u32 v79, v73, 8, 16                                  // 000000A03ED4: D610004F 02411149
	v_dot2acc_f32_f16 v49, v82, v34                            // 000000A03EDC: 04624552
	v_and_or_b32 v74, 0xffff, v74, v78                         // 000000A03EE0: D657004A 053A94FF 0000FFFF
	.long 0xd72c004e                                           // 000000A03EEC: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A03EF0: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v50, v80, v35                            // 000000A03EF8: 04644750
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A03EFC: BF870113
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A03F00: CC0E004A 0BFC0B4A 0000C931
	v_dot2acc_f32_f16 v50, v81, v36                            // 000000A03F0C: 04644951
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A03F10: BF870004
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A03F14: D622004E 03FD014E 00006400
	v_dot2acc_f32_f16 v49, v71, v35                            // 000000A03F20: 04624747
	.long 0xd72c0047                                           // 000000A03F24: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A03F28: 02029EFF 83DCD12D
	v_and_b32_e32 v79, 0xffff, v73                             // 000000A03F30: 369E92FF 0000FFFF
	v_bfe_u32 v73, v73, 4, 16                                  // 000000A03F38: D6100049 02410949
	s_waitcnt lgkmcnt(0)                                       // 000000A03F40: BF89FC07
	v_bfe_u32 v80, v76, 12, 16                                 // 000000A03F44: D6100050 0241194C
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A03F4C: 369C9CFF 0000FFFF
	v_bfe_u32 v82, v76, 8, 16                                  // 000000A03F54: D6100052 0241114C
	.long 0xd72c004f                                           // 000000A03F5C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A03F60: 02029EFF 83DCD12D
	.long 0xd72c0049                                           // 000000A03F68: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A03F6C: 020292FF 83DCD12D
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A03F74: D6220047 03FD0147 00006400
	.long 0xd72c0050                                           // 000000A03F80: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A03F84: 0202A0FF 83DCD12D
	v_and_b32_e32 v83, 0xffff, v76                             // 000000A03F8C: 36A698FF 0000FFFF
	v_bfe_u32 v76, v76, 4, 16                                  // 000000A03F94: D610004C 0241094C
	v_dot2acc_f32_f16 v49, v74, v36                            // 000000A03F9C: 0462494A
	v_lshl_or_b32 v78, v71, 16, v78                            // 000000A03FA0: D656004E 05392147
	v_sad_u8 v71, v79, 0, 0x6400                               // 000000A03FA8: D6220047 03FD014F 00006400
	.long 0xd72c004f                                           // 000000A03FB4: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A03FB8: 0202A4FF 83DCD12D
	.long 0xd72c0052                                           // 000000A03FC0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A03FC4: 0202A6FF 83DCD12D
	v_sad_u8 v83, v73, 0, 0x6400                               // 000000A03FCC: D6220053 03FD0149 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A03FD8: BF8701B4
	v_dual_mov_b32 v73, v75 :: v_dual_lshlrev_b32 v84, 16, v71 // 000000A03FDC: CA22014B 49548E90
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A03FE4: D6220050 03FD0150 00006400
	.long 0xd72c004b                                           // 000000A03FF0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A03FF4: 020298FF 83DCD12D
	.long 0xd73d0047                                           // 000000A03FFC: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A04000: 0202913E
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A04004: D622004F 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A04010: BF870004
	v_and_b32_e32 v76, 0xffff, v80                             // 000000A04014: 3698A0FF 0000FFFF
	v_sad_u8 v80, v82, 0, 0x6400                               // 000000A0401C: D6220050 03FD0152 00006400
	v_pk_fma_f16 v72, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04028: CC0E0048 0BFC0B4E 0000C931
	v_and_or_b32 v73, 0xffff, v83, v84                         // 000000A04034: D6570049 0552A6FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A04040: D622004B 03FD014B 00006400
	v_lshl_or_b32 v76, v79, 16, v76                            // 000000A0404C: D656004C 0531214F
	v_bfe_u32 v79, v71, 12, 16                                 // 000000A04054: D610004F 02411947
	v_lshlrev_b32_e32 v78, 16, v80                             // 000000A0405C: 309CA090
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04060: CC0E0049 0BFC0B49 0000C931
	v_dot2acc_f32_f16 v48, v72, v33                            // 000000A0406C: 04604348
	v_pk_fma_f16 v72, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04070: CC0E0048 0BFC0B4C 0000C931
	.long 0xd72c004c                                           // 000000A0407C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A04080: 02029EFF 83DCD12D
	v_and_or_b32 v75, 0xffff, v75, v78                         // 000000A04088: D657004B 053A96FF 0000FFFF
	v_bfe_u32 v78, v71, 8, 16                                  // 000000A04094: D610004E 02411147
	v_dot2acc_f32_f16 v48, v73, v34                            // 000000A0409C: 04604549
	v_bfe_u32 v83, v77, 8, 16                                  // 000000A040A0: D6100053 0241114D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A040A8: BF870214
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A040AC: CC0E004F 0BFC0B4B 0000C931
	.long 0xd72c0049                                           // 000000A040B8: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A040BC: 02029CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A040C4: BF870004
	v_dot2acc_f32_f16 v48, v72, v35                            // 000000A040C8: 04604748
	v_sad_u8 v74, v76, 0, 0x6400                               // 000000A040CC: D622004A 03FD014C 00006400
	v_bfe_u32 v76, v71, 4, 16                                  // 000000A040D8: D610004C 02410947
	v_and_b32_e32 v75, 0xffff, v71                             // 000000A040E0: 36968EFF 0000FFFF
	ds_load_2addr_b32 v[71:72], v69 offset0:128 offset1:160    // 000000A040E8: D8DCA080 47000045
	v_bfe_u32 v78, v77, 12, 16                                 // 000000A040F0: D610004E 0241194D
	v_and_b32_e32 v80, 0xffff, v74                             // 000000A040F8: 36A094FF 0000FFFF
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A04100: D6220049 03FD0149 00006400
	.long 0xd72c0051                                           // 000000A0410C: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A04110: 020296FF 83DCD12D
	ds_load_2addr_b32 v[74:75], v68 offset0:128 offset1:160    // 000000A04118: D8DCA080 4A000044
	v_and_b32_e32 v82, 0xffff, v77                             // 000000A04120: 36A49AFF 0000FFFF
	.long 0xd72c004c                                           // 000000A04128: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0412C: 020298FF 83DCD12D
	v_lshl_or_b32 v80, v73, 16, v80                            // 000000A04134: D6560050 05412149
	v_dot2acc_f32_f16 v48, v79, v36                            // 000000A0413C: 0460494F
	.long 0xd72c004e                                           // 000000A04140: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A04144: 02029CFF 83DCD12D
	.long 0xd72c0049                                           // 000000A0414C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A04150: 0202A4FF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A04158: D6220051 03FD0151 00006400
	v_pk_fma_f16 v79, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04164: CC0E004F 0BFC0B50 0000C931
	.long 0xd72c0052                                           // 000000A04170: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A04174: 0202A6FF 83DCD12D
	v_sad_u8 v84, v76, 0, 0x6400                               // 000000A0417C: D6220054 03FD014C 00006400
	v_bfe_u32 v77, v77, 4, 16                                  // 000000A04188: D610004D 0241094D
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000A04190: 30A2A290
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A04194: D622004E 03FD014E 00006400
	v_sad_u8 v85, v73, 0, 0x6400                               // 000000A041A0: D6220055 03FD0149 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A041AC: BF89FC17
	v_mov_b32_e32 v73, v71                                     // 000000A041B0: 7E920347
	v_dot2acc_f32_f16 v47, v79, v33                            // 000000A041B4: 045E434F
	.long 0xd72c0053                                           // 000000A041B8: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A041BC: 02029AFF 83DCD12D
	ds_load_2addr_b32 v[76:77], v65 offset0:128 offset1:160    // 000000A041C4: D8DCA080 4C000041
	v_sad_u8 v71, v82, 0, 0x6400                               // 000000A041CC: D6220047 03FD0152 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A041D8: BF89FC17
	.long 0xd73d0049                                           // 000000A041DC: D73D0049
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A041E0: 0202933E
	v_and_or_b32 v74, 0xffff, v84, v81                         // 000000A041E4: D657004A 0546A8FF 0000FFFF
	v_sad_u8 v82, v83, 0, 0x6400                               // 000000A041F0: D6220052 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A041FC: BF870193
	v_bfe_u32 v80, v73, 12, 16                                 // 000000A04200: D6100050 02411949
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04208: CC0E004A 0BFC0B4A 0000C931
	v_lshlrev_b32_e32 v83, 16, v85                             // 000000A04214: 30A6AA90
	v_bfe_u32 v79, v73, 8, 16                                  // 000000A04218: D610004F 02411149
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A04220: BF870214
	.long 0xd72c0050                                           // 000000A04224: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A04228: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v47, v74, v34                            // 000000A04230: 045E454A
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A04234: 369C9CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0423C: BF870114
	.long 0xd72c004f                                           // 000000A04240: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A04244: 02029EFF 83DCD12D
	v_lshl_or_b32 v71, v71, 16, v78                            // 000000A0424C: D6560047 05392147
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A04254: D6220050 03FD0150 00006400
	v_and_or_b32 v78, 0xffff, v82, v83                         // 000000A04260: D657004E 054EA4FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A0426C: BF89FC07
	v_bfe_u32 v82, v76, 12, 16                                 // 000000A04270: D6100052 0241194C
	v_bfe_u32 v83, v76, 8, 16                                  // 000000A04278: D6100053 0241114C
	v_pk_fma_f16 v81, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04280: CC0E0051 0BFC0B47 0000C931
	v_and_b32_e32 v80, 0xffff, v80                             // 000000A0428C: 36A0A0FF 0000FFFF
	v_and_b32_e32 v71, 0xffff, v73                             // 000000A04294: 368E92FF 0000FFFF
	v_bfe_u32 v73, v73, 4, 16                                  // 000000A0429C: D6100049 02410949
	v_bfe_u32 v84, v76, 4, 16                                  // 000000A042A4: D6100054 0241094C
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A042AC: 369898FF 0000FFFF
	.long 0xd72c0052                                           // 000000A042B4: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A042B8: 0202A4FF 83DCD12D
	.long 0xd72c0047                                           // 000000A042C0: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A042C4: 02028EFF 83DCD12D
	.long 0xd72c0049                                           // 000000A042CC: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A042D0: 020292FF 83DCD12D
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A042D8: D622004F 03FD014F 00006400
	.long 0xd72c004c                                           // 000000A042E4: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A042E8: 020298FF 83DCD12D
	.long 0xd72c0053                                           // 000000A042F0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A042F4: 0202A6FF 83DCD12D
	.long 0xd72c0054                                           // 000000A042FC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A04300: 0202A8FF 83DCD12D
	v_dot2acc_f32_f16 v47, v81, v35                            // 000000A04308: 045E4751
	v_lshl_or_b32 v79, v79, 16, v80                            // 000000A0430C: D656004F 0541214F
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A04314: D6220047 03FD0147 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A04320: D6220049 03FD0149 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A0432C: D6220052 03FD0152 00006400
	v_bfe_u32 v81, v77, 4, 16                                  // 000000A04338: D6100051 0241094D
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04340: CC0E004E 0BFC0B4E 0000C931
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000A0434C: 308E8E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A04350: BF870193
	.long 0xd72c0051                                           // 000000A04354: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A04358: 0202A2FF 83DCD12D
	v_dot2acc_f32_f16 v47, v78, v36                            // 000000A04360: 045E494E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A04364: BF870003
	v_and_or_b32 v80, 0xffff, v73, v71                         // 000000A04368: D6570050 051E92FF 0000FFFF
	v_sad_u8 v71, v76, 0, 0x6400                               // 000000A04374: D6220047 03FD014C 00006400
	v_mov_b32_e32 v73, v75                                     // 000000A04380: 7E92034B
	v_sad_u8 v76, v83, 0, 0x6400                               // 000000A04384: D622004C 03FD0153 00006400
	v_and_b32_e32 v75, 0xffff, v82                             // 000000A04390: 3696A4FF 0000FFFF
	v_sad_u8 v82, v84, 0, 0x6400                               // 000000A04398: D6220052 03FD0154 00006400
	v_lshlrev_b32_e32 v83, 16, v71                             // 000000A043A4: 30A68E90
	.long 0xd73d0047                                           // 000000A043A8: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A043AC: 0202913E
	v_pk_fma_f16 v72, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A043B0: CC0E0048 0BFC0B4F 0000C931
	v_lshl_or_b32 v74, v76, 16, v75                            // 000000A043BC: D656004A 052D214C
	v_pk_fma_f16 v73, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A043C4: CC0E0049 0BFC0B50 0000C931
	v_and_or_b32 v75, 0xffff, v82, v83                         // 000000A043D0: D657004B 054EA4FF 0000FFFF
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A043DC: D6220051 03FD0151 00006400
	v_bfe_u32 v76, v71, 12, 16                                 // 000000A043E8: D610004C 02411947
	v_dot2acc_f32_f16 v46, v72, v33                            // 000000A043F0: 045C4348
	v_pk_fma_f16 v79, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A043F4: CC0E004F 0BFC0B4A 0000C931
	v_bfe_u32 v74, v71, 4, 16                                  // 000000A04400: D610004A 02410947
	v_pk_fma_f16 v80, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04408: CC0E0050 0BFC0B4B 0000C931
	.long 0xd72c0048                                           // 000000A04414: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A04418: 020298FF 83DCD12D
	v_dot2acc_f32_f16 v46, v73, v34                            // 000000A04420: 045C4549
	v_bfe_u32 v73, v71, 8, 16                                  // 000000A04424: D6100049 02411147
	v_and_b32_e32 v71, 0xffff, v71                             // 000000A0442C: 368E8EFF 0000FFFF
	v_bfe_u32 v75, v77, 12, 16                                 // 000000A04434: D610004B 0241194D
	v_bfe_u32 v76, v77, 8, 16                                  // 000000A0443C: D610004C 0241114D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A04444: 369A9AFF 0000FFFF
	.long 0xd72c0049                                           // 000000A0444C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A04450: 020292FF 83DCD12D
	v_sad_u8 v82, v72, 0, 0x6400                               // 000000A04458: D6220052 03FD0148 00006400
	.long 0xd72c0053                                           // 000000A04464: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A04468: 02028EFF 83DCD12D
	ds_load_2addr_b32 v[71:72], v69 offset0:192 offset1:224    // 000000A04470: D8DCE0C0 47000045
	.long 0xd72c0054                                           // 000000A04478: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A0447C: 020296FF 83DCD12D
	.long 0xd72c0055                                           // 000000A04484: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A04488: 020294FF 83DCD12D
	ds_load_2addr_b32 v[74:75], v68 offset0:192 offset1:224    // 000000A04490: D8DCE0C0 4A000044
	.long 0xd72c004d                                           // 000000A04498: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0449C: 02029AFF 83DCD12D
	v_sad_u8 v86, v73, 0, 0x6400                               // 000000A044A4: D6220056 03FD0149 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A044B0: 36A4A4FF 0000FFFF
	v_sad_u8 v73, v83, 0, 0x6400                               // 000000A044B8: D6220049 03FD0153 00006400
	.long 0xd72c0053                                           // 000000A044C4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A044C8: 020298FF 83DCD12D
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A044D0: D6220054 03FD0154 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A044DC: D6220055 03FD0155 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A044E8: BF870004
	v_dual_dot2acc_f32_f16 v46, v79, v35 :: v_dual_lshlrev_b32 v87, 16, v73// 000000A044EC: CB22474F 2E569290
	v_sad_u8 v73, v77, 0, 0x6400                               // 000000A044F4: D6220049 03FD014D 00006400
	ds_load_2addr_b32 v[76:77], v65 offset0:192 offset1:224    // 000000A04500: D8DCE0C0 4C000041
	v_and_b32_e32 v84, 0xffff, v84                             // 000000A04508: 36A8A8FF 0000FFFF
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A04510: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v46, v80, v36                            // 000000A0451C: 045C4950
	v_lshlrev_b32_e32 v88, 16, v73                             // 000000A04520: 30B09290
	s_waitcnt lgkmcnt(2)                                       // 000000A04524: BF89FC27
	v_mov_b32_e32 v73, v71                                     // 000000A04528: 7E920347
	v_lshl_or_b32 v71, v86, 16, v82                            // 000000A0452C: D6560047 05492156
	v_and_or_b32 v82, 0xffff, v85, v87                         // 000000A04534: D6570052 055EAAFF 0000FFFF
	v_lshl_or_b32 v83, v83, 16, v84                            // 000000A04540: D6560053 05512153
	s_waitcnt lgkmcnt(1)                                       // 000000A04548: BF89FC17
	.long 0xd73d0049                                           // 000000A0454C: D73D0049
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A04550: 0202933E
	v_pk_fma_f16 v71, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04554: CC0E0047 0BFC0B47 0000C931
	v_pk_fma_f16 v74, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04560: CC0E004A 0BFC0B52 0000C931
	v_pk_fma_f16 v79, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0456C: CC0E004F 0BFC0B53 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A04578: BF870214
	v_bfe_u32 v82, v73, 12, 16                                 // 000000A0457C: D6100052 02411949
	v_dot2acc_f32_f16 v45, v71, v33                            // 000000A04584: 045A4347
	v_and_b32_e32 v71, 0xffff, v73                             // 000000A04588: 368E92FF 0000FFFF
	v_bfe_u32 v83, v73, 8, 16                                  // 000000A04590: D6100053 02411149
	v_bfe_u32 v73, v73, 4, 16                                  // 000000A04598: D6100049 02410949
	.long 0xd72c0052                                           // 000000A045A0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A045A4: 0202A4FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A045AC: BF89FC07
	v_bfe_u32 v84, v76, 12, 16                                 // 000000A045B0: D6100054 0241194C
	.long 0xd72c0047                                           // 000000A045B8: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A045BC: 02028EFF 83DCD12D
	.long 0xd72c0053                                           // 000000A045C4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A045C8: 0202A6FF 83DCD12D
	.long 0xd72c0049                                           // 000000A045D0: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A045D4: 020292FF 83DCD12D
	v_bfe_u32 v85, v76, 8, 16                                  // 000000A045DC: D6100055 0241114C
	.long 0xd72c0054                                           // 000000A045E4: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A045E8: 0202A8FF 83DCD12D
	v_bfe_u32 v86, v76, 4, 16                                  // 000000A045F0: D6100056 0241094C
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A045F8: D6220052 03FD0152 00006400
	v_dot2acc_f32_f16 v45, v74, v34                            // 000000A04604: 045A454A
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A04608: D6220047 03FD0147 00006400
	.long 0xd72c0055                                           // 000000A04614: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A04618: 0202AAFF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A04620: D6220053 03FD0153 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A0462C: 36A4A4FF 0000FFFF
	v_sad_u8 v87, v73, 0, 0x6400                               // 000000A04634: D6220057 03FD0149 00006400
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000A04640: 308E8E90
	v_mov_b32_e32 v73, v75                                     // 000000A04644: 7E92034B
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A04648: D6220054 03FD0154 00006400
	v_lshl_or_b32 v82, v83, 16, v82                            // 000000A04654: D6560052 05492153
	v_dual_dot2acc_f32_f16 v45, v79, v35 :: v_dual_and_b32 v76, 0xffff, v76// 000000A0465C: CB24474F 2D4C98FF 0000FFFF
	v_and_or_b32 v83, 0xffff, v87, v71                         // 000000A04668: D6570053 051EAEFF 0000FFFF
	.long 0xd73d0047                                           // 000000A04674: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A04678: 0202913E
	v_and_b32_e32 v84, 0xffff, v84                             // 000000A0467C: 36A8A8FF 0000FFFF
	v_sad_u8 v75, v85, 0, 0x6400                               // 000000A04684: D622004B 03FD0155 00006400
	.long 0xd72c0049                                           // 000000A04690: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A04694: 020298FF 83DCD12D
	.long 0xd72c0055                                           // 000000A0469C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A046A0: 0202ACFF 83DCD12D
	v_pk_fma_f16 v74, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A046A8: CC0E004A 0BFC0B52 0000C931
	v_bfe_u32 v76, v71, 12, 16                                 // 000000A046B4: D610004C 02411947
	v_lshl_or_b32 v72, v75, 16, v84                            // 000000A046BC: D6560048 0551214B
	v_pk_fma_f16 v75, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A046C4: CC0E004B 0BFC0B53 0000C931
	v_and_b32_e32 v83, 0xffff, v71                             // 000000A046D0: 36A68EFF 0000FFFF
	v_bfe_u32 v84, v71, 8, 16                                  // 000000A046D8: D6100054 02411147
	.long 0xd72c004c                                           // 000000A046E0: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A046E4: 020298FF 83DCD12D
	v_bfe_u32 v71, v71, 4, 16                                  // 000000A046EC: D6100047 02410947
	v_sad_u8 v82, v85, 0, 0x6400                               // 000000A046F4: D6220052 03FD0155 00006400
	.long 0xd72c0053                                           // 000000A04700: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A04704: 0202A6FF 83DCD12D
	v_bfe_u32 v85, v77, 12, 16                                 // 000000A0470C: D6100055 0241194D
	.long 0xd72c0054                                           // 000000A04714: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A04718: 0202A8FF 83DCD12D
	.long 0xd72c0047                                           // 000000A04720: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A04724: 02028EFF 83DCD12D
	v_bfe_u32 v86, v77, 8, 16                                  // 000000A0472C: D6100056 0241114D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A04734: D622004C 03FD014C 00006400
	v_bfe_u32 v87, v77, 4, 16                                  // 000000A04740: D6100057 0241094D
	.long 0xd72c0055                                           // 000000A04748: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A0474C: 0202AAFF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A04754: D6220053 03FD0153 00006400
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A04760: 369A9AFF 0000FFFF
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A04768: 369898FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A04770: D6220054 03FD0154 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A0477C: D6220047 03FD0147 00006400
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000A04788: 30A6A690
	.long 0xd72c0056                                           // 000000A0478C: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A04790: 0202ACFF 83DCD12D
	.long 0xd72c004d                                           // 000000A04798: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0479C: 02029AFF 83DCD12D
	v_and_or_b32 v81, 0xffff, v81, v88                         // 000000A047A4: D6570051 0562A2FF 0000FFFF
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A047B0: D6220055 03FD0155 00006400
	v_lshl_or_b32 v76, v84, 16, v76                            // 000000A047BC: D656004C 05312154
	v_and_or_b32 v71, 0xffff, v71, v83                         // 000000A047C4: D6570047 054E8EFF 0000FFFF
	.long 0xd72c0053                                           // 000000A047D0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A047D4: 0202AEFF 83DCD12D
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A047DC: CC0E0051 0BFC0B51 0000C931
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A047E8: D6220049 03FD0149 00006400
	v_and_b32_e32 v84, 0xffff, v85                             // 000000A047F4: 36A8AAFF 0000FFFF
	v_sad_u8 v85, v86, 0, 0x6400                               // 000000A047FC: D6220055 03FD0156 00006400
	v_dot2acc_f32_f16 v44, v74, v33                            // 000000A04808: 0458434A
	v_sad_u8 v74, v77, 0, 0x6400                               // 000000A0480C: D622004A 03FD014D 00006400
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04818: CC0E004C 0BFC0B4C 0000C931
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000A04824: 30929290
	v_pk_fma_f16 v71, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04828: CC0E0047 0BFC0B47 0000C931
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A04834: D6220053 03FD0153 00006400
	v_lshlrev_b32_e32 v74, 16, v74                             // 000000A04840: 30949490
	v_dual_dot2acc_f32_f16 v58, v76, v33 :: v_dual_dot2acc_f32_f16 v45, v81, v36// 000000A04844: CB18434C 3A2C4951
	v_lshl_or_b32 v77, v85, 16, v84                            // 000000A0484C: D656004D 05512155
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04854: CC0E0048 0BFC0B48 0000C931
	v_and_or_b32 v33, 0xffff, v82, v73                         // 000000A04860: D6570021 0526A4FF 0000FFFF
	v_dot2acc_f32_f16 v44, v75, v34                            // 000000A0486C: 0458454B
	v_and_or_b32 v74, 0xffff, v83, v74                         // 000000A04870: D657004A 052AA6FF 0000FFFF
	v_pk_fma_f16 v73, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0487C: CC0E0049 0BFC0B4D 0000C931
	v_dot2acc_f32_f16 v58, v71, v34                            // 000000A04888: 04744547
	v_pk_fma_f16 v33, v33, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0488C: CC0E0021 0BFC0B21 0000C931
	v_dot2acc_f32_f16 v44, v72, v35                            // 000000A04898: 04584748
	v_pk_fma_f16 v34, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0489C: CC0E0022 0BFC0B4A 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A048A8: BF870194
	v_dot2acc_f32_f16 v58, v73, v35                            // 000000A048AC: 04744749
	v_dot2acc_f32_f16 v44, v33, v36                            // 000000A048B0: 04584921
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A048B4: BF870002
	v_dot2acc_f32_f16 v58, v34, v36                            // 000000A048B8: 04744922
	s_or_b32 exec_lo, exec_lo, s6                              // 000000A048BC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A048C0: BF870009
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000A048C4: 8B006A7E
	.long 0xd7006a26                                           // 000000A048C8: D7006A26
	v_cndmask_b32_e32 v1, 0x1000, v38, vcc_lo                  // 000000A048CC: 02024CFF 00001000
	v_add_nc_u32_e32 v63, 64, v63                              // 000000A048D4: 4A7E7EC0
	v_add_co_ci_u32_e64 v39, null, 0, v39, vcc_lo              // 000000A048D8: D5207C27 01AA4E80
	v_mov_b32_e32 v71, v70                                     // 000000A048E0: 7E8E0346
	s_or_b32 s4, s0, s4                                        // 000000A048E4: 8C040400
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A048E8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A048EC: 917E047E
	s_cbranch_execz 1831                                       // 000000A048F0: BFA50727 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x6290>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A048F4: BF870001
	v_add_nc_u32_e32 v70, 2, v71                               // 000000A048F8: 4A8C8E82
	s_mov_b32 s6, exec_lo                                      // 000000A048FC: BE86007E
	s_waitcnt vmcnt(14)                                        // 000000A04900: BF893BF7
	ds_store_2addr_b32 v64, v17, v18 offset1:32                // 000000A04904: D8382000 00121140
	s_waitcnt vmcnt(12)                                        // 000000A0490C: BF8933F7
	ds_store_2addr_b32 v64, v19, v20 offset0:64 offset1:96     // 000000A04910: D8386040 00141340
	s_waitcnt vmcnt(10)                                        // 000000A04918: BF892BF7
	ds_store_2addr_b32 v64, v21, v22 offset0:128 offset1:160   // 000000A0491C: D838A080 00161540
	s_waitcnt vmcnt(8)                                         // 000000A04924: BF8923F7
	ds_store_2addr_b32 v64, v23, v24 offset0:192 offset1:224   // 000000A04928: D838E0C0 00181740
	s_waitcnt vmcnt(6)                                         // 000000A04930: BF891BF7
	ds_store_2addr_b32 v65, v25, v26 offset1:32                // 000000A04934: D8382000 001A1941
	s_waitcnt vmcnt(4)                                         // 000000A0493C: BF8913F7
	ds_store_2addr_b32 v65, v27, v28 offset0:64 offset1:96     // 000000A04940: D8386040 001C1B41
	s_waitcnt vmcnt(2)                                         // 000000A04948: BF890BF7
	ds_store_2addr_b32 v65, v29, v30 offset0:128 offset1:160   // 000000A0494C: D838A080 001E1D41
	s_waitcnt vmcnt(0)                                         // 000000A04954: BF8903F7
	ds_store_2addr_b32 v65, v31, v32 offset0:192 offset1:224   // 000000A04958: D838E0C0 00201F41
	v_cmp_ge_u32_e32 vcc_lo, v70, v43                          // 000000A04960: 7C9C5746
	.long 0xd4c9007e                                           // 000000A04964: D4C9007E
	v_cndmask_b32_e32 v1, v70, v43, vcc_lo                     // 000000A04968: 02025746
	s_cbranch_execz 33                                         // 000000A0496C: BFA50021 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x46f4>
	s_clause 0xf                                               // 000000A04970: BF85000F
	global_load_b32 v17, v[38:39], off offset:-1024            // 000000A04974: DC521C00 117C0026
	global_load_b32 v18, v[38:39], off offset:-896             // 000000A0497C: DC521C80 127C0026
	global_load_b32 v19, v[38:39], off offset:-768             // 000000A04984: DC521D00 137C0026
	global_load_b32 v20, v[38:39], off offset:-640             // 000000A0498C: DC521D80 147C0026
	global_load_b32 v21, v[38:39], off offset:-512             // 000000A04994: DC521E00 157C0026
	global_load_b32 v22, v[38:39], off offset:-384             // 000000A0499C: DC521E80 167C0026
	global_load_b32 v23, v[38:39], off offset:-256             // 000000A049A4: DC521F00 177C0026
	global_load_b32 v24, v[38:39], off offset:-128             // 000000A049AC: DC521F80 187C0026
	global_load_b32 v25, v[38:39], off                         // 000000A049B4: DC520000 197C0026
	global_load_b32 v26, v[38:39], off offset:128              // 000000A049BC: DC520080 1A7C0026
	global_load_b32 v27, v[38:39], off offset:256              // 000000A049C4: DC520100 1B7C0026
	global_load_b32 v28, v[38:39], off offset:384              // 000000A049CC: DC520180 1C7C0026
	global_load_b32 v29, v[38:39], off offset:512              // 000000A049D4: DC520200 1D7C0026
	global_load_b32 v30, v[38:39], off offset:640              // 000000A049DC: DC520280 1E7C0026
	global_load_b32 v31, v[38:39], off offset:768              // 000000A049E4: DC520300 1F7C0026
	global_load_b32 v32, v[38:39], off offset:896              // 000000A049EC: DC520380 207C0026
	s_or_b32 exec_lo, exec_lo, s6                              // 000000A049F4: 8C7E067E
	ds_load_2addr_b32 v[72:73], v67 offset1:32                 // 000000A049F8: D8DC2000 48000043
	ds_load_2addr_b32 v[82:83], v64 offset1:32                 // 000000A04A00: D8DC2000 52000040
	ds_load_2addr_b32 v[76:77], v66 offset1:32                 // 000000A04A08: D8DC2000 4C000042
	ds_load_b128 v[33:36], v63                                 // 000000A04A10: DBFC0000 2100003F
	ds_load_2addr_b32 v[78:79], v66 offset0:64 offset1:96      // 000000A04A18: D8DC6040 4E000042
	ds_load_2addr_b32 v[80:81], v67 offset0:64 offset1:96      // 000000A04A20: D8DC6040 50000043
	s_mov_b32 s6, exec_lo                                      // 000000A04A28: BE86007E
	s_waitcnt lgkmcnt(5)                                       // 000000A04A2C: BF89FC57
	v_mov_b32_e32 v75, v72                                     // 000000A04A30: 7E960348
	s_waitcnt lgkmcnt(4)                                       // 000000A04A34: BF89FC47
	v_bfe_u32 v72, v82, 12, 16                                 // 000000A04A38: D6100048 02411952
	v_bfe_u32 v84, v82, 8, 16                                  // 000000A04A40: D6100054 02411152
	v_bfe_u32 v85, v82, 4, 16                                  // 000000A04A48: D6100055 02410952
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A04A50: 36A4A4FF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 000000A04A58: BF89FC37
	v_mov_b32_e32 v74, v77                                     // 000000A04A5C: 7E94034D
	.long 0xd73d004b                                           // 000000A04A60: D73D004B
	v_cndmask_b32_e32 v1, v62, v75, vcc_lo                     // 000000A04A64: 0202973E
	v_bfe_u32 v77, v83, 12, 16                                 // 000000A04A68: D610004D 02411953
	v_bfe_u32 v86, v83, 8, 16                                  // 000000A04A70: D6100056 02411153
	v_bfe_u32 v87, v83, 4, 16                                  // 000000A04A78: D6100057 02410953
	v_and_b32_e32 v83, 0xffff, v83                             // 000000A04A80: 36A6A6FF 0000FFFF
	.long 0xd72c004c                                           // 000000A04A88: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A04A8C: 020290FF 83DCD12D
	.long 0xd73d0048                                           // 000000A04A94: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A04A98: 0202933E
	.long 0xd72c0049                                           // 000000A04A9C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A04AA0: 02029AFF 83DCD12D
	v_bfe_u32 v77, v75, 12, 16                                 // 000000A04AA8: D610004D 0241194B
	.long 0xd72c004a                                           // 000000A04AB0: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A04AB4: 0202A6FF 83DCD12D
	v_bfe_u32 v83, v75, 8, 16                                  // 000000A04ABC: D6100053 0241114B
	v_bfe_u32 v88, v75, 4, 16                                  // 000000A04AC4: D6100058 0241094B
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A04ACC: 369696FF 0000FFFF
	.long 0xd72c004d                                           // 000000A04AD4: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A04AD8: 02029AFF 83DCD12D
	v_bfe_u32 v89, v72, 12, 16                                 // 000000A04AE0: D6100059 02411948
	.long 0xd72c0053                                           // 000000A04AE8: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A04AEC: 0202A6FF 83DCD12D
	.long 0xd72c0058                                           // 000000A04AF4: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000A04AF8: 0202B0FF 83DCD12D
	.long 0xd72c004b                                           // 000000A04B00: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A04B04: 020296FF 83DCD12D
	.long 0xd72c0052                                           // 000000A04B0C: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A04B10: 0202A4FF 83DCD12D
	v_bfe_u32 v90, v72, 8, 16                                  // 000000A04B18: D610005A 02411148
	.long 0xd72c0059                                           // 000000A04B20: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000A04B24: 0202B2FF 83DCD12D
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A04B2C: D622004D 03FD014D 00006400
	.long 0xd72c0054                                           // 000000A04B38: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A04B3C: 0202A8FF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A04B44: D6220053 03FD0153 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000A04B50: D6220058 03FD0158 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A04B5C: D622004B 03FD014B 00006400
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A04B68: 369A9AFF 0000FFFF
	v_bfe_u32 v91, v72, 4, 16                                  // 000000A04B70: D610005B 02410948
	.long 0xd72c0055                                           // 000000A04B78: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A04B7C: 0202AAFF 83DCD12D
	.long 0xd72c005a                                           // 000000A04B84: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000A04B88: 0202B4FF 83DCD12D
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000A04B90: 30969690
	v_lshl_or_b32 v77, v83, 16, v77                            // 000000A04B94: D656004D 05352153
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A04B9C: D622004C 03FD014C 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A04BA8: D6220052 03FD0152 00006400
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000A04BB4: D6220059 03FD0159 00006400
	v_and_or_b32 v75, 0xffff, v88, v75                         // 000000A04BC0: D657004B 052EB0FF 0000FFFF
	v_pk_fma_f16 v77, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04BCC: CC0E004D 0BFC0B4D 0000C931
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A04BD8: 369090FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A04BE0: D6220054 03FD0154 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A04BEC: D6220055 03FD0155 00006400
	v_pk_fma_f16 v75, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04BF8: CC0E004B 0BFC0B4B 0000C931
	s_waitcnt lgkmcnt(2)                                       // 000000A04C04: BF89FC27
	v_dot2acc_f32_f16 v59, v77, v33                            // 000000A04C08: 0476434D
	.long 0xd72c0048                                           // 000000A04C0C: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A04C10: 020290FF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A04C18: 369898FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A04C20: BF89FC07
	v_dual_mov_b32 v77, v80 :: v_dual_lshlrev_b32 v82, 16, v82 // 000000A04C24: CA220150 4D52A490
	v_sad_u8 v83, v90, 0, 0x6400                               // 000000A04C2C: D6220053 03FD015A 00006400
	v_and_b32_e32 v89, 0xffff, v89                             // 000000A04C38: 36B2B2FF 0000FFFF
	.long 0xd72c005b                                           // 000000A04C40: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000A04C44: 0202B6FF 83DCD12D
	v_dot2acc_f32_f16 v59, v75, v34                            // 000000A04C4C: 0476454B
	v_lshl_or_b32 v76, v84, 16, v76                            // 000000A04C50: D656004C 05312154
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A04C58: D6220048 03FD0148 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A04C64: D6220049 03FD0149 00006400
	v_and_or_b32 v82, 0xffff, v85, v82                         // 000000A04C70: D6570052 054AAAFF 0000FFFF
	v_lshl_or_b32 v83, v83, 16, v89                            // 000000A04C7C: D6560053 05652153
	.long 0xd72c0056                                           // 000000A04C84: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A04C88: 0202ACFF 83DCD12D
	.long 0xd72c004b                                           // 000000A04C90: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A04C94: 0202AEFF 83DCD12D
	v_pk_fma_f16 v84, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04C9C: CC0E0054 0BFC0B4C 0000C931
	v_sad_u8 v76, v91, 0, 0x6400                               // 000000A04CA8: D622004C 03FD015B 00006400
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000A04CB4: 30909090
	v_pk_fma_f16 v85, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04CB8: CC0E0055 0BFC0B52 0000C931
	v_pk_fma_f16 v82, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04CC4: CC0E0052 0BFC0B53 0000C931
	v_and_b32_e32 v83, 0xffff, v73                             // 000000A04CD0: 36A692FF 0000FFFF
	v_sad_u8 v87, v74, 0, 0x6400                               // 000000A04CD8: D6220057 03FD014A 00006400
	ds_load_2addr_b32 v[73:74], v64 offset0:64 offset1:96      // 000000A04CE4: D8DC6040 49000040
	v_sad_u8 v80, v86, 0, 0x6400                               // 000000A04CEC: D6220050 03FD0156 00006400
	v_sad_u8 v86, v75, 0, 0x6400                               // 000000A04CF8: D6220056 03FD014B 00006400
	v_dot2acc_f32_f16 v59, v84, v35                            // 000000A04D04: 04764754
	v_and_or_b32 v72, 0xffff, v76, v72                         // 000000A04D08: D6570048 052298FF 0000FFFF
	.long 0xd73d004b                                           // 000000A04D14: D73D004B
	v_cndmask_b32_e32 v1, v62, v77, vcc_lo                     // 000000A04D18: 02029B3E
	v_lshl_or_b32 v76, v80, 16, v83                            // 000000A04D1C: D656004C 054D2150
	v_dot2acc_f32_f16 v57, v82, v33                            // 000000A04D24: 04724352
	v_lshlrev_b32_e32 v87, 16, v87                             // 000000A04D28: 30AEAE90
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04D2C: CC0E0048 0BFC0B48 0000C931
	v_bfe_u32 v78, v75, 12, 16                                 // 000000A04D38: D610004E 0241194B
	v_pk_fma_f16 v80, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04D40: CC0E0050 0BFC0B4C 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A04D4C: BF870223
	v_dual_dot2acc_f32_f16 v57, v72, v34 :: v_dual_and_b32 v76, 0xffff, v75// 000000A04D50: CB244548 394C96FF 0000FFFF
	v_and_or_b32 v77, 0xffff, v86, v87                         // 000000A04D5C: D657004D 055EACFF 0000FFFF
	.long 0xd72c0048                                           // 000000A04D68: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A04D6C: 02029CFF 83DCD12D
	v_bfe_u32 v78, v75, 8, 16                                  // 000000A04D74: D610004E 0241114B
	v_bfe_u32 v75, v75, 4, 16                                  // 000000A04D7C: D610004B 0241094B
	.long 0xd72c004c                                           // 000000A04D84: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A04D88: 020298FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A04D90: BF89FC07
	v_bfe_u32 v82, v73, 12, 16                                 // 000000A04D94: D6100052 02411949
	v_bfe_u32 v83, v73, 8, 16                                  // 000000A04D9C: D6100053 02411149
	.long 0xd72c004e                                           // 000000A04DA4: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A04DA8: 02029CFF 83DCD12D
	.long 0xd72c004b                                           // 000000A04DB0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A04DB4: 020296FF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A04DBC: D6220048 03FD0148 00006400
	.long 0xd72c0052                                           // 000000A04DC8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A04DCC: 0202A4FF 83DCD12D
	.long 0xd72c0053                                           // 000000A04DD4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A04DD8: 0202A6FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A04DE0: D622004C 03FD014C 00006400
	v_bfe_u32 v84, v73, 4, 16                                  // 000000A04DEC: D6100054 02410949
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A04DF4: 369090FF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A04DFC: D622004E 03FD014E 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A04E08: D622004B 03FD014B 00006400
	v_dual_dot2acc_f32_f16 v57, v80, v35 :: v_dual_lshlrev_b32 v76, 16, v76// 000000A04E14: CB224750 394C9890
	v_sad_u8 v86, v82, 0, 0x6400                               // 000000A04E1C: D6220056 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A04E28: BF870224
	v_lshl_or_b32 v72, v78, 16, v72                            // 000000A04E2C: D6560048 0521214E
	v_dual_mov_b32 v82, v79 :: v_dual_and_b32 v73, 0xffff, v73 // 000000A04E34: CA24014F 524892FF 0000FFFF
	v_and_or_b32 v78, 0xffff, v75, v76                         // 000000A04E40: D657004E 053296FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A04E4C: BF870004
	v_and_b32_e32 v79, 0xffff, v86                             // 000000A04E50: 369EACFF 0000FFFF
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A04E58: D6220053 03FD0153 00006400
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04E64: CC0E0048 0BFC0B48 0000C931
	.long 0xd72c0049                                           // 000000A04E70: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A04E74: 020292FF 83DCD12D
	.long 0xd73d004b                                           // 000000A04E7C: D73D004B
	v_cndmask_b32_e32 v1, v62, v81, vcc_lo                     // 000000A04E80: 0202A33E
	v_pk_fma_f16 v76, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04E84: CC0E004C 0BFC0B4E 0000C931
	v_lshl_or_b32 v78, v83, 16, v79                            // 000000A04E90: D656004E 053D2153
	v_dot2acc_f32_f16 v56, v72, v33                            // 000000A04E98: 04704348
	.long 0xd72c0054                                           // 000000A04E9C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A04EA0: 0202A8FF 83DCD12D
	v_pk_fma_f16 v77, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04EA8: CC0E004D 0BFC0B4D 0000C931
	v_bfe_u32 v72, v75, 12, 16                                 // 000000A04EB4: D6100048 0241194B
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A04EBC: D6220049 03FD0149 00006400
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04EC8: CC0E004E 0BFC0B4E 0000C931
	v_dual_dot2acc_f32_f16 v56, v76, v34 :: v_dual_dot2acc_f32_f16 v59, v85, v36// 000000A04ED4: CB18454C 383A4955
	v_and_b32_e32 v80, 0xffff, v75                             // 000000A04EDC: 36A096FF 0000FFFF
	v_sad_u8 v79, v84, 0, 0x6400                               // 000000A04EE4: D622004F 03FD0154 00006400
	.long 0xd72c004c                                           // 000000A04EF0: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A04EF4: 020290FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A04EFC: BF870004
	v_dual_dot2acc_f32_f16 v56, v78, v35 :: v_dual_lshlrev_b32 v73, 16, v73// 000000A04F00: CB22474E 38489290
	v_bfe_u32 v72, v75, 8, 16                                  // 000000A04F08: D6100048 0241114B
	v_bfe_u32 v81, v75, 4, 16                                  // 000000A04F10: D6100051 0241094B
	v_bfe_u32 v82, v74, 12, 16                                 // 000000A04F18: D6100052 0241194A
	.long 0xd72c0050                                           // 000000A04F20: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A04F24: 0202A0FF 83DCD12D
	v_and_or_b32 v73, 0xffff, v79, v73                         // 000000A04F2C: D6570049 05269EFF 0000FFFF
	v_sad_u8 v78, v76, 0, 0x6400                               // 000000A04F38: D622004E 03FD014C 00006400
	v_dot2acc_f32_f16 v57, v77, v36                            // 000000A04F44: 0472494D
	.long 0xd72c004d                                           // 000000A04F48: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A04F4C: 020290FF 83DCD12D
	ds_load_2addr_b32 v[75:76], v66 offset0:128 offset1:160    // 000000A04F54: D8DCA080 4B000042
	v_pk_fma_f16 v79, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A04F5C: CC0E004F 0BFC0B49 0000C931
	ds_load_2addr_b32 v[72:73], v67 offset0:128 offset1:160    // 000000A04F68: D8DCA080 48000043
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A04F70: 369C9CFF 0000FFFF
	.long 0xd72c0052                                           // 000000A04F78: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A04F7C: 0202A4FF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v74                             // 000000A04F84: 36A894FF 0000FFFF
	v_bfe_u32 v83, v74, 8, 16                                  // 000000A04F8C: D6100053 0241114A
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A04F94: D622004D 03FD014D 00006400
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A04FA0: D610004A 0241094A
	.long 0xd72c0051                                           // 000000A04FA8: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A04FAC: 0202A2FF 83DCD12D
	v_dot2acc_f32_f16 v56, v79, v36                            // 000000A04FB4: 0470494F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A04FB8: BF870004
	v_lshl_or_b32 v85, v77, 16, v78                            // 000000A04FBC: D6560055 0539214D
	.long 0xd72c004e                                           // 000000A04FC4: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A04FC8: 0202A8FF 83DCD12D
	v_sad_u8 v77, v80, 0, 0x6400                               // 000000A04FD0: D622004D 03FD0150 00006400
	v_sad_u8 v80, v82, 0, 0x6400                               // 000000A04FDC: D6220050 03FD0152 00006400
	.long 0xd72c0052                                           // 000000A04FE8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A04FEC: 0202A6FF 83DCD12D
	.long 0xd72c0053                                           // 000000A04FF4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A04FF8: 020294FF 83DCD12D
	v_sad_u8 v84, v78, 0, 0x6400                               // 000000A05000: D6220054 03FD014E 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000A0500C: BF89FC07
	v_mov_b32_e32 v74, v72                                     // 000000A05010: 7E940348
	v_sad_u8 v72, v81, 0, 0x6400                               // 000000A05014: D6220048 03FD0151 00006400
	v_lshlrev_b32_e32 v81, 16, v77                             // 000000A05020: 30A29A90
	ds_load_2addr_b32 v[77:78], v64 offset0:128 offset1:160    // 000000A05024: D8DCA080 4D000040
	.long 0xd73d004a                                           // 000000A0502C: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000A05030: 0202953E
	v_sad_u8 v75, v82, 0, 0x6400                               // 000000A05034: D622004B 03FD0152 00006400
	v_sad_u8 v82, v83, 0, 0x6400                               // 000000A05040: D6220052 03FD0153 00006400
	v_lshlrev_b32_e32 v83, 16, v84                             // 000000A0504C: 30A6A890
	v_and_or_b32 v72, 0xffff, v72, v81                         // 000000A05050: D6570048 054690FF 0000FFFF
	v_pk_fma_f16 v84, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0505C: CC0E0054 0BFC0B55 0000C931
	v_and_b32_e32 v80, 0xffff, v80                             // 000000A05068: 36A0A0FF 0000FFFF
	v_bfe_u32 v81, v74, 12, 16                                 // 000000A05070: D6100051 0241194A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A05078: BF870214
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0507C: CC0E0048 0BFC0B48 0000C931
	v_dot2acc_f32_f16 v55, v84, v33                            // 000000A05088: 046E4354
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0508C: BF870004
	v_lshl_or_b32 v75, v75, 16, v80                            // 000000A05090: D656004B 0541214B
	v_and_or_b32 v80, 0xffff, v82, v83                         // 000000A05098: D6570050 054EA4FF 0000FFFF
	.long 0xd72c0051                                           // 000000A050A4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A050A8: 0202A2FF 83DCD12D
	v_bfe_u32 v82, v74, 8, 16                                  // 000000A050B0: D6100052 0241114A
	v_and_b32_e32 v83, 0xffff, v74                             // 000000A050B8: 36A694FF 0000FFFF
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A050C0: D610004A 0241094A
	s_waitcnt lgkmcnt(0)                                       // 000000A050C8: BF89FC07
	v_dual_dot2acc_f32_f16 v55, v72, v34 :: v_dual_and_b32 v86, 0xffff, v77// 000000A050CC: CB244548 37569AFF 0000FFFF
	.long 0xd72c0052                                           // 000000A050D8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A050DC: 0202A4FF 83DCD12D
	.long 0xd72c0053                                           // 000000A050E4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A050E8: 0202A6FF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A050F0: D6220051 03FD0151 00006400
	v_bfe_u32 v84, v77, 12, 16                                 // 000000A050FC: D6100054 0241194D
	.long 0xd72c004a                                           // 000000A05104: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A05108: 020294FF 83DCD12D
	v_bfe_u32 v85, v77, 8, 16                                  // 000000A05110: D6100055 0241114D
	v_bfe_u32 v77, v77, 4, 16                                  // 000000A05118: D610004D 0241094D
	v_and_b32_e32 v81, 0xffff, v81                             // 000000A05120: 36A2A2FF 0000FFFF
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A05128: D6220052 03FD0152 00006400
	.long 0xd72c0054                                           // 000000A05134: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A05138: 0202A8FF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A05140: D6220053 03FD0153 00006400
	.long 0xd72c0055                                           // 000000A0514C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A05150: 0202AAFF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A05158: D622004A 03FD014A 00006400
	v_lshl_or_b32 v81, v82, 16, v81                            // 000000A05164: D6560051 05452152
	.long 0xd72c0052                                           // 000000A0516C: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A05170: 0202ACFF 83DCD12D
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000A05178: 30A6A690
	.long 0xd72c004d                                           // 000000A0517C: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A05180: 02029AFF 83DCD12D
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A05188: D6220054 03FD0154 00006400
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05194: CC0E0051 0BFC0B51 0000C931
	v_pk_fma_f16 v75, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A051A0: CC0E004B 0BFC0B4B 0000C931
	v_and_or_b32 v72, 0xffff, v74, v83                         // 000000A051AC: D6570048 054E94FF 0000FFFF
	v_sad_u8 v83, v85, 0, 0x6400                               // 000000A051B8: D6220053 03FD0155 00006400
	v_sad_u8 v74, v82, 0, 0x6400                               // 000000A051C4: D622004A 03FD0152 00006400
	v_and_b32_e32 v82, 0xffff, v84                             // 000000A051D0: 36A4A8FF 0000FFFF
	v_dot2acc_f32_f16 v54, v81, v33                            // 000000A051D8: 046C4351
	v_pk_fma_f16 v84, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A051DC: CC0E0054 0BFC0B48 0000C931
	v_sad_u8 v72, v77, 0, 0x6400                               // 000000A051E8: D6220048 03FD014D 00006400
	v_dual_mov_b32 v74, v76 :: v_dual_lshlrev_b32 v77, 16, v74 // 000000A051F4: CA22014C 4A4C9490
	v_lshl_or_b32 v76, v83, 16, v82                            // 000000A051FC: D656004C 05492153
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A05204: BF870194
	v_dual_dot2acc_f32_f16 v55, v75, v35 :: v_dual_dot2acc_f32_f16 v54, v84, v34// 000000A05208: CB18474B 37364554
	v_and_or_b32 v75, 0xffff, v72, v77                         // 000000A05210: D657004B 053690FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0521C: BF870214
	.long 0xd73d0048                                           // 000000A05220: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A05224: 0202933E
	v_pk_fma_f16 v73, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05228: CC0E0049 0BFC0B4C 0000C931
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05234: CC0E0050 0BFC0B50 0000C931
	v_bfe_u32 v82, v78, 8, 16                                  // 000000A05240: D6100052 0241114E
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05248: CC0E004F 0BFC0B4B 0000C931
	v_bfe_u32 v84, v78, 4, 16                                  // 000000A05254: D6100054 0241094E
	v_bfe_u32 v74, v72, 12, 16                                 // 000000A0525C: D610004A 02411948
	v_dot2acc_f32_f16 v54, v73, v35                            // 000000A05264: 046C4749
	v_bfe_u32 v75, v72, 8, 16                                  // 000000A05268: D610004B 02411148
	v_and_b32_e32 v76, 0xffff, v72                             // 000000A05270: 369890FF 0000FFFF
	v_bfe_u32 v77, v72, 4, 16                                  // 000000A05278: D610004D 02410948
	ds_load_2addr_b32 v[72:73], v67 offset0:192 offset1:224    // 000000A05280: D8DCE0C0 48000043
	.long 0xd72c004a                                           // 000000A05288: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0528C: 020294FF 83DCD12D
	.long 0xd72c0053                                           // 000000A05294: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A05298: 020296FF 83DCD12D
	.long 0xd72c0051                                           // 000000A052A0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A052A4: 020298FF 83DCD12D
	ds_load_2addr_b32 v[75:76], v66 offset0:192 offset1:224    // 000000A052AC: D8DCE0C0 4B000042
	v_dot2acc_f32_f16 v55, v80, v36                            // 000000A052B4: 046E4950
	v_bfe_u32 v80, v78, 12, 16                                 // 000000A052B8: D6100050 0241194E
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A052C0: 369C9CFF 0000FFFF
	.long 0xd72c0052                                           // 000000A052C8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A052CC: 0202A4FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A052D4: D622004A 03FD014A 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A052E0: D6220053 03FD0153 00006400
	.long 0xd72c0050                                           // 000000A052EC: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A052F0: 0202A0FF 83DCD12D
	.long 0xd72c004e                                           // 000000A052F8: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A052FC: 02029CFF 83DCD12D
	.long 0xd72c0054                                           // 000000A05304: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A05308: 0202A8FF 83DCD12D
	v_dual_dot2acc_f32_f16 v54, v79, v36 :: v_dual_and_b32 v85, 0xffff, v74// 000000A05310: CB24494F 365494FF 0000FFFF
	.long 0xd72c004d                                           // 000000A0531C: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A05320: 02029AFF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A05328: D6220051 03FD0151 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A05334: D6220050 03FD0150 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A05340: BF89FC17
	v_mov_b32_e32 v74, v72                                     // 000000A05344: 7E940348
	v_lshl_or_b32 v72, v83, 16, v85                            // 000000A05348: D6560048 05552153
	v_sad_u8 v83, v78, 0, 0x6400                               // 000000A05350: D6220053 03FD014E 00006400
	v_and_b32_e32 v80, 0xffff, v80                             // 000000A0535C: 36A0A0FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A05364: BF89FC07
	.long 0xd73d004a                                           // 000000A05368: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000A0536C: 0202953E
	v_sad_u8 v75, v82, 0, 0x6400                               // 000000A05370: D622004B 03FD0152 00006400
	v_sad_u8 v82, v84, 0, 0x6400                               // 000000A0537C: D6220052 03FD0154 00006400
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000A05388: 30A6A690
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0538C: CC0E0048 0BFC0B48 0000C931
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A05398: D622004D 03FD014D 00006400
	v_bfe_u32 v84, v74, 12, 16                                 // 000000A053A4: D6100054 0241194A
	v_lshl_or_b32 v75, v75, 16, v80                            // 000000A053AC: D656004B 0541214B
	v_and_or_b32 v80, 0xffff, v82, v83                         // 000000A053B4: D6570050 054EA4FF 0000FFFF
	v_dot2acc_f32_f16 v53, v72, v33                            // 000000A053C0: 046A4348
	v_bfe_u32 v82, v74, 8, 16                                  // 000000A053C4: D6100052 0241114A
	.long 0xd72c0048                                           // 000000A053CC: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A053D0: 0202A8FF 83DCD12D
	v_pk_fma_f16 v75, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A053D8: CC0E004B 0BFC0B4B 0000C931
	v_pk_fma_f16 v79, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A053E4: CC0E004F 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A053F0: BF870214
	.long 0xd72c0050                                           // 000000A053F4: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A053F8: 0202A4FF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A05400: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0540C: BF870112
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A05410: D6220050 03FD0150 00006400
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A0541C: 369090FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A05424: BF870091
	v_lshl_or_b32 v72, v80, 16, v72                            // 000000A05428: D6560048 05212150
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05430: CC0E0048 0BFC0B48 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A0543C: BF8700A1
	v_dot2acc_f32_f16 v52, v72, v33                            // 000000A05440: 04684348
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000A05444: 30A2A290
	v_and_or_b32 v81, 0xffff, v77, v81                         // 000000A05448: D6570051 05469AFF 0000FFFF
	ds_load_2addr_b32 v[77:78], v64 offset0:192 offset1:224    // 000000A05454: D8DCE0C0 4D000040
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0545C: CC0E0051 0BFC0B51 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A05468: BF8701B1
	v_dot2acc_f32_f16 v53, v81, v34                            // 000000A0546C: 046A4551
	v_and_b32_e32 v81, 0xffff, v74                             // 000000A05470: 36A294FF 0000FFFF
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A05478: D610004A 0241094A
	v_dot2acc_f32_f16 v53, v75, v35                            // 000000A05480: 046A474B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A05484: BF870193
	.long 0xd72c0051                                           // 000000A05488: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0548C: 0202A2FF 83DCD12D
	.long 0xd72c0052                                           // 000000A05494: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A05498: 020294FF 83DCD12D
	v_mov_b32_e32 v74, v76                                     // 000000A054A0: 7E94034C
	s_waitcnt lgkmcnt(0)                                       // 000000A054A4: BF89FC07
	v_bfe_u32 v75, v77, 12, 16                                 // 000000A054A8: D610004B 0241194D
	v_bfe_u32 v83, v77, 8, 16                                  // 000000A054B0: D6100053 0241114D
	v_bfe_u32 v84, v77, 4, 16                                  // 000000A054B8: D6100054 0241094D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A054C0: 369A9AFF 0000FFFF
	v_sad_u8 v80, v81, 0, 0x6400                               // 000000A054C8: D6220050 03FD0151 00006400
	.long 0xd72c0051                                           // 000000A054D4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A054D8: 020296FF 83DCD12D
	.long 0xd73d004a                                           // 000000A054E0: D73D004A
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A054E4: 0202933E
	v_sad_u8 v76, v82, 0, 0x6400                               // 000000A054E8: D622004C 03FD0152 00006400
	.long 0xd72c004d                                           // 000000A054F4: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A054F8: 02029AFF 83DCD12D
	v_lshlrev_b32_e32 v80, 16, v80                             // 000000A05500: 30A0A090
	.long 0xd72c0049                                           // 000000A05504: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A05508: 0202A8FF 83DCD12D
	.long 0xd72c0052                                           // 000000A05510: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A05514: 0202A6FF 83DCD12D
	v_bfe_u32 v84, v78, 8, 16                                  // 000000A0551C: D6100054 0241114E
	v_sad_u8 v75, v81, 0, 0x6400                               // 000000A05524: D622004B 03FD0151 00006400
	v_and_or_b32 v76, 0xffff, v76, v80                         // 000000A05530: D657004C 054298FF 0000FFFF
	v_bfe_u32 v80, v74, 12, 16                                 // 000000A0553C: D6100050 0241194A
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A05544: D622004D 03FD014D 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A05550: D6220049 03FD0149 00006400
	v_sad_u8 v81, v82, 0, 0x6400                               // 000000A0555C: D6220051 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A05568: BF870214
	.long 0xd72c0050                                           // 000000A0556C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A05570: 0202A0FF 83DCD12D
	v_lshlrev_b32_e32 v77, 16, v77                             // 000000A05578: 309A9A90
	v_bfe_u32 v82, v74, 8, 16                                  // 000000A0557C: D6100052 0241114A
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05584: CC0E004C 0BFC0B4C 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A05590: BF870193
	v_and_or_b32 v73, 0xffff, v73, v77                         // 000000A05594: D6570049 053692FF 0000FFFF
	.long 0xd72c0048                                           // 000000A055A0: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A055A4: 0202A4FF 83DCD12D
	v_sad_u8 v77, v80, 0, 0x6400                               // 000000A055AC: D622004D 03FD0150 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A055B8: BF870214
	v_dual_dot2acc_f32_f16 v53, v79, v36 :: v_dual_dot2acc_f32_f16 v52, v76, v34// 000000A055BC: CB18494F 3534454C
	v_pk_fma_f16 v80, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A055C4: CC0E0050 0BFC0B49 0000C931
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A055D0: 369696FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A055D8: BF870004
	v_and_b32_e32 v76, 0xffff, v77                             // 000000A055DC: 36989AFF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v78                             // 000000A055E4: 36A49CFF 0000FFFF
	v_sad_u8 v77, v72, 0, 0x6400                               // 000000A055EC: D622004D 03FD0148 00006400
	ds_load_2addr_b32 v[72:73], v69 offset1:32                 // 000000A055F8: D8DC2000 48000045
	v_lshl_or_b32 v75, v81, 16, v75                            // 000000A05600: D656004B 052D2151
	v_bfe_u32 v81, v78, 12, 16                                 // 000000A05608: D6100051 0241194E
	v_bfe_u32 v78, v78, 4, 16                                  // 000000A05610: D610004E 0241094E
	v_lshl_or_b32 v77, v77, 16, v76                            // 000000A05618: D656004D 0531214D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A05620: BF870004
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05624: CC0E004F 0BFC0B4B 0000C931
	v_and_b32_e32 v75, 0xffff, v74                             // 000000A05630: 369694FF 0000FFFF
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A05638: D610004A 0241094A
	.long 0xd72c0051                                           // 000000A05640: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A05644: 0202A2FF 83DCD12D
	v_pk_fma_f16 v85, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0564C: CC0E0055 0BFC0B4D 0000C931
	.long 0xd72c004d                                           // 000000A05658: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0565C: 0202A4FF 83DCD12D
	.long 0xd72c0053                                           // 000000A05664: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A05668: 020296FF 83DCD12D
	.long 0xd72c004a                                           // 000000A05670: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A05674: 020294FF 83DCD12D
	ds_load_2addr_b32 v[75:76], v68 offset1:32                 // 000000A0567C: D8DC2000 4B000044
	v_dual_dot2acc_f32_f16 v52, v79, v35 :: v_dual_dot2acc_f32_f16 v51, v85, v33// 000000A05684: CB18474F 34324355
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0568C: D6220051 03FD0151 00006400
	v_sad_u8 v87, v77, 0, 0x6400                               // 000000A05698: D6220057 03FD014D 00006400
	v_sad_u8 v82, v83, 0, 0x6400                               // 000000A056A4: D6220052 03FD0153 00006400
	.long 0xd72c0053                                           // 000000A056B0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A056B4: 0202A8FF 83DCD12D
	v_sad_u8 v86, v74, 0, 0x6400                               // 000000A056BC: D6220056 03FD014A 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A056C8: BF89FC17
	v_dual_mov_b32 v74, v72 :: v_dual_and_b32 v81, 0xffff, v81 // 000000A056CC: CA240148 4A50A2FF 0000FFFF
	v_lshlrev_b32_e32 v82, 16, v82                             // 000000A056D8: 30A4A490
	.long 0xd72c0054                                           // 000000A056DC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A056E0: 02029CFF 83DCD12D
	ds_load_2addr_b32 v[77:78], v65 offset1:32                 // 000000A056E8: D8DC2000 4D000041
	v_dot2acc_f32_f16 v52, v80, v36                            // 000000A056F0: 04684950
	v_sad_u8 v72, v83, 0, 0x6400                               // 000000A056F4: D6220048 03FD0153 00006400
	v_and_or_b32 v82, 0xffff, v86, v82                         // 000000A05700: D6570052 054AACFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0570C: BF870112
	v_lshl_or_b32 v72, v72, 16, v81                            // 000000A05710: D6560048 05452148
	v_pk_fma_f16 v79, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05718: CC0E004F 0BFC0B52 0000C931
	v_sad_u8 v83, v84, 0, 0x6400                               // 000000A05724: D6220053 03FD0154 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A05730: BF89FC17
	.long 0xd73d004a                                           // 000000A05734: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000A05738: 0202953E
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0573C: CC0E0048 0BFC0B48 0000C931
	v_dot2acc_f32_f16 v51, v79, v34                            // 000000A05748: 0466454F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0574C: BF870113
	v_bfe_u32 v81, v74, 12, 16                                 // 000000A05750: D6100051 0241194A
	v_dot2acc_f32_f16 v51, v72, v35                            // 000000A05758: 04664748
	v_lshlrev_b32_e32 v84, 16, v87                             // 000000A0575C: 30A8AE90
	s_waitcnt lgkmcnt(0)                                       // 000000A05760: BF89FC07
	v_bfe_u32 v85, v77, 4, 16                                  // 000000A05764: D6100055 0241094D
	.long 0xd72c004f                                           // 000000A0576C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A05770: 0202A2FF 83DCD12D
	v_bfe_u32 v81, v74, 8, 16                                  // 000000A05778: D6100051 0241114A
	v_and_or_b32 v75, 0xffff, v83, v84                         // 000000A05780: D657004B 0552A6FF 0000FFFF
	v_bfe_u32 v83, v77, 12, 16                                 // 000000A0578C: D6100053 0241194D
	v_bfe_u32 v84, v77, 8, 16                                  // 000000A05794: D6100054 0241114D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0579C: BF870004
	.long 0xd72c0051                                           // 000000A057A0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A057A4: 0202A2FF 83DCD12D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A057AC: 369A9AFF 0000FFFF
	v_pk_fma_f16 v82, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A057B4: CC0E0052 0BFC0B4B 0000C931
	v_and_b32_e32 v75, 0xffff, v74                             // 000000A057C0: 369694FF 0000FFFF
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A057C8: D610004A 0241094A
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A057D0: D622004F 03FD014F 00006400
	.long 0xd72c0053                                           // 000000A057DC: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A057E0: 0202A6FF 83DCD12D
	.long 0xd72c0054                                           // 000000A057E8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A057EC: 0202A8FF 83DCD12D
	.long 0xd72c004b                                           // 000000A057F4: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A057F8: 020296FF 83DCD12D
	.long 0xd72c004a                                           // 000000A05800: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A05804: 020294FF 83DCD12D
	v_and_b32_e32 v79, 0xffff, v79                             // 000000A0580C: 369E9EFF 0000FFFF
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A05814: D6220051 03FD0151 00006400
	.long 0xd72c004d                                           // 000000A05820: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A05824: 02029AFF 83DCD12D
	.long 0xd72c0055                                           // 000000A0582C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A05830: 0202AAFF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A05838: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v51, v82, v36                            // 000000A05844: 04664952
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A05848: D622004B 03FD014B 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A05854: D622004A 03FD014A 00006400
	v_lshl_or_b32 v79, v81, 16, v79                            // 000000A05860: D656004F 053D2151
	v_bfe_u32 v82, v78, 12, 16                                 // 000000A05868: D6100052 0241194E
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A05870: D622004D 03FD014D 00006400
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000A0587C: 30969690
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A05880: BF870214
	v_pk_fma_f16 v79, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05884: CC0E004F 0BFC0B4F 0000C931
	.long 0xd72c0052                                           // 000000A05890: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A05894: 0202A4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0589C: BF870214
	v_lshlrev_b32_e32 v77, 16, v77                             // 000000A058A0: 309A9A90
	v_and_or_b32 v81, 0xffff, v74, v75                         // 000000A058A4: D6570051 052E94FF 0000FFFF
	v_mov_b32_e32 v74, v76                                     // 000000A058B0: 7E94034C
	v_and_b32_e32 v76, 0xffff, v83                             // 000000A058B4: 3698A6FF 0000FFFF
	v_sad_u8 v83, v84, 0, 0x6400                               // 000000A058BC: D6220053 03FD0154 00006400
	v_dot2acc_f32_f16 v50, v79, v33                            // 000000A058C8: 0464434F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A058CC: BF870224
	.long 0xd73d004a                                           // 000000A058D0: D73D004A
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A058D4: 0202933E
	v_pk_fma_f16 v73, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A058D8: CC0E0049 0BFC0B51 0000C931
	v_lshl_or_b32 v75, v83, 16, v76                            // 000000A058E4: D656004B 05312153
	v_sad_u8 v76, v85, 0, 0x6400                               // 000000A058EC: D622004C 03FD0155 00006400
	v_bfe_u32 v83, v78, 8, 16                                  // 000000A058F8: D6100053 0241114E
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A05900: D6220052 03FD0152 00006400
	v_bfe_u32 v79, v74, 12, 16                                 // 000000A0590C: D610004F 0241194A
	v_pk_fma_f16 v72, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05914: CC0E0048 0BFC0B4B 0000C931
	v_dot2acc_f32_f16 v50, v73, v34                            // 000000A05920: 04644549
	v_bfe_u32 v73, v74, 8, 16                                  // 000000A05924: D6100049 0241114A
	v_and_or_b32 v75, 0xffff, v76, v77                         // 000000A0592C: D657004B 053698FF 0000FFFF
	.long 0xd72c004c                                           // 000000A05938: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A0593C: 02029EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A05944: BF870214
	v_dual_dot2acc_f32_f16 v50, v72, v35 :: v_dual_and_b32 v81, 0xffff, v74// 000000A05948: CB244748 325094FF 0000FFFF
	.long 0xd72c004d                                           // 000000A05954: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A05958: 020292FF 83DCD12D
	ds_load_2addr_b32 v[72:73], v69 offset0:64 offset1:96      // 000000A05960: D8DC6040 48000045
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05968: CC0E004F 0BFC0B4B 0000C931
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A05974: D610004A 0241094A
	.long 0xd72c0053                                           // 000000A0597C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A05980: 0202A6FF 83DCD12D
	v_sad_u8 v80, v76, 0, 0x6400                               // 000000A05988: D6220050 03FD014C 00006400
	ds_load_2addr_b32 v[75:76], v68 offset0:64 offset1:96      // 000000A05994: D8DC6040 4B000044
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A0599C: 36A4A4FF 0000FFFF
	.long 0xd72c0055                                           // 000000A059A4: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A059A8: 020294FF 83DCD12D
	.long 0xd72c0051                                           // 000000A059B0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A059B4: 0202A2FF 83DCD12D
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A059BC: D622004D 03FD014D 00006400
	v_dot2acc_f32_f16 v50, v79, v36                            // 000000A059C8: 0464494F
	s_waitcnt lgkmcnt(1)                                       // 000000A059CC: BF89FC17
	v_mov_b32_e32 v74, v72                                     // 000000A059D0: 7E940348
	v_sad_u8 v72, v85, 0, 0x6400                               // 000000A059D4: D6220048 03FD0155 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000A059E0: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A059E4: BF8700A2
	.long 0xd73d004a                                           // 000000A059E8: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000A059EC: 0202953E
	v_sad_u8 v75, v83, 0, 0x6400                               // 000000A059F0: D622004B 03FD0153 00006400
	v_lshl_or_b32 v75, v75, 16, v82                            // 000000A059FC: D656004B 0549214B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A05A04: BF8700A1
	v_pk_fma_f16 v75, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05A08: CC0E004B 0BFC0B4B 0000C931
	v_and_b32_e32 v80, 0xffff, v80                             // 000000A05A14: 36A0A0FF 0000FFFF
	v_lshl_or_b32 v80, v77, 16, v80                            // 000000A05A1C: D6560050 0541214D
	v_sad_u8 v77, v81, 0, 0x6400                               // 000000A05A24: D622004D 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A05A30: BF870112
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05A34: CC0E0050 0BFC0B50 0000C931
	v_lshlrev_b32_e32 v85, 16, v77                             // 000000A05A40: 30AA9A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A05A44: BF870112
	v_dot2acc_f32_f16 v49, v80, v33                            // 000000A05A48: 04624350
	v_and_or_b32 v72, 0xffff, v72, v85                         // 000000A05A4C: D6570048 055690FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A05A58: BF870091
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05A5C: CC0E0048 0BFC0B48 0000C931
	v_dot2acc_f32_f16 v49, v72, v34                            // 000000A05A68: 04624548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A05A6C: BF870121
	v_dual_dot2acc_f32_f16 v49, v75, v35 :: v_dual_and_b32 v84, 0xffff, v78// 000000A05A70: CB24474B 31549CFF 0000FFFF
	v_bfe_u32 v78, v78, 4, 16                                  // 000000A05A7C: D610004E 0241094E
	.long 0xd72c0051                                           // 000000A05A84: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A05A88: 0202A8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000A05A90: BF8701D2
	.long 0xd72c0054                                           // 000000A05A94: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A05A98: 02029CFF 83DCD12D
	ds_load_2addr_b32 v[77:78], v65 offset0:64 offset1:96      // 000000A05AA0: D8DC6040 4D000041
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A05AA8: D6220051 03FD0151 00006400
	v_sad_u8 v83, v84, 0, 0x6400                               // 000000A05AB4: D6220053 03FD0154 00006400
	v_bfe_u32 v84, v74, 12, 16                                 // 000000A05AC0: D6100054 0241194A
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000A05AC8: 30A2A290
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A05ACC: BF8701A2
	.long 0xd72c0052                                           // 000000A05AD0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A05AD4: 0202A8FF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v74                             // 000000A05ADC: 36A894FF 0000FFFF
	v_and_or_b32 v81, 0xffff, v83, v81                         // 000000A05AE4: D6570051 0546A6FF 0000FFFF
	v_bfe_u32 v83, v74, 8, 16                                  // 000000A05AF0: D6100053 0241114A
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A05AF8: D610004A 0241094A
	s_waitcnt lgkmcnt(0)                                       // 000000A05B00: BF89FC07
	v_and_b32_e32 v86, 0xffff, v77                             // 000000A05B04: 36AC9AFF 0000FFFF
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A05B0C: D6220052 03FD0152 00006400
	.long 0xd72c0050                                           // 000000A05B18: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A05B1C: 0202A6FF 83DCD12D
	.long 0xd72c0053                                           // 000000A05B24: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A05B28: 0202A8FF 83DCD12D
	v_bfe_u32 v84, v77, 12, 16                                 // 000000A05B30: D6100054 0241194D
	.long 0xd72c004a                                           // 000000A05B38: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A05B3C: 020294FF 83DCD12D
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A05B44: 36A4A4FF 0000FFFF
	v_bfe_u32 v85, v77, 8, 16                                  // 000000A05B4C: D6100055 0241114D
	v_bfe_u32 v77, v77, 4, 16                                  // 000000A05B54: D610004D 0241094D
	.long 0xd72c0054                                           // 000000A05B5C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A05B60: 0202A8FF 83DCD12D
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A05B68: D6220050 03FD0150 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A05B74: D6220053 03FD0153 00006400
	.long 0xd72c0055                                           // 000000A05B80: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A05B84: 0202AAFF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A05B8C: D622004A 03FD014A 00006400
	.long 0xd72c004d                                           // 000000A05B98: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A05B9C: 02029AFF 83DCD12D
	v_lshl_or_b32 v80, v80, 16, v82                            // 000000A05BA4: D6560050 05492150
	.long 0xd72c0052                                           // 000000A05BAC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A05BB0: 0202ACFF 83DCD12D
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000A05BB8: 30A6A690
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A05BBC: D6220054 03FD0154 00006400
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05BC8: CC0E0051 0BFC0B51 0000C931
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05BD4: CC0E0050 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A05BE0: BF870004
	v_and_or_b32 v72, 0xffff, v74, v83                         // 000000A05BE4: D6570048 054E94FF 0000FFFF
	v_sad_u8 v83, v85, 0, 0x6400                               // 000000A05BF0: D6220053 03FD0155 00006400
	v_sad_u8 v74, v82, 0, 0x6400                               // 000000A05BFC: D622004A 03FD0152 00006400
	v_and_b32_e32 v82, 0xffff, v84                             // 000000A05C08: 36A4A8FF 0000FFFF
	v_dot2acc_f32_f16 v48, v80, v33                            // 000000A05C10: 04604350
	v_pk_fma_f16 v84, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05C14: CC0E0054 0BFC0B48 0000C931
	v_sad_u8 v72, v77, 0, 0x6400                               // 000000A05C20: D6220048 03FD014D 00006400
	v_dual_mov_b32 v74, v76 :: v_dual_lshlrev_b32 v77, 16, v74 // 000000A05C2C: CA22014C 4A4C9490
	v_lshl_or_b32 v76, v83, 16, v82                            // 000000A05C34: D656004C 05492153
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A05C3C: BF870194
	v_dual_dot2acc_f32_f16 v48, v84, v34 :: v_dual_dot2acc_f32_f16 v49, v81, v36// 000000A05C40: CB184554 30304951
	v_and_or_b32 v75, 0xffff, v72, v77                         // 000000A05C48: D657004B 053690FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A05C54: BF870214
	.long 0xd73d0048                                           // 000000A05C58: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A05C5C: 0202933E
	v_pk_fma_f16 v73, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05C60: CC0E0049 0BFC0B4C 0000C931
	v_bfe_u32 v77, v78, 12, 16                                 // 000000A05C6C: D610004D 0241194E
	v_bfe_u32 v80, v78, 8, 16                                  // 000000A05C74: D6100050 0241114E
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05C7C: CC0E004F 0BFC0B4B 0000C931
	v_bfe_u32 v81, v78, 4, 16                                  // 000000A05C88: D6100051 0241094E
	v_bfe_u32 v74, v72, 12, 16                                 // 000000A05C90: D610004A 02411948
	v_bfe_u32 v75, v72, 8, 16                                  // 000000A05C98: D610004B 02411148
	v_bfe_u32 v76, v72, 4, 16                                  // 000000A05CA0: D610004C 02410948
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A05CA8: 369090FF 0000FFFF
	v_dot2acc_f32_f16 v48, v73, v35                            // 000000A05CB0: 04604749
	.long 0xd72c004a                                           // 000000A05CB4: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A05CB8: 020294FF 83DCD12D
	.long 0xd72c0053                                           // 000000A05CC0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A05CC4: 020296FF 83DCD12D
	.long 0xd72c0054                                           // 000000A05CCC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A05CD0: 020298FF 83DCD12D
	.long 0xd72c0052                                           // 000000A05CD8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A05CDC: 020290FF 83DCD12D
	ds_load_2addr_b32 v[72:73], v69 offset0:128 offset1:160    // 000000A05CE4: D8DCA080 48000045
	ds_load_2addr_b32 v[75:76], v68 offset0:128 offset1:160    // 000000A05CEC: D8DCA080 4B000044
	.long 0xd72c004d                                           // 000000A05CF4: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A05CF8: 02029AFF 83DCD12D
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A05D00: 369C9CFF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A05D08: D622004A 03FD014A 00006400
	.long 0xd72c0050                                           // 000000A05D14: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A05D18: 0202A0FF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A05D20: D6220053 03FD0153 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A05D2C: D6220052 03FD0152 00006400
	.long 0xd72c004e                                           // 000000A05D38: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A05D3C: 02029CFF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v74                             // 000000A05D44: 369494FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A05D4C: D6220054 03FD0154 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A05D58: D622004D 03FD014D 00006400
	v_lshlrev_b32_e32 v82, 16, v82                             // 000000A05D64: 30A4A490
	.long 0xd72c0051                                           // 000000A05D68: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A05D6C: 0202A2FF 83DCD12D
	v_lshl_or_b32 v83, v83, 16, v74                            // 000000A05D74: D6560053 05292153
	v_dot2acc_f32_f16 v48, v79, v36                            // 000000A05D7C: 0460494F
	v_sad_u8 v85, v78, 0, 0x6400                               // 000000A05D80: D6220055 03FD014E 00006400
	v_and_or_b32 v82, 0xffff, v84, v82                         // 000000A05D8C: D6570052 054AA8FF 0000FFFF
	v_and_b32_e32 v84, 0xffff, v77                             // 000000A05D98: 36A89AFF 0000FFFF
	ds_load_2addr_b32 v[77:78], v65 offset0:128 offset1:160    // 000000A05DA0: D8DCA080 4D000041
	s_waitcnt lgkmcnt(2)                                       // 000000A05DA8: BF89FC27
	v_mov_b32_e32 v74, v72                                     // 000000A05DAC: 7E940348
	v_sad_u8 v72, v80, 0, 0x6400                               // 000000A05DB0: D6220048 03FD0150 00006400
	v_sad_u8 v80, v81, 0, 0x6400                               // 000000A05DBC: D6220050 03FD0151 00006400
	v_lshlrev_b32_e32 v81, 16, v85                             // 000000A05DC8: 30A2AA90
	s_waitcnt lgkmcnt(1)                                       // 000000A05DCC: BF89FC17
	.long 0xd73d004a                                           // 000000A05DD0: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000A05DD4: 0202953E
	v_pk_fma_f16 v75, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05DD8: CC0E004B 0BFC0B53 0000C931
	v_lshl_or_b32 v72, v72, 16, v84                            // 000000A05DE4: D6560048 05512148
	v_and_or_b32 v79, 0xffff, v80, v81                         // 000000A05DEC: D657004F 0546A0FF 0000FFFF
	v_pk_fma_f16 v80, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05DF8: CC0E0050 0BFC0B52 0000C931
	v_bfe_u32 v81, v74, 12, 16                                 // 000000A05E04: D6100051 0241194A
	v_dot2acc_f32_f16 v47, v75, v33                            // 000000A05E0C: 045E434B
	v_pk_fma_f16 v75, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05E10: CC0E004B 0BFC0B48 0000C931
	v_and_b32_e32 v72, 0xffff, v74                             // 000000A05E1C: 369094FF 0000FFFF
	v_pk_fma_f16 v79, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05E24: CC0E004F 0BFC0B4F 0000C931
	.long 0xd72c0051                                           // 000000A05E30: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A05E34: 0202A2FF 83DCD12D
	v_dot2acc_f32_f16 v47, v80, v34                            // 000000A05E3C: 045E4550
	v_bfe_u32 v80, v74, 8, 16                                  // 000000A05E40: D6100050 0241114A
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A05E48: D610004A 0241094A
	.long 0xd72c0048                                           // 000000A05E50: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A05E54: 020290FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A05E5C: BF89FC07
	v_bfe_u32 v82, v77, 12, 16                                 // 000000A05E60: D6100052 0241194D
	v_bfe_u32 v83, v77, 8, 16                                  // 000000A05E68: D6100053 0241114D
	.long 0xd72c0050                                           // 000000A05E70: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A05E74: 0202A0FF 83DCD12D
	.long 0xd72c004a                                           // 000000A05E7C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A05E80: 020294FF 83DCD12D
	v_bfe_u32 v84, v77, 4, 16                                  // 000000A05E88: D6100054 0241094D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A05E90: 369A9AFF 0000FFFF
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A05E98: D6220051 03FD0151 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A05EA4: D6220048 03FD0148 00006400
	.long 0xd72c0052                                           // 000000A05EB0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A05EB4: 0202A4FF 83DCD12D
	.long 0xd72c0053                                           // 000000A05EBC: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A05EC0: 0202A6FF 83DCD12D
	.long 0xd72c004d                                           // 000000A05EC8: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A05ECC: 02029AFF 83DCD12D
	v_and_b32_e32 v81, 0xffff, v81                             // 000000A05ED4: 36A2A2FF 0000FFFF
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A05EDC: D6220050 03FD0150 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A05EE8: D622004A 03FD014A 00006400
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000A05EF4: 30909090
	.long 0xd72c0054                                           // 000000A05EF8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A05EFC: 0202A8FF 83DCD12D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A05F04: D6220052 03FD0152 00006400
	v_lshl_or_b32 v80, v80, 16, v81                            // 000000A05F10: D6560050 05452150
	v_dot2acc_f32_f16 v47, v75, v35                            // 000000A05F18: 045E474B
	v_and_or_b32 v81, 0xffff, v74, v72                         // 000000A05F1C: D6570051 052294FF 0000FFFF
	v_sad_u8 v72, v77, 0, 0x6400                               // 000000A05F28: D6220048 03FD014D 00006400
	v_mov_b32_e32 v74, v76                                     // 000000A05F34: 7E94034C
	v_sad_u8 v77, v83, 0, 0x6400                               // 000000A05F38: D622004D 03FD0153 00006400
	v_and_b32_e32 v76, 0xffff, v82                             // 000000A05F44: 3698A4FF 0000FFFF
	v_sad_u8 v82, v84, 0, 0x6400                               // 000000A05F4C: D6220052 03FD0154 00006400
	v_lshlrev_b32_e32 v83, 16, v72                             // 000000A05F58: 30A69090
	.long 0xd73d0048                                           // 000000A05F5C: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A05F60: 0202933E
	v_pk_fma_f16 v73, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05F64: CC0E0049 0BFC0B50 0000C931
	v_lshl_or_b32 v75, v77, 16, v76                            // 000000A05F70: D656004B 0531214D
	v_pk_fma_f16 v74, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05F78: CC0E004A 0BFC0B51 0000C931
	v_and_or_b32 v76, 0xffff, v82, v83                         // 000000A05F84: D657004C 054EA4FF 0000FFFF
	v_dot2acc_f32_f16 v47, v79, v36                            // 000000A05F90: 045E494F
	v_bfe_u32 v77, v72, 12, 16                                 // 000000A05F94: D610004D 02411948
	v_dot2acc_f32_f16 v46, v73, v33                            // 000000A05F9C: 045C4349
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05FA0: CC0E004F 0BFC0B4B 0000C931
	v_bfe_u32 v75, v72, 4, 16                                  // 000000A05FAC: D610004B 02410948
	v_pk_fma_f16 v80, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A05FB4: CC0E0050 0BFC0B4C 0000C931
	.long 0xd72c0049                                           // 000000A05FC0: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A05FC4: 02029AFF 83DCD12D
	v_dot2acc_f32_f16 v46, v74, v34                            // 000000A05FCC: 045C454A
	v_bfe_u32 v74, v72, 8, 16                                  // 000000A05FD0: D610004A 02411148
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A05FD8: 369090FF 0000FFFF
	v_bfe_u32 v76, v78, 12, 16                                 // 000000A05FE0: D610004C 0241194E
	v_bfe_u32 v77, v78, 8, 16                                  // 000000A05FE8: D610004D 0241114E
	v_bfe_u32 v81, v78, 4, 16                                  // 000000A05FF0: D6100051 0241094E
	.long 0xd72c004a                                           // 000000A05FF8: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A05FFC: 020294FF 83DCD12D
	v_sad_u8 v82, v73, 0, 0x6400                               // 000000A06004: D6220052 03FD0149 00006400
	.long 0xd72c0053                                           // 000000A06010: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A06014: 020290FF 83DCD12D
	ds_load_2addr_b32 v[72:73], v69 offset0:192 offset1:224    // 000000A0601C: D8DCE0C0 48000045
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A06024: 369C9CFF 0000FFFF
	.long 0xd72c0054                                           // 000000A0602C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A06030: 020298FF 83DCD12D
	.long 0xd72c0055                                           // 000000A06038: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A0603C: 020296FF 83DCD12D
	ds_load_2addr_b32 v[75:76], v68 offset0:192 offset1:224    // 000000A06044: D8DCE0C0 4B000044
	v_sad_u8 v86, v74, 0, 0x6400                               // 000000A0604C: D6220056 03FD014A 00006400
	.long 0xd72c004e                                           // 000000A06058: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0605C: 02029CFF 83DCD12D
	v_sad_u8 v74, v83, 0, 0x6400                               // 000000A06064: D622004A 03FD0153 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A06070: 36A4A4FF 0000FFFF
	.long 0xd72c0053                                           // 000000A06078: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0607C: 02029AFF 83DCD12D
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A06084: D6220054 03FD0154 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A06090: D6220055 03FD0155 00006400
	v_dual_dot2acc_f32_f16 v46, v79, v35 :: v_dual_lshlrev_b32 v87, 16, v74// 000000A0609C: CB22474F 2E569490
	v_sad_u8 v74, v78, 0, 0x6400                               // 000000A060A4: D622004A 03FD014E 00006400
	ds_load_2addr_b32 v[77:78], v65 offset0:192 offset1:224    // 000000A060B0: D8DCE0C0 4D000041
	v_and_b32_e32 v84, 0xffff, v84                             // 000000A060B8: 36A8A8FF 0000FFFF
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A060C0: D6220053 03FD0153 00006400
	.long 0xd72c0051                                           // 000000A060CC: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A060D0: 0202A2FF 83DCD12D
	v_lshlrev_b32_e32 v88, 16, v74                             // 000000A060D8: 30B09490
	s_waitcnt lgkmcnt(2)                                       // 000000A060DC: BF89FC27
	v_mov_b32_e32 v74, v72                                     // 000000A060E0: 7E940348
	v_lshl_or_b32 v72, v86, 16, v82                            // 000000A060E4: D6560048 05492156
	v_and_or_b32 v82, 0xffff, v85, v87                         // 000000A060EC: D6570052 055EAAFF 0000FFFF
	v_lshl_or_b32 v83, v83, 16, v84                            // 000000A060F8: D6560053 05512153
	s_waitcnt lgkmcnt(1)                                       // 000000A06100: BF89FC17
	.long 0xd73d004a                                           // 000000A06104: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000A06108: 0202953E
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0610C: CC0E0048 0BFC0B48 0000C931
	v_pk_fma_f16 v75, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A06118: CC0E004B 0BFC0B52 0000C931
	v_pk_fma_f16 v79, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A06124: CC0E004F 0BFC0B53 0000C931
	v_dot2acc_f32_f16 v46, v80, v36                            // 000000A06130: 045C4950
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A06134: D6220051 03FD0151 00006400
	v_bfe_u32 v82, v74, 12, 16                                 // 000000A06140: D6100052 0241194A
	v_dual_dot2acc_f32_f16 v45, v72, v33 :: v_dual_and_b32 v72, 0xffff, v74// 000000A06148: CB244348 2D4894FF 0000FFFF
	v_bfe_u32 v83, v74, 8, 16                                  // 000000A06154: D6100053 0241114A
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A0615C: D610004A 0241094A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A06164: BF870004
	.long 0xd72c0052                                           // 000000A06168: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0616C: 0202A4FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A06174: BF89FC07
	v_bfe_u32 v84, v77, 12, 16                                 // 000000A06178: D6100054 0241194D
	.long 0xd72c0048                                           // 000000A06180: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A06184: 020290FF 83DCD12D
	.long 0xd72c0053                                           // 000000A0618C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A06190: 0202A6FF 83DCD12D
	.long 0xd72c004a                                           // 000000A06198: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0619C: 020294FF 83DCD12D
	v_bfe_u32 v85, v77, 8, 16                                  // 000000A061A4: D6100055 0241114D
	.long 0xd72c0054                                           // 000000A061AC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A061B0: 0202A8FF 83DCD12D
	v_bfe_u32 v86, v77, 4, 16                                  // 000000A061B8: D6100056 0241094D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A061C0: D6220052 03FD0152 00006400
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A061CC: 369A9AFF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A061D4: D6220048 03FD0148 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A061E0: D6220053 03FD0153 00006400
	.long 0xd72c0055                                           // 000000A061EC: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A061F0: 0202AAFF 83DCD12D
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A061F8: 36A4A4FF 0000FFFF
	v_sad_u8 v87, v74, 0, 0x6400                               // 000000A06200: D6220057 03FD014A 00006400
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000A0620C: 30909090
	v_mov_b32_e32 v74, v76                                     // 000000A06210: 7E94034C
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A06214: D6220054 03FD0154 00006400
	v_lshl_or_b32 v82, v83, 16, v82                            // 000000A06220: D6560052 05492153
	v_dot2acc_f32_f16 v45, v75, v34                            // 000000A06228: 045A454B
	v_and_or_b32 v83, 0xffff, v87, v72                         // 000000A0622C: D6570053 0522AEFF 0000FFFF
	.long 0xd73d0048                                           // 000000A06238: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0623C: 0202933E
	v_and_b32_e32 v84, 0xffff, v84                             // 000000A06240: 36A8A8FF 0000FFFF
	v_sad_u8 v76, v85, 0, 0x6400                               // 000000A06248: D622004C 03FD0155 00006400
	v_pk_fma_f16 v75, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A06254: CC0E004B 0BFC0B52 0000C931
	.long 0xd72c004a                                           // 000000A06260: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A06264: 02029AFF 83DCD12D
	.long 0xd72c0055                                           // 000000A0626C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A06270: 0202ACFF 83DCD12D
	v_bfe_u32 v77, v72, 12, 16                                 // 000000A06278: D610004D 02411948
	v_lshl_or_b32 v73, v76, 16, v84                            // 000000A06280: D6560049 0551214C
	v_pk_fma_f16 v76, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A06288: CC0E004C 0BFC0B53 0000C931
	v_dot2acc_f32_f16 v44, v75, v33                            // 000000A06294: 0458434B
	v_bfe_u32 v84, v72, 8, 16                                  // 000000A06298: D6100054 02411148
	.long 0xd72c004d                                           // 000000A062A0: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A062A4: 02029AFF 83DCD12D
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A062AC: CC0E0049 0BFC0B49 0000C931
	v_sad_u8 v82, v85, 0, 0x6400                               // 000000A062B8: D6220052 03FD0155 00006400
	v_dual_dot2acc_f32_f16 v44, v76, v34 :: v_dual_and_b32 v83, 0xffff, v72// 000000A062C4: CB24454C 2C5290FF 0000FFFF
	.long 0xd72c0054                                           // 000000A062D0: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A062D4: 0202A8FF 83DCD12D
	v_bfe_u32 v72, v72, 4, 16                                  // 000000A062DC: D6100048 02410948
	v_bfe_u32 v85, v78, 12, 16                                 // 000000A062E4: D6100055 0241194E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A062EC: BF870004
	v_dot2acc_f32_f16 v44, v73, v35                            // 000000A062F0: 04584749
	.long 0xd72c0053                                           // 000000A062F4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A062F8: 0202A6FF 83DCD12D
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A06300: D622004D 03FD014D 00006400
	.long 0xd72c0048                                           // 000000A0630C: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A06310: 020290FF 83DCD12D
	v_bfe_u32 v86, v78, 8, 16                                  // 000000A06318: D6100056 0241114E
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A06320: D6220054 03FD0154 00006400
	v_bfe_u32 v87, v78, 4, 16                                  // 000000A0632C: D6100057 0241094E
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A06334: 369A9AFF 0000FFFF
	.long 0xd72c0055                                           // 000000A0633C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A06340: 0202AAFF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A06348: D6220053 03FD0153 00006400
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A06354: 369C9CFF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A0635C: D622004A 03FD014A 00006400
	v_lshl_or_b32 v77, v84, 16, v77                            // 000000A06368: D656004D 05352154
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A06370: D6220048 03FD0148 00006400
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000A0637C: 30A6A690
	.long 0xd72c0056                                           // 000000A06380: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A06384: 0202ACFF 83DCD12D
	.long 0xd72c004e                                           // 000000A0638C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A06390: 02029CFF 83DCD12D
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A06398: D6220055 03FD0155 00006400
	v_lshlrev_b32_e32 v74, 16, v74                             // 000000A063A4: 30949490
	v_pk_fma_f16 v77, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A063A8: CC0E004D 0BFC0B4D 0000C931
	v_and_or_b32 v72, 0xffff, v72, v83                         // 000000A063B4: D6570048 054E90FF 0000FFFF
	.long 0xd72c0053                                           // 000000A063C0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A063C4: 0202AEFF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v85                             // 000000A063CC: 36A8AAFF 0000FFFF
	v_sad_u8 v85, v86, 0, 0x6400                               // 000000A063D4: D6220055 03FD0156 00006400
	v_sad_u8 v75, v78, 0, 0x6400                               // 000000A063E0: D622004B 03FD014E 00006400
	v_dot2acc_f32_f16 v58, v77, v33                            // 000000A063EC: 0474434D
	v_and_or_b32 v33, 0xffff, v82, v74                         // 000000A063F0: D6570021 052AA4FF 0000FFFF
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A063FC: CC0E0048 0BFC0B48 0000C931
	v_lshl_or_b32 v78, v85, 16, v84                            // 000000A06408: D656004E 05512155
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A06410: D6220053 03FD0153 00006400
	v_and_or_b32 v81, 0xffff, v81, v88                         // 000000A0641C: D6570051 0562A2FF 0000FFFF
	v_pk_fma_f16 v33, v33, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A06428: CC0E0021 0BFC0B21 0000C931
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000A06434: 30969690
	v_pk_fma_f16 v74, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A06438: CC0E004A 0BFC0B4E 0000C931
	v_dot2acc_f32_f16 v58, v72, v34                            // 000000A06444: 04744548
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A06448: CC0E0051 0BFC0B51 0000C931
	v_dot2acc_f32_f16 v44, v33, v36                            // 000000A06454: 04584921
	v_and_or_b32 v75, 0xffff, v83, v75                         // 000000A06458: D657004B 052EA6FF 0000FFFF
	v_dot2acc_f32_f16 v45, v79, v35                            // 000000A06464: 045A474F
	v_dot2acc_f32_f16 v58, v74, v35                            // 000000A06468: 0474474A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0646C: BF870223
	v_pk_fma_f16 v34, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A06470: CC0E0022 0BFC0B4B 0000C931
	v_add_nc_u32_e32 v35, 1, v71                               // 000000A0647C: 4A468E81
	v_dot2acc_f32_f16 v45, v81, v36                            // 000000A06480: 045A4951
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A06484: BF870193
	v_dot2acc_f32_f16 v58, v34, v36                            // 000000A06488: 04744922
	.long 0xd4c9007e                                           // 000000A0648C: D4C9007E
	v_cndmask_b32_e32 v1, v35, v43, vcc_lo                     // 000000A06490: 02025723
	s_cbranch_execz 63753                                      // 000000A06494: BFA5F909 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x45bc>
	v_add_nc_u32_e32 v36, 3, v71                               // 000000A06498: 4A488E83
	s_mov_b32 s7, exec_lo                                      // 000000A0649C: BE87007E
	ds_store_2addr_b32 v64, v1, v2 offset1:32                  // 000000A064A0: D8382000 00020140
	ds_store_2addr_b32 v64, v3, v4 offset0:64 offset1:96       // 000000A064A8: D8386040 00040340
	ds_store_2addr_b32 v64, v5, v6 offset0:128 offset1:160     // 000000A064B0: D838A080 00060540
	ds_store_2addr_b32 v64, v7, v8 offset0:192 offset1:224     // 000000A064B8: D838E0C0 00080740
	ds_store_2addr_b32 v65, v9, v10 offset1:32                 // 000000A064C0: D8382000 000A0941
	ds_store_2addr_b32 v65, v11, v12 offset0:64 offset1:96     // 000000A064C8: D8386040 000C0B41
	ds_store_2addr_b32 v65, v13, v14 offset0:128 offset1:160   // 000000A064D0: D838A080 000E0D41
	ds_store_2addr_b32 v65, v15, v16 offset0:192 offset1:224   // 000000A064D8: D838E0C0 00100F41
	.long 0xd4c9007e                                           // 000000A064E0: D4C9007E
	v_cndmask_b32_e32 v1, v36, v43, vcc_lo                     // 000000A064E4: 02025724
	s_cbranch_execz 62032                                      // 000000A064E8: BFA5F250 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2b2c>
	.long 0xd73c0001                                           // 000000A064EC: D73C0001
	v_cndmask_b32_e32 v1, 11, v36, vcc_lo                      // 000000A064F0: 0202488B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A064F4: BF870091
	.long 0xd7000021                                           // 000000A064F8: D7000021
	v_cndmask_b32_e32 v1, v60, v1, vcc_lo                      // 000000A064FC: 0202033C
	v_add_co_ci_u32_e64 v34, null, v61, v2, s0                 // 000000A06500: D5207C22 0002053D
	s_clause 0xf                                               // 000000A06508: BF85000F
	global_load_b32 v1, v[33:34], off                          // 000000A0650C: DC520000 017C0021
	global_load_b32 v2, v[33:34], off offset:128               // 000000A06514: DC520080 027C0021
	global_load_b32 v3, v[33:34], off offset:256               // 000000A0651C: DC520100 037C0021
	global_load_b32 v4, v[33:34], off offset:384               // 000000A06524: DC520180 047C0021
	global_load_b32 v5, v[33:34], off offset:512               // 000000A0652C: DC520200 057C0021
	global_load_b32 v6, v[33:34], off offset:640               // 000000A06534: DC520280 067C0021
	global_load_b32 v7, v[33:34], off offset:768               // 000000A0653C: DC520300 077C0021
	global_load_b32 v8, v[33:34], off offset:896               // 000000A06544: DC520380 087C0021
	global_load_b32 v9, v[33:34], off offset:1024              // 000000A0654C: DC520400 097C0021
	global_load_b32 v10, v[33:34], off offset:1152             // 000000A06554: DC520480 0A7C0021
	global_load_b32 v11, v[33:34], off offset:1280             // 000000A0655C: DC520500 0B7C0021
	global_load_b32 v12, v[33:34], off offset:1408             // 000000A06564: DC520580 0C7C0021
	global_load_b32 v13, v[33:34], off offset:1536             // 000000A0656C: DC520600 0D7C0021
	global_load_b32 v14, v[33:34], off offset:1664             // 000000A06574: DC520680 0E7C0021
	global_load_b32 v15, v[33:34], off offset:1792             // 000000A0657C: DC520700 0F7C0021
	global_load_b32 v16, v[33:34], off offset:1920             // 000000A06584: DC520780 107C0021
	s_branch 61991                                             // 000000A0658C: BFA0F227 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2b2c>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A06590: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A06594: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A06598: 8C7E037E
	s_waitcnt vmcnt(14)                                        // 000000A0659C: BF893BF7
	v_dual_mov_b32 v1, v59 :: v_dual_mov_b32 v2, v57           // 000000A065A0: CA10013B 01020139
	s_waitcnt vmcnt(12)                                        // 000000A065A8: BF8933F7
	v_dual_mov_b32 v3, v56 :: v_dual_mov_b32 v4, v55           // 000000A065AC: CA100138 03040137
	s_waitcnt vmcnt(10)                                        // 000000A065B4: BF892BF7
	v_dual_mov_b32 v5, v54 :: v_dual_mov_b32 v6, v53           // 000000A065B8: CA100136 05060135
	s_waitcnt vmcnt(8)                                         // 000000A065C0: BF8923F7
	v_dual_mov_b32 v7, v52 :: v_dual_mov_b32 v8, v51           // 000000A065C4: CA100134 07080133
	s_waitcnt vmcnt(6)                                         // 000000A065CC: BF891BF7
	v_dual_mov_b32 v9, v50 :: v_dual_mov_b32 v10, v49          // 000000A065D0: CA100132 090A0131
	s_waitcnt vmcnt(4)                                         // 000000A065D8: BF8913F7
	v_dual_mov_b32 v11, v48 :: v_dual_mov_b32 v12, v47         // 000000A065DC: CA100130 0B0C012F
	s_waitcnt vmcnt(2)                                         // 000000A065E4: BF890BF7
	v_dual_mov_b32 v13, v46 :: v_dual_mov_b32 v14, v45         // 000000A065E8: CA10012E 0D0E012D
	s_waitcnt vmcnt(0)                                         // 000000A065F0: BF8903F7
	v_dual_mov_b32 v15, v44 :: v_dual_mov_b32 v16, v58         // 000000A065F4: CA10012C 0F10013A
	s_mov_b32 s0, 0x76543210                                   // 000000A065FC: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A06604: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000A06608: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A06614: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A06620: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A0662C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A06638: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A06644: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000A06650: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000A0665C: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000A06668: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A06674: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000A06680: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000A0668C: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000A06698: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000A066A4: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000A066B0: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000A066BC: D65C0010 03FC0110 FEDCBA98
	.long 0xd44c0000                                           // 000000A066C8: D44C0000
	v_cndmask_b32_e32 v1, 16, v41, vcc_lo                      // 000000A066CC: 02025290
	s_barrier                                                  // 000000A066D0: BFBD0000
	buffer_gl0_inv                                             // 000000A066D4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000A066DC: BE832000
	s_cbranch_execz 34                                         // 000000A066E0: BFA50022 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x646c>
	v_dual_add_f32 v16, v58, v16 :: v_dual_add_f32 v1, v59, v1 // 000000A066E4: C908213A 1000033B
	v_dual_add_f32 v2, v57, v2 :: v_dual_add_f32 v3, v56, v3   // 000000A066EC: C9080539 02020738
	v_lshl_or_b32 v17, v40, 10, v42                            // 000000A066F4: D6560011 04A91528
	v_dual_add_f32 v4, v55, v4 :: v_dual_add_f32 v5, v54, v5   // 000000A066FC: C9080937 04040B36
	v_dual_add_f32 v6, v53, v6 :: v_dual_add_f32 v7, v52, v7   // 000000A06704: C9080D35 06060F34
	v_dual_add_f32 v8, v51, v8 :: v_dual_add_f32 v9, v50, v9   // 000000A0670C: C9081133 08081332
	v_dual_add_f32 v10, v49, v10 :: v_dual_add_f32 v11, v48, v11// 000000A06714: C9081531 0A0A1730
	v_dual_add_f32 v12, v47, v12 :: v_dual_add_f32 v13, v46, v13// 000000A0671C: C908192F 0C0C1B2E
	v_dual_add_f32 v14, v45, v14 :: v_dual_add_f32 v15, v44, v15// 000000A06724: C9081D2D 0E0E1F2C
	ds_store_2addr_b32 v17, v1, v2 offset1:16                  // 000000A0672C: D8381000 00020111
	ds_store_2addr_b32 v17, v3, v4 offset0:32 offset1:48       // 000000A06734: D8383020 00040311
	ds_store_2addr_b32 v17, v5, v6 offset0:64 offset1:80       // 000000A0673C: D8385040 00060511
	ds_store_2addr_b32 v17, v7, v8 offset0:96 offset1:112      // 000000A06744: D8387060 00080711
	ds_store_2addr_b32 v17, v9, v10 offset0:128 offset1:144    // 000000A0674C: D8389080 000A0911
	ds_store_2addr_b32 v17, v11, v12 offset0:160 offset1:176   // 000000A06754: D838B0A0 000C0B11
	ds_store_2addr_b32 v17, v13, v14 offset0:192 offset1:208   // 000000A0675C: D838D0C0 000E0D11
	ds_store_2addr_b32 v17, v15, v16 offset0:224 offset1:240   // 000000A06764: D838F0E0 00100F11
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A0676C: 8C7E037E
	s_waitcnt lgkmcnt(0)                                       // 000000A06770: BF89FC07
	s_barrier                                                  // 000000A06774: BFBD0000
	buffer_gl0_inv                                             // 000000A06778: E0AC0000 00000000
	s_mov_b32 s3, exec_lo                                      // 000000A06780: BE83007E
	v_cmpx_eq_u32_e32 0, v40                                   // 000000A06784: 7D945080
	s_cbranch_execz 1332                                       // 000000A06788: BFA50534 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x795c>
	v_and_b32_e32 v3, 15, v0                                   // 000000A0678C: 3606008F
	s_mul_i32 s3, s1, 0xa00                                    // 000000A06790: 9603FF01 00000A00
	s_mul_hi_i32 s4, s1, 0xa00                                 // 000000A06798: 9704FF01 00000A00
	s_add_u32 s5, s18, s3                                      // 000000A067A0: 80050312
	s_addc_u32 s4, s19, s4                                     // 000000A067A4: 82040413
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000A067A8: 30080682
	s_lshl_b32 s2, s2, 7                                       // 000000A067AC: 84028702
	ds_load_2addr_b32 v[1:2], v4 offset1:16                    // 000000A067B0: D8DC1000 01000004
	ds_load_2addr_b32 v[5:6], v4 offset0:128 offset1:144       // 000000A067B8: D8DC9080 05000004
	s_ashr_i32 s3, s2, 31                                      // 000000A067C0: 86039F02
	v_lshlrev_b32_e32 v52, 1, v0                               // 000000A067C4: 30680081
	s_lshl_b64 s[12:13], s[2:3], 1                             // 000000A067C8: 848C8102
	s_mul_i32 s2, s1, 0x500                                    // 000000A067CC: 9602FF01 00000500
	s_add_u32 s6, s5, s12                                      // 000000A067D4: 80060C05
	s_addc_u32 s7, s4, s13                                     // 000000A067D8: 82070D04
	s_mul_hi_i32 s1, s1, 0x500                                 // 000000A067DC: 9701FF01 00000500
	s_add_u32 s2, s20, s2                                      // 000000A067E4: 80020214
	s_addc_u32 s1, s21, s1                                     // 000000A067E8: 82010115
	s_add_u32 s8, s2, s12                                      // 000000A067EC: 80080C02
	s_addc_u32 s9, s1, s13                                     // 000000A067F0: 82090D01
	s_waitcnt lgkmcnt(1)                                       // 000000A067F4: BF89FC17
	v_add_f32_e32 v1, 0, v1                                    // 000000A067F8: 06020280
	v_add_nc_u32_e32 v45, 0x400, v4                            // 000000A067FC: 4A5A08FF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000A06804: BF89FC07
	v_dual_add_f32 v5, 0, v5 :: v_dual_add_nc_u32 v46, 0x800, v4// 000000A06808: C9200A80 052E08FF 00000800
	v_add_nc_u32_e32 v47, 0xc00, v4                            // 000000A06814: 4A5E08FF 00000C00
	v_add_nc_u32_e32 v48, 0x1000, v4                           // 000000A0681C: 4A6008FF 00001000
	v_add_nc_u32_e32 v49, 0x1400, v4                           // 000000A06824: 4A6208FF 00001400
	v_add_nc_u32_e32 v50, 0x1800, v4                           // 000000A0682C: 4A6408FF 00001800
	v_add_nc_u32_e32 v51, 0x1c00, v4                           // 000000A06834: 4A6608FF 00001C00
	ds_load_2addr_b32 v[7:8], v45 offset1:16                   // 000000A0683C: D8DC1000 0700002D
	ds_load_2addr_b32 v[9:10], v4 offset0:32 offset1:48        // 000000A06844: D8DC3020 09000004
	ds_load_2addr_b32 v[11:12], v4 offset0:160 offset1:176     // 000000A0684C: D8DCB0A0 0B000004
	ds_load_2addr_b32 v[13:14], v45 offset0:128 offset1:144    // 000000A06854: D8DC9080 0D00002D
	ds_load_2addr_b32 v[15:16], v46 offset1:16                 // 000000A0685C: D8DC1000 0F00002E
	ds_load_2addr_b32 v[17:18], v46 offset0:128 offset1:144    // 000000A06864: D8DC9080 1100002E
	ds_load_2addr_b32 v[19:20], v47 offset1:16                 // 000000A0686C: D8DC1000 1300002F
	ds_load_2addr_b32 v[21:22], v47 offset0:128 offset1:144    // 000000A06874: D8DC9080 1500002F
	ds_load_2addr_b32 v[23:24], v48 offset1:16                 // 000000A0687C: D8DC1000 17000030
	ds_load_2addr_b32 v[25:26], v48 offset0:128 offset1:144    // 000000A06884: D8DC9080 19000030
	ds_load_2addr_b32 v[27:28], v49 offset1:16                 // 000000A0688C: D8DC1000 1B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:128 offset1:144    // 000000A06894: D8DC9080 1D000031
	ds_load_2addr_b32 v[31:32], v50 offset1:16                 // 000000A0689C: D8DC1000 1F000032
	ds_load_2addr_b32 v[33:34], v50 offset0:128 offset1:144    // 000000A068A4: D8DC9080 21000032
	ds_load_2addr_b32 v[35:36], v51 offset1:16                 // 000000A068AC: D8DC1000 23000033
	v_add_f32_e32 v2, 0, v2                                    // 000000A068B4: 06040480
	ds_load_2addr_b32 v[43:44], v46 offset0:32 offset1:48      // 000000A068B8: D8DC3020 2B00002E
	s_waitcnt lgkmcnt(15)                                      // 000000A068C0: BF89FCF7
	v_add_f32_e32 v1, v1, v7                                   // 000000A068C4: 06020F01
	v_dual_add_f32 v7, 0, v6 :: v_dual_add_f32 v2, v2, v8      // 000000A068C8: C9080C80 07021102
	s_waitcnt lgkmcnt(12)                                      // 000000A068D0: BF89FCC7
	v_add_f32_e32 v13, v5, v13                                 // 000000A068D4: 061A1B05
	ds_load_2addr_b32 v[5:6], v46 offset0:160 offset1:176      // 000000A068D8: D8DCB0A0 0500002E
	s_waitcnt lgkmcnt(12)                                      // 000000A068E0: BF89FCC7
	v_dual_add_f32 v1, v1, v15 :: v_dual_add_f32 v14, v7, v14  // 000000A068E4: C9081F01 010E1D07
	s_waitcnt lgkmcnt(11)                                      // 000000A068EC: BF89FCB7
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v13, v13, v17 // 000000A068F0: C9082102 020C230D
	ds_load_2addr_b32 v[15:16], v48 offset0:32 offset1:48      // 000000A068F8: D8DC3020 0F000030
	v_add_f32_e32 v14, v14, v18                                // 000000A06900: 061C250E
	s_waitcnt lgkmcnt(11)                                      // 000000A06904: BF89FCB7
	v_dual_add_f32 v2, v2, v20 :: v_dual_add_f32 v1, v1, v19   // 000000A06908: C9082902 02002701
	ds_load_2addr_b32 v[7:8], v47 offset0:32 offset1:48        // 000000A06910: D8DC3020 0700002F
	ds_load_2addr_b32 v[17:18], v48 offset0:160 offset1:176    // 000000A06918: D8DCB0A0 11000030
	s_waitcnt lgkmcnt(12)                                      // 000000A06920: BF89FCC7
	v_add_f32_e32 v14, v14, v22                                // 000000A06924: 061C2D0E
	s_waitcnt lgkmcnt(11)                                      // 000000A06928: BF89FCB7
	v_dual_add_f32 v2, v2, v24 :: v_dual_add_f32 v1, v1, v23   // 000000A0692C: C9083102 02002F01
	ds_load_2addr_b32 v[19:20], v49 offset0:32 offset1:48      // 000000A06934: D8DC3020 13000031
	s_waitcnt lgkmcnt(11)                                      // 000000A0693C: BF89FCB7
	v_add_f32_e32 v14, v14, v26                                // 000000A06940: 061C350E
	ds_load_2addr_b32 v[37:38], v51 offset0:128 offset1:144    // 000000A06944: D8DC9080 25000033
	ds_load_2addr_b32 v[39:40], v45 offset0:32 offset1:48      // 000000A0694C: D8DC3020 2700002D
	ds_load_2addr_b32 v[41:42], v45 offset0:160 offset1:176    // 000000A06954: D8DCB0A0 2900002D
	v_add_f32_e32 v13, v13, v21                                // 000000A0695C: 061A2B0D
	s_waitcnt lgkmcnt(13)                                      // 000000A06960: BF89FCD7
	v_add_f32_e32 v1, v1, v27                                  // 000000A06964: 06023701
	v_add_f32_e32 v23, v2, v28                                 // 000000A06968: 062E3902
	s_waitcnt lgkmcnt(12)                                      // 000000A0696C: BF89FCC7
	v_dual_add_f32 v24, v14, v30 :: v_dual_add_f32 v9, 0, v9   // 000000A06970: C9083D0E 18081280
	ds_load_2addr_b32 v[21:22], v49 offset0:160 offset1:176    // 000000A06978: D8DCB0A0 15000031
	v_add_f32_e32 v11, 0, v11                                  // 000000A06980: 06161680
	s_waitcnt lgkmcnt(11)                                      // 000000A06984: BF89FCB7
	v_dual_add_f32 v1, v1, v31 :: v_dual_add_f32 v26, v24, v34 // 000000A06988: C9083F01 011A4518
	s_waitcnt lgkmcnt(3)                                       // 000000A06990: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A06994: BF870001
	v_dual_add_f32 v13, v13, v25 :: v_dual_add_f32 v54, v26, v38// 000000A06998: C908330D 0D364D1A
	s_waitcnt lgkmcnt(2)                                       // 000000A069A0: BF89FC27
	v_add_f32_e32 v9, v9, v39                                  // 000000A069A4: 06124F09
	v_add_f32_e32 v39, v1, v35                                 // 000000A069A8: 064E4701
	v_lshlrev_b32_e32 v1, 1, v3                                // 000000A069AC: 30020681
	s_waitcnt lgkmcnt(1)                                       // 000000A069B0: BF89FC17
	v_add_f32_e32 v3, v11, v41                                 // 000000A069B4: 0606530B
	v_add_f32_e32 v11, v23, v32                                // 000000A069B8: 06164117
	v_add_f32_e32 v9, v9, v43                                  // 000000A069BC: 06125709
	ds_load_2addr_b32 v[23:24], v50 offset0:32 offset1:48      // 000000A069C0: D8DC3020 17000032
	v_or_b32_e32 v41, 32, v52                                  // 000000A069C8: 385268A0
	v_add_f32_e32 v5, v3, v5                                   // 000000A069CC: 060A0B03
	v_add_f32_e32 v53, v11, v36                                // 000000A069D0: 066A490B
	v_add_f32_e32 v7, v9, v7                                   // 000000A069D4: 060E0F09
	global_load_d16_b16 v3, v41, s[6:7]                        // 000000A069D8: DC820000 03060029
	v_add_f32_e32 v7, v7, v15                                  // 000000A069E0: 060E1F07
	v_add_f32_e32 v15, 0, v12                                  // 000000A069E4: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:192 offset1:208     // 000000A069E8: D8DCD0C0 0B000004
	ds_load_2addr_b32 v[27:28], v51 offset0:32 offset1:48      // 000000A069F0: D8DC3020 1B000033
	v_add_f32_e32 v7, v7, v19                                  // 000000A069F8: 060E2707
	s_waitcnt lgkmcnt(2)                                       // 000000A069FC: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A06A00: BF870001
	v_add_f32_e32 v19, v7, v23                                 // 000000A06A04: 06262F07
	v_add_f32_e32 v13, v13, v29                                // 000000A06A08: 061A3B0D
	ds_load_2addr_b32 v[29:30], v45 offset0:64 offset1:80      // 000000A06A0C: D8DC5040 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:192 offset1:208    // 000000A06A14: D8DCD0C0 1F00002D
	v_add_f32_e32 v25, v13, v33                                // 000000A06A1C: 0632430D
	ds_load_2addr_b32 v[13:14], v47 offset0:160 offset1:176    // 000000A06A20: D8DCB0A0 0D00002F
	s_waitcnt lgkmcnt(4)                                       // 000000A06A28: BF89FC47
	v_add_f32_e32 v11, 0, v11                                  // 000000A06A2C: 06161680
	v_add_f32_e32 v43, v25, v37                                // 000000A06A30: 06564B19
	ds_load_2addr_b32 v[25:26], v50 offset0:160 offset1:176    // 000000A06A34: D8DCB0A0 19000032
	ds_load_2addr_b32 v[37:38], v48 offset0:192 offset1:208    // 000000A06A3C: D8DCD0C0 25000030
	s_waitcnt lgkmcnt(3)                                       // 000000A06A44: BF89FC37
	v_add_f32_e32 v11, v11, v31                                // 000000A06A48: 06163F0B
	s_waitcnt lgkmcnt(2)                                       // 000000A06A4C: BF89FC27
	v_add_f32_e32 v5, v5, v13                                  // 000000A06A50: 060A1B05
	v_add_f32_e32 v13, 0, v10                                  // 000000A06A54: 061A1480
	ds_load_2addr_b32 v[9:10], v4 offset0:64 offset1:80        // 000000A06A58: D8DC5040 09000004
	v_add_f32_e32 v5, v5, v17                                  // 000000A06A60: 060A2305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A06A64: BF8701C1
	v_add_f32_e32 v17, v5, v21                                 // 000000A06A68: 06222B05
	v_add_f32_e32 v5, v13, v40                                 // 000000A06A6C: 060A510D
	v_add_f32_e32 v13, v15, v42                                // 000000A06A70: 061A550F
	s_waitcnt lgkmcnt(2)                                       // 000000A06A74: BF89FC27
	v_dual_add_f32 v40, v19, v27 :: v_dual_add_f32 v21, v17, v25// 000000A06A78: C9083713 28143311
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A06A80: BF870193
	v_add_f32_e32 v7, v5, v44                                  // 000000A06A84: 060E5905
	v_add_f32_e32 v13, v13, v6                                 // 000000A06A88: 061A0D0D
	ds_load_2addr_b32 v[5:6], v46 offset0:64 offset1:80        // 000000A06A8C: D8DC5040 0500002E
	ds_load_2addr_b32 v[33:34], v46 offset0:192 offset1:208    // 000000A06A94: D8DCD0C0 2100002E
	ds_load_2addr_b32 v[35:36], v51 offset0:160 offset1:176    // 000000A06A9C: D8DCB0A0 23000033
	v_add_f32_e32 v15, v7, v8                                  // 000000A06AA4: 061E1107
	ds_load_2addr_b32 v[7:8], v47 offset0:64 offset1:80        // 000000A06AA8: D8DC5040 0700002F
	v_add_f32_e32 v17, v13, v14                                // 000000A06AB0: 06221D0D
	ds_load_2addr_b32 v[13:14], v47 offset0:192 offset1:208    // 000000A06AB4: D8DCD0C0 0D00002F
	s_waitcnt lgkmcnt(5)                                       // 000000A06ABC: BF89FC57
	v_add_f32_e32 v9, 0, v9                                    // 000000A06AC0: 06121280
	v_add_f32_e32 v23, v15, v16                                // 000000A06AC4: 062E210F
	ds_load_2addr_b32 v[15:16], v48 offset0:64 offset1:80      // 000000A06AC8: D8DC5040 0F000030
	v_add_f32_e32 v17, v17, v18                                // 000000A06AD0: 06222511
	v_add_f32_e32 v9, v9, v29                                  // 000000A06AD4: 06123B09
	v_add_f32_e32 v23, v23, v20                                // 000000A06AD8: 062E2917
	ds_load_2addr_b32 v[19:20], v49 offset0:192 offset1:208    // 000000A06ADC: D8DCD0C0 13000031
	v_add_f32_e32 v22, v17, v22                                // 000000A06AE4: 062C2D11
	ds_load_2addr_b32 v[17:18], v49 offset0:64 offset1:80      // 000000A06AE8: D8DC5040 11000031
	s_waitcnt lgkmcnt(7)                                       // 000000A06AF0: BF89FC77
	v_add_f32_e32 v5, v9, v5                                   // 000000A06AF4: 060A0B09
	s_waitcnt lgkmcnt(5)                                       // 000000A06AF8: BF89FC57
	v_dual_add_f32 v9, v11, v33 :: v_dual_add_f32 v42, v21, v35// 000000A06AFC: C908430B 092A4715
	v_add_f32_e32 v27, v23, v24                                // 000000A06B04: 06363117
	v_add_f32_e32 v33, v22, v26                                // 000000A06B08: 06423516
	ds_load_2addr_b32 v[21:22], v50 offset0:64 offset1:80      // 000000A06B0C: D8DC5040 15000032
	ds_load_2addr_b32 v[23:24], v50 offset0:192 offset1:208    // 000000A06B14: D8DCD0C0 17000032
	s_waitcnt lgkmcnt(6)                                       // 000000A06B1C: BF89FC67
	v_add_f32_e32 v5, v5, v7                                   // 000000A06B20: 060A0F05
	s_waitcnt lgkmcnt(5)                                       // 000000A06B24: BF89FC57
	v_add_f32_e32 v7, v9, v13                                  // 000000A06B28: 060E1B09
	s_waitcnt lgkmcnt(4)                                       // 000000A06B2C: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A06B30: BF870002
	v_add_f32_e32 v13, v5, v15                                 // 000000A06B34: 061A1F05
	v_add_f32_e32 v5, 0, v10                                   // 000000A06B38: 060A1480
	ds_load_2addr_b32 v[9:10], v51 offset0:64 offset1:80       // 000000A06B3C: D8DC5040 09000033
	ds_load_2addr_b32 v[25:26], v51 offset0:192 offset1:208    // 000000A06B44: D8DCD0C0 19000033
	v_add_f32_e32 v7, v7, v37                                  // 000000A06B4C: 060E4B07
	v_add_f32_e32 v15, 0, v12                                  // 000000A06B50: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:96 offset1:112      // 000000A06B54: D8DC7060 0B000004
	v_add_f32_e32 v31, v5, v30                                 // 000000A06B5C: 063E3D05
	ds_load_2addr_b32 v[29:30], v4 offset0:224 offset1:240     // 000000A06B60: D8DCF0E0 1D000004
	s_waitcnt lgkmcnt(6)                                       // 000000A06B68: BF89FC67
	v_dual_add_f32 v13, v13, v17 :: v_dual_add_f32 v4, v15, v32// 000000A06B6C: C908230D 0D04410F
	v_add_f32_e32 v15, v7, v19                                 // 000000A06B74: 061E2707
	v_add_f32_e32 v17, v31, v6                                 // 000000A06B78: 06220D1F
	ds_load_2addr_b32 v[6:7], v45 offset0:96 offset1:112       // 000000A06B7C: D8DC7060 0600002D
	ds_load_2addr_b32 v[31:32], v45 offset0:224 offset1:240    // 000000A06B84: D8DCF0E0 1F00002D
	s_waitcnt lgkmcnt(7)                                       // 000000A06B8C: BF89FC77
	v_dual_add_f32 v13, v13, v21 :: v_dual_add_f32 v4, v4, v34 // 000000A06B90: C9082B0D 0D044504
	s_waitcnt lgkmcnt(6)                                       // 000000A06B98: BF89FC67
	v_dual_add_f32 v15, v15, v23 :: v_dual_add_f32 v8, v17, v8 // 000000A06B9C: C9082F0F 0F081111
	s_clause 0x1                                               // 000000A06BA4: BF850001
	global_load_d16_b16 v2, v1, s[6:7]                         // 000000A06BA8: DC820000 02060001
	global_load_d16_b16 v5, v1, s[6:7] offset:64               // 000000A06BB0: DC820040 05060001
	v_dual_add_f32 v4, v4, v14 :: v_dual_add_f32 v37, v27, v28 // 000000A06BB8: C9081D04 0424391B
	s_waitcnt lgkmcnt(5)                                       // 000000A06BC0: BF89FC57
	v_add_f32_e32 v23, v13, v9                                 // 000000A06BC4: 062E130D
	s_waitcnt lgkmcnt(4)                                       // 000000A06BC8: BF89FC47
	v_dual_add_f32 v25, v15, v25 :: v_dual_add_f32 v8, v8, v16 // 000000A06BCC: C908330F 19082108
	ds_load_2addr_b32 v[13:14], v46 offset0:96 offset1:112     // 000000A06BD4: D8DC7060 0D00002E
	ds_load_2addr_b32 v[15:16], v46 offset0:224 offset1:240    // 000000A06BDC: D8DCF0E0 0F00002E
	v_add_f32_e32 v9, v4, v38                                  // 000000A06BE4: 06124D04
	s_waitcnt lgkmcnt(5)                                       // 000000A06BE8: BF89FC57
	v_add_f32_e32 v11, 0, v11                                  // 000000A06BEC: 06161680
	s_waitcnt lgkmcnt(4)                                       // 000000A06BF0: BF89FC47
	v_dual_add_f32 v17, 0, v29 :: v_dual_add_f32 v38, v8, v18  // 000000A06BF4: C9083A80 11262508
	v_add_f32_e32 v21, v33, v36                                // 000000A06BFC: 062A4921
	v_add_f32_e32 v44, v9, v20                                 // 000000A06C00: 06582909
	s_waitcnt lgkmcnt(2)                                       // 000000A06C04: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A06C08: BF870003
	v_dual_add_f32 v8, v11, v6 :: v_dual_add_f32 v11, v17, v31 // 000000A06C0C: C9080D0B 080A3F11
	ds_load_2addr_b32 v[17:18], v47 offset0:96 offset1:112     // 000000A06C14: D8DC7060 1100002F
	ds_load_2addr_b32 v[19:20], v47 offset0:224 offset1:240    // 000000A06C1C: D8DCF0E0 1300002F
	ds_load_2addr_b32 v[27:28], v48 offset0:96 offset1:112     // 000000A06C24: D8DC7060 1B000030
	ds_load_2addr_b32 v[33:34], v48 offset0:224 offset1:240    // 000000A06C2C: D8DCF0E0 21000030
	v_add_f32_e32 v31, 0, v12                                  // 000000A06C34: 063E1880
	v_add_f32_e32 v35, 0, v30                                  // 000000A06C38: 06463C80
	s_clause 0x1                                               // 000000A06C3C: BF850001
	global_load_d16_b16 v6, v41, s[6:7] offset:1280            // 000000A06C40: DC820500 06060029
	global_load_d16_b16 v4, v1, s[6:7] offset:1280             // 000000A06C48: DC820500 04060001
	v_or_b32_e32 v45, 0x60, v52                                // 000000A06C50: 385A68FF 00000060
	v_add_f32_e32 v7, v31, v7                                  // 000000A06C58: 060E0F1F
	s_waitcnt lgkmcnt(5)                                       // 000000A06C5C: BF89FC57
	v_add_f32_e32 v13, v8, v13                                 // 000000A06C60: 061A1B08
	global_load_d16_b16 v8, v41, s[8:9]                        // 000000A06C64: DC820000 08080029
	s_waitcnt lgkmcnt(4)                                       // 000000A06C6C: BF89FC47
	v_add_f32_e32 v15, v11, v15                                // 000000A06C70: 061E1F0B
	ds_load_2addr_b32 v[11:12], v49 offset0:96 offset1:112     // 000000A06C74: D8DC7060 0B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:224 offset1:240    // 000000A06C7C: D8DCF0E0 1D000031
	v_add_f32_e32 v41, v35, v32                                // 000000A06C84: 06524123
	ds_load_2addr_b32 v[31:32], v50 offset0:96 offset1:112     // 000000A06C88: D8DC7060 1F000032
	ds_load_2addr_b32 v[35:36], v50 offset0:224 offset1:240    // 000000A06C90: D8DCF0E0 23000032
	v_add_f32_e32 v7, v7, v14                                  // 000000A06C98: 060E1D07
	global_load_d16_b16 v9, v45, s[6:7]                        // 000000A06C9C: DC820000 0906002D
	v_add_f32_e32 v41, v41, v16                                // 000000A06CA4: 06522129
	s_waitcnt lgkmcnt(7)                                       // 000000A06CA8: BF89FC77
	v_add_f32_e32 v17, v13, v17                                // 000000A06CAC: 0622230D
	s_waitcnt lgkmcnt(6)                                       // 000000A06CB0: BF89FC67
	v_add_f32_e32 v19, v15, v19                                // 000000A06CB4: 0626270F
	ds_load_2addr_b32 v[13:14], v51 offset0:96 offset1:112     // 000000A06CB8: D8DC7060 0D000033
	ds_load_2addr_b32 v[15:16], v51 offset0:224 offset1:240    // 000000A06CC0: D8DCF0E0 0F000033
	v_dual_add_f32 v7, v7, v18 :: v_dual_add_f32 v18, v41, v20 // 000000A06CC8: C9082507 07122929
	s_waitcnt lgkmcnt(7)                                       // 000000A06CD0: BF89FC77
	v_add_f32_e32 v17, v17, v27                                // 000000A06CD4: 06223711
	s_waitcnt lgkmcnt(6)                                       // 000000A06CD8: BF89FC67
	v_dual_add_f32 v19, v19, v33 :: v_dual_add_f32 v20, v38, v22// 000000A06CDC: C9084313 13142D26
	v_dual_add_f32 v7, v7, v28 :: v_dual_add_f32 v18, v18, v34 // 000000A06CE4: C9083907 07124512
	v_add_f32_e32 v22, v44, v24                                // 000000A06CEC: 062C312C
	v_or_b32_e32 v28, 0xa0, v52                                // 000000A06CF0: 383868FF 000000A0
	s_waitcnt lgkmcnt(5)                                       // 000000A06CF8: BF89FC57
	v_add_f32_e32 v11, v17, v11                                // 000000A06CFC: 06161711
	s_waitcnt lgkmcnt(4)                                       // 000000A06D00: BF89FC47
	v_add_f32_e32 v17, v19, v29                                // 000000A06D04: 06223B13
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v12, v18, v30 // 000000A06D08: C9081907 070C3D12
	s_waitcnt lgkmcnt(3)                                       // 000000A06D10: BF89FC37
	v_dual_add_f32 v10, v20, v10 :: v_dual_add_f32 v11, v11, v31// 000000A06D14: C9081514 0A0A3F0B
	s_waitcnt lgkmcnt(2)                                       // 000000A06D1C: BF89FC27
	v_dual_add_f32 v17, v17, v35 :: v_dual_add_f32 v18, v22, v26// 000000A06D20: C9084711 11123516
	v_add_f32_e32 v12, v12, v36                                // 000000A06D28: 0618490C
	v_add_f32_e32 v7, v7, v32                                  // 000000A06D2C: 060E4107
	s_waitcnt lgkmcnt(1)                                       // 000000A06D30: BF89FC17
	v_add_f32_e32 v11, v11, v13                                // 000000A06D34: 06161B0B
	s_waitcnt lgkmcnt(0)                                       // 000000A06D38: BF89FC07
	v_add_f32_e32 v13, v17, v15                                // 000000A06D3C: 061A1F11
	v_dual_add_f32 v19, v23, v10 :: v_dual_add_f32 v12, v12, v16// 000000A06D40: C9081517 130C210C
	v_sub_f32_e32 v10, v23, v10                                // 000000A06D48: 08141517
	v_dual_add_f32 v22, v43, v54 :: v_dual_add_f32 v23, v42, v21// 000000A06D4C: C9086D2B 16162B2A
	v_add_f32_e32 v24, v25, v18                                // 000000A06D54: 06302519
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A06D58: BF870004
	v_add_f32_e32 v27, v13, v12                                // 000000A06D5C: 0636190D
	v_add_f32_e32 v7, v7, v14                                  // 000000A06D60: 060E1D07
	v_sub_f32_e32 v15, v39, v53                                // 000000A06D64: 081E6B27
	v_add_f32_e32 v16, v40, v37                                // 000000A06D68: 06204B28
	v_dual_sub_f32 v17, v40, v37 :: v_dual_add_f32 v30, v22, v23// 000000A06D6C: C9484B28 111E2F16
	v_add_f32_e32 v31, v24, v27                                // 000000A06D74: 063E3718
	v_dual_add_f32 v20, v11, v7 :: v_dual_and_b32 v37, 1, v0   // 000000A06D78: C9240F0B 14240081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A06D80: BF870223
	v_add_f32_e32 v36, v15, v17                                // 000000A06D84: 0648230F
	v_sub_f32_e32 v15, v15, v17                                // 000000A06D88: 081E230F
	v_add_f32_e32 v17, v30, v31                                // 000000A06D8C: 06223F1E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A06D90: BF870004
	.long 0xd44a0002                                           // 000000A06D94: D44A0002
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 000000A06D98: 02024A80
	v_add_f32_e32 v14, v39, v53                                // 000000A06D9C: 061C6B27
	v_add_f32_e32 v39, v19, v20                                // 000000A06DA0: 064E2913
	v_sub_f32_e32 v19, v19, v20                                // 000000A06DA4: 08262913
	v_mov_b32_dpp v20, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A06DA8: 7E2802FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A06DB0: D5010011 200A2311
	v_sub_f32_e32 v37, v43, v54                                // 000000A06DB8: 084A6D2B
	v_dual_sub_f32 v21, v42, v21 :: v_dual_sub_f32 v18, v25, v18// 000000A06DBC: C94A2B2A 15122519
	v_dual_sub_f32 v12, v13, v12 :: v_dual_sub_f32 v11, v11, v7// 000000A06DC4: C94A190D 0C0A0F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A06DCC: BF8701A4
	v_add_f32_e32 v13, v17, v20                                // 000000A06DD0: 061A2911
	v_and_b32_e32 v17, 2, v0                                   // 000000A06DD4: 36220082
	v_dual_add_f32 v25, v37, v21 :: v_dual_add_f32 v40, v18, v12// 000000A06DD8: C9082B25 19281912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A06DE0: BF870224
	v_add_f32_e32 v20, v10, v11                                // 000000A06DE4: 0628170A
	v_sub_f32_e32 v10, v10, v11                                // 000000A06DE8: 0814170A
	.long 0xd44a0003                                           // 000000A06DEC: D44A0003
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000A06DF0: 02022280
	v_sub_f32_e32 v17, v22, v23                                // 000000A06DF4: 08222F16
	v_dual_add_f32 v11, v25, v40 :: v_dual_sub_f32 v22, v24, v27// 000000A06DF8: C90A5119 0B163718
	v_and_b32_e32 v23, 4, v0                                   // 000000A06E00: 362E0084
	v_mov_b32_dpp v41, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A06E04: 7E5202FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000A06E0C: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A06E14: BF870254
	v_mov_b32_dpp v24, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A06E18: 7E3002FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000A06E20: D501000B 200A170B
	v_add_f32_e32 v27, v17, v22                                // 000000A06E28: 06362D11
	.long 0xd44a0004                                           // 000000A06E2C: D44A0004
	v_cndmask_b32_e32 v1, 0, v23, vcc_lo                       // 000000A06E30: 02022E80
	v_dual_add_f32 v13, v13, v41 :: v_dual_and_b32 v0, 8, v0   // 000000A06E34: C924530D 0D000088
	v_add_f32_e32 v11, v11, v24                                // 000000A06E3C: 0616310B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A06E40: BF870224
	v_mov_b32_dpp v23, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A06E44: 7E2E02FA FF01611B
	v_cndmask_b32_e64 v24, -v27, v27, s2                       // 000000A06E4C: D5010018 200A371B
	.long 0xd44a0001                                           // 000000A06E54: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000A06E58: 02020080
	v_sub_f32_e32 v0, v37, v21                                 // 000000A06E5C: 08002B25
	v_mov_b32_dpp v27, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A06E60: 7E3602FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A06E68: D501000B 200E170B
	v_dual_add_f32 v23, v24, v23 :: v_dual_sub_f32 v12, v18, v12// 000000A06E70: C90A2F18 170C1912
	v_mov_b32_dpp v41, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A06E78: 7E5202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000A06E80: D501000D 20121B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A06E88: BF870214
	v_add_f32_e32 v11, v11, v27                                // 000000A06E8C: 0616370B
	v_mov_b32_dpp v18, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A06E90: 7E2402FA FF016217
	v_cndmask_b32_e64 v21, -v23, v23, s3                       // 000000A06E98: D5010015 200E2F17
	v_sub_f32_e32 v24, v25, v40                                // 000000A06EA0: 08305119
	v_add_f32_e32 v13, v13, v41                                // 000000A06EA4: 061A530D
	v_mov_b32_dpp v25, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A06EA8: 7E3202FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A06EB0: D501000B 2012170B
	v_dual_add_f32 v18, v21, v18 :: v_dual_add_f32 v21, v0, v12// 000000A06EB8: C9082515 12141900
	v_sub_f32_e32 v23, v30, v31                                // 000000A06EC0: 082E3F1E
	v_sub_f32_e32 v17, v17, v22                                // 000000A06EC4: 08222D11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A06EC8: BF870214
	v_add_f32_e32 v11, v11, v25                                // 000000A06ECC: 0616330B
	v_mov_b32_dpp v25, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A06ED0: 7E3202FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000A06ED8: D5010012 20122512
	v_mov_b32_dpp v30, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A06EE0: 7E3C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000A06EE8: D5010015 200A2B15
	v_mov_b32_dpp v22, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A06EF0: 7E2C02FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A06EF8: D501000D 20061B0D
	v_add_f32_e32 v18, v18, v25                                // 000000A06F00: 06243312
	v_add_f32_e32 v29, v14, v16                                // 000000A06F04: 063A210E
	v_dual_add_f32 v21, v21, v30 :: v_dual_sub_f32 v14, v14, v16// 000000A06F08: C90A3D15 150E210E
	v_or_b32_e32 v16, 0xe0, v52                                // 000000A06F10: 382068FF 000000E0
	v_sub_f32_e32 v0, v0, v12                                  // 000000A06F18: 08001900
	v_add_f32_e32 v12, v13, v22                                // 000000A06F1C: 06182D0D
	v_mov_b32_dpp v13, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A06F20: 7E1A02FA FF016812
	v_mov_b32_dpp v22, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A06F28: 7E2C02FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000A06F30: D5010015 200E2B15
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A06F38: D5010012 20062512
	v_mov_b32_dpp v25, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A06F40: 7E3202FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 000000A06F48: D5010017 200A2F17
	global_load_d16_b16 v38, v16, s[6:7]                       // 000000A06F50: DC820000 26060010
	v_add_f32_e32 v21, v21, v22                                // 000000A06F58: 062A2D15
	v_add_f32_e32 v13, v18, v13                                // 000000A06F5C: 061A1B12
	global_load_d16_b16 v22, v28, s[6:7] offset:1280           // 000000A06F60: DC820500 1606001C
	v_add_f32_e32 v18, v23, v25                                // 000000A06F68: 06243317
	s_clause 0x7                                               // 000000A06F6C: BF850007
	global_load_d16_b16 v25, v16, s[6:7] offset:1280           // 000000A06F70: DC820500 19060010
	global_load_d16_b16 v26, v1, s[6:7] offset:128             // 000000A06F78: DC820080 1A060001
	global_load_d16_b16 v32, v28, s[6:7]                       // 000000A06F80: DC820000 2006001C
	global_load_d16_b16 v33, v1, s[6:7] offset:1344            // 000000A06F88: DC820540 21060001
	global_load_d16_b16 v7, v1, s[6:7] offset:1408             // 000000A06F90: DC820580 07060001
	global_load_d16_b16 v34, v1, s[6:7] offset:1472            // 000000A06F98: DC8205C0 22060001
	global_load_d16_b16 v35, v1, s[6:7] offset:192             // 000000A06FA0: DC8200C0 23060001
	global_load_d16_b16 v27, v45, s[6:7] offset:1280           // 000000A06FA8: DC820500 1B06002D
	v_mov_b32_dpp v23, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A06FB0: 7E2E02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s4                       // 000000A06FB8: D5010015 20122B15
	s_clause 0x5                                               // 000000A06FC0: BF850005
	global_load_d16_b16 v28, v28, s[8:9]                       // 000000A06FC4: DC820000 1C08001C
	global_load_d16_b16 v16, v16, s[8:9]                       // 000000A06FCC: DC820000 10080010
	global_load_d16_b16 v37, v1, s[8:9]                        // 000000A06FD4: DC820000 25080001
	global_load_d16_b16 v40, v1, s[8:9] offset:64              // 000000A06FDC: DC820040 28080001
	global_load_d16_b16 v41, v1, s[8:9] offset:128             // 000000A06FE4: DC820080 29080001
	global_load_d16_b16 v42, v1, s[8:9] offset:192             // 000000A06FEC: DC8200C0 2A080001
	v_mov_b32_dpp v31, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A06FF4: 7E3E02FA FF01680B
	v_add_f32_e32 v21, v21, v23                                // 000000A06FFC: 062A2F15
	global_load_d16_b16 v23, v45, s[8:9]                       // 000000A07000: DC820000 1708002D
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A07008: D501000B 2006170B
	v_mov_b32_dpp v30, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A07010: 7E3C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000A07018: D5010012 200E2512
	v_add_f32_e32 v43, v36, v20                                // 000000A07020: 06562924
	v_mov_b32_dpp v47, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07024: 7E5E02FA FF016118
	v_add_f32_e32 v11, v11, v31                                // 000000A0702C: 06163F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A07030: BF870214
	v_dual_add_f32 v31, v29, v39 :: v_dual_add_f32 v18, v18, v30// 000000A07034: C9084F1D 1F123D12
	v_mov_b32_dpp v45, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0703C: 7E5A02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000A07044: D501002B 200A572B
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 000000A0704C: D5010018 200A3118
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A07054: BF870004
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07058: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000A07060: D501001F 200A3F1F
	v_mov_b32_dpp v44, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07068: 7E5802FA FF016815
	v_add_f32_e32 v43, v43, v45                                // 000000A07070: 06565B2B
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000A07074: D5010015 20062B15
	v_add_f32_e32 v24, v24, v47                                // 000000A0707C: 06305F18
	v_add_f32_e32 v30, v31, v30                                // 000000A07080: 063C3D1F
	v_mov_b32_dpp v31, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A07084: 7E3E02FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000A0708C: D5010012 20122512
	v_add_f32_e32 v21, v21, v44                                // 000000A07094: 062A5915
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000A07098: 101818FF 3DB504F3
	v_mov_b32_dpp v46, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A070A0: 7E5C02FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000A070A8: D501001E 200E3D1E
	v_add_f32_e32 v18, v18, v31                                // 000000A070B0: 06243F12
	v_mov_b32_dpp v31, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A070B4: 7E3E02FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000A070BC: D501002B 200E572B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A070C4: BF870234
	v_dual_sub_f32 v29, v29, v39 :: v_dual_add_f32 v30, v30, v46// 000000A070C8: C9484F1D 1D1E5D1E
	v_mov_b32_dpp v46, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A070D0: 7E5C02FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000A070D8: D5010018 200E3118
	v_add_f32_e32 v31, v43, v31                                // 000000A070E0: 063E3F2B
	v_mov_b32_dpp v43, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A070E4: 7E5602FA FF016812
	v_mov_b32_dpp v45, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A070EC: 7E5A02FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s4                       // 000000A070F4: D501001E 20123D1E
	v_add_f32_e32 v24, v24, v46                                // 000000A070FC: 06305D18
	v_mov_b32_dpp v44, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A07100: 7E5802FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000A07108: D501001F 20123F1F
	v_mov_b32_dpp v46, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07110: 7E5C02FA FF016111
	v_add_f32_e32 v30, v30, v45                                // 000000A07118: 063C5B1E
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A0711C: D5010011 200A2311
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A07124: D5010012 20062512
	v_add_f32_e32 v31, v31, v44                                // 000000A0712C: 063E591F
	v_mov_b32_dpp v44, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A07130: 7E5802FA FF016418
	v_mov_b32_dpp v45, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07138: 7E5A02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000A07140: D501001E 20063D1E
	v_add_f32_e32 v17, v17, v46                                // 000000A07148: 06225D11
	v_cndmask_b32_e64 v24, -v24, v24, s4                       // 000000A0714C: D5010018 20123118
	v_add_f32_e32 v18, v18, v43                                // 000000A07154: 06245712
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A07158: BF870004
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_add_f32 v30, v30, v45// 000000A0715C: C8C816FF 0B1E5B1E 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07168: 7E5A02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A07170: D501001F 20063F1F
	v_mov_b32_dpp v46, v17 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A07178: 7E5C02FA FF016211
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 000000A07180: D5010011 200E2311
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000A07188: 103C3CFF 3DB504F3
	v_add_f32_e32 v24, v24, v44                                // 000000A07190: 06305918
	v_dual_sub_f32 v20, v36, v20 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000A07194: C9462924 140C1AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A071A0: BF8701A4
	v_add_f32_e32 v17, v17, v46                                // 000000A071A4: 06225D11
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 000000A071A8: C8C62AFF 151224FF 3DB504F3
	v_mov_b32_dpp v36, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A071B4: 7E4802FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000A071BC: D5010014 200A2914
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A071C4: BF8700A4
	v_mov_b32_dpp v44, v17 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A071C8: 7E5802FA FF016411
	v_cndmask_b32_e64 v17, -v17, v17, s4                       // 000000A071D0: D5010011 20122311
	v_add_f32_e32 v17, v17, v44                                // 000000A071D8: 06225911
	v_mov_b32_dpp v44, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A071DC: 7E5802FA FF016100
	v_cndmask_b32_e64 v0, -v0, v0, s2                          // 000000A071E4: D5010000 200A0100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A071EC: BF870211
	v_add_f32_e32 v0, v0, v44                                  // 000000A071F0: 06005900
	v_mov_b32_dpp v44, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A071F4: 7E5802FA FF016811
	v_cndmask_b32_e64 v17, -v17, v17, s1                       // 000000A071FC: D5010011 20062311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A07204: BF870091
	v_add_f32_e32 v17, v17, v44                                // 000000A07208: 06225911
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000A0720C: 102222FF 3DB504F3
	s_waitcnt vmcnt(22)                                        // 000000A07214: BF895BF7
	v_fma_mix_f32 v2, v2, v30, neg(0) op_sel_hi:[1,0,0]        // 000000A07218: CC200002 8A023D02
	v_add_f32_e32 v30, v31, v45                                // 000000A07220: 063C5B1F
	v_mov_b32_dpp v31, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07224: 7E3E02FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 000000A0722C: D5010018 20063118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A07234: BF870214
	v_mul_f32_e32 v43, 0xbfb8aa3b, v2                          // 000000A07238: 105604FF BFB8AA3B
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000A07240: 103C3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A07248: BF870223
	v_add_f32_e32 v24, v24, v31                                // 000000A0724C: 06303F18
	v_add_f32_e32 v31, v14, v19                                // 000000A07250: 063E270E
	v_exp_f32_e32 v43, v43                                     // 000000A07254: 7E564B2B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A07258: BF870003
	v_fma_mix_f32 v3, v3, v30, neg(0) op_sel_hi:[1,0,0]        // 000000A0725C: CC200003 8A023D03
	v_sub_f32_e32 v14, v14, v19                                // 000000A07264: 081C270E
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 000000A07268: 103030FF 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07270: 7E5A02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000A07278: D501001F 200A3F1F
	v_mul_f32_e32 v30, 0xbfb8aa3b, v3                          // 000000A07280: 103C06FF BFB8AA3B
	v_mov_b32_dpp v19, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07288: 7E2602FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000A07290: D501000E 200A1D0E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A07298: BF870215
	v_add_f32_e32 v43, 1.0, v43                                // 000000A0729C: 065656F2
	v_exp_f32_e32 v30, v30                                     // 000000A072A0: 7E3C4B1E
	v_add_f32_e32 v31, v31, v45                                // 000000A072A4: 063E5B1F
	v_mov_b32_dpp v45, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A072A8: 7E5A02FA FF016200
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 000000A072B0: D5010000 200E0100
	v_div_scale_f32 v46, null, v43, v43, v2                    // 000000A072B8: D6FC7C2E 040A572B
	s_waitcnt vmcnt(19)                                        // 000000A072C0: BF894FF7
	v_fma_mix_f32 v4, v4, v12, neg(0) op_sel_hi:[1,0,0]        // 000000A072C4: CC200004 8A021904
	v_mov_b32_dpp v48, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A072CC: 7E6002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000A072D4: D501001F 200E3F1F
	v_add_f32_e32 v0, v0, v45                                  // 000000A072DC: 06005B00
	v_rcp_f32_e32 v47, v46                                     // 000000A072E0: 7E5E552E
	v_add_f32_e32 v30, 1.0, v30                                // 000000A072E4: 063C3CF2
	v_fma_mix_f32 v6, v6, v11, neg(0) op_sel_hi:[1,0,0]        // 000000A072E8: CC200006 8A021706
	v_add_f32_e32 v31, v31, v48                                // 000000A072F0: 063E611F
	v_mov_b32_dpp v44, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A072F4: 7E5802FA FF016400
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A072FC: D5010000 20120100
	v_div_scale_f32 v45, null, v30, v30, v3                    // 000000A07304: D6FC7C2D 040E3D1E
	v_add_f32_e32 v14, v14, v19                                // 000000A0730C: 061C270E
	v_mov_b32_dpp v50, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A07310: 7E6402FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000A07318: D501001F 20123F1F
	v_add_f32_e32 v0, v0, v44                                  // 000000A07320: 06005900
	v_rcp_f32_e32 v48, v45                                     // 000000A07324: 7E60552D
	v_add_f32_e32 v44, v15, v10                                // 000000A07328: 0658150F
	v_fma_f32 v49, -v46, v47, 1.0                              // 000000A0732C: D6130031 23CA5F2E
	v_add_f32_e32 v31, v31, v50                                // 000000A07334: 063E651F
	v_sub_f32_e32 v10, v15, v10                                // 000000A07338: 0814150F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 000000A0733C: BF8702C4
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07340: 7E6602FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000A07348: D501002C 200A592C
	v_fmac_f32_e32 v47, v49, v47                               // 000000A07350: 565E5F31
	v_div_scale_f32 v49, vcc_lo, v2, v43, v2                   // 000000A07354: D6FC6A31 040A5702
	v_fma_f32 v50, -v45, v48, 1.0                              // 000000A0735C: D6130032 23CA612D
	v_mov_b32_dpp v52, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07364: 7E6802FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A0736C: D501001F 20063F1F
	v_add_f32_e32 v44, v44, v51                                // 000000A07374: 0658672C
	v_mov_b32_dpp v51, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07378: 7E6602FA FF016800
	v_fmac_f32_e32 v48, v50, v48                               // 000000A07380: 56606132
	v_div_scale_f32 v50, s5, v3, v30, v3                       // 000000A07384: D6FC0532 040E3D03
	v_dual_add_f32 v31, v31, v52 :: v_dual_mul_f32 v52, v49, v47// 000000A0738C: C906691F 1F345F31
	v_mov_b32_dpp v54, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A07394: 7E6C02FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000A0739C: D501002C 200E592C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A073A4: BF870214
	v_mul_f32_e32 v53, v50, v48                                // 000000A073A8: 106A6132
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000A073AC: 103E3EFF 3DB504F3
	v_fma_f32 v55, -v46, v52, v49                              // 000000A073B4: D6130037 24C6692E
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A073BC: D5010000 20060100
	v_add_f32_e32 v44, v44, v54                                // 000000A073C4: 06586D2C
	v_fma_f32 v56, -v45, v53, v50                              // 000000A073C8: D6130038 24CA6B2D
	v_fma_mix_f32 v5, v5, v31, neg(0) op_sel_hi:[1,0,0]        // 000000A073D0: CC200005 8A023F05
	v_fmac_f32_e32 v52, v55, v47                               // 000000A073D8: 56685F37
	v_add_f32_e32 v0, v0, v51                                  // 000000A073DC: 06006700
	v_mov_b32_dpp v31, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A073E0: 7E3E02FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s4                       // 000000A073E8: D501002C 2012592C
	v_fmac_f32_e32 v53, v56, v48                               // 000000A073F0: 566A6138
	v_fma_f32 v46, -v46, v52, v49                              // 000000A073F4: D613002E 24C6692E
	v_mul_f32_e32 v51, 0xbfb8aa3b, v5                          // 000000A073FC: 10660AFF BFB8AA3B
	v_mov_b32_dpp v19, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07404: 7E2602FA FF01610A
	v_add_f32_e32 v31, v44, v31                                // 000000A0740C: 063E3F2C
	v_fma_f32 v45, -v45, v53, v50                              // 000000A07410: D613002D 24CA6B2D
	v_div_fmas_f32 v44, v46, v47, v52                          // 000000A07418: D637002C 04D25F2E
	s_mov_b32 vcc_lo, s5                                       // 000000A07420: BEEA0005
	v_exp_f32_e32 v49, v51                                     // 000000A07424: 7E624B33
	v_mov_b32_dpp v46, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07428: 7E5C02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A07430: D501001F 20063F1F
	v_div_fmas_f32 v45, v45, v48, v53                          // 000000A07438: D637002D 04D6612D
	v_div_fixup_f32 v2, v44, v43, v2                           // 000000A07440: D6270002 040A572C
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A07448: D501000A 200A150A
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000A07450: 100000FF 3DB504F3
	v_add_f32_e32 v12, v31, v46                                // 000000A07458: 06185D1F
	v_mov_b32_dpp v31, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0745C: 7E3E02FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000A07464: D501001D 200A3B1D
	v_div_fixup_f32 v3, v45, v30, v3                           // 000000A0746C: D6270003 040E3D2D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A07474: BF870224
	v_dual_mul_f32 v2, v4, v2 :: v_dual_mul_f32 v11, 0x3db504f3, v12// 000000A07478: C8C60504 020A18FF 3DB504F3
	v_add_f32_e32 v10, v10, v19                                // 000000A07484: 0614270A
	v_add_f32_e32 v4, v29, v31                                 // 000000A07488: 06083F1D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0748C: BF870004
	v_mul_f32_e32 v3, v6, v3                                   // 000000A07490: 10060706
	v_add_f32_e32 v47, 1.0, v49                                // 000000A07494: 065E62F2
	s_waitcnt vmcnt(17)                                        // 000000A07498: BF8947F7
	v_fma_mix_f32 v6, v9, v11, neg(0) op_sel_hi:[1,0,0]        // 000000A0749C: CC200006 8A021709
	v_add_f32_e32 v9, v20, v36                                 // 000000A074A4: 06124914
	v_mov_b32_dpp v20, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A074A8: 7E2802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000A074B0: D5010004 200E0904
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel_hi:[1,0,0]         // 000000A074B8: CC200003 8A020708
	v_mul_f32_e32 v8, 0xbfb8aa3b, v6                           // 000000A074C0: 10100CFF BFB8AA3B
	v_mov_b32_dpp v29, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A074C8: 7E3A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A074D0: D5010009 200E1309
	v_add_f32_e32 v4, v4, v20                                  // 000000A074D8: 06082904
	v_div_scale_f32 v30, null, v47, v47, v5                    // 000000A074DC: D6FC7C1E 04165F2F
	v_exp_f32_e32 v8, v8                                       // 000000A074E4: 7E104B08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A074E8: BF870193
	v_add_f32_e32 v9, v9, v29                                  // 000000A074EC: 06123B09
	v_mov_b32_dpp v15, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A074F0: 7E1E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000A074F8: D5010004 20120904
	v_mov_b32_dpp v29, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A07500: 7E3A02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 000000A07508: D501000E 200E1D0E
	v_mov_b32_dpp v20, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A07510: 7E2802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A07518: D5010009 20121309
	v_add_f32_e32 v4, v4, v15                                  // 000000A07520: 06081F04
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A07524: 7E1E02FA FF01620A
	v_add_f32_e32 v14, v14, v29                                // 000000A0752C: 061C3B0E
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A07530: D501000A 200E150A
	v_add_f32_e32 v9, v9, v20                                  // 000000A07538: 06122909
	v_mov_b32_dpp v19, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0753C: 7E2602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A07544: D5010004 20060904
	v_mov_b32_dpp v20, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0754C: 7E2802FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000A07554: D501000E 20121D0E
	v_add_f32_e32 v10, v10, v15                                // 000000A0755C: 06141F0A
	v_rcp_f32_e32 v12, v30                                     // 000000A07560: 7E18551E
	v_mov_b32_dpp v15, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07564: 7E1E02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A0756C: D5010009 20061309
	v_add_f32_e32 v4, v4, v19                                  // 000000A07574: 06082704
	v_add_f32_e32 v14, v14, v20                                // 000000A07578: 061C290E
	v_mov_b32_dpp v19, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0757C: 7E2602FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 000000A07584: D501000A 2012150A
	v_dual_add_f32 v8, 1.0, v8 :: v_dual_add_f32 v9, v9, v15   // 000000A0758C: C90810F2 08081F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A07594: BF870224
	v_mov_b32_dpp v15, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07598: 7E1E02FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000A075A0: D501000E 20061D0E
	v_add_f32_e32 v10, v10, v19                                // 000000A075A8: 0614270A
	v_fma_f32 v11, -v30, v12, 1.0                              // 000000A075AC: D613000B 23CA191E
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000A075B4: 100808FF 3DB504F3
	v_div_scale_f32 v19, null, v8, v8, v6                      // 000000A075BC: D6FC7C13 041A1108
	v_add_f32_e32 v14, v14, v15                                // 000000A075C4: 061C1F0E
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A075C8: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A075D0: D501000A 2006150A
	v_fmac_f32_e32 v12, v11, v12                               // 000000A075D8: 5618190B
	v_div_scale_f32 v11, vcc_lo, v5, v47, v5                   // 000000A075DC: D6FC6A0B 04165F05
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000A075E4: 101212FF 3DB504F3
	v_rcp_f32_e32 v20, v19                                     // 000000A075EC: 7E285513
	v_add_f32_e32 v10, v10, v15                                // 000000A075F0: 06141F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A075F4: BF8701B3
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_mul_f32 v15, v11, v12// 000000A075F8: C8C61CFF 0E0E190B 3DB504F3
	s_waitcnt vmcnt(12)                                        // 000000A07604: BF8933F7
	v_fma_mix_f32 v9, v32, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A07608: CC200009 8A021320
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000A07610: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A07618: BF870003
	v_fma_f32 v31, -v30, v15, v11                              // 000000A0761C: D613001F 242E1F1E
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A07624: CC200004 8A02091A
	s_waitcnt vmcnt(8)                                         // 000000A0762C: BF8923F7
	v_fma_mix_f32 v14, v35, v14, neg(0) op_sel_hi:[1,0,0]      // 000000A07630: CC20000E 8A021D23
	v_mul_f32_e32 v29, 0xbfb8aa3b, v9                          // 000000A07638: 103A12FF BFB8AA3B
	v_fma_f32 v32, -v19, v20, 1.0                              // 000000A07640: D6130020 23CA2913
	v_fma_mix_f32 v10, v38, v10, neg(0) op_sel_hi:[1,0,0]      // 000000A07648: CC20000A 8A021526
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A07650: BF870214
	v_dual_mul_f32 v26, 0xbfb8aa3b, v4 :: v_dual_mul_f32 v35, 0xbfb8aa3b, v14// 000000A07654: C8C608FF 1A221CFF BFB8AA3B
	v_exp_f32_e32 v29, v29                                     // 000000A07660: 7E3A4B1D
	v_fmac_f32_e32 v15, v31, v12                               // 000000A07664: 561E191F
	v_fmac_f32_e32 v20, v32, v20                               // 000000A07668: 56282920
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A0766C: BF870003
	v_exp_f32_e32 v26, v26                                     // 000000A07670: 7E344B1A
	v_mul_f32_e32 v32, 0xbfb8aa3b, v10                         // 000000A07674: 104014FF BFB8AA3B
	v_exp_f32_e32 v31, v35                                     // 000000A0767C: 7E3E4B23
	v_fma_f32 v11, -v30, v15, v11                              // 000000A07680: D613000B 242E1F1E
	v_div_scale_f32 v35, s5, v6, v8, v6                        // 000000A07688: D6FC0523 041A1106
	v_fma_mix_f32 v13, v33, v13, neg(0) op_sel_hi:[1,0,0]      // 000000A07690: CC20000D 8A021B21
	v_exp_f32_e32 v30, v32                                     // 000000A07698: 7E3C4B20
	v_add_f32_e32 v29, 1.0, v29                                // 000000A0769C: 063A3AF2
	v_div_fmas_f32 v11, v11, v12, v15                          // 000000A076A0: D637000B 043E190B
	v_mul_f32_e32 v32, v35, v20                                // 000000A076A8: 10402923
	v_add_f32_e32 v26, 1.0, v26                                // 000000A076AC: 063434F2
	s_mov_b32 vcc_lo, s5                                       // 000000A076B0: BEEA0005
	v_add_f32_e32 v31, 1.0, v31                                // 000000A076B4: 063E3EF2
	v_div_scale_f32 v39, null, v29, v29, v9                    // 000000A076B8: D6FC7C27 04263B1D
	v_fma_f32 v15, -v19, v32, v35                              // 000000A076C0: D613000F 248E4113
	v_div_scale_f32 v36, null, v26, v26, v4                    // 000000A076C8: D6FC7C24 0412351A
	v_add_f32_e32 v30, 1.0, v30                                // 000000A076D0: 063C3CF2
	v_div_scale_f32 v12, null, v31, v31, v14                   // 000000A076D4: D6FC7C0C 043A3F1F
	v_rcp_f32_e32 v43, v39                                     // 000000A076DC: 7E565527
	v_fmac_f32_e32 v32, v15, v20                               // 000000A076E0: 5640290F
	v_rcp_f32_e32 v38, v36                                     // 000000A076E4: 7E4C5524
	v_div_scale_f32 v33, null, v30, v30, v10                   // 000000A076E8: D6FC7C21 042A3D1E
	v_rcp_f32_e32 v45, v12                                     // 000000A076F0: 7E5A550C
	v_div_fixup_f32 v5, v11, v47, v5                           // 000000A076F4: D6270005 04165F0B
	v_div_scale_f32 v11, s6, v4, v26, v4                       // 000000A076FC: D6FC060B 04123504
	v_fma_f32 v19, -v19, v32, v35                              // 000000A07704: D6130013 248E4113
	v_rcp_f32_e32 v15, v33                                     // 000000A0770C: 7E1E5521
	s_waitcnt vmcnt(7)                                         // 000000A07710: BF891FF7
	v_fma_mix_f32 v21, v27, v21, neg(0) op_sel_hi:[1,0,0]      // 000000A07714: CC200015 8A022B1B
	v_mul_f32_e32 v5, v13, v5                                  // 000000A0771C: 100A0B0D
	v_fma_mix_f32 v0, v25, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A07720: CC200000 8A020119
	v_fma_f32 v44, -v36, v38, 1.0                              // 000000A07728: D613002C 23CA4D24
	v_div_fmas_f32 v19, v19, v20, v32                          // 000000A07730: D6370013 04822913
	v_fma_f32 v13, -v12, v45, 1.0                              // 000000A07738: D613000D 23CA5B0C
	s_mov_b32 vcc_lo, s6                                       // 000000A07740: BEEA0006
	v_fma_mix_f32 v7, v7, v18, neg(0) op_sel_hi:[1,0,0]        // 000000A07744: CC200007 8A022507
	v_fmac_f32_e32 v38, v44, v38                               // 000000A0774C: 564C4D2C
	v_fma_f32 v44, -v39, v43, 1.0                              // 000000A07750: D613002C 23CA5727
	v_fma_f32 v46, -v33, v15, 1.0                              // 000000A07758: D613002E 23CA1F21
	v_fmac_f32_e32 v45, v13, v45                               // 000000A07760: 565A5B0D
	v_div_scale_f32 v13, s8, v14, v31, v14                     // 000000A07764: D6FC080D 043A3F0E
	v_mul_f32_e32 v35, v11, v38                                // 000000A0776C: 10464D0B
	v_fmac_f32_e32 v43, v44, v43                               // 000000A07770: 5656572C
	v_div_scale_f32 v44, s7, v9, v29, v9                       // 000000A07774: D6FC072C 04263B09
	v_fmac_f32_e32 v15, v46, v15                               // 000000A0777C: 561E1F2E
	v_div_scale_f32 v46, s5, v10, v30, v10                     // 000000A07780: D6FC052E 042A3D0A
	v_fma_f32 v20, -v36, v35, v11                              // 000000A07788: D6130014 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A07790: BF8701A4
	v_dual_mul_f32 v47, v13, v45 :: v_dual_mul_f32 v32, v44, v43// 000000A07794: C8C65B0D 2F20572C
	v_div_fixup_f32 v6, v19, v8, v6                            // 000000A0779C: D6270006 041A1113
	v_dual_fmac_f32 v35, v20, v38 :: v_dual_mul_f32 v20, v46, v15// 000000A077A4: C8064D14 23141F2E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A077AC: BF870213
	v_fma_f32 v8, -v39, v32, v44                               // 000000A077B0: D6130008 24B24127
	v_fma_f32 v19, -v12, v47, v13                              // 000000A077B8: D6130013 24365F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A077C0: BF870214
	v_mul_f32_e32 v6, v21, v6                                  // 000000A077C4: 100C0D15
	v_fma_f32 v11, -v36, v35, v11                              // 000000A077C8: D613000B 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A077D0: BF870234
	v_fmac_f32_e32 v32, v8, v43                                // 000000A077D4: 56405708
	v_fma_f32 v8, -v33, v20, v46                               // 000000A077D8: D6130008 24BA2921
	v_fmac_f32_e32 v47, v19, v45                               // 000000A077E0: 565E5B13
	v_div_fmas_f32 v11, v11, v38, v35                          // 000000A077E4: D637000B 048E4D0B
	s_mov_b32 vcc_lo, s7                                       // 000000A077EC: BEEA0007
	v_fma_f32 v19, -v39, v32, v44                              // 000000A077F0: D6130013 24B24127
	v_fmac_f32_e32 v20, v8, v15                                // 000000A077F8: 56281F08
	v_fma_f32 v8, -v12, v47, v13                               // 000000A077FC: D6130008 24365F0C
	v_div_fixup_f32 v4, v11, v26, v4                           // 000000A07804: D6270004 0412350B
	v_fma_mix_f32 v11, v34, v17, neg(0) op_sel_hi:[1,0,0]      // 000000A0780C: CC20000B 8A022322
	v_div_fmas_f32 v12, v19, v43, v32                          // 000000A07814: D637000C 04825713
	v_fma_f32 v13, -v33, v20, v46                              // 000000A0781C: D613000D 24BA2921
	s_mov_b32 vcc_lo, s8                                       // 000000A07824: BEEA0008
	s_waitcnt vmcnt(0)                                         // 000000A07828: BF8903F7
	v_fma_mix_f32 v6, v23, v6, neg(0) op_sel_hi:[1,0,0]        // 000000A0782C: CC200006 8A020D17
	v_div_fmas_f32 v8, v8, v45, v47                            // 000000A07834: D6370008 04BE5B08
	s_mov_b32 vcc_lo, s5                                       // 000000A0783C: BEEA0005
	v_div_fixup_f32 v9, v12, v29, v9                           // 000000A07840: D6270009 04263B0C
	v_div_fmas_f32 v13, v13, v15, v20                          // 000000A07848: D637000D 04521F0D
	v_fma_mix_f32 v12, v22, v24, neg(0) op_sel_hi:[1,0,0]      // 000000A07850: CC20000C 8A023116
	v_div_fixup_f32 v8, v8, v31, v14                           // 000000A07858: D6270008 043A3F08
	v_mul_f32_e32 v4, v7, v4                                   // 000000A07860: 10080907
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A07864: BF870194
	v_div_fixup_f32 v10, v13, v30, v10                         // 000000A07868: D627000A 042A3D0D
	v_dual_mul_f32 v9, v12, v9 :: v_dual_mul_f32 v8, v11, v8   // 000000A07870: C8C6130C 0908110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A07878: BF870112
	v_mul_f32_e32 v0, v0, v10                                  // 000000A0787C: 10001500
	v_fma_mix_f32 v7, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A07880: CC200007 8A02131C
	v_fma_mix_f32 v9, v2, v37, v3 op_sel_hi:[0,1,0]            // 000000A07888: CC200009 140E4B02
	v_fma_mix_f32 v10, v5, v40, v6 op_sel_hi:[0,1,0]           // 000000A07890: CC20000A 141A5105
	v_fma_mix_f32 v2, v2, v37, -v3 op_sel_hi:[0,1,0]           // 000000A07898: CC200002 940E4B02
	v_fma_mix_f32 v0, v16, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A078A0: CC200000 8A020110
	v_fma_mix_f32 v11, v4, v41, v7 op_sel_hi:[0,1,0]           // 000000A078A8: CC20000B 141E5304
	v_fma_mix_f32 v3, v5, v40, -v6 op_sel_hi:[0,1,0]           // 000000A078B0: CC200003 941A5105
	v_fma_mix_f32 v4, v4, v41, -v7 op_sel_hi:[0,1,0]           // 000000A078B8: CC200004 941E5304
	v_add_f32_e32 v5, v9, v10                                  // 000000A078C0: 060A1509
	v_fma_mix_f32 v12, v8, v42, v0 op_sel_hi:[0,1,0]           // 000000A078C4: CC20000C 14025508
	v_fma_mix_f32 v0, v8, v42, -v0 op_sel_hi:[0,1,0]           // 000000A078CC: CC200000 94025508
	v_dual_sub_f32 v7, v9, v10 :: v_dual_add_f32 v8, v2, v3    // 000000A078D4: C9481509 07080702
	v_sub_f32_e32 v2, v2, v3                                   // 000000A078DC: 08040702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A078E0: BF8701B4
	v_add_f32_e32 v6, v11, v12                                 // 000000A078E4: 060C190B
	v_sub_f32_e32 v9, v11, v12                                 // 000000A078E8: 0812190B
	v_add_f32_e32 v10, v4, v0                                  // 000000A078EC: 06140104
	v_dual_sub_f32 v0, v4, v0 :: v_dual_add_f32 v3, v5, v6     // 000000A078F0: C9480104 00020D05
	v_sub_f32_e32 v4, v5, v6                                   // 000000A078F8: 08080D05
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A078FC: BF870003
	v_add_f32_e32 v6, v8, v10                                  // 000000A07900: 060C1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000A07904: 08101508
	v_add_f32_e32 v10, v7, v9                                  // 000000A07908: 06141307
	v_mov_b32_dpp v5, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0790C: 7E0A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000A07914: D5010003 200A0703
	v_sub_f32_e32 v7, v7, v9                                   // 000000A0791C: 080E1307
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07920: 7E1C02FA FF016104
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07928: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A07930: D501000A 200A150A
	v_add_f32_e32 v3, v3, v5                                   // 000000A07938: 06060B03
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0793C: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A07944: D5010006 200A0D06
	v_cndmask_b32_e64 v15, -v4, v4, s2                         // 000000A0794C: D501000F 200A0904
	v_add_f32_e32 v9, v10, v9                                  // 000000A07954: 0612130A
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A07958: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000A07960: D5010003 200E0703
	v_add_f32_e32 v5, v6, v5                                   // 000000A07968: 060A0B06
	v_add_f32_e32 v6, v2, v0                                   // 000000A0796C: 060C0102
	v_sub_f32_e32 v10, v2, v0                                  // 000000A07970: 08140102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A07974: BF870214
	v_add_f32_e32 v0, v3, v11                                  // 000000A07978: 06001703
	v_mov_b32_dpp v2, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0797C: 7E0402FA FF016205
	v_cndmask_b32_e64 v3, -v5, v5, s3                          // 000000A07984: D5010003 200E0B05
	v_mov_b32_dpp v5, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0798C: 7E0A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A07994: D5010009 200E1309
	v_mov_b32_dpp v11, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0799C: 7E1602FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A079A4: D5010006 200A0D06
	v_add_f32_e32 v2, v3, v2                                   // 000000A079AC: 06040503
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A079B0: 7E2002FA FF01610A
	v_add_f32_e32 v5, v9, v5                                   // 000000A079B8: 060A0B09
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A079BC: D501000A 200A150A
	v_add_f32_e32 v6, v6, v11                                  // 000000A079C4: 060C1706
	v_mov_b32_dpp v9, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A079C8: 7E1202FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000A079D0: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A079D8: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000A079E0: D5010005 20120B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A079E8: 7E1802FA FF016206
	v_cndmask_b32_e64 v13, -v6, v6, s3                         // 000000A079F0: D501000D 200E0D06
	v_add_f32_e32 v4, v2, v9                                   // 000000A079F8: 06081302
	v_add_f32_e32 v10, v10, v16                                // 000000A079FC: 0614210A
	v_dual_add_f32 v6, v5, v11 :: v_dual_add_f32 v11, v15, v14 // 000000A07A00: C9081705 060A1D0F
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07A08: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000A07A10: D5010008 200A1108
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07A18: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000A07A20: D5010007 200A0F07
	v_add_f32_e32 v9, v13, v12                                 // 000000A07A28: 0612190D
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A07A2C: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A07A34: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A07A3C: BF870234
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v7, v15   // 000000A07A40: C9081D08 08061F07
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A07A48: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A07A50: D501000A 200E150A
	v_add_f32_e32 v11, v11, v13                                // 000000A07A58: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A07A5C: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A07A60: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000A07A68: D5010008 200E1108
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A07A70: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000A07A78: D5010007 200E0F07
	v_add_f32_e32 v10, v10, v15                                // 000000A07A80: 06141F0A
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A07A84: 7E0602FA FF016400
	v_add_f32_e32 v8, v8, v13                                  // 000000A07A8C: 06101B08
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A07A90: D5010000 20120100
	v_add_f32_e32 v7, v7, v14                                  // 000000A07A98: 060E1D07
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A07A9C: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A07AA4: D5010009 20121309
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A07AAC: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A07AB4: D501000B 2012170B
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A07ABC: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000A07AC4: D5010008 20121108
	v_mov_b32_dpp v15, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A07ACC: 7E1E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000A07AD4: D5010007 20120F07
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A07ADC: 7E2002FA FF01640A
	v_cndmask_b32_e64 v17, -v10, v10, s4                       // 000000A07AE4: D5010011 2012150A
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v9, v12    // 000000A07AEC: C9080700 00081909
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v8, v14// 000000A07AF4: C9081B0B 0A0A1D08
	v_add_f32_e32 v13, v7, v15                                 // 000000A07AFC: 061A1F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A07B00: BF870214
	v_add_f32_e32 v15, v17, v16                                // 000000A07B04: 061E2111
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07B08: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07B10: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07B18: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07B20: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07B28: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07B30: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07B38: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A07B40: 7E2002FA FF01680F
	s_mov_b32 s2, 0x3db504f3                                   // 000000A07B48: BE8200FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s0                             // 000000A07B50: 8B7E007E
	s_cbranch_execz 65                                         // 000000A07B54: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x795c>
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000A07B58: D501000F 20061F0F
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A07B60: D5010000 20060100
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A07B68: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A07B70: D5010006 20060D06
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A07B78: D5010009 20061309
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A07B80: D501000D 20061B0D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A07B88: D501000A 2006150A
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A07B90: D501000B 2006170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 000000A07B98: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 000000A07BA0: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 000000A07BA4: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 000000A07BA8: 060E0F09
	s_mul_i32 s0, s10, 0x500                                   // 000000A07BAC: 9600FF0A 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 000000A07BB4: C9081D0D 0D08110A
	s_mul_hi_i32 s1, s10, 0x500                                // 000000A07BBC: 9701FF0A 00000500
	v_add_f32_e32 v11, v11, v12                                // 000000A07BC4: 0616190B
	s_add_u32 s0, s22, s0                                      // 000000A07BC8: 80000016
	v_fma_mixlo_f16 v0, v0, s2, 0                              // 000000A07BCC: CC210000 02000500
	s_addc_u32 s1, s23, s1                                     // 000000A07BD4: 82010117
	v_fma_mixhi_f16 v0, v3, s2, 0                              // 000000A07BD8: CC220000 02000503
	s_add_u32 s0, s0, s12                                      // 000000A07BE0: 80000C00
	v_fma_mixlo_f16 v2, v5, s2, 0                              // 000000A07BE4: CC210002 02000505
	s_addc_u32 s1, s1, s13                                     // 000000A07BEC: 82010D01
	v_fma_mixhi_f16 v2, v7, s2, 0                              // 000000A07BF0: CC220002 02000507
	v_fma_mixlo_f16 v3, v8, s2, 0                              // 000000A07BF8: CC210003 02000508
	v_fma_mixhi_f16 v3, v11, s2, 0                             // 000000A07C00: CC220003 0200050B
	v_fma_mixlo_f16 v4, v13, s2, 0                             // 000000A07C08: CC210004 0200050D
	v_fma_mixhi_f16 v4, v15, s2, 0                             // 000000A07C10: CC220004 0200050F
	s_clause 0x7                                               // 000000A07C18: BF850007
	global_store_b16 v1, v0, s[0:1]                            // 000000A07C1C: DC660000 00000001
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 000000A07C24: DC960020 00000001
	global_store_b16 v1, v2, s[0:1] offset:64                  // 000000A07C2C: DC660040 00000201
	global_store_d16_hi_b16 v1, v2, s[0:1] offset:96           // 000000A07C34: DC960060 00000201
	global_store_b16 v1, v3, s[0:1] offset:128                 // 000000A07C3C: DC660080 00000301
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:160          // 000000A07C44: DC9600A0 00000301
	global_store_b16 v1, v4, s[0:1] offset:192                 // 000000A07C4C: DC6600C0 00000401
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:224          // 000000A07C54: DC9600E0 00000401
	s_endpgm                                                   // 000000A07C5C: BFB00000
		...

