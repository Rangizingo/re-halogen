0000000000240c00 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i>:
; _ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i():
	s_clause 0x2                                               // 000000240C00: BF850002
	s_load_b32 s20, s[0:1], 0x30                               // 000000240C04: F4000500 F8000030
	s_load_b128 s[16:19], s[0:1], 0x20                         // 000000240C0C: F4080400 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 000000240C14: F40C0200 F8000000
	v_lshrrev_b32_e32 v1, 1, v0                                // 000000240C1C: 32020081
	s_lshl_b32 s0, s2, 7                                       // 000000240C20: 84008702
	v_dual_mov_b32 v33, 0 :: v_dual_and_b32 v70, 15, v0        // 000000240C24: CA240080 2146008F
	v_lshrrev_b32_e32 v2, 3, v0                                // 000000240C2C: 32040083
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000240C30: BF870193
	v_and_or_b32 v69, 0x70, v1, s0                             // 000000240C34: D6570045 000202FF 00000070
	v_dual_mov_b32 v36, v33 :: v_dual_and_b32 v1, 7, v0        // 000000240C40: CA240121 24000087
	v_dual_mov_b32 v34, v33 :: v_dual_lshlrev_b32 v3, 4, v0    // 000000240C48: CA220121 22020084
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000240C50: BF870214
	v_mul_u32_u24_e32 v4, 0xa0, v2                             // 000000240C54: 160804FF 000000A0
	v_or_b32_e32 v5, v69, v70                                  // 000000240C5C: 380A8D45
	s_lshl_b32 s4, s3, 5                                       // 000000240C60: 84048503
	v_mov_b32_e32 v35, v33                                     // 000000240C64: 7E460321
	v_or_b32_e32 v73, s4, v2                                   // 000000240C68: 38920404
	v_lshl_add_u32 v74, v1, 4, v4                              // 000000240C6C: D646004A 04110901
	v_and_b32_e32 v2, 0x70, v3                                 // 000000240C74: 360406FF 00000070
	s_waitcnt lgkmcnt(0)                                       // 000000240C7C: BF89FC07
	s_add_i32 s0, s20, -1                                      // 000000240C80: 8100C114
	v_or_b32_e32 v71, 0xffffff00, v0                           // 000000240C84: 388E00FF FFFFFF00
	v_min_i32_e32 v1, s0, v5                                   // 000000240C8C: 22020A00
	v_mul_u32_u24_e32 v72, 0xa0, v70                           // 000000240C90: 16908CFF 000000A0
	.long 0xd700004b                                           // 000000240C98: D700004B
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 000000240C9C: 02020408
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000240CA0: BF870211
	v_add_co_ci_u32_e64 v76, null, s9, 0, s0                   // 000000240CA4: D5207C4C 00010009
	v_mad_i64_i32 v[65:66], null, 0x280, v1, s[10:11]          // 000000240CAC: D6FF7C41 002A02FF 00000280
	v_mov_b32_e32 v37, v33                                     // 000000240CB8: 7E4A0321
	v_mov_b32_e32 v38, v33                                     // 000000240CBC: 7E4C0321
	v_mov_b32_e32 v39, v33                                     // 000000240CC0: 7E4E0321
	v_mov_b32_e32 v40, v33                                     // 000000240CC4: 7E500321
	v_mov_b32_e32 v1, v33                                      // 000000240CC8: 7E020321
	v_mov_b32_e32 v2, v33                                      // 000000240CCC: 7E040321
	v_mov_b32_e32 v3, v33                                      // 000000240CD0: 7E060321
	v_mov_b32_e32 v4, v33                                      // 000000240CD4: 7E080321
	v_mov_b32_e32 v5, v33                                      // 000000240CD8: 7E0A0321
	v_mov_b32_e32 v6, v33                                      // 000000240CDC: 7E0C0321
	v_mov_b32_e32 v7, v33                                      // 000000240CE0: 7E0E0321
	v_mov_b32_e32 v8, v33                                      // 000000240CE4: 7E100321
	v_mov_b32_e32 v41, v33                                     // 000000240CE8: 7E520321
	v_mov_b32_e32 v42, v33                                     // 000000240CEC: 7E540321
	v_mov_b32_e32 v43, v33                                     // 000000240CF0: 7E560321
	v_mov_b32_e32 v44, v33                                     // 000000240CF4: 7E580321
	v_mov_b32_e32 v45, v33                                     // 000000240CF8: 7E5A0321
	v_mov_b32_e32 v46, v33                                     // 000000240CFC: 7E5C0321
	v_mov_b32_e32 v47, v33                                     // 000000240D00: 7E5E0321
	v_mov_b32_e32 v48, v33                                     // 000000240D04: 7E600321
	v_mov_b32_e32 v9, v33                                      // 000000240D08: 7E120321
	v_mov_b32_e32 v10, v33                                     // 000000240D0C: 7E140321
	v_mov_b32_e32 v11, v33                                     // 000000240D10: 7E160321
	v_mov_b32_e32 v12, v33                                     // 000000240D14: 7E180321
	v_mov_b32_e32 v13, v33                                     // 000000240D18: 7E1A0321
	v_mov_b32_e32 v14, v33                                     // 000000240D1C: 7E1C0321
	v_mov_b32_e32 v15, v33                                     // 000000240D20: 7E1E0321
	v_mov_b32_e32 v16, v33                                     // 000000240D24: 7E200321
	v_mov_b32_e32 v49, v33                                     // 000000240D28: 7E620321
	v_mov_b32_e32 v50, v33                                     // 000000240D2C: 7E640321
	v_mov_b32_e32 v51, v33                                     // 000000240D30: 7E660321
	v_mov_b32_e32 v52, v33                                     // 000000240D34: 7E680321
	v_mov_b32_e32 v53, v33                                     // 000000240D38: 7E6A0321
	v_mov_b32_e32 v54, v33                                     // 000000240D3C: 7E6C0321
	v_mov_b32_e32 v55, v33                                     // 000000240D40: 7E6E0321
	v_mov_b32_e32 v56, v33                                     // 000000240D44: 7E700321
	v_mov_b32_e32 v17, v33                                     // 000000240D48: 7E220321
	v_mov_b32_e32 v18, v33                                     // 000000240D4C: 7E240321
	v_mov_b32_e32 v19, v33                                     // 000000240D50: 7E260321
	v_mov_b32_e32 v20, v33                                     // 000000240D54: 7E280321
	v_mov_b32_e32 v21, v33                                     // 000000240D58: 7E2A0321
	v_mov_b32_e32 v22, v33                                     // 000000240D5C: 7E2C0321
	v_mov_b32_e32 v23, v33                                     // 000000240D60: 7E2E0321
	v_mov_b32_e32 v24, v33                                     // 000000240D64: 7E300321
	v_mov_b32_e32 v57, v33                                     // 000000240D68: 7E720321
	v_mov_b32_e32 v58, v33                                     // 000000240D6C: 7E740321
	v_mov_b32_e32 v59, v33                                     // 000000240D70: 7E760321
	v_mov_b32_e32 v60, v33                                     // 000000240D74: 7E780321
	v_mov_b32_e32 v61, v33                                     // 000000240D78: 7E7A0321
	v_mov_b32_e32 v62, v33                                     // 000000240D7C: 7E7C0321
	v_mov_b32_e32 v63, v33                                     // 000000240D80: 7E7E0321
	v_mov_b32_e32 v64, v33                                     // 000000240D84: 7E800321
	v_mov_b32_e32 v25, v33                                     // 000000240D88: 7E320321
	v_mov_b32_e32 v26, v33                                     // 000000240D8C: 7E340321
	v_mov_b32_e32 v27, v33                                     // 000000240D90: 7E360321
	v_mov_b32_e32 v28, v33                                     // 000000240D94: 7E380321
	v_mov_b32_e32 v29, v33                                     // 000000240D98: 7E3A0321
	v_mov_b32_e32 v30, v33                                     // 000000240D9C: 7E3C0321
	v_mov_b32_e32 v31, v33                                     // 000000240DA0: 7E3E0321
	v_mov_b32_e32 v32, v33                                     // 000000240DA4: 7E400321
	s_mov_b32 s1, 0                                            // 000000240DA8: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000240DAC: BF870009
	s_mov_b32 s0, s1                                           // 000000240DB0: BE800001
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000240DB4: BF8700B9
	s_lshl_b64 s[2:3], s[0:1], 1                               // 000000240DB8: 84828100
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v78, v74           // 000000240DBC: CA100080 4D4E014A
	.long 0xd7006a43                                           // 000000240DC4: D7006A43
	v_cndmask_b32_e32 v0, v75, v2, vcc_lo                      // 000000240DC8: 0200054B
	v_add_co_ci_u32_e64 v68, null, s3, v76, vcc_lo             // 000000240DCC: D5207C44 01AA9803
	v_mov_b32_e32 v79, v71                                     // 000000240DD4: 7E9E0347
	s_mov_b32 s5, s1                                           // 000000240DD8: BE850001
	s_barrier                                                  // 000000240DDC: BFBD0000
	buffer_gl0_inv                                             // 000000240DE0: E0AC0000 00000000
	s_nop 0                                                    // 000000240DE8: BF800000
	s_nop 0                                                    // 000000240DEC: BF800000
	s_nop 0                                                    // 000000240DF0: BF800000
	s_nop 0                                                    // 000000240DF4: BF800000
	s_nop 0                                                    // 000000240DF8: BF800000
	s_nop 0                                                    // 000000240DFC: BF800000
	v_mad_u32_u24 v80, 0xa00, v77, v73                         // 000000240E00: D60B0050 05269AFF 00000A00
	v_add_nc_u32_e32 v79, 0x100, v79                           // 000000240E0C: 4A9E9EFF 00000100
	v_add_nc_u32_e32 v77, 1, v77                               // 000000240E14: 4A9A9A81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000240E18: BF870193
	v_mad_i64_i32 v[80:81], null, 0x280, v80, v[67:68]         // 000000240E1C: D6FF7C50 050EA0FF 00000280
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v79                        // 000000240E28: 7C929EFF 000002FF
	s_or_b32 s5, vcc_lo, s5                                    // 000000240E30: 8C05056A
	global_load_b128 v[80:83], v[80:81], off                   // 000000240E34: DC5E0000 507C0050
	s_waitcnt vmcnt(0)                                         // 000000240E3C: BF8903F7
	ds_store_b128 v78, v[80:83]                                // 000000240E40: DB7C0000 0000504E
	v_add_nc_u32_e32 v78, 0x1400, v78                          // 000000240E48: 4A9C9CFF 00001400
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000240E50: 917E057E
	s_cbranch_execnz 65514                                     // 000000240E54: BFA6FFEA <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x200>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000240E58: 8C7E057E
	.long 0xd7006a43                                           // 000000240E5C: D7006A43
	v_cndmask_b32_e32 v0, v65, v2, vcc_lo                      // 000000240E60: 02000541
	s_delay_alu instid0(VALU_DEP_1)                            // 000000240E64: BF870001
	v_add_co_ci_u32_e64 v68, null, s3, v66, vcc_lo             // 000000240E68: D5207C44 01AA8403
	s_waitcnt lgkmcnt(0)                                       // 000000240E70: BF89FC07
	s_barrier                                                  // 000000240E74: BFBD0000
	buffer_gl0_inv                                             // 000000240E78: E0AC0000 00000000
	s_clause 0x7                                               // 000000240E80: BF850007
	global_load_b128 v[81:84], v[67:68], off offset:16         // 000000240E84: DC5E0010 517C0043
	global_load_b128 v[77:80], v[67:68], off                   // 000000240E8C: DC5E0000 4D7C0043
	global_load_b128 v[89:92], v[67:68], off offset:48         // 000000240E94: DC5E0030 597C0043
	global_load_b128 v[85:88], v[67:68], off offset:32         // 000000240E9C: DC5E0020 557C0043
	global_load_b128 v[97:100], v[67:68], off offset:80        // 000000240EA4: DC5E0050 617C0043
	global_load_b128 v[93:96], v[67:68], off offset:64         // 000000240EAC: DC5E0040 5D7C0043
	global_load_b128 v[105:108], v[67:68], off offset:112      // 000000240EB4: DC5E0070 697C0043
	global_load_b128 v[101:104], v[67:68], off offset:96       // 000000240EBC: DC5E0060 657C0043
	ds_load_b128 v[109:112], v72                               // 000000240EC4: DBFC0000 6D000048
	ds_load_b128 v[113:116], v72 offset:16                     // 000000240ECC: DBFC0010 71000048
	ds_load_b128 v[121:124], v72 offset:2576                   // 000000240ED4: DBFC0A10 79000048
	ds_load_b128 v[117:120], v72 offset:2560                   // 000000240EDC: DBFC0A00 75000048
	s_add_i32 s2, s0, 64                                       // 000000240EE4: 8102C000
	s_cmpk_gt_u32 s0, 0xff                                     // 000000240EE8: B58000FF
	s_mov_b32 s0, s2                                           // 000000240EEC: BE800002
	s_waitcnt vmcnt(6) lgkmcnt(2)                              // 000000240EF0: BF891827
	v_wmma_f32_16x16x16_bf16 v[33:40], v[77:84], v[109:116], v[33:40]// 000000240EF4: CC414021 1C86DB4D
	ds_load_b128 v[113:116], v72 offset:5136                   // 000000240EFC: DBFC1410 71000048
	ds_load_b128 v[109:112], v72 offset:5120                   // 000000240F04: DBFC1400 6D000048
	s_waitcnt lgkmcnt(2)                                       // 000000240F0C: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[1:8], v[77:84], v[117:124], v[1:8]// 000000240F10: CC414001 1C06EB4D
	ds_load_b128 v[121:124], v72 offset:7696                   // 000000240F18: DBFC1E10 79000048
	ds_load_b128 v[117:120], v72 offset:7680                   // 000000240F20: DBFC1E00 75000048
	s_waitcnt lgkmcnt(2)                                       // 000000240F28: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[41:48], v[77:84], v[109:116], v[41:48]// 000000240F2C: CC414029 1CA6DB4D
	ds_load_b128 v[113:116], v72 offset:10256                  // 000000240F34: DBFC2810 71000048
	ds_load_b128 v[109:112], v72 offset:10240                  // 000000240F3C: DBFC2800 6D000048
	s_waitcnt lgkmcnt(2)                                       // 000000240F44: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[9:16], v[77:84], v[117:124], v[9:16]// 000000240F48: CC414009 1C26EB4D
	ds_load_b128 v[121:124], v72 offset:12816                  // 000000240F50: DBFC3210 79000048
	ds_load_b128 v[117:120], v72 offset:12800                  // 000000240F58: DBFC3200 75000048
	s_waitcnt lgkmcnt(2)                                       // 000000240F60: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[49:56], v[77:84], v[109:116], v[49:56]// 000000240F64: CC414031 1CC6DB4D
	ds_load_b128 v[113:116], v72 offset:15376                  // 000000240F6C: DBFC3C10 71000048
	ds_load_b128 v[109:112], v72 offset:15360                  // 000000240F74: DBFC3C00 6D000048
	s_waitcnt lgkmcnt(2)                                       // 000000240F7C: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[17:24], v[77:84], v[117:124], v[17:24]// 000000240F80: CC414011 1C46EB4D
	ds_load_b128 v[121:124], v72 offset:17936                  // 000000240F88: DBFC4610 79000048
	ds_load_b128 v[117:120], v72 offset:17920                  // 000000240F90: DBFC4600 75000048
	s_waitcnt lgkmcnt(2)                                       // 000000240F98: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[57:64], v[77:84], v[109:116], v[57:64]// 000000240F9C: CC414039 1CE6DB4D
	ds_load_b128 v[109:112], v72 offset:32                     // 000000240FA4: DBFC0020 6D000048
	ds_load_b128 v[113:116], v72 offset:48                     // 000000240FAC: DBFC0030 71000048
	s_waitcnt lgkmcnt(2)                                       // 000000240FB4: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[25:32], v[77:84], v[117:124], v[25:32]// 000000240FB8: CC414019 1C66EB4D
	ds_load_b128 v[81:84], v72 offset:2608                     // 000000240FC0: DBFC0A30 51000048
	ds_load_b128 v[77:80], v72 offset:2592                     // 000000240FC8: DBFC0A20 4D000048
	ds_load_b128 v[121:124], v72 offset:5168                   // 000000240FD0: DBFC1430 79000048
	ds_load_b128 v[117:120], v72 offset:5152                   // 000000240FD8: DBFC1420 75000048
	s_waitcnt vmcnt(4) lgkmcnt(2)                              // 000000240FE0: BF891027
	v_wmma_f32_16x16x16_bf16 v[1:8], v[85:92], v[77:84], v[1:8]// 000000240FE4: CC414001 1C069B55
	v_wmma_f32_16x16x16_bf16 v[33:40], v[85:92], v[109:116], v[33:40]// 000000240FEC: CC414021 1C86DB55
	ds_load_b128 v[113:116], v72 offset:7728                   // 000000240FF4: DBFC1E30 71000048
	ds_load_b128 v[109:112], v72 offset:7712                   // 000000240FFC: DBFC1E20 6D000048
	ds_load_b128 v[81:84], v72 offset:10288                    // 000000241004: DBFC2830 51000048
	ds_load_b128 v[77:80], v72 offset:10272                    // 00000024100C: DBFC2820 4D000048
	s_waitcnt lgkmcnt(4)                                       // 000000241014: BF89FC47
	v_wmma_f32_16x16x16_bf16 v[41:48], v[85:92], v[117:124], v[41:48]// 000000241018: CC414029 1CA6EB55
	ds_load_b128 v[121:124], v72 offset:12848                  // 000000241020: DBFC3230 79000048
	ds_load_b128 v[117:120], v72 offset:12832                  // 000000241028: DBFC3220 75000048
	s_waitcnt lgkmcnt(4)                                       // 000000241030: BF89FC47
	v_wmma_f32_16x16x16_bf16 v[9:16], v[85:92], v[109:116], v[9:16]// 000000241034: CC414009 1C26DB55
	ds_load_b128 v[113:116], v72 offset:15408                  // 00000024103C: DBFC3C30 71000048
	ds_load_b128 v[109:112], v72 offset:15392                  // 000000241044: DBFC3C20 6D000048
	s_waitcnt lgkmcnt(4)                                       // 00000024104C: BF89FC47
	v_wmma_f32_16x16x16_bf16 v[49:56], v[85:92], v[77:84], v[49:56]// 000000241050: CC414031 1CC69B55
	ds_load_b128 v[81:84], v72 offset:17968                    // 000000241058: DBFC4630 51000048
	ds_load_b128 v[77:80], v72 offset:17952                    // 000000241060: DBFC4620 4D000048
	s_waitcnt lgkmcnt(4)                                       // 000000241068: BF89FC47
	v_wmma_f32_16x16x16_bf16 v[17:24], v[85:92], v[117:124], v[17:24]// 00000024106C: CC414011 1C46EB55
	ds_load_b128 v[121:124], v72 offset:80                     // 000000241074: DBFC0050 79000048
	ds_load_b128 v[117:120], v72 offset:64                     // 00000024107C: DBFC0040 75000048
	s_waitcnt lgkmcnt(4)                                       // 000000241084: BF89FC47
	v_wmma_f32_16x16x16_bf16 v[57:64], v[85:92], v[109:116], v[57:64]// 000000241088: CC414039 1CE6DB55
	ds_load_b128 v[113:116], v72 offset:2640                   // 000000241090: DBFC0A50 71000048
	ds_load_b128 v[109:112], v72 offset:2624                   // 000000241098: DBFC0A40 6D000048
	s_waitcnt lgkmcnt(4)                                       // 0000002410A0: BF89FC47
	v_wmma_f32_16x16x16_bf16 v[25:32], v[85:92], v[77:84], v[25:32]// 0000002410A4: CC414019 1C669B55
	ds_load_b128 v[81:84], v72 offset:5200                     // 0000002410AC: DBFC1450 51000048
	ds_load_b128 v[77:80], v72 offset:5184                     // 0000002410B4: DBFC1440 4D000048
	ds_load_b128 v[89:92], v72 offset:7760                     // 0000002410BC: DBFC1E50 59000048
	ds_load_b128 v[85:88], v72 offset:7744                     // 0000002410C4: DBFC1E40 55000048
	s_waitcnt vmcnt(2) lgkmcnt(6)                              // 0000002410CC: BF890867
	v_wmma_f32_16x16x16_bf16 v[33:40], v[93:100], v[117:124], v[33:40]// 0000002410D0: CC414021 1C86EB5D
	ds_load_b128 v[121:124], v72 offset:10320                  // 0000002410D8: DBFC2850 79000048
	ds_load_b128 v[117:120], v72 offset:10304                  // 0000002410E0: DBFC2840 75000048
	s_waitcnt lgkmcnt(4)                                       // 0000002410E8: BF89FC47
	v_wmma_f32_16x16x16_bf16 v[41:48], v[93:100], v[77:84], v[41:48]// 0000002410EC: CC414029 1CA69B5D
	v_wmma_f32_16x16x16_bf16 v[1:8], v[93:100], v[109:116], v[1:8]// 0000002410F4: CC414001 1C06DB5D
	ds_load_b128 v[113:116], v72 offset:12880                  // 0000002410FC: DBFC3250 71000048
	ds_load_b128 v[109:112], v72 offset:12864                  // 000000241104: DBFC3240 6D000048
	ds_load_b128 v[81:84], v72 offset:15440                    // 00000024110C: DBFC3C50 51000048
	ds_load_b128 v[77:80], v72 offset:15424                    // 000000241114: DBFC3C40 4D000048
	s_waitcnt lgkmcnt(6)                                       // 00000024111C: BF89FC67
	v_wmma_f32_16x16x16_bf16 v[9:16], v[93:100], v[85:92], v[9:16]// 000000241120: CC414009 1C26AB5D
	ds_load_b128 v[89:92], v72 offset:18000                    // 000000241128: DBFC4650 59000048
	ds_load_b128 v[85:88], v72 offset:17984                    // 000000241130: DBFC4640 55000048
	s_waitcnt lgkmcnt(6)                                       // 000000241138: BF89FC67
	v_wmma_f32_16x16x16_bf16 v[49:56], v[93:100], v[117:124], v[49:56]// 00000024113C: CC414031 1CC6EB5D
	ds_load_b128 v[121:124], v72 offset:112                    // 000000241144: DBFC0070 79000048
	ds_load_b128 v[117:120], v72 offset:96                     // 00000024114C: DBFC0060 75000048
	s_waitcnt lgkmcnt(6)                                       // 000000241154: BF89FC67
	v_wmma_f32_16x16x16_bf16 v[17:24], v[93:100], v[109:116], v[17:24]// 000000241158: CC414011 1C46DB5D
	ds_load_b128 v[113:116], v72 offset:2672                   // 000000241160: DBFC0A70 71000048
	ds_load_b128 v[109:112], v72 offset:2656                   // 000000241168: DBFC0A60 6D000048
	s_waitcnt lgkmcnt(6)                                       // 000000241170: BF89FC67
	v_wmma_f32_16x16x16_bf16 v[57:64], v[93:100], v[77:84], v[57:64]// 000000241174: CC414039 1CE69B5D
	ds_load_b128 v[81:84], v72 offset:5232                     // 00000024117C: DBFC1470 51000048
	ds_load_b128 v[77:80], v72 offset:5216                     // 000000241184: DBFC1460 4D000048
	s_waitcnt lgkmcnt(6)                                       // 00000024118C: BF89FC67
	v_wmma_f32_16x16x16_bf16 v[25:32], v[93:100], v[85:92], v[25:32]// 000000241190: CC414019 1C66AB5D
	ds_load_b128 v[89:92], v72 offset:7792                     // 000000241198: DBFC1E70 59000048
	ds_load_b128 v[85:88], v72 offset:7776                     // 0000002411A0: DBFC1E60 55000048
	ds_load_b128 v[97:100], v72 offset:10352                   // 0000002411A8: DBFC2870 61000048
	ds_load_b128 v[93:96], v72 offset:10336                    // 0000002411B0: DBFC2860 5D000048
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 0000002411B8: BF890087
	v_wmma_f32_16x16x16_bf16 v[33:40], v[101:108], v[117:124], v[33:40]// 0000002411BC: CC414021 1C86EB65
	ds_load_b128 v[121:124], v72 offset:12912                  // 0000002411C4: DBFC3270 79000048
	ds_load_b128 v[117:120], v72 offset:12896                  // 0000002411CC: DBFC3260 75000048
	s_waitcnt lgkmcnt(8)                                       // 0000002411D4: BF89FC87
	v_wmma_f32_16x16x16_bf16 v[1:8], v[101:108], v[109:116], v[1:8]// 0000002411D8: CC414001 1C06DB65
	ds_load_b128 v[113:116], v72 offset:15472                  // 0000002411E0: DBFC3C70 71000048
	ds_load_b128 v[109:112], v72 offset:15456                  // 0000002411E8: DBFC3C60 6D000048
	s_waitcnt lgkmcnt(8)                                       // 0000002411F0: BF89FC87
	v_wmma_f32_16x16x16_bf16 v[41:48], v[101:108], v[77:84], v[41:48]// 0000002411F4: CC414029 1CA69B65
	ds_load_b128 v[81:84], v72 offset:18032                    // 0000002411FC: DBFC4670 51000048
	ds_load_b128 v[77:80], v72 offset:18016                    // 000000241204: DBFC4660 4D000048
	s_waitcnt lgkmcnt(8)                                       // 00000024120C: BF89FC87
	v_wmma_f32_16x16x16_bf16 v[9:16], v[101:108], v[85:92], v[9:16]// 000000241210: CC414009 1C26AB65
	s_waitcnt lgkmcnt(6)                                       // 000000241218: BF89FC67
	v_wmma_f32_16x16x16_bf16 v[49:56], v[101:108], v[93:100], v[49:56]// 00000024121C: CC414031 1CC6BB65
	s_waitcnt lgkmcnt(4)                                       // 000000241224: BF89FC47
	v_wmma_f32_16x16x16_bf16 v[17:24], v[101:108], v[117:124], v[17:24]// 000000241228: CC414011 1C46EB65
	s_waitcnt lgkmcnt(2)                                       // 000000241230: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[57:64], v[101:108], v[109:116], v[57:64]// 000000241234: CC414039 1CE6DB65
	s_waitcnt lgkmcnt(0)                                       // 00000024123C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[101:108], v[77:84], v[25:32]// 000000241240: CC414019 1C669B65
	s_cbranch_scc0 65242                                       // 000000241248: BFA1FEDA <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x1b4>
	v_or_b32_e32 v67, s4, v70                                  // 00000024124C: 38868C04
	v_lshrrev_b32_e32 v0, 4, v0                                // 000000241250: 32000084
	s_cmp_lg_u64 s[16:17], 0                                   // 000000241254: BF118010
	s_cselect_b32 s5, -1, 0                                    // 000000241258: 980580C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024125C: BF870112
	v_ashrrev_i32_e32 v68, 31, v67                             // 000000241260: 3488869F
	v_and_or_b32 v74, v0, 1, v69                               // 000000241264: D657004A 05150300
	v_cndmask_b32_e64 v73, 0, 1, s5                            // 00000024126C: D5010049 00150280
	s_cmp_lg_u64 s[18:19], 0                                   // 000000241274: BF118012
	s_cselect_b32 s11, -1, 0                                   // 000000241278: 980B80C1
	.long 0xd73c0041                                           // 00000024127C: D73C0041
	v_cndmask_b32_e32 v1, 1, v67, vcc_lo                       // 000000241280: 02028681
	.long 0xd4440000                                           // 000000241284: D4440000
	v_cndmask_b32_e32 v1, s20, v74, vcc_lo                     // 000000241288: 02029414
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000024128C: BF870092
	.long 0xd7006a45                                           // 000000241290: D7006A45
	v_cndmask_b32_e32 v1, s12, v65, vcc_lo                     // 000000241294: 0202820C
	v_add_co_ci_u32_e64 v70, null, s13, v66, vcc_lo            // 000000241298: D5207C46 01AA840D
	s_and_saveexec_b32 s4, s0                                  // 0000002412A0: BE842000
	s_cbranch_execz 284                                        // 0000002412A4: BFA5011C <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0xb18>
	v_mad_i64_i32 v[71:72], null, 0x5000, v74, v[69:70]        // 0000002412A8: D6FF7C47 051694FF 00005000
	v_bfe_u32 v79, v57, 16, 1                                  // 0000002412B4: D610004F 02052139
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002412BC: BF8700B1
	v_add3_u32 v57, v57, v79, 0x7fff                           // 0000002412C0: D6550039 03FE9F39 00007FFF
	global_load_u16 v0, v[71:72], off                          // 0000002412CC: DC4A0000 007C0047
	.long 0xd7006a4b                                           // 0000002412D4: D7006A4B
	v_cndmask_b32_e32 v1, 0x1000, v71, vcc_lo                  // 0000002412D8: 02028EFF 00001000
	v_add_co_ci_u32_e64 v76, null, 0, v72, vcc_lo              // 0000002412E0: D5207C4C 01AA9080
	.long 0xd7006a4d                                           // 0000002412E8: D7006A4D
	v_cndmask_b32_e32 v1, 0x2000, v71, vcc_lo                  // 0000002412EC: 02028EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002412F4: BF8700B1
	v_add_co_ci_u32_e64 v78, null, 0, v72, vcc_lo              // 0000002412F8: D5207C4E 01AA9080
	global_load_u16 v75, v[75:76], off offset:1024             // 000000241300: DC4A0400 4B7C004B
	.long 0xd7006a47                                           // 000000241308: D7006A47
	v_cndmask_b32_e32 v1, 0x3000, v71, vcc_lo                  // 00000024130C: 02028EFF 00003000
	v_add_co_ci_u32_e64 v72, null, 0, v72, vcc_lo              // 000000241314: D5207C48 01AA9080
	s_clause 0x1                                               // 00000024131C: BF850001
	global_load_u16 v76, v[77:78], off offset:2048             // 000000241320: DC4A0800 4C7C004D
	global_load_u16 v71, v[71:72], off offset:3072             // 000000241328: DC4A0C00 477C0047
	v_bfe_u32 v78, v49, 16, 1                                  // 000000241330: D610004E 02052131
	v_bfe_u32 v77, v41, 16, 1                                  // 000000241338: D610004D 02052129
	v_bfe_u32 v72, v33, 16, 1                                  // 000000241340: D6100048 02052121
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000241348: BF870193
	v_add3_u32 v49, v49, v78, 0x7fff                           // 00000024134C: D6550031 03FE9D31 00007FFF
	v_add3_u32 v41, v41, v77, 0x7fff                           // 000000241358: D6550029 03FE9B29 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000241364: BF870193
	v_add3_u32 v33, v33, v72, 0x7fff                           // 000000241368: D6550021 03FE9121 00007FFF
	v_and_b32_e32 v49, 0xffff0000, v49                         // 000000241374: 366262FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024137C: BF870112
	v_and_b32_e32 v33, 0xffff0000, v33                         // 000000241380: 364242FF FFFF0000
	v_mul_f32_e32 v49, 0xbfb8aa3b, v49                         // 000000241388: 106262FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241390: BF870112
	v_mul_f32_e32 v33, 0xbfb8aa3b, v33                         // 000000241394: 104242FF BFB8AA3B
	v_exp_f32_e32 v49, v49                                     // 00000024139C: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002413A0: BF870095
	v_add_f32_e32 v49, 1.0, v49                                // 0000002413A4: 066262F2
	v_div_scale_f32 v78, null, v49, v49, 1.0                   // 0000002413A8: D6FC7C4E 03CA6331
	v_div_scale_f32 v89, s2, 1.0, v49, 1.0                     // 0000002413B0: D6FC0259 03CA62F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002413B8: BF870292
	v_rcp_f32_e32 v82, v78                                     // 0000002413BC: 7EA4554E
	v_fma_f32 v88, -v78, v82, 1.0                              // 0000002413C0: D6130058 23CAA54E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002413C8: BF870121
	v_dual_fmac_f32 v82, v88, v82 :: v_dual_and_b32 v41, 0xffff0000, v41// 0000002413CC: C824A558 522852FF FFFF0000
	v_and_b32_e32 v57, 0xffff0000, v57                         // 0000002413D8: 367272FF FFFF0000
	v_mul_f32_e32 v41, 0xbfb8aa3b, v41                         // 0000002413E0: 105252FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002413E8: BF870112
	v_mul_f32_e32 v57, 0xbfb8aa3b, v57                         // 0000002413EC: 107272FF BFB8AA3B
	v_exp_f32_e32 v41, v41                                     // 0000002413F4: 7E524B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000002413F8: BF870311
	v_exp_f32_e32 v57, v57                                     // 0000002413FC: 7E724B39
	v_add_f32_e32 v41, 1.0, v41                                // 000000241400: 065252F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241404: BF870115
	v_add_f32_e32 v57, 1.0, v57                                // 000000241408: 067272F2
	v_div_scale_f32 v77, null, v41, v41, 1.0                   // 00000024140C: D6FC7C4D 03CA5329
	v_div_scale_f32 v85, s1, 1.0, v41, 1.0                     // 000000241414: D6FC0155 03CA52F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000024141C: BF870193
	v_div_scale_f32 v79, null, v57, v57, 1.0                   // 000000241420: D6FC7C4F 03CA7339
	v_rcp_f32_e32 v81, v77                                     // 000000241428: 7EA2554D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000024142C: BF870311
	v_rcp_f32_e32 v83, v79                                     // 000000241430: 7EA6554F
	v_fma_f32 v87, -v77, v81, 1.0                              // 000000241434: D6130057 23CAA34D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024143C: BF870115
	v_fma_f32 v90, -v79, v83, 1.0                              // 000000241440: D613005A 23CAA74F
	v_fmac_f32_e32 v81, v87, v81                               // 000000241448: 56A2A357
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000024144C: BF870121
	v_dual_fmac_f32 v83, v90, v83 :: v_dual_mul_f32 v88, v85, v81// 000000241450: C806A75A 5358A355
	v_mul_f32_e32 v90, v89, v82                                // 000000241458: 10B4A559
	v_fma_f32 v93, -v77, v88, v85                              // 00000024145C: D613005D 2556B14D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241464: BF870112
	v_fma_f32 v94, -v78, v90, v89                              // 000000241468: D613005E 2566B54E
	v_fmac_f32_e32 v88, v93, v81                               // 000000241470: 56B0A35D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241474: BF870112
	v_fmac_f32_e32 v90, v94, v82                               // 000000241478: 56B4A55E
	v_fma_f32 v77, -v77, v88, v85                              // 00000024147C: D613004D 2556B14D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 000000241484: BF8702C2
	v_fma_f32 v78, -v78, v90, v89                              // 000000241488: D613004E 2566B54E
	s_waitcnt vmcnt(3)                                         // 000000241490: BF890FF7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000241494: 30000090
	v_exp_f32_e32 v33, v33                                     // 000000241498: 7E424B21
	v_add_f32_e32 v33, 1.0, v33                                // 00000024149C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002414A0: BF870121
	v_div_scale_f32 v72, null, v33, v33, 1.0                   // 0000002414A4: D6FC7C48 03CA4321
	v_div_scale_f32 v84, vcc_lo, 1.0, v33, 1.0                 // 0000002414AC: D6FC6A54 03CA42F2
	v_rcp_f32_e32 v80, v72                                     // 0000002414B4: 7EA05548
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002414B8: BF870095
	v_fma_f32 v86, -v72, v80, 1.0                              // 0000002414BC: D6130056 23CAA148
	v_fmac_f32_e32 v80, v86, v80                               // 0000002414C4: 56A0A156
	v_div_scale_f32 v86, s3, 1.0, v57, 1.0                     // 0000002414C8: D6FC0356 03CA72F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002414D0: BF870092
	v_mul_f32_e32 v87, v84, v80                                // 0000002414D4: 10AEA154
	v_fma_f32 v92, -v72, v87, v84                              // 0000002414D8: D613005C 2552AF48
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002414E0: BF870091
	v_fmac_f32_e32 v87, v92, v80                               // 0000002414E4: 56AEA15C
	v_fma_f32 v72, -v72, v87, v84                              // 0000002414E8: D6130048 2552AF48
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000002414F0: BF870141
	v_div_fmas_f32 v72, v72, v80, v87                          // 0000002414F4: D6370048 055EA148
	s_mov_b32 vcc_lo, s1                                       // 0000002414FC: BEEA0001
	v_div_fmas_f32 v77, v77, v81, v88                          // 000000241500: D637004D 0562A34D
	s_mov_b32 vcc_lo, s2                                       // 000000241508: BEEA0002
	v_div_fixup_f32 v33, v72, v33, 1.0                         // 00000024150C: D6270021 03CA4348
	v_div_fmas_f32 v72, v78, v82, v90                          // 000000241514: D6370048 056AA54E
	s_mov_b32 vcc_lo, s3                                       // 00000024151C: BEEA0003
	v_div_fixup_f32 v41, v77, v41, 1.0                         // 000000241520: D6270029 03CA534D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000241528: BF870193
	v_bfe_u32 v77, v33, 16, 1                                  // 00000024152C: D610004D 02052121
	v_div_fixup_f32 v49, v72, v49, 1.0                         // 000000241534: D6270031 03CA6348
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000024153C: BF870193
	v_bfe_u32 v72, v41, 16, 1                                  // 000000241540: D6100048 02052129
	v_add3_u32 v33, v33, v77, 0x7fff                           // 000000241548: D6550021 03FE9B21 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000241554: BF870193
	v_bfe_u32 v77, v49, 16, 1                                  // 000000241558: D610004D 02052131
	v_add3_u32 v41, v41, v72, 0x7fff                           // 000000241560: D6550029 03FE9129 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000024156C: BF870193
	v_and_b32_e32 v33, 0xffff0000, v33                         // 000000241570: 364242FF FFFF0000
	v_add3_u32 v49, v49, v77, 0x7fff                           // 000000241578: D6550031 03FE9B31 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000241584: BF870193
	v_and_b32_e32 v41, 0xffff0000, v41                         // 000000241588: 365252FF FFFF0000
	v_fma_f32 v0, v0, v33, 0                                   // 000000241590: D6130000 02024300
	s_waitcnt vmcnt(2)                                         // 000000241598: BF890BF7
	v_lshlrev_b32_e32 v33, 16, v75                             // 00000024159C: 30429690
	v_mul_f32_e32 v91, v86, v83                                // 0000002415A0: 10B6A756
	v_and_b32_e32 v49, 0xffff0000, v49                         // 0000002415A4: 366262FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002415AC: BF870193
	v_fmac_f32_e32 v0, v33, v41                                // 0000002415B0: 56005321
	v_fma_f32 v95, -v79, v91, v86                              // 0000002415B4: D613005F 255AB74F
	s_waitcnt vmcnt(0)                                         // 0000002415BC: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v71                             // 0000002415C0: 30528E90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002415C4: BF870092
	v_fmac_f32_e32 v91, v95, v83                               // 0000002415C8: 56B6A75F
	v_fma_f32 v79, -v79, v91, v86                              // 0000002415CC: D613004F 255AB74F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002415D4: BF870091
	v_div_fmas_f32 v78, v79, v83, v91                          // 0000002415D8: D637004E 056EA74F
	v_div_fixup_f32 v57, v78, v57, 1.0                         // 0000002415E0: D6270039 03CA734E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002415E8: BF870091
	v_bfe_u32 v72, v57, 16, 1                                  // 0000002415EC: D6100048 02052139
	v_add3_u32 v57, v57, v72, 0x7fff                           // 0000002415F4: D6550039 03FE9139 00007FFF
	v_lshlrev_b32_e32 v72, 16, v76                             // 000000241600: 30909890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241604: BF870112
	v_and_b32_e32 v33, 0xffff0000, v57                         // 000000241608: 364272FF FFFF0000
	v_fmac_f32_e32 v0, v72, v49                                // 000000241610: 56006348
	v_mad_i64_i32 v[71:72], null, 0xa00, v74, v[67:68]         // 000000241614: D6FF7C47 050E94FF 00000A00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241620: BF870112
	v_fmac_f32_e32 v0, v41, v33                                // 000000241624: 56004329
	.long 0xd73c004b                                           // 000000241628: D73C004B
	v_cndmask_b32_e32 v1, 1, v71, vcc_lo                       // 00000024162C: 02028E81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241630: BF870092
	v_mul_f32_e32 v0, 0x3e800000, v0                           // 000000241634: 100000FF 3E800000
	v_bfe_u32 v33, v0, 16, 1                                   // 00000024163C: D6100021 02052100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241644: BF870093
	.long 0xd7006a4b                                           // 000000241648: D7006A4B
	v_cndmask_b32_e32 v1, s14, v75, vcc_lo                     // 00000024164C: 0202960E
	v_add_co_ci_u32_e64 v76, null, s15, v76, vcc_lo            // 000000241650: D5207C4C 01AA980F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000241658: BF870003
	v_add3_u32 v33, v0, v33, 0x7fff                            // 00000024165C: D6550021 03FE4300 00007FFF
	s_and_not1_b32 vcc_lo, exec_lo, s5                         // 000000241668: 916A057E
	global_store_d16_hi_b16 v[75:76], v33, off                 // 00000024166C: DC960000 007C214B
	s_cbranch_vccnz 9                                          // 000000241674: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0xa9c>
	.long 0xd73c0047                                           // 000000241678: D73C0047
	v_cndmask_b32_e32 v1, 2, v71, vcc_lo                       // 00000024167C: 02028E82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241680: BF870091
	.long 0xd7006a47                                           // 000000241684: D7006A47
	v_cndmask_b32_e32 v1, s16, v71, vcc_lo                     // 000000241688: 02028E10
	v_add_co_ci_u32_e64 v72, null, s17, v72, vcc_lo            // 00000024168C: D5207C48 01AA9011
	global_store_b32 v[71:72], v0, off                         // 000000241694: DC6A0000 007C0047
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 00000024169C: 916A0B7E
	s_cbranch_vccnz 29                                         // 0000002416A0: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0xb18>
	v_and_b32_e32 v41, 0xffff0000, v33                         // 0000002416A4: 365242FF FFFF0000
	v_mad_i64_i32 v[71:72], null, 0x2800, v74, s[18:19]        // 0000002416AC: D6FF7C47 004A94FF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002416B8: BF870112
	v_sub_f32_e32 v0, v0, v41                                  // 0000002416BC: 08005300
	.long 0xd7006a47                                           // 0000002416C0: D7006A47
	v_cndmask_b32_e32 v1, v71, v65, vcc_lo                     // 0000002416C4: 02028347
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002416C8: BF870212
	v_bfe_u32 v41, v0, 16, 1                                   // 0000002416CC: D6100029 02052100
	v_add_co_ci_u32_e64 v72, null, v72, v66, vcc_lo            // 0000002416D4: D5207C48 01AA8548
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002416DC: BF870193
	.long 0xd7006a4b                                           // 0000002416E0: D7006A4B
	v_cndmask_b32_e32 v1, 0x1000, v71, vcc_lo                  // 0000002416E4: 02028EFF 00001000
	v_add3_u32 v0, v0, v41, 0x7fff                             // 0000002416EC: D6550000 03FE5300 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002416F8: BF870003
	v_add_co_ci_u32_e64 v76, null, 0, v72, vcc_lo              // 0000002416FC: D5207C4C 01AA9080
	s_clause 0x1                                               // 000000241704: BF850001
	global_store_d16_hi_b16 v[71:72], v33, off                 // 000000241708: DC960000 007C2147
	global_store_d16_hi_b16 v[75:76], v0, off offset:1024      // 000000241710: DC960400 007C004B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000241718: 8C7E047E
	v_or_b32_e32 v41, 2, v74                                   // 00000024171C: 38529482
	s_delay_alu instid0(VALU_DEP_1)                            // 000000241720: BF870001
	.long 0xd4440001                                           // 000000241724: D4440001
	v_cndmask_b32_e32 v1, s20, v41, vcc_lo                     // 000000241728: 02025214
	s_and_saveexec_b32 s5, s1                                  // 00000024172C: BE852001
	s_cbranch_execz 282                                        // 000000241730: BFA5011A <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0xf9c>
	v_mad_i64_i32 v[71:72], null, 0x5000, v41, v[69:70]        // 000000241734: D6FF7C47 051652FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241740: BF870091
	.long 0xd7006a4b                                           // 000000241744: D7006A4B
	v_cndmask_b32_e32 v1, 0x1000, v71, vcc_lo                  // 000000241748: 02028EFF 00001000
	v_add_co_ci_u32_e64 v76, null, 0, v72, vcc_lo              // 000000241750: D5207C4C 01AA9080
	.long 0xd7006a4d                                           // 000000241758: D7006A4D
	v_cndmask_b32_e32 v1, 0x2000, v71, vcc_lo                  // 00000024175C: 02028EFF 00002000
	s_clause 0x1                                               // 000000241764: BF850001
	global_load_u16 v0, v[71:72], off                          // 000000241768: DC4A0000 007C0047
	global_load_u16 v33, v[75:76], off offset:1024             // 000000241770: DC4A0400 217C004B
	v_add_co_ci_u32_e64 v78, null, 0, v72, vcc_lo              // 000000241778: D5207C4E 01AA9080
	.long 0xd7006a47                                           // 000000241780: D7006A47
	v_cndmask_b32_e32 v1, 0x3000, v71, vcc_lo                  // 000000241784: 02028EFF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000024178C: BF870001
	v_add_co_ci_u32_e64 v72, null, 0, v72, vcc_lo              // 000000241790: D5207C48 01AA9080
	s_clause 0x1                                               // 000000241798: BF850001
	global_load_u16 v49, v[77:78], off offset:2048             // 00000024179C: DC4A0800 317C004D
	global_load_u16 v57, v[71:72], off offset:3072             // 0000002417A4: DC4A0C00 397C0047
	v_bfe_u32 v75, v50, 16, 1                                  // 0000002417AC: D610004B 02052132
	v_bfe_u32 v72, v42, 16, 1                                  // 0000002417B4: D6100048 0205212A
	v_bfe_u32 v71, v34, 16, 1                                  // 0000002417BC: D6100047 02052122
	v_bfe_u32 v76, v58, 16, 1                                  // 0000002417C4: D610004C 0205213A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002417CC: BF870214
	v_add3_u32 v50, v50, v75, 0x7fff                           // 0000002417D0: D6550032 03FE9732 00007FFF
	v_add3_u32 v42, v42, v72, 0x7fff                           // 0000002417DC: D655002A 03FE912A 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002417E8: BF870214
	v_add3_u32 v34, v34, v71, 0x7fff                           // 0000002417EC: D6550022 03FE8F22 00007FFF
	v_add3_u32 v58, v58, v76, 0x7fff                           // 0000002417F8: D655003A 03FE993A 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000241804: BF870194
	v_and_b32_e32 v50, 0xffff0000, v50                         // 000000241808: 366464FF FFFF0000
	v_and_b32_e32 v34, 0xffff0000, v34                         // 000000241810: 364444FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241818: BF870112
	v_mul_f32_e32 v50, 0xbfb8aa3b, v50                         // 00000024181C: 106464FF BFB8AA3B
	v_mul_f32_e32 v34, 0xbfb8aa3b, v34                         // 000000241824: 104444FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000024182C: BF870292
	v_exp_f32_e32 v50, v50                                     // 000000241830: 7E644B32
	v_add_f32_e32 v50, 1.0, v50                                // 000000241834: 066464F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000241838: BF870121
	v_div_scale_f32 v75, null, v50, v50, 1.0                   // 00000024183C: D6FC7C4B 03CA6532
	v_div_scale_f32 v86, s3, 1.0, v50, 1.0                     // 000000241844: D6FC0356 03CA64F2
	v_rcp_f32_e32 v79, v75                                     // 00000024184C: 7E9E554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241850: BF870095
	v_fma_f32 v85, -v75, v79, 1.0                              // 000000241854: D6130055 23CA9F4B
	v_dual_fmac_f32 v79, v85, v79 :: v_dual_and_b32 v42, 0xffff0000, v42// 00000024185C: C8249F55 4F2A54FF FFFF0000
	v_and_b32_e32 v58, 0xffff0000, v58                         // 000000241868: 367474FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241870: BF870112
	v_mul_f32_e32 v42, 0xbfb8aa3b, v42                         // 000000241874: 105454FF BFB8AA3B
	v_mul_f32_e32 v58, 0xbfb8aa3b, v58                         // 00000024187C: 107474FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000241884: BF870291
	v_exp_f32_e32 v58, v58                                     // 000000241888: 7E744B3A
	v_add_f32_e32 v58, 1.0, v58                                // 00000024188C: 067474F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241890: BF870091
	v_div_scale_f32 v76, null, v58, v58, 1.0                   // 000000241894: D6FC7C4C 03CA753A
	v_rcp_f32_e32 v80, v76                                     // 00000024189C: 7EA0554C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000002418A0: BF870005
	v_fma_f32 v87, -v76, v80, 1.0                              // 0000002418A4: D6130057 23CAA14C
	s_waitcnt vmcnt(3)                                         // 0000002418AC: BF890FF7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000002418B0: 30000090
	s_waitcnt vmcnt(2)                                         // 0000002418B4: BF890BF7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000002418B8: 30424290
	v_exp_f32_e32 v34, v34                                     // 0000002418BC: 7E444B22
	s_waitcnt vmcnt(1)                                         // 0000002418C0: BF8907F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000002418C4: 30626290
	v_exp_f32_e32 v42, v42                                     // 0000002418C8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002418CC: BF870096
	v_add_f32_e32 v34, 1.0, v34                                // 0000002418D0: 064444F2
	v_div_scale_f32 v71, null, v34, v34, 1.0                   // 0000002418D4: D6FC7C47 03CA4522
	v_div_scale_f32 v81, vcc_lo, 1.0, v34, 1.0                 // 0000002418DC: D6FC6A51 03CA44F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002418E4: BF870195
	v_add_f32_e32 v42, 1.0, v42                                // 0000002418E8: 065454F2
	v_rcp_f32_e32 v77, v71                                     // 0000002418EC: 7E9A5547
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002418F0: BF870121
	v_div_scale_f32 v72, null, v42, v42, 1.0                   // 0000002418F4: D6FC7C48 03CA552A
	v_div_scale_f32 v82, s2, 1.0, v42, 1.0                     // 0000002418FC: D6FC0252 03CA54F2
	v_rcp_f32_e32 v78, v72                                     // 000000241904: 7E9C5548
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241908: BF870096
	v_fma_f32 v83, -v71, v77, 1.0                              // 00000024190C: D6130053 23CA9B47
	v_fmac_f32_e32 v77, v83, v77                               // 000000241914: 569A9B53
	v_div_scale_f32 v83, s4, 1.0, v58, 1.0                     // 000000241918: D6FC0453 03CA74F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241920: BF870095
	v_fma_f32 v84, -v72, v78, 1.0                              // 000000241924: D6130054 23CA9D48
	v_fmac_f32_e32 v78, v84, v78                               // 00000024192C: 569C9D54
	v_dual_fmac_f32 v80, v87, v80 :: v_dual_mul_f32 v87, v86, v79// 000000241930: C806A157 50569F56
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241938: BF870111
	v_dual_mul_f32 v85, v82, v78 :: v_dual_mul_f32 v88, v83, v80// 00000024193C: C8C69D52 5558A153
	v_fma_f32 v91, -v75, v87, v86                              // 000000241944: D613005B 255AAF4B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000024194C: BF870222
	v_fma_f32 v90, -v72, v85, v82                              // 000000241950: D613005A 254AAB48
	v_mul_f32_e32 v84, v81, v77                                // 000000241958: 10A89B51
	v_fma_f32 v92, -v76, v88, v83                              // 00000024195C: D613005C 254EB14C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000241964: BF870214
	v_fmac_f32_e32 v87, v91, v79                               // 000000241968: 56AE9F5B
	v_fmac_f32_e32 v85, v90, v78                               // 00000024196C: 56AA9D5A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000241970: BF870214
	v_fma_f32 v89, -v71, v84, v81                              // 000000241974: D6130059 2546A947
	v_fmac_f32_e32 v88, v92, v80                               // 00000024197C: 56B0A15C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000241980: BF870214
	v_fma_f32 v75, -v75, v87, v86                              // 000000241984: D613004B 255AAF4B
	v_fma_f32 v72, -v72, v85, v82                              // 00000024198C: D6130048 254AAB48
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000241994: BF870214
	v_fmac_f32_e32 v84, v89, v77                               // 000000241998: 56A89B59
	v_fma_f32 v76, -v76, v88, v83                              // 00000024199C: D613004C 254EB14C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002419A4: BF870092
	v_fma_f32 v71, -v71, v84, v81                              // 0000002419A8: D6130047 2546A947
	v_div_fmas_f32 v71, v71, v77, v84                          // 0000002419B0: D6370047 05529B47
	s_mov_b32 vcc_lo, s2                                       // 0000002419B8: BEEA0002
	v_div_fmas_f32 v72, v72, v78, v85                          // 0000002419BC: D6370048 05569D48
	s_mov_b32 vcc_lo, s3                                       // 0000002419C4: BEEA0003
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002419C8: BF870002
	v_div_fixup_f32 v34, v71, v34, 1.0                         // 0000002419CC: D6270022 03CA4547
	v_div_fmas_f32 v71, v75, v79, v87                          // 0000002419D4: D6370047 055E9F4B
	s_mov_b32 vcc_lo, s4                                       // 0000002419DC: BEEA0004
	v_div_fixup_f32 v42, v72, v42, 1.0                         // 0000002419E0: D627002A 03CA5548
	v_div_fmas_f32 v75, v76, v80, v88                          // 0000002419E8: D637004B 0562A14C
	v_bfe_u32 v72, v34, 16, 1                                  // 0000002419F0: D6100048 02052122
	v_div_fixup_f32 v50, v71, v50, 1.0                         // 0000002419F8: D6270032 03CA6547
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 000000241A00: 7C9A9281
	v_bfe_u32 v71, v42, 16, 1                                  // 000000241A04: D6100047 0205212A
	v_div_fixup_f32 v58, v75, v58, 1.0                         // 000000241A0C: D627003A 03CA754B
	v_add3_u32 v34, v34, v72, 0x7fff                           // 000000241A14: D6550022 03FE9122 00007FFF
	v_bfe_u32 v72, v50, 16, 1                                  // 000000241A20: D6100048 02052132
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000241A28: 8B6A6A7E
	v_add3_u32 v42, v42, v71, 0x7fff                           // 000000241A2C: D655002A 03FE8F2A 00007FFF
	v_bfe_u32 v71, v58, 16, 1                                  // 000000241A38: D6100047 0205213A
	v_and_b32_e32 v34, 0xffff0000, v34                         // 000000241A40: 364444FF FFFF0000
	v_add3_u32 v50, v50, v72, 0x7fff                           // 000000241A48: D6550032 03FE9132 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000241A54: BF870194
	v_and_b32_e32 v42, 0xffff0000, v42                         // 000000241A58: 365454FF FFFF0000
	v_fma_f32 v0, v0, v34, 0                                   // 000000241A60: D6130000 02024500
	v_add3_u32 v34, v58, v71, 0x7fff                           // 000000241A68: D6550022 03FE8F3A 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000241A74: BF870194
	v_and_b32_e32 v50, 0xffff0000, v50                         // 000000241A78: 366464FF FFFF0000
	v_fmac_f32_e32 v0, v33, v42                                // 000000241A80: 56005521
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000241A84: BF8701B3
	v_and_b32_e32 v33, 0xffff0000, v34                         // 000000241A88: 364244FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 000000241A90: BF8903F7
	v_lshlrev_b32_e32 v34, 16, v57                             // 000000241A94: 30447290
	v_fmac_f32_e32 v0, v49, v50                                // 000000241A98: 56006531
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000241A9C: BF870121
	v_fmac_f32_e32 v0, v34, v33                                // 000000241AA0: 56004322
	v_mad_i64_i32 v[33:34], null, 0xa00, v41, v[67:68]         // 000000241AA4: D6FF7C21 050E52FF 00000A00
	v_mul_f32_e32 v0, 0x3e800000, v0                           // 000000241AB0: 100000FF 3E800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241AB8: BF870112
	.long 0xd73c0031                                           // 000000241ABC: D73C0031
	v_cndmask_b32_e32 v1, 1, v33, vcc_lo                       // 000000241AC0: 02024281
	v_bfe_u32 v42, v0, 16, 1                                   // 000000241AC4: D610002A 02052100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241ACC: BF870112
	.long 0xd7000231                                           // 000000241AD0: D7000231
	v_cndmask_b32_e32 v1, s14, v49, vcc_lo                     // 000000241AD4: 0202620E
	v_add3_u32 v42, v0, v42, 0x7fff                            // 000000241AD8: D655002A 03FE5500 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000241AE4: BF870004
	v_add_co_ci_u32_e64 v50, null, s15, v50, s2                // 000000241AE8: D5207C32 000A640F
	global_store_d16_hi_b16 v[49:50], v42, off                 // 000000241AF0: DC960000 007C2A31
	s_cbranch_vccnz 9                                          // 000000241AF8: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0xf20>
	.long 0xd73c0021                                           // 000000241AFC: D73C0021
	v_cndmask_b32_e32 v1, 2, v33, vcc_lo                       // 000000241B00: 02024282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241B04: BF870091
	.long 0xd7006a21                                           // 000000241B08: D7006A21
	v_cndmask_b32_e32 v1, s16, v33, vcc_lo                     // 000000241B0C: 02024210
	v_add_co_ci_u32_e64 v34, null, s17, v34, vcc_lo            // 000000241B10: D5207C22 01AA4411
	global_store_b32 v[33:34], v0, off                         // 000000241B18: DC6A0000 007C0021
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 000000241B20: 916A0B7E
	s_cbranch_vccnz 29                                         // 000000241B24: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0xf9c>
	v_and_b32_e32 v49, 0xffff0000, v42                         // 000000241B28: 366254FF FFFF0000
	v_mad_i64_i32 v[33:34], null, 0x2800, v41, s[18:19]        // 000000241B30: D6FF7C21 004A52FF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241B3C: BF870112
	v_sub_f32_e32 v0, v0, v49                                  // 000000241B40: 08006300
	.long 0xd7006a21                                           // 000000241B44: D7006A21
	v_cndmask_b32_e32 v1, v33, v65, vcc_lo                     // 000000241B48: 02028321
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000241B4C: BF870212
	v_bfe_u32 v49, v0, 16, 1                                   // 000000241B50: D6100031 02052100
	v_add_co_ci_u32_e64 v34, null, v34, v66, vcc_lo            // 000000241B58: D5207C22 01AA8522
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000241B60: BF870212
	v_add3_u32 v0, v0, v49, 0x7fff                             // 000000241B64: D6550000 03FE6300 00007FFF
	.long 0xd7006a31                                           // 000000241B70: D7006A31
	v_cndmask_b32_e32 v1, 0x1000, v33, vcc_lo                  // 000000241B74: 020242FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000241B7C: BF870001
	v_add_co_ci_u32_e64 v50, null, 0, v34, vcc_lo              // 000000241B80: D5207C32 01AA4480
	s_clause 0x1                                               // 000000241B88: BF850001
	global_store_d16_hi_b16 v[33:34], v42, off                 // 000000241B8C: DC960000 007C2A21
	global_store_d16_hi_b16 v[49:50], v0, off offset:1024      // 000000241B94: DC960400 007C0031
	s_or_b32 exec_lo, exec_lo, s5                              // 000000241B9C: 8C7E057E
	v_or_b32_e32 v42, 4, v74                                   // 000000241BA0: 38549484
	s_delay_alu instid0(VALU_DEP_1)                            // 000000241BA4: BF870001
	.long 0xd4440002                                           // 000000241BA8: D4440002
	v_cndmask_b32_e32 v1, s20, v42, vcc_lo                     // 000000241BAC: 02025414
	s_and_saveexec_b32 s6, s2                                  // 000000241BB0: BE862002
	s_cbranch_execz 285                                        // 000000241BB4: BFA5011D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x142c>
	v_mad_i64_i32 v[33:34], null, 0x5000, v42, v[69:70]        // 000000241BB8: D6FF7C21 051654FF 00005000
	v_bfe_u32 v71, v59, 16, 1                                  // 000000241BC4: D6100047 0205213B
	global_load_u16 v0, v[33:34], off                          // 000000241BCC: DC4A0000 007C0021
	.long 0xd7006a31                                           // 000000241BD4: D7006A31
	v_cndmask_b32_e32 v1, 0x1000, v33, vcc_lo                  // 000000241BD8: 020242FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000241BE0: BF8700A1
	v_add_co_ci_u32_e64 v50, null, 0, v34, vcc_lo              // 000000241BE4: D5207C32 01AA4480
	.long 0xd7006a39                                           // 000000241BEC: D7006A39
	v_cndmask_b32_e32 v1, 0x2000, v33, vcc_lo                  // 000000241BF0: 020242FF 00002000
	v_add_co_ci_u32_e64 v58, null, 0, v34, vcc_lo              // 000000241BF8: D5207C3A 01AA4480
	global_load_u16 v49, v[49:50], off offset:1024             // 000000241C00: DC4A0400 317C0031
	.long 0xd7006a21                                           // 000000241C08: D7006A21
	v_cndmask_b32_e32 v1, 0x3000, v33, vcc_lo                  // 000000241C0C: 020242FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000241C14: BF870001
	v_add_co_ci_u32_e64 v34, null, 0, v34, vcc_lo              // 000000241C18: D5207C22 01AA4480
	s_clause 0x1                                               // 000000241C20: BF850001
	global_load_u16 v50, v[57:58], off offset:2048             // 000000241C24: DC4A0800 327C0039
	global_load_u16 v33, v[33:34], off offset:3072             // 000000241C2C: DC4A0C00 217C0021
	v_bfe_u32 v34, v35, 16, 1                                  // 000000241C34: D6100022 02052123
	v_bfe_u32 v57, v43, 16, 1                                  // 000000241C3C: D6100039 0205212B
	v_bfe_u32 v58, v51, 16, 1                                  // 000000241C44: D610003A 02052133
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000241C4C: BF870193
	v_add3_u32 v34, v35, v34, 0x7fff                           // 000000241C50: D6550022 03FE4523 00007FFF
	v_add3_u32 v35, v43, v57, 0x7fff                           // 000000241C5C: D6550023 03FE732B 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000241C68: BF8701A3
	v_add3_u32 v43, v51, v58, 0x7fff                           // 000000241C6C: D655002B 03FE7533 00007FFF
	v_add3_u32 v51, v59, v71, 0x7fff                           // 000000241C78: D6550033 03FE8F3B 00007FFF
	v_and_b32_e32 v35, 0xffff0000, v35                         // 000000241C84: 364646FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241C8C: BF870091
	v_mul_f32_e32 v35, 0xbfb8aa3b, v35                         // 000000241C90: 104646FF BFB8AA3B
	v_exp_f32_e32 v35, v35                                     // 000000241C98: 7E464B23
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241C9C: BF870095
	v_dual_add_f32 v35, 1.0, v35 :: v_dual_and_b32 v34, 0xffff0000, v34// 000000241CA0: C92446F2 232244FF FFFF0000
	v_mul_f32_e32 v34, 0xbfb8aa3b, v34                         // 000000241CAC: 104444FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241CB4: BF870112
	v_div_scale_f32 v58, null, v35, v35, 1.0                   // 000000241CB8: D6FC7C3A 03CA4723
	v_exp_f32_e32 v34, v34                                     // 000000241CC0: 7E444B22
	v_div_scale_f32 v79, s3, 1.0, v35, 1.0                     // 000000241CC4: D6FC034F 03CA46F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000241CCC: BF870312
	v_rcp_f32_e32 v75, v58                                     // 000000241CD0: 7E96553A
	v_add_f32_e32 v34, 1.0, v34                                // 000000241CD4: 064444F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241CD8: BF870115
	v_fma_f32 v81, -v58, v75, 1.0                              // 000000241CDC: D6130051 23CA973A
	v_div_scale_f32 v57, null, v34, v34, 1.0                   // 000000241CE4: D6FC7C39 03CA4522
	v_div_scale_f32 v78, vcc_lo, 1.0, v34, 1.0                 // 000000241CEC: D6FC6A4E 03CA44F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000241CF4: BF870193
	v_fmac_f32_e32 v75, v81, v75                               // 000000241CF8: 56969751
	v_rcp_f32_e32 v72, v57                                     // 000000241CFC: 7E905539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241D00: BF870095
	v_fma_f32 v80, -v57, v72, 1.0                              // 000000241D04: D6130050 23CA9139
	v_dual_fmac_f32 v72, v80, v72 :: v_dual_and_b32 v43, 0xffff0000, v43// 000000241D0C: C8249150 482A56FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241D18: BF870091
	v_mul_f32_e32 v43, 0xbfb8aa3b, v43                         // 000000241D1C: 105656FF BFB8AA3B
	v_exp_f32_e32 v43, v43                                     // 000000241D24: 7E564B2B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241D28: BF870095
	v_add_f32_e32 v43, 1.0, v43                                // 000000241D2C: 065656F2
	v_div_scale_f32 v59, null, v43, v43, 1.0                   // 000000241D30: D6FC7C3B 03CA572B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000241D38: BF870291
	v_rcp_f32_e32 v76, v59                                     // 000000241D3C: 7E98553B
	v_fma_f32 v82, -v59, v76, 1.0                              // 000000241D40: D6130052 23CA993B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241D48: BF870091
	v_dual_fmac_f32 v76, v82, v76 :: v_dual_and_b32 v51, 0xffff0000, v51// 000000241D4C: C8249952 4C3266FF FFFF0000
	v_mul_f32_e32 v51, 0xbfb8aa3b, v51                         // 000000241D58: 106666FF BFB8AA3B
	v_mul_f32_e32 v82, v79, v75                                // 000000241D60: 10A4974F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241D64: BF870092
	v_exp_f32_e32 v51, v51                                     // 000000241D68: 7E664B33
	v_fma_f32 v87, -v58, v82, v79                              // 000000241D6C: D6130057 253EA53A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241D74: BF870091
	v_dual_mul_f32 v81, v78, v72 :: v_dual_fmac_f32 v82, v87, v75// 000000241D78: C8C0914E 51529757
	v_fma_f32 v86, -v57, v81, v78                              // 000000241D80: D6130056 253AA339
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000241D88: BF870195
	v_add_f32_e32 v51, 1.0, v51                                // 000000241D8C: 066666F2
	v_fma_f32 v58, -v58, v82, v79                              // 000000241D90: D613003A 253EA53A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241D98: BF870093
	v_fmac_f32_e32 v81, v86, v72                               // 000000241D9C: 56A29156
	v_fma_f32 v57, -v57, v81, v78                              // 000000241DA0: D6130039 253AA339
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000241DA8: BF870131
	v_div_fmas_f32 v57, v57, v72, v81                          // 000000241DAC: D6370039 05469139
	s_mov_b32 vcc_lo, s3                                       // 000000241DB4: BEEA0003
	v_div_fmas_f32 v58, v58, v75, v82                          // 000000241DB8: D637003A 054A973A
	v_div_fixup_f32 v34, v57, v34, 1.0                         // 000000241DC0: D6270022 03CA4539
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241DC8: BF870112
	v_div_fixup_f32 v35, v58, v35, 1.0                         // 000000241DCC: D6270023 03CA473A
	v_bfe_u32 v58, v34, 16, 1                                  // 000000241DD4: D610003A 02052122
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241DDC: BF870091
	v_add3_u32 v34, v34, v58, 0x7fff                           // 000000241DE0: D6550022 03FE7522 00007FFF
	v_and_b32_e32 v34, 0xffff0000, v34                         // 000000241DEC: 364444FF FFFF0000
	v_div_scale_f32 v83, s4, 1.0, v43, 1.0                     // 000000241DF4: D6FC0453 03CA56F2
	s_mov_b32 vcc_lo, s4                                       // 000000241DFC: BEEA0004
	s_waitcnt vmcnt(3)                                         // 000000241E00: BF890FF7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000241E04: 30000090
	v_div_scale_f32 v71, null, v51, v51, 1.0                   // 000000241E08: D6FC7C47 03CA6733
	v_div_scale_f32 v80, s5, 1.0, v51, 1.0                     // 000000241E10: D6FC0550 03CA66F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000241E18: BF870193
	v_fma_f32 v0, v0, v34, 0                                   // 000000241E1C: D6130000 02024500
	v_rcp_f32_e32 v77, v71                                     // 000000241E24: 7E9A5547
	s_waitcnt vmcnt(2)                                         // 000000241E28: BF890BF7
	v_lshlrev_b32_e32 v34, 16, v49                             // 000000241E2C: 30446290
	s_waitcnt vmcnt(1)                                         // 000000241E30: BF8907F7
	v_lshlrev_b32_e32 v50, 16, v50                             // 000000241E34: 30646490
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241E38: BF870095
	v_fma_f32 v84, -v71, v77, 1.0                              // 000000241E3C: D6130054 23CA9B47
	v_dual_fmac_f32 v77, v84, v77 :: v_dual_mul_f32 v84, v83, v76// 000000241E44: C8069B54 4D549953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241E4C: BF870111
	v_mul_f32_e32 v85, v80, v77                                // 000000241E50: 10AA9B50
	v_fma_f32 v88, -v59, v84, v83                              // 000000241E54: D6130058 254EA93B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241E5C: BF870112
	v_fma_f32 v89, -v71, v85, v80                              // 000000241E60: D6130059 2542AB47
	v_fmac_f32_e32 v84, v88, v76                               // 000000241E68: 56A89958
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241E6C: BF870091
	v_fma_f32 v59, -v59, v84, v83                              // 000000241E70: D613003B 254EA93B
	v_div_fmas_f32 v57, v59, v76, v84                          // 000000241E78: D6370039 0552993B
	s_mov_b32 vcc_lo, s5                                       // 000000241E80: BEEA0005
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000241E84: BF870121
	v_div_fixup_f32 v43, v57, v43, 1.0                         // 000000241E88: D627002B 03CA5739
	v_bfe_u32 v57, v35, 16, 1                                  // 000000241E90: D6100039 02052123
	v_bfe_u32 v58, v43, 16, 1                                  // 000000241E98: D610003A 0205212B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241EA0: BF870112
	v_add3_u32 v35, v35, v57, 0x7fff                           // 000000241EA4: D6550023 03FE7323 00007FFF
	v_add3_u32 v43, v43, v58, 0x7fff                           // 000000241EB0: D655002B 03FE752B 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000241EBC: BF8700C1
	v_and_b32_e32 v43, 0xffff0000, v43                         // 000000241EC0: 365656FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 000000241EC8: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000241ECC: 30424290
	v_and_b32_e32 v35, 0xffff0000, v35                         // 000000241ED0: 364646FF FFFF0000
	v_dual_fmac_f32 v85, v89, v77 :: v_dual_fmac_f32 v0, v34, v35// 000000241ED8: C8009B59 55004722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241EE0: BF870111
	v_fma_f32 v71, -v71, v85, v80                              // 000000241EE4: D6130047 2542AB47
	v_fmac_f32_e32 v0, v50, v43                                // 000000241EEC: 56005732
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000241EF0: BF870122
	v_div_fmas_f32 v59, v71, v77, v85                          // 000000241EF4: D637003B 05569B47
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 000000241EFC: 7C9A9281
	v_div_fixup_f32 v51, v59, v51, 1.0                         // 000000241F00: D6270033 03CA673B
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000241F08: 8B6A6A7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241F0C: BF870091
	v_bfe_u32 v57, v51, 16, 1                                  // 000000241F10: D6100039 02052133
	v_add3_u32 v49, v51, v57, 0x7fff                           // 000000241F18: D6550031 03FE7333 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241F24: BF870091
	v_and_b32_e32 v34, 0xffff0000, v49                         // 000000241F28: 364462FF FFFF0000
	v_fmac_f32_e32 v0, v33, v34                                // 000000241F30: 56004521
	v_mad_i64_i32 v[33:34], null, 0xa00, v42, v[67:68]         // 000000241F34: D6FF7C21 050E54FF 00000A00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241F40: BF870112
	v_mul_f32_e32 v0, 0x3e800000, v0                           // 000000241F44: 100000FF 3E800000
	.long 0xd73c0031                                           // 000000241F4C: D73C0031
	v_cndmask_b32_e32 v1, 1, v33, vcc_lo                       // 000000241F50: 02024281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241F54: BF870112
	v_bfe_u32 v35, v0, 16, 1                                   // 000000241F58: D6100023 02052100
	.long 0xd7000331                                           // 000000241F60: D7000331
	v_cndmask_b32_e32 v1, s14, v49, vcc_lo                     // 000000241F64: 0202620E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000241F68: BF870212
	v_add3_u32 v35, v0, v35, 0x7fff                            // 000000241F6C: D6550023 03FE4700 00007FFF
	v_add_co_ci_u32_e64 v50, null, s15, v50, s3                // 000000241F78: D5207C32 000E640F
	global_store_d16_hi_b16 v[49:50], v35, off                 // 000000241F80: DC960000 007C2331
	s_cbranch_vccnz 9                                          // 000000241F88: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x13b0>
	.long 0xd73c0021                                           // 000000241F8C: D73C0021
	v_cndmask_b32_e32 v1, 2, v33, vcc_lo                       // 000000241F90: 02024282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000241F94: BF870091
	.long 0xd7006a21                                           // 000000241F98: D7006A21
	v_cndmask_b32_e32 v1, s16, v33, vcc_lo                     // 000000241F9C: 02024210
	v_add_co_ci_u32_e64 v34, null, s17, v34, vcc_lo            // 000000241FA0: D5207C22 01AA4411
	global_store_b32 v[33:34], v0, off                         // 000000241FA8: DC6A0000 007C0021
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 000000241FB0: 916A0B7E
	s_cbranch_vccnz 29                                         // 000000241FB4: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x142c>
	v_and_b32_e32 v43, 0xffff0000, v35                         // 000000241FB8: 365646FF FFFF0000
	v_mad_i64_i32 v[33:34], null, 0x2800, v42, s[18:19]        // 000000241FC0: D6FF7C21 004A54FF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000241FCC: BF870112
	v_sub_f32_e32 v0, v0, v43                                  // 000000241FD0: 08005700
	.long 0xd7006a21                                           // 000000241FD4: D7006A21
	v_cndmask_b32_e32 v1, v33, v65, vcc_lo                     // 000000241FD8: 02028321
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000241FDC: BF870212
	v_bfe_u32 v43, v0, 16, 1                                   // 000000241FE0: D610002B 02052100
	v_add_co_ci_u32_e64 v34, null, v34, v66, vcc_lo            // 000000241FE8: D5207C22 01AA8522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000241FF0: BF870193
	.long 0xd7006a31                                           // 000000241FF4: D7006A31
	v_cndmask_b32_e32 v1, 0x1000, v33, vcc_lo                  // 000000241FF8: 020242FF 00001000
	v_add3_u32 v0, v0, v43, 0x7fff                             // 000000242000: D6550000 03FE5700 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000024200C: BF870003
	v_add_co_ci_u32_e64 v50, null, 0, v34, vcc_lo              // 000000242010: D5207C32 01AA4480
	s_clause 0x1                                               // 000000242018: BF850001
	global_store_d16_hi_b16 v[33:34], v35, off                 // 00000024201C: DC960000 007C2321
	global_store_d16_hi_b16 v[49:50], v0, off offset:1024      // 000000242024: DC960400 007C0031
	s_or_b32 exec_lo, exec_lo, s6                              // 00000024202C: 8C7E067E
	v_or_b32_e32 v35, 6, v74                                   // 000000242030: 38469486
	s_delay_alu instid0(VALU_DEP_1)                            // 000000242034: BF870001
	.long 0xd4440003                                           // 000000242038: D4440003
	v_cndmask_b32_e32 v1, s20, v35, vcc_lo                     // 00000024203C: 02024614
	s_and_saveexec_b32 s7, s3                                  // 000000242040: BE872003
	s_cbranch_execz 280                                        // 000000242044: BFA50118 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x18a8>
	v_mad_i64_i32 v[33:34], null, 0x5000, v35, v[69:70]        // 000000242048: D6FF7C21 051646FF 00005000
	v_bfe_u32 v51, v52, 16, 1                                  // 000000242054: D6100033 02052134
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000024205C: BF870092
	.long 0xd7006a31                                           // 000000242060: D7006A31
	v_cndmask_b32_e32 v1, 0x1000, v33, vcc_lo                  // 000000242064: 020242FF 00001000
	v_add_co_ci_u32_e64 v50, null, 0, v34, vcc_lo              // 00000024206C: D5207C32 01AA4480
	.long 0xd7006a39                                           // 000000242074: D7006A39
	v_cndmask_b32_e32 v1, 0x2000, v33, vcc_lo                  // 000000242078: 020242FF 00002000
	s_clause 0x1                                               // 000000242080: BF850001
	global_load_u16 v0, v[33:34], off                          // 000000242084: DC4A0000 007C0021
	global_load_u16 v43, v[49:50], off offset:1024             // 00000024208C: DC4A0400 2B7C0031
	v_add_co_ci_u32_e64 v58, null, 0, v34, vcc_lo              // 000000242094: D5207C3A 01AA4480
	.long 0xd7006a21                                           // 00000024209C: D7006A21
	v_cndmask_b32_e32 v1, 0x3000, v33, vcc_lo                  // 0000002420A0: 020242FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002420A8: BF870001
	v_add_co_ci_u32_e64 v34, null, 0, v34, vcc_lo              // 0000002420AC: D5207C22 01AA4480
	s_clause 0x1                                               // 0000002420B4: BF850001
	global_load_u16 v49, v[57:58], off offset:2048             // 0000002420B8: DC4A0800 317C0039
	global_load_u16 v33, v[33:34], off offset:3072             // 0000002420C0: DC4A0C00 217C0021
	v_bfe_u32 v34, v36, 16, 1                                  // 0000002420C8: D6100022 02052124
	v_bfe_u32 v50, v44, 16, 1                                  // 0000002420D0: D6100032 0205212C
	v_bfe_u32 v57, v60, 16, 1                                  // 0000002420D8: D6100039 0205213C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002420E0: BF870193
	v_add3_u32 v34, v36, v34, 0x7fff                           // 0000002420E4: D6550022 03FE4524 00007FFF
	v_add3_u32 v36, v44, v50, 0x7fff                           // 0000002420F0: D6550024 03FE652C 00007FFF
	v_add3_u32 v44, v52, v51, 0x7fff                           // 0000002420FC: D655002C 03FE6734 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000242108: BF870214
	v_add3_u32 v50, v60, v57, 0x7fff                           // 00000024210C: D6550032 03FE733C 00007FFF
	v_and_b32_e32 v34, 0xffff0000, v34                         // 000000242118: 364444FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242120: BF870093
	v_and_b32_e32 v44, 0xffff0000, v44                         // 000000242124: 365858FF FFFF0000
	v_mul_f32_e32 v44, 0xbfb8aa3b, v44                         // 00000024212C: 105858FF BFB8AA3B
	s_waitcnt vmcnt(3)                                         // 000000242134: BF890FF7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000242138: 30000090
	s_waitcnt vmcnt(1)                                         // 00000024213C: BF8907F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000242140: 30626290
	v_exp_f32_e32 v44, v44                                     // 000000242144: 7E584B2C
	s_waitcnt vmcnt(0)                                         // 000000242148: BF8903F7
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000024214C: BF870095
	v_dual_add_f32 v44, 1.0, v44 :: v_dual_lshlrev_b32 v33, 16, v33// 000000242150: C92258F2 2C204290
	v_div_scale_f32 v57, null, v44, v44, 1.0                   // 000000242158: D6FC7C39 03CA592C
	v_div_scale_f32 v80, s5, 1.0, v44, 1.0                     // 000000242160: D6FC0550 03CA58F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000242168: BF870292
	v_rcp_f32_e32 v71, v57                                     // 00000024216C: 7E8E5539
	v_fma_f32 v79, -v57, v71, 1.0                              // 000000242170: D613004F 23CA8F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242178: BF870091
	v_dual_fmac_f32 v71, v79, v71 :: v_dual_and_b32 v36, 0xffff0000, v36// 00000024217C: C8248F4F 472448FF FFFF0000
	v_mul_f32_e32 v36, 0xbfb8aa3b, v36                         // 000000242188: 104848FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000242190: BF870291
	v_exp_f32_e32 v36, v36                                     // 000000242194: 7E484B24
	v_add_f32_e32 v36, 1.0, v36                                // 000000242198: 064848F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000024219C: BF870121
	v_div_scale_f32 v52, null, v36, v36, 1.0                   // 0000002421A0: D6FC7C34 03CA4924
	v_div_scale_f32 v76, s4, 1.0, v36, 1.0                     // 0000002421A8: D6FC044C 03CA48F2
	v_rcp_f32_e32 v60, v52                                     // 0000002421B0: 7E785534
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002421B4: BF870095
	v_fma_f32 v78, -v52, v60, 1.0                              // 0000002421B8: D613004E 23CA7934
	v_fmac_f32_e32 v60, v78, v60                               // 0000002421C0: 5678794E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002421C4: BF870091
	v_dual_mul_f32 v79, v76, v60 :: v_dual_and_b32 v50, 0xffff0000, v50// 0000002421C8: C8E4794C 4F3264FF FFFF0000
	v_mul_f32_e32 v50, 0xbfb8aa3b, v50                         // 0000002421D4: 106464FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002421DC: BF8701A2
	v_fma_f32 v84, -v52, v79, v76                              // 0000002421E0: D6130054 25329F34
	v_mul_f32_e32 v34, 0xbfb8aa3b, v34                         // 0000002421E8: 104444FF BFB8AA3B
	v_exp_f32_e32 v50, v50                                     // 0000002421F0: 7E644B32
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002421F4: BF870112
	v_fmac_f32_e32 v79, v84, v60                               // 0000002421F8: 569E7954
	v_exp_f32_e32 v34, v34                                     // 0000002421FC: 7E444B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000242200: BF870311
	v_fma_f32 v52, -v52, v79, v76                              // 000000242204: D6130034 25329F34
	v_add_f32_e32 v50, 1.0, v50                                // 00000024220C: 066464F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242210: BF870115
	v_add_f32_e32 v34, 1.0, v34                                // 000000242214: 064444F2
	v_div_scale_f32 v58, null, v50, v50, 1.0                   // 000000242218: D6FC7C3A 03CA6532
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242220: BF870112
	v_div_scale_f32 v51, null, v34, v34, 1.0                   // 000000242224: D6FC7C33 03CA4522
	v_rcp_f32_e32 v72, v58                                     // 00000024222C: 7E90553A
	v_div_scale_f32 v75, vcc_lo, 1.0, v34, 1.0                 // 000000242230: D6FC6A4B 03CA44F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000242238: BF870312
	v_rcp_f32_e32 v59, v51                                     // 00000024223C: 7E765533
	v_fma_f32 v81, -v58, v72, 1.0                              // 000000242240: D6130051 23CA913A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242248: BF870115
	v_fma_f32 v77, -v51, v59, 1.0                              // 00000024224C: D613004D 23CA7733
	v_dual_fmac_f32 v72, v81, v72 :: v_dual_mul_f32 v81, v80, v71// 000000242254: C8069151 48508F50
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000024225C: BF8701A2
	v_fmac_f32_e32 v59, v77, v59                               // 000000242260: 5676774D
	v_div_scale_f32 v77, s6, 1.0, v50, 1.0                     // 000000242264: D6FC064D 03CA64F2
	v_fma_f32 v85, -v57, v81, v80                              // 00000024226C: D6130055 2542A339
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000242274: BF870193
	v_mul_f32_e32 v78, v75, v59                                // 000000242278: 109C774B
	v_mul_f32_e32 v82, v77, v72                                // 00000024227C: 10A4914D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000242280: BF870193
	v_fmac_f32_e32 v81, v85, v71                               // 000000242284: 56A28F55
	v_fma_f32 v83, -v51, v78, v75                              // 000000242288: D6130053 252E9D33
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000242290: BF870193
	v_fma_f32 v86, -v58, v82, v77                              // 000000242294: D6130056 2536A53A
	v_fma_f32 v57, -v57, v81, v80                              // 00000024229C: D6130039 2542A339
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002422A4: BF870193
	v_fmac_f32_e32 v78, v83, v59                               // 0000002422A8: 569C7753
	v_fmac_f32_e32 v82, v86, v72                               // 0000002422AC: 56A49156
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002422B0: BF870112
	v_fma_f32 v51, -v51, v78, v75                              // 0000002422B4: D6130033 252E9D33
	v_fma_f32 v58, -v58, v82, v77                              // 0000002422BC: D613003A 2536A53A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000002422C4: BF870142
	v_div_fmas_f32 v51, v51, v59, v78                          // 0000002422C8: D6370033 053A7733
	s_mov_b32 vcc_lo, s4                                       // 0000002422D0: BEEA0004
	v_div_fmas_f32 v52, v52, v60, v79                          // 0000002422D4: D6370034 053E7934
	s_mov_b32 vcc_lo, s5                                       // 0000002422DC: BEEA0005
	v_div_fixup_f32 v34, v51, v34, 1.0                         // 0000002422E0: D6270022 03CA4533
	v_div_fmas_f32 v51, v57, v71, v81                          // 0000002422E8: D6370033 05468F39
	s_mov_b32 vcc_lo, s6                                       // 0000002422F0: BEEA0006
	v_div_fixup_f32 v36, v52, v36, 1.0                         // 0000002422F4: D6270024 03CA4934
	v_div_fmas_f32 v57, v58, v72, v82                          // 0000002422FC: D6370039 054A913A
	v_bfe_u32 v52, v34, 16, 1                                  // 000000242304: D6100034 02052122
	v_div_fixup_f32 v44, v51, v44, 1.0                         // 00000024230C: D627002C 03CA5933
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 000000242314: 7C9A9281
	v_bfe_u32 v51, v36, 16, 1                                  // 000000242318: D6100033 02052124
	v_div_fixup_f32 v50, v57, v50, 1.0                         // 000000242320: D6270032 03CA6539
	v_add3_u32 v34, v34, v52, 0x7fff                           // 000000242328: D6550022 03FE6922 00007FFF
	v_bfe_u32 v52, v44, 16, 1                                  // 000000242334: D6100034 0205212C
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000024233C: 8B6A6A7E
	v_add3_u32 v36, v36, v51, 0x7fff                           // 000000242340: D6550024 03FE6724 00007FFF
	v_bfe_u32 v51, v50, 16, 1                                  // 00000024234C: D6100033 02052132
	v_and_b32_e32 v34, 0xffff0000, v34                         // 000000242354: 364444FF FFFF0000
	v_add3_u32 v44, v44, v52, 0x7fff                           // 00000024235C: D655002C 03FE692C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000242368: BF870194
	v_and_b32_e32 v36, 0xffff0000, v36                         // 00000024236C: 364848FF FFFF0000
	v_fma_f32 v0, v0, v34, 0                                   // 000000242374: D6130000 02024500
	v_lshlrev_b32_e32 v34, 16, v43                             // 00000024237C: 30445690
	v_add3_u32 v43, v50, v51, 0x7fff                           // 000000242380: D655002B 03FE6732 00007FFF
	v_and_b32_e32 v44, 0xffff0000, v44                         // 00000024238C: 365858FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000242394: BF870193
	v_fmac_f32_e32 v0, v34, v36                                // 000000242398: 56004922
	v_and_b32_e32 v34, 0xffff0000, v43                         // 00000024239C: 364456FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002423A4: BF870092
	v_fmac_f32_e32 v0, v49, v44                                // 0000002423A8: 56005931
	v_fmac_f32_e32 v0, v33, v34                                // 0000002423AC: 56004521
	v_mad_i64_i32 v[33:34], null, 0xa00, v35, v[67:68]         // 0000002423B0: D6FF7C21 050E46FF 00000A00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002423BC: BF870112
	v_mul_f32_e32 v0, 0x3e800000, v0                           // 0000002423C0: 100000FF 3E800000
	.long 0xd73c002b                                           // 0000002423C8: D73C002B
	v_cndmask_b32_e32 v1, 1, v33, vcc_lo                       // 0000002423CC: 02024281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002423D0: BF870112
	v_bfe_u32 v36, v0, 16, 1                                   // 0000002423D4: D6100024 02052100
	.long 0xd700042b                                           // 0000002423DC: D700042B
	v_cndmask_b32_e32 v1, s14, v43, vcc_lo                     // 0000002423E0: 0202560E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002423E4: BF870212
	v_add3_u32 v36, v0, v36, 0x7fff                            // 0000002423E8: D6550024 03FE4900 00007FFF
	v_add_co_ci_u32_e64 v44, null, s15, v44, s4                // 0000002423F4: D5207C2C 0012580F
	global_store_d16_hi_b16 v[43:44], v36, off                 // 0000002423FC: DC960000 007C242B
	s_cbranch_vccnz 9                                          // 000000242404: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x182c>
	.long 0xd73c0021                                           // 000000242408: D73C0021
	v_cndmask_b32_e32 v1, 2, v33, vcc_lo                       // 00000024240C: 02024282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242410: BF870091
	.long 0xd7006a21                                           // 000000242414: D7006A21
	v_cndmask_b32_e32 v1, s16, v33, vcc_lo                     // 000000242418: 02024210
	v_add_co_ci_u32_e64 v34, null, s17, v34, vcc_lo            // 00000024241C: D5207C22 01AA4411
	global_store_b32 v[33:34], v0, off                         // 000000242424: DC6A0000 007C0021
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 00000024242C: 916A0B7E
	s_cbranch_vccnz 29                                         // 000000242430: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x18a8>
	v_and_b32_e32 v43, 0xffff0000, v36                         // 000000242434: 365648FF FFFF0000
	v_mad_i64_i32 v[33:34], null, 0x2800, v35, s[18:19]        // 00000024243C: D6FF7C21 004A46FF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242448: BF870112
	v_sub_f32_e32 v0, v0, v43                                  // 00000024244C: 08005700
	.long 0xd7006a21                                           // 000000242450: D7006A21
	v_cndmask_b32_e32 v1, v33, v65, vcc_lo                     // 000000242454: 02028321
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000242458: BF870212
	v_bfe_u32 v43, v0, 16, 1                                   // 00000024245C: D610002B 02052100
	v_add_co_ci_u32_e64 v34, null, v34, v66, vcc_lo            // 000000242464: D5207C22 01AA8522
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000024246C: BF870212
	v_add3_u32 v0, v0, v43, 0x7fff                             // 000000242470: D6550000 03FE5700 00007FFF
	.long 0xd7006a2b                                           // 00000024247C: D7006A2B
	v_cndmask_b32_e32 v1, 0x1000, v33, vcc_lo                  // 000000242480: 020242FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000242488: BF870001
	v_add_co_ci_u32_e64 v44, null, 0, v34, vcc_lo              // 00000024248C: D5207C2C 01AA4480
	s_clause 0x1                                               // 000000242494: BF850001
	global_store_d16_hi_b16 v[33:34], v36, off                 // 000000242498: DC960000 007C2421
	global_store_d16_hi_b16 v[43:44], v0, off offset:1024      // 0000002424A0: DC960400 007C002B
	s_or_b32 exec_lo, exec_lo, s7                              // 0000002424A8: 8C7E077E
	v_or_b32_e32 v36, 8, v74                                   // 0000002424AC: 38489488
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002424B0: BF870001
	.long 0xd4440004                                           // 0000002424B4: D4440004
	v_cndmask_b32_e32 v1, s20, v36, vcc_lo                     // 0000002424B8: 02024814
	s_and_saveexec_b32 s8, s4                                  // 0000002424BC: BE882004
	s_cbranch_execz 283                                        // 0000002424C0: BFA5011B <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x1d30>
	v_mad_i64_i32 v[33:34], null, 0x5000, v36, v[69:70]        // 0000002424C4: D6FF7C21 051648FF 00005000
	v_bfe_u32 v51, v61, 16, 1                                  // 0000002424D0: D6100033 0205213D
	global_load_u16 v0, v[33:34], off                          // 0000002424D8: DC4A0000 007C0021
	.long 0xd7006a2b                                           // 0000002424E0: D7006A2B
	v_cndmask_b32_e32 v1, 0x1000, v33, vcc_lo                  // 0000002424E4: 020242FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002424EC: BF8700A1
	v_add_co_ci_u32_e64 v44, null, 0, v34, vcc_lo              // 0000002424F0: D5207C2C 01AA4480
	.long 0xd7006a31                                           // 0000002424F8: D7006A31
	v_cndmask_b32_e32 v1, 0x2000, v33, vcc_lo                  // 0000002424FC: 020242FF 00002000
	v_add_co_ci_u32_e64 v50, null, 0, v34, vcc_lo              // 000000242504: D5207C32 01AA4480
	global_load_u16 v43, v[43:44], off offset:1024             // 00000024250C: DC4A0400 2B7C002B
	.long 0xd7006a21                                           // 000000242514: D7006A21
	v_cndmask_b32_e32 v1, 0x3000, v33, vcc_lo                  // 000000242518: 020242FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000242520: BF870001
	v_add_co_ci_u32_e64 v34, null, 0, v34, vcc_lo              // 000000242524: D5207C22 01AA4480
	s_clause 0x1                                               // 00000024252C: BF850001
	global_load_u16 v44, v[49:50], off offset:2048             // 000000242530: DC4A0800 2C7C0031
	global_load_u16 v33, v[33:34], off offset:3072             // 000000242538: DC4A0C00 217C0021
	v_bfe_u32 v34, v37, 16, 1                                  // 000000242540: D6100022 02052125
	v_bfe_u32 v49, v45, 16, 1                                  // 000000242548: D6100031 0205212D
	v_bfe_u32 v50, v53, 16, 1                                  // 000000242550: D6100032 02052135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000242558: BF870193
	v_add3_u32 v34, v37, v34, 0x7fff                           // 00000024255C: D6550022 03FE4525 00007FFF
	v_add3_u32 v37, v45, v49, 0x7fff                           // 000000242568: D6550025 03FE632D 00007FFF
	v_add3_u32 v49, v61, v51, 0x7fff                           // 000000242574: D6550031 03FE673D 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000242580: BF870194
	v_add3_u32 v45, v53, v50, 0x7fff                           // 000000242584: D655002D 03FE6535 00007FFF
	v_and_b32_e32 v37, 0xffff0000, v37                         // 000000242590: 364A4AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242598: BF870113
	v_and_b32_e32 v49, 0xffff0000, v49                         // 00000024259C: 366262FF FFFF0000
	v_mul_f32_e32 v37, 0xbfb8aa3b, v37                         // 0000002425A4: 104A4AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002425AC: BF870291
	v_exp_f32_e32 v37, v37                                     // 0000002425B0: 7E4A4B25
	v_dual_add_f32 v37, 1.0, v37 :: v_dual_and_b32 v34, 0xffff0000, v34// 0000002425B4: C9244AF2 252244FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002425C0: BF870121
	v_div_scale_f32 v51, null, v37, v37, 1.0                   // 0000002425C4: D6FC7C33 03CA4B25
	v_div_scale_f32 v71, s5, 1.0, v37, 1.0                     // 0000002425CC: D6FC0547 03CA4AF2
	v_rcp_f32_e32 v58, v51                                     // 0000002425D4: 7E745533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002425D8: BF870095
	v_fma_f32 v75, -v51, v58, 1.0                              // 0000002425DC: D613004B 23CA7533
	v_dual_fmac_f32 v58, v75, v58 :: v_dual_and_b32 v45, 0xffff0000, v45// 0000002425E4: C824754B 3A2C5AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002425F0: BF870091
	v_dual_mul_f32 v34, 0xbfb8aa3b, v34 :: v_dual_mul_f32 v45, 0xbfb8aa3b, v45// 0000002425F4: C8C644FF 222C5AFF BFB8AA3B
	v_exp_f32_e32 v34, v34                                     // 000000242600: 7E444B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000242604: BF870291
	v_exp_f32_e32 v45, v45                                     // 000000242608: 7E5A4B2D
	v_dual_add_f32 v34, 1.0, v34 :: v_dual_add_f32 v45, 1.0, v45// 00000024260C: C90844F2 222C5AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242614: BF870111
	v_div_scale_f32 v50, null, v34, v34, 1.0                   // 000000242618: D6FC7C32 03CA4522
	v_div_scale_f32 v52, null, v45, v45, 1.0                   // 000000242620: D6FC7C34 03CA5B2D
	v_div_scale_f32 v61, vcc_lo, 1.0, v34, 1.0                 // 000000242628: D6FC6A3D 03CA44F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242630: BF870113
	v_rcp_f32_e32 v57, v50                                     // 000000242634: 7E725532
	v_rcp_f32_e32 v59, v52                                     // 000000242638: 7E765534
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000024263C: BF870296
	v_fma_f32 v72, -v50, v57, 1.0                              // 000000242640: D6130048 23CA7332
	v_fma_f32 v76, -v52, v59, 1.0                              // 000000242648: D613004C 23CA7734
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242650: BF870112
	v_fmac_f32_e32 v57, v72, v57                               // 000000242654: 56727348
	v_dual_fmac_f32 v59, v76, v59 :: v_dual_mul_f32 v76, v71, v58// 000000242658: C806774C 3B4C7547
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242660: BF870112
	v_mul_f32_e32 v75, v61, v57                                // 000000242664: 1096733D
	v_fma_f32 v81, -v51, v76, v71                              // 000000242668: D6130051 251E9933
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242670: BF870112
	v_fma_f32 v80, -v50, v75, v61                              // 000000242674: D6130050 24F69732
	v_fmac_f32_e32 v76, v81, v58                               // 00000024267C: 56987551
	v_div_scale_f32 v77, s6, 1.0, v45, 1.0                     // 000000242680: D6FC064D 03CA5AF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000242688: BF870193
	v_fmac_f32_e32 v75, v80, v57                               // 00000024268C: 56967350
	v_fma_f32 v51, -v51, v76, v71                              // 000000242690: D6130033 251E9933
	s_waitcnt vmcnt(3)                                         // 000000242698: BF890FF7
	v_dual_mul_f32 v49, 0xbfb8aa3b, v49 :: v_dual_lshlrev_b32 v0, 16, v0// 00000024269C: C8E262FF 31000090 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000002426A8: BF8702A1
	v_exp_f32_e32 v49, v49                                     // 0000002426AC: 7E624B31
	s_waitcnt vmcnt(1)                                         // 0000002426B0: BF8907F7
	v_dual_add_f32 v49, 1.0, v49 :: v_dual_lshlrev_b32 v44, 16, v44// 0000002426B4: C92262F2 312C5890
	v_fma_f32 v50, -v50, v75, v61                              // 0000002426BC: D6130032 24F69732
	s_waitcnt vmcnt(0)                                         // 0000002426C4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000002426C8: 30424290
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002426CC: BF870193
	v_div_scale_f32 v53, null, v49, v49, 1.0                   // 0000002426D0: D6FC7C35 03CA6331
	v_div_fmas_f32 v50, v50, v57, v75                          // 0000002426D8: D6370032 052E7332
	s_mov_b32 vcc_lo, s5                                       // 0000002426E0: BEEA0005
	v_div_fmas_f32 v51, v51, v58, v76                          // 0000002426E4: D6370033 05327533
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002426EC: BF870113
	v_rcp_f32_e32 v60, v53                                     // 0000002426F0: 7E785535
	v_div_fixup_f32 v34, v50, v34, 1.0                         // 0000002426F4: D6270022 03CA4532
	s_mov_b32 vcc_lo, s6                                       // 0000002426FC: BEEA0006
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242700: BF870112
	v_div_fixup_f32 v37, v51, v37, 1.0                         // 000000242704: D6270025 03CA4B33
	v_bfe_u32 v51, v34, 16, 1                                  // 00000024270C: D6100033 02052122
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242714: BF870115
	v_fma_f32 v78, -v53, v60, 1.0                              // 000000242718: D613004E 23CA7935
	v_add3_u32 v34, v34, v51, 0x7fff                           // 000000242720: D6550022 03FE6722 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000024272C: BF8701A2
	v_fmac_f32_e32 v60, v78, v60                               // 000000242730: 5678794E
	v_mul_f32_e32 v78, v77, v59                                // 000000242734: 109C774D
	v_and_b32_e32 v34, 0xffff0000, v34                         // 000000242738: 364444FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242740: BF870112
	v_fma_f32 v82, -v52, v78, v77                              // 000000242744: D6130052 25369D34
	v_fma_f32 v0, v0, v34, 0                                   // 00000024274C: D6130000 02024500
	v_lshlrev_b32_e32 v34, 16, v43                             // 000000242754: 30445690
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000242758: BF870123
	v_fmac_f32_e32 v78, v82, v59                               // 00000024275C: 569C7752
	v_div_scale_f32 v72, s7, 1.0, v49, 1.0                     // 000000242760: D6FC0748 03CA62F2
	v_fma_f32 v52, -v52, v78, v77                              // 000000242768: D6130034 25369D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000242770: BF8700A1
	v_div_fmas_f32 v50, v52, v59, v78                          // 000000242774: D6370032 053A7734
	s_mov_b32 vcc_lo, s7                                       // 00000024277C: BEEA0007
	v_div_fixup_f32 v45, v50, v45, 1.0                         // 000000242780: D627002D 03CA5B32
	v_bfe_u32 v50, v37, 16, 1                                  // 000000242788: D6100032 02052125
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242790: BF870112
	v_bfe_u32 v51, v45, 16, 1                                  // 000000242794: D6100033 0205212D
	v_add3_u32 v37, v37, v50, 0x7fff                           // 00000024279C: D6550025 03FE6525 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002427A8: BF870112
	v_add3_u32 v45, v45, v51, 0x7fff                           // 0000002427AC: D655002D 03FE672D 00007FFF
	v_and_b32_e32 v37, 0xffff0000, v37                         // 0000002427B8: 364A4AFF FFFF0000
	v_mul_f32_e32 v79, v72, v60                                // 0000002427C0: 109E7948
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002427C4: BF870193
	v_and_b32_e32 v45, 0xffff0000, v45                         // 0000002427C8: 365A5AFF FFFF0000
	v_fmac_f32_e32 v0, v34, v37                                // 0000002427D0: 56004B22
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002427D4: BF870093
	v_fma_f32 v83, -v53, v79, v72                              // 0000002427D8: D6130053 25229F35
	v_dual_fmac_f32 v0, v44, v45 :: v_dual_fmac_f32 v79, v83, v60// 0000002427E0: C8005B2C 004E7953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002427E8: BF870091
	v_fma_f32 v53, -v53, v79, v72                              // 0000002427EC: D6130035 25229F35
	v_div_fmas_f32 v52, v53, v60, v79                          // 0000002427F4: D6370034 053E7935
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 0000002427FC: 7C9A9281
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000242800: BF8700A2
	v_div_fixup_f32 v49, v52, v49, 1.0                         // 000000242804: D6270031 03CA6334
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000024280C: 8B6A6A7E
	v_bfe_u32 v50, v49, 16, 1                                  // 000000242810: D6100032 02052131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242818: BF870091
	v_add3_u32 v43, v49, v50, 0x7fff                           // 00000024281C: D655002B 03FE6531 00007FFF
	v_and_b32_e32 v34, 0xffff0000, v43                         // 000000242828: 364456FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000242830: BF870121
	v_fmac_f32_e32 v0, v33, v34                                // 000000242834: 56004521
	v_mad_i64_i32 v[33:34], null, 0xa00, v36, v[67:68]         // 000000242838: D6FF7C21 050E48FF 00000A00
	v_mul_f32_e32 v0, 0x3e800000, v0                           // 000000242844: 100000FF 3E800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024284C: BF870112
	.long 0xd73c002b                                           // 000000242850: D73C002B
	v_cndmask_b32_e32 v1, 1, v33, vcc_lo                       // 000000242854: 02024281
	v_bfe_u32 v37, v0, 16, 1                                   // 000000242858: D6100025 02052100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242860: BF870112
	.long 0xd700052b                                           // 000000242864: D700052B
	v_cndmask_b32_e32 v1, s14, v43, vcc_lo                     // 000000242868: 0202560E
	v_add3_u32 v37, v0, v37, 0x7fff                            // 00000024286C: D6550025 03FE4B00 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000242878: BF870004
	v_add_co_ci_u32_e64 v44, null, s15, v44, s5                // 00000024287C: D5207C2C 0016580F
	global_store_d16_hi_b16 v[43:44], v37, off                 // 000000242884: DC960000 007C252B
	s_cbranch_vccnz 9                                          // 00000024288C: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x1cb4>
	.long 0xd73c0021                                           // 000000242890: D73C0021
	v_cndmask_b32_e32 v1, 2, v33, vcc_lo                       // 000000242894: 02024282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242898: BF870091
	.long 0xd7006a21                                           // 00000024289C: D7006A21
	v_cndmask_b32_e32 v1, s16, v33, vcc_lo                     // 0000002428A0: 02024210
	v_add_co_ci_u32_e64 v34, null, s17, v34, vcc_lo            // 0000002428A4: D5207C22 01AA4411
	global_store_b32 v[33:34], v0, off                         // 0000002428AC: DC6A0000 007C0021
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 0000002428B4: 916A0B7E
	s_cbranch_vccnz 29                                         // 0000002428B8: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x1d30>
	v_and_b32_e32 v43, 0xffff0000, v37                         // 0000002428BC: 36564AFF FFFF0000
	v_mad_i64_i32 v[33:34], null, 0x2800, v36, s[18:19]        // 0000002428C4: D6FF7C21 004A48FF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002428D0: BF870112
	v_sub_f32_e32 v0, v0, v43                                  // 0000002428D4: 08005700
	.long 0xd7006a21                                           // 0000002428D8: D7006A21
	v_cndmask_b32_e32 v1, v33, v65, vcc_lo                     // 0000002428DC: 02028321
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002428E0: BF870212
	v_bfe_u32 v43, v0, 16, 1                                   // 0000002428E4: D610002B 02052100
	v_add_co_ci_u32_e64 v34, null, v34, v66, vcc_lo            // 0000002428EC: D5207C22 01AA8522
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002428F4: BF870212
	v_add3_u32 v0, v0, v43, 0x7fff                             // 0000002428F8: D6550000 03FE5700 00007FFF
	.long 0xd7006a2b                                           // 000000242904: D7006A2B
	v_cndmask_b32_e32 v1, 0x1000, v33, vcc_lo                  // 000000242908: 020242FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000242910: BF870001
	v_add_co_ci_u32_e64 v44, null, 0, v34, vcc_lo              // 000000242914: D5207C2C 01AA4480
	s_clause 0x1                                               // 00000024291C: BF850001
	global_store_d16_hi_b16 v[33:34], v37, off                 // 000000242920: DC960000 007C2521
	global_store_d16_hi_b16 v[43:44], v0, off offset:1024      // 000000242928: DC960400 007C002B
	s_or_b32 exec_lo, exec_lo, s8                              // 000000242930: 8C7E087E
	v_or_b32_e32 v37, 10, v74                                  // 000000242934: 384A948A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000242938: BF870001
	.long 0xd4440005                                           // 00000024293C: D4440005
	v_cndmask_b32_e32 v1, s20, v37, vcc_lo                     // 000000242940: 02024A14
	s_and_saveexec_b32 s9, s5                                  // 000000242944: BE892005
	s_cbranch_execz 279                                        // 000000242948: BFA50117 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x21a8>
	v_mad_i64_i32 v[33:34], null, 0x5000, v37, v[69:70]        // 00000024294C: D6FF7C21 05164AFF 00005000
	v_bfe_u32 v45, v46, 16, 1                                  // 000000242958: D610002D 0205212E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242960: BF870092
	.long 0xd7006a2b                                           // 000000242964: D7006A2B
	v_cndmask_b32_e32 v1, 0x1000, v33, vcc_lo                  // 000000242968: 020242FF 00001000
	v_add_co_ci_u32_e64 v44, null, 0, v34, vcc_lo              // 000000242970: D5207C2C 01AA4480
	.long 0xd7006a31                                           // 000000242978: D7006A31
	v_cndmask_b32_e32 v1, 0x2000, v33, vcc_lo                  // 00000024297C: 020242FF 00002000
	s_clause 0x1                                               // 000000242984: BF850001
	global_load_u16 v0, v[33:34], off                          // 000000242988: DC4A0000 007C0021
	global_load_u16 v43, v[43:44], off offset:1024             // 000000242990: DC4A0400 2B7C002B
	v_add_co_ci_u32_e64 v50, null, 0, v34, vcc_lo              // 000000242998: D5207C32 01AA4480
	.long 0xd7006a21                                           // 0000002429A0: D7006A21
	v_cndmask_b32_e32 v1, 0x3000, v33, vcc_lo                  // 0000002429A4: 020242FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002429AC: BF870001
	v_add_co_ci_u32_e64 v34, null, 0, v34, vcc_lo              // 0000002429B0: D5207C22 01AA4480
	s_clause 0x1                                               // 0000002429B8: BF850001
	global_load_u16 v44, v[49:50], off offset:2048             // 0000002429BC: DC4A0800 2C7C0031
	global_load_u16 v33, v[33:34], off offset:3072             // 0000002429C4: DC4A0C00 217C0021
	v_bfe_u32 v34, v38, 16, 1                                  // 0000002429CC: D6100022 02052126
	v_bfe_u32 v49, v54, 16, 1                                  // 0000002429D4: D6100031 02052136
	v_bfe_u32 v50, v62, 16, 1                                  // 0000002429DC: D6100032 0205213E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002429E4: BF870223
	v_add3_u32 v34, v38, v34, 0x7fff                           // 0000002429E8: D6550022 03FE4526 00007FFF
	v_add3_u32 v38, v46, v45, 0x7fff                           // 0000002429F4: D6550026 03FE5B2E 00007FFF
	v_add3_u32 v45, v54, v49, 0x7fff                           // 000000242A00: D655002D 03FE6336 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242A0C: BF870114
	v_add3_u32 v46, v62, v50, 0x7fff                           // 000000242A10: D655002E 03FE653E 00007FFF
	v_and_b32_e32 v45, 0xffff0000, v45                         // 000000242A1C: 365A5AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242A24: BF870091
	v_mul_f32_e32 v45, 0xbfb8aa3b, v45                         // 000000242A28: 105A5AFF BFB8AA3B
	v_exp_f32_e32 v45, v45                                     // 000000242A30: 7E5A4B2D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242A34: BF870095
	v_dual_add_f32 v45, 1.0, v45 :: v_dual_and_b32 v34, 0xffff0000, v34// 000000242A38: C9245AF2 2D2244FF FFFF0000
	v_div_scale_f32 v51, null, v45, v45, 1.0                   // 000000242A44: D6FC7C33 03CA5B2D
	v_div_scale_f32 v72, s7, 1.0, v45, 1.0                     // 000000242A4C: D6FC0748 03CA5AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000242A54: BF870292
	v_rcp_f32_e32 v57, v51                                     // 000000242A58: 7E725533
	v_fma_f32 v71, -v51, v57, 1.0                              // 000000242A5C: D6130047 23CA7333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242A64: BF870091
	v_dual_fmac_f32 v57, v71, v57 :: v_dual_and_b32 v46, 0xffff0000, v46// 000000242A68: C8247347 392E5CFF FFFF0000
	v_mul_f32_e32 v46, 0xbfb8aa3b, v46                         // 000000242A74: 105C5CFF BFB8AA3B
	v_mul_f32_e32 v34, 0xbfb8aa3b, v34                         // 000000242A7C: 104444FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000242A84: BF870292
	v_exp_f32_e32 v46, v46                                     // 000000242A88: 7E5C4B2E
	v_add_f32_e32 v46, 1.0, v46                                // 000000242A8C: 065C5CF2
	s_waitcnt vmcnt(3)                                         // 000000242A90: BF890FF7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000242A94: 30000090
	s_waitcnt vmcnt(1)                                         // 000000242A98: BF8907F7
	v_lshlrev_b32_e32 v44, 16, v44                             // 000000242A9C: 30585890
	s_waitcnt vmcnt(0)                                         // 000000242AA0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000242AA4: 30424290
	v_div_scale_f32 v52, null, v46, v46, 1.0                   // 000000242AA8: D6FC7C34 03CA5D2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000242AB0: BF870291
	v_rcp_f32_e32 v58, v52                                     // 000000242AB4: 7E745534
	v_fma_f32 v75, -v52, v58, 1.0                              // 000000242AB8: D613004B 23CA7534
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000242AC0: BF8700A1
	v_dual_fmac_f32 v58, v75, v58 :: v_dual_mul_f32 v75, v72, v57// 000000242AC4: C806754B 3A4A7348
	v_exp_f32_e32 v34, v34                                     // 000000242ACC: 7E444B22
	v_fma_f32 v79, -v51, v75, v72                              // 000000242AD0: D613004F 25229733
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 000000242AD8: BF870085
	v_dual_fmac_f32 v75, v79, v57 :: v_dual_add_f32 v34, 1.0, v34// 000000242ADC: C808734F 4B2244F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242AE4: BF870111
	v_fma_f32 v51, -v51, v75, v72                              // 000000242AE8: D6130033 25229733
	v_div_scale_f32 v49, null, v34, v34, 1.0                   // 000000242AF0: D6FC7C31 03CA4522
	v_div_scale_f32 v59, vcc_lo, 1.0, v34, 1.0                 // 000000242AF8: D6FC6A3B 03CA44F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000242B00: BF870292
	v_rcp_f32_e32 v53, v49                                     // 000000242B04: 7E6A5531
	v_fma_f32 v61, -v49, v53, 1.0                              // 000000242B08: D613003D 23CA6B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242B10: BF870091
	v_dual_fmac_f32 v53, v61, v53 :: v_dual_and_b32 v38, 0xffff0000, v38// 000000242B14: C8246B3D 35264CFF FFFF0000
	v_mul_f32_e32 v38, 0xbfb8aa3b, v38                         // 000000242B20: 104C4CFF BFB8AA3B
	v_div_scale_f32 v61, s8, 1.0, v46, 1.0                     // 000000242B28: D6FC083D 03CA5CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242B30: BF870092
	v_exp_f32_e32 v38, v38                                     // 000000242B34: 7E4C4B26
	v_mul_f32_e32 v76, v61, v58                                // 000000242B38: 1098753D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000242B3C: BF870291
	v_fma_f32 v80, -v52, v76, v61                              // 000000242B40: D6130050 24F69934
	v_add_f32_e32 v38, 1.0, v38                                // 000000242B48: 064C4CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242B4C: BF870112
	v_fmac_f32_e32 v76, v80, v58                               // 000000242B50: 56987550
	v_div_scale_f32 v50, null, v38, v38, 1.0                   // 000000242B54: D6FC7C32 03CA4D26
	v_div_scale_f32 v60, s6, 1.0, v38, 1.0                     // 000000242B5C: D6FC063C 03CA4CF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000242B64: BF870193
	v_fma_f32 v52, -v52, v76, v61                              // 000000242B68: D6130034 24F69934
	v_rcp_f32_e32 v54, v50                                     // 000000242B70: 7E6C5532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242B74: BF870095
	v_fma_f32 v62, -v50, v54, 1.0                              // 000000242B78: D613003E 23CA6D32
	v_fmac_f32_e32 v54, v62, v54                               // 000000242B80: 566C6D3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242B84: BF870091
	v_dual_mul_f32 v62, v59, v53 :: v_dual_mul_f32 v71, v60, v54// 000000242B88: C8C66B3B 3E466D3C
	v_fma_f32 v77, -v49, v62, v59                              // 000000242B90: D613004D 24EE7D31
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242B98: BF870092
	v_fma_f32 v78, -v50, v71, v60                              // 000000242B9C: D613004E 24F28F32
	v_dual_fmac_f32 v62, v77, v53 :: v_dual_fmac_f32 v71, v78, v54// 000000242BA4: C8006B4D 3E466D4E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242BAC: BF870111
	v_fma_f32 v49, -v49, v62, v59                              // 000000242BB0: D6130031 24EE7D31
	v_fma_f32 v50, -v50, v71, v60                              // 000000242BB8: D6130032 24F28F32
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000242BC0: BF870122
	v_div_fmas_f32 v49, v49, v53, v62                          // 000000242BC4: D6370031 04FA6B31
	s_mov_b32 vcc_lo, s6                                       // 000000242BCC: BEEA0006
	v_div_fmas_f32 v50, v50, v54, v71                          // 000000242BD0: D6370032 051E6D32
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000242BD8: BF8701B2
	v_div_fixup_f32 v34, v49, v34, 1.0                         // 000000242BDC: D6270022 03CA4531
	s_mov_b32 vcc_lo, s7                                       // 000000242BE4: BEEA0007
	v_div_fmas_f32 v49, v51, v57, v75                          // 000000242BE8: D6370031 052E7333
	v_div_fixup_f32 v38, v50, v38, 1.0                         // 000000242BF0: D6270026 03CA4D32
	s_delay_alu instid0(VALU_DEP_3)                            // 000000242BF8: BF870003
	v_bfe_u32 v50, v34, 16, 1                                  // 000000242BFC: D6100032 02052122
	s_mov_b32 vcc_lo, s8                                       // 000000242C04: BEEA0008
	v_div_fmas_f32 v51, v52, v58, v76                          // 000000242C08: D6370033 05327534
	v_div_fixup_f32 v45, v49, v45, 1.0                         // 000000242C10: D627002D 03CA5B31
	v_bfe_u32 v49, v38, 16, 1                                  // 000000242C18: D6100031 02052126
	v_add3_u32 v34, v34, v50, 0x7fff                           // 000000242C20: D6550022 03FE6522 00007FFF
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 000000242C2C: 7C9A9281
	v_div_fixup_f32 v46, v51, v46, 1.0                         // 000000242C30: D627002E 03CA5D33
	v_bfe_u32 v50, v45, 16, 1                                  // 000000242C38: D6100032 0205212D
	v_add3_u32 v38, v38, v49, 0x7fff                           // 000000242C40: D6550026 03FE6326 00007FFF
	v_and_b32_e32 v34, 0xffff0000, v34                         // 000000242C4C: 364444FF FFFF0000
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000242C54: 8B6A6A7E
	v_bfe_u32 v49, v46, 16, 1                                  // 000000242C58: D6100031 0205212E
	v_add3_u32 v45, v45, v50, 0x7fff                           // 000000242C60: D655002D 03FE652D 00007FFF
	v_and_b32_e32 v38, 0xffff0000, v38                         // 000000242C6C: 364C4CFF FFFF0000
	v_fma_f32 v0, v0, v34, 0                                   // 000000242C74: D6130000 02024500
	v_lshlrev_b32_e32 v34, 16, v43                             // 000000242C7C: 30445690
	v_add3_u32 v43, v46, v49, 0x7fff                           // 000000242C80: D655002B 03FE632E 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242C8C: BF870112
	v_dual_fmac_f32 v0, v34, v38 :: v_dual_and_b32 v45, 0xffff0000, v45// 000000242C90: C8244D22 002C5AFF FFFF0000
	v_and_b32_e32 v34, 0xffff0000, v43                         // 000000242C9C: 364456FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242CA4: BF870092
	v_fmac_f32_e32 v0, v44, v45                                // 000000242CA8: 56005B2C
	v_fmac_f32_e32 v0, v33, v34                                // 000000242CAC: 56004521
	v_mad_i64_i32 v[33:34], null, 0xa00, v37, v[67:68]         // 000000242CB0: D6FF7C21 050E4AFF 00000A00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242CBC: BF870112
	v_mul_f32_e32 v0, 0x3e800000, v0                           // 000000242CC0: 100000FF 3E800000
	.long 0xd73c002b                                           // 000000242CC8: D73C002B
	v_cndmask_b32_e32 v1, 1, v33, vcc_lo                       // 000000242CCC: 02024281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242CD0: BF870112
	v_bfe_u32 v38, v0, 16, 1                                   // 000000242CD4: D6100026 02052100
	.long 0xd700062b                                           // 000000242CDC: D700062B
	v_cndmask_b32_e32 v1, s14, v43, vcc_lo                     // 000000242CE0: 0202560E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000242CE4: BF870212
	v_add3_u32 v38, v0, v38, 0x7fff                            // 000000242CE8: D6550026 03FE4D00 00007FFF
	v_add_co_ci_u32_e64 v44, null, s15, v44, s6                // 000000242CF4: D5207C2C 001A580F
	global_store_d16_hi_b16 v[43:44], v38, off                 // 000000242CFC: DC960000 007C262B
	s_cbranch_vccnz 9                                          // 000000242D04: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x212c>
	.long 0xd73c0021                                           // 000000242D08: D73C0021
	v_cndmask_b32_e32 v1, 2, v33, vcc_lo                       // 000000242D0C: 02024282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242D10: BF870091
	.long 0xd7006a21                                           // 000000242D14: D7006A21
	v_cndmask_b32_e32 v1, s16, v33, vcc_lo                     // 000000242D18: 02024210
	v_add_co_ci_u32_e64 v34, null, s17, v34, vcc_lo            // 000000242D1C: D5207C22 01AA4411
	global_store_b32 v[33:34], v0, off                         // 000000242D24: DC6A0000 007C0021
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 000000242D2C: 916A0B7E
	s_cbranch_vccnz 29                                         // 000000242D30: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x21a8>
	v_and_b32_e32 v43, 0xffff0000, v38                         // 000000242D34: 36564CFF FFFF0000
	v_mad_i64_i32 v[33:34], null, 0x2800, v37, s[18:19]        // 000000242D3C: D6FF7C21 004A4AFF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242D48: BF870112
	v_sub_f32_e32 v0, v0, v43                                  // 000000242D4C: 08005700
	.long 0xd7006a21                                           // 000000242D50: D7006A21
	v_cndmask_b32_e32 v1, v33, v65, vcc_lo                     // 000000242D54: 02028321
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000242D58: BF870212
	v_bfe_u32 v43, v0, 16, 1                                   // 000000242D5C: D610002B 02052100
	v_add_co_ci_u32_e64 v34, null, v34, v66, vcc_lo            // 000000242D64: D5207C22 01AA8522
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000242D6C: BF870212
	v_add3_u32 v0, v0, v43, 0x7fff                             // 000000242D70: D6550000 03FE5700 00007FFF
	.long 0xd7006a2b                                           // 000000242D7C: D7006A2B
	v_cndmask_b32_e32 v1, 0x1000, v33, vcc_lo                  // 000000242D80: 020242FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000242D88: BF870001
	v_add_co_ci_u32_e64 v44, null, 0, v34, vcc_lo              // 000000242D8C: D5207C2C 01AA4480
	s_clause 0x1                                               // 000000242D94: BF850001
	global_store_d16_hi_b16 v[33:34], v38, off                 // 000000242D98: DC960000 007C2621
	global_store_d16_hi_b16 v[43:44], v0, off offset:1024      // 000000242DA0: DC960400 007C002B
	s_or_b32 exec_lo, exec_lo, s9                              // 000000242DA8: 8C7E097E
	v_or_b32_e32 v38, 12, v74                                  // 000000242DAC: 384C948C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000242DB0: BF870001
	.long 0xd4440006                                           // 000000242DB4: D4440006
	v_cndmask_b32_e32 v1, s20, v38, vcc_lo                     // 000000242DB8: 02024C14
	s_and_saveexec_b32 s10, s6                                 // 000000242DBC: BE8A2006
	s_cbranch_execz 278                                        // 000000242DC0: BFA50116 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x261c>
	v_mad_i64_i32 v[33:34], null, 0x5000, v38, v[69:70]        // 000000242DC4: D6FF7C21 05164CFF 00005000
	v_bfe_u32 v49, v63, 16, 1                                  // 000000242DD0: D6100031 0205213F
	global_load_u16 v0, v[33:34], off                          // 000000242DD8: DC4A0000 007C0021
	.long 0xd7006a2b                                           // 000000242DE0: D7006A2B
	v_cndmask_b32_e32 v1, 0x1000, v33, vcc_lo                  // 000000242DE4: 020242FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000242DEC: BF8700A1
	v_add_co_ci_u32_e64 v44, null, 0, v34, vcc_lo              // 000000242DF0: D5207C2C 01AA4480
	.long 0xd7006a2d                                           // 000000242DF8: D7006A2D
	v_cndmask_b32_e32 v1, 0x2000, v33, vcc_lo                  // 000000242DFC: 020242FF 00002000
	v_add_co_ci_u32_e64 v46, null, 0, v34, vcc_lo              // 000000242E04: D5207C2E 01AA4480
	global_load_u16 v43, v[43:44], off offset:1024             // 000000242E0C: DC4A0400 2B7C002B
	.long 0xd7006a21                                           // 000000242E14: D7006A21
	v_cndmask_b32_e32 v1, 0x3000, v33, vcc_lo                  // 000000242E18: 020242FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000242E20: BF870001
	v_add_co_ci_u32_e64 v34, null, 0, v34, vcc_lo              // 000000242E24: D5207C22 01AA4480
	s_clause 0x1                                               // 000000242E2C: BF850001
	global_load_u16 v44, v[45:46], off offset:2048             // 000000242E30: DC4A0800 2C7C002D
	global_load_u16 v33, v[33:34], off offset:3072             // 000000242E38: DC4A0C00 217C0021
	v_bfe_u32 v34, v39, 16, 1                                  // 000000242E40: D6100022 02052127
	v_bfe_u32 v45, v47, 16, 1                                  // 000000242E48: D610002D 0205212F
	v_bfe_u32 v46, v55, 16, 1                                  // 000000242E50: D610002E 02052137
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000242E58: BF870193
	v_add3_u32 v34, v39, v34, 0x7fff                           // 000000242E5C: D6550022 03FE4527 00007FFF
	v_add3_u32 v39, v47, v45, 0x7fff                           // 000000242E68: D6550027 03FE5B2F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000242E74: BF8701A3
	v_add3_u32 v45, v55, v46, 0x7fff                           // 000000242E78: D655002D 03FE5D37 00007FFF
	v_add3_u32 v46, v63, v49, 0x7fff                           // 000000242E84: D655002E 03FE633F 00007FFF
	v_and_b32_e32 v39, 0xffff0000, v39                         // 000000242E90: 364E4EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000242E98: BF870092
	v_and_b32_e32 v46, 0xffff0000, v46                         // 000000242E9C: 365C5CFF FFFF0000
	v_dual_mul_f32 v39, 0xbfb8aa3b, v39 :: v_dual_mul_f32 v46, 0xbfb8aa3b, v46// 000000242EA4: C8C64EFF 272E5CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000242EB0: BF870121
	v_exp_f32_e32 v39, v39                                     // 000000242EB4: 7E4E4B27
	v_and_b32_e32 v34, 0xffff0000, v34                         // 000000242EB8: 364444FF FFFF0000
	v_exp_f32_e32 v46, v46                                     // 000000242EC0: 7E5C4B2E
	v_and_b32_e32 v45, 0xffff0000, v45                         // 000000242EC4: 365A5AFF FFFF0000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242ECC: BF870115
	v_dual_add_f32 v39, 1.0, v39 :: v_dual_add_f32 v46, 1.0, v46// 000000242ED0: C9084EF2 272E5CF2
	v_dual_mul_f32 v34, 0xbfb8aa3b, v34 :: v_dual_mul_f32 v45, 0xbfb8aa3b, v45// 000000242ED8: C8C644FF 222C5AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000242EE4: BF870222
	v_div_scale_f32 v49, null, v39, v39, 1.0                   // 000000242EE8: D6FC7C31 03CA4F27
	v_div_scale_f32 v58, s7, 1.0, v39, 1.0                     // 000000242EF0: D6FC073A 03CA4EF2
	v_div_scale_f32 v51, null, v46, v46, 1.0                   // 000000242EF8: D6FC7C33 03CA5D2E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000242F00: BF8700B4
	v_exp_f32_e32 v34, v34                                     // 000000242F04: 7E444B22
	v_exp_f32_e32 v45, v45                                     // 000000242F08: 7E5A4B2D
	v_rcp_f32_e32 v53, v49                                     // 000000242F0C: 7E6A5531
	v_rcp_f32_e32 v55, v51                                     // 000000242F10: 7E6E5533
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000242F14: BF870317
	v_dual_add_f32 v34, 1.0, v34 :: v_dual_add_f32 v45, 1.0, v45// 000000242F18: C90844F2 222C5AF2
	v_fma_f32 v60, -v49, v53, 1.0                              // 000000242F20: D613003C 23CA6B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000242F28: BF870195
	v_fma_f32 v63, -v51, v55, 1.0                              // 000000242F2C: D613003F 23CA6F33
	v_div_scale_f32 v47, null, v34, v34, 1.0                   // 000000242F34: D6FC7C2F 03CA4522
	s_delay_alu instid0(VALU_DEP_4)                            // 000000242F3C: BF870004
	v_div_scale_f32 v50, null, v45, v45, 1.0                   // 000000242F40: D6FC7C32 03CA5B2D
	v_div_scale_f32 v57, vcc_lo, 1.0, v34, 1.0                 // 000000242F48: D6FC6A39 03CA44F2
	v_div_scale_f32 v62, s8, 1.0, v45, 1.0                     // 000000242F50: D6FC083E 03CA5AF2
	v_fmac_f32_e32 v53, v60, v53                               // 000000242F58: 566A6B3C
	v_rcp_f32_e32 v52, v47                                     // 000000242F5C: 7E68552F
	v_rcp_f32_e32 v54, v50                                     // 000000242F60: 7E6C5532
	v_fmac_f32_e32 v55, v63, v55                               // 000000242F64: 566E6F3F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000242F68: BF870296
	v_fma_f32 v59, -v47, v52, 1.0                              // 000000242F6C: D613003B 23CA692F
	v_fma_f32 v61, -v50, v54, 1.0                              // 000000242F74: D613003D 23CA6D32
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242F7C: BF870112
	v_fmac_f32_e32 v52, v59, v52                               // 000000242F80: 5668693B
	v_dual_fmac_f32 v54, v61, v54 :: v_dual_mul_f32 v61, v58, v53// 000000242F84: C8066D3D 363C6B3A
	v_div_scale_f32 v59, s9, 1.0, v46, 1.0                     // 000000242F8C: D6FC093B 03CA5CF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000242F94: BF870193
	v_mul_f32_e32 v60, v57, v52                                // 000000242F98: 10786939
	v_fma_f32 v75, -v49, v61, v58                              // 000000242F9C: D613004B 24EA7B31
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000242FA4: BF870122
	v_fma_f32 v72, -v47, v60, v57                              // 000000242FA8: D6130048 24E6792F
	v_mul_f32_e32 v63, v62, v54                                // 000000242FB0: 107E6D3E
	v_dual_fmac_f32 v61, v75, v53 :: v_dual_fmac_f32 v60, v72, v52// 000000242FB4: C8006B4B 3D3C6948
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242FBC: BF870112
	v_fma_f32 v76, -v50, v63, v62                              // 000000242FC0: D613004C 24FA7F32
	v_fma_f32 v47, -v47, v60, v57                              // 000000242FC8: D613002F 24E6792F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000242FD0: BF870112
	v_fmac_f32_e32 v63, v76, v54                               // 000000242FD4: 567E6D4C
	v_div_fmas_f32 v47, v47, v52, v60                          // 000000242FD8: D637002F 04F2692F
	s_mov_b32 vcc_lo, s7                                       // 000000242FE0: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000242FE4: BF8700C1
	v_div_fixup_f32 v34, v47, v34, 1.0                         // 000000242FE8: D6270022 03CA452F
	s_waitcnt vmcnt(3)                                         // 000000242FF0: BF890FF7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000242FF4: 30000090
	v_fma_f32 v49, -v49, v61, v58                              // 000000242FF8: D6130031 24EA7B31
	v_div_fmas_f32 v49, v49, v53, v61                          // 000000243000: D6370031 04F66B31
	s_mov_b32 vcc_lo, s8                                       // 000000243008: BEEA0008
	s_delay_alu instid0(VALU_DEP_1)                            // 00000024300C: BF870001
	v_div_fixup_f32 v39, v49, v39, 1.0                         // 000000243010: D6270027 03CA4F31
	v_bfe_u32 v49, v34, 16, 1                                  // 000000243018: D6100031 02052122
	s_waitcnt vmcnt(1)                                         // 000000243020: BF8907F7
	v_lshlrev_b32_e32 v44, 16, v44                             // 000000243024: 30585890
	s_waitcnt vmcnt(0)                                         // 000000243028: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000024302C: 30424290
	v_add3_u32 v34, v34, v49, 0x7fff                           // 000000243030: D6550022 03FE6322 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000024303C: BF870091
	v_dual_mul_f32 v71, v59, v55 :: v_dual_and_b32 v34, 0xffff0000, v34// 000000243040: C8E46F3B 472244FF FFFF0000
	v_fma_f32 v77, -v51, v71, v59                              // 00000024304C: D613004D 24EE8F33
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000243054: BF870232
	v_fma_f32 v0, v0, v34, 0                                   // 000000243058: D6130000 02024500
	v_lshlrev_b32_e32 v34, 16, v43                             // 000000243060: 30445690
	v_fma_f32 v50, -v50, v63, v62                              // 000000243064: D6130032 24FA7F32
	v_fmac_f32_e32 v71, v77, v55                               // 00000024306C: 568E6F4D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243070: BF870112
	v_div_fmas_f32 v47, v50, v54, v63                          // 000000243074: D637002F 04FE6D32
	v_fma_f32 v51, -v51, v71, v59                              // 00000024307C: D6130033 24EE8F33
	s_mov_b32 vcc_lo, s9                                       // 000000243084: BEEA0009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243088: BF870112
	v_div_fixup_f32 v45, v47, v45, 1.0                         // 00000024308C: D627002D 03CA5B2F
	v_div_fmas_f32 v50, v51, v55, v71                          // 000000243094: D6370032 051E6F33
	v_bfe_u32 v47, v39, 16, 1                                  // 00000024309C: D610002F 02052127
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 0000002430A4: 7C9A9281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002430A8: BF870214
	v_bfe_u32 v49, v45, 16, 1                                  // 0000002430AC: D6100031 0205212D
	v_div_fixup_f32 v46, v50, v46, 1.0                         // 0000002430B4: D627002E 03CA5D32
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002430BC: BF8701A4
	v_add3_u32 v39, v39, v47, 0x7fff                           // 0000002430C0: D6550027 03FE5F27 00007FFF
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000002430CC: 8B6A6A7E
	v_add3_u32 v45, v45, v49, 0x7fff                           // 0000002430D0: D655002D 03FE632D 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002430DC: BF870113
	v_bfe_u32 v47, v46, 16, 1                                  // 0000002430E0: D610002F 0205212E
	v_and_b32_e32 v45, 0xffff0000, v45                         // 0000002430E8: 365A5AFF FFFF0000
	v_and_b32_e32 v39, 0xffff0000, v39                         // 0000002430F0: 364E4EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002430F8: BF870113
	v_add3_u32 v43, v46, v47, 0x7fff                           // 0000002430FC: D655002B 03FE5F2E 00007FFF
	v_fmac_f32_e32 v0, v34, v39                                // 000000243108: 56004F22
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024310C: BF870112
	v_and_b32_e32 v34, 0xffff0000, v43                         // 000000243110: 364456FF FFFF0000
	v_fmac_f32_e32 v0, v44, v45                                // 000000243118: 56005B2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000024311C: BF870121
	v_fmac_f32_e32 v0, v33, v34                                // 000000243120: 56004521
	v_mad_i64_i32 v[33:34], null, 0xa00, v38, v[67:68]         // 000000243124: D6FF7C21 050E4CFF 00000A00
	v_mul_f32_e32 v0, 0x3e800000, v0                           // 000000243130: 100000FF 3E800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243138: BF870112
	.long 0xd73c002b                                           // 00000024313C: D73C002B
	v_cndmask_b32_e32 v1, 1, v33, vcc_lo                       // 000000243140: 02024281
	v_bfe_u32 v39, v0, 16, 1                                   // 000000243144: D6100027 02052100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024314C: BF870112
	.long 0xd700072b                                           // 000000243150: D700072B
	v_cndmask_b32_e32 v1, s14, v43, vcc_lo                     // 000000243154: 0202560E
	v_add3_u32 v39, v0, v39, 0x7fff                            // 000000243158: D6550027 03FE4F00 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000243164: BF870004
	v_add_co_ci_u32_e64 v44, null, s15, v44, s7                // 000000243168: D5207C2C 001E580F
	global_store_d16_hi_b16 v[43:44], v39, off                 // 000000243170: DC960000 007C272B
	s_cbranch_vccnz 9                                          // 000000243178: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x25a0>
	.long 0xd73c0021                                           // 00000024317C: D73C0021
	v_cndmask_b32_e32 v1, 2, v33, vcc_lo                       // 000000243180: 02024282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243184: BF870091
	.long 0xd7006a21                                           // 000000243188: D7006A21
	v_cndmask_b32_e32 v1, s16, v33, vcc_lo                     // 00000024318C: 02024210
	v_add_co_ci_u32_e64 v34, null, s17, v34, vcc_lo            // 000000243190: D5207C22 01AA4411
	global_store_b32 v[33:34], v0, off                         // 000000243198: DC6A0000 007C0021
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 0000002431A0: 916A0B7E
	s_cbranch_vccnz 29                                         // 0000002431A4: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x261c>
	v_and_b32_e32 v43, 0xffff0000, v39                         // 0000002431A8: 36564EFF FFFF0000
	v_mad_i64_i32 v[33:34], null, 0x2800, v38, s[18:19]        // 0000002431B0: D6FF7C21 004A4CFF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002431BC: BF870112
	v_sub_f32_e32 v0, v0, v43                                  // 0000002431C0: 08005700
	.long 0xd7006a21                                           // 0000002431C4: D7006A21
	v_cndmask_b32_e32 v1, v33, v65, vcc_lo                     // 0000002431C8: 02028321
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002431CC: BF870212
	v_bfe_u32 v43, v0, 16, 1                                   // 0000002431D0: D610002B 02052100
	v_add_co_ci_u32_e64 v34, null, v34, v66, vcc_lo            // 0000002431D8: D5207C22 01AA8522
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002431E0: BF870212
	v_add3_u32 v0, v0, v43, 0x7fff                             // 0000002431E4: D6550000 03FE5700 00007FFF
	.long 0xd7006a2b                                           // 0000002431F0: D7006A2B
	v_cndmask_b32_e32 v1, 0x1000, v33, vcc_lo                  // 0000002431F4: 020242FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002431FC: BF870001
	v_add_co_ci_u32_e64 v44, null, 0, v34, vcc_lo              // 000000243200: D5207C2C 01AA4480
	s_clause 0x1                                               // 000000243208: BF850001
	global_store_d16_hi_b16 v[33:34], v39, off                 // 00000024320C: DC960000 007C2721
	global_store_d16_hi_b16 v[43:44], v0, off offset:1024      // 000000243214: DC960400 007C002B
	s_or_b32 exec_lo, exec_lo, s10                             // 00000024321C: 8C7E0A7E
	v_or_b32_e32 v39, 14, v74                                  // 000000243220: 384E948E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000243224: BF870001
	.long 0xd4440007                                           // 000000243228: D4440007
	v_cndmask_b32_e32 v1, s20, v39, vcc_lo                     // 00000024322C: 02024E14
	s_and_saveexec_b32 s12, s7                                 // 000000243230: BE8C2007
	s_cbranch_execz 286                                        // 000000243234: BFA5011E <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x2ab0>
	v_mad_i64_i32 v[33:34], null, 0x5000, v39, v[69:70]        // 000000243238: D6FF7C21 05164EFF 00005000
	v_bfe_u32 v47, v64, 16, 1                                  // 000000243244: D610002F 02052140
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000024324C: BF870092
	.long 0xd7006a2b                                           // 000000243250: D7006A2B
	v_cndmask_b32_e32 v1, 0x1000, v33, vcc_lo                  // 000000243254: 020242FF 00001000
	v_add_co_ci_u32_e64 v44, null, 0, v34, vcc_lo              // 00000024325C: D5207C2C 01AA4480
	.long 0xd7006a2d                                           // 000000243264: D7006A2D
	v_cndmask_b32_e32 v1, 0x2000, v33, vcc_lo                  // 000000243268: 020242FF 00002000
	s_clause 0x1                                               // 000000243270: BF850001
	global_load_u16 v0, v[33:34], off                          // 000000243274: DC4A0000 007C0021
	global_load_u16 v43, v[43:44], off offset:1024             // 00000024327C: DC4A0400 2B7C002B
	v_add_co_ci_u32_e64 v46, null, 0, v34, vcc_lo              // 000000243284: D5207C2E 01AA4480
	.long 0xd7006a21                                           // 00000024328C: D7006A21
	v_cndmask_b32_e32 v1, 0x3000, v33, vcc_lo                  // 000000243290: 020242FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000243298: BF870001
	v_add_co_ci_u32_e64 v34, null, 0, v34, vcc_lo              // 00000024329C: D5207C22 01AA4480
	s_clause 0x1                                               // 0000002432A4: BF850001
	global_load_u16 v44, v[45:46], off offset:2048             // 0000002432A8: DC4A0800 2C7C002D
	global_load_u16 v33, v[33:34], off offset:3072             // 0000002432B0: DC4A0C00 217C0021
	v_bfe_u32 v34, v40, 16, 1                                  // 0000002432B8: D6100022 02052128
	v_bfe_u32 v45, v48, 16, 1                                  // 0000002432C0: D610002D 02052130
	v_bfe_u32 v46, v56, 16, 1                                  // 0000002432C8: D610002E 02052138
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002432D0: BF870193
	v_add3_u32 v34, v40, v34, 0x7fff                           // 0000002432D4: D6550022 03FE4528 00007FFF
	v_add3_u32 v40, v48, v45, 0x7fff                           // 0000002432E0: D6550028 03FE5B30 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002432EC: BF870123
	v_add3_u32 v45, v56, v46, 0x7fff                           // 0000002432F0: D655002D 03FE5D38 00007FFF
	v_add3_u32 v46, v64, v47, 0x7fff                           // 0000002432FC: D655002E 03FE5F40 00007FFF
	v_and_b32_e32 v45, 0xffff0000, v45                         // 000000243308: 365A5AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243310: BF870091
	v_mul_f32_e32 v45, 0xbfb8aa3b, v45                         // 000000243314: 105A5AFF BFB8AA3B
	v_exp_f32_e32 v45, v45                                     // 00000024331C: 7E5A4B2D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243320: BF870095
	v_dual_add_f32 v45, 1.0, v45 :: v_dual_and_b32 v34, 0xffff0000, v34// 000000243324: C9245AF2 2D2244FF FFFF0000
	v_mul_f32_e32 v34, 0xbfb8aa3b, v34                         // 000000243330: 104444FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243338: BF870112
	v_div_scale_f32 v49, null, v45, v45, 1.0                   // 00000024333C: D6FC7C31 03CA5B2D
	v_exp_f32_e32 v34, v34                                     // 000000243344: 7E444B22
	v_div_scale_f32 v60, s9, 1.0, v45, 1.0                     // 000000243348: D6FC093C 03CA5AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000243350: BF870312
	v_rcp_f32_e32 v53, v49                                     // 000000243354: 7E6A5531
	v_add_f32_e32 v34, 1.0, v34                                // 000000243358: 064444F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000024335C: BF8701A5
	v_fma_f32 v59, -v49, v53, 1.0                              // 000000243360: D613003B 23CA6B31
	v_and_b32_e32 v46, 0xffff0000, v46                         // 000000243368: 365C5CFF FFFF0000
	v_div_scale_f32 v47, null, v34, v34, 1.0                   // 000000243370: D6FC7C2F 03CA4522
	v_div_scale_f32 v55, vcc_lo, 1.0, v34, 1.0                 // 000000243378: D6FC6A37 03CA44F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000243380: BF870193
	v_dual_fmac_f32 v53, v59, v53 :: v_dual_mul_f32 v46, 0xbfb8aa3b, v46// 000000243384: C8066B3B 352E5CFF BFB8AA3B
	v_rcp_f32_e32 v51, v47                                     // 000000243390: 7E66552F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000243394: BF870311
	v_exp_f32_e32 v46, v46                                     // 000000243398: 7E5C4B2E
	v_fma_f32 v57, -v47, v51, 1.0                              // 00000024339C: D6130039 23CA672F
	v_and_b32_e32 v40, 0xffff0000, v40                         // 0000002433A4: 365050FF FFFF0000
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 0000002433AC: BF870105
	v_dual_add_f32 v46, 1.0, v46 :: v_dual_fmac_f32 v51, v57, v51// 0000002433B0: C9005CF2 2E326739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002433B8: BF870112
	v_mul_f32_e32 v40, 0xbfb8aa3b, v40                         // 0000002433BC: 105050FF BFB8AA3B
	v_div_scale_f32 v50, null, v46, v46, 1.0                   // 0000002433C4: D6FC7C32 03CA5D2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002433CC: BF870291
	v_rcp_f32_e32 v54, v50                                     // 0000002433D0: 7E6C5532
	v_fma_f32 v61, -v50, v54, 1.0                              // 0000002433D4: D613003D 23CA6D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002433DC: BF8700A1
	v_dual_fmac_f32 v54, v61, v54 :: v_dual_mul_f32 v61, v60, v53// 0000002433E0: C8066D3D 363C6B3C
	v_exp_f32_e32 v40, v40                                     // 0000002433E8: 7E504B28
	v_fma_f32 v71, -v49, v61, v60                              // 0000002433EC: D6130047 24F27B31
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000002433F4: BF870085
	v_dual_fmac_f32 v61, v71, v53 :: v_dual_add_f32 v40, 1.0, v40// 0000002433F8: C8086B47 3D2850F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243400: BF870111
	v_fma_f32 v49, -v49, v61, v60                              // 000000243404: D6130031 24F27B31
	v_div_scale_f32 v48, null, v40, v40, 1.0                   // 00000024340C: D6FC7C30 03CA5128
	v_div_scale_f32 v56, s8, 1.0, v40, 1.0                     // 000000243414: D6FC0838 03CA50F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000024341C: BF870292
	v_rcp_f32_e32 v52, v48                                     // 000000243420: 7E685530
	v_fma_f32 v58, -v48, v52, 1.0                              // 000000243424: D613003A 23CA6930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000024342C: BF870091
	v_fmac_f32_e32 v52, v58, v52                               // 000000243430: 5668693A
	v_dual_mul_f32 v58, v55, v51 :: v_dual_mul_f32 v59, v56, v52// 000000243434: C8C66737 3A3A6938
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024343C: BF870111
	v_fma_f32 v63, -v47, v58, v55                              // 000000243440: D613003F 24DE752F
	v_fma_f32 v64, -v48, v59, v56                              // 000000243448: D6130040 24E27730
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000243450: BF870121
	v_dual_fmac_f32 v58, v63, v51 :: v_dual_fmac_f32 v59, v64, v52// 000000243454: C800673F 3A3A6940
	v_div_scale_f32 v57, s10, 1.0, v46, 1.0                    // 00000024345C: D6FC0A39 03CA5CF2
	v_fma_f32 v47, -v47, v58, v55                              // 000000243464: D613002F 24DE752F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024346C: BF870113
	v_fma_f32 v48, -v48, v59, v56                              // 000000243470: D6130030 24E27730
	v_div_fmas_f32 v47, v47, v51, v58                          // 000000243478: D637002F 04EA672F
	s_mov_b32 vcc_lo, s8                                       // 000000243480: BEEA0008
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000243484: BF870122
	v_div_fmas_f32 v48, v48, v52, v59                          // 000000243488: D6370030 04EE6930
	s_mov_b32 vcc_lo, s9                                       // 000000243490: BEEA0009
	v_div_fixup_f32 v34, v47, v34, 1.0                         // 000000243494: D6270022 03CA452F
	v_div_fmas_f32 v47, v49, v53, v61                          // 00000024349C: D637002F 04F66B31
	s_mov_b32 vcc_lo, s10                                      // 0000002434A4: BEEA000A
	v_div_fixup_f32 v40, v48, v40, 1.0                         // 0000002434A8: D6270028 03CA5130
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002434B0: BF870193
	v_bfe_u32 v48, v34, 16, 1                                  // 0000002434B4: D6100030 02052122
	v_div_fixup_f32 v45, v47, v45, 1.0                         // 0000002434BC: D627002D 03CA5B2F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002434C4: BF870193
	v_bfe_u32 v47, v40, 16, 1                                  // 0000002434C8: D610002F 02052128
	v_add3_u32 v34, v34, v48, 0x7fff                           // 0000002434D0: D6550022 03FE6122 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002434DC: BF870193
	v_bfe_u32 v48, v45, 16, 1                                  // 0000002434E0: D6100030 0205212D
	v_add3_u32 v40, v40, v47, 0x7fff                           // 0000002434E8: D6550028 03FE5F28 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002434F4: BF870193
	v_and_b32_e32 v34, 0xffff0000, v34                         // 0000002434F8: 364444FF FFFF0000
	v_add3_u32 v45, v45, v48, 0x7fff                           // 000000243500: D655002D 03FE612D 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024350C: BF870113
	v_and_b32_e32 v40, 0xffff0000, v40                         // 000000243510: 365050FF FFFF0000
	v_and_b32_e32 v45, 0xffff0000, v45                         // 000000243518: 365A5AFF FFFF0000
	s_waitcnt vmcnt(3)                                         // 000000243520: BF890FF7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000243524: 30000090
	s_delay_alu instid0(VALU_DEP_1)                            // 000000243528: BF870001
	v_fma_f32 v0, v0, v34, 0                                   // 00000024352C: D6130000 02024500
	s_waitcnt vmcnt(2)                                         // 000000243534: BF890BF7
	v_lshlrev_b32_e32 v34, 16, v43                             // 000000243538: 30445690
	s_waitcnt vmcnt(1)                                         // 00000024353C: BF8907F7
	v_lshlrev_b32_e32 v44, 16, v44                             // 000000243540: 30585890
	s_waitcnt vmcnt(0)                                         // 000000243544: BF8903F7
	v_dual_mul_f32 v62, v57, v54 :: v_dual_lshlrev_b32 v33, 16, v33// 000000243548: C8E26D39 3E204290
	v_fmac_f32_e32 v0, v34, v40                                // 000000243550: 56005122
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243554: BF870112
	v_fma_f32 v72, -v50, v62, v57                              // 000000243558: D6130048 24E67D32
	v_fmac_f32_e32 v0, v44, v45                                // 000000243560: 56005B2C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243564: BF870092
	v_fmac_f32_e32 v62, v72, v54                               // 000000243568: 567C6D48
	v_fma_f32 v50, -v50, v62, v57                              // 00000024356C: D6130032 24E67D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000243574: BF870121
	v_div_fmas_f32 v49, v50, v54, v62                          // 000000243578: D6370031 04FA6D32
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 000000243580: 7C9A9281
	v_div_fixup_f32 v46, v49, v46, 1.0                         // 000000243584: D627002E 03CA5D31
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000024358C: 8B6A6A7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243590: BF870091
	v_bfe_u32 v47, v46, 16, 1                                  // 000000243594: D610002F 0205212E
	v_add3_u32 v43, v46, v47, 0x7fff                           // 00000024359C: D655002B 03FE5F2E 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002435A8: BF870091
	v_and_b32_e32 v34, 0xffff0000, v43                         // 0000002435AC: 364456FF FFFF0000
	v_fmac_f32_e32 v0, v33, v34                                // 0000002435B4: 56004521
	v_mad_i64_i32 v[33:34], null, 0xa00, v39, v[67:68]         // 0000002435B8: D6FF7C21 050E4EFF 00000A00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002435C4: BF870112
	v_mul_f32_e32 v0, 0x3e800000, v0                           // 0000002435C8: 100000FF 3E800000
	.long 0xd73c002b                                           // 0000002435D0: D73C002B
	v_cndmask_b32_e32 v1, 1, v33, vcc_lo                       // 0000002435D4: 02024281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002435D8: BF870112
	v_bfe_u32 v40, v0, 16, 1                                   // 0000002435DC: D6100028 02052100
	.long 0xd700082b                                           // 0000002435E4: D700082B
	v_cndmask_b32_e32 v1, s14, v43, vcc_lo                     // 0000002435E8: 0202560E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002435EC: BF870212
	v_add3_u32 v40, v0, v40, 0x7fff                            // 0000002435F0: D6550028 03FE5100 00007FFF
	v_add_co_ci_u32_e64 v44, null, s15, v44, s8                // 0000002435FC: D5207C2C 0022580F
	global_store_d16_hi_b16 v[43:44], v40, off                 // 000000243604: DC960000 007C282B
	s_cbranch_vccnz 9                                          // 00000024360C: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x2a34>
	.long 0xd73c0021                                           // 000000243610: D73C0021
	v_cndmask_b32_e32 v1, 2, v33, vcc_lo                       // 000000243614: 02024282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243618: BF870091
	.long 0xd7006a21                                           // 00000024361C: D7006A21
	v_cndmask_b32_e32 v1, s16, v33, vcc_lo                     // 000000243620: 02024210
	v_add_co_ci_u32_e64 v34, null, s17, v34, vcc_lo            // 000000243624: D5207C22 01AA4411
	global_store_b32 v[33:34], v0, off                         // 00000024362C: DC6A0000 007C0021
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 000000243634: 916A0B7E
	s_cbranch_vccnz 29                                         // 000000243638: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x2ab0>
	v_and_b32_e32 v43, 0xffff0000, v40                         // 00000024363C: 365650FF FFFF0000
	v_mad_i64_i32 v[33:34], null, 0x2800, v39, s[18:19]        // 000000243644: D6FF7C21 004A4EFF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243650: BF870112
	v_sub_f32_e32 v0, v0, v43                                  // 000000243654: 08005700
	.long 0xd7006a21                                           // 000000243658: D7006A21
	v_cndmask_b32_e32 v1, v33, v65, vcc_lo                     // 00000024365C: 02028321
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000243660: BF870212
	v_bfe_u32 v43, v0, 16, 1                                   // 000000243664: D610002B 02052100
	v_add_co_ci_u32_e64 v34, null, v34, v66, vcc_lo            // 00000024366C: D5207C22 01AA8522
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000243674: BF870212
	v_add3_u32 v0, v0, v43, 0x7fff                             // 000000243678: D6550000 03FE5700 00007FFF
	.long 0xd7006a2b                                           // 000000243684: D7006A2B
	v_cndmask_b32_e32 v1, 0x1000, v33, vcc_lo                  // 000000243688: 020242FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000243690: BF870001
	v_add_co_ci_u32_e64 v44, null, 0, v34, vcc_lo              // 000000243694: D5207C2C 01AA4480
	s_clause 0x1                                               // 00000024369C: BF850001
	global_store_d16_hi_b16 v[33:34], v40, off                 // 0000002436A0: DC960000 007C2821
	global_store_d16_hi_b16 v[43:44], v0, off offset:1024      // 0000002436A8: DC960400 007C002B
	s_or_b32 exec_lo, exec_lo, s12                             // 0000002436B0: 8C7E0C7E
	s_and_saveexec_b32 s10, s0                                 // 0000002436B4: BE8A2000
	s_cbranch_execz 281                                        // 0000002436B8: BFA50119 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x2f20>
	v_mad_i64_i32 v[33:34], null, 0x5000, v74, v[69:70]        // 0000002436BC: D6FF7C21 051694FF 00005000
	global_load_u16 v0, v[33:34], off offset:32                // 0000002436C8: DC4A0020 007C0021
	.long 0xd7006a2b                                           // 0000002436D0: D7006A2B
	v_cndmask_b32_e32 v1, 0x1000, v33, vcc_lo                  // 0000002436D4: 020242FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002436DC: BF8700A1
	v_add_co_ci_u32_e64 v44, null, 0, v34, vcc_lo              // 0000002436E0: D5207C2C 01AA4480
	.long 0xd7006a2d                                           // 0000002436E8: D7006A2D
	v_cndmask_b32_e32 v1, 0x2000, v33, vcc_lo                  // 0000002436EC: 020242FF 00002000
	v_add_co_ci_u32_e64 v46, null, 0, v34, vcc_lo              // 0000002436F4: D5207C2E 01AA4480
	global_load_u16 v40, v[43:44], off offset:1056             // 0000002436FC: DC4A0420 287C002B
	.long 0xd7006a21                                           // 000000243704: D7006A21
	v_cndmask_b32_e32 v1, 0x3000, v33, vcc_lo                  // 000000243708: 020242FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000243710: BF870001
	v_add_co_ci_u32_e64 v34, null, 0, v34, vcc_lo              // 000000243714: D5207C22 01AA4480
	s_clause 0x1                                               // 00000024371C: BF850001
	global_load_u16 v43, v[45:46], off offset:2080             // 000000243720: DC4A0820 2B7C002D
	global_load_u16 v33, v[33:34], off offset:3104             // 000000243728: DC4A0C20 217C0021
	v_bfe_u32 v46, v25, 16, 1                                  // 000000243730: D610002E 02052119
	v_bfe_u32 v44, v9, 16, 1                                   // 000000243738: D610002C 02052109
	v_bfe_u32 v34, v1, 16, 1                                   // 000000243740: D6100022 02052101
	v_bfe_u32 v45, v17, 16, 1                                  // 000000243748: D610002D 02052111
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000243750: BF870214
	v_add3_u32 v25, v25, v46, 0x7fff                           // 000000243754: D6550019 03FE5D19 00007FFF
	v_add3_u32 v9, v9, v44, 0x7fff                             // 000000243760: D6550009 03FE5909 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000024376C: BF870214
	v_add3_u32 v1, v1, v34, 0x7fff                             // 000000243770: D6550001 03FE4501 00007FFF
	v_add3_u32 v17, v17, v45, 0x7fff                           // 00000024377C: D6550011 03FE5B11 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243788: BF870094
	v_and_b32_e32 v25, 0xffff0000, v25                         // 00000024378C: 363232FF FFFF0000
	v_mul_f32_e32 v25, 0xbfb8aa3b, v25                         // 000000243794: 103232FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000024379C: BF870291
	v_exp_f32_e32 v25, v25                                     // 0000002437A0: 7E324B19
	v_add_f32_e32 v25, 1.0, v25                                // 0000002437A4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002437A8: BF870091
	v_div_scale_f32 v46, null, v25, v25, 1.0                   // 0000002437AC: D6FC7C2E 03CA3319
	v_rcp_f32_e32 v50, v46                                     // 0000002437B4: 7E64552E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002437B8: BF870095
	v_fma_f32 v57, -v46, v50, 1.0                              // 0000002437BC: D6130039 23CA652E
	v_dual_fmac_f32 v50, v57, v50 :: v_dual_and_b32 v9, 0xffff0000, v9// 0000002437C4: C8246539 320812FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002437D0: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 0000002437D4: 101212FF BFB8AA3B
	v_exp_f32_e32 v9, v9                                       // 0000002437DC: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002437E0: BF870095
	v_add_f32_e32 v9, 1.0, v9                                  // 0000002437E4: 061212F2
	v_div_scale_f32 v44, null, v9, v9, 1.0                     // 0000002437E8: D6FC7C2C 03CA1309
	v_div_scale_f32 v52, s0, 1.0, v9, 1.0                      // 0000002437F0: D6FC0034 03CA12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002437F8: BF870292
	v_rcp_f32_e32 v48, v44                                     // 0000002437FC: 7E60552C
	v_fma_f32 v54, -v44, v48, 1.0                              // 000000243800: D6130036 23CA612C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243808: BF870091
	v_dual_fmac_f32 v48, v54, v48 :: v_dual_and_b32 v1, 0xffff0000, v1// 00000024380C: C8246136 300002FF FFFF0000
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000243818: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000243820: BF870291
	v_exp_f32_e32 v1, v1                                       // 000000243824: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 000000243828: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000024382C: BF870121
	v_div_scale_f32 v34, null, v1, v1, 1.0                     // 000000243830: D6FC7C22 03CA0301
	v_div_scale_f32 v51, vcc_lo, 1.0, v1, 1.0                  // 000000243838: D6FC6A33 03CA02F2
	v_rcp_f32_e32 v47, v34                                     // 000000243840: 7E5E5522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243844: BF870095
	v_fma_f32 v53, -v34, v47, 1.0                              // 000000243848: D6130035 23CA5F22
	v_fmac_f32_e32 v47, v53, v47                               // 000000243850: 565E5F35
	v_and_b32_e32 v17, 0xffff0000, v17                         // 000000243854: 362222FF FFFF0000
	v_div_scale_f32 v53, s9, 1.0, v25, 1.0                     // 00000024385C: D6FC0935 03CA32F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243864: BF870112
	v_dual_mul_f32 v54, v51, v47 :: v_dual_mul_f32 v17, 0xbfb8aa3b, v17// 000000243868: C8C65F33 361022FF BFB8AA3B
	v_mul_f32_e32 v58, v53, v50                                // 000000243874: 10746535
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243878: BF870112
	v_fma_f32 v59, -v34, v54, v51                              // 00000024387C: D613003B 24CE6D22
	v_fma_f32 v62, -v46, v58, v53                              // 000000243884: D613003E 24D6752E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024388C: BF870112
	v_fmac_f32_e32 v54, v59, v47                               // 000000243890: 566C5F3B
	v_fmac_f32_e32 v58, v62, v50                               // 000000243894: 5674653E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243898: BF870112
	v_fma_f32 v34, -v34, v54, v51                              // 00000024389C: D6130022 24CE6D22
	v_fma_f32 v46, -v46, v58, v53                              // 0000002438A4: D613002E 24D6752E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002438AC: BF8700A2
	v_div_fmas_f32 v34, v34, v47, v54                          // 0000002438B0: D6370022 04DA5F22
	s_mov_b32 vcc_lo, s0                                       // 0000002438B8: BEEA0000
	v_div_fixup_f32 v1, v34, v1, 1.0                           // 0000002438BC: D6270001 03CA0322
	s_waitcnt vmcnt(3)                                         // 0000002438C4: BF890FF7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000002438C8: 30000090
	v_exp_f32_e32 v17, v17                                     // 0000002438CC: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002438D0: BF870095
	v_add_f32_e32 v17, 1.0, v17                                // 0000002438D4: 062222F2
	v_div_scale_f32 v45, null, v17, v17, 1.0                   // 0000002438D8: D6FC7C2D 03CA2311
	v_div_scale_f32 v56, s8, 1.0, v17, 1.0                     // 0000002438E0: D6FC0838 03CA22F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002438E8: BF870292
	v_rcp_f32_e32 v49, v45                                     // 0000002438EC: 7E62552D
	v_fma_f32 v55, -v45, v49, 1.0                              // 0000002438F0: D6130037 23CA632D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002438F8: BF870121
	v_fmac_f32_e32 v49, v55, v49                               // 0000002438FC: 56626337
	v_mul_f32_e32 v55, v52, v48                                // 000000243900: 106E6134
	v_mul_f32_e32 v57, v56, v49                                // 000000243904: 10726338
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243908: BF870112
	v_fma_f32 v60, -v44, v55, v52                              // 00000024390C: D613003C 24D26F2C
	v_fma_f32 v61, -v45, v57, v56                              // 000000243914: D613003D 24E2732D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024391C: BF870112
	v_fmac_f32_e32 v55, v60, v48                               // 000000243920: 566E613C
	v_fmac_f32_e32 v57, v61, v49                               // 000000243924: 5672633D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243928: BF870112
	v_fma_f32 v44, -v44, v55, v52                              // 00000024392C: D613002C 24D26F2C
	v_fma_f32 v45, -v45, v57, v56                              // 000000243934: D613002D 24E2732D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000024393C: BF870122
	v_div_fmas_f32 v44, v44, v48, v55                          // 000000243940: D637002C 04DE612C
	s_mov_b32 vcc_lo, s8                                       // 000000243948: BEEA0008
	v_div_fmas_f32 v34, v45, v49, v57                          // 00000024394C: D6370022 04E6632D
	s_delay_alu instid0(VALU_DEP_2)                            // 000000243954: BF870002
	v_div_fixup_f32 v9, v44, v9, 1.0                           // 000000243958: D6270009 03CA132C
	v_bfe_u32 v44, v1, 16, 1                                   // 000000243960: D610002C 02052101
	s_mov_b32 vcc_lo, s9                                       // 000000243968: BEEA0009
	v_div_fmas_f32 v45, v46, v50, v58                          // 00000024396C: D637002D 04EA652E
	v_div_fixup_f32 v17, v34, v17, 1.0                         // 000000243974: D6270011 03CA2322
	v_bfe_u32 v34, v9, 16, 1                                   // 00000024397C: D6100022 02052109
	v_add3_u32 v1, v1, v44, 0x7fff                             // 000000243984: D6550001 03FE5901 00007FFF
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 000000243990: 7C9A9281
	v_div_fixup_f32 v25, v45, v25, 1.0                         // 000000243994: D6270019 03CA332D
	v_bfe_u32 v44, v17, 16, 1                                  // 00000024399C: D610002C 02052111
	v_add3_u32 v9, v9, v34, 0x7fff                             // 0000002439A4: D6550009 03FE4509 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002439B0: 360202FF FFFF0000
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000002439B8: 8B6A6A7E
	v_bfe_u32 v34, v25, 16, 1                                  // 0000002439BC: D6100022 02052119
	v_add3_u32 v17, v17, v44, 0x7fff                           // 0000002439C4: D6550011 03FE5911 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000002439D0: 361212FF FFFF0000
	v_fma_f32 v44, v0, v1, 0                                   // 0000002439D8: D613002C 02020300
	s_waitcnt vmcnt(2)                                         // 0000002439E0: BF890BF7
	v_lshlrev_b32_e32 v0, 16, v40                              // 0000002439E4: 30005090
	v_add3_u32 v1, v25, v34, 0x7fff                            // 0000002439E8: D6550001 03FE4519 00007FFF
	v_and_b32_e32 v17, 0xffff0000, v17                         // 0000002439F4: 362222FF FFFF0000
	s_waitcnt vmcnt(1)                                         // 0000002439FC: BF8907F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000243A00: BF870193
	v_dual_fmac_f32 v44, v0, v9 :: v_dual_lshlrev_b32 v25, 16, v43// 000000243A04: C8221300 2C185690
	v_and_b32_e32 v0, 0xffff0000, v1                           // 000000243A0C: 360002FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 000000243A14: BF8903F7
	v_lshlrev_b32_e32 v1, 16, v33                              // 000000243A18: 30024290
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243A1C: BF870093
	v_fmac_f32_e32 v44, v25, v17                               // 000000243A20: 56582319
	v_fmac_f32_e32 v44, v1, v0                                 // 000000243A24: 56580101
	v_mad_i64_i32 v[0:1], null, 0xa00, v74, v[67:68]           // 000000243A28: D6FF7C00 050E94FF 00000A00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243A34: BF870112
	v_mul_f32_e32 v9, 0x3e800000, v44                          // 000000243A38: 101258FF 3E800000
	.long 0xd73c0021                                           // 000000243A40: D73C0021
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000243A44: 02020081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243A48: BF870112
	v_bfe_u32 v17, v9, 16, 1                                   // 000000243A4C: D6100011 02052109
	.long 0xd7000021                                           // 000000243A54: D7000021
	v_cndmask_b32_e32 v1, s14, v33, vcc_lo                     // 000000243A58: 0202420E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000243A5C: BF870212
	v_add3_u32 v17, v9, v17, 0x7fff                            // 000000243A60: D6550011 03FE2309 00007FFF
	v_add_co_ci_u32_e64 v34, null, s15, v34, s0                // 000000243A6C: D5207C22 0002440F
	global_store_d16_hi_b16 v[33:34], v17, off offset:32       // 000000243A74: DC960020 007C1121
	s_cbranch_vccnz 9                                          // 000000243A7C: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x2ea4>
	.long 0xd73c0000                                           // 000000243A80: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000243A84: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243A88: BF870091
	.long 0xd7006a00                                           // 000000243A8C: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000243A90: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000243A94: D5207C01 01AA0211
	global_store_b32 v[0:1], v9, off offset:64                 // 000000243A9C: DC6A0040 007C0900
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 000000243AA4: 916A0B7E
	s_cbranch_vccnz 29                                         // 000000243AA8: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x2f20>
	v_and_b32_e32 v25, 0xffff0000, v17                         // 000000243AAC: 363222FF FFFF0000
	v_mad_i64_i32 v[0:1], null, 0x2800, v74, s[18:19]          // 000000243AB4: D6FF7C00 004A94FF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243AC0: BF870112
	v_sub_f32_e32 v9, v9, v25                                  // 000000243AC4: 08123309
	.long 0xd7006a00                                           // 000000243AC8: D7006A00
	v_cndmask_b32_e32 v1, v0, v65, vcc_lo                      // 000000243ACC: 02028300
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000243AD0: BF870212
	v_bfe_u32 v25, v9, 16, 1                                   // 000000243AD4: D6100019 02052109
	v_add_co_ci_u32_e64 v1, null, v1, v66, vcc_lo              // 000000243ADC: D5207C01 01AA8501
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000243AE4: BF870193
	.long 0xd7006a21                                           // 000000243AE8: D7006A21
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000243AEC: 020200FF 00001000
	v_add3_u32 v9, v9, v25, 0x7fff                             // 000000243AF4: D6550009 03FE3309 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000243B00: BF870003
	v_add_co_ci_u32_e64 v34, null, 0, v1, vcc_lo               // 000000243B04: D5207C22 01AA0280
	s_clause 0x1                                               // 000000243B0C: BF850001
	global_store_d16_hi_b16 v[0:1], v17, off offset:32         // 000000243B10: DC960020 007C1100
	global_store_d16_hi_b16 v[33:34], v9, off offset:1056      // 000000243B18: DC960420 007C0921
	s_or_b32 exec_lo, exec_lo, s10                             // 000000243B20: 8C7E0A7E
	s_and_saveexec_b32 s9, s1                                  // 000000243B24: BE892001
	s_cbranch_execz 285                                        // 000000243B28: BFA5011D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x33a0>
	v_mad_i64_i32 v[0:1], null, 0x5000, v41, v[69:70]          // 000000243B2C: D6FF7C00 051652FF 00005000
	v_bfe_u32 v40, v26, 16, 1                                  // 000000243B38: D6100028 0205211A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243B40: BF870092
	.long 0xd7006a21                                           // 000000243B44: D7006A21
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000243B48: 020200FF 00001000
	v_add_co_ci_u32_e64 v34, null, 0, v1, vcc_lo               // 000000243B50: D5207C22 01AA0280
	global_load_u16 v9, v[0:1], off offset:32                  // 000000243B58: DC4A0020 097C0000
	.long 0xd7006a2b                                           // 000000243B60: D7006A2B
	v_cndmask_b32_e32 v1, 0x2000, v0, vcc_lo                   // 000000243B64: 020200FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000243B6C: BF8700B1
	v_add_co_ci_u32_e64 v44, null, 0, v1, vcc_lo               // 000000243B70: D5207C2C 01AA0280
	global_load_u16 v17, v[33:34], off offset:1056             // 000000243B78: DC4A0420 117C0021
	.long 0xd7006a00                                           // 000000243B80: D7006A00
	v_cndmask_b32_e32 v1, 0x3000, v0, vcc_lo                   // 000000243B84: 020200FF 00003000
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000243B8C: D5207C01 01AA0280
	s_clause 0x1                                               // 000000243B94: BF850001
	global_load_u16 v25, v[43:44], off offset:2080             // 000000243B98: DC4A0820 197C002B
	global_load_u16 v0, v[0:1], off offset:3104                // 000000243BA0: DC4A0C20 007C0000
	v_bfe_u32 v1, v2, 16, 1                                    // 000000243BA8: D6100001 02052102
	v_bfe_u32 v33, v10, 16, 1                                  // 000000243BB0: D6100021 0205210A
	v_bfe_u32 v34, v18, 16, 1                                  // 000000243BB8: D6100022 02052112
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000243BC0: BF870193
	v_add3_u32 v1, v2, v1, 0x7fff                              // 000000243BC4: D6550001 03FE0302 00007FFF
	v_add3_u32 v2, v10, v33, 0x7fff                            // 000000243BD0: D6550002 03FE430A 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000243BDC: BF8701A3
	v_add3_u32 v10, v18, v34, 0x7fff                           // 000000243BE0: D655000A 03FE4512 00007FFF
	v_add3_u32 v18, v26, v40, 0x7fff                           // 000000243BEC: D6550012 03FE511A 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000243BF8: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243C00: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 000000243C04: 100404FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 000000243C0C: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243C10: BF870095
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_and_b32 v1, 0xffff0000, v1// 000000243C14: C92404F2 020002FF FFFF0000
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000243C20: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243C28: BF870112
	v_div_scale_f32 v33, null, v2, v2, 1.0                     // 000000243C2C: D6FC7C21 03CA0502
	v_exp_f32_e32 v1, v1                                       // 000000243C34: 7E024B01
	v_div_scale_f32 v48, s0, 1.0, v2, 1.0                      // 000000243C38: D6FC0030 03CA04F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000243C40: BF870312
	v_rcp_f32_e32 v44, v33                                     // 000000243C44: 7E585521
	v_add_f32_e32 v1, 1.0, v1                                  // 000000243C48: 060202F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243C4C: BF870115
	v_fma_f32 v50, -v33, v44, 1.0                              // 000000243C50: D6130032 23CA5921
	v_div_scale_f32 v26, null, v1, v1, 1.0                     // 000000243C58: D6FC7C1A 03CA0301
	v_div_scale_f32 v47, vcc_lo, 1.0, v1, 1.0                  // 000000243C60: D6FC6A2F 03CA02F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000243C68: BF870193
	v_fmac_f32_e32 v44, v50, v44                               // 000000243C6C: 56585932
	v_rcp_f32_e32 v43, v26                                     // 000000243C70: 7E56551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243C74: BF870095
	v_fma_f32 v49, -v26, v43, 1.0                              // 000000243C78: D6130031 23CA571A
	v_dual_fmac_f32 v43, v49, v43 :: v_dual_and_b32 v10, 0xffff0000, v10// 000000243C80: C8245731 2B0A14FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243C8C: BF870111
	v_mul_f32_e32 v10, 0xbfb8aa3b, v10                         // 000000243C90: 101414FF BFB8AA3B
	v_mul_f32_e32 v50, v47, v43                                // 000000243C98: 1064572F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243C9C: BF870092
	v_exp_f32_e32 v10, v10                                     // 000000243CA0: 7E144B0A
	v_fma_f32 v55, -v26, v50, v47                              // 000000243CA4: D6130037 24BE651A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000243CAC: BF870291
	v_fmac_f32_e32 v50, v55, v43                               // 000000243CB0: 56645737
	v_add_f32_e32 v10, 1.0, v10                                // 000000243CB4: 061414F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243CB8: BF870112
	v_fma_f32 v26, -v26, v50, v47                              // 000000243CBC: D613001A 24BE651A
	v_div_scale_f32 v34, null, v10, v10, 1.0                   // 000000243CC4: D6FC7C22 03CA150A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243CCC: BF870112
	v_div_fmas_f32 v26, v26, v43, v50                          // 000000243CD0: D637001A 04CA571A
	v_rcp_f32_e32 v45, v34                                     // 000000243CD8: 7E5A5522
	s_mov_b32 vcc_lo, s0                                       // 000000243CDC: BEEA0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000243CE0: BF870291
	v_div_fixup_f32 v1, v26, v1, 1.0                           // 000000243CE4: D6270001 03CA031A
	v_fma_f32 v51, -v34, v45, 1.0                              // 000000243CEC: D6130033 23CA5B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000243CF4: BF8700A1
	v_dual_fmac_f32 v45, v51, v45 :: v_dual_and_b32 v18, 0xffff0000, v18// 000000243CF8: C8245B33 2D1224FF FFFF0000
	v_mul_f32_e32 v51, v48, v44                                // 000000243D04: 10665930
	v_fma_f32 v56, -v33, v51, v48                              // 000000243D08: D6130038 24C26721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000243D10: BF8701B1
	v_fmac_f32_e32 v51, v56, v44                               // 000000243D14: 56665938
	v_div_scale_f32 v52, s1, 1.0, v10, 1.0                     // 000000243D18: D6FC0134 03CA14F2
	v_mul_f32_e32 v18, 0xbfb8aa3b, v18                         // 000000243D20: 102424FF BFB8AA3B
	v_fma_f32 v33, -v33, v51, v48                              // 000000243D28: D6130021 24C26721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243D30: BF870092
	v_exp_f32_e32 v18, v18                                     // 000000243D34: 7E244B12
	v_div_fmas_f32 v33, v33, v44, v51                          // 000000243D38: D6370021 04CE5921
	s_mov_b32 vcc_lo, s1                                       // 000000243D40: BEEA0001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000243D44: BF8702A1
	v_div_fixup_f32 v2, v33, v2, 1.0                           // 000000243D48: D6270002 03CA0521
	v_bfe_u32 v33, v1, 16, 1                                   // 000000243D50: D6100021 02052101
	v_add_f32_e32 v18, 1.0, v18                                // 000000243D58: 062424F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243D5C: BF870112
	v_add3_u32 v1, v1, v33, 0x7fff                             // 000000243D60: D6550001 03FE4301 00007FFF
	v_div_scale_f32 v40, null, v18, v18, 1.0                   // 000000243D6C: D6FC7C28 03CA2512
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243D74: BF870112
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000243D78: 360202FF FFFF0000
	v_rcp_f32_e32 v46, v40                                     // 000000243D80: 7E5C5528
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243D84: BF870095
	v_fma_f32 v53, -v40, v46, 1.0                              // 000000243D88: D6130035 23CA5D28
	v_dual_fmac_f32 v46, v53, v46 :: v_dual_mul_f32 v53, v52, v45// 000000243D90: C8065D35 2E345B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243D98: BF870091
	v_fma_f32 v57, -v34, v53, v52                              // 000000243D9C: D6130039 24D26B22
	v_fmac_f32_e32 v53, v57, v45                               // 000000243DA4: 566A5B39
	v_div_scale_f32 v49, s8, 1.0, v18, 1.0                     // 000000243DA8: D6FC0831 03CA24F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243DB0: BF870092
	v_fma_f32 v34, -v34, v53, v52                              // 000000243DB4: D6130022 24D26B22
	v_div_fmas_f32 v26, v34, v45, v53                          // 000000243DBC: D637001A 04D65B22
	s_mov_b32 vcc_lo, s8                                       // 000000243DC4: BEEA0008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000243DC8: BF870121
	v_div_fixup_f32 v10, v26, v10, 1.0                         // 000000243DCC: D627000A 03CA151A
	v_bfe_u32 v26, v2, 16, 1                                   // 000000243DD4: D610001A 02052102
	v_bfe_u32 v33, v10, 16, 1                                  // 000000243DDC: D6100021 0205210A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243DE4: BF870112
	v_add3_u32 v2, v2, v26, 0x7fff                             // 000000243DE8: D6550002 03FE3502 00007FFF
	v_add3_u32 v10, v10, v33, 0x7fff                           // 000000243DF4: D655000A 03FE430A 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243E00: BF870112
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000243E04: 360404FF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v10                         // 000000243E0C: 361414FF FFFF0000
	s_waitcnt vmcnt(3)                                         // 000000243E14: BF890FF7
	v_dual_mul_f32 v54, v49, v46 :: v_dual_lshlrev_b32 v9, 16, v9// 000000243E18: C8E25D31 36081290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243E20: BF870111
	v_fma_f32 v9, v9, v1, 0                                    // 000000243E24: D6130009 02020309
	v_fma_f32 v58, -v40, v54, v49                              // 000000243E2C: D613003A 24C66D28
	s_waitcnt vmcnt(2)                                         // 000000243E34: BF890BF7
	v_lshlrev_b32_e32 v1, 16, v17                              // 000000243E38: 30022290
	s_waitcnt vmcnt(0)                                         // 000000243E3C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000243E40: BF8700A1
	v_dual_fmac_f32 v9, v1, v2 :: v_dual_lshlrev_b32 v0, 16, v0// 000000243E44: C8220501 09000090
	v_fmac_f32_e32 v54, v58, v46                               // 000000243E4C: 566C5D3A
	v_fma_f32 v40, -v40, v54, v49                              // 000000243E50: D6130028 24C66D28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000243E58: BF870121
	v_div_fmas_f32 v34, v40, v46, v54                          // 000000243E5C: D6370022 04DA5D28
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 000000243E64: 7C9A9281
	v_div_fixup_f32 v18, v34, v18, 1.0                         // 000000243E68: D6270012 03CA2522
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000243E70: 8B6A6A7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243E74: BF870091
	v_bfe_u32 v26, v18, 16, 1                                  // 000000243E78: D610001A 02052112
	v_add3_u32 v17, v18, v26, 0x7fff                           // 000000243E80: D6550011 03FE3512 00007FFF
	v_lshlrev_b32_e32 v18, 16, v25                             // 000000243E8C: 30243290
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243E90: BF870112
	v_and_b32_e32 v1, 0xffff0000, v17                          // 000000243E94: 360222FF FFFF0000
	v_fmac_f32_e32 v9, v18, v10                                // 000000243E9C: 56121512
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000243EA0: BF870121
	v_fmac_f32_e32 v9, v0, v1                                  // 000000243EA4: 56120300
	v_mad_i64_i32 v[0:1], null, 0xa00, v41, v[67:68]           // 000000243EA8: D6FF7C00 050E52FF 00000A00
	v_mul_f32_e32 v2, 0x3e800000, v9                           // 000000243EB4: 100412FF 3E800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243EBC: BF870112
	.long 0xd73c0011                                           // 000000243EC0: D73C0011
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000243EC4: 02020081
	v_bfe_u32 v9, v2, 16, 1                                    // 000000243EC8: D6100009 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243ED0: BF870112
	.long 0xd7000011                                           // 000000243ED4: D7000011
	v_cndmask_b32_e32 v1, s14, v17, vcc_lo                     // 000000243ED8: 0202220E
	v_add3_u32 v9, v2, v9, 0x7fff                              // 000000243EDC: D6550009 03FE1302 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000243EE8: BF870004
	v_add_co_ci_u32_e64 v18, null, s15, v18, s0                // 000000243EEC: D5207C12 0002240F
	global_store_d16_hi_b16 v[17:18], v9, off offset:32        // 000000243EF4: DC960020 007C0911
	s_cbranch_vccnz 9                                          // 000000243EFC: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x3324>
	.long 0xd73c0000                                           // 000000243F00: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000243F04: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243F08: BF870091
	.long 0xd7006a00                                           // 000000243F0C: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000243F10: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000243F14: D5207C01 01AA0211
	global_store_b32 v[0:1], v2, off offset:64                 // 000000243F1C: DC6A0040 007C0200
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 000000243F24: 916A0B7E
	s_cbranch_vccnz 29                                         // 000000243F28: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x33a0>
	v_and_b32_e32 v10, 0xffff0000, v9                          // 000000243F2C: 361412FF FFFF0000
	v_mad_i64_i32 v[0:1], null, 0x2800, v41, s[18:19]          // 000000243F34: D6FF7C00 004A52FF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000243F40: BF870112
	v_sub_f32_e32 v2, v2, v10                                  // 000000243F44: 08041502
	.long 0xd7006a00                                           // 000000243F48: D7006A00
	v_cndmask_b32_e32 v1, v0, v65, vcc_lo                      // 000000243F4C: 02028300
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000243F50: BF870212
	v_bfe_u32 v10, v2, 16, 1                                   // 000000243F54: D610000A 02052102
	v_add_co_ci_u32_e64 v1, null, v1, v66, vcc_lo              // 000000243F5C: D5207C01 01AA8501
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000243F64: BF870193
	.long 0xd7006a11                                           // 000000243F68: D7006A11
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000243F6C: 020200FF 00001000
	v_add3_u32 v2, v2, v10, 0x7fff                             // 000000243F74: D6550002 03FE1502 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000243F80: BF870003
	v_add_co_ci_u32_e64 v18, null, 0, v1, vcc_lo               // 000000243F84: D5207C12 01AA0280
	s_clause 0x1                                               // 000000243F8C: BF850001
	global_store_d16_hi_b16 v[0:1], v9, off offset:32          // 000000243F90: DC960020 007C0900
	global_store_d16_hi_b16 v[17:18], v2, off offset:1056      // 000000243F98: DC960420 007C0211
	s_or_b32 exec_lo, exec_lo, s9                              // 000000243FA0: 8C7E097E
	s_and_saveexec_b32 s8, s2                                  // 000000243FA4: BE882002
	s_cbranch_execz 286                                        // 000000243FA8: BFA5011E <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x3824>
	v_mad_i64_i32 v[0:1], null, 0x5000, v42, v[69:70]          // 000000243FAC: D6FF7C00 051654FF 00005000
	v_bfe_u32 v25, v27, 16, 1                                  // 000000243FB8: D6100019 0205211B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000243FC0: BF870092
	.long 0xd7006a09                                           // 000000243FC4: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000243FC8: 020200FF 00001000
	v_add_co_ci_u32_e64 v10, null, 0, v1, vcc_lo               // 000000243FD0: D5207C0A 01AA0280
	.long 0xd7006a11                                           // 000000243FD8: D7006A11
	v_cndmask_b32_e32 v1, 0x2000, v0, vcc_lo                   // 000000243FDC: 020200FF 00002000
	s_clause 0x1                                               // 000000243FE4: BF850001
	global_load_u16 v2, v[0:1], off offset:32                  // 000000243FE8: DC4A0020 027C0000
	global_load_u16 v9, v[9:10], off offset:1056               // 000000243FF0: DC4A0420 097C0009
	v_add_co_ci_u32_e64 v18, null, 0, v1, vcc_lo               // 000000243FF8: D5207C12 01AA0280
	.long 0xd7006a00                                           // 000000244000: D7006A00
	v_cndmask_b32_e32 v1, 0x3000, v0, vcc_lo                   // 000000244004: 020200FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000024400C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000244010: D5207C01 01AA0280
	s_clause 0x1                                               // 000000244018: BF850001
	global_load_u16 v10, v[17:18], off offset:2080             // 00000024401C: DC4A0820 0A7C0011
	global_load_u16 v0, v[0:1], off offset:3104                // 000000244024: DC4A0C20 007C0000
	v_bfe_u32 v1, v3, 16, 1                                    // 00000024402C: D6100001 02052103
	v_bfe_u32 v17, v11, 16, 1                                  // 000000244034: D6100011 0205210B
	v_bfe_u32 v18, v19, 16, 1                                  // 00000024403C: D6100012 02052113
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000244044: BF870193
	v_add3_u32 v1, v3, v1, 0x7fff                              // 000000244048: D6550001 03FE0303 00007FFF
	v_add3_u32 v3, v11, v17, 0x7fff                            // 000000244054: D6550003 03FE230B 00007FFF
	v_add3_u32 v17, v27, v25, 0x7fff                           // 000000244060: D6550011 03FE331B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024406C: BF870114
	v_add3_u32 v11, v19, v18, 0x7fff                           // 000000244070: D655000B 03FE2513 00007FFF
	v_and_b32_e32 v17, 0xffff0000, v17                         // 00000024407C: 362222FF FFFF0000
	s_waitcnt vmcnt(3)                                         // 000000244084: BF890FF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000244088: BF870131
	v_dual_mul_f32 v17, 0xbfb8aa3b, v17 :: v_dual_lshlrev_b32 v2, 16, v2// 00000024408C: C8E222FF 11020490 BFB8AA3B
	s_waitcnt vmcnt(1)                                         // 000000244098: BF8907F7
	v_lshlrev_b32_e32 v10, 16, v10                             // 00000024409C: 30141490
	v_exp_f32_e32 v17, v17                                     // 0000002440A0: 7E224B11
	s_waitcnt vmcnt(0)                                         // 0000002440A4: BF8903F7
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002440A8: BF870095
	v_dual_add_f32 v17, 1.0, v17 :: v_dual_lshlrev_b32 v0, 16, v0// 0000002440AC: C92222F2 11000090
	v_div_scale_f32 v26, null, v17, v17, 1.0                   // 0000002440B4: D6FC7C1A 03CA2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002440BC: BF870291
	v_rcp_f32_e32 v40, v26                                     // 0000002440C0: 7E50551A
	v_fma_f32 v48, -v26, v40, 1.0                              // 0000002440C4: D6130030 23CA511A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002440CC: BF870091
	v_dual_fmac_f32 v40, v48, v40 :: v_dual_and_b32 v3, 0xffff0000, v3// 0000002440D0: C8245130 280206FF FFFF0000
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 0000002440DC: 100606FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002440E4: BF870291
	v_exp_f32_e32 v3, v3                                       // 0000002440E8: 7E064B03
	v_add_f32_e32 v3, 1.0, v3                                  // 0000002440EC: 060606F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002440F0: BF870121
	v_div_scale_f32 v19, null, v3, v3, 1.0                     // 0000002440F4: D6FC7C13 03CA0703
	v_div_scale_f32 v43, s0, 1.0, v3, 1.0                      // 0000002440FC: D6FC002B 03CA06F2
	v_rcp_f32_e32 v33, v19                                     // 000000244104: 7E425513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244108: BF870095
	v_fma_f32 v45, -v19, v33, 1.0                              // 00000024410C: D613002D 23CA4313
	v_fmac_f32_e32 v33, v45, v33                               // 000000244114: 5642432D
	v_and_b32_e32 v11, 0xffff0000, v11                         // 000000244118: 361616FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244120: BF870091
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 000000244124: 101616FF BFB8AA3B
	v_exp_f32_e32 v11, v11                                     // 00000024412C: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244130: BF870095
	v_add_f32_e32 v11, 1.0, v11                                // 000000244134: 061616F2
	v_div_scale_f32 v25, null, v11, v11, 1.0                   // 000000244138: D6FC7C19 03CA170B
	v_div_scale_f32 v47, s1, 1.0, v11, 1.0                     // 000000244140: D6FC012F 03CA16F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000244148: BF870292
	v_rcp_f32_e32 v34, v25                                     // 00000024414C: 7E445519
	v_fma_f32 v46, -v25, v34, 1.0                              // 000000244150: D613002E 23CA4519
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000244158: BF870121
	v_dual_fmac_f32 v34, v46, v34 :: v_dual_and_b32 v1, 0xffff0000, v1// 00000024415C: C824452E 220002FF FFFF0000
	v_mul_f32_e32 v46, v43, v33                                // 000000244168: 105C432B
	v_mul_f32_e32 v48, v47, v34                                // 00000024416C: 1060452F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244170: BF870112
	v_fma_f32 v51, -v19, v46, v43                              // 000000244174: D6130033 24AE5D13
	v_fma_f32 v52, -v25, v48, v47                              // 00000024417C: D6130034 24BE6119
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000244184: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000024418C: BF870193
	v_fmac_f32_e32 v46, v51, v33                               // 000000244190: 565C4333
	v_fmac_f32_e32 v48, v52, v34                               // 000000244194: 56604534
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244198: BF870113
	v_exp_f32_e32 v1, v1                                       // 00000024419C: 7E024B01
	v_fma_f32 v19, -v19, v46, v43                              // 0000002441A0: D6130013 24AE5D13
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002441A8: BF870292
	v_fma_f32 v25, -v25, v48, v47                              // 0000002441AC: D6130019 24BE6119
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002441B4: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002441B8: BF870121
	v_div_scale_f32 v18, null, v1, v1, 1.0                     // 0000002441BC: D6FC7C12 03CA0301
	v_div_scale_f32 v41, vcc_lo, 1.0, v1, 1.0                  // 0000002441C4: D6FC6A29 03CA02F2
	v_rcp_f32_e32 v27, v18                                     // 0000002441CC: 7E365512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002441D0: BF870095
	v_fma_f32 v44, -v18, v27, 1.0                              // 0000002441D4: D613002C 23CA3712
	v_fmac_f32_e32 v27, v44, v27                               // 0000002441DC: 5636372C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002441E0: BF870091
	v_mul_f32_e32 v45, v41, v27                                // 0000002441E4: 105A3729
	v_fma_f32 v50, -v18, v45, v41                              // 0000002441E8: D6130032 24A65B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002441F0: BF870091
	v_fmac_f32_e32 v45, v50, v27                               // 0000002441F4: 565A3732
	v_fma_f32 v18, -v18, v45, v41                              // 0000002441F8: D6130012 24A65B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000244200: BF870141
	v_div_fmas_f32 v18, v18, v27, v45                          // 000000244204: D6370012 04B63712
	s_mov_b32 vcc_lo, s0                                       // 00000024420C: BEEA0000
	v_div_fmas_f32 v19, v19, v33, v46                          // 000000244210: D6370013 04BA4313
	s_mov_b32 vcc_lo, s1                                       // 000000244218: BEEA0001
	v_div_fixup_f32 v1, v18, v1, 1.0                           // 00000024421C: D6270001 03CA0312
	v_div_fmas_f32 v18, v25, v34, v48                          // 000000244224: D6370012 04C24519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000024422C: BF870193
	v_div_fixup_f32 v3, v19, v3, 1.0                           // 000000244230: D6270003 03CA0713
	v_bfe_u32 v19, v1, 16, 1                                   // 000000244238: D6100013 02052101
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000244240: BF870193
	v_div_fixup_f32 v11, v18, v11, 1.0                         // 000000244244: D627000B 03CA1712
	v_bfe_u32 v18, v3, 16, 1                                   // 00000024424C: D6100012 02052103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000244254: BF870193
	v_add3_u32 v1, v1, v19, 0x7fff                             // 000000244258: D6550001 03FE2701 00007FFF
	v_bfe_u32 v19, v11, 16, 1                                  // 000000244264: D6100013 0205210B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000024426C: BF870193
	v_add3_u32 v3, v3, v18, 0x7fff                             // 000000244270: D6550003 03FE2503 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 00000024427C: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000244284: BF870193
	v_add3_u32 v11, v11, v19, 0x7fff                           // 000000244288: D655000B 03FE270B 00007FFF
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000244294: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000024429C: BF870223
	v_fma_f32 v2, v2, v1, 0                                    // 0000002442A0: D6130002 02020302
	v_lshlrev_b32_e32 v1, 16, v9                               // 0000002442A8: 30021290
	v_and_b32_e32 v11, 0xffff0000, v11                         // 0000002442AC: 361616FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002442B4: BF8700C2
	v_fmac_f32_e32 v2, v1, v3                                  // 0000002442B8: 56040701
	v_div_scale_f32 v44, s2, 1.0, v17, 1.0                     // 0000002442BC: D6FC022C 03CA22F2
	s_mov_b32 vcc_lo, s2                                       // 0000002442C4: BEEA0002
	v_dual_fmac_f32 v2, v10, v11 :: v_dual_mul_f32 v49, v44, v40// 0000002442C8: C806170A 0230512C
	v_fma_f32 v53, -v26, v49, v44                              // 0000002442D0: D6130035 24B2631A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002442D8: BF870091
	v_fmac_f32_e32 v49, v53, v40                               // 0000002442DC: 56625135
	v_fma_f32 v26, -v26, v49, v44                              // 0000002442E0: D613001A 24B2631A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002442E8: BF870121
	v_div_fmas_f32 v25, v26, v40, v49                          // 0000002442EC: D6370019 04C6511A
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 0000002442F4: 7C9A9281
	v_div_fixup_f32 v17, v25, v17, 1.0                         // 0000002442F8: D6270011 03CA2319
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000244300: 8B6A6A7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244304: BF870091
	v_bfe_u32 v18, v17, 16, 1                                  // 000000244308: D6100012 02052111
	v_add3_u32 v9, v17, v18, 0x7fff                            // 000000244310: D6550009 03FE2511 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000024431C: BF870091
	v_and_b32_e32 v1, 0xffff0000, v9                           // 000000244320: 360212FF FFFF0000
	v_fmac_f32_e32 v2, v0, v1                                  // 000000244328: 56040300
	v_mad_i64_i32 v[0:1], null, 0xa00, v42, v[67:68]           // 00000024432C: D6FF7C00 050E54FF 00000A00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244338: BF870112
	v_mul_f32_e32 v2, 0x3e800000, v2                           // 00000024433C: 100404FF 3E800000
	.long 0xd73c0009                                           // 000000244344: D73C0009
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000244348: 02020081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024434C: BF870112
	v_bfe_u32 v3, v2, 16, 1                                    // 000000244350: D6100003 02052102
	.long 0xd7000009                                           // 000000244358: D7000009
	v_cndmask_b32_e32 v1, s14, v9, vcc_lo                      // 00000024435C: 0202120E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000244360: BF870212
	v_add3_u32 v3, v2, v3, 0x7fff                              // 000000244364: D6550003 03FE0702 00007FFF
	v_add_co_ci_u32_e64 v10, null, s15, v10, s0                // 000000244370: D5207C0A 0002140F
	global_store_d16_hi_b16 v[9:10], v3, off offset:32         // 000000244378: DC960020 007C0309
	s_cbranch_vccnz 9                                          // 000000244380: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x37a8>
	.long 0xd73c0000                                           // 000000244384: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000244388: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000024438C: BF870091
	.long 0xd7006a00                                           // 000000244390: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000244394: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000244398: D5207C01 01AA0211
	global_store_b32 v[0:1], v2, off offset:64                 // 0000002443A0: DC6A0040 007C0200
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 0000002443A8: 916A0B7E
	s_cbranch_vccnz 29                                         // 0000002443AC: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x3824>
	v_and_b32_e32 v9, 0xffff0000, v3                           // 0000002443B0: 361206FF FFFF0000
	v_mad_i64_i32 v[0:1], null, 0x2800, v42, s[18:19]          // 0000002443B8: D6FF7C00 004A54FF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002443C4: BF870112
	v_sub_f32_e32 v2, v2, v9                                   // 0000002443C8: 08041302
	.long 0xd7006a00                                           // 0000002443CC: D7006A00
	v_cndmask_b32_e32 v1, v0, v65, vcc_lo                      // 0000002443D0: 02028300
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002443D4: BF870212
	v_bfe_u32 v9, v2, 16, 1                                    // 0000002443D8: D6100009 02052102
	v_add_co_ci_u32_e64 v1, null, v1, v66, vcc_lo              // 0000002443E0: D5207C01 01AA8501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002443E8: BF870212
	v_add3_u32 v2, v2, v9, 0x7fff                              // 0000002443EC: D6550002 03FE1302 00007FFF
	.long 0xd7006a09                                           // 0000002443F8: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000002443FC: 020200FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000244404: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v1, vcc_lo               // 000000244408: D5207C0A 01AA0280
	s_clause 0x1                                               // 000000244410: BF850001
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 000000244414: DC960020 007C0300
	global_store_d16_hi_b16 v[9:10], v2, off offset:1056       // 00000024441C: DC960420 007C0209
	s_or_b32 exec_lo, exec_lo, s8                              // 000000244424: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000244428: BE882003
	s_cbranch_execz 277                                        // 00000024442C: BFA50115 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x3c84>
	v_mad_i64_i32 v[0:1], null, 0x5000, v35, v[69:70]          // 000000244430: D6FF7C00 051646FF 00005000
	v_bfe_u32 v17, v28, 16, 1                                  // 00000024443C: D6100011 0205211C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244444: BF870092
	.long 0xd7006a02                                           // 000000244448: D7006A02
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000024444C: 020200FF 00001000
	v_add_co_ci_u32_e64 v3, null, 0, v1, vcc_lo                // 000000244454: D5207C03 01AA0280
	.long 0xd7006a09                                           // 00000024445C: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v0, vcc_lo                   // 000000244460: 020200FF 00002000
	s_clause 0x1                                               // 000000244468: BF850001
	global_load_u16 v11, v[0:1], off offset:32                 // 00000024446C: DC4A0020 0B7C0000
	global_load_u16 v2, v[2:3], off offset:1056                // 000000244474: DC4A0420 027C0002
	v_add_co_ci_u32_e64 v10, null, 0, v1, vcc_lo               // 00000024447C: D5207C0A 01AA0280
	.long 0xd7006a00                                           // 000000244484: D7006A00
	v_cndmask_b32_e32 v1, 0x3000, v0, vcc_lo                   // 000000244488: 020200FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000244490: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000244494: D5207C01 01AA0280
	s_clause 0x1                                               // 00000024449C: BF850001
	global_load_u16 v3, v[9:10], off offset:2080               // 0000002444A0: DC4A0820 037C0009
	global_load_u16 v0, v[0:1], off offset:3104                // 0000002444A8: DC4A0C20 007C0000
	v_bfe_u32 v1, v4, 16, 1                                    // 0000002444B0: D6100001 02052104
	v_bfe_u32 v9, v12, 16, 1                                   // 0000002444B8: D6100009 0205210C
	v_bfe_u32 v10, v20, 16, 1                                  // 0000002444C0: D610000A 02052114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002444C8: BF870193
	v_add3_u32 v1, v4, v1, 0x7fff                              // 0000002444CC: D6550001 03FE0304 00007FFF
	v_add3_u32 v4, v12, v9, 0x7fff                             // 0000002444D8: D6550004 03FE130C 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002444E4: BF8701A3
	v_add3_u32 v9, v20, v10, 0x7fff                            // 0000002444E8: D6550009 03FE1514 00007FFF
	v_add3_u32 v10, v28, v17, 0x7fff                           // 0000002444F4: D655000A 03FE231C 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000244500: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244508: BF870112
	v_and_b32_e32 v10, 0xffff0000, v10                         // 00000024450C: 361414FF FFFF0000
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 000000244514: 100808FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024451C: BF870112
	v_mul_f32_e32 v10, 0xbfb8aa3b, v10                         // 000000244520: 101414FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 000000244528: 7E084B04
	v_and_b32_e32 v1, 0xffff0000, v1                           // 00000024452C: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000244534: BF870312
	v_exp_f32_e32 v10, v10                                     // 000000244538: 7E144B0A
	v_dual_add_f32 v4, 1.0, v4 :: v_dual_and_b32 v9, 0xffff0000, v9// 00000024453C: C92408F2 040812FF FFFF0000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244548: BF870115
	v_dual_mul_f32 v1, 0xbfb8aa3b, v1 :: v_dual_add_f32 v10, 1.0, v10// 00000024454C: C8C802FF 010A14F2 BFB8AA3B
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 000000244558: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000244560: BF870193
	v_div_scale_f32 v17, null, v4, v4, 1.0                     // 000000244564: D6FC7C11 03CA0904
	v_exp_f32_e32 v1, v1                                       // 00000024456C: 7E024B01
	v_div_scale_f32 v33, s0, 1.0, v4, 1.0                      // 000000244570: D6FC0021 03CA08F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000244578: BF8700B3
	v_exp_f32_e32 v9, v9                                       // 00000024457C: 7E124B09
	v_div_scale_f32 v19, null, v10, v10, 1.0                   // 000000244580: D6FC7C13 03CA150A
	v_rcp_f32_e32 v25, v17                                     // 000000244588: 7E325511
	v_rcp_f32_e32 v27, v19                                     // 00000024458C: 7E365513
	v_add_f32_e32 v1, 1.0, v1                                  // 000000244590: 060202F2
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000244594: BF870317
	v_add_f32_e32 v9, 1.0, v9                                  // 000000244598: 061212F2
	v_fma_f32 v40, -v17, v25, 1.0                              // 00000024459C: D6130028 23CA3311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002445A4: BF870223
	v_div_scale_f32 v12, null, v1, v1, 1.0                     // 0000002445A8: D6FC7C0C 03CA0301
	v_div_scale_f32 v28, vcc_lo, 1.0, v1, 1.0                  // 0000002445B0: D6FC6A1C 03CA02F2
	v_div_scale_f32 v18, null, v9, v9, 1.0                     // 0000002445B8: D6FC7C12 03CA1309
	v_div_scale_f32 v42, s1, 1.0, v9, 1.0                      // 0000002445C0: D6FC012A 03CA12F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000002445C8: BF870145
	v_fma_f32 v43, -v19, v27, 1.0                              // 0000002445CC: D613002B 23CA3713
	v_rcp_f32_e32 v20, v12                                     // 0000002445D4: 7E28550C
	v_fmac_f32_e32 v25, v40, v25                               // 0000002445D8: 56323328
	v_rcp_f32_e32 v26, v18                                     // 0000002445DC: 7E345512
	v_fmac_f32_e32 v27, v43, v27                               // 0000002445E0: 5636372B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002445E4: BF870296
	v_fma_f32 v34, -v12, v20, 1.0                              // 0000002445E8: D6130022 23CA290C
	v_fma_f32 v41, -v18, v26, 1.0                              // 0000002445F0: D6130029 23CA3512
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002445F8: BF8701A2
	v_fmac_f32_e32 v20, v34, v20                               // 0000002445FC: 56282922
	v_div_scale_f32 v34, s2, 1.0, v10, 1.0                     // 000000244600: D6FC0222 03CA14F2
	v_fmac_f32_e32 v26, v41, v26                               // 000000244608: 56343529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000024460C: BF870093
	v_dual_mul_f32 v41, v33, v25 :: v_dual_mul_f32 v40, v28, v20// 000000244610: C8C63321 2928291C
	v_fma_f32 v46, -v17, v41, v33                              // 000000244618: D613002E 24865311
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244620: BF870092
	v_fma_f32 v45, -v12, v40, v28                              // 000000244624: D613002D 2472510C
	v_dual_mul_f32 v43, v42, v26 :: v_dual_fmac_f32 v40, v45, v20// 00000024462C: C8C0352A 2B28292D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000244634: BF8701A1
	v_fma_f32 v47, -v18, v43, v42                              // 000000244638: D613002F 24AA5712
	v_mul_f32_e32 v44, v34, v27                                // 000000244640: 10583722
	v_fma_f32 v12, -v12, v40, v28                              // 000000244644: D613000C 2472510C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000024464C: BF870193
	v_fmac_f32_e32 v43, v47, v26                               // 000000244650: 5656352F
	v_fma_f32 v48, -v19, v44, v34                              // 000000244654: D6130030 248A5913
	v_fmac_f32_e32 v41, v46, v25                               // 00000024465C: 5652332E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000244660: BF8701A4
	v_div_fmas_f32 v12, v12, v20, v40                          // 000000244664: D637000C 04A2290C
	s_mov_b32 vcc_lo, s0                                       // 00000024466C: BEEA0000
	v_fmac_f32_e32 v44, v48, v27                               // 000000244670: 56583730
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000244674: BF870233
	v_fma_f32 v17, -v17, v41, v33                              // 000000244678: D6130011 24865311
	v_fma_f32 v18, -v18, v43, v42                              // 000000244680: D6130012 24AA5712
	v_div_fixup_f32 v1, v12, v1, 1.0                           // 000000244688: D6270001 03CA030C
	v_fma_f32 v19, -v19, v44, v34                              // 000000244690: D6130013 248A5913
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000244698: BF870144
	v_div_fmas_f32 v17, v17, v25, v41                          // 00000024469C: D6370011 04A63311
	s_mov_b32 vcc_lo, s1                                       // 0000002446A4: BEEA0001
	v_div_fmas_f32 v12, v18, v26, v43                          // 0000002446A8: D637000C 04AE3512
	s_mov_b32 vcc_lo, s2                                       // 0000002446B0: BEEA0002
	v_div_fixup_f32 v4, v17, v4, 1.0                           // 0000002446B4: D6270004 03CA0911
	v_bfe_u32 v17, v1, 16, 1                                   // 0000002446BC: D6100011 02052101
	v_div_fmas_f32 v18, v19, v27, v44                          // 0000002446C4: D6370012 04B23713
	v_div_fixup_f32 v9, v12, v9, 1.0                           // 0000002446CC: D6270009 03CA130C
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 0000002446D4: 7C9A9281
	v_bfe_u32 v12, v4, 16, 1                                   // 0000002446D8: D610000C 02052104
	v_add3_u32 v1, v1, v17, 0x7fff                             // 0000002446E0: D6550001 03FE2301 00007FFF
	v_div_fixup_f32 v10, v18, v10, 1.0                         // 0000002446EC: D627000A 03CA1512
	v_bfe_u32 v17, v9, 16, 1                                   // 0000002446F4: D6100011 02052109
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000002446FC: 8B6A6A7E
	v_add3_u32 v4, v4, v12, 0x7fff                             // 000000244700: D6550004 03FE1904 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 00000024470C: 360202FF FFFF0000
	v_bfe_u32 v12, v10, 16, 1                                  // 000000244714: D610000C 0205210A
	v_add3_u32 v9, v9, v17, 0x7fff                             // 00000024471C: D6550009 03FE2309 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000244728: BF8700B1
	v_and_b32_e32 v9, 0xffff0000, v9                           // 00000024472C: 361212FF FFFF0000
	s_waitcnt vmcnt(3)                                         // 000000244734: BF890FF7
	v_lshlrev_b32_e32 v11, 16, v11                             // 000000244738: 30161690
	v_fma_f32 v11, v11, v1, 0                                  // 00000024473C: D613000B 0202030B
	s_waitcnt vmcnt(2)                                         // 000000244744: BF890BF7
	v_lshlrev_b32_e32 v1, 16, v2                               // 000000244748: 30020490
	v_add3_u32 v2, v10, v12, 0x7fff                            // 00000024474C: D6550002 03FE190A 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000244758: BF8907F7
	v_lshlrev_b32_e32 v3, 16, v3                               // 00000024475C: 30060690
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000244760: 360808FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 000000244768: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000024476C: 30000090
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000244770: BF870122
	v_fmac_f32_e32 v11, v1, v4                                 // 000000244774: 56160901
	v_and_b32_e32 v1, 0xffff0000, v2                           // 000000244778: 360204FF FFFF0000
	v_fmac_f32_e32 v11, v3, v9                                 // 000000244780: 56161303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000244784: BF870121
	v_fmac_f32_e32 v11, v0, v1                                 // 000000244788: 56160300
	v_mad_i64_i32 v[0:1], null, 0xa00, v35, v[67:68]           // 00000024478C: D6FF7C00 050E46FF 00000A00
	v_mul_f32_e32 v2, 0x3e800000, v11                          // 000000244798: 100416FF 3E800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002447A0: BF870112
	.long 0xd73c0009                                           // 0000002447A4: D73C0009
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000002447A8: 02020081
	v_bfe_u32 v3, v2, 16, 1                                    // 0000002447AC: D6100003 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002447B4: BF870112
	.long 0xd7000009                                           // 0000002447B8: D7000009
	v_cndmask_b32_e32 v1, s14, v9, vcc_lo                      // 0000002447BC: 0202120E
	v_add3_u32 v3, v2, v3, 0x7fff                              // 0000002447C0: D6550003 03FE0702 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002447CC: BF870004
	v_add_co_ci_u32_e64 v10, null, s15, v10, s0                // 0000002447D0: D5207C0A 0002140F
	global_store_d16_hi_b16 v[9:10], v3, off offset:32         // 0000002447D8: DC960020 007C0309
	s_cbranch_vccnz 9                                          // 0000002447E0: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x3c08>
	.long 0xd73c0000                                           // 0000002447E4: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000002447E8: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002447EC: BF870091
	.long 0xd7006a00                                           // 0000002447F0: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000002447F4: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000002447F8: D5207C01 01AA0211
	global_store_b32 v[0:1], v2, off offset:64                 // 000000244800: DC6A0040 007C0200
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 000000244808: 916A0B7E
	s_cbranch_vccnz 29                                         // 00000024480C: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x3c84>
	v_and_b32_e32 v4, 0xffff0000, v3                           // 000000244810: 360806FF FFFF0000
	v_mad_i64_i32 v[0:1], null, 0x2800, v35, s[18:19]          // 000000244818: D6FF7C00 004A46FF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244824: BF870112
	v_sub_f32_e32 v2, v2, v4                                   // 000000244828: 08040902
	.long 0xd7006a00                                           // 00000024482C: D7006A00
	v_cndmask_b32_e32 v1, v0, v65, vcc_lo                      // 000000244830: 02028300
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000244834: BF870212
	v_bfe_u32 v4, v2, 16, 1                                    // 000000244838: D6100004 02052102
	v_add_co_ci_u32_e64 v1, null, v1, v66, vcc_lo              // 000000244840: D5207C01 01AA8501
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000244848: BF870193
	.long 0xd7006a09                                           // 00000024484C: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000244850: 020200FF 00001000
	v_add3_u32 v2, v2, v4, 0x7fff                              // 000000244858: D6550002 03FE0902 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000244864: BF870003
	v_add_co_ci_u32_e64 v10, null, 0, v1, vcc_lo               // 000000244868: D5207C0A 01AA0280
	s_clause 0x1                                               // 000000244870: BF850001
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 000000244874: DC960020 007C0300
	global_store_d16_hi_b16 v[9:10], v2, off offset:1056       // 00000024487C: DC960420 007C0209
	s_or_b32 exec_lo, exec_lo, s8                              // 000000244884: 8C7E087E
	s_and_saveexec_b32 s3, s4                                  // 000000244888: BE832004
	s_cbranch_execz 275                                        // 00000024488C: BFA50113 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x40dc>
	v_mad_i64_i32 v[0:1], null, 0x5000, v36, v[69:70]          // 000000244890: D6FF7C00 051648FF 00005000
	v_bfe_u32 v11, v29, 16, 1                                  // 00000024489C: D610000B 0205211D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002448A4: BF870092
	.long 0xd7006a02                                           // 0000002448A8: D7006A02
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000002448AC: 020200FF 00001000
	v_add_co_ci_u32_e64 v3, null, 0, v1, vcc_lo                // 0000002448B4: D5207C03 01AA0280
	global_load_u16 v4, v[0:1], off offset:32                  // 0000002448BC: DC4A0020 047C0000
	.long 0xd7006a09                                           // 0000002448C4: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v0, vcc_lo                   // 0000002448C8: 020200FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002448D0: BF8700B1
	v_add_co_ci_u32_e64 v10, null, 0, v1, vcc_lo               // 0000002448D4: D5207C0A 01AA0280
	global_load_u16 v2, v[2:3], off offset:1056                // 0000002448DC: DC4A0420 027C0002
	.long 0xd7006a00                                           // 0000002448E4: D7006A00
	v_cndmask_b32_e32 v1, 0x3000, v0, vcc_lo                   // 0000002448E8: 020200FF 00003000
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000002448F0: D5207C01 01AA0280
	s_clause 0x1                                               // 0000002448F8: BF850001
	global_load_u16 v3, v[9:10], off offset:2080               // 0000002448FC: DC4A0820 037C0009
	global_load_u16 v0, v[0:1], off offset:3104                // 000000244904: DC4A0C20 007C0000
	v_bfe_u32 v1, v5, 16, 1                                    // 00000024490C: D6100001 02052105
	v_bfe_u32 v9, v13, 16, 1                                   // 000000244914: D6100009 0205210D
	v_bfe_u32 v10, v21, 16, 1                                  // 00000024491C: D610000A 02052115
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000244924: BF870193
	v_add3_u32 v1, v5, v1, 0x7fff                              // 000000244928: D6550001 03FE0305 00007FFF
	v_add3_u32 v5, v13, v9, 0x7fff                             // 000000244934: D6550005 03FE130D 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000244940: BF870123
	v_add3_u32 v9, v21, v10, 0x7fff                            // 000000244944: D6550009 03FE1515 00007FFF
	v_add3_u32 v10, v29, v11, 0x7fff                           // 000000244950: D655000A 03FE171D 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 00000024495C: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244964: BF870092
	v_and_b32_e32 v10, 0xffff0000, v10                         // 000000244968: 361414FF FFFF0000
	v_dual_mul_f32 v9, 0xbfb8aa3b, v9 :: v_dual_mul_f32 v10, 0xbfb8aa3b, v10// 000000244970: C8C612FF 090A14FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000024497C: BF870091
	v_exp_f32_e32 v9, v9                                       // 000000244980: 7E124B09
	v_exp_f32_e32 v10, v10                                     // 000000244984: 7E144B0A
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000244988: 360202FF FFFF0000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244990: BF870115
	v_dual_add_f32 v9, 1.0, v9 :: v_dual_add_f32 v10, 1.0, v10 // 000000244994: C90812F2 090A14F2
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 00000024499C: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002449A4: BF870192
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 0000002449A8: D6FC7C0D 03CA1309
	v_div_scale_f32 v17, null, v10, v10, 1.0                   // 0000002449B0: D6FC7C11 03CA150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002449B8: BF8701A3
	v_exp_f32_e32 v1, v1                                       // 0000002449BC: 7E024B01
	v_div_scale_f32 v33, s1, 1.0, v9, 1.0                      // 0000002449C0: D6FC0121 03CA12F2
	v_rcp_f32_e32 v20, v13                                     // 0000002449C8: 7E28550D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 0000002449CC: BF870392
	v_rcp_f32_e32 v21, v17                                     // 0000002449D0: 7E2A5511
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002449D4: 060202F2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002449D8: BF870296
	v_fma_f32 v29, -v13, v20, 1.0                              // 0000002449DC: D613001D 23CA290D
	v_fma_f32 v34, -v17, v21, 1.0                              // 0000002449E4: D6130022 23CA2B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002449EC: BF8701A3
	v_div_scale_f32 v11, null, v1, v1, 1.0                     // 0000002449F0: D6FC7C0B 03CA0301
	v_div_scale_f32 v25, vcc_lo, 1.0, v1, 1.0                  // 0000002449F8: D6FC6A19 03CA02F2
	v_dual_fmac_f32 v20, v29, v20 :: v_dual_fmac_f32 v21, v34, v21// 000000244A00: C800291D 14142B22
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244A08: BF870093
	v_rcp_f32_e32 v18, v11                                     // 000000244A0C: 7E24550B
	v_mul_f32_e32 v34, v33, v20                                // 000000244A10: 10442921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000244A14: BF870291
	v_fma_f32 v42, -v13, v34, v33                              // 000000244A18: D613002A 2486450D
	v_fma_f32 v27, -v11, v18, 1.0                              // 000000244A20: D613001B 23CA250B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244A28: BF870092
	v_dual_fmac_f32 v34, v42, v20 :: v_dual_and_b32 v5, 0xffff0000, v5// 000000244A2C: C824292A 22040AFF FFFF0000
	v_dual_fmac_f32 v18, v27, v18 :: v_dual_mul_f32 v5, 0xbfb8aa3b, v5// 000000244A38: C806251B 12040AFF BFB8AA3B
	v_div_scale_f32 v27, s2, 1.0, v10, 1.0                     // 000000244A44: D6FC021B 03CA14F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000244A4C: BF870193
	v_fma_f32 v13, -v13, v34, v33                              // 000000244A50: D613000D 2486450D
	v_exp_f32_e32 v5, v5                                       // 000000244A58: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244A5C: BF870095
	v_add_f32_e32 v5, 1.0, v5                                  // 000000244A60: 060A0AF2
	v_div_scale_f32 v12, null, v5, v5, 1.0                     // 000000244A64: D6FC7C0C 03CA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000244A6C: BF870291
	v_rcp_f32_e32 v19, v12                                     // 000000244A70: 7E26550C
	v_fma_f32 v28, -v12, v19, 1.0                              // 000000244A74: D613001C 23CA270C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244A7C: BF870091
	v_dual_fmac_f32 v19, v28, v19 :: v_dual_mul_f32 v28, v25, v18// 000000244A80: C806271C 131C2519
	v_fma_f32 v40, -v11, v28, v25                              // 000000244A88: D6130028 2466390B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000244A90: BF870121
	v_fmac_f32_e32 v28, v40, v18                               // 000000244A94: 56382528
	v_div_scale_f32 v26, s0, 1.0, v5, 1.0                      // 000000244A98: D6FC001A 03CA0AF2
	v_fma_f32 v11, -v11, v28, v25                              // 000000244AA0: D613000B 2466390B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000244AA8: BF8700A1
	v_div_fmas_f32 v11, v11, v18, v28                          // 000000244AAC: D637000B 0472250B
	s_mov_b32 vcc_lo, s0                                       // 000000244AB4: BEEA0000
	v_div_fixup_f32 v1, v11, v1, 1.0                           // 000000244AB8: D6270001 03CA030B
	s_waitcnt vmcnt(3)                                         // 000000244AC0: BF890FF7
	v_dual_mul_f32 v29, v26, v19 :: v_dual_lshlrev_b32 v4, 16, v4// 000000244AC4: C8E2271A 1D040890
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000244ACC: BF8701C1
	v_fma_f32 v41, -v12, v29, v26                              // 000000244AD0: D6130029 246A3B0C
	s_waitcnt vmcnt(0)                                         // 000000244AD8: BF8903F7
	v_dual_mul_f32 v35, v27, v21 :: v_dual_lshlrev_b32 v0, 16, v0// 000000244ADC: C8E22B1B 23000090
	v_lshlrev_b32_e32 v3, 16, v3                               // 000000244AE4: 30060690
	v_fmac_f32_e32 v29, v41, v19                               // 000000244AE8: 563A2729
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244AEC: BF870113
	v_fma_f32 v43, -v17, v35, v27                              // 000000244AF0: D613002B 246E4711
	v_fma_f32 v12, -v12, v29, v26                              // 000000244AF8: D613000C 246A3B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244B00: BF870112
	v_fmac_f32_e32 v35, v43, v21                               // 000000244B04: 56462B2B
	v_div_fmas_f32 v12, v12, v19, v29                          // 000000244B08: D637000C 0476270C
	s_mov_b32 vcc_lo, s1                                       // 000000244B10: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000244B14: BF8701A2
	v_fma_f32 v17, -v17, v35, v27                              // 000000244B18: D6130011 246E4711
	v_div_fmas_f32 v11, v13, v20, v34                          // 000000244B20: D637000B 048A290D
	v_div_fixup_f32 v5, v12, v5, 1.0                           // 000000244B28: D6270005 03CA0B0C
	v_bfe_u32 v12, v1, 16, 1                                   // 000000244B30: D610000C 02052101
	s_mov_b32 vcc_lo, s2                                       // 000000244B38: BEEA0002
	v_div_fmas_f32 v13, v17, v21, v35                          // 000000244B3C: D637000D 048E2B11
	v_div_fixup_f32 v9, v11, v9, 1.0                           // 000000244B44: D6270009 03CA130B
	v_bfe_u32 v11, v5, 16, 1                                   // 000000244B4C: D610000B 02052105
	v_add3_u32 v1, v1, v12, 0x7fff                             // 000000244B54: D6550001 03FE1901 00007FFF
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 000000244B60: 7C9A9281
	v_div_fixup_f32 v10, v13, v10, 1.0                         // 000000244B64: D627000A 03CA150D
	v_bfe_u32 v12, v9, 16, 1                                   // 000000244B6C: D610000C 02052109
	v_add3_u32 v5, v5, v11, 0x7fff                             // 000000244B74: D6550005 03FE1705 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000244B80: 360202FF FFFF0000
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000244B88: 8B6A6A7E
	v_bfe_u32 v11, v10, 16, 1                                  // 000000244B8C: D610000B 0205210A
	v_add3_u32 v9, v9, v12, 0x7fff                             // 000000244B94: D6550009 03FE1909 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000244BA0: 360A0AFF FFFF0000
	v_fma_f32 v4, v4, v1, 0                                    // 000000244BA8: D6130004 02020304
	v_lshlrev_b32_e32 v1, 16, v2                               // 000000244BB0: 30020490
	v_add3_u32 v2, v10, v11, 0x7fff                            // 000000244BB4: D6550002 03FE170A 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 000000244BC0: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244BC8: BF870092
	v_dual_fmac_f32 v4, v1, v5 :: v_dual_and_b32 v1, 0xffff0000, v2// 000000244BCC: C8240B01 040004FF FFFF0000
	v_fmac_f32_e32 v4, v3, v9                                  // 000000244BD8: 56081303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000244BDC: BF870121
	v_fmac_f32_e32 v4, v0, v1                                  // 000000244BE0: 56080300
	v_mad_i64_i32 v[0:1], null, 0xa00, v36, v[67:68]           // 000000244BE4: D6FF7C00 050E48FF 00000A00
	v_mul_f32_e32 v2, 0x3e800000, v4                           // 000000244BF0: 100408FF 3E800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244BF8: BF870112
	.long 0xd73c0004                                           // 000000244BFC: D73C0004
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000244C00: 02020081
	v_bfe_u32 v3, v2, 16, 1                                    // 000000244C04: D6100003 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244C0C: BF870112
	.long 0xd7000004                                           // 000000244C10: D7000004
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 000000244C14: 0202080E
	v_add3_u32 v3, v2, v3, 0x7fff                              // 000000244C18: D6550003 03FE0702 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000244C24: BF870004
	v_add_co_ci_u32_e64 v5, null, s15, v5, s0                  // 000000244C28: D5207C05 00020A0F
	global_store_d16_hi_b16 v[4:5], v3, off offset:32          // 000000244C30: DC960020 007C0304
	s_cbranch_vccnz 9                                          // 000000244C38: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x4060>
	.long 0xd73c0000                                           // 000000244C3C: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000244C40: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244C44: BF870091
	.long 0xd7006a00                                           // 000000244C48: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000244C4C: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000244C50: D5207C01 01AA0211
	global_store_b32 v[0:1], v2, off offset:64                 // 000000244C58: DC6A0040 007C0200
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 000000244C60: 916A0B7E
	s_cbranch_vccnz 29                                         // 000000244C64: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x40dc>
	v_and_b32_e32 v4, 0xffff0000, v3                           // 000000244C68: 360806FF FFFF0000
	v_mad_i64_i32 v[0:1], null, 0x2800, v36, s[18:19]          // 000000244C70: D6FF7C00 004A48FF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244C7C: BF870112
	v_sub_f32_e32 v2, v2, v4                                   // 000000244C80: 08040902
	.long 0xd7006a00                                           // 000000244C84: D7006A00
	v_cndmask_b32_e32 v1, v0, v65, vcc_lo                      // 000000244C88: 02028300
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000244C8C: BF870212
	v_bfe_u32 v4, v2, 16, 1                                    // 000000244C90: D6100004 02052102
	v_add_co_ci_u32_e64 v1, null, v1, v66, vcc_lo              // 000000244C98: D5207C01 01AA8501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000244CA0: BF870212
	v_add3_u32 v2, v2, v4, 0x7fff                              // 000000244CA4: D6550002 03FE0902 00007FFF
	.long 0xd7006a04                                           // 000000244CB0: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000244CB4: 020200FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000244CBC: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v1, vcc_lo                // 000000244CC0: D5207C05 01AA0280
	s_clause 0x1                                               // 000000244CC8: BF850001
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 000000244CCC: DC960020 007C0300
	global_store_d16_hi_b16 v[4:5], v2, off offset:1056        // 000000244CD4: DC960420 007C0204
	s_or_b32 exec_lo, exec_lo, s3                              // 000000244CDC: 8C7E037E
	s_and_saveexec_b32 s3, s5                                  // 000000244CE0: BE832005
	s_cbranch_execz 278                                        // 000000244CE4: BFA50116 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x4540>
	v_mad_i64_i32 v[0:1], null, 0x5000, v37, v[69:70]          // 000000244CE8: D6FF7C00 05164AFF 00005000
	v_bfe_u32 v10, v30, 16, 1                                  // 000000244CF4: D610000A 0205211E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244CFC: BF870092
	.long 0xd7006a02                                           // 000000244D00: D7006A02
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000244D04: 020200FF 00001000
	v_add_co_ci_u32_e64 v3, null, 0, v1, vcc_lo                // 000000244D0C: D5207C03 01AA0280
	.long 0xd7006a04                                           // 000000244D14: D7006A04
	v_cndmask_b32_e32 v1, 0x2000, v0, vcc_lo                   // 000000244D18: 020200FF 00002000
	s_clause 0x1                                               // 000000244D20: BF850001
	global_load_u16 v9, v[0:1], off offset:32                  // 000000244D24: DC4A0020 097C0000
	global_load_u16 v2, v[2:3], off offset:1056                // 000000244D2C: DC4A0420 027C0002
	v_add_co_ci_u32_e64 v5, null, 0, v1, vcc_lo                // 000000244D34: D5207C05 01AA0280
	.long 0xd7006a00                                           // 000000244D3C: D7006A00
	v_cndmask_b32_e32 v1, 0x3000, v0, vcc_lo                   // 000000244D40: 020200FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000244D48: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000244D4C: D5207C01 01AA0280
	s_clause 0x1                                               // 000000244D54: BF850001
	global_load_u16 v3, v[4:5], off offset:2080                // 000000244D58: DC4A0820 037C0004
	global_load_u16 v0, v[0:1], off offset:3104                // 000000244D60: DC4A0C20 007C0000
	v_bfe_u32 v4, v14, 16, 1                                   // 000000244D68: D6100004 0205210E
	v_bfe_u32 v1, v6, 16, 1                                    // 000000244D70: D6100001 02052106
	v_bfe_u32 v5, v22, 16, 1                                   // 000000244D78: D6100005 02052116
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000244D80: BF870193
	v_add3_u32 v4, v14, v4, 0x7fff                             // 000000244D84: D6550004 03FE090E 00007FFF
	v_add3_u32 v1, v6, v1, 0x7fff                              // 000000244D90: D6550001 03FE0306 00007FFF
	v_add3_u32 v6, v30, v10, 0x7fff                            // 000000244D9C: D6550006 03FE151E 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000244DA8: BF870214
	v_add3_u32 v5, v22, v5, 0x7fff                             // 000000244DAC: D6550005 03FE0B16 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000244DB8: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244DC0: BF870113
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000244DC4: 360C0CFF FFFF0000
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 000000244DCC: 100808FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244DD4: BF870112
	v_mul_f32_e32 v6, 0xbfb8aa3b, v6                           // 000000244DD8: 100C0CFF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 000000244DE0: 7E084B04
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000244DE4: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000244DEC: BF870312
	v_exp_f32_e32 v6, v6                                       // 000000244DF0: 7E0C4B06
	v_dual_add_f32 v4, 1.0, v4 :: v_dual_and_b32 v5, 0xffff0000, v5// 000000244DF4: C92408F2 04040AFF FFFF0000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244E00: BF870115
	v_dual_mul_f32 v1, 0xbfb8aa3b, v1 :: v_dual_add_f32 v6, 1.0, v6// 000000244E04: C8C802FF 01060CF2 BFB8AA3B
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 000000244E10: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000244E18: BF870193
	v_div_scale_f32 v11, null, v4, v4, 1.0                     // 000000244E1C: D6FC7C0B 03CA0904
	v_exp_f32_e32 v1, v1                                       // 000000244E24: 7E024B01
	v_div_scale_f32 v21, s0, 1.0, v4, 1.0                      // 000000244E28: D6FC0015 03CA08F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000244E30: BF8700B3
	v_exp_f32_e32 v5, v5                                       // 000000244E34: 7E0A4B05
	v_div_scale_f32 v13, null, v6, v6, 1.0                     // 000000244E38: D6FC7C0D 03CA0D06
	v_rcp_f32_e32 v17, v11                                     // 000000244E40: 7E22550B
	v_rcp_f32_e32 v19, v13                                     // 000000244E44: 7E26550D
	v_add_f32_e32 v1, 1.0, v1                                  // 000000244E48: 060202F2
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000244E4C: BF870317
	v_add_f32_e32 v5, 1.0, v5                                  // 000000244E50: 060A0AF2
	v_fma_f32 v25, -v11, v17, 1.0                              // 000000244E54: D6130019 23CA230B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000244E5C: BF870223
	v_div_scale_f32 v10, null, v1, v1, 1.0                     // 000000244E60: D6FC7C0A 03CA0301
	v_div_scale_f32 v20, vcc_lo, 1.0, v1, 1.0                  // 000000244E68: D6FC6A14 03CA02F2
	v_div_scale_f32 v12, null, v5, v5, 1.0                     // 000000244E70: D6FC7C0C 03CA0B05
	v_div_scale_f32 v27, s1, 1.0, v5, 1.0                      // 000000244E78: D6FC011B 03CA0AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000244E80: BF870145
	v_fma_f32 v28, -v13, v19, 1.0                              // 000000244E84: D613001C 23CA270D
	v_rcp_f32_e32 v14, v10                                     // 000000244E8C: 7E1C550A
	v_fmac_f32_e32 v17, v25, v17                               // 000000244E90: 56222319
	v_rcp_f32_e32 v18, v12                                     // 000000244E94: 7E24550C
	v_fmac_f32_e32 v19, v28, v19                               // 000000244E98: 5626271C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000244E9C: BF870296
	v_fma_f32 v22, -v10, v14, 1.0                              // 000000244EA0: D6130016 23CA1D0A
	v_fma_f32 v26, -v12, v18, 1.0                              // 000000244EA8: D613001A 23CA250C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000244EB0: BF8701A2
	v_fmac_f32_e32 v14, v22, v14                               // 000000244EB4: 561C1D16
	v_div_scale_f32 v22, s2, 1.0, v6, 1.0                      // 000000244EB8: D6FC0216 03CA0CF2
	v_fmac_f32_e32 v18, v26, v18                               // 000000244EC0: 5624251A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244EC4: BF870113
	v_dual_mul_f32 v26, v21, v17 :: v_dual_mul_f32 v25, v20, v14// 000000244EC8: C8C62315 1A181D14
	v_dual_mul_f32 v29, v22, v19 :: v_dual_mul_f32 v28, v27, v18// 000000244ED0: C8C62716 1D1C251B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000244ED8: BF870192
	v_fma_f32 v33, -v11, v26, v21                              // 000000244EDC: D6130021 2456350B
	v_fma_f32 v30, -v10, v25, v20                              // 000000244EE4: D613001E 2452330A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000244EEC: BF870213
	v_fma_f32 v35, -v13, v29, v22                              // 000000244EF0: D6130023 245A3B0D
	v_fma_f32 v34, -v12, v28, v27                              // 000000244EF8: D6130022 246E390C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000244F00: BF870113
	v_dual_fmac_f32 v26, v33, v17 :: v_dual_fmac_f32 v25, v30, v14// 000000244F04: C8002321 1A181D1E
	v_dual_fmac_f32 v29, v35, v19 :: v_dual_fmac_f32 v28, v34, v18// 000000244F0C: C8002723 1D1C2522
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000244F14: BF870192
	v_fma_f32 v11, -v11, v26, v21                              // 000000244F18: D613000B 2456350B
	v_fma_f32 v10, -v10, v25, v20                              // 000000244F20: D613000A 2452330A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000244F28: BF870213
	v_fma_f32 v13, -v13, v29, v22                              // 000000244F2C: D613000D 245A3B0D
	v_fma_f32 v12, -v12, v28, v27                              // 000000244F34: D613000C 246E390C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000244F3C: BF870143
	v_div_fmas_f32 v10, v10, v14, v25                          // 000000244F40: D637000A 04661D0A
	s_mov_b32 vcc_lo, s0                                       // 000000244F48: BEEA0000
	v_div_fmas_f32 v11, v11, v17, v26                          // 000000244F4C: D637000B 046A230B
	s_mov_b32 vcc_lo, s1                                       // 000000244F54: BEEA0001
	v_div_fixup_f32 v1, v10, v1, 1.0                           // 000000244F58: D6270001 03CA030A
	v_div_fmas_f32 v10, v12, v18, v28                          // 000000244F60: D637000A 0472250C
	s_mov_b32 vcc_lo, s2                                       // 000000244F68: BEEA0002
	v_div_fixup_f32 v4, v11, v4, 1.0                           // 000000244F6C: D6270004 03CA090B
	v_div_fmas_f32 v12, v13, v19, v29                          // 000000244F74: D637000C 0476270D
	v_bfe_u32 v11, v1, 16, 1                                   // 000000244F7C: D610000B 02052101
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 000000244F84: 7C9A9281
	v_div_fixup_f32 v5, v10, v5, 1.0                           // 000000244F88: D6270005 03CA0B0A
	v_bfe_u32 v10, v4, 16, 1                                   // 000000244F90: D610000A 02052104
	v_div_fixup_f32 v6, v12, v6, 1.0                           // 000000244F98: D6270006 03CA0D0C
	v_add3_u32 v1, v1, v11, 0x7fff                             // 000000244FA0: D6550001 03FE1701 00007FFF
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000244FAC: 8B6A6A7E
	v_bfe_u32 v11, v5, 16, 1                                   // 000000244FB0: D610000B 02052105
	v_add3_u32 v4, v4, v10, 0x7fff                             // 000000244FB8: D6550004 03FE1504 00007FFF
	v_bfe_u32 v10, v6, 16, 1                                   // 000000244FC4: D610000A 02052106
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000244FCC: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000244FD4: BF870094
	v_add3_u32 v5, v5, v11, 0x7fff                             // 000000244FD8: D6550005 03FE1705 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000244FE4: 360A0AFF FFFF0000
	s_waitcnt vmcnt(3)                                         // 000000244FEC: BF890FF7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000244FF0: 30121290
	s_delay_alu instid0(VALU_DEP_1)                            // 000000244FF4: BF870001
	v_fma_f32 v9, v9, v1, 0                                    // 000000244FF8: D6130009 02020309
	s_waitcnt vmcnt(2)                                         // 000000245000: BF890BF7
	v_lshlrev_b32_e32 v1, 16, v2                               // 000000245004: 30020490
	v_add3_u32 v2, v6, v10, 0x7fff                             // 000000245008: D6550002 03FE1506 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000245014: BF8907F7
	v_lshlrev_b32_e32 v3, 16, v3                               // 000000245018: 30060690
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000024501C: 360808FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 000000245024: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000245028: 30000090
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000024502C: BF870122
	v_fmac_f32_e32 v9, v1, v4                                  // 000000245030: 56120901
	v_and_b32_e32 v1, 0xffff0000, v2                           // 000000245034: 360204FF FFFF0000
	v_fmac_f32_e32 v9, v3, v5                                  // 00000024503C: 56120B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000245040: BF870121
	v_fmac_f32_e32 v9, v0, v1                                  // 000000245044: 56120300
	v_mad_i64_i32 v[0:1], null, 0xa00, v37, v[67:68]           // 000000245048: D6FF7C00 050E4AFF 00000A00
	v_mul_f32_e32 v2, 0x3e800000, v9                           // 000000245054: 100412FF 3E800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024505C: BF870112
	.long 0xd73c0004                                           // 000000245060: D73C0004
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000245064: 02020081
	v_bfe_u32 v3, v2, 16, 1                                    // 000000245068: D6100003 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000245070: BF870112
	.long 0xd7000004                                           // 000000245074: D7000004
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 000000245078: 0202080E
	v_add3_u32 v3, v2, v3, 0x7fff                              // 00000024507C: D6550003 03FE0702 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000245088: BF870004
	v_add_co_ci_u32_e64 v5, null, s15, v5, s0                  // 00000024508C: D5207C05 00020A0F
	global_store_d16_hi_b16 v[4:5], v3, off offset:32          // 000000245094: DC960020 007C0304
	s_cbranch_vccnz 9                                          // 00000024509C: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x44c4>
	.long 0xd73c0000                                           // 0000002450A0: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000002450A4: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002450A8: BF870091
	.long 0xd7006a00                                           // 0000002450AC: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000002450B0: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000002450B4: D5207C01 01AA0211
	global_store_b32 v[0:1], v2, off offset:64                 // 0000002450BC: DC6A0040 007C0200
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 0000002450C4: 916A0B7E
	s_cbranch_vccnz 29                                         // 0000002450C8: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x4540>
	v_and_b32_e32 v4, 0xffff0000, v3                           // 0000002450CC: 360806FF FFFF0000
	v_mad_i64_i32 v[0:1], null, 0x2800, v37, s[18:19]          // 0000002450D4: D6FF7C00 004A4AFF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002450E0: BF870112
	v_sub_f32_e32 v2, v2, v4                                   // 0000002450E4: 08040902
	.long 0xd7006a00                                           // 0000002450E8: D7006A00
	v_cndmask_b32_e32 v1, v0, v65, vcc_lo                      // 0000002450EC: 02028300
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002450F0: BF870212
	v_bfe_u32 v4, v2, 16, 1                                    // 0000002450F4: D6100004 02052102
	v_add_co_ci_u32_e64 v1, null, v1, v66, vcc_lo              // 0000002450FC: D5207C01 01AA8501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000245104: BF870212
	v_add3_u32 v2, v2, v4, 0x7fff                              // 000000245108: D6550002 03FE0902 00007FFF
	.long 0xd7006a04                                           // 000000245114: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000245118: 020200FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000245120: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v1, vcc_lo                // 000000245124: D5207C05 01AA0280
	s_clause 0x1                                               // 00000024512C: BF850001
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 000000245130: DC960020 007C0300
	global_store_d16_hi_b16 v[4:5], v2, off offset:1056        // 000000245138: DC960420 007C0204
	s_or_b32 exec_lo, exec_lo, s3                              // 000000245140: 8C7E037E
	s_and_saveexec_b32 s3, s6                                  // 000000245144: BE832006
	s_cbranch_execz 278                                        // 000000245148: BFA50116 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x49a4>
	v_mad_i64_i32 v[0:1], null, 0x5000, v38, v[69:70]          // 00000024514C: D6FF7C00 05164CFF 00005000
	v_bfe_u32 v9, v31, 16, 1                                   // 000000245158: D6100009 0205211F
	global_load_u16 v6, v[0:1], off offset:32                  // 000000245160: DC4A0020 067C0000
	.long 0xd7006a02                                           // 000000245168: D7006A02
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000024516C: 020200FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000245174: BF8700A1
	v_add_co_ci_u32_e64 v3, null, 0, v1, vcc_lo                // 000000245178: D5207C03 01AA0280
	.long 0xd7006a04                                           // 000000245180: D7006A04
	v_cndmask_b32_e32 v1, 0x2000, v0, vcc_lo                   // 000000245184: 020200FF 00002000
	v_add_co_ci_u32_e64 v5, null, 0, v1, vcc_lo                // 00000024518C: D5207C05 01AA0280
	global_load_u16 v2, v[2:3], off offset:1056                // 000000245194: DC4A0420 027C0002
	.long 0xd7006a00                                           // 00000024519C: D7006A00
	v_cndmask_b32_e32 v1, 0x3000, v0, vcc_lo                   // 0000002451A0: 020200FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002451A8: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000002451AC: D5207C01 01AA0280
	s_clause 0x1                                               // 0000002451B4: BF850001
	global_load_u16 v3, v[4:5], off offset:2080                // 0000002451B8: DC4A0820 037C0004
	global_load_u16 v0, v[0:1], off offset:3104                // 0000002451C0: DC4A0C20 007C0000
	v_bfe_u32 v4, v15, 16, 1                                   // 0000002451C8: D6100004 0205210F
	v_bfe_u32 v1, v7, 16, 1                                    // 0000002451D0: D6100001 02052107
	v_bfe_u32 v5, v23, 16, 1                                   // 0000002451D8: D6100005 02052117
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002451E0: BF870193
	v_add3_u32 v4, v15, v4, 0x7fff                             // 0000002451E4: D6550004 03FE090F 00007FFF
	v_add3_u32 v1, v7, v1, 0x7fff                              // 0000002451F0: D6550001 03FE0307 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002451FC: BF870223
	v_add3_u32 v5, v23, v5, 0x7fff                             // 000000245200: D6550005 03FE0B17 00007FFF
	v_add3_u32 v7, v31, v9, 0x7fff                             // 00000024520C: D6550007 03FE131F 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000245218: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000245220: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 000000245224: 100808FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 00000024522C: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000245230: BF870095
	v_dual_add_f32 v4, 1.0, v4 :: v_dual_and_b32 v1, 0xffff0000, v1// 000000245234: C92408F2 040002FF FFFF0000
	v_div_scale_f32 v10, null, v4, v4, 1.0                     // 000000245240: D6FC7C0A 03CA0904
	v_div_scale_f32 v19, s0, 1.0, v4, 1.0                      // 000000245248: D6FC0013 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000245250: BF870292
	v_rcp_f32_e32 v14, v10                                     // 000000245254: 7E1C550A
	v_fma_f32 v21, -v10, v14, 1.0                              // 000000245258: D6130015 23CA1D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000245260: BF870091
	v_dual_fmac_f32 v14, v21, v14 :: v_dual_and_b32 v5, 0xffff0000, v5// 000000245264: C8241D15 0E040AFF FFFF0000
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 000000245270: 100A0AFF BFB8AA3B
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000245278: 360E0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000245280: BF8702A2
	v_exp_f32_e32 v5, v5                                       // 000000245284: 7E0A4B05
	s_waitcnt vmcnt(3)                                         // 000000245288: BF890FF7
	v_dual_add_f32 v5, 1.0, v5 :: v_dual_lshlrev_b32 v6, 16, v6// 00000024528C: C9220AF2 05060C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000245294: BF870121
	v_div_scale_f32 v11, null, v5, v5, 1.0                     // 000000245298: D6FC7C0B 03CA0B05
	v_div_scale_f32 v23, s1, 1.0, v5, 1.0                      // 0000002452A0: D6FC0117 03CA0AF2
	v_rcp_f32_e32 v15, v11                                     // 0000002452A8: 7E1E550B
	s_waitcnt vmcnt(1)                                         // 0000002452AC: BF8907F7
	v_lshlrev_b32_e32 v3, 16, v3                               // 0000002452B0: 30060690
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002452B4: BF8700A5
	v_fma_f32 v22, -v11, v15, 1.0                              // 0000002452B8: D6130016 23CA1F0B
	s_waitcnt vmcnt(0)                                         // 0000002452C0: BF8903F7
	v_dual_fmac_f32 v15, v22, v15 :: v_dual_lshlrev_b32 v0, 16, v0// 0000002452C4: C8221F16 0F000090
	v_dual_mul_f32 v22, v19, v14 :: v_dual_mul_f32 v7, 0xbfb8aa3b, v7// 0000002452CC: C8C61D13 16060EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002452D8: BF8701A1
	v_fma_f32 v28, -v10, v22, v19                              // 0000002452DC: D613001C 244E2D0A
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002452E4: 100202FF BFB8AA3B
	v_exp_f32_e32 v7, v7                                       // 0000002452EC: 7E0E4B07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002452F0: BF870112
	v_fmac_f32_e32 v22, v28, v14                               // 0000002452F4: 562C1D1C
	v_exp_f32_e32 v1, v1                                       // 0000002452F8: 7E024B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000002452FC: BF870311
	v_fma_f32 v10, -v10, v22, v19                              // 000000245300: D613000A 244E2D0A
	v_add_f32_e32 v7, 1.0, v7                                  // 000000245308: 060E0EF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024530C: BF870115
	v_add_f32_e32 v1, 1.0, v1                                  // 000000245310: 060202F2
	v_div_scale_f32 v12, null, v7, v7, 1.0                     // 000000245314: D6FC7C0C 03CA0F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024531C: BF870112
	v_div_scale_f32 v9, null, v1, v1, 1.0                      // 000000245320: D6FC7C09 03CA0301
	v_rcp_f32_e32 v17, v12                                     // 000000245328: 7E22550C
	v_div_scale_f32 v18, vcc_lo, 1.0, v1, 1.0                  // 00000024532C: D6FC6A12 03CA02F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000245334: BF870312
	v_rcp_f32_e32 v13, v9                                      // 000000245338: 7E1A5509
	v_fma_f32 v25, -v12, v17, 1.0                              // 00000024533C: D6130019 23CA230C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000245344: BF870115
	v_fma_f32 v20, -v9, v13, 1.0                               // 000000245348: D6130014 23CA1B09
	v_fmac_f32_e32 v17, v25, v17                               // 000000245350: 56222319
	v_mul_f32_e32 v25, v23, v15                                // 000000245354: 10321F17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000245358: BF8701A3
	v_fmac_f32_e32 v13, v20, v13                               // 00000024535C: 561A1B14
	v_div_scale_f32 v20, s2, 1.0, v7, 1.0                      // 000000245360: D6FC0214 03CA0EF2
	v_fma_f32 v29, -v11, v25, v23                              // 000000245368: D613001D 245E330B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000245370: BF870113
	v_mul_f32_e32 v21, v18, v13                                // 000000245374: 102A1B12
	v_dual_mul_f32 v26, v20, v17 :: v_dual_fmac_f32 v25, v29, v15// 000000245378: C8C02314 1A181F1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000245380: BF870112
	v_fma_f32 v27, -v9, v21, v18                               // 000000245384: D613001B 244A2B09
	v_fma_f32 v30, -v12, v26, v20                              // 00000024538C: D613001E 2452350C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000245394: BF870193
	v_fma_f32 v11, -v11, v25, v23                              // 000000245398: D613000B 245E330B
	v_fmac_f32_e32 v21, v27, v13                               // 0000002453A0: 562A1B1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002453A4: BF870113
	v_fmac_f32_e32 v26, v30, v17                               // 0000002453A8: 5634231E
	v_fma_f32 v9, -v9, v21, v18                                // 0000002453AC: D6130009 244A2B09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002453B4: BF870112
	v_fma_f32 v12, -v12, v26, v20                              // 0000002453B8: D613000C 2452350C
	v_div_fmas_f32 v9, v9, v13, v21                            // 0000002453C0: D6370009 04561B09
	s_mov_b32 vcc_lo, s0                                       // 0000002453C8: BEEA0000
	v_div_fmas_f32 v10, v10, v14, v22                          // 0000002453CC: D637000A 045A1D0A
	s_mov_b32 vcc_lo, s1                                       // 0000002453D4: BEEA0001
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002453D8: BF870002
	v_div_fixup_f32 v1, v9, v1, 1.0                            // 0000002453DC: D6270001 03CA0309
	v_div_fmas_f32 v9, v11, v15, v25                           // 0000002453E4: D6370009 04661F0B
	s_mov_b32 vcc_lo, s2                                       // 0000002453EC: BEEA0002
	v_div_fixup_f32 v4, v10, v4, 1.0                           // 0000002453F0: D6270004 03CA090A
	v_div_fmas_f32 v11, v12, v17, v26                          // 0000002453F8: D637000B 046A230C
	v_bfe_u32 v10, v1, 16, 1                                   // 000000245400: D610000A 02052101
	v_div_fixup_f32 v5, v9, v5, 1.0                            // 000000245408: D6270005 03CA0B09
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 000000245410: 7C9A9281
	v_bfe_u32 v9, v4, 16, 1                                    // 000000245414: D6100009 02052104
	v_div_fixup_f32 v7, v11, v7, 1.0                           // 00000024541C: D6270007 03CA0F0B
	v_add3_u32 v1, v1, v10, 0x7fff                             // 000000245424: D6550001 03FE1501 00007FFF
	v_bfe_u32 v10, v5, 16, 1                                   // 000000245430: D610000A 02052105
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000245438: 8B6A6A7E
	v_add3_u32 v4, v4, v9, 0x7fff                              // 00000024543C: D6550004 03FE1304 00007FFF
	v_bfe_u32 v9, v7, 16, 1                                    // 000000245448: D6100009 02052107
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000245450: 360202FF FFFF0000
	v_add3_u32 v5, v5, v10, 0x7fff                             // 000000245458: D6550005 03FE1505 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000245464: BF870194
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000245468: 360808FF FFFF0000
	v_fma_f32 v6, v6, v1, 0                                    // 000000245470: D6130006 02020306
	v_lshlrev_b32_e32 v1, 16, v2                               // 000000245478: 30020490
	v_add3_u32 v2, v7, v9, 0x7fff                              // 00000024547C: D6550002 03FE1307 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000245488: BF870092
	v_dual_fmac_f32 v6, v1, v4 :: v_dual_and_b32 v5, 0xffff0000, v5// 00000024548C: C8240901 06040AFF FFFF0000
	v_dual_fmac_f32 v6, v3, v5 :: v_dual_and_b32 v1, 0xffff0000, v2// 000000245498: C8240B03 060004FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002454A4: BF870121
	v_fmac_f32_e32 v6, v0, v1                                  // 0000002454A8: 560C0300
	v_mad_i64_i32 v[0:1], null, 0xa00, v38, v[67:68]           // 0000002454AC: D6FF7C00 050E4CFF 00000A00
	v_mul_f32_e32 v2, 0x3e800000, v6                           // 0000002454B8: 10040CFF 3E800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002454C0: BF870112
	.long 0xd73c0004                                           // 0000002454C4: D73C0004
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000002454C8: 02020081
	v_bfe_u32 v3, v2, 16, 1                                    // 0000002454CC: D6100003 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002454D4: BF870112
	.long 0xd7000004                                           // 0000002454D8: D7000004
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 0000002454DC: 0202080E
	v_add3_u32 v3, v2, v3, 0x7fff                              // 0000002454E0: D6550003 03FE0702 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002454EC: BF870004
	v_add_co_ci_u32_e64 v5, null, s15, v5, s0                  // 0000002454F0: D5207C05 00020A0F
	global_store_d16_hi_b16 v[4:5], v3, off offset:32          // 0000002454F8: DC960020 007C0304
	s_cbranch_vccnz 9                                          // 000000245500: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x4928>
	.long 0xd73c0000                                           // 000000245504: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000245508: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000024550C: BF870091
	.long 0xd7006a00                                           // 000000245510: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000245514: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000245518: D5207C01 01AA0211
	global_store_b32 v[0:1], v2, off offset:64                 // 000000245520: DC6A0040 007C0200
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 000000245528: 916A0B7E
	s_cbranch_vccnz 29                                         // 00000024552C: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x49a4>
	v_and_b32_e32 v4, 0xffff0000, v3                           // 000000245530: 360806FF FFFF0000
	v_mad_i64_i32 v[0:1], null, 0x2800, v38, s[18:19]          // 000000245538: D6FF7C00 004A4CFF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000245544: BF870112
	v_sub_f32_e32 v2, v2, v4                                   // 000000245548: 08040902
	.long 0xd7006a00                                           // 00000024554C: D7006A00
	v_cndmask_b32_e32 v1, v0, v65, vcc_lo                      // 000000245550: 02028300
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000245554: BF870212
	v_bfe_u32 v4, v2, 16, 1                                    // 000000245558: D6100004 02052102
	v_add_co_ci_u32_e64 v1, null, v1, v66, vcc_lo              // 000000245560: D5207C01 01AA8501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000245568: BF870212
	v_add3_u32 v2, v2, v4, 0x7fff                              // 00000024556C: D6550002 03FE0902 00007FFF
	.long 0xd7006a04                                           // 000000245578: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000024557C: 020200FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000245584: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v1, vcc_lo                // 000000245588: D5207C05 01AA0280
	s_clause 0x1                                               // 000000245590: BF850001
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 000000245594: DC960020 007C0300
	global_store_d16_hi_b16 v[4:5], v2, off offset:1056        // 00000024559C: DC960420 007C0204
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002455A4: 8C7E037E
	s_and_saveexec_b32 s0, s7                                  // 0000002455A8: BE802007
	s_cbranch_execz 284                                        // 0000002455AC: BFA5011C <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x4e20>
	v_mad_i64_i32 v[0:1], null, 0x5000, v39, v[69:70]          // 0000002455B0: D6FF7C00 05164EFF 00005000
	v_bfe_u32 v7, v32, 16, 1                                   // 0000002455BC: D6100007 02052120
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002455C4: BF8700B1
	v_add3_u32 v7, v32, v7, 0x7fff                             // 0000002455C8: D6550007 03FE0F20 00007FFF
	global_load_u16 v6, v[0:1], off offset:32                  // 0000002455D4: DC4A0020 067C0000
	.long 0xd7006a02                                           // 0000002455DC: D7006A02
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000002455E0: 020200FF 00001000
	v_add_co_ci_u32_e64 v3, null, 0, v1, vcc_lo                // 0000002455E8: D5207C03 01AA0280
	.long 0xd7006a04                                           // 0000002455F0: D7006A04
	v_cndmask_b32_e32 v1, 0x2000, v0, vcc_lo                   // 0000002455F4: 020200FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002455FC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, 0, v1, vcc_lo                // 000000245600: D5207C05 01AA0280
	global_load_u16 v2, v[2:3], off offset:1056                // 000000245608: DC4A0420 027C0002
	.long 0xd7006a00                                           // 000000245610: D7006A00
	v_cndmask_b32_e32 v1, 0x3000, v0, vcc_lo                   // 000000245614: 020200FF 00003000
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000024561C: D5207C01 01AA0280
	s_clause 0x1                                               // 000000245624: BF850001
	global_load_u16 v3, v[4:5], off offset:2080                // 000000245628: DC4A0820 037C0004
	global_load_u16 v0, v[0:1], off offset:3104                // 000000245630: DC4A0C20 007C0000
	v_bfe_u32 v4, v16, 16, 1                                   // 000000245638: D6100004 02052110
	v_bfe_u32 v1, v8, 16, 1                                    // 000000245640: D6100001 02052108
	v_bfe_u32 v5, v24, 16, 1                                   // 000000245648: D6100005 02052118
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000245650: BF870193
	v_add3_u32 v4, v16, v4, 0x7fff                             // 000000245654: D6550004 03FE0910 00007FFF
	v_add3_u32 v1, v8, v1, 0x7fff                              // 000000245660: D6550001 03FE0308 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000024566C: BF870193
	v_add3_u32 v5, v24, v5, 0x7fff                             // 000000245670: D6550005 03FE0B18 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000024567C: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000245684: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 000000245688: 100808FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 000000245690: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000245694: BF870095
	v_dual_add_f32 v4, 1.0, v4 :: v_dual_and_b32 v1, 0xffff0000, v1// 000000245698: C92408F2 040002FF FFFF0000
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002456A4: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002456AC: BF870112
	v_div_scale_f32 v9, null, v4, v4, 1.0                      // 0000002456B0: D6FC7C09 03CA0904
	v_exp_f32_e32 v1, v1                                       // 0000002456B8: 7E024B01
	v_div_scale_f32 v17, s0, 1.0, v4, 1.0                      // 0000002456BC: D6FC0011 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000002456C4: BF870312
	v_rcp_f32_e32 v13, v9                                      // 0000002456C8: 7E1A5509
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002456CC: 060202F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002456D0: BF870115
	v_fma_f32 v19, -v9, v13, 1.0                               // 0000002456D4: D6130013 23CA1B09
	v_div_scale_f32 v8, null, v1, v1, 1.0                      // 0000002456DC: D6FC7C08 03CA0301
	v_div_scale_f32 v16, vcc_lo, 1.0, v1, 1.0                  // 0000002456E4: D6FC6A10 03CA02F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002456EC: BF870193
	v_fmac_f32_e32 v13, v19, v13                               // 0000002456F0: 561A1B13
	v_rcp_f32_e32 v12, v8                                      // 0000002456F4: 7E185508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002456F8: BF870095
	v_fma_f32 v18, -v8, v12, 1.0                               // 0000002456FC: D6130012 23CA1908
	v_dual_fmac_f32 v12, v18, v12 :: v_dual_and_b32 v5, 0xffff0000, v5// 000000245704: C8241912 0C040AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000245710: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 000000245714: 100A0AFF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 00000024571C: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000245720: BF870095
	v_add_f32_e32 v5, 1.0, v5                                  // 000000245724: 060A0AF2
	v_div_scale_f32 v10, null, v5, v5, 1.0                     // 000000245728: D6FC7C0A 03CA0B05
	v_div_scale_f32 v21, s1, 1.0, v5, 1.0                      // 000000245730: D6FC0115 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000245738: BF870292
	v_rcp_f32_e32 v14, v10                                     // 00000024573C: 7E1C550A
	v_fma_f32 v20, -v10, v14, 1.0                              // 000000245740: D6130014 23CA1D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000245748: BF8700A1
	v_dual_fmac_f32 v14, v20, v14 :: v_dual_and_b32 v7, 0xffff0000, v7// 00000024574C: C8241D14 0E060EFF FFFF0000
	s_waitcnt vmcnt(3)                                         // 000000245758: BF890FF7
	v_dual_mul_f32 v7, 0xbfb8aa3b, v7 :: v_dual_lshlrev_b32 v6, 16, v6// 00000024575C: C8E20EFF 07060C90 BFB8AA3B
	v_mul_f32_e32 v20, v17, v13                                // 000000245768: 10281B11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000024576C: BF870092
	v_exp_f32_e32 v7, v7                                       // 000000245770: 7E0E4B07
	v_fma_f32 v25, -v9, v20, v17                               // 000000245774: D6130019 24462909
	s_waitcnt vmcnt(1)                                         // 00000024577C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000245780: BF870291
	v_dual_fmac_f32 v20, v25, v13 :: v_dual_lshlrev_b32 v3, 16, v3// 000000245784: C8221B19 14020690
	v_add_f32_e32 v7, 1.0, v7                                  // 00000024578C: 060E0EF2
	v_mul_f32_e32 v19, v16, v12                                // 000000245790: 10261910
	s_delay_alu instid0(VALU_DEP_3)                            // 000000245794: BF870003
	v_fma_f32 v9, -v9, v20, v17                                // 000000245798: D6130009 24462909
	s_waitcnt vmcnt(0)                                         // 0000002457A0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000002457A4: 30000090
	v_div_scale_f32 v11, null, v7, v7, 1.0                     // 0000002457A8: D6FC7C0B 03CA0F07
	v_fma_f32 v24, -v8, v19, v16                               // 0000002457B0: D6130018 24422708
	v_div_scale_f32 v18, s2, 1.0, v7, 1.0                      // 0000002457B8: D6FC0212 03CA0EF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002457C0: BF870113
	v_rcp_f32_e32 v15, v11                                     // 0000002457C4: 7E1E550B
	v_fmac_f32_e32 v19, v24, v12                               // 0000002457C8: 56261918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002457CC: BF870291
	v_fma_f32 v8, -v8, v19, v16                                // 0000002457D0: D6130008 24422708
	v_fma_f32 v22, -v11, v15, 1.0                              // 0000002457D8: D6130016 23CA1F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002457E0: BF8701B2
	v_div_fmas_f32 v8, v8, v12, v19                            // 0000002457E4: D6370008 044E1908
	s_mov_b32 vcc_lo, s0                                       // 0000002457EC: BEEA0000
	v_div_fmas_f32 v9, v9, v13, v20                            // 0000002457F0: D6370009 04521B09
	v_dual_fmac_f32 v15, v22, v15 :: v_dual_mul_f32 v22, v21, v14// 0000002457F8: C8061F16 0F161D15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000245800: BF8701A3
	v_div_fixup_f32 v1, v8, v1, 1.0                            // 000000245804: D6270001 03CA0308
	s_mov_b32 vcc_lo, s1                                       // 00000024580C: BEEA0001
	v_div_fixup_f32 v4, v9, v4, 1.0                            // 000000245810: D6270004 03CA0909
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000245818: BF870193
	v_fma_f32 v26, -v10, v22, v21                              // 00000024581C: D613001A 24562D0A
	v_bfe_u32 v9, v1, 16, 1                                    // 000000245824: D6100009 02052101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024582C: BF870112
	v_fmac_f32_e32 v22, v26, v14                               // 000000245830: 562C1D1A
	v_add3_u32 v1, v1, v9, 0x7fff                              // 000000245834: D6550001 03FE1301 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000245840: BF870112
	v_fma_f32 v10, -v10, v22, v21                              // 000000245844: D613000A 24562D0A
	v_and_b32_e32 v1, 0xffff0000, v1                           // 00000024584C: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000245854: BF870112
	v_div_fmas_f32 v8, v10, v14, v22                           // 000000245858: D6370008 045A1D0A
	v_fma_f32 v6, v6, v1, 0                                    // 000000245860: D6130006 02020306
	v_lshlrev_b32_e32 v1, 16, v2                               // 000000245868: 30020490
	s_mov_b32 vcc_lo, s2                                       // 00000024586C: BEEA0002
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000245870: BF870123
	v_div_fixup_f32 v5, v8, v5, 1.0                            // 000000245874: D6270005 03CA0B08
	v_bfe_u32 v8, v4, 16, 1                                    // 00000024587C: D6100008 02052104
	v_bfe_u32 v9, v5, 16, 1                                    // 000000245884: D6100009 02052105
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000024588C: BF870112
	v_add3_u32 v4, v4, v8, 0x7fff                              // 000000245890: D6550004 03FE1104 00007FFF
	v_add3_u32 v5, v5, v9, 0x7fff                              // 00000024589C: D6550005 03FE1305 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002458A8: BF870092
	v_dual_mul_f32 v23, v18, v15 :: v_dual_and_b32 v4, 0xffff0000, v4// 0000002458AC: C8E41F12 170408FF FFFF0000
	v_dual_fmac_f32 v6, v1, v4 :: v_dual_and_b32 v5, 0xffff0000, v5// 0000002458B8: C8240901 06040AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002458C4: BF870112
	v_fma_f32 v27, -v11, v23, v18                              // 0000002458C8: D613001B 244A2F0B
	v_fmac_f32_e32 v6, v3, v5                                  // 0000002458D0: 560C0B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002458D4: BF870092
	v_fmac_f32_e32 v23, v27, v15                               // 0000002458D8: 562E1F1B
	v_fma_f32 v11, -v11, v23, v18                              // 0000002458DC: D613000B 244A2F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002458E4: BF870121
	v_div_fmas_f32 v10, v11, v15, v23                          // 0000002458E8: D637000A 045E1F0B
	v_cmp_ne_u32_e32 vcc_lo, 1, v73                            // 0000002458F0: 7C9A9281
	v_div_fixup_f32 v7, v10, v7, 1.0                           // 0000002458F4: D6270007 03CA0F0A
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000002458FC: 8B6A6A7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000245900: BF870091
	v_bfe_u32 v8, v7, 16, 1                                    // 000000245904: D6100008 02052107
	v_add3_u32 v2, v7, v8, 0x7fff                              // 00000024590C: D6550002 03FE1107 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000245918: BF870091
	v_and_b32_e32 v1, 0xffff0000, v2                           // 00000024591C: 360204FF FFFF0000
	v_fmac_f32_e32 v6, v0, v1                                  // 000000245924: 560C0300
	v_mad_i64_i32 v[0:1], null, 0xa00, v39, v[67:68]           // 000000245928: D6FF7C00 050E4EFF 00000A00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000245934: BF870112
	v_mul_f32_e32 v2, 0x3e800000, v6                           // 000000245938: 10040CFF 3E800000
	.long 0xd73c0004                                           // 000000245940: D73C0004
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000245944: 02020081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000245948: BF870112
	v_bfe_u32 v3, v2, 16, 1                                    // 00000024594C: D6100003 02052102
	.long 0xd7000004                                           // 000000245954: D7000004
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 000000245958: 0202080E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000024595C: BF870212
	v_add3_u32 v3, v2, v3, 0x7fff                              // 000000245960: D6550003 03FE0702 00007FFF
	v_add_co_ci_u32_e64 v5, null, s15, v5, s0                  // 00000024596C: D5207C05 00020A0F
	global_store_d16_hi_b16 v[4:5], v3, off offset:32          // 000000245974: DC960020 007C0304
	s_cbranch_vccnz 9                                          // 00000024597C: BFA40009 <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x4da4>
	.long 0xd73c0000                                           // 000000245980: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000245984: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000245988: BF870091
	.long 0xd7006a00                                           // 00000024598C: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000245990: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000245994: D5207C01 01AA0211
	global_store_b32 v[0:1], v2, off offset:64                 // 00000024599C: DC6A0040 007C0200
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 0000002459A4: 916A0B7E
	s_cbranch_vccnz 29                                         // 0000002459A8: BFA4001D <_ZN7halogen12_GLOBAL__N_18k_hcup4wEPKtS2_S2_PtPfS3_i+0x4e20>
	v_and_b32_e32 v4, 0xffff0000, v3                           // 0000002459AC: 360806FF FFFF0000
	v_mad_i64_i32 v[0:1], null, 0x2800, v39, s[18:19]          // 0000002459B4: D6FF7C00 004A4EFF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002459C0: BF870112
	v_sub_f32_e32 v2, v2, v4                                   // 0000002459C4: 08040902
	.long 0xd7006a00                                           // 0000002459C8: D7006A00
	v_cndmask_b32_e32 v1, v0, v65, vcc_lo                      // 0000002459CC: 02028300
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002459D0: BF870212
	v_bfe_u32 v4, v2, 16, 1                                    // 0000002459D4: D6100004 02052102
	v_add_co_ci_u32_e64 v1, null, v1, v66, vcc_lo              // 0000002459DC: D5207C01 01AA8501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002459E4: BF870212
	v_add3_u32 v2, v2, v4, 0x7fff                              // 0000002459E8: D6550002 03FE0902 00007FFF
	.long 0xd7006a04                                           // 0000002459F4: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000002459F8: 020200FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000245A00: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v1, vcc_lo                // 000000245A04: D5207C05 01AA0280
	s_clause 0x1                                               // 000000245A0C: BF850001
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 000000245A10: DC960020 007C0300
	global_store_d16_hi_b16 v[4:5], v2, off offset:1056        // 000000245A18: DC960420 007C0204
	s_nop 0                                                    // 000000245A20: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000245A24: BFB60003
	s_endpgm                                                   // 000000245A28: BFB00000
		...

