0000000000753000 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000753000: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000753008: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000075300C: 32040082
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000753010: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000753014: BF8701A9
	v_dual_mov_b32 v24, s1 :: v_dual_and_b32 v1, 15, v0        // 000000753018: CA240001 1800008F
	v_and_b32_e32 v30, 31, v0                                  // 000000753020: 363C009F
	v_and_b32_e32 v2, 60, v2                                   // 000000753024: 360404BC
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000753028: 300E0082
	s_delay_alu instid0(VALU_DEP_4)                            // 00000075302C: BF870004
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000753030: 30020282
	.long 0x7f0c3880                                           // 000000753034: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 000000753038: BF89FC07
	s_clause 0x1                                               // 00000075303C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000753040: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000753048: DC520000 04040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000753050: 32020085
	s_add_u32 s22, s4, s16                                     // 000000753054: 80161004
	s_addc_u32 s23, s5, s17                                    // 000000753058: 82171105
	s_ashr_i32 s2, s11, 31                                     // 00000075305C: 86029F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000753060: BF8704A1
	v_or_b32_e32 v23, s0, v1                                   // 000000753064: 382E0200
	s_lshr_b32 s2, s2, 27                                      // 000000753068: 85029B02
	s_add_u32 s2, s10, s2                                      // 00000075306C: 8002020A
	s_addc_u32 s3, s11, 0                                      // 000000753070: 8203800B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000753074: BF8704A1
	.long 0xd4540000                                           // 000000753078: D4540000
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 00000075307C: 02022E0C
	s_lshr_b64 s[20:21], s[2:3], 5                             // 000000753080: 85948502
	s_cmpk_lt_i32 s20, 0x101                                   // 000000753084: B3940101
	.long 0xd4440002                                           // 000000753088: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000075308C: 02023C14
	v_cndmask_b32_e64 v2, 0, v23, s0                           // 000000753090: D5010002 00022E80
	v_cndmask_b32_e64 v5, 0, s1, s0                            // 000000753098: D5010005 00000280
	s_cselect_b32 s1, -1, 0                                    // 0000007530A0: 980180C1
	s_cmpk_gt_i32 s20, 0x100                                   // 0000007530A4: B2940100
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007530A8: BF870002
	.long 0xd72c0008                                           // 0000007530AC: D72C0008
	v_cndmask_b32_e32 v1, s19, v2, vcc_lo                      // 0000007530B0: 02020413
	v_mad_u64_u32 v[0:1], null, s18, v2, 0                     // 0000007530B4: D6FE7C00 02020412
	s_waitcnt vmcnt(1)                                         // 0000007530BC: BF8907F7
	v_bfe_u32 v9, v3, 16, 1                                    // 0000007530C0: D6100009 02052103
	s_waitcnt vmcnt(0)                                         // 0000007530C8: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 0000007530CC: D610000A 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007530D4: BF8701A2
	v_add3_u32 v3, v3, v9, 0x7fff                              // 0000007530D8: D6550003 03FE1303 00007FFF
	.long 0xd72c0009                                           // 0000007530E4: D72C0009
	v_cndmask_b32_e32 v1, s18, v5, vcc_lo                      // 0000007530E8: 02020A12
	v_add3_u32 v4, v4, v10, 0x7fff                             // 0000007530EC: D6550004 03FE1504 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 0000007530F8: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000007530FC: BF870239
	s_and_b32 vcc_lo, exec_lo, s18                             // 000000753100: 8B6A127E
	.long 0x7e0c3983                                           // 000000753104: 7E0C3983
	.long 0xd7000303                                           // 000000753108: D7000303
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 00000075310C: 02020016
	v_add3_u32 v1, v1, v9, v8                                  // 000000753110: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000753118: BF870113
	v_and_or_b32 v6, 0xffff0000, v4, v6                        // 00000075311C: D6570006 041A08FF FFFF0000
	v_add_co_ci_u32_e64 v4, null, s23, v1, s3                  // 000000753128: D5207C04 000E0217
	ds_store_b32 v7, v6                                        // 000000753130: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 000000753138: BF89FC07
	s_barrier                                                  // 00000075313C: BFBD0000
	buffer_gl0_inv                                             // 000000753140: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 000000753148: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x394>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 00000075314C: CA100080 08060080
	s_and_saveexec_b32 s3, s2                                  // 000000753154: BE832002
	s_cbranch_execz 10                                         // 000000753158: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x184>
	v_lshlrev_b32_e32 v6, 1, v30                               // 00000075315C: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753160: BF870091
	.long 0xd7006a06                                           // 000000753164: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000753168: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 00000075316C: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 000000753174: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000075317C: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 000000753180: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s3                              // 000000753184: 8C7E037E
	v_or_b32_e32 v6, 32, v30                                   // 000000753188: 380C3CA0
	s_mov_b32 s2, exec_lo                                      // 00000075318C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000753190: BF870001
	.long 0xd4c4007e                                           // 000000753194: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000753198: 02020C14
	s_cbranch_execz 10                                         // 00000075319C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1c8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007531A0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007531A4: BF870091
	.long 0xd7006a08                                           // 0000007531A8: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007531AC: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 0000007531B0: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 0000007531B8: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 0000007531C0: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 0000007531C4: 7E101706
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007531C8: 8C7E027E
	v_or_b32_e32 v6, 64, v30                                   // 0000007531CC: 380C3CC0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 0000007531D0: CA100080 0A080080
	s_mov_b32 s2, exec_lo                                      // 0000007531D8: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007531DC: BF870002
	.long 0xd4c4007e                                           // 0000007531E0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 0000007531E4: 02020C14
	s_cbranch_execz 10                                         // 0000007531E8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x214>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007531EC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007531F0: BF870091
	.long 0xd7006a0b                                           // 0000007531F4: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007531F8: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 0000007531FC: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 000000753204: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000075320C: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 000000753210: 7E121706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000753214: 8C7E027E
	v_or_b32_e32 v6, 0x60, v30                                 // 000000753218: 380C3CFF 00000060
	s_mov_b32 s2, exec_lo                                      // 000000753220: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000753224: BF870001
	.long 0xd4c4007e                                           // 000000753228: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000075322C: 02020C14
	s_cbranch_execz 10                                         // 000000753230: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x25c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000753234: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753238: BF870091
	.long 0xd7006a0a                                           // 00000075323C: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000753240: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 000000753244: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 00000075324C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 000000753254: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 000000753258: 7E141706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000075325C: 8C7E027E
	v_or_b32_e32 v6, 0x80, v30                                 // 000000753260: 380C3CFF 00000080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 000000753268: CA100080 0C0A0080
	s_mov_b32 s2, exec_lo                                      // 000000753270: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000753274: BF870002
	.long 0xd4c4007e                                           // 000000753278: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000075327C: 02020C14
	s_cbranch_execz 10                                         // 000000753280: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2ac>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000753284: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753288: BF870091
	.long 0xd7006a0d                                           // 00000075328C: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000753290: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 000000753294: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 00000075329C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 0000007532A4: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 0000007532A8: 7E161706
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007532AC: 8C7E027E
	v_or_b32_e32 v6, 0xa0, v30                                 // 0000007532B0: 380C3CFF 000000A0
	s_mov_b32 s2, exec_lo                                      // 0000007532B8: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007532BC: BF870001
	.long 0xd4c4007e                                           // 0000007532C0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 0000007532C4: 02020C14
	s_cbranch_execz 10                                         // 0000007532C8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2f4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007532CC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007532D0: BF870091
	.long 0xd7006a0c                                           // 0000007532D4: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007532D8: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 0000007532DC: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 0000007532E4: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 0000007532EC: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 0000007532F0: 7E181706
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007532F4: 8C7E027E
	v_or_b32_e32 v6, 0xc0, v30                                 // 0000007532F8: 380C3CFF 000000C0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 000000753300: CA100080 0E0C0080
	s_mov_b32 s2, exec_lo                                      // 000000753308: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000075330C: BF870002
	.long 0xd4c4007e                                           // 000000753310: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000753314: 02020C14
	s_cbranch_execz 10                                         // 000000753318: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x344>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000075331C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753320: BF870091
	.long 0xd7006a0f                                           // 000000753324: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000753328: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000075332C: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 000000753334: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 00000075333C: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 000000753340: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000753344: 8C7E027E
	v_or_b32_e32 v6, 0xe0, v30                                 // 000000753348: 380C3CFF 000000E0
	s_mov_b32 s2, exec_lo                                      // 000000753350: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000753354: BF870001
	.long 0xd4c4007e                                           // 000000753358: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000075335C: 02020C14
	s_cbranch_execz 10                                         // 000000753360: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000753364: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753368: BF870091
	.long 0xd7006a0e                                           // 00000075336C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000753370: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 000000753374: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 00000075337C: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 000000753384: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 000000753388: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000075338C: 8C7E027E
	s_branch 9                                                 // 000000753390: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_mov_b32_e32 v7, 0                                        // 000000753394: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000753398: BF870001
	v_mov_b32_e32 v8, v7                                       // 00000075339C: 7E100307
	v_mov_b32_e32 v9, v7                                       // 0000007533A0: 7E120307
	v_mov_b32_e32 v10, v7                                      // 0000007533A4: 7E140307
	v_mov_b32_e32 v11, v7                                      // 0000007533A8: 7E160307
	v_mov_b32_e32 v12, v7                                      // 0000007533AC: 7E180307
	v_mov_b32_e32 v13, v7                                      // 0000007533B0: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 0000007533B4: 7E1C0307
	s_add_u32 s2, s4, s14                                      // 0000007533B8: 80020E04
	s_addc_u32 s3, s5, s15                                     // 0000007533BC: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 0000007533C0: 850E9F0B
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000007533C4: CA100080 13140080
	s_add_u32 s14, s10, s14                                    // 0000007533CC: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 0000007533D0: 820F800B
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v22, 0             // 0000007533D4: CA100080 21160080
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000007533DC: 868E810E
	v_cndmask_b32_e64 v31, 0, 1, s18                           // 0000007533E0: D501001F 00490280
	v_mad_u64_u32 v[25:26], null, v2, s14, s[2:3]              // 0000007533E8: D6FE7C19 00081D02
	.long 0xd72c0002                                           // 0000007533F0: D72C0002
	v_cndmask_b32_e32 v0, v2, v15, vcc_lo                      // 0000007533F4: 02001F02
	.long 0xd72c0005                                           // 0000007533F8: D72C0005
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 0000007533FC: 02001D05
	.long 0xd4440002                                           // 000000753400: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 000000753404: 02023C14
	v_mov_b32_e32 v41, 0                                       // 000000753408: 7E520280
	v_mov_b32_e32 v21, 0                                       // 00000075340C: 7E2A0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000753410: BF870004
	v_add3_u32 v32, v5, v26, v2                                // 000000753414: D6550020 040A3505
	s_and_saveexec_b32 s3, s2                                  // 00000075341C: BE832002
	s_cbranch_execz 21                                         // 000000753420: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v2, 4, v30     // 000000753424: CA220080 29023C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075342C: BF870091
	.long 0xd7006a05                                           // 000000753430: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 000000753434: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v32, vcc_lo               // 000000753438: D5207C06 01AA4080
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 000000753440: 916A127E
	global_load_b128 v[19:22], v[5:6], off                     // 000000753444: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 00000075344C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 1, v30                               // 000000753450: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753454: BF870091
	.long 0xd7006a02                                           // 000000753458: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000075345C: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 000000753460: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 000000753468: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000753470: BF8903F7
	v_cvt_f32_f16_e32 v41, v2                                  // 000000753474: 7E521702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000753478: 8C7E037E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 00000075347C: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 000000753484: CA100080 24240080
	s_and_saveexec_b32 s3, s2                                  // 00000075348C: BE832002
	s_cbranch_execz 507                                        // 000000753490: BFA501FB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xc80>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 000000753494: CA220080 1B023C81
	.long 0xd7006a00                                           // 00000075349C: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000007534A0: 02020010
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007534A4: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000007534A8: D5207C01 01AA0211
	v_dual_mov_b32 v39, v30 :: v_dual_lshlrev_b32 v26, 5, v30  // 0000007534B0: CA22011E 271A3C85
	.long 0xd7006a00                                           // 0000007534B8: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 0000007534BC: 02020500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007534C0: BF8701A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000007534C4: D5207C01 01AA0280
	v_lshl_or_b32 v38, v30, 4, 0x200                           // 0000007534CC: D6560026 03FD091E 00000200
	.long 0xd7006a00                                           // 0000007534D8: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000007534DC: 02020004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007534E0: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000007534E4: D5207C01 01AA0205
	v_dual_mov_b32 v37, v27 :: v_dual_mov_b32 v40, v41         // 0000007534EC: CA10011B 25280129
	.long 0xd7006a1c                                           // 0000007534F4: D7006A1C
	v_cndmask_b32_e32 v0, v0, v192, vcc_lo                     // 0000007534F8: 02018100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007534FC: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 000000753500: D5207C1D 01AA0280
	v_mov_b32_e32 v36, v27                                     // 000000753508: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 00000075350C: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 000000753510: 7E44031B
	v_mov_b32_e32 v33, v27                                     // 000000753514: 7E42031B
	s_mul_i32 s2, s11, 6                                       // 000000753518: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 00000075351C: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000753520: 848E820A
	s_add_i32 s18, s18, s2                                     // 000000753524: 81120212
	s_mul_i32 s17, s10, 6                                      // 000000753528: 9611860A
	s_mov_b32 s16, 0                                           // 00000075352C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000753530: 8484810A
	s_branch 437                                               // 000000753534: BFA001B5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xc0c>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000753538: 8C7E0A7E
	v_cndmask_b32_e64 v51, v41, v7, s1                         // 00000075353C: D5010033 00060F29
	v_cndmask_b32_e64 v1, v8, v9, s1                           // 000000753544: D5010001 00061308
	v_cndmask_b32_e64 v0, v7, v8, s1                           // 00000075354C: D5010000 00061107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 000000753554: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s1                         // 000000753560: D5010006 00061D0D
	v_cndmask_b32_e64 v5, v12, v13, s1                         // 000000753568: D5010005 00061B0C
	v_cndmask_b32_e64 v4, v11, v12, s1                         // 000000753570: D5010004 0006190B
	v_cndmask_b32_e64 v3, v10, v11, s1                         // 000000753578: D5010003 0006170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000753580: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s1                          // 000000753584: D5010002 00061509
	s_and_b32 s2, exec_lo, s2                                  // 00000075358C: 8B02027E
	v_add_nc_u32_e32 v38, 0x200, v38                           // 000000753590: 4A4C4CFF 00000200
	s_or_b32 s16, s2, s16                                      // 000000753598: 8C101002
	ds_load_b32 v14, v8                                        // 00000075359C: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 0000007535A4: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007535A8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007535AC: 361010FF 000003FC
	ds_load_b32 v52, v8                                        // 0000007535B4: D8D80000 34000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 0000007535BC: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007535C0: 361010FF 000003FC
	ds_load_b32 v53, v8                                        // 0000007535C8: D8D80000 35000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 0000007535D0: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007535D4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007535D8: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 0000007535E0: D8D80000 36000008
	v_and_b32_e32 v8, 0xff, v20                                // 0000007535E8: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007535F0: 30101082
	ds_load_b32 v55, v8                                        // 0000007535F4: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 0000007535FC: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000753600: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000753604: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 00000075360C: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 000000753614: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000753618: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 000000753620: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 000000753628: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075362C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000753630: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 000000753638: D8D80000 3A000008
	v_and_b32_e32 v8, 0xff, v21                                // 000000753640: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000753648: 30101082
	ds_load_b32 v59, v8                                        // 00000075364C: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 000000753654: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000753658: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000075365C: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 000000753664: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 00000075366C: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000753670: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 000000753678: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 000000753680: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000753684: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000753688: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 000000753690: D8D80000 3E000008
	v_and_b32_e32 v8, 0xff, v22                                // 000000753698: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007536A0: 30101082
	ds_load_b32 v63, v8                                        // 0000007536A4: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 0000007536AC: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007536B0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007536B4: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 0000007536BC: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 0000007536C4: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007536C8: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 0000007536D0: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 0000007536D8: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007536DC: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007536E0: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 0000007536E8: D8D80000 42000008
	.long 0xd73c0008                                           // 0000007536F0: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000007536F4: 02023481
	v_add_nc_u32_e32 v26, 0x400, v26                           // 0000007536F8: 4A3434FF 00000400
	.long 0xd7006a0c                                           // 000000753700: D7006A0C
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 000000753704: 02021006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000753708: BF870001
	v_add_co_ci_u32_e64 v13, null, s7, v9, vcc_lo              // 00000075370C: D5207C0D 01AA1207
	s_clause 0x3                                               // 000000753714: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000753718: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000753720: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 000000753728: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 000000753730: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000753738: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000075373C: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 000000753744: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000753748: BF8700A1
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000075374C: CC1A4008 1C226909
	s_waitcnt lgkmcnt(13)                                      // 000000753754: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000753758: CC1A4008 1C226B0A
	s_waitcnt lgkmcnt(12)                                      // 000000753760: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000753764: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 000000753768: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000753770: BF8908B7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000753774: CC1A4008 1C226F13
	s_waitcnt lgkmcnt(10)                                      // 00000075377C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000753780: BF8700A1
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000753784: CC1A4008 1C227114
	s_waitcnt lgkmcnt(9)                                       // 00000075378C: BF89FC97
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 000000753790: CC1A4008 1C227315
	s_waitcnt lgkmcnt(8)                                       // 000000753798: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075379C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000007537A0: CC1A4008 1C227516
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000007537A8: BF890477
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000007537AC: CC1A4008 1C227729
	s_waitcnt lgkmcnt(6)                                       // 0000007537B4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007537B8: BF8700A1
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000007537BC: CC1A4008 1C22792A
	s_waitcnt lgkmcnt(5)                                       // 0000007537C4: BF89FC57
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007537C8: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(4)                                       // 0000007537D0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007537D4: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007537D8: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007537E0: BF890037
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007537E4: CC1A4008 1C227F2D
	.long 0xd7006a2d                                           // 0000007537EC: D7006A2D
	v_cndmask_b32_e32 v0, v12, v4, vcc_lo                      // 0000007537F0: 0200090C
	s_waitcnt lgkmcnt(2)                                       // 0000007537F4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007537F8: BF8701C2
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000007537FC: CC1A4008 1C22812E
	v_add_co_ci_u32_e64 v46, null, s5, v13, vcc_lo             // 000000753804: D5207C2E 01AA1A05
	.long 0xd7006a31                                           // 00000075380C: D7006A31
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 000000753810: 02001D0C
	s_waitcnt lgkmcnt(1)                                       // 000000753814: BF89FC17
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000753818: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v50, null, s15, v13, vcc_lo            // 000000753820: D5207C32 01AA1A0F
	.long 0xd7006a0c                                           // 000000753828: D7006A0C
	v_cndmask_b32_e32 v0, v12, v17, vcc_lo                     // 00000075382C: 0200230C
	s_waitcnt lgkmcnt(0)                                       // 000000753830: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000753834: BF870123
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000753838: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v13, null, s18, v13, vcc_lo            // 000000753840: D5207C0D 01AA1A12
	v_fmac_f32_e32 v37, v51, v8                                // 000000753848: 564A1133
	s_clause 0x3                                               // 00000075384C: BF850003
	global_load_b128 v[8:11], v[45:46], off                    // 000000753850: DC5E0000 087C002D
	global_load_b128 v[19:22], v[45:46], off offset:16         // 000000753858: DC5E0010 137C002D
	global_load_b128 v[41:44], v[45:46], off offset:32         // 000000753860: DC5E0020 297C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 000000753868: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 000000753870: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000753874: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075387C: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000753880: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000753888: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000753890: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 000000753894: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 00000075389C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 0000007538A0: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007538A8: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 0000007538AC: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 0000007538B4: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007538BC: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000007538C0: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 0000007538C8: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000007538CC: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007538D4: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000007538D8: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007538E0: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007538E8: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007538EC: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000007538F4: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007538F8: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753900: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000753904: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000075390C: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753914: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000753918: CC1A4008 1C228530
	v_fmac_f32_e32 v36, v51, v8                                // 000000753920: 56481133
	s_clause 0x3                                               // 000000753924: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 000000753928: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 000000753930: DC5E0010 137C0031
	global_load_b128 v[41:44], v[49:50], off offset:32         // 000000753938: DC5E0020 297C0031
	global_load_b128 v[45:48], v[49:50], off offset:48         // 000000753940: DC5E0030 2D7C0031
	s_waitcnt vmcnt(3)                                         // 000000753948: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000075394C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753954: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000753958: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000753960: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000753968: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000075396C: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 000000753974: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000753978: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753980: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000753984: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000075398C: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000753994: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 000000753998: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 0000007539A0: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000007539A4: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007539AC: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000007539B0: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007539B8: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007539C0: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007539C4: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000007539CC: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007539D0: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007539D8: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000007539DC: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000007539E4: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007539EC: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000007539F0: CC1A4008 1C228530
	v_fmac_f32_e32 v35, v51, v8                                // 0000007539F8: 56461133
	s_clause 0x3                                               // 0000007539FC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000753A00: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000753A08: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 000000753A10: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 000000753A18: DC5E0030 2D7C000C
	.long 0xd7006a0c                                           // 000000753A20: D7006A0C
	v_cndmask_b32_e32 v0, v49, v14, vcc_lo                     // 000000753A24: 02001D31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000753A28: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s15, v50, vcc_lo            // 000000753A2C: D5207C0D 01AA640F
	.long 0xd7006a1c                                           // 000000753A34: D7006A1C
	v_cndmask_b32_e32 v0, v28, v192, vcc_lo                    // 000000753A38: 0201811C
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 000000753A3C: D5207C1D 01AA3A80
	s_waitcnt vmcnt(3)                                         // 000000753A44: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000753A48: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753A50: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000753A54: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000753A5C: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000753A64: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 000000753A68: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 000000753A70: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000753A74: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753A7C: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000753A80: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 000000753A88: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000753A90: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 000000753A94: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 000000753A9C: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 000000753AA0: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753AA8: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000753AAC: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000753AB4: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000753ABC: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000753AC0: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 000000753AC8: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000753ACC: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753AD4: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000753AD8: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000753AE0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753AE8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000753AEC: CC1A4008 1C228530
	v_fmac_f32_e32 v34, v51, v8                                // 000000753AF4: 56441133
	s_clause 0x3                                               // 000000753AF8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000753AFC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000753B04: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 000000753B0C: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 000000753B14: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3)                                         // 000000753B1C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000753B20: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753B28: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000753B2C: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000753B34: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000753B3C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 000000753B40: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 000000753B48: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000753B4C: CC1A4008 1C226F13
	v_mov_b32_e32 v19, v15                                     // 000000753B54: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000753B58: BF870122
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000753B5C: CC1A4008 1C227114
	v_mov_b32_e32 v20, v16                                     // 000000753B64: 7E280310
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 000000753B68: CC1A4008 1C227315
	v_mov_b32_e32 v21, v17                                     // 000000753B70: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000753B74: BF870132
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 000000753B78: CC1A4008 1C227516
	v_mov_b32_e32 v22, v18                                     // 000000753B80: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 000000753B84: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 000000753B88: CC1A4008 1C227729
	v_mov_b32_e32 v41, v40                                     // 000000753B90: 7E520328
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753B94: BF870092
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000753B98: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000753BA0: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000753BA8: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000753BAC: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 000000753BB4: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000753BB8: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753BC0: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000753BC4: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000753BCC: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753BD4: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000753BD8: CC1A4008 1C228530
	v_fmac_f32_e32 v33, v51, v8                                // 000000753BE0: 56421133
	v_mov_b32_e32 v14, v7                                      // 000000753BE4: 7E1C0307
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 000000753BE8: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 000000753BF0: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 000000753BF8: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 000000753C00: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000753C04: 917E107E
	s_cbranch_execz 28                                         // 000000753C08: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xc7c>
	s_waitcnt vmcnt(0)                                         // 000000753C0C: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v39, 32, v39  // 000000753C10: CA200114 10264EA0
	v_dual_mov_b32 v15, v19 :: v_dual_mov_b32 v18, v22         // 000000753C18: CA100113 0F120116
	v_mov_b32_e32 v17, v21                                     // 000000753C20: 7E220315
	s_delay_alu instid0(VALU_DEP_3)                            // 000000753C24: BF870003
	.long 0xd4430002                                           // 000000753C28: D4430002
	v_cndmask_b32_e32 v1, s20, v39, vcc_lo                     // 000000753C2C: 02024E14
	s_mov_b32 s10, exec_lo                                     // 000000753C30: BE8A007E
	.long 0xd4c4007e                                           // 000000753C34: D4C4007E
	v_cndmask_b32_e32 v1, s20, v39, vcc_lo                     // 000000753C38: 02024E14
	s_cbranch_execz 65086                                      // 000000753C3C: BFA5FE3E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x538>
	.long 0xd7006a00                                           // 000000753C40: D7006A00
	v_cndmask_b32_e32 v1, v25, v38, vcc_lo                     // 000000753C44: 02024D19
	s_delay_alu instid0(VALU_DEP_1)                            // 000000753C48: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v32, vcc_lo               // 000000753C4C: D5207C01 01AA4080
	v_cmp_ne_u32_e32 vcc_lo, 1, v31                            // 000000753C54: 7C9A3E81
	v_mov_b32_e32 v40, v41                                     // 000000753C58: 7E500329
	global_load_b128 v[15:18], v[0:1], off                     // 000000753C5C: DC5E0000 0F7C0000
	s_cbranch_vccnz 65076                                      // 000000753C64: BFA4FE34 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x538>
	global_load_d16_b16 v0, v[28:29], off                      // 000000753C68: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 000000753C70: BF8903F7
	v_cvt_f32_f16_e32 v40, v0                                  // 000000753C74: 7E501700
	s_branch 65071                                             // 000000753C78: BFA0FE2F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x538>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000753C7C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000753C80: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000753C84: 8C7E037E
	.long 0xd71f0000                                           // 000000753C88: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000753C8C: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000753C90: 3A020090
	v_xor_b32_e32 v6, 8, v0                                    // 000000753C94: 3A0C0088
	v_xor_b32_e32 v11, 4, v0                                   // 000000753C98: 3A160084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000753C9C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000753CA0: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000753CA4: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000753CA8: 7C980CA0
	v_cndmask_b32_e32 v6, v0, v6, vcc_lo                       // 000000753CAC: 020C0D00
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 000000753CB0: 7C9816A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000753CB4: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 000000753CB8: 300C0C82
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000753CBC: 30020282
	ds_bpermute_b32 v2, v1, v37                                // 000000753CC0: DACC0000 02002501
	s_waitcnt lgkmcnt(0)                                       // 000000753CC8: BF89FC07
	v_add_f32_e32 v2, v37, v2                                  // 000000753CCC: 06040525
	ds_bpermute_b32 v3, v1, v36                                // 000000753CD0: DACC0000 03002401
	ds_bpermute_b32 v4, v1, v35                                // 000000753CD8: DACC0000 04002301
	ds_bpermute_b32 v5, v1, v34                                // 000000753CE0: DACC0000 05002201
	ds_bpermute_b32 v1, v1, v33                                // 000000753CE8: DACC0000 01002101
	ds_bpermute_b32 v7, v6, v2                                 // 000000753CF0: DACC0000 07000206
	s_waitcnt lgkmcnt(3)                                       // 000000753CF8: BF89FC37
	v_dual_add_f32 v3, v36, v3 :: v_dual_add_f32 v4, v35, v4   // 000000753CFC: C9080724 03040923
	s_waitcnt lgkmcnt(2)                                       // 000000753D04: BF89FC27
	v_add_f32_e32 v5, v34, v5                                  // 000000753D08: 060A0B22
	s_waitcnt lgkmcnt(0)                                       // 000000753D0C: BF89FC07
	v_dual_add_f32 v1, v33, v1 :: v_dual_add_f32 v2, v2, v7    // 000000753D10: C9080321 01020F02
	ds_bpermute_b32 v8, v6, v3                                 // 000000753D18: DACC0000 08000306
	ds_bpermute_b32 v9, v6, v4                                 // 000000753D20: DACC0000 09000406
	ds_bpermute_b32 v10, v6, v5                                // 000000753D28: DACC0000 0A000506
	ds_bpermute_b32 v6, v6, v1                                 // 000000753D30: DACC0000 06000106
	v_cndmask_b32_e32 v11, v0, v11, vcc_lo                     // 000000753D38: 02161700
	s_waitcnt lgkmcnt(2)                                       // 000000753D3C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000753D40: BF870001
	v_dual_add_f32 v4, v4, v9 :: v_dual_lshlrev_b32 v11, 2, v11// 000000753D44: C9221304 040A1682
	s_waitcnt lgkmcnt(1)                                       // 000000753D4C: BF89FC17
	v_add_f32_e32 v5, v5, v10                                  // 000000753D50: 060A1505
	s_waitcnt lgkmcnt(0)                                       // 000000753D54: BF89FC07
	v_add_f32_e32 v1, v1, v6                                   // 000000753D58: 06020D01
	ds_bpermute_b32 v6, v11, v2                                // 000000753D5C: DACC0000 0600020B
	ds_bpermute_b32 v10, v11, v1                               // 000000753D64: DACC0000 0A00010B
	v_add_f32_e32 v3, v3, v8                                   // 000000753D6C: 06061103
	ds_bpermute_b32 v8, v11, v4                                // 000000753D70: DACC0000 0800040B
	s_waitcnt lgkmcnt(2)                                       // 000000753D78: BF89FC27
	v_add_f32_e32 v2, v2, v6                                   // 000000753D7C: 06040D02
	s_waitcnt lgkmcnt(1)                                       // 000000753D80: BF89FC17
	v_add_f32_e32 v6, v1, v10                                  // 000000753D84: 060C1501
	ds_bpermute_b32 v7, v11, v3                                // 000000753D88: DACC0000 0700030B
	s_waitcnt lgkmcnt(1)                                       // 000000753D90: BF89FC17
	v_add_f32_e32 v4, v4, v8                                   // 000000753D94: 06081104
	ds_bpermute_b32 v9, v11, v5                                // 000000753D98: DACC0000 0900050B
	v_xor_b32_e32 v11, 2, v0                                   // 000000753DA0: 3A160082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000753DA4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 000000753DA8: 7C9816A0
	v_cndmask_b32_e32 v11, v0, v11, vcc_lo                     // 000000753DAC: 02161700
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000753DB0: 30161682
	s_waitcnt lgkmcnt(1)                                       // 000000753DB4: BF89FC17
	v_add_f32_e32 v3, v3, v7                                   // 000000753DB8: 06060F03
	s_waitcnt lgkmcnt(0)                                       // 000000753DBC: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 000000753DC0: 060A1305
	ds_bpermute_b32 v1, v11, v2                                // 000000753DC4: DACC0000 0100020B
	ds_bpermute_b32 v8, v11, v4                                // 000000753DCC: DACC0000 0800040B
	ds_bpermute_b32 v7, v11, v3                                // 000000753DD4: DACC0000 0700030B
	ds_bpermute_b32 v10, v11, v6                               // 000000753DDC: DACC0000 0A00060B
	ds_bpermute_b32 v9, v11, v5                                // 000000753DE4: DACC0000 0900050B
	v_xor_b32_e32 v11, 1, v0                                   // 000000753DEC: 3A160081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000753DF0: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 000000753DF4: 7C9816A0
	v_cndmask_b32_e32 v0, v0, v11, vcc_lo                      // 000000753DF8: 02001700
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 000000753DFC: 7C943C80
	s_waitcnt lgkmcnt(4)                                       // 000000753E00: BF89FC47
	v_dual_add_f32 v0, v2, v1 :: v_dual_lshlrev_b32 v11, 2, v0 // 000000753E04: C9220302 000A0082
	s_waitcnt lgkmcnt(2)                                       // 000000753E0C: BF89FC27
	v_dual_add_f32 v1, v3, v7 :: v_dual_add_f32 v2, v4, v8     // 000000753E10: C9080F03 01021104
	s_waitcnt lgkmcnt(0)                                       // 000000753E18: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 000000753E1C: 060A1305
	v_add_f32_e32 v7, v6, v10                                  // 000000753E20: 060E1506
	ds_bpermute_b32 v3, v11, v0                                // 000000753E24: DACC0000 0300000B
	ds_bpermute_b32 v4, v11, v1                                // 000000753E2C: DACC0000 0400010B
	ds_bpermute_b32 v6, v11, v2                                // 000000753E34: DACC0000 0600020B
	ds_bpermute_b32 v8, v11, v5                                // 000000753E3C: DACC0000 0800050B
	ds_bpermute_b32 v9, v11, v7                                // 000000753E44: DACC0000 0900070B
	s_and_b32 s0, vcc_lo, s0                                   // 000000753E4C: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000753E50: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000753E54: BE812000
	s_cbranch_execz 45                                         // 000000753E58: BFA5002D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xf10>
	.long 0xd73c000a                                           // 000000753E5C: D73C000A
	v_cndmask_b32_e32 v1, 2, v23, vcc_lo                       // 000000753E60: 02022E82
	s_waitcnt lgkmcnt(0)                                       // 000000753E64: BF89FC07
	v_dual_add_f32 v12, v7, v9 :: v_dual_add_f32 v13, v5, v8   // 000000753E68: C9081307 0C0C1105
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000753E70: 8480820C
	v_dual_add_f32 v15, v0, v3 :: v_dual_add_f32 v14, v1, v4   // 000000753E74: C9080700 0F0E0901
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753E7C: BF870093
	.long 0xd7006a07                                           // 000000753E80: D7006A07
	v_cndmask_b32_e32 v1, s8, v10, vcc_lo                      // 000000753E84: 02021408
	v_add_co_ci_u32_e64 v8, null, s9, v11, vcc_lo              // 000000753E88: D5207C08 01AA1609
	v_add_f32_e32 v11, v2, v6                                  // 000000753E90: 06160D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000753E94: BF870193
	.long 0xd7006a03                                           // 000000753E98: D7006A03
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 000000753E9C: 02000107
	v_mad_u64_u32 v[0:1], null, s12, 12, v[7:8]                // 000000753EA0: D6FE7C00 041D180C
	v_add_co_ci_u32_e64 v4, null, s1, v8, vcc_lo               // 000000753EA8: D5207C04 01AA1001
	s_lshl_b64 s[0:1], s[12:13], 3                             // 000000753EB0: 8480830C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753EB4: BF870099
	.long 0xd7006a05                                           // 000000753EB8: D7006A05
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 000000753EBC: 02000107
	v_add_co_ci_u32_e64 v6, null, s1, v8, vcc_lo               // 000000753EC0: D5207C06 01AA1001
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000753EC8: D6FE7C01 0405180D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000753ED0: BF870093
	.long 0xd7006a09                                           // 000000753ED4: D7006A09
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 000000753ED8: 02000105
	v_add_co_ci_u32_e64 v10, null, s1, v6, vcc_lo              // 000000753EDC: D5207C0A 01AA0C01
	s_clause 0x4                                               // 000000753EE4: BF850004
	global_store_b32 v[7:8], v15, off                          // 000000753EE8: DC6A0000 007C0F07
	global_store_b32 v[3:4], v14, off                          // 000000753EF0: DC6A0000 007C0E03
	global_store_b32 v[5:6], v11, off                          // 000000753EF8: DC6A0000 007C0B05
	global_store_b32 v[0:1], v13, off                          // 000000753F00: DC6A0000 007C0D00
	global_store_b32 v[9:10], v12, off                         // 000000753F08: DC6A0000 007C0C09
	s_endpgm                                                   // 000000753F10: BFB00000
		...

