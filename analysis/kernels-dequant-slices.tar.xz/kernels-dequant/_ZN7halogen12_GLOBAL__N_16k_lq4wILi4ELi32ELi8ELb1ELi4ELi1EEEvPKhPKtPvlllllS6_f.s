0000000000f8f300 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000F8F300: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000F8F308: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000F8F30C: 32040082
	v_lshrrev_b32_e32 v22, 5, v0                               // 000000F8F310: 322C0085
	v_and_b32_e32 v23, 31, v0                                  // 000000F8F314: 362E009F
	.long 0x7f0a3880                                           // 000000F8F318: 7F0A3880
	v_lshlrev_b32_e32 v21, 2, v0                               // 000000F8F31C: 302A0082
	s_waitcnt lgkmcnt(0)                                       // 000000F8F320: BF89FC07
	.long 0xd4510000                                           // 000000F8F324: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000F8F328: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000F8F32C: 8B007E00
	s_cselect_b32 s20, s3, 0                                   // 000000F8F330: 98148003
	s_cselect_b32 s21, s2, 0                                   // 000000F8F334: 98158002
	s_add_u32 s0, s4, s16                                      // 000000F8F338: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000F8F33C: 82011105
	v_and_b32_e32 v1, 15, v0                                   // 000000F8F340: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 000000F8F344: 360404BC
	s_ashr_i32 s16, s11, 31                                    // 000000F8F348: 86109F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F8F34C: BF870119
	s_lshr_b32 s16, s16, 27                                    // 000000F8F350: 85109B10
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F8F354: 30020282
	s_add_u32 s16, s10, s16                                    // 000000F8F358: 8010100A
	s_clause 0x1                                               // 000000F8F35C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000F8F360: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000F8F368: DC520000 04040002
	s_addc_u32 s17, s11, 0                                     // 000000F8F370: 8211800B
	v_mov_b32_e32 v2, s1                                       // 000000F8F374: 7E040201
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000F8F378: 85908510
	v_mov_b32_e32 v1, s0                                       // 000000F8F37C: 7E020200
	s_add_i32 s17, s16, 7                                      // 000000F8F380: 81118710
	s_mul_i32 s1, s19, s21                                     // 000000F8F384: 96011513
	s_ashr_i32 s22, s17, 31                                    // 000000F8F388: 86169F11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000F8F38C: BF8704B9
	s_lshr_b32 s0, s22, 29                                     // 000000F8F390: 85009D16
	v_mad_u64_u32 v[17:18], null, s18, s21, v[1:2]             // 000000F8F394: D6FE7C11 04042A12
	s_add_i32 s17, s17, s0                                     // 000000F8F39C: 81110011
	s_ashr_i32 s0, s17, 3                                      // 000000F8F3A0: 86008311
	s_cmpk_lt_i32 s16, 0x801                                   // 000000F8F3A4: B3900801
	.long 0xd72c0001                                           // 000000F8F3A8: D72C0001
	v_cndmask_b32_e32 v1, s0, v22, vcc_lo                      // 000000F8F3AC: 02022C00
	s_mul_i32 s17, s18, s20                                    // 000000F8F3B0: 96111412
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F8F3B4: BF870141
	v_add_nc_u32_e32 v7, s0, v1                                // 000000F8F3B8: 4A0E0200
	v_add_nc_u32_e32 v24, v1, v23                              // 000000F8F3BC: 4A302F01
	s_cselect_b32 s0, -1, 0                                    // 000000F8F3C0: 980080C1
	s_cmpk_gt_i32 s16, 0x800                                   // 000000F8F3C4: B2900800
	v_min_i32_e32 v25, s16, v7                                 // 000000F8F3C8: 22320E10
	s_cselect_b32 s16, -1, 0                                   // 000000F8F3CC: 981080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000F8F3D0: BF870159
	s_and_b32 vcc_lo, exec_lo, s16                             // 000000F8F3D4: 8B6A107E
	s_waitcnt vmcnt(1)                                         // 000000F8F3D8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 000000F8F3DC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 000000F8F3E4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 000000F8F3E8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000F8F3F0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s1, v18                               // 000000F8F3FC: 4A062401
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F8F400: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000F8F404: D6550004 03FE0D04 00007FFF
	.long 0xd4410001                                           // 000000F8F410: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000F8F414: 02023318
	.long 0x7e0a3982                                           // 000000F8F418: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F8F41C: BF870114
	v_add_nc_u32_e32 v26, s17, v3                              // 000000F8F420: 4A340611
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 000000F8F424: D6570001 041608FF FFFF0000
	ds_store_b32 v21, v1                                       // 000000F8F430: D8340000 00000115
	s_waitcnt lgkmcnt(0)                                       // 000000F8F438: BF89FC07
	s_barrier                                                  // 000000F8F43C: BFBD0000
	buffer_gl0_inv                                             // 000000F8F440: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000F8F448: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 000000F8F44C: CA100080 02000080
	s_and_saveexec_b32 s17, s1                                 // 000000F8F454: BE912001
	s_cbranch_execz 11                                         // 000000F8F458: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v24                               // 000000F8F45C: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8F460: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 000000F8F464: 3408029F
	.long 0xd7006a03                                           // 000000F8F468: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000F8F46C: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 000000F8F470: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 000000F8F478: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 000000F8F480: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000F8F484: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000F8F488: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 000000F8F48C: 4A0630A0
	s_mov_b32 s1, exec_lo                                      // 000000F8F490: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F8F494: BF870001
	.long 0xd4c1007e                                           // 000000F8F498: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 000000F8F49C: 02023303
	s_cbranch_execz 11                                         // 000000F8F4A0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v2, 1, v3                                // 000000F8F4A4: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8F4A8: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000F8F4AC: 3406049F
	.long 0xd7006a02                                           // 000000F8F4B0: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 000000F8F4B4: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 000000F8F4B8: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 000000F8F4C0: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000F8F4C8: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000F8F4CC: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F8F4D0: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 000000F8F4D4: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 000000F8F4DC: 7E060280
	s_mov_b32 s1, exec_lo                                      // 000000F8F4E0: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F8F4E4: BF870002
	.long 0xd4c1007e                                           // 000000F8F4E8: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 000000F8F4EC: 02023305
	s_cbranch_execz 11                                         // 000000F8F4F0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v3, 1, v5                                // 000000F8F4F4: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8F4F8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 000000F8F4FC: 340C069F
	.long 0xd7006a05                                           // 000000F8F500: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000F8F504: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 000000F8F508: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 000000F8F510: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 000000F8F518: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000F8F51C: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F8F520: 8C7E017E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 000000F8F524: 4A0A30FF 00000060
	s_mov_b32 s1, exec_lo                                      // 000000F8F52C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F8F530: BF870001
	.long 0xd4c1007e                                           // 000000F8F534: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 000000F8F538: 02023305
	s_cbranch_execz 11                                         // 000000F8F53C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v4, 1, v5                                // 000000F8F540: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8F544: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 000000F8F548: 340A089F
	.long 0xd7006a04                                           // 000000F8F54C: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 000000F8F550: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 000000F8F554: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 000000F8F55C: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000F8F564: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000F8F568: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F8F56C: 8C7E017E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 000000F8F570: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 000000F8F57C: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 000000F8F580: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F8F584: BF870002
	.long 0xd4c1007e                                           // 000000F8F588: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 000000F8F58C: 02023307
	s_cbranch_execz 11                                         // 000000F8F590: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v5, 1, v7                                // 000000F8F594: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8F598: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 000000F8F59C: 34100A9F
	.long 0xd7006a07                                           // 000000F8F5A0: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 000000F8F5A4: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 000000F8F5A8: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 000000F8F5B0: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 000000F8F5B8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 000000F8F5BC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F8F5C0: 8C7E017E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 000000F8F5C4: 4A0E30FF 000000A0
	s_mov_b32 s1, exec_lo                                      // 000000F8F5CC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F8F5D0: BF870001
	.long 0xd4c1007e                                           // 000000F8F5D4: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 000000F8F5D8: 02023307
	s_cbranch_execz 11                                         // 000000F8F5DC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v6, 1, v7                                // 000000F8F5E0: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8F5E4: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000F8F5E8: 340E0C9F
	.long 0xd7006a06                                           // 000000F8F5EC: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 000000F8F5F0: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 000000F8F5F4: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 000000F8F5FC: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000F8F604: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000F8F608: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F8F60C: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v9, 0xc0, v24    // 000000F8F610: CA200080 080830FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 000000F8F61C: 7E0E0280
	s_mov_b32 s1, exec_lo                                      // 000000F8F620: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F8F624: BF870002
	.long 0xd4c1007e                                           // 000000F8F628: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 000000F8F62C: 02023309
	s_cbranch_execz 11                                         // 000000F8F630: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v7, 1, v9                                // 000000F8F634: 300E1281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8F638: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v7                              // 000000F8F63C: 34140E9F
	.long 0xd7006a09                                           // 000000F8F640: D7006A09
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 000000F8F644: 02020F11
	v_add_co_ci_u32_e64 v10, null, v26, v10, vcc_lo            // 000000F8F648: D5207C0A 01AA151A
	global_load_d16_b16 v7, v[9:10], off                       // 000000F8F650: DC820000 077C0009
	s_waitcnt vmcnt(0)                                         // 000000F8F658: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000F8F65C: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F8F660: 8C7E017E
	v_add_nc_u32_e32 v9, 0xe0, v24                             // 000000F8F664: 4A1230FF 000000E0
	s_mov_b32 s1, exec_lo                                      // 000000F8F66C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F8F670: BF870001
	.long 0xd4c1007e                                           // 000000F8F674: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 000000F8F678: 02023309
	s_cbranch_execz 11                                         // 000000F8F67C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v8, 1, v9                                // 000000F8F680: 30101281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8F684: BF8700A1
	v_ashrrev_i32_e32 v9, 31, v8                               // 000000F8F688: 3412109F
	.long 0xd7006a08                                           // 000000F8F68C: D7006A08
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 000000F8F690: 02021111
	v_add_co_ci_u32_e64 v9, null, v26, v9, vcc_lo              // 000000F8F694: D5207C09 01AA131A
	global_load_d16_b16 v8, v[8:9], off                        // 000000F8F69C: DC820000 087C0008
	s_waitcnt vmcnt(0)                                         // 000000F8F6A4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 000000F8F6A8: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F8F6AC: 8C7E017E
	s_branch 9                                                 // 000000F8F6B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v1, 0                                        // 000000F8F6B4: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F8F6B8: BF870001
	v_mov_b32_e32 v2, v1                                       // 000000F8F6BC: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000F8F6C0: 7E060301
	v_mov_b32_e32 v4, v1                                       // 000000F8F6C4: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000F8F6C8: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000F8F6CC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000F8F6D0: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000F8F6D4: 7E100301
	s_add_u32 s4, s4, s14                                      // 000000F8F6D8: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000F8F6DC: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 000000F8F6E0: 85019F0B
	v_dual_mov_b32 v9, s21 :: v_dual_mov_b32 v20, 0            // 000000F8F6E4: CA100015 09140080
	s_add_u32 s14, s10, s1                                     // 000000F8F6EC: 800E010A
	s_addc_u32 s15, s11, 0                                     // 000000F8F6F0: 820F800B
	.long 0xd4410001                                           // 000000F8F6F4: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000F8F6F8: 02023318
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000F8F6FC: 868E810E
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v14, 0             // 000000F8F700: CA100080 0D0E0080
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 000000F8F708: D6FE7C12 00101D09
	.long 0xd72c0009                                           // 000000F8F710: D72C0009
	v_cndmask_b32_e32 v0, s21, v15, vcc_lo                     // 000000F8F714: 02001E15
	.long 0xd72c000a                                           // 000000F8F718: D72C000A
	v_cndmask_b32_e32 v0, s20, v14, vcc_lo                     // 000000F8F71C: 02001C14
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v16, 0             // 000000F8F720: CA100080 1B100080
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 000000F8F728: D501001C 00410280
	v_mov_b32_e32 v15, 0                                       // 000000F8F730: 7E1E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000F8F734: BF870004
	v_add3_u32 v29, v10, v19, v9                               // 000000F8F738: D655001D 0426270A
	s_and_saveexec_b32 s4, s1                                  // 000000F8F740: BE842001
	s_cbranch_execz 22                                         // 000000F8F744: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v9, 4, v24     // 000000F8F748: CA220080 14083084
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8F750: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000F8F754: 3414129F
	.long 0xd7006a09                                           // 000000F8F758: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 000000F8F75C: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 000000F8F760: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000F8F768: 916A107E
	global_load_b128 v[13:16], v[9:10], off                    // 000000F8F76C: DC5E0000 0D7C0009
	s_cbranch_vccnz 10                                         // 000000F8F774: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v9, 1, v24                               // 000000F8F778: 30123081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8F77C: BF870091
	.long 0xd7006a09                                           // 000000F8F780: D7006A09
	v_cndmask_b32_e32 v1, v17, v9, vcc_lo                      // 000000F8F784: 02021311
	v_add_co_ci_u32_e64 v10, null, 0, v26, vcc_lo              // 000000F8F788: D5207C0A 01AA3480
	global_load_d16_b16 v9, v[9:10], off                       // 000000F8F790: DC820000 097C0009
	s_waitcnt vmcnt(0)                                         // 000000F8F798: BF8903F7
	v_cvt_f32_f16_e32 v20, v9                                  // 000000F8F79C: 7E281709
	s_or_b32 exec_lo, exec_lo, s4                              // 000000F8F7A0: 8C7E047E
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 000000F8F7A4: CA100080 1F200080
	v_mov_b32_e32 v30, 0                                       // 000000F8F7AC: 7E3C0280
	s_and_saveexec_b32 s14, s1                                 // 000000F8F7B0: BE8E2001
	s_cbranch_execz 429                                        // 000000F8F7B4: BFA501AD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xb6c>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v9, 32, v24     // 000000F8F7B8: CA200080 1E0830A0
	v_dual_mov_b32 v32, 0 :: v_dual_lshlrev_b32 v19, 5, v24    // 000000F8F7C0: CA220080 20123085
	v_mov_b32_e32 v27, 0                                       // 000000F8F7C8: 7E360280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F8F7CC: BF870003
	v_lshlrev_b32_e32 v33, 4, v9                               // 000000F8F7D0: 30421284
	v_dual_mov_b32 v31, 0 :: v_dual_lshlrev_b32 v34, 1, v9     // 000000F8F7D4: CA220080 1F221281
	v_mov_b32_e32 v35, v20                                     // 000000F8F7DC: 7E460314
	s_mul_i32 s1, s11, 6                                       // 000000F8F7E0: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 000000F8F7E4: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000F8F7E8: 8484820A
	s_add_i32 s15, s15, s1                                     // 000000F8F7EC: 810F010F
	s_mul_i32 s17, s10, 6                                      // 000000F8F7F0: 9611860A
	s_mov_b32 s16, 0                                           // 000000F8F7F4: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000F8F7F8: 848A810A
	s_branch 375                                               // 000000F8F7FC: BFA00177 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xadc>
	s_or_b32 exec_lo, exec_lo, s18                             // 000000F8F800: 8C7E127E
	v_cndmask_b32_e64 v50, v20, v1, s0                         // 000000F8F804: D5010032 00020314
	v_cndmask_b32_e64 v36, v1, v2, s0                          // 000000F8F80C: D5010024 00020501
	v_and_b32_e32 v1, 0xff, v13                                // 000000F8F814: 36021AFF 000000FF
	v_cndmask_b32_e64 v42, v7, v8, s0                          // 000000F8F81C: D501002A 00021107
	v_cndmask_b32_e64 v41, v6, v7, s0                          // 000000F8F824: D5010029 00020F06
	v_cndmask_b32_e64 v40, v5, v6, s0                          // 000000F8F82C: D5010028 00020D05
	v_cndmask_b32_e64 v39, v4, v5, s0                          // 000000F8F834: D5010027 00020B04
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F8F83C: 30020282
	v_cndmask_b32_e64 v38, v3, v4, s0                          // 000000F8F840: D5010026 00020903
	v_cndmask_b32_e64 v37, v2, v3, s0                          // 000000F8F848: D5010025 00020702
	v_mov_b32_e32 v43, v8                                      // 000000F8F850: 7E560308
	v_ashrrev_i32_e32 v20, 31, v19                             // 000000F8F854: 3428269F
	ds_load_b32 v51, v1                                        // 000000F8F858: D8D80000 33000001
	v_lshrrev_b32_e32 v1, 6, v13                               // 000000F8F860: 32021A86
	v_add_nc_u32_e32 v33, 0x200, v33                           // 000000F8F864: 4A4242FF 00000200
	s_and_b32 s1, exec_lo, s1                                  // 000000F8F86C: 8B01017E
	v_add_nc_u32_e32 v34, 64, v34                              // 000000F8F870: 4A4444C0
	s_or_b32 s16, s1, s16                                      // 000000F8F874: 8C101001
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000F8F878: 360202FF 000003FC
	ds_load_b32 v52, v1                                        // 000000F8F880: D8D80000 34000001
	v_lshrrev_b32_e32 v1, 14, v13                              // 000000F8F888: 32021A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F8F88C: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000F8F890: 360202FF 000003FC
	ds_load_b32 v53, v1                                        // 000000F8F898: D8D80000 35000001
	v_lshrrev_b32_e32 v1, 22, v13                              // 000000F8F8A0: 32021A96
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000F8F8A4: 360202FF 000003FC
	ds_load_b32 v54, v1                                        // 000000F8F8AC: D8D80000 36000001
	v_and_b32_e32 v1, 0xff, v14                                // 000000F8F8B4: 36021CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F8F8BC: BF8700B1
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F8F8C0: 30020282
	ds_load_b32 v55, v1                                        // 000000F8F8C4: D8D80000 37000001
	v_lshrrev_b32_e32 v1, 6, v14                               // 000000F8F8CC: 32021C86
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000F8F8D0: 360202FF 000003FC
	ds_load_b32 v56, v1                                        // 000000F8F8D8: D8D80000 38000001
	v_lshrrev_b32_e32 v1, 14, v14                              // 000000F8F8E0: 32021C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F8F8E4: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000F8F8E8: 360202FF 000003FC
	ds_load_b32 v57, v1                                        // 000000F8F8F0: D8D80000 39000001
	v_lshrrev_b32_e32 v1, 22, v14                              // 000000F8F8F8: 32021C96
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000F8F8FC: 360202FF 000003FC
	ds_load_b32 v58, v1                                        // 000000F8F904: D8D80000 3A000001
	v_and_b32_e32 v1, 0xff, v15                                // 000000F8F90C: 36021EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F8F914: BF8700B1
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F8F918: 30020282
	ds_load_b32 v59, v1                                        // 000000F8F91C: D8D80000 3B000001
	v_lshrrev_b32_e32 v1, 6, v15                               // 000000F8F924: 32021E86
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000F8F928: 360202FF 000003FC
	ds_load_b32 v60, v1                                        // 000000F8F930: D8D80000 3C000001
	v_lshrrev_b32_e32 v1, 14, v15                              // 000000F8F938: 32021E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F8F93C: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000F8F940: 360202FF 000003FC
	ds_load_b32 v61, v1                                        // 000000F8F948: D8D80000 3D000001
	v_lshrrev_b32_e32 v1, 22, v15                              // 000000F8F950: 32021E96
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000F8F954: 360202FF 000003FC
	ds_load_b32 v62, v1                                        // 000000F8F95C: D8D80000 3E000001
	v_and_b32_e32 v1, 0xff, v16                                // 000000F8F964: 360220FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F8F96C: BF8700B1
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F8F970: 30020282
	ds_load_b32 v63, v1                                        // 000000F8F974: D8D80000 3F000001
	v_lshrrev_b32_e32 v1, 6, v16                               // 000000F8F97C: 32022086
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000F8F980: 360202FF 000003FC
	ds_load_b32 v64, v1                                        // 000000F8F988: D8D80000 40000001
	v_lshrrev_b32_e32 v1, 14, v16                              // 000000F8F990: 3202208E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F8F994: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000F8F998: 360202FF 000003FC
	ds_load_b32 v65, v1                                        // 000000F8F9A0: D8D80000 41000001
	v_lshrrev_b32_e32 v1, 22, v16                              // 000000F8F9A8: 32022096
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000F8F9AC: 360202FF 000003FC
	ds_load_b32 v66, v1                                        // 000000F8F9B4: D8D80000 42000001
	.long 0xd73c0001                                           // 000000F8F9BC: D73C0001
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000F8F9C0: 02022681
	v_dual_mov_b32 v20, v35 :: v_dual_add_nc_u32 v19, 0x400, v19// 000000F8F9C4: CA200123 141226FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8F9D0: BF870092
	.long 0xd7006a30                                           // 000000F8F9D4: D7006A30
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 000000F8F9D8: 02020206
	v_add_co_ci_u32_e64 v49, null, s7, v2, vcc_lo              // 000000F8F9DC: D5207C31 01AA0407
	s_clause 0x3                                               // 000000F8F9E4: BF850003
	global_load_b128 v[1:4], v[48:49], off                     // 000000F8F9E8: DC5E0000 017C0030
	global_load_b128 v[5:8], v[48:49], off offset:16           // 000000F8F9F0: DC5E0010 057C0030
	global_load_b128 v[13:16], v[48:49], off offset:32         // 000000F8F9F8: DC5E0020 0D7C0030
	global_load_b128 v[44:47], v[48:49], off offset:48         // 000000F8FA00: DC5E0030 2C7C0030
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000F8FA08: BF890CF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 000000F8FA0C: CC1A4001 1A026701
	s_waitcnt lgkmcnt(14)                                      // 000000F8FA14: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8FA18: BF8700A1
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 000000F8FA1C: CC1A4001 1C066902
	s_waitcnt lgkmcnt(13)                                      // 000000F8FA24: BF89FCD7
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 000000F8FA28: CC1A4001 1C066B03
	s_waitcnt lgkmcnt(12)                                      // 000000F8FA30: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8FA34: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 000000F8FA38: CC1A4001 1C066D04
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000F8FA40: BF8908B7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 000000F8FA44: CC1A4001 1C066F05
	s_waitcnt lgkmcnt(10)                                      // 000000F8FA4C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8FA50: BF8700A1
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 000000F8FA54: CC1A4001 1C067106
	s_waitcnt lgkmcnt(9)                                       // 000000F8FA5C: BF89FC97
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 000000F8FA60: CC1A4001 1C067307
	s_waitcnt lgkmcnt(8)                                       // 000000F8FA68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8FA6C: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 000000F8FA70: CC1A4001 1C067508
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000F8FA78: BF890477
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 000000F8FA7C: CC1A4001 1C06770D
	s_waitcnt lgkmcnt(6)                                       // 000000F8FA84: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8FA88: BF8700A1
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 000000F8FA8C: CC1A4001 1C06790E
	s_waitcnt lgkmcnt(5)                                       // 000000F8FA94: BF89FC57
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 000000F8FA98: CC1A4001 1C067B0F
	s_waitcnt lgkmcnt(4)                                       // 000000F8FAA0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8FAA4: BF8700A1
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 000000F8FAA8: CC1A4001 1C067D10
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000F8FAB0: BF890037
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 000000F8FAB4: CC1A4001 1C067F2C
	.long 0xd7006a2c                                           // 000000F8FABC: D7006A2C
	v_cndmask_b32_e32 v0, v48, v10, vcc_lo                     // 000000F8FAC0: 02001530
	s_waitcnt lgkmcnt(2)                                       // 000000F8FAC4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000F8FAC8: BF870132
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 000000F8FACC: CC1A4001 1C06812D
	v_add_co_ci_u32_e64 v45, null, s11, v49, vcc_lo            // 000000F8FAD4: D5207C2D 01AA620B
	s_waitcnt lgkmcnt(1)                                       // 000000F8FADC: BF89FC17
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 000000F8FAE0: CC1A4001 1C06832E
	s_waitcnt lgkmcnt(0)                                       // 000000F8FAE8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8FAEC: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 000000F8FAF0: CC1A4001 1C06852F
	v_fmac_f32_e32 v30, v50, v1                                // 000000F8FAF8: 563C0332
	s_clause 0x3                                               // 000000F8FAFC: BF850003
	global_load_b128 v[1:4], v[44:45], off                     // 000000F8FB00: DC5E0000 017C002C
	global_load_b128 v[5:8], v[44:45], off offset:16           // 000000F8FB08: DC5E0010 057C002C
	global_load_b128 v[13:16], v[44:45], off offset:32         // 000000F8FB10: DC5E0020 0D7C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 000000F8FB18: DC5E0030 2C7C002C
	s_waitcnt vmcnt(3)                                         // 000000F8FB20: BF890FF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 000000F8FB24: CC1A4001 1A026701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8FB2C: BF870091
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 000000F8FB30: CC1A4001 1C066902
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 000000F8FB38: CC1A4001 1C066B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8FB40: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 000000F8FB44: CC1A4001 1C066D04
	s_waitcnt vmcnt(2)                                         // 000000F8FB4C: BF890BF7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 000000F8FB50: CC1A4001 1C066F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8FB58: BF870091
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 000000F8FB5C: CC1A4001 1C067106
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 000000F8FB64: CC1A4001 1C067307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8FB6C: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 000000F8FB70: CC1A4001 1C067508
	s_waitcnt vmcnt(1)                                         // 000000F8FB78: BF8907F7
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 000000F8FB7C: CC1A4001 1C06770D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8FB84: BF870091
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 000000F8FB88: CC1A4001 1C06790E
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 000000F8FB90: CC1A4001 1C067B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8FB98: BF8700A1
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 000000F8FB9C: CC1A4001 1C067D10
	s_waitcnt vmcnt(0)                                         // 000000F8FBA4: BF8903F7
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 000000F8FBA8: CC1A4001 1C067F2C
	.long 0xd7006a2c                                           // 000000F8FBB0: D7006A2C
	v_cndmask_b32_e32 v0, v48, v4, vcc_lo                      // 000000F8FBB4: 02000930
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F8FBB8: BF870122
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 000000F8FBBC: CC1A4001 1C06812D
	v_add_co_ci_u32_e64 v45, null, s5, v49, vcc_lo             // 000000F8FBC4: D5207C2D 01AA6205
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 000000F8FBCC: CC1A4001 1C06832E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8FBD4: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 000000F8FBD8: CC1A4001 1C06852F
	v_fmac_f32_e32 v32, v50, v1                                // 000000F8FBE0: 56400332
	s_clause 0x3                                               // 000000F8FBE4: BF850003
	global_load_b128 v[1:4], v[44:45], off                     // 000000F8FBE8: DC5E0000 017C002C
	global_load_b128 v[5:8], v[44:45], off offset:16           // 000000F8FBF0: DC5E0010 057C002C
	global_load_b128 v[13:16], v[44:45], off offset:32         // 000000F8FBF8: DC5E0020 0D7C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 000000F8FC00: DC5E0030 2C7C002C
	s_waitcnt vmcnt(3)                                         // 000000F8FC08: BF890FF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 000000F8FC0C: CC1A4001 1A026701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8FC14: BF870091
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 000000F8FC18: CC1A4001 1C066902
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 000000F8FC20: CC1A4001 1C066B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8FC28: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 000000F8FC2C: CC1A4001 1C066D04
	s_waitcnt vmcnt(2)                                         // 000000F8FC34: BF890BF7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 000000F8FC38: CC1A4001 1C066F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8FC40: BF870091
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 000000F8FC44: CC1A4001 1C067106
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 000000F8FC4C: CC1A4001 1C067307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8FC54: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 000000F8FC58: CC1A4001 1C067508
	s_waitcnt vmcnt(1)                                         // 000000F8FC60: BF8907F7
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 000000F8FC64: CC1A4001 1C06770D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8FC6C: BF870091
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 000000F8FC70: CC1A4001 1C06790E
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 000000F8FC78: CC1A4001 1C067B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8FC80: BF8700A1
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 000000F8FC84: CC1A4001 1C067D10
	s_waitcnt vmcnt(0)                                         // 000000F8FC8C: BF8903F7
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 000000F8FC90: CC1A4001 1C067F2C
	.long 0xd7006a2c                                           // 000000F8FC98: D7006A2C
	v_cndmask_b32_e32 v0, v48, v17, vcc_lo                     // 000000F8FC9C: 02002330
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F8FCA0: BF870122
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 000000F8FCA4: CC1A4001 1C06812D
	v_add_co_ci_u32_e64 v45, null, s15, v49, vcc_lo            // 000000F8FCAC: D5207C2D 01AA620F
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 000000F8FCB4: CC1A4001 1C06832E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8FCBC: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 000000F8FCC0: CC1A4001 1C06852F
	v_fmac_f32_e32 v31, v50, v1                                // 000000F8FCC8: 563E0332
	s_clause 0x3                                               // 000000F8FCCC: BF850003
	global_load_b128 v[1:4], v[44:45], off                     // 000000F8FCD0: DC5E0000 017C002C
	global_load_b128 v[5:8], v[44:45], off offset:16           // 000000F8FCD8: DC5E0010 057C002C
	global_load_b128 v[13:16], v[44:45], off offset:32         // 000000F8FCE0: DC5E0020 0D7C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 000000F8FCE8: DC5E0030 2C7C002C
	s_waitcnt vmcnt(3)                                         // 000000F8FCF0: BF890FF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 000000F8FCF4: CC1A4001 1A026701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8FCFC: BF870091
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 000000F8FD00: CC1A4001 1C066902
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 000000F8FD08: CC1A4001 1C066B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8FD10: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 000000F8FD14: CC1A4001 1C066D04
	s_waitcnt vmcnt(2)                                         // 000000F8FD1C: BF890BF7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 000000F8FD20: CC1A4001 1C066F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8FD28: BF870091
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 000000F8FD2C: CC1A4001 1C067106
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 000000F8FD34: CC1A4001 1C067307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8FD3C: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 000000F8FD40: CC1A4001 1C067508
	s_waitcnt vmcnt(1)                                         // 000000F8FD48: BF8907F7
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 000000F8FD4C: CC1A4001 1C06770D
	v_mov_b32_e32 v13, v9                                      // 000000F8FD54: 7E1A0309
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F8FD58: BF870122
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 000000F8FD5C: CC1A4001 1C06790E
	v_mov_b32_e32 v14, v10                                     // 000000F8FD64: 7E1C030A
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 000000F8FD68: CC1A4001 1C067B0F
	v_mov_b32_e32 v15, v11                                     // 000000F8FD70: 7E1E030B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000F8FD74: BF870132
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 000000F8FD78: CC1A4001 1C067D10
	v_mov_b32_e32 v16, v12                                     // 000000F8FD80: 7E20030C
	s_waitcnt vmcnt(0)                                         // 000000F8FD84: BF8903F7
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 000000F8FD88: CC1A4001 1C067F2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8FD90: BF870091
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 000000F8FD94: CC1A4001 1C06812D
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 000000F8FD9C: CC1A4001 1C06832E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8FDA4: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 000000F8FDA8: CC1A4001 1C06852F
	v_fmac_f32_e32 v27, v50, v1                                // 000000F8FDB0: 56360332
	v_dual_mov_b32 v1, v36 :: v_dual_mov_b32 v2, v37           // 000000F8FDB4: CA100124 01020125
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v39           // 000000F8FDBC: CA100126 03040127
	v_dual_mov_b32 v5, v40 :: v_dual_mov_b32 v6, v41           // 000000F8FDC4: CA100128 05060129
	v_dual_mov_b32 v7, v42 :: v_dual_mov_b32 v8, v43           // 000000F8FDCC: CA10012A 0708012B
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000F8FDD4: 917E107E
	s_cbranch_execz 35                                         // 000000F8FDD8: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xb68>
	s_waitcnt vmcnt(0)                                         // 000000F8FDDC: BF8903F7
	v_dual_mov_b32 v9, v13 :: v_dual_add_nc_u32 v24, 32, v24   // 000000F8FDE0: CA20010D 091830A0
	v_dual_mov_b32 v10, v14 :: v_dual_mov_b32 v11, v15         // 000000F8FDE8: CA10010E 0A0A010F
	v_mov_b32_e32 v12, v16                                     // 000000F8FDF0: 7E180310
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F8FDF4: BF870003
	.long 0xd4460001                                           // 000000F8FDF8: D4460001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000F8FDFC: 02023318
	s_mov_b32 s18, exec_lo                                     // 000000F8FE00: BE92007E
	.long 0xd4c1007e                                           // 000000F8FE04: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000F8FE08: 02023318
	s_cbranch_execz 65148                                      // 000000F8FE0C: BFA5FE7C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	v_ashrrev_i32_e32 v10, 31, v33                             // 000000F8FE10: 3414429F
	.long 0xd7006a09                                           // 000000F8FE14: D7006A09
	v_cndmask_b32_e32 v1, v18, v33, vcc_lo                     // 000000F8FE18: 02024312
	v_mov_b32_e32 v35, v20                                     // 000000F8FE1C: 7E460314
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F8FE20: BF870003
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 000000F8FE24: D5207C0A 01AA151D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 000000F8FE2C: 7C9A3881
	global_load_b128 v[9:12], v[9:10], off                     // 000000F8FE30: DC5E0000 097C0009
	s_cbranch_vccnz 65137                                      // 000000F8FE38: BFA4FE71 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	v_ashrrev_i32_e32 v36, 31, v34                             // 000000F8FE3C: 3448449F
	.long 0xd7006a23                                           // 000000F8FE40: D7006A23
	v_cndmask_b32_e32 v1, v17, v34, vcc_lo                     // 000000F8FE44: 02024511
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F8FE48: BF870001
	v_add_co_ci_u32_e64 v36, null, v26, v36, vcc_lo            // 000000F8FE4C: D5207C24 01AA491A
	global_load_d16_b16 v35, v[35:36], off                     // 000000F8FE54: DC820000 237C0023
	s_waitcnt vmcnt(0)                                         // 000000F8FE5C: BF8903F7
	v_cvt_f32_f16_e32 v35, v35                                 // 000000F8FE60: 7E461723
	s_branch 65126                                             // 000000F8FE64: BFA0FE66 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000F8FE68: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F8FE6C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000F8FE70: 8C7E0E7E
	.long 0xd71f0001                                           // 000000F8FE74: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000F8FE78: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000F8FE7C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000F8FE80: 3A040290
	v_xor_b32_e32 v6, 8, v1                                    // 000000F8FE84: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 000000F8FE88: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F8FE8C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000F8FE90: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000F8FE94: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000F8FE98: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F8FE9C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000F8FEA0: 30040482
	ds_bpermute_b32 v5, v2, v31                                // 000000F8FEA4: DACC0000 05001F02
	s_waitcnt lgkmcnt(0)                                       // 000000F8FEAC: BF89FC07
	v_add_f32_e32 v5, v31, v5                                  // 000000F8FEB0: 060A0B1F
	ds_bpermute_b32 v3, v2, v30                                // 000000F8FEB4: DACC0000 03001E02
	ds_bpermute_b32 v4, v2, v32                                // 000000F8FEBC: DACC0000 04002002
	ds_bpermute_b32 v2, v2, v27                                // 000000F8FEC4: DACC0000 02001B02
	s_waitcnt lgkmcnt(2)                                       // 000000F8FECC: BF89FC27
	v_dual_add_f32 v3, v30, v3 :: v_dual_cndmask_b32 v6, v1, v6// 000000F8FED0: C912071E 03060D01
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000F8FED8: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F8FEDC: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 000000F8FEE0: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000F8FEE4: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 000000F8FEE8: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 000000F8FEF0: BF89FC07
	v_dual_add_f32 v5, v5, v9 :: v_dual_lshlrev_b32 v10, 2, v10// 000000F8FEF4: C9221305 050A1482
	ds_bpermute_b32 v7, v6, v3                                 // 000000F8FEFC: DACC0000 07000306
	v_add_f32_e32 v2, v27, v2                                  // 000000F8FF04: 0604051B
	s_waitcnt lgkmcnt(0)                                       // 000000F8FF08: BF89FC07
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v32, v4    // 000000F8FF0C: C9080F03 03040920
	ds_bpermute_b32 v8, v6, v4                                 // 000000F8FF14: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 000000F8FF1C: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 000000F8FF24: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 000000F8FF28: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 000000F8FF2C: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 000000F8FF34: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 000000F8FF3C: BF89FC17
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 000000F8FF40: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 000000F8FF48: DACC0000 0800050A
	s_waitcnt lgkmcnt(1)                                       // 000000F8FF50: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 000000F8FF54: 060C1302
	ds_bpermute_b32 v7, v10, v4                                // 000000F8FF58: DACC0000 0700040A
	v_xor_b32_e32 v10, 2, v1                                   // 000000F8FF60: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F8FF64: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000F8FF68: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000F8FF6C: 02141501
	s_waitcnt lgkmcnt(1)                                       // 000000F8FF70: BF89FC17
	v_dual_add_f32 v5, v5, v8 :: v_dual_lshlrev_b32 v10, 2, v10// 000000F8FF74: C9221105 050A1482
	ds_bpermute_b32 v2, v10, v3                                // 000000F8FF7C: DACC0000 0200030A
	s_waitcnt lgkmcnt(1)                                       // 000000F8FF84: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 000000F8FF88: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 000000F8FF8C: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 000000F8FF94: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 000000F8FF9C: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 000000F8FFA4: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F8FFA8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000F8FFAC: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 000000F8FFB0: 02021501
	s_waitcnt lgkmcnt(3)                                       // 000000F8FFB4: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 000000F8FFB8: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 000000F8FFC0: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 000000F8FFC4: 06061105
	s_waitcnt lgkmcnt(0)                                       // 000000F8FFC8: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 000000F8FFCC: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 000000F8FFD4: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 000000F8FFDC: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 000000F8FFE4: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 000000F8FFEC: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v23                                   // 000000F8FFF4: 7D942E80
	s_cbranch_execz 9                                          // 000000F8FFF8: BFA50009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xd20>
	s_waitcnt lgkmcnt(1)                                       // 000000F8FFFC: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_add_f32 v7, v3, v7     // 000000F90000: C9081105 08060F03
	s_waitcnt lgkmcnt(0)                                       // 000000F90008: BF89FC07
	v_dual_add_f32 v6, v2, v6 :: v_dual_add_f32 v5, v1, v4     // 000000F9000C: C9080D02 06040901
	v_lshlrev_b32_e32 v1, 4, v22                               // 000000F90014: 30022C84
	ds_store_b128 v1, v[5:8] offset:1024                       // 000000F90018: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s0                              // 000000F90020: 8C7E007E
	.long 0xd4510000                                           // 000000F90024: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000F90028: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 4, v0                             // 000000F9002C: 7C980084
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000F90030: BF890007
	s_barrier                                                  // 000000F90034: BFBD0000
	buffer_gl0_inv                                             // 000000F90038: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000F90040: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000F90044: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000F90048: BE812000
	s_cbranch_execz 74                                         // 000000F9004C: BFA5004A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xe78>
	v_add_nc_u32_e32 v7, 0x400, v21                            // 000000F90050: 4A0E2AFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000F90058: 84808202
	ds_load_2addr_b32 v[1:2], v7 offset1:4                     // 000000F9005C: D8DC0400 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:8 offset1:12          // 000000F90064: D8DC0C08 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:16 offset1:20         // 000000F9006C: D8DC1410 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000F90074: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000F90078: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000F9007C: BF8700C1
	v_add_f32_e32 v8, v1, v2                                   // 000000F90080: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:24 offset1:28         // 000000F90084: D8DC1C18 01000007
	s_waitcnt lgkmcnt(2)                                       // 000000F9008C: BF89FC27
	v_add_f32_e32 v3, v8, v3                                   // 000000F90090: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 000000F90094: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000F90098: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9009C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000F900A0: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000F900A4: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000F900A8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F900AC: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000F900B0: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000F900B4: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F900B8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000F900BC: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 000000F900C4: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F900C8: BF870095
	v_add_f32_e32 v4, 1.0, v1                                  // 000000F900CC: 060802F2
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 000000F900D0: D6FC7C05 03CA0904
	v_div_scale_f32 v7, vcc_lo, 1.0, v4, 1.0                   // 000000F900D8: D6FC6A07 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000F900E0: BF870292
	v_rcp_f32_e32 v6, v5                                       // 000000F900E4: 7E0C5505
	v_fma_f32 v1, -v5, v6, 1.0                                 // 000000F900E8: D6130001 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F900F0: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 000000F900F4: 560C0D01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000F900F8: D6FE7C01 0202000C
	v_mul_f32_e32 v8, v7, v6                                   // 000000F90100: 10100D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F90104: BF870112
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000F90108: D6FE7C02 040A000D
	v_fma_f32 v9, -v5, v8, v7                                  // 000000F90110: D6130009 241E1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F90118: BF870191
	v_fmac_f32_e32 v8, v9, v6                                  // 000000F9011C: 56100D09
	.long 0xd73c0000                                           // 000000F90120: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000F90124: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F90128: BF870092
	v_fma_f32 v3, -v5, v8, v7                                  // 000000F9012C: D6130003 241E1105
	v_div_fmas_f32 v2, v3, v6, v8                              // 000000F90134: D6370002 04220D03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9013C: BF870093
	.long 0xd7006a00                                           // 000000F90140: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000F90144: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000F90148: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F90150: BF870193
	v_div_fixup_f32 v2, v2, v4, 1.0                            // 000000F90154: D6270002 03CA0902
	.long 0xd7006a00                                           // 000000F9015C: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000F90160: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F90164: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000F90168: D5207C01 01AA0201
	global_store_b32 v[0:1], v2, off                           // 000000F90170: DC6A0000 007C0200
	s_endpgm                                                   // 000000F90178: BFB00000
		...

