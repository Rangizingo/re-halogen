0000000000f89500 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000F89500: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000F89508: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000F8950C: 32040082
	v_lshrrev_b32_e32 v22, 5, v0                               // 000000F89510: 322C0085
	v_and_b32_e32 v23, 31, v0                                  // 000000F89514: 362E009F
	.long 0x7f0a3880                                           // 000000F89518: 7F0A3880
	v_lshlrev_b32_e32 v21, 2, v0                               // 000000F8951C: 302A0082
	s_waitcnt lgkmcnt(0)                                       // 000000F89520: BF89FC07
	.long 0xd4510000                                           // 000000F89524: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000F89528: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000F8952C: 8B007E00
	s_cselect_b32 s20, s3, 0                                   // 000000F89530: 98148003
	s_cselect_b32 s21, s2, 0                                   // 000000F89534: 98158002
	s_add_u32 s0, s4, s16                                      // 000000F89538: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000F8953C: 82011105
	v_and_b32_e32 v1, 15, v0                                   // 000000F89540: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 000000F89544: 360404BC
	s_ashr_i32 s16, s11, 31                                    // 000000F89548: 86109F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F8954C: BF870119
	s_lshr_b32 s16, s16, 27                                    // 000000F89550: 85109B10
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F89554: 30020282
	s_add_u32 s16, s10, s16                                    // 000000F89558: 8010100A
	s_clause 0x1                                               // 000000F8955C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000F89560: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000F89568: DC520000 04040002
	s_addc_u32 s17, s11, 0                                     // 000000F89570: 8211800B
	v_mov_b32_e32 v2, s1                                       // 000000F89574: 7E040201
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000F89578: 85908510
	v_mov_b32_e32 v1, s0                                       // 000000F8957C: 7E020200
	s_add_i32 s17, s16, 7                                      // 000000F89580: 81118710
	s_mul_i32 s1, s19, s21                                     // 000000F89584: 96011513
	s_ashr_i32 s22, s17, 31                                    // 000000F89588: 86169F11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000F8958C: BF8704B9
	s_lshr_b32 s0, s22, 29                                     // 000000F89590: 85009D16
	v_mad_u64_u32 v[17:18], null, s18, s21, v[1:2]             // 000000F89594: D6FE7C11 04042A12
	s_add_i32 s17, s17, s0                                     // 000000F8959C: 81110011
	s_ashr_i32 s0, s17, 3                                      // 000000F895A0: 86008311
	s_cmpk_lt_i32 s16, 0x801                                   // 000000F895A4: B3900801
	.long 0xd72c0001                                           // 000000F895A8: D72C0001
	v_cndmask_b32_e32 v1, s0, v22, vcc_lo                      // 000000F895AC: 02022C00
	s_mul_i32 s17, s18, s20                                    // 000000F895B0: 96111412
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F895B4: BF870141
	v_add_nc_u32_e32 v7, s0, v1                                // 000000F895B8: 4A0E0200
	v_add_nc_u32_e32 v24, v1, v23                              // 000000F895BC: 4A302F01
	s_cselect_b32 s0, -1, 0                                    // 000000F895C0: 980080C1
	s_cmpk_gt_i32 s16, 0x800                                   // 000000F895C4: B2900800
	v_min_i32_e32 v25, s16, v7                                 // 000000F895C8: 22320E10
	s_cselect_b32 s16, -1, 0                                   // 000000F895CC: 981080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000F895D0: BF870159
	s_and_b32 vcc_lo, exec_lo, s16                             // 000000F895D4: 8B6A107E
	s_waitcnt vmcnt(1)                                         // 000000F895D8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 000000F895DC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 000000F895E4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 000000F895E8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000F895F0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s1, v18                               // 000000F895FC: 4A062401
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F89600: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000F89604: D6550004 03FE0D04 00007FFF
	.long 0xd4410001                                           // 000000F89610: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000F89614: 02023318
	.long 0x7e0a3982                                           // 000000F89618: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F8961C: BF870114
	v_add_nc_u32_e32 v26, s17, v3                              // 000000F89620: 4A340611
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 000000F89624: D6570001 041608FF FFFF0000
	ds_store_b32 v21, v1                                       // 000000F89630: D8340000 00000115
	s_waitcnt lgkmcnt(0)                                       // 000000F89638: BF89FC07
	s_barrier                                                  // 000000F8963C: BFBD0000
	buffer_gl0_inv                                             // 000000F89640: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000F89648: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 000000F8964C: CA100080 02000080
	s_and_saveexec_b32 s17, s1                                 // 000000F89654: BE912001
	s_cbranch_execz 11                                         // 000000F89658: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v24                               // 000000F8965C: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F89660: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 000000F89664: 3408029F
	.long 0xd7006a03                                           // 000000F89668: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000F8966C: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 000000F89670: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 000000F89678: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 000000F89680: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000F89684: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000F89688: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 000000F8968C: 4A0630A0
	s_mov_b32 s1, exec_lo                                      // 000000F89690: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F89694: BF870001
	.long 0xd4c1007e                                           // 000000F89698: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 000000F8969C: 02023303
	s_cbranch_execz 11                                         // 000000F896A0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v2, 1, v3                                // 000000F896A4: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F896A8: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000F896AC: 3406049F
	.long 0xd7006a02                                           // 000000F896B0: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 000000F896B4: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 000000F896B8: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 000000F896C0: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000F896C8: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000F896CC: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F896D0: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 000000F896D4: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 000000F896DC: 7E060280
	s_mov_b32 s1, exec_lo                                      // 000000F896E0: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F896E4: BF870002
	.long 0xd4c1007e                                           // 000000F896E8: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 000000F896EC: 02023305
	s_cbranch_execz 11                                         // 000000F896F0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v3, 1, v5                                // 000000F896F4: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F896F8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 000000F896FC: 340C069F
	.long 0xd7006a05                                           // 000000F89700: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000F89704: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 000000F89708: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 000000F89710: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 000000F89718: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000F8971C: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F89720: 8C7E017E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 000000F89724: 4A0A30FF 00000060
	s_mov_b32 s1, exec_lo                                      // 000000F8972C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F89730: BF870001
	.long 0xd4c1007e                                           // 000000F89734: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 000000F89738: 02023305
	s_cbranch_execz 11                                         // 000000F8973C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v4, 1, v5                                // 000000F89740: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F89744: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 000000F89748: 340A089F
	.long 0xd7006a04                                           // 000000F8974C: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 000000F89750: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 000000F89754: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 000000F8975C: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000F89764: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000F89768: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F8976C: 8C7E017E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 000000F89770: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 000000F8977C: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 000000F89780: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F89784: BF870002
	.long 0xd4c1007e                                           // 000000F89788: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 000000F8978C: 02023307
	s_cbranch_execz 11                                         // 000000F89790: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v5, 1, v7                                // 000000F89794: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F89798: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 000000F8979C: 34100A9F
	.long 0xd7006a07                                           // 000000F897A0: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 000000F897A4: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 000000F897A8: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 000000F897B0: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 000000F897B8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 000000F897BC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F897C0: 8C7E017E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 000000F897C4: 4A0E30FF 000000A0
	s_mov_b32 s1, exec_lo                                      // 000000F897CC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F897D0: BF870001
	.long 0xd4c1007e                                           // 000000F897D4: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 000000F897D8: 02023307
	s_cbranch_execz 11                                         // 000000F897DC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v6, 1, v7                                // 000000F897E0: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F897E4: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000F897E8: 340E0C9F
	.long 0xd7006a06                                           // 000000F897EC: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 000000F897F0: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 000000F897F4: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 000000F897FC: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000F89804: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000F89808: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F8980C: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v9, 0xc0, v24    // 000000F89810: CA200080 080830FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 000000F8981C: 7E0E0280
	s_mov_b32 s1, exec_lo                                      // 000000F89820: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F89824: BF870002
	.long 0xd4c1007e                                           // 000000F89828: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 000000F8982C: 02023309
	s_cbranch_execz 11                                         // 000000F89830: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v7, 1, v9                                // 000000F89834: 300E1281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F89838: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v7                              // 000000F8983C: 34140E9F
	.long 0xd7006a09                                           // 000000F89840: D7006A09
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 000000F89844: 02020F11
	v_add_co_ci_u32_e64 v10, null, v26, v10, vcc_lo            // 000000F89848: D5207C0A 01AA151A
	global_load_d16_b16 v7, v[9:10], off                       // 000000F89850: DC820000 077C0009
	s_waitcnt vmcnt(0)                                         // 000000F89858: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000F8985C: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F89860: 8C7E017E
	v_add_nc_u32_e32 v9, 0xe0, v24                             // 000000F89864: 4A1230FF 000000E0
	s_mov_b32 s1, exec_lo                                      // 000000F8986C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F89870: BF870001
	.long 0xd4c1007e                                           // 000000F89874: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 000000F89878: 02023309
	s_cbranch_execz 11                                         // 000000F8987C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v8, 1, v9                                // 000000F89880: 30101281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F89884: BF8700A1
	v_ashrrev_i32_e32 v9, 31, v8                               // 000000F89888: 3412109F
	.long 0xd7006a08                                           // 000000F8988C: D7006A08
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 000000F89890: 02021111
	v_add_co_ci_u32_e64 v9, null, v26, v9, vcc_lo              // 000000F89894: D5207C09 01AA131A
	global_load_d16_b16 v8, v[8:9], off                        // 000000F8989C: DC820000 087C0008
	s_waitcnt vmcnt(0)                                         // 000000F898A4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 000000F898A8: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F898AC: 8C7E017E
	s_branch 9                                                 // 000000F898B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v1, 0                                        // 000000F898B4: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F898B8: BF870001
	v_mov_b32_e32 v2, v1                                       // 000000F898BC: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000F898C0: 7E060301
	v_mov_b32_e32 v4, v1                                       // 000000F898C4: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000F898C8: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000F898CC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000F898D0: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000F898D4: 7E100301
	s_add_u32 s4, s4, s14                                      // 000000F898D8: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000F898DC: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 000000F898E0: 85019F0B
	v_dual_mov_b32 v9, s21 :: v_dual_mov_b32 v10, 0            // 000000F898E4: CA100015 090A0080
	s_add_u32 s14, s10, s1                                     // 000000F898EC: 800E010A
	s_addc_u32 s15, s11, 0                                     // 000000F898F0: 820F800B
	.long 0xd4410001                                           // 000000F898F4: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000F898F8: 02023318
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000F898FC: 868E810E
	v_mov_b32_e32 v27, 0                                       // 000000F89900: 7E360280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 000000F89904: D6FE7C12 00101D09
	.long 0xd72c000b                                           // 000000F8990C: D72C000B
	v_cndmask_b32_e32 v0, s21, v15, vcc_lo                     // 000000F89910: 02001E15
	.long 0xd72c000c                                           // 000000F89914: D72C000C
	v_cndmask_b32_e32 v0, s20, v14, vcc_lo                     // 000000F89918: 02001C14
	v_mov_b32_e32 v9, 0                                        // 000000F8991C: 7E120280
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 000000F89920: D501001C 00410280
	v_mov_b32_e32 v35, 0                                       // 000000F89928: 7E460280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000F8992C: BF870004
	v_add3_u32 v29, v12, v19, v11                              // 000000F89930: D655001D 042E270C
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 000000F89938: CA100080 0B0C0080
	s_and_saveexec_b32 s4, s1                                  // 000000F89940: BE842001
	s_cbranch_execz 22                                         // 000000F89944: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v9, 4, v24                               // 000000F89948: 30123084
	v_mov_b32_e32 v35, 0                                       // 000000F8994C: 7E460280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F89950: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000F89954: 3414129F
	.long 0xd7006a09                                           // 000000F89958: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 000000F8995C: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 000000F89960: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000F89968: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 000000F8996C: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 000000F89974: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v13, 1, v24                              // 000000F89978: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8997C: BF870091
	.long 0xd7006a0d                                           // 000000F89980: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 000000F89984: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 000000F89988: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 000000F89990: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 000000F89998: BF8903F7
	v_cvt_f32_f16_e32 v35, v13                                 // 000000F8999C: 7E46170D
	s_or_b32 exec_lo, exec_lo, s4                              // 000000F899A0: 8C7E047E
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0             // 000000F899A4: CA100080 1F1E0080
	s_and_saveexec_b32 s14, s1                                 // 000000F899AC: BE8E2001
	s_cbranch_execz 338                                        // 000000F899B0: BFA50152 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x9fc>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v13, 32, v24    // 000000F899B4: CA200080 1E0C30A0
	v_dual_mov_b32 v34, v35 :: v_dual_lshlrev_b32 v19, 5, v24  // 000000F899BC: CA220123 22123085
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F899C4: BF870002
	v_dual_mov_b32 v31, 0 :: v_dual_lshlrev_b32 v32, 4, v13    // 000000F899C8: CA220080 1F201A84
	v_lshlrev_b32_e32 v33, 1, v13                              // 000000F899D0: 30421A81
	v_mov_b32_e32 v27, 0                                       // 000000F899D4: 7E360280
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000F899D8: 8484820A
	s_mov_b32 s15, 0                                           // 000000F899DC: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000F899E0: 848A810A
	s_branch 289                                               // 000000F899E4: BFA00121 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x96c>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000F899E8: 8C7E107E
	v_ashrrev_i32_e32 v20, 31, v19                             // 000000F899EC: 3428269F
	v_cndmask_b32_e64 v84, v35, v1, s0                         // 000000F899F0: D5010054 00020323
	v_lshrrev_b32_e32 v35, 6, v9                               // 000000F899F8: 32461286
	v_lshrrev_b32_e32 v85, 14, v9                              // 000000F899FC: 32AA128E
	v_and_b32_e32 v86, 0xff, v10                               // 000000F89A00: 36AC14FF 000000FF
	.long 0xd73c0024                                           // 000000F89A08: D73C0024
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000F89A0C: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 000000F89A10: 362812FF 000000FF
	v_and_b32_e32 v35, 0x3fc, v35                              // 000000F89A18: 364646FF 000003FC
	v_and_b32_e32 v85, 0x3fc, v85                              // 000000F89A20: 36AAAAFF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 000000F89A28: 32121296
	v_lshrrev_b32_e32 v87, 6, v10                              // 000000F89A2C: 32AE1486
	.long 0xd7006a48                                           // 000000F89A30: D7006A48
	v_cndmask_b32_e32 v1, s6, v36, vcc_lo                      // 000000F89A34: 02024806
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F89A38: BF8701A1
	v_add_co_ci_u32_e64 v73, null, s7, v37, vcc_lo             // 000000F89A3C: D5207C49 01AA4A07
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000F89A44: 30282882
	.long 0xd7006a4c                                           // 000000F89A48: D7006A4C
	v_cndmask_b32_e32 v0, v72, v10, vcc_lo                     // 000000F89A4C: 02001548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F89A50: BF8700A1
	v_add_co_ci_u32_e64 v77, null, s11, v73, vcc_lo            // 000000F89A54: D5207C4D 01AA920B
	.long 0xd7006a50                                           // 000000F89A5C: D7006A50
	v_cndmask_b32_e32 v0, v72, v4, vcc_lo                      // 000000F89A60: 02000948
	v_add_co_ci_u32_e64 v81, null, s5, v73, vcc_lo             // 000000F89A64: D5207C51 01AA9205
	s_clause 0xb                                               // 000000F89A6C: BF85000B
	global_load_b128 v[36:39], v[72:73], off                   // 000000F89A70: DC5E0000 247C0048
	global_load_b128 v[40:43], v[76:77], off                   // 000000F89A78: DC5E0000 287C004C
	global_load_b128 v[44:47], v[80:81], off                   // 000000F89A80: DC5E0000 2C7C0050
	global_load_b128 v[48:51], v[72:73], off offset:16         // 000000F89A88: DC5E0010 307C0048
	global_load_b128 v[52:55], v[76:77], off offset:16         // 000000F89A90: DC5E0010 347C004C
	global_load_b128 v[56:59], v[80:81], off offset:16         // 000000F89A98: DC5E0010 387C0050
	global_load_b128 v[60:63], v[72:73], off offset:32         // 000000F89AA0: DC5E0020 3C7C0048
	global_load_b128 v[64:67], v[76:77], off offset:32         // 000000F89AA8: DC5E0020 407C004C
	global_load_b128 v[68:71], v[80:81], off offset:32         // 000000F89AB0: DC5E0020 447C0050
	global_load_b128 v[72:75], v[72:73], off offset:48         // 000000F89AB8: DC5E0030 487C0048
	global_load_b128 v[76:79], v[76:77], off offset:48         // 000000F89AC0: DC5E0030 4C7C004C
	global_load_b128 v[80:83], v[80:81], off offset:48         // 000000F89AC8: DC5E0030 507C0050
	ds_load_b32 v20, v20                                       // 000000F89AD0: D8D80000 14000014
	ds_load_b32 v35, v35                                       // 000000F89AD8: D8D80000 23000023
	ds_load_b32 v85, v85                                       // 000000F89AE0: D8D80000 55000055
	v_lshrrev_b32_e32 v88, 14, v10                             // 000000F89AE8: 32B0148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 000000F89AEC: 32141496
	v_lshlrev_b32_e32 v86, 2, v86                              // 000000F89AF0: 30ACAC82
	v_and_b32_e32 v87, 0x3fc, v87                              // 000000F89AF4: 36AEAEFF 000003FC
	v_and_b32_e32 v89, 0xff, v11                               // 000000F89AFC: 36B216FF 000000FF
	v_and_b32_e32 v88, 0x3fc, v88                              // 000000F89B04: 36B0B0FF 000003FC
	v_lshrrev_b32_e32 v90, 6, v11                              // 000000F89B0C: 32B41686
	v_lshrrev_b32_e32 v91, 14, v11                             // 000000F89B10: 32B6168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 000000F89B14: 32161696
	v_lshrrev_b32_e32 v93, 14, v12                             // 000000F89B18: 32BA188E
	v_add_nc_u32_e32 v33, 64, v33                              // 000000F89B1C: 4A4242C0
	v_add_nc_u32_e32 v19, 0x400, v19                           // 000000F89B20: 4A2626FF 00000400
	s_and_b32 s1, exec_lo, s1                                  // 000000F89B28: 8B01017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000F89B2C: BF870009
	s_or_b32 s15, s1, s15                                      // 000000F89B30: 8C0F0F01
	s_waitcnt vmcnt(11) lgkmcnt(2)                             // 000000F89B34: BF892C27
	v_dot2_f32_bf16 v36, v36, v20, 0                           // 000000F89B38: CC1A4024 1A022924
	s_waitcnt vmcnt(10)                                        // 000000F89B40: BF892BF7
	v_dot2_f32_bf16 v40, v40, v20, 0                           // 000000F89B44: CC1A4028 1A022928
	s_waitcnt vmcnt(9)                                         // 000000F89B4C: BF8927F7
	v_dot2_f32_bf16 v20, v44, v20, 0                           // 000000F89B50: CC1A4014 1A02292C
	v_lshrrev_b32_e32 v44, 6, v12                              // 000000F89B58: 32581886
	s_waitcnt lgkmcnt(1)                                       // 000000F89B5C: BF89FC17
	v_dot2_f32_bf16 v36, v37, v35, v36                         // 000000F89B60: CC1A4024 1C924725
	v_dot2_f32_bf16 v37, v41, v35, v40                         // 000000F89B68: CC1A4025 1CA24729
	v_dot2_f32_bf16 v20, v45, v35, v20                         // 000000F89B70: CC1A4014 1C52472D
	v_and_b32_e32 v40, 0x3fc, v91                              // 000000F89B78: 3650B6FF 000003FC
	v_and_b32_e32 v41, 0x3fc, v93                              // 000000F89B80: 3652BAFF 000003FC
	s_waitcnt lgkmcnt(0)                                       // 000000F89B88: BF89FC07
	v_dot2_f32_bf16 v36, v38, v85, v36                         // 000000F89B8C: CC1A4024 1C92AB26
	v_dot2_f32_bf16 v37, v42, v85, v37                         // 000000F89B94: CC1A4025 1C96AB2A
	v_cndmask_b32_e64 v42, v7, v8, s0                          // 000000F89B9C: D501002A 00021107
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F89BA4: 361212FF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000F89BAC: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 000000F89BB4: D8D80000 09000009
	ds_load_b32 v86, v86                                       // 000000F89BBC: D8D80000 56000056
	ds_load_b32 v87, v87                                       // 000000F89BC4: D8D80000 57000057
	ds_load_b32 v88, v88                                       // 000000F89BCC: D8D80000 58000058
	ds_load_b32 v10, v10                                       // 000000F89BD4: D8D80000 0A00000A
	v_dot2_f32_bf16 v20, v46, v85, v20                         // 000000F89BDC: CC1A4014 1C52AB2E
	v_lshlrev_b32_e32 v35, 2, v89                              // 000000F89BE4: 3046B282
	v_and_b32_e32 v38, 0x3fc, v90                              // 000000F89BE8: 364CB4FF 000003FC
	ds_load_b32 v35, v35                                       // 000000F89BF0: D8D80000 23000023
	ds_load_b32 v38, v38                                       // 000000F89BF8: D8D80000 26000026
	s_waitcnt lgkmcnt(6)                                       // 000000F89C00: BF89FC67
	v_dot2_f32_bf16 v36, v39, v9, v36                          // 000000F89C04: CC1A4024 1C921327
	v_dot2_f32_bf16 v37, v43, v9, v37                          // 000000F89C0C: CC1A4025 1C96132B
	v_dot2_f32_bf16 v9, v47, v9, v20                           // 000000F89C14: CC1A4009 1C52132F
	ds_load_b32 v43, v40                                       // 000000F89C1C: D8D80000 2B000028
	v_and_b32_e32 v92, 0xff, v12                               // 000000F89C24: 36B818FF 000000FF
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 000000F89C2C: BF892067
	v_dot2_f32_bf16 v36, v48, v86, v36                         // 000000F89C30: CC1A4024 1C92AD30
	s_waitcnt vmcnt(7)                                         // 000000F89C38: BF891FF7
	v_dot2_f32_bf16 v37, v52, v86, v37                         // 000000F89C3C: CC1A4025 1C96AD34
	s_waitcnt vmcnt(6)                                         // 000000F89C44: BF891BF7
	v_dot2_f32_bf16 v9, v56, v86, v9                           // 000000F89C48: CC1A4009 1C26AD38
	v_lshrrev_b32_e32 v12, 22, v12                             // 000000F89C50: 32181896
	v_cndmask_b32_e64 v40, v5, v6, s0                          // 000000F89C54: D5010028 00020D05
	s_waitcnt lgkmcnt(5)                                       // 000000F89C5C: BF89FC57
	v_dot2_f32_bf16 v36, v49, v87, v36                         // 000000F89C60: CC1A4024 1C92AF31
	v_dot2_f32_bf16 v37, v53, v87, v37                         // 000000F89C68: CC1A4025 1C96AF35
	v_dot2_f32_bf16 v9, v57, v87, v9                           // 000000F89C70: CC1A4009 1C26AF39
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000F89C78: 361616FF 000003FC
	v_lshlrev_b32_e32 v20, 2, v92                              // 000000F89C80: 3028B882
	s_waitcnt lgkmcnt(4)                                       // 000000F89C84: BF89FC47
	v_dot2_f32_bf16 v36, v50, v88, v36                         // 000000F89C88: CC1A4024 1C92B132
	v_dot2_f32_bf16 v37, v54, v88, v37                         // 000000F89C90: CC1A4025 1C96B136
	v_dot2_f32_bf16 v9, v58, v88, v9                           // 000000F89C98: CC1A4009 1C26B13A
	v_and_b32_e32 v39, 0x3fc, v44                              // 000000F89CA0: 364E58FF 000003FC
	v_and_b32_e32 v12, 0x3fc, v12                              // 000000F89CA8: 361818FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000F89CB0: BF89FC37
	v_dot2_f32_bf16 v36, v51, v10, v36                         // 000000F89CB4: CC1A4024 1C921533
	v_dot2_f32_bf16 v37, v55, v10, v37                         // 000000F89CBC: CC1A4025 1C961537
	v_dot2_f32_bf16 v9, v59, v10, v9                           // 000000F89CC4: CC1A4009 1C26153B
	ds_load_b32 v10, v11                                       // 000000F89CCC: D8D80000 0A00000B
	ds_load_b32 v11, v20                                       // 000000F89CD4: D8D80000 0B000014
	ds_load_b32 v20, v39                                       // 000000F89CDC: D8D80000 14000027
	ds_load_b32 v44, v41                                       // 000000F89CE4: D8D80000 2C000029
	ds_load_b32 v45, v12                                       // 000000F89CEC: D8D80000 2D00000C
	v_cndmask_b32_e64 v41, v6, v7, s0                          // 000000F89CF4: D5010029 00020F06
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 000000F89CFC: BF891477
	v_dot2_f32_bf16 v12, v60, v35, v36                         // 000000F89D00: CC1A400C 1C92473C
	s_waitcnt vmcnt(4)                                         // 000000F89D08: BF8913F7
	v_dot2_f32_bf16 v36, v64, v35, v37                         // 000000F89D0C: CC1A4024 1C964740
	s_waitcnt vmcnt(3)                                         // 000000F89D14: BF890FF7
	v_dot2_f32_bf16 v9, v68, v35, v9                           // 000000F89D18: CC1A4009 1C264744
	v_cndmask_b32_e64 v39, v4, v5, s0                          // 000000F89D20: D5010027 00020B04
	v_cndmask_b32_e64 v37, v2, v3, s0                          // 000000F89D28: D5010025 00020702
	s_waitcnt lgkmcnt(6)                                       // 000000F89D30: BF89FC67
	v_dot2_f32_bf16 v7, v61, v38, v12                          // 000000F89D34: CC1A4007 1C324D3D
	v_dot2_f32_bf16 v12, v65, v38, v36                         // 000000F89D3C: CC1A400C 1C924D41
	v_dot2_f32_bf16 v9, v69, v38, v9                           // 000000F89D44: CC1A4009 1C264D45
	v_cndmask_b32_e64 v38, v3, v4, s0                          // 000000F89D4C: D5010026 00020903
	v_cndmask_b32_e64 v36, v1, v2, s0                          // 000000F89D54: D5010024 00020501
	s_waitcnt lgkmcnt(5)                                       // 000000F89D5C: BF89FC57
	v_dot2_f32_bf16 v5, v62, v43, v7                           // 000000F89D60: CC1A4005 1C1E573E
	v_dot2_f32_bf16 v6, v66, v43, v12                          // 000000F89D68: CC1A4006 1C325742
	v_dot2_f32_bf16 v7, v70, v43, v9                           // 000000F89D70: CC1A4007 1C265746
	v_dual_mov_b32 v43, v8 :: v_dual_add_nc_u32 v32, 0x200, v32// 000000F89D78: CA200108 2B2040FF 00000200
	s_waitcnt lgkmcnt(4)                                       // 000000F89D84: BF89FC47
	v_dot2_f32_bf16 v3, v63, v10, v5                           // 000000F89D88: CC1A4003 1C16153F
	v_dot2_f32_bf16 v4, v67, v10, v6                           // 000000F89D90: CC1A4004 1C1A1543
	v_dot2_f32_bf16 v5, v71, v10, v7                           // 000000F89D98: CC1A4005 1C1E1547
	v_mov_b32_e32 v12, v16                                     // 000000F89DA0: 7E180310
	v_mov_b32_e32 v10, v14                                     // 000000F89DA4: 7E14030E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 000000F89DA8: BF890837
	v_dot2_f32_bf16 v1, v72, v11, v3                           // 000000F89DAC: CC1A4001 1C0E1748
	s_waitcnt vmcnt(1)                                         // 000000F89DB4: BF8907F7
	v_dot2_f32_bf16 v2, v76, v11, v4                           // 000000F89DB8: CC1A4002 1C12174C
	s_waitcnt vmcnt(0)                                         // 000000F89DC0: BF8903F7
	v_dot2_f32_bf16 v3, v80, v11, v5                           // 000000F89DC4: CC1A4003 1C161750
	v_mov_b32_e32 v11, v15                                     // 000000F89DCC: 7E16030F
	v_mov_b32_e32 v9, v13                                      // 000000F89DD0: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 000000F89DD4: BF89FC27
	v_dot2_f32_bf16 v1, v73, v20, v1                           // 000000F89DD8: CC1A4001 1C062949
	v_dot2_f32_bf16 v2, v77, v20, v2                           // 000000F89DE0: CC1A4002 1C0A294D
	v_dot2_f32_bf16 v3, v81, v20, v3                           // 000000F89DE8: CC1A4003 1C0E2951
	v_mov_b32_e32 v35, v34                                     // 000000F89DF0: 7E460322
	s_waitcnt lgkmcnt(1)                                       // 000000F89DF4: BF89FC17
	v_dot2_f32_bf16 v1, v74, v44, v1                           // 000000F89DF8: CC1A4001 1C06594A
	v_dot2_f32_bf16 v2, v78, v44, v2                           // 000000F89E00: CC1A4002 1C0A594E
	v_dot2_f32_bf16 v3, v82, v44, v3                           // 000000F89E08: CC1A4003 1C0E5952
	s_waitcnt lgkmcnt(0)                                       // 000000F89E10: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F89E14: BF870193
	v_dot2_f32_bf16 v1, v75, v45, v1                           // 000000F89E18: CC1A4001 1C065B4B
	v_dot2_f32_bf16 v2, v79, v45, v2                           // 000000F89E20: CC1A4002 1C0A5B4F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F89E28: BF870193
	v_dot2_f32_bf16 v3, v83, v45, v3                           // 000000F89E2C: CC1A4003 1C0E5B53
	v_fmac_f32_e32 v30, v84, v1                                // 000000F89E34: 563C0354
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F89E38: BF870193
	v_fmac_f32_e32 v31, v84, v2                                // 000000F89E3C: 563E0554
	v_fmac_f32_e32 v27, v84, v3                                // 000000F89E40: 56360754
	v_dual_mov_b32 v1, v36 :: v_dual_mov_b32 v2, v37           // 000000F89E44: CA100124 01020125
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v39           // 000000F89E4C: CA100126 03040127
	v_dual_mov_b32 v5, v40 :: v_dual_mov_b32 v6, v41           // 000000F89E54: CA100128 05060129
	v_dual_mov_b32 v7, v42 :: v_dual_mov_b32 v8, v43           // 000000F89E5C: CA10012A 0708012B
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000F89E64: 917E0F7E
	s_cbranch_execz 35                                         // 000000F89E68: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x9f8>
	s_waitcnt vmcnt(0)                                         // 000000F89E6C: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 000000F89E70: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 000000F89E78: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 000000F89E80: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F89E84: BF870003
	.long 0xd4460001                                           // 000000F89E88: D4460001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000F89E8C: 02023318
	s_mov_b32 s16, exec_lo                                     // 000000F89E90: BE90007E
	.long 0xd4c1007e                                           // 000000F89E94: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000F89E98: 02023318
	s_cbranch_execz 65234                                      // 000000F89E9C: BFA5FED2 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4e8>
	v_ashrrev_i32_e32 v14, 31, v32                             // 000000F89EA0: 341C409F
	.long 0xd7006a0d                                           // 000000F89EA4: D7006A0D
	v_cndmask_b32_e32 v1, v18, v32, vcc_lo                     // 000000F89EA8: 02024112
	v_mov_b32_e32 v34, v35                                     // 000000F89EAC: 7E440323
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F89EB0: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 000000F89EB4: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 000000F89EBC: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 000000F89EC0: DC5E0000 0D7C000D
	s_cbranch_vccnz 65223                                      // 000000F89EC8: BFA4FEC7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4e8>
	v_ashrrev_i32_e32 v20, 31, v33                             // 000000F89ECC: 3428429F
	.long 0xd7006a24                                           // 000000F89ED0: D7006A24
	v_cndmask_b32_e32 v1, v17, v33, vcc_lo                     // 000000F89ED4: 02024311
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F89ED8: BF870001
	v_add_co_ci_u32_e64 v37, null, v26, v20, vcc_lo            // 000000F89EDC: D5207C25 01AA291A
	global_load_d16_b16 v20, v[36:37], off                     // 000000F89EE4: DC820000 147C0024
	s_waitcnt vmcnt(0)                                         // 000000F89EEC: BF8903F7
	v_cvt_f32_f16_e32 v34, v20                                 // 000000F89EF0: 7E441714
	s_branch 65212                                             // 000000F89EF4: BFA0FEBC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4e8>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000F89EF8: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F89EFC: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000F89F00: 8C7E0E7E
	.long 0xd71f0001                                           // 000000F89F04: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000F89F08: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000F89F0C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000F89F10: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 000000F89F14: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 000000F89F18: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F89F1C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000F89F20: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000F89F24: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000F89F28: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 000000F89F2C: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000F89F30: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F89F34: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000F89F38: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000F89F3C: 30040482
	ds_bpermute_b32 v3, v2, v30                                // 000000F89F40: DACC0000 03001E02
	s_waitcnt lgkmcnt(0)                                       // 000000F89F48: BF89FC07
	v_add_f32_e32 v3, v30, v3                                  // 000000F89F4C: 0606071E
	ds_bpermute_b32 v4, v2, v31                                // 000000F89F50: DACC0000 04001F02
	ds_bpermute_b32 v2, v2, v27                                // 000000F89F58: DACC0000 02001B02
	ds_bpermute_b32 v6, v5, v3                                 // 000000F89F60: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000F89F68: 02101101
	s_waitcnt lgkmcnt(2)                                       // 000000F89F6C: BF89FC27
	v_add_f32_e32 v4, v31, v4                                  // 000000F89F70: 0608091F
	s_waitcnt lgkmcnt(1)                                       // 000000F89F74: BF89FC17
	v_add_f32_e32 v2, v27, v2                                  // 000000F89F78: 0604051B
	s_waitcnt lgkmcnt(0)                                       // 000000F89F7C: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 000000F89F80: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 000000F89F84: DACC0000 07000405
	ds_bpermute_b32 v5, v5, v2                                 // 000000F89F8C: DACC0000 05000205
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000F89F94: 30101082
	s_waitcnt lgkmcnt(0)                                       // 000000F89F98: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 000000F89F9C: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 000000F89FA0: DACC0000 05000308
	s_waitcnt lgkmcnt(0)                                       // 000000F89FA8: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v7     // 000000F89FAC: C9080B03 03040F04
	ds_bpermute_b32 v7, v8, v2                                 // 000000F89FB4: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 000000F89FBC: DACC0000 06000408
	v_xor_b32_e32 v8, 2, v1                                    // 000000F89FC4: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F89FC8: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000F89FCC: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000F89FD0: 02101101
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000F89FD4: 30101082
	s_waitcnt lgkmcnt(1)                                       // 000000F89FD8: BF89FC17
	v_add_f32_e32 v2, v2, v7                                   // 000000F89FDC: 06040F02
	s_waitcnt lgkmcnt(0)                                       // 000000F89FE0: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 000000F89FE4: 06080D04
	ds_bpermute_b32 v5, v8, v3                                 // 000000F89FE8: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 000000F89FF0: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 000000F89FF8: DACC0000 06000408
	v_xor_b32_e32 v8, 1, v1                                    // 000000F8A000: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8A004: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000F8A008: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 000000F8A00C: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000F8A010: 30100282
	s_waitcnt lgkmcnt(1)                                       // 000000F8A014: BF89FC17
	v_dual_add_f32 v1, v3, v5 :: v_dual_add_f32 v2, v2, v7     // 000000F8A018: C9080B03 01020F02
	s_waitcnt lgkmcnt(0)                                       // 000000F8A020: BF89FC07
	v_add_f32_e32 v3, v4, v6                                   // 000000F8A024: 06060D04
	ds_bpermute_b32 v4, v8, v1                                 // 000000F8A028: DACC0000 04000108
	ds_bpermute_b32 v5, v8, v2                                 // 000000F8A030: DACC0000 05000208
	ds_bpermute_b32 v6, v8, v3                                 // 000000F8A038: DACC0000 06000308
	v_cmpx_eq_u32_e32 0, v23                                   // 000000F8A040: 7D942E80
	s_cbranch_execz 12                                         // 000000F8A044: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xb78>
	v_mul_u32_u24_e32 v7, 12, v22                              // 000000F8A048: 160E2C8C
	s_waitcnt lgkmcnt(0)                                       // 000000F8A04C: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v2, v2, v5     // 000000F8A050: C9080D03 03020B02
	v_add_f32_e32 v1, v1, v4                                   // 000000F8A058: 06020901
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F8A05C: BF870003
	v_or_b32_e32 v4, 0x400, v7                                 // 000000F8A060: 38080EFF 00000400
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 000000F8A068: D8380100 00030104
	ds_store_b32 v7, v2 offset:1032                            // 000000F8A070: D8340408 00000207
	s_or_b32 exec_lo, exec_lo, s0                              // 000000F8A078: 8C7E007E
	.long 0xd4510000                                           // 000000F8A07C: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000F8A080: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 3, v0                             // 000000F8A084: 7C980083
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000F8A088: BF890007
	s_barrier                                                  // 000000F8A08C: BFBD0000
	buffer_gl0_inv                                             // 000000F8A090: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000F8A098: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000F8A09C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000F8A0A0: BE812000
	s_cbranch_execz 74                                         // 000000F8A0A4: BFA5004A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xcd0>
	v_add_nc_u32_e32 v7, 0x400, v21                            // 000000F8A0A8: 4A0E2AFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000F8A0B0: 84808202
	ds_load_2addr_b32 v[1:2], v7 offset1:3                     // 000000F8A0B4: D8DC0300 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:6 offset1:9           // 000000F8A0BC: D8DC0906 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:12 offset1:15         // 000000F8A0C4: D8DC0F0C 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000F8A0CC: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000F8A0D0: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000F8A0D4: BF8700C1
	v_add_f32_e32 v8, v1, v2                                   // 000000F8A0D8: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:18 offset1:21         // 000000F8A0DC: D8DC1512 01000007
	s_waitcnt lgkmcnt(2)                                       // 000000F8A0E4: BF89FC27
	v_add_f32_e32 v3, v8, v3                                   // 000000F8A0E8: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 000000F8A0EC: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000F8A0F0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8A0F4: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000F8A0F8: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000F8A0FC: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000F8A100: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8A104: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000F8A108: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000F8A10C: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8A110: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000F8A114: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 000000F8A11C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8A120: BF870095
	v_add_f32_e32 v4, 1.0, v1                                  // 000000F8A124: 060802F2
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 000000F8A128: D6FC7C05 03CA0904
	v_div_scale_f32 v7, vcc_lo, 1.0, v4, 1.0                   // 000000F8A130: D6FC6A07 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000F8A138: BF870292
	v_rcp_f32_e32 v6, v5                                       // 000000F8A13C: 7E0C5505
	v_fma_f32 v1, -v5, v6, 1.0                                 // 000000F8A140: D6130001 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F8A148: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 000000F8A14C: 560C0D01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000F8A150: D6FE7C01 0202000C
	v_mul_f32_e32 v8, v7, v6                                   // 000000F8A158: 10100D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F8A15C: BF870112
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000F8A160: D6FE7C02 040A000D
	v_fma_f32 v9, -v5, v8, v7                                  // 000000F8A168: D6130009 241E1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F8A170: BF870191
	v_fmac_f32_e32 v8, v9, v6                                  // 000000F8A174: 56100D09
	.long 0xd73c0000                                           // 000000F8A178: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000F8A17C: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8A180: BF870092
	v_fma_f32 v3, -v5, v8, v7                                  // 000000F8A184: D6130003 241E1105
	v_div_fmas_f32 v2, v3, v6, v8                              // 000000F8A18C: D6370002 04220D03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8A194: BF870093
	.long 0xd7006a00                                           // 000000F8A198: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000F8A19C: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000F8A1A0: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F8A1A8: BF870193
	v_div_fixup_f32 v2, v2, v4, 1.0                            // 000000F8A1AC: D6270002 03CA0902
	.long 0xd7006a00                                           // 000000F8A1B4: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000F8A1B8: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F8A1BC: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000F8A1C0: D5207C01 01AA0201
	global_store_b32 v[0:1], v2, off                           // 000000F8A1C8: DC6A0000 007C0200
	s_endpgm                                                   // 000000F8A1D0: BFB00000
		...

